from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('.test_output');dest=Path('docs/evidence/nanolang-ownership-modules-20261121');inputs=dest/'inputs'
def digest(b):return hashlib.sha256(b).hexdigest()
results=dict(implementation_commit='a471982ca',terminal_commands=[
 dict(session=17549,command='bin/nanoc_c tests/nvm2c_module_driver.nano -o .test_output/ownership-module-driver',exit_code=0,log='ownership-module-first-build.log'),
 dict(session=14841,command='make obj/nvm2c_module_reference and rebuild reports driver',exit_code=0,logs=['ownership-module-reference-build.log','ownership-module-reports-build.log']),
 dict(session=9815,command='Linux original synthetic ownership module unittest, first test source retained',exit_code=0,log='ownership-module-linux-first.log'),
 dict(session=38408,command='Linux final ownership module unittest with genuine NanoLang producer',exit_code=0,log='ownership-module-linux-final.log'),
 dict(session=52441,command='Linux core and passive module regressions with genuine NanoLang producer',exit_code=0,log='ownership-module-linux-regression.log'),
 dict(session=12027,command='Darwin fetch/checkout a471982ca, build oracles, combined ownership/core/passive module unittests',exit_code=0,logs=['ownership-module-darwin-build.log','ownership-module-darwin-final.log']),
 dict(session=96283,command='Linux make test-embedded-nano-identifiers',exit_code=0,log='ownership-module-linux-identifiers.log'),
 dict(session=70290,command='Darwin make test-embedded-nano-identifiers',exit_code=0,log='ownership-module-darwin-identifiers.log')],observer_attempts=[
 dict(command='toolscheme -e \'(wait-for (quote (matches ".test_output/ownership-module-linux-final.log" "^OK$")) (timeout-ms 30000))\'',exit_code=1,stderr='toolscheme: unbound symbol: timeout-ms\n'),
 dict(session=33468,command='Same anchored marker with quoted timeout clause',exit_code=0,log='ownership-module-wait-corrected.log',meaning='Observer timeout, not a failed or restarted test.'),
 dict(command='Quoted timeout clause with unanchored OK marker',exit_code=0,log='ownership-module-wait-final.log',meaning='Observer satisfied; test exit codes above remain authoritative.')],limits=['These are observed command outcomes, not inferred from a last matching log line.','No product check failed during this checkpoint. The first pending allowance was tightened before the final paired qualification.'])
(root/'ownership-modules-terminal-results.json').write_text(json.dumps(results,indent=2)+'\n')
files=['ownership-modules-corpus.json.gz','ownership-modules-darwin-corpus.json.gz','ownership-modules-linux-products.json.gz','ownership-modules-darwin-products.json.gz','ownership-modules-linux-manifest.json','ownership-modules-darwin-manifest.json','ownership-modules-collect.py','ownership-modules-archive.py','ownership-modules-terminal-results.json','ownership-modules-corpus.log','ownership-module-first-test.py','ownership-module-first-build.log','ownership-module-reference-build.log','ownership-module-reports-build.log','ownership-module-linux-first.log','ownership-module-linux-final.log','ownership-module-linux-regression.log','ownership-module-linux-identifiers.log','ownership-module-darwin-build.log','ownership-module-darwin-final.log','ownership-module-darwin-identifiers.log','ownership-module-wait-corrected.log','ownership-module-wait-final.log']
records=[]
for name in files:
 data=(root/name).read_bytes();raw=gzip.decompress(data) if name.endswith('.gz') else data
 output=name if name.endswith('.gz') else name+'.gz';compressed=data if name.endswith('.gz') else gzip.compress(raw,mtime=0)
 (inputs/output).write_bytes(compressed)
 records.append(dict(path='inputs/'+output,raw_bytes=len(raw),raw_sha256=digest(raw),compressed_bytes=len(compressed),compressed_sha256=digest(compressed)))
for name in ['src_nano/nvm2c/module.nano','tests/nvm2c_module_driver.nano','tests/nvm2c_module_reference.c','tests/test_nanolang_translator_ownership_module.py','tests/test_nanolang_translator_module.py','tests/test_nanolang_translator_declarations.py','Makefile.gnu']:
 raw=subprocess.check_output(['git','show','a471982ca:'+name]);assert raw==Path(name).read_bytes()
 output='qualified-'+name.replace('/','_')+'.gz';compressed=gzip.compress(raw,mtime=0);(inputs/output).write_bytes(compressed)
 records.append(dict(path='inputs/'+output,raw_bytes=len(raw),raw_sha256=digest(raw),compressed_bytes=len(compressed),compressed_sha256=digest(compressed)))
(dest/'retained-inputs.json').write_text(json.dumps(dict(implementation_commit='a471982ca',inputs=records),indent=2)+'\n')
for r in records:
 data=(dest/r['path']).read_bytes();raw=gzip.decompress(data)
 assert digest(data)==r['compressed_sha256'] and len(data)==r['compressed_bytes']
 assert digest(raw)==r['raw_sha256'] and len(raw)==r['raw_bytes']
print('I verified',len(records),'retained inputs;',sum(r['compressed_bytes'] for r in records),'compressed bytes.')
