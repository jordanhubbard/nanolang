from pathlib import Path
import gzip,hashlib,json,os,platform,re,subprocess,sys,tempfile
from tests.test_nanolang_translator_ownership_module import corpus
from tests.nanolang_translator_routes import checked

def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,value):Path(path).write_bytes(gzip.compress((json.dumps(value,separators=(',',':'))+'\n').encode(),mtime=0))
def observe(*args):
 p=subprocess.run(args,capture_output=True,text=True);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

if sys.argv[1]=='--corpus':
 cases=corpus();records=[]
 with tempfile.TemporaryDirectory(prefix='ownership-module-corpus-') as d:
  paths=[];carrier_paths=[];map_reports={}
  for i,(_,data,_,_,carrier) in enumerate(cases):
   p=Path(d)/str(i);p.write_bytes(data);paths.append(p)
   if carrier is not None:
    p=Path(d)/('route-'+str(i));p.write_bytes(carrier);carrier_paths.append((i,p))
  for offset in range(0,len(carrier_paths),32):
   batch=carrier_paths[offset:offset+32]
   reports=checked(['obj/nvm2c_declaration_reference','0',*[p for _,p in batch]],timeout=600).splitlines();assert len(reports)==len(batch)
   map_reports.update({i:r for (i,_),r in zip(batch,reports)})
  reports=[]
  for offset in range(0,len(paths),32):reports+=checked(['obj/nvm2c_module_reference','--claims',*paths[offset:offset+32]],timeout=600).splitlines()
  assert len(reports)==len(cases)
  for i,((name,data,expected,private,carrier),report) in enumerate(zip(cases,reports)):
   if expected is not None:assert int(report.split(':')[0])==expected,(name,expected,report[:100])
   records.append(dict(name=name,bytes_hex=data.hex(),sha256=digest(data),explicit_status=expected,actual_c_claims_report=report,private_layout_scope=private,actual_c_routing_report=map_reports.get(i),routing_carrier_hex=carrier.hex() if carrier is not None else None))
 save('.test_output/ownership-modules-corpus.json.gz',records)
 print('I retained',len(records),'synthetic full modules and complete C claims reports;',sum(r['explicit_status'] is not None for r in records),'explicit statuses.')
elif sys.argv[1]=='--products':
 match=re.search(r'I retain actual producer modules/models at (.+)',Path(sys.argv[2]).read_text());assert match
 root=Path(match[1]);records=json.loads((root/'records.json').read_text());result=[]
 for record in records:
  module=(root/record['module']).read_bytes();model=(root/record['model']).read_bytes()
  assert digest(module)==record['module_sha256'] and digest(model)==record['model_sha256']
  assert digest(Path(record['source']).read_bytes())==record['source_sha256']
  assert model[:16]==bytes(16),'I require a separate carrier for foreign context.'
  report=checked(['obj/nvm2c_module_reference','--claims',root/record['module']],timeout=120).strip();assert report.startswith('0:')
  routing=checked(['obj/nvm2c_declaration_reference','0',root/record['model']],timeout=120).strip()
  result.append(dict(**record,module_bytes_hex=module.hex(),model_bytes_hex=model.hex(),actual_c_claims_report=report,actual_c_route_report=routing))
 save(sys.argv[3],result);print('I retained',len(result),'original producer modules, original VM results and C claims/routing reports.')
else:
 host='darwin' if sys.platform=='darwin' else 'linux'
 sources=['Makefile.gnu']+[str(p) for p in Path('src_nano/nvm2c').glob('*.nano')]+[str(p) for p in Path('tests').glob('nvm2c_*')]+[str(p) for p in Path('tests').glob('*nanolang_translator*.py')]+['tests/native_process.py']
 sources+=[str(p) for p in Path('src/nanoisa').iterdir() if p.suffix in ('.c','.h','.inc')]
 tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_module_reference','obj/nvm2c_declaration_reference','.test_output/ownership-source-final']
 hashes={s:digest(Path(s).read_bytes()) for s in tools}
 previous=json.loads(gzip.decompress(Path('docs/evidence/nanolang-ownership-20261120/inputs/ownership-'+host+'-manifest.json.gz').read_bytes()))
 assert previous['post_run_tool_sha256']['.test_output/ownership-source-final']==hashes['.test_output/ownership-source-final']
 result=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,sanitizer_environment={key:os.environ.get(key) for key in ('ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS')},source_sha256={s:digest(Path(s).read_bytes()) for s in sorted(set(sources))},post_run_tool_sha256=hashes,reused_compiler_matches_previous_receipt=True,limits=['I reuse the C-seed-built NanoLang compiler image from7cd173b30, verified against the previous paired ownership receipt.','My C whole-module and routing reference providers are ordinary builds. Generated C decoder fixtures are ASan/UBSan instrumented and link an ordinary AOT runtime.','I compare immutable narrow module views and exact ownership/passive bytes; allocation failure and arbitrary C pointer graphs are not modeled.','I retain selected private-profile inputs and their C results; NanoLang pending status -1 grants no successful admission.','Shared ownership module conversion does not perform ordinary instruction verification; accepting an unknown opcode here grants no execution authority.','This checkpoint does not establish private flow admission, service14, pure NanoLang C emission, raw fixed point, installed cutover or release acceptance.'])
 if sys.platform=='darwin':result.update(sdk=observe('xcrun','--sdk','macosx','--show-sdk-version'),sdk_path=observe('xcrun','--sdk','macosx','--show-sdk-path'),os=observe('sw_vers'))
 Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
