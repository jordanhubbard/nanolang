from pathlib import Path
import hashlib,json,platform,subprocess,sys,tempfile
from tests.test_nanolang_translator_private_layouts import corpus
from tests.nanolang_translator_routes import checked

def observe(*args):
    p=subprocess.run(args,capture_output=True,text=True)
    return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

if sys.argv[1] in ('--corpus','--asan'):
    cases=corpus(); reports={}
    with tempfile.TemporaryDirectory(prefix='nano-private-receipt-') as d:
        paths=[]
        for i,(_,data,_) in enumerate(cases):
            p=Path(d)/str(i);p.write_bytes(data);paths.append(p)
        for profile in range(4):
            values=[];ordinary=[]
            for i in range(0,len(paths),64):
                command='.test_output/private-layout-reference-asan' if sys.argv[1]=='--asan' else 'obj/nvm2c_private_layout_reference'
                values+=checked([command,str(profile),*paths[i:i+64]],timeout=600).splitlines()
                if sys.argv[1]=='--asan':ordinary+=checked(['obj/nvm2c_private_layout_reference',str(profile),*paths[i:i+64]],timeout=600).splitlines()
            assert len(values)==len(cases)
            for (name,_,expected),report in zip(cases,values):
                if expected is not None:assert int(report.split(':')[0])==expected[profile],(name,profile,expected,report[:30])
            if sys.argv[1]=='--asan':assert values==ordinary,profile
            reports[profile]=values
    if sys.argv[1]=='--corpus':
        records=[dict(name=name,bytes_hex=data.hex(),sha256=hashlib.sha256(data).hexdigest(),explicit_status=expected,actual_c_reports={p:reports[p][i] for p in range(4)}) for i,(name,data,expected) in enumerate(cases)]
        Path('.test_output/private-layout-corpus.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
    print('I matched',len(cases),'cases per profile across four C profiles;',sum(e is not None for _,_,e in cases)*4,'explicit expectations.',sys.argv[1])
else:
    sources=['src_nano/nvm2c/payloads.nano','src_nano/nvm2c/private_layouts.nano','tests/nvm2c_private_layout_driver.nano','tests/nvm2c_private_layout_reference.c','tests/test_nanolang_translator_private_layouts.py','tests/test_nanolang_translator_payloads.py','tests/nanolang_translator_routes.py','tests/native_process.py','src/nanoisa/nvm_v2_layouts.c','src/nanoisa/nvm_v2_cursor.c','src/nanoisa/ownership_layouts_private.h','src/nanoisa/nvm_v2_sections.h','src/nanoisa/isa.h','Makefile.gnu','src/typechecker.c','src_nano/typecheck.nano','src_nano/nanoc_v06.nano']
    tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_private_layout_reference','.test_output/private-layout-reference-asan','.test_output/ownership-source-final']
    record=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,source_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},post_run_tool_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in tools},limits=['I reuse the C-seed-built development NanoLang compiler at 7cd173b30; its frontend sources are unchanged.', 'My generated-C fixtures are instrumented and link an ordinary AOT runtime.', 'My separate C oracle sanitizer image instruments the complete layout/cursor providers and oracle.', 'I retain exact synthetic inputs and C re-encoded byte reports, not temporary unittest executables.', 'These private immutable views require immutable input; they grant no element, resource or execution authority.', 'I do not simulate allocation denial, claim complete leak freedom or a full SDK closure.'])
    if sys.platform=='darwin':record.update(sdk=observe('xcrun','--sdk','macosx','--show-sdk-version'),sdk_path=observe('xcrun','--sdk','macosx','--show-sdk-path'),os=observe('sw_vers'))
    Path(sys.argv[1]).write_text(json.dumps(record,indent=2)+'\n')
