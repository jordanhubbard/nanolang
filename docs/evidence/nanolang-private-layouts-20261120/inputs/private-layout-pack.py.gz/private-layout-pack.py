from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('docs/evidence/nanolang-private-layouts-20261120');inputs=root/'inputs';inputs.mkdir(exist_ok=True)
records=[]
def retain(name,data):
    packed=gzip.compress(data,mtime=0);(inputs/(name+'.gz')).write_bytes(packed)
    records.append(dict(path='inputs/'+name+'.gz',uncompressed_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),compressed_sha256=hashlib.sha256(packed).hexdigest()))
for p in sorted(Path('.test_output').glob('private-layout-*.log')):retain('linux-'+p.name,p.read_bytes())
for p in sorted(Path('.test_output/private-layout-darwin').glob('*.log')):retain('darwin-'+p.name,p.read_bytes())
for name in ['private-layout-corpus.json','private-layout-linux-manifest.json','private-layout-collect.py','private-layout-pack.py','private-layout-first-driver.nano','private-layout-first-tests.py','private-layout-launch-results.json']:
    retain(name,Path('.test_output',name).read_bytes())
retain('private-layout-darwin-manifest.json',Path('.test_output/private-layout-darwin/private-layout-darwin-manifest.json').read_bytes())
manifest=json.loads(Path('.test_output/private-layout-linux-manifest.json').read_text())
other=json.loads(Path('.test_output/private-layout-darwin/private-layout-darwin-manifest.json').read_text())
assert manifest['source_sha256']==other['source_sha256']
for name,sha in manifest['source_sha256'].items():
    data=subprocess.check_output(['git','show','a139ebd10:'+name]);assert hashlib.sha256(data).hexdigest()==sha,name
    retain('source-'+name.replace('/','_'),data)
raw=Path('.test_output/private-layout-corpus.json').read_bytes()
remote=gzip.decompress(Path('.test_output/private-layout-darwin/private-layout-corpus.json.gz').read_bytes())
assert raw==remote
(root/'retained-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
    packed=(root/r['path']).read_bytes();data=gzip.decompress(packed)
    assert len(data)==r['uncompressed_bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
    assert hashlib.sha256(packed).hexdigest()==r['compressed_sha256']
print('I retained and verified',len(records),'inputs; both hosts have identical corpus bytes/reports and source hashes.')
