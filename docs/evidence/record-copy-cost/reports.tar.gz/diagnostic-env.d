/home/jkh/nanolang-qualification/record-copy-cost-946/diagnostic-env.o: \
 /tmp/record-cost-env.c src/nanolang.h src/generated/compiler_schema.h \
 src/runtime/dyn_array.h src/runtime/gc.h src/runtime/dyn_array.h \
 src/runtime/gc_struct.h src/eval_u8.h src/nanolang.h \
 src/builtins_registry.h src/runtime/gc.h \
 /tmp/record-cost-env-records.inc src/runtime/list_int.h \
 src/env_provider_leases.inc src/env_opaque_types.inc \
 src/env_opaque_keys.inc src/env_signature_snapshot.inc
src/nanolang.h:
src/generated/compiler_schema.h:
src/runtime/dyn_array.h:
src/runtime/gc.h:
src/runtime/dyn_array.h:
src/runtime/gc_struct.h:
src/eval_u8.h:
src/nanolang.h:
src/builtins_registry.h:
src/runtime/gc.h:
/tmp/record-cost-env-records.inc:
src/runtime/list_int.h:
src/env_provider_leases.inc:
src/env_opaque_types.inc:
src/env_opaque_keys.inc:
src/env_signature_snapshot.inc:
