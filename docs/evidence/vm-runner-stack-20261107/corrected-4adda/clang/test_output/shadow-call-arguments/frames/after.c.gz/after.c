/*
 * NanoVM Test Suite
 *
 * Tests: VM execution of bytecode programs covering arithmetic,
 *        control flow, functions, closures, strings, arrays,
 *        structs, unions, tuples, hashmaps, type casts, and GC.
 *
 * Programs are built using the NvmModule API + ISA encoder,
 * then executed via vm_call_function/vm_execute.
 */

#include "nanovm/vm.h"
#include "nanovm/heap.h"
#include "nanovm/value.h"
#include "nanoisa/isa.h"
#include "nanoisa/nvm_format.h"
#include "nanoisa/assembler.h"
#include "nanoisa/verifier.h"
#include "nanoisa/retained_layouts.h"
#include "nanoisa/ownership_contracts.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <unistd.h>

/* Globals expected by runtime/cli.c */
int g_argc = 0;
char **g_argv = NULL;

/* ========================================================================
 * Test Framework (same as test_nanoisa.c)
 * ======================================================================== */

static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

#define ASSERT(cond, msg) do { \
    tests_run++; \
    if (!(cond)) { \
        printf("  FAIL [%s:%d]: %s\n", __FILE__, __LINE__, msg); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define ASSERT_EQ_INT(a, b, msg) do { \
    tests_run++; \
    long long _a = (long long)(a), _b = (long long)(b); \
    if (_a != _b) { \
        printf("  FAIL [%s:%d]: %s (expected %lld, got %lld)\n", \
               __FILE__, __LINE__, msg, _b, _a); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define ASSERT_EQ_F64(a, b, msg) do { \
    tests_run++; \
    double _a = (double)(a), _b = (double)(b); \
    if (fabs(_a - _b) > 1e-10) { \
        printf("  FAIL [%s:%d]: %s (expected %g, got %g)\n", \
               __FILE__, __LINE__, msg, _b, _a); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

#define ASSERT_EQ_STR(a, b, msg) do { \
    tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        printf("  FAIL [%s:%d]: %s (expected \"%s\", got \"%s\")\n", \
               __FILE__, __LINE__, msg, (b), (a)); \
        tests_failed++; \
        return; \
    } else { \
        tests_passed++; \
    } \
} while(0)

/* I keep each fixture's VM storage outside my runner's stack frame. */
#if defined(_MSC_VER)
__declspec(noinline)
#elif defined(__GNUC__) || defined(__clang__)
__attribute__((noinline))
#endif
static void run_fixture(void (*fixture)(void)) {
    fixture();
}

#define RUN_TEST(fn) do { \
    printf("  %s...\n", #fn); \
    run_fixture(fn); \
} while(0)

/* ========================================================================
 * Helpers: Build simple NVM modules for testing
 * ======================================================================== */

/* Encode an instruction into a buffer. Returns bytes written. */
static uint32_t emit(uint8_t *buf, NanoOpcode op, ...) {
    /* Use the ISA encoder */
    DecodedInstruction instr = {0};
    instr.opcode = op;
    const InstructionInfo *info = isa_get_info(op);
    if (!info) return 0;

    /* Parse operands from varargs based on info */
    va_list args;
    va_start(args, op);
    for (int i = 0; i < info->operand_count; i++) {
        switch (info->operands[i]) {
            case OPERAND_U8:
                instr.operands[i].u8 = (uint8_t)va_arg(args, int);
                break;
            case OPERAND_U16:
                instr.operands[i].u16 = (uint16_t)va_arg(args, int);
                break;
            case OPERAND_U32:
                instr.operands[i].u32 = va_arg(args, uint32_t);
                break;
            case OPERAND_I32:
                instr.operands[i].i32 = va_arg(args, int32_t);
                break;
            case OPERAND_I64:
                instr.operands[i].i64 = va_arg(args, int64_t);
                break;
            case OPERAND_F64:
                instr.operands[i].f64 = va_arg(args, double);
                break;
            default:
                break;
        }
    }
    va_end(args);

    return isa_encode(&instr, buf, 64);
}

/* Create a single-function module from raw bytecode.
 * The function has the given arity + local_count and code. */
static NvmModule *make_module(const uint8_t *code, uint32_t code_size,
                               uint16_t arity, uint16_t local_count) {
    NvmModule *mod = nvm_module_new();

    /* Add function name */
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    /* Append code */
    uint32_t code_off = nvm_append_code(mod, code, code_size);

    /* Add function entry */
    NvmFunctionEntry fn = { .result_count = 1 };
    fn.name_idx = name_idx;
    fn.arity = arity;
    fn.code_offset = code_off;
    fn.code_length = code_size;
    fn.local_count = local_count;
    fn.upvalue_count = 0;
    fn.result_count = 1;
    uint32_t fn_idx = nvm_add_function(mod, &fn);

    /* Set entry point */
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    return mod;
}

/* Create a module with multiple functions. The first function is the entry point. */
static NvmModule *make_multi_fn_module(void) {
    return nvm_module_new();
}

/* Add a function to a module being built. Returns function index. */
static uint32_t add_fn(NvmModule *mod, const char *name,
                        const uint8_t *code, uint32_t code_size,
                        uint16_t arity, uint16_t local_count) {
    uint32_t name_idx = nvm_add_string(mod, name, (uint32_t)strlen(name));
    uint32_t code_off = nvm_append_code(mod, code, code_size);
    NvmFunctionEntry fn = { .result_count = 1 };
    fn.name_idx = name_idx;
    fn.arity = arity;
    fn.code_offset = code_off;
    fn.code_length = code_size;
    fn.local_count = local_count;
    fn.upvalue_count = 0;
    fn.result_count = 1;
    return nvm_add_function(mod, &fn);
}

/* Run a module and return the result. Destroys vm after. */
static NanoValue run_module(NvmModule *mod, VmResult *out_result) {
    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    if (out_result) *out_result = r;
    NanoValue result = vm_get_result(&vm);
    /* Retain result before destroy releases stack */
    vm_retain(&vm.heap, result);
    vm_destroy(&vm);
    return result;
}

/* The verifier rejects an import declaring more parameters than
 * NANO_MAX_FFI_ARGS, but the VM must not rely on having been verified. This
 * covers OP_CALL_EXTERN itself: an unverified module reaching it with an
 * over-long declared arity has to trap rather than clamp. Clamping would drop
 * the arguments past the limit AND leave them on the operand stack,
 * desynchronizing it for every instruction that follows. */
static void test_call_extern_arg_limit_is_error_not_truncation(void) {
    const uint16_t declared = NANO_MAX_FFI_ARGS + 4;

    NvmModule *mod = nvm_module_new();
    uint32_t mname = nvm_add_string(mod, "", 0);
    uint32_t fname = nvm_add_string(mod, "strlen", 6);
    uint8_t params[NANO_MAX_FFI_ARGS + 4];
    for (uint16_t i = 0; i < declared; i++) params[i] = TAG_INT;
    nvm_add_import(mod, mname, fname, declared, TAG_INT, params);

    uint8_t code[512];
    uint32_t off = 0;
    for (uint16_t i = 0; i < declared; i++)
        off += emit(code + off, OP_PUSH_I64, (int64_t)i);
    off += emit(code + off, OP_CALL_EXTERN, (uint32_t)0);
    off += emit(code + off, OP_RET);

    uint32_t name_idx = nvm_add_string(mod, "main", 4);
    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    fn.result_count = 1;
    mod->header.entry_point = nvm_add_function(mod, &fn);
    mod->header.flags = NVM_FLAG_HAS_MAIN;

    VmState vm;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_OUT_OF_BOUNDS,
                  "over-limit extern call is refused, not truncated");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_persistent_invoke(void) {
    uint8_t add_code[32];
    uint32_t add_off = 0;
    add_off += emit(add_code + add_off, OP_LOAD_LOCAL, 0);
    add_off += emit(add_code + add_off, OP_LOAD_LOCAL, 1);
    add_off += emit(add_code + add_off, OP_ADD);
    add_off += emit(add_code + add_off, OP_RET);

    NvmModule *mod = nvm_module_new();
    uint32_t add_idx = add_fn(mod, "add", add_code, add_off, 2, 2);
    ASSERT_EQ_INT(nvm_find_function(mod, "add"), add_idx,
                  "function lookup finds latest definition");
    ASSERT_EQ_INT(nvm_find_function(mod, "missing"), UINT32_MAX,
                  "function lookup reports missing definition");

    VmState vm;
    vm_init(&vm, mod);
    NanoValue args[] = {val_int(20), val_int(22)};
    NanoValue value = val_void();
    VmResult first = vm_invoke(&vm, add_idx, args, 2, &value);
    ASSERT_EQ_INT(first, VM_OK, "first persistent invocation succeeds");
    ASSERT_EQ_INT(value.as.i64, 42, "first persistent result is returned");
    ASSERT_EQ_INT(vm.stack_size, 0, "persistent invocation cleans operand stack");

    args[0] = val_int(40);
    args[1] = val_int(2);
    VmResult second = vm_invoke(&vm, add_idx, args, 2, &value);
    ASSERT_EQ_INT(second, VM_OK, "second persistent invocation succeeds");
    ASSERT_EQ_INT(value.as.i64, 42, "second persistent result is returned");
    ASSERT_EQ_INT(vm.frame_count, 0, "persistent invocation cleans call frames");

    VmResult bad_arity = vm_invoke(&vm, add_idx, args, 1, &value);
    ASSERT_EQ_INT(bad_arity, VM_ERR_TYPE_ERROR, "persistent invocation checks arity");
    ASSERT_EQ_INT(vm.stack_size, 0, "arity failure leaves operand stack clean");

    uint8_t fail_code[32];
    uint32_t fail_off = 0;
    fail_off += emit(fail_code + fail_off, OP_PUSH_I64, (int64_t)1);
    fail_off += emit(fail_code + fail_off, OP_PUSH_STR,
                     nvm_add_string(mod, "not an integer", 14));
    fail_off += emit(fail_code + fail_off, OP_ADD);
    fail_off += emit(fail_code + fail_off, OP_RET);
    uint32_t fail_idx = add_fn(mod, "fail", fail_code, fail_off, 0, 0);
    ASSERT(vm_rebuild_module(&vm, mod),
           "persistent mutation rebuilds decoded instructions");
    VmResult failed = vm_invoke(&vm, fail_idx, NULL, 0, &value);
    ASSERT_EQ_INT(failed, VM_ERR_TYPE_ERROR,
                  "failed persistent invocation reports VM error");
    ASSERT_EQ_INT(vm.stack_size, 0, "failed invocation restores operand stack");
    ASSERT_EQ_INT(vm.frame_count, 0, "failed invocation restores call frames");

    VmResult recovered = vm_invoke(&vm, add_idx, args, 2, &value);
    ASSERT_EQ_INT(recovered, VM_OK, "persistent VM recovers after failed invocation");
    ASSERT_EQ_INT(value.as.i64, 42, "recovered invocation returns correct result");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_mutation_lifecycle(void) {
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.decoded_module_valid, "initial module is decoded");

    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "initial decoded function executes");
    ASSERT_EQ_INT(result.as.i64, 1, "initial decoded operand is retained");

    emit(mod->code, OP_PUSH_I64, (int64_t)2);
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "raw mutation does not silently replace decoded code");
    ASSERT_EQ_INT(result.as.i64, 1, "execution still uses the decoded operand");

    vm_invalidate_module(&vm, mod);
    ASSERT(!vm.decoded_module_valid, "invalidation marks decoded code stale");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_ERR_DECODE,
                  "stale decoded code cannot execute");
    ASSERT(vm_rebuild_module(&vm, mod), "mutated module rebuild succeeds");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "rebuilt function executes");
    ASSERT_EQ_INT(result.as.i64, 2, "rebuilt operand is visible");

    uint32_t literal_idx = nvm_add_string(mod, "rebuilt", 7);
    emit(mod->code, OP_PUSH_STR, literal_idx);
    ASSERT(vm_rebuild_module(&vm, mod), "new string constant rebuild succeeds");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "rebuilt string constant executes");
    ASSERT_EQ_STR(vmstring_cstr(result.as.string), "rebuilt",
                  "rebuilt string constant is visible");
    ASSERT(result.as.string == vm.module_constants.strings[literal_idx],
           "rebuild replaces the instantiated constant table");
    vm_release(&vm.heap, result);

    vm_destroy(&vm);
    ASSERT(vm.stack == NULL, "destroy clears the operand stack allocation");
    ASSERT(vm.decoded_module.functions == NULL,
           "destroy clears root decoded instructions");
    nvm_module_free(mod);
}

static void test_sync_new_functions_keeps_existing_decode(void) {
    uint8_t code[16];
    uint32_t off = 0;
    uint8_t extra[16];
    uint32_t extra_off = 0;
    uint32_t extra_idx;
    const VmDecodedInstruction *old_instr;
    NvmModule *mod;
    VmState vm;
    NanoValue result = val_void();

    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    vm_init(&vm, mod);
    ASSERT(vm.decoded_module_valid, "initial module is decoded");
    old_instr = vm.decoded_module.functions[0].instructions;
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "existing function executes before append");
    ASSERT_EQ_INT(result.as.i64, 1, "existing operand is retained");

    extra_off += emit(extra + extra_off, OP_PUSH_I64, (int64_t)99);
    extra_off += emit(extra + extra_off, OP_RET);
    extra_idx = add_fn(mod, "extra", extra, extra_off, 0, 0);
    ASSERT(vm_sync_new_functions(&vm, mod), "append decode succeeds");
    ASSERT(vm.decoded_module.functions[0].instructions == old_instr,
           "existing decode arrays are not freed");
    ASSERT_EQ_INT(vm.decoded_module.function_count, extra_idx + 1,
                  "decoded function count includes the new function");
    ASSERT(vm_sync_new_functions(&vm, mod), "sync with no new functions succeeds");
    ASSERT_EQ_INT(vm_invoke(&vm, extra_idx, NULL, 0, &result), VM_OK,
                  "appended function executes without full rebuild");
    ASSERT_EQ_INT(result.as.i64, 99, "appended operand is visible");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "existing function still executes after append");
    ASSERT_EQ_INT(result.as.i64, 1, "existing operand is unchanged");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_rejects_malformed_code(void) {
    uint8_t truncated[] = { OP_PUSH_I64, 1 };
    NvmModule *mod = make_module(truncated, sizeof(truncated), 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT(!vm.decoded_module_valid, "truncated bytecode is not published");
    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_DECODE,
                  "truncated bytecode fails before dispatch");
    vm_destroy(&vm);
    nvm_module_free(mod);

    uint8_t branch[16];
    uint32_t off = 0;
    off += emit(branch + off, OP_JMP, (int32_t)2);
    off += emit(branch + off, OP_RET);
    mod = make_module(branch, off, 0, 0);
    vm_init(&vm, mod);
    ASSERT(!vm.decoded_module_valid,
           "branch into an operand is rejected during decode");
    ASSERT(strstr(vm.error_msg, "instruction boundary") != NULL,
           "malformed branch identifies its boundary error");
    vm_destroy(&vm);
    nvm_module_free(mod);

    uint8_t call[16];
    off = 0;
    off += emit(call + off, OP_CALL, (uint32_t)99);
    off += emit(call + off, OP_RET);
    mod = make_module(call, off, 0, 0);
    vm_init(&vm, mod);
    ASSERT(!vm.decoded_module_valid,
           "invalid direct call is rejected during decode");
    ASSERT(strstr(vm.error_msg, "direct call") != NULL,
           "malformed direct call identifies its target error");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_trap_resume_offset(void) {
    uint8_t code[32];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    uint32_t trap_offset = off;
    off += emit(code + off, OP_ASSERT);
    uint32_t resume_offset = off;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);

    const VmDecodedInstruction *trap = vm_decoded_function_at(
        &vm.decoded_module.functions[0], trap_offset);
    ASSERT(trap != NULL, "trap instruction has a decoded offset entry");
    ASSERT_EQ_INT(trap->next_byte_offset, resume_offset,
                  "trap stores its byte-accurate resume offset");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK,
                  "host trap resumes at the next decoded instruction");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 42,
                  "trap resume preserves execution result");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ========================================================================
 * Optimized Dispatch IR (representation 3)
 *
 * These tests exercise the dispatch IR as a distinct projection of the
 * verified instruction IR: successor/branch/call target precomputation,
 * cursor traversal, and lockstep rebuild with the verified IR.
 * ======================================================================== */

static void test_dispatch_projects_branch_targets(void) {
    /* if (true) skip one push; join.  Layout:
     *   0: PUSH_BOOL 1
     *   .: JMP_FALSE +N   (branch over the "then" push)
     *   .: PUSH_I64 7     (then arm)
     *   .: PUSH_I64 9     (join / else arm target)
     *   .: RET
     */
    uint8_t code[32];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    uint32_t jmp_off = off;
    uint32_t then_off = jmp_off + emit(code + off, OP_JMP_FALSE, (int32_t)0);
    off = then_off;
    uint32_t then_push_off = off;
    off += emit(code + off, OP_PUSH_I64, (int64_t)7);
    uint32_t join_off = off;
    /* Patch JMP_FALSE to land on the join instruction. */
    emit(code + jmp_off, OP_JMP_FALSE, (int32_t)(join_off - jmp_off));
    off += emit(code + off, OP_PUSH_I64, (int64_t)9);
    off += emit(code + off, OP_RET);
    (void)then_push_off;

    NvmModule *mod = make_module(code, off, 0, 0);
    VmDecodedModule decoded;
    char err[VM_DECODE_ERROR_SIZE];
    ASSERT(vm_decode_module(mod, &decoded, err), "verified IR decodes");

    VmDispatchModule dispatch;
    char derr[VM_DISPATCH_ERROR_SIZE];
    ASSERT(vm_dispatch_build_module(&decoded, vm_dispatch_profile_none(), &dispatch, derr),
           "dispatch IR projects from verified IR");
    ASSERT_EQ_INT(dispatch.function_count, 1, "one dispatch function");

    const VmDispatchFunction *fn = &dispatch.functions[0];
    ASSERT_EQ_INT(fn->instruction_count, decoded.functions[0].instruction_count,
                  "dispatch preserves the verified instruction count");

    /* Instruction 1 is the JMP_FALSE. */
    const VmDispatchInstruction *jmp = &fn->instructions[1];
    ASSERT_EQ_INT(jmp->instruction.opcode, OP_JMP_FALSE, "second instr is JMP_FALSE");
    ASSERT(jmp->branch_target != VM_DISPATCH_NO_INDEX,
           "branch stores a resolved dispatch index");
    ASSERT_EQ_INT(jmp->branch_target_offset, join_off,
                  "branch offset points at the join instruction");
    const VmDispatchInstruction *join = &fn->instructions[jmp->branch_target];
    ASSERT_EQ_INT(join->byte_offset, join_off,
                  "branch target index resolves to the join offset");
    ASSERT_EQ_INT(join->instruction.opcode, OP_PUSH_I64,
                  "branch target is the join push");

    /* Fall-through of the bool push is the JMP_FALSE. */
    ASSERT_EQ_INT(fn->instructions[0].next_index, 1,
                  "linear successor is the next dispatch index");
    ASSERT(fn->instructions[0].branch_target == VM_DISPATCH_NO_INDEX,
           "non-branch has no branch target");
    ASSERT(fn->instructions[0].call_target == VM_DISPATCH_NO_INDEX,
           "non-call has no call target");

    vm_dispatch_module_free(&dispatch);
    ASSERT(dispatch.functions == NULL, "dispatch free clears functions");
    vm_decoded_module_free(&decoded);
    nvm_module_free(mod);
}

static void test_dispatch_cursor_walks_stream(void) {
    uint8_t code[32];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    uint32_t second_off = off;
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmDecodedModule decoded;
    char err[VM_DECODE_ERROR_SIZE];
    ASSERT(vm_decode_module(mod, &decoded, err), "verified IR decodes");
    VmDispatchModule dispatch;
    char derr[VM_DISPATCH_ERROR_SIZE];
    ASSERT(vm_dispatch_build_module(&decoded, vm_dispatch_profile_none(), &dispatch, derr),
           "dispatch IR projects");

    VmDispatchCursor cursor = {0};
    ASSERT(vm_dispatch_seek(&cursor, &dispatch.functions[0], 0),
           "seek to entry succeeds");
    const VmDispatchInstruction *cur = vm_dispatch_current(&cursor);
    ASSERT(cur != NULL && cur->byte_offset == 0, "cursor starts at offset 0");
    cur = vm_dispatch_advance(&cursor);
    ASSERT(cur != NULL, "cursor advances to second instruction");
    ASSERT_EQ_INT(cur->byte_offset, second_off, "advance lands on second offset");

    /* Re-entry by byte offset (as after a jump). */
    ASSERT(vm_dispatch_seek(&cursor, &dispatch.functions[0], second_off),
           "seek to a mid-stream offset succeeds");
    ASSERT_EQ_INT(vm_dispatch_current(&cursor)->byte_offset, second_off,
                  "re-entry lands on the requested offset");
    ASSERT(!vm_dispatch_seek(&cursor, &dispatch.functions[0], 1),
           "seek to a non-boundary offset fails");

    vm_dispatch_module_free(&dispatch);
    vm_decoded_module_free(&decoded);
    nvm_module_free(mod);
}

static void test_dispatch_lockstep_with_verified_ir(void) {
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.decoded_module_valid, "verified IR is published");
    ASSERT(vm.dispatch_module_valid, "dispatch IR is published alongside it");

    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "execution runs through the dispatch IR");
    ASSERT_EQ_INT(result.as.i64, 1, "dispatch execution result is correct");

    emit(mod->code, OP_PUSH_I64, (int64_t)2);
    vm_invalidate_module(&vm, mod);
    ASSERT(!vm.decoded_module_valid, "invalidation clears verified IR");
    ASSERT(!vm.dispatch_module_valid,
           "invalidation clears the dispatch IR in lockstep");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_ERR_DECODE,
                  "stale dispatch IR refuses to execute");

    ASSERT(vm_rebuild_module(&vm, mod), "module rebuild succeeds");
    ASSERT(vm.dispatch_module_valid, "rebuild republishes the dispatch IR");
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "rebuilt dispatch IR executes");
    ASSERT_EQ_INT(result.as.i64, 2, "rebuilt dispatch operand is visible");

    vm_destroy(&vm);
    ASSERT(vm.dispatch_module.functions == NULL,
           "destroy clears the dispatch IR");
    nvm_module_free(mod);
}

/* ------------------------------------------------------------------ *
 * Private superinstructions (profile-selected dispatch fusion).
 *
 * These verify that a profile can fold LOAD_LOCAL + AGG_GET into one
 * private dispatch step (VM_SUPER_LOAD_LOCAL_FIELD) without changing
 * results, that the default profile leaves the stream unfused, and that
 * fusion never breaks a branch that lands directly on the folded tail.
 * ------------------------------------------------------------------ */

/* Emit: pack a 2-field record into local 0, then LOAD_LOCAL 0 / AGG_GET field.
 * Returns the byte offset of the AGG_GET instruction via *agg_get_off. */
static uint32_t emit_local_field_program(uint8_t *code, uint16_t field,
                                         uint32_t *load_local_off,
                                         uint32_t *agg_get_off) {
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)111);
    off += emit(code + off, OP_PUSH_I64, (int64_t)222);
    off += emit(code + off, OP_AGG_PACK, AGG_RECORD, (uint32_t)0, 0, 2);
    off += emit(code + off, OP_STORE_LOCAL, 0);
    if (load_local_off) *load_local_off = off;
    off += emit(code + off, OP_LOAD_LOCAL, 0);
    if (agg_get_off) *agg_get_off = off;
    off += emit(code + off, OP_AGG_GET, field);
    off += emit(code + off, OP_RET);
    return off;
}

static void test_super_profile_none_leaves_stream_unfused(void) {
    uint8_t code[128];
    uint32_t load_off = 0, agg_off = 0;
    uint32_t off = emit_local_field_program(code, 1, &load_off, &agg_off);
    NvmModule *mod = make_module(code, off, 0, 1);

    VmDecodedModule decoded;
    char err[VM_DECODE_ERROR_SIZE];
    ASSERT(vm_decode_module(mod, &decoded, err), "verified IR decodes");
    VmDispatchModule dispatch;
    char derr[VM_DISPATCH_ERROR_SIZE];
    ASSERT(vm_dispatch_build_module(&decoded, vm_dispatch_profile_none(),
                                    &dispatch, derr),
           "unfused dispatch IR projects");

    const VmDispatchFunction *fn = &dispatch.functions[0];
    uint32_t load_idx = fn->offset_to_index[load_off] - 1;
    const VmDispatchInstruction *lead = &fn->instructions[load_idx];
    ASSERT_EQ_INT(lead->super_op, VM_SUPER_NONE,
                  "no profile means no superinstruction");
    ASSERT_EQ_INT(lead->instruction.opcode, OP_LOAD_LOCAL,
                  "leader stays a plain LOAD_LOCAL");
    ASSERT_EQ_INT(lead->next_byte_offset, agg_off,
                  "unfused fall-through still points at AGG_GET");

    vm_dispatch_module_free(&dispatch);
    vm_decoded_module_free(&decoded);
    nvm_module_free(mod);
}

static void test_super_profile_fuses_local_field_load(void) {
    uint8_t code[128];
    uint32_t load_off = 0, agg_off = 0;
    uint32_t off = emit_local_field_program(code, 1, &load_off, &agg_off);
    NvmModule *mod = make_module(code, off, 0, 1);

    VmDecodedModule decoded;
    char err[VM_DECODE_ERROR_SIZE];
    ASSERT(vm_decode_module(mod, &decoded, err), "verified IR decodes");
    VmDispatchModule dispatch;
    char derr[VM_DISPATCH_ERROR_SIZE];
    ASSERT(vm_dispatch_build_module(&decoded, vm_dispatch_profile_all(),
                                    &dispatch, derr),
           "fused dispatch IR projects");

    const VmDispatchFunction *fn = &dispatch.functions[0];
    uint32_t load_idx = fn->offset_to_index[load_off] - 1;
    const VmDispatchInstruction *lead = &fn->instructions[load_idx];
    ASSERT_EQ_INT(lead->super_op, VM_SUPER_LOAD_LOCAL_FIELD,
                  "profile fuses LOAD_LOCAL + AGG_GET");
    ASSERT_EQ_INT(lead->super_operand, 1, "fused field index is carried");
    ASSERT_EQ_INT(lead->instruction.opcode, OP_LOAD_LOCAL,
                  "the leader still carries the local operand");

    /* The fused leader skips past the AGG_GET; the folded AGG_GET stays in
     * the array so a direct branch to it still works. */
    uint32_t agg_idx = fn->offset_to_index[agg_off] - 1;
    ASSERT_EQ_INT(lead->next_index, agg_idx + 1,
                  "fused fall-through skips the folded AGG_GET");
    ASSERT_EQ_INT(fn->instructions[agg_idx].instruction.opcode, OP_AGG_GET,
                  "the folded AGG_GET remains independently reachable");
    ASSERT_EQ_INT(fn->instructions[agg_idx].super_op, VM_SUPER_NONE,
                  "the folded tail is not itself a superinstruction");

    vm_dispatch_module_free(&dispatch);
    vm_decoded_module_free(&decoded);
    nvm_module_free(mod);
}

static void test_super_fusion_preserves_result(void) {
    /* Same program run unfused and fused must return the same field value. */
    for (uint16_t field = 0; field < 2; field++) {
        uint8_t code[128];
        uint32_t off = emit_local_field_program(code, field, NULL, NULL);

        NvmModule *plain = make_module(code, off, 0, 1);
        VmState vm_plain;
        vm_init(&vm_plain, plain);
        vm_set_dispatch_profile(&vm_plain, vm_dispatch_profile_none());
        ASSERT(vm_rebuild_module(&vm_plain, plain),
               "unfused rebuild succeeds");
        NanoValue plain_result = val_void();
        ASSERT_EQ_INT(vm_invoke(&vm_plain, 0, NULL, 0, &plain_result), VM_OK,
                      "unfused program executes");
        int64_t plain_val = plain_result.as.i64;
        vm_destroy(&vm_plain);
        nvm_module_free(plain);

        NvmModule *fused = make_module(code, off, 0, 1);
        VmState vm_fused;
        vm_init(&vm_fused, fused);
        vm_set_dispatch_profile(&vm_fused, vm_dispatch_profile_all());
        ASSERT(vm_rebuild_module(&vm_fused, fused),
               "fused rebuild succeeds");
        ASSERT(vm_fused.dispatch_module_valid, "fused dispatch IR is valid");
        NanoValue fused_result = val_void();
        ASSERT_EQ_INT(vm_invoke(&vm_fused, 0, NULL, 0, &fused_result), VM_OK,
                      "fused program executes");
        ASSERT_EQ_INT(fused_result.as.i64, plain_val,
                      "fused superinstruction returns the same field value");
        int64_t expect = (field == 0) ? 111 : 222;
        ASSERT_EQ_INT(fused_result.as.i64, expect,
                      "fused field value matches the packed record");
        vm_destroy(&vm_fused);
        nvm_module_free(fused);
    }
}

static void test_super_fusion_keeps_branch_target_reachable(void) {
    /* A JMP_FALSE lands directly on the AGG_GET that a preceding LOAD_LOCAL
     * would otherwise fuse with.  The folded tail must still execute the
     * plain AGG_GET when reached by branch, proving fusion never rewrites a
     * branch target. */
    uint8_t code[160];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_AGG_PACK, AGG_RECORD, (uint32_t)0, 0, 2);
    off += emit(code + off, OP_STORE_LOCAL, 0);   /* local 0 = {10, 20} */

    /* Push false, then a LOAD_LOCAL/AGG_GET pair the profile would fuse.
     * A JMP_FALSE jumps over the LOAD_LOCAL straight onto the AGG_GET. */
    off += emit(code + off, OP_LOAD_LOCAL, 0);    /* leave the record on top */
    off += emit(code + off, OP_PUSH_BOOL, 0);     /* condition = false */
    uint32_t jmp_off = off;
    /* placeholder; patched once AGG_GET offset is known */
    off += emit(code + off, OP_JMP_FALSE, (int32_t)0);
    uint32_t load_off = off;
    off += emit(code + off, OP_LOAD_LOCAL, 0);    /* skipped when false */
    off += emit(code + off, OP_POP);              /* would drop the record */
    uint32_t agg_off = off;
    off += emit(code + off, OP_AGG_GET, 0);       /* branch target: field 0 */
    off += emit(code + off, OP_RET);

    /* Patch the JMP_FALSE to target the AGG_GET (relative to the jmp). */
    (void)load_off;
    emit(code + jmp_off, OP_JMP_FALSE, (int32_t)(agg_off - jmp_off));

    NvmModule *mod = make_module(code, off, 0, 1);
    VmState vm;
    vm_init(&vm, mod);
    vm_set_dispatch_profile(&vm, vm_dispatch_profile_all());
    ASSERT(vm_rebuild_module(&vm, mod), "fused rebuild succeeds");
    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "branch into folded AGG_GET executes");
    ASSERT_EQ_INT(result.as.i64, 10,
                  "branch target AGG_GET reads field 0 of the record");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_result_signature_enforcement(void) {
    uint8_t code[32];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    mod->functions[0].result_tag = TAG_INT;
    mod->functions[0].result_count = 1;

    VmState vm;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_TYPE_ERROR,
                  "RET rejects a result with the wrong tag");
    vm_destroy(&vm);
    nvm_module_free(mod);

    off = emit(code, OP_RET);
    mod = make_module(code, off, 0, 0);
    mod->functions[0].result_tag = TAG_INT;
    mod->functions[0].result_count = 1;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_TYPE_ERROR,
                  "RET rejects a missing result");
    vm_destroy(&vm);
    nvm_module_free(mod);

    off = emit(code, OP_RET);
    mod = make_module(code, off, 0, 0);
    mod->functions[0].result_tag = TAG_VOID;
    mod->functions[0].result_count = 0;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "void RET returns no value");
    ASSERT_EQ_INT(vm.stack_size, 0, "void RET leaves no stack result");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_instruction_profile(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)22);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    uint64_t allocations = vm.heap.stats.allocation_calls;
    vm_profile_enable(&vm, true);
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "profiled execution succeeds");
    ASSERT_EQ_INT(vm.profile.retired, 4, "profile counts retired instructions");
    ASSERT_EQ_INT(vm.profile.opcode_counts[OP_PUSH_I64], 2,
                  "profile counts opcodes");
    ASSERT_EQ_INT(vm.profile.pair_counts[(OP_PUSH_I64 << 8) | OP_PUSH_I64], 1,
                  "profile counts opcode pairs");
    ASSERT_EQ_INT(vm.profile.pair_counts[(OP_PUSH_I64 << 8) | OP_ADD], 1,
                  "profile counts second opcode pair");
    ASSERT_EQ_INT(vm.heap.stats.allocation_calls, allocations,
                  "profile shows execution performs no allocations");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_heap_profile(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, (uint32_t)0);
    off += emit(code + off, OP_DUP);
    off += emit(code + off, OP_POP);
    off += emit(code + off, OP_RET);

    NvmModule *mod = nvm_module_new();
    nvm_add_string(mod, "profiled", 8);
    uint32_t main_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmState vm;
    vm_init(&vm, mod);
    uint64_t allocations = vm.heap.stats.allocation_calls;
    vm_profile_enable(&vm, true);
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "heap-profile execution succeeds");
    ASSERT_EQ_INT(vm.heap.stats.allocation_calls, allocations,
                  "heap profile shows constant execution performs no allocations");
    ASSERT(vm.heap.stats.allocated > 0,
           "heap profile counts allocated bytes");
    ASSERT_EQ_INT(vm.heap.stats.retain_calls, 2,
                  "heap profile counts constant push and duplicate retains");
    ASSERT(vm.heap.stats.release_calls >= 1,
           "heap profile counts releases");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Basic Integer Arithmetic
 * ======================================================================== */

static void test_push_int_halt(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_HALT, 0);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "push_int_halt: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_INT, "push_int_halt: result is int");
    ASSERT_EQ_INT(result.as.i64, 42, "push_int_halt: result == 42");
    nvm_module_free(mod);
}

static void test_add_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)32);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add_ints: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "add_ints: 10 + 32 == 42");
    nvm_module_free(mod);
}

static void test_sub_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)100);
    off += emit(code + off, OP_PUSH_I64, (int64_t)58);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "sub_ints: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "sub_ints: 100 - 58 == 42");
    nvm_module_free(mod);
}

static void test_mul_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)6);
    off += emit(code + off, OP_PUSH_I64, (int64_t)7);
    off += emit(code + off, OP_MUL);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mul_ints: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "mul_ints: 6 * 7 == 42");
    nvm_module_free(mod);
}

static void test_div_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)84);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_DIV);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "div_ints: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "div_ints: 84 / 2 == 42");
    nvm_module_free(mod);
}

static void test_div_by_zero(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_DIV);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "div_by_zero: VM_OK (not an error)");
    ASSERT_EQ_INT(result.as.i64, 0, "div_by_zero: 42 / 0 == 0 (Coq semantics)");
    nvm_module_free(mod);
}

static void test_mod_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)47);
    off += emit(code + off, OP_PUSH_I64, (int64_t)5);
    off += emit(code + off, OP_MOD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mod_ints: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "mod_ints: 47 %% 5 == 2");
    nvm_module_free(mod);
}

static void test_neg_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_NEG);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "neg_int: VM_OK");
    ASSERT_EQ_INT(result.as.i64, -42, "neg_int: -42");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Float Arithmetic
 * ======================================================================== */

static void test_float_add(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 3.14);
    off += emit(code + off, OP_PUSH_F64, 2.86);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "float_add: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 6.0, "float_add: 3.14 + 2.86 == 6.0");
    nvm_module_free(mod);
}

static void test_mixed_int_float_add(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_F64, 0.5);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mixed_add: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_FLOAT, "mixed_add: result is float");
    ASSERT_EQ_F64(result.as.f64, 10.5, "mixed_add: 10 + 0.5 == 10.5");
    nvm_module_free(mod);
}

static void test_float_div_by_zero(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 1.0);
    off += emit(code + off, OP_PUSH_F64, 0.0);
    off += emit(code + off, OP_DIV);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "float_div_zero: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 0.0, "float_div_zero: 1.0 / 0.0 == 0.0");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Boolean & Comparison
 * ======================================================================== */

static void test_bool_push(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "bool_push: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_BOOL, "bool_push: tag is bool");
    ASSERT(result.as.boolean == true, "bool_push: true");
    nvm_module_free(mod);
}

static void test_eq_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_EQ);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "eq_ints: VM_OK");
    ASSERT(result.as.boolean == true, "eq_ints: 42 == 42");
    nvm_module_free(mod);
}

static void test_ne_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_I64, (int64_t)43);
    off += emit(code + off, OP_NE);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "ne_ints: VM_OK");
    ASSERT(result.as.boolean == true, "ne_ints: 42 != 43");
    nvm_module_free(mod);
}

static void test_lt_ints(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_LT);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "lt_ints: VM_OK");
    ASSERT(result.as.boolean == true, "lt_ints: 10 < 20");
    nvm_module_free(mod);
}

static void test_logic_and(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_AND);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "logic_and: VM_OK");
    ASSERT(result.as.boolean == true, "logic_and: true && true");
    nvm_module_free(mod);
}

static void test_logic_not(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 0);
    off += emit(code + off, OP_NOT);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "logic_not: VM_OK");
    ASSERT(result.as.boolean == true, "logic_not: !false == true");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Stack Operations
 * ======================================================================== */

static void test_dup(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_DUP);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "dup: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 84, "dup: 42 + 42 == 84");
    nvm_module_free(mod);
}

static void test_swap(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_SWAP);
    off += emit(code + off, OP_SUB);  /* 20 - 10 = 10 */
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "swap: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 10, "swap: 20 - 10 == 10 after swap");
    nvm_module_free(mod);
}

static void test_pop(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)99);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_POP);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "pop: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 99, "pop: 99 remains after popping 42");
    nvm_module_free(mod);
}

static void test_push_void(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_VOID);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "push_void: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_VOID, "push_void: tag is void");
    nvm_module_free(mod);
}

static void test_push_u8(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_U8, 255);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "push_u8: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_U8, "push_u8: tag is u8");
    ASSERT_EQ_INT(result.as.u8, 255, "push_u8: value == 255");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Local Variables
 * ======================================================================== */

static void test_locals(void) {
    /* let x = 10; let y = 32; return x + y */
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_STORE_LOCAL, 0);
    off += emit(code + off, OP_PUSH_I64, (int64_t)32);
    off += emit(code + off, OP_STORE_LOCAL, 1);
    off += emit(code + off, OP_LOAD_LOCAL, 0);
    off += emit(code + off, OP_LOAD_LOCAL, 1);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 2);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "locals: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "locals: x + y == 42");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Global Variables
 * ======================================================================== */

static void test_globals(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_STORE_GLOBAL, (uint32_t)0);
    off += emit(code + off, OP_LOAD_GLOBAL, (uint32_t)0);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "globals: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "globals: stored and loaded 42");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Control Flow
 * ======================================================================== */

static void test_jmp(void) {
    /* Jump over a push, return 10 */
    uint8_t code[128];
    uint32_t off = 0;
    uint32_t jmp_pos = off;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);  /* bytes 0-8 */
    /* We need to jump over the next PUSH_I64 instruction
       JMP offset is relative to instruction start.
       JMP is at position 9, its encoding is 5 bytes (1 + 4).
       Next PUSH_I64 is at position 14, 9 bytes (1 + 8).
       Target (RET) is at position 23.
       So offset = 23 - 14 = ??? Actually: offset relative to JMP start = 23. No.
       Let me compute: JMP is encoded at offset 9. JMP offset is relative to instr_start.
       vm->ip = (uint32_t)((int32_t)instr_start + offset)
       So we want instr_start + offset = target.
       instr_start of JMP = 9.
       After JMP: PUSH_I64 at 14 (9 bytes), then RET.
       target = 14 + 9 = 23.
       offset = 23 - 9 = 14. */
    (void)jmp_pos;
    /* Let me just build it step by step and track offsets */
    off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);  /* off 0, 9 bytes */
    uint32_t jmp_off = off;                               /* off 9 */
    off += emit(code + off, OP_JMP, (int32_t)0);          /* off 9, 5 bytes, target TBD */
    uint32_t skip_start = off;                             /* off 14 */
    off += emit(code + off, OP_PUSH_I64, (int64_t)999);   /* off 14, 9 bytes */
    off += emit(code + off, OP_ADD);                       /* off 23, 1 byte */
    uint32_t target = off;                                 /* off 24 */
    off += emit(code + off, OP_RET);                       /* off 24, 1 byte */
    (void)skip_start;

    /* Patch jump: offset = target - jmp_off = 24 - 9 = 15 */
    emit(code + jmp_off, OP_JMP, (int32_t)(target - jmp_off));

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "jmp: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 10, "jmp: skipped 999, result == 10");
    nvm_module_free(mod);
}

static void test_jmp_false(void) {
    /* if (false) 999 else 42 */
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 0);            /* 0: 2 bytes */
    uint32_t jf_off = off;                                /* 2 */
    off += emit(code + off, OP_JMP_FALSE, (int32_t)0);    /* 2: 5 bytes */
    off += emit(code + off, OP_PUSH_I64, (int64_t)999);   /* 7: 9 bytes */
    uint32_t jmp2_off = off;                               /* 16 */
    off += emit(code + off, OP_JMP, (int32_t)0);           /* 16: 5 bytes */
    uint32_t else_off = off;                               /* 21 */
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);    /* 21: 9 bytes */
    uint32_t end_off = off;                                /* 30 */
    off += emit(code + off, OP_RET);

    /* Patch: JMP_FALSE jumps to else branch */
    emit(code + jf_off, OP_JMP_FALSE, (int32_t)(else_off - jf_off));
    /* Patch: JMP at end of then-branch jumps to end */
    emit(code + jmp2_off, OP_JMP, (int32_t)(end_off - jmp2_off));

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "jmp_false: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "jmp_false: false -> else branch -> 42");
    nvm_module_free(mod);
}

static void test_jmp_true(void) {
    /* if (true) 42 else 999 */
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    uint32_t jt_off = off;
    off += emit(code + off, OP_JMP_TRUE, (int32_t)0);
    off += emit(code + off, OP_PUSH_I64, (int64_t)999);
    uint32_t jmp2_off = off;
    off += emit(code + off, OP_JMP, (int32_t)0);
    uint32_t then_off = off;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    uint32_t end_off = off;
    off += emit(code + off, OP_RET);

    emit(code + jt_off, OP_JMP_TRUE, (int32_t)(then_off - jt_off));
    emit(code + jmp2_off, OP_JMP, (int32_t)(end_off - jmp2_off));

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "jmp_true: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "jmp_true: true -> then branch -> 42");
    nvm_module_free(mod);
}

static void test_loop(void) {
    /* sum = 0; i = 10; while (i > 0) { sum = sum + i; i = i - 1 }; return sum
     * Locals: 0=sum, 1=i */
    uint8_t code[256];
    uint32_t off = 0;

    /* sum = 0 */
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_STORE_LOCAL, 0);
    /* i = 10 */
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_STORE_LOCAL, 1);

    /* loop_top: */
    uint32_t loop_top = off;
    /* i > 0 ? */
    off += emit(code + off, OP_LOAD_LOCAL, 1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_GT);
    uint32_t jf_off = off;
    off += emit(code + off, OP_JMP_FALSE, (int32_t)0);  /* to loop_end */

    /* sum = sum + i */
    off += emit(code + off, OP_LOAD_LOCAL, 0);
    off += emit(code + off, OP_LOAD_LOCAL, 1);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_STORE_LOCAL, 0);

    /* i = i - 1 */
    off += emit(code + off, OP_LOAD_LOCAL, 1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_STORE_LOCAL, 1);

    /* jump back to loop_top */
    uint32_t jmp_back = off;
    off += emit(code + off, OP_JMP, (int32_t)(loop_top - jmp_back));

    /* loop_end: */
    uint32_t loop_end = off;
    off += emit(code + off, OP_LOAD_LOCAL, 0);
    off += emit(code + off, OP_RET);

    /* Patch JMP_FALSE */
    emit(code + jf_off, OP_JMP_FALSE, (int32_t)(loop_end - jf_off));

    NvmModule *mod = make_module(code, off, 0, 2);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "loop: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 55, "loop: sum(1..10) == 55");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Function Calls
 * ======================================================================== */

static void test_call_function(void) {
    /* fn add(a, b) = a + b;  main() = add(10, 32) */
    NvmModule *mod = make_multi_fn_module();

    /* Build add function: locals 0=a, 1=b */
    uint8_t add_code[64];
    uint32_t add_off = 0;
    add_off += emit(add_code + add_off, OP_LOAD_LOCAL, 0);
    add_off += emit(add_code + add_off, OP_LOAD_LOCAL, 1);
    add_off += emit(add_code + add_off, OP_ADD);
    add_off += emit(add_code + add_off, OP_RET);
    uint32_t add_idx = add_fn(mod, "add", add_code, add_off, 2, 2);

    /* Build main: push args, call add */
    uint8_t main_code[64];
    uint32_t main_off = 0;
    main_off += emit(main_code + main_off, OP_PUSH_I64, (int64_t)10);
    main_off += emit(main_code + main_off, OP_PUSH_I64, (int64_t)32);
    main_off += emit(main_code + main_off, OP_CALL, add_idx);
    main_off += emit(main_code + main_off, OP_RET);
    uint32_t main_idx = add_fn(mod, "main", main_code, main_off, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "call_function: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "call_function: add(10, 32) == 42");
    nvm_module_free(mod);
}

static void test_recursive_factorial(void) {
    /* fn fact(n) = if n <= 1 then 1 else n * fact(n-1) */
    NvmModule *mod = make_multi_fn_module();

    uint8_t fact_code[256];
    uint32_t off = 0;

    /* n <= 1? */
    off += emit(fact_code + off, OP_LOAD_LOCAL, 0);          /* load n */
    off += emit(fact_code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(fact_code + off, OP_LE);
    uint32_t jf = off;
    off += emit(fact_code + off, OP_JMP_FALSE, (int32_t)0);

    /* then: return 1 */
    off += emit(fact_code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(fact_code + off, OP_RET);

    /* else: n * fact(n-1) */
    uint32_t else_off = off;
    off += emit(fact_code + off, OP_LOAD_LOCAL, 0);          /* load n */
    off += emit(fact_code + off, OP_LOAD_LOCAL, 0);          /* load n */
    off += emit(fact_code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(fact_code + off, OP_SUB);                     /* n - 1 */
    off += emit(fact_code + off, OP_CALL, (uint32_t)0);       /* fact(n-1), fn idx 0 */
    off += emit(fact_code + off, OP_MUL);                     /* n * result */
    off += emit(fact_code + off, OP_RET);

    /* Patch JMP_FALSE to else */
    emit(fact_code + jf, OP_JMP_FALSE, (int32_t)(else_off - jf));

    uint32_t fact_idx = add_fn(mod, "fact", fact_code, off, 1, 1);

    /* Main: fact(10) */
    uint8_t main_code[64];
    uint32_t moff = 0;
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)10);
    moff += emit(main_code + moff, OP_CALL, fact_idx);
    moff += emit(main_code + moff, OP_RET);
    uint32_t main_idx = add_fn(mod, "main", main_code, moff, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "recursive_factorial: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3628800, "recursive_factorial: 10! == 3628800");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Strings
 * ======================================================================== */

static void test_push_string(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t str_idx = nvm_add_string(mod, "hello", 5);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, str_idx);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmState vm;
    vm_init(&vm, mod);
    uint64_t allocations = vm.heap.stats.allocation_calls;
    VmString *constant = vm.module_constants.strings[str_idx];
    for (uint32_t i = 0; i < 3; i++) {
        NanoValue result = val_void();
        VmResult r = vm_invoke(&vm, fn_idx, NULL, 0, &result);
        ASSERT_EQ_INT(r, VM_OK, "push_string: VM_OK");
        ASSERT_EQ_INT(result.tag, TAG_STRING, "push_string: tag is string");
        ASSERT_EQ_STR(vmstring_cstr(result.as.string), "hello", "push_string: value");
        ASSERT(result.as.string == constant,
               "push_string: execution reuses the instantiated constant");
        vm_release(&vm.heap, result);
    }
    ASSERT_EQ_INT(vm.heap.stats.allocation_calls, allocations,
                  "push_string: repeated execution performs no allocations");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_string_concat(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t s1 = nvm_add_string(mod, "hello", 5);
    uint32_t s2 = nvm_add_string(mod, " world", 6);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s1);
    off += emit(code + off, OP_PUSH_STR, s2);
    off += emit(code + off, OP_ADD);  /* string concat via ADD */
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "string_concat: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_STR(vmstring_cstr(result.as.string), "hello world", "string_concat: value");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_string_len(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t s1 = nvm_add_string(mod, "hello", 5);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s1);
    off += emit(code + off, OP_STR_LEN);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "string_len: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 5, "string_len: len('hello') == 5");
    nvm_module_free(mod);
}

static void test_str_from_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_STR_FROM_INT);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "str_from_int: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_STRING, "str_from_int: tag is string");
    ASSERT_EQ_STR(vmstring_cstr(result.as.string), "42", "str_from_int: '42'");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ------------------------------------------------------------------------
 * Tests: stored string lengths / embedded zero bytes
 *
 * NanoVM strings carry an explicit byte length and may hold embedded '\0'
 * bytes. These tests exercise the heap-level string operations directly to
 * confirm they honor the stored length rather than treating the payload as a
 * C string (which would truncate at the first zero byte).
 * ------------------------------------------------------------------------ */

static void test_string_embedded_zero_bytes(void) {
    VmHeap heap;
    vm_heap_init(&heap);

    /* "ab\0cd" : length 5, embedded NUL at index 2. */
    VmString *s = vm_string_new(&heap, "ab\0cd", 5);
    ASSERT(s != NULL, "embedded_zero: alloc");
    ASSERT_EQ_INT(vmstring_len(s), 5, "embedded_zero: stored length is 5");
    ASSERT_EQ_INT((unsigned char)s->data[2], 0, "embedded_zero: byte 2 is NUL");
    ASSERT_EQ_INT((unsigned char)s->data[4], 'd', "embedded_zero: byte 4 preserved");

    /* Equality must compare full byte ranges, not stop at the NUL. */
    VmString *same = vm_string_new(&heap, "ab\0cd", 5);
    VmString *prefix = vm_string_new(&heap, "ab", 2);
    ASSERT(vmstring_equal(s, same), "embedded_zero: full equal");
    ASSERT(!vmstring_equal(s, prefix), "embedded_zero: not equal to NUL-truncated prefix");

    /* Distinct strings sharing the pre-NUL prefix must not collapse to equal. */
    VmString *diff = vm_string_new(&heap, "ab\0XY", 5);
    ASSERT(!vmstring_equal(s, diff), "embedded_zero: bytes after NUL distinguish");

    vm_heap_destroy(&heap);
}

static void test_string_find_across_zero(void) {
    VmHeap heap;
    vm_heap_init(&heap);

    /* Needle that lives entirely past the first NUL byte. */
    VmString *hay = vm_string_new(&heap, "a\0bcd", 5);
    VmString *needle = vm_string_new(&heap, "bcd", 3);
    VmString *pre = vm_string_new(&heap, "a", 1);

    ASSERT_EQ_INT(vmstring_find(hay, needle), 2, "find: needle after NUL at offset 2");
    ASSERT(vmstring_contains(hay, needle), "contains: matches past NUL");
    ASSERT_EQ_INT(vmstring_find(hay, pre), 0, "find: prefix at offset 0");

    /* A needle containing an embedded NUL must match by full bytes. */
    VmString *needle2 = vm_string_new(&heap, "\0bc", 3);
    ASSERT_EQ_INT(vmstring_find(hay, needle2), 1, "find: NUL-containing needle at offset 1");

    /* Empty needle matches at offset 0; absent needle returns -1. */
    VmString *empty = vm_string_new(&heap, "", 0);
    VmString *absent = vm_string_new(&heap, "zz", 2);
    ASSERT_EQ_INT(vmstring_find(hay, empty), 0, "find: empty needle at 0");
    ASSERT_EQ_INT(vmstring_find(hay, absent), -1, "find: absent needle -1");

    vm_heap_destroy(&heap);
}

static void test_string_substr_across_zero(void) {
    VmHeap heap;
    vm_heap_init(&heap);

    VmString *s = vm_string_new(&heap, "ab\0cd", 5);
    VmString *sub = vm_string_substr(&heap, s, 1, 3); /* "b\0c" */
    ASSERT_EQ_INT(vmstring_len(sub), 3, "substr: length spans the NUL");
    ASSERT_EQ_INT((unsigned char)sub->data[0], 'b', "substr: byte 0");
    ASSERT_EQ_INT((unsigned char)sub->data[1], 0, "substr: byte 1 is NUL");
    ASSERT_EQ_INT((unsigned char)sub->data[2], 'c', "substr: byte 2");

    /* char_at must index by stored length, including the NUL position. */
    VmString *ch = vmstring_char_at(&heap, s, 2);
    ASSERT_EQ_INT(vmstring_len(ch), 1, "char_at: single byte");
    ASSERT_EQ_INT((unsigned char)ch->data[0], 0, "char_at: NUL byte at index 2");

    vm_heap_destroy(&heap);
}

static void test_str_replace_op_embedded_zero(void) {
    /* replace("a\0bXb\0c", "b", "Z") -> "a\0ZXZ\0c" : the '\0' bytes on each
     * side of a replaced needle must be preserved and the length must stay 7. */
    NvmModule *mod = nvm_module_new();
    uint32_t s_idx   = nvm_add_string(mod, "a\0bXb\0c", 7);
    uint32_t old_idx = nvm_add_string(mod, "b", 1);
    uint32_t new_idx = nvm_add_string(mod, "Z", 1);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s_idx);
    off += emit(code + off, OP_PUSH_STR, old_idx);
    off += emit(code + off, OP_PUSH_STR, new_idx);
    off += emit(code + off, OP_STR_REPLACE);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    /* Assert before vm_destroy: run_module() tears the VM down and frees the
     * heap before returning, so the result string would be dangling here. The
     * sibling embedded-zero tests inspect the result while the VM is alive for
     * the same reason. */
    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "str_replace_zero: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_STRING, "str_replace_zero: tag string");
    ASSERT_EQ_INT(vmstring_len(result.as.string), 7, "str_replace_zero: length preserved");
    const char *d = result.as.string->data;
    ASSERT_EQ_INT((unsigned char)d[0], 'a', "str_replace_zero: [0]");
    ASSERT_EQ_INT((unsigned char)d[1], 0,   "str_replace_zero: [1] NUL kept");
    ASSERT_EQ_INT((unsigned char)d[2], 'Z', "str_replace_zero: [2] replaced");
    ASSERT_EQ_INT((unsigned char)d[3], 'X', "str_replace_zero: [3]");
    ASSERT_EQ_INT((unsigned char)d[4], 'Z', "str_replace_zero: [4] replaced");
    ASSERT_EQ_INT((unsigned char)d[5], 0,   "str_replace_zero: [5] NUL kept");
    ASSERT_EQ_INT((unsigned char)d[6], 'c', "str_replace_zero: [6]");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_str_contains_op_embedded_zero(void) {
    /* contains("a\0needle", "needle") must be true even though the needle
     * begins right after an embedded NUL byte. */
    NvmModule *mod = nvm_module_new();
    uint32_t hay_idx = nvm_add_string(mod, "a\0needle", 8);
    uint32_t nee_idx = nvm_add_string(mod, "needle", 6);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, hay_idx);
    off += emit(code + off, OP_PUSH_STR, nee_idx);
    off += emit(code + off, OP_STR_CONTAINS);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_contains_zero: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_BOOL, "str_contains_zero: tag bool");
    ASSERT(result.as.boolean, "str_contains_zero: found past NUL");
    nvm_module_free(mod);
}

static void test_str_split_op_embedded_zero(void) {
    /* split("x\0y,z", ",") -> ["x\0y", "z"], preserving the NUL in the first
     * segment and reporting its full length of 3. Inspect the result before
     * vm_destroy so the array elements are still live. */
    NvmModule *mod = nvm_module_new();
    uint32_t s_idx = nvm_add_string(mod, "x\0y,z", 5);
    uint32_t d_idx = nvm_add_string(mod, ",", 1);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s_idx);
    off += emit(code + off, OP_PUSH_STR, d_idx);
    off += emit(code + off, OP_STR_SPLIT);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "str_split_zero: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_ARRAY, "str_split_zero: tag array");
    ASSERT_EQ_INT(result.as.array->length, 2, "str_split_zero: two segments");
    NanoValue seg0 = vm_array_get(result.as.array, 0);
    NanoValue seg1 = vm_array_get(result.as.array, 1);
    ASSERT_EQ_INT(vmstring_len(seg0.as.string), 3, "str_split_zero: seg0 length 3");
    ASSERT_EQ_INT((unsigned char)seg0.as.string->data[1], 0, "str_split_zero: seg0 keeps NUL");
    ASSERT_EQ_INT(vmstring_len(seg1.as.string), 1, "str_split_zero: seg1 length 1");
    ASSERT_EQ_INT((unsigned char)seg1.as.string->data[0], 'z', "str_split_zero: seg1 is z");
    vm_destroy(&vm);
    nvm_module_free(mod);
}
/* ========================================================================
 * Tests: Arrays
 * ======================================================================== */

static void test_array_literal(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)30);
    off += emit(code + off, OP_ARR_LITERAL, TAG_INT, 3);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "array_literal: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_ARRAY, "array_literal: tag is array");
    ASSERT_EQ_INT(result.as.array->length, 3, "array_literal: length == 3");
    ASSERT_EQ_INT(result.as.array->unboxed, 1, "array_literal: int array is unboxed");
    ASSERT_EQ_INT(vm_array_get(result.as.array, 0).as.i64, 10, "array_literal: [0] == 10");
    ASSERT_EQ_INT(vm_array_get(result.as.array, 1).as.i64, 20, "array_literal: [1] == 20");
    ASSERT_EQ_INT(vm_array_get(result.as.array, 2).as.i64, 30, "array_literal: [2] == 30");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_array_push_get(void) {
    uint8_t code[128];
    uint32_t off = 0;
    /* Create array, push 42, get element 0 */
    off += emit(code + off, OP_ARR_NEW, TAG_INT);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_ARR_PUSH);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_ARR_GET);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "array_push_get: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "array_push_get: get(0) == 42");
    nvm_module_free(mod);
}

static void test_array_len(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)4);
    off += emit(code + off, OP_PUSH_I64, (int64_t)5);
    off += emit(code + off, OP_ARR_LITERAL, TAG_INT, 5);
    off += emit(code + off, OP_ARR_LEN);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "array_len: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 5, "array_len: length == 5");
    nvm_module_free(mod);
}

/* Unboxed homogeneous arrays: int/float/bool/byte element types are stored in
 * a compact packed buffer rather than a boxed NanoValue[]. Exercise the heap
 * array API directly to prove the accessors round-trip payloads correctly and
 * that mutation ops (set/pop/slice/remove/grow) preserve values. */
static void test_array_unboxed_representation(void) {
    /* Classification: only the four non-reference primitives are unboxable. */
    ASSERT(vm_array_type_unboxable(TAG_INT),   "unboxable: int");
    ASSERT(vm_array_type_unboxable(TAG_FLOAT), "unboxable: float");
    ASSERT(vm_array_type_unboxable(TAG_BOOL),  "unboxable: bool");
    ASSERT(vm_array_type_unboxable(TAG_U8),    "unboxable: byte");
    ASSERT(!vm_array_type_unboxable(TAG_STRING), "boxed: string");
    ASSERT(!vm_array_type_unboxable(TAG_ARRAY),  "boxed: array");

    VmHeap heap;
    vm_heap_init(&heap);

    /* --- int array (unboxed), forcing a grow past initial capacity --- */
    VmArray *ints = vm_array_new(&heap, TAG_INT, 2);
    ASSERT_EQ_INT(ints->unboxed, 1, "int array is unboxed");
    for (int i = 0; i < 100; i++) {
        vm_array_push(&heap, ints, val_int((int64_t)i * 3 - 7));
    }
    ASSERT_EQ_INT(ints->length, 100, "int array length after 100 pushes");
    ASSERT_EQ_INT(vm_array_get(ints, 0).tag, TAG_INT, "int get preserves tag");
    ASSERT_EQ_INT(vm_array_get(ints, 0).as.i64, -7, "int get [0]");
    ASSERT_EQ_INT(vm_array_get(ints, 42).as.i64, 42 * 3 - 7, "int get [42]");
    vm_array_set(ints, 42, val_int(999));
    ASSERT_EQ_INT(vm_array_get(ints, 42).as.i64, 999, "int set/get [42]");
    NanoValue popped = vm_array_pop(ints);
    ASSERT_EQ_INT(popped.as.i64, 99 * 3 - 7, "int pop returns last");
    ASSERT_EQ_INT(ints->length, 99, "int length after pop");

    /* remove shifts the packed buffer down */
    vm_array_remove(&heap, ints, 0);
    ASSERT_EQ_INT(ints->length, 98, "int length after remove");
    ASSERT_EQ_INT(vm_array_get(ints, 0).as.i64, 3 - 7, "int remove shifted [0]");

    /* slice copies the packed buffer */
    VmArray *sl = vm_array_slice(&heap, ints, 0, 3);
    ASSERT_EQ_INT(sl->unboxed, 1, "slice stays unboxed");
    ASSERT_EQ_INT(sl->length, 3, "slice length");
    ASSERT_EQ_INT(vm_array_get(sl, 2).as.i64, 3 * 3 - 7, "slice value [2]");
    vm_release(&heap, val_array(sl));
    vm_release(&heap, val_array(ints));

    /* --- float array (unboxed) --- */
    VmArray *flts = vm_array_new(&heap, TAG_FLOAT, 8);
    ASSERT_EQ_INT(flts->unboxed, 1, "float array is unboxed");
    vm_array_push(&heap, flts, val_float(1.5));
    vm_array_push(&heap, flts, val_float(-2.25));
    ASSERT_EQ_INT(vm_array_get(flts, 0).tag, TAG_FLOAT, "float get tag");
    ASSERT_EQ_F64(vm_array_get(flts, 0).as.f64, 1.5, "float get [0]");
    ASSERT_EQ_F64(vm_array_get(flts, 1).as.f64, -2.25, "float get [1]");
    vm_release(&heap, val_array(flts));

    /* --- bool array (unboxed, 1 byte per element) --- */
    VmArray *bools = vm_array_new(&heap, TAG_BOOL, 4);
    ASSERT_EQ_INT(bools->unboxed, 1, "bool array is unboxed");
    vm_array_push(&heap, bools, val_bool(true));
    vm_array_push(&heap, bools, val_bool(false));
    ASSERT_EQ_INT(vm_array_get(bools, 0).tag, TAG_BOOL, "bool get tag");
    ASSERT(vm_array_get(bools, 0).as.boolean, "bool get [0] true");
    ASSERT(!vm_array_get(bools, 1).as.boolean, "bool get [1] false");
    vm_release(&heap, val_array(bools));

    /* --- byte array (unboxed) --- */
    VmArray *bytes = vm_array_new(&heap, TAG_U8, 4);
    ASSERT_EQ_INT(bytes->unboxed, 1, "byte array is unboxed");
    vm_array_push(&heap, bytes, val_u8(0));
    vm_array_push(&heap, bytes, val_u8(255));
    ASSERT_EQ_INT(vm_array_get(bytes, 0).tag, TAG_U8, "byte get tag");
    ASSERT_EQ_INT(vm_array_get(bytes, 0).as.u8, 0, "byte get [0]");
    ASSERT_EQ_INT(vm_array_get(bytes, 1).as.u8, 255, "byte get [1]");
    vm_release(&heap, val_array(bytes));

    /* --- reference element type stays boxed --- */
    VmArray *strs = vm_array_new(&heap, TAG_STRING, 4);
    ASSERT_EQ_INT(strs->unboxed, 0, "string array stays boxed");
    VmString *hello = vm_string_new(&heap, "hi", 2);
    vm_array_push(&heap, strs, val_string(hello));
    vm_release(&heap, val_string(hello)); /* array holds its own ref */
    ASSERT_EQ_INT(vm_array_get(strs, 0).tag, TAG_STRING, "boxed string get tag");
    vm_release(&heap, val_array(strs));

    vm_heap_destroy(&heap);
}

/* ========================================================================
 * Tests: Structs
 * ======================================================================== */

static void test_struct_literal(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_STRUCT_LITERAL, (uint32_t)0, 2);
    off += emit(code + off, OP_STRUCT_GET, 1);  /* get field 1 */
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "struct_literal: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 20, "struct_literal: field 1 == 20");
    nvm_module_free(mod);
}

static void test_struct_set(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_STRUCT_LITERAL, (uint32_t)0, 2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_STRUCT_SET, 0);   /* set field 0 to 42 */
    off += emit(code + off, OP_STRUCT_GET, 0);   /* get field 0 */
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "struct_set: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "struct_set: field 0 == 42 after set");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Tuples
 * ======================================================================== */

static void test_tuple(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_I64, (int64_t)99);
    off += emit(code + off, OP_TUPLE_NEW, 3);
    off += emit(code + off, OP_TUPLE_GET, 1);  /* get element 1 */
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "tuple: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "tuple: element 1 == 42");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Enums & Unions
 * ======================================================================== */

static void test_enum_val(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_ENUM_VAL, (uint32_t)0, 3);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "enum_val: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_ENUM, "enum_val: tag is enum");
    ASSERT_EQ_INT(result.as.enum_val, 3, "enum_val: variant 3");
    nvm_module_free(mod);
}

static void test_union_construct_tag(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_UNION_CONSTRUCT, (uint32_t)0, 2, 1);  /* variant 2, 1 field */
    off += emit(code + off, OP_UNION_TAG);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "union_construct_tag: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "union_construct_tag: variant == 2");
    nvm_module_free(mod);
}

static void test_union_field(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_UNION_CONSTRUCT, (uint32_t)0, 1, 1);  /* variant 1, 1 field */
    off += emit(code + off, OP_UNION_FIELD, 0);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "union_field: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "union_field: field 0 == 42");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Hashmaps
 * ======================================================================== */

static void test_hashmap_basic(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t key_str = nvm_add_string(mod, "answer", 6);

    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_HM_NEW, TAG_STRING, TAG_INT);
    off += emit(code + off, OP_PUSH_STR, key_str);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_PUSH_STR, key_str);
    off += emit(code + off, OP_HM_GET);
    off += emit(code + off, OP_RET);

    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hashmap_basic: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "hashmap_basic: get('answer') == 42");
    nvm_module_free(mod);
}

static void test_hashmap_len(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_HM_NEW, TAG_INT, TAG_INT);
    /* Set key 1 = 10, key 2 = 20 */
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_HM_LEN);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hashmap_len: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "hashmap_len: length == 2");
    nvm_module_free(mod);
}

/* I invoke an ordinary write through borrowed API arguments and inspect the
 * surviving owners after either success or the checked type refusal. */
static void test_hashmap_declared_write_tags(void) {
    uint8_t code[64];
    uint32_t off = 0;
    for (int i = 0; i < 3; ++i) off += emit(code + off, OP_LOAD_LOCAL, i);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_POP);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 3, 3);
    VmState vm;
    vm_init(&vm, mod);
    size_t baseline_objects = vm.heap.stats.num_objects;
    VmHashMap *map = vm_hashmap_new(&vm.heap, TAG_STRING, TAG_INT);
    VmString *key = vm_string_new(&vm.heap, "declared-key", 12);
    VmString *wrong_text = vm_string_new(&vm.heap, "wrong-value", 11);
    VmArray *wrong_array = vm_array_new(&vm.heap, TAG_INT, 1);
    ASSERT(map && key && wrong_text && wrong_array, "I allocate ordinary map owners");
    vm_hashmap_set(&vm.heap, map, val_string(key), val_int(41));
    NanoValue wrong[] = { val_bool(true), val_u8(41), val_float(41), val_enum(41),
                          val_void(), val_string(wrong_text), val_array(wrong_array) };
    size_t objects = vm.heap.stats.num_objects;
    for (size_t i = 0; i < sizeof wrong / sizeof *wrong; ++i) {
        NanoValue args[] = { val_hashmap(map), val_string(key), wrong[i] };
        NanoValue result = val_void();
        ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 3, &result), VM_ERR_TYPE_ERROR,
                      "I reject a value tag distinct from the declared int");
        ASSERT(strstr(vm.error_msg, "HM_SET key/value tags") != NULL,
               "I report the exact declared map write guard");
        ASSERT_EQ_INT(result.tag, TAG_VOID, "I publish no result after refused write");
        ASSERT_EQ_INT(map->count, 1, "I retain the prior entry count");
        ASSERT_EQ_INT(vm_hashmap_get(map, val_string(key)).as.i64, 41,
                      "I retain the prior entry value");
        ASSERT_EQ_INT(map->header.ref_count, 1, "I release the consumed map alias");
        ASSERT_EQ_INT(key->header.ref_count, 2, "I retain only caller and map key owners");
        ASSERT_EQ_INT(wrong_text->header.ref_count, 1, "I release consumed string aliases");
        ASSERT_EQ_INT(wrong_array->header.ref_count, 1, "I release consumed array aliases");
        ASSERT_EQ_INT(vm.heap.stats.num_objects, objects, "I retain no additional heap objects");
    }
    NanoValue args[] = { val_hashmap(map), val_array(wrong_array), val_int(99) };
    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 3, &result), VM_ERR_TYPE_ERROR,
                  "I reject a key tag distinct from the declaration");
    ASSERT_EQ_INT(wrong_array->header.ref_count, 1, "I release the consumed wrong key");
    ASSERT_EQ_INT(map->count, 1, "I do not add a wrong-key entry");
    args[1] = val_string(key);
    ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 3, &result), VM_OK,
                  "I can replace a value with matching tags after refusal");
    ASSERT_EQ_INT(vm_hashmap_get(map, val_string(key)).as.i64, 99,
                  "I publish a valid replacement");
    vm_release(&vm.heap, val_hashmap(map));
    vm_release(&vm.heap, val_string(key));
    vm_release(&vm.heap, val_string(wrong_text));
    vm_release(&vm.heap, val_array(wrong_array));
    vm_gc_collect_cycles(&vm.heap);
    ASSERT_EQ_INT(vm.heap.stats.num_objects, baseline_objects, "I reclaim all external owners");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_hashmap_contiguous_collisions(void) {
    VmHeap heap;
    vm_heap_init(&heap);
    VmHashMap *map = vm_hashmap_new(&heap, TAG_INT, TAG_INT);
    ASSERT(map != NULL, "hashmap allocation succeeds");
    ASSERT(map->entries != NULL, "hashmap entries use one contiguous allocation");

    for (int64_t i = 0; i < 40; i++) {
        vm_hashmap_set(&heap, map, val_int(i * 16), val_int(i + 100));
    }
    ASSERT_EQ_INT(map->count, 40, "colliding inserts survive growth");
    ASSERT(map->bucket_count >= 64, "contiguous table grows at its load limit");
    for (int64_t i = 0; i < 40; i++) {
        ASSERT_EQ_INT(vm_hashmap_get(map, val_int(i * 16)).as.i64, i + 100,
                      "colliding key remains reachable");
    }

    vm_hashmap_delete(&heap, map, val_int(16 * 10));
    ASSERT(!vm_hashmap_has(map, val_int(16 * 10)), "deleted colliding key is absent");
    ASSERT(vm_hashmap_has(map, val_int(16 * 11)), "probe continues past tombstone");
    vm_hashmap_set(&heap, map, val_int(16 * 50), val_int(150));
    ASSERT_EQ_INT(vm_hashmap_get(map, val_int(16 * 50)).as.i64, 150,
                  "tombstone remains reusable");

    vm_release(&heap, val_hashmap(map));
    vm_heap_destroy(&heap);
}

/* ========================================================================
 * Tests: Type Casts
 * ======================================================================== */

static void test_cast_int_from_float(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 3.14);
    off += emit(code + off, OP_CAST_INT);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "cast_int_from_float: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_INT, "cast_int_from_float: tag is int");
    ASSERT_EQ_INT(result.as.i64, 3, "cast_int_from_float: 3.14 -> 3");
    nvm_module_free(mod);
}

static void test_cast_float_from_u8(void) {
    for (unsigned value = 0; value <= 255; value++) {
        uint8_t code[16];
        uint32_t off = 0;
        off += emit(code + off, OP_PUSH_U8, (int)value);
        off += emit(code + off, OP_CAST_FLOAT);
        off += emit(code + off, OP_RET);
        NvmModule *mod = make_module(code, off, 0, 0);
        VmResult r;
        NanoValue result = run_module(mod, &r);
        ASSERT_EQ_INT(r, VM_OK, "cast_float_from_u8: VM_OK");
        ASSERT_EQ_INT(result.tag, TAG_FLOAT, "cast_float_from_u8: exact float tag");
        ASSERT_EQ_F64(result.as.f64, (double)value, "cast_float_from_u8: exact unsigned value");
        nvm_module_free(mod);
    }
}

static void test_cast_float_from_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_CAST_FLOAT);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "cast_float_from_int: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_FLOAT, "cast_float_from_int: tag is float");
    ASSERT_EQ_F64(result.as.f64, 42.0, "cast_float_from_int: 42 -> 42.0");
    nvm_module_free(mod);
}

static void test_cast_bool(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_CAST_BOOL);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "cast_bool: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_BOOL, "cast_bool: tag is bool");
    ASSERT(result.as.boolean == false, "cast_bool: 0 -> false");
    nvm_module_free(mod);
}

static void test_cast_string_from_u8(void) {
    for (unsigned value = 0; value <= 255; value++) {
        uint8_t code[16];
        uint32_t off = 0;
        off += emit(code + off, OP_PUSH_U8, (int)value);
        off += emit(code + off, OP_CAST_STRING);
        off += emit(code + off, OP_RET);
        NvmModule *mod = make_module(code, off, 0, 0);
        VmState vm;
        vm_init(&vm, mod);
        size_t baseline = vm.heap.stats.num_objects;
        ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "byte string: execution");
        NanoValue result = vm_get_result(&vm);
        ASSERT_EQ_INT(result.tag, TAG_STRING, "byte string: exact string tag");
        char expected[4];
        snprintf(expected, sizeof expected, "%u", value);
        ASSERT_EQ_STR(vmstring_cstr(result.as.string), expected, "byte string: unsigned decimal");
        /* I remove the returned stack root, then release exactly its reference. */
        vm.stack_size--;
        vm_release(&vm.heap, result);
        vm_gc_collect_cycles(&vm.heap);
        ASSERT_EQ_INT(vm.heap.stats.num_objects, baseline, "byte string: no retained allocation");
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

static void test_cast_string(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_CAST_STRING);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "cast_string: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_STRING, "cast_string: tag is string");
    ASSERT_EQ_STR(vmstring_cstr(result.as.string), "42", "cast_string: 42 -> '42'");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Closures
 * ======================================================================== */

static void test_closure(void) {
    /* fn make_adder(x) = closure(y) -> x + y
     * main: adder = make_adder(10); adder(32) => 42 */
    NvmModule *mod = make_multi_fn_module();

    /* Closure body: fn(y) { load_upvalue 0 (x) + load_local 0 (y) }
     * Locals: 0=y. Upvalues: 0=x */
    uint8_t body_code[64];
    uint32_t body_off = 0;
    body_off += emit(body_code + body_off, OP_LOAD_UPVALUE, 0, 0); /* x from closure */
    body_off += emit(body_code + body_off, OP_LOAD_LOCAL, 0);       /* y (param) */
    body_off += emit(body_code + body_off, OP_ADD);
    body_off += emit(body_code + body_off, OP_RET);
    uint32_t body_idx = add_fn(mod, "adder_body", body_code, body_off, 1, 1);

    /* make_adder(x): push x, CLOSURE_NEW body_idx 1, RET */
    uint8_t maker_code[64];
    uint32_t maker_off = 0;
    maker_off += emit(maker_code + maker_off, OP_LOAD_LOCAL, 0);  /* x */
    maker_off += emit(maker_code + maker_off, OP_CLOSURE_NEW, body_idx, 1);
    maker_off += emit(maker_code + maker_off, OP_RET);
    uint32_t maker_idx = add_fn(mod, "make_adder", maker_code, maker_off, 1, 1);

    /* main: make_adder(10), then call closure with 32 */
    uint8_t main_code[64];
    uint32_t main_off = 0;
    main_off += emit(main_code + main_off, OP_PUSH_I64, (int64_t)10);
    main_off += emit(main_code + main_off, OP_CALL, maker_idx);   /* returns closure */
    main_off += emit(main_code + main_off, OP_STORE_LOCAL, 0);     /* save closure */
    main_off += emit(main_code + main_off, OP_PUSH_I64, (int64_t)32); /* arg y */
    main_off += emit(main_code + main_off, OP_LOAD_LOCAL, 0);       /* load closure */
    /* CALL_INDIRECT invokes closures directly; the former CLOSURE_CALL opcode
     * was a duplicate that no frontend emitted and has been removed. */
    main_off += emit(main_code + main_off, OP_CALL_INDIRECT, 1, 1);
    main_off += emit(main_code + main_off, OP_RET);
    uint32_t main_idx = add_fn(mod, "main", main_code, main_off, 0, 1);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "closure: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "closure: make_adder(10)(32) == 42");
    nvm_module_free(mod);
}

/* ── Cycle collection ────────────────────────────────────────────────────
 *
 * Reference counting frees an object the moment its count reaches zero, which
 * never happens for a cycle: each member's count includes the reference from
 * the next. Cycles are constructible from ordinary NanoLang -- a struct with
 * an `array<Self>` field, pushed into its own array -- so the VM collects them
 * rather than forbidding the shape.
 */

static void test_self_referential_array_is_collected(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *a = vm_array_new(&heap, TAG_ARRAY, 4);
    NanoValue av = val_array(a);
    vm_array_push(&heap, a, av);      /* the array now holds itself */
    vm_release(&heap, av);            /* drop the only outside reference */

    ASSERT_EQ_INT((int)heap.stats.num_objects, 1,
                  "cycles: refcounting alone cannot free a self-reference");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 1, "cycles: one object reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "cycles: nothing left live");
    vm_heap_destroy(&heap);
}

static void test_two_object_cycle_is_collected(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *x = vm_array_new(&heap, TAG_ARRAY, 2);
    VmArray *y = vm_array_new(&heap, TAG_ARRAY, 2);
    NanoValue xv = val_array(x), yv = val_array(y);
    vm_array_push(&heap, x, yv);
    vm_array_push(&heap, y, xv);
    vm_release(&heap, xv);
    vm_release(&heap, yv);

    ASSERT_EQ_INT((int)heap.stats.num_objects, 2, "cycles: two-object cycle survives refcounting");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 2, "cycles: both reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "cycles: nothing left live");
    vm_heap_destroy(&heap);
}

/* The failure mode worse than the leak: freeing a cycle that is still
 * reachable. Trial deletion must restore the counts it subtracted. */
static void test_reachable_cycle_is_not_collected(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *p = vm_array_new(&heap, TAG_ARRAY, 2);
    VmArray *q = vm_array_new(&heap, TAG_ARRAY, 2);
    NanoValue pv = val_array(p), qv = val_array(q);
    vm_array_push(&heap, p, qv);
    vm_array_push(&heap, q, pv);
    vm_release(&heap, qv);            /* pv is still held: the cycle is live */

    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 0,
                  "cycles: a reachable cycle must survive");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 2, "cycles: both still live");
    /* Still usable, not just still allocated -- a collector that restored the
     * count but corrupted the contents would pass the check above. */
    ASSERT_EQ_INT((int)p->length, 1, "cycles: survivor is still readable");
    ASSERT_EQ_INT((int)vm_array_get(p, 0).tag, TAG_ARRAY, "cycles: its element survived");

    vm_release(&heap, pv);            /* now nothing outside points at it */
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 2, "cycles: collected once unreachable");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "cycles: nothing left live");
    vm_heap_destroy(&heap);
}

/* A cycle whose payload includes a leaf. The string cannot close a cycle, but
 * it is only reachable through one, so it has to go with it. */
static void test_cycle_payload_is_freed_with_it(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *r = vm_array_new(&heap, TAG_ARRAY, 4);
    NanoValue rv = val_array(r);
    VmString *str = vm_string_new(&heap, "payload", 7);
    vm_array_push(&heap, r, val_string(str));
    vm_release(&heap, val_string(str));
    vm_array_push(&heap, r, rv);
    vm_release(&heap, rv);

    ASSERT_EQ_INT((int)heap.stats.num_objects, 2, "cycles: array and string live");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 2, "cycles: both reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "cycles: including the leaf");
    vm_heap_destroy(&heap);
}

static void test_cycle_preserves_shared_live_payload(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *cycle = vm_array_new(&heap, TAG_ARRAY, 4);
    NanoValue cv = val_array(cycle);
    VmString *shared = vm_string_new(&heap, "shared", 6);
    NanoValue sv = val_string(shared);
    vm_array_push(&heap, cycle, sv);
    vm_array_push(&heap, cycle, cv);
    vm_release(&heap, cv);

    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 1,
                  "cycles: only the unreachable cycle is reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 1,
                  "cycles: externally held payload remains live");
    ASSERT_EQ_INT((int)shared->header.ref_count, 1,
                  "cycles: dead edge is removed exactly once");
    ASSERT(strcmp(vmstring_cstr(shared), "shared") == 0,
           "cycles: surviving payload remains readable");
    vm_release(&heap, sv);
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0,
                  "cycles: surviving payload releases normally");
    vm_heap_destroy(&heap);
}

static void test_cycles_share_dead_leaf(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *left = vm_array_new(&heap, TAG_ARRAY, 3);
    VmArray *right = vm_array_new(&heap, TAG_ARRAY, 3);
    NanoValue lv = val_array(left), rv = val_array(right);
    VmString *leaf = vm_string_new(&heap, "leaf", 4);
    NanoValue leafv = val_string(leaf);
    vm_array_push(&heap, left, leafv);
    vm_array_push(&heap, right, leafv);
    vm_release(&heap, leafv);
    vm_array_push(&heap, left, lv);
    vm_array_push(&heap, right, rv);
    vm_release(&heap, lv);
    vm_release(&heap, rv);

    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 3,
                  "cycles: two cycles and their shared dead leaf are reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0,
                  "cycles: shared dead leaf is freed once");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 0,
                  "cycles: repeated collection is empty and safe");
    vm_heap_destroy(&heap);
}

static void test_cycle_detaches_struct_field_names(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmStruct *record = vm_struct_new(&heap, 0, 1);
    NanoValue recordv = val_struct(record);
    record->field_names = calloc(1, sizeof(*record->field_names));
    ASSERT(record->field_names != NULL, "cycles: field name storage allocated");
    record->field_names[0] = vm_string_new(&heap, "next", 4);
    record->fields[0] = recordv;
    vm_retain(&heap, recordv);
    vm_release(&heap, recordv);

    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 2,
                  "cycles: record and owned field name are reclaimed");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0,
                  "cycles: detached field name is not released twice");
    vm_heap_destroy(&heap);
}

/* An object can reach zero while sitting on the suspect buffer, which holds a
 * bare pointer to it. Freeing it there would leave that pointer dangling and
 * the next collection would read a freed header -- so vm_release defers, and
 * the collector frees it on the pass that finds it at zero.
 *
 * AddressSanitizer found this and two more like it in the same function:
 * freeing an entry before the trial deletions had run, and freeing during the
 * collection walk while later entries still had to be read. All three are the
 * same mistake, which is reading an object's header after something else has
 * freed it. */
static void test_dead_cycles_preserve_shared_live_payload(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmString *text = vm_string_new(&heap, "live constant", 13);
    for (int round = 0; round < 4; round++) {
        VmArray *a = vm_array_new(&heap, TAG_ARRAY, 4);
        VmArray *b = vm_array_new(&heap, TAG_ARRAY, 4);
        vm_array_push(&heap, a, val_array(b));
        vm_array_push(&heap, b, val_array(a));
        vm_array_push(&heap, a, val_string(text));
        vm_array_push(&heap, b, val_string(text));
        vm_release(&heap, val_array(a));
        vm_release(&heap, val_array(b));
        ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 2, "I collect only the dead pair");
        ASSERT_EQ_INT((int)heap.stats.num_objects, 1, "I preserve the externally held string");
        ASSERT_EQ_INT((int)text->header.ref_count, 1, "I subtract each dead edge once");
        ASSERT_EQ_INT((int)text->length, 13, "I preserve constant contents");
    }
    vm_release(&heap, val_string(text));
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "I free the payload after its live owner releases it");
    vm_heap_destroy(&heap);
}

static void test_dead_cycle_preserves_live_field_name(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmString *name = vm_string_new(&heap, "field", 5);
    VmStruct *record = vm_struct_new(&heap, 0, 1);
    NanoValue value = val_struct(record);
    record->fields[0] = value;
    vm_retain(&heap, value);
    record->field_names = calloc(1, sizeof(VmString *));
    record->field_names[0] = name;
    vm_retain(&heap, val_string(name));
    vm_release(&heap, value);
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 1, "I collect the self-referential record");
    ASSERT_EQ_INT((int)name->header.ref_count, 1, "I account for its field-name edge once");
    ASSERT_EQ_INT((int)name->length, 5, "I preserve the externally owned field name");
    vm_release(&heap, val_string(name));
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "I reclaim the final field-name reference");
    vm_heap_destroy(&heap);
}

static void test_object_freed_while_buffered(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *outer = vm_array_new(&heap, TAG_ARRAY, 2);
    VmArray *inner = vm_array_new(&heap, TAG_ARRAY, 2);
    NanoValue ov = val_array(outer), iv = val_array(inner);

    vm_array_push(&heap, outer, iv);   /* inner is held twice */
    vm_release(&heap, iv);             /* down to one, and buffered as a suspect */
    vm_release(&heap, ov);             /* outer goes, taking inner to zero */

    /* inner is unreachable but still allocated, because it was buffered. */
    ASSERT_EQ_INT((int)heap.stats.num_objects, 1,
                  "buffered: an object at zero is held for the collector");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), 1,
                  "buffered: the collector frees it");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "buffered: nothing left live");
    vm_heap_destroy(&heap);
}

/* Several cycles collected in one pass. Each root is walked from the buffer
 * after earlier roots have already been dealt with, which is the shape that
 * exposed freeing during the walk. */
static void test_many_cycles_in_one_pass(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    const int pairs = 8;
    for (int i = 0; i < pairs; i++) {
        VmArray *x = vm_array_new(&heap, TAG_ARRAY, 2);
        VmArray *y = vm_array_new(&heap, TAG_ARRAY, 2);
        NanoValue xv = val_array(x), yv = val_array(y);
        vm_array_push(&heap, x, yv);
        vm_array_push(&heap, y, xv);
        vm_release(&heap, xv);
        vm_release(&heap, yv);
    }
    ASSERT_EQ_INT((int)heap.stats.num_objects, pairs * 2,
                  "many cycles: all still live under refcounting");
    ASSERT_EQ_INT((int)vm_gc_collect_cycles(&heap), pairs * 2,
                  "many cycles: one pass reclaims every one");
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0, "many cycles: nothing left live");
    vm_heap_destroy(&heap);
}

/* Destroying a heap collects first, so a program that ends holding a cycle
 * does not report it as still-allocated memory. */
static void test_heap_destroy_collects_cycles(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    VmArray *a = vm_array_new(&heap, TAG_ARRAY, 2);
    NanoValue av = val_array(a);
    vm_array_push(&heap, a, av);
    vm_release(&heap, av);
    vm_heap_destroy(&heap);
    ASSERT_EQ_INT((int)heap.cycles_collected, 1,
                  "cycles: teardown reclaims what is left");
}

/* Reference ownership when an array element is removed.
 *
 * vm_array_set releases the value it overwrites. vm_array_remove did not
 * release the value it drops -- it shifted the tail left and decremented the
 * length, so the array stopped pointing at the element while its refcount
 * still counted the array as an owner. Nothing else held a claim, so the
 * object leaked for the life of the process.
 *
 * Only arrays of reference types are affected; an unboxed array of ints has
 * no references to lose, which is why this uses strings. */
static void test_array_remove_releases_the_element(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);

    VmArray *a = vm_array_new(&heap, TAG_STRING, 4);
    NanoValue arr = val_array(a);
    const char *const labels[] = {"s0", "s1", "s2"};
    for (int i = 0; i < 3; i++) {
        VmString *s = vm_string_new(&heap, labels[i], 2);
        vm_array_push(&heap, a, val_string(s));
        vm_release(&heap, val_string(s));   /* push retains */
    }

    size_t before = heap.stats.num_objects;
    vm_array_remove(&heap, a, 1);
    ASSERT_EQ_INT((int)heap.stats.num_objects, (int)before - 1,
                  "array remove: the dropped element is freed");
    ASSERT_EQ_INT((int)a->length, 2, "array remove: length shrinks");

    vm_release(&heap, arr);
    ASSERT_EQ_INT((int)heap.stats.num_objects, 0,
                  "array remove: releasing the array leaves nothing behind");
    vm_heap_destroy(&heap);
}

/* Reference ownership across an indirect call through a closure.
 *
 * CALL_INDIRECT pops the callable, taking the stack's reference into a local,
 * and stores a borrowed VmClosure* in the new frame. Nothing released that
 * reference: not the instruction, and not the frame teardown, which only
 * releases stack slots. So every closure call through CALL_INDIRECT kept the
 * closure alive forever.
 *
 * Counting live objects after the run is what makes this visible. A test that
 * only checked the arithmetic result passed the whole time. */
static void test_closure_call_releases_the_callable(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t body_name = nvm_add_string(mod, "adder", 5);
    uint32_t maker_name = nvm_add_string(mod, "make_adder", 10);
    uint32_t main_name = nvm_add_string(mod, "main", 4);

    /* adder(y) = y + captured x */
    uint8_t body[32];
    uint32_t bl = 0;
    bl += emit(body + bl, OP_LOAD_LOCAL, (uint16_t)0);
    bl += emit(body + bl, OP_LOAD_UPVALUE, (uint16_t)0, (uint16_t)0);
    bl += emit(body + bl, OP_I64_ADD);
    bl += emit(body + bl, OP_RET);
    uint32_t bo = nvm_append_code(mod, body, bl);
    NvmFunctionEntry bf = {0};
    bf.name_idx = body_name; bf.arity = 1; bf.local_count = 1; bf.upvalue_count = 1;
    bf.code_offset = bo; bf.code_length = bl;
    bf.result_tag = TAG_INT; bf.result_count = 1;
    uint32_t body_idx = nvm_add_function(mod, &bf);

    /* make_adder(x) = closure over x */
    uint8_t maker[32];
    uint32_t mkl = 0;
    mkl += emit(maker + mkl, OP_LOAD_LOCAL, (uint16_t)0);
    mkl += emit(maker + mkl, OP_CLOSURE_NEW, body_idx, (uint16_t)1);
    mkl += emit(maker + mkl, OP_RET);
    uint32_t mko = nvm_append_code(mod, maker, mkl);
    NvmFunctionEntry mkf = {0};
    mkf.name_idx = maker_name; mkf.arity = 1; mkf.local_count = 1;
    mkf.code_offset = mko; mkf.code_length = mkl;
    mkf.result_tag = TAG_CLOSURE; mkf.result_count = 1;
    uint32_t maker_idx = nvm_add_function(mod, &mkf);

    /* main: call the closure, then discard the result so nothing is live. */
    uint8_t mc[64];
    uint32_t ml = 0;
    ml += emit(mc + ml, OP_PUSH_I64, (int64_t)10);
    ml += emit(mc + ml, OP_CALL, maker_idx);
    ml += emit(mc + ml, OP_STORE_LOCAL, (uint16_t)0);
    ml += emit(mc + ml, OP_PUSH_I64, (int64_t)32);
    ml += emit(mc + ml, OP_LOAD_LOCAL, (uint16_t)0);
    ml += emit(mc + ml, OP_CALL_INDIRECT, 1, 1);
    ml += emit(mc + ml, OP_POP);
    ml += emit(mc + ml, OP_RET);
    uint32_t mo = nvm_append_code(mod, mc, ml);
    NvmFunctionEntry mf = {0};
    mf.name_idx = main_name; mf.local_count = 1;
    mf.code_offset = mo; mf.code_length = ml;
    mf.result_tag = TAG_VOID; mf.result_count = 0;
    uint32_t main_idx = nvm_add_function(mod, &mf);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmState vm;
    vm_init(&vm, mod);
    /* vm_init preinstantiates the module's string constants, so the baseline
     * is what is live before execution -- not zero. Comparing against zero
     * would measure the constant pool, not ownership. */
    size_t baseline = vm.heap.stats.num_objects;
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "closure ownership: VM_OK");
    /* The closure is the only heap object the program creates, and the local
     * holding it is released with the frame. Its count passes through one on
     * the way down, which buffers it as a possible cycle root, so the last
     * release defers to the collector rather than freeing a pointer the
     * buffer still holds -- the count returns to baseline after a pass, not
     * before it. Before CALL_INDIRECT transferred the callable's reference to
     * the frame, it stayed one above even after collecting. */
    vm_gc_collect_cycles(&vm.heap);
    ASSERT_EQ_INT((int)vm.heap.stats.num_objects, (int)baseline,
                  "closure ownership: no heap object outlives the call");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_recursive_calls_retain_closure(void) {
    for (int tail = 0; tail < 2; ++tail) {
        char source[1024];
        snprintf(source, sizeof(source),
            ".function recurse 1 1 1 int 1\n"
            "LOAD_LOCAL 0\nPUSH_I64 0\nEQ\nJMP_FALSE again\n"
            "LOAD_UPVALUE 0 0\nRET\nagain:\n"
            "LOAD_LOCAL 0\nPUSH_I64 1\nSUB\n%s\n.end\n"
            ".function caller 0 0 0 int 1\n"
            "PUSH_I64 8\nPUSH_I64 42\nCLOSURE_NEW 0 1\n"
            "CALL_INDIRECT 1 1\nRET\n.end\n.entry 1\n",
            tail ? "TAIL_CALL 0" : "CALL 0\nRET");
        AsmResult assembled;
        NvmModule *module = asm_assemble(source, &assembled);
        ASSERT(module, "I assemble direct and tail recursive closure calls");
        NvmVerifyResult verified = nvm_verify(module);
        ASSERT(verified.ok, "I verify recursive capture access");
        VmState vm;vm_init(&vm,module);
        size_t baseline = vm.heap.stats.num_objects;
        NanoValue result = val_void();
        ASSERT_EQ_INT(vm_invoke(&vm,1,NULL,0,&result),VM_OK,
                      "I retain the active environment across recursion");
        ASSERT_EQ_INT(result.tag,TAG_INT,"I return the captured scalar type");
        ASSERT_EQ_INT(result.as.i64,42,"I return the captured scalar value");
        vm_gc_collect_cycles(&vm.heap);
        ASSERT_EQ_INT(vm.heap.stats.num_objects,baseline,
                      "I release recursive frame ownership after return");
        vm_destroy(&vm);nvm_module_free(module);
    }
}

static void test_destroy_releases_trapped_callable(void) {
    AsmResult assembled;
    NvmModule *module = asm_assemble(
        ".function trapped 0 0 1 void 0\nPUSH_BOOL 0\nASSERT\nRET\n.end\n"
        ".function caller 0 0 0 void 0\nPUSH_I64 42\nTUPLE_NEW 1\n"
        "CLOSURE_NEW 0 1\nCALL_INDIRECT 0 0\nRET\n.end\n", &assembled);
    ASSERT(module, "I assemble a managed closure with an assertion failure");
    NvmVerifyResult verified = nvm_verify(module);
    ASSERT(verified.ok, "I verify the complete trap teardown program");
    VmState vm;vm_init(&vm,module);
    size_t baseline = vm.heap.stats.num_objects;
    ASSERT_EQ_INT(vm_call_function(&vm,1,NULL,0),VM_ERR_ASSERT_FAILED,
                  "I retain the actual indirect-call assertion terminal");
    ASSERT_EQ_INT(vm.frame_count,2,"I leave both direct/core frames for explicit teardown");
    ASSERT(vm.frames[1].owned_callable.tag == TAG_CLOSURE,
           "The trapped frame still owns its invoked closure");
    ASSERT_EQ_INT(vm.heap.stats.num_objects,baseline+2,
                  "The closure and its managed tuple are live before teardown");
    vm_destroy(&vm);
    ASSERT_EQ_INT(vm.frame_count,0,"I detach every frame during destruction");
    ASSERT_EQ_INT(vm.handler_count,0,"I remove handlers after their frames");
    ASSERT_EQ_INT(vm.heap.stats.num_objects,0,"I release the callable and its captured tuple");
    ASSERT(vm.heap.stats.allocated == vm.heap.stats.freed,
           "I balance accounted heap bytes after trapped callable destruction");
    nvm_module_free(module);
}

static void test_direct_function_reference(void) {
    NvmModule *mod = make_multi_fn_module();
    uint8_t callee_code[32];
    uint32_t co = 0;
    co += emit(callee_code + co, OP_LOAD_LOCAL, 0);
    co += emit(callee_code + co, OP_PUSH_I64, (int64_t)1);
    co += emit(callee_code + co, OP_I64_ADD);
    co += emit(callee_code + co, OP_RET);
    uint32_t callee = add_fn(mod, "increment", callee_code, co, 1, 1);

    uint8_t main_code[32];
    uint32_t mo = 0;
    mo += emit(main_code + mo, OP_PUSH_I64, (int64_t)41);
    mo += emit(main_code + mo, OP_FUNCREF, callee);
    mo += emit(main_code + mo, OP_CALL_INDIRECT, 1, 1);
    mo += emit(main_code + mo, OP_RET);
    uint32_t main_fn = add_fn(mod, "main", main_code, mo, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_fn;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "direct function reference executes");
    ASSERT_EQ_INT(result.as.i64, 42, "direct function reference is unambiguous");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: I/O
 * ======================================================================== */

static void test_print(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t s1 = nvm_add_string(mod, "hello", 5);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s1);
    off += emit(code + off, OP_PRINTLN);
    off += emit(code + off, OP_PUSH_VOID);
    off += emit(code + off, OP_RET);

    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    /* Redirect output to capture */
    VmState vm;
    vm_init(&vm, mod);
    char buf[256] = {0};
    FILE *memf = fmemopen(buf, sizeof(buf), "w");
    vm.output = memf;

    VmResult r = vm_execute(&vm);
    fflush(memf);
    fclose(memf);

    ASSERT_EQ_INT(r, VM_OK, "print: VM_OK");
    ASSERT_EQ_STR(buf, "hello\n", "print: output is 'hello\\n'");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_assert_pass(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_ASSERT);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "assert_pass: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "assert_pass: execution continues");
    nvm_module_free(mod);
}

static void test_assert_fail(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 0);
    off += emit(code + off, OP_ASSERT);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_ASSERT_FAILED, "assert_fail: assertion failed");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Error Handling
 * ======================================================================== */

static void test_type_error_add(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "type_error_add: ADD int + bool => type error");
    nvm_module_free(mod);
}

static void test_no_entry_point(void) {
    NvmModule *mod = nvm_module_new();
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    add_fn(mod, "main", code, off, 0, 0);
    /* flags does NOT have NVM_FLAG_HAS_MAIN */

    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_ERR_UNDEFINED_FUNCTION, "no_entry_point: error");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Stack Trace / Debug Mode
 * ======================================================================== */

static void test_stack_trace_debug_mode(void) {
    /*
     * Build a module with debug info and a deliberate type error.
     * Enable debug_mode, capture output, and verify the trace
     * contains the expected function name and source location.
     *
     * Bytecode:
     *   DEBUG_LINE 10       <- marks line 10
     *   PUSH_I64  42
     *   PUSH_BOOL 1
     *   ADD                 <- type error: int + bool
     *   RET
     *
     * Debug entry: offset=0, line=10, col=3
     */
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_DEBUG_LINE, (uint32_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_PUSH_BOOL, (int)1);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    /* Add debug entry: bytecode offset 0 -> line 10, col 3 */
    nvm_add_debug_entry(mod, 0, 10, 3);
    mod->header.flags |= NVM_FLAG_DEBUG_INFO;
    /* Set source file */
    mod->source_file_idx = nvm_add_string(mod, "test_src.nano", 13);

    /* Capture output to a memory buffer */
    char buf[1024];
    memset(buf, 0, sizeof(buf));
    FILE *memf = fmemopen(buf, sizeof(buf) - 1, "w");
    ASSERT(memf != NULL, "fmemopen succeeded");

    VmState vm;
    vm_init(&vm, mod);
    vm.debug_mode = true;
    vm.output = memf;
    VmResult r = vm_execute(&vm);
    fclose(memf);
    vm_destroy(&vm);
    nvm_module_free(mod);

    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "debug_trace: ADD int+bool => type error");
    ASSERT(strstr(buf, "Stack trace") != NULL, "debug_trace: output contains 'Stack trace'");
    ASSERT(strstr(buf, "main") != NULL, "debug_trace: output contains function name 'main'");
    ASSERT(strstr(buf, "test_src.nano") != NULL, "debug_trace: output contains source file");
    ASSERT(strstr(buf, "10") != NULL, "debug_trace: output contains line 10");
}

static void test_assertion_stack_context(void) {
    /* I retain assertion context under either explicit debug or module metadata. */
    for (int mode = 0; mode < 3; ++mode) {
        uint8_t code[64];
        uint32_t off = 0;
        off += emit(code + off, OP_DEBUG_LINE, (uint32_t)17);
        off += emit(code + off, OP_PUSH_BOOL, (int)0);
        off += emit(code + off, OP_ASSERT);
        off += emit(code + off, OP_RET);
        NvmModule *mod = make_module(code, off, 0, 0);
        nvm_add_debug_entry(mod, 0, 17, 4);
        if (mode == 2) mod->header.flags |= NVM_FLAG_DEBUG_INFO;
        else mod->header.flags &= ~NVM_FLAG_DEBUG_INFO;
        mod->source_file_idx = nvm_add_string(mod, "assert.nano", 11);
        char buf[2048] = {0};
        FILE *out = fmemopen(buf, sizeof(buf) - 1, "w");
        ASSERT(out != NULL, "assert context stream");
        VmState vm;
        vm_init(&vm, mod);
        vm.debug_mode = mode == 1;
        vm.output = out;
        ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_ASSERT_FAILED, "assert result preserved");
        fclose(out);
        ASSERT(strcmp(vm.error_msg, "Assertion failed") == 0, "assert message preserved");
        if (mode) {
            ASSERT(strstr(buf, "Stack trace") != NULL, "assert stack context");
            ASSERT(strstr(buf, "main") != NULL, "assert function context");
            ASSERT(strstr(buf, "assert.nano:17") != NULL, "assert source context");
        } else {
            ASSERT(strstr(buf, "Stack trace") == NULL, "ordinary assert remains quiet");
        }
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

/* I distinguish the executing assertion and suspended call from their next
 * statements, without executable DEBUG_LINE instructions masking the lookup. */
static void test_stack_trace_executing_offsets(void) {
    for (unsigned mode = 0; mode < 4; ++mode) {
        uint8_t main_code[64], helper_code[64];
        uint32_t mo = 0, ho = 0;
        if (mode == 1) {
            mo += emit(main_code + mo, OP_FUNCREF, (uint32_t)1);
            mo += emit(main_code + mo, OP_CALL_INDIRECT, (int)0, (int)1);
        } else {
            mo += emit(main_code + mo, mode == 2 ? OP_TAIL_CALL : OP_CALL, (uint32_t)1);
        }
        uint32_t continuation = mo;
        mo += emit(main_code + mo, OP_RET);
        /* The taken branch reaches the assertion after an unrelated mapping. */
        ho += emit(helper_code + ho, OP_PUSH_BOOL, (int)1);
        ho += emit(helper_code + ho, OP_JMP_TRUE, (int32_t)6);
        ho += emit(helper_code + ho, OP_NOP);
        uint32_t selected = ho;
        ho += emit(helper_code + ho, OP_PUSH_BOOL, (int)0);
        ho += emit(helper_code + ho, OP_ASSERT);
        uint32_t next_statement = ho;
        ho += emit(helper_code + ho, OP_PUSH_I64, (int64_t)0);
        ho += emit(helper_code + ho, OP_RET);
        NvmModule *mod = make_multi_fn_module();
        uint32_t main_idx = add_fn(mod, "main", main_code, mo, 0, 0);
        add_fn(mod, "helper", helper_code, ho, 0, 0);
        nvm_add_debug_entry(mod, 0, 100, 3);
        nvm_add_debug_entry(mod, continuation, 101, 4);
        if (mode != 3) {
            nvm_add_debug_entry(mod, mo, 199, 5);
            nvm_add_debug_entry(mod, mo + selected, 200, 6);
            nvm_add_debug_entry(mod, mo + next_statement, 201, 7);
        }
        mod->header.flags |= NVM_FLAG_DEBUG_INFO | NVM_FLAG_HAS_MAIN;
        mod->header.entry_point = main_idx;
        mod->source_file_idx = nvm_add_string(mod, "offset.nano", 11);
        char buf[2048] = {0};
        FILE *out = fmemopen(buf, sizeof(buf) - 1, "w");
        ASSERT(out != NULL, "I open the exact-location trace");
        VmState vm;
        vm_init(&vm, mod);
        vm.output = out;
        ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_ASSERT_FAILED, "I preserve the assertion failure");
        fclose(out);
        ASSERT(strstr(buf, "offset.nano:101") == NULL, "I do not report the caller continuation");
        ASSERT(strstr(buf, "offset.nano:201") == NULL, "I do not report the next assertion statement");
        if (mode != 3)
            ASSERT(strstr(buf, "helper  offset.nano:200:6") != NULL, "I report the executing assertion");
        else
            ASSERT(strstr(buf, "helper  offset.nano:?") != NULL, "I report unknown instead of borrowing another function's mapping");
        if (mode != 2)
            ASSERT(strstr(buf, "main  offset.nano:100:3") != NULL, "I retain the suspended call location");
        else
            ASSERT(strstr(buf, "main  offset.nano:") == NULL, "I replace the tail-call frame");
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

static void test_stack_trace_fused_field_location(void) {
    for (unsigned fused = 0; fused < 2; ++fused) {
        uint8_t code[128];
        uint32_t load = 0, field = 0;
        uint32_t size = emit_local_field_program(code, 9, &load, &field);
        NvmModule *mod = make_module(code, size, 0, 1);
        mod->header.flags |= NVM_FLAG_DEBUG_INFO;
        mod->source_file_idx = nvm_add_string(mod, "fused.nano", 10);
        nvm_add_debug_entry(mod, load, 301, 1);
        nvm_add_debug_entry(mod, field, 302, 2);
        nvm_add_debug_entry(mod, size - 1, 303, 3);
        char buf[2048] = {0};
        FILE *out = fmemopen(buf, sizeof(buf) - 1, "w");
        ASSERT(out != NULL, "I capture the fused field location");
        VmState vm;
        vm_init(&vm, mod);
        vm.output = out;
        vm_set_dispatch_profile(&vm, fused ? vm_dispatch_profile_all() : vm_dispatch_profile_none());
        ASSERT(vm_rebuild_module(&vm, mod), "I rebuild the selected fusion profile");
        uint32_t index = vm.dispatch_module.functions[0].offset_to_index[load] - 1;
        ASSERT_EQ_INT(vm.dispatch_module.functions[0].instructions[index].super_op,
                      fused ? VM_SUPER_LOAD_LOCAL_FIELD : VM_SUPER_NONE,
                      "I exercise the actual requested dispatch profile");
        ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_OUT_OF_BOUNDS, "I preserve field bounds failure");
        fclose(out);
        ASSERT(strstr(buf, "fused.nano:302:2") != NULL, "I report the field phase");
        ASSERT(strstr(buf, "fused.nano:301") == NULL, "I do not report the preceding local load");
        ASSERT(strstr(buf, "fused.nano:303") == NULL, "I do not report the continuation");
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

static void test_stack_trace_col(void) {
    /*
     * Verify col appears in the trace when source_col > 0 in the debug entry.
     */
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_DEBUG_LINE, (uint32_t)5);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_BOOL, (int)0);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    nvm_add_debug_entry(mod, 0, 5, 7);
    mod->header.flags |= NVM_FLAG_DEBUG_INFO;
    mod->source_file_idx = nvm_add_string(mod, "col_test.nano", 13);

    char buf[1024];
    memset(buf, 0, sizeof(buf));
    FILE *memf = fmemopen(buf, sizeof(buf) - 1, "w");
    ASSERT(memf != NULL, "fmemopen for col test");

    VmState vm;
    vm_init(&vm, mod);
    vm.debug_mode = true;
    vm.output = memf;
    VmResult r = vm_execute(&vm);
    fclose(memf);
    vm_destroy(&vm);
    nvm_module_free(mod);

    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "debug_trace_col: type error");
    ASSERT(strstr(buf, "5:7") != NULL, "debug_trace_col: output contains line:col '5:7'");
}

static void test_stack_trace_multi_frame(void) {
    /*
     * Build a two-function module: main calls helper, helper traps.
     *
     *  fn helper():           fn main():
     *    DEBUG_LINE 42          DEBUG_LINE 100
     *    PUSH_I64 1             CALL helper (fn_idx=0)
     *    PUSH_BOOL false        RET
     *    ADD  <- type trap
     *    RET
     *
     * Expected trace (innermost first):
     *   #0  helper  multi.nano:42
     *   #1  main    multi.nano:100
     */
    uint8_t helper_code[64];
    uint32_t ho = 0;
    ho += emit(helper_code + ho, OP_DEBUG_LINE, (uint32_t)42);
    ho += emit(helper_code + ho, OP_PUSH_I64,   (int64_t)1);
    ho += emit(helper_code + ho, OP_PUSH_BOOL,  (int)0);
    ho += emit(helper_code + ho, OP_ADD);
    ho += emit(helper_code + ho, OP_RET);

    uint8_t main_code[64];
    uint32_t mo = 0;
    mo += emit(main_code + mo, OP_DEBUG_LINE, (uint32_t)100);
    /* OP_CALL fn_idx=0 (helper) */
    mo += emit(main_code + mo, OP_CALL, (uint32_t)0);
    mo += emit(main_code + mo, OP_RET);

    NvmModule *mod = make_multi_fn_module();
    uint32_t helper_idx = add_fn(mod, "helper", helper_code, ho, 0, 0);
    uint32_t main_idx   = add_fn(mod, "main",   main_code,   mo, 0, 0);
    (void)helper_idx;

    nvm_add_debug_entry(mod, 0, 42,  1);   /* helper at bytecode offset 0 -> line 42 */
    nvm_add_debug_entry(mod, ho, 100, 1);  /* main   at bytecode offset ho -> line 100 */
    mod->header.flags |= NVM_FLAG_DEBUG_INFO | NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;
    mod->source_file_idx = nvm_add_string(mod, "multi.nano", 10);

    char buf[2048];
    memset(buf, 0, sizeof(buf));
    FILE *memf = fmemopen(buf, sizeof(buf) - 1, "w");
    ASSERT(memf != NULL, "fmemopen for multi-frame test");

    VmState vm;
    vm_init(&vm, mod);
    vm.debug_mode = true;
    vm.output = memf;
    VmResult r = vm_execute(&vm);
    fclose(memf);
    vm_destroy(&vm);
    nvm_module_free(mod);

    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "multi_frame: type error in helper");
    ASSERT(strstr(buf, "Stack trace") != NULL, "multi_frame: contains 'Stack trace'");
    ASSERT(strstr(buf, "helper") != NULL, "multi_frame: contains 'helper'");
    ASSERT(strstr(buf, "42") != NULL,     "multi_frame: contains line 42 (helper)");
    ASSERT(strstr(buf, "multi.nano") != NULL, "multi_frame: contains source file");
}

/* ========================================================================
 * Tests: Opaque Proxy
 * ======================================================================== */

static void test_opaque_null(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_OPAQUE_NULL);
    off += emit(code + off, OP_OPAQUE_VALID);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "opaque_null: VM_OK");
    ASSERT(result.as.boolean == false, "opaque_null: null proxy is not valid");
    nvm_module_free(mod);
}

/* ========================================================================
 * Tests: Serialize/Execute Round-trip
 * ======================================================================== */

static void test_serialize_execute(void) {
    /* Build a module, serialize, deserialize, execute */
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)21);
    off += emit(code + off, OP_PUSH_I64, (int64_t)21);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);

    NvmModule *mod1 = make_module(code, off, 0, 0);

    uint32_t blob_size = 0;
    uint8_t *blob = nvm_serialize(mod1, &blob_size);
    ASSERT(blob != NULL, "serialize_execute: serialize ok");
    ASSERT(blob_size > 0, "serialize_execute: blob_size > 0");
    nvm_module_free(mod1);

    NvmModule *mod2 = nvm_deserialize(blob, blob_size);
    free(blob);
    ASSERT(mod2 != NULL, "serialize_execute: deserialize ok");

    VmResult r;
    NanoValue result = run_module(mod2, &r);
    ASSERT_EQ_INT(r, VM_OK, "serialize_execute: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "serialize_execute: 21 + 21 == 42");
    nvm_module_free(mod2);
}

/* ========================================================================
 * Tests: Complex Programs
 * ======================================================================== */

static void test_fibonacci(void) {
    /* fn fib(n) = if n <= 1 then n else fib(n-1) + fib(n-2) */
    NvmModule *mod = make_multi_fn_module();

    uint8_t fib_code[256];
    uint32_t off = 0;

    /* n <= 1? */
    off += emit(fib_code + off, OP_LOAD_LOCAL, 0);
    off += emit(fib_code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(fib_code + off, OP_LE);
    uint32_t jf = off;
    off += emit(fib_code + off, OP_JMP_FALSE, (int32_t)0);

    /* then: return n */
    off += emit(fib_code + off, OP_LOAD_LOCAL, 0);
    off += emit(fib_code + off, OP_RET);

    /* else: fib(n-1) + fib(n-2) */
    uint32_t else_off = off;
    off += emit(fib_code + off, OP_LOAD_LOCAL, 0);
    off += emit(fib_code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(fib_code + off, OP_SUB);
    off += emit(fib_code + off, OP_CALL, (uint32_t)0);  /* fib(n-1), fn idx 0 */

    off += emit(fib_code + off, OP_LOAD_LOCAL, 0);
    off += emit(fib_code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(fib_code + off, OP_SUB);
    off += emit(fib_code + off, OP_CALL, (uint32_t)0);  /* fib(n-2) */

    off += emit(fib_code + off, OP_ADD);
    off += emit(fib_code + off, OP_RET);

    emit(fib_code + jf, OP_JMP_FALSE, (int32_t)(else_off - jf));

    uint32_t fib_idx = add_fn(mod, "fib", fib_code, off, 1, 1);

    /* main: fib(10) = 55 */
    uint8_t main_code[64];
    uint32_t moff = 0;
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)10);
    moff += emit(main_code + moff, OP_CALL, fib_idx);
    moff += emit(main_code + moff, OP_RET);
    uint32_t main_idx = add_fn(mod, "main", main_code, moff, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "fibonacci: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 55, "fibonacci: fib(10) == 55");
    nvm_module_free(mod);
}

static void test_gcd(void) {
    /* fn gcd(a, b) = if b == 0 then a else gcd(b, a % b) */
    NvmModule *mod = make_multi_fn_module();

    uint8_t gcd_code[256];
    uint32_t off = 0;

    /* b == 0? */
    off += emit(gcd_code + off, OP_LOAD_LOCAL, 1);  /* b */
    off += emit(gcd_code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(gcd_code + off, OP_EQ);
    uint32_t jf = off;
    off += emit(gcd_code + off, OP_JMP_FALSE, (int32_t)0);

    /* then: return a */
    off += emit(gcd_code + off, OP_LOAD_LOCAL, 0);
    off += emit(gcd_code + off, OP_RET);

    /* else: gcd(b, a % b) */
    uint32_t else_off = off;
    off += emit(gcd_code + off, OP_LOAD_LOCAL, 1);  /* b */
    off += emit(gcd_code + off, OP_LOAD_LOCAL, 0);  /* a */
    off += emit(gcd_code + off, OP_LOAD_LOCAL, 1);  /* b */
    off += emit(gcd_code + off, OP_MOD);             /* a % b */
    off += emit(gcd_code + off, OP_CALL, (uint32_t)0);  /* gcd(b, a%b) */
    off += emit(gcd_code + off, OP_RET);

    emit(gcd_code + jf, OP_JMP_FALSE, (int32_t)(else_off - jf));

    uint32_t gcd_idx = add_fn(mod, "gcd", gcd_code, off, 2, 2);

    /* main: gcd(48, 18) = 6 */
    uint8_t main_code[64];
    uint32_t moff = 0;
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)48);
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)18);
    moff += emit(main_code + moff, OP_CALL, gcd_idx);
    moff += emit(main_code + moff, OP_RET);
    uint32_t main_idx = add_fn(mod, "main", main_code, moff, 0, 0);

    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = main_idx;

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "gcd: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 6, "gcd: gcd(48, 18) == 6");
    nvm_module_free(mod);
}

/* ========================================================================
 * Test: Assembler -> VM integration
 * ======================================================================== */

static void test_assemble_and_run(void) {
    /* Assemble a simple program, execute it */
    const char *src =
        ".string \"unused\"\n"
        ".function main 0 0 0 int 1\n"
        "  PUSH_I64 21\n"
        "  PUSH_I64 21\n"
        "  ADD\n"
        "  RET\n"
        ".end\n"
        ".entry 0\n";

    AsmResult asm_result;
    NvmModule *mod = asm_assemble(src, &asm_result);
    ASSERT(mod != NULL, "assemble_and_run: assembly ok");
    ASSERT_EQ_INT(asm_result.error, ASM_OK, "assemble_and_run: no asm error");

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "assemble_and_run: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "assemble_and_run: 21 + 21 == 42");
    nvm_module_free(mod);
}

static void test_assemble_function_call(void) {
    const char *src =
        ".function double 1 1 0 int 1\n"
        "  LOAD_LOCAL 0\n"
        "  DUP\n"
        "  ADD\n"
        "  RET\n"
        ".end\n"
        ".function main 0 0 0 int 1\n"
        "  PUSH_I64 21\n"
        "  CALL 0\n"
        "  RET\n"
        ".end\n"
        ".entry 1\n";

    AsmResult asm_result;
    NvmModule *mod = asm_assemble(src, &asm_result);
    ASSERT(mod != NULL, "asm_function_call: assembly ok");

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "asm_function_call: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "asm_function_call: double(21) == 42");
    nvm_module_free(mod);
}

static void test_assemble_loop(void) {
    /* Sum 1..5 using a loop */
    const char *src =
        ".function main 0 2 0 int 1\n"
        "  PUSH_I64 0\n"
        "  STORE_LOCAL 0\n"     /* sum = 0 */
        "  PUSH_I64 5\n"
        "  STORE_LOCAL 1\n"     /* i = 5 */
        "loop_top:\n"
        "  LOAD_LOCAL 1\n"
        "  PUSH_I64 0\n"
        "  GT\n"
        "  JMP_FALSE loop_end\n"
        "  LOAD_LOCAL 0\n"
        "  LOAD_LOCAL 1\n"
        "  ADD\n"
        "  STORE_LOCAL 0\n"     /* sum += i */
        "  LOAD_LOCAL 1\n"
        "  PUSH_I64 1\n"
        "  SUB\n"
        "  STORE_LOCAL 1\n"     /* i -= 1 */
        "  JMP loop_top\n"
        "loop_end:\n"
        "  LOAD_LOCAL 0\n"
        "  RET\n"
        ".end\n"
        ".entry 0\n";

    AsmResult asm_result;
    NvmModule *mod = asm_assemble(src, &asm_result);
    ASSERT(mod != NULL, "asm_loop: assembly ok");
    ASSERT_EQ_INT(asm_result.error, ASM_OK, "asm_loop: no asm error");

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "asm_loop: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 15, "asm_loop: sum(1..5) == 15");
    nvm_module_free(mod);
}

/* ========================================================================
 * Additional Opcode Coverage Tests
 * ======================================================================== */

static void test_rot3(void) {
    /* ROT3: rotates top 3 items.
     * Implementation: a=stack[top], stack[top]=stack[top-1],
     *   stack[top-1]=stack[top-2], stack[top-2]=a
     * So [1, 2, 3] → [3, 1, 2]  (3 goes to bottom, 1 and 2 move up) */
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);  /* bottom */
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);  /* middle */
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);  /* top */
    off += emit(code + off, OP_ROT3);                  /* [3, 1, 2] */
    off += emit(code + off, OP_POP);                   /* pop 2 (top) */
    off += emit(code + off, OP_POP);                   /* pop 1 (middle) */
    /* Only 3 (was top, now at bottom) remains */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "rot3: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3, "rot3: original top moved to bottom");
    nvm_module_free(mod);
}

static void test_call_indirect(void) {
    /* CALL_INDIRECT: push function index then call indirectly */
    uint8_t helper_code[16];
    uint32_t hoff = 0;
    /* Helper fn: just add 1 to param */
    hoff += emit(helper_code + hoff, OP_LOAD_LOCAL, (uint16_t)0);
    hoff += emit(helper_code + hoff, OP_PUSH_I64, (int64_t)1);
    hoff += emit(helper_code + hoff, OP_ADD);
    hoff += emit(helper_code + hoff, OP_RET);

    NvmModule *mod = nvm_module_new();
    uint32_t helper_idx = add_fn(mod, "helper", helper_code, hoff, 1, 1);

    uint8_t main_code[64];
    uint32_t moff = 0;
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)41);  /* arg */
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)helper_idx);
    /* push function value */
    /* Actually need to push a TAG_FUNCTION value — but val_function uses TAG_FUNCTION.
     * The easiest way is: emit OP_PUSH_I64 with fn_idx? No, we need a function value.
     * Use OP_CLOSURE_NEW to create a function value: */
    /* Reset: use a simpler approach - push fn_idx as a FUNCTION tag.
     * CLOSURE_NEW creates a closure value (TAG_FUNCTION) with fn_idx */
    moff = 0; /* reset */
    moff += emit(main_code + moff, OP_PUSH_I64, (int64_t)41);
    moff += emit(main_code + moff, OP_CLOSURE_NEW, (uint32_t)helper_idx, (uint16_t)0);
    moff += emit(main_code + moff, OP_CALL_INDIRECT, 1, 1);
    moff += emit(main_code + moff, OP_RET);

    add_fn(mod, "main", main_code, moff, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = 1; /* main is fn[1] */

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "call_indirect: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 42, "call_indirect: helper(41) == 42");
    nvm_module_free(mod);
}

static void test_arr_remove(void) {
    /* ARR_REMOVE: removes element at index */
    uint8_t code[64];
    uint32_t off = 0;
    /* Create [10, 20, 30] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)30);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    /* Remove index 1 (element 20) → [10, 30] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_ARR_REMOVE);
    off += emit(code + off, OP_ARR_LEN);  /* should be 2 */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "arr_remove: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "arr_remove: length is 2 after remove");
    nvm_module_free(mod);
}

static void test_arr_slice(void) {
    /* ARR_SLICE: slices array [start, end) */
    uint8_t code[64];
    uint32_t off = 0;
    /* Create [10, 20, 30, 40] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)30);
    off += emit(code + off, OP_PUSH_I64, (int64_t)40);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)4);
    /* Slice [1, 3) → [20, 30] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_ARR_SLICE);
    off += emit(code + off, OP_ARR_LEN);  /* should be 2 */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "arr_slice: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "arr_slice: length is 2");
    nvm_module_free(mod);
}

static void test_arr_pop(void) {
    /* ARR_POP removes the last element and leaves just that element. It used
     * to leave the element AND the array, making it the only instruction in
     * the ISA with two results and forcing every caller to discard one. */
    uint8_t code[64];
    uint32_t off = 0;
    /* Create [10, 20] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)2);
    off += emit(code + off, OP_ARR_POP);  /* stack: [20] */
    off += emit(code + off, OP_RET);      /* return 20 */
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "arr_pop: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 20, "arr_pop: popped value is 20");
    nvm_module_free(mod);
}

static void test_str_substr(void) {
    /* STR_SUBSTR: substring(str, start, len) */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t str_idx = nvm_add_string(mod, "hello world", 11);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_PUSH_STR, str_idx);   /* str */
    off += emit(code + off, OP_PUSH_I64, (int64_t)6); /* start */
    off += emit(code + off, OP_PUSH_I64, (int64_t)5); /* len */
    off += emit(code + off, OP_STR_SUBSTR);            /* → "world" */
    off += emit(code + off, OP_STR_LEN);               /* → 5 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_substr: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 5, "str_substr: 'world' has length 5");
    nvm_module_free(mod);
}

static void test_str_contains(void) {
    /* STR_CONTAINS: haystack contains needle */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t hay_idx = nvm_add_string(mod, "hello world", 11);
    uint32_t needle_idx = nvm_add_string(mod, "world", 5);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_PUSH_STR, hay_idx);
    off += emit(code + off, OP_PUSH_STR, needle_idx);
    off += emit(code + off, OP_STR_CONTAINS);  /* → true */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_BOOL, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_contains: VM_OK");
    ASSERT(result.tag == TAG_BOOL && result.as.boolean, "str_contains: 'hello world' contains 'world'");
    nvm_module_free(mod);
}

static void test_str_eq(void) {
    /* STR_EQ: string equality */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t s1_idx = nvm_add_string(mod, "foo", 3);
    uint32_t s2_idx = nvm_add_string(mod, "foo", 3);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_PUSH_STR, s1_idx);
    off += emit(code + off, OP_PUSH_STR, s2_idx);
    off += emit(code + off, OP_STR_EQ);   /* → true */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_BOOL, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_eq: VM_OK");
    ASSERT(result.tag == TAG_BOOL && result.as.boolean, "str_eq: 'foo' == 'foo'");
    nvm_module_free(mod);
}

static void test_str_char_at(void) {
    /* STR_CHAR_AT: returns the integer codepoint at the given index */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t str_idx = nvm_add_string(mod, "hello", 5);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_PUSH_STR, str_idx);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);  /* index 1 → 'e' = 101 */
    off += emit(code + off, OP_STR_CHAR_AT);            /* → int 101 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_char_at: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 'e', "str_char_at: index 1 of 'hello' is 'e'");
    nvm_module_free(mod);
}

static void test_str_from_float(void) {
    /* STR_FROM_FLOAT: float to string */
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 3.14);
    off += emit(code + off, OP_STR_FROM_FLOAT);
    off += emit(code + off, OP_STR_LEN);   /* length should be > 0 */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "str_from_float: VM_OK");
    ASSERT(result.as.i64 > 0, "str_from_float: result string non-empty");
    nvm_module_free(mod);
}

static void test_hm_has(void) {
    /* HM_HAS: check if key exists in hashmap */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t key_idx = nvm_add_string(mod, "name", 4);
    uint32_t val_idx = nvm_add_string(mod, "Alice", 5);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_HM_NEW, (uint8_t)TAG_STRING, (uint8_t)TAG_STRING);
    off += emit(code + off, OP_PUSH_STR, key_idx);
    off += emit(code + off, OP_PUSH_STR, val_idx);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_PUSH_STR, key_idx);
    off += emit(code + off, OP_HM_HAS);   /* → true */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_BOOL, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hm_has: VM_OK");
    ASSERT(result.tag == TAG_BOOL && result.as.boolean, "hm_has: key exists");
    nvm_module_free(mod);
}

static void test_hm_delete(void) {
    /* HM_DELETE: remove key from hashmap */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t key_idx = nvm_add_string(mod, "x", 1);
    uint32_t val_idx = nvm_add_string(mod, "v", 1);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_HM_NEW, (uint8_t)TAG_STRING, (uint8_t)TAG_STRING);
    off += emit(code + off, OP_PUSH_STR, key_idx);
    off += emit(code + off, OP_PUSH_STR, val_idx);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_PUSH_STR, key_idx);
    off += emit(code + off, OP_HM_DELETE);  /* removes key */
    off += emit(code + off, OP_HM_LEN);     /* → 0 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hm_delete: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 0, "hm_delete: map empty after delete");
    nvm_module_free(mod);
}

static void test_hm_keys(void) {
    /* HM_KEYS: returns array of all keys */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t k1 = nvm_add_string(mod, "a", 1);
    uint32_t k2 = nvm_add_string(mod, "b", 1);
    uint32_t v1 = nvm_add_string(mod, "1", 1);
    uint32_t v2 = nvm_add_string(mod, "2", 1);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_HM_NEW, (uint8_t)TAG_STRING, (uint8_t)TAG_STRING);
    off += emit(code + off, OP_PUSH_STR, k1);
    off += emit(code + off, OP_PUSH_STR, v1);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_PUSH_STR, k2);
    off += emit(code + off, OP_PUSH_STR, v2);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_HM_KEYS);   /* → array of 2 keys */
    off += emit(code + off, OP_ARR_LEN);   /* → 2 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hm_keys: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 2, "hm_keys: 2 keys");
    nvm_module_free(mod);
}

static void test_hm_values(void) {
    /* HM_VALUES: returns array of all values */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t k1 = nvm_add_string(mod, "x", 1);
    uint32_t v1 = nvm_add_string(mod, "alpha", 5);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_HM_NEW, (uint8_t)TAG_STRING, (uint8_t)TAG_STRING);
    off += emit(code + off, OP_PUSH_STR, k1);
    off += emit(code + off, OP_PUSH_STR, v1);
    off += emit(code + off, OP_HM_SET);
    off += emit(code + off, OP_HM_VALUES);  /* → array of 1 value */
    off += emit(code + off, OP_ARR_LEN);    /* → 1 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "hm_values: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 1, "hm_values: 1 value");
    nvm_module_free(mod);
}

static void test_add_strings(void) {
    /* OP_ADD with two strings → string concat */
    uint8_t code[64];
    uint32_t off = 0;
    NvmModule *mod = nvm_module_new();
    uint32_t s1 = nvm_add_string(mod, "hello", 5);
    uint32_t s2 = nvm_add_string(mod, " world", 6);
    uint32_t name_idx = nvm_add_string(mod, "main", 4);

    off += emit(code + off, OP_PUSH_STR, s1);
    off += emit(code + off, OP_PUSH_STR, s2);
    off += emit(code + off, OP_ADD);         /* string + string = concat */
    off += emit(code + off, OP_STR_LEN);     /* → 11 */
    off += emit(code + off, OP_RET);

    uint32_t code_off = nvm_append_code(mod, code, off);
    NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
    fn.name_idx = name_idx;
    fn.code_offset = code_off;
    fn.code_length = off;
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = nvm_add_function(mod, &fn);

    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add_strings: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 11, "add_strings: 'hello' + ' world' = length 11");
    nvm_module_free(mod);
}

static void test_add_array_array(void) {
    /* OP_ADD with two int arrays → element-wise add */
    uint8_t code[128]; /* Need >64 bytes: 6×PUSH_I64(9) + 2×ARR_LITERAL(4) + ops */
    uint32_t off = 0;
    /* [1, 2, 3] + [10, 20, 30] = [11, 22, 33] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)30);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_ADD);        /* element-wise */
    off += emit(code + off, OP_ARR_LEN);    /* → 3 */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add_array_array: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3, "add_array_array: result has 3 elements");
    nvm_module_free(mod);
}

static void test_scalar_arithmetic_boundaries(void) {
    const NanoOpcode ops[] = {OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD,
        OP_I64_ADD, OP_I64_SUB, OP_I64_MUL, OP_I64_DIV_S, OP_I64_REM_S};
    const int64_t pairs[][2] = {{INT64_MAX, 1}, {INT64_MIN, -1}, {9, 0}};
    const int64_t expected[][5] = {
        {INT64_MIN, INT64_MAX - 1, INT64_MAX, INT64_MAX, 0},
        {INT64_MAX, INT64_MIN + 1, INT64_MIN, INT64_MIN, 0},
        {9, 9, 0, 0, 0}
    };
    for (unsigned op = 0; op < 10; op++) {
        uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0,
                          (uint8_t)ops[op], OP_RET};
        NvmModule *mod = make_module(code, sizeof(code), 2, 2);
        mod->functions[0].result_tag = TAG_INT;
        VmState vm;
        vm_init(&vm, mod);
        for (unsigned pair = 0; pair < 3; pair++) {
            NanoValue args[] = {val_int(pairs[pair][0]), val_int(pairs[pair][1])};
            NanoValue output = val_void();
            ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_OK, "scalar boundary");
            ASSERT_EQ_INT(output.tag, TAG_INT, "integer result");
            ASSERT_EQ_INT(output.as.i64, expected[pair][op % 5], "total wrapping result");
        }
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

static void test_array_read_index_contract(void) {
    uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0, OP_ARR_GET, OP_RET};
    NvmModule *mod = make_module(code, sizeof code, 2, 2);
    /* The in-memory embedder result permits a present string or missing void. */
    mod->functions[0].result_tag = TAG_VOID;
    VmState vm;
    vm_init(&vm, mod);
    for (unsigned test = 0; test < 13; ++test) {
        size_t before = vm.heap.stats.num_objects;
        VmArray *array = vm_array_new(&vm.heap, TAG_STRING, 1);
        if (test != 10) {
            VmString *value = vm_string_new(&vm.heap, "kept", 4);
            ASSERT(vm_array_push(&vm.heap, array, val_string(value)), "I initialize a read payload");
            vm_release(&vm.heap, val_string(value));
        }
        NanoValue index = val_int(0);
        if (test == 1) index = val_bool(false);
        if (test == 2 || test == 11) index = val_string(vm_string_new(&vm.heap, "index", 5));
        if (test == 3) index = val_void();
        if (test == 4) index = val_float(0.0);
        if (test == 5) index = val_int(-1);
        if (test == 6) index = val_int(1);
        if (test == 7) index = val_int(INT64_C(4294967296));
        if (test == 8) index = val_int(INT64_MAX);
        if (test == 9) index = val_int(INT64_MIN);
        if (test == 12) index = val_array(vm_array_new(&vm.heap, TAG_INT, 0));
        NanoValue receiver = test == 11 ? val_string(vm_string_new(&vm.heap, "receiver", 8)) : val_array(array);
        NanoValue args[] = {receiver, index};
        NanoValue result = val_void();
        bool bad_tag = (test >= 1 && test <= 4) || test >= 11;
        ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &result), bad_tag ? VM_ERR_TYPE_ERROR : VM_OK,
                      "I reject invalid read tags and preserve missing integer reads as void");
        ASSERT_EQ_INT(vm.stack_size, 0, "I restore the read operand stack");
        ASSERT_EQ_INT(vm.frame_count, 0, "I restore read call frames");
        ASSERT_EQ_INT(result.tag, test == 0 ? TAG_STRING : TAG_VOID,
                      "I retain valid values without narrowing a missing index into range");
        if (test == 0) ASSERT_EQ_STR(result.as.string->data, "kept", "I retain the read payload");
        vm_release(&vm.heap, result);
        ASSERT_EQ_INT(array->header.ref_count, 1, "I release the consumed array reference after reads");
        if (index.tag == TAG_STRING)
            ASSERT_EQ_INT(index.as.string->header.ref_count, 1, "I release a rejected string index");
        if (index.tag == TAG_ARRAY)
            ASSERT_EQ_INT(index.as.array->header.ref_count, 1, "I release a rejected array index");
        vm_release(&vm.heap, index);
        if (test == 11) vm_release(&vm.heap, receiver);
        vm_release(&vm.heap, val_array(array));
        vm_gc_collect_cycles(&vm.heap);
        ASSERT_EQ_INT(vm.heap.stats.num_objects, before, "I retain no heap objects after read cleanup");
    }
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_array_update_index_contract(void) {
    uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0,
                      OP_LOAD_LOCAL, 2, 0, OP_ARR_SET, OP_RET};
    NvmModule *mod = make_module(code, sizeof code, 3, 3);
    mod->functions[0].result_tag = TAG_ARRAY;
    VmState vm;
    vm_init(&vm, mod);
    for (unsigned test = 0; test < 10; ++test) {
        size_t before = vm.heap.stats.num_objects;
        VmString *old = vm_string_new(&vm.heap, "old", 3);
        VmString *replacement = vm_string_new(&vm.heap, "new", 3);
        VmArray *array = vm_array_new(&vm.heap, TAG_STRING, 1);
        ASSERT(vm_array_push(&vm.heap, array, val_string(old)), "I initialize the aliased array");
        vm_release(&vm.heap, val_string(old));
        NanoValue index = val_int(0);
        if (test == 1) index = val_bool(false);
        if (test == 2 || test == 9) index = val_string(vm_string_new(&vm.heap, "index", 5));
        if (test == 3) index = val_void();
        if (test == 4) index = val_float(0.0);
        if (test == 5) index = val_int(-1);
        if (test == 6) index = val_int(1);
        if (test == 7) index = val_int(INT64_C(4294967296));
        if (test == 8) index = val_int(INT64_MAX);
        NanoValue receiver = test == 9 ? val_string(vm_string_new(&vm.heap, "receiver", 8)) : val_array(array);
        NanoValue args[] = {receiver, index, val_string(replacement)};
        NanoValue result = val_void();
        VmResult expected = test == 0 ? VM_OK : test >= 5 && test <= 8 ? VM_ERR_OUT_OF_BOUNDS : VM_ERR_TYPE_ERROR;
        ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 3, &result), expected,
                      "I reject wrong index tags and full-width bounds before mutation");
        ASSERT_EQ_INT(vm.stack_size, 0, "I restore the operand stack after an array update");
        ASSERT_EQ_INT(vm.frame_count, 0, "I restore call frames after an array update");
        ASSERT_EQ_STR(vm_array_get(array, 0).as.string->data, test == 0 ? "new" : "old",
                      "I preserve aliases and leave rejected updates unchanged");
        vm_release(&vm.heap, result);
        ASSERT_EQ_INT(array->header.ref_count, 1, "I release the consumed array reference");
        ASSERT_EQ_INT(replacement->header.ref_count, test == 0 ? 2 : 1,
                      "I transfer successful payloads and release rejected payload references");
        if (index.tag == TAG_STRING)
            ASSERT_EQ_INT(index.as.string->header.ref_count, 1, "I release rejected heap index references");
        vm_release(&vm.heap, index);
        if (test == 9) vm_release(&vm.heap, receiver);
        vm_release(&vm.heap, val_array(array));
        vm_release(&vm.heap, val_string(replacement));
        vm_gc_collect_cycles(&vm.heap);
        ASSERT_EQ_INT(vm.heap.stats.num_objects, before, "I retain no heap objects after update cleanup");
    }
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_array_arithmetic_values(void) {
    const NanoOpcode ops[] = {OP_ADD, OP_SUB, OP_MUL, OP_DIV,
                             OP_ARRAY_ADD, OP_ARRAY_SUB, OP_ARRAY_MUL, OP_ARRAY_DIV};
    for (unsigned op = 0; op < 8; op++) {
        for (unsigned shape = 0; shape < 3; shape++) {
            for (unsigned kind = 0; kind < 5; kind++) {
                uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0,
                                  (uint8_t)ops[op], OP_RET};
                NvmModule *mod = make_module(code, sizeof(code), 2, 2);
                mod->functions[0].result_tag = TAG_ARRAY;
                VmState vm;
                vm_init(&vm, mod);
                uint64_t baseline = vm.heap.stats.num_objects;
                /* int/int, float/float, int/float, float/int, boxed mixed. */
                NanoValue x = (kind == 1 || kind == 3) ? val_float(7.5) : val_int(7);
                NanoValue y = (kind == 1 || kind == 2) ? val_float(2.5) : val_int(2);
                VmArray *left = vm_array_new(&vm.heap, kind == 4 ? TAG_VOID : x.tag, 2);
                VmArray *right = vm_array_new(&vm.heap, kind == 4 ? TAG_VOID : y.tag, 2);
                ASSERT(vm_array_push(&vm.heap, left, x), "left element");
                ASSERT(vm_array_push(&vm.heap, right, y), "right element");
                ASSERT(vm_array_push(&vm.heap, left, kind == 4 ? val_float(7.5) : x), "left second");
                ASSERT(vm_array_push(&vm.heap, right, kind == 4 ? val_float(2.5) : y), "right second");
                NanoValue args[] = {shape == 2 ? x : val_array(left),
                                    shape == 1 ? y : val_array(right)};
                NanoValue output = val_void();
                ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_OK, "vector invocation");
                ASSERT_EQ_INT(output.tag, TAG_ARRAY, "array result");
                ASSERT_EQ_INT(output.as.array->length, 2, "vector result length");
                ASSERT_EQ_INT(output.as.array->elem_type,
                              kind == 4 ? TAG_VOID : kind == 0 ? TAG_INT : TAG_FLOAT,
                              "result storage type");
                for (unsigned i = 0; i < 2; i++) {
                    bool floating = kind != 0 && (kind != 4 || i == 1);
                    double a = kind == 4 && i == 1 && shape != 2 ? 7.5 :
                               x.tag == TAG_FLOAT ? x.as.f64 : (double)x.as.i64;
                    double b = kind == 4 && i == 1 && shape != 1 ? 2.5 :
                               y.tag == TAG_FLOAT ? y.as.f64 : (double)y.as.i64;
                    double expected = op % 4 == 0 ? a + b : op % 4 == 1 ? a - b :
                                      op % 4 == 2 ? a * b : a / b;
                    NanoValue actual = vm_array_get(output.as.array, i);
                    ASSERT_EQ_INT(actual.tag, floating ? TAG_FLOAT : TAG_INT, "element tag");
                    if (floating) ASSERT_EQ_F64(actual.as.f64, expected, "fractional result");
                    else ASSERT_EQ_INT(actual.as.i64, (int64_t)expected, "integer result");
                }
                vm_release(&vm.heap, output);
                vm_release(&vm.heap, val_array(left));
                vm_release(&vm.heap, val_array(right));
                vm_gc_collect_cycles(&vm.heap);
                ASSERT_EQ_INT(vm.heap.stats.num_objects, baseline, "numeric cleanup");
                vm_destroy(&vm);
                nvm_module_free(mod);
            }
        }
    }
}

static void test_array_arithmetic_boundaries(void) {
    const NanoOpcode ops[] = {OP_ADD, OP_SUB, OP_MUL, OP_DIV,
                             OP_ARRAY_ADD, OP_ARRAY_SUB, OP_ARRAY_MUL, OP_ARRAY_DIV};
    const int64_t pairs[][2] = {{INT64_MAX, 1}, {INT64_MIN, -1}, {9, 0}};
    const int64_t expected[][4] = {
        {INT64_MIN, INT64_MAX - 1, INT64_MAX, INT64_MAX},
        {INT64_MAX, INT64_MIN + 1, INT64_MIN, INT64_MIN},
        {9, 9, 0, 0}
    };
    for (unsigned op = 0; op < 8; op++) {
        for (unsigned shape = 0; shape < 3; shape++) {
            for (unsigned pair = 0; pair < 3; pair++) {
                uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0,
                                  (uint8_t)ops[op], OP_RET};
                NvmModule *mod = make_module(code, sizeof(code), 2, 2);
                mod->functions[0].result_tag = TAG_ARRAY;
                VmState vm;
                vm_init(&vm, mod);
                uint64_t baseline = vm.heap.stats.num_objects;
                NanoValue x = val_int(pairs[pair][0]), y = val_int(pairs[pair][1]);
                VmArray *left = vm_array_new(&vm.heap, TAG_INT, 2);
                VmArray *right = vm_array_new(&vm.heap, TAG_INT, 1);
                ASSERT(vm_array_push(&vm.heap, left, x), "boundary left");
                ASSERT(vm_array_push(&vm.heap, right, y), "boundary right");
                /* The shorter-array rule must not inspect an unused tail. */
                if (shape == 0) ASSERT(vm_array_push(&vm.heap, left, x), "longer left");
                NanoValue args[] = {shape == 2 ? x : val_array(left),
                                    shape == 1 ? y : val_array(right)};
                NanoValue output = val_void();
                ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_OK, "boundary invocation");
                ASSERT_EQ_INT(output.as.array->length, 1, "shorter length");
                ASSERT_EQ_INT(vm_array_get(output.as.array, 0).as.i64,
                              expected[pair][op % 4], "wrapping and total integer arithmetic");
                vm_release(&vm.heap, output);
                left->length = right->length = 0; /* Packed integers own no references. */
                ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_OK, "empty invocation");
                ASSERT_EQ_INT(output.as.array->length, 0, "empty result");
                ASSERT_EQ_INT(output.as.array->elem_type, TAG_INT, "empty type preserved");
                vm_release(&vm.heap, output);
                vm_release(&vm.heap, val_array(left));
                vm_release(&vm.heap, val_array(right));
                vm_gc_collect_cycles(&vm.heap);
                ASSERT_EQ_INT(vm.heap.stats.num_objects, baseline, "boundary cleanup");
                vm_destroy(&vm);
                nvm_module_free(mod);
            }
        }
    }
}

static void test_array_arithmetic_strings(void) {
    for (unsigned dedicated = 0; dedicated < 2; dedicated++) {
        for (unsigned shape = 0; shape < 3; shape++) {
            uint8_t code[] = {OP_LOAD_LOCAL, 0, 0, OP_LOAD_LOCAL, 1, 0,
                              dedicated ? OP_ARRAY_ADD : OP_ADD, OP_RET};
            NvmModule *mod = make_module(code, sizeof(code), 2, 2);
            mod->functions[0].result_tag = TAG_ARRAY;
            VmState vm;
            vm_init(&vm, mod);
            uint64_t baseline = vm.heap.stats.num_objects;
            NanoValue x = val_string(vm_string_new(&vm.heap, "left", 4));
            NanoValue y = val_string(vm_string_new(&vm.heap, "right", 5));
            VmArray *left = vm_array_new(&vm.heap, TAG_STRING, 1);
            VmArray *right = vm_array_new(&vm.heap, TAG_STRING, 1);
            ASSERT(vm_array_push(&vm.heap, left, x), "left string");
            ASSERT(vm_array_push(&vm.heap, right, y), "right string");
            NanoValue args[] = {shape == 2 ? x : val_array(left),
                                shape == 1 ? y : val_array(right)};
            NanoValue output = val_void();
            ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_OK, "string vector");
            ASSERT_EQ_INT(output.as.array->elem_type, TAG_STRING, "boxed string type");
            NanoValue element = vm_array_get(output.as.array, 0);
            ASSERT_EQ_INT(element.tag, TAG_STRING, "string element tag");
            ASSERT_EQ_STR(vmstring_cstr(element.as.string), "leftright", "ordered concatenation");
            ASSERT_EQ_INT(element.as.string->header.ref_count, 1, "one result owner");
            vm_release(&vm.heap, output);
            /* A bad second pair must fail without converting pointer payloads. */
            ASSERT(vm_array_push(&vm.heap, left, val_bool(true)), "boxed invalid element");
            ASSERT(vm_array_push(&vm.heap, right, y), "second right string");
            args[0] = val_array(left);
            ASSERT_EQ_INT(vm_invoke(&vm, 0, args, 2, &output), VM_ERR_TYPE_ERROR,
                          "reject unsupported element pair");
            vm_release(&vm.heap, x);
            vm_release(&vm.heap, y);
            vm_release(&vm.heap, val_array(left));
            vm_release(&vm.heap, val_array(right));
            vm_gc_collect_cycles(&vm.heap);
            ASSERT_EQ_INT(vm.heap.stats.num_objects, baseline, "string cleanup");
            vm_destroy(&vm);
            nvm_module_free(mod);
        }
    }
}

static void test_add_array_scalar(void) {
    /* OP_ADD with array + scalar → broadcast add */
    uint8_t code[64];
    uint32_t off = 0;
    /* [5, 10, 15] + 1 = [6, 11, 16] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)5);
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)15);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_ADD);        /* broadcast add */
    off += emit(code + off, OP_ARR_LEN);    /* → 3 */
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add_array_scalar: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3, "add_array_scalar: result has 3 elements");
    nvm_module_free(mod);
}

/* ========================================================================
 * Cross-Module Linking Tests
 * ======================================================================== */

static void test_call_module(void) {
    /*
     * Module B has a function "add_10" that adds 10 to its argument.
     * Module A's main calls add_10(5) via OP_CALL_MODULE.
     * Expected result: 15
     */

    /* Build Module B: fn add_10(x) -> x + 10 */
    NvmModule *mod_b = nvm_module_new();
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_LOAD_LOCAL, 0);     /* load param x */
        n += emit(code + n, OP_PUSH_I64, (int64_t)10);
        n += emit(code + n, OP_ADD);
        n += emit(code + n, OP_RET);

        uint32_t name_idx = nvm_add_string(mod_b, "add_10", 6);
        uint32_t code_off = nvm_append_code(mod_b, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name_idx;
        fn.arity = 1;
        fn.code_offset = code_off;
        fn.code_length = n;
        fn.local_count = 1;
        fn.upvalue_count = 0;
        nvm_add_function(mod_b, &fn);
    }

    /* Build Module A: fn main() -> call_module(0, 0, arg=5) */
    NvmModule *mod_a = nvm_module_new();
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_PUSH_I64, (int64_t)5);  /* arg */
        n += emit(code + n, OP_CALL_MODULE, (uint32_t)0, (uint32_t)0,
                  (uint16_t)1, (uint16_t)1);  /* mod 0, fn 0, 1 arg -> 1 result */
        n += emit(code + n, OP_RET);

        uint32_t name_idx = nvm_add_string(mod_a, "main", 4);
        uint32_t code_off = nvm_append_code(mod_a, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name_idx;
        fn.arity = 0;
        fn.code_offset = code_off;
        fn.code_length = n;
        fn.local_count = 0;
        fn.upvalue_count = 0;
        uint32_t fn_idx = nvm_add_function(mod_a, &fn);
        mod_a->header.flags = NVM_FLAG_HAS_MAIN;
        mod_a->header.entry_point = fn_idx;
    }

    /* Link and execute */
    VmState vm;
    vm_init(&vm, mod_a);
    uint32_t link_idx = vm_link_module(&vm, mod_b);
    ASSERT_EQ_INT(link_idx, 0, "call_module: link idx == 0");

    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "call_module: VM_OK");

    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.as.i64, 15, "call_module: 5 + 10 == 15");

    vm_destroy(&vm);
    nvm_module_free(mod_a);
    nvm_module_free(mod_b);
}

static void test_call_module_string_constant(void) {
    NvmModule *mod_b = nvm_module_new();
    uint32_t literal_idx = nvm_add_string(mod_b, "linked literal", 14);
    uint8_t linked_code[16];
    uint32_t linked_len = 0;
    linked_len += emit(linked_code + linked_len, OP_PUSH_STR, literal_idx);
    linked_len += emit(linked_code + linked_len, OP_RET);
    uint32_t linked_fn = add_fn(mod_b, "literal", linked_code, linked_len, 0, 0);

    NvmModule *mod_a = nvm_module_new();
    uint8_t root_code[16];
    uint32_t root_len = 0;
    root_len += emit(root_code + root_len, OP_CALL_MODULE, (uint32_t)0, linked_fn,
                     (uint16_t)0, (uint16_t)1);
    root_len += emit(root_code + root_len, OP_RET);
    uint32_t root_fn = add_fn(mod_a, "main", root_code, root_len, 0, 0);

    VmState vm;
    vm_init(&vm, mod_a);
    ASSERT_EQ_INT(vm_link_module(&vm, mod_b), 0,
                  "linked string module is instantiated");
    uint64_t allocations = vm.heap.stats.allocation_calls;
    VmString *constant = vm.linked_module_constants[0].strings[literal_idx];
    for (uint32_t i = 0; i < 3; i++) {
        NanoValue result = val_void();
        ASSERT_EQ_INT(vm_invoke(&vm, root_fn, NULL, 0, &result), VM_OK,
                      "linked string function executes");
        ASSERT(result.as.string == constant,
               "linked execution selects the linked module constant");
        vm_release(&vm.heap, result);
    }
    ASSERT_EQ_INT(vm.heap.stats.allocation_calls, allocations,
                  "linked string execution performs no allocations");

    vm_destroy(&vm);
    nvm_module_free(mod_a);
    nvm_module_free(mod_b);
}

static void test_call_module_bad_idx(void) {
    /* Test error on invalid module index */
    NvmModule *mod = nvm_module_new();
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_CALL_MODULE, (uint32_t)99, (uint32_t)0,
                  (uint16_t)0, (uint16_t)0);
        n += emit(code + n, OP_RET);

        uint32_t name_idx = nvm_add_string(mod, "main", 4);
        uint32_t code_off = nvm_append_code(mod, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name_idx;
        fn.arity = 0;
        fn.code_offset = code_off;
        fn.code_length = n;
        fn.local_count = 0;
        fn.upvalue_count = 0;
        uint32_t fn_idx = nvm_add_function(mod, &fn);
        mod->header.flags = NVM_FLAG_HAS_MAIN;
        mod->header.entry_point = fn_idx;
    }

    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT(r != VM_OK, "call_module_bad: should fail on invalid module idx");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_call_module_chain(void) {
    /*
     * Module C: fn double(x) -> x * 2
     * Module B: fn add_then_double(x) -> call_module(C, double, x + 1)
     * Module A: fn main() -> call_module(B, add_then_double, 4)
     * Expected: double(4 + 1) = 10
     *
     * But this requires module B to also link module C. For simplicity,
     * test a two-module chain: A calls B which calls a local function.
     */

    /* Module B: fn calc(x) -> (x + 3) * 2
     * Uses two local functions: add3 and double_it */
    NvmModule *mod_b = nvm_module_new();
    {
        /* fn add3(x) -> x + 3 */
        uint8_t code1[64];
        uint32_t n1 = 0;
        n1 += emit(code1 + n1, OP_LOAD_LOCAL, 0);
        n1 += emit(code1 + n1, OP_PUSH_I64, (int64_t)3);
        n1 += emit(code1 + n1, OP_ADD);
        n1 += emit(code1 + n1, OP_RET);

        uint32_t name1 = nvm_add_string(mod_b, "add3", 4);
        uint32_t off1 = nvm_append_code(mod_b, code1, n1);
        NvmFunctionEntry fn1 = { .result_tag = TAG_INT, .result_count = 1 };
        fn1.name_idx = name1;
        fn1.arity = 1;
        fn1.code_offset = off1;
        fn1.code_length = n1;
        fn1.local_count = 1;
        nvm_add_function(mod_b, &fn1);

        /* fn calc(x) -> call add3(x), then * 2 */
        uint8_t code2[64];
        uint32_t n2 = 0;
        n2 += emit(code2 + n2, OP_LOAD_LOCAL, 0);
        n2 += emit(code2 + n2, OP_CALL, (uint32_t)0);  /* call add3 */
        n2 += emit(code2 + n2, OP_PUSH_I64, (int64_t)2);
        n2 += emit(code2 + n2, OP_MUL);
        n2 += emit(code2 + n2, OP_RET);

        uint32_t name2 = nvm_add_string(mod_b, "calc", 4);
        uint32_t off2 = nvm_append_code(mod_b, code2, n2);
        NvmFunctionEntry fn2 = { .result_tag = TAG_INT, .result_count = 1 };
        fn2.name_idx = name2;
        fn2.arity = 1;
        fn2.code_offset = off2;
        fn2.code_length = n2;
        fn2.local_count = 1;
        nvm_add_function(mod_b, &fn2);
    }

    /* Module A: fn main() -> call_module(0, 1, 4)  (mod B, fn "calc", arg 4) */
    NvmModule *mod_a = nvm_module_new();
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_PUSH_I64, (int64_t)4);
        n += emit(code + n, OP_CALL_MODULE, (uint32_t)0, (uint32_t)1,
                  (uint16_t)1, (uint16_t)1);
        n += emit(code + n, OP_RET);

        uint32_t name = nvm_add_string(mod_a, "main", 4);
        uint32_t off = nvm_append_code(mod_a, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name;
        fn.arity = 0;
        fn.code_offset = off;
        fn.code_length = n;
        fn.local_count = 0;
        uint32_t fn_idx = nvm_add_function(mod_a, &fn);
        mod_a->header.flags = NVM_FLAG_HAS_MAIN;
        mod_a->header.entry_point = fn_idx;
    }

    VmState vm;
    vm_init(&vm, mod_a);
    vm_link_module(&vm, mod_b);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "call_module_chain: VM_OK");

    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.as.i64, 14, "call_module_chain: (4+3)*2 == 14");

    vm_destroy(&vm);
    nvm_module_free(mod_a);
    nvm_module_free(mod_b);
}

static void test_call_module_handle_resolution(void) {
    /*
     * Cross-module calls are resolved to callable handles during linking
     * rather than carrying a (module index, function index) pair through
     * dispatch. Verify vm_resolve_module_calls binds the handle to the
     * target module/function, that re-linking re-resolves, and that an
     * out-of-range pair leaves the handle unresolved.
     */

    /* Module B: fn add_10(x) -> x + 10 */
    NvmModule *mod_b = nvm_module_new();
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_LOAD_LOCAL, 0);
        n += emit(code + n, OP_PUSH_I64, (int64_t)10);
        n += emit(code + n, OP_ADD);
        n += emit(code + n, OP_RET);

        uint32_t name_idx = nvm_add_string(mod_b, "add_10", 6);
        uint32_t code_off = nvm_append_code(mod_b, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name_idx;
        fn.arity = 1;
        fn.code_offset = code_off;
        fn.code_length = n;
        fn.local_count = 1;
        nvm_add_function(mod_b, &fn);
    }

    /* Module A: fn main() -> call_module(0, 0, arg=5) */
    NvmModule *mod_a = nvm_module_new();
    uint32_t call_off = 0;
    {
        uint8_t code[64];
        uint32_t n = 0;
        n += emit(code + n, OP_PUSH_I64, (int64_t)5);
        call_off = n;
        n += emit(code + n, OP_CALL_MODULE, (uint32_t)0, (uint32_t)0,
                  (uint16_t)1, (uint16_t)1);
        n += emit(code + n, OP_RET);

        uint32_t name_idx = nvm_add_string(mod_a, "main", 4);
        uint32_t code_off = nvm_append_code(mod_a, code, n);
        NvmFunctionEntry fn = { .result_tag = TAG_INT, .result_count = 1 };
        fn.name_idx = name_idx;
        fn.arity = 0;
        fn.code_offset = code_off;
        fn.code_length = n;
        fn.local_count = 0;
        uint32_t fn_idx = nvm_add_function(mod_a, &fn);
        mod_a->header.flags = NVM_FLAG_HAS_MAIN;
        mod_a->header.entry_point = fn_idx;
    }

    VmState vm;
    vm_init(&vm, mod_a);

    /* Before linking, resolution leaves the handle unbound. */
    ASSERT(vm_resolve_module_calls(&vm), "handle: resolve before link ok");
    const VmDecodedInstruction *ins =
        vm_decoded_function_at(&vm.decoded_module.functions[0], call_off);
    ASSERT(ins != NULL, "handle: found CALL_MODULE instruction");
    ASSERT_EQ_INT(ins->instruction.opcode, OP_CALL_MODULE, "handle: opcode is CALL_MODULE");
    ASSERT(!ins->call_handle.resolved, "handle: unresolved before link");

    /* Linking must invalidate the prior (empty) resolution. */
    uint32_t link_idx = vm_link_module(&vm, mod_b);
    ASSERT_EQ_INT(link_idx, 0, "handle: link idx == 0");
    ASSERT(!vm.module_calls_resolved, "handle: linking clears resolved flag");

    ASSERT(vm_resolve_module_calls(&vm), "handle: resolve after link ok");
    ASSERT(vm.module_calls_resolved, "handle: resolved flag set");

    ins = vm_decoded_function_at(&vm.decoded_module.functions[0], call_off);
    ASSERT(ins != NULL, "handle: re-find CALL_MODULE instruction");
    ASSERT(ins->call_handle.resolved, "handle: resolved after link");
    ASSERT(ins->call_handle.module == mod_b, "handle: bound to target module B");
    ASSERT_EQ_INT(ins->call_handle.function_index, 0, "handle: bound to function 0");
    ASSERT(ins->call_handle.function == &mod_b->functions[0],
           "handle: bound to function entry");

    /* Executing through the resolved handle still yields 5 + 10 == 15. */
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "handle: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.as.i64, 15, "handle: 5 + 10 == 15");

    vm_destroy(&vm);
    nvm_module_free(mod_a);
    nvm_module_free(mod_b);
}

typedef struct {
    VmState *vm;
    NanoCallbackV1 *handle;
    NvmCallbackContract contract;
    NanoValue callable;
    bool ok;
    bool allow_cancellation;
    unsigned cancelled;
} CallbackWorker;

static void *invoke_vm_callback_worker(void *opaque) {
    CallbackWorker *worker = opaque;
    worker->ok = !vm_callback_create(worker->vm, worker->callable, &worker->contract) &&
        vm_callback_pump(worker->vm, false) == -1 &&
        vm_callback_shutdown(worker->vm) == NANO_CALLBACK_WRONG_THREAD;
    for (int i = 0; i < 256; i++) {
        NanoCallbackValue arg = {.tag = NANO_CALLBACK_INT, .as.integer = i}, result;
        NanoCallbackStatus status = worker->handle->invoke(worker->handle, &arg, 1, &result);
        if (worker->allow_cancellation && status == NANO_CALLBACK_CANCELLED) {
            worker->cancelled++;
            worker->ok = worker->ok && result.tag == NANO_CALLBACK_VOID;
            continue;
        }
        worker->ok = worker->ok && status == NANO_CALLBACK_OK &&
            result.tag == NANO_CALLBACK_INT && result.as.integer == i + 40;
    }
    worker->handle->release(worker->handle);
    return NULL;
}

static void test_vm_retained_callbacks(void) {
    AsmResult assembled;
    NvmModule *module = asm_assemble(
        ".function callback 1 1 1 int 1\n"
        "LOAD_UPVALUE 0 0\nPUSH_I64 0\nARR_GET\nLOAD_LOCAL 0\nADD\n"
        "DUP\nSTORE_GLOBAL 0\nRET\n.end\n.parameters 0 int\n"
        ".function fail 1 1 0 int 1\nPUSH_BOOL 0\nASSERT\nLOAD_LOCAL 0\nRET\n.end\n.parameters 1 int\n",
        &assembled);
    ASSERT(module, "I assemble typed retained-callback targets");
    VmState vm;
    vm_init(&vm, module);
    VmArray *capture = vm_array_new(&vm.heap, TAG_INT, 1);
    ASSERT(capture && vm_array_push(&vm.heap, capture, val_int(40)), "I allocate a captured array");
    VmClosure *closure = vm_closure_new(&vm.heap, 0, 1);
    ASSERT(closure, "I allocate a callback closure");
    closure->captures[0] = val_array(capture);
    NanoValue callable = val_closure(closure);
    NvmCallbackContract contract = {.abi_version = NVM_CALLBACK_ABI_RETAINED_V1,
        .parameter_idx = 0, .execution = NVM_FOREIGN_WORKER_THREAD,
        .param_count = 1, .param_tags = {TAG_INT}, .return_tag = TAG_INT};
    module->function_param_types[0][0] = TAG_VOID;
    ASSERT(!vm_callback_create(&vm, callable, &contract), "I reject unknown callable signatures");
    module->function_param_types[0][0] = TAG_FLOAT;
    ASSERT(!vm_callback_create(&vm, callable, &contract), "I reject mismatched callable signatures");
    module->function_param_types[0][0] = TAG_INT;
    vm.isolate_ffi = true;
    ASSERT(!vm_callback_create(&vm, callable, &contract), "I do not publish native pointers for isolated FFI");
    vm.isolate_ffi = false;
    NanoCallbackV1 *handle = vm_callback_create(&vm, callable, &contract);
    ASSERT(handle && closure->header.ref_count == 2, "I root the callable before native publication");
    vm_release(&vm.heap, callable);
    vm_gc_collect_cycles(&vm.heap);
    ASSERT_EQ_INT(closure->header.ref_count, 1, "I keep the native-owned closure live across collection");
    CallbackWorker worker = {.vm = &vm, .handle = handle, .contract = contract, .callable = callable};
    pthread_t thread;
    handle->retain(handle);
    alarm(20);
    ASSERT_EQ_INT(pthread_create(&thread, NULL, invoke_vm_callback_worker, &worker), 0,
                  "I start a foreign callback producer");
    for (int i = 0; i < 256;) if (vm_callback_pump(&vm, true) == 1) i++;
    ASSERT_EQ_INT(pthread_join(thread, NULL), 0, "I join the foreign producer");
    alarm(0);
    ASSERT(worker.ok, "I execute foreign-thread requests only through the owner");
    ASSERT_EQ_INT(vm.globals[0].as.i64, 295, "I preserve shared globals and captured arrays");
    VmState failed_vm;
    vm_init(&failed_vm, module);
    NanoCallbackV1 *bad = vm_callback_create(&failed_vm, val_function(1), &contract);
    ASSERT(bad, "I publish a typed callback that can fail during execution");
    NanoCallbackValue arg = {.tag = NANO_CALLBACK_INT, .as.integer = 1}, result;
    ASSERT_EQ_INT(bad->invoke(bad, &arg, 1, &result), NANO_CALLBACK_EXECUTION_ERROR,
                  "I report a VM assertion failure through the retained ABI");
    ASSERT(failed_vm.callback_error == VM_ERR_ASSERT_FAILED && result.tag == NANO_CALLBACK_VOID,
           "I retain callback failure evidence and clear the native result");
    bad->release(bad);
    vm_destroy(&failed_vm);
    worker.allow_cancellation = true;
    handle->retain(handle);
    alarm(20);
    ASSERT_EQ_INT(pthread_create(&thread, NULL, invoke_vm_callback_worker, &worker), 0,
                  "I start a producer that remains live through VM shutdown");
    for (int i = 0; i < 128;) if (vm_callback_pump(&vm, true) == 1) i++;
    vm_destroy(&vm);
    ASSERT_EQ_INT(pthread_join(thread, NULL), 0, "I join the producer after VM shutdown");
    alarm(0);
    ASSERT(worker.ok && worker.cancelled == 128, "I cancel remaining requests without touching the destroyed heap");
    ASSERT(!vm_callback_create(&vm, val_function(1), &contract), "I do not reopen a destroyed callback host");
    ASSERT_EQ_INT(handle->invoke(handle, &arg, 1, &result), NANO_CALLBACK_CANCELLED,
                  "I cancel late native calls after VM and capture destruction");
    handle->release(handle);
    nvm_module_free(module);
}

static void test_suspended_callable_activation(void) {
    for (unsigned depth = 1; depth <= 2; depth++) {
        for (unsigned failure = 0; failure < 3; failure++) {
            AsmResult assembled;
            NvmModule *root = asm_assemble(
                ".function paused 0 1 0 int 1\nPUSH_I64 999\nPRINT\nLOAD_GLOBAL 0\nRET\n.end\n", &assembled);
            ASSERT(root, "I assemble a caller that pauses at a real print trap");
            const char *body = failure == 1 ? "PUSH_BOOL 0\nASSERT\nLOAD_LOCAL 0\nRET\n" :
                failure == 2 ? "PUSH_I64 42\nHALT\n" :
                "LOAD_UPVALUE 0 0\nLOAD_LOCAL 0\nADD\nDUP\nSTORE_GLOBAL 0\nRET\n";
            char source[512];
            snprintf(source, sizeof(source), ".function callback 1 2 1 int 1\n%s.end\n", body);
            NvmModule *target = asm_assemble(source, &assembled);
            ASSERT(target, "I assemble a capturing callback target");
            VmState vm;
            vm_init(&vm, root);
            ASSERT_EQ_INT(vm_link_module(&vm, target), 0, "I link a callback owner");
            ASSERT(vm_ensure_globals(&vm, 1), "I reserve shared callback globals");
            vm.globals[0] = val_int(7);
            vm.global_count = 1;
            VmString *guard = vm_string_new(&vm.heap, "caller root", 11);
            VmClosure *closure = vm_closure_new(&vm.heap, 0, 1);
            ASSERT(guard && closure, "I allocate caller and callback roots");
            closure->callable_module = 2;
            closure->captures[0] = val_int(40);
            vm.stack[vm.stack_size++] = val_string(guard);
            vm.frame_count = depth;
            vm.activation_floor = depth - 1;
            for (unsigned i = 0; i < depth; i++) vm.frames[i].module = root;
            vm.frames[depth - 1].local_count = 1;
            VmTrap paused = vm_core_execute(&vm);
            ASSERT_EQ_INT(paused.type, TRAP_PRINT, "I reach the suspended host boundary");
            vm_release(&vm.heap, paused.data.print.value);
            uint32_t saved_ip = vm.ip;
            VmCallFrame saved_frames[2];
            memcpy(saved_frames, vm.frames, depth * sizeof(VmCallFrame));
            vm.halt_requested = true;
            NanoValue argument = val_int(1), returned = val_void();
            VmResult status = vm_invoke_callable(&vm, val_closure(closure), &argument, 1, &returned);
            ASSERT_EQ_INT(status, failure == 1 ? VM_ERR_ASSERT_FAILED : failure == 2 ? VM_ERR_TYPE_ERROR : VM_OK,
                          "I distinguish normal return, assertion failure, and halt");
            ASSERT(vm.module == root && vm.ip == saved_ip && vm.current_fn == 0 &&
                   vm.frame_count == depth && vm.activation_floor == depth - 1 && vm.halt_requested,
                   "I restore suspended execution state");
            ASSERT(!memcmp(saved_frames, vm.frames, depth * sizeof(VmCallFrame)),
                   "I do not rewrite suspended frames");
            ASSERT(vm.stack_size == 1 && vm.stack[0].as.string == guard && guard->header.ref_count == 1,
                   "I preserve caller stack roots");
            ASSERT_EQ_INT(closure->header.ref_count, 1, "I release the activation's callable reference");
            if (!failure) ASSERT(returned.tag == TAG_INT && returned.as.i64 == 41,
                                 "I execute captures against shared globals");
            vm_release(&vm.heap, returned);
            vm_release(&vm.heap, val_closure(closure));
            vm.halt_requested = false;
            VmTrap resumed = vm_core_execute(&vm);
            ASSERT_EQ_INT(resumed.type, TRAP_NONE, "I resume the original caller after callback completion");
            ASSERT_EQ_INT(vm.frame_count, depth - 1, "I stop at the enclosing activation floor");
            ASSERT_EQ_INT(vm_get_result(&vm).as.i64, failure ? 7 : 41,
                          "I preserve shared state and the caller's return value");
            vm_destroy(&vm);
            nvm_module_free(root);
            nvm_module_free(target);
        }
    }
}

static void test_linked_callable_identity(void) {
    const char *root_source =
        ".module_ref \"one\"\n.module_ref \"two\"\n.entry 0\n"
        ".function main 0 2 0 int 1\n"
        "CALL_MODULE 0 0 0 1\nSTORE_LOCAL 0\n"
        "CALL_MODULE 1 0 0 1\nSTORE_LOCAL 1\n"
        "LOAD_LOCAL 0\nLOAD_LOCAL 1\nEQ\nNOT\nASSERT\n"
        "PUSH_I64 1\nLOAD_LOCAL 0\nCALL_INDIRECT 1 1\n"
        "PUSH_I64 1\nLOAD_LOCAL 1\nCALL_INDIRECT 1 1\nADD\n"
        "PUSH_I64 1\nFUNCREF 1\nCALL_MODULE 0 2 2 1\nADD\nRET\n.end\n"
        ".function root_target 1 1 0 int 1\nLOAD_LOCAL 0\nPUSH_I64 1000\nADD\nRET\n.end\n"
        ".function call 2 2 0 int 1\nLOAD_LOCAL 0\nLOAD_LOCAL 1\nCALL_INDIRECT 1 1\nRET\n.end\n";
    for (int closure = 0; closure < 2; closure++) {
        AsmResult assembled;
        NvmModule *root = asm_assemble(root_source, &assembled);
        ASSERT(root, "I assemble the linked callable consumer");
        NvmModule *libraries[2];
        for (int i = 0; i < 2; i++) {
            char source[1024], factory[128], target[128];
            if (closure) {
                snprintf(factory, sizeof(factory), "PUSH_I64 %d\nCLOSURE_NEW 1 1\n", 40 * (i + 1));
                snprintf(target, sizeof(target), "LOAD_UPVALUE 0 0\n");
            } else {
                snprintf(factory, sizeof(factory), "FUNCREF 1\n");
                snprintf(target, sizeof(target), "PUSH_I64 %d\n", 40 * (i + 1));
            }
            snprintf(source, sizeof(source),
                ".function factory 0 0 0 %s 1\n%sRET\n.end\n"
                ".function target 1 1 %d int 1\nLOAD_LOCAL 0\n%sADD\nRET\n.end\n"
                ".function apply 2 2 0 int 1\nLOAD_LOCAL 0\nLOAD_LOCAL 1\nCALL_INDIRECT 1 1\nRET\n.end\n",
                closure ? "closure" : "function", factory, closure, target);
            libraries[i] = asm_assemble(source, &assembled);
            if (!libraries[i]) fprintf(stderr, "%s\n%s\n", source, assembled.message);
            ASSERT(libraries[i], "I assemble the linked callable producer");
        }
        VmState vm;
        vm_init(&vm, root);
        ASSERT_EQ_INT(vm_link_named_module(&vm, "one", libraries[0]), 0, "I link the first producer");
        ASSERT_EQ_INT(vm_link_named_module(&vm, "two", libraries[1]), 1, "I link the second producer");
        ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "I invoke returned and forwarded cross-module callables");
        ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 1123, "I use all three distinct function-one targets");
        const NvmModule *owner = NULL;
        uint32_t index = UINT32_MAX;
        NanoValue first = val_function_owned(1, 2), second = val_function_owned(1, 3);
        ASSERT(sizeof(NanoValue) == 16, "I preserve the compact value layout");
        ASSERT(!val_equal(first, second) && val_compare(first, second) < 0,
               "I distinguish equal indices in distinct modules");
        ASSERT(vm_callable_target(&vm, first, &owner, &index) && owner == libraries[0] && index == 1,
               "I resolve the explicit callable owner");
        ASSERT(!vm_callable_target(&vm, val_function_owned(1, 0), &owner, &index),
               "I reject an unbound callable");
        ASSERT(!vm_callable_target(&vm, val_function_owned(1, UINT32_MAX), &owner, &index),
               "I reject an unknown callable owner");
        NanoValue args[] = {val_int(1), val_function_owned(1, UINT32_MAX)}, result;
        ASSERT_EQ_INT(vm_invoke(&vm, 2, args, 2, &result), VM_ERR_UNDEFINED_FUNCTION,
                      "I reject invalid identity before indirect entry");
        vm_destroy(&vm);
        nvm_module_free(root);
        nvm_module_free(libraries[0]);
        nvm_module_free(libraries[1]);
    }
}

static void test_separately_linked_module_roundtrip(void) {
    NvmModule *dependency = nvm_module_new();
    uint8_t dependency_code[32];
    uint32_t dependency_size = 0;
    dependency_size += emit(dependency_code + dependency_size, OP_LOAD_LOCAL, 0);
    dependency_size += emit(dependency_code + dependency_size, OP_PUSH_I64, (int64_t)7);
    dependency_size += emit(dependency_code + dependency_size, OP_ADD);
    dependency_size += emit(dependency_code + dependency_size, OP_RET);
    NvmFunctionEntry add_seven = { .result_tag = TAG_INT, .result_count = 1 };
    add_seven.name_idx = nvm_add_string(dependency, "add_seven", 9);
    add_seven.arity = 1;
    add_seven.local_count = 1;
    add_seven.code_offset = nvm_append_code(dependency, dependency_code,
                                             dependency_size);
    add_seven.code_length = dependency_size;
    nvm_add_function(dependency, &add_seven);

    NvmModule *root = nvm_module_new();
    uint32_t dependency_name = nvm_add_string(root, "math", 4);
    ASSERT_EQ_INT(nvm_add_module_ref(root, dependency_name), 0,
                  "separate link: dependency occupies module index 0");
    uint8_t root_code[32];
    uint32_t root_size = 0;
    root_size += emit(root_code + root_size, OP_PUSH_I64, (int64_t)5);
    root_size += emit(root_code + root_size, OP_CALL_MODULE, (uint32_t)0,
                      (uint32_t)0, (uint16_t)1, (uint16_t)1);
    root_size += emit(root_code + root_size, OP_RET);
    NvmFunctionEntry main_fn = { .result_tag = TAG_INT, .result_count = 1 };
    main_fn.name_idx = nvm_add_string(root, "main", 4);
    main_fn.code_offset = nvm_append_code(root, root_code, root_size);
    main_fn.code_length = root_size;
    root->header.flags = NVM_FLAG_HAS_MAIN;
    root->header.entry_point = nvm_add_function(root, &main_fn);

    uint32_t root_blob_size = 0;
    uint32_t dependency_blob_size = 0;
    uint8_t *root_blob = nvm_serialize(root, &root_blob_size);
    uint8_t *dependency_blob = nvm_serialize(dependency, &dependency_blob_size);
    NvmModule *loaded_root = nvm_deserialize(root_blob, root_blob_size);
    NvmModule *loaded_dependency = nvm_deserialize(dependency_blob,
                                                    dependency_blob_size);
    ASSERT(loaded_root != NULL && loaded_dependency != NULL,
           "separate link: both module files deserialize");
    ASSERT_EQ_INT(loaded_root->module_ref_count, 1,
                  "separate link: dependency directory survives serialization");

    VmState vm;
    vm_init(&vm, loaded_root);
    ASSERT_EQ_INT(vm_link_module(&vm, loaded_dependency), (uint32_t)-1,
                  "separate link: unnamed linking cannot bypass dependencies");
    ASSERT_EQ_INT(vm_link_named_module(&vm, "wrong", loaded_dependency),
                  (uint32_t)-1, "separate link: dependency name is enforced");
    ASSERT_EQ_INT(vm_link_named_module(&vm, "math", loaded_dependency), 0,
                  "separate link: declared dependency links at index 0");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK,
                  "separate link: serialized module graph executes");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 12,
                  "separate link: cross-file call returns its result");

    vm_destroy(&vm);
    free(root_blob);
    free(dependency_blob);
    nvm_module_free(loaded_root);
    nvm_module_free(loaded_dependency);
    nvm_module_free(root);
    nvm_module_free(dependency);
}

/* ========================================================================
 * Additional coverage tests: vm_error_string, float/mixed arith,
 * OP_STR_CONCAT, and type-error paths
 * ======================================================================== */

static void test_vm_error_string(void) {
    /* Exercise all switch cases in vm_error_string (lines 29-44 in vm.c) */
    ASSERT(vm_error_string(VM_OK) != NULL, "VM_OK string");
    ASSERT(vm_error_string(VM_ERR_STACK_OVERFLOW) != NULL, "STACK_OVERFLOW string");
    ASSERT(vm_error_string(VM_ERR_STACK_UNDERFLOW) != NULL, "STACK_UNDERFLOW string");
    ASSERT(vm_error_string(VM_ERR_CALL_DEPTH) != NULL, "CALL_DEPTH string");
    ASSERT(vm_error_string(VM_ERR_INVALID_OPCODE) != NULL, "INVALID_OPCODE string");
    ASSERT(vm_error_string(VM_ERR_TYPE_ERROR) != NULL, "TYPE_ERROR string");
    ASSERT(vm_error_string(VM_ERR_OUT_OF_BOUNDS) != NULL, "OUT_OF_BOUNDS string");
    ASSERT(vm_error_string(VM_ERR_DIV_ZERO) != NULL, "DIV_ZERO string");
    ASSERT(vm_error_string(VM_ERR_ASSERT_FAILED) != NULL, "ASSERT_FAILED string");
    ASSERT(vm_error_string(VM_ERR_UNDEFINED_GLOBAL) != NULL, "UNDEFINED_GLOBAL string");
    ASSERT(vm_error_string(VM_ERR_UNDEFINED_FUNCTION) != NULL, "UNDEFINED_FUNCTION string");
    ASSERT(vm_error_string(VM_ERR_NOT_IMPLEMENTED) != NULL, "NOT_IMPLEMENTED string");
    ASSERT(vm_error_string(VM_ERR_MEMORY) != NULL, "MEMORY string");
    ASSERT(vm_error_string(VM_ERR_DECODE) != NULL, "DECODE string");
    ASSERT(vm_error_string((VmResult)9999) != NULL, "unknown error string");
}

static void test_predecode_malformed_bytecode(void) {
    uint8_t code[] = { OP_PUSH_I64, 1, 2 };
    NvmModule *mod = make_module(code, sizeof(code), 0, 0);
    VmState vm;
    vm_init(&vm, mod);

    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_DECODE,
                  "truncated instruction is rejected during cached decode");
    ASSERT_EQ_INT(vm.ip, 0, "decode failure preserves the byte offset");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_invalid_branch_target(void) {
    uint8_t code[64];
    uint32_t n = 0;
    n += emit(code + n, OP_JMP, (int32_t)2);
    n += emit(code + n, OP_HALT);
    NvmModule *mod = make_module(code, n, 0, 0);
    VmState vm;
    vm_init(&vm, mod);

    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_DECODE,
                  "branch into an operand is rejected before dispatch");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_invalidate_rebuild(void) {
    uint8_t code[64];
    uint32_t n = 0;
    n += emit(code + n, OP_PUSH_I64, (int64_t)1);
    n += emit(code + n, OP_HALT);
    NvmModule *mod = make_module(code, n, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "initial cached program executes");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 1, "initial cached operand is used");

    DecodedInstruction replacement = {0};
    replacement.opcode = OP_PUSH_I64;
    replacement.operands[0].i64 = 2;
    ASSERT_EQ_INT(isa_encode(&replacement, mod->code, mod->code_size), 9,
                  "replacement instruction encodes");
    vm.stack_size = 0;
    vm_invalidate_decoded_module(&vm, mod);
    ASSERT_EQ_INT(vm_rebuild_decoded_module(&vm, mod), VM_OK,
                  "mutated module cache rebuilds");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "rebuilt program executes");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 2, "rebuilt cache sees mutation");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_resolves_branch_targets(void) {
    /* Forward JMP over a PUSH_I64, then land on the RET. Decode must resolve
     * the branch target to an absolute code offset during instantiation so
     * dispatch never re-derives it from the relative operand. */
    uint8_t code[64];
    uint32_t n = 0;
    uint32_t jmp_offset = n;
    n += emit(code + n, OP_JMP, (int32_t)0); /* placeholder, patched below */
    uint32_t skipped_offset = n;
    n += emit(code + n, OP_PUSH_I64, (int64_t)7);
    uint32_t target_offset = n;
    n += emit(code + n, OP_PUSH_I64, (int64_t)42);
    n += emit(code + n, OP_RET);

    /* Re-emit the JMP now that we know the branch distance. */
    int32_t rel = (int32_t)target_offset - (int32_t)jmp_offset;
    emit(code + jmp_offset, OP_JMP, rel);

    NvmModule *mod = make_module(code, n, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.decoded_module_valid, "branch module decodes cleanly");

    const VmDecodedFunction *fn = &vm.decoded_module.functions[0];
    const VmDecodedInstruction *branch = vm_decoded_function_at(fn, jmp_offset);
    ASSERT(branch != NULL, "branch instruction is indexed by offset");
    ASSERT_EQ_INT(branch->resolved_target, target_offset,
                  "branch resolves to the absolute target offset at decode time");

    const VmDecodedInstruction *skipped = vm_decoded_function_at(fn, skipped_offset);
    ASSERT(skipped != NULL, "skipped instruction remains an instruction boundary");
    ASSERT_EQ_INT(skipped->resolved_target, UINT32_MAX,
                  "non-branch instructions carry no resolved target");

    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, 0, NULL, 0, &result), VM_OK,
                  "resolved branch executes");
    ASSERT_EQ_INT(result.as.i64, 42,
                  "resolved branch skips the guarded instruction");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

static void test_predecode_resolves_call_targets(void) {
    /* A caller that direct-calls and tail-calls a callee. Decode must bind both
     * to the callee's function-table index during instantiation. */
    uint8_t callee_code[32];
    uint32_t c = 0;
    c += emit(callee_code + c, OP_PUSH_I64, (int64_t)5);
    c += emit(callee_code + c, OP_RET);

    uint8_t direct_code[32];
    uint32_t d = 0;
    uint32_t call_offset = d;
    d += emit(direct_code + d, OP_CALL, (uint32_t)0); /* patched after add */
    d += emit(direct_code + d, OP_RET);

    uint8_t tail_code[32];
    uint32_t t = 0;
    uint32_t tail_offset = t;
    t += emit(tail_code + t, OP_TAIL_CALL, (uint32_t)0); /* patched after add */

    NvmModule *mod = make_multi_fn_module();
    uint32_t callee_idx = add_fn(mod, "callee", callee_code, c, 0, 0);
    /* Patch the encoded call operands now that callee_idx is known. */
    emit(direct_code, OP_CALL, callee_idx);
    emit(tail_code, OP_TAIL_CALL, callee_idx);
    uint32_t direct_idx = add_fn(mod, "direct", direct_code, d, 0, 0);
    uint32_t tail_idx = add_fn(mod, "tail", tail_code, t, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = direct_idx;

    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.decoded_module_valid, "call module decodes cleanly");

    const VmDecodedInstruction *call = vm_decoded_function_at(
        &vm.decoded_module.functions[direct_idx], call_offset);
    ASSERT(call != NULL, "direct call is indexed by offset");
    ASSERT_EQ_INT(call->resolved_target, callee_idx,
                  "direct call resolves to the callee index at decode time");

    const VmDecodedInstruction *tail = vm_decoded_function_at(
        &vm.decoded_module.functions[tail_idx], tail_offset);
    ASSERT(tail != NULL, "tail call is indexed by offset");
    ASSERT_EQ_INT(tail->resolved_target, callee_idx,
                  "tail call resolves to the callee index at decode time");

    NanoValue result = val_void();
    ASSERT_EQ_INT(vm_invoke(&vm, direct_idx, NULL, 0, &result), VM_OK,
                  "resolved direct call executes");
    ASSERT_EQ_INT(result.as.i64, 5, "resolved direct call returns callee result");

    ASSERT_EQ_INT(vm_invoke(&vm, tail_idx, NULL, 0, &result), VM_OK,
                  "resolved tail call executes");
    ASSERT_EQ_INT(result.as.i64, 5, "resolved tail call returns callee result");

    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* OP_ADD float+int (a=float first on stack, b=int): hits line 355 in vm.c */
static void test_add_float_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 3.0);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add_float_int: VM_OK");
    ASSERT_EQ_INT(result.tag, TAG_FLOAT, "add_float_int: tag float");
    ASSERT_EQ_F64(result.as.f64, 5.0, "add_float_int: 3.0+2==5.0");
    nvm_module_free(mod);
}

/* OP_SUB float-float */
static void test_sub_floats(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 5.0);
    off += emit(code + off, OP_PUSH_F64, 2.0);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "sub_floats: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 3.0, "sub_floats: 5.0-2.0==3.0");
    nvm_module_free(mod);
}

/* OP_SUB float-int (a=float, b=int): hits line 451 */
static void test_sub_float_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 7.5);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "sub_float_int: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 5.5, "sub_float_int: 7.5-2==5.5");
    nvm_module_free(mod);
}

/* OP_SUB int-float (a=int, b=float): hits line 453 */
static void test_sub_int_float(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_F64, 2.5);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "sub_int_float: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 7.5, "sub_int_float: 10-2.5==7.5");
    nvm_module_free(mod);
}

/* OP_MUL float*float */
static void test_mul_floats(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 3.0);
    off += emit(code + off, OP_PUSH_F64, 4.0);
    off += emit(code + off, OP_MUL);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mul_floats: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 12.0, "mul_floats: 3.0*4.0==12.0");
    nvm_module_free(mod);
}

/* OP_MUL float*int (a=float, b=int): hits line 521 */
static void test_mul_float_int(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_F64, 2.5);
    off += emit(code + off, OP_PUSH_I64, (int64_t)4);
    off += emit(code + off, OP_MUL);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mul_float_int: VM_OK");
    ASSERT_EQ_F64(result.as.f64, 10.0, "mul_float_int: 2.5*4==10.0");
    nvm_module_free(mod);
}

/* OP_SUB with two int arrays (element-wise): covers lines 454-479 */
static void test_sub_array_array(void) {
    uint8_t code[128];
    uint32_t off = 0;
    /* [10, 20, 30] - [1, 2, 3] = [9, 18, 27] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)30);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_SUB);
    off += emit(code + off, OP_ARR_LEN);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "sub_array_array: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3, "sub_array_array: length 3");
    nvm_module_free(mod);
}

/* OP_MUL with two int arrays (element-wise): covers lines 524-549 */
static void test_mul_array_array(void) {
    uint8_t code[128];
    uint32_t off = 0;
    /* [2, 3, 4] * [5, 6, 7] = [10, 18, 28] */
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)4);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)5);
    off += emit(code + off, OP_PUSH_I64, (int64_t)6);
    off += emit(code + off, OP_PUSH_I64, (int64_t)7);
    off += emit(code + off, OP_ARR_LITERAL, (uint8_t)TAG_INT, (uint16_t)3);
    off += emit(code + off, OP_MUL);
    off += emit(code + off, OP_ARR_LEN);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "mul_array_array: VM_OK");
    ASSERT_EQ_INT(result.as.i64, 3, "mul_array_array: length 3");
    nvm_module_free(mod);
}

/* OP_STR_CONCAT (opcode 0x41): covers lines 1008-1019 */
static void test_str_concat_op(void) {
    NvmModule *mod = nvm_module_new();
    uint32_t s1_idx = nvm_add_string(mod, "hello ", 6);
    uint32_t s2_idx = nvm_add_string(mod, "world", 5);

    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_STR, s1_idx);
    off += emit(code + off, OP_PUSH_STR, s2_idx);
    off += emit(code + off, OP_STR_CONCAT);
    off += emit(code + off, OP_RET);
    uint32_t fn_idx = add_fn(mod, "main", code, off, 0, 0);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;

    VmState vm;
    vm_init(&vm, mod);
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "str_concat_op: VM_OK");
    NanoValue result = vm_get_result(&vm);
    ASSERT_EQ_INT(result.tag, TAG_STRING, "str_concat_op: tag string");
    ASSERT_EQ_STR(vmstring_cstr(result.as.string), "hello world", "str_concat_op: value");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* OP_STR_CONCAT with non-string args → type error path */
static void test_str_concat_type_error(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_STR_CONCAT);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "str_concat_type_error: type error");
    nvm_module_free(mod);
}

/* ARR_PUSH on a non-array value → type error path (lines 1113-1115) */
static void test_arr_push_type_error(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);  /* not an array */
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_ARR_PUSH);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "arr_push_type_error: type error");
    nvm_module_free(mod);
}

/* STR_LEN on a non-string → type error path (lines 998-999) */
static void test_str_len_type_error(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);  /* not a string */
    off += emit(code + off, OP_STR_LEN);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "str_len_type_error: type error");
    nvm_module_free(mod);
}

/* STRUCT_GET on a non-struct → type error path (lines 1235-1236) */
static void test_struct_get_type_error(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)99); /* not a struct */
    off += emit(code + off, OP_STRUCT_GET, (uint16_t)0);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR, "struct_get_type_error: type error");
    nvm_module_free(mod);
}

/* ========================================================================
 * Main
 * ======================================================================== */

static void test_typed_scalar_operations(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PUSH_I64, (int64_t)22);
    off += emit(code + off, OP_I64_ADD);
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_I64_EQ);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "typed integer operations execute");
    ASSERT(result.as.boolean, "typed integer comparison succeeds");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_F64, 20.0);
    off += emit(code + off, OP_PUSH_F64, 22.0);
    off += emit(code + off, OP_F64_ADD);
    off += emit(code + off, OP_PUSH_F64, 42.0);
    off += emit(code + off, OP_F64_EQ);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    mod->functions[0].result_count = 1;
    result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "typed float operations execute");
    ASSERT(result.as.boolean, "typed float comparison succeeds");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_BOOL, 1);
    off += emit(code + off, OP_PUSH_BOOL, 0);
    off += emit(code + off, OP_BOOL_OR);
    off += emit(code + off, OP_BOOL_NOT);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "typed boolean operations execute");
    ASSERT(!result.as.boolean, "typed boolean result is correct");
    nvm_module_free(mod);
}

static void test_typed_scalar_type_error(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_F64, 2.0);
    off += emit(code + off, OP_I64_ADD);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    (void)result;
    ASSERT_EQ_INT(r, VM_ERR_TYPE_ERROR,
                  "typed integer opcode rejects a float operand");
    nvm_module_free(mod);
}

static void test_integer_machine_primitives(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)-1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_I64_DIV_U);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "unsigned division executes");
    ASSERT_EQ_INT(result.as.i64, INT64_MAX, "unsigned division uses cell bits");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)-1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_I64_ADD_CARRY);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    mod->functions[0].result_count = 2;
    result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "add with carry executes");
    ASSERT_EQ_INT(result.as.i64, 1, "add with carry returns carry above low cell");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)-1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_I64_MUL_WIDE_U);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    mod->functions[0].result_count = 2;
    result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "wide unsigned multiplication executes");
    ASSERT_EQ_INT(result.as.i64, 1, "wide multiplication returns high cell on top");
    nvm_module_free(mod);
}

static void test_indexed_stack_and_memory(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)10);
    off += emit(code + off, OP_PUSH_I64, (int64_t)20);
    off += emit(code + off, OP_PICK, 1);
    off += emit(code + off, OP_I64_ADD);
    off += emit(code + off, OP_I64_ADD);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmResult r;
    NanoValue result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "PICK executes");
    ASSERT_EQ_INT(result.as.i64, 40, "PICK copies indexed stack value");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)1);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_ROLL, 2);
    off += emit(code + off, OP_I64_SUB);
    off += emit(code + off, OP_I64_ADD);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    result = run_module(mod, &r);
    ASSERT_EQ_INT(r, VM_OK, "ROLL executes");
    ASSERT_EQ_INT(result.as.i64, 4, "ROLL moves indexed value to top");
    nvm_module_free(mod);

    off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_PUSH_I64, (int64_t)0x0102030405060708LL);
    off += emit(code + off, OP_MEM_STORE64);
    off += emit(code + off, OP_PUSH_I64, (int64_t)3);
    off += emit(code + off, OP_MEM_LOAD64);
    off += emit(code + off, OP_RET);
    mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm_memory_resize(&vm, 16), "linear memory allocation succeeds");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "unaligned 64-bit memory access executes");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 0x0102030405060708LL,
                  "memory load preserves little-endian cell");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* ========================================================================
 * Dynamically-sized globals (Roadmap 4.0 Phase 12, Runtime representation)
 * ======================================================================== */

/* A module that stores to and loads from a global slot sizes the VM globals
 * array to the declared slots instead of embedding VM_MAX_GLOBALS values. */
static void test_globals_dynamic_size(void) {
    uint8_t code[128];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)7);
    off += emit(code + off, OP_STORE_GLOBAL, (uint32_t)5);
    off += emit(code + off, OP_LOAD_GLOBAL, (uint32_t)5);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    /* Sized to one past the highest referenced slot (index 5 => 6 slots),
     * never the fixed VM_MAX_GLOBALS embedding. */
    ASSERT_EQ_INT(vm.global_capacity, 6, "globals sized to declared slots");
    ASSERT(vm.global_capacity < VM_MAX_GLOBALS, "globals not embedded at max");
    ASSERT(vm.globals != NULL, "globals array allocated");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "global store/load executes");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 7, "global round-trips value");
    vm_destroy(&vm);
    ASSERT(vm.globals == NULL, "globals freed on destroy");
    ASSERT_EQ_INT(vm.global_capacity, 0, "global capacity cleared on destroy");
    nvm_module_free(mod);
}

/* A module that uses no globals allocates no globals array at all. */
static void test_globals_none_unallocated(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)42);
    off += emit(code + off, OP_RET);

    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm.global_capacity, 0, "no globals => zero capacity");
    ASSERT(vm.globals == NULL, "no globals => no allocation");
    ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "global-free module executes");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* vm_ensure_globals grows the dynamically-sized array on demand and refuses
 * to exceed VM_MAX_GLOBALS. */
static void test_globals_ensure_bounds(void) {
    uint8_t code[64];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)0);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_module(code, off, 0, 0);
    VmState vm;
    vm_init(&vm, mod);
    ASSERT_EQ_INT(vm.global_capacity, 0, "no globals declared => zero capacity");
    ASSERT(vm_ensure_globals(&vm, 8), "grow to 8 slots succeeds");
    ASSERT_EQ_INT(vm.global_capacity, 8, "capacity grew to 8");
    ASSERT(vm_ensure_globals(&vm, 3), "shrink request is a no-op success");
    ASSERT_EQ_INT(vm.global_capacity, 8, "capacity never shrinks");
    ASSERT(!vm_ensure_globals(&vm, VM_MAX_GLOBALS + 1),
           "request beyond VM_MAX_GLOBALS is rejected");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* Build a module whose single "main" returns an int, with a well-formed
 * result signature (result_count/result_tag agree) so nvm_verify() accepts it
 * and the VM enables the verified fast path. */
static NvmModule *make_verifiable_int_module(const uint8_t *code,
                                             uint32_t code_size,
                                             uint16_t local_count) {
    NvmModule *mod = nvm_module_new();
    uint32_t name_idx = nvm_add_string(mod, "main", 4);
    uint32_t code_off = nvm_append_code(mod, code, code_size);
    NvmFunctionEntry fn = {0};
    fn.name_idx = name_idx;
    fn.arity = 0;
    fn.code_offset = code_off;
    fn.code_length = code_size;
    fn.local_count = local_count;
    fn.upvalue_count = 0;
    fn.result_count = 1;
    fn.result_tag = TAG_INT;
    uint32_t fn_idx = nvm_add_function(mod, &fn);
    mod->header.flags = NVM_FLAG_HAS_MAIN;
    mod->header.entry_point = fn_idx;
    return mod;
}

/* ========================================================================
 * Verified fast path: unchecked private stack handlers
 *
 * nvm_verify() proves the operand-stack depth of every reachable
 * instruction, so a verified module lets the VM use the unchecked private
 * handlers (stack_pop_unchecked/stack_peek_unchecked). These tests pin the
 * proof flag (vm.verified) to the verifier's verdict and confirm the
 * unchecked path still computes correct results, while an unverifiable
 * module stays on the guarded path.
 * ======================================================================== */

/* A well-formed module is verified, so the VM runs the unchecked handlers
 * and still returns the right answer. */
static void test_verified_fastpath_enabled(void) {
    uint8_t code[32];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)40);
    off += emit(code + off, OP_PUSH_I64, (int64_t)2);
    off += emit(code + off, OP_ADD);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_verifiable_int_module(code, off, 0);

    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.verified, "well-formed module enables the verified fast path");
    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "verified module executes cleanly");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 42,
                  "unchecked stack handlers compute the correct result");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* A module the verifier rejects (stack underflow: OP_ADD with an empty
 * stack) must leave the proof flag clear so the guarded handlers stay in
 * force rather than reading below the operand stack. */
static void test_owned_transfers_require_runtime(void) {
    const char *names[]={"OWN_MOVE_LOCAL", "OWN_STORE_LOCAL", "OWN_PACK", "OWN_UNPACK_LOCAL"};
    for (unsigned i=0;i<4;i++) {
        char source[256];
        snprintf(source,sizeof(source),".entry 0\n.function main 0 1 0 int 1\n%s%s 0\nPUSH_I64 0\nRET\n.end\n",i==1?"PUSH_I64 1\n":"",names[i]);
        AsmResult error;
        NvmModule *module=asm_assemble_unverified(source,&error);
        ASSERT(module!=NULL,"non-executing transfer fixture retained");
        VmState vm;vm_init(&vm,module);
        ASSERT(!vm.verified,"missing transfer contract never becomes verified");
        VmResult stopped=vm_execute(&vm);
        ASSERT_EQ_INT(stopped,VM_ERR_NOT_IMPLEMENTED,"raw transfer cannot execute without runtime semantics");
        vm_destroy(&vm);nvm_module_free(module);
    }
}

static void test_ownership_contracts_refuse_checked_fallback(void) {
    AsmResult assembly;
    NvmModule *module = asm_assemble(
        ".types 1 0 0\n.entry 0\n.function main 0 0 0 int 1\n"
        "PUSH_I64 0\nRET\n.end\n", &assembly);
    ASSERT(module != NULL, "ordinary fixture assembles");
    NvmV2LayoutField field = {TAG_INT, NVM_V2_NO_INDEX, NVM_V2_NO_INDEX};
    NvmV2Layout item = {NVM_V2_LAYOUT_STRUCT, 1, NVM_V2_NO_INDEX, &field};
    NvmV2Layouts layouts = {&item, 1};
    ASSERT(nvm_retain_layouts(module, &layouts) == NVM_V2_OK, "layout retained");
    const uint8_t ordinary[] = {
        1,0,0,0, 1,0,0,0, NVM_LAYOUT_COMPLETE,0,0,0, 1,0,0,0,
        0,0,0,0, TAG_INT,0,0,0, 255,255,255,255
    };
    module->ownership_size = sizeof ordinary;
    module->ownership_data = malloc(sizeof ordinary);
    ASSERT(module->ownership_data != NULL, "contract allocated");
    memcpy(module->ownership_data, ordinary, sizeof ordinary);
    VmState vm;
    vm_init(&vm, module);
    ASSERT(vm_execute(&vm) == VM_OK, "ordinary declarations execute");
    vm_destroy(&vm);
    module->ownership_data[8] |= NVM_LAYOUT_RESOURCE;
    bool needs = false;
    ASSERT(nvm_ownership_contracts_validate(module, &needs) == NVM_V2_OK && needs,
           "resource declaration is valid but not executable");
    vm_init(&vm, module);
    ASSERT(!vm.verified, "unsupported ownership is not verified");
    ASSERT(vm_execute(&vm) == VM_ERR_TYPE_ERROR, "raw entry refuses ownership");
    ASSERT(vm_call_function(&vm, 0, NULL, 0) == VM_ERR_TYPE_ERROR,
           "raw function call refuses ownership");
    NanoValue returned = val_int(99);
    ASSERT(vm_invoke(&vm, 0, NULL, 0, &returned) == VM_ERR_TYPE_ERROR,
           "raw invoke refuses ownership");
    ASSERT(returned.tag == TAG_INT && returned.as.i64 == 99, "result remains unchanged");
    ASSERT(vm_invoke_callable(&vm, val_function_owned(0, 1), NULL, 0, &returned) == VM_ERR_TYPE_ERROR,
           "callable invoke refuses ownership");
    ASSERT(vm.frame_count == 0 && vm.stack_size == 0, "refusal creates no activation");
    /* I set up the ordinary zero-local entry activation for the core API.
     * Refusal happens before its first instruction changes the stack. */
    vm.frame_count = 1;
    vm.current_fn = 0;
    VmTrap trap = vm_core_execute(&vm);
    ASSERT(trap.type == TRAP_ERROR && trap.data.error.code == VM_ERR_TYPE_ERROR,
           "core API refuses ownership");
    ASSERT(vm.stack_size == 0, "core refusal leaves operands unchanged");
    vm.frame_count = 0;
    vm_destroy(&vm);
    NvmModule *root = asm_assemble(
        ".entry 0\n.function main 0 0 0 int 1\nPUSH_I64 0\nRET\n.end\n", &assembly);
    ASSERT(root != NULL, "ordinary linked caller assembles");
    vm_init(&vm, root);
    ASSERT(vm_link_module(&vm, module) != UINT32_MAX, "declarations remain inspectable when linked");
    ASSERT(vm_execute(&vm) == VM_ERR_TYPE_ERROR, "linked resource contract refuses execution");
    vm_destroy(&vm);
    nvm_module_free(root);
    nvm_module_free(module);
}

static void test_unverifiable_stays_checked(void) {
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_ADD); /* pops two with nothing pushed */
    off += emit(code + off, OP_RET);
    /* Signature is well-formed, so the only reason verification fails is the
     * proven stack underflow at OP_ADD. */
    NvmModule *mod = make_verifiable_int_module(code, off, 0);

    VmState vm;
    vm_init(&vm, mod);
    ASSERT(!vm.verified,
           "verifier rejects the underflowing module, proof flag stays clear");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* Invalidating a module drops the proof; rebuilding a well-formed module
 * re-establishes it. */
static void test_verified_flag_tracks_module_lifecycle(void) {
    uint8_t code[16];
    uint32_t off = 0;
    off += emit(code + off, OP_PUSH_I64, (int64_t)7);
    off += emit(code + off, OP_RET);
    NvmModule *mod = make_verifiable_int_module(code, off, 0);

    VmState vm;
    vm_init(&vm, mod);
    ASSERT(vm.verified, "initial well-formed module is verified");

    vm_invalidate_module(&vm, mod);
    ASSERT(!vm.verified, "invalidating a module clears the proof flag");

    ASSERT(vm_rebuild_module(&vm, mod), "rebuild of well-formed module succeeds");
    ASSERT(vm.verified, "rebuild re-establishes the proof flag");

    VmResult r = vm_execute(&vm);
    ASSERT_EQ_INT(r, VM_OK, "rebuilt verified module executes cleanly");
    ASSERT_EQ_INT(vm_get_result(&vm).as.i64, 7,
                  "rebuilt verified module returns the correct result");
    vm_destroy(&vm);
    nvm_module_free(mod);
}

/* I reject missing operands before touching locals or a caller's stack. */
static void test_stack_slice_underflow(void) {
    NanoOpcode ops[256] = {OP_DUP, OP_POP, OP_SWAP, OP_ROT3,
                              OP_PICK, OP_ROLL, OP_PICK, OP_ROLL,
                              OP_PICK, OP_ROLL, OP_ARR_LITERAL, OP_STRUCT_LITERAL,
                              OP_UNION_CONSTRUCT, OP_TUPLE_NEW, OP_AGG_PACK,
                              OP_CLOSURE_NEW};
    unsigned required[256] = {1, 1, 2, 3, 3, 3, 1, 1, 65536, 65536,
                              3, 3, 3, 3, 3, 3};
    size_t count = 16;
    unsigned file_refusals = 0;
    for (unsigned opcode = 0; opcode < NANOISA_PRIMARY_OPCODE_LIMIT; opcode++) {
        const InstructionInfo *info = isa_get_info((uint8_t)opcode);
        if (!info || info->operand_count || info->pop_count <= 0) continue;
        if (opcode == OP_DUP || opcode == OP_POP || opcode == OP_SWAP
                || opcode == OP_ROT3) continue;
        ops[count] = (NanoOpcode)opcode;
        required[count++] = (unsigned)info->pop_count;
    }
    ASSERT(count > 50, "I exercise fixed-effect handler families, not just stack shuffles");
    for (size_t op = 0; op < count; op++) {
        unsigned needed = required[op];
        for (unsigned depth = 0; depth < needed && depth <= 3; depth++) {
            for (unsigned locals = 0; locals <= 2; locals += 2) {
                for (unsigned caller = 0; caller <= 2; caller += 2) {
                    uint8_t code[64];
                    uint32_t size = 0;
                    for (unsigned i = 0; i < depth; i++)
                        size += emit(code + size, OP_PUSH_I64, (int64_t)(42 + i));
                    if (ops[op] == OP_PICK || ops[op] == OP_ROLL)
                        size += emit(code + size, ops[op], (int)(needed - 1));
                    else if (ops[op] == OP_ARR_LITERAL)
                        size += emit(code + size, ops[op], TAG_INT, (int)needed);
                    else if (ops[op] == OP_STRUCT_LITERAL || ops[op] == OP_CLOSURE_NEW)
                        size += emit(code + size, ops[op], (uint32_t)0, (int)needed);
                    else if (ops[op] == OP_UNION_CONSTRUCT)
                        size += emit(code + size, ops[op], (uint32_t)0, 0, (int)needed);
                    else if (ops[op] == OP_TUPLE_NEW)
                        size += emit(code + size, ops[op], (int)needed);
                    else if (ops[op] == OP_AGG_PACK)
                        size += emit(code + size, ops[op], AGG_TUPLE, (uint32_t)0, 0, (int)needed);
                    else
                        size += emit(code + size, ops[op]);
                    size += emit(code + size, OP_HALT);
                    NvmModule *mod = make_module(code, size, 0, (uint16_t)locals);
                    VmState vm;
                    vm_init(&vm, mod);
                    ASSERT(!vm.verified, "I reject underflow in the verifier");
                    for (unsigned i = 0; i < caller; i++)
                        vm.stack[vm.stack_size++] = val_int(100 + i);
                    bool file_opcode = isa_is_file_opcode((uint8_t)ops[op]);
                    VmResult expected = file_opcode ? VM_ERR_TYPE_ERROR : VM_ERR_STACK_UNDERFLOW;
                    VmResult actual = vm_execute(&vm);
                    if (actual != expected)
                        fprintf(stderr, "I observed opcode 0x%02x depth %u locals %u caller %u: expected %d, got %d (%s).\n",
                                (unsigned)ops[op], depth, locals, caller,
                                (int)expected, (int)actual, vm.error_msg);
                    if (file_opcode) {
                        /* I refuse bare File code before creating its activation. */
                        ASSERT_EQ_INT(ops[op], OP_FILE_DROP_STACK, "I identify the fixed-effect File control");
                        ASSERT_EQ_INT(actual, VM_ERR_TYPE_ERROR, "I preserve service-first public refusal");
                        ASSERT_EQ_INT(vm.frame_count, 0, "I create no frame for refused File code");
                        ASSERT_EQ_INT(vm.stack_size, caller, "I leave the caller stack intact before File activation");
                        for (unsigned i = 0; i < caller; i++) {
                            ASSERT_EQ_INT(vm.stack[i].tag, TAG_INT, "I preserve refused File caller tags");
                            ASSERT_EQ_INT(vm.stack[i].as.i64, 100 + i, "I preserve refused File caller values");
                        }
                        file_refusals++;
                        vm_destroy(&vm);
                        nvm_module_free(mod);
                        continue;
                    }
                    ASSERT_EQ_INT(actual, VM_ERR_STACK_UNDERFLOW,
                                  "I trap on missing operands");
                    ASSERT_EQ_INT(vm.stack_size, caller + locals + depth,
                                  "I preserve the stack on underflow");
                    for (unsigned i = 0; i < caller; i++) {
                        ASSERT_EQ_INT(vm.stack[i].tag, TAG_INT, "I preserve caller tags");
                        ASSERT_EQ_INT(vm.stack[i].as.i64, 100 + i, "I preserve caller values");
                    }
                    for (unsigned i = 0; i < locals; i++)
                        ASSERT_EQ_INT(vm.stack[caller + i].tag, TAG_VOID,
                                      "I preserve frame locals");
                    for (unsigned i = 0; i < depth; i++) {
                        ASSERT_EQ_INT(vm.stack[caller + locals + i].tag, TAG_INT,
                                      "I preserve the remaining operand tag");
                        ASSERT_EQ_INT(vm.stack[caller + locals + i].as.i64, 42 + i,
                                      "I preserve the remaining operand value");
                    }
                    vm_destroy(&vm);
                    nvm_module_free(mod);
                }
            }
        }
    }
    ASSERT_EQ_INT(file_refusals, 4, "I cover both local and caller states for bare File refusal");
}

static void test_linked_call_shape_boundaries(void) {
    for (unsigned mismatch = 0; mismatch < 2; mismatch++) {
        uint8_t code[64], body[32];
        uint32_t size = emit(code, OP_PUSH_I64, (int64_t)42);
        size += emit(code + size, OP_CALL_MODULE, (uint32_t)0, (uint32_t)0, 1, 1);
        size += emit(code + size, OP_RET);
        NvmModule *mod = make_module(code, size, 0, 2);
        mod->functions[0].result_tag = TAG_INT;
        uint32_t body_size = 0;
        if (!mismatch) body_size += emit(body, OP_PUSH_I64, (int64_t)7);
        body_size += emit(body + body_size, OP_RET);
        NvmModule *linked = make_module(body, body_size, mismatch ? 1 : 2, 2);
        linked->functions[0].result_count = mismatch ? 0 : 1;
        linked->functions[0].result_tag = mismatch ? TAG_VOID : TAG_INT;
        ASSERT(nvm_verify(mod).ok, "I verify the caller's declared shape separately");
        ASSERT(nvm_verify(linked).ok, "I verify the target separately");
        VmState vm;
        vm_init(&vm, mod);
        ASSERT_EQ_INT(vm_link_module(&vm, linked), 0, "I bind the target module");
        ASSERT(!vm.verified, "I do not confuse separate proofs with a linked proof");
        vm.stack[vm.stack_size++] = val_int(100);
        ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_TYPE_ERROR,
                      "I reject the mismatched linked shape before entering it");
        ASSERT_EQ_INT(vm.frame_count, 1, "I keep the caller frame");
        ASSERT_EQ_INT(vm.stack_size, 4, "I keep caller, locals and argument");
        ASSERT_EQ_INT(vm.stack[0].as.i64, 100, "I preserve the caller prefix");
        ASSERT_EQ_INT(vm.stack[1].tag, TAG_VOID, "I preserve the first local");
        ASSERT_EQ_INT(vm.stack[2].tag, TAG_VOID, "I preserve the second local");
        ASSERT_EQ_INT(vm.stack[3].as.i64, 42, "I preserve the argument");
        vm_destroy(&vm);
        nvm_module_free(mod);
        nvm_module_free(linked);
    }
}

static void test_call_operand_boundaries(void) {
    const NanoOpcode ops[] = {OP_CALL, OP_TAIL_CALL, OP_CALL_INDIRECT,
                              OP_CALL_EXTERN, OP_CALL_MODULE};
    for (size_t op = 0; op < sizeof(ops) / sizeof(ops[0]); op++) {
        for (unsigned depth = 0; depth < 2; depth++) {
            for (unsigned locals = 0; locals <= 2; locals += 2) {
                for (unsigned caller = 0; caller <= 2; caller += 2) {
                    uint8_t code[64], body[8];
                    uint32_t size = 0;
                    for (unsigned i = 0; i < depth; i++)
                        size += emit(code + size, OP_PUSH_I64, (int64_t)(42 + i));
                    bool indirect = ops[op] == OP_CALL_INDIRECT;
                    if (indirect) {
                        size += emit(code + size, OP_FUNCREF, (uint32_t)1);
                        size += emit(code + size, ops[op], 2, 1);
                    } else if (ops[op] == OP_CALL_MODULE) {
                        size += emit(code + size, ops[op], (uint32_t)0,
                                     (uint32_t)0, 2, 1);
                    } else {
                        size += emit(code + size, ops[op],
                                     (uint32_t)(ops[op] == OP_CALL_EXTERN ? 0 : 1));
                    }
                    size += emit(code + size, OP_HALT);
                    NvmModule *mod = make_module(code, size, 0, (uint16_t)locals);
                    uint32_t body_size = emit(body, OP_HALT);
                    add_fn(mod, "callee", body, body_size, 2, 2);
                    uint8_t params[] = {TAG_INT, TAG_INT};
                    uint32_t module_name = nvm_add_string(mod, "foreign", 7);
                    uint32_t function_name = nvm_add_string(mod, "call", 4);
                    nvm_add_import(mod, module_name, function_name, 2, TAG_INT, params);
                    NvmModule *linked = make_module(body, body_size, 2, 2);
                    VmState vm;
                    vm_init(&vm, mod);
                    vm_link_module(&vm, linked);
                    ASSERT(!vm.verified, "I keep malformed calls on the checked path");
                    for (unsigned i = 0; i < caller; i++)
                        vm.stack[vm.stack_size++] = val_int(100 + i);
                    ASSERT_EQ_INT(vm_execute(&vm), VM_ERR_STACK_UNDERFLOW,
                                  "I reject missing call arguments before frame changes");
                    ASSERT_EQ_INT(vm.frame_count, 1, "I do not enter the callee");
                    ASSERT_EQ_INT(vm.stack_size, caller + locals + depth + indirect,
                                  "I preserve the call stack on argument failure");
                    for (unsigned i = 0; i < caller; i++)
                        ASSERT_EQ_INT(vm.stack[i].as.i64, 100 + i, "I preserve caller values");
                    for (unsigned i = 0; i < locals; i++)
                        ASSERT_EQ_INT(vm.stack[caller + i].tag, TAG_VOID, "I preserve locals");
                    for (unsigned i = 0; i < depth; i++)
                        ASSERT_EQ_INT(vm.stack[caller + locals + i].as.i64, 42 + i,
                                      "I preserve existing arguments");
                    if (indirect)
                        ASSERT_EQ_INT(vm.stack[vm.stack_size - 1].tag, TAG_FUNCTION,
                                      "I preserve the callable on failure");
                    vm_destroy(&vm);
                    nvm_module_free(mod);
                    nvm_module_free(linked);
                }
            }
        }
    }
}

static void test_closure_large_capture_count(void) {
    const unsigned counts[] = {0, 32768, 32769, 65535};
    for (size_t c = 0; c < sizeof(counts) / sizeof(counts[0]); c++) {
        unsigned count = counts[c];
        uint8_t *code = malloc((size_t)count * 9 + 16);
        ASSERT(code != NULL, "I allocate the capture-boundary program");
        uint32_t size = 0;
        for (unsigned i = 0; i < count; i++)
            size += emit(code + size, OP_PUSH_I64, (int64_t)i);
        size += emit(code + size, OP_CLOSURE_NEW, (uint32_t)0, (int)count);
        size += emit(code + size, OP_HALT);
        NvmModule *mod = make_module(code, size, 0, 0);
        free(code);
        VmState vm;
        vm_init(&vm, mod);
        ASSERT_EQ_INT(vm_execute(&vm), VM_OK, "I construct the complete closure");
        ASSERT_EQ_INT(vm.stack_size, 1, "I consume every capture operand");
        ASSERT_EQ_INT(vm.stack[0].tag, TAG_CLOSURE, "I return a closure");
        for (unsigned i = 0; i < count; i++) {
            ASSERT_EQ_INT(vm.stack[0].as.closure->captures[i].tag, TAG_INT,
                          "I preserve capture tags");
            ASSERT_EQ_INT(vm.stack[0].as.closure->captures[i].as.i64, i,
                          "I preserve capture order across the signed boundary");
        }
        vm_destroy(&vm);
        nvm_module_free(mod);
    }
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("=== NanoVM Test Suite ===\n");

    printf("\n[Integer Arithmetic]\n");
    RUN_TEST(test_push_int_halt);
    RUN_TEST(test_add_ints);
    RUN_TEST(test_sub_ints);
    RUN_TEST(test_mul_ints);
    RUN_TEST(test_div_ints);
    RUN_TEST(test_div_by_zero);
    RUN_TEST(test_mod_ints);
    RUN_TEST(test_neg_int);

    printf("\n[Float Arithmetic]\n");
    RUN_TEST(test_float_add);
    RUN_TEST(test_mixed_int_float_add);
    RUN_TEST(test_float_div_by_zero);
    RUN_TEST(test_typed_scalar_operations);
    RUN_TEST(test_typed_scalar_type_error);
    RUN_TEST(test_integer_machine_primitives);
    RUN_TEST(test_indexed_stack_and_memory);

    printf("\n[Boolean & Comparison]\n");
    RUN_TEST(test_bool_push);
    RUN_TEST(test_eq_ints);
    RUN_TEST(test_ne_ints);
    RUN_TEST(test_lt_ints);
    RUN_TEST(test_logic_and);
    RUN_TEST(test_logic_not);

    printf("\n[Stack Operations]\n");
    RUN_TEST(test_dup);
    RUN_TEST(test_stack_slice_underflow);
    RUN_TEST(test_call_operand_boundaries);
    RUN_TEST(test_linked_call_shape_boundaries);
    RUN_TEST(test_closure_large_capture_count);
    RUN_TEST(test_swap);
    RUN_TEST(test_pop);
    RUN_TEST(test_push_void);
    RUN_TEST(test_push_u8);

    printf("\n[Local Variables]\n");
    RUN_TEST(test_locals);

    printf("\n[Global Variables]\n");
    RUN_TEST(test_globals);

    printf("\n[Control Flow]\n");
    RUN_TEST(test_jmp);
    RUN_TEST(test_jmp_false);
    RUN_TEST(test_jmp_true);
    RUN_TEST(test_loop);

    printf("\n[Function Calls]\n");
    RUN_TEST(test_call_function);
    RUN_TEST(test_recursive_factorial);

    printf("\n[Strings]\n");
    RUN_TEST(test_push_string);
    RUN_TEST(test_string_concat);
    RUN_TEST(test_string_len);
    RUN_TEST(test_str_from_int);
    RUN_TEST(test_string_embedded_zero_bytes);
    RUN_TEST(test_string_find_across_zero);
    RUN_TEST(test_string_substr_across_zero);
    RUN_TEST(test_str_replace_op_embedded_zero);
    RUN_TEST(test_str_contains_op_embedded_zero);
    RUN_TEST(test_str_split_op_embedded_zero);

    printf("\n[Arrays]\n");
    RUN_TEST(test_array_literal);
    RUN_TEST(test_array_push_get);
    RUN_TEST(test_array_len);
    RUN_TEST(test_array_unboxed_representation);

    printf("\n[Structs]\n");
    RUN_TEST(test_struct_literal);
    RUN_TEST(test_struct_set);

    printf("\n[Tuples]\n");
    RUN_TEST(test_tuple);

    printf("\n[Enums & Unions]\n");
    RUN_TEST(test_enum_val);
    RUN_TEST(test_union_construct_tag);
    RUN_TEST(test_union_field);

    printf("\n[Hashmaps]\n");
    RUN_TEST(test_hashmap_basic);
    RUN_TEST(test_hashmap_declared_write_tags);
    RUN_TEST(test_hashmap_len);
    RUN_TEST(test_hashmap_contiguous_collisions);

    printf("\n[Type Casts]\n");
    RUN_TEST(test_cast_int_from_float);
    RUN_TEST(test_cast_float_from_u8);
    RUN_TEST(test_cast_float_from_int);
    RUN_TEST(test_cast_bool);
    RUN_TEST(test_cast_string_from_u8);
    RUN_TEST(test_cast_string);

    printf("\n[Closures]\n");
    RUN_TEST(test_closure);
    RUN_TEST(test_self_referential_array_is_collected);
    RUN_TEST(test_two_object_cycle_is_collected);
    RUN_TEST(test_reachable_cycle_is_not_collected);
    RUN_TEST(test_cycle_payload_is_freed_with_it);
    RUN_TEST(test_dead_cycles_preserve_shared_live_payload);
    RUN_TEST(test_dead_cycle_preserves_live_field_name);
    RUN_TEST(test_cycle_preserves_shared_live_payload);
    RUN_TEST(test_cycles_share_dead_leaf);
    RUN_TEST(test_cycle_detaches_struct_field_names);
    RUN_TEST(test_object_freed_while_buffered);
    RUN_TEST(test_many_cycles_in_one_pass);
    RUN_TEST(test_heap_destroy_collects_cycles);
    RUN_TEST(test_array_remove_releases_the_element);
    RUN_TEST(test_closure_call_releases_the_callable);
    RUN_TEST(test_recursive_calls_retain_closure);
    RUN_TEST(test_destroy_releases_trapped_callable);
    RUN_TEST(test_direct_function_reference);

    printf("\n[I/O]\n");
    RUN_TEST(test_print);
    RUN_TEST(test_assert_pass);
    RUN_TEST(test_assert_fail);

    printf("\n[Error Handling]\n");
    RUN_TEST(test_type_error_add);
    RUN_TEST(test_no_entry_point);

    printf("\n[Dynamically-sized globals]\n");
    RUN_TEST(test_globals_dynamic_size);
    RUN_TEST(test_globals_none_unallocated);
    RUN_TEST(test_globals_ensure_bounds);
    RUN_TEST(test_call_extern_arg_limit_is_error_not_truncation);
    RUN_TEST(test_persistent_invoke);
    RUN_TEST(test_predecode_mutation_lifecycle);
    RUN_TEST(test_sync_new_functions_keeps_existing_decode);
    RUN_TEST(test_predecode_rejects_malformed_code);
    RUN_TEST(test_predecode_trap_resume_offset);
    RUN_TEST(test_result_signature_enforcement);
    RUN_TEST(test_instruction_profile);
    RUN_TEST(test_heap_profile);

    printf("\n[Stack Trace / Debug Mode]\n");
    RUN_TEST(test_stack_trace_debug_mode);
    RUN_TEST(test_assertion_stack_context);
    RUN_TEST(test_stack_trace_executing_offsets);
    RUN_TEST(test_stack_trace_fused_field_location);
    RUN_TEST(test_stack_trace_col);
    RUN_TEST(test_stack_trace_multi_frame);

    printf("\n[Opaque Proxy]\n");
    RUN_TEST(test_opaque_null);

    printf("\n[Serialize/Execute Round-trip]\n");
    RUN_TEST(test_serialize_execute);

    printf("\n[Complex Programs]\n");
    RUN_TEST(test_fibonacci);
    RUN_TEST(test_gcd);

    printf("\n[Assembler -> VM Integration]\n");
    RUN_TEST(test_assemble_and_run);
    RUN_TEST(test_assemble_function_call);
    RUN_TEST(test_assemble_loop);

    printf("\n[Cross-Module Linking]\n");
    RUN_TEST(test_call_module);
    RUN_TEST(test_call_module_string_constant);
    RUN_TEST(test_call_module_bad_idx);
    RUN_TEST(test_call_module_chain);
    RUN_TEST(test_call_module_handle_resolution);
    RUN_TEST(test_separately_linked_module_roundtrip);
    RUN_TEST(test_linked_callable_identity);
    RUN_TEST(test_suspended_callable_activation);
    RUN_TEST(test_vm_retained_callbacks);

    printf("\n[Stack Ops: ROT3]\n");
    RUN_TEST(test_rot3);

    printf("\n[Indirect Call]\n");
    RUN_TEST(test_call_indirect);

    printf("\n[Array: Remove/Slice/Pop]\n");
    RUN_TEST(test_arr_remove);
    RUN_TEST(test_arr_slice);
    RUN_TEST(test_arr_pop);

    printf("\n[String: Substr/Contains/Eq/CharAt/FromFloat]\n");
    RUN_TEST(test_str_substr);
    RUN_TEST(test_str_contains);
    RUN_TEST(test_str_eq);
    RUN_TEST(test_str_char_at);
    RUN_TEST(test_str_from_float);

    printf("\n[Upvalue Store]\n");

    printf("\n[HashMap: Has/Delete/Keys/Values]\n");
    RUN_TEST(test_hm_has);
    RUN_TEST(test_hm_delete);
    RUN_TEST(test_hm_keys);
    RUN_TEST(test_hm_values);

    printf("\n[ADD: String/Array variants]\n");
    RUN_TEST(test_add_strings);
    RUN_TEST(test_add_array_array);
    RUN_TEST(test_add_array_scalar);
    RUN_TEST(test_array_arithmetic_values);
    RUN_TEST(test_array_read_index_contract);
    RUN_TEST(test_array_update_index_contract);
    RUN_TEST(test_scalar_arithmetic_boundaries);
    RUN_TEST(test_array_arithmetic_boundaries);
    RUN_TEST(test_array_arithmetic_strings);

    printf("\n[vm_error_string]\n");
    RUN_TEST(test_vm_error_string);

    printf("\n[Predecoded Dispatch]\n");
    RUN_TEST(test_predecode_malformed_bytecode);
    RUN_TEST(test_predecode_invalid_branch_target);
    RUN_TEST(test_predecode_invalidate_rebuild);
    RUN_TEST(test_predecode_resolves_branch_targets);
    RUN_TEST(test_predecode_resolves_call_targets);

    printf("\n[Optimized Dispatch IR]\n");
    RUN_TEST(test_dispatch_projects_branch_targets);
    RUN_TEST(test_dispatch_cursor_walks_stream);
    RUN_TEST(test_dispatch_lockstep_with_verified_ir);
    RUN_TEST(test_super_profile_none_leaves_stream_unfused);
    RUN_TEST(test_super_profile_fuses_local_field_load);
    RUN_TEST(test_super_fusion_preserves_result);
    RUN_TEST(test_super_fusion_keeps_branch_target_reachable);

    printf("\n[Float/mixed arithmetic]\n");
    RUN_TEST(test_add_float_int);
    RUN_TEST(test_sub_floats);
    RUN_TEST(test_sub_float_int);
    RUN_TEST(test_sub_int_float);
    RUN_TEST(test_mul_floats);
    RUN_TEST(test_mul_float_int);
    RUN_TEST(test_sub_array_array);
    RUN_TEST(test_mul_array_array);

    printf("\n[OP_STR_CONCAT]\n");
    RUN_TEST(test_str_concat_op);
    RUN_TEST(test_str_concat_type_error);

    printf("\n[Type error paths]\n");
    RUN_TEST(test_arr_push_type_error);
    RUN_TEST(test_str_len_type_error);
    RUN_TEST(test_struct_get_type_error);

    printf("\n[Verified Fast Path]\n");
    RUN_TEST(test_verified_fastpath_enabled);
    RUN_TEST(test_unverifiable_stays_checked);
    RUN_TEST(test_owned_transfers_require_runtime);
    RUN_TEST(test_ownership_contracts_refuse_checked_fallback);
    RUN_TEST(test_verified_flag_tracks_module_lifecycle);

    printf("\n=== Results: %d passed, %d failed, %d total ===\n",
           tests_passed, tests_failed, tests_run);

    return tests_failed > 0 ? 1 : 0;
}
