nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/assembler.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/assembler.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/local_bindings.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/verifier.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/isa.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h \
 /usr/include/stdio.h /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/ctype.h /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h /usr/include/errno.h \
 /usr/include/aarch64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/aarch64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h \
 /usr/include/limits.h /usr/include/aarch64-linux-gnu/bits/posix1_lim.h \
 /usr/include/aarch64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/aarch64-linux-gnu/bits/pthread_stack_min.h \
 /usr/include/aarch64-linux-gnu/bits/posix2_lim.h /usr/include/math.h \
 /usr/include/aarch64-linux-gnu/bits/math-vector.h \
 /usr/include/aarch64-linux-gnu/bits/libm-simd-decl-stubs.h \
 /usr/include/aarch64-linux-gnu/bits/flt-eval-method.h \
 /usr/include/aarch64-linux-gnu/bits/fp-logb.h \
 /usr/include/aarch64-linux-gnu/bits/fp-fast.h \
 /usr/include/aarch64-linux-gnu/bits/mathcalls-helper-functions.h \
 /usr/include/aarch64-linux-gnu/bits/mathcalls.h
