nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_bindings_module.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_codec_internal.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_bindings_module.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_bindings.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_file_nominal.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_socket_nominal.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_multi_nominal.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi_socket_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi_service_catalog.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi_file_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/service_classification_private.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/owned_array_admission.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/owned_array_authority.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/owned_array_origins.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/owned_array_layouts.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi_file_catalog.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/../nsi_file_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h
