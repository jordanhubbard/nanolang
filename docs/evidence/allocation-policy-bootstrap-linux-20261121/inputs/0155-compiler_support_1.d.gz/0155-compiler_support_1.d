nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h \
 /usr/include/stdio.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/aarch64-linux-gnu/sys/types.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/alloca.h /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/string.h /usr/include/strings.h /usr/include/ctype.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h /usr/include/assert.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h \
 src/runtime/dyn_array.h src/runtime/gc.h /usr/include/execinfo.h \
 /usr/include/unistd.h /usr/include/aarch64-linux-gnu/bits/posix_opt.h \
 /usr/include/aarch64-linux-gnu/bits/environments.h \
 /usr/include/aarch64-linux-gnu/bits/confname.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_posix.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_core.h \
 /usr/include/aarch64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/dyn_array.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_link_response.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/module_build_dir.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/assembler_capture.h \
 /usr/include/fcntl.h /usr/include/aarch64-linux-gnu/bits/fcntl.h \
 /usr/include/aarch64-linux-gnu/bits/fcntl-linux.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_iovec.h \
 /usr/include/linux/falloc.h /usr/include/aarch64-linux-gnu/bits/stat.h \
 /usr/include/aarch64-linux-gnu/bits/struct_stat.h \
 /usr/include/aarch64-linux-gnu/sys/stat.h \
 /usr/include/aarch64-linux-gnu/bits/statx.h /usr/include/linux/stat.h \
 /usr/include/linux/types.h /usr/include/aarch64-linux-gnu/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/aarch64-linux-gnu/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h \
 /usr/include/aarch64-linux-gnu/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/aarch64-linux-gnu/bits/statx-generic.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx_timestamp.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx.h \
 /usr/include/elf.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/utf8.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/shell_path.h \
 /usr/include/errno.h /usr/include/aarch64-linux-gnu/bits/errno.h \
 /usr/include/linux/errno.h /usr/include/aarch64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/aarch64-linux-gnu/bits/types/error_t.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h \
 /usr/include/limits.h /usr/include/aarch64-linux-gnu/bits/posix1_lim.h \
 /usr/include/aarch64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/aarch64-linux-gnu/bits/posix2_lim.h \
 /usr/include/aarch64-linux-gnu/bits/xopen_lim.h \
 /usr/include/aarch64-linux-gnu/bits/uio_lim.h /usr/include/time.h \
 /usr/include/aarch64-linux-gnu/bits/time.h \
 /usr/include/aarch64-linux-gnu/bits/timex.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/dirent.h /usr/include/aarch64-linux-gnu/bits/dirent.h \
 /usr/include/aarch64-linux-gnu/bits/dirent_ext.h \
 /usr/include/aarch64-linux-gnu/sys/file.h \
 /usr/include/aarch64-linux-gnu/sys/wait.h /usr/include/signal.h \
 /usr/include/aarch64-linux-gnu/bits/signum-generic.h \
 /usr/include/aarch64-linux-gnu/bits/signum-arch.h \
 /usr/include/aarch64-linux-gnu/bits/types/sig_atomic_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/siginfo_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigval_t.h \
 /usr/include/aarch64-linux-gnu/bits/siginfo-arch.h \
 /usr/include/aarch64-linux-gnu/bits/siginfo-consts.h \
 /usr/include/aarch64-linux-gnu/bits/siginfo-consts-arch.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigval_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigevent_t.h \
 /usr/include/aarch64-linux-gnu/bits/sigevent-consts.h \
 /usr/include/aarch64-linux-gnu/bits/sigaction.h \
 /usr/include/aarch64-linux-gnu/bits/sigcontext.h \
 /usr/include/aarch64-linux-gnu/asm/sigcontext.h \
 /usr/include/aarch64-linux-gnu/asm/sve_context.h \
 /usr/include/aarch64-linux-gnu/bits/types/stack_t.h \
 /usr/include/aarch64-linux-gnu/sys/ucontext.h \
 /usr/include/aarch64-linux-gnu/sys/procfs.h \
 /usr/include/aarch64-linux-gnu/sys/time.h \
 /usr/include/aarch64-linux-gnu/sys/user.h \
 /usr/include/aarch64-linux-gnu/bits/procfs.h \
 /usr/include/aarch64-linux-gnu/bits/procfs-id.h \
 /usr/include/aarch64-linux-gnu/bits/procfs-prregset.h \
 /usr/include/aarch64-linux-gnu/bits/procfs-extra.h \
 /usr/include/aarch64-linux-gnu/bits/sigstack.h \
 /usr/include/aarch64-linux-gnu/bits/sigstksz.h \
 /usr/include/aarch64-linux-gnu/bits/ss_flags.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_sigstack.h \
 /usr/include/aarch64-linux-gnu/bits/sigthread.h \
 /usr/include/aarch64-linux-gnu/bits/signal_ext.h \
 /usr/include/aarch64-linux-gnu/bits/types/idtype_t.h \
 /usr/include/spawn.h /usr/include/sched.h \
 /usr/include/aarch64-linux-gnu/bits/sched.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/aarch64-linux-gnu/bits/cpu-set.h \
 /usr/include/aarch64-linux-gnu/bits/spawn_ext.h /usr/include/poll.h \
 /usr/include/aarch64-linux-gnu/sys/poll.h \
 /usr/include/aarch64-linux-gnu/bits/poll.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/cJSON.h
