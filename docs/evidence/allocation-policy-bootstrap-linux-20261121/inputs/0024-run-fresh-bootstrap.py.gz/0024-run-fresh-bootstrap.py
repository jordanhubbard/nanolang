from pathlib import Path
import os,subprocess,time,json,hashlib
root=Path.cwd();out=root/'.test_output/fresh-bootstrap';out.mkdir(exist_ok=False)
env=dict(os.environ)
for name in ['NANO_CC','NANO_CFLAGS','NANO_LDFLAGS','NANOLANG_BOOTSTRAP_NO_CC','NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANOLANG_TRANSLATOR_SOURCE_MODULE']:
 env.pop(name,None)
env.update(PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_BUILD_CACHE=str(root/'obj/module_cache'),NANO_MODULE_PATH='modules',NANOLANG_ROOT=str(root),NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_SHADOW_TIMEOUT_SECONDS='30',NANO_COMPILER_PHASE_RECORDER=str(root/'.test_output/bootstrap-phase-recorder.py'),NANO_BOOTSTRAP_PHASE_FILE=str(out/'phases.jsonl'))
record=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),root=str(root),environment={k:env[k] for k in ['PATH','CC','NANO_BUILD_CACHE','NANO_MODULE_PATH','NANO_AS_CAPTURE_HELPER','NANO_SHADOW_TIMEOUT_SECONDS']},steps=[],limits=['I build original source tools and run my real Make bootstrap3 in a fresh fixed checkout. Each generation retains1800 seconds; complete compiler shadows retain30. I require exact raw bytes, unchanged closure, native smoke and installed refusal checks. I preserve failed commands and never reset refusal markers.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,timeout):
 t=time.monotonic();entry=dict(label=label,argv=argv);record['steps'].append(entry);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(argv,env=env,stdout=a,stderr=b);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  finally:entry['elapsed_seconds']=time.monotonic()-t;save()
 if entry['returncode']:raise RuntimeError(entry)
run(['make','-j8','CC=/usr/bin/cc','nano_virt','nano_vm','nanoisa_dump','nvm2c','nvm2c-runtime','bin/nano_as_capture.so'],'build-original-tools',1200)
run(['make','CC=/usr/bin/cc','test-nanovm','test-vm-heap-allocation-sanitizers','test-record-map-heap','test-record-map-ordinary-heap','test-record-map-string-heap'],'vm-heap-regressions',1200)
run(['make','CC=/usr/bin/cc','BOOTSTRAP_NANOISA_TIMEOUT=1800','bootstrap3'],'complete-bootstrap3',7200)
record['final_status']=subprocess.check_output(['git','status','--short'],text=True);save();assert not record['final_status'];print('I passed my fresh complete original Make bootstrap and selected VM/heap controls.')
