from pathlib import Path
import gzip,hashlib,json,re
root=Path.cwd();fresh=Path('/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121');base=fresh/'.test_output';work=fresh/'obj/bootstrap-nanoisa/run-focw0g5q';analysis=json.loads((base/'fresh-bootstrap/final-analysis.json').read_text());dest=root/'docs/evidence/allocation-policy-bootstrap-linux-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__)}
for directory in [base/'fresh-bootstrap',base/'fresh-native-controls',work]:
 paths.update(p for p in directory.rglob('*') if p.is_file())
for pattern in ['run-fresh*.py','run-fresh*.log','retain-fresh*.py','retain-fresh*.log','bootstrap-phase-recorder.py']:
 paths.update(base.glob(pattern))
for name in ['bin/nanoc_c','bin/nanoc_seed.nvm','bin/nanoc_stage1.nvm','bin/nanoc_stage2.nvm','bin/nanoc_stage1','bin/nanoc_stage2','bin/nanoc_bootstrap.json','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so','Makefile.gnu','scripts/bootstrap_nanoisa.py','tests/bootstrap_native_guard.py','scripts/verify_no_nanoc_c.sh','src/nanovm/heap.c','src/nanovm/heap_cycles.c','src/nanovm/heap.h','src/nanovm/bstring_intrinsics.inc','src/nanovm/vm.c','tests/nanovm/test_vm.c','src_nano/nanoc_v06.nano']:
 p=fresh/name
 if p.is_file():paths.add(p)
paths.update(p for p in (fresh/'obj/nanovm').glob('test*') if p.is_file() and p.suffix not in ('.o','.d'))
for library in analysis['hosts']:
 paths.update(p for p in Path(library).parent.rglob('*') if p.is_file())
log=(base/'fresh-bootstrap/vm-heap-regressions.stdout').read_text()
for directory in re.findall(r'I retain (?:heap|ordinary heap|string heap) artifacts at (/[^\n]+)',log):
 p=Path(directory)
 if p.is_dir():paths.update(x for x in p.rglob('*') if x.is_file())
sha=lambda raw:hashlib.sha256(raw).hexdigest();entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,analysis=analysis),indent=2)+'\n')
for entry in entries:
 packed=(dest/entry['artifact']).read_bytes();assert sha(packed)==entry['compressed_sha256'] and sha(gzip.decompress(packed))==entry['sha256']
print(len(entries),sum(e['bytes'] for e in entries),sum(p.stat().st_size for p in seen.values()))
