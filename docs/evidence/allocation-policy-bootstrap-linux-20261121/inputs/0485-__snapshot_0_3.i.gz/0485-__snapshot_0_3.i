# 0 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.h" 2



# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.h"
    nvm_passive_valid(const NvmModule *module);
# 2 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 3 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 2



# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
typedef struct { const uint8_t *p; size_t left; 
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                               _Bool 
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                    ok; } Reader;
static uint32_t word(Reader *r) {
    if (r->left < 4) { r->ok = 
# 8 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                              0
# 8 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                   ; return 0; }
    const uint8_t *p = r->p;
    uint32_t v = (uint32_t)p[0] | (uint32_t)p[1] << 8 |
                 (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
    r->p += 4; r->left -= 4; return v;
}
typedef struct {
    uint32_t entry, exit, result, dependencies, reads;
    const uint8_t *deps, *inputs;
    
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        done;
} Node;
static uint32_t at(const uint8_t *p, uint32_t index) {
    Reader r = {p + (size_t)index * 4, 4, 
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                         1
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                             }; return word(&r);
}
static 
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           contains(const uint8_t *p, uint32_t count, uint32_t value) {
    for (uint32_t i = 0; i < count; ++i) if (at(p, i) == value) return 
# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                      1
# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                          ;
    return 
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
          0
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
               ;
}
static 
# 26 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 26 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           scalar(uint8_t tag) {
    return tag == TAG_INT || tag == TAG_BOOL || tag == TAG_FLOAT ||
           tag == TAG_U8 || tag == TAG_STRING;
}

static 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           guarded_input(const NvmModule *m, uint32_t function,
                          uint32_t input, uint32_t entry) {
    const NvmFunctionEntry *f = &m->functions[function];
    if (!m->function_param_types || !m->function_param_types[function]) return 
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                              0
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                   ;
    uint32_t pc = f->code_offset, previous = 0;
    
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        first = 
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                1
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                    ;
    while (pc < entry) {
        DecodedInstruction guard[3];
        for (unsigned i = 0; i < 3; ++i) {
            if (pc >= entry) return 
# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                   0
# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                        ;
            uint32_t length = isa_decode(m->code + pc, entry - pc, &guard[i]);
            if (!length) return 
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                               0
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                    ;
            pc += length;
        }
        if (guard[0].opcode != OP_LOAD_LOCAL || guard[1].opcode != OP_TYPE_CHECK ||
            guard[2].opcode != OP_ASSERT) return 
# 46 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                0
# 46 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                     ;
        uint32_t parameter = guard[0].operands[0].u16;
        if (parameter >= f->arity || (!first && parameter <= previous)) return 
# 48 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                              0
# 48 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                   ;
        uint8_t tag = m->function_param_types[function][parameter];
        if (!scalar(tag) || tag == TAG_U8 || guard[1].operands[0].u8 != tag) return 
# 50 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                   0
# 50 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                        ;
        if (parameter == input) return 
# 51 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                      1
# 51 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                          ;
        if (parameter > input) return 
# 52 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                     0
# 52 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                          ;
        previous = parameter;
        first = 
# 54 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
               0
# 54 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                    ;
    }
    return 
# 56 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
          0
# 56 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
               ;
}
static 
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           allowed(uint8_t op, uint32_t version) {
    switch (op) {
    case OP_NOP: case OP_PUSH_I64: case OP_PUSH_F64: case OP_PUSH_BOOL:
    case OP_PUSH_U8: case OP_PUSH_STR: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_DUP: case OP_POP: case OP_SWAP: case OP_ROT3:
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_AND: case OP_OR: case OP_NOT:
        return 
# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
              1
# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                  ;
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
    case OP_I64_REM_S: case OP_I64_NEG: case OP_I64_EQ: case OP_I64_NE:
    case OP_I64_LT_S: case OP_I64_LE_S: case OP_I64_GT_S: case OP_I64_GE_S:
    case OP_F64_FROM_BITS: case OP_F64_TO_BITS:
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV:
    case OP_F64_NEG: case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT:
    case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
    case OP_BOOL_AND: case OP_BOOL_OR: case OP_BOOL_NOT: case OP_STR_CONCAT:
        return version == 2;
    default: return 
# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                   0
# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                        ;
    }
}
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 1
# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
typedef struct {
    DecodedInstruction instruction;
    uint32_t pc, length;
    int32_t height;
    
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
        queued;
} ClosedInstruction;
typedef struct {
    const NvmModule *module;
    uint8_t *state;
    uint32_t depth;
} ClosedCalls;

static uint32_t closed_target(const ClosedInstruction *code, uint32_t count,
                              uint32_t target) {
    uint32_t low = 0, high = count;
    while (low < high) {
        uint32_t mid = low + (high - low) / 2;
        if (code[mid].pc < target) low = mid + 1;
        else high = mid;
    }
    return low < count && code[low].pc == target ? low : count;
}
static 
# 32 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
      _Bool 
# 32 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
           closed_function(ClosedCalls *calls, uint32_t index) {
    const NvmModule *m = calls->module;
    if (index >= m->function_count || calls->depth >= 64u) return 
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                                                0
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                                     ;
    if (calls->state[index]) return calls->state[index] == 2;
    const NvmFunctionEntry *f = &m->functions[index];
    if (f->upvalue_count || f->arity > f->local_count || f->result_count > 1 ||
        !f->code_length || f->code_offset > m->code_size ||
        f->code_length > m->code_size - f->code_offset) return 
# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                              0
# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                   ;
    calls->state[index] = 1;
    calls->depth++;
    
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
   _Bool 
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
        ok = 
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
             1
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                 , returns = 
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                             0
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                  ;
    uint32_t count = 0, end = f->code_offset + f->code_length;
    for (uint32_t pc = f->code_offset; pc < end;) {
        DecodedInstruction d;
        uint32_t length = isa_decode(m->code + pc, end - pc, &d);
        if (!length || count == 65536u) { ok = 
# 47 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                          0
# 47 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                               ; break; }
        ++count; pc += length;
    }
    uint32_t width = (f->local_count + 63u) / 64u;
    if (!width) width = 1;
    if (!ok || count > 2097152u / width) {
        calls->state[index] = 3; calls->depth--; return 
# 53 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                       0
# 53 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                            ;
    }
    ClosedInstruction *code = calloc(count, sizeof(*code));
    uint64_t *locals = calloc((size_t)count * width, sizeof(*locals));
    uint64_t *out = calloc(width, sizeof(*out));
    uint32_t *queue = calloc(count, sizeof(*queue));
    if (!code || !locals || !out || !queue) { ok = 
# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                  0
# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                       ; goto done; }
    uint32_t pc = f->code_offset;
    for (uint32_t i = 0; i < count; ++i) {
        code[i].pc = pc;
        code[i].length = isa_decode(m->code + pc, end - pc, &code[i].instruction);
        code[i].height = -1;
        pc += code[i].length;
    }
    for (uint32_t i = 0; i < f->arity; ++i) locals[i / 64] |= 1UL << (i % 64);
    code[0].height = 0; code[0].queued = 
# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                        1
# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                            ;
    uint32_t head = 0, tail = 0, pending = 1, steps = 0;
    queue[tail++] = 0; if (tail == count) tail = 0;
    while (ok && pending) {
        if (++steps > 1048576u) { ok = 
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                0
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                     ; break; }
        uint32_t i = queue[head++]; if (head == count) head = 0;
        --pending; code[i].queued = 
# 74 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                   0
# 74 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                        ;
        DecodedInstruction *d = &code[i].instruction;
        const InstructionInfo *info = isa_get_info(d->opcode);
        if (!info) { ok = 
# 77 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                         0
# 77 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                              ; break; }
        int32_t pop = info->pop_count, push = info->push_count;
        
# 79 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
       _Bool 
# 79 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
            branch = d->opcode == OP_JMP || d->opcode == OP_JMP_TRUE || d->opcode == OP_JMP_FALSE;
        if ((d->opcode == OP_CALL || d->opcode == OP_TAIL_CALL)) {
            uint32_t callee = d->operands[0].u32;
            if (!closed_function(calls, callee)) { ok = 
# 82 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                       0
# 82 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                            ; break; }
            pop = m->functions[callee].arity; push = m->functions[callee].result_count;
        } else if (d->opcode == OP_RET) {
            pop = f->result_count; push = 0;
        } else if (!allowed(d->opcode, 2) && !branch &&
                   d->opcode != OP_TYPE_CHECK && d->opcode != OP_ASSERT &&
                   d->opcode != OP_CAST_INT && d->opcode != OP_CAST_FLOAT &&
                   d->opcode != OP_CAST_BOOL && d->opcode != OP_CAST_STRING) {
            ok = 
# 90 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                0
# 90 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                     ; break;
        }
        if (pop < 0 || push < 0 || code[i].height < pop ||
            code[i].height - pop > 
# 93 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                  (2147483647) 
# 93 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                            - push) { ok = 
# 93 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                           0
# 93 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                ; break; }
        int32_t height = code[i].height - pop + push;
        for (uint32_t w = 0; w < width; ++w) out[w] = locals[(size_t)i * width + w];
        if (d->opcode == OP_LOAD_LOCAL || d->opcode == OP_STORE_LOCAL) {
            uint32_t local = d->operands[0].u16;
            if (local >= f->local_count) { ok = 
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                               0
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                    ; break; }
            if (d->opcode == OP_STORE_LOCAL) out[local / 64] |= 1UL << (local % 64);
        }
        if (d->opcode == OP_RET || d->opcode == OP_TAIL_CALL) {
            if (d->opcode == OP_RET ? height != 0 :
                (height != f->result_count || m->functions[d->operands[0].u32].result_count != f->result_count)) ok = 
# 103 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                                                                                     0
# 103 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                                                                          ;
            returns = 
# 104 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                     1
# 104 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                         ; continue;
        }
        uint32_t next[2], nnext = 0;
        if (branch) {
            int64_t target = (int64_t)code[i].pc + d->operands[0].i32;
            if (target < f->code_offset || target >= end) { ok = 
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                                0
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                     ; break; }
            next[nnext++] = closed_target(code, count, (uint32_t)target);
        }
        if (d->opcode != OP_JMP) next[nnext++] = i + 1;
        for (uint32_t edge = 0; ok && edge < nnext; ++edge) {
            uint32_t j = next[edge];
            if (j >= count) { ok = 
# 115 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                  0
# 115 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                       ; break; }
            
# 116 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
           _Bool 
# 116 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                fresh = code[j].height < 0, changed = fresh;
            if (!fresh && code[j].height != height) { ok = 
# 117 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                          0
# 117 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                               ; break; }
            code[j].height = height;
            for (uint32_t w = 0; w < width; ++w) {
                uint64_t *slot = &locals[(size_t)j * width + w];
                uint64_t value = fresh ? out[w] : *slot & out[w];
                if (*slot != value) changed = 
# 122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                             1
# 122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                 ;
                *slot = value;
            }
            if (changed && !code[j].queued) {
                code[j].queued = 
# 126 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                1
# 126 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                    ; queue[tail++] = j;
                if (tail == count) tail = 0;
                ++pending;
            }
        }
    }

    for (uint32_t i = 0; ok && i < count; ++i) {
        if (code[i].height < 0 || code[i].instruction.opcode != OP_LOAD_LOCAL) continue;
        uint32_t local = code[i].instruction.operands[0].u16;
        if (!(locals[(size_t)i * width + local / 64] & (1UL << (local % 64)))) ok = 
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc" 3 4
                                                                                           0
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive_calls.inc"
                                                                                                ;
    }
done:
    free(code); free(locals); free(out); free(queue);
    calls->state[index] = ok && returns ? 2 : 3;
    calls->depth--;
    return calls->state[index] == 2;
}
# 80 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 2




typedef struct {
    uint32_t pc, length;
    int64_t height;
} PassiveInstruction;
static uint32_t passive_target(const PassiveInstruction *code, uint32_t count,
                               uint32_t target) {
    uint32_t low = 0, high = count;
    while (low < high) {
        uint32_t mid = low + (high - low) / 2;
        if (code[mid].pc < target) low = mid + 1;
        else high = mid;
    }
    return low < count && code[low].pc == target ? low : count;
}
static 
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           node_cfg(const NvmModule *m, const NvmFunctionEntry *f,
                     Node *nodes, uint32_t count, uint32_t index, ClosedCalls *calls) {
    const Node *n = &nodes[index];
    uint32_t instructions = 0;
    for (uint32_t pc = n->entry; pc < n->exit;) {
        DecodedInstruction d;
        uint32_t length = isa_decode(m->code + pc, n->exit - pc, &d);
        if (!length || instructions == 65536u) return 
# 105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                 0
# 105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                      ;
        ++instructions; pc += length;
    }
    PassiveInstruction *code = calloc(instructions, sizeof(*code));
    
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        *seen_deps = calloc(count, sizeof(*seen_deps));
    
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        *seen_reads = calloc(f->arity ? f->arity : 1, sizeof(*seen_reads));
    
# 111 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 111 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        ok = code && seen_deps && seen_reads;
    if (!ok) goto done;
    uint32_t pc = n->entry;
    for (uint32_t i = 0; i < instructions; ++i) {
        DecodedInstruction d;
        code[i].pc = pc;
        code[i].length = isa_decode(m->code + pc, n->exit - pc, &d);
        code[i].height = -1;
        pc += code[i].length;
    }
    code[0].height = 0;
    for (uint32_t i = 0; ok && i < instructions; ++i) {
        DecodedInstruction d;
        isa_decode(m->code + code[i].pc, code[i].length, &d);
        
# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
       _Bool 
# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
            branch = d.opcode == OP_JMP || d.opcode == OP_JMP_TRUE || d.opcode == OP_JMP_FALSE;
        const InstructionInfo *info = isa_get_info(d.opcode);
        if (code[i].height < 0 || !info ||
            (!allowed(d.opcode, 2) && d.opcode != OP_CALL && !branch)) { ok = 
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                             0
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                  ; break; }
        int32_t pop = info->pop_count, push = info->push_count;
        if (d.opcode == OP_CALL) {
            uint32_t callee = d.operands[0].u32;
            if (!closed_function(calls, callee)) { ok = 
# 132 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                       0
# 132 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                            ; break; }
            pop = m->functions[callee].arity; push = m->functions[callee].result_count;
        }
        if (pop < 0 || push < 0 || code[i].height < pop ||
            code[i].height - pop > 
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                  (4294967295U) 
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                             - (uint32_t)push) { ok = 
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                      0
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                           ; break; }
        int64_t height = code[i].height - pop + push;
        if (d.opcode == OP_STORE_LOCAL) {
            if (i + 1 != instructions || d.operands[0].u16 != n->result || height) ok = 
# 139 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                       0
# 139 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                            ;
            continue;
        }
        if (i + 1 == instructions) { ok = 
# 142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                         0
# 142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                              ; break; }
        if (d.opcode == OP_LOAD_LOCAL) {
            uint32_t local = d.operands[0].u16, producer = count;
            for (uint32_t j = 0; j < count; ++j) if (nodes[j].result == local) producer = j;
            if (producer < count) {
                if (!contains(n->deps, n->dependencies, producer)) ok = 
# 147 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                       0
# 147 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                            ;
                seen_deps[producer] = 
# 148 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                     1
# 148 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                         ;
            } else if (local >= f->arity || !contains(n->inputs, n->reads, local)) ok = 
# 149 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                       0
# 149 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                            ;
            else seen_reads[local] = 
# 150 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                    1
# 150 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                        ;
        }
        uint32_t next[2], successors = 0;
        if (branch) {
            int64_t target = (int64_t)code[i].pc + d.operands[0].i32;
            if (target <= code[i].pc || target >= n->exit) { ok = 
# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                 0
# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                      ; break; }
            next[successors++] = passive_target(code, instructions, (uint32_t)target);
        }
        if (d.opcode != OP_JMP) next[successors++] = i + 1;
        for (uint32_t edge = 0; ok && edge < successors; ++edge) {
            uint32_t j = next[edge];
            if (j >= instructions || (code[j].height >= 0 && code[j].height != height)) ok = 
# 161 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                            0
# 161 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                                 ;
            else code[j].height = height;
        }
    }
    for (uint32_t i = 0; ok && i < n->dependencies; ++i)
        if (!seen_deps[at(n->deps, i)]) ok = 
# 166 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                            0
# 166 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                 ;
    for (uint32_t i = 0; ok && i < n->reads; ++i)
        if (!seen_reads[at(n->inputs, i)]) ok = 
# 168 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                               0
# 168 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                    ;
done:
    free(code); free(seen_deps); free(seen_reads);
    return ok;
}

static 
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           internal_node_edge(const Node *nodes, uint32_t count,
                               uint32_t pc, int64_t target, uint32_t version) {
    if (version != 2) return 
# 176 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                            0
# 176 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                 ;
    for (uint32_t i = 0; i < count; ++i)
        if (pc >= nodes[i].entry && pc < nodes[i].exit &&
            target > pc && target < nodes[i].exit) return 
# 179 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                         1
# 179 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                             ;
    return 
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
          0
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
               ;
}

static 
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           node_code(const NvmModule *m, const NvmFunctionEntry *f,
                      Node *nodes, uint32_t count, uint32_t index, uint32_t version, ClosedCalls *calls) {
    if (version == 2) return node_cfg(m, f, nodes, count, index, calls);
    Node *n = &nodes[index];
    uint32_t depth = 0;
    
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        *seen_deps = calloc(count, sizeof(
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                          _Bool
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                              ));
    
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        *seen_reads = calloc(f->arity ? f->arity : 1, sizeof(
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                             _Bool
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                 ));
    if (!seen_deps || !seen_reads) { free(seen_deps); free(seen_reads); return 
# 190 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                              0
# 190 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                   ; }
    
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        ok = 
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
             1
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                 ;
    for (uint32_t pc = n->entry; ok && pc < n->exit;) {
        DecodedInstruction d;
        uint32_t length = isa_decode(m->code + pc, n->exit - pc, &d);
        if (!length || (!allowed(d.opcode, version) && !(version == 2 && d.opcode == OP_CALL))) { ok = 
# 195 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                                      0
# 195 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                                           ; break; }
        const InstructionInfo *info = isa_get_info(d.opcode);
        if (!info) { ok = 
# 197 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                         0
# 197 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                              ; break; }
        int32_t pop = info->pop_count, push = info->push_count;
        if (d.opcode == OP_CALL) {
            uint32_t callee = d.operands[0].u32;
            if (!closed_function(calls, callee)) { ok = 
# 201 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                       0
# 201 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                            ; break; }
            pop = m->functions[callee].arity; push = m->functions[callee].result_count;
        }
        if (pop < 0 || push < 0 || depth < (uint32_t)pop ||
            depth - (uint32_t)pop > 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                   (4294967295U) 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                              - (uint32_t)push) { ok = 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                       0
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                            ; break; }
        depth = depth - (uint32_t)pop + (uint32_t)push;
        if (d.opcode == OP_STORE_LOCAL) {
            if (pc + length != n->exit || d.operands[0].u16 != n->result || depth != 0) ok = 
# 208 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                            0
# 208 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                                 ;
        } else if (pc + length == n->exit) ok = 
# 209 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                               0
# 209 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                    ;
        if (d.opcode == OP_LOAD_LOCAL) {
            uint32_t local = d.operands[0].u16;
            uint32_t producer = count;
            for (uint32_t j = 0; j < count; ++j) if (nodes[j].result == local) producer = j;
            if (producer < count) {
                if (!contains(n->deps, n->dependencies, producer)) ok = 
# 215 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                       0
# 215 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                            ;
                seen_deps[producer] = 
# 216 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                     1
# 216 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                         ;
            } else {
                if (local >= f->arity || !contains(n->inputs, n->reads, local)) ok = 
# 218 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                    0
# 218 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                         ;
                else seen_reads[local] = 
# 219 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                        1
# 219 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                            ;
            }
        }
        pc += length;
    }
    for (uint32_t i = 0; i < n->dependencies; ++i) if (!seen_deps[at(n->deps, i)]) ok = 
# 224 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                       0
# 224 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                            ;
    for (uint32_t i = 0; i < n->reads; ++i) if (!seen_reads[at(n->inputs, i)]) ok = 
# 225 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                   0
# 225 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                        ;
    free(seen_deps); free(seen_reads);
    return ok && depth == 0;
}
static 
# 229 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
      _Bool 
# 229 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
           block(Reader *r, const NvmModule *m, uint32_t *previous_function,
                  uint32_t *previous_exit, 
# 230 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                          _Bool 
# 230 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                               first, uint32_t version, ClosedCalls *calls) {
    uint32_t kind = word(r), function = word(r), entry = word(r), exit = word(r), count = word(r);
    if (!r->ok || (kind != 1 && kind != 2) || function >= m->function_count ||
        !count || count > r->left / 28 || entry >= exit || exit > m->code_size) return 
# 233 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                      0
# 233 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                           ;
    const NvmFunctionEntry *f = &m->functions[function];
    if (f->code_offset > m->code_size || f->code_length > m->code_size - f->code_offset ||
        entry < f->code_offset || exit > f->code_offset + f->code_length ||
        (!first && (function < *previous_function || (function == *previous_function && entry < *previous_exit)))) return 
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                                                         0
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                                                              ;
    Node *nodes = calloc(count, sizeof(Node));
    if (!nodes) return 
# 239 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                      0
# 239 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                           ;
    
# 240 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 240 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        ok = 
# 240 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
             1
# 240 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                 ;
    for (uint32_t i = 0; ok && i < count; ++i) {
        Node *n = &nodes[i];
        n->entry = word(r); n->exit = word(r); n->result = word(r);
        n->dependencies = word(r); n->reads = word(r);
        uint32_t effects = word(r), resources = word(r);
        if (!r->ok || effects || resources || n->entry < entry || n->exit > exit ||
            n->entry >= n->exit || n->result < f->arity || n->result >= f->local_count ||
            n->dependencies > count || (version == 1 && n->reads != 0) ||
            (uint64_t)n->dependencies + n->reads > r->left / 4 || (kind == 1 && n->dependencies)) { ok = 
# 249 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                                        0
# 249 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                                             ; break; }
        n->deps = r->p;
        for (uint32_t j = 0; j < n->dependencies; ++j) {
            uint32_t d = word(r);
            if (d >= count || d == i || (j && d <= at(n->deps, j - 1))) ok = 
# 253 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                            0
# 253 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                 ;
        }
        n->inputs = r->p;
        for (uint32_t j = 0; j < n->reads; ++j) {
            uint32_t input = word(r);
            if (input >= f->arity || (j && input <= at(n->inputs, j - 1)) ||
                !m->function_param_types || !m->function_param_types[function] ||
                (input < f->arity && (!scalar(m->function_param_types[function][input]) ||
                 !guarded_input(m, function, input, entry)))) ok = 
# 261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                  0
# 261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                       ;
        }
        for (uint32_t j = 0; j < i; ++j) if (nodes[j].result == n->result) ok = 
# 263 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                               0
# 263 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                    ;
    }

    uint32_t cursor = entry;
    for (uint32_t step = 0; ok && step < count; ++step) {
        uint32_t selected = count;
        for (uint32_t i = 0; i < count; ++i) {
            if (nodes[i].done) continue;
            
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
           _Bool 
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                ready = 
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                        1
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                            ;
            for (uint32_t j = 0; j < nodes[i].dependencies; ++j)
                if (!nodes[at(nodes[i].deps, j)].done) ready = 
# 273 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                              0
# 273 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                   ;
            if (ready) { selected = i; break; }
        }
        if (selected == count || nodes[selected].entry != cursor) { ok = 
# 276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                        0
# 276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                             ; break; }
        ok = node_code(m, f, nodes, count, selected, version, calls);
        cursor = nodes[selected].exit; nodes[selected].done = 
# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                             1
# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                 ;
    }
    if (cursor != exit) ok = 
# 280 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                            0
# 280 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                 ;


    
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        saw_entry = 
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                    0
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                         , saw_exit = exit == f->code_offset + f->code_length;
    for (uint32_t pc = f->code_offset; ok && pc < f->code_offset + f->code_length;) {
        DecodedInstruction d;
        uint32_t length = isa_decode(m->code + pc, f->code_offset + f->code_length - pc, &d);
        if (!length) { ok = 
# 287 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                           0
# 287 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                ; break; }
        if (!allowed(d.opcode, version) && d.opcode != OP_JMP && d.opcode != OP_JMP_TRUE &&
            d.opcode != OP_JMP_FALSE && d.opcode != OP_RET && d.opcode != OP_HALT &&
            d.opcode != OP_PRINT && d.opcode != OP_PRINTLN && d.opcode != OP_ASSERT &&
            !(version == 2 && (d.opcode == OP_TYPE_CHECK ||
              d.opcode == OP_CALL))) {
            ok = 
# 293 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                0
# 293 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                     ; break;
        }
        if (pc == entry) saw_entry = 
# 295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                    1
# 295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                        ;
        if (pc == exit) saw_exit = 
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                  1
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                      ;
        if (d.opcode == OP_JMP || d.opcode == OP_JMP_TRUE || d.opcode == OP_JMP_FALSE) {

            int64_t target = (int64_t)pc + d.operands[0].i32;
            if (target > entry && target < exit &&
                !internal_node_edge(nodes, count, pc, target, version)) ok = 
# 301 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                            0
# 301 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                 ;
        }
        if (d.opcode == OP_STORE_LOCAL) {
            uint32_t local = d.operands[0].u16;
            for (uint32_t i = 0; i < count; ++i)
                if (contains(nodes[i].inputs, nodes[i].reads, local)) ok = 
# 306 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                          0
# 306 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                               ;
        }
        pc += length;
    }
    free(nodes);
    *previous_function = function; *previous_exit = exit;
    return ok && saw_entry && saw_exit;
}

# 314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
_Bool 
# 314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
    nvm_passive_valid(const NvmModule *m) {
    if (!m) return 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                  0
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                       ;
    if (!m->passive_size) return m->passive_data == 
# 316 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                   ((void *)0)
# 316 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                       ;
    if (!m->passive_data || !m->code || !m->functions) return 
# 317 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                             0
# 317 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                  ;
    Reader r = {m->passive_data, m->passive_size, 
# 318 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                 1
# 318 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                     };
    uint32_t version = word(&r), count = word(&r);
    if (!r.ok || (version != 1 && version != 2) || !count || count > r.left / 48) return 
# 320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                                                                                        0
# 320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                                                                             ;
    uint32_t function = 0, exit = 0;
    ClosedCalls calls = {m, 
# 322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                           ((void *)0)
# 322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                               , 0};
    calls.state = calloc(m->function_count ? m->function_count : 1, 1);
    if (!calls.state) return 
# 324 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
                            0
# 324 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                                 ;
    
# 325 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
   _Bool 
# 325 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
        ok = 
# 325 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c" 3 4
             1
# 325 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanoisa/passive.c"
                 ;
    for (uint32_t i = 0; ok && i < count; ++i)
        ok = block(&r, m, &function, &exit, i == 0, version, &calls);


    free(calls.state);
    return ok && r.ok && r.left == 0;
}
