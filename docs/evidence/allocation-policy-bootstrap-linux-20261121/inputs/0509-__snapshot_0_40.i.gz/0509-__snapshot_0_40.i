# 0 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"




# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 1
# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 1
# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4
# 53 "/usr/include/stdio.h" 3 4
typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;
# 78 "/usr/include/stdio.h" 3 4
typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 184 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 211 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 236 "/usr/include/stdio.h" 3 4
extern int fflush (FILE *__stream);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 299 "/usr/include/stdio.h" 3 4
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 314 "/usr/include/stdio.h" 3 4
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 357 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 410 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4
# 463 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 540 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 635 "/usr/include/stdio.h" 3 4
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
# 654 "/usr/include/stdio.h" 3 4
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 779 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 860 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 878 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
# 941 "/usr/include/stdio.h" 3 4
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"

# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 2





typedef struct VmString VmString;
typedef struct VmBString VmBString;
typedef struct VmArray VmArray;
typedef struct VmStruct VmStruct;
typedef struct VmUnion VmUnion;
typedef struct VmTuple VmTuple;
typedef struct VmHashMap VmHashMap;
typedef struct VmClosure VmClosure;





typedef struct {
    uint8_t tag;


    uint32_t callable_module;
    union {
        int64_t i64;
        double f64;
        uint8_t u8;
        
# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
       _Bool 
# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                boolean;
        int32_t enum_val;
        uint32_t fn_idx;
        uint32_t proxy_id;


        VmString *string;
        VmArray *array;
        VmStruct *sval;
        VmUnion *uval;
        VmTuple *tuple;
        VmHashMap *hashmap;
        VmClosure *closure;
        void *obj;
    } as;
} NanoValue;





static inline NanoValue val_void(void) {
    NanoValue v = {0};
    v.tag = TAG_VOID;
    return v;
}

static inline NanoValue val_int(int64_t n) {
    NanoValue v = {0};
    v.tag = TAG_INT;
    v.as.i64 = n;
    return v;
}

static inline NanoValue val_float(double d) {
    NanoValue v = {0};
    v.tag = TAG_FLOAT;
    v.as.f64 = d;
    return v;
}

static inline NanoValue val_bool(
# 84 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
                                _Bool 
# 84 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                                     b) {
    NanoValue v = {0};
    v.tag = TAG_BOOL;
    v.as.boolean = b;
    return v;
}

static inline NanoValue val_u8(uint8_t b) {
    NanoValue v = {0};
    v.tag = TAG_U8;
    v.as.u8 = b;
    return v;
}

static inline NanoValue val_string(VmString *s) {
    NanoValue v = {0};
    v.tag = TAG_STRING;
    v.as.string = s;
    return v;
}

static inline NanoValue val_bstring(VmBString *s) {
    NanoValue v = {0};
    v.tag = TAG_BSTRING;
    v.as.obj = s;
    return v;
}

static inline NanoValue val_array(VmArray *a) {
    NanoValue v = {0};
    v.tag = TAG_ARRAY;
    v.as.array = a;
    return v;
}

static inline NanoValue val_struct(VmStruct *s) {
    NanoValue v = {0};
    v.tag = TAG_STRUCT;
    v.as.sval = s;
    return v;
}

static inline NanoValue val_enum(int32_t variant) {
    NanoValue v = {0};
    v.tag = TAG_ENUM;
    v.as.enum_val = variant;
    return v;
}

static inline NanoValue val_union(VmUnion *u) {
    NanoValue v = {0};
    v.tag = TAG_UNION;
    v.as.uval = u;
    return v;
}

static inline NanoValue val_function(uint32_t fn_idx) {
    NanoValue v = {0};
    v.tag = TAG_FUNCTION;
    v.callable_module = 1;
    v.as.fn_idx = fn_idx;
    return v;
}

static inline NanoValue val_function_owned(uint32_t fn_idx, uint32_t module_id) {
    NanoValue v = val_function(fn_idx);
    v.callable_module = module_id;
    return v;
}

static inline NanoValue val_tuple(VmTuple *t) {
    NanoValue v = {0};
    v.tag = TAG_TUPLE;
    v.as.tuple = t;
    return v;
}

static inline NanoValue val_hashmap(VmHashMap *h) {
    NanoValue v = {0};
    v.tag = TAG_HASHMAP;
    v.as.hashmap = h;
    return v;
}

static inline NanoValue val_closure(VmClosure *c) {
    NanoValue v = {0};
    v.tag = TAG_CLOSURE;
    v.as.closure = c;
    return v;
}





static inline 
# 179 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 179 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_int(NanoValue v) { return v.tag == TAG_INT; }
static inline 
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_float(NanoValue v) { return v.tag == TAG_FLOAT; }
static inline 
# 181 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 181 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_bool(NanoValue v) { return v.tag == TAG_BOOL; }
static inline 
# 182 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 182 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_string(NanoValue v) { return v.tag == TAG_STRING; }
static inline 
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_array(NanoValue v) { return v.tag == TAG_ARRAY; }
static inline 
# 184 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 184 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_struct(NanoValue v) { return v.tag == TAG_STRUCT; }
static inline 
# 185 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 185 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_union(NanoValue v) { return v.tag == TAG_UNION; }
static inline 
# 186 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 186 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_tuple(NanoValue v) { return v.tag == TAG_TUPLE; }
static inline 
# 187 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 187 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_hashmap(NanoValue v) { return v.tag == TAG_HASHMAP; }
static inline 
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 188 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_function(NanoValue v) {
    return v.tag == TAG_FUNCTION || v.tag == TAG_CLOSURE;
}
static inline 
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 191 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_void(NanoValue v) { return v.tag == TAG_VOID; }
static inline 
# 192 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
             _Bool 
# 192 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
                  val_is_heap_obj(NanoValue v) {
    return v.tag == TAG_STRING || v.tag == TAG_BSTRING || v.tag == TAG_ARRAY || v.tag == TAG_STRUCT ||
           v.tag == TAG_UNION || v.tag == TAG_TUPLE || v.tag == TAG_HASHMAP ||
           v.tag == TAG_CLOSURE;
}






void val_print(NanoValue v, FILE *out);


void val_println(NanoValue v);



# 209 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
_Bool 
# 209 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
    val_equal(NanoValue a, NanoValue b);


int val_compare(NanoValue a, NanoValue b);



# 215 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h" 3 4
_Bool 
# 215 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/value.h"
    val_truthy(NanoValue v);


char *val_to_cstring(NanoValue v);
# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 1
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 2


# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4

# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 2






# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    
# 27 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 27 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
        is_utf8;
    
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
   _Bool 
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
        null_terminated;
} nl_string_t;


static inline void nl_string_free_owned_storage(nl_string_t *str) {
    if (!str) return;
    free(str->data);
    free(str);
}
# 47 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
nl_string_t* nl_string_new(const char *cstr);





nl_string_t* nl_string_new_binary(const void *data, size_t length);





nl_string_t* nl_string_from_utf8(const char *utf8_data, size_t length);




nl_string_t* nl_string_with_capacity(size_t capacity);




void nl_string_free(nl_string_t *str);
# 78 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
size_t nl_string_length(const nl_string_t *str);




char nl_string_byte_at(const nl_string_t *str, size_t index);





# 88 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
    nl_string_byte_at_safe(const nl_string_t *str, size_t index, char *out);





nl_string_t* nl_string_concat(const nl_string_t *a, const nl_string_t *b);





nl_string_t* nl_string_substring(const nl_string_t *str, size_t start, size_t length);





# 105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
    nl_string_equals(const nl_string_t *a, const nl_string_t *b);





# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
    nl_string_equals_cstr(const nl_string_t *str, const char *cstr);
# 120 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"

# 120 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 120 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
    nl_string_validate_utf8(nl_string_t *str);






int64_t nl_string_utf8_length(const nl_string_t *str);





int32_t nl_string_utf8_char_at(const nl_string_t *str, size_t char_index);




nl_string_t* nl_string_utf8_substring(const nl_string_t *str, size_t char_start, size_t char_length);
# 150 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
const char* nl_string_to_cstr(nl_string_t *str);




const void* nl_string_to_binary(const nl_string_t *str, size_t *out_length);





void nl_string_ensure_null_terminated(nl_string_t *str);
# 170 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
void nl_string_reserve(nl_string_t *str, size_t new_capacity);




void nl_string_shrink_to_fit(nl_string_t *str);




nl_string_t* nl_string_clone(const nl_string_t *str);
# 194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
int64_t nl_cstr_length(const char *s);


char *nl_cstr_concat(const char *a, const char *b);


char *nl_cstr_substring(const char *s, int64_t start, int64_t len);



# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h" 3 4
_Bool 
# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../runtime/nl_string.h"
           nl_cstr_contains(const char *haystack, const char *needle);


int64_t nl_cstr_index_of(const char *haystack, const char *needle);
int64_t nl_cstr_last_index_of(const char *haystack, const char *needle);


int64_t nl_cstr_char_at(const char *s, int64_t index);


char *nl_cstr_from_char(int64_t code);
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 2
# 35 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
typedef struct VmHeapHeader {
    uint32_t ref_count;
    uint8_t obj_type;
    uint8_t colour;
    uint8_t buffered;
} VmHeapHeader;






struct VmString {
    VmHeapHeader header;
    uint32_t length;
    uint32_t hash;
    struct VmString *intern_next;
    char data[];
};


struct VmBString {
    VmHeapHeader header;
    nl_string_t *value;
};
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
struct VmArray {
    VmHeapHeader header;
    uint8_t elem_type;
    uint8_t unboxed;
    uint32_t length;
    uint32_t capacity;
    NanoValue *elements;
    void *packed;
};




# 84 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vm_array_type_unboxable(uint8_t elem_type);


size_t vm_array_elem_size(uint8_t elem_type);


struct VmStruct {
    VmHeapHeader header;
    uint32_t def_idx;
    uint32_t field_count;
    VmString **field_names;
    NanoValue *fields;
};


struct VmUnion {
    VmHeapHeader header;
    uint32_t def_idx;
    uint16_t variant;
    uint16_t field_count;
    NanoValue *fields;
};


struct VmTuple {
    VmHeapHeader header;
    uint32_t count;
    NanoValue elements[];
};


struct VmClosure {
    VmHeapHeader header;
    uint32_t fn_idx;
    uint32_t callable_module;
    uint16_t capture_count;
    NanoValue captures[];
};


typedef struct VmHMEntry {
    uint8_t state;
    NanoValue key;
    NanoValue value;
} VmHMEntry;


struct VmHashMap {
    VmHeapHeader header;
    uint8_t key_type;
    uint8_t val_type;
    uint32_t count;
    uint32_t tombstone_count;
    uint32_t bucket_count;
    VmHMEntry *entries;
};





typedef struct {
    size_t allocated;
    size_t freed;
    size_t num_objects;
    uint64_t allocation_calls;
    uint64_t retain_calls;
    uint64_t release_calls;
} VmHeapStats;

typedef struct VmHeap {
    VmHeapStats stats;



    VmString **intern_buckets;
    uint32_t intern_bucket_count;
    uint32_t intern_count;





    void **cycle_buf;
    uint32_t cycle_count;
    uint32_t cycle_capacity;
    uint64_t cycles_collected;
    
# 171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
   _Bool 
# 171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
              gc_running;






} VmHeap;
# 194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
uint64_t vm_gc_collect_cycles(VmHeap *heap);




void vm_gc_note_suspect(VmHeap *heap, NanoValue v);


void vm_gc_maybe_collect(VmHeap *heap);
void vm_gc_cycle_buffer_free(VmHeap *heap);


void vm_heap_init(VmHeap *heap);
void vm_heap_destroy(VmHeap *heap);


void vm_retain(VmHeap *heap, NanoValue v);
void vm_release(VmHeap *heap, NanoValue v);


VmBString *vm_bstring_adopt(VmHeap *heap, nl_string_t *owned);
void vm_bstring_clear(VmHeap *heap, VmBString *value);


VmString *vm_string_new(VmHeap *heap, const char *data, uint32_t length);
VmString *vm_string_concat(VmHeap *heap, VmString *a, VmString *b);
VmString *vm_string_substr(VmHeap *heap, VmString *s, uint32_t start, uint32_t len);


const char *vmstring_cstr(VmString *s);
uint32_t vmstring_len(VmString *s);

# 225 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 225 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vmstring_equal(VmString *a, VmString *b);
int vmstring_compare(VmString *a, VmString *b);

# 227 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 227 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vmstring_contains(VmString *haystack, VmString *needle);



int64_t vmstring_find(VmString *haystack, VmString *needle);
VmString *vmstring_char_at(VmHeap *heap, VmString *s, uint32_t index);


VmArray *vm_array_new(VmHeap *heap, uint8_t elem_type, uint32_t initial_capacity);


# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vm_array_push(VmHeap *heap, VmArray *a, NanoValue v);
NanoValue vm_array_pop(VmArray *a);
NanoValue vm_array_get(VmArray *a, uint32_t index);
void vm_array_set(VmArray *a, uint32_t index, NanoValue v);


void vm_array_swap_scalar_storage(VmArray *a, VmArray *b);
VmArray *vm_array_slice(VmHeap *heap, VmArray *a, uint32_t start, uint32_t end);







void vm_array_remove(VmHeap *heap, VmArray *a, uint32_t index);


VmStruct *vm_struct_new(VmHeap *heap, uint32_t def_idx, uint32_t field_count);


VmUnion *vm_union_new(VmHeap *heap, uint32_t def_idx, uint16_t variant, uint16_t field_count);


VmTuple *vm_tuple_new(VmHeap *heap, uint32_t count);


VmClosure *vm_closure_new(VmHeap *heap, uint32_t fn_idx, uint16_t capture_count);


VmHashMap *vm_hashmap_new(VmHeap *heap, uint8_t key_type, uint8_t val_type);
NanoValue vm_hashmap_get(VmHashMap *m, NanoValue key);


# 270 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 270 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vm_hashmap_set(VmHeap *heap, VmHashMap *m, NanoValue key, NanoValue value);

# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vm_hashmap_has(VmHashMap *m, NanoValue key);
void vm_hashmap_delete(VmHeap *heap, VmHashMap *m, NanoValue key);
VmArray *vm_hashmap_keys(VmHeap *heap, VmHashMap *m);
VmArray *vm_hashmap_values(VmHeap *heap, VmHashMap *m);




# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
_Bool 
# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
    vm_string_replacement_length(uint32_t source_length, uint32_t needle_length,
                                  uint32_t replacement_length, uint64_t count,
                                  uint32_t *out);
VmString *vm_string_from_int(VmHeap *heap, int64_t v);
VmString *vm_string_from_float(VmHeap *heap, double v);
VmString *vm_string_from_bool(VmHeap *heap, 
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h" 3 4
                                           _Bool 
# 283 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.h"
                                                v);
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/isa.h" 1
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_shapes.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_array_shapes.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_array_shapes.h" 2



typedef enum {
    NVM_ARRAY_ELIGIBLE, NVM_ARRAY_UNRESOLVED, NVM_ARRAY_INVALID,
    NVM_ARRAY_LIMIT, NVM_ARRAY_MEMORY
} NvmArrayEligibilityStatus;
typedef struct {
    uint32_t function, pc;
    uint16_t child_tags;
    uint8_t declared_tag, packed;
} NvmArrayOrigin;
typedef struct {
    uint32_t origin_count, checked_writes;

    uint32_t runtime_tag_checks;
    NvmArrayOrigin origins[64];
} NvmArrayEligibilityReport;

typedef struct {
    NvmArrayEligibilityReport arrays;
    uint64_t child_origins[64];
    uint8_t child_unknown[64];
} NvmArrayGraphEligibilityReport;
typedef struct {
    NvmArrayEligibilityStatus status;
    uint32_t function, pc;
    char message[192];
} NvmArrayEligibilityResult;

NvmArrayEligibilityResult nvm_analyze_managed_arrays(
    const NvmModule *module, NvmArrayEligibilityReport **out);
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report);

NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(
    const NvmModule *module, NvmArrayGraphEligibilityReport **out);
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report);



NvmArrayEligibilityResult nvm_select_managed_array_mode(
    const NvmModule *module, int *graph_required);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_shapes.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_plan.h" 1



# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_plan.h" 2





typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_shapes.h" 2


typedef struct {
    uint64_t origins;
    uint16_t tags;
    uint8_t unknown;
} NvmRecordValueOrigins;
typedef enum { NVM_HEAP_ORIGIN_ARRAY, NVM_HEAP_ORIGIN_RECORD } NvmHeapOriginKind;
typedef struct {
    uint32_t function, pc;
    uint32_t record_ordinal, layout_index, field_start;
    uint16_t field_count;
    uint8_t kind, declared_tag, packed;
    NvmRecordValueOrigins children;
} NvmRecordHeapOrigin;
typedef struct {
    uint32_t origin_count, field_value_count, checked_field_writes;
    uint32_t checked_array_writes, runtime_tag_checks;
    NvmRecordHeapOrigin origins[64];
    NvmRecordValueOrigins *fields;
} NvmRecordEligibilityReport;



NvmArrayEligibilityResult nvm_analyze_managed_records(
    const NvmModule *module, NvmRecordEligibilityReport **out);
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report);


typedef enum { NVM_MANAGED_LEAF, NVM_MANAGED_ARRAY_GRAPH, NVM_MANAGED_RECORD } NvmManagedHeapMode;
typedef struct {
    NvmManagedHeapMode mode;
    NvmRecordPlan *records;
    NvmRecordEligibilityReport *fields;
} NvmManagedHeapPlan;
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *, int mutable_arrays,
                                                 NvmManagedHeapPlan **out);
void nvm_managed_heap_plan_free(NvmManagedHeapPlan *);
NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *, NvmManagedHeapPlan **);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 1


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h" 1






typedef struct NvmOrdinaryArrayAuthority NvmOrdinaryArrayAuthority;
typedef enum { NVM_OAA_DESCRIBED, NVM_OAA_UNKNOWN, NVM_OAA_INVALID,
               NVM_OAA_LIMIT, NVM_OAA_MEMORY } NvmOrdinaryArrayStatus;
typedef struct { NvmOrdinaryArrayStatus status; uint32_t layout, field;
                 const char *message; } NvmOrdinaryArrayResult;
typedef struct { uint32_t layouts, types, bindings; } NvmOrdinaryArrayCounts;
typedef struct { uint8_t tag; uint32_t referent; } NvmOrdinaryArrayType;
typedef struct { uint32_t layout; uint16_t field; uint32_t element_type; } NvmOrdinaryArrayBinding;
NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(const NvmModule *, NvmOrdinaryArrayAuthority **);
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *);

# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *, NvmOrdinaryArrayCounts *);

# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayType *);

# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayBinding *);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 2

# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h" 1
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 2



typedef struct NvmOwnershipDeclarationPlan NvmOwnershipDeclarationPlan;
typedef enum {
    NVM_DECL_PREPARED, NVM_DECL_UNKNOWN, NVM_DECL_INVALID,
    NVM_DECL_LIMIT, NVM_DECL_MEMORY
} NvmDeclarationStatus;
typedef struct { NvmDeclarationStatus status; const char *message; } NvmDeclarationResult;
typedef struct { uint32_t layouts, types, bindings, unions, variants; } NvmDeclarationCounts;
typedef struct { uint8_t kind, flags; uint16_t fields; uint32_t name; } NvmDeclarationLayout;
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *,NvmOwnershipDeclarationPlan **);
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *);

# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *,NvmDeclarationCounts *);

# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *,uint32_t,NvmDeclarationLayout *);

# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayType *);

# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 2


typedef struct NvmRecordArrayOrigins NvmRecordArrayOrigins;
typedef struct {
    uint32_t origins, fields, checked_field_writes, checked_array_writes, runtime_tag_checks;
    uint64_t work_reserved, peak_bytes_reserved;
} NvmRecordArrayOriginCounts;
NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *,NvmRecordArrayOrigins **);
void nvm_record_array_origins_free(NvmRecordArrayOrigins *);

# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *,NvmRecordArrayOriginCounts *);

# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_origin(const NvmRecordArrayOrigins *,uint32_t,NvmRecordHeapOrigin *);

# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *,uint32_t,NvmRecordValueOrigins *);
# 33 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
static inline uint16_t nvm_record_array_requirement(uint8_t depth,uint8_t leaf) {
    if(leaf<TAG_INT || leaf>TAG_STRING)return 0;
    if(depth==1)return (uint16_t)(1u<<leaf);
    if(depth==2) {
        switch(leaf) {
        case TAG_INT:return ((uint16_t)(1u << TAG_ARRAY));
        case TAG_U8:return ((uint16_t)(1u << 9));
        case TAG_FLOAT:return ((uint16_t)(1u << 10));
        case TAG_BOOL:return ((uint16_t)(1u << 11));
        case TAG_STRING:return ((uint16_t)(1u << 8));
        }
    }
    if(depth==3)return leaf==TAG_STRING?((uint16_t)(1u << 6)):(uint16_t)(1u<<(11u+leaf));
    return 0;
}
static inline uint8_t nvm_record_array_requirement_depth(uint16_t requirement) {
    for(uint8_t depth=1;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(requirement==nvm_record_array_requirement(depth,leaf))return depth;
    return 0;
}

static inline uint8_t nvm_record_array_requirement_leaf(uint16_t requirement) {
    switch(requirement) {
    case ((uint16_t)(1u << 12)):case ((uint16_t)(1u << TAG_ARRAY)):return TAG_INT;
    case ((uint16_t)(1u << 13)):case ((uint16_t)(1u << 9)):return TAG_U8;
    case ((uint16_t)(1u << 14)):case ((uint16_t)(1u << 10)):return TAG_FLOAT;
    case ((uint16_t)(1u << 15)):case ((uint16_t)(1u << 11)):return TAG_BOOL;
    case ((uint16_t)(1u << 6)):case ((uint16_t)(1u << 8)):return TAG_STRING;
    default:return TAG_VOID;
    }
}

# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *,uint32_t,uint16_t *);

# 65 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *,NvmDeclarationCounts *);

# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *,uint32_t,NvmDeclarationLayout *);

# 67 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmV2LayoutField *);

# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayType *);

# 69 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayBinding *);

# 70 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 2





typedef struct NvmRecordArrayExecutionPlan NvmRecordArrayExecutionPlan;
typedef enum {
    NVM_RA_ROOT_SCALAR, NVM_RA_ROOT_CONSTANT, NVM_RA_ROOT_LOAD,
    NVM_RA_ROOT_STORE, NVM_RA_ROOT_DUP, NVM_RA_ROOT_SWAP, NVM_RA_ROOT_DROP,
    NVM_RA_ROOT_BRANCH, NVM_RA_ROOT_CALL, NVM_RA_ROOT_RETURN,
    NVM_RA_ROOT_STRING, NVM_RA_ROOT_CONSTRUCT, NVM_RA_ROOT_GET,
    NVM_RA_ROOT_SET, NVM_RA_ROOT_ARRAY_PUSH, NVM_RA_ROOT_ARRAY_POP,
    NVM_RA_ROOT_ARRAY_COPY, NVM_RA_ROOT_TAIL
} NvmRecordArrayRootRecipe;
enum {

    NVM_RA_CHECK_TAGS=1u, NVM_RA_CHECK_BOUNDS=2u, NVM_RA_CHECK_NOMINAL=4u,
    NVM_RA_SAFEPOINT_BEFORE=8u, NVM_RA_STAGE_OPERANDS=16u,
    NVM_RA_RETAIN_BEFORE_RELEASE=32u, NVM_RA_FIRST_ERROR_CLEANUP=64u
};
typedef struct {
    uint32_t functions, instructions, globals, initializer, entry, frame_limit;
    uint32_t strings, sections, metadata, debug, records;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordArrayExecutionCounts;
typedef struct {
    NvmFunctionEntry signature;
    uint32_t instruction_start, instruction_count;
    uint16_t maximum_stack;
    uint8_t parameter_tags_present;
} NvmRecordArrayExecutionFunction;



typedef struct {
    uint32_t function, pc, next_pc, successors[2], callee;
    uint16_t pops, pushes, obligations;
    uint8_t opcode, recipe, successor_count, operand_count;
    uint8_t operand_types[4];
    uint64_t operand_bits[4];
} NvmRecordArrayExecutionInstruction;
typedef struct {
    uint32_t ordinal, layout;
    uint16_t fields;
} NvmRecordArrayExecutionDescriptor;
typedef enum {
    NVM_RA_SNAPSHOT_CODE, NVM_RA_SNAPSHOT_LAYOUTS, NVM_RA_SNAPSHOT_OWNERSHIP,
    NVM_RA_SNAPSHOT_STRING
} NvmRecordArraySnapshotKind;
NvmArrayEligibilityResult nvm_prepare_record_array_execution(
    const NvmModule *, NvmRecordArrayExecutionPlan **);
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *);

# 56 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 56 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionInstruction *);

# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 60 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 61 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionDescriptor *);

# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *,NvmHeader *);

# 63 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *,uint32_t,NvmSectionEntry *);

# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *,uint32_t,NvmMetadataEntry *);

# 65 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDebugEntry *);

# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 67 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayOriginCounts *);

# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordHeapOrigin *);

# 69 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 70 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t *);

# 71 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *,NvmDeclarationCounts *);

# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 73 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 74 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayType *);

# 75 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 1
# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
typedef struct NvmRecordMapFrozenContext NvmRecordMapFrozenContext;
typedef struct {
    uint32_t origins,map_origins,fields,checked_map_operations;
    uint64_t peak_bytes_reserved,work_reserved;
} NvmRecordMapCounts;
NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *,NvmRecordMapFrozenContext **);
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *);

# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *,NvmRecordMapCounts *);

# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *,uint32_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordHeapOrigin *);

# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_origins.h"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordValueOrigins *);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 2


typedef struct NvmRecordMapExecutionPlan NvmRecordMapExecutionPlan;
typedef enum { NVM_RM_NONE, NVM_RM_NEW, NVM_RM_SET, NVM_RM_GET,
               NVM_RM_HAS, NVM_RM_LEN, NVM_RM_DELETE } NvmRecordMapOperation;
typedef struct {
    NvmRecordArrayExecutionCounts carrier;
    NvmRecordMapCounts maps;
} NvmRecordMapExecutionCounts;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    uint16_t key_tags,value_tags,result_tags;
    uint8_t map_operation;
} NvmRecordMapExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *,NvmRecordMapExecutionPlan **);




# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *,uint8_t *);
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *);

# 25 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *,NvmRecordMapExecutionCounts *);

# 26 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *,uint32_t,NvmRecordMapExecutionInstruction *);

# 27 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *,uint32_t,uint8_t *,uint8_t *);

# 29 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out);

# 30 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out);

# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out);

# 32 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out);

# 33 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out);

# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out);

# 35 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out);

# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out);

# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out);

# 38 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out);

# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out);

# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out);

# 41 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out);

# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out);

# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out);

# 44 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out);

# 45 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out);

# 46 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out);

# 47 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h" 2





typedef enum { NVM_RECORD_MAP_ABSENT, NVM_RECORD_MAP_PRESENT,
    NVM_RECORD_MAP_INVALID, NVM_RECORD_MAP_LIMIT, NVM_RECORD_MAP_DEFER } NvmRecordMapRoute;
NvmRecordMapRoute nvm_record_map_route(const NvmModule *);


# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h"
    nvm_record_map_wire_selected(const NvmV2Module *);
static inline 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../nanoisa/record_map_admission.h"
                  nvm_record_map_selected(NvmRecordMapRoute r) {
    return r==NVM_RECORD_MAP_PRESENT || r==NVM_RECORD_MAP_INVALID || r==NVM_RECORD_MAP_LIMIT;
}


NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *,NvmRecordMapExecutionPlan **);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 2





typedef enum {
    VM_RM_HEAP_OK, VM_RM_HEAP_INVALID, VM_RM_HEAP_MEMORY,
    VM_RM_HEAP_RETAIN_OVERFLOW, VM_RM_HEAP_LIMIT
} VmRmHeapStatus;
typedef struct { uint64_t used,limit;
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 3 4
                                    _Bool 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
                                         limited; } VmRmObservationWork;
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
static inline 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 3 4
             _Bool 
# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
                  vm_rm_private_dag(const VmHeap *heap) {



    (void)heap;return 
# 35 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 3 4
                     0
# 35 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
                          ;

}






VmRmHeapStatus vm_rm_ordinary_new(VmHeap *,VmHashMap **);


VmRmHeapStatus vm_rm_ordinary_delete(VmHeap *,VmHashMap *,NanoValue);
VmRmHeapStatus vm_rm_ordinary_set(VmHeap *,VmHashMap *,NanoValue,NanoValue);
VmRmHeapStatus vm_rm_ordinary_get(const VmHeap *,const VmHashMap *,NanoValue,NanoValue *);
VmRmHeapStatus vm_rm_ordinary_has(const VmHeap *,const VmHashMap *,NanoValue,
# 50 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 3 4
                                                                            _Bool 
# 50 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
                                                                                 *);
VmRmHeapStatus vm_rm_ordinary_len(const VmHeap *,const VmHashMap *,uint32_t *);


VmRmHeapStatus vm_rm_heap_import_validate(const VmHashMap *,VmRmObservationWork *);
# 79 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
VmRmHeapStatus vm_rm_ordinary_ss_new(VmHeap *,VmHashMap **);
VmRmHeapStatus vm_rm_ordinary_ss_set(VmHeap *,VmHashMap *,NanoValue,NanoValue);
VmRmHeapStatus vm_rm_ordinary_ss_get_owned(VmHeap *,const VmHashMap *,NanoValue,NanoValue *);
VmRmHeapStatus vm_rm_ordinary_ss_delete(VmHeap *,VmHashMap *,NanoValue);
VmRmHeapStatus vm_rm_ordinary_ss_has(const VmHeap *,const VmHashMap *,NanoValue,
# 83 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h" 3 4
                                                                               _Bool 
# 83 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap_private.h"
                                                                                    *);
VmRmHeapStatus vm_rm_ordinary_ss_len(const VmHeap *,const VmHashMap *,uint32_t *);
VmRmHeapStatus vm_rm_heap_ss_import_validate(const VmHashMap *,VmRmObservationWork *);
# 7 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/float.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h" 2


# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4

# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 8 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h" 2
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h"

# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h"
typedef char nano_rt_f64_format_storage[(sizeof(double) == 8 && sizeof(uint64_t) == 8) ? 1 : -1]; static inline const char *nano_rt_f64_nonfinite(double value) { uint64_t bits; memcpy(&bits, &value, sizeof bits); if ((bits & 0x7ff0000000000000UL) != 0x7ff0000000000000UL) return 
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h" 3 4
((void *)0)
# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/../binary64_format.h"
; if (bits & 0x000fffffffffffffUL) return bits >> 63 ? "-nan" : "nan"; return bits >> 63 ? "-inf" : "inf"; } static inline int nano_rt_f64_format(char *out, size_t size, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? snprintf(out, size, "%s", special) : snprintf(out, size, "%g", value); } static inline int nano_rt_f64_print(FILE *out, double value) { const char *special = nano_rt_f64_nonfinite(value); return special ? fprintf(out, "%s", special) : fprintf(out, "%g", value); }
# 8 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 2



# 1 "/usr/include/assert.h" 1 3 4
# 66 "/usr/include/assert.h" 3 4




# 69 "/usr/include/assert.h" 3 4
extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));


extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 2








# 19 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
void vm_heap_init(VmHeap *heap) {
    memset(heap, 0, sizeof(*heap));
    heap->intern_bucket_count = 256u;
    heap->intern_count = 0;
    heap->intern_buckets = calloc(heap->intern_bucket_count, sizeof(VmString *));
    if (!heap->intern_buckets) heap->intern_bucket_count = 0;
}

void vm_heap_destroy(VmHeap *heap) {


    vm_gc_collect_cycles(heap);
    vm_gc_cycle_buffer_free(heap);

    for (uint32_t b = 0; b < heap->intern_bucket_count; b++) {
        VmString *s = heap->intern_buckets ? heap->intern_buckets[b] : 
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                                      ((void *)0)
# 34 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                          ;
        while (s) {
            VmString *next = s->intern_next;

            free(s);
            s = next;
        }
    }
    free(heap->intern_buckets);
    heap->intern_buckets = 
# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                          ((void *)0)
# 43 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                              ;
    heap->intern_bucket_count = 0;
    heap->intern_count = 0;
}





static uint32_t fnv1a(const char *data, uint32_t len) {
    uint32_t hash = 2166136261u;
    for (uint32_t i = 0; i < len; i++) {
        hash ^= (uint8_t)data[i];
        hash *= 16777619u;
    }
    return hash;
}
# 71 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
static void vm_intern_maybe_grow(VmHeap *heap) {
    if ((uint64_t)heap->intern_count * 4u <
        (uint64_t)heap->intern_bucket_count * 3u) {
        return;
    }
    if (heap->intern_bucket_count > 
# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                   (4294967295U) 
# 76 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                              / 2) return;
    uint32_t new_count = heap->intern_bucket_count ? heap->intern_bucket_count * 2 : 256;
    VmString **new_buckets = calloc(new_count, sizeof(VmString *));
    if (!new_buckets) return;
    for (uint32_t b = 0; b < heap->intern_bucket_count; b++) {
        VmString *s = heap->intern_buckets[b];
        while (s) {
            VmString *next = s->intern_next;
            uint32_t idx = s->hash & (new_count - 1);
            s->intern_next = new_buckets[idx];
            new_buckets[idx] = s;
            s = next;
        }
    }
    free(heap->intern_buckets);
    heap->intern_buckets = new_buckets;
    heap->intern_bucket_count = new_count;
}


static VmString *vm_intern_lookup(VmHeap *heap, uint32_t hash,
                                  const char *data, uint32_t length) {
    if (heap->intern_bucket_count == 0) return 
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                              ((void *)0)
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                  ;
    uint32_t idx = hash & (heap->intern_bucket_count - 1);
    for (VmString *s = heap->intern_buckets[idx]; s; s = s->intern_next) {
        if (s->hash == hash && s->length == length &&
            memcmp(s->data, data, length) == 0) {
            return s;
        }
    }
    return 
# 106 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          ((void *)0)
# 106 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}


static 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
      _Bool 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
           vm_intern_insert(VmHeap *heap, VmString *s) {
    vm_intern_maybe_grow(heap);
    if (!heap->intern_bucket_count) return 
# 112 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                          0
# 112 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                               ;
    uint32_t idx = s->hash & (heap->intern_bucket_count - 1);
    s->intern_next = heap->intern_buckets[idx];
    heap->intern_buckets[idx] = s;
    heap->intern_count++;
    return 
# 117 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 117 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}


static void vm_intern_unlink(VmHeap *heap, VmString *s) {
    if (heap->intern_bucket_count == 0) return;
    uint32_t idx = s->hash & (heap->intern_bucket_count - 1);
    VmString **link = &heap->intern_buckets[idx];
    while (*link) {
        if (*link == s) {
            *link = s->intern_next;
            s->intern_next = 
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                            ((void *)0)
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                ;
            heap->intern_count--;
            return;
        }
        link = &(*link)->intern_next;
    }
}





void vm_retain(VmHeap *heap, NanoValue v) {
    if (!val_is_heap_obj(v)) return;
    void *ptr = v.as.obj;
    if (!ptr) return;
    VmHeapHeader *hdr = (VmHeapHeader *)ptr;
    if (heap) heap->stats.retain_calls++;
    hdr->ref_count++;
}

static void release_array(VmHeap *heap, VmArray *a);
static void release_struct(VmHeap *heap, VmStruct *s);
static void release_union(VmHeap *heap, VmUnion *u);
static void release_tuple(VmHeap *heap, VmTuple *t);
static void release_closure(VmHeap *heap, VmClosure *c);
static void release_hashmap(VmHeap *heap, VmHashMap *m);

VmBString *vm_bstring_adopt(VmHeap *heap, nl_string_t *owned) {
    if (!owned) return 
# 157 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                      ((void *)0)
# 157 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                          ;
    VmBString *value = heap ? malloc(sizeof *value) : 
# 158 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                     ((void *)0)
# 158 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                         ;
    if (!value) { nl_string_free_owned_storage(owned); return 
# 159 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                             ((void *)0)
# 159 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                 ; }
    value->header.ref_count = 1;
    value->header.obj_type = TAG_BSTRING;
    value->header.colour = 0u;
    value->header.buffered = 0;
    value->value = owned;
    heap->stats.allocated += sizeof *value + sizeof *owned + owned->capacity;
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return value;
}

void vm_bstring_clear(VmHeap *heap, VmBString *value) {
    if (!value || !value->value) return;
    heap->stats.freed += sizeof *value->value + value->value->capacity;
    nl_string_free_owned_storage(value->value);
    value->value = 
# 176 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 176 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
}
# 305 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
void vm_release(VmHeap *heap, NanoValue v) {



    if (!val_is_heap_obj(v)) return;
    void *ptr = v.as.obj;
    if (!ptr) return;
    if (heap) heap->stats.release_calls++;
    VmHeapHeader *hdr = (VmHeapHeader *)ptr;
    if (hdr->ref_count == 0) return;
    hdr->ref_count--;
    if (hdr->ref_count > 0) {



        if (heap) vm_gc_note_suspect(heap, v);
        return;
    }





    if (heap && hdr->buffered) {
        hdr->colour = 0u;
        return;
    }


    switch (v.tag) {
        case TAG_BSTRING: {
            VmBString *s = v.as.obj;
            vm_bstring_clear(heap, s);
            heap->stats.freed += sizeof *s;
            heap->stats.num_objects--;
            free(s);
            break;
        }
        case TAG_STRING: {
            VmString *s = v.as.string;
            heap->stats.freed += sizeof(VmString) + s->length + 1;
            heap->stats.num_objects--;

            vm_intern_unlink(heap, s);
            free(s);
            break;
        }
        case TAG_ARRAY:
            release_array(heap, v.as.array);
            break;
        case TAG_STRUCT:
            release_struct(heap, v.as.sval);
            break;
        case TAG_UNION:
            release_union(heap, v.as.uval);
            break;
        case TAG_TUPLE:
            release_tuple(heap, v.as.tuple);
            break;
        case TAG_HASHMAP:
            release_hashmap(heap, v.as.hashmap);
            break;
        case TAG_CLOSURE:
            release_closure(heap, v.as.closure);
            break;
        default:
            break;
    }
}

static void release_array(VmHeap *heap, VmArray *a) {
    if (a->unboxed) {

        heap->stats.freed += sizeof(VmArray) +
            (size_t)a->capacity * vm_array_elem_size(a->elem_type);
        heap->stats.num_objects--;
        free(a->packed);
        free(a);
        return;
    }
    for (uint32_t i = 0; i < a->length; i++) {
        vm_release(heap, a->elements[i]);
    }
    heap->stats.freed += sizeof(VmArray) + a->capacity * sizeof(NanoValue);
    heap->stats.num_objects--;
    free(a->elements);
    free(a);
}

static void release_struct(VmHeap *heap, VmStruct *s) {
    for (uint32_t i = 0; i < s->field_count; i++) {
        vm_release(heap, s->fields[i]);
    }
    if (s->field_names) {
        for (uint32_t i = 0; i < s->field_count; i++) {
            if (s->field_names[i]) {
                NanoValue sv = val_string(s->field_names[i]);
                vm_release(heap, sv);
            }
        }
        free(s->field_names);
    }
    heap->stats.freed += sizeof(VmStruct) + s->field_count * sizeof(NanoValue);
    heap->stats.num_objects--;
    free(s->fields);
    free(s);
}

static void release_union(VmHeap *heap, VmUnion *u) {
    for (uint32_t i = 0; i < u->field_count; i++) {
        vm_release(heap, u->fields[i]);
    }
    heap->stats.freed += sizeof(VmUnion) + u->field_count * sizeof(NanoValue);
    heap->stats.num_objects--;
    free(u->fields);
    free(u);
}

static void release_tuple(VmHeap *heap, VmTuple *t) {
    for (uint32_t i = 0; i < t->count; i++) {
        vm_release(heap, t->elements[i]);
    }
    size_t sz = sizeof(VmTuple) + t->count * sizeof(NanoValue);
    heap->stats.freed += sz;
    heap->stats.num_objects--;
    free(t);
}

static void release_closure(VmHeap *heap, VmClosure *c) {
    for (uint16_t i = 0; i < c->capture_count; i++) {
        vm_release(heap, c->captures[i]);
    }
    size_t sz = sizeof(VmClosure) + c->capture_count * sizeof(NanoValue);
    heap->stats.freed += sz;
    heap->stats.num_objects--;
    free(c);
}

static void release_hashmap(VmHeap *heap, VmHashMap *m) {
    for (uint32_t i = 0; i < m->bucket_count; i++) {
        VmHMEntry *entry = &m->entries[i];
        if (entry->state == 1) {
            vm_release(heap, entry->key);
            vm_release(heap, entry->value);
        }
    }
    heap->stats.freed += sizeof(VmHashMap) + m->bucket_count * sizeof(VmHMEntry);
    heap->stats.num_objects--;
    free(m->entries);
    free(m);
}





VmString *vm_string_new(VmHeap *heap, const char *data, uint32_t length) {
    if ((uint64_t)length + sizeof(VmString) + 1 > 
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                 (18446744073709551615UL) 
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                          || (!data && length))
        return 
# 463 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 463 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    if (!data) data = "";
    uint32_t hash = fnv1a(data, length);


    VmString *existing = vm_intern_lookup(heap, hash, data, length);
    if (existing) {
        if (existing->header.ref_count == 
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                         (4294967295U)
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                   ) return 
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                            ((void *)0)
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                ;
        existing->header.ref_count++;
        return existing;
    }


    size_t sz = sizeof(VmString) + length + 1;
    VmString *s = malloc(sz);
    if (!s) return 
# 478 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 478 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    s->header.ref_count = 1;
    s->header.obj_type = TAG_STRING;
    s->header.colour = 0u;
    s->header.buffered = 0;
    s->length = length;
    s->hash = hash;
    s->intern_next = 
# 485 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    ((void *)0)
# 485 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                        ;
    memcpy(s->data, data, length);
    s->data[length] = '\0';


    if (!vm_intern_insert(heap, s)) {
        free(s);
        return 
# 492 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 492 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    heap->stats.allocated += sz;
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);

    return s;
}

VmString *vm_string_concat(VmHeap *heap, VmString *a, VmString *b) {
    if (!a || !b) return 
# 503 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                        ((void *)0)
# 503 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                            ;
    uint64_t length = (uint64_t)a->length + b->length;
    if (length > 
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                (4294967295U) 
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                           || length + sizeof(VmString) + 1 > 
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                              (18446744073709551615UL)
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                      )
        return 
# 506 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 506 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    uint32_t new_len = (uint32_t)length;
    if (!new_len) return vm_string_new(heap, "", 0);
    char *buf = malloc(new_len);
    if (!buf) return 
# 510 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    ((void *)0)
# 510 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                        ;
    memcpy(buf, a->data, a->length);
    memcpy(buf + a->length, b->data, b->length);
    VmString *result = vm_string_new(heap, buf, new_len);
    free(buf);
    return result;
}

VmString *vm_string_substr(VmHeap *heap, VmString *s, uint32_t start, uint32_t len) {
    if (start >= s->length) return vm_string_new(heap, "", 0);
    uint32_t remaining = s->length - start;
    if (len > remaining) len = remaining;
    return vm_string_new(heap, s->data + start, len);
}



const char *vmstring_cstr(VmString *s) {
    return s ? s->data : "";
}

uint32_t vmstring_len(VmString *s) {
    return s ? s->length : 0;
}


# 535 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 535 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vmstring_equal(VmString *a, VmString *b) {
    if (a == b) return 
# 536 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                      1
# 536 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                          ;
    if (a->length != b->length) return 
# 537 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                      0
# 537 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                           ;
    if (a->hash != b->hash) return 
# 538 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                  0
# 538 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                       ;
    return memcmp(a->data, b->data, a->length) == 0;
}

int vmstring_compare(VmString *a, VmString *b) {
    uint32_t min_len = a->length < b->length ? a->length : b->length;
    int cmp = memcmp(a->data, b->data, min_len);
    if (cmp != 0) return cmp;
    if (a->length < b->length) return -1;
    if (a->length > b->length) return 1;
    return 0;
}




int64_t vmstring_find(VmString *haystack, VmString *needle) {
    uint32_t nlen = needle->length;
    if (nlen == 0) return 0;
    uint32_t hlen = haystack->length;
    if (nlen > hlen) return -1;
    const char *hay = haystack->data;
    const char *nee = needle->data;
    uint32_t last = hlen - nlen;
    for (uint32_t i = 0; i <= last; i++) {
        if (memcmp(hay + i, nee, nlen) == 0) return (int64_t)i;
    }
    return -1;
}


# 568 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 568 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vmstring_contains(VmString *haystack, VmString *needle) {
    return vmstring_find(haystack, needle) >= 0;
}

VmString *vmstring_char_at(VmHeap *heap, VmString *s, uint32_t index) {
    if (index >= s->length) return vm_string_new(heap, "", 0);
    return vm_string_new(heap, &s->data[index], 1);
}


# 577 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 577 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vm_string_replacement_length(uint32_t source_length, uint32_t needle_length,
                                  uint32_t replacement_length, uint64_t count,
                                  uint32_t *out) {
    if (!out) return 
# 580 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    0
# 580 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                         ;
    if (!needle_length) {
        if (count) return 
# 582 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                         0
# 582 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                              ;
        *out = source_length;
        return 
# 584 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              1
# 584 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    if (count > source_length / needle_length) return 
# 586 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                     0
# 586 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                          ;
    uint32_t remaining = source_length - (uint32_t)count * needle_length;
    if (replacement_length && count > (
# 588 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                      (4294967295U) 
# 588 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                 - remaining) / replacement_length)
        return 
# 589 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              0
# 589 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                   ;
    *out = remaining + (uint32_t)count * replacement_length;
    return 
# 591 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 591 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}

VmString *vm_string_from_int(VmHeap *heap, int64_t v) {
    char buf[32];
    int len = snprintf(buf, sizeof(buf), "%lld", (long long)v);
    if (len < 0 || (size_t)len >= sizeof(buf)) return 
# 597 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                     ((void *)0)
# 597 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                         ;
    return vm_string_new(heap, buf, (uint32_t)len);
}

VmString *vm_string_from_float(VmHeap *heap, double v) {
    char buf[64];
    int len = nano_rt_f64_format(buf, sizeof(buf), v);
    if (len < 0 || (size_t)len >= sizeof(buf)) return 
# 604 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                     ((void *)0)
# 604 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                         ;
    return vm_string_new(heap, buf, (uint32_t)len);
}

VmString *vm_string_from_bool(VmHeap *heap, 
# 608 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                           _Bool 
# 608 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                v) {
    return v ? vm_string_new(heap, "true", 4) : vm_string_new(heap, "false", 5);
}






# 616 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 616 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vm_array_type_unboxable(uint8_t elem_type) {
    return elem_type == TAG_INT || elem_type == TAG_FLOAT ||
           elem_type == TAG_BOOL || elem_type == TAG_U8;
}



size_t vm_array_elem_size(uint8_t elem_type) {
    switch (elem_type) {
        case TAG_INT: return sizeof(int64_t);
        case TAG_FLOAT: return sizeof(double);
        case TAG_BOOL: return sizeof(uint8_t);
        case TAG_U8: return sizeof(uint8_t);
        default: return 0;
    }
}


static NanoValue packed_load(const VmArray *a, uint32_t index) {
    switch (a->elem_type) {
        case TAG_INT: return val_int(((const int64_t *)a->packed)[index]);
        case TAG_FLOAT: return val_float(((const double *)a->packed)[index]);
        case TAG_BOOL: return val_bool(((const uint8_t *)a->packed)[index] != 0);
        case TAG_U8: return val_u8(((const uint8_t *)a->packed)[index]);
        default: return val_void();
    }
}





static void packed_store(VmArray *a, uint32_t index, NanoValue v) {
    switch (a->elem_type) {
        case TAG_INT:
            ((int64_t *)a->packed)[index] =
                (v.tag == TAG_U8) ? (int64_t)v.as.u8 : v.as.i64;
            break;
        case TAG_FLOAT:
            ((double *)a->packed)[index] =
                (v.tag == TAG_INT) ? (double)v.as.i64 : v.as.f64;
            break;
        case TAG_BOOL:
            ((uint8_t *)a->packed)[index] = v.as.boolean ? 1u : 0u;
            break;
        case TAG_U8:
            ((uint8_t *)a->packed)[index] =
                (v.tag == TAG_INT) ? (uint8_t)v.as.i64 : v.as.u8;
            break;
        default:
            break;
    }
}

VmArray *vm_array_new(VmHeap *heap, uint8_t elem_type, uint32_t initial_capacity) {
    if (initial_capacity < 8) initial_capacity = 8;
    VmArray *a = malloc(sizeof(VmArray));
    if (!a) return 
# 673 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 673 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    a->header.ref_count = 1;
    a->header.obj_type = TAG_ARRAY;
    a->header.colour = 0u;
    a->header.buffered = 0;
    a->elem_type = elem_type;
    a->unboxed = vm_array_type_unboxable(elem_type) ? 1u : 0u;
    a->length = 0;
    a->capacity = initial_capacity;
    a->elements = 
# 682 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                 ((void *)0)
# 682 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                     ;
    a->packed = 
# 683 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
               ((void *)0)
# 683 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                   ;
    if (a->unboxed) {
        size_t esz = vm_array_elem_size(elem_type);
        a->packed = calloc(initial_capacity, esz);
        if (!a->packed) { free(a); return 
# 687 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                         ((void *)0)
# 687 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                             ; }
        heap->stats.allocated += sizeof(VmArray) + (size_t)initial_capacity * esz;
    } else {
        a->elements = calloc(initial_capacity, sizeof(NanoValue));
        if (!a->elements) { free(a); return 
# 691 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                           ((void *)0)
# 691 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                               ; }
        heap->stats.allocated += sizeof(VmArray) + initial_capacity * sizeof(NanoValue);
    }
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return a;
}



static 
# 702 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
      _Bool 
# 702 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
           array_grow(VmHeap *heap, VmArray *a) {
    uint32_t new_cap = a->capacity ? a->capacity * 2 : 4;
    size_t esz = a->unboxed ? vm_array_elem_size(a->elem_type) : sizeof(NanoValue);


    if (new_cap <= a->capacity || new_cap > (
# 707 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                            (4294967295U) 
# 707 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                       / esz)) {
        return 
# 708 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              0
# 708 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                   ;
    }
    if (a->unboxed) {
        void *new_buf = realloc(a->packed, (size_t)new_cap * esz);
        if (!new_buf) return 
# 712 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                            0
# 712 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                 ;
        a->packed = new_buf;
    } else {
        NanoValue *new_elems = realloc(a->elements, new_cap * sizeof(NanoValue));
        if (!new_elems) return 
# 716 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                              0
# 716 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                   ;
        a->elements = new_elems;
    }
    heap->stats.allocated += (size_t)(new_cap - a->capacity) * esz;
    a->capacity = new_cap;
    vm_gc_maybe_collect(heap);
    return 
# 722 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 722 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}

void vm_array_swap_scalar_storage(VmArray *a, VmArray *b) {
    
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ((void) sizeof ((
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   a && b && a->elem_type == b->elem_type && a->unboxed == b->unboxed
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ) ? 1 : 0), __extension__ ({ if (
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   a && b && a->elem_type == b->elem_type && a->unboxed == b->unboxed
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ) ; else __assert_fail (
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   "a && b && a->elem_type == b->elem_type && a->unboxed == b->unboxed"
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c", 726, __extension__ __PRETTY_FUNCTION__); }))
# 726 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                             ;
    
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ((void) sizeof ((
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   vm_array_type_unboxable(a->elem_type) || a->elem_type == TAG_STRING
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ) ? 1 : 0), __extension__ ({ if (
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   vm_array_type_unboxable(a->elem_type) || a->elem_type == TAG_STRING
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   ) ; else __assert_fail (
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
   "vm_array_type_unboxable(a->elem_type) || a->elem_type == TAG_STRING"
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c", 727, __extension__ __PRETTY_FUNCTION__); }))
# 727 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                              ;
    uint32_t length = a->length, capacity = a->capacity;
    NanoValue *elements = a->elements;
    void *packed = a->packed;
    a->length = b->length; a->capacity = b->capacity;
    a->elements = b->elements; a->packed = b->packed;
    b->length = length; b->capacity = capacity;
    b->elements = elements; b->packed = packed;
}


# 737 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 737 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vm_array_push(VmHeap *heap, VmArray *a, NanoValue v) {
    if (!a) return 
# 738 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  0
# 738 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                       ;




    if (a->length >= a->capacity) {
        if (!array_grow(heap, a)) return 
# 744 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                        0
# 744 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                             ;
    }
    if (a->unboxed) {
        packed_store(a, a->length, v);
        a->length++;

        return 
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              1
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    a->elements[a->length++] = v;
    vm_retain(heap, v);
    return 
# 754 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 754 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}

NanoValue vm_array_pop(VmArray *a) {
    if (a->length == 0) return val_void();
    a->length--;
    if (a->unboxed) {
        return packed_load(a, a->length);
    }
    NanoValue v = a->elements[a->length];

    return v;
}

NanoValue vm_array_get(VmArray *a, uint32_t index) {
    if (index >= a->length) return val_void();
    if (a->unboxed) return packed_load(a, index);
    return a->elements[index];
}

void vm_array_set(VmArray *a, uint32_t index, NanoValue v) {
    if (index >= a->length) return;
    if (a->unboxed) {
        packed_store(a, index, v);
        return;
    }
    a->elements[index] = v;
}

VmArray *vm_array_slice(VmHeap *heap, VmArray *a, uint32_t start, uint32_t end) {
    if (start >= a->length) start = a->length;
    if (end > a->length) end = a->length;
    if (end <= start) return vm_array_new(heap, a->elem_type, 8);

    uint32_t new_len = end - start;
    VmArray *result = vm_array_new(heap, a->elem_type, new_len);
    if (!result) return 
# 790 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                       ((void *)0)
# 790 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                           ;
    if (a->unboxed) {
        size_t esz = vm_array_elem_size(a->elem_type);
        memcpy(result->packed,
               (const char *)a->packed + (size_t)start * esz,
               (size_t)new_len * esz);
        result->length = new_len;
        return result;
    }
    for (uint32_t i = 0; i < new_len; i++) {
# 809 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
        result->elements[i] = a->elements[start + i];
        vm_retain(heap, result->elements[i]);
    }
    result->length = new_len;
    return result;
}

void vm_array_remove(VmHeap *heap, VmArray *a, uint32_t index) {
    if (index >= a->length) return;
    if (a->unboxed) {
        size_t esz = vm_array_elem_size(a->elem_type);
        char *base = (char *)a->packed;
        memmove(base + (size_t)index * esz,
                base + (size_t)(index + 1) * esz,
                (size_t)(a->length - 1 - index) * esz);
        a->length--;
        return;
    }


    NanoValue previous = a->elements[index];


    for (uint32_t i = index; i < a->length - 1; i++) {
        a->elements[i] = a->elements[i + 1];
    }
    a->length--;
    a->elements[a->length] = val_void();
    vm_release(heap, previous);
}





VmStruct *vm_struct_new(VmHeap *heap, uint32_t def_idx, uint32_t field_count) {
    VmStruct *s = malloc(sizeof(VmStruct));
    if (!s) return 
# 846 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 846 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    s->header.ref_count = 1;
    s->header.obj_type = TAG_STRUCT;
    s->header.colour = 0u;
    s->header.buffered = 0;
    s->def_idx = def_idx;
    s->field_count = field_count;
    s->field_names = 
# 853 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    ((void *)0)
# 853 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                        ;
    s->fields = calloc(field_count, sizeof(NanoValue));
    if (field_count && !s->fields) {
        free(s);
        return 
# 857 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 857 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    heap->stats.allocated += sizeof(VmStruct) + field_count * sizeof(NanoValue);
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return s;
}





VmUnion *vm_union_new(VmHeap *heap, uint32_t def_idx, uint16_t variant, uint16_t field_count) {
    VmUnion *u = malloc(sizeof(VmUnion));
    if (!u) return 
# 872 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 872 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    u->header.ref_count = 1;
    u->header.obj_type = TAG_UNION;
    u->header.colour = 0u;
    u->header.buffered = 0;
    u->def_idx = def_idx;
    u->variant = variant;
    u->field_count = field_count;
    u->fields = calloc(field_count, sizeof(NanoValue));
    if (field_count && !u->fields) {
        free(u);
        return 
# 883 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 883 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    heap->stats.allocated += sizeof(VmUnion) + field_count * sizeof(NanoValue);
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return u;
}





VmTuple *vm_tuple_new(VmHeap *heap, uint32_t count) {
    size_t sz = sizeof(VmTuple) + count * sizeof(NanoValue);
    VmTuple *t = calloc(1, sz);
    if (!t) return 
# 899 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 899 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    t->header.ref_count = 1;
    t->header.obj_type = TAG_TUPLE;
    t->header.colour = 0u;
    t->header.buffered = 0;
    t->count = count;
    heap->stats.allocated += sz;
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return t;
}





VmClosure *vm_closure_new(VmHeap *heap, uint32_t fn_idx, uint16_t capture_count) {
    size_t sz = sizeof(VmClosure) + capture_count * sizeof(NanoValue);
    VmClosure *c = calloc(1, sz);
    if (!c) return 
# 919 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 919 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    c->header.ref_count = 1;
    c->header.obj_type = TAG_CLOSURE;
    c->header.colour = 0u;
    c->header.buffered = 0;
    c->fn_idx = fn_idx;
    c->callable_module = 1;
    c->capture_count = capture_count;
    heap->stats.allocated += sz;
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return c;
}
# 941 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
static uint32_t hash_value(NanoValue v) {
    switch (v.tag) {
        case TAG_INT: return (uint32_t)(v.as.i64 ^ (v.as.i64 >> 32));
        case TAG_STRING: return v.as.string ? v.as.string->hash : 0;
        case TAG_BOOL: return v.as.boolean ? 1 : 0;
        case TAG_ENUM: return (uint32_t)v.as.enum_val;
        default: return 0;
    }
}

VmHashMap *vm_hashmap_new(VmHeap *heap, uint8_t key_type, uint8_t val_type) {
    VmHashMap *m = malloc(sizeof(VmHashMap));
    if (!m) return 
# 953 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 953 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
    m->header.ref_count = 1;
    m->header.obj_type = TAG_HASHMAP;
    m->header.colour = 0u;
    m->header.buffered = 0;
    m->key_type = key_type;
    m->val_type = val_type;
    m->count = 0;
    m->tombstone_count = 0;
    m->bucket_count = 16;
    m->entries = calloc(16, sizeof(VmHMEntry));
    if (!m->entries) {
        free(m);
        return 
# 966 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              ((void *)0)
# 966 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    heap->stats.allocated += sizeof(VmHashMap) + 16 * sizeof(VmHMEntry);
    heap->stats.allocation_calls++;
    heap->stats.num_objects++;
    vm_gc_maybe_collect(heap);
    return m;
}

static 
# 975 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
      _Bool 
# 975 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
           hm_find_slot(const VmHashMap *m, NanoValue key, uint32_t *slot, 
# 975 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                                           _Bool 
# 975 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                                *found) {
    uint32_t idx = hash_value(key) % m->bucket_count;
    uint32_t first_tombstone = 
# 977 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                              (4294967295U)
# 977 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                        ;
    for (uint32_t probes = 0; probes < m->bucket_count; probes++) {
        VmHMEntry *entry = &m->entries[idx];
        if (entry->state == 0) {
            *slot = first_tombstone != 
# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                      (4294967295U) 
# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                 ? first_tombstone : idx;
            *found = 
# 982 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    0
# 982 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                         ;
            return 
# 983 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  1
# 983 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
        }
        if (entry->state == 2) {
            if (first_tombstone == 
# 986 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                  (4294967295U)
# 986 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                            ) first_tombstone = idx;
        } else if (val_equal(entry->key, key)) {
            *slot = idx;
            *found = 
# 989 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                    1
# 989 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                        ;
            return 
# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  1
# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
        }
        idx = (idx + 1) % m->bucket_count;
    }
    if (first_tombstone != 
# 994 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                          (4294967295U)
# 994 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                    ) {
        *slot = first_tombstone;
        *found = 
# 996 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                0
# 996 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                     ;
        return 
# 997 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              1
# 997 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    return 
# 999 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          0
# 999 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
               ;
}

static 
# 1002 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
      _Bool 
# 1002 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
           hm_resize(VmHeap *heap, VmHashMap *m, uint32_t new_count) {
    VmHMEntry *old_entries = m->entries;
    uint32_t old_count = m->bucket_count;
    if (!new_count || sizeof(VmHMEntry) > 
# 1005 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                         (18446744073709551615UL) 
# 1005 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                  / (size_t)new_count) return 
# 1005 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                                              0
# 1005 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                                   ;
    VmHMEntry *new_entries = calloc(new_count, sizeof(VmHMEntry));
    if (!new_entries) return 
# 1007 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                            0
# 1007 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                 ;

    VmHashMap replacement = *m;
    replacement.entries = new_entries;
    replacement.bucket_count = new_count;
    replacement.count = 0;
    replacement.tombstone_count = 0;
    for (uint32_t i = 0; i < old_count; i++) {
        if (old_entries[i].state == 1) {
            uint32_t slot;
            
# 1017 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
           _Bool 
# 1017 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                found;
            if (!hm_find_slot(&replacement, old_entries[i].key, &slot, &found)) {
                free(new_entries);
                return 
# 1020 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                      0
# 1020 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                           ;
            }
            replacement.entries[slot] = old_entries[i];
            replacement.entries[slot].state = 1;
            replacement.count++;
        }
    }
    *m = replacement;


    if (heap) heap->stats.allocated += (size_t)(new_count - old_count) * sizeof(VmHMEntry);
    free(old_entries);
    vm_gc_maybe_collect(heap);
    return 
# 1033 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 1033 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}

# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_map_header(const VmHashMap *m) {
    return m && m->header.obj_type==TAG_HASHMAP && m->header.ref_count && !m->header.buffered &&
        m->key_type==TAG_STRING && m->val_type==TAG_INT && m->entries &&
        m->bucket_count>=16 && !(m->bucket_count&(m->bucket_count-1)) &&
        sizeof(VmHMEntry)<=
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          (18446744073709551615UL)
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                  /(size_t)m->bucket_count &&
        m->count<=m->bucket_count && m->tombstone_count<=m->bucket_count-m->count;
}
static 
# 9 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 9 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_string(NanoValue key) {
    return key.tag==TAG_STRING && key.as.string && key.as.string->header.obj_type==TAG_STRING &&
        key.as.string->header.ref_count && !key.as.string->header.buffered &&
        (uint64_t)key.as.string->length+sizeof(VmString)+1<=
# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                           (18446744073709551615UL)
# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                   ;
}


static VmRmHeapStatus vm_rm_delete_validated(VmHeap *heap,VmHashMap *m,NanoValue key) {
    uint32_t slot;
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    if(!hm_find_slot(m,key,&slot,&found) || !found)return VM_RM_HEAP_OK;
    VmHMEntry *entry=&m->entries[slot];
    if(entry->state!=1 || !vm_rm_string(entry->key) || entry->value.tag!=TAG_INT || !m->count)
        return VM_RM_HEAP_INVALID;
    NanoValue stored=entry->key;
    entry->key=val_void();entry->value=val_void();entry->state=2;
    m->count--;m->tombstone_count++;

    vm_release(heap,stored);return VM_RM_HEAP_OK;
}
# 92 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
static 
# 92 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 92 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_observation_charge(VmRmObservationWork *w,uint64_t amount) {
    if(w->limited || w->used>w->limit || amount>w->limit-w->used) {
        w->limited=
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                  1
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      ;return 
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                              0
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                   ;
    }
    w->used+=amount;return 
# 96 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          1
# 96 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                              ;
}


static 
# 100 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 100 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_import_header(const VmHashMap *m) {
    return m && m->header.obj_type==TAG_HASHMAP && m->header.ref_count && m->header.buffered<=1 &&
        m->key_type==TAG_STRING && m->val_type==TAG_INT && m->entries &&
        m->bucket_count>=16 && !(m->bucket_count&(m->bucket_count-1)) &&
        sizeof(VmHMEntry)<=
# 104 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          (18446744073709551615UL)
# 104 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                  /(size_t)m->bucket_count &&
        m->count<=m->bucket_count && m->tombstone_count<=m->bucket_count-m->count;
}



static 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_ordinary_header(const VmHashMap *m) {
    return vm_rm_import_header(m) &&
        (m->header.colour==0u || m->header.colour==3u) &&
        (!m->header.buffered || m->header.colour==3u);
}
static 
# 115 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 115 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_ordinary_string(NanoValue key) {
    return vm_rm_string(key) && key.as.string->header.colour==0u;
}
VmRmHeapStatus vm_rm_ordinary_new(VmHeap *heap,VmHashMap **out) {
    if(!heap || !out || heap->gc_running || vm_rm_private_dag(heap))return VM_RM_HEAP_INVALID;
    VmHashMap *m=vm_hashmap_new(heap,TAG_STRING,TAG_INT);
    if(!m)return VM_RM_HEAP_MEMORY;
    *out=m;return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_ordinary_set(VmHeap *heap,VmHashMap *m,NanoValue key,NanoValue value) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !vm_rm_ordinary_header(m) || !vm_rm_ordinary_string(key) || value.tag!=TAG_INT)
        return VM_RM_HEAP_INVALID;
    uint32_t slot;
# 127 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 127 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    if(!hm_find_slot(m,key,&slot,&found))return VM_RM_HEAP_INVALID;
    if(found) {
        if(m->entries[slot].state!=1 || m->entries[slot].value.tag!=TAG_INT)return VM_RM_HEAP_INVALID;


        m->entries[slot].value=value;return VM_RM_HEAP_OK;
    }
    if(key.as.string->header.ref_count==
# 135 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                       (4294967295U)
# 135 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                 )return VM_RM_HEAP_RETAIN_OVERFLOW;
    if(m->entries[slot].state!=0 &&
       (m->entries[slot].state!=2 || !m->tombstone_count ||
        m->entries[slot].key.tag!=TAG_VOID || m->entries[slot].value.tag!=TAG_VOID))return VM_RM_HEAP_INVALID;
    uint64_t occupied=(uint64_t)m->count+m->tombstone_count+1;
    if((double)occupied/(double)m->bucket_count>0.75) {
        if(m->bucket_count>
# 141 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          (4294967295U)
# 141 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                    /2 || !hm_resize(heap,m,m->bucket_count*2))return VM_RM_HEAP_MEMORY;


        if(!hm_find_slot(m,key,&slot,&found) || found || m->entries[slot].state!=0)
            return VM_RM_HEAP_INVALID;
    }

    vm_retain(heap,key);
    if(m->entries[slot].state==2)m->tombstone_count--;
    m->entries[slot].key=key;m->entries[slot].value=value;
    m->entries[slot].state=1;m->count++;
    return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_ordinary_delete(VmHeap *heap,VmHashMap *m,NanoValue key) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) ||
       !vm_rm_ordinary_header(m) || !vm_rm_ordinary_string(key))return VM_RM_HEAP_INVALID;
    return vm_rm_delete_validated(heap,m,key);
}
VmRmHeapStatus vm_rm_ordinary_get(const VmHeap *heap,const VmHashMap *m,NanoValue key,NanoValue *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ordinary_header(m) || !vm_rm_ordinary_string(key))return VM_RM_HEAP_INVALID;
    uint32_t slot;
# 161 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 161 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    if(!hm_find_slot(m,key,&slot,&found))return VM_RM_HEAP_INVALID;
    NanoValue result=val_void();
    if(found) {
        if(m->entries[slot].state!=1 || m->entries[slot].value.tag!=TAG_INT)return VM_RM_HEAP_INVALID;
        result=m->entries[slot].value;
    }
    *out=result;return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_ordinary_has(const VmHeap *heap,const VmHashMap *m,NanoValue key,
# 170 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                     _Bool 
# 170 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                          *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ordinary_header(m) || !vm_rm_ordinary_string(key))return VM_RM_HEAP_INVALID;
    uint32_t slot;
# 172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    if(!hm_find_slot(m,key,&slot,&found))return VM_RM_HEAP_INVALID;
    if(found && (m->entries[slot].state!=1 || m->entries[slot].value.tag!=TAG_INT))return VM_RM_HEAP_INVALID;
    *out=found;return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_ordinary_len(const VmHeap *heap,const VmHashMap *m,uint32_t *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ordinary_header(m))return VM_RM_HEAP_INVALID;
    *out=m->count;return VM_RM_HEAP_OK;
}


static VmRmHeapStatus vm_rm_validate_tombstones(const VmHashMap *m,VmRmObservationWork *w,
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                         _Bool 
# 183 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                              ordinary) {
    uint32_t count=0,tombstones=0;
    for(uint32_t i=0;i<m->bucket_count;i++) {
        if(!vm_rm_observation_charge(w,8))return VM_RM_HEAP_LIMIT;
        const VmHMEntry *entry=&m->entries[i];
        if(!entry->state)continue;
        if(entry->state==2) {
            if(entry->key.tag!=TAG_VOID || entry->value.tag!=TAG_VOID)return VM_RM_HEAP_INVALID;
            tombstones++;continue;
        }
        if(entry->state!=1 || !vm_rm_string(entry->key) || entry->value.tag!=TAG_INT)return VM_RM_HEAP_INVALID;
        count++;
        const VmString *key=entry->key.as.string;
        if(!vm_rm_observation_charge(w,(uint64_t)key->length+1))return VM_RM_HEAP_LIMIT;
        if(ordinary && (key->header.colour!=0u || key->data[key->length]!=0))return VM_RM_HEAP_INVALID;
        if(fnv1a(key->data,key->length)!=key->hash)return VM_RM_HEAP_INVALID;
        uint32_t index=key->hash%m->bucket_count;
# 199 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                _Bool 
# 199 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                     located=
# 199 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                             0
# 199 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                  ;
        for(uint32_t probes=0;probes<m->bucket_count;probes++) {
            if(!vm_rm_observation_charge(w,4))return VM_RM_HEAP_LIMIT;
            const VmHMEntry *candidate=&m->entries[index];
            if(candidate->state==0)return VM_RM_HEAP_INVALID;
            if(candidate->state==2) {
                if(candidate->key.tag!=TAG_VOID || candidate->value.tag!=TAG_VOID)return VM_RM_HEAP_INVALID;
                index=(index+1)%m->bucket_count;continue;
            }
            if(candidate->state!=1 || !vm_rm_string(candidate->key))return VM_RM_HEAP_INVALID;
            uint64_t comparison=candidate->key.as.string->length==key->length?(uint64_t)key->length+1:1;
            if(!vm_rm_observation_charge(w,comparison))return VM_RM_HEAP_LIMIT;
            if(val_equal(candidate->key,entry->key)) {
                if(index!=i)return VM_RM_HEAP_INVALID;
                located=
# 213 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                       1
# 213 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                           ;break;
            }
            index=(index+1)%m->bucket_count;
        }
        if(!located)return VM_RM_HEAP_INVALID;
    }
    return count==m->count && tombstones==m->tombstone_count?VM_RM_HEAP_OK:VM_RM_HEAP_INVALID;
}
static VmRmHeapStatus vm_rm_validate_using(const VmHashMap *m,VmRmObservationWork *w,
# 221 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                    _Bool 
# 221 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                         ordinary) {
    if(!w || w->limit>33554432UL)return VM_RM_HEAP_INVALID;
    if(!vm_rm_observation_charge(w,16))return VM_RM_HEAP_LIMIT;
    if(!(ordinary?vm_rm_import_header(m):vm_rm_map_header(m)))return VM_RM_HEAP_INVALID;
    if(m->tombstone_count!=0)return vm_rm_validate_tombstones(m,w,ordinary);
    uint32_t count=0;
    for(uint32_t i=0;i<m->bucket_count;i++) {
        if(!vm_rm_observation_charge(w,8))return VM_RM_HEAP_LIMIT;
        const VmHMEntry *entry=&m->entries[i];
        if(!entry->state)continue;
        if(entry->state!=1 || !vm_rm_string(entry->key) || entry->value.tag!=TAG_INT)return VM_RM_HEAP_INVALID;
        count++;
        const VmString *key=entry->key.as.string;
        if(!vm_rm_observation_charge(w,(uint64_t)key->length+1))return VM_RM_HEAP_LIMIT;
        if(ordinary && (key->header.colour!=0u || key->data[key->length]!=0))return VM_RM_HEAP_INVALID;
        if(fnv1a(key->data,key->length)!=key->hash)return VM_RM_HEAP_INVALID;
        uint32_t index=key->hash%m->bucket_count;
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                _Bool 
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                     located=
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                             0
# 237 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                  ;


        for(uint32_t probes=0;probes<m->bucket_count;probes++) {
            if(!vm_rm_observation_charge(w,4))return VM_RM_HEAP_LIMIT;
            const VmHMEntry *candidate=&m->entries[index];
            if(candidate->state==0)return VM_RM_HEAP_INVALID;
            if(candidate->state!=1 || !vm_rm_string(candidate->key))return VM_RM_HEAP_INVALID;
            uint64_t comparison=candidate->key.as.string->length==key->length?(uint64_t)key->length+1:1;
            if(!vm_rm_observation_charge(w,comparison))return VM_RM_HEAP_LIMIT;
            if(val_equal(candidate->key,entry->key)) {
                if(index!=i)return VM_RM_HEAP_INVALID;
                located=
# 249 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                       1
# 249 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                           ;break;
            }
            index=(index+1)%m->bucket_count;
        }
        if(!located)return VM_RM_HEAP_INVALID;
    }
    return count==m->count?VM_RM_HEAP_OK:VM_RM_HEAP_INVALID;
}






VmRmHeapStatus vm_rm_heap_import_validate(const VmHashMap *m,VmRmObservationWork *w) {
    return vm_rm_validate_using(m,w,
# 264 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                   1
# 264 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                       );
}
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
static 
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_ss_header(const VmHashMap *m,
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                              _Bool 
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                   ordinary) {
    return m && m->header.obj_type==TAG_HASHMAP && m->header.ref_count &&
        (ordinary ? (m->header.buffered<=1 &&
          (m->header.colour==0u || m->header.colour==3u) &&
          (!m->header.buffered || m->header.colour==3u)) : !m->header.buffered) &&
        m->key_type==TAG_STRING && m->val_type==TAG_STRING && m->entries &&
        m->bucket_count>=16 && !(m->bucket_count&(m->bucket_count-1)) &&
        sizeof(VmHMEntry)<=
# 306 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          (18446744073709551615UL)
# 306 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                  /(size_t)m->bucket_count &&
        m->count<=m->bucket_count && m->tombstone_count<=m->bucket_count-m->count;
}
static 
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
      _Bool 
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
           vm_rm_ss_string(NanoValue value) {
    return vm_rm_ordinary_string(value);
}
static VmRmHeapStatus vm_rm_ss_set_validated(VmHeap *heap,VmHashMap *m,NanoValue key,NanoValue value) {
    uint32_t slot;
# 313 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 313 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;


    if(!hm_find_slot(m,key,&slot,&found))return VM_RM_HEAP_INVALID;
    VmHMEntry *entry=&m->entries[slot];
    if(found) {
        if(entry->state!=1 || !vm_rm_ss_string(entry->key) || !vm_rm_ss_string(entry->value))return VM_RM_HEAP_INVALID;
        if(value.as.string->header.ref_count==
# 320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                             (4294967295U)
# 320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                       )return VM_RM_HEAP_RETAIN_OVERFLOW;
        NanoValue old=entry->value;
        vm_retain(heap,value);entry->value=value;vm_release(heap,old);
        return VM_RM_HEAP_OK;
    }
    uint32_t needed=key.as.string==value.as.string?2:1;
    if(key.as.string->header.ref_count>
# 326 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                      (4294967295U)
# 326 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                -needed ||
       value.as.string->header.ref_count>
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                        (4294967295U)
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                  -needed)return VM_RM_HEAP_RETAIN_OVERFLOW;
    if((entry->state!=0 && entry->state!=2) ||
       entry->key.tag!=TAG_VOID || entry->value.tag!=TAG_VOID ||
       (entry->state==2 && !m->tombstone_count))return VM_RM_HEAP_INVALID;
    uint64_t occupied=(uint64_t)m->count+m->tombstone_count+1;
    if((double)occupied/(double)m->bucket_count>0.75) {
        if(m->bucket_count>
# 333 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                          (4294967295U)
# 333 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                    /2 || !hm_resize(heap,m,m->bucket_count*2))return VM_RM_HEAP_MEMORY;
        if(!hm_find_slot(m,key,&slot,&found) || found || m->entries[slot].state!=0)return VM_RM_HEAP_INVALID;
        entry=&m->entries[slot];
    }


    vm_retain(heap,key);vm_retain(heap,value);
    if(entry->state==2)m->tombstone_count--;
    entry->key=key;entry->value=value;entry->state=1;m->count++;
    return VM_RM_HEAP_OK;
}
static VmRmHeapStatus vm_rm_ss_get_validated(VmHeap *heap,const VmHashMap *m,NanoValue key,NanoValue *out) {
    uint32_t slot;
# 345 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 345 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    NanoValue result=val_void();
    if(hm_find_slot(m,key,&slot,&found) && found) {
        const VmHMEntry *entry=&m->entries[slot];
        if(entry->state!=1 || !vm_rm_ss_string(entry->value))return VM_RM_HEAP_INVALID;
        result=entry->value;
        if(result.as.string->header.ref_count==
# 351 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                              (4294967295U)
# 351 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                        )return VM_RM_HEAP_RETAIN_OVERFLOW;
        vm_retain(heap,result);
    }
    *out=result;return VM_RM_HEAP_OK;
}
static VmRmHeapStatus vm_rm_ss_has_validated(const VmHashMap *m,NanoValue key,
# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                             _Bool 
# 356 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                  *out) {
    uint32_t slot;
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found=
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                            0
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                 ;
    if(!hm_find_slot(m,key,&slot,&found))found=
# 358 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                              0
# 358 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                   ;
    if(found && (m->entries[slot].state!=1 || !vm_rm_ss_string(m->entries[slot].value)))return VM_RM_HEAP_INVALID;
    *out=found;return VM_RM_HEAP_OK;
}
static VmRmHeapStatus vm_rm_ss_delete_validated(VmHeap *heap,VmHashMap *m,NanoValue key) {
    uint32_t slot;
# 363 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                 _Bool 
# 363 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                      found;
    if(!hm_find_slot(m,key,&slot,&found) || !found)return VM_RM_HEAP_OK;
    VmHMEntry *entry=&m->entries[slot];
    if(entry->state!=1 || !vm_rm_ss_string(entry->key) || !vm_rm_ss_string(entry->value) || !m->count)return VM_RM_HEAP_INVALID;
    NanoValue stored_key=entry->key,stored_value=entry->value;
    entry->key=val_void();entry->value=val_void();entry->state=2;
    m->count--;m->tombstone_count++;
    vm_release(heap,stored_key);vm_release(heap,stored_value);
    return VM_RM_HEAP_OK;
}
static VmRmHeapStatus vm_rm_ss_validate_using(const VmHashMap *m,VmRmObservationWork *w,
# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                       _Bool 
# 373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                            ordinary) {
    if(!w || w->used>w->limit || w->limit>33554432UL)return VM_RM_HEAP_INVALID;
    if(!vm_rm_observation_charge(w,16))return VM_RM_HEAP_LIMIT;
    if(!vm_rm_ss_header(m,ordinary))return VM_RM_HEAP_INVALID;
    uint32_t count=0,tombstones=0;
    for(uint32_t i=0;i<m->bucket_count;i++) {
        if(!vm_rm_observation_charge(w,8))return VM_RM_HEAP_LIMIT;
        const VmHMEntry *entry=&m->entries[i];
        if(entry->state!=1) {
            if(entry->state>2 || entry->key.tag!=TAG_VOID || entry->value.tag!=TAG_VOID)return VM_RM_HEAP_INVALID;
            if(entry->state==2)tombstones++;
            continue;
        }
        if(!vm_rm_ss_string(entry->key))return VM_RM_HEAP_INVALID;


        if(!vm_rm_observation_charge(w,16))return VM_RM_HEAP_LIMIT;
        if(!vm_rm_ss_string(entry->value))return VM_RM_HEAP_INVALID;
        const VmString *value=entry->value.as.string,*key=entry->key.as.string;
        if(!vm_rm_observation_charge(w,(uint64_t)value->length+1))return VM_RM_HEAP_LIMIT;
        if(value->data[value->length]!=0 || fnv1a(value->data,value->length)!=value->hash)return VM_RM_HEAP_INVALID;
        if(!vm_rm_observation_charge(w,(uint64_t)key->length+1))return VM_RM_HEAP_LIMIT;
        if(key->data[key->length]!=0 || fnv1a(key->data,key->length)!=key->hash)return VM_RM_HEAP_INVALID;
        count++;
        uint32_t index=key->hash%m->bucket_count;
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                _Bool 
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                     located=
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                             0
# 397 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                  ;
        for(uint32_t probes=0;probes<m->bucket_count;probes++) {
            if(!vm_rm_observation_charge(w,4))return VM_RM_HEAP_LIMIT;
            const VmHMEntry *candidate=&m->entries[index];
            if(candidate->state==0)return VM_RM_HEAP_INVALID;
            if(candidate->state==2) {
                if(candidate->key.tag!=TAG_VOID || candidate->value.tag!=TAG_VOID)return VM_RM_HEAP_INVALID;
                index=(index+1)%m->bucket_count;continue;
            }
            if(candidate->state!=1 || !vm_rm_ss_string(candidate->key))return VM_RM_HEAP_INVALID;
            uint64_t comparison=candidate->key.as.string->length==key->length?(uint64_t)key->length+1:1;
            if(!vm_rm_observation_charge(w,comparison))return VM_RM_HEAP_LIMIT;
            if(val_equal(candidate->key,entry->key)) {
                if(index!=i)return VM_RM_HEAP_INVALID;
                located=
# 411 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                       1
# 411 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                           ;break;
            }
            index=(index+1)%m->bucket_count;
        }
        if(!located)return VM_RM_HEAP_INVALID;
    }
    return count==m->count && tombstones==m->tombstone_count?VM_RM_HEAP_OK:VM_RM_HEAP_INVALID;
}
# 451 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
VmRmHeapStatus vm_rm_ordinary_ss_new(VmHeap *heap,VmHashMap **out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out)return VM_RM_HEAP_INVALID;
    VmHashMap *m=vm_hashmap_new(heap,TAG_STRING,TAG_STRING);
    if(!m)return VM_RM_HEAP_MEMORY;
    *out=m;return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_ordinary_ss_set(VmHeap *heap,VmHashMap *m,NanoValue key,NanoValue value) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !vm_rm_ss_header(m,
# 458 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                 1
# 458 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                     ) || !vm_rm_ss_string(key) || !vm_rm_ss_string(value))return VM_RM_HEAP_INVALID;
    return vm_rm_ss_set_validated(heap,m,key,value);
}
VmRmHeapStatus vm_rm_ordinary_ss_get_owned(VmHeap *heap,const VmHashMap *m,NanoValue key,NanoValue *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ss_header(m,
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                         1
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                             ) || !vm_rm_ss_string(key))return VM_RM_HEAP_INVALID;
    return vm_rm_ss_get_validated(heap,m,key,out);
}
VmRmHeapStatus vm_rm_ordinary_ss_delete(VmHeap *heap,VmHashMap *m,NanoValue key) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !vm_rm_ss_header(m,
# 466 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                 1
# 466 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                     ) || !vm_rm_ss_string(key))return VM_RM_HEAP_INVALID;
    return vm_rm_ss_delete_validated(heap,m,key);
}
VmRmHeapStatus vm_rm_ordinary_ss_has(const VmHeap *heap,const VmHashMap *m,NanoValue key,
# 469 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                        _Bool 
# 469 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                             *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ss_header(m,
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                         1
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                             ) || !vm_rm_ss_string(key))return VM_RM_HEAP_INVALID;
    return vm_rm_ss_has_validated(m,key,out);
}
VmRmHeapStatus vm_rm_ordinary_ss_len(const VmHeap *heap,const VmHashMap *m,uint32_t *out) {
    if(!heap || heap->gc_running || vm_rm_private_dag(heap) || !out || !vm_rm_ss_header(m,
# 474 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                                                                         1
# 474 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                                                                             ))return VM_RM_HEAP_INVALID;
    *out=m->count;return VM_RM_HEAP_OK;
}
VmRmHeapStatus vm_rm_heap_ss_import_validate(const VmHashMap *m,VmRmObservationWork *w) {
    return vm_rm_ss_validate_using(m,w,
# 478 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc" 3 4
                                      1
# 478 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/record_map_heap.inc"
                                          );
}
# 1037 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 2

NanoValue vm_hashmap_get(VmHashMap *m, NanoValue key) {
    uint32_t slot;
    
# 1040 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   _Bool 
# 1040 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
        found;
    if (hm_find_slot(m, key, &slot, &found) && found) return m->entries[slot].value;
    return val_void();
}


# 1045 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 1045 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vm_hashmap_set(VmHeap *heap, VmHashMap *m, NanoValue key, NanoValue value) {
    uint32_t slot;
    
# 1047 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   _Bool 
# 1047 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
        found;
    if (!hm_find_slot(m, key, &slot, &found)) return 
# 1048 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                    0
# 1048 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                         ;
    if (found) {
        VmHMEntry *entry = &m->entries[slot];
        NanoValue previous = entry->value;
        vm_retain(heap, value);
        entry->value = value;
        vm_release(heap, previous);
        return 
# 1055 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
              1
# 1055 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                  ;
    }
    uint64_t occupied = (uint64_t)m->count + m->tombstone_count + 1;
    if ((double)occupied / (double)m->bucket_count > 0.75) {
        if (m->bucket_count > 
# 1059 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                             (4294967295U) 
# 1059 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                        / 2 || !hm_resize(heap, m, m->bucket_count * 2)) return 
# 1059 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                                                                0
# 1059 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                                                                     ;
        if (!hm_find_slot(m, key, &slot, &found)) return 
# 1060 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                                                        0
# 1060 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                                                             ;
    }
    VmHMEntry *entry = &m->entries[slot];
    if (entry->state == 2) m->tombstone_count--;
    entry->state = 1;
    entry->key = key;
    entry->value = value;
    vm_retain(heap, key);
    vm_retain(heap, value);
    m->count++;
    return 
# 1070 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
          1
# 1070 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
              ;
}


# 1073 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
_Bool 
# 1073 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
    vm_hashmap_has(VmHashMap *m, NanoValue key) {
    uint32_t slot;
    
# 1075 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   _Bool 
# 1075 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
        found;
    return hm_find_slot(m, key, &slot, &found) && found;
}

void vm_hashmap_delete(VmHeap *heap, VmHashMap *m, NanoValue key) {
    uint32_t slot;
    
# 1081 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
   _Bool 
# 1081 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
        found;
    if (!hm_find_slot(m, key, &slot, &found) || !found) return;
    VmHMEntry *entry = &m->entries[slot];
    NanoValue previous_key = entry->key, previous_value = entry->value;
    entry->key = val_void();
    entry->value = val_void();
    entry->state = 2;
    m->count--;
    m->tombstone_count++;
    vm_release(heap, previous_key);
    vm_release(heap, previous_value);
}

VmArray *vm_hashmap_keys(VmHeap *heap, VmHashMap *m) {
    VmArray *result = vm_array_new(heap, m->key_type, m->count > 0 ? m->count : 8);
    if (!result) return 
# 1096 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                       ((void *)0)
# 1096 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                           ;
    for (uint32_t i = 0; i < m->bucket_count; i++) {
        VmHMEntry *entry = &m->entries[i];
        if (entry->state == 1 && !vm_array_push(heap, result, entry->key)) {
            vm_release(heap, val_array(result));
            return 
# 1101 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 1101 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
        }
    }
    return result;
}

VmArray *vm_hashmap_values(VmHeap *heap, VmHashMap *m) {
    VmArray *result = vm_array_new(heap, m->val_type, m->count > 0 ? m->count : 8);
    if (!result) return 
# 1109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                       ((void *)0)
# 1109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                           ;
    for (uint32_t i = 0; i < m->bucket_count; i++) {
        VmHMEntry *entry = &m->entries[i];
        if (entry->state == 1 && !vm_array_push(heap, result, entry->value)) {
            vm_release(heap, val_array(result));
            return 
# 1114 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c" 3 4
                  ((void *)0)
# 1114 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/nanoisa/../../src/nanovm/heap.c"
                      ;
        }
    }
    return result;
}
