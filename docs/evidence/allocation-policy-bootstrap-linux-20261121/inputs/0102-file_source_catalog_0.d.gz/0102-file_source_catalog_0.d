nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/file_source_catalog.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/file_source_plan.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/service_source_catalog.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi_socket_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi_service_catalog.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi_websocket_plan.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi_file_catalog.h \
 /home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_catalog/../../src/nanoisa/../nsi_file_plan.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/stdio.h /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h /usr/include/inttypes.h
