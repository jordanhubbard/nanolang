# 0 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"



# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.h" 1




const char *nlc_module_artifact(const char *source_path);


const char *nlc_module_header_constants(const char *source_path);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 1
# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 1
# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 40 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;






typedef __off64_t off64_t;






typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4




extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream)
    __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 97 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 114 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 153 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));



# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 552 "/usr/include/string.h" 3 4

# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/include/ctype.h" 1 3 4
# 28 "/usr/include/ctype.h" 3 4

# 46 "/usr/include/ctype.h" 3 4
enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};
# 79 "/usr/include/ctype.h" 3 4
extern const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 108 "/usr/include/ctype.h" 3 4
extern int isalnum (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha (int) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit (int) __attribute__ ((__nothrow__ , __leaf__));
extern int islower (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint (int) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper (int) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit (int) __attribute__ ((__nothrow__ , __leaf__));



extern int tolower (int __c) __attribute__ ((__nothrow__ , __leaf__));


extern int toupper (int __c) __attribute__ ((__nothrow__ , __leaf__));




extern int isblank (int) __attribute__ ((__nothrow__ , __leaf__));




extern int isctype (int __c, int __mask) __attribute__ ((__nothrow__ , __leaf__));






extern int isascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



extern int toascii (int __c) __attribute__ ((__nothrow__ , __leaf__));



extern int _toupper (int) __attribute__ ((__nothrow__ , __leaf__));
extern int _tolower (int) __attribute__ ((__nothrow__ , __leaf__));
# 251 "/usr/include/ctype.h" 3 4
extern int isalnum_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isalpha_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int iscntrl_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isdigit_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int islower_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isgraph_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isprint_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int ispunct_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isspace_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isupper_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));
extern int isxdigit_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));

extern int isblank_l (int, locale_t) __attribute__ ((__nothrow__ , __leaf__));



extern int __tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));


extern int __toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
extern int toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 327 "/usr/include/ctype.h" 3 4

# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 17 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/include/assert.h" 1 3 4
# 66 "/usr/include/assert.h" 3 4



extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));


extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



# 18 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2

# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 1







# 1 "src/runtime/dyn_array.h" 1
# 9 "src/runtime/dyn_array.h"
# 1 "src/runtime/gc.h" 1
# 17 "src/runtime/gc.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 18 "src/runtime/gc.h" 2




# 21 "src/runtime/gc.h"
typedef enum {
    GC_TYPE_ARRAY = 1,
    GC_TYPE_STRING = 2,
    GC_TYPE_STRUCT = 3,
    GC_TYPE_CLOSURE = 4,
    GC_TYPE_OPAQUE = 5
} GCObjectType;


typedef void (*GCFinalizer)(void* object);


typedef struct GCHeader {
    uint32_t ref_count;
    uint8_t type;
    uint8_t marked;
    uint16_t flags;
    size_t size;
    struct GCHeader* next;
    struct GCHeader* prev;
    GCFinalizer finalizer;
} GCHeader;


typedef struct {
    size_t total_allocated;
    size_t total_freed;
    size_t current_usage;
    size_t num_objects;
    size_t num_collections;
} GCStats;


void gc_init(void);


void gc_shutdown(void);


void* gc_alloc(size_t size, GCObjectType type);


void gc_retain(void* ptr);


void gc_release(void* ptr);


void gc_collect_cycles(void);


void gc_collect_all(void);


GCStats gc_get_stats(void);


void gc_print_stats(void);


static inline GCHeader* gc_get_header(void* ptr) {
    return (GCHeader*)((char*)ptr - sizeof(GCHeader));
}


static inline void* gc_header_to_ptr(GCHeader* header) {
    return (void*)((char*)header + sizeof(GCHeader));
}



# 91 "src/runtime/gc.h" 3 4
_Bool 
# 91 "src/runtime/gc.h"
    gc_is_managed(void* ptr);


void gc_set_cycle_detection_enabled(
# 94 "src/runtime/gc.h" 3 4
                                   _Bool 
# 94 "src/runtime/gc.h"
                                        enabled);


void gc_set_threshold(size_t bytes);


char* gc_alloc_string(size_t length);


void* gc_alloc_opaque(size_t size, GCFinalizer finalizer);




void* gc_wrap_external(void* external_ptr, GCFinalizer finalizer);


void* gc_unwrap(void* wrapper_ptr);


void gc_set_finalizer(void* ptr, GCFinalizer finalizer);
# 10 "src/runtime/dyn_array.h" 2
# 33 "src/runtime/dyn_array.h"
typedef enum { ELEM_INT = 1, ELEM_U8 = 8, ELEM_FLOAT = 2, ELEM_STRING = 3, ELEM_BOOL = 4, ELEM_ARRAY = 5, ELEM_STRUCT = 6, ELEM_POINTER = 7 } ElementType; typedef struct { int64_t length; int64_t capacity; ElementType elem_type; uint8_t elem_size; void *data; } DynArray;



static inline 
# 37 "src/runtime/dyn_array.h" 3 4
             _Bool 
# 37 "src/runtime/dyn_array.h"
                  dyn_array_has_storage(const DynArray *array, ElementType type,
                                         size_t width, uint64_t bytes) {
    if (!array || !array->data || array->elem_type != type || !width ||
        array->elem_size != width || array->length < 0 || array->capacity < array->length ||
        (uint64_t)array->length > 
# 41 "src/runtime/dyn_array.h" 3 4
                                 (18446744073709551615UL) 
# 41 "src/runtime/dyn_array.h"
                                          / width) return 
# 41 "src/runtime/dyn_array.h" 3 4
                                                          0
# 41 "src/runtime/dyn_array.h"
                                                               ;
    return bytes <= (uint64_t)array->length * width;
}







DynArray* dyn_array_new(ElementType elem_type);


DynArray* dyn_array_new_with_capacity(ElementType elem_type, int64_t initial_capacity);


DynArray* dyn_array_push_int(DynArray* arr, int64_t value);
DynArray* dyn_array_push_u8(DynArray* arr, uint8_t value);
DynArray* dyn_array_push_float(DynArray* arr, double value);
DynArray* dyn_array_push_bool(DynArray* arr, 
# 60 "src/runtime/dyn_array.h" 3 4
                                            _Bool 
# 60 "src/runtime/dyn_array.h"
                                                 value);
DynArray* dyn_array_push_string(DynArray* arr, const char* value);
DynArray* dyn_array_push_string_copy(DynArray* arr, const char* value);
DynArray* dyn_array_push_array(DynArray* arr, DynArray* value);


int64_t dyn_array_pop_int(DynArray* arr, 
# 66 "src/runtime/dyn_array.h" 3 4
                                        _Bool
# 66 "src/runtime/dyn_array.h"
                                            * success);
uint8_t dyn_array_pop_u8(DynArray* arr, 
# 67 "src/runtime/dyn_array.h" 3 4
                                       _Bool
# 67 "src/runtime/dyn_array.h"
                                           * success);
double dyn_array_pop_float(DynArray* arr, 
# 68 "src/runtime/dyn_array.h" 3 4
                                         _Bool
# 68 "src/runtime/dyn_array.h"
                                             * success);

# 69 "src/runtime/dyn_array.h" 3 4
_Bool 
# 69 "src/runtime/dyn_array.h"
    dyn_array_pop_bool(DynArray* arr, 
# 69 "src/runtime/dyn_array.h" 3 4
                                      _Bool
# 69 "src/runtime/dyn_array.h"
                                          * success);
const char* dyn_array_pop_string(DynArray* arr, 
# 70 "src/runtime/dyn_array.h" 3 4
                                               _Bool
# 70 "src/runtime/dyn_array.h"
                                                   * success);
DynArray* dyn_array_pop_array(DynArray* arr, 
# 71 "src/runtime/dyn_array.h" 3 4
                                            _Bool
# 71 "src/runtime/dyn_array.h"
                                                * success);


int64_t dyn_array_get_int(DynArray* arr, int64_t index);
uint8_t dyn_array_get_u8(DynArray* arr, int64_t index);
double dyn_array_get_float(DynArray* arr, int64_t index);

# 77 "src/runtime/dyn_array.h" 3 4
_Bool 
# 77 "src/runtime/dyn_array.h"
    dyn_array_get_bool(DynArray* arr, int64_t index);
char* dyn_array_get_string(DynArray* arr, int64_t index);
DynArray* dyn_array_get_array(DynArray* arr, int64_t index);


void dyn_array_set_int(DynArray* arr, int64_t index, int64_t value);
void dyn_array_set_u8(DynArray* arr, int64_t index, uint8_t value);
void dyn_array_set_float(DynArray* arr, int64_t index, double value);
void dyn_array_set_bool(DynArray* arr, int64_t index, 
# 85 "src/runtime/dyn_array.h" 3 4
                                                     _Bool 
# 85 "src/runtime/dyn_array.h"
                                                          value);
void dyn_array_set_string(DynArray* arr, int64_t index, const char* value);
void dyn_array_set_array(DynArray* arr, int64_t index, DynArray* value);


DynArray* dyn_array_remove_at(DynArray* arr, int64_t index);


DynArray* dyn_array_insert_int(DynArray* arr, int64_t index, int64_t value);
DynArray* dyn_array_insert_float(DynArray* arr, int64_t index, double value);
DynArray* dyn_array_insert_bool(DynArray* arr, int64_t index, 
# 95 "src/runtime/dyn_array.h" 3 4
                                                             _Bool 
# 95 "src/runtime/dyn_array.h"
                                                                  value);
DynArray* dyn_array_insert_string(DynArray* arr, int64_t index, const char* value);


void dyn_array_clear(DynArray* arr);


int64_t dyn_array_length(DynArray* arr);


int64_t dyn_array_capacity(DynArray* arr);


ElementType dyn_array_get_elem_type(DynArray* arr);


void dyn_array_reserve(DynArray* arr, int64_t new_capacity);


DynArray* dyn_array_clone(DynArray* arr);


DynArray* dyn_array_sorted(DynArray* arr);


DynArray* dyn_array_push_struct(DynArray* arr, const void* struct_ptr, size_t struct_size);
void* dyn_array_get_struct(DynArray* arr, int64_t index);
void dyn_array_set_struct(DynArray* arr, int64_t index, const void* struct_ptr, size_t struct_size);
void dyn_array_pop_struct(DynArray* arr, void* out_struct, size_t struct_size, 
# 123 "src/runtime/dyn_array.h" 3 4
                                                                              _Bool
# 123 "src/runtime/dyn_array.h"
                                                                                  * success);
# 9 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 2




typedef struct List_ASTArrayLiteral List_ASTArrayLiteral;



typedef struct List_ASTAssert List_ASTAssert;



typedef struct List_ASTBinaryOp List_ASTBinaryOp;



typedef struct List_ASTBlock List_ASTBlock;



typedef struct List_ASTBool List_ASTBool;



typedef struct List_ASTCall List_ASTCall;



typedef struct List_ASTEnum List_ASTEnum;



typedef struct List_ASTFieldAccess List_ASTFieldAccess;



typedef struct List_ASTFloat List_ASTFloat;



typedef struct List_ASTFor List_ASTFor;



typedef struct List_ASTFunction List_ASTFunction;



typedef struct List_ASTIdentifier List_ASTIdentifier;



typedef struct List_ASTIf List_ASTIf;



typedef struct List_ASTImport List_ASTImport;



typedef struct List_ASTLet List_ASTLet;



typedef struct List_ASTMatch List_ASTMatch;



typedef struct List_ASTModuleQualifiedCall List_ASTModuleQualifiedCall;



typedef struct List_ASTNumber List_ASTNumber;



typedef struct List_ASTOpaqueType List_ASTOpaqueType;



typedef struct List_ASTPrint List_ASTPrint;



typedef struct List_ASTReturn List_ASTReturn;



typedef struct List_ASTServiceDecl List_ASTServiceDecl;



typedef struct List_ASTSet List_ASTSet;



typedef struct List_ASTShadow List_ASTShadow;



typedef struct List_ASTStmtRef List_ASTStmtRef;



typedef struct List_ASTString List_ASTString;



typedef struct List_ASTStruct List_ASTStruct;



typedef struct List_ASTStructLiteral List_ASTStructLiteral;



typedef struct List_ASTTupleIndex List_ASTTupleIndex;



typedef struct List_ASTTupleLiteral List_ASTTupleLiteral;



typedef struct List_ASTUnion List_ASTUnion;



typedef struct List_ASTUnionConstruct List_ASTUnionConstruct;



typedef struct List_ASTUnsafeBlock List_ASTUnsafeBlock;



typedef struct List_ASTWhile List_ASTWhile;



typedef struct List_CompilerDiagnostic List_CompilerDiagnostic;



typedef struct List_LexerToken List_LexerToken;




typedef enum DiagnosticSeverity {
    DiagnosticSeverity_DIAG_INFO,
    DiagnosticSeverity_DIAG_WARNING,
    DiagnosticSeverity_DIAG_ERROR
} DiagnosticSeverity;




typedef enum CompilerPhase {
    CompilerPhase_PHASE_LEXER,
    CompilerPhase_PHASE_PARSER,
    CompilerPhase_PHASE_TYPECHECK,
    CompilerPhase_PHASE_NANOISA,
    CompilerPhase_PHASE_RUNTIME,
    CompilerPhase_PHASE_BACKEND
} CompilerPhase;


typedef enum {
    TOKEN_EOF = 0,
    TOKEN_NUMBER = 1,
    TOKEN_FLOAT = 2,
    TOKEN_STRING = 3,
    TOKEN_IDENTIFIER = 4,
    TOKEN_TRUE = 5,
    TOKEN_FALSE = 6,
    TOKEN_LPAREN = 7,
    TOKEN_RPAREN = 8,
    TOKEN_LBRACE = 9,
    TOKEN_RBRACE = 10,
    TOKEN_LBRACKET = 11,
    TOKEN_RBRACKET = 12,
    TOKEN_COMMA = 13,
    TOKEN_COLON = 14,
    TOKEN_DOUBLE_COLON = 15,
    TOKEN_ARROW = 16,
    TOKEN_ASSIGN = 17,
    TOKEN_DOT = 18,
    TOKEN_MODULE = 19,
    TOKEN_PUB = 20,
    TOKEN_FROM = 21,
    TOKEN_USE = 22,
    TOKEN_EXTERN = 23,
    TOKEN_FN = 24,
    TOKEN_LET = 25,
    TOKEN_MUT = 26,
    TOKEN_SET = 27,
    TOKEN_IF = 28,
    TOKEN_ELSE = 29,
    TOKEN_COND = 30,
    TOKEN_WHILE = 31,
    TOKEN_FOR = 32,
    TOKEN_IN = 33,
    TOKEN_RETURN = 34,
    TOKEN_BREAK = 35,
    TOKEN_CONTINUE = 36,
    TOKEN_ASSERT = 37,
    TOKEN_SHADOW = 38,
    TOKEN_REQUIRES = 39,
    TOKEN_ENSURES = 40,
    TOKEN_PRINT = 41,
    TOKEN_ARRAY = 42,
    TOKEN_STRUCT = 43,
    TOKEN_ENUM = 44,
    TOKEN_UNION = 45,
    TOKEN_MATCH = 46,
    TOKEN_IMPORT = 47,
    TOKEN_AS = 48,
    TOKEN_OPAQUE = 49,
    TOKEN_TYPE_INT = 50,
    TOKEN_TYPE_U8 = 51,
    TOKEN_TYPE_FLOAT = 52,
    TOKEN_TYPE_BOOL = 53,
    TOKEN_TYPE_STRING = 54,
    TOKEN_TYPE_BSTRING = 55,
    TOKEN_TYPE_VOID = 56,
    TOKEN_PLUS = 57,
    TOKEN_MINUS = 58,
    TOKEN_STAR = 59,
    TOKEN_SLASH = 60,
    TOKEN_PERCENT = 61,
    TOKEN_EQ = 62,
    TOKEN_NE = 63,
    TOKEN_LT = 64,
    TOKEN_LE = 65,
    TOKEN_GT = 66,
    TOKEN_GE = 67,
    TOKEN_AND = 68,
    TOKEN_OR = 69,
    TOKEN_NOT = 70,
    TOKEN_RANGE = 71,
    TOKEN_UNSAFE = 72,
    TOKEN_RESOURCE = 73,
    TOKEN_PIPE = 74,
    TOKEN_GRAMMAR = 75,
    TOKEN_LARROW = 76,
    TOKEN_QUESTION = 77,
    TOKEN_PAR = 78,
    TOKEN_BAR = 79,
    TOKEN_EFFECT = 80,
    TOKEN_HANDLE = 81,
    TOKEN_WITH = 82,
    TOKEN_RESUME = 83,
    TOKEN_GPU = 84,
    TOKEN_ASYNC = 85,
    TOKEN_AWAIT = 86,
    TOKEN_PURE = 87,
    TOKEN_AMPERSAND = 88
} TokenType;

typedef enum {
    PNODE_NUMBER = 0,
    PNODE_FLOAT = 1,
    PNODE_STRING = 2,
    PNODE_BOOL = 3,
    PNODE_IDENTIFIER = 4,
    PNODE_BINARY_OP = 5,
    PNODE_CALL = 6,
    PNODE_ARRAY_LITERAL = 7,
    PNODE_LET = 8,
    PNODE_SET = 9,
    PNODE_IF = 10,
    PNODE_COND = 11,
    PNODE_WHILE = 12,
    PNODE_FOR = 13,
    PNODE_RETURN = 14,
    PNODE_BREAK = 15,
    PNODE_CONTINUE = 16,
    PNODE_BLOCK = 17,
    PNODE_PRINT = 18,
    PNODE_ASSERT = 19,
    PNODE_PROGRAM = 20,
    PNODE_FUNCTION = 21,
    PNODE_SHADOW = 22,
    PNODE_STRUCT_DEF = 23,
    PNODE_STRUCT_LITERAL = 24,
    PNODE_FIELD_ACCESS = 25,
    PNODE_ENUM_DEF = 26,
    PNODE_UNION_DEF = 27,
    PNODE_UNION_CONSTRUCT = 28,
    PNODE_MATCH = 29,
    PNODE_IMPORT = 30,
    PNODE_OPAQUE_TYPE = 31,
    PNODE_TUPLE_LITERAL = 32,
    PNODE_TUPLE_INDEX = 33,
    PNODE_STRUCT = 34,
    PNODE_ENUM = 35,
    PNODE_UNION = 36,
    PNODE_UNSAFE_BLOCK = 37,
    PNODE_MODULE_QUALIFIED_CALL = 38,
    PNODE_GRAMMAR = 39,
    PNODE_PAR_BLOCK = 40,
    PNODE_EFFECT_DECL = 41,
    PNODE_HANDLE_EXPR = 42,
    PNODE_ASYNC_FN = 43,
    PNODE_SERVICE_DECL = 44,
    PNODE_LAMBDA = 45,
    PNODE_EFFECT_OP = 46
} ParseNodeType;



typedef struct nl_LexerToken {
    int token_type;
    const char * value;
    int line;
    int column;
    int64_t value_bytes;
} nl_LexerToken;
typedef nl_LexerToken LexerToken;
typedef nl_LexerToken Token;




typedef struct nl_ParseNode {
    int node_type;
    int line;
    int column;
} nl_ParseNode;
typedef nl_ParseNode ParseNode;




typedef struct nl_ASTNumber {
    int node_type;
    int line;
    int column;
    const char * value;
} nl_ASTNumber;
typedef nl_ASTNumber ASTNumber;




typedef struct nl_ASTFloat {
    int node_type;
    int line;
    int column;
    const char * value;
} nl_ASTFloat;
typedef nl_ASTFloat ASTFloat;




typedef struct nl_ASTString {
    int node_type;
    int line;
    int column;
    const char * value;
} nl_ASTString;
typedef nl_ASTString ASTString;




typedef struct nl_ASTBool {
    int node_type;
    int line;
    int column;
    
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        value;
} nl_ASTBool;
typedef nl_ASTBool ASTBool;




typedef struct nl_ASTIdentifier {
    int node_type;
    int line;
    int column;
    const char * name;
    DynArray * affine_owner;
    int affine_epoch;
    int checked_affine_use;
} nl_ASTIdentifier;
typedef nl_ASTIdentifier ASTIdentifier;




typedef struct nl_ASTBinaryOp {
    int node_type;
    int line;
    int column;
    int op;
    int left;
    int right;
    int left_type;
    int right_type;
    
# 411 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 411 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_unary;
} nl_ASTBinaryOp;
typedef nl_ASTBinaryOp ASTBinaryOp;




typedef struct nl_ASTCall {
    int node_type;
    int line;
    int column;
    int function;
    int function_type;
    int arg_start;
    int arg_count;
    int borrow_mode;
} nl_ASTCall;
typedef nl_ASTCall ASTCall;




typedef struct nl_ASTModuleQualifiedCall {
    int node_type;
    int line;
    int column;
    const char * module_name;
    const char * function_name;
    int arg_start;
    int arg_count;
} nl_ASTModuleQualifiedCall;
typedef nl_ASTModuleQualifiedCall ASTModuleQualifiedCall;




typedef struct nl_ASTArrayLiteral {
    int node_type;
    int line;
    int column;
    const char * element_type;
    int element_start;
    int element_count;
} nl_ASTArrayLiteral;
typedef nl_ASTArrayLiteral ASTArrayLiteral;




typedef struct nl_ASTLet {
    int node_type;
    int line;
    int column;
    const char * name;
    const char * var_type;
    int value;
    int value_type;
    
# 468 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 468 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_mut;
    
# 469 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 469 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_pub;
    
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_generated;
    
# 471 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 471 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_destructure;
    
# 472 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 472 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_destructure_projection;
    DynArray * destructure_names;
} nl_ASTLet;
typedef nl_ASTLet ASTLet;




typedef struct nl_ASTSet {
    int node_type;
    int line;
    int column;
    const char * target;
    int value;
    int value_type;
    const char * field_name;
} nl_ASTSet;
typedef nl_ASTSet ASTSet;




typedef struct nl_ASTStmtRef {
    int node_id;
    int node_type;
} nl_ASTStmtRef;
typedef nl_ASTStmtRef ASTStmtRef;




typedef struct nl_ASTIf {
    int node_type;
    int line;
    int column;
    int condition;
    int condition_type;
    int then_body;
    int else_body;
} nl_ASTIf;
typedef nl_ASTIf ASTIf;




typedef struct nl_ASTWhile {
    int node_type;
    int line;
    int column;
    int condition;
    int condition_type;
    int body;
} nl_ASTWhile;
typedef nl_ASTWhile ASTWhile;




typedef struct nl_ASTFor {
    int node_type;
    int line;
    int column;
    const char * var_name;
    int iterable;
    int iterable_type;
    int body;
} nl_ASTFor;
typedef nl_ASTFor ASTFor;




typedef struct nl_ASTReturn {
    int node_type;
    int line;
    int column;
    int value;
    int value_type;
} nl_ASTReturn;
typedef nl_ASTReturn ASTReturn;




typedef struct nl_ASTBlock {
    int node_type;
    int line;
    int column;
    List_ASTStmtRef * statements;
    
# 561 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 561 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_par;
    
# 562 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 562 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_flow;
    
# 563 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 563 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_legacy_par;
} nl_ASTBlock;
typedef nl_ASTBlock ASTBlock;




typedef struct nl_ASTUnsafeBlock {
    int node_type;
    int line;
    int column;
    List_ASTStmtRef * statements;
} nl_ASTUnsafeBlock;
typedef nl_ASTUnsafeBlock ASTUnsafeBlock;




typedef struct nl_ASTPrint {
    int node_type;
    int line;
    int column;
    int value;
    int value_type;
    
# 587 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 587 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_println;
} nl_ASTPrint;
typedef nl_ASTPrint ASTPrint;




typedef struct nl_ASTAssert {
    int node_type;
    int line;
    int column;
    int condition;
    int condition_type;
} nl_ASTAssert;
typedef nl_ASTAssert ASTAssert;




typedef struct nl_ASTFunction {
    int node_type;
    int line;
    int column;
    const char * name;
    int param_start;
    int param_count;
    const char * return_type;
    int body;
    
# 615 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 615 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_pure;
    const char * self_name;
    int checked_affine;
    DynArray * affine_owner;
    int affine_completed_epoch;
} nl_ASTFunction;
typedef nl_ASTFunction ASTFunction;




typedef struct nl_ASTShadow {
    int node_type;
    int line;
    int column;
    const char * target_name;
    int body;
} nl_ASTShadow;
typedef nl_ASTShadow ASTShadow;




typedef struct nl_ASTStruct {
    int node_type;
    int line;
    int column;
    const char * name;
    int field_start;
    int field_count;
    DynArray * field_names;
    DynArray * field_types;
    
# 647 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 647 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_resource;
    
# 648 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 648 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_extern;
} nl_ASTStruct;
typedef nl_ASTStruct ASTStruct;




typedef struct nl_ASTStructLiteral {
    int node_type;
    int line;
    int column;
    const char * struct_name;
    DynArray * field_names;
    DynArray * field_value_ids;
    DynArray * field_value_types;
    int field_count;
} nl_ASTStructLiteral;
typedef nl_ASTStructLiteral ASTStructLiteral;




typedef struct nl_ASTFieldAccess {
    int node_type;
    int line;
    int column;
    int object;
    int object_type;
    const char * field_name;
} nl_ASTFieldAccess;
typedef nl_ASTFieldAccess ASTFieldAccess;




typedef struct nl_ASTEnum {
    int node_type;
    int line;
    int column;
    const char * name;
    int variant_count;
    DynArray * variant_names;
    DynArray * variant_values;
} nl_ASTEnum;
typedef nl_ASTEnum ASTEnum;




typedef struct nl_ASTUnion {
    int node_type;
    int line;
    int column;
    const char * name;
    int variant_count;
    DynArray * variant_names;
    DynArray * variant_field_counts;
    DynArray * variant_field_names;
    DynArray * variant_field_types;
    DynArray * generic_params;
    int generic_param_count;
} nl_ASTUnion;
typedef nl_ASTUnion ASTUnion;




typedef struct nl_ASTUnionConstruct {
    int node_type;
    int line;
    int column;
    const char * union_name;
    const char * variant_name;
    DynArray * field_names;
    DynArray * field_value_ids;
    DynArray * field_value_types;
    int field_count;
} nl_ASTUnionConstruct;
typedef nl_ASTUnionConstruct ASTUnionConstruct;




typedef struct nl_ASTMatchArm {
    const char * variant_name;
    const char * binding_name;
    int body_id;
    int body_type;
} nl_ASTMatchArm;
typedef nl_ASTMatchArm ASTMatchArm;




typedef struct nl_ASTMatch {
    int node_type;
    int line;
    int column;
    int checked_coverage;
    int scrutinee;
    int scrutinee_type;
    DynArray * arm_variants;
    DynArray * arm_bindings;
    DynArray * arm_body_ids;
    DynArray * arm_body_types;
    DynArray * arm_guard_ids;
    DynArray * arm_guard_types;
    int arm_count;
} nl_ASTMatch;
typedef nl_ASTMatch ASTMatch;




typedef struct nl_ASTImport {
    int node_type;
    int line;
    int column;
    const char * module_path;
    const char * module_name;
    
# 768 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 768 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_unsafe;
    
# 769 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 769 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_selective;
    
# 770 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 770 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_wildcard;
    
# 771 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 771 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_pub_use;
    DynArray * import_symbols;
    DynArray * import_aliases;
    int import_symbol_count;
} nl_ASTImport;
typedef nl_ASTImport ASTImport;




typedef struct nl_ASTOpaqueType {
    int node_type;
    int line;
    int column;
    const char * type_name;
} nl_ASTOpaqueType;
typedef nl_ASTOpaqueType ASTOpaqueType;




typedef struct nl_ASTTupleLiteral {
    int node_type;
    int line;
    int column;
    DynArray * element_ids;
    DynArray * element_types;
    int element_count;
} nl_ASTTupleLiteral;
typedef nl_ASTTupleLiteral ASTTupleLiteral;




typedef struct nl_ASTTupleIndex {
    int node_type;
    int line;
    int column;
    int tuple;
    int tuple_type;
    int index;
} nl_ASTTupleIndex;
typedef nl_ASTTupleIndex ASTTupleIndex;




typedef struct nl_ASTEffectDecl {
    int node_type;
    int line;
    int column;
    const char * name;
    
# 823 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 823 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        is_pub;
    DynArray * operation_names;
    DynArray * parameter_types;
    DynArray * parameter_starts;
    DynArray * parameter_counts;
    DynArray * return_types;
} nl_ASTEffectDecl;
typedef nl_ASTEffectDecl ASTEffectDecl;




typedef struct nl_ASTEffectPerform {
    int node_type;
    int line;
    int column;
    const char * effect_name;
    const char * operation_name;
    DynArray * argument_ids;
    DynArray * argument_types;
} nl_ASTEffectPerform;
typedef nl_ASTEffectPerform ASTEffectPerform;




typedef struct nl_ASTEffectHandle {
    int node_type;
    int line;
    int column;
    int body_id;
    int body_type;
    DynArray * operation_names;
    DynArray * parameter_names;
    DynArray * parameter_starts;
    DynArray * parameter_counts;
    DynArray * arm_ids;
    DynArray * arm_types;
} nl_ASTEffectHandle;
typedef nl_ASTEffectHandle ASTEffectHandle;




typedef struct nl_Parser {
    List_LexerToken * tokens;
    const char * file_name;
    int position;
    int token_count;
    
# 872 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 872 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        has_error;
    List_CompilerDiagnostic * diagnostics;
    List_ASTNumber * numbers;
    List_ASTFloat * floats;
    List_ASTString * strings;
    List_ASTBool * bools;
    List_ASTIdentifier * identifiers;
    List_ASTBinaryOp * binary_ops;
    List_ASTCall * calls;
    List_ASTModuleQualifiedCall * module_qualified_calls;
    List_ASTStmtRef * call_args;
    List_ASTStmtRef * array_elements;
    List_ASTArrayLiteral * array_literals;
    List_ASTLet * lets;
    List_ASTSet * sets;
    List_ASTIf * ifs;
    List_ASTWhile * whiles;
    List_ASTFor * fors;
    List_ASTReturn * returns;
    List_ASTBlock * blocks;
    List_ASTUnsafeBlock * unsafe_blocks;
    List_ASTPrint * prints;
    List_ASTAssert * asserts;
    List_ASTFunction * functions;
    List_ASTShadow * shadows;
    List_ASTStruct * structs;
    List_ASTStructLiteral * struct_literals;
    List_ASTFieldAccess * field_accesses;
    List_ASTEnum * enums;
    List_ASTUnion * unions;
    List_ASTUnionConstruct * union_constructs;
    List_ASTMatch * matches;
    List_ASTImport * imports;
    List_ASTOpaqueType * opaque_types;
    List_ASTTupleLiteral * tuple_literals;
    List_ASTTupleIndex * tuple_indices;
    int numbers_count;
    int floats_count;
    int strings_count;
    int bools_count;
    int identifiers_count;
    int binary_ops_count;
    int calls_count;
    int module_qualified_calls_count;
    int array_literals_count;
    int lets_count;
    int sets_count;
    int ifs_count;
    int whiles_count;
    int fors_count;
    int returns_count;
    int blocks_count;
    int unsafe_blocks_count;
    int prints_count;
    int asserts_count;
    int functions_count;
    int shadows_count;
    int structs_count;
    int struct_literals_count;
    int field_accesses_count;
    int enums_count;
    int unions_count;
    int union_constructs_count;
    int matches_count;
    int imports_count;
    int opaque_types_count;
    int tuple_literals_count;
    int tuple_indices_count;
    int next_node_id;
    int last_expr_node_id;
    int last_expr_node_type;
    List_ASTServiceDecl * services;
    int services_count;
    DynArray * effects;
    DynArray * performs;
    DynArray * handlers;
} nl_Parser;
typedef nl_Parser Parser;




typedef struct nl_NSType {
    int kind;
    const char * name;
    int element_type_kind;
    const char * element_type_name;
} nl_NSType;
typedef nl_NSType NSType;




typedef struct nl_OptionType {
    
# 966 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 966 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        has_value;
    NSType value;
} nl_OptionType;
typedef nl_OptionType OptionType;




typedef struct nl_CompilerSourceLocation {
    const char * file;
    int line;
    int column;
} nl_CompilerSourceLocation;
typedef nl_CompilerSourceLocation CompilerSourceLocation;




typedef struct nl_CompilerDiagnostic {
    int phase;
    int severity;
    const char * code;
    const char * message;
    CompilerSourceLocation location;
} nl_CompilerDiagnostic;
typedef nl_CompilerDiagnostic CompilerDiagnostic;




typedef struct nl_LexPhaseOutput {
    List_LexerToken * tokens;
    int token_count;
    List_CompilerDiagnostic * diagnostics;
    
# 1000 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 1000 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        had_error;
} nl_LexPhaseOutput;
typedef nl_LexPhaseOutput LexPhaseOutput;




typedef struct nl_ParsePhaseOutput {
    Parser parser;
    List_CompilerDiagnostic * diagnostics;
    
# 1010 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 1010 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        had_error;
} nl_ParsePhaseOutput;
typedef nl_ParsePhaseOutput ParsePhaseOutput;




typedef struct nl_TypeEnvironment {
    int error_count;
    
# 1019 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 1019 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        has_error;
    List_CompilerDiagnostic * diagnostics;
} nl_TypeEnvironment;
typedef nl_TypeEnvironment TypeEnvironment;




typedef struct nl_TypecheckPhaseOutput {
    TypeEnvironment environment;
    List_CompilerDiagnostic * diagnostics;
    
# 1030 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 1030 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        had_error;
} nl_TypecheckPhaseOutput;
typedef nl_TypecheckPhaseOutput TypecheckPhaseOutput;




typedef struct nl_TranspilePhaseOutput {
    const char * c_source;
    List_CompilerDiagnostic * diagnostics;
    
# 1040 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h" 3 4
   _Bool 
# 1040 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/generated/compiler_schema.h"
        had_error;
    const char * output_path;
} nl_TranspilePhaseOutput;
typedef nl_TranspilePhaseOutput TranspilePhaseOutput;




typedef struct nl_ASTServiceDecl {
    int node_type;
    int line;
    int column;
    const char * interface_id;
    int interface_bytes;
    const char * document_path;
    int path_bytes;
    int catalog_version;
    int origin_index;
} nl_ASTServiceDecl;
typedef nl_ASTServiceDecl ASTServiceDecl;
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2






# 1 "/usr/include/execinfo.h" 1 3 4
# 23 "/usr/include/execinfo.h" 3 4





# 27 "/usr/include/execinfo.h" 3 4
extern int backtrace (void **__array, int __size) __attribute__ ((__nonnull__ (1)));




extern char **backtrace_symbols (void *const *__array, int __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void backtrace_symbols_fd (void *const *__array, int __size, int __fd)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


# 27 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/environments.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/environments.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/environments.h" 2 3 4
# 207 "/usr/include/unistd.h" 2 3 4
# 226 "/usr/include/unistd.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 274 "/usr/include/unistd.h" 3 4
typedef __socklen_t socklen_t;
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int euidaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int eaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int execveat (int __fd, const char *__path, char *const __argv[],
                     char *const __envp[], int __flags)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));






extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));
# 350 "/usr/include/unistd.h" 3 4
extern __off64_t lseek64 (int __fd, __off64_t __offset, int __whence)
     __attribute__ ((__nothrow__ , __leaf__));






extern int close (int __fd);




extern void closefrom (int __lowfd) __attribute__ ((__nothrow__ , __leaf__));







extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    __attribute__ ((__access__ (__write_only__, 2, 3)));





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
# 389 "/usr/include/unistd.h" 3 4
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
    __attribute__ ((__access__ (__write_only__, 2, 3)));






extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
# 422 "/usr/include/unistd.h" 3 4
extern ssize_t pread64 (int __fd, void *__buf, size_t __nbytes,
   __off64_t __offset)
    __attribute__ ((__access__ (__write_only__, 2, 3)));


extern ssize_t pwrite64 (int __fd, const void *__buf, size_t __n,
    __off64_t __offset)
    __attribute__ ((__access__ (__read_only__, 2, 3)));







extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int pipe2 (int __pipedes[2], int __flags) __attribute__ ((__nothrow__ , __leaf__)) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);







extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ , __leaf__));






extern int usleep (__useconds_t __useconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



extern int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;





extern char *get_current_dir_name (void) __attribute__ ((__nothrow__ , __leaf__));







extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__))
    __attribute__ ((__access__ (__write_only__, 1)));




extern int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;


extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));




extern int dup3 (int __fd, int __fd2, int __flags) __attribute__ ((__nothrow__ , __leaf__));



extern char **__environ;

extern char **environ;





extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int execvpe (const char *__file, char *const __argv[],
      char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;




extern void _exit (int __status) __attribute__ ((__noreturn__));





# 1 "/usr/include/aarch64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));


extern long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));



extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 3)));




extern __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));

extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));






extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));
# 682 "/usr/include/unistd.h" 3 4
extern int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));






extern __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));



extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));



extern __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));




extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 1)));


extern int group_member (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__));






extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;





extern int getresuid (__uid_t *__ruid, __uid_t *__euid, __uid_t *__suid)
     __attribute__ ((__nothrow__ , __leaf__));



extern int getresgid (__gid_t *__rgid, __gid_t *__egid, __gid_t *__sgid)
     __attribute__ ((__nothrow__ , __leaf__));



extern int setresuid (__uid_t __ruid, __uid_t __euid, __uid_t __suid)
     __attribute__ ((__nothrow__ , __leaf__)) ;



extern int setresgid (__gid_t __rgid, __gid_t __egid, __gid_t __sgid)
     __attribute__ ((__nothrow__ , __leaf__)) ;






extern __pid_t fork (void) __attribute__ ((__nothrow__));







extern __pid_t vfork (void) __attribute__ ((__nothrow__ , __leaf__));






extern __pid_t _Fork (void) __attribute__ ((__nothrow__ , __leaf__));





extern char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));



extern int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern int ttyslot (void) __attribute__ ((__nothrow__ , __leaf__));




extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;




extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));





extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;


extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)))
     __attribute__ ((__access__ (__write_only__, 3, 4)));



extern int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));






extern char *getlogin (void);







extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));




extern int setlogin (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4








extern char *optarg;
# 50 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4
extern int optind;




extern int opterr;



extern int optopt;
# 91 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));


# 28 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 2 3 4


# 49 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 3 4

# 904 "/usr/include/unistd.h" 2 3 4







extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));






extern int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__read_only__, 1, 2)));



extern int sethostid (long int __id) __attribute__ ((__nothrow__ , __leaf__)) ;





extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
     __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__read_only__, 1, 2)));




extern int vhangup (void) __attribute__ ((__nothrow__ , __leaf__));


extern int revoke (const char *__file) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;







extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int acct (const char *__name) __attribute__ ((__nothrow__ , __leaf__));



extern char *getusershell (void) __attribute__ ((__nothrow__ , __leaf__));
extern void endusershell (void) __attribute__ ((__nothrow__ , __leaf__));
extern void setusershell (void) __attribute__ ((__nothrow__ , __leaf__));





extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int chroot (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));







extern int fsync (int __fd);





extern int syncfs (int __fd) __attribute__ ((__nothrow__ , __leaf__));






extern long int gethostid (void);


extern void sync (void) __attribute__ ((__nothrow__ , __leaf__));





extern int getpagesize (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));




extern int getdtablesize (void) __attribute__ ((__nothrow__ , __leaf__));
# 1026 "/usr/include/unistd.h" 3 4
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1038 "/usr/include/unistd.h" 3 4
extern int truncate64 (const char *__file, __off64_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1049 "/usr/include/unistd.h" 3 4
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;
# 1059 "/usr/include/unistd.h" 3 4
extern int ftruncate64 (int __fd, __off64_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;
# 1070 "/usr/include/unistd.h" 3 4
extern int brk (void *__addr) __attribute__ ((__nothrow__ , __leaf__)) ;





extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ , __leaf__));
# 1091 "/usr/include/unistd.h" 3 4
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ , __leaf__));
# 1114 "/usr/include/unistd.h" 3 4
extern int lockf (int __fd, int __cmd, __off_t __len) ;
# 1124 "/usr/include/unistd.h" 3 4
extern int lockf64 (int __fd, int __cmd, __off64_t __len) ;
# 1142 "/usr/include/unistd.h" 3 4
ssize_t copy_file_range (int __infd, __off64_t *__pinoff,
    int __outfd, __off64_t *__poutoff,
    size_t __length, unsigned int __flags);





extern int fdatasync (int __fildes);
# 1162 "/usr/include/unistd.h" 3 4
extern char *crypt (const char *__key, const char *__salt)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));







extern void swab (const void *__restrict __from, void *__restrict __to,
    ssize_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
    __attribute__ ((__access__ (__read_only__, 1, 3)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 1201 "/usr/include/unistd.h" 3 4
int getentropy (void *__buffer, size_t __length)
    __attribute__ ((__access__ (__write_only__, 1, 2)));
# 1211 "/usr/include/unistd.h" 3 4
extern int close_range (unsigned int __fd, unsigned int __max_fd,
   int __flags) __attribute__ ((__nothrow__ , __leaf__));
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/unistd_ext.h" 3 4
extern __pid_t gettid (void) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/linux/close_range.h" 1 3 4
# 39 "/usr/include/aarch64-linux-gnu/bits/unistd_ext.h" 2 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 28 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2




# 31 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
typedef struct Value Value;
struct FunctionSignature;


# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/dyn_array.h" 1
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h" 1
# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h"
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc.h" 1
# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h" 2




typedef struct {
    char* struct_name;
    int field_count;
    char** field_names;
    void** field_values;
    uint8_t* field_gc_flags;
    uint8_t* field_types;
} GCStruct;


typedef enum {
    FIELD_INT = 1,
    FIELD_FLOAT = 2,
    FIELD_BOOL = 3,
    FIELD_STRING = 4,
    FIELD_ARRAY = 5,
    FIELD_STRUCT = 6,
    FIELD_UNION = 7
} FieldType;


GCStruct* gc_struct_new(const char* struct_name, int field_count);


void gc_struct_free(GCStruct* s);


void gc_struct_set_field(GCStruct* s, int field_index,
                         const char* field_name, void* value,
                         FieldType type, 
# 44 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h" 3 4
                                        _Bool 
# 44 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/runtime/gc_struct.h"
                                             is_gc_object);


void* gc_struct_get_field(GCStruct* s, int field_index);


void* gc_struct_get_field_by_name(GCStruct* s, const char* field_name);


int gc_struct_get_field_index(GCStruct* s, const char* field_name);


GCStruct* gc_struct_clone(GCStruct* s);
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 2


typedef enum {
    VAL_INT,
    VAL_FLOAT,
    VAL_BOOL,
    VAL_STRING,
    VAL_ARRAY,
    VAL_DYN_ARRAY,
    VAL_STRUCT,
    VAL_GC_STRUCT,
    VAL_UNION,
    VAL_FUNCTION,
    VAL_TUPLE,
    VAL_COROUTINE,
    VAL_VOID,
    VAL_BSTRING
} ValueType;


typedef struct {
    ValueType element_type;
    int length;
    int capacity;
    void *data;
    
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_byte_array;
} Array;


typedef struct {
    char *struct_name;
    char **field_names;
    Value *field_values;
    int field_count;
    
# 71 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 71 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        packed_names;
} StructValue;

StructValue *allocate_struct_carrier(const char *name, char **fields, int field_count);
void release_struct_carrier_names(StructValue *record);


typedef struct {
    char *union_name;
    int variant_index;
    char *variant_name;
    char **field_names;
    Value *field_values;
    int field_count;
} UnionValue;


typedef struct {
    Value *elements;
    int element_count;
} TupleValue;


typedef enum {
    TYPE_INT,
    TYPE_U8,
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_STRING,
    TYPE_BSTRING,
    TYPE_VOID,
    TYPE_ARRAY,
    TYPE_STRUCT,
    TYPE_ENUM,
    TYPE_UNION,
    TYPE_GENERIC,
    TYPE_LIST_INT,
    TYPE_LIST_STRING,
    TYPE_LIST_TOKEN,
    TYPE_LIST_GENERIC,
    TYPE_HASHMAP,
    TYPE_FUNCTION,
    TYPE_TUPLE,
    TYPE_OPAQUE,
    TYPE_OPEN_RECORD,
    TYPE_UNKNOWN,
    TYPE_BORROW_SHARED,
    TYPE_BORROW_MUT,
    TYPE_LIST_BOOL
} Type;


typedef struct TypeInfo {
    Type base_type;


    uint32_t service_declaration, service_module, service_ordinal, service_category;
    struct TypeInfo *element_type;


    char *generic_name;
    struct TypeInfo **type_params;
    int type_param_count;


    Type *tuple_types;
    struct TypeInfo **tuple_elements;
    char **tuple_type_names;
    int tuple_element_count;


    char *opaque_type_name;


    struct FunctionSignature *fn_sig;







    
# 153 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 153 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
          is_open_row;
    char *row_var_name;
    char **row_field_names;
    Type *row_field_types;
    struct TypeInfo **row_field_type_info;
    char **row_field_type_names;
    int row_field_count;






    char **type_var_names;
    int type_var_count;
} TypeInfo;


struct Value {
    ValueType type;
    
# 173 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 173 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_return;
    
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_break;
    
# 175 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 175 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_continue;
    const void *return_target;
    union {
        long long int_val;
        double float_val;
        
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       _Bool 
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
            bool_val;
        char *string_val;
        void *bstring_val;
        Array *array_val;
        DynArray *dyn_array_val;
        StructValue *struct_val;
        GCStruct *gc_struct_val;
        UnionValue *union_val;
        struct {
            char *function_name;
            struct FunctionSignature *signature;
        } function_val;
        TupleValue *tuple_val;
    } as;
};


typedef enum {
    AST_NUMBER,
    AST_FLOAT,
    AST_STRING,
    AST_BOOL,
    AST_IDENTIFIER,
    AST_PREFIX_OP,
    AST_CALL,
    AST_MODULE_QUALIFIED_CALL,
    AST_ARRAY_LITERAL,
    AST_LET,
    AST_SET,
    AST_IF,
    AST_COND,
    AST_WHILE,
    AST_FOR,
    AST_RETURN,
    AST_BREAK,
    AST_CONTINUE,
    AST_BLOCK,
    AST_FUNCTION,
    AST_SHADOW,
    AST_PROGRAM,
    AST_PRINT,
    AST_ASSERT,
    AST_STRUCT_DEF,
    AST_STRUCT_LITERAL,
    AST_FIELD_ACCESS,
    AST_ENUM_DEF,
    AST_UNION_DEF,
    AST_UNION_CONSTRUCT,
    AST_MATCH,
    AST_IMPORT,
    AST_MODULE_DECL,
    AST_OPAQUE_TYPE,
    AST_TUPLE_LITERAL,
    AST_TUPLE_INDEX,
    AST_QUALIFIED_NAME,
    AST_UNSAFE_BLOCK,
    AST_TRY_OP,
    AST_PAR_BLOCK,
    AST_EFFECT_DECL,
    AST_HANDLE_EXPR,


    AST_PAR_LET,
    AST_EFFECT_HANDLER,
    AST_EFFECT_OP,
    AST_ASYNC_FN,
    AST_AWAIT,
    AST_SERVICE_DECL
} ASTNodeType;


typedef struct ASTNode ASTNode;


typedef struct FunctionSignature {
    Type *param_types;
    int param_count;
    char **param_struct_names;
    TypeInfo **param_type_info;
    TypeInfo *return_type_info;
    Type return_type;
    char *return_struct_name;
    struct FunctionSignature *return_fn_sig;
} FunctionSignature;


typedef struct {
    char *name;
    Type type;
    char *struct_type_name;
    Type element_type;
    FunctionSignature *fn_sig;
    TypeInfo *type_info;
} Parameter;


struct ASTNode {
    ASTNodeType type;
    int line;
    int column;

    int scope_end_line;
    int scope_end_column;


    ASTNode *lambda_definition;
    ASTNode *checked_global;
    
# 287 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 287 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        checked_function_name;
    ASTNode *affine_use_owner;
    uint64_t affine_use_epoch;
    unsigned char checked_affine_use;
    char *contextual_func_name;
    union {
        long long number;
        double float_val;
        char *string_val;
        
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       _Bool 
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
            bool_val;
        char *identifier;
        struct {
            TokenType op;
            ASTNode **args;
            int arg_count;
        } prefix_op;
        struct {
            int borrow_mode;
            char *name;
            ASTNode *func_expr;
            ASTNode **args;
            int arg_count;
            char *return_struct_type_name;
            Type map_key_type;
            Type map_value_type;
            
# 312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                map_context_checked;
            FunctionSignature *checked_signature;
            char *concrete_func_name;
        } call;
        struct {
            char *module_alias;
            char *function_name;
            ASTNode **args;
            int arg_count;
            char *return_struct_type_name;
            FunctionSignature *checked_signature;
        } module_qualified_call;
        struct {
            ASTNode **elements;
            int element_count;
            Type element_type;
            
# 328 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 328 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                has_element_annotation;
        } array_literal;
        struct {
            char *name;
            Type var_type;
            char *type_name;
            Type element_type;
            FunctionSignature *fn_sig;
            TypeInfo *type_info;
            
# 337 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 337 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_mut;
            
# 338 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 338 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;
            ASTNode *value;
            
# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_generated;
            
# 341 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 341 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_destructure;
            
# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_destructure_projection;
            int destructure_count;
            char **destructure_names;
        } let;
        struct {
            char *name;
            ASTNode *value;
            char *field_name;
            
# 350 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 350 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                qualified_global;
        } set;
        struct {
            ASTNode *condition;
            ASTNode *then_branch;
            ASTNode *else_branch;
        } if_stmt;
        struct {
            ASTNode **conditions;
            ASTNode **values;
            int clause_count;
            ASTNode *else_value;
        } cond_expr;
        struct {
            ASTNode *condition;
            ASTNode *body;
        } while_stmt;
        struct {
            char *var_name;
            ASTNode *range_expr;
            ASTNode *body;
        } for_stmt;
        struct {
            ASTNode *value;
        } return_stmt;
        struct {
            ASTNode **statements;
            int count;
        } block;
        struct {
            char *name;
            Parameter *params;
            int param_count;
            Type return_type;
            Type return_element_type;
            char *return_struct_type_name;
            FunctionSignature *return_fn_sig;
            TypeInfo *return_type_info;
            ASTNode *body;
            
# 389 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 389 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_extern;
            
# 390 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 390 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_anonymous;
            
# 391 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 391 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;
            
# 392 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 392 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_gpu;
            unsigned char checked_affine;
            uint64_t affine_check_epoch;
            uint64_t affine_completed_epoch;
            
# 396 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 396 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pure;
            char **effect_names;
            int effect_count;
        } function;
        struct {
            char *function_name;
            ASTNode *body;
        } shadow;
        struct {
            ASTNode **items;
            int count;
        } program;
        struct {
            ASTNode *expr;
            
# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 410 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_println;
        } print;
        struct {
            ASTNode *condition;
        } assert;
        struct {
            char *name;
            char *original_name;
            char **field_names;
            Type *field_types;
            char **field_type_names;
            Type *field_element_types;
            TypeInfo **field_type_info;
            int field_count;
            
# 424 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 424 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;
            
# 425 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 425 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_resource;
            
# 426 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 426 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_extern;
        } struct_def;
        struct {
            char *struct_name;
            char **field_names;
            ASTNode **field_values;
            int field_count;
            ASTNode *spread_source;
        } struct_literal;
        struct {
            ASTNode *object;
            char *field_name;
            TypeInfo *resolved_type_info;
        } field_access;
        struct {
            char *name;
            char *original_name;
            char **variant_names;
            int *variant_values;
            int variant_count;
            
# 446 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 446 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;
            
# 447 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 447 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_extern;
        } enum_def;



        struct {
            char *name;
            char *original_name;
            int variant_count;
            char **variant_names;
            int *variant_field_counts;
            char ***variant_field_names;
            Type **variant_field_types;
            char ***variant_field_type_names;
            TypeInfo ***variant_field_type_info;
            
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;
            
# 463 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 463 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_extern;
            char **generic_params;
            int generic_param_count;
        } union_def;


        struct {
            char *union_name;
            char *variant_name;
            int field_count;
            char **field_names;
            ASTNode **field_values;
            TypeInfo *type_info;
        } union_construct;


        struct {
            ASTNode *expr;
            int arm_count;
            char **pattern_variants;
            char **pattern_bindings;
            ASTNode **arm_bodies;
            ASTNode **guard_exprs;
            char *union_type_name;
            Type checked_scrutinee_type;
            
# 488 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 488 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                scrutinee_type_checked;
            unsigned char checked_coverage;
            Type result_type;
            
# 491 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 491 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                result_type_checked;
        } match_expr;

        struct {
            char *module_path;
            char *module_alias;
            
# 497 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 497 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_unsafe;
            
# 498 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 498 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_selective;
            
# 499 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 499 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_wildcard;
            
# 500 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 500 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub_use;
            char **import_symbols;
            char **import_aliases;
            int import_symbol_count;
        } import_stmt;

        struct {
            char *name;
        } module_decl;

        struct {
            char **name_parts;
            int part_count;
        } qualified_name;

        struct {
            char *name;
        } opaque_type;
        struct {
            char *interface_id;
            char *document_path;
            int64_t interface_bytes, path_bytes;
            int64_t catalog_version;
            int64_t origin_index;
        } service_decl;

        struct {
            ASTNode **elements;
            int element_count;
            Type *element_types;
            TypeInfo *type_info;
        } tuple_literal;

        struct {
            ASTNode *tuple;
            int index;
        } tuple_index;

        struct {
            ASTNode **statements;
            int count;
        } unsafe_block;

        struct {
            ASTNode *operand;
            char *union_type_name;
            char *ok_field_name;
        } try_op;

        struct {
            ASTNode **bindings;
            int count;
            
# 552 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 552 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_flow;
        } par_block;



        struct {
            char *effect_name;
            int op_count;
            char **op_names;
            Parameter **op_params;
            int *op_param_counts;
            Type *op_return_types;
            TypeInfo **op_return_type_infos;
            char **op_return_type_names;
            
# 566 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 566 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                is_pub;

            Type *op_param_types;
            char **op_param_type_names;
        } effect_decl;


        struct {
            ASTNode *body;
            char *effect_name;
            int handler_count;
            char **handler_op_names;
            char ***handler_param_names;
            int *handler_param_counts;
            ASTNode **handler_bodies;
        } handle_expr;




        struct {
            char **names;
            ASTNode **values;
            int count;
            ASTNode *body;
            
# 591 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
           _Bool 
# 591 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                    *independent;
        } par_let;


        struct {
            ASTNode *body;
            char *effect_name;
            ASTNode **handler_bodies;
            char **handler_op_names;
            char **handler_param_names;
            int handler_count;
        } effect_handler;


        struct {
            char *effect_name;
            char *op_name;
            ASTNode **args;
            int arg_count;
        } effect_op;


        struct {
            ASTNode *function;
        } async_fn;


        struct {
            ASTNode *expr;
        } await_expr;
    } as;
};


typedef enum {
    RESOURCE_UNUSED,
    RESOURCE_USED,
    RESOURCE_CONSUMED
} ResourceUseState;


typedef struct {
    char *name;
    Type type;
    char *struct_type_name;
    Type element_type;
    TypeInfo *type_info;
    
# 638 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 638 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_mut;
    Value value;
    
# 640 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 640 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_global;
    ASTNode *global_declaration;
    
# 642 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 642 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_used;
    
# 643 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 643 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_resource;
    ResourceUseState resource_state;
    
# 645 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 645 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        from_c_header;
    int def_line;
    int def_column;
    int flow_start_line;
    int flow_start_column;
    int scope_end_line;
    int scope_end_column;
# 661 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    const char *def_file;
} Symbol;


typedef struct {
    char *name;
    Parameter *params;
    int param_count;
    Type return_type;
    Type return_element_type;
    char *return_struct_type_name;
    FunctionSignature *return_fn_sig;
    TypeInfo *return_type_info;
    ASTNode *body;
    ASTNode *shadow_test;
    ASTNode *lexical_scope;
    
# 677 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 677 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_extern;
    
# 678 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 678 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_gpu;
    
# 679 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 679 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_async;
    
# 680 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 680 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pure;
    
# 681 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 681 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pub;
    char *module_name;
    const char *source_file;
    char *alias_of;


    
# 687 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 687 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        returns_gc_managed;
    
# 688 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 688 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        requires_manual_free;
    
# 689 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 689 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        returns_borrowed;
    char *cleanup_function;


    char **effect_names;
    int effect_count;
} Function;


typedef struct {
    char *name;
    char *original_name;
    char **field_names;
    Type *field_types;
    char **field_type_names;
    Type *field_element_types;
    TypeInfo **field_type_info;
    int field_count;
    
# 707 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 707 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pub;
    
# 708 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 708 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_resource;
    
# 709 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 709 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_extern;
    char *module_name;
} StructDef;


typedef struct {
    char *name;
    char *original_name;
    char **variant_names;
    int *variant_values;
    int variant_count;
    
# 720 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 720 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pub;
    
# 721 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 721 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_extern;
    char *module_name;
} EnumDef;


typedef struct {
    char *name;
    char *original_name;
    int variant_count;
    char **variant_names;
    int *variant_field_counts;
    char ***variant_field_names;
    Type **variant_field_types;
    char ***variant_field_type_names;
    TypeInfo ***variant_field_type_info;
    
# 736 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 736 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pub;
    
# 737 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 737 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_extern;
    char *module_name;
    char **generic_params;
    int generic_param_count;
} UnionDef;


typedef struct {
    char *name;
    char *c_type_name;
} OpaqueTypeDef;



typedef struct {
    char *name;
    Parameter *params;
    int param_count;
    Type return_type;
    char *return_type_name;
    TypeInfo *return_type_info;
} EffectOp;


typedef struct {
    char *name;
    char *original_name;
    EffectOp *ops;
    int op_count;
    
# 766 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 766 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_pub;
    char *module_name;
} EffectDef;


typedef struct {
    char *name;
    int64_t value;
    Type type;
} ConstantDef;


typedef struct {
    char *generic_name;
    Type *type_args;
    int type_arg_count;
    char **type_arg_names;
    char *concrete_name;
    TypeInfo *type_info;
} GenericInstantiation;


typedef struct {
    char *orig_name;
    char *mono_name;
    char **var_names;
    Type *bound_types;
    char **bound_type_names;
    int binding_count;
    FunctionSignature *signature;
} GenericFuncInstance;


typedef struct {
    char *alias;
    char *owner_module;
    char *module_name;
    char **function_names;
    int function_count;
    char **struct_names;
    int struct_count;
    char **enum_names;
    int enum_count;
    char **union_names;
    int union_count;
} ModuleNamespace;


typedef struct {
    char *name;
    char *path;
    
# 817 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 817 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_unsafe;
    
# 818 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 818 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        has_ffi;
    char **exported_functions;
    int function_count;
    char **exported_structs;
    int struct_count;
} ModuleInfo;


typedef struct {
    char *module_path;
    char **imported_symbols;
    int symbol_count;
    
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        is_wildcard;
} SelectiveImport;


typedef struct {
    SelectiveImport *imports;
    int import_count;
    int import_capacity;
} ImportTracker;


typedef struct EnumImport {
    char *name;
    char *owner_module;
    char *target_name;
    struct EnumImport *next;
} EnumImport;

typedef struct EffectImport {
    char *name;
    char *owner_module;
    char *target_name;
    struct EffectImport *next;
} EffectImport;

typedef struct GlobalImport {
    const char *owner_file;
    const char *name;
    ASTNode *declaration;
    struct GlobalImport *next;
} GlobalImport;


typedef struct {
    Symbol *symbols;
    GlobalImport *global_imports;
    int symbol_count;
    int symbol_capacity;
    struct EnvCheckerAllocation *checker_allocations;
    struct EnvSymbolIndex *symbol_index;
    Function *functions;
    struct EnvSymbolIndex *function_index;
    int function_count;
    int function_capacity;
    StructDef *structs;
    int struct_count;
    int struct_capacity;
    EnumDef *enums;
    int enum_count;
    int enum_capacity;
    UnionDef *unions;
    int union_count;
    int union_capacity;
    OpaqueTypeDef *opaque_types;
    int opaque_type_count;
    int opaque_type_capacity;
    EffectDef *effects;
    int effect_count;
    int effect_capacity;
    GenericInstantiation *generic_instances;
    int generic_instance_count;
    int generic_instance_capacity;
    GenericFuncInstance *generic_func_instances;
    int generic_func_instance_count;
    int generic_func_instance_capacity;
    EnumImport *enum_imports;
    EffectImport *effect_imports;
    ModuleNamespace *namespaces;
    int namespace_count;
    int namespace_capacity;
    char *current_module;
    ImportTracker *import_tracker;
    
# 902 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 902 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        builtins_registered;
    ModuleInfo *modules;
    int module_count;
    int module_capacity;
    
# 906 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 906 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        emit_module_metadata;
    
# 907 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 907 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        emit_c_main;
    
# 908 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 908 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        current_module_is_unsafe;

    
# 910 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 910 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        warn_unsafe_imports;
    
# 911 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 911 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        warn_unsafe_calls;
    
# 912 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 912 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        warn_ffi;
    
# 913 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 913 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        forbid_unsafe;
    
# 914 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 914 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        profile_gprof;
    
# 915 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 915 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        profile;
    
# 916 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 916 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        trace;
    
# 917 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 917 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        profile_runtime;

    const char *profile_output_path;
    const char *profile_flamegraph_path;
    
# 921 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 921 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        suppress_shadow_warnings;
    
# 922 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 922 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        gpu_target;


    void *effect_registry;



    const char *current_file;


    char *service_origins[16];
    int service_origin_count;
    struct NlFileSourceSnapshots *service_inputs;
    struct NlServiceBodyCheck *service_bodies;
    struct NlServiceOwnershipCheck *service_ownership;
    struct NlServiceNamespace *service_namespace;
    int service_import_depth;
    size_t service_snapshot_indices[16];
    
# 940 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   _Bool 
# 940 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
        service_snapshot_bound[16];
    struct CheckedBorrowLedger *checked_borrow_facts;
} Environment;




Token *tokenize(const char *source, int *token_count);
void free_tokens(Token *tokens, int count);
const char *token_type_name(TokenType type);
const char *lexer_last_error_id(void);
const char *parser_last_error_id(void);


typedef struct {
    Token *tokens;
    int count;
    int pos;
    int recursion_depth;
    int error_count;
    int last_error_line;
    int last_error_column;
    const char *last_error_message;

    struct ASTNode **lambda_functions;
    int lambda_count;
    int lambda_capacity;
} Stage1Parser;

ASTNode *parse_program(Token *tokens, int token_count);

# 970 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 970 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    ast_has_service_declaration(const ASTNode *program);

# 971 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 971 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    bind_service_origin(ASTNode *program, Environment *env, const char *source_file);

# 972 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 972 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    acquire_service_input(ASTNode *program, Environment *env);

# 973 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 973 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    ast_is_value_expression(ASTNodeType type);

# 974 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 974 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    ast_always_returns(const ASTNode *node);
ASTNode *parse_repl_input(Token *tokens, int token_count);
void free_ast(ASTNode *node);



# 979 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 979 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    type_check(ASTNode *program, Environment *env);

# 980 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 980 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    type_check_module(ASTNode *program, Environment *env);

# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    type_check_root_shadows(ASTNode *program, Environment *env);

Type map_transform_result_type(ASTNode *callback, Environment *env);
Type filter_predicate_element_type(ASTNode *callback, Environment *env);
unsigned typecheck_advisory_effects(Environment *env, ASTNode *body);
void typecheck_set_current_file(const char *path);
Type check_expression(ASTNode *expr, Environment *env);



# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    run_shadow_tests(ASTNode *program, Environment *env, 
# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                         _Bool 
# 990 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                              verbose);



# 993 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 993 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    run_program(ASTNode *program, Environment *env);
Value call_function(const char *name, Value *args, int arg_count, Environment *env);

Value repl_eval_node(ASTNode *node, Environment *env);
void repl_print_value(Value val);


char *transpile_to_c(ASTNode *program, Environment *env, const char *input_file);


Environment *create_environment(void);

void env_symbol_index_invalidate(Environment *env);
# 1015 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
void env_set_current_file(Environment *env, const char *path);
const char *env_current_file(Environment *env);
void free_environment(Environment *env);


void *env_own_checker_allocation(Environment *env, void *allocation);

# 1021 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1021 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_import_global(Environment *env, const char *owner_file, const char *name, ASTNode *declaration);
const GlobalImport *env_lookup_global_import(Environment *env, const char *name);
const GlobalImport *env_lookup_global_import_at(Environment *env, const char *owner_file, const char *name);
Symbol *env_global_import_symbol(Environment *env, const char *name);
ASTNode *env_qualified_import_literal(Environment *env, ASTNode *expr);
Symbol *env_global_import_symbol_at(Environment *env, const char *owner_file, const char *name);
void env_define_var(Environment *env, const char *name, Type type, 
# 1027 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                  _Bool 
# 1027 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                       is_mut, Value value);
void env_define_string_copy(Environment *env, const char *name, Type type, 
# 1028 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                          _Bool 
# 1028 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                               is_mut, const char *text);
void env_define_var_with_element_type(Environment *env, const char *name, Type type, Type element_type, 
# 1029 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                                                       _Bool 
# 1029 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                                                            is_mut, Value value);
void env_define_var_with_type_info(Environment *env, const char *name, Type type, Type element_type, TypeInfo *type_info, 
# 1030 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                                                                         _Bool 
# 1030 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                                                                              is_mut, Value value);



void env_reclaim_static_arrays(Environment *env);


size_t env_static_array_reclaim_count(void);
Symbol *env_get_var(Environment *env, const char *name);
Symbol *env_get_declared_global(Environment *env, const ASTNode *declaration);
Symbol *env_get_var_visible_at(Environment *env, const char *name, int line, int column);

void env_define_evaluated_var(Environment *env, const char *name, Type type, Type element_type,
                              TypeInfo *type_info, 
# 1043 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                  _Bool 
# 1043 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                       is_mut, Value value, ASTNode *expression);
void env_set_evaluated_var(Environment *env, const char *name, Value value, ASTNode *expression);
void env_set_evaluated_binding(Environment *env, Symbol *binding, Value value, ASTNode *expression);
void env_set_var(Environment *env, const char *name, Value value);
void env_define_function(Environment *env, Function func);
Function *env_get_function(Environment *env, const char *name);
Function *env_get_function_at(Environment *env, const char *name, int line, int column);

# 1050 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1050 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_array_push_is_builtin(Environment *env, int line, int column);
const char *env_array_operation(Environment *env, ASTNode *call);

# 1052 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1052 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    is_builtin_function(const char *name);
void env_define_struct(Environment *env, StructDef struct_def);
StructDef *env_get_struct(Environment *env, const char *name);
StructDef *env_get_struct_owned(Environment *env, const char *name, const char *owner);

# 1056 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1056 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    bind_nominal_records(ASTNode *program, Environment *env);

# 1057 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1057 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    bind_service_annotations(ASTNode *program, Environment *env, const char *source);
void env_register_namespace(Environment *env, const char *alias, const char *module_name,
                            char **function_names, int function_count,
                            char **struct_names, int struct_count,
                            char **enum_names, int enum_count,
                            char **union_names, int union_count);

void env_register_module(Environment *env, const char *name, const char *path, 
# 1064 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                              _Bool 
# 1064 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                                   is_unsafe);
ModuleInfo *env_get_module(Environment *env, const char *name);

# 1066 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1066 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_is_current_module_unsafe(Environment *env);
void env_mark_module_has_ffi(Environment *env, const char *name);
void env_add_module_exported_function(Environment *env, const char *module_name, const char *function_name);
void env_add_module_exported_struct(Environment *env, const char *module_name, const char *struct_name);
void env_define_enum(Environment *env, EnumDef enum_def);
EnumDef *env_get_enum(Environment *env, const char *name);

# 1072 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1072 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_import_enum(Environment *env, const char *alias, const EnumDef *target);
void env_register_list_instantiation(Environment *env, const char *element_type);
void env_register_hashmap_instantiation(Environment *env, const char *key_type, const char *value_type);

char *typeinfo_to_generic_arg_name(TypeInfo *info);
void env_register_union_instantiation(Environment *env, const char *union_name,
                                      const char **type_args, int type_arg_count);
int env_get_enum_variant(Environment *env, const char *variant_name);

void env_define_union(Environment *env, UnionDef union_def);
UnionDef *env_get_union(Environment *env, const char *name);
void env_define_opaque_type(Environment *env, const char *name);
OpaqueTypeDef *env_get_opaque_type(Environment *env, const char *name);
int env_get_union_variant_index(Environment *env, const char *union_name, const char *variant_name);


void env_register_generic_func_instance(Environment *env, const char *orig_name, const char *mono_name,
                                         const char **var_names, Type *bound_types, const char **bound_type_names,
                                         int binding_count);


void env_define_effect(Environment *env, EffectDef effect_def);
EffectDef *env_get_effect(Environment *env, const char *name);
EffectDef *env_get_effect_owned(Environment *env, const char *name, const char *owner);

# 1096 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1096 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_import_effect(Environment *env, const char *alias, const EffectDef *target);

# 1097 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1097 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    env_effect_visible(Environment *env, const EffectDef *effect);
EffectOp *effect_get_op(EffectDef *effect, const char *op_name);


Type token_to_type(TokenType token);
const char *type_to_string(Type type);
Value create_int(long long val);
Value create_float(double val);
Value create_bool(
# 1105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                 _Bool 
# 1105 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                      val);
Value create_string(const char *val);
char *nl_unescape_string(const char *raw);
Value create_void(void);
Value create_array(ValueType elem_type, int length, int capacity);
Value create_struct(const char *struct_name, char **field_names, Value *field_values, int field_count);
Value create_union(const char *union_name, int variant_index, const char *variant_name,
                   char **field_names, Value *field_values, int field_count);
Value create_function(const char *function_name, FunctionSignature *signature);


FunctionSignature *create_function_signature(Type *param_types, int param_count, Type return_type);
FunctionSignature *function_signature_from_function(const Function *function);
FunctionSignature *copy_function_signature(const FunctionSignature *signature);
FunctionSignature *copy_contextual_callable_signature(ASTNode *value, Environment *env,
                                                      const FunctionSignature *expected);
void free_function_signature(FunctionSignature *sig);

# 1122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    function_signatures_equal(FunctionSignature *sig1, FunctionSignature *sig2);

# 1123 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1123 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    type_infos_equal(const TypeInfo *left, const TypeInfo *right);
void free_type_info(TypeInfo *info);
TypeInfo *copy_payload_type_info(const TypeInfo *info);
const TypeInfo *tuple_element_info(const TypeInfo *info, int index, TypeInfo *fallback);
const TypeInfo *row_field_info(const TypeInfo *info, int index, TypeInfo *fallback);
void free_payload_type_info(TypeInfo *info);
TypeInfo *resolve_union_payload_type_info(const UnionDef *def, int arm, int field, const TypeInfo *arguments);


Value create_tuple(Value *elements, int element_count);
void free_tuple(TupleValue *tuple);


typedef struct {
    char **module_paths;
    int count;
    int capacity;
} ModuleList;


# 1142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    type_check_shadow_scope(ASTNode *program, Environment *env, ModuleList *modules,
                             const char *input_file, 
# 1143 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                    _Bool 
# 1143 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                         include_imports);

# 1144 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1144 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    run_shadow_tests_scope(ASTNode *program, Environment *env, ModuleList *modules,
                            const char *input_file, 
# 1145 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                   _Bool 
# 1145 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                        include_imports, 
# 1145 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                         _Bool 
# 1145 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                              verbose);

ModuleList *create_module_list(void);
void free_module_list(ModuleList *list);
void module_list_add(ModuleList *list, const char *module_path);
const char *resolve_module_path(const char *module_path, const char *current_file);
char *find_module_in_paths(const char *module_name);
char *unpack_module_package(const char *package_path, char *temp_dir_out, size_t temp_dir_size);
ASTNode *load_module(const char *module_path, Environment *env);
ASTNode *load_module_from_package(const char *package_path, Environment *env, char *temp_dir_out, size_t temp_dir_size);
ASTNode *get_cached_module_ast(const char *module_path);
char *module_program_name(ASTNode *program, const char *module_path);
int64_t module_get_import_count(const char *module_path);
const char *module_get_import_path(const char *module_path, int64_t index);
const char *module_generate_forward_declarations(const char *module_path);

# 1160 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1160 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    process_imports(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file);


# 1162 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1162 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    process_imports_for_service(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file);
void clear_module_cache(void);

# 1164 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1164 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    compile_module_to_object(const char *module_path,
                              const char *output_obj,
                              Environment *env,
                              
# 1167 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                             _Bool 
# 1167 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                  verbose,
                              char **extra_compile_flags,
                              size_t extra_compile_flags_count);


# 1171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    module_is_ffi_only(const char *module_path);

# 1172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    compile_modules(ModuleList *modules, Environment *env, char **module_objs_buffer, char *compile_flags_buffer, size_t compile_flags_buffer_size, 
# 1172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                                                                                                                                                    _Bool 
# 1172 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                                                                                                                                         verbose);


typedef struct {
    char *module_name;
    int function_count;
    Function *functions;
    int struct_count;
    StructDef *structs;
    int enum_count;
    EnumDef *enums;
    int union_count;
    UnionDef *unions;
    int constant_count;
    ConstantDef *constants;
} ModuleMetadata;


ModuleMetadata *extract_module_metadata(Environment *env, const char *module_name);
void free_module_metadata(ModuleMetadata *meta);
char *serialize_module_metadata_to_c(ModuleMetadata *meta);
char *serialize_module_metadata_for_source(ModuleMetadata *meta, const char *source);

# 1194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    deserialize_module_metadata_from_c(const char *c_code, ModuleMetadata **meta_out);

# 1195 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1195 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    embed_metadata_in_module_c(char *c_code, ModuleMetadata *meta, size_t buffer_size);





static inline size_t safe_strlen(const char *str) {
    return str ? strlen(str) : 0;
}


static inline size_t safe_strnlen(const char *str, size_t maxlen) {
    if (!str) return 0;
    size_t len = 0;
    while (len < maxlen && str[len] != '\0') len++;
    return len;
}


static inline int safe_strcmp(const char *s1, const char *s2) {
    if (!s1 && !s2) return 0;
    if (!s1 || !s2) return (s1 ? 1 : -1);
    return strcmp(s1, s2);
}


static inline int safe_strncmp(const char *s1, const char *s2, size_t n) {
    if (!s1 && !s2) return 0;
    if (!s1 || !s2) return (s1 ? 1 : -1);
    return strncmp(s1, s2, n);
}


static inline char *safe_strncpy(char *dest, const char *src, size_t dest_size) {
    if (!dest || dest_size == 0) return dest;
    if (!src) {
        dest[0] = '\0';
        return dest;
    }
    size_t src_len = safe_strnlen(src, dest_size - 1);
    memcpy(dest, src, src_len);
    dest[src_len] = '\0';
    return dest;
}


static inline char *safe_strncat(char *dest, const char *src, size_t dest_size) {
    if (!dest || dest_size == 0) return dest;
    if (!src) return dest;
    size_t dest_len = safe_strnlen(dest, dest_size);
    if (dest_len >= dest_size - 1) return dest;
    size_t avail = dest_size - dest_len - 1;
    size_t src_len = safe_strnlen(src, avail);
    memcpy(dest + dest_len, src, src_len);
    dest[dest_len + src_len] = '\0';
    return dest;
}


static inline const char *safe_format_string(const char *str) {
    return str ? str : "(NULL)";
}



static inline int safe_fprintf(FILE *stream, const char *format, ...) {
    
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void) sizeof ((
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   stream != 
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ? 1 : 0), __extension__ ({ if (
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   stream != 
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ; else __assert_fail (
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   "stream != NULL"
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h", 1261, __extension__ __PRETTY_FUNCTION__); }))
# 1261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void) sizeof ((
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ? 1 : 0), __extension__ ({ if (
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ; else __assert_fail (
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   "format != NULL"
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h", 1262, __extension__ __PRETTY_FUNCTION__); }))
# 1262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    if (!stream || !format) return -1;

    char buffer[4096];
    va_list args;
    
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_start(
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ,
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1267 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    int result = vsnprintf(buffer, sizeof(buffer), format, args);
    
# 1269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_end(
# 1269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
               ;

    if (result < 0) return -1;
    if (result >= (int)sizeof(buffer)) {

        char *large_buffer = malloc(result + 1);
        if (!large_buffer) return -1;
        
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       __builtin_va_start(
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       args
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       ,
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       format
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       )
# 1276 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                             ;
        vsnprintf(large_buffer, result + 1, format, args);
        
# 1278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       __builtin_va_end(
# 1278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       args
# 1278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       )
# 1278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                   ;
        fputs(large_buffer, stream);
        free(large_buffer);
        return result;
    }

    fputs(buffer, stream);
    return result;
}


static inline int safe_snprintf(char *dest, size_t dest_size, const char *format, ...) {
    
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void) sizeof ((
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   dest != 
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ? 1 : 0), __extension__ ({ if (
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   dest != 
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ; else __assert_fail (
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   "dest != NULL"
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h", 1290, __extension__ __PRETTY_FUNCTION__); }))
# 1290 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                       ;
    
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void) sizeof ((
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ? 1 : 0), __extension__ ({ if (
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ; else __assert_fail (
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   "format != NULL"
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h", 1291, __extension__ __PRETTY_FUNCTION__); }))
# 1291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    if (!dest || dest_size == 0 || !format) return -1;

    va_list args;
    
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_start(
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ,
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1295 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    int result = vsnprintf(dest, dest_size, format, args);
    
# 1297 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_end(
# 1297 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1297 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1297 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
               ;

    if (result >= (int)dest_size) {
        dest[dest_size - 1] = '\0';
    }
    return result;
}


static inline int safe_printf(const char *format, ...) {
    
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void) sizeof ((
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ? 1 : 0), __extension__ ({ if (
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format != 
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ((void *)0)) ; else __assert_fail (
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   "format != NULL"
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   , "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h", 1307, __extension__ __PRETTY_FUNCTION__); }))
# 1307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    if (!format) return -1;

    char buffer[4096];
    va_list args;
    
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_start(
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   ,
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   format
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1312 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                         ;
    int result = vsnprintf(buffer, sizeof(buffer), format, args);
    
# 1314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   __builtin_va_end(
# 1314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
   args
# 1314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
   )
# 1314 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
               ;

    if (result < 0) return -1;
    if (result >= (int)sizeof(buffer)) {
        char *large_buffer = malloc(result + 1);
        if (!large_buffer) return -1;
        
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       __builtin_va_start(
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       args
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       ,
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       format
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       )
# 1320 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                             ;
        vsnprintf(large_buffer, result + 1, format, args);
        
# 1322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       __builtin_va_end(
# 1322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
       args
# 1322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
       )
# 1322 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                   ;
        fputs(large_buffer, 
# 1323 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                           stdout
# 1323 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                                 );
        free(large_buffer);
        return result;
    }

    fputs(buffer, 
# 1328 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                 stdout
# 1328 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                       );
    return result;
}


static inline void print_backtrace(void) {

    void *array[64];
    int size = backtrace(array, 64);
    char **symbols = backtrace_symbols(array, size);

    if (symbols) {
        safe_fprintf(
# 1340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                    stderr
# 1340 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                          , "\n=== Backtrace ===\n");
        for (int i = 0; i < size; i++) {
            safe_fprintf(
# 1342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                        stderr
# 1342 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                              , "  [%d] %s\n", i, safe_format_string(symbols[i]));
        }
        safe_fprintf(
# 1344 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                    stderr
# 1344 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                          , "==================\n\n");
        free(symbols);
    } else {
        safe_fprintf(
# 1347 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                    stderr
# 1347 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                          , "\n=== Backtrace (symbols unavailable) ===\n");
        safe_fprintf(
# 1348 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                    stderr
# 1348 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                          , "  %d stack frames\n", size);
        safe_fprintf(
# 1349 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
                    stderr
# 1349 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
                          , "========================================\n\n");
    }



}
# 1373 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
const char *get_project_root(void);




int64_t nl_gpu_thread_id_x(void);
int64_t nl_gpu_thread_id_y(void);
int64_t nl_gpu_thread_id_z(void);
int64_t nl_gpu_block_id_x(void);
int64_t nl_gpu_block_id_y(void);
int64_t nl_gpu_block_id_z(void);
int64_t nl_gpu_block_dim_x(void);
int64_t nl_gpu_block_dim_y(void);
int64_t nl_gpu_block_dim_z(void);
int64_t nl_gpu_grid_dim_x(void);
int64_t nl_gpu_grid_dim_y(void);
int64_t nl_gpu_grid_dim_z(void);
int64_t nl_gpu_global_id_x(void);
int64_t nl_gpu_global_id_y(void);
void nl_gpu_barrier(void);

int64_t nl_gpu_load(int64_t ptr);
void nl_gpu_store(int64_t ptr, int64_t val);
double nl_gpu_load_float(int64_t ptr);
void nl_gpu_store_float(int64_t ptr, double val);


# 1399 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h" 3 4
_Bool 
# 1399 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/nanolang.h"
    passive_expression_reads_name(const ASTNode *node, const char *name);
int *passive_binding_order(const ASTNode *block);
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 2


typedef struct {
    char *function_name;
    char *adapter_symbol;
    
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
        worker_thread;
} ModuleCallbackAdapter;

typedef struct {
    char *name;
    char *version;
    char *description;


    char **headers;
    size_t headers_count;


    int header_priority;


    char **c_sources;
    size_t c_sources_count;


    char *c_compiler;


    char **system_libs;
    size_t system_libs_count;


    char **pkg_config;
    size_t pkg_config_count;


    char **include_dirs;
    size_t include_dirs_count;


    char **cflags;
    size_t cflags_count;


    char **cflags_macos;
    size_t cflags_macos_count;
    char **cflags_linux;
    size_t cflags_linux_count;
    char **cflags_freebsd;
    size_t cflags_freebsd_count;


    char **ldflags;
    size_t ldflags_count;
    char **ldflags_macos;
    size_t ldflags_macos_count;
    char **ldflags_linux;
    size_t ldflags_linux_count;
    char **ldflags_freebsd;
    size_t ldflags_freebsd_count;


    char **frameworks;
    size_t frameworks_count;


    char **dependencies;
    size_t dependencies_count;



    char **system_packages;
    size_t system_packages_count;


    char **apt_packages;
    size_t apt_packages_count;
    char **dnf_packages;
    size_t dnf_packages_count;
    char **brew_packages;
    size_t brew_packages_count;


    char *module_dir;


    char *install_brew;
    char *install_apt;




    char **owned_string_returns;
    size_t owned_string_returns_count;




    char **shared_c_sources;
    size_t shared_c_sources_count;
    ModuleCallbackAdapter *callback_adapters;
    size_t callback_adapters_count;
} ModuleBuildMetadata;


typedef struct {
    char *object_file;
    char *module_dir;
    char **link_flags;
    size_t link_flags_count;
    char **compile_flags;
    size_t compile_flags_count;
    
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 3 4
   _Bool 
# 128 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
        needs_rebuild;
} ModuleBuildInfo;


typedef struct ModuleBuilder ModuleBuilder;


ModuleBuilder* module_builder_new(const char *module_path);


void module_builder_free(ModuleBuilder *builder);



ModuleBuildMetadata* module_load_metadata(const char *module_dir);


void module_metadata_free(ModuleBuildMetadata *meta);



ModuleBuildInfo* module_build(ModuleBuilder *builder, ModuleBuildMetadata *meta);



ModuleBuildInfo* module_build_native(ModuleBuilder *builder, ModuleBuildMetadata *meta);


void module_build_info_free(ModuleBuildInfo *info);


char** module_get_link_flags(ModuleBuildInfo **modules, size_t count, size_t *out_count);


char** module_get_compile_flags(ModuleBuildInfo **modules, size_t count, size_t *out_count);



# 165 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 3 4
_Bool 
# 165 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
    module_needs_rebuild(const char *module_dir, ModuleBuildMetadata *meta);


char* module_get_build_dir(const char *module_dir);



# 171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 3 4
_Bool 
# 171 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
    module_ensure_build_dir(const char *module_dir);


extern 
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h" 3 4
      _Bool 
# 174 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/../../src/module_builder.h"
           module_builder_verbose;






ConstantDef* parse_c_header_constants(const char *header_path, int *count_out);


char *module_find_header(const char *header_name);
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 2



# 1 "/usr/include/aarch64-linux-gnu/sys/stat.h" 1 3 4
# 99 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stat.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 2 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4

# 44 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
struct stat
  {
    __dev_t st_dev;
    __ino_t st_ino;
    __mode_t st_mode;
    __nlink_t st_nlink;
    __uid_t st_uid;
    __gid_t st_gid;
    __dev_t st_rdev;
    __dev_t __pad1;
    __off_t st_size;
    __blksize_t st_blksize;
    int __pad2;
    __blkcnt_t st_blocks;







    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 79 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
    int __glibc_reserved[2];
  };




struct stat64
  {
    __dev_t st_dev;
    __ino64_t st_ino;
    __mode_t st_mode;
    __nlink_t st_nlink;
    __uid_t st_uid;
    __gid_t st_gid;
    __dev_t st_rdev;
    __dev_t __pad1;
    __off64_t st_size;
    __blksize_t st_blksize;
    int __pad2;
    __blkcnt64_t st_blocks;







    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 117 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
    int __glibc_reserved[2];
  };
# 26 "/usr/include/aarch64-linux-gnu/bits/stat.h" 2 3 4
# 102 "/usr/include/aarch64-linux-gnu/sys/stat.h" 2 3 4
# 205 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 240 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int stat64 (const char *__restrict __file,
     struct stat64 *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int fstat64 (int __fd, struct stat64 *__buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 264 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 291 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int fstatat64 (int __fd, const char *__restrict __file,
        struct stat64 *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 313 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 338 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int lstat64 (const char *__restrict __file,
      struct stat64 *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 352 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int lchmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ , __leaf__));





extern int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;






extern __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ , __leaf__));




extern __mode_t getumask (void) __attribute__ ((__nothrow__ , __leaf__));



extern int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






extern int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





extern int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






extern int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 452 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ , __leaf__));
# 465 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/statx.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/bits/statx.h" 3 4
# 1 "/usr/include/linux/stat.h" 1 3 4




# 1 "/usr/include/linux/types.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/asm/types.h" 1 3 4
# 1 "/usr/include/asm-generic/types.h" 1 3 4






# 1 "/usr/include/asm-generic/int-ll64.h" 1 3 4
# 12 "/usr/include/asm-generic/int-ll64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/asm/bitsperlong.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/asm/bitsperlong.h" 3 4
# 1 "/usr/include/asm-generic/bitsperlong.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/asm/bitsperlong.h" 2 3 4
# 13 "/usr/include/asm-generic/int-ll64.h" 2 3 4







typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;


__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
# 8 "/usr/include/asm-generic/types.h" 2 3 4
# 2 "/usr/include/aarch64-linux-gnu/asm/types.h" 2 3 4
# 6 "/usr/include/linux/types.h" 2 3 4



# 1 "/usr/include/linux/posix_types.h" 1 3 4




# 1 "/usr/include/linux/stddef.h" 1 3 4
# 6 "/usr/include/linux/posix_types.h" 2 3 4
# 25 "/usr/include/linux/posix_types.h" 3 4
typedef struct {
 unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;


typedef void (*__kernel_sighandler_t)(int);


typedef int __kernel_key_t;
typedef int __kernel_mqd_t;

# 1 "/usr/include/aarch64-linux-gnu/asm/posix_types.h" 1 3 4




typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;


# 1 "/usr/include/asm-generic/posix_types.h" 1 3 4
# 15 "/usr/include/asm-generic/posix_types.h" 3 4
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;



typedef __kernel_ulong_t __kernel_ino_t;



typedef unsigned int __kernel_mode_t;



typedef int __kernel_pid_t;



typedef int __kernel_ipc_pid_t;



typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;



typedef __kernel_long_t __kernel_suseconds_t;



typedef int __kernel_daddr_t;



typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
# 59 "/usr/include/asm-generic/posix_types.h" 3 4
typedef unsigned int __kernel_old_dev_t;
# 72 "/usr/include/asm-generic/posix_types.h" 3 4
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;




typedef struct {
 int val[2];
} __kernel_fsid_t;





typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef __kernel_long_t __kernel_old_time_t;
typedef __kernel_long_t __kernel_time_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
# 10 "/usr/include/aarch64-linux-gnu/asm/posix_types.h" 2 3 4
# 37 "/usr/include/linux/posix_types.h" 2 3 4
# 10 "/usr/include/linux/types.h" 2 3 4


typedef __signed__ __int128 __s128 __attribute__((aligned(16)));
typedef unsigned __int128 __u128 __attribute__((aligned(16)));
# 31 "/usr/include/linux/types.h" 3 4
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;

typedef __u16 __sum16;
typedef __u32 __wsum;
# 55 "/usr/include/linux/types.h" 3 4
typedef unsigned __poll_t;
# 6 "/usr/include/linux/stat.h" 2 3 4
# 56 "/usr/include/linux/stat.h" 3 4
struct statx_timestamp {
 __s64 tv_sec;
 __u32 tv_nsec;
 __s32 __reserved;
};
# 99 "/usr/include/linux/stat.h" 3 4
struct statx {

 __u32 stx_mask;
 __u32 stx_blksize;
 __u64 stx_attributes;

 __u32 stx_nlink;
 __u32 stx_uid;
 __u32 stx_gid;
 __u16 stx_mode;
 __u16 __spare0[1];

 __u64 stx_ino;
 __u64 stx_size;
 __u64 stx_blocks;
 __u64 stx_attributes_mask;

 struct statx_timestamp stx_atime;
 struct statx_timestamp stx_btime;
 struct statx_timestamp stx_ctime;
 struct statx_timestamp stx_mtime;

 __u32 stx_rdev_major;
 __u32 stx_rdev_minor;
 __u32 stx_dev_major;
 __u32 stx_dev_minor;

 __u64 stx_mnt_id;
 __u32 stx_dio_mem_align;
 __u32 stx_dio_offset_align;

 __u64 __spare3[12];

};
# 32 "/usr/include/aarch64-linux-gnu/bits/statx.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/statx-generic.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/statx-generic.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_statx_timestamp.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/statx-generic.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_statx.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/statx-generic.h" 2 3 4
# 58 "/usr/include/aarch64-linux-gnu/bits/statx-generic.h" 3 4



int statx (int __dirfd, const char *__restrict __path, int __flags,
           unsigned int __mask, struct statx *__restrict __buf)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 5)));


# 40 "/usr/include/aarch64-linux-gnu/bits/statx.h" 2 3 4
# 466 "/usr/include/aarch64-linux-gnu/sys/stat.h" 2 3 4



# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 2
# 1 "/usr/include/inttypes.h" 1 3 4
# 34 "/usr/include/inttypes.h" 3 4
typedef unsigned int __gwchar_t;
# 327 "/usr/include/inttypes.h" 3 4





typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
# 351 "/usr/include/inttypes.h" 3 4
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));


extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));


extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));





extern intmax_t strtoimax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoimax") __attribute__ ((__nothrow__ , __leaf__))

                                         ;
extern uintmax_t strtoumax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoumax") __attribute__ ((__nothrow__ , __leaf__))

                                          ;
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoimax") __attribute__ ((__nothrow__ , __leaf__))


                       ;
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoumax") __attribute__ ((__nothrow__ , __leaf__))


                        ;
# 415 "/usr/include/inttypes.h" 3 4

# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 2


# 12 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
const char *nlc_module_header_constants(const char *source_path) {
    static _Thread_local char *snapshot;
    char *source = 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                  ((void *)0)
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                      ;
    ModuleBuildMetadata *metadata = 
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                   ((void *)0)
# 15 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                       ;
    
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
        failed = 
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                 0
# 16 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                      ;
    size_t length = 0;
    struct stat st;
    free(snapshot);
    snapshot = 
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
              ((void *)0)
# 20 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                  ;
    if (!source_path || !source_path[0] || !(source = realpath(source_path, 
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                                           ((void *)0)
# 21 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                                               )) ||
        stat(source, &st) != 0 || !
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                  ((((
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                  st.st_mode
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                  )) & 0170000) == (0100000))
# 22 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                     ) goto done;
    char *slash = strrchr(source, '/');
    if (!slash) goto done;
    if (slash == source) slash[1] = '\0';
    else *slash = '\0';
    metadata = module_load_metadata(source);
    if (!metadata) goto done;
    for (size_t i = 0; i < metadata->headers_count && !failed; ++i) {
        char *path = module_find_header(metadata->headers[i]);
        if (!path) continue;
        int count = 0;
        ConstantDef *constants = parse_c_header_constants(path, &count);
        free(path);
        for (int j = 0; j < count; ++j) {
            int extra = snprintf(
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                ((void *)0)
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                    , 0, "%s=%" 
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                "l" "d" 
# 36 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                       "\n", constants[j].name, constants[j].value);
            if (extra < 0 || (size_t)extra >= 
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                             (18446744073709551615UL) 
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                      - length) { failed = 
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                                           1
# 37 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                                               ; break; }
            char *grown = realloc(snapshot, length + (size_t)extra + 1);
            if (!grown) { failed = 
# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                  1
# 39 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                      ; break; }
            snapshot = grown;
            snprintf(snapshot + length, (size_t)extra + 1, "%s=%" 
# 41 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                                 "l" "d" 
# 41 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                                        "\n",
                     constants[j].name, constants[j].value);
            length += (size_t)extra;
        }
        for (int j = 0; j < count; ++j) free(constants[j].name);
        free(constants);
    }
done:
    free(source);
    module_metadata_free(metadata);
    if (failed) { free(snapshot); snapshot = 
# 51 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                            ((void *)0)
# 51 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                ; }
    return snapshot ? snapshot : "";
}

const char *nlc_module_artifact(const char *source_path) {
    static _Thread_local char *snapshot;
    char *source = 
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                  ((void *)0)
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                      , *generation = 
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                      ((void *)0)
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                          , *library = 
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                       ((void *)0)
# 57 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                           ;
    ModuleBuildMetadata *metadata = 
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                   ((void *)0)
# 58 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                       ;
    ModuleBuildInfo *build = 
# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                            ((void *)0)
# 59 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                ;
    struct stat st;
    free(snapshot);
    snapshot = 
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
              ((void *)0)
# 62 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                  ;
    if (!source_path || !source_path[0] || !(source = realpath(source_path, 
# 63 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                                           ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                                               )) ||
        stat(source, &st) != 0 || !
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                  ((((
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                  st.st_mode
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                  )) & 0170000) == (0100000))
# 64 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                     ) goto done;
    char *slash = strrchr(source, '/');
    if (!slash) goto done;
    if (slash == source) slash[1] = '\0';
    else *slash = '\0';
    metadata = module_load_metadata(source);
    if (!metadata || !metadata->name || !metadata->name[0] ||
        metadata->c_sources_count == 0) goto done;
    build = module_build(
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                        ((void *)0)
# 72 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                            , metadata);
    if (!build || !build->object_file || !(generation = strdup(build->object_file))) goto done;
    slash = strrchr(generation, '/');
    if (!slash) goto done;
    *slash = '\0';



    const char *extension = "so";


    int library_length = snprintf(
# 83 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                 ((void *)0)
# 83 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                     , 0, "%s/lib%s.%s",
                                  generation, metadata->name, extension);
    if (library_length < 0) goto done;
    library = malloc((size_t)library_length + 1U);
    if (!library || snprintf(library, (size_t)library_length + 1U,
                             "%s/lib%s.%s", generation, metadata->name,
                             extension) != library_length) {
        free(library);
        library = 
# 91 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                 ((void *)0)
# 91 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                     ;
        goto done;
    }
    snapshot = realpath(library, 
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                ((void *)0)
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                    );
    if (snapshot && (stat(snapshot, &st) != 0 || !
# 95 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                 ((((
# 95 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                 st.st_mode
# 95 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                                                 )) & 0170000) == (0100000))
# 95 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                                                                    )) {
        free(snapshot);
        snapshot = 
# 97 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c" 3 4
                  ((void *)0)
# 97 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/compiler_support/compiler_support.c"
                      ;
    }
done:
    free(source);
    free(generation);
    free(library);
    module_build_info_free(build);
    module_metadata_free(metadata);
    return snapshot ? snapshot : "";
}
