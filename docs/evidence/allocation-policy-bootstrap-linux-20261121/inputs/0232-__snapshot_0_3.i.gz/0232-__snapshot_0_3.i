# 0 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 6 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.h" 2








# 13 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 2 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h" 1
# 86 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 87 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h" 2
# 103 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h"
typedef struct cJSON
{

    struct cJSON *next;
    struct cJSON *prev;

    struct cJSON *child;


    int type;


    char *valuestring;

    int valueint;

    double valuedouble;


    char *string;
} cJSON;

typedef struct cJSON_Hooks
{

      void *( *malloc_fn)(size_t sz);
      void ( *free_fn)(void *ptr);
} cJSON_Hooks;

typedef int cJSON_bool;
# 147 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h"
const char* cJSON_Version(void);


void cJSON_InitHooks(cJSON_Hooks* hooks);



cJSON * cJSON_Parse(const char *value);
cJSON * cJSON_ParseWithLength(const char *value, size_t buffer_length);


cJSON * cJSON_ParseWithOpts(const char *value, const char **return_parse_end, cJSON_bool require_null_terminated);
cJSON * cJSON_ParseWithLengthOpts(const char *value, size_t buffer_length, const char **return_parse_end, cJSON_bool require_null_terminated);


char * cJSON_Print(const cJSON *item);

char * cJSON_PrintUnformatted(const cJSON *item);

char * cJSON_PrintBuffered(const cJSON *item, int prebuffer, cJSON_bool fmt);


cJSON_bool cJSON_PrintPreallocated(cJSON *item, char *buffer, const int length, const cJSON_bool format);

void cJSON_Delete(cJSON *item);


int cJSON_GetArraySize(const cJSON *array);

cJSON * cJSON_GetArrayItem(const cJSON *array, int index);

cJSON * cJSON_GetObjectItem(const cJSON * const object, const char * const string);
cJSON * cJSON_GetObjectItemCaseSensitive(const cJSON * const object, const char * const string);
cJSON_bool cJSON_HasObjectItem(const cJSON *object, const char *string);

const char * cJSON_GetErrorPtr(void);


char * cJSON_GetStringValue(const cJSON * const item);
double cJSON_GetNumberValue(const cJSON * const item);


cJSON_bool cJSON_IsInvalid(const cJSON * const item);
cJSON_bool cJSON_IsFalse(const cJSON * const item);
cJSON_bool cJSON_IsTrue(const cJSON * const item);
cJSON_bool cJSON_IsBool(const cJSON * const item);
cJSON_bool cJSON_IsNull(const cJSON * const item);
cJSON_bool cJSON_IsNumber(const cJSON * const item);
cJSON_bool cJSON_IsString(const cJSON * const item);
cJSON_bool cJSON_IsArray(const cJSON * const item);
cJSON_bool cJSON_IsObject(const cJSON * const item);
cJSON_bool cJSON_IsRaw(const cJSON * const item);


cJSON * cJSON_CreateNull(void);
cJSON * cJSON_CreateTrue(void);
cJSON * cJSON_CreateFalse(void);
cJSON * cJSON_CreateBool(cJSON_bool boolean);
cJSON * cJSON_CreateNumber(double num);
cJSON * cJSON_CreateString(const char *string);

cJSON * cJSON_CreateRaw(const char *raw);
cJSON * cJSON_CreateArray(void);
cJSON * cJSON_CreateObject(void);



cJSON * cJSON_CreateStringReference(const char *string);


cJSON * cJSON_CreateObjectReference(const cJSON *child);
cJSON * cJSON_CreateArrayReference(const cJSON *child);



cJSON * cJSON_CreateIntArray(const int *numbers, int count);
cJSON * cJSON_CreateFloatArray(const float *numbers, int count);
cJSON * cJSON_CreateDoubleArray(const double *numbers, int count);
cJSON * cJSON_CreateStringArray(const char *const *strings, int count);


cJSON_bool cJSON_AddItemToArray(cJSON *array, cJSON *item);
cJSON_bool cJSON_AddItemToObject(cJSON *object, const char *string, cJSON *item);



cJSON_bool cJSON_AddItemToObjectCS(cJSON *object, const char *string, cJSON *item);

cJSON_bool cJSON_AddItemReferenceToArray(cJSON *array, cJSON *item);
cJSON_bool cJSON_AddItemReferenceToObject(cJSON *object, const char *string, cJSON *item);


cJSON * cJSON_DetachItemViaPointer(cJSON *parent, cJSON * const item);
cJSON * cJSON_DetachItemFromArray(cJSON *array, int which);
void cJSON_DeleteItemFromArray(cJSON *array, int which);
cJSON * cJSON_DetachItemFromObject(cJSON *object, const char *string);
cJSON * cJSON_DetachItemFromObjectCaseSensitive(cJSON *object, const char *string);
void cJSON_DeleteItemFromObject(cJSON *object, const char *string);
void cJSON_DeleteItemFromObjectCaseSensitive(cJSON *object, const char *string);


cJSON_bool cJSON_InsertItemInArray(cJSON *array, int which, cJSON *newitem);
cJSON_bool cJSON_ReplaceItemViaPointer(cJSON * const parent, cJSON * const item, cJSON * replacement);
cJSON_bool cJSON_ReplaceItemInArray(cJSON *array, int which, cJSON *newitem);
cJSON_bool cJSON_ReplaceItemInObject(cJSON *object,const char *string,cJSON *newitem);
cJSON_bool cJSON_ReplaceItemInObjectCaseSensitive(cJSON *object,const char *string,cJSON *newitem);


cJSON * cJSON_Duplicate(const cJSON *item, cJSON_bool recurse);





cJSON_bool cJSON_Compare(const cJSON * const a, const cJSON * const b, const cJSON_bool case_sensitive);




void cJSON_Minify(char *json);



cJSON* cJSON_AddNullToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddTrueToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddFalseToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddBoolToObject(cJSON * const object, const char * const name, const cJSON_bool boolean);
cJSON* cJSON_AddNumberToObject(cJSON * const object, const char * const name, const double number);
cJSON* cJSON_AddStringToObject(cJSON * const object, const char * const name, const char * const string);
cJSON* cJSON_AddRawToObject(cJSON * const object, const char * const name, const char * const raw);
cJSON* cJSON_AddObjectToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddArrayToObject(cJSON * const object, const char * const name);




double cJSON_SetNumberHelper(cJSON *object, double number);


char* cJSON_SetValuestring(cJSON *object, const char *valuestring);
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/cJSON.h"
void * cJSON_malloc(size_t size);
void cJSON_free(void *object);
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi_internal.h" 2



NlNsi *nl_nsi_decode_object(cJSON *json);
# 3 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2
# 1 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h" 2







# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h" 3 4
_Bool 
# 11 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h"
    nl_utf8_validate(const char *data, size_t n, size_t *error_offset);



# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/utf8.h"
    nl_utf8_ok_cstr(const char *s);



const char *nl_utf8_cstr_or_marker(const char *s);


int nl_ascii_isspace(int c);
int nl_ascii_isdigit(int c);
int nl_ascii_isalpha(int c);
int nl_ascii_isalnum(int c);
int nl_ascii_isupper(int c);
int nl_ascii_islower(int c);
int nl_ascii_isprint(int c);
int nl_ascii_toupper(int c);
int nl_ascii_tolower(int c);




void nl_utf8_sanitize_log(const char *s, char *out, size_t out_n);
# 4 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2


# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 40 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;






typedef __off64_t off64_t;






typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4




extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream)
    __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 7 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 97 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 114 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 153 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 8 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));



# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 552 "/usr/include/string.h" 3 4

# 9 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 2


# 10 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
static void free_named(NlNsiNamed *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
    }
    free(items);
}

static void free_params(NlNsiParam *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
        free(items[i].type_id);
    }
    free(items);
}

static void free_methods(NlNsiMethod *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
        free_params(items[i].params, items[i].param_count);
    }
    free(items);
}

static void free_members(NlNsiMember *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
        free(items[i].type_id);
    }
    free(items);
}

static void free_types(NlNsiType *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
        free_members(items[i].members, items[i].member_count);
        free(items[i].element_id);
        free(items[i].method_id);
        free(items[i].result_id);
    }
    free(items);
}

static void free_errors(NlNsiError *items, size_t n) {
    size_t i;
    if (!items) return;
    for (i = 0; i < n; i++) {
        free(items[i].id);
        free(items[i].name);
        free(items[i].version);
    }
    free(items);
}

void nl_nsi_free(NlNsi *nsi) {
    if (!nsi) return;
    free(nsi->iface.id);
    free(nsi->iface.name);
    free_methods(nsi->methods, nsi->method_count);
    free_types(nsi->types, nsi->type_count);
    free_errors(nsi->errors, nsi->error_count);
    free_named(nsi->capabilities, nsi->capability_count);
    free(nsi);
}

static int id_char_ok(unsigned char c) {
    return nl_ascii_isalnum((int)c) || c == ':' || c == '/' || c == '.' ||
           c == '_' || c == '-' || c == '#';
}

static 
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 94 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           id_ascii_ok(const char *id) {
    size_t i;
    if (!id || !id[0]) return 
# 96 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                             0
# 96 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                  ;
    for (i = 0; id[i]; i++) {
        if (!id_char_ok((unsigned char)id[i])) return 
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                     0
# 98 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                          ;
    }
    return 
# 100 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 100 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 103 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 103 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           starts_with(const char *s, const char *pfx) {
    return s && pfx && strncmp(s, pfx, strlen(pfx)) == 0;
}

static 
# 107 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 107 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           keys_allowed(const cJSON *obj, const char *const *allowed, size_t n) {
    const cJSON *child;
    if (!obj || !cJSON_IsObject(obj)) return 
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                            0
# 109 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                 ;
    for(child = (obj != 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
   ((void *)0)
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
   ) ? (obj)->child : 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
   ((void *)0)
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
   ; child != 
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
   ((void *)0)
# 110 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
   ; child = child->next) {
        size_t i;
        int ok = 0;
        if (!child->string) return 
# 113 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                  0
# 113 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                       ;
        for (i = 0; i < n; i++) {
            if (strcmp(child->string, allowed[i]) == 0) {
                ok = 1;
                break;
            }
        }
        if (!ok) return 
# 120 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       0
# 120 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                            ;
    }
    return 
# 122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 122 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 125 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           is_core_type(const char *id) {
    return id &&
           (strcmp(id, "nsi:core/string") == 0 ||
            strcmp(id, "nsi:core/int") == 0 ||
            strcmp(id, "nsi:core/bool") == 0 ||
            strcmp(id, "nsi:core/unit") == 0 ||
            strcmp(id, "nsi:core/bytes") == 0 ||
            strcmp(id, "nsi:core/float") == 0);
}

static 
# 135 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 135 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_named(cJSON *obj, NlNsiNamed *out) {
    cJSON *id;
    cJSON *name;
    if (!obj || !cJSON_IsObject(obj) || !out) return 
# 138 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                    0
# 138 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                         ;
    id = cJSON_GetObjectItemCaseSensitive(obj, "id");
    name = cJSON_GetObjectItemCaseSensitive(obj, "name");
    if (!cJSON_IsString(id) || !cJSON_IsString(name)) return 
# 141 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                            0
# 141 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                 ;
    if (!id_ascii_ok(id->valuestring)) return 
# 142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                             0
# 142 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                  ;
    if (!name->valuestring || !name->valuestring[0]) return 
# 143 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                           0
# 143 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                ;
    char *copy_id = strdup(id->valuestring);
    char *copy_name = strdup(name->valuestring);
    if (!copy_id || !copy_name) {
        free(copy_id);
        free(copy_name);
        return 
# 149 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 149 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    out->id = copy_id;
    out->name = copy_name;
    return 
# 153 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 153 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 156 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 156 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_named_array(cJSON *arr, NlNsiNamed **out, size_t *count) {
    int n;
    int i;
    if (!arr) {
        *out = 
# 160 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 160 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 162 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 162 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    if (!cJSON_IsArray(arr)) return 
# 164 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                   0
# 164 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                        ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 166 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 166 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 168 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 168 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 170 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 170 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 173 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 173 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        static const char *const keys[] = { "id", "name" };
        cJSON *item = cJSON_GetArrayItem(arr, i);
        if (!keys_allowed(item, keys, 2) || !parse_named(item, &(*out)[i])) {
            free_named(*out, (size_t)i);
            *out = 
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 180 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 182 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 182 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 186 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 186 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 189 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_enum(cJSON *obj, const char *key, const char *const *names, int n, int *out) {
    cJSON *item;
    int i;
    if (!obj || !key || !names || !out || n <= 0) return 
# 192 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                        0
# 192 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                             ;
    item = cJSON_GetObjectItemCaseSensitive(obj, key);
    if (!cJSON_IsString(item) || !item->valuestring) return 
# 194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                           0
# 194 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                ;
    for (i = 0; i < n; i++) {
        if (strcmp(item->valuestring, names[i]) == 0) {
            *out = i;
            return 
# 198 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  1
# 198 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
        }
    }
    return 
# 201 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          0
# 201 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
               ;
}

static 
# 204 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 204 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           streaming_matches_direction(NlNsiDirection dir, NlNsiStreaming stream) {
    if (stream == NL_NSI_STREAM_NONE) return 
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                            1
# 205 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    if (stream == NL_NSI_STREAM_IN)
        return dir == NL_NSI_DIR_IN || dir == NL_NSI_DIR_INOUT;
    if (stream == NL_NSI_STREAM_OUT)
        return dir == NL_NSI_DIR_OUT || dir == NL_NSI_DIR_INOUT ||
               dir == NL_NSI_DIR_RETURN;
    if (stream == NL_NSI_STREAM_BIDI) return dir == NL_NSI_DIR_INOUT;
    return 
# 212 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          0
# 212 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
               ;
}

static const char *const k_direction[] = { "in", "out", "inout", "return" };
static const char *const k_ownership[] = { "borrow", "transfer", "copy" };
static const char *const k_lifetime[] = { "call", "caller", "callee", "resource" };
static const char *const k_mutability[] = { "immutable", "mutable" };
static const char *const k_streaming[] = { "none", "in", "out", "bidi" };

static 
# 221 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 221 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_param(cJSON *obj, NlNsiParam *out) {
    static const char *const keys[] = {
        "id", "name", "type", "direction", "ownership", "lifetime",
        "mutability", "optional", "streaming"
    };
    NlNsiNamed named = {0};
    cJSON *optional;
    cJSON *type;
    int direction = 0;
    int ownership = 0;
    int lifetime = 0;
    int mutability = 0;
    int streaming = 0;

    if (!keys_allowed(obj, keys, 9)) return 
# 235 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                           0
# 235 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    if (!parse_named(obj, &named)) return 
# 236 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                         0
# 236 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                              ;
    out->id = named.id;
    out->name = named.name;
    type = cJSON_GetObjectItemCaseSensitive(obj, "type");
    if (!cJSON_IsString(type) || !id_ascii_ok(type->valuestring)) {
        free(out->id);
        free(out->name);
        out->id = 
# 243 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 243 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 244 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 244 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 245 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 245 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    if (!starts_with(type->valuestring, "nsi:")) {
        free(out->id);
        free(out->name);
        out->id = 
# 250 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 250 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 251 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 251 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 252 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 252 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    if (!parse_enum(obj, "direction", k_direction, 4, &direction) ||
        !parse_enum(obj, "ownership", k_ownership, 3, &ownership) ||
        !parse_enum(obj, "lifetime", k_lifetime, 4, &lifetime) ||
        !parse_enum(obj, "mutability", k_mutability, 2, &mutability) ||
        !parse_enum(obj, "streaming", k_streaming, 4, &streaming)) {
        free(out->id);
        free(out->name);
        out->id = 
# 261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 261 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 262 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 263 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 263 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    optional = cJSON_GetObjectItemCaseSensitive(obj, "optional");
    if (!cJSON_IsBool(optional)) {
        free(out->id);
        free(out->name);
        out->id = 
# 269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 269 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 270 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 270 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 271 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    out->type_id = strdup(type->valuestring);
    if (!out->type_id) {
        free(out->id);
        free(out->name);
        out->id = 
# 277 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 277 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 278 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 279 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 279 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    out->direction = (NlNsiDirection)direction;
    out->ownership = (NlNsiOwnership)ownership;
    out->lifetime = (NlNsiLifetime)lifetime;
    out->mutability = (NlNsiMutability)mutability;
    out->optional = cJSON_IsTrue(optional) ? 1 : 0;
    out->streaming = (NlNsiStreaming)streaming;
    if (!streaming_matches_direction(out->direction, out->streaming)) {
        free(out->id);
        free(out->name);
        free(out->type_id);
        out->id = 
# 291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 291 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 292 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 292 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        out->type_id = 
# 293 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                      ((void *)0)
# 293 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
        return 
# 294 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 294 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    return 
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 296 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 299 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_param_array(cJSON *arr, NlNsiParam **out, size_t *count) {
    int n;
    int i;
    if (!arr) {
        *out = 
# 303 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 303 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 305 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 305 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    if (!cJSON_IsArray(arr)) return 
# 307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                   0
# 307 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                        ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 309 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 311 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 311 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 313 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 313 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 316 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 316 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        if (!parse_param(cJSON_GetArrayItem(arr, i), &(*out)[i])) {
            free_params(*out, (size_t)i);
            *out = 
# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 321 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 323 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 323 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 327 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 330 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 330 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_method(cJSON *obj, NlNsiMethod *out) {
    static const char *const keys[] = { "id", "name", "params", "idempotent" };
    NlNsiNamed named = {0};
    cJSON *params;
    cJSON *idemp;
    if (!keys_allowed(obj, keys, 4)) return 
# 335 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                           0
# 335 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    if (!parse_named(obj, &named)) return 
# 336 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                         0
# 336 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                              ;
    out->id = named.id;
    out->name = named.name;
    out->params = 
# 339 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 339 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
    out->param_count = 0;
    out->idempotent = 0;
    idemp = cJSON_GetObjectItemCaseSensitive(obj, "idempotent");
    if (idemp) {
        if (!cJSON_IsBool(idemp)) {
            free(out->id);
            free(out->name);
            out->id = 
# 347 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 347 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 348 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 348 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 349 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 349 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        out->idempotent = cJSON_IsTrue(idemp) ? 1 : 0;
    }
    params = cJSON_GetObjectItemCaseSensitive(obj, "params");
    if (!params || !cJSON_IsArray(params)) {
        free(out->id);
        free(out->name);
        out->id = 
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 357 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 358 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 358 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 359 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 359 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    if (!parse_param_array(params, &out->params, &out->param_count)) {
        free(out->id);
        free(out->name);
        out->id = 
# 364 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 364 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 365 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 366 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 366 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    return 
# 368 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 368 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 371 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 371 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_method_array(cJSON *arr, NlNsiMethod **out, size_t *count) {
    int n;
    int i;
    if (!arr) {
        *out = 
# 375 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 375 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 377 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 377 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    if (!cJSON_IsArray(arr)) return 
# 379 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                   0
# 379 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                        ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 381 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 383 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 383 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 385 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 388 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 388 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        if (!parse_method(cJSON_GetArrayItem(arr, i), &(*out)[i])) {
            free_methods(*out, (size_t)i);
            *out = 
# 393 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 393 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 395 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 395 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 399 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 399 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 402 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 402 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           type_ref_ok(const char *id) {
    return id_ascii_ok(id) && starts_with(id, "nsi:");
}

static 
# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 406 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           version_ok(const char *v) {
    size_t i;
    if (!v || !v[0]) return 
# 408 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                           0
# 408 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                ;
    for (i = 0; v[i]; i++) {
        unsigned char c = (unsigned char)v[i];
        if (!nl_ascii_isalnum((int)c) && c != '.' && c != '_' && c != '-')
            return 
# 412 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 412 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
    }
    return 
# 414 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 414 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 417 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 417 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_member(cJSON *obj, NlNsiMember *out, int require_type) {
    static const char *const keys[] = { "id", "name", "type" };
    NlNsiNamed named = {0};
    cJSON *type;
    if (!keys_allowed(obj, keys, 3)) return 
# 421 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                           0
# 421 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    if (!parse_named(obj, &named)) return 
# 422 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                         0
# 422 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                              ;
    out->id = named.id;
    out->name = named.name;
    out->type_id = 
# 425 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 425 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
    type = cJSON_GetObjectItemCaseSensitive(obj, "type");
    if (type) {
        if (!cJSON_IsString(type) || !type_ref_ok(type->valuestring)) {
            free(out->id);
            free(out->name);
            out->id = 
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 431 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 432 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 432 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 433 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 433 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        out->type_id = strdup(type->valuestring);
        if (!out->type_id) {
            free(out->id);
            free(out->name);
            out->id = 
# 439 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 439 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 440 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 440 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 441 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 441 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    } else if (require_type) {
        free(out->id);
        free(out->name);
        out->id = 
# 446 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 446 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 447 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 447 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 448 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 448 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    return 
# 450 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 450 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 453 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 453 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_member_array(cJSON *arr, NlNsiMember **out, size_t *count, int require_type) {
    int n;
    int i;
    if (!arr || !cJSON_IsArray(arr)) return 
# 456 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                           0
# 456 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 458 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 458 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 460 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 460 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 462 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 465 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 465 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        if (!parse_member(cJSON_GetArrayItem(arr, i), &(*out)[i], require_type)) {
            free_members(*out, (size_t)i);
            *out = 
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 470 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 472 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 472 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 476 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 476 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static const char *const k_type_kind[] = {
    "opaque", "record", "variant", "array", "string", "binary",
    "resource", "callback", "async"
};

static 
# 484 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 484 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_type(cJSON *obj, NlNsiType *out) {
    NlNsiNamed named = {0};
    cJSON *kind_item;
    int kind = NL_NSI_TYPE_OPAQUE;

    if (!parse_named(obj, &named)) return 
# 489 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                         0
# 489 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                              ;
    out->id = named.id;
    out->name = named.name;
    out->members = 
# 492 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 492 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
    out->member_count = 0;
    out->element_id = 
# 494 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 494 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
    out->method_id = 
# 495 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    ((void *)0)
# 495 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                        ;
    out->result_id = 
# 496 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    ((void *)0)
# 496 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                        ;
    kind_item = cJSON_GetObjectItemCaseSensitive(obj, "kind");
    if (!kind_item ||
        !parse_enum(obj, "kind", k_type_kind, 9, &kind) ||
        kind == NL_NSI_TYPE_OPAQUE) {
        free(out->id);
        free(out->name);
        out->id = 
# 503 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 503 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 504 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 504 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 505 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    out->kind = (NlNsiTypeKind)kind;
    {
        const char *const *keys = 
# 509 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                 ((void *)0)
# 509 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                     ;
        size_t nkeys = 0;
        static const char *const k_record[] = { "id", "name", "kind", "fields" };
        static const char *const k_variant[] = { "id", "name", "kind", "cases" };
        static const char *const k_array[] = { "id", "name", "kind", "element" };
        static const char *const k_simple[] = { "id", "name", "kind" };
        static const char *const k_callback[] = { "id", "name", "kind", "method" };
        static const char *const k_async[] = { "id", "name", "kind", "result" };
        if (out->kind == NL_NSI_TYPE_RECORD) { keys = k_record; nkeys = 4; }
        else if (out->kind == NL_NSI_TYPE_VARIANT) { keys = k_variant; nkeys = 4; }
        else if (out->kind == NL_NSI_TYPE_ARRAY) { keys = k_array; nkeys = 4; }
        else if (out->kind == NL_NSI_TYPE_CALLBACK) { keys = k_callback; nkeys = 4; }
        else if (out->kind == NL_NSI_TYPE_ASYNC) { keys = k_async; nkeys = 4; }
        else { keys = k_simple; nkeys = 3; }
        if (!keys_allowed(obj, keys, nkeys)) {
            free(out->id);
            free(out->name);
            out->id = 
# 526 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 526 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 527 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 527 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 528 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 528 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    }
    if (out->kind == NL_NSI_TYPE_RECORD) {
        if (!parse_member_array(cJSON_GetObjectItemCaseSensitive(obj, "fields"),
                                &out->members, &out->member_count, 1)) {
            free(out->id);
            free(out->name);
            out->id = 
# 536 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 536 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 537 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 537 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 538 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 538 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    } else if (out->kind == NL_NSI_TYPE_VARIANT) {
        if (!parse_member_array(cJSON_GetObjectItemCaseSensitive(obj, "cases"),
                                &out->members, &out->member_count, 0) ||
            out->member_count == 0) {
            free(out->id);
            free(out->name);
            free_members(out->members, out->member_count);
            out->id = 
# 547 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 547 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 548 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 548 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            out->members = 
# 549 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                          ((void *)0)
# 549 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                              ;
            out->member_count = 0;
            return 
# 551 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 551 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    } else if (out->kind == NL_NSI_TYPE_ARRAY) {
        cJSON *el = cJSON_GetObjectItemCaseSensitive(obj, "element");
        if (!cJSON_IsString(el) || !type_ref_ok(el->valuestring)) {
            free(out->id);
            free(out->name);
            out->id = 
# 558 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 558 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 559 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 559 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 560 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 560 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        out->element_id = strdup(el->valuestring);
        if (!out->element_id) {
            free(out->id);
            free(out->name);
            out->id = 
# 566 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 566 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 567 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 567 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 568 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 568 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    } else if (out->kind == NL_NSI_TYPE_CALLBACK) {
        cJSON *m = cJSON_GetObjectItemCaseSensitive(obj, "method");
        if (!cJSON_IsString(m) || !id_ascii_ok(m->valuestring)) {
            free(out->id);
            free(out->name);
            out->id = 
# 575 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 575 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 576 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 576 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 577 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 577 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        out->method_id = strdup(m->valuestring);
        if (!out->method_id) {
            free(out->id);
            free(out->name);
            out->id = 
# 583 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 583 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 584 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 584 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 585 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 585 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    } else if (out->kind == NL_NSI_TYPE_ASYNC) {
        cJSON *r = cJSON_GetObjectItemCaseSensitive(obj, "result");
        if (!cJSON_IsString(r) || !type_ref_ok(r->valuestring)) {
            free(out->id);
            free(out->name);
            out->id = 
# 592 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 592 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 593 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 593 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 594 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 594 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        out->result_id = strdup(r->valuestring);
        if (!out->result_id) {
            free(out->id);
            free(out->name);
            out->id = 
# 600 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 600 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
            out->name = 
# 601 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                       ((void *)0)
# 601 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
            return 
# 602 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 602 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
    }
    return 
# 605 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 605 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 608 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 608 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_type_array(cJSON *arr, NlNsiType **out, size_t *count) {
    int n;
    int i;
    if (!arr) {
        *out = 
# 612 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 612 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 614 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 614 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    if (!cJSON_IsArray(arr)) return 
# 616 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                   0
# 616 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                        ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 618 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 618 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 620 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 620 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 622 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 622 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 625 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 625 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        if (!parse_type(cJSON_GetArrayItem(arr, i), &(*out)[i])) {
            free_types(*out, (size_t)i);
            *out = 
# 630 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 630 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 632 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 632 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 636 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 636 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 639 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 639 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_error(cJSON *obj, NlNsiError *out) {
    static const char *const keys[] = { "id", "name", "version" };
    NlNsiNamed named = {0};
    cJSON *ver;
    if (!keys_allowed(obj, keys, 3)) return 
# 643 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                           0
# 643 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                ;
    if (!parse_named(obj, &named)) return 
# 644 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                         0
# 644 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                              ;
    out->id = named.id;
    out->name = named.name;
    out->version = 
# 647 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 647 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
    ver = cJSON_GetObjectItemCaseSensitive(obj, "version");
    if (!ver) return 
# 649 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    1
# 649 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                        ;
    if (!cJSON_IsString(ver) || !version_ok(ver->valuestring)) {
        free(out->id);
        free(out->name);
        out->id = 
# 653 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 653 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 654 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 654 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 655 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 655 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    out->version = strdup(ver->valuestring);
    if (!out->version) {
        free(out->id);
        free(out->name);
        out->id = 
# 661 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                 ((void *)0)
# 661 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                     ;
        out->name = 
# 662 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 662 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        return 
# 663 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              0
# 663 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                   ;
    }
    return 
# 665 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 665 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 668 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 668 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           parse_error_array(cJSON *arr, NlNsiError **out, size_t *count) {
    int n;
    int i;
    if (!arr) {
        *out = 
# 672 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 672 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 674 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 674 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    if (!cJSON_IsArray(arr)) return 
# 676 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                   0
# 676 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                        ;
    n = cJSON_GetArraySize(arr);
    if (n < 0) return 
# 678 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 678 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    if (n == 0) {
        *out = 
# 680 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 680 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
        *count = 0;
        return 
# 682 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              1
# 682 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return 
# 685 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     0
# 685 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                          ;
    *count = 0;
    for (i = 0; i < n; i++) {
        if (!parse_error(cJSON_GetArrayItem(arr, i), &(*out)[i])) {
            free_errors(*out, (size_t)i);
            *out = 
# 690 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 690 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
            *count = 0;
            return 
# 692 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  0
# 692 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
        }
        (*count)++;
    }
    return 
# 696 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 696 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 699 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 699 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           ids_unique(const NlNsi *nsi) {
    size_t n = 1u;
    size_t i;
    size_t j;
    size_t k = 0;
    const char **ids;
    
# 705 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
   _Bool 
# 705 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
        ok = 
# 705 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
             1
# 705 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                 ;

    n += nsi->method_count + nsi->type_count + nsi->error_count +
         nsi->capability_count;
    for (i = 0; i < nsi->method_count; i++) n += nsi->methods[i].param_count;
    for (i = 0; i < nsi->type_count; i++) n += nsi->types[i].member_count;
    ids = malloc(n * sizeof(*ids));
    if (!ids) return 
# 712 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    0
# 712 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
    ids[k++] = nsi->iface.id;
    for (i = 0; i < nsi->method_count; i++) {
        ids[k++] = nsi->methods[i].id;
        for (j = 0; j < nsi->methods[i].param_count; j++)
            ids[k++] = nsi->methods[i].params[j].id;
    }
    for (i = 0; i < nsi->type_count; i++) {
        ids[k++] = nsi->types[i].id;
        for (j = 0; j < nsi->types[i].member_count; j++)
            ids[k++] = nsi->types[i].members[j].id;
    }
    for (i = 0; i < nsi->error_count; i++) ids[k++] = nsi->errors[i].id;
    for (i = 0; i < nsi->capability_count; i++) ids[k++] = nsi->capabilities[i].id;
    for (i = 0; i < k && ok; i++) {
        for (j = i + 1; j < k; j++) {
            if (strcmp(ids[i], ids[j]) == 0) {
                ok = 
# 729 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    0
# 729 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
                break;
            }
        }
    }
    free(ids);
    return ok;
}

static 
# 738 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 738 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           fragment_of_interface(const char *iface, const char *id) {
    size_t n;
    if (!iface || !id) return 
# 740 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                             0
# 740 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                  ;
    n = strlen(iface);
    if (strncmp(id, iface, n) != 0) return 
# 742 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                          0
# 742 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                               ;
    return id[n] == '#' && id[n + 1] != '\0';
}

static 
# 746 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 746 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           validate_prefixes(const NlNsi *nsi) {
    size_t i;
    size_t j;
    if (!starts_with(nsi->iface.id, "nsi:")) return 
# 749 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                   0
# 749 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                        ;
    if (strchr(nsi->iface.id, '#') != 
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                     ((void *)0)
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                         ) return 
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                  0
# 750 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                       ;
    for (i = 0; i < nsi->method_count; i++) {
        if (!fragment_of_interface(nsi->iface.id, nsi->methods[i].id)) return 
# 752 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                             0
# 752 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                                  ;
        for (j = 0; j < nsi->methods[i].param_count; j++) {
            if (!fragment_of_interface(nsi->iface.id, nsi->methods[i].params[j].id))
                return 
# 755 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                      0
# 755 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
        }
    }
    for (i = 0; i < nsi->type_count; i++) {
        if (!fragment_of_interface(nsi->iface.id, nsi->types[i].id)) return 
# 759 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                           0
# 759 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                                ;
        for (j = 0; j < nsi->types[i].member_count; j++) {
            if (!fragment_of_interface(nsi->iface.id, nsi->types[i].members[j].id))
                return 
# 762 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                      0
# 762 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
        }
        if (nsi->types[i].kind == NL_NSI_TYPE_CALLBACK) {
            int found = 0;
            size_t m;
            for (m = 0; m < nsi->method_count; m++) {
                if (nsi->types[i].method_id &&
                    strcmp(nsi->types[i].method_id, nsi->methods[m].id) == 0) {
                    found = 1;
                    break;
                }
            }
            if (!found) return 
# 774 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                              0
# 774 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                   ;
        }
    }
    for (i = 0; i < nsi->error_count; i++) {
        if (!fragment_of_interface(nsi->iface.id, nsi->errors[i].id)) return 
# 778 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                            0
# 778 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                                 ;
    }
    for (i = 0; i < nsi->capability_count; i++) {
        if (!starts_with(nsi->capabilities[i].id, "cap:")) return 
# 781 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                 0
# 781 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                      ;
        if (strchr(nsi->capabilities[i].id, '#') != 
# 782 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                   ((void *)0)
# 782 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                       ) return 
# 782 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                0
# 782 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                     ;
    }
    return 
# 784 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 784 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static 
# 787 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 787 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           type_bound_ok(const NlNsi *nsi, const char *id) {
    size_t i;
    if (is_core_type(id)) return 
# 789 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                1
# 789 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                    ;
    if (!nsi || !id) return 
# 790 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                           0
# 790 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                ;
    for (i = 0; i < nsi->type_count; i++) {
        if (nsi->types[i].id && strcmp(nsi->types[i].id, id) == 0 &&
            nsi->types[i].kind != NL_NSI_TYPE_OPAQUE)
            return 
# 794 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  1
# 794 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
    }
    return 
# 796 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          0
# 796 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
               ;
}

static 
# 799 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
      _Bool 
# 799 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
           validate_type_bounds(const NlNsi *nsi) {
    size_t i;
    size_t j;
    for (i = 0; i < nsi->method_count; i++) {
        for (j = 0; j < nsi->methods[i].param_count; j++) {
            if (!type_bound_ok(nsi, nsi->methods[i].params[j].type_id))
                return 
# 805 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                      0
# 805 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
        }
    }
    for (i = 0; i < nsi->type_count; i++) {
        const NlNsiType *t = &nsi->types[i];
        for (j = 0; j < t->member_count; j++) {
            if (t->members[j].type_id && !type_bound_ok(nsi, t->members[j].type_id))
                return 
# 812 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                      0
# 812 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                           ;
        }
        if (t->element_id && !type_bound_ok(nsi, t->element_id)) return 
# 814 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                       0
# 814 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                            ;
        if (t->result_id && !type_bound_ok(nsi, t->result_id)) return 
# 815 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                                     0
# 815 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                          ;
    }
    return 
# 817 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          1
# 817 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

NlNsi *nl_nsi_load_path(const char *path) {
    FILE *fp;
    long size;
    char *buf;
    cJSON *json;
    NlNsi *nsi;

    if (!path) return 
# 827 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                     ((void *)0)
# 827 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                         ;
    fp = fopen(path, "rb");
    if (!fp) return 
# 829 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                   ((void *)0)
# 829 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                       ;
    if (fseek(fp, 0, 
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    2
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                            ) != 0) { fclose(fp); return 
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                         ((void *)0)
# 830 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                             ; }
    size = ftell(fp);
    if (size < 0) { fclose(fp); return 
# 832 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                      ((void *)0)
# 832 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                          ; }
    if (fseek(fp, 0, 
# 833 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                    0
# 833 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                            ) != 0) { fclose(fp); return 
# 833 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                         ((void *)0)
# 833 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                             ; }
    buf = malloc((size_t)size + 1);
    if (!buf) { fclose(fp); return 
# 835 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                  ((void *)0)
# 835 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                      ; }
    if (fread(buf, 1, (size_t)size, fp) != (size_t)size) {
        free(buf);
        fclose(fp);
        return 
# 839 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 839 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    buf[size] = '\0';
    fclose(fp);

    if (!nl_utf8_validate(buf, (size_t)size, 
# 844 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                            ((void *)0)
# 844 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                )) {
        free(buf);
        return 
# 846 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 846 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }

    json = cJSON_Parse(buf);
    free(buf);
    if (!json || !cJSON_IsObject(json)) {
        if (json) cJSON_Delete(json);
        return 
# 853 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 853 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }

    nsi = nl_nsi_decode_object(json);
    cJSON_Delete(json);
    return nsi;
}

NlNsi *nl_nsi_decode_object(cJSON *json) {
    cJSON *ver;
    NlNsi *nsi;
    if (!json || !cJSON_IsObject(json)) return 
# 864 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                              ((void *)0)
# 864 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                  ;
    nsi = calloc(1, sizeof(*nsi));
    if (!nsi) {
        return 
# 867 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 867 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }

    ver = cJSON_GetObjectItemCaseSensitive(json, "nsi_version");
    if (!cJSON_IsNumber(ver) || ver->valuedouble != (double)0) {
        nl_nsi_free(nsi);
        return 
# 873 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
              ((void *)0)
# 873 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                  ;
    }
    nsi->version = 0;

    {
        static const char *const root_keys[] = {
            "nsi_version", "interface", "methods", "types", "errors", "capabilities"
        };
        static const char *const iface_keys[] = { "id", "name" };
        cJSON *iface = cJSON_GetObjectItemCaseSensitive(json, "interface");
        if (!keys_allowed(json, root_keys, 6) ||
            !keys_allowed(iface, iface_keys, 2) ||
            !parse_named(iface, &nsi->iface) ||
            !parse_method_array(cJSON_GetObjectItemCaseSensitive(json, "methods"),
                                &nsi->methods, &nsi->method_count) ||
            !parse_type_array(cJSON_GetObjectItemCaseSensitive(json, "types"),
                               &nsi->types, &nsi->type_count) ||
            !parse_error_array(cJSON_GetObjectItemCaseSensitive(json, "errors"),
                               &nsi->errors, &nsi->error_count) ||
            !parse_named_array(cJSON_GetObjectItemCaseSensitive(json, "capabilities"),
                               &nsi->capabilities, &nsi->capability_count) ||
            !ids_unique(nsi) ||
            !validate_prefixes(nsi) ||
            !validate_type_bounds(nsi)) {
            nl_nsi_free(nsi);
            return 
# 898 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                  ((void *)0)
# 898 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                      ;
        }
    }

    return nsi;
}

const char *nl_nsi_interface_id(const NlNsi *nsi) {
    return nsi && nsi->iface.id ? nsi->iface.id : "";
}

size_t nl_nsi_method_count(const NlNsi *nsi) {
    return nsi ? nsi->method_count : 0;
}

const char *nl_nsi_method_id(const NlNsi *nsi, size_t i) {
    if (!nsi || i >= nsi->method_count) return "";
    return nsi->methods[i].id ? nsi->methods[i].id : "";
}

size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i) {
    if (!nsi || method_i >= nsi->method_count) return 0;
    return nsi->methods[method_i].param_count;
}

const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i) {
    if (!nsi || method_i >= nsi->method_count) return 
# 924 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                     ((void *)0)
# 924 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                         ;
    if (param_i >= nsi->methods[method_i].param_count) return 
# 925 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                                                             ((void *)0)
# 925 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                                                                 ;
    return &nsi->methods[method_i].params[param_i];
}

static int cstr_eq(const char *a, const char *b) {
    if (a == 
# 930 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
            ((void *)0) 
# 930 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                 && b == 
# 930 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                         ((void *)0)
# 930 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                             ) return 1;
    if (a == 
# 931 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
            ((void *)0) 
# 931 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                 || b == 
# 931 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                         ((void *)0)
# 931 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                             ) return 0;
    return strcmp(a, b) == 0;
}

static const NlNsiMethod *find_method(const NlNsi *nsi, const char *id) {
    size_t i;
    if (!nsi || !id) return 
# 937 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                           ((void *)0)
# 937 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                               ;
    for (i = 0; i < nsi->method_count; i++) {
        if (cstr_eq(nsi->methods[i].id, id)) return &nsi->methods[i];
    }
    return 
# 941 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          ((void *)0)
# 941 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id) {
    return find_method(nsi, id);
}

static const NlNsiParam *find_param(const NlNsiMethod *m, const char *id) {
    size_t i;
    if (!m || !id) return 
# 950 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                         ((void *)0)
# 950 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                             ;
    for (i = 0; i < m->param_count; i++) {
        if (cstr_eq(m->params[i].id, id)) return &m->params[i];
    }
    return 
# 954 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          ((void *)0)
# 954 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static const NlNsiType *find_type(const NlNsi *nsi, const char *id) {
    size_t i;
    if (!nsi || !id) return 
# 959 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                           ((void *)0)
# 959 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                               ;
    for (i = 0; i < nsi->type_count; i++) {
        if (cstr_eq(nsi->types[i].id, id)) return &nsi->types[i];
    }
    return 
# 963 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          ((void *)0)
# 963 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static const NlNsiMember *find_member(const NlNsiType *t, const char *id) {
    size_t i;
    if (!t || !id) return 
# 968 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                         ((void *)0)
# 968 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                             ;
    for (i = 0; i < t->member_count; i++) {
        if (cstr_eq(t->members[i].id, id)) return &t->members[i];
    }
    return 
# 972 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          ((void *)0)
# 972 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static const NlNsiError *find_error(const NlNsi *nsi, const char *id) {
    size_t i;
    if (!nsi || !id) return 
# 977 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
                           ((void *)0)
# 977 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
                               ;
    for (i = 0; i < nsi->error_count; i++) {
        if (cstr_eq(nsi->errors[i].id, id)) return &nsi->errors[i];
    }
    return 
# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c" 3 4
          ((void *)0)
# 981 "/home/jkh/.worktrees/nanolang/bootstrap-allocation-policy-20261121/modules/file_source_inputs/../../src/nsi.c"
              ;
}

static int param_contract_eq(const NlNsiParam *a, const NlNsiParam *b) {
    if (!a || !b) return 0;
    return cstr_eq(a->type_id, b->type_id) &&
           a->direction == b->direction &&
           a->ownership == b->ownership &&
           a->lifetime == b->lifetime &&
           a->mutability == b->mutability &&
           a->optional == b->optional &&
           a->streaming == b->streaming;
}

static int type_payload_eq(const NlNsiType *a, const NlNsiType *b) {
    if (!a || !b) return 0;
    if (a->kind != b->kind) return 0;
    if (!cstr_eq(a->element_id, b->element_id)) return 0;
    if (!cstr_eq(a->method_id, b->method_id)) return 0;
    if (!cstr_eq(a->result_id, b->result_id)) return 0;
    return 1;
}

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer) {
    size_t i;
    size_t j;
    if (!older || !newer) return NL_NSI_COMPAT_BREAKING;
    if (!cstr_eq(older->iface.id, newer->iface.id)) return NL_NSI_COMPAT_BREAKING;
    if (older->version != newer->version) return NL_NSI_COMPAT_BREAKING;

    for (i = 0; i < older->method_count; i++) {
        const NlNsiMethod *om = &older->methods[i];
        const NlNsiMethod *nm = find_method(newer, om->id);
        if (!nm) return NL_NSI_COMPAT_BREAKING;
        if (om->idempotent && !nm->idempotent) return NL_NSI_COMPAT_BREAKING;
        for (j = 0; j < om->param_count; j++) {
            const NlNsiParam *op = &om->params[j];
            const NlNsiParam *np = find_param(nm, op->id);
            if (!np || !param_contract_eq(op, np)) return NL_NSI_COMPAT_BREAKING;
        }
        for (j = 0; j < nm->param_count; j++) {
            if (find_param(om, nm->params[j].id)) continue;
            if (!nm->params[j].optional || nm->params[j].direction != NL_NSI_DIR_IN)
                return NL_NSI_COMPAT_BREAKING;
        }
    }

    for (i = 0; i < older->type_count; i++) {
        const NlNsiType *ot = &older->types[i];
        const NlNsiType *nt = find_type(newer, ot->id);
        if (!nt || !type_payload_eq(ot, nt)) return NL_NSI_COMPAT_BREAKING;
        for (j = 0; j < ot->member_count; j++) {
            const NlNsiMember *omem = &ot->members[j];
            const NlNsiMember *nmem = find_member(nt, omem->id);
            if (!nmem || !cstr_eq(omem->type_id, nmem->type_id))
                return NL_NSI_COMPAT_BREAKING;
        }
        if (ot->kind == NL_NSI_TYPE_RECORD && nt->member_count != ot->member_count)
            return NL_NSI_COMPAT_BREAKING;
    }

    for (i = 0; i < older->error_count; i++) {
        const NlNsiError *oe = &older->errors[i];
        const NlNsiError *ne = find_error(newer, oe->id);
        if (!ne || !cstr_eq(oe->version, ne->version)) return NL_NSI_COMPAT_BREAKING;
    }

    return NL_NSI_COMPAT_OK;
}
