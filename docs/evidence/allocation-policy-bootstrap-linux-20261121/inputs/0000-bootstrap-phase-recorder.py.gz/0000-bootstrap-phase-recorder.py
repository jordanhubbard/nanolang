#!/usr/bin/env python3
import datetime,fcntl,json,os,socket,sys,time
path=os.environ['NANO_BOOTSTRAP_PHASE_FILE']
record=dict(phase=sys.argv[1],monotonic_ns=time.monotonic_ns(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=socket.gethostname(),pid=os.getpid(),parent_pid=os.getppid())
with open(path,'a') as output:
 fcntl.flock(output,fcntl.LOCK_EX);output.write(json.dumps(record,separators=(',',':'))+'\n');output.flush()
