from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tempfile
from tests.nanolang_translator_routes import checked
from tests.test_nanolang_translator_service_module import corpus
ROOT=Path.cwd();HOST='darwin' if sys.platform=='darwin' else 'linux';BASE=ROOT/'.test_output'
def digest(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
 data=(json.dumps(value,separators=(',',':'))+'\n').encode();(BASE/name).write_bytes(gzip.compress(data,mtime=0))
def observe(*args):
 p=subprocess.run(args,capture_output=True,text=True);return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
if sys.argv[1]=='--corpus':
 cases=corpus();reports=[]
 with tempfile.TemporaryDirectory(prefix='shared-service-evidence-') as directory:
  paths=[]
  for i,(_,data,_) in enumerate(cases):
   path=Path(directory)/str(i);path.write_bytes(data);paths.append(path)
  for i in range(0,len(paths),32):reports+=checked(['obj/nvm2c_service_nominal_reference','0',*paths[i:i+32]],timeout=600).splitlines()
 assert len(cases)==len(reports)
 records=[]
 for (name,data,expected),report in zip(cases,reports):
  if expected is not None:assert int(report.split('|')[0])==expected,(name,expected,report)
  records.append(dict(name=name,bytes_hex=data.hex(),sha256=digest(data),explicit_status=expected,actual_c_report=report))
 save('service-module-'+HOST+'-corpus.json.gz',records)
 print('I retained',len(records),'complete carriers/reports;',sum(r['explicit_status'] is not None for r in records),'explicit statuses.')
elif sys.argv[1]=='--products':
 log=(BASE/('service-module-'+HOST+'-first.log')).read_text();assert '\nOK\n' in log
 roots=[s.split('I retain actual service source products at ',1)[1] for s in log.splitlines() if 'I retain actual service source products at ' in s];assert len(roots)==2
 root=Path(roots[-1]);records=json.loads((root/'records.json').read_text());assert len(records)==8
 files={str(p.relative_to(root)):dict(sha256=digest(p.read_bytes()),bytes_hex=p.read_bytes().hex()) for p in root.rglob('*') if p.is_file()}
 for row in records:
  for key in ('module','carrier'):assert files[row[key]]['sha256']==row[key+'_sha256']
  for name,h in row['sources'].items():assert files[name]['sha256']==h
 save('service-module-'+HOST+'-products.json.gz',dict(records=records,files=files,metadata_only=True))
 print('I retained eight actual source/module/carrier products and',len(files),'files.')
else:
 sources=subprocess.check_output(['git','ls-files','src_nano/nvm2c','src/nanoisa','src/nsi*','Makefile.gnu','tests/nvm2c_service*','tests/test_nanolang_translator_service*','tests/test_nanolang_translator_ownership.py','tests/fixtures/nsi_*_plan.json','tests/nanolang_translator_routes.py','tests/native_process.py','tests/test_service_drivers.py','tests/test_socket_service_source.py','tests/test_websocket_service_drivers.py','tests/test_mixed_websocket_source.py','tests/test_service_bindings_module.py','tests/nanoisa/test_service_bindings_module.c','tests/nanoisa/test_service_mixed_boundaries.c','scripts/generate_nvm2c_service_catalog.py'],text=True).splitlines()
 tools=['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nanoisa','bin/nvm2c','bin/nano_aot_runtime.o','obj/nvm2c_service_catalog_reference','obj/nvm2c_service_nominal_reference','obj/nvm2c_service_module_reference_asan','.test_output/ownership-source-final']
 if HOST=='linux':tools+=['bin/nano_as_capture.so']
 hashes={s:digest(Path(s).read_bytes()) for s in tools}
 old=json.loads(gzip.decompress(Path('docs/evidence/nanolang-service-nominal-20261121/inputs/.test_output_service-nominal-'+HOST+'-manifest.json.gz').read_bytes()))
 unchanged={s:h for s,h in hashes.items() if s in old['post_run_tool_sha256'] and s!='obj/nvm2c_service_nominal_reference'}
 assert all(h==old['post_run_tool_sha256'][s] for s,h in unchanged.items())
 result=dict(commit=observe('git','rev-parse','HEAD'),status=observe('git','status','--short'),uname=observe('uname','-a'),cc=observe('cc','--version'),python=sys.version,environment={k:os.environ.get(k) for k in ('NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANO_AS_CAPTURE_HELPER','CC','LDFLAGS','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS')},source_sha256={s:digest(Path(s).read_bytes()) for s in sources},post_run_tool_sha256=hashes,unchanged_prior_tools=unchanged,reused_real_compiler_matches_previous_receipt=True,limits=['I qualify the shared normal narrow NvmModule service boundary, not the v2 rich-table adapter, whole-module conversion or executable admission.','C allocation/pointer failures retain their original C test scope; pure immutable NanoLang values do not model arbitrary pointer graphs.','Generated C fixtures are ASan/UBSan instrumented and link an ordinary AOT runtime. I instrument actual nominal/raw/shared/classification providers in the C oracle.','Actual producer modules retain selected shadows and metadata transport; this fixture does not execute network lifecycles.','My available development NanoLang compiler is genuine and hash-equal to the previous paired receipt. Installed/no-C-seed/raw fixed-point acceptance remains open.'])
 (BASE/('service-module-'+HOST+'-manifest.json')).write_text(json.dumps(result,indent=2)+'\n');print('I recorded',len(sources),'source hashes and',len(tools),'tools.')
