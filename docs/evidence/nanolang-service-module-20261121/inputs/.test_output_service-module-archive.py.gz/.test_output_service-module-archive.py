from pathlib import Path
import gzip,hashlib,json
root=Path('docs/evidence/nanolang-service-module-20261121');out=root/'inputs';out.mkdir(parents=True,exist_ok=True)
files=[Path(p) for p in ['Makefile.gnu','docs/NANOLANG_NANOISA_C_TRANSLATOR.md','src_nano/nvm2c/service_module.nano','tests/nvm2c_service_nominal_driver.nano','tests/nvm2c_service_nominal_reference.c','tests/test_nanolang_translator_service_module.py','tests/test_nanolang_translator_service_nominal.py','tests/nanolang_translator_routes.py','tests/native_process.py','tests/test_service_bindings_module.py','tests/nanoisa/test_service_bindings_module.c','tests/nanoisa/test_service_mixed_boundaries.c','scripts/embed_managed_runtime.py','obj/nanoisa/managed_runtime_ir.json']]
files+=[p for p in Path('src/nanoisa').glob('service*') if p.suffix in ('.c','.h','.inc')]
files+=[p for p in Path('tests/nanoisa').glob('test_*nominal.c')]
files+=[Path('tests/nanoisa/test_service_bindings.c')]
files+=[p for p in Path('.test_output').glob('service-module-*') if p.is_file() and p.suffix in ('.log','.py','.json','.gz','.nano','.c')]
records=[]
for path in sorted(set(files)):
 data=path.read_bytes();name=str(path).replace('/','_')
 if path.suffix=='.gz':data=gzip.decompress(data);name=name[:-3]
 blob=gzip.compress(data,mtime=0);target='inputs/'+name+'.gz';(root/target).write_bytes(blob)
 records.append(dict(path=str(path),artifact=target,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),compressed_sha256=hashlib.sha256(blob).hexdigest(),compressed_bytes=len(blob)))
(root/'manifest.json').write_text(json.dumps(dict(code_commit='d7670ef3f',files=records),indent=2)+'\n')
print('I retained',len(records),'hash-bound inputs;',sum(r['compressed_bytes'] for r in records),'compressed bytes.')
