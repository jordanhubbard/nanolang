from pathlib import Path
import os,shlex,subprocess,sys
host='darwin' if sys.platform=='darwin' else 'linux'
name='service-module-darwin-corrected-original.log' if host=='darwin' else 'service-module-linux-original.log'
lines=Path('.test_output',name).read_text().splitlines()
line=next(s for s in reversed(lines) if 'SERVICE_MODULE_OBJECTS=' in s and 'tests.test_multi_nominal' in s)
args=shlex.split(line);env=dict(os.environ)
while args and '=' in args[0]:
 key,value=args.pop(0).split('=',1);env[key]=value
objects=shlex.split(env['SERVICE_MODULE_OBJECTS'])
archives=list(dict.fromkeys(x for x in objects if x.endswith('.a')))
objects=[x for x in objects if not x.endswith('.a')]
objects.append('obj/nanoisa/nvm2llvm.o')
env['SERVICE_MODULE_OBJECTS']=shlex.join(objects)
env['SERVICE_MODULE_LDFLAGS']=shlex.join(archives+shlex.split(env['SERVICE_MODULE_LDFLAGS']))
command=[sys.executable,'-m','unittest','-v','tests.test_service_bindings_module']
print('I select the actual LLVM refusal provider and put COMMON archives after instrumented users, retaining every ordinary object/link flag; I run all three unchanged shared-module methods.',flush=True)
subprocess.run(command,env=env,check=True)
