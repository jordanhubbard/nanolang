from pathlib import Path
import os,shlex,subprocess,sys
host='darwin' if sys.platform=='darwin' else 'linux'
name='service-module-darwin-corrected-original.log' if host=='darwin' else 'service-module-linux-original.log'
lines=Path('.test_output',name).read_text().splitlines()
line=next(s for s in reversed(lines) if 'SERVICE_MODULE_OBJECTS=' in s and 'tests.test_multi_nominal' in s)
args=shlex.split(line);env=dict(os.environ)
while args and '=' in args[0]:
 key,value=args.pop(0).split('=',1);env[key]=value
command=[sys.executable,'-m','unittest','-v','tests.test_service_bindings_module.ServiceModule.test_allocation_failures']
print('I preserve the original Make-provided object/link closure and run the unchanged shared-module allocation method.',flush=True)
subprocess.run(command,env=env,check=True)
