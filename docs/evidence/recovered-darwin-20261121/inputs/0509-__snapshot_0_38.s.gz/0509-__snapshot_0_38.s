	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_vm_dispatch_function_free      ; -- Begin function vm_dispatch_function_free
	.p2align	2
_vm_dispatch_function_free:             ; @vm_dispatch_function_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	b	LBB0_3
LBB0_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #24                         ; =0x18
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB0_3
LBB0_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_module_free        ; -- Begin function vm_dispatch_module_free
	.p2align	2
_vm_dispatch_module_free:               ; @vm_dispatch_module_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_7
LBB1_2:
	str	wzr, [sp, #4]
	b	LBB1_3
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB1_6
	b	LBB1_4
LBB1_4:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp, #8]
	ldr	x10, [x8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_vm_dispatch_function_free
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB1_3
LBB1_6:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB1_7
LBB1_7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_profile_none       ; -- Begin function vm_dispatch_profile_none
	.p2align	2
_vm_dispatch_profile_none:              ; @vm_dispatch_profile_none
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	wzr, [sp, #15]
	ldrb	w0, [sp, #15]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_profile_all        ; -- Begin function vm_dispatch_profile_all
	.p2align	2
_vm_dispatch_profile_all:               ; @vm_dispatch_profile_all
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	wzr, [sp, #15]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #15]
	ldrb	w0, [sp, #15]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_build_function     ; -- Begin function vm_dispatch_build_function
	.p2align	2
_vm_dispatch_build_function:            ; @vm_dispatch_build_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	sturb	w8, [x29, #-2]
	stur	x0, [x29, #-16]
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-32]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_2:
	ldur	x0, [x29, #-24]
	mov	w1, #0                          ; =0x0
	mov	x2, #24                         ; =0x18
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB4_4
	b	LBB4_3
LBB4_3:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #12]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	add	x0, x8, #1
	mov	x1, #4                          ; =0x4
	bl	_calloc
	ldur	x8, [x29, #-24]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB4_6
	b	LBB4_5
LBB4_5:
	ldur	x0, [x29, #-24]
	bl	_vm_dispatch_function_free
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	subs	w8, w8, #0
	b.ls	LBB4_10
	b	LBB4_7
LBB4_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	mov	x0, x8
	mov	x1, #120                        ; =0x78
	bl	_calloc
	ldur	x8, [x29, #-24]
	str	x0, [x8]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	cbnz	x8, LBB4_9
	b	LBB4_8
LBB4_8:
	ldur	x0, [x29, #-24]
	bl	_vm_dispatch_function_free
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_9:
	b	LBB4_10
LBB4_10:
	stur	wzr, [x29, #-36]
	b	LBB4_11
LBB4_11:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB4_16
	b	LBB4_12
LBB4_12:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-24]
	ldr	x10, [x8]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]
	ldr	x0, [sp, #56]
	ldur	x8, [x29, #-48]
	add	x1, x8, #40
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x9, [sp, #56]
	ldur	x8, [x29, #-48]
	ldr	q0, [x8, #16]
	str	q0, [x9, #64]
	ldr	x8, [x8, #32]
	str	x8, [x9, #80]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	ldr	x9, [sp, #56]
	str	w8, [x9, #88]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #56]
	str	w8, [x9, #92]
	ldr	x9, [sp, #56]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #100]
	ldr	x9, [sp, #56]
	str	w8, [x9, #104]
	ldr	x9, [sp, #56]
	str	w8, [x9, #108]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB4_14
	b	LBB4_13
LBB4_13:
	ldur	x0, [x29, #-24]
	bl	_vm_dispatch_function_free
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-48]
	ldr	w2, [x8]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_14:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #16]
	ldur	x10, [x29, #-48]
	ldr	w10, [x10]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB4_11
LBB4_16:
	str	wzr, [sp, #52]
	b	LBB4_17
LBB4_17:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB4_35
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldur	x8, [x29, #-24]
	ldr	x10, [x8]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #40]
	strb	w8, [sp, #31]
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	w1, [x8, #4]
	bl	_dispatch_index_at
	ldr	x8, [sp, #32]
	str	w0, [x8, #96]
	ldrb	w0, [sp, #31]
	bl	_dispatch_is_branch
	tbz	w0, #0, LBB4_30
	b	LBB4_19
LBB4_19:                                ;   in Loop: Header=BB4_17 Depth=1
	ldrb	w8, [sp, #31]
	subs	w8, w8, #107
	b.eq	LBB4_21
	b	LBB4_20
LBB4_20:                                ;   in Loop: Header=BB4_17 Depth=1
	ldrb	w8, [sp, #31]
	subs	w8, w8, #165
	b.ne	LBB4_22
	b	LBB4_21
LBB4_21:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #56]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB4_23
LBB4_22:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #48]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB4_23
LBB4_23:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	w9, [sp]                        ; 4-byte Folded Reload
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	str	x8, [sp, #16]
	ldr	x8, [sp, #40]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #16]
	add	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	tbnz	x8, #63, LBB4_25
	b	LBB4_24
LBB4_24:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.le	LBB4_26
	b	LBB4_25
LBB4_25:
	ldur	x0, [x29, #-24]
	bl	_vm_dispatch_function_free
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #40]
	ldr	w2, [x8]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_26:                                ;   in Loop: Header=BB4_17 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #8]
	mov	x1, x8
	bl	_dispatch_index_at
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	adds	w8, w8, #1
	b.ne	LBB4_29
	b	LBB4_27
LBB4_27:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #8]
                                        ; kill: def $w8 killed $w8 killed $x8
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.eq	LBB4_29
	b	LBB4_28
LBB4_28:
	ldur	x0, [x29, #-24]
	bl	_vm_dispatch_function_free
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #40]
	ldr	w2, [x8]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_29:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #32]
	str	w8, [x9, #100]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #32]
	str	w8, [x9, #104]
	b	LBB4_33
LBB4_30:                                ;   in Loop: Header=BB4_17 Depth=1
	ldrb	w0, [sp, #31]
	bl	_dispatch_is_direct_call
	tbz	w0, #0, LBB4_32
	b	LBB4_31
LBB4_31:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #32]
	str	w8, [x9, #108]
	b	LBB4_32
LBB4_32:                                ;   in Loop: Header=BB4_17 Depth=1
	b	LBB4_33
LBB4_33:                                ;   in Loop: Header=BB4_17 Depth=1
	b	LBB4_34
LBB4_34:                                ;   in Loop: Header=BB4_17 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB4_17
LBB4_35:
	ldur	x0, [x29, #-24]
	ldurb	w8, [x29, #-2]
	mov	x1, x8
	bl	_dispatch_apply_fusions
	ldur	x8, [x29, #-32]
	cbz	x8, LBB4_37
	b	LBB4_36
LBB4_36:
	ldur	x8, [x29, #-32]
	strb	wzr, [x8]
	b	LBB4_37
LBB4_37:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB4_38
LBB4_38:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dispatch_fail
_dispatch_fail:                         ; @dispatch_fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	w2, [sp, #12]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldur	x0, [x29, #-8]
	ldr	x4, [sp, #16]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___snprintf_chk
	b	LBB5_2
LBB5_2:
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dispatch_index_at
_dispatch_index_at:                     ; @dispatch_index_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_3
	b	LBB6_1
LBB6_1:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB6_3
	b	LBB6_2
LBB6_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB6_4
	b	LBB6_3
LBB6_3:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB6_8
LBB6_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	cbz	w8, LBB6_6
	b	LBB6_5
LBB6_5:
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ls	LBB6_7
	b	LBB6_6
LBB6_6:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB6_8
LBB6_7:
	ldr	w8, [sp, #8]
	subs	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB6_8
LBB6_8:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dispatch_is_branch
_dispatch_is_branch:                    ; @dispatch_is_branch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #56
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB7_5
	b	LBB7_1
LBB7_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #57
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB7_5
	b	LBB7_2
LBB7_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #58
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB7_5
	b	LBB7_3
LBB7_3:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #107
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB7_5
	b	LBB7_4
LBB7_4:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #165
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB7_5
LBB7_5:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dispatch_is_direct_call
_dispatch_is_direct_call:               ; @dispatch_is_direct_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #59
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB8_2
	b	LBB8_1
LBB8_1:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #51
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB8_2
LBB8_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dispatch_apply_fusions
_dispatch_apply_fusions:                ; @dispatch_apply_fusions
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	mov	x8, x1
	strb	w8, [sp, #47]
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	subs	w8, w8, #2
	b.hs	LBB9_3
	b	LBB9_2
LBB9_2:
	b	LBB9_16
LBB9_3:
	str	wzr, [sp, #28]
	b	LBB9_4
LBB9_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB9_16
	b	LBB9_5
LBB9_5:                                 ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #32]
	ldr	x10, [x8]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #32]
	ldr	x10, [x8]
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	mov	w9, #120                        ; =0x78
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #112]
	cbz	w8, LBB9_7
	b	LBB9_6
LBB9_6:                                 ;   in Loop: Header=BB9_4 Depth=1
	b	LBB9_15
LBB9_7:                                 ;   in Loop: Header=BB9_4 Depth=1
	ldrb	w8, [sp, #47]
	tbz	w8, #0, LBB9_14
	b	LBB9_8
LBB9_8:                                 ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.ne	LBB9_14
	b	LBB9_9
LBB9_9:                                 ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #252
	b.ne	LBB9_14
	b	LBB9_10
LBB9_10:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #92]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #88]
	subs	w8, w8, w9
	b.ne	LBB9_14
	b	LBB9_11
LBB9_11:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #100]
	adds	w8, w8, #1
	b.ne	LBB9_14
	b	LBB9_12
LBB9_12:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #108]
	adds	w8, w8, #1
	b.ne	LBB9_14
	b	LBB9_13
LBB9_13:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #112]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #114]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #92]
	ldr	x9, [sp, #16]
	str	w8, [x9, #92]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #96]
	ldr	x9, [sp, #16]
	str	w8, [x9, #96]
	b	LBB9_14
LBB9_14:                                ;   in Loop: Header=BB9_4 Depth=1
	b	LBB9_15
LBB9_15:                                ;   in Loop: Header=BB9_4 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB9_4
LBB9_16:
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_build_module       ; -- Begin function vm_dispatch_build_module
	.p2align	2
_vm_dispatch_build_module:              ; @vm_dispatch_build_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x1
	sturb	w8, [x29, #-2]
	stur	x0, [x29, #-16]
	str	x2, [sp, #24]
	str	x3, [sp, #16]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_2:
	ldr	x0, [sp, #24]
	mov	w1, #0                          ; =0x0
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB10_4
	b	LBB10_3
LBB10_3:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.6@PAGE
	add	x1, x1, l_.str.6@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	cbnz	w8, LBB10_8
	b	LBB10_5
LBB10_5:
	ldr	x8, [sp, #16]
	cbz	x8, LBB10_7
	b	LBB10_6
LBB10_6:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	b	LBB10_7
LBB10_7:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_8:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	mov	x0, x8
	mov	x1, #24                         ; =0x18
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB10_10
	b	LBB10_9
LBB10_9:
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	mov	w2, #0                          ; =0x0
	bl	_dispatch_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_10:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #24]
	str	w8, [x9, #8]
	str	wzr, [sp, #12]
	b	LBB10_11
LBB10_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB10_16
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #5
	ldr	x8, [sp, #24]
	ldr	x10, [x8]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x2, w8, w9, x10
	ldr	x3, [sp, #16]
	ldurb	w8, [x29, #-2]
	mov	x1, x8
	bl	_vm_dispatch_build_function
	tbnz	w0, #0, LBB10_14
	b	LBB10_13
LBB10_13:
	ldr	x0, [sp, #24]
	bl	_vm_dispatch_module_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_14:                               ;   in Loop: Header=BB10_11 Depth=1
	b	LBB10_15
LBB10_15:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB10_11
LBB10_16:
	ldr	x8, [sp, #16]
	cbz	x8, LBB10_18
	b	LBB10_17
LBB10_17:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	b	LBB10_18
LBB10_18:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_19
LBB10_19:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_seek               ; -- Begin function vm_dispatch_seek
	.p2align	2
_vm_dispatch_seek:                      ; @vm_dispatch_seek
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	w2, [sp, #4]
	ldr	x8, [sp, #16]
	cbz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB11_3
	b	LBB11_2
LBB11_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_6
LBB11_3:
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_dispatch_index_at
	str	w0, [sp]
	ldr	w8, [sp]
	adds	w8, w8, #1
	b.ne	LBB11_5
	b	LBB11_4
LBB11_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_6
LBB11_5:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	ldr	w8, [sp]
	ldr	x9, [sp, #16]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_6
LBB11_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_current            ; -- Begin function vm_dispatch_current
	.p2align	2
_vm_dispatch_current:                   ; @vm_dispatch_current
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB12_3
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB12_3
	b	LBB12_2
LBB12_2:
	ldr	x8, [sp]
	ldr	w8, [x8, #8]
	ldr	x9, [sp]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB12_4
	b	LBB12_3
LBB12_3:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	LBB12_5
LBB12_4:
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x10, [x8]
	ldr	x8, [sp]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	b	LBB12_5
LBB12_5:
	ldr	x0, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_dispatch_advance            ; -- Begin function vm_dispatch_advance
	.p2align	2
_vm_dispatch_advance:                   ; @vm_dispatch_advance
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_vm_dispatch_current
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_6
LBB13_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #96]
	str	w8, [sp, #4]
	ldr	w8, [sp, #4]
	adds	w8, w8, #1
	b.eq	LBB13_4
	b	LBB13_3
LBB13_3:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB13_5
	b	LBB13_4
LBB13_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #16]
	str	w8, [x9, #8]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB13_6
LBB13_5:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #16]
	str	w8, [x9, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x10, [x8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-8]
	b	LBB13_6
LBB13_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"verified IR is NULL"

l_.str.1:                               ; @.str.1
	.asciz	"dispatch offset map allocation failed"

l_.str.2:                               ; @.str.2
	.asciz	"dispatch instruction allocation failed"

l_.str.3:                               ; @.str.3
	.asciz	"dispatch instruction lies outside code at offset %u"

l_.str.4:                               ; @.str.4
	.asciz	"dispatch branch target out of range at offset %u"

l_.str.5:                               ; @.str.5
	.asciz	"dispatch branch misses an instruction boundary at offset %u"

l_.str.6:                               ; @.str.6
	.asciz	"verified module is NULL"

l_.str.7:                               ; @.str.7
	.asciz	"dispatch module allocation failed"

.subsections_via_symbols
