	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_local_names_validate       ; -- Begin function nvm_local_names_validate
	.p2align	2
_nvm_local_names_validate:              ; @nvm_local_names_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w8, #0                          ; =0x0
	and	w1, w8, #0x1
	bl	_names_validate
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function names_validate
_names_validate:                        ; @names_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB1_4
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB1_3
	b	LBB1_2
LBB1_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbnz	w0, #0, LBB1_5
	b	LBB1_4
LBB1_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB1_24
LBB1_5:
	sturb	wzr, [x29, #-18]
	stur	wzr, [x29, #-24]
	b	LBB1_6
LBB1_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_13 Depth 2
	ldur	w8, [x29, #-24]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB1_23
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	ldurb	w8, [x29, #-17]
	and	w2, w8, #0x1
	bl	_named
	tbnz	w0, #0, LBB1_9
	b	LBB1_8
LBB1_8:                                 ;   in Loop: Header=BB1_6 Depth=1
	b	LBB1_22
LBB1_9:                                 ;   in Loop: Header=BB1_6 Depth=1
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-18]
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #40
	bl	_decode
	tbz	w0, #0, LBB1_11
	b	LBB1_10
LBB1_10:                                ;   in Loop: Header=BB1_6 Depth=1
	ldur	x0, [x29, #-16]
	ldurb	w8, [x29, #-17]
	add	x1, sp, #40
	and	w2, w8, #0x1
	bl	_valid
	tbnz	w0, #0, LBB1_12
	b	LBB1_11
LBB1_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB1_24
LBB1_12:                                ;   in Loop: Header=BB1_6 Depth=1
	str	wzr, [sp, #36]
	b	LBB1_13
LBB1_13:                                ;   Parent Loop BB1_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	b.hs	LBB1_21
	b	LBB1_14
LBB1_14:                                ;   in Loop: Header=BB1_13 Depth=2
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	ldurb	w8, [x29, #-17]
	and	w2, w8, #0x1
	bl	_named
	tbnz	w0, #0, LBB1_16
	b	LBB1_15
LBB1_15:                                ;   in Loop: Header=BB1_13 Depth=2
	b	LBB1_20
LBB1_16:                                ;   in Loop: Header=BB1_13 Depth=2
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	mov	x2, sp
	bl	_decode
	tbz	w0, #0, LBB1_18
	b	LBB1_17
LBB1_17:                                ;   in Loop: Header=BB1_13 Depth=2
	ldurb	w8, [x29, #-17]
	add	x0, sp, #40
	mov	x1, sp
	and	w2, w8, #0x1
	bl	_overlap
	tbz	w0, #0, LBB1_19
	b	LBB1_18
LBB1_18:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB1_24
LBB1_19:                                ;   in Loop: Header=BB1_13 Depth=2
	b	LBB1_20
LBB1_20:                                ;   in Loop: Header=BB1_13 Depth=2
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB1_13
LBB1_21:                                ;   in Loop: Header=BB1_6 Depth=1
	b	LBB1_22
LBB1_22:                                ;   in Loop: Header=BB1_6 Depth=1
	ldur	w8, [x29, #-24]
	add	w8, w8, #1
	stur	w8, [x29, #-24]
	b	LBB1_6
LBB1_23:
	ldurb	w9, [x29, #-18]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	stur	w8, [x29, #-4]
	b	LBB1_24
LBB1_24:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_upvalue_names_validate     ; -- Begin function nvm_upvalue_names_validate
	.p2align	2
_nvm_upvalue_names_validate:            ; @nvm_upvalue_names_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_names_validate
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_local_name_at              ; -- Begin function nvm_local_name_at
	.p2align	2
_nvm_local_name_at:                     ; @nvm_local_name_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	w3, [sp, #12]
	str	x4, [sp]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	w3, [sp, #12]
	ldr	x4, [sp]
	mov	w8, #0                          ; =0x0
	and	w5, w8, #0x1
	bl	_name_at
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function name_at
_name_at:                               ; @name_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	stur	w3, [x29, #-28]
	stur	x4, [x29, #-40]
	sturb	w5, [x29, #-41]
	ldur	x0, [x29, #-16]
	ldurb	w8, [x29, #-41]
	and	w1, w8, #0x1
	bl	_names_validate
	str	w0, [sp, #48]
	ldr	w8, [sp, #48]
	subs	w8, w8, #1
	b.eq	LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	w8, [sp, #48]
	stur	w8, [x29, #-4]
	b	LBB4_16
LBB4_2:
	str	wzr, [sp, #44]
	b	LBB4_3
LBB4_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB4_15
	b	LBB4_4
LBB4_4:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	ldurb	w8, [x29, #-41]
	and	w2, w8, #0x1
	bl	_named
	tbz	w0, #0, LBB4_13
	b	LBB4_5
LBB4_5:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #8
	bl	_decode
	tbz	w0, #0, LBB4_13
	b	LBB4_6
LBB4_6:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #8]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB4_13
	b	LBB4_7
LBB4_7:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldrh	w8, [sp, #20]
	ldurh	w9, [x29, #-22]
	subs	w8, w8, w9
	b.ne	LBB4_13
	b	LBB4_8
LBB4_8:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #12]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.hi	LBB4_13
	b	LBB4_9
LBB4_9:                                 ;   in Loop: Header=BB4_3 Depth=1
	ldur	w8, [x29, #-28]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.hs	LBB4_13
	b	LBB4_10
LBB4_10:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB4_12
	b	LBB4_11
LBB4_11:
	ldur	x8, [x29, #-40]
	ldur	q0, [sp, #8]
	str	q0, [x8]
	ldur	q0, [sp, #24]
	str	q0, [x8, #16]
	b	LBB4_12
LBB4_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_16
LBB4_13:                                ;   in Loop: Header=BB4_3 Depth=1
	b	LBB4_14
LBB4_14:                                ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB4_3
LBB4_15:
	stur	wzr, [x29, #-4]
	b	LBB4_16
LBB4_16:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_upvalue_name_at            ; -- Begin function nvm_upvalue_name_at
	.p2align	2
_nvm_upvalue_name_at:                   ; @nvm_upvalue_name_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	w3, [sp, #12]
	str	x4, [sp]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	w3, [sp, #12]
	ldr	x4, [sp]
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_name_at
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_local_binding          ; -- Begin function nvm_add_local_binding
	.p2align	2
_nvm_add_local_binding:                 ; @nvm_add_local_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_add_binding
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function add_binding
_add_binding:                           ; @add_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	ldurb	w10, [x29, #-25]
	adrp	x9, _local_key@PAGE
	add	x9, x9, _local_key@PAGEOFF
	adrp	x8, _upvalue_key@PAGE
	add	x8, x8, _upvalue_key@PAGEOFF
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	x8, x8, x9, ne
	stur	x8, [x29, #-40]
	ldur	x0, [x29, #-40]
	bl	_strlen
	stur	x0, [x29, #-48]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB7_4
	b	LBB7_1
LBB7_1:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB7_4
	b	LBB7_2
LBB7_2:
	ldur	x0, [x29, #-16]
	bl	_nvm_metadata_valid
	tbz	w0, #0, LBB7_4
	b	LBB7_3
LBB7_3:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	ldurb	w8, [x29, #-25]
	and	w2, w8, #0x1
	bl	_valid
	tbnz	w0, #0, LBB7_5
	b	LBB7_4
LBB7_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_20
LBB7_5:
	stur	wzr, [x29, #-52]
	b	LBB7_6
LBB7_6:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB7_14
	b	LBB7_7
LBB7_7:                                 ;   in Loop: Header=BB7_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	ldurb	w8, [x29, #-25]
	and	w2, w8, #0x1
	bl	_named
	tbnz	w0, #0, LBB7_9
	b	LBB7_8
LBB7_8:                                 ;   in Loop: Header=BB7_6 Depth=1
	b	LBB7_13
LBB7_9:                                 ;   in Loop: Header=BB7_6 Depth=1
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	add	x2, sp, #40
	bl	_decode
	tbz	w0, #0, LBB7_11
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_6 Depth=1
	ldur	x0, [x29, #-24]
	ldurb	w8, [x29, #-25]
	add	x1, sp, #40
	and	w2, w8, #0x1
	bl	_overlap
	tbz	w0, #0, LBB7_12
	b	LBB7_11
LBB7_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_20
LBB7_12:                                ;   in Loop: Header=BB7_6 Depth=1
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_6 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB7_6
LBB7_14:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #24]
	add	w8, w8, #16
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
	mov	x0, x8
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB7_16
	b	LBB7_15
LBB7_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_20
LBB7_16:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_write_word
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #12]
	ldr	x9, [sp, #24]
	strb	w8, [x9, #4]
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #12]
	asr	w8, w8, #8
	ldr	x9, [sp, #24]
	strb	w8, [x9, #5]
	ldr	x8, [sp, #24]
	strb	wzr, [x8, #7]
	ldr	x8, [sp, #24]
	strb	wzr, [x8, #6]
	ldr	x8, [sp, #24]
	add	x0, x8, #8
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #4]
	bl	_write_word
	ldr	x8, [sp, #24]
	add	x0, x8, #12
	ldur	x8, [x29, #-24]
	ldr	w1, [x8, #8]
	bl	_write_word
	ldr	x8, [sp, #24]
	add	x0, x8, #16
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #24]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-40]
	ldur	x8, [x29, #-48]
	mov	x2, x8
	bl	_nvm_add_string
	str	w0, [sp, #20]
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #24]
	ldr	w2, [sp, #36]
	bl	_nvm_add_string
	str	w0, [sp, #16]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	w8, [sp, #20]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB7_19
	b	LBB7_17
LBB7_17:
	ldr	w8, [sp, #16]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB7_19
	b	LBB7_18
LBB7_18:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #20]
	ldr	w2, [sp, #16]
	bl	_nvm_add_metadata
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_19
LBB7_19:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB7_20
LBB7_20:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_add_upvalue_binding        ; -- Begin function nvm_add_upvalue_binding
	.p2align	2
_nvm_add_upvalue_binding:               ; @nvm_add_upvalue_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_add_binding
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function named
_named:                                 ; @named
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	sturb	w2, [x29, #-17]
	ldurb	w10, [x29, #-17]
	adrp	x9, _local_key@PAGE
	add	x9, x9, _local_key@PAGEOFF
	adrp	x8, _upvalue_key@PAGE
	add	x8, x8, _upvalue_key@PAGEOFF
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	w9, [x8]
	ldur	x8, [x29, #-8]
	ldr	w10, [x8, #248]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB9_3
	b	LBB9_1
LBB9_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	ldr	x10, [sp, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB9_3
	b	LBB9_2
LBB9_2:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB9_3
LBB9_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function decode
_decode:                                ; @decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB10_2
	b	LBB10_1
LBB10_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #16
	b.hi	LBB10_3
	b	LBB10_2
LBB10_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_7
LBB10_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #6]
	cbnz	w8, LBB10_5
	b	LBB10_4
LBB10_4:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #7]
	cbz	w8, LBB10_6
	b	LBB10_5
LBB10_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_7
LBB10_6:
	ldur	x8, [x29, #-32]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [sp, #40]
	bl	_read_word
	str	w0, [sp, #8]
	ldr	x8, [sp, #40]
	add	x0, x8, #8
	bl	_read_word
	str	w0, [sp, #12]
	ldr	x8, [sp, #40]
	add	x0, x8, #12
	bl	_read_word
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	w0, [sp, #16]
	ldr	x9, [sp, #40]
	ldrb	w9, [x9, #4]
	ldr	x10, [sp, #40]
	ldrb	w10, [x10, #5]
	orr	w9, w9, w10, lsl #8
	strh	w9, [sp, #20]
	strh	wzr, [sp, #22]
	ldr	x9, [sp, #40]
	add	x9, x9, #16
	str	x9, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #240]
	ldur	x10, [x29, #-24]
	ldr	w10, [x10, #4]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w9, w9, #16
	str	w9, [sp, #32]
	str	wzr, [sp, #36]
	ldur	q0, [sp, #8]
	str	q0, [x8]
	ldur	q0, [sp, #24]
	str	q0, [x8, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_7
LBB10_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function valid
_valid:                                 ; @valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strb	w2, [sp, #15]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	x8, LBB11_17
	b	LBB11_1
LBB11_1:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #272]
	cbz	w8, LBB11_3
	b	LBB11_2
LBB11_2:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #256]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	x8, LBB11_17
	b	LBB11_3
LBB11_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	x8, LBB11_17
	b	LBB11_4
LBB11_4:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB11_17
	b	LBB11_5
LBB11_5:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #24]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #17
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.hi	LBB11_17
	b	LBB11_6
LBB11_6:
	ldr	x8, [sp, #16]
	ldr	w9, [x8]
	ldur	x8, [x29, #-8]
	ldr	w10, [x8, #272]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.hs	LBB11_17
	b	LBB11_7
LBB11_7:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #12]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldrb	w8, [sp, #15]
	tbz	w8, #0, LBB11_9
	b	LBB11_8
LBB11_8:
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #16]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #18]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB11_10
LBB11_9:
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #16]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB11_10
LBB11_10:
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	ldr	w10, [sp]                       ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ge	LBB11_17
	b	LBB11_11
LBB11_11:
	ldrb	w8, [sp, #15]
	tbz	w8, #0, LBB11_14
	b	LBB11_12
LBB11_12:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #4]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbnz	w8, LBB11_17
	b	LBB11_13
LBB11_13:
	ldr	x8, [sp, #16]
	ldr	w9, [x8, #8]
	ldur	x8, [x29, #-8]
	ldr	x11, [x8, #256]
	ldr	x8, [sp, #16]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB11_17
	b	LBB11_14
LBB11_14:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.hi	LBB11_17
	b	LBB11_15
LBB11_15:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	w1, [x8]
	ldr	x8, [sp, #16]
	ldr	w2, [x8, #4]
	bl	_boundary
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w0, #0, LBB11_17
	b	LBB11_16
LBB11_16:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #16]
	ldr	w1, [x8]
	ldr	x8, [sp, #16]
	ldr	w2, [x8, #8]
	bl	_boundary
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB11_17
LBB11_17:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function overlap
_overlap:                               ; @overlap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	strb	w2, [sp, #23]
	ldrb	w8, [sp, #23]
	tbz	w8, #0, LBB12_4
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #32]
	ldr	w9, [x8]
	ldr	x8, [sp, #24]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB12_3
	b	LBB12_2
LBB12_2:
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #12]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB12_3
LBB12_3:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB12_11
LBB12_4:
	ldr	x8, [sp, #32]
	ldr	w9, [x8]
	ldr	x8, [sp, #24]
	ldr	w10, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB12_10
	b	LBB12_5
LBB12_5:
	ldr	x8, [sp, #32]
	ldrh	w9, [x8, #12]
	ldr	x8, [sp, #24]
	ldrh	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB12_10
	b	LBB12_6
LBB12_6:
	ldr	x8, [sp, #32]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #32]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB12_10
	b	LBB12_7
LBB12_7:
	ldr	x8, [sp, #24]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #24]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB12_10
	b	LBB12_8
LBB12_8:
	ldr	x8, [sp, #32]
	ldr	w9, [x8, #4]
	ldr	x8, [sp, #24]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB12_10
	b	LBB12_9
LBB12_9:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB12_10
LBB12_10:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB12_11
LBB12_11:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_word
_read_word:                             ; @read_word
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function boundary
_boundary:                              ; @boundary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB14_5
	b	LBB14_1
LBB14_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-32]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB14_5
	b	LBB14_2
LBB14_2:
	ldur	w8, [x29, #-24]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hi	LBB14_5
	b	LBB14_3
LBB14_3:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	cbz	w8, LBB14_6
	b	LBB14_4
LBB14_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbnz	x8, LBB14_6
	b	LBB14_5
LBB14_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_13
LBB14_6:
	stur	wzr, [x29, #-36]
	b	LBB14_7
LBB14_7:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	b.hs	LBB14_12
	b	LBB14_8
LBB14_8:                                ;   in Loop: Header=BB14_7 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #8
	bl	_isa_decode
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB14_10
	b	LBB14_9
LBB14_9:                                ;   in Loop: Header=BB14_7 Depth=1
	ldr	w8, [sp, #4]
	ldur	w9, [x29, #-24]
	ldur	w10, [x29, #-36]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB14_11
	b	LBB14_10
LBB14_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_13
LBB14_11:                               ;   in Loop: Header=BB14_7 Depth=1
	ldr	w9, [sp, #4]
	ldur	w8, [x29, #-36]
	add	w8, w8, w9
	stur	w8, [x29, #-36]
	b	LBB14_7
LBB14_12:
	ldur	w8, [x29, #-36]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_13
LBB14_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_word
_write_word:                            ; @write_word
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	str	wzr, [sp]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	subs	w8, w8, #4
	b.hs	LBB15_4
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	w8, [sp, #4]
	ldr	w10, [sp]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	x9, [sp, #8]
	ldr	w10, [sp]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB15_3
LBB15_3:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB15_1
LBB15_4:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
_upvalue_key:                           ; @upvalue_key
	.asciz	"nano.upvalue.v1"

_local_key:                             ; @local_key
	.asciz	"nano.local.v1"

.subsections_via_symbols
