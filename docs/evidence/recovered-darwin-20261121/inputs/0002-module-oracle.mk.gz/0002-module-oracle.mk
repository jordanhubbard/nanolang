print-module-oracle-inputs:
	@echo $(NANOISA_OBJECTS) $(NANOISA_UTF8)
