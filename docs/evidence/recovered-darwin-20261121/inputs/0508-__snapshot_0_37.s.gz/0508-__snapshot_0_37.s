	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_vm_decoded_function_free       ; -- Begin function vm_decoded_function_free
	.p2align	2
_vm_decoded_function_free:              ; @vm_decoded_function_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	b	LBB0_3
LBB0_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #32                         ; =0x20
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB0_3
LBB0_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_decoded_module_free         ; -- Begin function vm_decoded_module_free
	.p2align	2
_vm_decoded_module_free:                ; @vm_decoded_module_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	b	LBB1_7
LBB1_2:
	str	wzr, [sp, #4]
	b	LBB1_3
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB1_6
	b	LBB1_4
LBB1_4:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #5
	bl	_vm_decoded_function_free
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_3 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB1_3
LBB1_6:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_free
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB1_7
LBB1_7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_decoded_function_has_boundary ; -- Begin function vm_decoded_function_has_boundary
	.p2align	2
_vm_decoded_function_has_boundary:      ; @vm_decoded_function_has_boundary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB2_4
	b	LBB2_1
LBB2_1:
	ldr	w9, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.hi	LBB2_4
	b	LBB2_2
LBB2_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB2_4
LBB2_4:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_decode_function             ; -- Begin function vm_decode_function
	.p2align	2
_vm_decode_function:                    ; @vm_decode_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_2:
	ldur	x0, [x29, #-32]
	mov	w1, #0                          ; =0x0
	mov	x2, #32                         ; =0x20
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x8, [x29, #-16]
	cbz	x8, LBB3_4
	b	LBB3_3
LBB3_3:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB3_5
	b	LBB3_4
LBB3_4:
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	mov	w3, #0                          ; =0x0
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_5:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB3_9
	b	LBB3_6
LBB3_6:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-48]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB3_9
	b	LBB3_7
LBB3_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbnz	x8, LBB3_10
	b	LBB3_8
LBB3_8:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	b.ls	LBB3_10
	b	LBB3_9
LBB3_9:
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #8]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_10:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #12]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x1, #1                          ; =0x1
	add	x0, x8, #1
	bl	_calloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #16]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	add	x0, x8, #1
	mov	x1, #4                          ; =0x4
	bl	_calloc
	ldur	x8, [x29, #-32]
	str	x0, [x8, #24]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	cbz	x8, LBB3_12
	b	LBB3_11
LBB3_11:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB3_13
	b	LBB3_12
LBB3_12:
	ldur	x0, [x29, #-32]
	bl	_vm_decoded_function_free
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #8]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_13:
	stur	wzr, [x29, #-52]
	stur	wzr, [x29, #-56]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	b.ls	LBB3_15
	b	LBB3_14
LBB3_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_16
LBB3_15:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_16
LBB3_16:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-64]
	b	LBB3_17
LBB3_17:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-56]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB3_28
	b	LBB3_18
LBB3_18:                                ;   in Loop: Header=BB3_17 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.ne	LBB3_25
	b	LBB3_19
LBB3_19:                                ;   in Loop: Header=BB3_17 Depth=1
	ldur	w8, [x29, #-52]
	cbz	w8, LBB3_21
	b	LBB3_20
LBB3_20:                                ;   in Loop: Header=BB3_17 Depth=1
	ldur	w8, [x29, #-52]
	lsl	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB3_22
LBB3_21:                                ;   in Loop: Header=BB3_17 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB3_22
LBB3_22:                                ;   in Loop: Header=BB3_17 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-68]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldur	w8, [x29, #-68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	bl	_realloc
	str	x0, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB3_24
	b	LBB3_23
LBB3_23:
	ldur	x0, [x29, #-32]
	bl	_vm_decoded_function_free
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-56]
	add	w3, w8, w9
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_24:                                ;   in Loop: Header=BB3_17 Depth=1
	ldr	x8, [sp, #80]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldur	w8, [x29, #-68]
	stur	w8, [x29, #-52]
	b	LBB3_25
LBB3_25:                                ;   in Loop: Header=BB3_17 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldur	x8, [x29, #-64]
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldr	x8, [sp, #72]
	add	x2, x8, #40
	bl	_isa_decode
	str	w0, [sp, #68]
	ldr	w8, [sp, #68]
	cbnz	w8, LBB3_27
	b	LBB3_26
LBB3_26:
	ldur	x0, [x29, #-32]
	bl	_vm_decoded_function_free
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-56]
	add	w3, w8, w9
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_27:                                ;   in Loop: Header=BB3_17 Depth=1
	ldur	w8, [x29, #-56]
	ldr	x9, [sp, #72]
	str	w8, [x9]
	ldur	w8, [x29, #-56]
	ldr	w9, [sp, #68]
	add	w8, w8, w9
	ldr	x9, [sp, #72]
	str	w8, [x9, #4]
	ldr	x9, [sp, #72]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #8]
	ldr	x8, [sp, #72]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #16]
	ldr	x8, [sp, #72]
	str	xzr, [x8, #24]
	ldr	x8, [sp, #72]
	str	wzr, [x8, #32]
	ldr	x8, [sp, #72]
	strb	wzr, [x8, #36]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	add	w8, w8, #1
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-56]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #8]
	add	w8, w8, #1
	str	w8, [x9, #8]
	ldr	w9, [sp, #68]
	ldur	w8, [x29, #-56]
	add	w8, w8, w9
	stur	w8, [x29, #-56]
	b	LBB3_17
LBB3_28:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	str	wzr, [sp, #64]
	b	LBB3_29
LBB3_29:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #64]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB3_57
	b	LBB3_30
LBB3_30:                                ;   in Loop: Header=BB3_29 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8]
	ldr	w8, [sp, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #40]
	strb	w8, [sp, #55]
	ldrb	w8, [sp, #55]
	subs	w8, w8, #56
	b.eq	LBB3_36
	b	LBB3_31
LBB3_31:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #57
	b.eq	LBB3_36
	b	LBB3_32
LBB3_32:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #58
	b.eq	LBB3_36
	b	LBB3_33
LBB3_33:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #107
	b.eq	LBB3_36
	b	LBB3_34
LBB3_34:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #165
	b.eq	LBB3_36
	b	LBB3_35
LBB3_35:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #146
	b.ne	LBB3_49
	b	LBB3_36
LBB3_36:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #107
	b.eq	LBB3_39
	b	LBB3_37
LBB3_37:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #165
	b.eq	LBB3_39
	b	LBB3_38
LBB3_38:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #146
	b.ne	LBB3_40
	b	LBB3_39
LBB3_39:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #56]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB3_41
LBB3_40:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #48]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB3_41
LBB3_41:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #48]
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	tbnz	x8, #63, LBB3_47
	b	LBB3_42
LBB3_42:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.gt	LBB3_47
	b	LBB3_43
LBB3_43:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #146
	b.ne	LBB3_46
	b	LBB3_44
LBB3_44:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB3_47
	b	LBB3_45
LBB3_45:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB3_47
	b	LBB3_46
LBB3_46:                                ;   in Loop: Header=BB3_29 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #40]
	mov	x1, x8
	bl	_vm_decoded_function_has_boundary
	tbnz	w0, #0, LBB3_48
	b	LBB3_47
LBB3_47:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #56]
	ldr	w9, [x9]
	add	w8, w8, w9
	str	w8, [sp, #36]
	ldur	x0, [x29, #-32]
	bl	_vm_decoded_function_free
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldr	w3, [sp, #36]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_48:                                ;   in Loop: Header=BB3_29 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #40]
                                        ; kill: def $w9 killed $w9 killed $x9
	add	w8, w8, w9
	ldr	x9, [sp, #56]
	str	w8, [x9, #8]
	b	LBB3_55
LBB3_49:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #59
	b.eq	LBB3_51
	b	LBB3_50
LBB3_50:                                ;   in Loop: Header=BB3_29 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #51
	b.ne	LBB3_54
	b	LBB3_51
LBB3_51:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #48]
	str	w8, [sp, #32]
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB3_53
	b	LBB3_52
LBB3_52:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #56]
	ldr	w9, [x9]
	add	w8, w8, w9
	str	w8, [sp, #28]
	ldur	x0, [x29, #-32]
	bl	_vm_decoded_function_free
	ldur	x0, [x29, #-40]
	ldur	w2, [x29, #-20]
	ldr	w3, [sp, #28]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_decode_fail
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_53:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	w8, [sp, #32]
	ldr	x9, [sp, #56]
	str	w8, [x9, #8]
	b	LBB3_54
LBB3_54:                                ;   in Loop: Header=BB3_29 Depth=1
	b	LBB3_55
LBB3_55:                                ;   in Loop: Header=BB3_29 Depth=1
	b	LBB3_56
LBB3_56:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB3_29
LBB3_57:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB3_59
	b	LBB3_58
LBB3_58:
	ldur	x8, [x29, #-40]
	strb	wzr, [x8]
	b	LBB3_59
LBB3_59:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_60
LBB3_60:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function decode_fail
_decode_fail:                           ; @decode_fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	str	w3, [sp, #24]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldur	x0, [x29, #-8]
	ldur	x4, [x29, #-16]
	ldur	w8, [x29, #-20]
	mov	x10, x8
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___snprintf_chk
	b	LBB4_2
LBB4_2:
	mov	w8, #0                          ; =0x0
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_decoded_function_at         ; -- Begin function vm_decoded_function_at
	.p2align	2
_vm_decoded_function_at:                ; @vm_decoded_function_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB5_3
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB5_4
	b	LBB5_3
LBB5_3:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB5_7
LBB5_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	cbnz	w8, LBB5_6
	b	LBB5_5
LBB5_5:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB5_7
LBB5_6:
	ldr	x8, [sp, #16]
	ldr	x10, [x8]
	ldr	w8, [sp, #8]
	subs	w8, w8, #1
	mov	w9, #104                        ; =0x68
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	b	LBB5_7
LBB5_7:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_decode_module               ; -- Begin function vm_decode_module
	.p2align	2
_vm_decode_module:                      ; @vm_decode_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_2:
	ldr	x0, [sp, #24]
	mov	w1, #0                          ; =0x0
	mov	x2, #16                         ; =0x10
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB6_6
	b	LBB6_3
LBB6_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_5
	b	LBB6_4
LBB6_4:
	ldr	x0, [sp, #16]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.6@PAGE
	add	x4, x4, l_.str.6@PAGEOFF
	bl	___snprintf_chk
	b	LBB6_5
LBB6_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbnz	w8, LBB6_10
	b	LBB6_7
LBB6_7:
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_9
	b	LBB6_8
LBB6_8:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	b	LBB6_9
LBB6_9:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_10:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	mov	x0, x8
	mov	x1, #32                         ; =0x20
	bl	_calloc
	ldr	x8, [sp, #24]
	str	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	cbnz	x8, LBB6_14
	b	LBB6_11
LBB6_11:
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_13
	b	LBB6_12
LBB6_12:
	ldr	x0, [sp, #16]
	mov	x1, #256                        ; =0x100
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.7@PAGE
	add	x4, x4, l_.str.7@PAGEOFF
	bl	___snprintf_chk
	b	LBB6_13
LBB6_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_14:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	ldr	x9, [sp, #24]
	str	w8, [x9, #8]
	str	wzr, [sp, #12]
	b	LBB6_15
LBB6_15:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB6_20
	b	LBB6_16
LBB6_16:                                ;   in Loop: Header=BB6_15 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #12]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x2, x8, x9, lsl #5
	ldr	x3, [sp, #16]
	bl	_vm_decode_function
	tbnz	w0, #0, LBB6_18
	b	LBB6_17
LBB6_17:
	ldr	x0, [sp, #24]
	bl	_vm_decoded_module_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_18:                                ;   in Loop: Header=BB6_15 Depth=1
	b	LBB6_19
LBB6_19:                                ;   in Loop: Header=BB6_15 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB6_15
LBB6_20:
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_22
	b	LBB6_21
LBB6_21:
	ldr	x8, [sp, #16]
	strb	wzr, [x8]
	b	LBB6_22
LBB6_22:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB6_23
LBB6_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"function index %u is invalid at offset %u"

l_.str.1:                               ; @.str.1
	.asciz	"function[%u] has an invalid code range at offset %u"

l_.str.2:                               ; @.str.2
	.asciz	"function[%u] allocation failed at offset %u"

l_.str.3:                               ; @.str.3
	.asciz	"function[%u] invalid instruction at offset %u"

l_.str.4:                               ; @.str.4
	.asciz	"function[%u] branch targets a non-instruction boundary at offset %u"

l_.str.5:                               ; @.str.5
	.asciz	"function[%u] direct call has an invalid target at offset %u"

l_.str.6:                               ; @.str.6
	.asciz	"module is NULL"

l_.str.7:                               ; @.str.7
	.asciz	"module allocation failed"

.subsections_via_symbols
