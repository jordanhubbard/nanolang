	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_ownership_path             ; -- Begin function nvm_ownership_path
	.p2align	2
_nvm_ownership_path:                    ; @nvm_ownership_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-88]
	stur	w1, [x29, #-92]
	str	x2, [sp, #104]
	strh	w3, [sp, #102]
	str	x4, [sp, #88]
	ldur	x8, [x29, #-88]
	cbz	x8, LBB0_3
	b	LBB0_1
LBB0_1:
	ldur	x8, [x29, #-88]
	ldr	x8, [x8, #296]
	cbz	x8, LBB0_3
	b	LBB0_2
LBB0_2:
	ldur	w8, [x29, #-92]
	adds	w8, w8, #1
	b.ne	LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_4:
	add	x1, sp, #87
	strb	wzr, [sp, #87]
	ldur	x0, [x29, #-88]
	bl	_nvm_ownership_contracts_validate
	str	w0, [sp, #80]
	ldr	w8, [sp, #80]
	cbz	w8, LBB0_6
	b	LBB0_5
LBB0_5:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_6:
	ldur	x8, [x29, #-88]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-88]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #56
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, sp, #52
	bl	_nvm_v2_u32
	str	w0, [sp, #80]
	cbz	w0, LBB0_8
	b	LBB0_7
LBB0_7:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_8:
	ldr	w8, [sp, #52]
	subs	w8, w8, #2
	b.eq	LBB0_11
	b	LBB0_9
LBB0_9:
	ldr	w8, [sp, #52]
	subs	w8, w8, #3
	b.eq	LBB0_11
	b	LBB0_10
LBB0_10:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_11:
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u32
	str	w0, [sp, #80]
	cbnz	w0, LBB0_15
	b	LBB0_12
LBB0_12:
	ldr	w8, [sp, #48]
	mov	x1, x8
	add	x0, sp, #56
	add	x2, sp, #32
	bl	_nvm_v2_take
	str	w0, [sp, #80]
	cbnz	w0, LBB0_15
	b	LBB0_13
LBB0_13:
	add	x0, sp, #56
	bl	_nvm_v2_align4
	str	w0, [sp, #80]
	cbnz	w0, LBB0_15
	b	LBB0_14
LBB0_14:
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	str	w0, [sp, #80]
	cbz	w0, LBB0_16
	b	LBB0_15
LBB0_15:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_16:
	ldr	w8, [sp, #44]
	ldur	x9, [x29, #-88]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB0_18
	b	LBB0_17
LBB0_17:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_18:
	str	wzr, [sp, #28]
	b	LBB0_19
LBB0_19:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.hs	LBB0_29
	b	LBB0_20
LBB0_20:                                ;   in Loop: Header=BB0_19 Depth=1
	add	x0, sp, #56
	add	x1, sp, #26
	bl	_nvm_v2_u16
	str	w0, [sp, #80]
	cbnz	w0, LBB0_22
	b	LBB0_21
LBB0_21:                                ;   in Loop: Header=BB0_19 Depth=1
	add	x0, sp, #56
	add	x1, sp, #24
	bl	_nvm_v2_u16
	str	w0, [sp, #80]
	cbz	w0, LBB0_23
	b	LBB0_22
LBB0_22:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_23:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrh	w8, [sp, #24]
	ldrh	w9, [sp, #26]
	subs	w8, w8, w9
	b.le	LBB0_25
	b	LBB0_24
LBB0_24:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_25:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrh	w8, [sp, #26]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	add	x0, sp, #56
	add	x2, sp, #32
	bl	_nvm_v2_take
	str	w0, [sp, #80]
	cbz	w0, LBB0_27
	b	LBB0_26
LBB0_26:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_27:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_28
LBB0_28:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB0_19
LBB0_29:
	strh	wzr, [sp, #22]
	ldr	w8, [sp, #52]
	subs	w8, w8, #2
	b.ne	LBB0_31
	b	LBB0_30
LBB0_30:
	ldur	w1, [x29, #-92]
	add	x0, sp, #56
	sub	x2, x29, #72
	mov	w3, #32                         ; =0x20
	add	x4, sp, #22
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_paths_read
	str	w0, [sp, #80]
	b	LBB0_32
LBB0_31:
	ldur	w1, [x29, #-92]
	add	x0, sp, #56
	sub	x2, x29, #72
	mov	w3, #32                         ; =0x20
	add	x4, sp, #22
	mov	x5, #0                          ; =0x0
	bl	_extension_suffix_read
	str	w0, [sp, #80]
	b	LBB0_32
LBB0_32:
	ldr	w8, [sp, #80]
	cbz	w8, LBB0_34
	b	LBB0_33
LBB0_33:
	ldr	w8, [sp, #80]
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_34:
	ldr	x8, [sp, #104]
	cbz	x8, LBB0_37
	b	LBB0_35
LBB0_35:
	ldr	x8, [sp, #88]
	cbz	x8, LBB0_37
	b	LBB0_36
LBB0_36:
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #102]
	subs	w8, w8, w9
	b.le	LBB0_38
	b	LBB0_37
LBB0_37:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB0_43
LBB0_38:
	strh	wzr, [sp, #20]
	b	LBB0_39
LBB0_39:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #20]
	ldrh	w9, [sp, #22]
	subs	w8, w8, w9
	b.ge	LBB0_42
	b	LBB0_40
LBB0_40:                                ;   in Loop: Header=BB0_39 Depth=1
	ldrh	w8, [sp, #20]
	mov	x9, x8
	sub	x8, x29, #72
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp, #104]
	ldrh	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB0_41
LBB0_41:                                ;   in Loop: Header=BB0_39 Depth=1
	ldrh	w8, [sp, #20]
	add	w8, w8, #1
	strh	w8, [sp, #20]
	b	LBB0_39
LBB0_42:
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #88]
	strh	w8, [x9]
	stur	wzr, [x29, #-76]
	b	LBB0_43
LBB0_43:
	ldur	w8, [x29, #-76]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_45
	b	LBB0_44
LBB0_44:
	bl	___stack_chk_fail
LBB0_45:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_contracts_validate ; -- Begin function nvm_ownership_contracts_validate
	.p2align	2
_nvm_ownership_contracts_validate:      ; @nvm_ownership_contracts_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB1_3
	b	LBB1_2
LBB1_2:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB1_12
LBB1_3:
	ldur	x8, [x29, #-24]
	strb	wzr, [x8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB1_5
	b	LBB1_4
LBB1_4:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #296]
	mov	w8, #9                          ; =0x9
	mov	w9, #0                          ; =0x0
	subs	x10, x10, #0
	csel	w8, w8, w9, ne
	stur	w8, [x29, #-4]
	b	LBB1_12
LBB1_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB1_8
	b	LBB1_6
LBB1_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbz	w8, LBB1_8
	b	LBB1_7
LBB1_7:
	ldur	x0, [x29, #-16]
	bl	_nvm_retained_layouts_valid
	tbnz	w0, #0, LBB1_9
	b	LBB1_8
LBB1_8:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB1_12
LBB1_9:
	add	x2, sp, #24
	str	xzr, [sp, #24]
	str	xzr, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB1_11
	b	LBB1_10
LBB1_10:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB1_12
LBB1_11:
	ldur	x0, [x29, #-16]
	ldur	x2, [x29, #-24]
	add	x1, sp, #24
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x5, #0                          ; =0x0
	mov	x3, x5
	mov	x4, x5
	bl	_ownership_validate_owned
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	w8, [sp, #20]
	bl	_nvm_v2_layouts_free
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB1_12
LBB1_12:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function paths_read
_paths_read:                            ; @paths_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	str	x0, [sp, #72]
	str	w1, [sp, #68]
	str	x2, [sp, #56]
	strh	w3, [sp, #54]
	str	x4, [sp, #40]
	strb	w5, [sp, #39]
	strh	wzr, [sp, #26]
	ldr	x0, [sp, #72]
	add	x1, sp, #32
	bl	_nvm_v2_u32
	str	w0, [sp, #28]
	cbz	w0, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_2:
	ldr	w8, [sp, #32]
	subs	w8, w8, #256
	b.ls	LBB2_4
	b	LBB2_3
LBB2_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_4:
	str	wzr, [sp, #20]
	b	LBB2_5
LBB2_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_15 Depth 2
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	b.hs	LBB2_28
	b	LBB2_6
LBB2_6:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldr	x0, [sp, #72]
	add	x1, sp, #18
	bl	_nvm_v2_u16
	str	w0, [sp, #28]
	cbnz	w0, LBB2_8
	b	LBB2_7
LBB2_7:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldr	x0, [sp, #72]
	add	x1, sp, #16
	bl	_nvm_v2_u16
	str	w0, [sp, #28]
	cbz	w0, LBB2_9
	b	LBB2_8
LBB2_8:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_9:                                 ;   in Loop: Header=BB2_5 Depth=1
	ldrh	w8, [sp, #16]
	cbz	w8, LBB2_11
	b	LBB2_10
LBB2_10:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_11:                                ;   in Loop: Header=BB2_5 Depth=1
	ldrh	w8, [sp, #18]
	cbz	w8, LBB2_13
	b	LBB2_12
LBB2_12:                                ;   in Loop: Header=BB2_5 Depth=1
	ldrh	w8, [sp, #18]
	subs	w8, w8, #32
	b.ls	LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_14:                                ;   in Loop: Header=BB2_5 Depth=1
	strh	wzr, [sp, #14]
	b	LBB2_15
LBB2_15:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #14]
	ldrh	w9, [sp, #18]
	subs	w8, w8, w9
	b.ge	LBB2_22
	b	LBB2_16
LBB2_16:                                ;   in Loop: Header=BB2_15 Depth=2
	ldr	x0, [sp, #72]
	add	x1, sp, #12
	bl	_nvm_v2_u16
	str	w0, [sp, #28]
	cbz	w0, LBB2_18
	b	LBB2_17
LBB2_17:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_18:                                ;   in Loop: Header=BB2_15 Depth=2
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.ne	LBB2_20
	b	LBB2_19
LBB2_19:                                ;   in Loop: Header=BB2_15 Depth=2
	ldrh	w8, [sp, #12]
	ldrh	w9, [sp, #14]
	mov	x10, x9
	sub	x9, x29, #72
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB2_20
LBB2_20:                                ;   in Loop: Header=BB2_15 Depth=2
	b	LBB2_21
LBB2_21:                                ;   in Loop: Header=BB2_15 Depth=2
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB2_15
LBB2_22:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.ne	LBB2_24
	b	LBB2_23
LBB2_23:                                ;   in Loop: Header=BB2_5 Depth=1
	ldrh	w8, [sp, #18]
	strh	w8, [sp, #26]
	b	LBB2_24
LBB2_24:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	x0, [sp, #72]
	bl	_nvm_v2_align4
	str	w0, [sp, #28]
	cbz	w0, LBB2_26
	b	LBB2_25
LBB2_25:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_26:                                ;   in Loop: Header=BB2_5 Depth=1
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB2_5
LBB2_28:
	ldrb	w8, [sp, #39]
	tbz	w8, #0, LBB2_31
	b	LBB2_29
LBB2_29:
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #72]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB2_31
	b	LBB2_30
LBB2_30:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_31:
	ldr	w8, [sp, #68]
	adds	w8, w8, #1
	b.eq	LBB2_42
	b	LBB2_32
LBB2_32:
	ldrh	w8, [sp, #26]
	cbz	w8, LBB2_36
	b	LBB2_33
LBB2_33:
	ldrh	w8, [sp, #26]
	ldrh	w9, [sp, #54]
	subs	w8, w8, w9
	b.gt	LBB2_36
	b	LBB2_34
LBB2_34:
	ldr	x8, [sp, #56]
	cbz	x8, LBB2_36
	b	LBB2_35
LBB2_35:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB2_37
	b	LBB2_36
LBB2_36:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-76]
	b	LBB2_43
LBB2_37:
	strh	wzr, [sp, #10]
	b	LBB2_38
LBB2_38:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldrh	w9, [sp, #26]
	subs	w8, w8, w9
	b.ge	LBB2_41
	b	LBB2_39
LBB2_39:                                ;   in Loop: Header=BB2_38 Depth=1
	ldrh	w8, [sp, #10]
	mov	x9, x8
	sub	x8, x29, #72
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp, #56]
	ldrh	w10, [sp, #10]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB2_40
LBB2_40:                                ;   in Loop: Header=BB2_38 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB2_38
LBB2_41:
	ldrh	w8, [sp, #26]
	ldr	x9, [sp, #40]
	strh	w8, [x9]
	b	LBB2_42
LBB2_42:
	stur	wzr, [x29, #-76]
	b	LBB2_43
LBB2_43:
	ldur	w8, [x29, #-76]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB2_45
	b	LBB2_44
LBB2_44:
	bl	___stack_chk_fail
LBB2_45:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function extension_suffix_read
_extension_suffix_read:                 ; @extension_suffix_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #24]
	strh	w3, [sp, #22]
	str	x4, [sp, #8]
	str	x5, [sp]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #24]
	ldrh	w3, [sp, #22]
	ldr	x4, [sp, #8]
	ldr	x5, [sp]
	mov	x6, #0                          ; =0x0
	bl	_extension_suffix_read_map
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_validate_owned
_ownership_validate_owned:              ; @ownership_validate_owned
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2496
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #248
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	str	x0, [x8, #224]
	str	x1, [x8, #216]
	str	x2, [x8, #208]
	str	x3, [x8, #200]
	str	x4, [x8, #192]
	str	x5, [x8, #184]
	sturb	wzr, [x29, #-69]
	str	xzr, [x8, #168]
	stur	wzr, [x29, #-84]
	ldr	x9, [x8, #224]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #224]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #112
	str	x0, [sp, #176]                  ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #176]                  ; 8-byte Folded Reload
	sturb	wzr, [x29, #-129]
	sub	x1, x29, #116
	bl	_nvm_v2_u32
	stur	w0, [x29, #-68]
	cbnz	w0, LBB4_2
	b	LBB4_1
LBB4_1:
	sub	x0, x29, #112
	sub	x1, x29, #120
	bl	_nvm_v2_u32
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_3
	b	LBB4_2
LBB4_2:
	b	LBB4_128
LBB4_3:
	ldur	w0, [x29, #-116]
	bl	_ownership_version
	tbnz	w0, #0, LBB4_5
	b	LBB4_4
LBB4_4:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_5:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldur	w8, [x29, #-120]
	ldr	x9, [x9, #216]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB4_7
	b	LBB4_6
LBB4_6:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_7:
	ldur	w8, [x29, #-120]
	mov	x1, x8
	sub	x0, x29, #112
	sub	x2, x29, #128
	bl	_nvm_v2_take
	stur	w0, [x29, #-68]
	cbnz	w0, LBB4_13
	b	LBB4_8
LBB4_8:
	sub	x0, x29, #112
	bl	_nvm_v2_align4
	stur	w0, [x29, #-68]
	cbnz	w0, LBB4_13
	b	LBB4_9
LBB4_9:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #216]
	str	x9, [sp, #144]                  ; 8-byte Folded Spill
	ldr	x9, [x8, #120]
	str	x9, [sp, #152]                  ; 8-byte Folded Spill
	ldr	x8, [x8, #200]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #160]                  ; 4-byte Folded Spill
	ldur	w9, [x29, #-116]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp, #164]                  ; 4-byte Folded Spill
	b.ne	LBB4_11
	b	LBB4_10
LBB4_10:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	subs	x8, x8, #0
	cset	w8, eq
	str	w8, [sp, #164]                  ; 4-byte Folded Spill
	b	LBB4_11
LBB4_11:
	ldr	w3, [sp, #160]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #152]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #164]                  ; 4-byte Folded Reload
	ldr	x9, [x9, #184]
	subs	x9, x9, #0
	cset	w5, ne
	sub	x2, x29, #129
	and	w4, w8, #0x1
	bl	_check_layouts
	stur	w0, [x29, #-68]
	cbnz	w0, LBB4_13
	b	LBB4_12
LBB4_12:
	sub	x0, x29, #112
	sub	x1, x29, #120
	bl	_nvm_v2_u32
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_14
	b	LBB4_13
LBB4_13:
	b	LBB4_128
LBB4_14:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_20
	b	LBB4_15
LBB4_15:
	stur	wzr, [x29, #-136]
	b	LBB4_16
LBB4_16:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldur	w8, [x29, #-136]
	ldr	x9, [x9, #216]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB4_19
	b	LBB4_17
LBB4_17:                                ;   in Loop: Header=BB4_16 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #120]
	ldur	w10, [x29, #-136]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10
	ldrb	w8, [x8]
	ldr	x9, [x9, #200]
	add	x9, x9, #32
	ldur	w10, [x29, #-136]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_16 Depth=1
	ldur	w8, [x29, #-136]
	add	w8, w8, #1
	stur	w8, [x29, #-136]
	b	LBB4_16
LBB4_19:
	b	LBB4_20
LBB4_20:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldur	w8, [x29, #-120]
	ldr	x9, [x9, #224]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB4_23
	b	LBB4_21
LBB4_21:
	ldur	w8, [x29, #-120]
	cbz	w8, LBB4_24
	b	LBB4_22
LBB4_22:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #224]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB4_24
	b	LBB4_23
LBB4_23:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_24:
	stur	wzr, [x29, #-140]
	b	LBB4_25
LBB4_25:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_52 Depth 2
	ldur	w8, [x29, #-140]
	ldur	w9, [x29, #-120]
	subs	w8, w8, w9
	b.hs	LBB4_78
	b	LBB4_26
LBB4_26:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #224]
	ldr	x11, [x8, #256]
	ldur	w8, [x29, #-140]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [x9, #96]
	sub	x0, x29, #112
	sub	x1, x29, #142
	bl	_nvm_v2_u16
	stur	w0, [x29, #-68]
	cbnz	w0, LBB4_28
	b	LBB4_27
LBB4_27:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x0, x29, #112
	sub	x1, x29, #144
	bl	_nvm_v2_u16
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_29
	b	LBB4_28
LBB4_28:
	b	LBB4_128
LBB4_29:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldurh	w8, [x29, #-142]
	ldr	x9, [x9, #96]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB4_33
	b	LBB4_30
LBB4_30:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldurh	w8, [x29, #-144]
	ldr	x9, [x9, #96]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB4_33
	b	LBB4_31
LBB4_31:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurh	w8, [x29, #-144]
	ldurh	w9, [x29, #-142]
	subs	w8, w8, w9
	b.gt	LBB4_33
	b	LBB4_32
LBB4_32:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #96]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.le	LBB4_34
	b	LBB4_33
LBB4_33:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_34:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #96]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB4_36
	b	LBB4_35
LBB4_35:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #96]
	ldrb	w8, [x8, #20]
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB4_37
LBB4_36:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB4_37
LBB4_37:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #140]                  ; 4-byte Folded Reload
	stur	w9, [x29, #-156]
	ldr	x8, [x8, #184]
	cbz	x8, LBB4_40
	b	LBB4_38
LBB4_38:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-156]
	subs	w8, w8, #13
	b.ne	LBB4_40
	b	LBB4_39
LBB4_39:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_40:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	sturb	wzr, [x29, #-69]
	ldr	x9, [x8, #216]
	str	x9, [sp, #112]                  ; 8-byte Folded Spill
	ldr	x9, [x8, #120]
	str	x9, [sp, #120]                  ; 8-byte Folded Spill
	ldur	w9, [x29, #-116]
	str	w9, [sp, #132]                  ; 4-byte Folded Spill
	ldur	w9, [x29, #-156]
	str	w9, [sp, #136]                  ; 4-byte Folded Spill
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_42
	b	LBB4_41
LBB4_41:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x8, x29, #69
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	b	LBB4_43
LBB4_42:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	b	LBB4_43
LBB4_43:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	str	x9, [sp, #96]                   ; 8-byte Folded Spill
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_45
	b	LBB4_44
LBB4_44:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB4_46
LBB4_45:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x8, x29, #80
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB4_46
LBB4_46:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x7, [sp, #96]                   ; 8-byte Folded Reload
	ldr	w5, [sp, #136]                  ; 4-byte Folded Reload
	ldr	w3, [sp, #132]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	sub	x0, x29, #112
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	sub	x6, x29, #129
	bl	_descriptor
	stur	w0, [x29, #-68]
	ldur	w8, [x29, #-68]
	cbz	w8, LBB4_51
	b	LBB4_47
LBB4_47:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #192]
	cbz	x8, LBB4_49
	b	LBB4_48
LBB4_48:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-69]
	tbnz	w8, #0, LBB4_50
	b	LBB4_49
LBB4_49:
	b	LBB4_128
LBB4_50:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #192]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #48]
	stur	wzr, [x29, #-68]
	b	LBB4_51
LBB4_51:                                ;   in Loop: Header=BB4_25 Depth=1
	sturh	wzr, [x29, #-158]
	b	LBB4_52
LBB4_52:                                ;   Parent Loop BB4_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-158]
	ldurh	w9, [x29, #-142]
	subs	w8, w8, w9
	b.ge	LBB4_76
	b	LBB4_53
LBB4_53:                                ;   in Loop: Header=BB4_52 Depth=2
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-164]
	ldurh	w8, [x29, #-158]
	ldurh	w9, [x29, #-144]
	subs	w8, w8, w9
	b.ge	LBB4_59
	b	LBB4_54
LBB4_54:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #224]
	ldr	x8, [x8, #264]
	cbz	x8, LBB4_57
	b	LBB4_55
LBB4_55:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #224]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-140]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB4_57
	b	LBB4_56
LBB4_56:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #224]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-140]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldurh	w9, [x29, #-158]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB4_58
LBB4_57:                                ;   in Loop: Header=BB4_52 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB4_58
LBB4_58:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-164]
	b	LBB4_59
LBB4_59:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #184]
	cbz	x8, LBB4_63
	b	LBB4_60
LBB4_60:                                ;   in Loop: Header=BB4_52 Depth=2
	ldurh	w8, [x29, #-158]
	ldurh	w9, [x29, #-144]
	subs	w8, w8, w9
	b.ge	LBB4_63
	b	LBB4_61
LBB4_61:                                ;   in Loop: Header=BB4_52 Depth=2
	ldur	w8, [x29, #-164]
	subs	w8, w8, #13
	b.ne	LBB4_63
	b	LBB4_62
LBB4_62:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_63:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	sturb	wzr, [x29, #-69]
	ldr	x9, [x8, #216]
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	ldr	x9, [x8, #120]
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	ldur	w9, [x29, #-116]
	str	w9, [sp, #72]                   ; 4-byte Folded Spill
	ldurh	w9, [x29, #-158]
	ldurh	w10, [x29, #-144]
	subs	w9, w9, w10
	cset	w9, lt
	str	w9, [sp, #76]                   ; 4-byte Folded Spill
	ldur	w9, [x29, #-164]
	str	w9, [sp, #80]                   ; 4-byte Folded Spill
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_65
	b	LBB4_64
LBB4_64:                                ;   in Loop: Header=BB4_52 Depth=2
	sub	x8, x29, #69
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB4_66
LBB4_65:                                ;   in Loop: Header=BB4_52 Depth=2
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB4_66
LBB4_66:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_68
	b	LBB4_67
LBB4_67:                                ;   in Loop: Header=BB4_52 Depth=2
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB4_69
LBB4_68:                                ;   in Loop: Header=BB4_52 Depth=2
	sub	x8, x29, #80
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB4_69
LBB4_69:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x7, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w5, [sp, #80]                   ; 4-byte Folded Reload
	ldr	w4, [sp, #76]                   ; 4-byte Folded Reload
	ldr	w3, [sp, #72]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	sub	x0, x29, #112
	sub	x6, x29, #129
	bl	_descriptor
	stur	w0, [x29, #-68]
	ldur	w8, [x29, #-68]
	cbz	w8, LBB4_74
	b	LBB4_70
LBB4_70:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #192]
	cbz	x8, LBB4_72
	b	LBB4_71
LBB4_71:                                ;   in Loop: Header=BB4_52 Depth=2
	ldurb	w8, [x29, #-69]
	tbnz	w8, #0, LBB4_73
	b	LBB4_72
LBB4_72:
	b	LBB4_128
LBB4_73:                                ;   in Loop: Header=BB4_52 Depth=2
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #192]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #48]
	stur	wzr, [x29, #-68]
	b	LBB4_74
LBB4_74:                                ;   in Loop: Header=BB4_52 Depth=2
	b	LBB4_75
LBB4_75:                                ;   in Loop: Header=BB4_52 Depth=2
	ldurh	w8, [x29, #-158]
	add	w8, w8, #1
	sturh	w8, [x29, #-158]
	b	LBB4_52
LBB4_76:                                ;   in Loop: Header=BB4_25 Depth=1
	b	LBB4_77
LBB4_77:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-140]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	b	LBB4_25
LBB4_78:
	sub	x0, x29, #232
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	xzr, [x8]
	str	xzr, [x8, #8]
	ldur	w8, [x29, #-116]
	subs	w8, w8, #2
	b.ne	LBB4_82
	b	LBB4_79
LBB4_79:
	sub	x0, x29, #112
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_paths_read
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_81
	b	LBB4_80
LBB4_80:
	b	LBB4_128
LBB4_81:
	b	LBB4_116
LBB4_82:
	ldur	w8, [x29, #-116]
	subs	w8, w8, #3
	b.ne	LBB4_115
	b	LBB4_83
LBB4_83:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #184]
	cbz	x8, LBB4_85
	b	LBB4_84
LBB4_84:
	sub	x8, x29, #248
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB4_86
LBB4_85:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB4_86
LBB4_86:
	ldr	x6, [sp, #24]                   ; 8-byte Folded Reload
	sub	x0, x29, #112
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	sub	x5, x29, #232
	bl	_extension_suffix_read_map
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_88
	b	LBB4_87
LBB4_87:
	b	LBB4_128
LBB4_88:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	subs	x8, x8, #0
	cset	w8, ne
	ldr	x9, [x9, #224]
	ldr	w9, [x9, #476]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB4_90
	b	LBB4_89
LBB4_89:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_90:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbz	x8, LBB4_96
	b	LBB4_91
LBB4_91:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x1, [x8, #16]
	ldur	w8, [x29, #-224]
	mov	x2, x8
	add	x0, sp, #2240
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #224]
	ldr	x2, [x8, #216]
	ldr	x3, [x8, #120]
	ldr	x7, [x8, #192]
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_union_facts_read
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_93
	b	LBB4_92
LBB4_92:
	b	LBB4_128
LBB4_93:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #192]
	cbz	x8, LBB4_95
	b	LBB4_94
LBB4_94:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #192]
	ldr	q0, [x9, #16]
	str	q0, [x8]
	b	LBB4_95
LBB4_95:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-129]
	b	LBB4_96
LBB4_96:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	cbz	x8, LBB4_102
	b	LBB4_97
LBB4_97:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_99
	b	LBB4_98
LBB4_98:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_99:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x2, [x8, #216]
	ldr	x3, [x8, #120]
	ldr	x0, [x8, #48]
	ldr	x1, [x8, #56]
	bl	_globals_read
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_101
	b	LBB4_100
LBB4_100:
	b	LBB4_128
LBB4_101:
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-129]
	b	LBB4_102
LBB4_102:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #64]
	cbz	x8, LBB4_108
	b	LBB4_103
LBB4_103:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_105
	b	LBB4_104
LBB4_104:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_105:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x2, [x8, #224]
	ldr	x3, [x8, #216]
	ldr	x4, [x8, #120]
	ldr	x0, [x8, #64]
	ldr	x1, [x8, #72]
	mov	x8, sp
	mov	x6, #0                          ; =0x0
	str	xzr, [x8]
	mov	w5, #-1                         ; =0xffffffff
	add	x7, sp, #188
	bl	_effects_read
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_107
	b	LBB4_106
LBB4_106:
	b	LBB4_128
LBB4_107:
	ldr	w8, [sp, #188]
	stur	w8, [x29, #-84]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-129]
	b	LBB4_108
LBB4_108:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	cbz	x8, LBB4_114
	b	LBB4_109
LBB4_109:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	cbnz	x8, LBB4_111
	b	LBB4_110
LBB4_110:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_111:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x2, [x8, #200]
	ldr	x0, [x8, #32]
	ldr	x1, [x8, #40]
	bl	_oaa_array_fields
	stur	w0, [x29, #-68]
	cbz	w0, LBB4_113
	b	LBB4_112
LBB4_112:
	b	LBB4_128
LBB4_113:
	b	LBB4_114
LBB4_114:
	b	LBB4_115
LBB4_115:
	b	LBB4_116
LBB4_116:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #184]
	cbz	x8, LBB4_120
	b	LBB4_117
LBB4_117:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB4_119
	b	LBB4_118
LBB4_118:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x0, [x8, #184]
	ldr	x3, [x8, #216]
	ldr	x4, [x8, #120]
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_map_payload
	tbnz	w0, #0, LBB4_120
	b	LBB4_119
LBB4_119:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_120:
	ldur	w8, [x29, #-80]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.ls	LBB4_122
	b	LBB4_121
LBB4_121:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_122:
	ldur	w8, [x29, #-84]
	cbz	w8, LBB4_125
	b	LBB4_123
LBB4_123:
	ldurb	w8, [x29, #-76]
	tbz	w8, #0, LBB4_125
	b	LBB4_124
LBB4_124:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_125:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #152]
	ldr	x9, [x9, #144]
	subs	x8, x8, x9
	b.eq	LBB4_127
	b	LBB4_126
LBB4_126:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-68]
	b	LBB4_128
LBB4_127:
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldurb	w8, [x29, #-129]
	ldr	x9, [x9, #208]
	and	w8, w8, #0x1
	strb	w8, [x9]
	b	LBB4_128
LBB4_128:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #200]
	cbz	x8, LBB4_132
	b	LBB4_129
LBB4_129:
	ldurb	w8, [x29, #-69]
	tbz	w8, #0, LBB4_132
	b	LBB4_130
LBB4_130:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #192]
	cbnz	x8, LBB4_132
	b	LBB4_131
LBB4_131:
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #200]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #300]
	b	LBB4_132
LBB4_132:
	ldur	w0, [x29, #-68]
	add	sp, sp, #2496
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_globals          ; -- Begin function nvm_ownership_globals
	.p2align	2
_nvm_ownership_globals:                 ; @nvm_ownership_globals
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #192
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #24]
	str	x1, [x8, #16]
	str	w2, [sp, #204]
	str	x3, [x8]
	ldr	x8, [x8, #24]
	cbz	x8, LBB5_4
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB5_4
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbnz	x8, LBB5_5
	b	LBB5_3
LBB5_3:
	ldr	w8, [sp, #204]
	cbz	w8, LBB5_5
	b	LBB5_4
LBB5_4:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_5:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	add	x1, sp, #191
	strb	wzr, [sp, #191]
	ldr	x0, [x8, #24]
	bl	_nvm_ownership_contracts_validate
	str	w0, [sp, #184]
	ldr	w8, [sp, #184]
	cbz	w8, LBB5_7
	b	LBB5_6
LBB5_6:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_7:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB5_9
	b	LBB5_8
LBB5_8:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	wzr, [x8]
	str	wzr, [sp, #228]
	b	LBB5_51
LBB5_9:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #24]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #24]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #160
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	add	x1, sp, #156
	bl	_nvm_v2_u32
	str	w0, [sp, #184]
	cbz	w0, LBB5_11
	b	LBB5_10
LBB5_10:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_11:
	ldr	w8, [sp, #156]
	subs	w8, w8, #3
	b.eq	LBB5_13
	b	LBB5_12
LBB5_12:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	wzr, [x8]
	str	wzr, [sp, #228]
	b	LBB5_51
LBB5_13:
	add	x0, sp, #160
	add	x1, sp, #152
	bl	_nvm_v2_u32
	str	w0, [sp, #184]
	cbnz	w0, LBB5_17
	b	LBB5_14
LBB5_14:
	ldr	w8, [sp, #152]
	mov	x1, x8
	add	x0, sp, #160
	add	x2, sp, #144
	bl	_nvm_v2_take
	str	w0, [sp, #184]
	cbnz	w0, LBB5_17
	b	LBB5_15
LBB5_15:
	add	x0, sp, #160
	bl	_nvm_v2_align4
	str	w0, [sp, #184]
	cbnz	w0, LBB5_17
	b	LBB5_16
LBB5_16:
	add	x0, sp, #160
	add	x1, sp, #152
	bl	_nvm_v2_u32
	str	w0, [sp, #184]
	cbz	w0, LBB5_18
	b	LBB5_17
LBB5_17:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_18:
	str	wzr, [sp, #140]
	b	LBB5_19
LBB5_19:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #140]
	ldr	w9, [sp, #152]
	subs	w8, w8, w9
	b.hs	LBB5_26
	b	LBB5_20
LBB5_20:                                ;   in Loop: Header=BB5_19 Depth=1
	add	x0, sp, #160
	add	x1, sp, #138
	bl	_nvm_v2_u16
	str	w0, [sp, #184]
	cbnz	w0, LBB5_23
	b	LBB5_21
LBB5_21:                                ;   in Loop: Header=BB5_19 Depth=1
	add	x0, sp, #160
	add	x1, sp, #136
	bl	_nvm_v2_u16
	str	w0, [sp, #184]
	cbnz	w0, LBB5_23
	b	LBB5_22
LBB5_22:                                ;   in Loop: Header=BB5_19 Depth=1
	ldrh	w8, [sp, #138]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	add	x0, sp, #160
	add	x2, sp, #144
	bl	_nvm_v2_take
	str	w0, [sp, #184]
	cbz	w0, LBB5_24
	b	LBB5_23
LBB5_23:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_24:                                ;   in Loop: Header=BB5_19 Depth=1
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_19 Depth=1
	ldr	w8, [sp, #140]
	add	w8, w8, #1
	str	w8, [sp, #140]
	b	LBB5_19
LBB5_26:
	add	x0, sp, #72
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	w3, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x5, [sp, #32]                   ; 8-byte Folded Reload
	add	x0, sp, #160
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	bl	_extension_suffix_read
	str	w0, [sp, #184]
	cbz	w0, LBB5_28
	b	LBB5_27
LBB5_27:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_28:
	ldr	x8, [sp, #104]
	cbnz	x8, LBB5_30
	b	LBB5_29
LBB5_29:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	wzr, [x8]
	str	wzr, [sp, #228]
	b	LBB5_51
LBB5_30:
	ldr	x1, [sp, #104]
	ldr	w8, [sp, #112]
	mov	x2, x8
	add	x0, sp, #160
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #152
	bl	_nvm_v2_u32
	str	w0, [sp, #184]
	cbz	w0, LBB5_32
	b	LBB5_31
LBB5_31:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_32:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbz	x8, LBB5_35
	b	LBB5_33
LBB5_33:
	ldr	w8, [sp, #204]
	ldr	w9, [sp, #152]
	subs	w8, w8, w9
	b.hs	LBB5_35
	b	LBB5_34
LBB5_34:
	mov	w8, #13                         ; =0xd
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_35:
	str	wzr, [sp, #68]
	b	LBB5_36
LBB5_36:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #152]
	subs	w8, w8, w9
	b.hs	LBB5_44
	b	LBB5_37
LBB5_37:                                ;   in Loop: Header=BB5_36 Depth=1
	ldr	w8, [sp, #68]
	mov	x9, x8
	add	x8, sp, #232
	add	x1, x8, x9, lsl #3
	add	x0, sp, #160
	bl	_nvm_v2_u8
	str	w0, [sp, #184]
	cbnz	w0, LBB5_41
	b	LBB5_38
LBB5_38:                                ;   in Loop: Header=BB5_36 Depth=1
	add	x0, sp, #160
	add	x1, sp, #67
	bl	_nvm_v2_u8
	str	w0, [sp, #184]
	cbnz	w0, LBB5_41
	b	LBB5_39
LBB5_39:                                ;   in Loop: Header=BB5_36 Depth=1
	add	x0, sp, #160
	add	x1, sp, #64
	bl	_nvm_v2_u16
	str	w0, [sp, #184]
	cbnz	w0, LBB5_41
	b	LBB5_40
LBB5_40:                                ;   in Loop: Header=BB5_36 Depth=1
	ldr	w8, [sp, #68]
	mov	x9, x8
	add	x8, sp, #232
	add	x8, x8, x9, lsl #3
	add	x1, x8, #4
	add	x0, sp, #160
	bl	_nvm_v2_u32
	str	w0, [sp, #184]
	cbz	w0, LBB5_42
	b	LBB5_41
LBB5_41:
	ldr	w8, [sp, #184]
	str	w8, [sp, #228]
	b	LBB5_51
LBB5_42:                                ;   in Loop: Header=BB5_36 Depth=1
	ldrb	w8, [sp, #67]
	subs	w8, w8, #0
	cset	w8, ne
	ldr	w9, [sp, #68]
	mov	x10, x9
	add	x9, sp, #232
	add	x9, x9, x10, lsl #3
	strb	w8, [x9, #1]
	b	LBB5_43
LBB5_43:                                ;   in Loop: Header=BB5_36 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB5_36
LBB5_44:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbz	x8, LBB5_50
	b	LBB5_45
LBB5_45:
	str	wzr, [sp, #60]
	b	LBB5_46
LBB5_46:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	w9, [sp, #152]
	subs	w8, w8, w9
	b.hs	LBB5_49
	b	LBB5_47
LBB5_47:                                ;   in Loop: Header=BB5_46 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	ldr	w8, [sp, #60]
	mov	x10, x8
	ldr	w8, [sp, #60]
	mov	x11, x8
	add	x8, sp, #232
	ldr	x8, [x8, x11, lsl #3]
	str	x8, [x9, x10, lsl #3]
	b	LBB5_48
LBB5_48:                                ;   in Loop: Header=BB5_46 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB5_46
LBB5_49:
	b	LBB5_50
LBB5_50:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #152]
	ldr	x9, [x9]
	str	w8, [x9]
	str	wzr, [sp, #228]
	b	LBB5_51
LBB5_51:
	ldr	w8, [sp, #228]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB5_53
	b	LBB5_52
LBB5_52:
	bl	___stack_chk_fail
LBB5_53:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #2288
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_effect           ; -- Begin function nvm_ownership_effect
	.p2align	2
_nvm_ownership_effect:                  ; @nvm_ownership_effect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	mov	x4, #0                          ; =0x0
	mov	x3, x4
	bl	_ownership_effect_query
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_effect_query
_ownership_effect_query:                ; @ownership_effect_query
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	stur	x4, [x29, #-64]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB7_6
	b	LBB7_1
LBB7_1:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB7_4
	b	LBB7_2
LBB7_2:
	ldur	x8, [x29, #-56]
	cbnz	x8, LBB7_4
	b	LBB7_3
LBB7_3:
	ldur	x8, [x29, #-64]
	cbz	x8, LBB7_6
	b	LBB7_4
LBB7_4:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB7_7
	b	LBB7_5
LBB7_5:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB7_7
	b	LBB7_6
LBB7_6:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_7:
	sub	x1, x29, #65
	sturb	wzr, [x29, #-65]
	ldur	x0, [x29, #-32]
	bl	_nvm_ownership_contracts_validate
	stur	w0, [x29, #-72]
	ldur	w8, [x29, #-72]
	cbz	w8, LBB7_9
	b	LBB7_8
LBB7_8:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_9:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB7_11
	b	LBB7_10
LBB7_10:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_11:
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #96
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	stur	w0, [x29, #-72]
	cbz	w0, LBB7_13
	b	LBB7_12
LBB7_12:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_13:
	ldur	w8, [x29, #-100]
	subs	w8, w8, #3
	b.eq	LBB7_15
	b	LBB7_14
LBB7_14:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_15:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	stur	w0, [x29, #-72]
	cbnz	w0, LBB7_19
	b	LBB7_16
LBB7_16:
	ldur	w8, [x29, #-104]
	mov	x1, x8
	sub	x0, x29, #96
	sub	x2, x29, #112
	bl	_nvm_v2_take
	stur	w0, [x29, #-72]
	cbnz	w0, LBB7_19
	b	LBB7_17
LBB7_17:
	sub	x0, x29, #96
	bl	_nvm_v2_align4
	stur	w0, [x29, #-72]
	cbnz	w0, LBB7_19
	b	LBB7_18
LBB7_18:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	stur	w0, [x29, #-72]
	cbz	w0, LBB7_20
	b	LBB7_19
LBB7_19:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_20:
	stur	wzr, [x29, #-124]
	b	LBB7_21
LBB7_21:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-104]
	subs	w8, w8, w9
	b.hs	LBB7_28
	b	LBB7_22
LBB7_22:                                ;   in Loop: Header=BB7_21 Depth=1
	sub	x0, x29, #96
	sub	x1, x29, #126
	bl	_nvm_v2_u16
	stur	w0, [x29, #-72]
	cbnz	w0, LBB7_25
	b	LBB7_23
LBB7_23:                                ;   in Loop: Header=BB7_21 Depth=1
	sub	x0, x29, #96
	add	x1, sp, #128
	bl	_nvm_v2_u16
	stur	w0, [x29, #-72]
	cbnz	w0, LBB7_25
	b	LBB7_24
LBB7_24:                                ;   in Loop: Header=BB7_21 Depth=1
	ldurh	w8, [x29, #-126]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	sub	x0, x29, #96
	sub	x2, x29, #120
	bl	_nvm_v2_take
	stur	w0, [x29, #-72]
	cbz	w0, LBB7_26
	b	LBB7_25
LBB7_25:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_26:                                ;   in Loop: Header=BB7_21 Depth=1
	b	LBB7_27
LBB7_27:                                ;   in Loop: Header=BB7_21 Depth=1
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	stur	w8, [x29, #-124]
	b	LBB7_21
LBB7_28:
	add	x0, sp, #64
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	w3, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x5, [sp, #32]                   ; 8-byte Folded Reload
	sub	x0, x29, #96
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	bl	_extension_suffix_read
	stur	w0, [x29, #-72]
	cbz	w0, LBB7_30
	b	LBB7_29
LBB7_29:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_30:
	ldr	x8, [sp, #112]
	cbnz	x8, LBB7_32
	b	LBB7_31
LBB7_31:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_32:
	add	x2, sp, #48
	str	xzr, [sp, #48]
	str	xzr, [sp, #56]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	stur	w0, [x29, #-72]
	ldur	w8, [x29, #-72]
	cbz	w8, LBB7_34
	b	LBB7_33
LBB7_33:
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_34:
	ldur	x2, [x29, #-32]
	ldur	x4, [x29, #-112]
	ldur	w5, [x29, #-36]
	ldur	x6, [x29, #-48]
	ldur	x7, [x29, #-56]
	ldur	x8, [x29, #-64]
	ldr	x0, [sp, #112]
	ldr	x1, [sp, #120]
	mov	x9, sp
	str	x8, [x9]
	add	x3, sp, #48
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	_effects_read
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	stur	w8, [x29, #-72]
	bl	_nvm_v2_layouts_free
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-20]
	b	LBB7_35
LBB7_35:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_effect_types     ; -- Begin function nvm_ownership_effect_types
	.p2align	2
_nvm_ownership_effect_types:            ; @nvm_ownership_effect_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x3, [sp]
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	bl	_ownership_effect_query
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_array_constructor ; -- Begin function nvm_ownership_array_constructor
	.p2align	2
_nvm_ownership_array_constructor:       ; @nvm_ownership_array_constructor
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	w2, [sp, #24]
	str	x3, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB9_5
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB9_5
	b	LBB9_2
LBB9_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB9_5
	b	LBB9_3
LBB9_3:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB9_5
	b	LBB9_4
LBB9_4:
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB9_6
	b	LBB9_5
LBB9_5:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB9_9
LBB9_6:
	ldur	w8, [x29, #-20]
	add	x4, sp, #4
	str	w8, [sp, #4]
	ldr	w8, [sp, #24]
	str	w8, [sp, #8]
	mov	w1, #-1                         ; =0xffffffff
	str	w1, [sp, #12]
	ldur	x0, [x29, #-16]
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_ownership_effect_query
	str	w0, [sp]
	ldr	w8, [sp]
	cbnz	w8, LBB9_8
	b	LBB9_7
LBB9_7:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	b	LBB9_8
LBB9_8:
	ldr	w8, [sp]
	stur	w8, [x29, #-4]
	b	LBB9_9
LBB9_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_union_variant    ; -- Begin function nvm_ownership_union_variant
	.p2align	2
_nvm_ownership_union_variant:           ; @nvm_ownership_union_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	add	x29, sp, #272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #72
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x8, #40]
	stur	w1, [x29, #-36]
	sturh	w2, [x29, #-38]
	str	x3, [x8, #24]
	ldr	x8, [x8, #40]
	cbz	x8, LBB10_4
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbz	x8, LBB10_4
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	x8, [x8, #296]
	cbz	x8, LBB10_4
	b	LBB10_3
LBB10_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	x8, [x8, #312]
	cbnz	x8, LBB10_5
	b	LBB10_4
LBB10_4:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB10_34
LBB10_5:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	sub	x1, x29, #49
	sturb	wzr, [x29, #-49]
	ldr	x0, [x8, #40]
	bl	_nvm_ownership_contracts_validate
	stur	w0, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbz	w8, LBB10_7
	b	LBB10_6
LBB10_6:
	ldur	w8, [x29, #-56]
	stur	w8, [x29, #-20]
	b	LBB10_34
LBB10_7:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	sub	x2, x29, #72
	str	xzr, [x8]
	str	xzr, [x8, #8]
	ldr	x9, [x8, #40]
	ldr	x0, [x9, #312]
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	stur	w0, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbz	w8, LBB10_9
	b	LBB10_8
LBB10_8:
	ldur	w8, [x29, #-56]
	stur	w8, [x29, #-20]
	b	LBB10_34
LBB10_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #40]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #96
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_15
	b	LBB10_10
LBB10_10:
	ldur	w8, [x29, #-100]
	subs	w8, w8, #3
	b.ne	LBB10_15
	b	LBB10_11
LBB10_11:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_15
	b	LBB10_12
LBB10_12:
	ldur	w8, [x29, #-104]
	mov	x1, x8
	sub	x0, x29, #96
	sub	x2, x29, #120
	bl	_nvm_v2_take
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_15
	b	LBB10_13
LBB10_13:
	sub	x0, x29, #96
	bl	_nvm_v2_align4
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_15
	b	LBB10_14
LBB10_14:
	sub	x0, x29, #96
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	stur	w0, [x29, #-56]
	cbz	w0, LBB10_18
	b	LBB10_15
LBB10_15:
	ldur	w8, [x29, #-56]
	cbnz	w8, LBB10_17
	b	LBB10_16
LBB10_16:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-56]
	b	LBB10_17
LBB10_17:
	b	LBB10_33
LBB10_18:
	stur	wzr, [x29, #-124]
	b	LBB10_19
LBB10_19:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-104]
	subs	w8, w8, w9
	b.hs	LBB10_26
	b	LBB10_20
LBB10_20:                               ;   in Loop: Header=BB10_19 Depth=1
	sub	x0, x29, #96
	sub	x1, x29, #126
	bl	_nvm_v2_u16
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_23
	b	LBB10_21
LBB10_21:                               ;   in Loop: Header=BB10_19 Depth=1
	sub	x0, x29, #96
	sub	x1, x29, #128
	bl	_nvm_v2_u16
	stur	w0, [x29, #-56]
	cbnz	w0, LBB10_23
	b	LBB10_22
LBB10_22:                               ;   in Loop: Header=BB10_19 Depth=1
	ldurh	w8, [x29, #-126]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	sub	x0, x29, #96
	sub	x2, x29, #112
	bl	_nvm_v2_take
	stur	w0, [x29, #-56]
	cbz	w0, LBB10_24
	b	LBB10_23
LBB10_23:
	b	LBB10_33
LBB10_24:                               ;   in Loop: Header=BB10_19 Depth=1
	b	LBB10_25
LBB10_25:                               ;   in Loop: Header=BB10_19 Depth=1
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	stur	w8, [x29, #-124]
	b	LBB10_19
LBB10_26:
	add	x0, sp, #80
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	w3, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x5, [sp, #16]                   ; 8-byte Folded Reload
	sub	x0, x29, #96
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	bl	_extension_suffix_read
	stur	w0, [x29, #-56]
	cbz	w0, LBB10_28
	b	LBB10_27
LBB10_27:
	b	LBB10_33
LBB10_28:
	ldr	x8, [sp, #80]
	cbnz	x8, LBB10_30
	b	LBB10_29
LBB10_29:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-56]
	b	LBB10_33
LBB10_30:
	ldr	x1, [sp, #80]
	ldr	w8, [sp, #88]
	mov	x2, x8
	add	x0, sp, #56
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [x8, #40]
	ldur	x3, [x29, #-120]
	ldur	w4, [x29, #-36]
	ldurh	w5, [x29, #-38]
	sub	x2, x29, #72
	add	x6, sp, #44
	mov	x7, #0                          ; =0x0
	bl	_union_facts_read
	stur	w0, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbnz	w8, LBB10_32
	b	LBB10_31
LBB10_31:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #24]
	ldur	x8, [sp, #44]
	str	x8, [x9]
	ldr	w8, [sp, #52]
	str	w8, [x9, #8]
	b	LBB10_32
LBB10_32:
	b	LBB10_33
LBB10_33:
	sub	x0, x29, #72
	bl	_nvm_v2_layouts_free
	ldur	w8, [x29, #-56]
	stur	w8, [x29, #-20]
	b	LBB10_34
LBB10_34:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_facts_read
_union_facts_read:                      ; @union_facts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #80
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x0, [x8, #48]
	str	x1, [x8, #40]
	str	x2, [x8, #32]
	str	x3, [x8, #24]
	stur	w4, [x29, #-60]
	sturh	w5, [x29, #-62]
	str	x6, [x8, #8]
	str	x7, [x8]
	stur	xzr, [x29, #-104]
	stur	wzr, [x29, #-96]
	sturb	wzr, [x29, #-105]
	ldr	x0, [x8, #48]
	sub	x1, x29, #84
	bl	_nvm_v2_u32
	stur	w0, [x29, #-88]
	cbz	w0, LBB11_2
	b	LBB11_1
LBB11_1:
	ldur	w8, [x29, #-88]
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_2:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-84]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.ne	LBB11_4
	b	LBB11_3
LBB11_3:
	ldur	w8, [x29, #-84]
	subs	w8, w8, #256
	b.ls	LBB11_5
	b	LBB11_4
LBB11_4:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_5:
	stur	wzr, [x29, #-112]
	stur	wzr, [x29, #-116]
	stur	wzr, [x29, #-120]
	b	LBB11_6
LBB11_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_12 Depth 2
                                        ;     Child Loop BB11_31 Depth 2
                                        ;       Child Loop BB11_41 Depth 3
                                        ;       Child Loop BB11_50 Depth 3
	ldur	w8, [x29, #-120]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB11_81
	b	LBB11_7
LBB11_7:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	stur	w0, [x29, #-88]
	cbnz	w0, LBB11_10
	b	LBB11_8
LBB11_8:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	sub	x1, x29, #126
	bl	_nvm_v2_u16
	stur	w0, [x29, #-88]
	cbnz	w0, LBB11_10
	b	LBB11_9
LBB11_9:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	add	x1, sp, #128
	bl	_nvm_v2_u16
	stur	w0, [x29, #-88]
	cbz	w0, LBB11_11
	b	LBB11_10
LBB11_10:
	ldur	w8, [x29, #-88]
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_11:                               ;   in Loop: Header=BB11_6 Depth=1
	b	LBB11_12
LBB11_12:                               ;   Parent Loop BB11_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-112]
	ldr	x8, [x8, #32]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.hs	LBB11_14
	b	LBB11_13
LBB11_13:                               ;   in Loop: Header=BB11_12 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	cset	w8, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB11_14
LBB11_14:                               ;   in Loop: Header=BB11_12 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB11_16
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_12 Depth=2
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB11_12
LBB11_16:                               ;   in Loop: Header=BB11_6 Depth=1
	ldrh	w8, [sp, #128]
	cbnz	w8, LBB11_23
	b	LBB11_17
LBB11_17:                               ;   in Loop: Header=BB11_6 Depth=1
	ldurh	w8, [x29, #-126]
	cbz	w8, LBB11_23
	b	LBB11_18
LBB11_18:                               ;   in Loop: Header=BB11_6 Depth=1
	ldurh	w8, [x29, #-126]
	subs	w8, w8, #256
	b.hi	LBB11_23
	b	LBB11_19
LBB11_19:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-112]
	ldr	x9, [x9, #32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB11_23
	b	LBB11_20
LBB11_20:                               ;   in Loop: Header=BB11_6 Depth=1
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-112]
	subs	w8, w8, w9
	b.ne	LBB11_23
	b	LBB11_21
LBB11_21:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB11_23
	b	LBB11_22
LBB11_22:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.ne	LBB11_24
	b	LBB11_23
LBB11_23:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_24:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #32]
	ldr	x9, [x9]
	ldur	w10, [x29, #-124]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [sp, #120]
	ldr	x8, [x8]
	cbz	x8, LBB11_30
	b	LBB11_25
LBB11_25:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB11_30
	b	LBB11_26
LBB11_26:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-116]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hi	LBB11_28
	b	LBB11_27
LBB11_27:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-126]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	ldur	w10, [x29, #-116]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB11_29
	b	LBB11_28
LBB11_28:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_29:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-116]
	ldr	x10, [x9]
	ldr	x10, [x10, #32]
	ldur	w11, [x29, #-120]
                                        ; kill: def $x11 killed $w11
	str	w8, [x10, x11, lsl #2]
	ldurh	w8, [x29, #-126]
	ldr	x9, [x9]
	ldr	x9, [x9, #40]
	ldur	w10, [x29, #-120]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB11_30
LBB11_30:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #16]
	str	x8, [sp, #112]
	str	wzr, [sp, #108]
	strh	wzr, [sp, #106]
	b	LBB11_31
LBB11_31:                               ;   Parent Loop BB11_6 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB11_41 Depth 3
                                        ;       Child Loop BB11_50 Depth 3
	ldrh	w8, [sp, #106]
	ldurh	w9, [x29, #-126]
	subs	w8, w8, w9
	b.ge	LBB11_77
	b	LBB11_32
LBB11_32:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	add	x1, sp, #100
	bl	_nvm_v2_u32
	stur	w0, [x29, #-88]
	cbnz	w0, LBB11_35
	b	LBB11_33
LBB11_33:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	add	x1, sp, #98
	bl	_nvm_v2_u16
	stur	w0, [x29, #-88]
	cbnz	w0, LBB11_35
	b	LBB11_34
LBB11_34:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	add	x1, sp, #96
	bl	_nvm_v2_u16
	stur	w0, [x29, #-88]
	cbz	w0, LBB11_36
	b	LBB11_35
LBB11_35:
	ldur	w8, [x29, #-88]
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_36:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #100]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB11_39
	b	LBB11_37
LBB11_37:                               ;   in Loop: Header=BB11_31 Depth=2
	ldrh	w8, [sp, #98]
	ldr	w9, [sp, #108]
	subs	w8, w8, w9
	b.ne	LBB11_39
	b	LBB11_38
LBB11_38:                               ;   in Loop: Header=BB11_31 Depth=2
	ldrh	w8, [sp, #96]
	ldr	x9, [sp, #120]
	ldrh	w9, [x9, #2]
	ldrh	w10, [sp, #98]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.le	LBB11_40
	b	LBB11_39
LBB11_39:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_40:                               ;   in Loop: Header=BB11_31 Depth=2
	strh	wzr, [sp, #94]
	b	LBB11_41
LBB11_41:                               ;   Parent Loop BB11_6 Depth=1
                                        ;     Parent Loop BB11_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [sp, #94]
	ldrh	w9, [sp, #106]
	subs	w8, w8, w9
	b.ge	LBB11_49
	b	LBB11_42
LBB11_42:                               ;   in Loop: Header=BB11_41 Depth=3
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #112]
	ldrh	w10, [sp, #94]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #3
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	x9, [x9, #48]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB11_44
	b	LBB11_43
LBB11_43:                               ;   in Loop: Header=BB11_41 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #80]
	subs	x8, x8, x9
	subs	x8, x8, #4
	b.hs	LBB11_45
	b	LBB11_44
LBB11_44:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_45:                               ;   in Loop: Header=BB11_41 Depth=3
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #48]
	ldr	x8, [x8]
	ldr	x10, [sp, #80]
	ldrb	w8, [x8, x10]
	ldr	x10, [x9, #48]
	ldr	x10, [x10]
	ldr	x11, [sp, #80]
	add	x11, x11, #1
	ldrb	w10, [x10, x11]
	orr	w8, w8, w10, lsl #8
	ldr	x10, [x9, #48]
	ldr	x10, [x10]
	ldr	x11, [sp, #80]
	add	x11, x11, #2
	ldrb	w10, [x10, x11]
	orr	w8, w8, w10, lsl #16
	ldr	x9, [x9, #48]
	ldr	x9, [x9]
	ldr	x10, [sp, #80]
	add	x10, x10, #3
	ldrb	w9, [x9, x10]
	orr	w8, w8, w9, lsl #24
	str	w8, [sp, #76]
	ldr	w8, [sp, #76]
	ldr	w9, [sp, #100]
	subs	w8, w8, w9
	b.ne	LBB11_47
	b	LBB11_46
LBB11_46:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_47:                               ;   in Loop: Header=BB11_41 Depth=3
	b	LBB11_48
LBB11_48:                               ;   in Loop: Header=BB11_41 Depth=3
	ldrh	w8, [sp, #94]
	add	w8, w8, #1
	strh	w8, [sp, #94]
	b	LBB11_41
LBB11_49:                               ;   in Loop: Header=BB11_31 Depth=2
	strh	wzr, [sp, #74]
	b	LBB11_50
LBB11_50:                               ;   Parent Loop BB11_6 Depth=1
                                        ;     Parent Loop BB11_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [sp, #74]
	ldrh	w9, [sp, #96]
	subs	w8, w8, w9
	b.ge	LBB11_69
	b	LBB11_51
LBB11_51:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #120]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #98]
	ldrh	w9, [sp, #74]
	add	w8, w8, w9
	mov	w9, #12                         ; =0xc
	smaddl	x8, w8, w9, x10
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldrb	w0, [x8]
	bl	_scalar
	tbnz	w0, #0, LBB11_53
	b	LBB11_52
LBB11_52:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldrb	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB11_54
	b	LBB11_53
LBB11_53:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_54
LBB11_54:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	mov	w10, #1                         ; =0x1
	and	w9, w9, w10
	strb	w9, [sp, #63]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-124]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_63
	b	LBB11_55
LBB11_55:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldr	w9, [x8, #4]
	ldur	w10, [x29, #-124]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.hs	LBB11_63
	b	LBB11_56
LBB11_56:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_63
	b	LBB11_57
LBB11_57:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB11_59
	b	LBB11_58
LBB11_58:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB11_62
	b	LBB11_59
LBB11_59:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldrb	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB11_61
	b	LBB11_60
LBB11_60:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB11_61
LBB11_61:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB11_62
LBB11_62:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB11_63
LBB11_63:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #62]
	ldrb	w8, [sp, #63]
	tbnz	w8, #0, LBB11_65
	b	LBB11_64
LBB11_64:                               ;   in Loop: Header=BB11_50 Depth=3
	ldrb	w8, [sp, #62]
	tbz	w8, #0, LBB11_66
	b	LBB11_65
LBB11_65:                               ;   in Loop: Header=BB11_50 Depth=3
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.ne	LBB11_67
	b	LBB11_66
LBB11_66:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_67:                               ;   in Loop: Header=BB11_50 Depth=3
	b	LBB11_68
LBB11_68:                               ;   in Loop: Header=BB11_50 Depth=3
	ldrh	w8, [sp, #74]
	add	w8, w8, #1
	strh	w8, [sp, #74]
	b	LBB11_50
LBB11_69:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB11_72
	b	LBB11_70
LBB11_70:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB11_72
	b	LBB11_71
LBB11_71:                               ;   in Loop: Header=BB11_31 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x10, [x8, #16]
	ldur	w8, [x29, #-116]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldur	w8, [x29, #-124]
	str	w8, [sp, #48]
	ldr	w8, [sp, #100]
	str	w8, [sp, #52]
	ldrh	w8, [sp, #98]
	strh	w8, [sp, #56]
	ldrh	w8, [sp, #96]
	strh	w8, [sp, #58]
	ldr	x8, [sp, #48]
	str	x8, [x9]
	ldr	w8, [sp, #56]
	str	w8, [x9, #8]
	b	LBB11_72
LBB11_72:                               ;   in Loop: Header=BB11_31 Depth=2
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	ldur	w8, [x29, #-120]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.ne	LBB11_75
	b	LBB11_73
LBB11_73:                               ;   in Loop: Header=BB11_31 Depth=2
	ldrh	w8, [sp, #106]
	ldurh	w9, [x29, #-62]
	subs	w8, w8, w9
	b.ne	LBB11_75
	b	LBB11_74
LBB11_74:                               ;   in Loop: Header=BB11_31 Depth=2
	ldur	w8, [x29, #-124]
	str	w8, [sp, #36]
	ldr	w8, [sp, #100]
	str	w8, [sp, #40]
	ldrh	w8, [sp, #98]
	strh	w8, [sp, #44]
	ldrh	w8, [sp, #96]
	strh	w8, [sp, #46]
	ldur	x8, [sp, #36]
	stur	x8, [x29, #-104]
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-96]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-105]
	b	LBB11_75
LBB11_75:                               ;   in Loop: Header=BB11_31 Depth=2
	ldrh	w8, [sp, #98]
	ldrh	w9, [sp, #96]
	add	w8, w8, w9
	str	w8, [sp, #108]
	b	LBB11_76
LBB11_76:                               ;   in Loop: Header=BB11_31 Depth=2
	ldrh	w8, [sp, #106]
	add	w8, w8, #1
	strh	w8, [sp, #106]
	b	LBB11_31
LBB11_77:                               ;   in Loop: Header=BB11_6 Depth=1
	ldr	w8, [sp, #108]
	ldr	x9, [sp, #120]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.eq	LBB11_79
	b	LBB11_78
LBB11_78:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_79:                               ;   in Loop: Header=BB11_6 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB11_80
LBB11_80:                               ;   in Loop: Header=BB11_6 Depth=1
	ldur	w8, [x29, #-120]
	add	w8, w8, #1
	stur	w8, [x29, #-120]
	b	LBB11_6
LBB11_81:
	b	LBB11_82
LBB11_82:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-112]
	ldr	x9, [x9, #32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB11_86
	b	LBB11_83
LBB11_83:                               ;   in Loop: Header=BB11_82 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB11_85
	b	LBB11_84
LBB11_84:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_85:                               ;   in Loop: Header=BB11_82 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB11_82
LBB11_86:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #48]
	ldr	x8, [x8, #16]
	ldr	x9, [x9, #48]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB11_88
	b	LBB11_87
LBB11_87:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_88:
	ldur	w8, [x29, #-60]
	adds	w8, w8, #1
	b.eq	LBB11_91
	b	LBB11_89
LBB11_89:
	ldurb	w8, [x29, #-105]
	tbnz	w8, #0, LBB11_91
	b	LBB11_90
LBB11_90:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB11_97
LBB11_91:
	ldurb	w8, [x29, #-105]
	tbz	w8, #0, LBB11_94
	b	LBB11_92
LBB11_92:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB11_94
	b	LBB11_93
LBB11_93:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	ldur	x8, [x29, #-104]
	str	x8, [x9]
	ldur	w8, [x29, #-96]
	str	w8, [x9, #8]
	b	LBB11_94
LBB11_94:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB11_96
	b	LBB11_95
LBB11_95:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-116]
	ldr	x9, [x9]
	str	w8, [x9, #28]
	b	LBB11_96
LBB11_96:
	stur	wzr, [x29, #-20]
	b	LBB11_97
LBB11_97:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_layout_authority ; -- Begin function nvm_ownership_layout_authority
	.p2align	2
_nvm_ownership_layout_authority:        ; @nvm_ownership_layout_authority
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB12_3
	b	LBB12_1
LBB12_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB12_3
	b	LBB12_2
LBB12_2:
	ldur	w8, [x29, #-20]
	adds	w8, w8, #1
	b.ne	LBB12_4
	b	LBB12_3
LBB12_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_17
LBB12_4:
	ldur	x0, [x29, #-16]
	sub	x1, x29, #33
	bl	_nvm_ownership_contracts_validate
	stur	w0, [x29, #-40]
	ldur	w8, [x29, #-40]
	cbz	w8, LBB12_6
	b	LBB12_5
LBB12_5:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB12_17
LBB12_6:
	stur	wzr, [x29, #-44]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbz	w8, LBB12_16
	b	LBB12_7
LBB12_7:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #24
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	x1, sp, #20
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbnz	w0, LBB12_10
	b	LBB12_8
LBB12_8:
	add	x0, sp, #24
	add	x1, sp, #16
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbnz	w0, LBB12_10
	b	LBB12_9
LBB12_9:
	ldr	w8, [sp, #16]
	mov	x1, x8
	add	x0, sp, #24
	add	x2, sp, #8
	bl	_nvm_v2_take
	stur	w0, [x29, #-40]
	cbz	w0, LBB12_11
	b	LBB12_10
LBB12_10:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB12_17
LBB12_11:
	ldur	w8, [x29, #-20]
	ldr	w9, [sp, #16]
	subs	w8, w8, w9
	b.lo	LBB12_13
	b	LBB12_12
LBB12_12:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB12_17
LBB12_13:
	ldr	x8, [sp, #8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB12_15
	b	LBB12_14
LBB12_14:
	ldr	x8, [sp, #8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w9, [x8, x9]
	mov	w8, #2                          ; =0x2
	ands	w9, w9, #0x2
	csinc	w8, w8, wzr, ne
	stur	w8, [x29, #-44]
	b	LBB12_15
LBB12_15:
	b	LBB12_16
LBB12_16:
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-32]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB12_17
LBB12_17:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_layout_authorities ; -- Begin function nvm_ownership_layout_authorities
	.p2align	2
_nvm_ownership_layout_authorities:      ; @nvm_ownership_layout_authorities
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_3
	b	LBB13_1
LBB13_1:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB13_4
	b	LBB13_2
LBB13_2:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB13_4
	b	LBB13_3
LBB13_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB13_24
LBB13_4:
	ldur	x0, [x29, #-16]
	sub	x1, x29, #33
	bl	_nvm_ownership_contracts_validate
	stur	w0, [x29, #-40]
	ldur	w8, [x29, #-40]
	cbz	w8, LBB13_6
	b	LBB13_5
LBB13_5:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB13_24
LBB13_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-48]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbz	w8, LBB13_15
	b	LBB13_7
LBB13_7:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #40
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #36
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbnz	w0, LBB13_9
	b	LBB13_8
LBB13_8:
	add	x0, sp, #40
	add	x1, sp, #32
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbz	w0, LBB13_10
	b	LBB13_9
LBB13_9:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB13_24
LBB13_10:
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.eq	LBB13_12
	b	LBB13_11
LBB13_11:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB13_24
LBB13_12:
	ldur	w8, [x29, #-20]
	mov	x1, x8
	add	x0, sp, #40
	sub	x2, x29, #48
	bl	_nvm_v2_take
	stur	w0, [x29, #-40]
	cbz	w0, LBB13_14
	b	LBB13_13
LBB13_13:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB13_24
LBB13_14:
	b	LBB13_15
LBB13_15:
	str	wzr, [sp, #28]
	b	LBB13_16
LBB13_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB13_23
	b	LBB13_17
LBB13_17:                               ;   in Loop: Header=BB13_16 Depth=1
	ldur	x8, [x29, #-48]
	cbz	x8, LBB13_20
	b	LBB13_18
LBB13_18:                               ;   in Loop: Header=BB13_16 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB13_20
	b	LBB13_19
LBB13_19:                               ;   in Loop: Header=BB13_16 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldrb	w9, [x8, x9]
	mov	w8, #2                          ; =0x2
	ands	w9, w9, #0x2
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_21
LBB13_20:                               ;   in Loop: Header=BB13_16 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB13_21
LBB13_21:                               ;   in Loop: Header=BB13_16 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldur	x9, [x29, #-32]
	ldr	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	b	LBB13_22
LBB13_22:                               ;   in Loop: Header=BB13_16 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB13_16
LBB13_23:
	stur	wzr, [x29, #-4]
	b	LBB13_24
LBB13_24:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ordinary_array_authority_free ; -- Begin function nvm_ordinary_array_authority_free
	.p2align	2
_nvm_ordinary_array_authority_free:     ; @nvm_ordinary_array_authority_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	b	LBB14_3
LBB14_2:
	ldr	x0, [sp, #8]
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB14_3
LBB14_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ordinary_array_authority_counts ; -- Begin function nvm_ordinary_array_authority_counts
	.p2align	2
_nvm_ordinary_array_authority_counts:   ; @nvm_ordinary_array_authority_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB15_4
LBB15_3:
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	str	w8, [sp, #12]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #288]
	str	w8, [sp, #16]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #292]
	str	w8, [sp, #20]
	ldur	x8, [sp, #12]
	str	x8, [x9]
	ldr	w8, [sp, #20]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB15_4
LBB15_4:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ordinary_array_authority_type ; -- Begin function nvm_ordinary_array_authority_type
	.p2align	2
_nvm_ordinary_array_authority_type:     ; @nvm_ordinary_array_authority_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB16_3
	b	LBB16_1
LBB16_1:
	ldr	x8, [sp]
	cbz	x8, LBB16_3
	b	LBB16_2
LBB16_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.lo	LBB16_4
	b	LBB16_3
LBB16_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB16_5
LBB16_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB16_5
LBB16_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ordinary_array_authority_binding ; -- Begin function nvm_ordinary_array_authority_binding
	.p2align	2
_nvm_ordinary_array_authority_binding:  ; @nvm_ordinary_array_authority_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB17_3
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp]
	cbz	x8, LBB17_3
	b	LBB17_2
LBB17_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #292]
	subs	w8, w8, w9
	b.lo	LBB17_4
	b	LBB17_3
LBB17_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_5
LBB17_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x11, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_5
LBB17_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_describe_ordinary_array_authority ; -- Begin function nvm_describe_ordinary_array_authority
	.p2align	2
_nvm_describe_ordinary_array_authority: ; @nvm_describe_ordinary_array_authority
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	bl	_oaa_prepare
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_prepare
_oaa_prepare:                           ; @oaa_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	x3, #0                          ; =0x0
	bl	_oaa_prepare_map
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_free ; -- Begin function nvm_ownership_declarations_free
	.p2align	2
_nvm_ownership_declarations_free:       ; @nvm_ownership_declarations_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB20_2
	b	LBB20_1
LBB20_1:
	b	LBB20_3
LBB20_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_ordinary_array_authority_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB20_3
LBB20_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_prepare_ownership_declarations ; -- Begin function nvm_prepare_ownership_declarations
	.p2align	2
_nvm_prepare_ownership_declarations:    ; @nvm_prepare_ownership_declarations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	bl	_prepare_ownership_declarations_map
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function prepare_ownership_declarations_map
_prepare_ownership_declarations_map:    ; @prepare_ownership_declarations_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #112
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x8, #72]
	str	x1, [x8, #64]
	str	x2, [x8, #56]
	ldr	x8, [x8, #64]
	cbnz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	mov	w0, #2                          ; =0x2
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_2:
	sub	x0, x29, #112
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	sub	x1, x29, #120
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-120]
	ldr	x0, [x8, #72]
	ldr	x3, [x8, #56]
	add	x8, sp, #112
	bl	_oaa_prepare_map
	ldr	w8, [sp, #112]
	cbz	w8, LBB22_10
	b	LBB22_3
LBB22_3:
	ldr	w8, [sp, #112]
	subs	w8, w8, #1
	b.ne	LBB22_5
	b	LBB22_4
LBB22_4:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB22_9
LBB22_5:
	ldr	w8, [sp, #112]
	subs	w8, w8, #3
	b.ne	LBB22_7
	b	LBB22_6
LBB22_6:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB22_8
LBB22_7:
	ldr	w10, [sp, #112]
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #4
	csel	w8, w8, w9, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB22_8
LBB22_8:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB22_9
LBB22_9:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #108]
	ldr	w0, [sp, #108]
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_10:
	ldur	x8, [x29, #-120]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #4
	add	x8, x8, #312
	str	x8, [sp, #96]
	str	wzr, [sp, #92]
	b	LBB22_11
LBB22_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #92]
	ldur	x9, [x29, #-120]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB22_14
	b	LBB22_12
LBB22_12:                               ;   in Loop: Header=BB22_11 Depth=1
	ldur	x8, [x29, #-120]
	ldr	x8, [x8]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	ldr	x10, [sp, #96]
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #96]
	b	LBB22_13
LBB22_13:                               ;   in Loop: Header=BB22_11 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB22_11
LBB22_14:
	ldur	x8, [x29, #-120]
	ldr	w8, [x8, #288]
	mov	x9, x8
	ldr	x8, [sp, #96]
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #96]
	ldur	x8, [x29, #-120]
	ldr	w8, [x8, #292]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	ldr	x11, [sp, #96]
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #96]
	ldur	w8, [x29, #-84]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w9
	str	x8, [sp, #80]
	ldur	w8, [x29, #-84]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hi	LBB22_18
	b	LBB22_15
LBB22_15:
	ldr	x8, [sp, #96]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hi	LBB22_18
	b	LBB22_16
LBB22_16:
	ldr	x9, [sp, #96]
	mov	x8, #16777216                   ; =0x1000000
	subs	x9, x8, x9
	mov	x8, #1560                       ; =0x618
	subs	x8, x8, x9
	b.hi	LBB22_18
	b	LBB22_17
LBB22_17:
	ldr	x8, [sp, #80]
	ldr	x10, [sp, #96]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x9, x9, #1560
	subs	x8, x8, x9
	b.ls	LBB22_19
	b	LBB22_18
LBB22_18:
	ldur	x0, [x29, #-120]
	bl	_nvm_ordinary_array_authority_free
	mov	w0, #3                          ; =0x3
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_19:
	mov	x0, #1                          ; =0x1
	mov	x1, #1560                       ; =0x618
	bl	_calloc
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbnz	x8, LBB22_21
	b	LBB22_20
LBB22_20:
	ldur	x0, [x29, #-120]
	bl	_nvm_ordinary_array_authority_free
	mov	w0, #4                          ; =0x4
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-120]
	ldr	x10, [sp, #72]
	str	x9, [x10]
	ldr	x8, [x8, #72]
	ldr	w8, [x8, #476]
	ldr	x9, [sp, #72]
	str	w8, [x9, #16]
	ldur	w8, [x29, #-84]
	ldr	x9, [sp, #72]
	str	w8, [x9, #20]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #20]
	cbz	w8, LBB22_28
	b	LBB22_22
LBB22_22:
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #20]
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	bl	_calloc
	ldr	x8, [sp, #72]
	str	x0, [x8, #8]
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB22_24
	b	LBB22_23
LBB22_23:
	ldr	x0, [sp, #72]
	bl	_nvm_ownership_declarations_free
	mov	w0, #4                          ; =0x4
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_24:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #8]
	sub	x10, x29, #112
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	stur	x8, [x29, #-96]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #20]
	stur	w8, [x29, #-88]
	ldr	x8, [sp, #72]
	add	x8, x8, #24
	str	x8, [x9, #32]
	ldr	x8, [sp, #72]
	add	x8, x8, #1048
	str	x8, [x9, #40]
	ldur	x1, [x29, #-112]
	ldur	w8, [x29, #-104]
	mov	x2, x8
	add	x0, sp, #48
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x7, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [x8, #72]
	ldur	x2, [x29, #-120]
	ldur	x8, [x29, #-120]
	add	x3, x8, #32
	mov	w4, #-1                         ; =0xffffffff
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_union_facts_read
	str	w0, [sp, #44]
	ldr	w8, [sp, #44]
	cbnz	w8, LBB22_26
	b	LBB22_25
LBB22_25:
	ldur	w8, [x29, #-84]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.eq	LBB22_27
	b	LBB22_26
LBB22_26:
	ldr	x0, [sp, #72]
	bl	_nvm_ownership_declarations_free
	mov	w0, #2                          ; =0x2
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_27:
	b	LBB22_28
LBB22_28:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	ldr	x9, [x9, #64]
	str	x8, [x9]
	mov	w0, #0                          ; =0x0
	bl	_declaration_result
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	b	LBB22_29
LBB22_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #80]
	ldr	x1, [x8, #88]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_counts ; -- Begin function nvm_ownership_declarations_counts
	.p2align	2
_nvm_ownership_declarations_counts:     ; @nvm_ownership_declarations_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB23_3
	b	LBB23_2
LBB23_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB23_4
LBB23_3:
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w8, [x8, #8]
	str	w8, [sp, #4]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w8, [x8, #288]
	str	w8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w8, [x8, #292]
	str	w8, [sp, #12]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	str	w8, [sp, #16]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #20]
	str	w8, [sp, #20]
	ldur	q0, [sp, #4]
	str	q0, [x9]
	ldr	w8, [sp, #20]
	str	w8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB23_4
LBB23_4:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_layout ; -- Begin function nvm_ownership_declarations_layout
	.p2align	2
_nvm_ownership_declarations_layout:     ; @nvm_ownership_declarations_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	str	x2, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB24_3
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB24_3
	b	LBB24_2
LBB24_2:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #32]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB24_4
	b	LBB24_3
LBB24_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB24_5
LBB24_4:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	strb	w8, [sp]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	add	x8, x8, #32
	ldr	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10
	ldrb	w8, [x8]
	strb	w8, [sp, #1]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	strh	w8, [sp, #2]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB24_5
LBB24_5:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_field ; -- Begin function nvm_ownership_declarations_field
	.p2align	2
_nvm_ownership_declarations_field:      ; @nvm_ownership_declarations_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB25_4
	b	LBB25_1
LBB25_1:
	ldr	x8, [sp]
	cbz	x8, LBB25_4
	b	LBB25_2
LBB25_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB25_4
	b	LBB25_3
LBB25_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB25_5
	b	LBB25_4
LBB25_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB25_6
LBB25_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #4
	ldr	x11, [x8, #8]
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB25_6
LBB25_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_type ; -- Begin function nvm_ownership_declarations_type
	.p2align	2
_nvm_ownership_declarations_type:       ; @nvm_ownership_declarations_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB26_2
	b	LBB26_1
LBB26_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_ordinary_array_authority_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB26_2
LBB26_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_binding ; -- Begin function nvm_ownership_declarations_binding
	.p2align	2
_nvm_ownership_declarations_binding:    ; @nvm_ownership_declarations_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB27_2
	b	LBB27_1
LBB27_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_ordinary_array_authority_binding
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB27_2
LBB27_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_variant ; -- Begin function nvm_ownership_declarations_variant
	.p2align	2
_nvm_ownership_declarations_variant:    ; @nvm_ownership_declarations_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB28_4
	b	LBB28_1
LBB28_1:
	ldr	x8, [sp]
	cbz	x8, LBB28_4
	b	LBB28_2
LBB28_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB28_4
	b	LBB28_3
LBB28_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	add	x9, x9, #1048
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.lt	LBB28_5
	b	LBB28_4
LBB28_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB28_6
LBB28_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x11, [x8, #8]
	ldr	x8, [sp, #16]
	add	x8, x8, #24
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	ldrh	w10, [sp, #10]
	add	w8, w8, w10
	mov	w10, #12                        ; =0xc
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB28_6
LBB28_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_ownership_declarations_retained_cost ; -- Begin function nvm_ownership_declarations_retained_cost
	.p2align	2
_nvm_ownership_declarations_retained_cost: ; @nvm_ownership_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x0, [x29, #-24]
	mov	x1, #16                         ; =0x10
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB29_2
	b	LBB29_1
LBB29_1:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_2:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB29_7
	b	LBB29_3
LBB29_3:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB29_7
	b	LBB29_4
LBB29_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	cbz	x8, LBB29_7
	b	LBB29_5
LBB29_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #16]
	subs	w8, w8, #256
	b.hi	LBB29_7
	b	LBB29_6
LBB29_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #20]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB29_8
	b	LBB29_7
LBB29_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	subs	w8, w8, #256
	b.hi	LBB29_11
	b	LBB29_9
LBB29_9:
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #288]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.hi	LBB29_11
	b	LBB29_10
LBB29_10:
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #292]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB29_12
	b	LBB29_11
LBB29_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_12:
	str	xzr, [sp, #32]
	b	LBB29_13
LBB29_13:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	mov	x2, #1                          ; =0x1
	mov	x3, #1560                       ; =0x618
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_15
	b	LBB29_14
LBB29_14:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_15:
	b	LBB29_16
LBB29_16:
	b	LBB29_17
LBB29_17:
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #40]
	mov	x2, #1                          ; =0x1
	mov	x3, #312                        ; =0x138
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_19
	b	LBB29_18
LBB29_18:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_19:
	b	LBB29_20
LBB29_20:
	b	LBB29_21
LBB29_21:
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	x1, [x8]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	mov	x2, x8
	mov	x3, #16                         ; =0x10
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_23
	b	LBB29_22
LBB29_22:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_23:
	b	LBB29_24
LBB29_24:
	b	LBB29_25
LBB29_25:
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #20]
	mov	x2, x8
	mov	x3, #12                         ; =0xc
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_27
	b	LBB29_26
LBB29_26:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_27:
	b	LBB29_28
LBB29_28:
	b	LBB29_29
LBB29_29:
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	x1, [x8, #16]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #288]
	mov	x2, x8
	mov	x3, #8                          ; =0x8
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_31
	b	LBB29_30
LBB29_30:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_31:
	b	LBB29_32
LBB29_32:
	b	LBB29_33
LBB29_33:
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #40]
	ldr	x1, [x8, #24]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #292]
	mov	x2, x8
	mov	x3, #12                         ; =0xc
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_35
	b	LBB29_34
LBB29_34:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_35:
	b	LBB29_36
LBB29_36:
	str	wzr, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB29_37
LBB29_37:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB29_48
	b	LBB29_38
LBB29_38:                               ;   in Loop: Header=BB29_37 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #8                          ; =0x8
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB29_40
	b	LBB29_39
LBB29_39:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_40:                               ;   in Loop: Header=BB29_37 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	ldr	w10, [sp, #24]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB29_42
	b	LBB29_41
LBB29_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_42:                               ;   in Loop: Header=BB29_37 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w9, [x8, #2]
	ldr	w8, [sp, #24]
	add	w8, w8, w9
	str	w8, [sp, #24]
	b	LBB29_43
LBB29_43:                               ;   in Loop: Header=BB29_37 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #8]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	mov	x2, x8
	mov	x3, #12                         ; =0xc
	add	x4, sp, #32
	bl	_nvm_map_copy_term
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB29_45
	b	LBB29_44
LBB29_44:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB29_49
LBB29_45:                               ;   in Loop: Header=BB29_37 Depth=1
	b	LBB29_46
LBB29_46:                               ;   in Loop: Header=BB29_37 Depth=1
	b	LBB29_47
LBB29_47:                               ;   in Loop: Header=BB29_37 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB29_37
LBB29_48:
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB29_49
LBB29_49:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_map_copy_charge
_nvm_map_copy_charge:                   ; @nvm_map_copy_charge
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB30_2
	b	LBB30_1
LBB30_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB30_7
LBB30_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB30_5
	b	LBB30_3
LBB30_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.hi	LBB30_5
	b	LBB30_4
LBB30_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	ldr	x10, [sp, #16]
	ldr	x10, [x10]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB30_6
	b	LBB30_5
LBB30_5:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #16]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB30_7
LBB30_6:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB30_7
LBB30_7:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_map_copy_term
_nvm_map_copy_term:                     ; @nvm_map_copy_term
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	str	x4, [sp]
	ldur	x0, [x29, #-16]
	mov	x1, #4                          ; =0x4
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB31_2
	b	LBB31_1
LBB31_1:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB31_9
LBB31_2:
	ldr	x8, [sp, #24]
	subs	x8, x8, #0
	cset	w8, ne
	ldr	x9, [sp, #16]
	subs	x9, x9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.ne	LBB31_4
	b	LBB31_3
LBB31_3:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB31_5
	b	LBB31_4
LBB31_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB31_9
LBB31_5:
	ldr	x8, [sp, #16]
	ldr	x10, [sp, #8]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB31_7
	b	LBB31_6
LBB31_6:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	mul	x8, x8, x9
	ldr	x9, [sp]
	ldr	x10, [x9]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB31_8
	b	LBB31_7
LBB31_7:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB31_9
LBB31_8:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	mul	x10, x8, x9
	ldr	x9, [sp]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB31_9
LBB31_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_free      ; -- Begin function nvm_map_declarations_free
	.p2align	2
_nvm_map_declarations_free:             ; @nvm_map_declarations_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB32_2
	b	LBB32_1
LBB32_1:
	b	LBB32_3
LBB32_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_ownership_declarations_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB32_3
LBB32_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_prepare_map_declarations   ; -- Begin function nvm_prepare_map_declarations
	.p2align	2
_nvm_prepare_map_declarations:          ; @nvm_prepare_map_declarations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB33_2
	b	LBB33_1
LBB33_1:
	mov	w0, #2                          ; =0x2
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB33_17
LBB33_2:
	add	x1, sp, #40
	str	xzr, [sp, #40]
	ldur	x0, [x29, #-24]
	bl	_map_route
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	subs	w8, w8, #1
	b.eq	LBB33_7
	b	LBB33_3
LBB33_3:
	ldr	w8, [sp, #36]
	cbnz	w8, LBB33_5
	b	LBB33_4
LBB33_4:
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB33_6
LBB33_5:
	ldr	w10, [sp, #36]
	mov	w8, #3                          ; =0x3
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #3
	csel	w8, w8, w9, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB33_6
LBB33_6:
	ldr	w0, [sp]                        ; 4-byte Folded Reload
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB33_17
LBB33_7:
	mov	x0, #1                          ; =0x1
	mov	x1, #80                         ; =0x50
	bl	_calloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB33_9
	b	LBB33_8
LBB33_8:
	mov	w0, #4                          ; =0x4
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB33_17
LBB33_9:
	ldr	x9, [sp, #24]
	mov	x8, #80                         ; =0x50
	str	x8, [x9, #56]
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #24]
	str	x8, [x9, #64]
	ldr	x9, [sp, #24]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #72]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #24]
	bl	_prepare_ownership_declarations_map
	str	x0, [sp, #8]
	str	x1, [sp, #16]
	ldr	w8, [sp, #8]
	cbz	w8, LBB33_16
	b	LBB33_10
LBB33_10:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #72]
	str	w8, [sp, #4]
	ldr	w8, [sp, #8]
	subs	w8, w8, #4
	b.ne	LBB33_12
	b	LBB33_11
LBB33_11:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #4]
	b	LBB33_15
LBB33_12:
	ldr	w8, [sp, #8]
	subs	w8, w8, #3
	b.ne	LBB33_14
	b	LBB33_13
LBB33_13:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #4]
	b	LBB33_14
LBB33_14:
	b	LBB33_15
LBB33_15:
	ldr	x0, [sp, #24]
	bl	_nvm_map_declarations_free
	ldr	w0, [sp, #4]
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB33_17
LBB33_16:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	mov	w0, #1                          ; =0x1
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB33_17
LBB33_17:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_result
_map_result:                            ; @map_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #12]
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp]
	ldr	w8, [sp, #12]
	cbnz	w8, LBB34_2
	b	LBB34_1
LBB34_1:
	adrp	x8, l_.str.10@PAGE
	add	x8, x8, l_.str.10@PAGEOFF
	str	x8, [sp]
	b	LBB34_11
LBB34_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.ne	LBB34_4
	b	LBB34_3
LBB34_3:
	adrp	x8, l_.str.11@PAGE
	add	x8, x8, l_.str.11@PAGEOFF
	str	x8, [sp]
	b	LBB34_10
LBB34_4:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	b.ne	LBB34_6
	b	LBB34_5
LBB34_5:
	adrp	x8, l_.str.12@PAGE
	add	x8, x8, l_.str.12@PAGEOFF
	str	x8, [sp]
	b	LBB34_9
LBB34_6:
	ldr	w8, [sp, #12]
	subs	w8, w8, #4
	b.ne	LBB34_8
	b	LBB34_7
LBB34_7:
	adrp	x8, l_.str.13@PAGE
	add	x8, x8, l_.str.13@PAGEOFF
	str	x8, [sp]
	b	LBB34_8
LBB34_8:
	b	LBB34_9
LBB34_9:
	b	LBB34_10
LBB34_10:
	b	LBB34_11
LBB34_11:
	ldr	w8, [sp, #12]
	str	w8, [sp, #16]
	str	wzr, [sp, #20]
	ldr	x8, [sp]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_route
_map_route:                             ; @map_route
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #88
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x0, [x8, #56]
	str	x1, [x8, #48]
	ldr	x8, [x8, #56]
	cbz	x8, LBB35_3
	b	LBB35_1
LBB35_1:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #56]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [x9, #56]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB35_3
	b	LBB35_2
LBB35_2:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #56]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [x9, #56]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB35_4
	b	LBB35_3
LBB35_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB35_7
	b	LBB35_5
LBB35_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB35_7
	b	LBB35_6
LBB35_6:
	stur	wzr, [x29, #-20]
	b	LBB35_103
LBB35_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #320]
	cbz	w8, LBB35_9
	b	LBB35_8
LBB35_8:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB35_10
	b	LBB35_9
LBB35_9:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_10:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #320]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.hi	LBB35_12
	b	LBB35_11
LBB35_11:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB35_13
	b	LBB35_12
LBB35_12:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_13:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #56]
	ldr	w9, [x9, #320]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [x8, #56]
	ldr	w10, [x10, #304]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	ldr	x10, [x8, #48]
	str	x9, [x10]
	ldr	x8, [x8, #48]
	ldr	x8, [x8]
	subs	x8, x8, #1024, lsl #12          ; =4194304
	b.ls	LBB35_15
	b	LBB35_14
LBB35_14:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	sturb	wzr, [x29, #-41]
	stur	wzr, [x29, #-80]
	ldr	x9, [x8, #56]
	ldr	x1, [x9, #312]
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #72
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	sub	x1, x29, #76
	bl	_nvm_v2_u32
	cbz	w0, LBB35_17
	b	LBB35_16
LBB35_16:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_17:
	ldur	w8, [x29, #-76]
	subs	w8, w8, #256
	b.ls	LBB35_19
	b	LBB35_18
LBB35_18:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_19:
	stur	wzr, [x29, #-92]
	b	LBB35_20
LBB35_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_29 Depth 2
	ldur	w8, [x29, #-92]
	ldur	w9, [x29, #-76]
	subs	w8, w8, w9
	b.hs	LBB35_41
	b	LBB35_21
LBB35_21:                               ;   in Loop: Header=BB35_20 Depth=1
	sub	x0, x29, #72
	mov	x1, #8                          ; =0x8
	sub	x2, x29, #88
	bl	_nvm_v2_take
	cbz	w0, LBB35_23
	b	LBB35_22
LBB35_22:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_23:                               ;   in Loop: Header=BB35_20 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldrb	w9, [x9, #2]
	ldr	x10, [x8]
	ldrb	w10, [x10, #3]
	orr	w9, w9, w10, lsl #8
	sturh	w9, [x29, #-94]
	ldr	x8, [x8]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB35_25
	b	LBB35_24
LBB35_24:                               ;   in Loop: Header=BB35_20 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8]
	subs	w8, w8, #3
	b.le	LBB35_26
	b	LBB35_25
LBB35_25:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_26:                               ;   in Loop: Header=BB35_20 Depth=1
	ldurh	w8, [x29, #-94]
	ldur	w10, [x29, #-80]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB35_28
	b	LBB35_27
LBB35_27:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_28:                               ;   in Loop: Header=BB35_20 Depth=1
	ldurh	w9, [x29, #-94]
	ldur	w8, [x29, #-80]
	add	w8, w8, w9
	stur	w8, [x29, #-80]
	sturh	wzr, [x29, #-96]
	b	LBB35_29
LBB35_29:                               ;   Parent Loop BB35_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-96]
	ldurh	w9, [x29, #-94]
	subs	w8, w8, w9
	b.ge	LBB35_39
	b	LBB35_30
LBB35_30:                               ;   in Loop: Header=BB35_29 Depth=2
	sub	x0, x29, #72
	mov	x1, #12                         ; =0xc
	sub	x2, x29, #88
	bl	_nvm_v2_take
	cbz	w0, LBB35_32
	b	LBB35_31
LBB35_31:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_32:                               ;   in Loop: Header=BB35_29 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.ge	LBB35_36
	b	LBB35_33
LBB35_33:                               ;   in Loop: Header=BB35_29 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB35_36
	b	LBB35_34
LBB35_34:                               ;   in Loop: Header=BB35_29 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8, #2]
	cbnz	w8, LBB35_36
	b	LBB35_35
LBB35_35:                               ;   in Loop: Header=BB35_29 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8, #3]
	cbz	w8, LBB35_37
	b	LBB35_36
LBB35_36:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_37:                               ;   in Loop: Header=BB35_29 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrb	w8, [x8]
	subs	w8, w8, #13
	cset	w9, eq
	ldurb	w8, [x29, #-41]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-41]
	b	LBB35_38
LBB35_38:                               ;   in Loop: Header=BB35_29 Depth=2
	ldurh	w8, [x29, #-96]
	add	w8, w8, #1
	sturh	w8, [x29, #-96]
	b	LBB35_29
LBB35_39:                               ;   in Loop: Header=BB35_20 Depth=1
	b	LBB35_40
LBB35_40:                               ;   in Loop: Header=BB35_20 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB35_20
LBB35_41:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #32]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.eq	LBB35_43
	b	LBB35_42
LBB35_42:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_43:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #56]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #56]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #72
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB35_48
	b	LBB35_44
LBB35_44:
	ldur	w0, [x29, #-100]
	bl	_ownership_version
	tbz	w0, #0, LBB35_48
	b	LBB35_45
LBB35_45:
	sub	x0, x29, #72
	sub	x1, x29, #104
	bl	_nvm_v2_u32
	cbnz	w0, LBB35_48
	b	LBB35_46
LBB35_46:
	ldur	w8, [x29, #-104]
	ldur	w9, [x29, #-76]
	subs	w8, w8, w9
	b.ne	LBB35_48
	b	LBB35_47
LBB35_47:
	ldur	w8, [x29, #-104]
	mov	x1, x8
	sub	x0, x29, #72
	sub	x2, x29, #88
	bl	_nvm_v2_take
	cbz	w0, LBB35_49
	b	LBB35_48
LBB35_48:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_49:
	stur	wzr, [x29, #-112]
	b	LBB35_50
LBB35_50:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-112]
	ldur	w9, [x29, #-104]
	subs	w8, w8, w9
	b.hs	LBB35_55
	b	LBB35_51
LBB35_51:                               ;   in Loop: Header=BB35_50 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w8, w8, #0xfffffffc
	cbz	w8, LBB35_53
	b	LBB35_52
LBB35_52:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_53:                               ;   in Loop: Header=BB35_50 Depth=1
	b	LBB35_54
LBB35_54:                               ;   in Loop: Header=BB35_50 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB35_50
LBB35_55:
	sub	x0, x29, #72
	bl	_nvm_v2_align4
	cbnz	w0, LBB35_60
	b	LBB35_56
LBB35_56:
	sub	x0, x29, #72
	sub	x1, x29, #108
	bl	_nvm_v2_u32
	cbnz	w0, LBB35_60
	b	LBB35_57
LBB35_57:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-108]
	ldr	x9, [x9, #56]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB35_60
	b	LBB35_58
LBB35_58:
	ldur	w8, [x29, #-108]
	cbz	w8, LBB35_61
	b	LBB35_59
LBB35_59:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB35_61
	b	LBB35_60
LBB35_60:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_61:
	stur	wzr, [x29, #-116]
	b	LBB35_62
LBB35_62:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_71 Depth 2
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hs	LBB35_81
	b	LBB35_63
LBB35_63:                               ;   in Loop: Header=BB35_62 Depth=1
	sub	x0, x29, #72
	sub	x1, x29, #118
	bl	_nvm_v2_u16
	cbnz	w0, LBB35_69
	b	LBB35_64
LBB35_64:                               ;   in Loop: Header=BB35_62 Depth=1
	sub	x0, x29, #72
	sub	x1, x29, #120
	bl	_nvm_v2_u16
	cbnz	w0, LBB35_69
	b	LBB35_65
LBB35_65:                               ;   in Loop: Header=BB35_62 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-118]
	ldr	x9, [x9, #56]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB35_69
	b	LBB35_66
LBB35_66:                               ;   in Loop: Header=BB35_62 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-120]
	ldr	x9, [x9, #56]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB35_69
	b	LBB35_67
LBB35_67:                               ;   in Loop: Header=BB35_62 Depth=1
	ldurh	w8, [x29, #-120]
	ldurh	w9, [x29, #-118]
	subs	w8, w8, w9
	b.gt	LBB35_69
	b	LBB35_68
LBB35_68:                               ;   in Loop: Header=BB35_62 Depth=1
	ldurh	w8, [x29, #-118]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	sub	x0, x29, #72
	sub	x2, x29, #88
	bl	_nvm_v2_take
	cbz	w0, LBB35_70
	b	LBB35_69
LBB35_69:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_70:                               ;   in Loop: Header=BB35_62 Depth=1
	stur	wzr, [x29, #-124]
	b	LBB35_71
LBB35_71:                               ;   Parent Loop BB35_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-124]
	ldurh	w9, [x29, #-118]
	subs	w8, w8, w9
	b.hi	LBB35_79
	b	LBB35_72
LBB35_72:                               ;   in Loop: Header=BB35_71 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
	lsl	w9, w9, #3
	ldrb	w8, [x8, w9, uxtw]
	subs	w8, w8, #16
	b.ge	LBB35_76
	b	LBB35_73
LBB35_73:                               ;   in Loop: Header=BB35_71 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
	lsl	w9, w9, #3
	add	w9, w9, #1
	ldrb	w8, [x8, w9, uxtw]
	subs	w8, w8, #2
	b.gt	LBB35_76
	b	LBB35_74
LBB35_74:                               ;   in Loop: Header=BB35_71 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
	lsl	w9, w9, #3
	add	w9, w9, #2
	ldrb	w8, [x8, w9, uxtw]
	cbnz	w8, LBB35_76
	b	LBB35_75
LBB35_75:                               ;   in Loop: Header=BB35_71 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-124]
	lsl	w9, w9, #3
	add	w9, w9, #3
	ldrb	w8, [x8, w9, uxtw]
	cbz	w8, LBB35_77
	b	LBB35_76
LBB35_76:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_77:                               ;   in Loop: Header=BB35_71 Depth=2
	b	LBB35_78
LBB35_78:                               ;   in Loop: Header=BB35_71 Depth=2
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	stur	w8, [x29, #-124]
	b	LBB35_71
LBB35_79:                               ;   in Loop: Header=BB35_62 Depth=1
	b	LBB35_80
LBB35_80:                               ;   in Loop: Header=BB35_62 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB35_62
LBB35_81:
	ldur	w8, [x29, #-100]
	subs	w8, w8, #3
	b.ne	LBB35_92
	b	LBB35_82
LBB35_82:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [x8, #16]
	add	x0, sp, #128
	str	q0, [sp, #128]
	ldr	x8, [x8, #32]
	str	x8, [sp, #144]
	add	x1, sp, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB35_85
	b	LBB35_83
LBB35_83:
	ldr	w8, [sp, #124]
	mov	x1, x8
	add	x0, sp, #128
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB35_85
	b	LBB35_84
LBB35_84:
	add	x0, sp, #128
	add	x1, sp, #120
	bl	_nvm_v2_u32
	cbz	w0, LBB35_86
	b	LBB35_85
LBB35_85:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_86:
	ldr	w8, [sp, #120]
	subs	w8, w8, #4
	b.ls	LBB35_88
	b	LBB35_87
LBB35_87:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_88:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8]
	subs	x8, x8, #1024, lsl #12          ; =4194304
	b.hi	LBB35_90
	b	LBB35_89
LBB35_89:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x9, [x8]
	mov	x8, #4194304                    ; =0x400000
	subs	x9, x8, x9
	mov	x8, #8                          ; =0x8
	subs	x8, x8, x9
	b.ls	LBB35_91
	b	LBB35_90
LBB35_90:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_91:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #48]
	ldr	x8, [x9]
	add	x8, x8, #8
	str	x8, [x9]
	b	LBB35_92
LBB35_92:
	str	xzr, [sp, #104]
	str	xzr, [sp, #112]
	add	x0, sp, #40
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	str	wzr, [sp, #36]
	ldur	w8, [x29, #-100]
	subs	w8, w8, #2
	b.ne	LBB35_94
	b	LBB35_93
LBB35_93:
	sub	x0, x29, #72
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_paths_read
	str	w0, [sp, #36]
	b	LBB35_97
LBB35_94:
	ldur	w8, [x29, #-100]
	subs	w8, w8, #3
	b.ne	LBB35_96
	b	LBB35_95
LBB35_95:
	sub	x0, x29, #72
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	add	x5, sp, #40
	add	x6, sp, #104
	bl	_extension_suffix_read_map
	str	w0, [sp, #36]
	b	LBB35_96
LBB35_96:
	b	LBB35_97
LBB35_97:
	ldr	w8, [sp, #36]
	cbnz	w8, LBB35_99
	b	LBB35_98
LBB35_98:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #32]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.eq	LBB35_100
	b	LBB35_99
LBB35_99:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_100:
	ldurb	w8, [x29, #-41]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbnz	w8, #0, LBB35_102
	b	LBB35_101
LBB35_101:
	ldr	x8, [sp, #104]
	subs	x8, x8, #0
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB35_102
LBB35_102:
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	stur	w8, [x29, #-20]
	b	LBB35_103
LBB35_103:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_counts    ; -- Begin function nvm_map_declarations_counts
	.p2align	2
_nvm_map_declarations_counts:           ; @nvm_map_declarations_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB36_2
	b	LBB36_1
LBB36_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB36_3
	b	LBB36_2
LBB36_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_4
LBB36_3:
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #40]
	str	x10, [x9]
	ldr	w8, [x8, #48]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_4
LBB36_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_scalar    ; -- Begin function nvm_map_declarations_scalar
	.p2align	2
_nvm_map_declarations_scalar:           ; @nvm_map_declarations_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB37_3
	b	LBB37_1
LBB37_1:
	ldr	x8, [sp]
	cbz	x8, LBB37_3
	b	LBB37_2
LBB37_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.lo	LBB37_4
	b	LBB37_3
LBB37_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB37_5
LBB37_4:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	ldr	x9, [sp]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB37_5
LBB37_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_pair      ; -- Begin function nvm_map_declarations_pair
	.p2align	2
_nvm_map_declarations_pair:             ; @nvm_map_declarations_pair
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB38_3
	b	LBB38_1
LBB38_1:
	ldr	x8, [sp]
	cbz	x8, LBB38_3
	b	LBB38_2
LBB38_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #44]
	subs	w8, w8, w9
	b.lo	LBB38_4
	b	LBB38_3
LBB38_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB38_5
LBB38_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB38_5
LBB38_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_binding   ; -- Begin function nvm_map_declarations_binding
	.p2align	2
_nvm_map_declarations_binding:          ; @nvm_map_declarations_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB39_3
	b	LBB39_1
LBB39_1:
	ldr	x8, [sp]
	cbz	x8, LBB39_3
	b	LBB39_2
LBB39_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.lo	LBB39_4
	b	LBB39_3
LBB39_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB39_5
LBB39_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x11, [x8, #24]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB39_5
LBB39_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_field     ; -- Begin function nvm_map_declarations_field
	.p2align	2
_nvm_map_declarations_field:            ; @nvm_map_declarations_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	w1, [sp, #44]
	strh	w2, [sp, #42]
	str	x3, [sp, #32]
	ldr	x8, [sp, #48]
	cbz	x8, LBB40_3
	b	LBB40_1
LBB40_1:
	ldr	x8, [sp, #32]
	cbz	x8, LBB40_3
	b	LBB40_2
LBB40_2:
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #52]
	subs	w8, w8, w9
	b.lo	LBB40_4
	b	LBB40_3
LBB40_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB40_13
LBB40_4:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #28]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #32]
	ldr	w9, [sp, #44]
	add	w9, w9, #1
	ldr	w8, [x8, w9, uxtw #2]
	str	w8, [sp, #24]
	b	LBB40_5
LBB40_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.hs	LBB40_12
	b	LBB40_6
LBB40_6:                                ;   in Loop: Header=BB40_5 Depth=1
	ldr	w8, [sp, #28]
	ldr	w9, [sp, #24]
	ldr	w10, [sp, #28]
	subs	w9, w9, w10
	mov	w10, #2                         ; =0x2
	udiv	w9, w9, w10
	add	w8, w8, w9
	str	w8, [sp, #20]
	ldr	x8, [sp, #48]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #4]
	ldrh	w9, [sp, #42]
	subs	w8, w8, w9
	b.ne	LBB40_8
	b	LBB40_7
LBB40_7:
	ldr	x9, [sp, #32]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #16]
	ldr	x10, [sp, #8]
	ldr	w10, [x10, #8]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB40_13
LBB40_8:                                ;   in Loop: Header=BB40_5 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #4]
	ldrh	w9, [sp, #42]
	subs	w8, w8, w9
	b.ge	LBB40_10
	b	LBB40_9
LBB40_9:                                ;   in Loop: Header=BB40_5 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB40_11
LBB40_10:                               ;   in Loop: Header=BB40_5 Depth=1
	ldr	w8, [sp, #20]
	str	w8, [sp, #24]
	b	LBB40_11
LBB40_11:                               ;   in Loop: Header=BB40_5 Depth=1
	b	LBB40_5
LBB40_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB40_13
LBB40_13:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_prepare_map_declarations_split ; -- Begin function nvm_prepare_map_declarations_split
	.p2align	2
_nvm_prepare_map_declarations_split:    ; @nvm_prepare_map_declarations_split
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB41_3
	b	LBB41_1
LBB41_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB41_3
	b	LBB41_2
LBB41_2:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB41_4
	b	LBB41_3
LBB41_3:
	mov	w0, #2                          ; =0x2
	bl	_map_result
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	b	LBB41_7
LBB41_4:
	mov	x1, sp
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp]
	ldr	x0, [sp, #24]
	bl	_nvm_prepare_map_declarations
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	ldur	w8, [x29, #-16]
	subs	w8, w8, #1
	b.eq	LBB41_6
	b	LBB41_5
LBB41_5:
	b	LBB41_7
LBB41_6:
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x8, [sp]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	b	LBB41_7
LBB41_7:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_map_declarations_retained_cost ; -- Begin function nvm_map_declarations_retained_cost
	.p2align	2
_nvm_map_declarations_retained_cost:    ; @nvm_map_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x0, [sp, #24]
	mov	x1, #16                         ; =0x10
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB42_2
	b	LBB42_1
LBB42_1:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_2:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB42_12
	b	LBB42_3
LBB42_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB42_12
	b	LBB42_4
LBB42_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	cbnz	x8, LBB42_12
	b	LBB42_5
LBB42_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #40]
	cbz	w8, LBB42_12
	b	LBB42_6
LBB42_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #40]
	subs	w8, w8, #5
	b.hi	LBB42_12
	b	LBB42_7
LBB42_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #44]
	cbz	w8, LBB42_12
	b	LBB42_8
LBB42_8:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #44]
	subs	w8, w8, #25
	b.hi	LBB42_12
	b	LBB42_9
LBB42_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #48]
	cbz	w8, LBB42_12
	b	LBB42_10
LBB42_10:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #48]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hi	LBB42_12
	b	LBB42_11
LBB42_11:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #52]
	subs	w8, w8, #256
	b.ls	LBB42_13
	b	LBB42_12
LBB42_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_13:
	str	xzr, [sp, #8]
	b	LBB42_14
LBB42_14:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	mov	x2, #1                          ; =0x1
	mov	x3, #80                         ; =0x50
	add	x4, sp, #8
	bl	_nvm_map_copy_term
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB42_16
	b	LBB42_15
LBB42_15:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_16:
	b	LBB42_17
LBB42_17:
	b	LBB42_18
LBB42_18:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #40]
	mov	x2, x8
	mov	x3, #1                          ; =0x1
	add	x4, sp, #8
	bl	_nvm_map_copy_term
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB42_20
	b	LBB42_19
LBB42_19:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_20:
	b	LBB42_21
LBB42_21:
	b	LBB42_22
LBB42_22:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #44]
	mov	x2, x8
	mov	x3, #8                          ; =0x8
	add	x4, sp, #8
	bl	_nvm_map_copy_term
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB42_24
	b	LBB42_23
LBB42_23:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_24:
	b	LBB42_25
LBB42_25:
	b	LBB42_26
LBB42_26:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #48]
	mov	x2, x8
	mov	x3, #12                         ; =0xc
	add	x4, sp, #8
	bl	_nvm_map_copy_term
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB42_28
	b	LBB42_27
LBB42_27:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_28:
	b	LBB42_29
LBB42_29:
	b	LBB42_30
LBB42_30:
	ldr	x0, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #32]
	mov	x2, #257                        ; =0x101
	mov	x3, #4                          ; =0x4
	add	x4, sp, #8
	bl	_nvm_map_copy_term
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbz	w8, LBB42_32
	b	LBB42_31
LBB42_31:
	ldr	w8, [sp, #4]
	stur	w8, [x29, #-4]
	b	LBB42_34
LBB42_32:
	b	LBB42_33
LBB42_33:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB42_34
LBB42_34:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_map_route           ; -- Begin function nvm_record_map_route
	.p2align	2
_nvm_record_map_route:                  ; @nvm_record_map_route
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB43_2
	b	LBB43_1
LBB43_1:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB43_22
LBB43_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbnz	x8, LBB43_7
	b	LBB43_3
LBB43_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB43_7
	b	LBB43_4
LBB43_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbnz	x8, LBB43_7
	b	LBB43_5
LBB43_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB43_7
	b	LBB43_6
LBB43_6:
	stur	wzr, [x29, #-4]
	b	LBB43_22
LBB43_7:
	sub	x1, x29, #17
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	sturb	wzr, [x29, #-17]
	add	x2, sp, #24
	str	wzr, [sp, #24]
	ldur	x0, [x29, #-16]
	bl	_map_public_layout_scan
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	strb	w0, [sp, #23]
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #24]
	bl	_map_public_ownership_scan
	strb	w0, [sp, #22]
	ldurb	w8, [x29, #-17]
	tbnz	w8, #0, LBB43_11
	b	LBB43_8
LBB43_8:
	ldrb	w8, [sp, #23]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB43_10
	b	LBB43_9
LBB43_9:
	ldrb	w8, [sp, #22]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB43_10
LBB43_10:
	ldr	w10, [sp, #4]                   ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	stur	w8, [x29, #-4]
	b	LBB43_22
LBB43_11:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.hi	LBB43_13
	b	LBB43_12
LBB43_12:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB43_14
	b	LBB43_13
LBB43_13:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB43_22
LBB43_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbz	x8, LBB43_20
	b	LBB43_15
LBB43_15:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbz	w8, LBB43_20
	b	LBB43_16
LBB43_16:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB43_20
	b	LBB43_17
LBB43_17:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbz	w8, LBB43_20
	b	LBB43_18
LBB43_18:
	ldrb	w8, [sp, #23]
	tbz	w8, #0, LBB43_20
	b	LBB43_19
LBB43_19:
	ldrb	w8, [sp, #22]
	tbnz	w8, #0, LBB43_21
	b	LBB43_20
LBB43_20:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB43_22
LBB43_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB43_22
LBB43_22:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_public_layout_scan
_map_public_layout_scan:                ; @map_public_layout_scan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbnz	x8, LBB44_2
	b	LBB44_1
LBB44_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	subs	w8, w8, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_32
LBB44_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB44_4
	b	LBB44_3
LBB44_3:
	mov	w8, #16777216                   ; =0x1000000
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB44_5
LBB44_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB44_5
LBB44_5:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #312]
	ldr	x2, [sp, #40]
	sub	x0, x29, #56
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB44_7
	b	LBB44_6
LBB44_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_32
LBB44_7:
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-32]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #39]
	str	wzr, [sp, #32]
	b	LBB44_8
LBB44_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB44_15 Depth 2
	ldr	w8, [sp, #32]
	ldr	w9, [sp, #52]
	subs	w8, w8, w9
	b.hs	LBB44_29
	b	LBB44_9
LBB44_9:                                ;   in Loop: Header=BB44_8 Depth=1
	sub	x0, x29, #56
	mov	x1, #8                          ; =0x8
	add	x2, sp, #64
	bl	_nvm_v2_take
	cbz	w0, LBB44_11
	b	LBB44_10
LBB44_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_32
LBB44_11:                               ;   in Loop: Header=BB44_8 Depth=1
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB44_13
	b	LBB44_12
LBB44_12:                               ;   in Loop: Header=BB44_8 Depth=1
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #3
	b.le	LBB44_14
	b	LBB44_13
LBB44_13:                               ;   in Loop: Header=BB44_8 Depth=1
	strb	wzr, [sp, #39]
	b	LBB44_14
LBB44_14:                               ;   in Loop: Header=BB44_8 Depth=1
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #2]
	ldr	x9, [sp, #64]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #8
	strh	w8, [sp, #30]
	strh	wzr, [sp, #28]
	b	LBB44_15
LBB44_15:                               ;   Parent Loop BB44_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #28]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.ge	LBB44_27
	b	LBB44_16
LBB44_16:                               ;   in Loop: Header=BB44_15 Depth=2
	sub	x0, x29, #56
	mov	x1, #12                         ; =0xc
	add	x2, sp, #56
	bl	_nvm_v2_take
	cbz	w0, LBB44_18
	b	LBB44_17
LBB44_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_32
LBB44_18:                               ;   in Loop: Header=BB44_15 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #13
	b.ne	LBB44_20
	b	LBB44_19
LBB44_19:                               ;   in Loop: Header=BB44_15 Depth=2
	ldur	x9, [x29, #-24]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB44_20
LBB44_20:                               ;   in Loop: Header=BB44_15 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.ge	LBB44_24
	b	LBB44_21
LBB44_21:                               ;   in Loop: Header=BB44_15 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB44_24
	b	LBB44_22
LBB44_22:                               ;   in Loop: Header=BB44_15 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #2]
	cbnz	w8, LBB44_24
	b	LBB44_23
LBB44_23:                               ;   in Loop: Header=BB44_15 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #3]
	cbz	w8, LBB44_25
	b	LBB44_24
LBB44_24:                               ;   in Loop: Header=BB44_15 Depth=2
	strb	wzr, [sp, #39]
	b	LBB44_25
LBB44_25:                               ;   in Loop: Header=BB44_15 Depth=2
	b	LBB44_26
LBB44_26:                               ;   in Loop: Header=BB44_15 Depth=2
	ldrh	w8, [sp, #28]
	add	w8, w8, #1
	strh	w8, [sp, #28]
	b	LBB44_15
LBB44_27:                               ;   in Loop: Header=BB44_8 Depth=1
	b	LBB44_28
LBB44_28:                               ;   in Loop: Header=BB44_8 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB44_8
LBB44_29:
	ldrb	w8, [sp, #39]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB44_31
	b	LBB44_30
LBB44_30:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-48]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB44_31
LBB44_31:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB44_32
LBB44_32:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_public_ownership_scan
_map_public_ownership_scan:             ; @map_public_ownership_scan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	w2, [x29, #-44]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #296]
	cbnz	x8, LBB45_2
	b	LBB45_1
LBB45_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	subs	w8, w8, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_2:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB45_4
	b	LBB45_3
LBB45_3:
	mov	w8, #16777216                   ; =0x1000000
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB45_5
LBB45_4:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #304]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB45_5
LBB45_5:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	stur	x8, [x29, #-104]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #296]
	ldur	x2, [x29, #-104]
	sub	x0, x29, #72
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	sub	x1, x29, #76
	bl	_nvm_v2_u32
	cbnz	w0, LBB45_8
	b	LBB45_6
LBB45_6:
	sub	x0, x29, #72
	sub	x1, x29, #80
	bl	_nvm_v2_u32
	cbnz	w0, LBB45_8
	b	LBB45_7
LBB45_7:
	ldur	w8, [x29, #-80]
	mov	x1, x8
	sub	x0, x29, #72
	sub	x2, x29, #96
	bl	_nvm_v2_take
	cbz	w0, LBB45_9
	b	LBB45_8
LBB45_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_9:
	ldur	w0, [x29, #-76]
	bl	_ownership_version
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB45_11
	b	LBB45_10
LBB45_10:
	ldur	w8, [x29, #-80]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB45_11
LBB45_11:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	sturb	w8, [x29, #-105]
	stur	wzr, [x29, #-112]
	b	LBB45_12
LBB45_12:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-112]
	ldur	w9, [x29, #-80]
	subs	w8, w8, w9
	b.hs	LBB45_17
	b	LBB45_13
LBB45_13:                               ;   in Loop: Header=BB45_12 Depth=1
	ldur	x8, [x29, #-96]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w8, w8, #0xfffffffc
	cbz	w8, LBB45_15
	b	LBB45_14
LBB45_14:                               ;   in Loop: Header=BB45_12 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB45_15
LBB45_15:                               ;   in Loop: Header=BB45_12 Depth=1
	b	LBB45_16
LBB45_16:                               ;   in Loop: Header=BB45_12 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB45_12
LBB45_17:
	sub	x0, x29, #72
	bl	_nvm_v2_align4
	cbnz	w0, LBB45_19
	b	LBB45_18
LBB45_18:
	sub	x0, x29, #72
	sub	x1, x29, #84
	bl	_nvm_v2_u32
	cbz	w0, LBB45_20
	b	LBB45_19
LBB45_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_20:
	stur	wzr, [x29, #-116]
	b	LBB45_21
LBB45_21:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB45_30
	b	LBB45_22
LBB45_22:                               ;   in Loop: Header=BB45_21 Depth=1
	sub	x0, x29, #72
	sub	x1, x29, #118
	bl	_nvm_v2_u16
	cbnz	w0, LBB45_25
	b	LBB45_23
LBB45_23:                               ;   in Loop: Header=BB45_21 Depth=1
	sub	x0, x29, #72
	sub	x1, x29, #120
	bl	_nvm_v2_u16
	cbnz	w0, LBB45_25
	b	LBB45_24
LBB45_24:                               ;   in Loop: Header=BB45_21 Depth=1
	ldurh	w8, [x29, #-118]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	lsl	x1, x8, #3
	sub	x0, x29, #72
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbz	w0, LBB45_26
	b	LBB45_25
LBB45_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_26:                               ;   in Loop: Header=BB45_21 Depth=1
	ldurh	w8, [x29, #-120]
	ldurh	w9, [x29, #-118]
	subs	w8, w8, w9
	b.le	LBB45_28
	b	LBB45_27
LBB45_27:                               ;   in Loop: Header=BB45_21 Depth=1
	sturb	wzr, [x29, #-105]
	b	LBB45_28
LBB45_28:                               ;   in Loop: Header=BB45_21 Depth=1
	b	LBB45_29
LBB45_29:                               ;   in Loop: Header=BB45_21 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB45_21
LBB45_30:
	ldur	w8, [x29, #-76]
	subs	w8, w8, #3
	b.ne	LBB45_51
	b	LBB45_31
LBB45_31:
	ldur	q0, [x29, #-72]
	add	x0, sp, #144
	str	q0, [sp, #144]
	ldur	x8, [x29, #-56]
	str	x8, [sp, #160]
	add	x1, sp, #140
	bl	_nvm_v2_u32
	cbnz	w0, LBB45_34
	b	LBB45_32
LBB45_32:
	ldr	w8, [sp, #140]
	mov	x1, x8
	add	x0, sp, #144
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB45_34
	b	LBB45_33
LBB45_33:
	add	x0, sp, #144
	add	x1, sp, #136
	bl	_nvm_v2_u32
	cbz	w0, LBB45_35
	b	LBB45_34
LBB45_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_35:
	str	wzr, [sp, #132]
	b	LBB45_36
LBB45_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #132]
	ldr	w9, [sp, #136]
	subs	w8, w8, w9
	b.hs	LBB45_48
	b	LBB45_37
LBB45_37:                               ;   in Loop: Header=BB45_36 Depth=1
	add	x0, sp, #144
	add	x1, sp, #130
	bl	_nvm_v2_u16
	cbz	w0, LBB45_39
	b	LBB45_38
LBB45_38:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_39:                               ;   in Loop: Header=BB45_36 Depth=1
	ldrh	w8, [sp, #130]
	subs	w8, w8, #5
	b.ne	LBB45_41
	b	LBB45_40
LBB45_40:                               ;   in Loop: Header=BB45_36 Depth=1
	ldur	x9, [x29, #-40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB45_41
LBB45_41:                               ;   in Loop: Header=BB45_36 Depth=1
	add	x0, sp, #144
	add	x1, sp, #128
	bl	_nvm_v2_u16
	cbnz	w0, LBB45_45
	b	LBB45_42
LBB45_42:                               ;   in Loop: Header=BB45_36 Depth=1
	add	x0, sp, #144
	add	x1, sp, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB45_45
	b	LBB45_43
LBB45_43:                               ;   in Loop: Header=BB45_36 Depth=1
	ldr	w8, [sp, #124]
	mov	x1, x8
	add	x0, sp, #144
	mov	x2, #0                          ; =0x0
	bl	_nvm_v2_take
	cbnz	w0, LBB45_45
	b	LBB45_44
LBB45_44:                               ;   in Loop: Header=BB45_36 Depth=1
	add	x0, sp, #144
	bl	_nvm_v2_align4
	cbz	w0, LBB45_46
	b	LBB45_45
LBB45_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_46:                               ;   in Loop: Header=BB45_36 Depth=1
	b	LBB45_47
LBB45_47:                               ;   in Loop: Header=BB45_36 Depth=1
	ldr	w8, [sp, #132]
	add	w8, w8, #1
	str	w8, [sp, #132]
	b	LBB45_36
LBB45_48:
	add	x0, sp, #56
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	bl	_memset
	ldr	w3, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x5, [sp, #8]                    ; 8-byte Folded Reload
	add	x6, sp, #40
	str	xzr, [sp, #40]
	str	xzr, [sp, #48]
	sub	x0, x29, #72
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	bl	_extension_suffix_read_map
	cbz	w0, LBB45_50
	b	LBB45_49
LBB45_49:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_50:
	b	LBB45_55
LBB45_51:
	ldur	w8, [x29, #-76]
	subs	w8, w8, #2
	b.ne	LBB45_54
	b	LBB45_52
LBB45_52:
	sub	x0, x29, #72
	mov	w1, #-1                         ; =0xffffffff
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_paths_read
	cbz	w0, LBB45_54
	b	LBB45_53
LBB45_53:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_54:
	b	LBB45_55
LBB45_55:
	ldurb	w8, [x29, #-105]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	tbz	w8, #0, LBB45_57
	b	LBB45_56
LBB45_56:
	ldur	x8, [x29, #-56]
	ldur	x9, [x29, #-64]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB45_57
LBB45_57:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB45_58
LBB45_58:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_map_wire_selected   ; -- Begin function nvm_record_map_wire_selected
	.p2align	2
_nvm_record_map_wire_selected:          ; @nvm_record_map_wire_selected
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #64
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	x0, [x8, #480]
	ldr	x8, [x8, #480]
	cbnz	x8, LBB46_2
	b	LBB46_1
LBB46_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_2:
	add	x0, sp, #64
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x1, #480                        ; =0x1e0
	bl	_bzero
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8, #480]
	ldr	x9, [x9, #184]
	str	x9, [x8, #296]
	ldr	x9, [x8, #480]
	ldr	w9, [x9, #192]
	str	w9, [x8, #304]
	add	x1, sp, #63
	strb	wzr, [sp, #63]
	ldr	x8, [x8, #480]
	ldr	w2, [x8, #64]
	bl	_map_public_ownership_scan
	ldrb	w8, [sp, #63]
	tbz	w8, #0, LBB46_4
	b	LBB46_3
LBB46_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #480]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB46_6
	b	LBB46_5
LBB46_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_6:
	str	xzr, [sp, #48]
	str	wzr, [sp, #44]
	b	LBB46_7
LBB46_7:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB46_14 Depth 2
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #44]
	ldr	x9, [x9, #480]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.hs	LBB46_23
	b	LBB46_8
LBB46_8:                                ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #48]
	add	x8, x8, #1
	str	x8, [sp, #48]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB46_10
	b	LBB46_9
LBB46_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_10:                               ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #480]
	ldr	x8, [x8, #56]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB46_13
	b	LBB46_11
LBB46_11:                               ;   in Loop: Header=BB46_7 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB46_13
	b	LBB46_12
LBB46_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_13:                               ;   in Loop: Header=BB46_7 Depth=1
	strh	wzr, [sp, #30]
	b	LBB46_14
LBB46_14:                               ;   Parent Loop BB46_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB46_21
	b	LBB46_15
LBB46_15:                               ;   in Loop: Header=BB46_14 Depth=2
	ldr	x8, [sp, #48]
	add	x8, x8, #1
	str	x8, [sp, #48]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB46_17
	b	LBB46_16
LBB46_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_17:                               ;   in Loop: Header=BB46_14 Depth=2
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #13
	b.ne	LBB46_19
	b	LBB46_18
LBB46_18:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_19:                               ;   in Loop: Header=BB46_14 Depth=2
	b	LBB46_20
LBB46_20:                               ;   in Loop: Header=BB46_14 Depth=2
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB46_14
LBB46_21:                               ;   in Loop: Header=BB46_7 Depth=1
	b	LBB46_22
LBB46_22:                               ;   in Loop: Header=BB46_7 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB46_7
LBB46_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB46_24
LBB46_24:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	add	sp, sp, #560
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_free ; -- Begin function nvm_union_field_declarations_free
	.p2align	2
_nvm_union_field_declarations_free:     ; @nvm_union_field_declarations_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB47_2
	b	LBB47_1
LBB47_1:
	b	LBB47_3
LBB47_2:
	ldr	x0, [sp, #8]
	bl	_nvm_v2_layouts_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB47_3
LBB47_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_prepare ; -- Begin function nvm_union_field_declarations_prepare
	.p2align	2
_nvm_union_field_declarations_prepare:  ; @nvm_union_field_declarations_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_ufd_prepare_reserved
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufd_prepare_reserved
_ufd_prepare_reserved:                  ; @ufd_prepare_reserved
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #184
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	str	x0, [x9, #160]
	str	x1, [x9, #152]
	str	x2, [x9, #144]
	str	x3, [x9, #136]
	mov	x8, #64                         ; =0x40
	str	x8, [x9, #128]
	str	xzr, [x9, #120]
	ldr	x8, [x9, #136]
	ldr	x10, [x9, #128]
	mov	x9, #1048576                    ; =0x100000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB49_2
	b	LBB49_1
LBB49_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #144]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB49_3
	b	LBB49_2
LBB49_2:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [x8, #136]
	ldr	x9, [x8, #128]
	add	x9, x9, x10
	str	x9, [x8, #128]
	ldr	x9, [x8, #144]
	str	x9, [x8, #120]
	ldr	x8, [x8, #160]
	cbz	x8, LBB49_7
	b	LBB49_4
LBB49_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #152]
	cbz	x8, LBB49_7
	b	LBB49_5
LBB49_5:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #160]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [x9, #160]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB49_7
	b	LBB49_6
LBB49_6:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #160]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [x9, #160]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB49_8
	b	LBB49_7
LBB49_7:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #320]
	cbz	w8, LBB49_10
	b	LBB49_9
LBB49_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB49_11
	b	LBB49_10
LBB49_10:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #320]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.hi	LBB49_14
	b	LBB49_12
LBB49_12:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.hi	LBB49_14
	b	LBB49_13
LBB49_13:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #272]
	subs	w8, w8, #256
	b.ls	LBB49_15
	b	LBB49_14
LBB49_14:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_15:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #272]
	cbz	w8, LBB49_18
	b	LBB49_16
LBB49_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB49_18
	b	LBB49_17
LBB49_17:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_18:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #160]
	ldr	w8, [x8, #320]
                                        ; kill: def $x8 killed $w8
	ldr	x10, [x9, #160]
	ldr	w10, [x10, #304]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10
	str	x8, [x9, #112]
	ldr	x8, [x9, #112]
	ldr	x10, [x9, #128]
	mov	x9, #1048576                    ; =0x100000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB49_20
	b	LBB49_19
LBB49_19:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_20:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [x8, #112]
	ldr	x9, [x8, #128]
	add	x9, x9, x10
	str	x9, [x8, #128]
	ldr	x9, [x8, #160]
	ldr	x1, [x9, #312]
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #96
	bl	_nvm_v2_cursor_init
	b	LBB49_21
LBB49_21:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_23
	b	LBB49_22
LBB49_22:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_23:
	b	LBB49_24
LBB49_24:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #2
	b.ne	LBB49_28
	b	LBB49_25
LBB49_25:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #468]
	subs	w8, w8, #1
	b.ne	LBB49_28
	b	LBB49_26
LBB49_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #476]
	subs	w8, w8, #1
	b.ne	LBB49_28
	b	LBB49_27
LBB49_27:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #472]
	cbz	w8, LBB49_29
	b	LBB49_28
LBB49_28:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #68]
	b	LBB49_30
LBB49_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #68]
	subs	w8, w8, #2
	b.hs	LBB49_48
	b	LBB49_31
LBB49_31:                               ;   in Loop: Header=BB49_30 Depth=1
	b	LBB49_32
LBB49_32:                               ;   in Loop: Header=BB49_30 Depth=1
	sub	x0, x29, #96
	mov	x1, #8                          ; =0x8
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbz	w0, LBB49_34
	b	LBB49_33
LBB49_33:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_34:                               ;   in Loop: Header=BB49_30 Depth=1
	b	LBB49_35
LBB49_35:                               ;   in Loop: Header=BB49_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldrb	w8, [x8, #2]
	ldr	x9, [x9, #72]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #8
	sturh	w8, [x29, #-118]
	ldurh	w8, [x29, #-118]
	subs	w8, w8, #1
	b.eq	LBB49_37
	b	LBB49_36
LBB49_36:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_37:                               ;   in Loop: Header=BB49_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldrb	w8, [x8]
	ldr	w11, [x9, #68]
	mov	w9, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	subs	w11, w11, #0
	csel	w9, w9, w10, ne
	subs	w8, w8, w9
	b.eq	LBB49_39
	b	LBB49_38
LBB49_38:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_39:                               ;   in Loop: Header=BB49_30 Depth=1
	b	LBB49_40
LBB49_40:                               ;   in Loop: Header=BB49_30 Depth=1
	sub	x0, x29, #96
	mov	x1, #12                         ; =0xc
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbz	w0, LBB49_42
	b	LBB49_41
LBB49_41:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_42:                               ;   in Loop: Header=BB49_30 Depth=1
	b	LBB49_43
LBB49_43:                               ;   in Loop: Header=BB49_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldrb	w8, [x8, #4]
	ldr	x10, [x9, #72]
	ldrb	w10, [x10, #5]
	orr	w8, w8, w10, lsl #8
	ldr	x10, [x9, #72]
	ldrb	w10, [x10, #6]
	orr	w8, w8, w10, lsl #16
	ldr	x10, [x9, #72]
	ldrb	w10, [x10, #7]
	orr	w8, w8, w10, lsl #24
	str	w8, [x9, #60]
	ldr	x8, [x9, #72]
	ldrb	w8, [x8]
	ldr	w10, [x9, #68]
	mov	w9, #10                         ; =0xa
	subs	w10, w10, #0
	csinc	w9, w9, wzr, ne
	subs	w8, w8, w9
	b.ne	LBB49_45
	b	LBB49_44
LBB49_44:                               ;   in Loop: Header=BB49_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #60]
	ldr	w9, [x9, #68]
	subs	w9, w9, #0
	csetm	w9, eq
	subs	w8, w8, w9
	b.eq	LBB49_46
	b	LBB49_45
LBB49_45:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_46:                               ;   in Loop: Header=BB49_30 Depth=1
	b	LBB49_47
LBB49_47:                               ;   in Loop: Header=BB49_30 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #68]
	add	w8, w8, #1
	str	w8, [x9, #68]
	b	LBB49_30
LBB49_48:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	ldr	x9, [x9, #96]
	subs	x8, x8, x9
	b.eq	LBB49_50
	b	LBB49_49
LBB49_49:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_50:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #160]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #96
	bl	_nvm_v2_cursor_init
	b	LBB49_51
LBB49_51:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_53
	b	LBB49_52
LBB49_52:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_53:
	b	LBB49_54
LBB49_54:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #3
	b.eq	LBB49_56
	b	LBB49_55
LBB49_55:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_56:
	b	LBB49_57
LBB49_57:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_59
	b	LBB49_58
LBB49_58:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_59:
	b	LBB49_60
LBB49_60:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #2
	b.eq	LBB49_62
	b	LBB49_61
LBB49_61:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_62:
	b	LBB49_63
LBB49_63:
	sub	x0, x29, #96
	mov	x1, #2                          ; =0x2
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbz	w0, LBB49_65
	b	LBB49_64
LBB49_64:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_65:
	b	LBB49_66
LBB49_66:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #72]
	ldrb	w9, [x9]
	sturb	w9, [x29, #-126]
	ldr	x8, [x8, #72]
	ldrb	w8, [x8, #1]
	sturb	w8, [x29, #-125]
	ldurb	w8, [x29, #-126]
	subs	w8, w8, #1
	b.ne	LBB49_68
	b	LBB49_67
LBB49_67:
	ldurb	w8, [x29, #-125]
	subs	w8, w8, #1
	b.eq	LBB49_69
	b	LBB49_68
LBB49_68:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_69:
	b	LBB49_70
LBB49_70:
	sub	x0, x29, #96
	bl	_nvm_v2_align4
	cbz	w0, LBB49_72
	b	LBB49_71
LBB49_71:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_72:
	b	LBB49_73
LBB49_73:
	b	LBB49_74
LBB49_74:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_76
	b	LBB49_75
LBB49_75:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_76:
	b	LBB49_77
LBB49_77:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #84]
	ldr	x9, [x9, #160]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB49_79
	b	LBB49_78
LBB49_78:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_79:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	xzr, [x8, #48]
	str	wzr, [x8, #44]
	b	LBB49_80
LBB49_80:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB49_96 Depth 2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #44]
	ldr	w9, [x9, #84]
	subs	w8, w8, w9
	b.hs	LBB49_107
	b	LBB49_81
LBB49_81:                               ;   in Loop: Header=BB49_80 Depth=1
	b	LBB49_82
LBB49_82:                               ;   in Loop: Header=BB49_80 Depth=1
	sub	x0, x29, #96
	sub	x1, x29, #142
	bl	_nvm_v2_u16
	cbz	w0, LBB49_84
	b	LBB49_83
LBB49_83:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_84:                               ;   in Loop: Header=BB49_80 Depth=1
	b	LBB49_85
LBB49_85:                               ;   in Loop: Header=BB49_80 Depth=1
	b	LBB49_86
LBB49_86:                               ;   in Loop: Header=BB49_80 Depth=1
	sub	x0, x29, #96
	sub	x1, x29, #144
	bl	_nvm_v2_u16
	cbz	w0, LBB49_88
	b	LBB49_87
LBB49_87:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_88:                               ;   in Loop: Header=BB49_80 Depth=1
	b	LBB49_89
LBB49_89:                               ;   in Loop: Header=BB49_80 Depth=1
	ldurh	w8, [x29, #-142]
	subs	w8, w8, #256
	b.le	LBB49_91
	b	LBB49_90
LBB49_90:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_91:                               ;   in Loop: Header=BB49_80 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-142]
	ldr	x10, [x9, #160]
	ldr	x11, [x10, #256]
	ldr	w9, [x9, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB49_94
	b	LBB49_92
LBB49_92:                               ;   in Loop: Header=BB49_80 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-144]
	ldr	x10, [x9, #160]
	ldr	x11, [x10, #256]
	ldr	w9, [x9, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB49_94
	b	LBB49_93
LBB49_93:                               ;   in Loop: Header=BB49_80 Depth=1
	ldurh	w8, [x29, #-144]
	ldurh	w9, [x29, #-142]
	subs	w8, w8, w9
	b.le	LBB49_95
	b	LBB49_94
LBB49_94:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_95:                               ;   in Loop: Header=BB49_80 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldurh	w9, [x29, #-142]
	add	w9, w9, #1
	mov	w9, w9
	mov	x10, x9
	ldr	x9, [x8, #48]
	add	x9, x9, x10
	str	x9, [x8, #48]
	str	wzr, [x8, #36]
	b	LBB49_96
LBB49_96:                               ;   Parent Loop BB49_80 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
	ldurh	w9, [x29, #-142]
	subs	w8, w8, w9
	b.hi	LBB49_105
	b	LBB49_97
LBB49_97:                               ;   in Loop: Header=BB49_96 Depth=2
	b	LBB49_98
LBB49_98:                               ;   in Loop: Header=BB49_96 Depth=2
	sub	x0, x29, #96
	mov	x1, #8                          ; =0x8
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbz	w0, LBB49_100
	b	LBB49_99
LBB49_99:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_100:                              ;   in Loop: Header=BB49_96 Depth=2
	b	LBB49_101
LBB49_101:                              ;   in Loop: Header=BB49_96 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #72]
	ldrb	w8, [x8, #1]
	cbz	w8, LBB49_103
	b	LBB49_102
LBB49_102:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_103:                              ;   in Loop: Header=BB49_96 Depth=2
	b	LBB49_104
LBB49_104:                              ;   in Loop: Header=BB49_96 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #36]
	add	w8, w8, #1
	str	w8, [x9, #36]
	b	LBB49_96
LBB49_105:                              ;   in Loop: Header=BB49_80 Depth=1
	b	LBB49_106
LBB49_106:                              ;   in Loop: Header=BB49_80 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #44]
	add	w8, w8, #1
	str	w8, [x9, #44]
	b	LBB49_80
LBB49_107:
	b	LBB49_108
LBB49_108:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_110
	b	LBB49_109
LBB49_109:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_110:
	b	LBB49_111
LBB49_111:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #4
	b.eq	LBB49_113
	b	LBB49_112
LBB49_112:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_113:
	b	LBB49_114
LBB49_114:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_116
	b	LBB49_115
LBB49_115:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_116:
	b	LBB49_117
LBB49_117:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	cbz	w8, LBB49_119
	b	LBB49_118
LBB49_118:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_119:
	b	LBB49_120
LBB49_120:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_122
	b	LBB49_121
LBB49_121:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_122:
	b	LBB49_123
LBB49_123:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #1
	b.eq	LBB49_125
	b	LBB49_124
LBB49_124:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_125:
	b	LBB49_126
LBB49_126:
	sub	x0, x29, #96
	sub	x1, x29, #150
	bl	_nvm_v2_u16
	cbz	w0, LBB49_128
	b	LBB49_127
LBB49_127:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_128:
	b	LBB49_129
LBB49_129:
	b	LBB49_130
LBB49_130:
	sub	x0, x29, #96
	sub	x1, x29, #152
	bl	_nvm_v2_u16
	cbz	w0, LBB49_132
	b	LBB49_131
LBB49_131:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_132:
	b	LBB49_133
LBB49_133:
	ldurh	w8, [x29, #-150]
	subs	w8, w8, #1
	b.ne	LBB49_135
	b	LBB49_134
LBB49_134:
	ldurh	w8, [x29, #-152]
	subs	w8, w8, #1
	b.eq	LBB49_136
	b	LBB49_135
LBB49_135:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_136:
	b	LBB49_137
LBB49_137:
	sub	x0, x29, #96
	sub	x1, x29, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB49_139
	b	LBB49_138
LBB49_138:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_139:
	b	LBB49_140
LBB49_140:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #84]
	subs	w8, w8, #28
	b.eq	LBB49_142
	b	LBB49_141
LBB49_141:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_142:
	b	LBB49_143
LBB49_143:
	sub	x0, x29, #96
	mov	x1, #28                         ; =0x1c
	sub	x2, x29, #112
	bl	_nvm_v2_take
	cbz	w0, LBB49_145
	b	LBB49_144
LBB49_144:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_145:
	b	LBB49_146
LBB49_146:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	ldr	x9, [x9, #96]
	subs	x8, x8, x9
	b.eq	LBB49_148
	b	LBB49_147
LBB49_147:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_148:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #72]
	sub	x0, x29, #176
	mov	x2, #28                         ; =0x1c
	bl	_nvm_v2_cursor_init
	b	LBB49_149
LBB49_149:
	sub	x0, x29, #176
	sub	x1, x29, #180
	bl	_nvm_v2_u32
	cbz	w0, LBB49_151
	b	LBB49_150
LBB49_150:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_151:
	b	LBB49_152
LBB49_152:
	b	LBB49_153
LBB49_153:
	sub	x0, x29, #176
	add	x1, sp, #184
	bl	_nvm_v2_u32
	cbz	w0, LBB49_155
	b	LBB49_154
LBB49_154:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_155:
	b	LBB49_156
LBB49_156:
	b	LBB49_157
LBB49_157:
	sub	x0, x29, #176
	add	x1, sp, #182
	bl	_nvm_v2_u16
	cbz	w0, LBB49_159
	b	LBB49_158
LBB49_158:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_159:
	b	LBB49_160
LBB49_160:
	b	LBB49_161
LBB49_161:
	sub	x0, x29, #176
	add	x1, sp, #180
	bl	_nvm_v2_u16
	cbz	w0, LBB49_163
	b	LBB49_162
LBB49_162:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_163:
	b	LBB49_164
LBB49_164:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4]
	subs	w8, w8, #1
	b.ne	LBB49_168
	b	LBB49_165
LBB49_165:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cbnz	w8, LBB49_168
	b	LBB49_166
LBB49_166:
	ldrh	w8, [sp, #182]
	subs	w8, w8, #2
	b.ne	LBB49_168
	b	LBB49_167
LBB49_167:
	ldrh	w8, [sp, #180]
	cbz	w8, LBB49_169
	b	LBB49_168
LBB49_168:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #2                          ; =0x2
	bl	_ufd_result
	b	LBB49_216
LBB49_169:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB49_175
	b	LBB49_170
LBB49_170:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB49_175
	b	LBB49_171
LBB49_171:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #336]
	cbnz	w8, LBB49_175
	b	LBB49_172
LBB49_172:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB49_175
	b	LBB49_173
LBB49_173:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB49_175
	b	LBB49_174
LBB49_174:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	ldr	x8, [x8, #344]
	cbz	x8, LBB49_176
	b	LBB49_175
LBB49_175:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #1                          ; =0x1
	bl	_ufd_result
	b	LBB49_216
LBB49_176:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [x9, #112]
	mov	x8, #4                          ; =0x4
	mul	x8, x8, x10
	ldr	x11, [x9, #48]
	mov	x10, #32                        ; =0x20
	mul	x10, x10, x11
	add	x8, x8, x10
	add	x8, x8, #256
	add	x8, x8, #128
	str	x8, [sp, #168]
	ldr	x8, [sp, #168]
	ldr	x10, [x9, #128]
	mov	x9, #1048576                    ; =0x100000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB49_178
	b	LBB49_177
LBB49_177:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_178:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #168]
	ldr	x8, [x9, #128]
	add	x8, x8, x10
	str	x8, [x9, #128]
	mov	x8, #112                        ; =0x70
	str	x8, [sp, #160]
	ldr	x8, [sp, #160]
	ldr	x10, [x9, #120]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB49_180
	b	LBB49_179
LBB49_179:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #3                          ; =0x3
	bl	_ufd_result
	b	LBB49_216
LBB49_180:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #160]
	ldr	x8, [x9, #120]
	add	x8, x8, x10
	str	x8, [x9, #120]
	mov	x0, #1                          ; =0x1
	mov	x1, #56                         ; =0x38
	bl	_calloc
	str	x0, [sp, #152]
	ldr	x8, [sp, #152]
	cbnz	x8, LBB49_182
	b	LBB49_181
LBB49_181:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	mov	w0, #4                          ; =0x4
	bl	_ufd_result
	b	LBB49_216
LBB49_182:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	x3, sp, #151
	strb	wzr, [sp, #151]
	ldr	x9, [x8, #160]
	ldr	x0, [x9, #312]
	ldr	x8, [x8, #160]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x2, [sp, #152]
	bl	_nvm_ownership_mixed_layouts_private_decode_detailed
	str	w0, [sp, #144]
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #140]
	ldr	w8, [sp, #144]
	cbz	w8, LBB49_186
	b	LBB49_183
LBB49_183:
	ldrb	w8, [sp, #151]
	tbz	w8, #0, LBB49_185
	b	LBB49_184
LBB49_184:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #140]
	b	LBB49_185
LBB49_185:
	b	LBB49_215
LBB49_186:
	ldr	x8, [sp, #152]
	ldr	w8, [x8, #8]
	subs	w8, w8, #2
	b.ne	LBB49_189
	b	LBB49_187
LBB49_187:
	ldr	x8, [sp, #152]
	ldr	x8, [x8]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB49_189
	b	LBB49_188
LBB49_188:
	ldr	x8, [sp, #152]
	ldr	x8, [x8]
	ldrb	w8, [x8, #16]
	cbz	w8, LBB49_190
	b	LBB49_189
LBB49_189:
	b	LBB49_215
LBB49_190:
	str	wzr, [sp, #136]
	b	LBB49_191
LBB49_191:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #136]
	subs	w8, w8, #2
	b.hs	LBB49_201
	b	LBB49_192
LBB49_192:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	x8, [sp, #152]
	ldr	x8, [x8]
	ldr	w9, [sp, #136]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #128]
	ldr	x8, [sp, #128]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #1
	b.ne	LBB49_195
	b	LBB49_193
LBB49_193:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #128]
	ldr	w8, [x8, #4]
	ldr	x9, [x9, #160]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB49_195
	b	LBB49_194
LBB49_194:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #128]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #160]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB49_196
	b	LBB49_195
LBB49_195:
	b	LBB49_215
LBB49_196:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	x8, [sp, #128]
	ldr	x8, [x8, #8]
	str	x8, [sp, #120]
	ldr	x8, [sp, #120]
	ldrb	w8, [x8]
	ldr	w10, [sp, #136]
	mov	w9, #10                         ; =0xa
	subs	w10, w10, #0
	csinc	w9, w9, wzr, ne
	subs	w8, w8, w9
	b.ne	LBB49_198
	b	LBB49_197
LBB49_197:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	x8, [sp, #120]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #136]
	subs	w9, w9, #0
	csetm	w9, eq
	subs	w8, w8, w9
	b.eq	LBB49_199
	b	LBB49_198
LBB49_198:
	b	LBB49_215
LBB49_199:                              ;   in Loop: Header=BB49_191 Depth=1
	b	LBB49_200
LBB49_200:                              ;   in Loop: Header=BB49_191 Depth=1
	ldr	w8, [sp, #136]
	add	w8, w8, #1
	str	w8, [sp, #136]
	b	LBB49_191
LBB49_201:
	add	x0, sp, #64
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x4, [sp, #24]                   ; 8-byte Folded Reload
	add	x2, sp, #63
	strb	wzr, [sp, #63]
	ldr	x0, [x8, #160]
	ldr	x1, [sp, #152]
	mov	x5, #0                          ; =0x0
	mov	x3, x5
	bl	_ownership_validate_owned
	cbnz	w0, LBB49_205
	b	LBB49_202
LBB49_202:
	ldrb	w8, [sp, #112]
	tbnz	w8, #0, LBB49_205
	b	LBB49_203
LBB49_203:
	ldr	w8, [sp, #92]
	subs	w8, w8, #2
	b.ne	LBB49_205
	b	LBB49_204
LBB49_204:
	ldr	x8, [sp, #64]
	cbnz	x8, LBB49_206
	b	LBB49_205
LBB49_205:
	b	LBB49_215
LBB49_206:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	add	x9, sp, #56
	str	wzr, [sp, #56]
	add	x8, sp, #54
	strh	wzr, [sp, #54]
	ldr	x10, [sp, #152]
	add	x10, x10, #16
	add	x11, sp, #64
	str	x11, [sp, #16]                  ; 8-byte Folded Spill
	str	x10, [sp, #80]
	mov	w10, #2                         ; =0x2
	str	w10, [sp, #88]
	str	x9, [sp, #96]
	str	x8, [sp, #104]
	ldr	x1, [sp, #64]
	ldr	w8, [sp, #72]
	mov	x2, x8
	sub	x0, x29, #176
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	w5, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x7, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #160]
	ldr	x2, [sp, #152]
	sub	x3, x29, #126
	mov	w4, #-1                         ; =0xffffffff
	mov	x6, #0                          ; =0x0
	bl	_union_facts_read
	cbnz	w0, LBB49_211
	b	LBB49_207
LBB49_207:
	ldrb	w8, [sp, #112]
	tbnz	w8, #0, LBB49_211
	b	LBB49_208
LBB49_208:
	ldr	w8, [sp, #92]
	subs	w8, w8, #2
	b.ne	LBB49_211
	b	LBB49_209
LBB49_209:
	ldr	w8, [sp, #56]
	cbnz	w8, LBB49_211
	b	LBB49_210
LBB49_210:
	ldrh	w8, [sp, #54]
	subs	w8, w8, #2
	b.eq	LBB49_212
	b	LBB49_211
LBB49_211:
	b	LBB49_215
LBB49_212:
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #26]
	ldr	x9, [sp, #152]
	ldrh	w9, [x9, #38]
	add	w8, w8, w9
	subs	w8, w8, #1
	b.eq	LBB49_214
	b	LBB49_213
LBB49_213:
	b	LBB49_215
LBB49_214:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #152]
	ldrh	w11, [x10, #26]
	mov	w0, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	subs	w11, w11, #0
	cset	w11, eq
	ldr	x12, [sp, #152]
	strh	w11, [x12, #46]
	ldr	x11, [sp, #152]
	ldrh	w11, [x11, #46]
	subs	w10, w10, w11
	ldr	x11, [sp, #152]
	strh	w10, [x11, #48]
	ldr	x11, [sp, #152]
	mov	w10, #1                         ; =0x1
	strh	w10, [x11, #42]
	ldr	x10, [sp, #152]
	strh	wzr, [x10, #44]
	ldurb	w10, [x29, #-126]
	ldr	x11, [sp, #152]
	strb	w10, [x11, #40]
	ldurb	w10, [x29, #-125]
	ldr	x11, [sp, #152]
	strb	w10, [x11, #41]
	ldr	x10, [sp, #152]
	ldr	x11, [x9, #152]
	str	x10, [x11]
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	bl	_ufd_result
	b	LBB49_216
LBB49_215:
	ldr	x0, [sp, #152]
	bl	_nvm_union_field_declarations_free
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w0, [sp, #140]
	ldr	x1, [x9, #120]
	ldr	x2, [x9, #128]
	bl	_ufd_result
	b	LBB49_216
LBB49_216:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_layout ; -- Begin function nvm_union_field_declarations_layout
	.p2align	2
_nvm_union_field_declarations_layout:   ; @nvm_union_field_declarations_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	str	x2, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB50_3
	b	LBB50_1
LBB50_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB50_3
	b	LBB50_2
LBB50_2:
	ldr	w8, [sp, #28]
	subs	w8, w8, #2
	b.lo	LBB50_4
	b	LBB50_3
LBB50_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB50_5
LBB50_4:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	strb	w8, [sp]
	ldr	x8, [sp, #32]
	add	x8, x8, #40
	ldr	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10
	ldrb	w8, [x8]
	strb	w8, [sp, #1]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	strh	w8, [sp, #2]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	str	w8, [sp, #4]
	ldr	x8, [sp]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB50_5
LBB50_5:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_field ; -- Begin function nvm_union_field_declarations_field
	.p2align	2
_nvm_union_field_declarations_field:    ; @nvm_union_field_declarations_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB51_4
	b	LBB51_1
LBB51_1:
	ldr	x8, [sp]
	cbz	x8, LBB51_4
	b	LBB51_2
LBB51_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.hs	LBB51_4
	b	LBB51_3
LBB51_3:
	ldrh	w8, [sp, #10]
	cbz	w8, LBB51_5
	b	LBB51_4
LBB51_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB51_6
LBB51_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #4
	ldr	x8, [x8, #8]
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB51_6
LBB51_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_variant ; -- Begin function nvm_union_field_declarations_variant
	.p2align	2
_nvm_union_field_declarations_variant:  ; @nvm_union_field_declarations_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB52_4
	b	LBB52_1
LBB52_1:
	ldr	x8, [sp]
	cbz	x8, LBB52_4
	b	LBB52_2
LBB52_2:
	ldr	w8, [sp, #12]
	cbnz	w8, LBB52_4
	b	LBB52_3
LBB52_3:
	ldrh	w8, [sp, #10]
	subs	w8, w8, #2
	b.lt	LBB52_5
	b	LBB52_4
LBB52_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB52_6
LBB52_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	add	x11, x8, #16
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB52_6
LBB52_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_field_declarations_nominal ; -- Begin function nvm_union_field_declarations_nominal
	.p2align	2
_nvm_union_field_declarations_nominal:  ; @nvm_union_field_declarations_nominal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	strb	w1, [sp, #31]
	str	w2, [sp, #24]
	str	x3, [sp, #16]
	ldr	x8, [sp, #32]
	cbz	x8, LBB53_5
	b	LBB53_1
LBB53_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB53_5
	b	LBB53_2
LBB53_2:
	ldr	w8, [sp, #24]
	cbnz	w8, LBB53_5
	b	LBB53_3
LBB53_3:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #8
	b.eq	LBB53_6
	b	LBB53_4
LBB53_4:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #10
	b.eq	LBB53_6
	b	LBB53_5
LBB53_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB53_10
LBB53_6:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #8
	b.ne	LBB53_8
	b	LBB53_7
LBB53_7:
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #42]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB53_9
LBB53_8:
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #44]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB53_9
LBB53_9:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB53_10
LBB53_10:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_union_declarations_retained_cost ; -- Begin function nvm_union_declarations_retained_cost
	.p2align	2
_nvm_union_declarations_retained_cost:  ; @nvm_union_declarations_retained_cost
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x0, [x29, #-24]
	ldr	x1, [sp, #32]
	bl	_ufc_outputs_disjoint
	tbnz	w0, #0, LBB54_2
	b	LBB54_1
LBB54_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_2:
	ldur	x0, [x29, #-24]
	mov	x1, #32                         ; =0x20
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB54_4
	b	LBB54_3
LBB54_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_4:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB54_19
	b	LBB54_5
LBB54_5:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	subs	w8, w8, #2
	b.ne	LBB54_19
	b	LBB54_6
LBB54_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	cbz	x8, LBB54_19
	b	LBB54_7
LBB54_7:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #42]
	subs	w8, w8, #1
	b.ne	LBB54_19
	b	LBB54_8
LBB54_8:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #44]
	cbnz	w8, LBB54_19
	b	LBB54_9
LBB54_9:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #46]
	subs	w8, w8, #1
	b.gt	LBB54_19
	b	LBB54_10
LBB54_10:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #48]
	ldur	x9, [x29, #-16]
	ldrh	w10, [x9, #46]
	mov	w9, #1                          ; =0x1
	subs	w9, w9, w10
	subs	w8, w8, w9, uxth
	b.ne	LBB54_19
	b	LBB54_11
LBB54_11:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	subs	w8, w8, #1
	b.ne	LBB54_19
	b	LBB54_12
LBB54_12:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #41]
	subs	w8, w8, #1
	b.ne	LBB54_19
	b	LBB54_13
LBB54_13:
	ldur	x8, [x29, #-16]
	add	x10, x8, #16
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #46]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #10]
	subs	w8, w8, #1
	b.ne	LBB54_19
	b	LBB54_14
LBB54_14:
	ldur	x8, [x29, #-16]
	add	x10, x8, #16
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #10]
	cbnz	w8, LBB54_19
	b	LBB54_15
LBB54_15:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #16]
	cbnz	w8, LBB54_19
	b	LBB54_16
LBB54_16:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #28]
	cbnz	w8, LBB54_19
	b	LBB54_17
LBB54_17:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #24]
	cbnz	w8, LBB54_19
	b	LBB54_18
LBB54_18:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #36]
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #26]
	subs	w8, w8, w9
	b.eq	LBB54_20
	b	LBB54_19
LBB54_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_20:
	str	xzr, [sp, #24]
	b	LBB54_21
LBB54_21:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	mov	x2, #1                          ; =0x1
	mov	x3, #56                         ; =0x38
	add	x4, sp, #24
	bl	_nvm_map_copy_term
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB54_23
	b	LBB54_22
LBB54_22:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_23:
	b	LBB54_24
LBB54_24:
	b	LBB54_25
LBB54_25:
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x1, [x8]
	mov	x2, #2                          ; =0x2
	mov	x3, #16                         ; =0x10
	add	x4, sp, #24
	bl	_nvm_map_copy_term
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB54_27
	b	LBB54_26
LBB54_26:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_27:
	b	LBB54_28
LBB54_28:
	str	wzr, [sp, #16]
	b	LBB54_29
LBB54_29:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #16]
	subs	w8, w8, #2
	b.hs	LBB54_44
	b	LBB54_30
LBB54_30:                               ;   in Loop: Header=BB54_29 Depth=1
	ldur	x0, [x29, #-24]
	mov	x1, #8                          ; =0x8
	bl	_nvm_map_copy_charge
	tbnz	w0, #0, LBB54_32
	b	LBB54_31
LBB54_31:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_32:                               ;   in Loop: Header=BB54_29 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	w11, [sp, #16]
	mov	w9, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	subs	w11, w11, #0
	csel	w9, w9, w10, ne
	subs	w8, w8, w9
	b.ne	LBB54_34
	b	LBB54_33
LBB54_33:                               ;   in Loop: Header=BB54_29 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #1
	b.eq	LBB54_35
	b	LBB54_34
LBB54_34:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_35:                               ;   in Loop: Header=BB54_29 Depth=1
	b	LBB54_36
LBB54_36:                               ;   in Loop: Header=BB54_29 Depth=1
	ldur	x0, [x29, #-24]
	ldr	x8, [sp, #8]
	ldr	x1, [x8, #8]
	mov	x2, #1                          ; =0x1
	mov	x3, #12                         ; =0xc
	add	x4, sp, #24
	bl	_nvm_map_copy_term
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB54_38
	b	LBB54_37
LBB54_37:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_38:                               ;   in Loop: Header=BB54_29 Depth=1
	b	LBB54_39
LBB54_39:                               ;   in Loop: Header=BB54_29 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	ldr	w10, [sp, #16]
	mov	w9, #10                         ; =0xa
	subs	w10, w10, #0
	csinc	w9, w9, wzr, ne
	subs	w8, w8, w9
	b.ne	LBB54_41
	b	LBB54_40
LBB54_40:                               ;   in Loop: Header=BB54_29 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #16]
	subs	w9, w9, #0
	csetm	w9, eq
	subs	w8, w8, w9
	b.eq	LBB54_42
	b	LBB54_41
LBB54_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB54_45
LBB54_42:                               ;   in Loop: Header=BB54_29 Depth=1
	b	LBB54_43
LBB54_43:                               ;   in Loop: Header=BB54_29 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB54_29
LBB54_44:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB54_45
LBB54_45:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufc_outputs_disjoint
_ufc_outputs_disjoint:                  ; @ufc_outputs_disjoint
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB55_2
	b	LBB55_1
LBB55_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB55_3
	b	LBB55_2
LBB55_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB55_7
LBB55_3:
	ldr	x8, [sp, #32]
	str	x8, [sp, #16]
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ls	LBB55_5
	b	LBB55_4
LBB55_4:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	subs	x8, x8, #8
	cset	w8, hs
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB55_6
LBB55_5:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	subs	x8, x8, #24
	cset	w8, hs
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB55_6
LBB55_6:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB55_7
LBB55_7:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function extension_suffix_read_map
_extension_suffix_read_map:             ; @extension_suffix_read_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	stur	x4, [x29, #-48]
	stur	x5, [x29, #-56]
	str	x6, [sp, #64]
	ldur	x0, [x29, #-16]
	add	x1, sp, #60
	bl	_nvm_v2_u32
	str	w0, [sp, #44]
	cbz	w0, LBB56_2
	b	LBB56_1
LBB56_1:
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-4]
	b	LBB56_10
LBB56_2:
	ldr	w8, [sp, #60]
	subs	w8, w8, #4
	b.lo	LBB56_4
	b	LBB56_3
LBB56_3:
	ldr	w8, [sp, #60]
	mov	w10, #4                         ; =0x4
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbz	w8, LBB56_5
	b	LBB56_4
LBB56_4:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB56_10
LBB56_5:
	ldur	x0, [x29, #-16]
	ldr	w8, [sp, #60]
	mov	x1, x8
	add	x2, sp, #48
	bl	_nvm_v2_take
	str	w0, [sp, #44]
	cbz	w0, LBB56_7
	b	LBB56_6
LBB56_6:
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-4]
	b	LBB56_10
LBB56_7:
	ldr	x1, [sp, #48]
	ldr	w8, [sp, #60]
	mov	x2, x8
	add	x0, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldur	x2, [x29, #-32]
	ldurh	w3, [x29, #-34]
	ldur	x4, [x29, #-48]
	mov	w8, #1                          ; =0x1
	and	w5, w8, #0x1
	bl	_paths_read
	str	w0, [sp, #44]
	cbz	w0, LBB56_9
	b	LBB56_8
LBB56_8:
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-4]
	b	LBB56_10
LBB56_9:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-56]
	ldr	x2, [sp, #64]
	bl	_extensions_read_map
	stur	w0, [x29, #-4]
	b	LBB56_10
LBB56_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function extensions_read_map
_extensions_read_map:                   ; @extensions_read_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	add	x0, sp, #48
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	strh	wzr, [sp, #46]
	ldur	x0, [x29, #-16]
	sub	x1, x29, #36
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbz	w0, LBB57_2
	b	LBB57_1
LBB57_1:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_2:
	ldur	w8, [x29, #-36]
	cbz	w8, LBB57_4
	b	LBB57_3
LBB57_3:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #4
	b.ls	LBB57_5
	b	LBB57_4
LBB57_4:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_5:
	str	wzr, [sp, #40]
	b	LBB57_6
LBB57_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.hs	LBB57_39
	b	LBB57_7
LBB57_7:                                ;   in Loop: Header=BB57_6 Depth=1
	ldur	x0, [x29, #-16]
	add	x1, sp, #38
	bl	_nvm_v2_u16
	stur	w0, [x29, #-40]
	cbnz	w0, LBB57_12
	b	LBB57_8
LBB57_8:                                ;   in Loop: Header=BB57_6 Depth=1
	ldur	x0, [x29, #-16]
	add	x1, sp, #36
	bl	_nvm_v2_u16
	stur	w0, [x29, #-40]
	cbnz	w0, LBB57_12
	b	LBB57_9
LBB57_9:                                ;   in Loop: Header=BB57_6 Depth=1
	ldur	x0, [x29, #-16]
	add	x1, sp, #32
	bl	_nvm_v2_u32
	stur	w0, [x29, #-40]
	cbnz	w0, LBB57_12
	b	LBB57_10
LBB57_10:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w8, [sp, #32]
	mov	x1, x8
	add	x2, sp, #24
	bl	_nvm_v2_take
	stur	w0, [x29, #-40]
	cbnz	w0, LBB57_12
	b	LBB57_11
LBB57_11:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_align4
	stur	w0, [x29, #-40]
	cbz	w0, LBB57_13
	b	LBB57_12
LBB57_12:
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_13:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	cbz	w8, LBB57_15
	b	LBB57_14
LBB57_14:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.gt	LBB57_16
	b	LBB57_15
LBB57_15:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_16:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #36]
	subs	w8, w8, #1
	b.eq	LBB57_21
	b	LBB57_17
LBB57_17:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	subs	w8, w8, #4
	b.ne	LBB57_20
	b	LBB57_18
LBB57_18:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #36]
	subs	w8, w8, #2
	b.eq	LBB57_21
	b	LBB57_19
LBB57_19:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #36]
	subs	w8, w8, #3
	b.eq	LBB57_21
	b	LBB57_20
LBB57_20:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_21:                               ;   in Loop: Header=BB57_6 Depth=1
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]
	ldr	w8, [sp, #32]
	str	w8, [sp, #16]
	ldrh	w8, [sp, #36]
	strh	w8, [sp, #20]
	strh	wzr, [sp, #22]
	ldrh	w8, [sp, #38]
	subs	w8, w8, #1
	b.ne	LBB57_23
	b	LBB57_22
LBB57_22:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	q0, [sp, #8]
	str	q0, [sp, #48]
	b	LBB57_37
LBB57_23:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	subs	w8, w8, #2
	b.ne	LBB57_25
	b	LBB57_24
LBB57_24:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	q0, [sp, #8]
	str	q0, [sp, #64]
	b	LBB57_36
LBB57_25:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	subs	w8, w8, #3
	b.ne	LBB57_27
	b	LBB57_26
LBB57_26:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	q0, [sp, #8]
	str	q0, [sp, #80]
	b	LBB57_35
LBB57_27:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	subs	w8, w8, #4
	b.ne	LBB57_29
	b	LBB57_28
LBB57_28:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	q0, [sp, #8]
	str	q0, [sp, #96]
	b	LBB57_34
LBB57_29:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	subs	w8, w8, #5
	b.ne	LBB57_32
	b	LBB57_30
LBB57_30:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	x8, [x29, #-32]
	cbz	x8, LBB57_32
	b	LBB57_31
LBB57_31:                               ;   in Loop: Header=BB57_6 Depth=1
	ldur	x8, [x29, #-32]
	ldur	q0, [sp, #8]
	str	q0, [x8]
	b	LBB57_33
LBB57_32:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_33:                               ;   in Loop: Header=BB57_6 Depth=1
	b	LBB57_34
LBB57_34:                               ;   in Loop: Header=BB57_6 Depth=1
	b	LBB57_35
LBB57_35:                               ;   in Loop: Header=BB57_6 Depth=1
	b	LBB57_36
LBB57_36:                               ;   in Loop: Header=BB57_6 Depth=1
	b	LBB57_37
LBB57_37:                               ;   in Loop: Header=BB57_6 Depth=1
	ldrh	w8, [sp, #38]
	strh	w8, [sp, #46]
	b	LBB57_38
LBB57_38:                               ;   in Loop: Header=BB57_6 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB57_6
LBB57_39:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB57_41
	b	LBB57_40
LBB57_40:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB57_44
LBB57_41:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB57_43
	b	LBB57_42
LBB57_42:
	ldur	x0, [x29, #-24]
	add	x1, sp, #48
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB57_43
LBB57_43:
	stur	wzr, [x29, #-4]
	b	LBB57_44
LBB57_44:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_version
_ownership_version:                     ; @ownership_version
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_3
	b	LBB58_1
LBB58_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB58_3
	b	LBB58_2
LBB58_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB58_3
LBB58_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function check_layouts
_check_layouts:                         ; @check_layouts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	sturb	w4, [x29, #-34]
	sturb	w5, [x29, #-35]
	sturb	wzr, [x29, #-36]
	stur	wzr, [x29, #-40]
	b	LBB59_1
LBB59_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB59_6
	b	LBB59_2
LBB59_2:                                ;   in Loop: Header=BB59_1 Depth=1
	ldur	x8, [x29, #-24]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #1, LBB59_4
	b	LBB59_3
LBB59_3:                                ;   in Loop: Header=BB59_1 Depth=1
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-36]
	b	LBB59_4
LBB59_4:                                ;   in Loop: Header=BB59_1 Depth=1
	b	LBB59_5
LBB59_5:                                ;   in Loop: Header=BB59_1 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB59_1
LBB59_6:
	ldurb	w8, [x29, #-36]
	tbz	w8, #0, LBB59_19
	b	LBB59_7
LBB59_7:
	stur	wzr, [x29, #-44]
	b	LBB59_8
LBB59_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB59_10 Depth 2
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB59_18
	b	LBB59_9
LBB59_9:                                ;   in Loop: Header=BB59_8 Depth=1
	sturh	wzr, [x29, #-46]
	b	LBB59_10
LBB59_10:                               ;   Parent Loop BB59_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-46]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldur	w10, [x29, #-44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB59_16
	b	LBB59_11
LBB59_11:                               ;   in Loop: Header=BB59_10 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-46]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	str	w8, [sp, #44]
	ldr	w8, [sp, #44]
	adds	w8, w8, #1
	b.eq	LBB59_14
	b	LBB59_12
LBB59_12:                               ;   in Loop: Header=BB59_10 Depth=2
	ldr	w8, [sp, #44]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.lo	LBB59_14
	b	LBB59_13
LBB59_13:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_14:                               ;   in Loop: Header=BB59_10 Depth=2
	b	LBB59_15
LBB59_15:                               ;   in Loop: Header=BB59_10 Depth=2
	ldurh	w8, [x29, #-46]
	add	w8, w8, #1
	sturh	w8, [x29, #-46]
	b	LBB59_10
LBB59_16:                               ;   in Loop: Header=BB59_8 Depth=1
	b	LBB59_17
LBB59_17:                               ;   in Loop: Header=BB59_8 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB59_8
LBB59_18:
	b	LBB59_19
LBB59_19:
	str	wzr, [sp, #40]
	b	LBB59_20
LBB59_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB59_33 Depth 2
	ldr	w8, [sp, #40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB59_76
	b	LBB59_21
LBB59_21:                               ;   in Loop: Header=BB59_20 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #36]
	ldr	w8, [sp, #36]
	and	w8, w8, #0xfffffffc
	cbz	w8, LBB59_23
	b	LBB59_22
LBB59_22:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_23:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	w8, [sp, #36]
	tbz	w8, #1, LBB59_26
	b	LBB59_24
LBB59_24:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	w8, [sp, #36]
	tbnz	w8, #0, LBB59_26
	b	LBB59_25
LBB59_25:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_26:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	w8, [sp, #36]
	tbnz	w8, #0, LBB59_28
	b	LBB59_27
LBB59_27:                               ;   in Loop: Header=BB59_20 Depth=1
	b	LBB59_75
LBB59_28:                               ;   in Loop: Header=BB59_20 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbz	w8, LBB59_32
	b	LBB59_29
LBB59_29:                               ;   in Loop: Header=BB59_20 Depth=1
	ldurb	w8, [x29, #-34]
	tbz	w8, #0, LBB59_31
	b	LBB59_30
LBB59_30:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB59_32
	b	LBB59_31
LBB59_31:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_32:                               ;   in Loop: Header=BB59_20 Depth=1
	strh	wzr, [sp, #22]
	b	LBB59_33
LBB59_33:                               ;   Parent Loop BB59_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB59_72
	b	LBB59_34
LBB59_34:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #24]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w0, [x8]
	bl	_scalar
	tbnz	w0, #0, LBB59_36
	b	LBB59_35
LBB59_35:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB59_39
	b	LBB59_36
LBB59_36:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB59_38
	b	LBB59_37
LBB59_37:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_38:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_70
LBB59_39:                               ;   in Loop: Header=BB59_33 Depth=2
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB59_45
	b	LBB59_40
LBB59_40:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.ne	LBB59_45
	b	LBB59_41
LBB59_41:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	w8, [sp, #36]
	tbnz	w8, #1, LBB59_45
	b	LBB59_42
LBB59_42:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB59_44
	b	LBB59_43
LBB59_43:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_44:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_69
LBB59_45:                               ;   in Loop: Header=BB59_33 Depth=2
	ldurb	w8, [x29, #-35]
	tbz	w8, #0, LBB59_52
	b	LBB59_46
LBB59_46:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #13
	b.ne	LBB59_52
	b	LBB59_47
LBB59_47:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbnz	w8, LBB59_52
	b	LBB59_48
LBB59_48:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	w8, [sp, #36]
	subs	w8, w8, #1
	b.ne	LBB59_52
	b	LBB59_49
LBB59_49:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB59_51
	b	LBB59_50
LBB59_50:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_51:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_68
LBB59_52:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.eq	LBB59_55
	b	LBB59_53
LBB59_53:                               ;   in Loop: Header=BB59_33 Depth=2
	ldurb	w8, [x29, #-34]
	tbz	w8, #0, LBB59_66
	b	LBB59_54
LBB59_54:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB59_66
	b	LBB59_55
LBB59_55:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB59_66
	b	LBB59_56
LBB59_56:                               ;   in Loop: Header=BB59_33 Depth=2
	ldurb	w8, [x29, #-36]
	tbz	w8, #0, LBB59_58
	b	LBB59_57
LBB59_57:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.hs	LBB59_66
	b	LBB59_58
LBB59_58:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	x8, [sp, #8]
	ldrb	w10, [x8]
	mov	w9, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	subs	w10, w10, #8
	csel	w8, w8, w9, eq
	strh	w8, [sp, #6]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	ldrh	w9, [sp, #6]
	subs	w8, w8, w9
	b.eq	LBB59_60
	b	LBB59_59
LBB59_59:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_60:                               ;   in Loop: Header=BB59_33 Depth=2
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp]
	ldr	w8, [sp]
	tbnz	w8, #0, LBB59_62
	b	LBB59_61
LBB59_61:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_62:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	w8, [sp]
	tbz	w8, #1, LBB59_65
	b	LBB59_63
LBB59_63:                               ;   in Loop: Header=BB59_33 Depth=2
	ldr	w8, [sp, #36]
	tbnz	w8, #1, LBB59_65
	b	LBB59_64
LBB59_64:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_65:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_67
LBB59_66:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB59_77
LBB59_67:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_68
LBB59_68:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_69
LBB59_69:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_70
LBB59_70:                               ;   in Loop: Header=BB59_33 Depth=2
	b	LBB59_71
LBB59_71:                               ;   in Loop: Header=BB59_33 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB59_33
LBB59_72:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	w8, [sp, #36]
	tbz	w8, #1, LBB59_74
	b	LBB59_73
LBB59_73:                               ;   in Loop: Header=BB59_20 Depth=1
	ldur	x9, [x29, #-32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB59_74
LBB59_74:                               ;   in Loop: Header=BB59_20 Depth=1
	b	LBB59_75
LBB59_75:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB59_20
LBB59_76:
	stur	wzr, [x29, #-4]
	b	LBB59_77
LBB59_77:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor
_descriptor:                            ; @descriptor
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x29, #16]
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	w3, [x29, #-36]
	sturb	w4, [x29, #-37]
	stur	w5, [x29, #-44]
	stur	x6, [x29, #-56]
	stur	x7, [x29, #-64]
	str	x8, [sp, #72]
	ldur	x0, [x29, #-16]
	add	x1, sp, #71
	bl	_nvm_v2_u8
	str	w0, [sp, #60]
	cbnz	w0, LBB60_4
	b	LBB60_1
LBB60_1:
	ldur	x0, [x29, #-16]
	add	x1, sp, #70
	bl	_nvm_v2_u8
	str	w0, [sp, #60]
	cbnz	w0, LBB60_4
	b	LBB60_2
LBB60_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #68
	bl	_nvm_v2_u16
	str	w0, [sp, #60]
	cbnz	w0, LBB60_4
	b	LBB60_3
LBB60_3:
	ldur	x0, [x29, #-16]
	add	x1, sp, #64
	bl	_nvm_v2_u32
	str	w0, [sp, #60]
	cbz	w0, LBB60_5
	b	LBB60_4
LBB60_4:
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_5:
	ldrh	w8, [sp, #68]
	cbz	w8, LBB60_7
	b	LBB60_6
LBB60_6:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_7:
	ldrb	w8, [sp, #71]
	subs	w8, w8, #16
	b.ge	LBB60_13
	b	LBB60_8
LBB60_8:
	ldrb	w8, [sp, #70]
	subs	w8, w8, #2
	b.gt	LBB60_13
	b	LBB60_9
LBB60_9:
	ldurb	w8, [x29, #-37]
	tbnz	w8, #0, LBB60_11
	b	LBB60_10
LBB60_10:
	ldrb	w8, [sp, #70]
	cbnz	w8, LBB60_13
	b	LBB60_11
LBB60_11:
	ldur	w8, [x29, #-44]
	tbnz	w8, #31, LBB60_14
	b	LBB60_12
LBB60_12:
	ldrb	w8, [sp, #71]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.eq	LBB60_14
	b	LBB60_13
LBB60_13:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_14:
	ldrb	w8, [sp, #71]
	subs	w8, w8, #7
	b.ne	LBB60_25
	b	LBB60_15
LBB60_15:
	ldr	x8, [sp, #72]
	cbz	x8, LBB60_25
	b	LBB60_16
LBB60_16:
	ldr	w8, [sp, #64]
	adds	w8, w8, #1
	b.ne	LBB60_18
	b	LBB60_17
LBB60_17:
	ldr	x9, [sp, #72]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #4]
	b	LBB60_24
LBB60_18:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #3
	b.ne	LBB60_20
	b	LBB60_19
LBB60_19:
	ldrb	w8, [sp, #70]
	cbz	w8, LBB60_21
	b	LBB60_20
LBB60_20:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_21:
	ldr	x8, [sp, #72]
	ldr	w8, [x8]
	ldr	w9, [sp, #64]
	add	w9, w9, #1
	subs	w8, w8, w9
	b.hs	LBB60_23
	b	LBB60_22
LBB60_22:
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	ldr	x9, [sp, #72]
	str	w8, [x9]
	b	LBB60_23
LBB60_23:
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB60_52
LBB60_24:
	b	LBB60_25
LBB60_25:
	ldr	w8, [sp, #64]
	adds	w8, w8, #1
	b.eq	LBB60_42
	b	LBB60_26
LBB60_26:
	ldr	w8, [sp, #64]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB60_28
	b	LBB60_27
LBB60_27:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_28:
	ldrb	w9, [sp, #71]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB60_31
	b	LBB60_29
LBB60_29:
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB60_31
	b	LBB60_30
LBB60_30:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB60_31
LBB60_31:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #59]
	ldur	w9, [x29, #-36]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB60_36
	b	LBB60_32
LBB60_32:
	ldrb	w9, [sp, #71]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB60_36
	b	LBB60_33
LBB60_33:
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB60_35
	b	LBB60_34
LBB60_34:
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB60_36
	b	LBB60_35
LBB60_35:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB60_36
LBB60_36:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #58]
	ldrb	w8, [sp, #59]
	tbnz	w8, #0, LBB60_39
	b	LBB60_37
LBB60_37:
	ldrb	w8, [sp, #58]
	tbnz	w8, #0, LBB60_39
	b	LBB60_38
LBB60_38:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_39:
	ldrb	w8, [sp, #58]
	tbz	w8, #0, LBB60_41
	b	LBB60_40
LBB60_40:
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB60_41
LBB60_41:
	b	LBB60_42
LBB60_42:
	ldrb	w8, [sp, #70]
	cbz	w8, LBB60_51
	b	LBB60_43
LBB60_43:
	ldr	w8, [sp, #64]
	adds	w8, w8, #1
	b.eq	LBB60_45
	b	LBB60_44
LBB60_44:
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #1, LBB60_46
	b	LBB60_45
LBB60_45:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_46:
	add	x2, sp, #16
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #16]
	strh	wzr, [sp, #24]
	strh	wzr, [sp, #26]
	ldr	w8, [sp, #64]
	str	w8, [sp, #28]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	strh	wzr, [sp, #40]
	strh	wzr, [sp, #42]
	ldr	w8, [sp, #64]
	str	w8, [sp, #44]
	ldrb	w8, [sp, #70]
	str	w8, [sp, #48]
	str	wzr, [sp, #52]
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #64]
	bl	_nvm_reference_place_valid
	tbnz	w0, #0, LBB60_50
	b	LBB60_47
LBB60_47:
	ldur	x8, [x29, #-64]
	cbz	x8, LBB60_49
	b	LBB60_48
LBB60_48:
	ldur	x9, [x29, #-64]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB60_49
LBB60_49:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB60_52
LBB60_50:
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB60_51
LBB60_51:
	stur	wzr, [x29, #-4]
	b	LBB60_52
LBB60_52:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function globals_read
_globals_read:                          ; @globals_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x1, [x29, #-24]
	ldur	w8, [x29, #-16]
	mov	x2, x8
	add	x0, sp, #32
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	x1, sp, #28
	bl	_nvm_v2_u32
	str	w0, [sp, #24]
	cbz	w0, LBB61_2
	b	LBB61_1
LBB61_1:
	ldr	w8, [sp, #24]
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_2:
	ldr	w8, [sp, #28]
	cbz	w8, LBB61_4
	b	LBB61_3
LBB61_3:
	ldr	w8, [sp, #28]
	subs	w8, w8, #256
	b.ls	LBB61_5
	b	LBB61_4
LBB61_4:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_5:
	str	wzr, [sp, #20]
	b	LBB61_6
LBB61_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.hs	LBB61_32
	b	LBB61_7
LBB61_7:                                ;   in Loop: Header=BB61_6 Depth=1
	add	x0, sp, #32
	add	x1, sp, #19
	bl	_nvm_v2_u8
	str	w0, [sp, #24]
	cbnz	w0, LBB61_11
	b	LBB61_8
LBB61_8:                                ;   in Loop: Header=BB61_6 Depth=1
	add	x0, sp, #32
	add	x1, sp, #18
	bl	_nvm_v2_u8
	str	w0, [sp, #24]
	cbnz	w0, LBB61_11
	b	LBB61_9
LBB61_9:                                ;   in Loop: Header=BB61_6 Depth=1
	add	x0, sp, #32
	add	x1, sp, #16
	bl	_nvm_v2_u16
	str	w0, [sp, #24]
	cbnz	w0, LBB61_11
	b	LBB61_10
LBB61_10:                               ;   in Loop: Header=BB61_6 Depth=1
	add	x0, sp, #32
	add	x1, sp, #12
	bl	_nvm_v2_u32
	str	w0, [sp, #24]
	cbz	w0, LBB61_12
	b	LBB61_11
LBB61_11:
	ldr	w8, [sp, #24]
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_12:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrh	w8, [sp, #16]
	cbnz	w8, LBB61_14
	b	LBB61_13
LBB61_13:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w8, [sp, #18]
	subs	w8, w8, #1
	b.le	LBB61_15
	b	LBB61_14
LBB61_14:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_15:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w0, [sp, #19]
	bl	_scalar
	tbnz	w0, #0, LBB61_17
	b	LBB61_16
LBB61_16:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w8, [sp, #19]
	subs	w8, w8, #5
	b.ne	LBB61_20
	b	LBB61_17
LBB61_17:                               ;   in Loop: Header=BB61_6 Depth=1
	ldr	w8, [sp, #12]
	adds	w8, w8, #1
	b.eq	LBB61_19
	b	LBB61_18
LBB61_18:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_19:                               ;   in Loop: Header=BB61_6 Depth=1
	b	LBB61_30
LBB61_20:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w8, [sp, #19]
	subs	w8, w8, #8
	b.eq	LBB61_22
	b	LBB61_21
LBB61_21:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w8, [sp, #19]
	subs	w8, w8, #10
	b.ne	LBB61_28
	b	LBB61_22
LBB61_22:                               ;   in Loop: Header=BB61_6 Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB61_24
	b	LBB61_23
LBB61_23:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_24:                               ;   in Loop: Header=BB61_6 Depth=1
	ldrb	w10, [sp, #19]
	mov	w9, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	subs	w10, w10, #8
	csel	w8, w8, w9, eq
	strh	w8, [sp, #10]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	ldrh	w9, [sp, #10]
	subs	w8, w8, w9
	b.ne	LBB61_26
	b	LBB61_25
LBB61_25:                               ;   in Loop: Header=BB61_6 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB61_27
	b	LBB61_26
LBB61_26:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_27:                               ;   in Loop: Header=BB61_6 Depth=1
	b	LBB61_29
LBB61_28:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_29:                               ;   in Loop: Header=BB61_6 Depth=1
	b	LBB61_30
LBB61_30:                               ;   in Loop: Header=BB61_6 Depth=1
	b	LBB61_31
LBB61_31:                               ;   in Loop: Header=BB61_6 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB61_6
LBB61_32:
	ldr	x10, [sp, #48]
	ldr	x11, [sp, #40]
	mov	w9, #9                          ; =0x9
	mov	w8, #0                          ; =0x0
	subs	x10, x10, x11
	csel	w8, w8, w9, eq
	stur	w8, [x29, #-4]
	b	LBB61_33
LBB61_33:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effects_read
_effects_read:                          ; @effects_read
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #7440                       ; =0x1d10
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3344
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2208
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x9, sp, #2148
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	ldr	x9, [x29, #16]
	adrp	x10, ___stack_chk_guard@GOTPAGE
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x10, [x10]
	stur	x10, [x29, #-24]
	str	x0, [x8, #80]
	str	x1, [x8, #88]
	str	x2, [x8, #72]
	str	x3, [x8, #64]
	str	x4, [x8, #56]
	str	w5, [x8, #52]
	str	x6, [x8, #40]
	str	x7, [x8, #32]
	str	x9, [x8, #24]
	ldr	x1, [x8, #80]
	ldr	w8, [x8, #88]
	mov	x2, x8
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	bl	_nvm_v2_cursor_init
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #136
	mov	x1, #2064                       ; =0x810
	bl	_bzero
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #2083]
	add	x0, sp, #2176
	mov	x1, #2052                       ; =0x804
	bl	_bzero
	ldrh	w8, [sp, #6396]
	subs	w8, w8, #2
	b.lo	LBB62_13
	b	LBB62_1
LBB62_1:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	add	x1, sp, #2176
	bl	_nvm_v2_u32
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_3
	b	LBB62_2
LBB62_2:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_3:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #28]
	cbz	w8, LBB62_5
	b	LBB62_4
LBB62_4:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #28]
	subs	w8, w8, #256
	b.ls	LBB62_6
	b	LBB62_5
LBB62_5:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_6:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	wzr, [x8, #24]
	b	LBB62_7
LBB62_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #24]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.hs	LBB62_12
	b	LBB62_8
LBB62_8:                                ;   in Loop: Header=BB62_7 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #64]
	ldr	x2, [x8, #56]
	ldr	w4, [x9, #24]
	add	x8, sp, #2176
	add	x8, x8, #4
	ldr	w9, [x9, #24]
                                        ; kill: def $x9 killed $w9
	add	x6, x8, x9, lsl #3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	mov	w9, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w3, w9, #0x1
	and	w5, w8, #0x1
	bl	_effect_value_read
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_10
	b	LBB62_9
LBB62_9:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_10:                               ;   in Loop: Header=BB62_7 Depth=1
	b	LBB62_11
LBB62_11:                               ;   in Loop: Header=BB62_7 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #24]
	add	w8, w8, #1
	str	w8, [x9, #24]
	b	LBB62_7
LBB62_12:
	b	LBB62_13
LBB62_13:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbz	x8, LBB62_15
	b	LBB62_14
LBB62_14:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	x10, [x8]
	stur	x10, [x9, #12]
	ldr	w8, [x8, #8]
	str	w8, [x9, #20]
	b	LBB62_16
LBB62_15:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	wzr, [x8, #12]
	str	wzr, [x8, #16]
	str	wzr, [x8, #20]
	b	LBB62_16
LBB62_16:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #20]
	ldrh	w8, [sp, #6396]
	subs	w8, w8, #3
	b.ne	LBB62_19
	b	LBB62_17
LBB62_17:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #72]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	add	x2, sp, #2176
	add	x3, sp, #2160
	bl	_effect_constructors_read
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_19
	b	LBB62_18
LBB62_18:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_19:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #52]
	adds	w8, w8, #1
	b.ne	LBB62_21
	b	LBB62_20
LBB62_20:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB62_22
LBB62_21:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #72]
	ldr	w1, [x8, #52]
	bl	_nvm_get_string
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB62_22
LBB62_22:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	stur	x9, [x10, #4]
	ldr	w8, [x8, #52]
	adds	w8, w8, #1
	b.eq	LBB62_25
	b	LBB62_23
LBB62_23:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #4]
	cbnz	x8, LBB62_25
	b	LBB62_24
LBB62_24:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_25:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2204
	bl	_nvm_v2_u32
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_27
	b	LBB62_26
LBB62_26:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_27:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4152]
	cbz	w8, LBB62_29
	b	LBB62_28
LBB62_28:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4152]
	subs	w8, w8, #256
	b.ls	LBB62_30
	b	LBB62_29
LBB62_29:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_30:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	wzr, [x8]
	b	LBB62_31
LBB62_31:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB62_48 Depth 2
                                        ;     Child Loop BB62_56 Depth 2
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	ldr	w9, [x9, #4152]
	subs	w8, w8, w9
	b.hs	LBB62_67
	b	LBB62_32
LBB62_32:                               ;   in Loop: Header=BB62_31 Depth=1
	add	x0, sp, #84
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x1, #2064                       ; =0x810
	bl	_bzero
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	bl	_nvm_v2_u32
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbnz	w0, LBB62_35
	b	LBB62_33
LBB62_33:                               ;   in Loop: Header=BB62_31 Depth=1
	add	x8, sp, #84
	add	x1, x8, #4
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	bl	_nvm_v2_u16
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbnz	w0, LBB62_35
	b	LBB62_34
LBB62_34:                               ;   in Loop: Header=BB62_31 Depth=1
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	add	x1, sp, #82
	bl	_nvm_v2_u16
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_36
	b	LBB62_35
LBB62_35:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_36:                               ;   in Loop: Header=BB62_31 Depth=1
	ldrh	w8, [sp, #82]
	cbz	w8, LBB62_38
	b	LBB62_37
LBB62_37:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #7                          ; =0x7
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_38:                               ;   in Loop: Header=BB62_31 Depth=1
	ldrh	w8, [sp, #88]
	subs	w8, w8, #256
	b.hi	LBB62_40
	b	LBB62_39
LBB62_39:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #84]
	ldr	x9, [x9, #72]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB62_41
	b	LBB62_40
LBB62_40:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_41:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #72]
	ldr	w1, [sp, #84]
	bl	_nvm_get_string
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x0, [sp, #72]
	ldr	x0, [x8, #72]
	ldr	w1, [sp, #84]
	bl	_nvm_get_string_len
	str	w0, [sp, #68]
	ldr	x8, [sp, #72]
	cbz	x8, LBB62_46
	b	LBB62_42
LBB62_42:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	w8, [sp, #68]
	cbz	w8, LBB62_46
	b	LBB62_43
LBB62_43:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x0, [sp, #72]
	ldr	w8, [sp, #68]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB62_46
	b	LBB62_44
LBB62_44:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cbz	w8, LBB62_47
	b	LBB62_45
LBB62_45:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #84]
	ldr	w9, [x9]
	subs	w10, w9, #1
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2312
	ldr	w9, [x9, w10, uxtw #2]
	subs	w8, w8, w9
	b.hi	LBB62_47
	b	LBB62_46
LBB62_46:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_47:                               ;   in Loop: Header=BB62_31 Depth=1
	str	wzr, [sp, #64]
	b	LBB62_48
LBB62_48:                               ;   Parent Loop BB62_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #64]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB62_53
	b	LBB62_49
LBB62_49:                               ;   in Loop: Header=BB62_48 Depth=2
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #72]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x0, [x8, #72]
	ldr	w8, [sp, #64]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2312
	ldr	w1, [x8, x9, lsl #2]
	bl	_nvm_get_string
	mov	x1, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_strcmp
	cbnz	w0, LBB62_51
	b	LBB62_50
LBB62_50:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_51:                               ;   in Loop: Header=BB62_48 Depth=2
	b	LBB62_52
LBB62_52:                               ;   in Loop: Header=BB62_48 Depth=2
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB62_48
LBB62_53:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	add	x8, sp, #84
	ldr	w11, [sp, #84]
	ldr	w12, [x9]
	mov	x13, x12
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2312
	str	w11, [x12, x13, lsl #2]
	ldr	x1, [x10, #64]
	ldr	x2, [x10, #56]
	ldr	w4, [x9, #28]
	ldrh	w9, [sp, #6396]
	subs	w9, w9, #2
	cset	w5, hs
	add	x6, x8, #8
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	bl	_effect_value_read
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_55
	b	LBB62_54
LBB62_54:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_55:                               ;   in Loop: Header=BB62_31 Depth=1
	strh	wzr, [sp, #62]
	b	LBB62_56
LBB62_56:                               ;   Parent Loop BB62_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #62]
	ldrh	w9, [sp, #88]
	subs	w8, w8, w9
	b.ge	LBB62_61
	b	LBB62_57
LBB62_57:                               ;   in Loop: Header=BB62_56 Depth=2
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x1, [x9, #64]
	ldr	x2, [x9, #56]
	ldr	w4, [x8, #28]
	ldrh	w8, [sp, #6396]
	subs	w8, w8, #2
	cset	w5, hs
	add	x8, sp, #84
	add	x8, x8, #16
	ldrh	w9, [sp, #62]
                                        ; kill: def $x9 killed $w9
	add	x6, x8, x9, lsl #3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2208
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	bl	_effect_value_read
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	w0, [x8, #4148]
	cbz	w0, LBB62_59
	b	LBB62_58
LBB62_58:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4148]
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_59:                               ;   in Loop: Header=BB62_56 Depth=2
	b	LBB62_60
LBB62_60:                               ;   in Loop: Header=BB62_56 Depth=2
	ldrh	w8, [sp, #62]
	add	w8, w8, #1
	strh	w8, [sp, #62]
	b	LBB62_56
LBB62_61:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #4]
	cbz	x8, LBB62_65
	b	LBB62_62
LBB62_62:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #72]
	ldr	w1, [x8, #52]
	bl	_nvm_get_string_len
	ldr	w8, [sp, #68]
	subs	w8, w0, w8
	b.ne	LBB62_65
	b	LBB62_63
LBB62_63:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #4]
	ldr	x1, [sp, #72]
	ldr	w8, [sp, #68]
	mov	x2, x8
	bl	_memcmp
	cbnz	w0, LBB62_65
	b	LBB62_64
LBB62_64:                               ;   in Loop: Header=BB62_31 Depth=1
	add	x1, sp, #84
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #136
	mov	x2, #2064                       ; =0x810
	bl	_memcpy
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2083]
	b	LBB62_65
LBB62_65:                               ;   in Loop: Header=BB62_31 Depth=1
	b	LBB62_66
LBB62_66:                               ;   in Loop: Header=BB62_31 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB62_31
LBB62_67:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.eq	LBB62_69
	b	LBB62_68
LBB62_68:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #9                          ; =0x9
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_69:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #52]
	adds	w8, w8, #1
	b.eq	LBB62_72
	b	LBB62_70
LBB62_70:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #2083]
	tbnz	w8, #0, LBB62_72
	b	LBB62_71
LBB62_71:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #100]
	b	LBB62_80
LBB62_72:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	cbz	x8, LBB62_75
	b	LBB62_73
LBB62_73:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #2083]
	tbz	w8, #0, LBB62_75
	b	LBB62_74
LBB62_74:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #40]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #136
	mov	x2, #2064                       ; =0x810
	bl	_memcpy
	b	LBB62_75
LBB62_75:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	cbz	x8, LBB62_77
	b	LBB62_76
LBB62_76:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	add	x1, sp, #2176
	mov	x2, #2052                       ; =0x804
	bl	_memcpy
	b	LBB62_77
LBB62_77:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbz	x8, LBB62_79
	b	LBB62_78
LBB62_78:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #24]
	ldur	x10, [x8, #12]
	str	x10, [x9]
	ldr	w8, [x8, #20]
	str	w8, [x9, #8]
	b	LBB62_79
LBB62_79:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	wzr, [x8, #100]
	b	LBB62_80
LBB62_80:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #100]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB62_82
	b	LBB62_81
LBB62_81:
	bl	___stack_chk_fail
LBB62_82:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3344
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_array_fields
_oaa_array_fields:                      ; @oaa_array_fields
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #8720                       ; =0x2210
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #164
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	stur	x0, [x8, #76]
	stur	x1, [x8, #84]
	stur	x2, [x8, #68]
	ldur	x1, [x8, #76]
	ldr	w8, [x8, #84]
	mov	x2, x8
	add	x0, sp, #208
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #204
	bl	_nvm_v2_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbz	w0, LBB63_2
	b	LBB63_1
LBB63_1:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #32]
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_2:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ls	LBB63_4
	b	LBB63_3
LBB63_3:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #300]
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	add	x0, sp, #208
	add	x2, sp, #184
	bl	_nvm_v2_take
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_6
	b	LBB63_5
LBB63_5:
	add	x0, sp, #208
	add	x1, sp, #200
	bl	_nvm_v2_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbz	w0, LBB63_7
	b	LBB63_6
LBB63_6:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #32]
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB63_9
	b	LBB63_8
LBB63_8:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #300]
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_9:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	add	x0, sp, #208
	add	x2, sp, #176
	bl	_nvm_v2_take
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbz	w0, LBB63_11
	b	LBB63_10
LBB63_10:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #32]
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_11:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #60]
	ldur	x9, [x9, #52]
	subs	x8, x8, x9
	b.eq	LBB63_13
	b	LBB63_12
LBB63_12:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #9                          ; =0x9
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_13:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #68]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	add	x9, x9, #312
	stur	x9, [x8, #4]
	str	wzr, [x8]
	b	LBB63_14
LBB63_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	ldur	x9, [x9, #68]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB63_17
	b	LBB63_15
LBB63_15:                               ;   in Loop: Header=BB63_14 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #68]
	ldr	x8, [x8]
	ldr	w10, [x9]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #4
	ldrh	w8, [x8, #2]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
	ldur	x11, [x9, #4]
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	stur	x8, [x9, #4]
	b	LBB63_16
LBB63_16:                               ;   in Loop: Header=BB63_14 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB63_14
LBB63_17:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #40]
                                        ; kill: def $x9 killed $w9
	lsl	x11, x9, #3
	ldr	w9, [x8, #36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [sp, #152]
	ldur	x8, [x8, #4]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hi	LBB63_19
	b	LBB63_18
LBB63_18:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #152]
	ldur	x10, [x9, #4]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB63_20
	b	LBB63_19
LBB63_19:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #300]
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_20:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #40]
	ldur	x10, [x8, #68]
	str	w9, [x10, #288]
	ldr	w9, [x8, #36]
	ldur	x10, [x8, #68]
	str	w9, [x10, #292]
	ldr	w8, [x8, #40]
	cbz	w8, LBB63_22
	b	LBB63_21
LBB63_21:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	str	x0, [x8, #16]
	b	LBB63_22
LBB63_22:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
	cbz	w8, LBB63_24
	b	LBB63_23
LBB63_23:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	bl	_calloc
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	str	x0, [x8, #24]
	b	LBB63_24
LBB63_24:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	cbz	w8, LBB63_26
	b	LBB63_25
LBB63_25:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #16]
	cbz	x8, LBB63_28
	b	LBB63_26
LBB63_26:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #36]
	cbz	w8, LBB63_29
	b	LBB63_27
LBB63_27:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB63_29
	b	LBB63_28
LBB63_28:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #4                          ; =0x4
	str	w8, [x10, #300]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_29:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x1, [x8, #20]
	ldr	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	add	x0, sp, #128
	bl	_nvm_v2_cursor_init
	str	wzr, [sp, #124]
	b	LBB63_30
LBB63_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #124]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.hs	LBB63_61
	b	LBB63_31
LBB63_31:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_33
	b	LBB63_32
LBB63_32:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_33:                               ;   in Loop: Header=BB63_30 Depth=1
	add	x0, sp, #128
	add	x1, sp, #123
	bl	_nvm_v2_u8
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_37
	b	LBB63_34
LBB63_34:                               ;   in Loop: Header=BB63_30 Depth=1
	add	x0, sp, #128
	add	x1, sp, #122
	bl	_nvm_v2_u8
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_37
	b	LBB63_35
LBB63_35:                               ;   in Loop: Header=BB63_30 Depth=1
	add	x0, sp, #128
	add	x1, sp, #120
	bl	_nvm_v2_u16
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_37
	b	LBB63_36
LBB63_36:                               ;   in Loop: Header=BB63_30 Depth=1
	add	x0, sp, #128
	add	x1, sp, #116
	bl	_nvm_v2_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbz	w0, LBB63_38
	b	LBB63_37
LBB63_37:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #32]
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_38:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrb	w8, [sp, #122]
	cbnz	w8, LBB63_40
	b	LBB63_39
LBB63_39:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrh	w8, [sp, #120]
	cbz	w8, LBB63_41
	b	LBB63_40
LBB63_40:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #7                          ; =0x7
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_41:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrb	w0, [sp, #123]
	bl	_scalar
	tbnz	w0, #0, LBB63_43
	b	LBB63_42
LBB63_42:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #5
	b.ne	LBB63_46
	b	LBB63_43
LBB63_43:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	w8, [sp, #116]
	adds	w8, w8, #1
	b.eq	LBB63_45
	b	LBB63_44
LBB63_44:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_45:                               ;   in Loop: Header=BB63_30 Depth=1
	b	LBB63_59
LBB63_46:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #7
	b.ne	LBB63_50
	b	LBB63_47
LBB63_47:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #116]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.lo	LBB63_49
	b	LBB63_48
LBB63_48:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_49:                               ;   in Loop: Header=BB63_30 Depth=1
	b	LBB63_58
LBB63_50:                               ;   in Loop: Header=BB63_30 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #8
	b.ne	LBB63_56
	b	LBB63_51
LBB63_51:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #116]
	ldur	x9, [x9, #68]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB63_54
	b	LBB63_52
LBB63_52:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8]
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB63_54
	b	LBB63_53
LBB63_53:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	add	x8, x8, #32
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.eq	LBB63_55
	b	LBB63_54
LBB63_54:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_55:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #68]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB63_57
LBB63_56:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_57:                               ;   in Loop: Header=BB63_30 Depth=1
	b	LBB63_58
LBB63_58:                               ;   in Loop: Header=BB63_30 Depth=1
	b	LBB63_59
LBB63_59:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x9, [x8, #16]
	ldr	w8, [sp, #124]
	mov	x10, x8
	ldrb	w11, [sp, #123]
	add	x8, sp, #108
	strb	w11, [sp, #108]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #111]
	ldr	w8, [sp, #116]
	str	w8, [sp, #112]
	ldur	x8, [sp, #108]
	str	x8, [x9, x10, lsl #3]
	b	LBB63_60
LBB63_60:                               ;   in Loop: Header=BB63_30 Depth=1
	ldr	w8, [sp, #124]
	add	w8, w8, #1
	str	w8, [sp, #124]
	b	LBB63_30
LBB63_61:
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #520
	mov	x1, #4096                       ; =0x1000
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	bl	_bzero
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, sp, #520
	bl	_bzero
	str	wzr, [sp, #104]
	b	LBB63_62
LBB63_62:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB63_64 Depth 2
                                        ;     Child Loop BB63_77 Depth 2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #104]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.hs	LBB63_83
	b	LBB63_63
LBB63_63:                               ;   in Loop: Header=BB63_62 Depth=1
	ldr	w8, [sp, #104]
	str	w8, [sp, #100]
	str	wzr, [sp, #96]
	str	wzr, [sp, #92]
	b	LBB63_64
LBB63_64:                               ;   Parent Loop BB63_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #100]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #520
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbnz	w8, LBB63_74
	b	LBB63_65
LBB63_65:                               ;   in Loop: Header=BB63_64 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_67
	b	LBB63_66
LBB63_66:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_67:                               ;   in Loop: Header=BB63_64 Depth=2
	ldr	w8, [sp, #96]
	subs	w8, w8, #64
	b.ne	LBB63_69
	b	LBB63_68
LBB63_68:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #300]
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_69:                               ;   in Loop: Header=BB63_64 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #100]
	mov	x10, x9
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #520
	add	x10, x9, x10
	mov	w9, #1                          ; =0x1
	strb	w9, [x10]
	ldr	w9, [sp, #100]
	ldr	w10, [sp, #96]
	mov	x11, x10
	mov	x10, x11
	add	w10, w10, #1
	str	w10, [sp, #96]
	add	x10, sp, #264
	str	w9, [x10, x11, lsl #2]
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #7
	b.eq	LBB63_71
	b	LBB63_70
LBB63_70:                               ;   in Loop: Header=BB63_62 Depth=1
	b	LBB63_74
LBB63_71:                               ;   in Loop: Header=BB63_64 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #100]
	ldr	w8, [sp, #100]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #520
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB63_73
	b	LBB63_72
LBB63_72:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_73:                               ;   in Loop: Header=BB63_64 Depth=2
	b	LBB63_64
LBB63_74:                               ;   in Loop: Header=BB63_62 Depth=1
	ldr	w8, [sp, #100]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #520
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB63_76
	b	LBB63_75
LBB63_75:                               ;   in Loop: Header=BB63_62 Depth=1
	ldr	w8, [sp, #100]
	mov	x9, x8
	add	x8, sp, #520
	ldrb	w8, [x8, x9]
	str	w8, [sp, #92]
	b	LBB63_76
LBB63_76:                               ;   in Loop: Header=BB63_62 Depth=1
	b	LBB63_77
LBB63_77:                               ;   Parent Loop BB63_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #96]
	cbz	w8, LBB63_81
	b	LBB63_78
LBB63_78:                               ;   in Loop: Header=BB63_77 Depth=2
	ldr	w8, [sp, #96]
	subs	w9, w8, #1
	str	w9, [sp, #96]
	add	x8, sp, #264
	ldr	w8, [x8, w9, uxtw #2]
	str	w8, [sp, #88]
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	subs	w8, w8, #64
	b.ls	LBB63_80
	b	LBB63_79
LBB63_79:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x10, [x9, #68]
	mov	w8, #3                          ; =0x3
	str	w8, [x10, #300]
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_80:                               ;   in Loop: Header=BB63_77 Depth=2
	ldr	w8, [sp, #88]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #520
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldr	w8, [sp, #92]
	ldr	w9, [sp, #88]
	mov	x10, x9
	add	x9, sp, #520
	strb	w8, [x9, x10]
	b	LBB63_77
LBB63_81:                               ;   in Loop: Header=BB63_62 Depth=1
	b	LBB63_82
LBB63_82:                               ;   in Loop: Header=BB63_62 Depth=1
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB63_62
LBB63_83:
	str	wzr, [sp, #84]
	b	LBB63_84
LBB63_84:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #84]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.hs	LBB63_99
	b	LBB63_85
LBB63_85:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldrb	w8, [x8, x9]
	subs	w8, w8, #7
	b.ne	LBB63_97
	b	LBB63_86
LBB63_86:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_88
	b	LBB63_87
LBB63_87:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_88:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #68]
	ldr	x8, [x8, #16]
	ldur	x9, [x9, #68]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #84]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #72]
	ldrb	w8, [sp, #72]
	subs	w8, w8, #7
	b.ne	LBB63_92
	b	LBB63_89
LBB63_89:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_91
	b	LBB63_90
LBB63_90:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_91:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #72]
	b	LBB63_92
LBB63_92:                               ;   in Loop: Header=BB63_84 Depth=1
	ldrb	w8, [sp, #72]
	subs	w8, w8, #1
	b.lt	LBB63_95
	b	LBB63_93
LBB63_93:                               ;   in Loop: Header=BB63_84 Depth=1
	ldrb	w8, [sp, #72]
	subs	w8, w8, #5
	b.gt	LBB63_95
	b	LBB63_94
LBB63_94:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	w8, [sp, #76]
	adds	w8, w8, #1
	b.eq	LBB63_96
	b	LBB63_95
LBB63_95:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #68]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB63_96
LBB63_96:                               ;   in Loop: Header=BB63_84 Depth=1
	b	LBB63_97
LBB63_97:                               ;   in Loop: Header=BB63_84 Depth=1
	b	LBB63_98
LBB63_98:                               ;   in Loop: Header=BB63_84 Depth=1
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB63_84
LBB63_99:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x1, [x8, #12]
	ldr	w8, [x8, #36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	add	x0, sp, #128
	bl	_nvm_v2_cursor_init
	str	wzr, [sp, #68]
	b	LBB63_100
LBB63_100:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #68]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.hs	LBB63_124
	b	LBB63_101
LBB63_101:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_103
	b	LBB63_102
LBB63_102:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_103:                              ;   in Loop: Header=BB63_100 Depth=1
	add	x0, sp, #128
	add	x1, sp, #64
	bl	_nvm_v2_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_107
	b	LBB63_104
LBB63_104:                              ;   in Loop: Header=BB63_100 Depth=1
	add	x0, sp, #128
	add	x1, sp, #58
	bl	_nvm_v2_u16
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_107
	b	LBB63_105
LBB63_105:                              ;   in Loop: Header=BB63_100 Depth=1
	add	x0, sp, #128
	add	x1, sp, #56
	bl	_nvm_v2_u16
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbnz	w0, LBB63_107
	b	LBB63_106
LBB63_106:                              ;   in Loop: Header=BB63_100 Depth=1
	add	x0, sp, #128
	add	x1, sp, #60
	bl	_nvm_v2_u32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #32]
	cbz	w0, LBB63_108
	b	LBB63_107
LBB63_107:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x9, #32]
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_108:                              ;   in Loop: Header=BB63_100 Depth=1
	ldrh	w8, [sp, #56]
	cbz	w8, LBB63_110
	b	LBB63_109
LBB63_109:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #7                          ; =0x7
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_110:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #64]
	ldur	x9, [x9, #68]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB63_116
	b	LBB63_111
LBB63_111:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #60]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.hs	LBB63_116
	b	LBB63_112
LBB63_112:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	add	x8, x8, #32
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB63_116
	b	LBB63_113
LBB63_113:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB63_116
	b	LBB63_114
LBB63_114:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #58]
	ldur	x9, [x9, #68]
	ldr	x9, [x9]
	ldr	w10, [sp, #64]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB63_116
	b	LBB63_115
LBB63_115:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #58]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #7
	b.eq	LBB63_117
	b	LBB63_116
LBB63_116:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_117:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	w8, [sp, #68]
	cbz	w8, LBB63_122
	b	LBB63_118
LBB63_118:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #64]
	ldur	x9, [x9, #68]
	ldr	x9, [x9, #24]
	ldr	w10, [sp, #68]
	subs	w10, w10, #1
	mov	w11, #12                        ; =0xc
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB63_121
	b	LBB63_119
LBB63_119:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #64]
	ldur	x9, [x9, #68]
	ldr	x9, [x9, #24]
	ldr	w10, [sp, #68]
	subs	w10, w10, #1
	mov	w11, #12                        ; =0xc
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.ne	LBB63_122
	b	LBB63_120
LBB63_120:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #58]
	ldur	x9, [x9, #68]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #68]
	subs	w9, w9, #1
	mov	w10, #12                        ; =0xc
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.gt	LBB63_122
	b	LBB63_121
LBB63_121:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_122:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	w8, [sp, #64]
	str	w8, [sp, #44]
	ldrh	w8, [sp, #58]
	strh	w8, [sp, #48]
	strh	wzr, [sp, #50]
	ldr	w8, [sp, #60]
	str	w8, [sp, #52]
	ldur	x8, [sp, #44]
	str	x8, [x9]
	ldr	w8, [sp, #52]
	str	w8, [x9, #8]
	b	LBB63_123
LBB63_123:                              ;   in Loop: Header=BB63_100 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB63_100
LBB63_124:
	str	wzr, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB63_125
LBB63_125:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB63_127 Depth 2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #36]
	ldur	x9, [x9, #68]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB63_141
	b	LBB63_126
LBB63_126:                              ;   in Loop: Header=BB63_125 Depth=1
	strh	wzr, [sp, #34]
	b	LBB63_127
LBB63_127:                              ;   Parent Loop BB63_125 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #34]
	ldur	x9, [x9, #68]
	ldr	x9, [x9]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB63_139
	b	LBB63_128
LBB63_128:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #68]
	mov	w1, #1                          ; =0x1
	bl	_oaa_charge
	tbnz	w0, #0, LBB63_130
	b	LBB63_129
LBB63_129:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #13                         ; =0xd
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_130:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	add	x8, x8, #32
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB63_137
	b	LBB63_131
LBB63_131:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #34]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #7
	b.ne	LBB63_137
	b	LBB63_132
LBB63_132:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #40]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.hs	LBB63_135
	b	LBB63_133
LBB63_133:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #36]
	subs	w8, w8, w9
	b.ne	LBB63_135
	b	LBB63_134
LBB63_134:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #68]
	ldr	x10, [x8, #24]
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #4]
	ldrh	w9, [sp, #34]
	subs	w8, w8, w9
	b.eq	LBB63_136
	b	LBB63_135
LBB63_135:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_136:                              ;   in Loop: Header=BB63_127 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB63_137
LBB63_137:                              ;   in Loop: Header=BB63_127 Depth=2
	b	LBB63_138
LBB63_138:                              ;   in Loop: Header=BB63_127 Depth=2
	ldrh	w8, [sp, #34]
	add	w8, w8, #1
	strh	w8, [sp, #34]
	b	LBB63_127
LBB63_139:                              ;   in Loop: Header=BB63_125 Depth=1
	b	LBB63_140
LBB63_140:                              ;   in Loop: Header=BB63_125 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB63_125
LBB63_141:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #40]
	ldr	w12, [x9, #36]
	mov	w10, #8                         ; =0x8
	mov	w8, #0                          ; =0x0
	subs	w11, w11, w12
	csel	w8, w8, w10, eq
	str	w8, [x9, #96]
	b	LBB63_142
LBB63_142:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #96]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB63_144
	b	LBB63_143
LBB63_143:
	bl	___stack_chk_fail
LBB63_144:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #528
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_payload
_map_payload:                           ; @map_payload
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #160
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x1, [sp, #160]
	str	x2, [x8, #8]
	str	x0, [sp, #152]
	str	x3, [sp, #144]
	str	x4, [sp, #136]
	ldr	x0, [sp, #152]
	ldr	w8, [sp, #168]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	mov	x1, #128                        ; =0x80
	bl	_map_charge
	tbnz	w0, #0, LBB64_2
	b	LBB64_1
LBB64_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_2:
	sub	x0, x29, #152
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #128                        ; =0x80
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, x8, #32
	ldr	x1, [sp, #160]
	ldr	w8, [sp, #168]
	mov	x2, x8
	bl	_nvm_v2_cursor_init
	ldrh	w8, [sp, #172]
	subs	w8, w8, #1
	b.ne	LBB64_4
	b	LBB64_3
LBB64_3:
	sub	x8, x29, #152
	add	x0, x8, #32
	add	x1, x8, #100
	bl	_nvm_v2_u32
	cbz	w0, LBB64_5
	b	LBB64_4
LBB64_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_5:
	ldur	w8, [x29, #-52]
	cbz	w8, LBB64_7
	b	LBB64_6
LBB64_6:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #5
	b.ls	LBB64_8
	b	LBB64_7
LBB64_7:
	ldur	w11, [x29, #-52]
	mov	w8, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	mov	w9, #3                          ; =0x3
	subs	w11, w11, #0
	csel	w9, w9, w10, ne
	ldr	x10, [sp, #152]
	str	w9, [x10, #72]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_8:
	sub	x8, x29, #152
	add	x0, x8, #32
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	add	x2, sp, #128
	bl	_nvm_v2_take
	cbnz	w0, LBB64_10
	b	LBB64_9
LBB64_9:
	sub	x8, x29, #152
	add	x0, x8, #32
	add	x1, x8, #104
	bl	_nvm_v2_u32
	cbz	w0, LBB64_11
	b	LBB64_10
LBB64_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_11:
	ldur	w8, [x29, #-48]
	cbz	w8, LBB64_13
	b	LBB64_12
LBB64_12:
	ldur	w8, [x29, #-48]
	subs	w8, w8, #25
	b.ls	LBB64_14
	b	LBB64_13
LBB64_13:
	ldur	w11, [x29, #-48]
	mov	w8, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	mov	w9, #3                          ; =0x3
	subs	w11, w11, #0
	csel	w9, w9, w10, ne
	ldr	x10, [sp, #152]
	str	w9, [x10, #72]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_14:
	sub	x8, x29, #152
	add	x0, x8, #32
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	add	x2, sp, #120
	bl	_nvm_v2_take
	cbnz	w0, LBB64_16
	b	LBB64_15
LBB64_15:
	sub	x8, x29, #152
	add	x0, x8, #32
	add	x1, x8, #108
	bl	_nvm_v2_u32
	cbz	w0, LBB64_17
	b	LBB64_16
LBB64_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_17:
	ldur	w8, [x29, #-44]
	cbz	w8, LBB64_19
	b	LBB64_18
LBB64_18:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB64_20
	b	LBB64_19
LBB64_19:
	ldur	w11, [x29, #-44]
	mov	w8, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	mov	w9, #3                          ; =0x3
	subs	w11, w11, #0
	csel	w9, w9, w10, ne
	ldr	x10, [sp, #152]
	str	w9, [x10, #72]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_20:
	sub	x8, x29, #152
	add	x0, x8, #32
	ldur	w8, [x29, #-44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	add	x2, sp, #112
	bl	_nvm_v2_take
	cbnz	w0, LBB64_23
	b	LBB64_21
LBB64_21:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ne	LBB64_23
	b	LBB64_22
LBB64_22:
	ldr	x8, [sp, #144]
	ldr	w8, [x8, #8]
	subs	w8, w8, #256
	b.ls	LBB64_24
	b	LBB64_23
LBB64_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_24:
	ldr	x9, [sp, #152]
	ldur	w8, [x29, #-52]
	str	w8, [sp, #100]
	ldur	w8, [x29, #-48]
	str	w8, [sp, #104]
	ldur	w8, [x29, #-44]
	str	w8, [sp, #108]
	ldur	x8, [sp, #100]
	str	x8, [x9, #40]
	ldr	w8, [sp, #108]
	str	w8, [x9, #48]
	ldr	x8, [sp, #144]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #152]
	str	w8, [x9, #52]
	ldr	x0, [sp, #152]
	ldur	w8, [x29, #-52]
	mov	x1, x8
	mov	x2, #1                          ; =0x1
	bl	_map_alloc
	ldr	x8, [sp, #152]
	str	x0, [x8, #8]
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB64_26
	b	LBB64_25
LBB64_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_26:
	ldr	x0, [sp, #152]
	ldur	w8, [x29, #-48]
	mov	x1, x8
	mov	x2, #8                          ; =0x8
	bl	_map_alloc
	ldr	x8, [sp, #152]
	str	x0, [x8, #16]
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB64_28
	b	LBB64_27
LBB64_27:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_28:
	ldr	x0, [sp, #152]
	ldur	w8, [x29, #-44]
	mov	x1, x8
	mov	x2, #12                         ; =0xc
	bl	_map_alloc
	ldr	x8, [sp, #152]
	str	x0, [x8, #24]
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB64_30
	b	LBB64_29
LBB64_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_30:
	ldr	x0, [sp, #152]
	mov	x1, #257                        ; =0x101
	mov	x2, #4                          ; =0x4
	bl	_map_alloc
	ldr	x8, [sp, #152]
	str	x0, [x8, #32]
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #8]
	cbz	x8, LBB64_34
	b	LBB64_31
LBB64_31:
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #16]
	cbz	x8, LBB64_34
	b	LBB64_32
LBB64_32:
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #24]
	cbz	x8, LBB64_34
	b	LBB64_33
LBB64_33:
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB64_35
	b	LBB64_34
LBB64_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_35:
	sub	x8, x29, #152
	add	x0, x8, #56
	ldr	x1, [sp, #128]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	_nvm_v2_cursor_init
	stur	wzr, [x29, #-40]
	b	LBB64_36
LBB64_36:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB64_53
	b	LBB64_37
LBB64_37:                               ;   in Loop: Header=BB64_36 Depth=1
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #1                          ; =0x1
	bl	_map_charge
	tbnz	w0, #0, LBB64_39
	b	LBB64_38
LBB64_38:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_39:                               ;   in Loop: Header=BB64_36 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #99
	bl	_nvm_v2_u8
	cbnz	w0, LBB64_50
	b	LBB64_40
LBB64_40:                               ;   in Loop: Header=BB64_36 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #98
	bl	_nvm_v2_u8
	cbnz	w0, LBB64_50
	b	LBB64_41
LBB64_41:                               ;   in Loop: Header=BB64_36 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #96
	bl	_nvm_v2_u16
	cbnz	w0, LBB64_50
	b	LBB64_42
LBB64_42:                               ;   in Loop: Header=BB64_36 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbnz	w0, LBB64_50
	b	LBB64_43
LBB64_43:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrb	w8, [sp, #98]
	cbnz	w8, LBB64_50
	b	LBB64_44
LBB64_44:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrh	w8, [sp, #96]
	cbnz	w8, LBB64_50
	b	LBB64_45
LBB64_45:                               ;   in Loop: Header=BB64_36 Depth=1
	ldr	w8, [sp, #92]
	adds	w8, w8, #1
	b.ne	LBB64_50
	b	LBB64_46
LBB64_46:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrb	w0, [sp, #99]
	bl	_scalar
	tbnz	w0, #0, LBB64_48
	b	LBB64_47
LBB64_47:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrb	w8, [sp, #99]
	subs	w8, w8, #5
	b.ne	LBB64_50
	b	LBB64_48
LBB64_48:                               ;   in Loop: Header=BB64_36 Depth=1
	ldur	w8, [x29, #-40]
	cbz	w8, LBB64_51
	b	LBB64_49
LBB64_49:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrb	w8, [sp, #99]
	ldurb	w9, [x29, #-32]
	subs	w8, w8, w9
	b.gt	LBB64_51
	b	LBB64_50
LBB64_50:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_51:                               ;   in Loop: Header=BB64_36 Depth=1
	ldrb	w8, [sp, #99]
	ldr	x9, [sp, #152]
	ldr	x9, [x9, #8]
	ldur	w10, [x29, #-40]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	ldrb	w8, [sp, #99]
	sturb	w8, [x29, #-32]
	b	LBB64_52
LBB64_52:                               ;   in Loop: Header=BB64_36 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB64_36
LBB64_53:
	sub	x8, x29, #152
	add	x0, x8, #56
	ldr	x1, [sp, #120]
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	_nvm_v2_cursor_init
	stur	wzr, [x29, #-40]
	b	LBB64_54
LBB64_54:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.hs	LBB64_68
	b	LBB64_55
LBB64_55:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #4                          ; =0x4
	bl	_map_charge
	tbnz	w0, #0, LBB64_57
	b	LBB64_56
LBB64_56:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_57:                               ;   in Loop: Header=BB64_54 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #84
	bl	_nvm_v2_u32
	cbnz	w0, LBB64_65
	b	LBB64_58
LBB64_58:                               ;   in Loop: Header=BB64_54 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x8, sp, #84
	add	x1, x8, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB64_65
	b	LBB64_59
LBB64_59:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB64_65
	b	LBB64_60
LBB64_60:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	w8, [sp, #88]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB64_65
	b	LBB64_61
LBB64_61:                               ;   in Loop: Header=BB64_54 Depth=1
	ldur	w8, [x29, #-40]
	cbz	w8, LBB64_66
	b	LBB64_62
LBB64_62:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.lo	LBB64_65
	b	LBB64_63
LBB64_63:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.ne	LBB64_66
	b	LBB64_64
LBB64_64:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	w8, [sp, #88]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hi	LBB64_66
	b	LBB64_65
LBB64_65:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_66:                               ;   in Loop: Header=BB64_54 Depth=1
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #152]
	ldr	x11, [x8, #16]
	sub	x9, x29, #152
	ldur	w8, [x29, #-40]
	mov	x12, x8
	ldur	x8, [sp, #84]
	str	x8, [x11, x12, lsl #3]
	ldur	x8, [sp, #84]
	str	x8, [x10, #104]
	ldr	w8, [sp, #84]
	mov	x10, x8
	mov	x8, x9
	add	x10, x8, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x10]
	ldr	w10, [sp, #88]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB64_67
LBB64_67:                               ;   in Loop: Header=BB64_54 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB64_54
LBB64_68:
	sub	x8, x29, #152
	add	x0, x8, #56
	ldr	x1, [sp, #112]
	ldur	w8, [x29, #-44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	_nvm_v2_cursor_init
	stur	wzr, [x29, #-40]
	b	LBB64_69
LBB64_69:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB64_92
	b	LBB64_70
LBB64_70:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #5                          ; =0x5
	bl	_map_charge
	tbnz	w0, #0, LBB64_72
	b	LBB64_71
LBB64_71:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_72:                               ;   in Loop: Header=BB64_69 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB64_84
	b	LBB64_73
LBB64_73:                               ;   in Loop: Header=BB64_69 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x8, sp, #72
	add	x1, x8, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB64_84
	b	LBB64_74
LBB64_74:                               ;   in Loop: Header=BB64_69 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x1, sp, #70
	bl	_nvm_v2_u16
	cbnz	w0, LBB64_84
	b	LBB64_75
LBB64_75:                               ;   in Loop: Header=BB64_69 Depth=1
	sub	x8, x29, #152
	add	x0, x8, #56
	add	x8, sp, #72
	add	x1, x8, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB64_84
	b	LBB64_76
LBB64_76:                               ;   in Loop: Header=BB64_69 Depth=1
	ldrh	w8, [sp, #70]
	cbnz	w8, LBB64_84
	b	LBB64_77
LBB64_77:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	w8, [sp, #72]
	ldr	x9, [sp, #144]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB64_84
	b	LBB64_78
LBB64_78:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	w8, [sp, #80]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.hs	LBB64_84
	b	LBB64_79
LBB64_79:                               ;   in Loop: Header=BB64_69 Depth=1
	ldrh	w8, [sp, #76]
	ldr	x9, [sp, #144]
	ldr	x9, [x9]
	ldr	w10, [sp, #72]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB64_84
	b	LBB64_80
LBB64_80:                               ;   in Loop: Header=BB64_69 Depth=1
	ldur	w8, [x29, #-40]
	cbz	w8, LBB64_85
	b	LBB64_81
LBB64_81:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	w8, [sp, #72]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.lo	LBB64_84
	b	LBB64_82
LBB64_82:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	w8, [sp, #72]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.ne	LBB64_85
	b	LBB64_83
LBB64_83:                               ;   in Loop: Header=BB64_69 Depth=1
	ldrh	w8, [sp, #76]
	ldurh	w9, [x29, #-60]
	subs	w8, w8, w9
	b.gt	LBB64_85
	b	LBB64_84
LBB64_84:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_85:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x8, [sp, #144]
	ldr	x8, [x8]
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	cbnz	w8, LBB64_89
	b	LBB64_86
LBB64_86:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x8, [sp, #136]
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB64_89
	b	LBB64_87
LBB64_87:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #13
	b.ne	LBB64_89
	b	LBB64_88
LBB64_88:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB64_90
	b	LBB64_89
LBB64_89:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_90:                               ;   in Loop: Header=BB64_69 Depth=1
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #152]
	ldr	x12, [x8, #24]
	sub	x8, x29, #152
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	mov	x11, #12                        ; =0xc
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x11, w9, w11, x12
	ldr	x9, [sp, #72]
	str	x9, [x11]
	ldr	w9, [sp, #80]
	str	w9, [x11, #8]
	ldr	x9, [sp, #72]
	str	x9, [x10, #112]
	ldr	w9, [sp, #80]
	stur	w9, [x29, #-56]
	add	x8, x8, #5
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB64_91
LBB64_91:                               ;   in Loop: Header=BB64_69 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB64_69
LBB64_92:
	stur	wzr, [x29, #-40]
	stur	wzr, [x29, #-36]
	b	LBB64_93
LBB64_93:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB64_97 Depth 2
	ldur	w8, [x29, #-36]
	ldr	x9, [sp, #144]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB64_110
	b	LBB64_94
LBB64_94:                               ;   in Loop: Header=BB64_93 Depth=1
	ldr	x8, [sp, #144]
	ldr	x8, [x8]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #48]
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #1                          ; =0x1
	bl	_map_charge
	tbnz	w0, #0, LBB64_96
	b	LBB64_95
LBB64_95:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_96:                               ;   in Loop: Header=BB64_93 Depth=1
	ldur	w8, [x29, #-40]
	ldr	x9, [sp, #152]
	ldr	x9, [x9, #32]
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	strh	wzr, [sp, #46]
	b	LBB64_97
LBB64_97:                               ;   Parent Loop BB64_93 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB64_108
	b	LBB64_98
LBB64_98:                               ;   in Loop: Header=BB64_97 Depth=2
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #2                          ; =0x2
	bl	_map_charge
	tbnz	w0, #0, LBB64_100
	b	LBB64_99
LBB64_99:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_100:                              ;   in Loop: Header=BB64_97 Depth=2
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #13
	b.eq	LBB64_102
	b	LBB64_101
LBB64_101:                              ;   in Loop: Header=BB64_97 Depth=2
	b	LBB64_107
LBB64_102:                              ;   in Loop: Header=BB64_97 Depth=2
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB64_105
	b	LBB64_103
LBB64_103:                              ;   in Loop: Header=BB64_97 Depth=2
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB64_105
	b	LBB64_104
LBB64_104:                              ;   in Loop: Header=BB64_97 Depth=2
	ldr	x8, [sp, #152]
	ldr	x10, [x8, #24]
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #4]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.eq	LBB64_106
	b	LBB64_105
LBB64_105:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_106:                              ;   in Loop: Header=BB64_97 Depth=2
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB64_107
LBB64_107:                              ;   in Loop: Header=BB64_97 Depth=2
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB64_97
LBB64_108:                              ;   in Loop: Header=BB64_93 Depth=1
	b	LBB64_109
LBB64_109:                              ;   in Loop: Header=BB64_93 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB64_93
LBB64_110:
	ldur	w8, [x29, #-40]
	ldr	x9, [sp, #152]
	ldr	x9, [x9, #32]
	ldr	x10, [sp, #144]
	ldr	w10, [x10, #8]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.eq	LBB64_112
	b	LBB64_111
LBB64_111:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_112:
	str	wzr, [sp, #40]
	b	LBB64_113
LBB64_113:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB64_119
	b	LBB64_114
LBB64_114:                              ;   in Loop: Header=BB64_113 Depth=1
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #1                          ; =0x1
	bl	_map_charge
	tbz	w0, #0, LBB64_116
	b	LBB64_115
LBB64_115:                              ;   in Loop: Header=BB64_113 Depth=1
	ldr	w8, [sp, #40]
	mov	x9, x8
	sub	x8, x29, #152
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbnz	w8, LBB64_117
	b	LBB64_116
LBB64_116:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_117:                              ;   in Loop: Header=BB64_113 Depth=1
	b	LBB64_118
LBB64_118:                              ;   in Loop: Header=BB64_113 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB64_113
LBB64_119:
	str	wzr, [sp, #36]
	b	LBB64_120
LBB64_120:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.hs	LBB64_126
	b	LBB64_121
LBB64_121:                              ;   in Loop: Header=BB64_120 Depth=1
	ldr	x0, [sp, #152]
	mov	x1, #0                          ; =0x0
	mov	x2, #1                          ; =0x1
	bl	_map_charge
	tbz	w0, #0, LBB64_123
	b	LBB64_122
LBB64_122:                              ;   in Loop: Header=BB64_120 Depth=1
	sub	x8, x29, #152
	add	x8, x8, #5
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbnz	w8, LBB64_124
	b	LBB64_123
LBB64_123:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_124:                              ;   in Loop: Header=BB64_120 Depth=1
	b	LBB64_125
LBB64_125:                              ;   in Loop: Header=BB64_120 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB64_120
LBB64_126:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	b	LBB64_127
LBB64_127:
	ldurb	w8, [x29, #-153]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB64_129
	b	LBB64_128
LBB64_128:
	bl	___stack_chk_fail
LBB64_129:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_4
	b	LBB65_1
LBB65_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_4
	b	LBB65_2
LBB65_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_4
	b	LBB65_3
LBB65_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB65_4
LBB65_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_value_read
_effect_value_read:                     ; @effect_value_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	str	w4, [sp, #40]
	strb	w5, [sp, #39]
	str	x6, [sp, #24]
	add	x1, sp, #8
	str	xzr, [sp, #8]
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_u8
	str	w0, [sp, #16]
	cbnz	w0, LBB66_4
	b	LBB66_1
LBB66_1:
	ldur	x0, [x29, #-16]
	add	x1, sp, #23
	bl	_nvm_v2_u8
	str	w0, [sp, #16]
	cbnz	w0, LBB66_4
	b	LBB66_2
LBB66_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #20
	bl	_nvm_v2_u16
	str	w0, [sp, #16]
	cbnz	w0, LBB66_4
	b	LBB66_3
LBB66_3:
	ldur	x0, [x29, #-16]
	add	x8, sp, #8
	add	x1, x8, #4
	bl	_nvm_v2_u32
	str	w0, [sp, #16]
	cbz	w0, LBB66_5
	b	LBB66_4
LBB66_4:
	ldr	w8, [sp, #16]
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_5:
	ldrb	w8, [sp, #23]
	cbnz	w8, LBB66_7
	b	LBB66_6
LBB66_6:
	ldrh	w8, [sp, #20]
	cbz	w8, LBB66_8
	b	LBB66_7
LBB66_7:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_8:
	ldrb	w0, [sp, #8]
	bl	_scalar
	tbnz	w0, #0, LBB66_12
	b	LBB66_9
LBB66_9:
	ldrb	w8, [sp, #8]
	subs	w8, w8, #5
	b.eq	LBB66_12
	b	LBB66_10
LBB66_10:
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB66_15
	b	LBB66_11
LBB66_11:
	ldrb	w8, [sp, #8]
	cbnz	w8, LBB66_15
	b	LBB66_12
LBB66_12:
	ldr	w8, [sp, #12]
	adds	w8, w8, #1
	b.eq	LBB66_14
	b	LBB66_13
LBB66_13:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_14:
	b	LBB66_31
LBB66_15:
	ldrb	w8, [sp, #8]
	subs	w8, w8, #8
	b.eq	LBB66_17
	b	LBB66_16
LBB66_16:
	ldrb	w8, [sp, #8]
	subs	w8, w8, #10
	b.ne	LBB66_23
	b	LBB66_17
LBB66_17:
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB66_19
	b	LBB66_18
LBB66_18:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_19:
	ldrb	w10, [sp, #8]
	mov	w9, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	subs	w10, w10, #8
	csel	w8, w8, w9, eq
	strh	w8, [sp, #6]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	ldrh	w9, [sp, #6]
	subs	w8, w8, w9
	b.ne	LBB66_21
	b	LBB66_20
LBB66_20:
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB66_22
	b	LBB66_21
LBB66_21:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_22:
	b	LBB66_30
LBB66_23:
	ldrb	w8, [sp, #39]
	tbz	w8, #0, LBB66_28
	b	LBB66_24
LBB66_24:
	ldrb	w8, [sp, #8]
	subs	w8, w8, #7
	b.ne	LBB66_28
	b	LBB66_25
LBB66_25:
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.lo	LBB66_27
	b	LBB66_26
LBB66_26:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_27:
	b	LBB66_29
LBB66_28:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB66_32
LBB66_29:
	b	LBB66_30
LBB66_30:
	b	LBB66_31
LBB66_31:
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB66_32
LBB66_32:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_constructors_read
_effect_constructors_read:              ; @effect_constructors_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #24
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [x8, #8]
	str	x1, [x8]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	mov	w9, #-1                         ; =0xffffffff
	stur	w9, [x29, #-48]
	stur	wzr, [x29, #-52]
	stur	wzr, [x29, #-56]
	ldr	x0, [x8, #8]
	sub	x1, x29, #44
	bl	_nvm_v2_u32
	stur	w0, [x29, #-60]
	cbz	w0, LBB67_2
	b	LBB67_1
LBB67_1:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_2:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #8, lsl #12             ; =32768
	b.ls	LBB67_4
	b	LBB67_3
LBB67_3:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_4:
	stur	wzr, [x29, #-64]
	b	LBB67_5
LBB67_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB67_27 Depth 2
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB67_45
	b	LBB67_6
LBB67_6:                                ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	stur	w0, [x29, #-60]
	cbnz	w0, LBB67_9
	b	LBB67_7
LBB67_7:                                ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	sub	x1, x29, #72
	bl	_nvm_v2_u32
	stur	w0, [x29, #-60]
	cbnz	w0, LBB67_9
	b	LBB67_8
LBB67_8:                                ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	sub	x1, x29, #76
	bl	_nvm_v2_u32
	stur	w0, [x29, #-60]
	cbz	w0, LBB67_10
	b	LBB67_9
LBB67_9:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_10:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #256]
	cbz	x8, LBB67_13
	b	LBB67_11
LBB67_11:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w8, [x29, #-68]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB67_13
	b	LBB67_12
LBB67_12:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-76]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB67_14
	b	LBB67_13
LBB67_13:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_14:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-64]
	cbz	w8, LBB67_19
	b	LBB67_15
LBB67_15:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-68]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.lo	LBB67_18
	b	LBB67_16
LBB67_16:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-68]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.ne	LBB67_19
	b	LBB67_17
LBB67_17:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-72]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hi	LBB67_19
	b	LBB67_18
LBB67_18:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_19:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-68]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [sp, #88]
	ldr	x8, [x8]
	ldr	x8, [x8, #280]
	cbz	x8, LBB67_23
	b	LBB67_20
LBB67_20:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB67_23
	b	LBB67_21
LBB67_21:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #12]
	ldr	x9, [x9]
	ldr	w9, [x9, #288]
	ldr	x10, [sp, #88]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB67_23
	b	LBB67_22
LBB67_22:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-72]
	ldr	x9, [sp, #88]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB67_24
	b	LBB67_23
LBB67_23:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_24:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-68]
	ldur	w9, [x29, #-48]
	subs	w8, w8, w9
	b.eq	LBB67_26
	b	LBB67_25
LBB67_25:                               ;   in Loop: Header=BB67_5 Depth=1
	stur	wzr, [x29, #-56]
	b	LBB67_26
LBB67_26:                               ;   in Loop: Header=BB67_5 Depth=1
	b	LBB67_27
LBB67_27:                               ;   Parent Loop BB67_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.hs	LBB67_31
	b	LBB67_28
LBB67_28:                               ;   in Loop: Header=BB67_27 Depth=2
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #88]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #24
	bl	_isa_decode
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB67_30
	b	LBB67_29
LBB67_29:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_30:                               ;   in Loop: Header=BB67_27 Depth=2
	ldr	w9, [sp, #20]
	ldur	w8, [x29, #-56]
	add	w8, w8, w9
	stur	w8, [x29, #-56]
	b	LBB67_27
LBB67_31:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.eq	LBB67_33
	b	LBB67_32
LBB67_32:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_33:                               ;   in Loop: Header=BB67_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #88]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #24
	bl	_isa_decode
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbz	w8, LBB67_38
	b	LBB67_34
LBB67_34:                               ;   in Loop: Header=BB67_5 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #80
	b.eq	LBB67_37
	b	LBB67_35
LBB67_35:                               ;   in Loop: Header=BB67_5 Depth=1
	ldrb	w8, [sp, #24]
	subs	w8, w8, #88
	b.ne	LBB67_38
	b	LBB67_36
LBB67_36:                               ;   in Loop: Header=BB67_5 Depth=1
	ldrh	w8, [sp, #40]
	cbnz	w8, LBB67_38
	b	LBB67_37
LBB67_37:                               ;   in Loop: Header=BB67_5 Depth=1
	ldrb	w8, [sp, #32]
	ldur	x9, [x29, #-32]
	add	x9, x9, #4
	ldur	w10, [x29, #-76]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #3
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB67_39
	b	LBB67_38
LBB67_38:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB67_46
LBB67_39:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	x8, [x29, #-40]
	cbz	x8, LBB67_43
	b	LBB67_40
LBB67_40:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w8, [x8]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.ne	LBB67_43
	b	LBB67_41
LBB67_41:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.ne	LBB67_43
	b	LBB67_42
LBB67_42:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-76]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #8]
	b	LBB67_43
LBB67_43:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-68]
	stur	w8, [x29, #-48]
	ldur	w8, [x29, #-72]
	stur	w8, [x29, #-52]
	ldr	w9, [sp, #20]
	ldur	w8, [x29, #-56]
	add	w8, w8, w9
	stur	w8, [x29, #-56]
	b	LBB67_44
LBB67_44:                               ;   in Loop: Header=BB67_5 Depth=1
	ldur	w8, [x29, #-64]
	add	w8, w8, #1
	stur	w8, [x29, #-64]
	b	LBB67_5
LBB67_45:
	stur	wzr, [x29, #-4]
	b	LBB67_46
LBB67_46:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_charge
_oaa_charge:                            ; @oaa_charge
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w10, [x9, #296]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB68_2
	b	LBB68_1
LBB68_1:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #300]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB68_3
LBB68_2:
	ldr	w10, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w8, [x9, #296]
	add	w8, w8, w10
	str	w8, [x9, #296]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB68_3
LBB68_3:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_charge
_map_charge:                            ; @map_charge
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	subs	x8, x8, #512, lsl #12           ; =2097152
	b.hi	LBB69_4
	b	LBB69_1
LBB69_1:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x10, [x9, #56]
	mov	x9, #2097152                    ; =0x200000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB69_4
	b	LBB69_2
LBB69_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #64]
	subs	x8, x8, #1024, lsl #12          ; =4194304
	b.hi	LBB69_4
	b	LBB69_3
LBB69_3:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x10, [x9, #64]
	mov	x9, #4194304                    ; =0x400000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB69_5
	b	LBB69_4
LBB69_4:
	ldr	x9, [sp, #16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #72]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB69_6
LBB69_5:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #56]
	add	x8, x8, x10
	str	x8, [x9, #56]
	ldr	x10, [sp]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #64]
	add	x8, x8, x10
	str	x8, [x9, #64]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB69_6
LBB69_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_alloc
_map_alloc:                             ; @map_alloc
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB70_3
	b	LBB70_1
LBB70_1:
	ldr	x8, [sp, #24]
	ldr	x10, [sp, #16]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB70_3
	b	LBB70_2
LBB70_2:
	ldur	x9, [x29, #-16]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #72]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB70_8
LBB70_3:
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	mul	x1, x8, x9
	mov	x2, #0                          ; =0x0
	bl	_map_charge
	tbnz	w0, #0, LBB70_5
	b	LBB70_4
LBB70_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB70_8
LBB70_5:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #16]
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB70_7
	b	LBB70_6
LBB70_6:
	ldur	x9, [x29, #-16]
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #72]
	b	LBB70_7
LBB70_7:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB70_8
LBB70_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_prepare_map
_oaa_prepare_map:                       ; @oaa_prepare_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-32]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB71_4
	b	LBB71_1
LBB71_1:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB71_4
	b	LBB71_2
LBB71_2:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB71_4
	b	LBB71_3
LBB71_3:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB71_5
	b	LBB71_4
LBB71_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	bl	_oaa_result
	b	LBB71_103
LBB71_5:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #320]
	cbz	w8, LBB71_7
	b	LBB71_6
LBB71_6:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB71_8
	b	LBB71_7
LBB71_7:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	bl	_oaa_result
	b	LBB71_103
LBB71_8:
	sub	x1, x29, #36
	stur	wzr, [x29, #-36]
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-24]
	subs	x8, x8, #0
	cset	w2, ne
	bl	_oaa_preflight
	stur	w0, [x29, #-40]
	ldur	w8, [x29, #-40]
	cbz	w8, LBB71_10
	b	LBB71_9
LBB71_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w0, [x29, #-40]
	bl	_oaa_result
	b	LBB71_103
LBB71_10:
	mov	x0, #1                          ; =0x1
	mov	x1, #312                        ; =0x138
	bl	_calloc
	stur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB71_12
	b	LBB71_11
LBB71_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	bl	_oaa_result
	b	LBB71_103
LBB71_12:
	ldur	x9, [x29, #-48]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #300]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-48]
	str	w8, [x9, #296]
	sturb	wzr, [x29, #-49]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB71_14
	b	LBB71_13
LBB71_13:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldur	x2, [x29, #-48]
	sub	x3, x29, #49
	bl	_nvm_ownership_map_layouts_private_decode_detailed
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB71_18
LBB71_14:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB71_16
	b	LBB71_15
LBB71_15:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldur	x2, [x29, #-48]
	sub	x3, x29, #49
	bl	_nvm_ownership_mixed_layouts_private_decode_detailed
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB71_17
LBB71_16:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldur	x2, [x29, #-48]
	bl	_nvm_ownership_layouts_private_decode
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB71_17
LBB71_17:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB71_18
LBB71_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbz	w8, LBB71_23
	b	LBB71_19
LBB71_19:
	ldurb	w8, [x29, #-49]
	tbz	w8, #0, LBB71_21
	b	LBB71_20
LBB71_20:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB71_22
LBB71_21:
	ldur	w9, [x29, #-56]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #1
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB71_22
LBB71_22:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_23:
	stur	wzr, [x29, #-60]
	stur	wzr, [x29, #-64]
	stur	wzr, [x29, #-68]
	stur	wzr, [x29, #-72]
	b	LBB71_24
LBB71_24:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_33 Depth 2
	ldur	w8, [x29, #-72]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB71_63
	b	LBB71_25
LBB71_25:                               ;   in Loop: Header=BB71_24 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.eq	LBB71_28
	b	LBB71_26
LBB71_26:                               ;   in Loop: Header=BB71_24 Depth=1
	ldr	x8, [sp, #80]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB71_28
	b	LBB71_27
LBB71_27:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_28:                               ;   in Loop: Header=BB71_24 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w9, [x8]
	ldur	w8, [x29, #-60]
	subs	w9, w9, #0
	cinc	w8, w8, eq
	stur	w8, [x29, #-60]
	ldr	x8, [sp, #80]
	ldrb	w9, [x8]
	ldur	w8, [x29, #-64]
	subs	w9, w9, #3
	cinc	w8, w8, eq
	stur	w8, [x29, #-64]
	ldr	x8, [sp, #80]
	ldrb	w9, [x8]
	ldur	w8, [x29, #-68]
	subs	w9, w9, #2
	cinc	w8, w8, eq
	stur	w8, [x29, #-68]
	ldr	x8, [sp, #80]
	ldrb	w8, [x8]
	cbz	w8, LBB71_32
	b	LBB71_29
LBB71_29:                               ;   in Loop: Header=BB71_24 Depth=1
	ldur	x8, [x29, #-24]
	cbz	x8, LBB71_31
	b	LBB71_30
LBB71_30:                               ;   in Loop: Header=BB71_24 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.eq	LBB71_32
	b	LBB71_31
LBB71_31:                               ;   in Loop: Header=BB71_24 Depth=1
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_32
LBB71_32:                               ;   in Loop: Header=BB71_24 Depth=1
	strh	wzr, [sp, #78]
	b	LBB71_33
LBB71_33:                               ;   Parent Loop BB71_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #78]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB71_61
	b	LBB71_34
LBB71_34:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #80]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #78]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #4]
	str	w8, [sp, #60]
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB71_37
	b	LBB71_35
LBB71_35:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB71_37
	b	LBB71_36
LBB71_36:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_37:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB71_42
	b	LBB71_38
LBB71_38:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB71_40
	b	LBB71_39
LBB71_39:                               ;   in Loop: Header=BB71_33 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbz	w8, LBB71_41
	b	LBB71_40
LBB71_40:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_41:                               ;   in Loop: Header=BB71_33 Depth=2
	b	LBB71_52
LBB71_42:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #9
	b.ne	LBB71_48
	b	LBB71_43
LBB71_43:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	w8, [sp, #60]
	adds	w8, w8, #1
	b.eq	LBB71_48
	b	LBB71_44
LBB71_44:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB71_46
	b	LBB71_45
LBB71_45:                               ;   in Loop: Header=BB71_33 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #3
	b.eq	LBB71_47
	b	LBB71_46
LBB71_46:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_47:                               ;   in Loop: Header=BB71_33 Depth=2
	b	LBB71_51
LBB71_48:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	w8, [sp, #60]
	adds	w8, w8, #1
	b.eq	LBB71_50
	b	LBB71_49
LBB71_49:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_50:                               ;   in Loop: Header=BB71_33 Depth=2
	b	LBB71_51
LBB71_51:                               ;   in Loop: Header=BB71_33 Depth=2
	b	LBB71_52
LBB71_52:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w0, [x8]
	bl	_scalar
	tbnz	w0, #0, LBB71_59
	b	LBB71_53
LBB71_53:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.eq	LBB71_59
	b	LBB71_54
LBB71_54:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.eq	LBB71_59
	b	LBB71_55
LBB71_55:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.eq	LBB71_59
	b	LBB71_56
LBB71_56:                               ;   in Loop: Header=BB71_33 Depth=2
	ldur	x8, [x29, #-32]
	cbz	x8, LBB71_58
	b	LBB71_57
LBB71_57:                               ;   in Loop: Header=BB71_33 Depth=2
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	subs	w8, w8, #13
	b.eq	LBB71_59
	b	LBB71_58
LBB71_58:                               ;   in Loop: Header=BB71_33 Depth=2
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_59
LBB71_59:                               ;   in Loop: Header=BB71_33 Depth=2
	b	LBB71_60
LBB71_60:                               ;   in Loop: Header=BB71_33 Depth=2
	ldrh	w8, [sp, #78]
	add	w8, w8, #1
	strh	w8, [sp, #78]
	b	LBB71_33
LBB71_61:                               ;   in Loop: Header=BB71_24 Depth=1
	b	LBB71_62
LBB71_62:                               ;   in Loop: Header=BB71_24 Depth=1
	ldur	w8, [x29, #-72]
	add	w8, w8, #1
	stur	w8, [x29, #-72]
	b	LBB71_24
LBB71_63:
	ldur	w8, [x29, #-60]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.ne	LBB71_66
	b	LBB71_64
LBB71_64:
	ldur	w8, [x29, #-64]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.ne	LBB71_66
	b	LBB71_65
LBB71_65:
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.eq	LBB71_67
	b	LBB71_66
LBB71_66:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_67:
	add	x2, sp, #59
	strb	wzr, [sp, #59]
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-48]
	ldur	x3, [x29, #-48]
	ldur	x4, [x29, #-24]
	ldur	x5, [x29, #-32]
	bl	_ownership_validate_owned
	stur	w0, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbz	w8, LBB71_69
	b	LBB71_68
LBB71_68:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #300]
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_69:
	ldrb	w8, [sp, #59]
	tbz	w8, #0, LBB71_71
	b	LBB71_70
LBB71_70:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB71_79
	b	LBB71_71
LBB71_71:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB71_73
	b	LBB71_72
LBB71_72:
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #48]
	tbnz	w8, #0, LBB71_79
	b	LBB71_73
LBB71_73:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB71_79
	b	LBB71_74
LBB71_74:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB71_79
	b	LBB71_75
LBB71_75:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #336]
	cbnz	w8, LBB71_79
	b	LBB71_76
LBB71_76:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB71_79
	b	LBB71_77
LBB71_77:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB71_79
	b	LBB71_78
LBB71_78:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #344]
	cbz	x8, LBB71_80
	b	LBB71_79
LBB71_79:
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_80
LBB71_80:
	str	wzr, [sp, #52]
	str	wzr, [sp, #48]
	b	LBB71_81
LBB71_81:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB71_87 Depth 2
	ldr	w8, [sp, #48]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB71_92
	b	LBB71_82
LBB71_82:                               ;   in Loop: Header=BB71_81 Depth=1
	ldur	x8, [x29, #-48]
	add	x8, x8, #32
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	x8, LBB71_84
	b	LBB71_83
LBB71_83:                               ;   in Loop: Header=BB71_81 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB71_84
LBB71_84:                               ;   in Loop: Header=BB71_81 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB71_86
	b	LBB71_85
LBB71_85:                               ;   in Loop: Header=BB71_81 Depth=1
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_86
LBB71_86:                               ;   in Loop: Header=BB71_81 Depth=1
	strh	wzr, [sp, #46]
	b	LBB71_87
LBB71_87:                               ;   Parent Loop BB71_81 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #46]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9]
	ldr	w10, [sp, #48]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB71_90
	b	LBB71_88
LBB71_88:                               ;   in Loop: Header=BB71_87 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w9, [x8, x9]
	ldr	w8, [sp, #52]
	subs	w9, w9, #7
	cinc	w8, w8, eq
	str	w8, [sp, #52]
	b	LBB71_89
LBB71_89:                               ;   in Loop: Header=BB71_87 Depth=2
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB71_87
LBB71_90:                               ;   in Loop: Header=BB71_81 Depth=1
	b	LBB71_91
LBB71_91:                               ;   in Loop: Header=BB71_81 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB71_81
LBB71_92:
	ldr	w8, [sp, #52]
	cbz	w8, LBB71_95
	b	LBB71_93
LBB71_93:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #292]
	cbnz	w8, LBB71_95
	b	LBB71_94
LBB71_94:
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_95
LBB71_95:
	ldur	x8, [x29, #-24]
	cbz	x8, LBB71_99
	b	LBB71_96
LBB71_96:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #476]
	cbz	w8, LBB71_99
	b	LBB71_97
LBB71_97:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	cbnz	x8, LBB71_99
	b	LBB71_98
LBB71_98:
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #304]
	b	LBB71_99
LBB71_99:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #304]
	tbz	w8, #0, LBB71_101
	b	LBB71_100
LBB71_100:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-40]
	b	LBB71_102
LBB71_101:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-16]
	str	x9, [x10]
	mov	w0, #0                          ; =0x0
	bl	_oaa_result
	b	LBB71_103
LBB71_102:
	ldur	x0, [x29, #-48]
	bl	_nvm_ordinary_array_authority_free
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w0, [x29, #-40]
	bl	_oaa_result
	b	LBB71_103
LBB71_103:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_result
_oaa_result:                            ; @oaa_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	w0, [sp, #28]
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #16]
	ldr	w8, [sp, #28]
	cbnz	w8, LBB72_2
	b	LBB72_1
LBB72_1:
	adrp	x8, l_.str.1@PAGE
	add	x8, x8, l_.str.1@PAGEOFF
	str	x8, [sp, #16]
	b	LBB72_11
LBB72_2:
	ldr	w8, [sp, #28]
	subs	w8, w8, #2
	b.ne	LBB72_4
	b	LBB72_3
LBB72_3:
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	str	x8, [sp, #16]
	b	LBB72_10
LBB72_4:
	ldr	w8, [sp, #28]
	subs	w8, w8, #3
	b.ne	LBB72_6
	b	LBB72_5
LBB72_5:
	adrp	x8, l_.str.3@PAGE
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [sp, #16]
	b	LBB72_9
LBB72_6:
	ldr	w8, [sp, #28]
	subs	w8, w8, #4
	b.ne	LBB72_8
	b	LBB72_7
LBB72_7:
	adrp	x8, l_.str.4@PAGE
	add	x8, x8, l_.str.4@PAGEOFF
	str	x8, [sp, #16]
	b	LBB72_8
LBB72_8:
	b	LBB72_9
LBB72_9:
	b	LBB72_10
LBB72_10:
	b	LBB72_11
LBB72_11:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #28]
	str	w8, [x9]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	str	w8, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #16]
	str	x8, [x9, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oaa_preflight
_oaa_preflight:                         ; @oaa_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.hi	LBB73_2
	b	LBB73_1
LBB73_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB73_3
	b	LBB73_2
LBB73_2:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_3:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #56
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	wzr, [sp, #64]
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbz	w0, LBB73_5
	b	LBB73_4
LBB73_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_5:
	ldur	w8, [x29, #-60]
	subs	w8, w8, #256
	b.ls	LBB73_7
	b	LBB73_6
LBB73_6:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_7:
	str	wzr, [sp, #60]
	b	LBB73_8
LBB73_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB73_17
	b	LBB73_9
LBB73_9:                                ;   in Loop: Header=BB73_8 Depth=1
	sub	x0, x29, #56
	mov	x1, #8                          ; =0x8
	add	x2, sp, #48
	bl	_nvm_v2_take
	cbz	w0, LBB73_11
	b	LBB73_10
LBB73_10:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_11:                               ;   in Loop: Header=BB73_8 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #2]
	ldr	x9, [sp, #48]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #8
	strh	w8, [sp, #38]
	ldrh	w8, [sp, #38]
	ldr	w10, [sp, #64]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB73_13
	b	LBB73_12
LBB73_12:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_13:                               ;   in Loop: Header=BB73_8 Depth=1
	ldrh	w9, [sp, #38]
	ldr	w8, [sp, #64]
	add	w8, w8, w9
	str	w8, [sp, #64]
	ldrh	w8, [sp, #38]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x1, w8, w9
	sub	x0, x29, #56
	add	x2, sp, #40
	bl	_nvm_v2_take
	cbz	w0, LBB73_15
	b	LBB73_14
LBB73_14:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_15:                               ;   in Loop: Header=BB73_8 Depth=1
	b	LBB73_16
LBB73_16:                               ;   in Loop: Header=BB73_8 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB73_8
LBB73_17:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-48]
	subs	x8, x8, x9
	b.eq	LBB73_19
	b	LBB73_18
LBB73_18:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_19:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB73_22
	b	LBB73_20
LBB73_20:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB73_22
	b	LBB73_21
LBB73_21:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_22:
	ldr	w9, [sp, #64]
	ldur	w8, [x29, #-60]
	lsl	w8, w8, #2
	add	w8, w8, w9, lsl #2
	str	w8, [sp, #32]
	ldr	w8, [sp, #64]
	mov	w9, #3                          ; =0x3
	mul	w8, w8, w9
	ldur	w9, [x29, #-60]
	add	w8, w8, w9
	add	w8, w8, #33
	str	w8, [sp, #28]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	ldr	w10, [sp, #32]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	ldr	w10, [sp, #28]
	udiv	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB73_24
	b	LBB73_23
LBB73_23:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_24:
	str	wzr, [sp, #24]
	b	LBB73_25
LBB73_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB73_32
	b	LBB73_26
LBB73_26:                               ;   in Loop: Header=BB73_25 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	add	w8, w8, #1
	str	w8, [sp, #20]
	ldr	w8, [sp, #20]
	ldr	w10, [sp, #32]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	ldr	w10, [sp, #28]
	udiv	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB73_28
	b	LBB73_27
LBB73_27:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_28:                               ;   in Loop: Header=BB73_25 Depth=1
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #28]
	mul	w8, w8, w9
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
	ldr	w10, [sp, #32]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB73_30
	b	LBB73_29
LBB73_29:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_30:                               ;   in Loop: Header=BB73_25 Depth=1
	ldr	w9, [sp, #16]
	ldr	w8, [sp, #32]
	add	w8, w8, w9
	str	w8, [sp, #32]
	b	LBB73_31
LBB73_31:                               ;   in Loop: Header=BB73_25 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB73_25
LBB73_32:
	ldurb	w10, [x29, #-25]
	mov	w9, #65536                      ; =0x10000
	mov	w8, #131072                     ; =0x20000
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	str	w8, [sp, #12]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #476]
	ldr	w10, [sp, #32]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	ldr	w10, [sp, #12]
	udiv	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB73_34
	b	LBB73_33
LBB73_33:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB73_35
LBB73_34:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #476]
	ldr	w9, [sp, #12]
	mul	w9, w8, w9
	ldr	w8, [sp, #32]
	add	w8, w8, w9
	str	w8, [sp, #32]
	ldr	w8, [sp, #32]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB73_35
LBB73_35:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function declaration_result
_declaration_result:                    ; @declaration_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #12]
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp]
	ldr	w8, [sp, #12]
	cbnz	w8, LBB74_2
	b	LBB74_1
LBB74_1:
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	str	x8, [sp]
	b	LBB74_11
LBB74_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.ne	LBB74_4
	b	LBB74_3
LBB74_3:
	adrp	x8, l_.str.2@PAGE
	add	x8, x8, l_.str.2@PAGEOFF
	str	x8, [sp]
	b	LBB74_10
LBB74_4:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	b.ne	LBB74_6
	b	LBB74_5
LBB74_5:
	adrp	x8, l_.str.7@PAGE
	add	x8, x8, l_.str.7@PAGEOFF
	str	x8, [sp]
	b	LBB74_9
LBB74_6:
	ldr	w8, [sp, #12]
	subs	w8, w8, #4
	b.ne	LBB74_8
	b	LBB74_7
LBB74_7:
	adrp	x8, l_.str.8@PAGE
	add	x8, x8, l_.str.8@PAGEOFF
	str	x8, [sp]
	b	LBB74_8
LBB74_8:
	b	LBB74_9
LBB74_9:
	b	LBB74_10
LBB74_10:
	b	LBB74_11
LBB74_11:
	ldr	w8, [sp, #12]
	str	w8, [sp, #16]
	str	wzr, [sp, #20]
	ldr	x8, [sp]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufd_result
_ufd_result:                            ; @ufd_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	w0, [sp, #44]
	str	x1, [sp, #32]
	str	x2, [sp, #24]
	adrp	x8, l_.str.14@PAGE
	add	x8, x8, l_.str.14@PAGEOFF
	str	x8, [sp, #16]
	ldr	w8, [sp, #44]
	cbnz	w8, LBB75_2
	b	LBB75_1
LBB75_1:
	adrp	x8, l_.str.15@PAGE
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [sp, #16]
	b	LBB75_11
LBB75_2:
	ldr	w8, [sp, #44]
	subs	w8, w8, #1
	b.ne	LBB75_4
	b	LBB75_3
LBB75_3:
	adrp	x8, l_.str.16@PAGE
	add	x8, x8, l_.str.16@PAGEOFF
	str	x8, [sp, #16]
	b	LBB75_10
LBB75_4:
	ldr	w8, [sp, #44]
	subs	w8, w8, #3
	b.ne	LBB75_6
	b	LBB75_5
LBB75_5:
	adrp	x8, l_.str.17@PAGE
	add	x8, x8, l_.str.17@PAGEOFF
	str	x8, [sp, #16]
	b	LBB75_9
LBB75_6:
	ldr	w8, [sp, #44]
	subs	w8, w8, #4
	b.ne	LBB75_8
	b	LBB75_7
LBB75_7:
	adrp	x8, l_.str.18@PAGE
	add	x8, x8, l_.str.18@PAGEOFF
	str	x8, [sp, #16]
	b	LBB75_8
LBB75_8:
	b	LBB75_9
LBB75_9:
	b	LBB75_10
LBB75_10:
	b	LBB75_11
LBB75_11:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #44]
	str	w8, [x9]
	str	wzr, [x9, #4]
	ldr	x8, [sp, #16]
	str	x8, [x9, #8]
	ldr	x8, [sp, #32]
	str	x8, [x9, #16]
	ldr	x8, [sp, #24]
	str	x8, [x9, #24]
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I could not establish complete ordinary array declarations."

l_.str.1:                               ; @.str.1
	.asciz	"I copied ordinary array declarations without executable admission."

l_.str.2:                               ; @.str.2
	.asciz	"I require consistent complete declaration bytes."

l_.str.3:                               ; @.str.3
	.asciz	"I reached my bounded declaration budget."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate my declaration report."

l_.str.5:                               ; @.str.5
	.asciz	"I could not establish complete mixed declarations."

l_.str.6:                               ; @.str.6
	.asciz	"I copied complete declarations without execution authority."

l_.str.7:                               ; @.str.7
	.asciz	"I reached my declaration storage or work bound."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate my declaration projection."

l_.str.9:                               ; @.str.9
	.asciz	"I require complete exact map declarations."

l_.str.10:                              ; @.str.10
	.asciz	"I found no map declaration route."

l_.str.11:                              ; @.str.11
	.asciz	"I copied exact map declarations without execution authority."

l_.str.12:                              ; @.str.12
	.asciz	"I reached my map declaration bound."

l_.str.13:                              ; @.str.13
	.asciz	"I could not allocate map declarations."

l_.str.14:                              ; @.str.14
	.asciz	"I require consistent union declaration bytes."

l_.str.15:                              ; @.str.15
	.asciz	"I copied union declarations without execution authority."

l_.str.16:                              ; @.str.16
	.asciz	"I could not establish the supported union declarations."

l_.str.17:                              ; @.str.17
	.asciz	"I reached the union declaration bound."

l_.str.18:                              ; @.str.18
	.asciz	"I could not allocate union declarations."

.subsections_via_symbols
