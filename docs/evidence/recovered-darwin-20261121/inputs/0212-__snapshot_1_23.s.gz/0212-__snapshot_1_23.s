	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_multi_nominal_storage_bound ; -- Begin function nvm_multi_nominal_storage_bound
	.globl	_nvm_multi_nominal_storage_bound
	.p2align	2
_nvm_multi_nominal_storage_bound:       ; @nvm_multi_nominal_storage_bound
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	w0, #16, lsl #12                ; =65536
	ccmp	x1, #0, #4, ls
	cset	w0, ne
	b.eq	LBB0_2
; %bb.1:
	mov	w9, #24                         ; =0x18
	mov	w10, #3848                      ; =0xf08
	madd	w8, w8, w9, w10
	str	x8, [x1]
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_plan ; -- Begin function nvm_multi_nominal_plan
	.globl	_nvm_multi_nominal_plan
	.p2align	2
_nvm_multi_nominal_plan:                ; @nvm_multi_nominal_plan
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #3952
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	cbz	x19, LBB1_12
; %bb.1:
	cbz	x1, LBB1_12
; %bb.2:
	mov	x25, x1
	ldr	x0, [x19, #328]
	ldr	w1, [x19, #336]
	add	x2, sp, #56
	bl	_nvm_multi_nominal_decode
	cbnz	w0, LBB1_11
; %bb.3:
	ldr	w8, [sp, #56]
	cbz	w8, LBB1_7
; %bb.4:
	mov	x21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	w22, #4                         ; =0x4
	add	x23, sp, #56
LBB1_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w0, [x23, x22]
	bl	_nvm_multi_nominal_catalog_methods
	add	w20, w0, w20
	add	x21, x21, #1
	ldr	w8, [sp, #56]
	add	x22, x22, #60
	cmp	x21, x8
	b.lo	LBB1_5
; %bb.6:
	cmp	w8, #0
	cset	w8, eq
	b	LBB1_8
LBB1_7:
	mov	w20, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
LBB1_8:
	ldr	w9, [x19, #432]
	cmp	w9, w20
	b.ne	LBB1_11
; %bb.9:
	ldr	x9, [x19, #400]
	cbz	x9, LBB1_11
; %bb.10:
	ldr	w9, [x19, #448]
	cbz	w9, LBB1_13
LBB1_11:
	mov	w0, #1                          ; =0x1
LBB1_12:
	add	sp, sp, #3952
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_13:
	ldr	w9, [x19, #424]
	cmp	w9, #0
	csinc	w8, w8, wzr, eq
	tbz	w8, #0, LBB1_38
; %bb.14:
	cbnz	w9, LBB1_11
LBB1_15:
	str	wzr, [sp, #52]
	add	x1, sp, #56
	add	x2, sp, #52
	mov	x0, x19
	mov	x3, #0                          ; =0x0
	bl	_layouts_read
	cbnz	w0, LBB1_12
; %bb.16:
	ldr	x1, [x19, #296]
	cbz	x1, LBB1_11
; %bb.17:
	ldr	w2, [x19, #304]
	cbz	w2, LBB1_11
; %bb.18:
	ldr	w20, [sp, #52]
	sub	x0, x29, #112
	bl	_nvm_v2_cursor_init
	sub	x0, x29, #112
	sub	x1, x29, #116
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_11
; %bb.19:
	ldur	w8, [x29, #-116]
	cmp	w8, #1
	b.ne	LBB1_11
; %bb.20:
	sub	x0, x29, #112
	sub	x1, x29, #120
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_11
; %bb.21:
	ldur	w8, [x29, #-120]
	cmp	w8, w20
	b.ne	LBB1_11
; %bb.22:
	sub	x0, x29, #112
	sub	x2, x29, #128
	mov	x1, x20
	bl	_nvm_v2_take
	cbnz	w0, LBB1_11
; %bb.23:
	sub	x0, x29, #112
	bl	_nvm_v2_align4
	cbnz	w0, LBB1_11
; %bb.24:
	ldur	w8, [x29, #-120]
	str	x20, [sp, #8]                   ; 8-byte Folded Spill
	cbz	w8, LBB1_83
; %bb.25:
	mov	x22, #0                         ; =0x0
	add	x8, sp, #56
	add	x9, x8, #4
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	add	x8, x8, #28
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
LBB1_26:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_29 Depth 2
                                        ;       Child Loop BB1_31 Depth 3
	sub	x8, x29, #128
	ldr	x8, [x8]
	ldrb	w9, [x8, x22]
	ldr	w8, [sp, #56]
	cbz	w8, LBB1_35
; %bb.27:                               ;   in Loop: Header=BB1_26 Depth=1
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	mov	w27, #0                         ; =0x0
	str	wzr, [sp, #40]                  ; 4-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x28, #-1                        ; =0xffffffffffffffff
	ldr	x20, [sp, #16]                  ; 8-byte Folded Reload
	b	LBB1_29
LBB1_28:                                ;   in Loop: Header=BB1_29 Depth=2
	add	x26, x26, #1
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	sub	w8, w8, #9
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #56]
	add	w27, w27, #9
	sub	x28, x28, #9
	add	x20, x20, #60
	cmp	x26, x8
	b.hs	LBB1_37
LBB1_29:                                ;   Parent Loop BB1_26 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_31 Depth 3
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w9, #60                         ; =0x3c
	madd	x21, x26, x9, x8
	ldr	w0, [x21]
	bl	_nvm_multi_nominal_catalog_types
	cbz	w0, LBB1_28
; %bb.30:                               ;   in Loop: Header=BB1_29 Depth=2
	mov	x23, #0                         ; =0x0
	mov	x24, x27
LBB1_31:                                ;   Parent Loop BB1_26 Depth=1
                                        ;     Parent Loop BB1_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x20, x23, lsl #2]
	cmp	x22, x8
	b.eq	LBB1_33
; %bb.32:                               ;   in Loop: Header=BB1_31 Depth=3
	add	x23, x23, #1
	ldr	w0, [x21]
	bl	_nvm_multi_nominal_catalog_types
	add	w24, w24, #1
	cmp	x23, w0, uxtw
	b.lo	LBB1_31
	b	LBB1_28
LBB1_33:                                ;   in Loop: Header=BB1_26 Depth=1
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w24, w8
	lsr	x8, x8, #33
	add	w8, w8, w8, lsl #3
	ldr	w9, [sp, #40]                   ; 4-byte Folded Reload
	add	w8, w9, w8
	add	w9, w8, #3
	cmp	w9, w23
	ccmp	w8, w23, #4, ne
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
	cmp	w28, w23
	csel	w8, wzr, w8, eq
LBB1_34:                                ;   in Loop: Header=BB1_26 Depth=1
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
LBB1_35:                                ;   in Loop: Header=BB1_26 Depth=1
	cmp	w9, w8
	b.ne	LBB1_11
; %bb.36:                               ;   in Loop: Header=BB1_26 Depth=1
	add	x22, x22, #1
	ldur	w8, [x29, #-120]
	cmp	x22, x8
	b.lo	LBB1_26
	b	LBB1_83
LBB1_37:                                ;   in Loop: Header=BB1_26 Depth=1
	mov	w8, #0                          ; =0x0
	b	LBB1_34
LBB1_38:
	mov	x28, #0                         ; =0x0
	add	x8, sp, #56
	add	x24, x8, #4
	mov	w20, #60                        ; =0x3c
	mov	w22, #12                        ; =0xc
LBB1_39:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_41 Depth 2
                                        ;       Child Loop BB1_74 Depth 3
	madd	x23, x28, x20, x24
	ldr	w0, [x23]
	bl	_nvm_multi_nominal_catalog_methods
	cbz	w0, LBB1_82
; %bb.40:                               ;   in Loop: Header=BB1_39 Depth=1
	mov	x26, #0                         ; =0x0
	add	x9, x23, #4
	stp	x23, x24, [sp, #8]              ; 16-byte Folded Spill
	str	x9, [sp]                        ; 8-byte Folded Spill
	str	x28, [sp, #40]                  ; 8-byte Folded Spill
LBB1_41:                                ;   Parent Loop BB1_39 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_74 Depth 3
	ldr	w20, [x9, x26, lsl #2]
	ldr	w8, [x19, #432]
	cmp	w20, w8
	b.hs	LBB1_11
; %bb.42:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x21, [x19, #400]
	ldr	w8, [x23]
	mov	x0, x26
	cmp	w8, #2
	b.eq	LBB1_45
; %bb.43:                               ;   in Loop: Header=BB1_41 Depth=2
	cmp	w8, #1
	b.ne	LBB1_46
; %bb.44:                               ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_file_catalog_method
	b	LBB1_47
LBB1_45:                                ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_socket_catalog_method
	b	LBB1_47
LBB1_46:                                ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_websocket_catalog_method
LBB1_47:                                ;   in Loop: Header=BB1_41 Depth=2
	mov	x27, x0
	cbz	x0, LBB1_11
; %bb.48:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x8, [x27, #56]
	cbz	x8, LBB1_11
; %bb.49:                               ;   in Loop: Header=BB1_41 Depth=2
	str	x26, [sp, #24]                  ; 8-byte Folded Spill
	umaddl	x26, w20, w22, x21
	sub	x8, x8, #1
	ldrh	w9, [x26, #8]
	cmp	x8, x9
	b.ne	LBB1_11
; %bb.50:                               ;   in Loop: Header=BB1_41 Depth=2
	ldrb	w8, [x26, #11]
	cmp	w8, #3
	b.ne	LBB1_11
; %bb.51:                               ;   in Loop: Header=BB1_41 Depth=2
	ldrb	w8, [x26, #10]
	cmp	w8, #10
	b.ne	LBB1_11
; %bb.52:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	w21, [x26]
	ldr	w8, [x23]
	cmp	w8, #2
	str	x20, [sp, #32]                  ; 8-byte Folded Spill
	b.eq	LBB1_55
; %bb.53:                               ;   in Loop: Header=BB1_41 Depth=2
	cmp	w8, #1
	b.ne	LBB1_56
; %bb.54:                               ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_file_catalog_interface
	b	LBB1_57
LBB1_55:                                ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_socket_catalog_interface
	b	LBB1_57
LBB1_56:                                ;   in Loop: Header=BB1_41 Depth=2
	bl	_nl_websocket_catalog_interface
LBB1_57:                                ;   in Loop: Header=BB1_41 Depth=2
	mov	x23, x0
	ldr	w20, [x19, #248]
	cmp	w21, w20
	b.hs	LBB1_11
; %bb.58:                               ;   in Loop: Header=BB1_41 Depth=2
	mov	x22, x27
	ldr	x27, [x19, #232]
	cbz	x27, LBB1_11
; %bb.59:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x28, [x19, #240]
	cbz	x28, LBB1_11
; %bb.60:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x24, [x27, x21, lsl #3]
	cbz	x24, LBB1_11
; %bb.61:                               ;   in Loop: Header=BB1_41 Depth=2
	mov	x0, x23
	bl	_strlen
	ldr	w8, [x28, x21, lsl #2]
	cmp	x0, x8
	b.ne	LBB1_11
; %bb.62:                               ;   in Loop: Header=BB1_41 Depth=2
	mov	x2, x0
	mov	x0, x24
	mov	x1, x23
	bl	_memcmp
	cbnz	w0, LBB1_11
; %bb.63:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	w21, [x26, #4]
	cmp	w21, w20
	b.hs	LBB1_11
; %bb.64:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x23, [x27, x21, lsl #3]
	cbz	x23, LBB1_11
; %bb.65:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x24, [x22]
	mov	x0, x24
	bl	_strlen
	ldr	w8, [x28, x21, lsl #2]
	cmp	x0, x8
	b.ne	LBB1_11
; %bb.66:                               ;   in Loop: Header=BB1_41 Depth=2
	mov	x2, x0
	mov	x0, x23
	mov	x1, x24
	bl	_memcmp
	cbnz	w0, LBB1_11
; %bb.67:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x8, [x19, #408]
	cbz	x8, LBB1_69
; %bb.68:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x23, [x8, x9, lsl #3]
	b	LBB1_70
LBB1_69:                                ;   in Loop: Header=BB1_41 Depth=2
	mov	x23, #0                         ; =0x0
LBB1_70:                                ;   in Loop: Header=BB1_41 Depth=2
	ldr	x28, [sp, #40]                  ; 8-byte Folded Reload
	ldrh	w8, [x26, #8]
	cbz	w8, LBB1_72
; %bb.71:                               ;   in Loop: Header=BB1_41 Depth=2
	cbz	x23, LBB1_11
LBB1_72:                                ;   in Loop: Header=BB1_41 Depth=2
	cbz	w8, LBB1_78
; %bb.73:                               ;   in Loop: Header=BB1_41 Depth=2
	mov	x21, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
LBB1_74:                                ;   Parent Loop BB1_39 Depth=1
                                        ;     Parent Loop BB1_41 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x8, [x22, #48]
	add	x8, x8, x21
	ldr	w9, [x8, #24]
	cbnz	w9, LBB1_11
; %bb.75:                               ;   in Loop: Header=BB1_74 Depth=3
	ldr	x2, [x8, #16]
	add	x0, sp, #56
	sub	x3, x29, #128
	sub	x4, x29, #112
	mov	x1, x28
	bl	_member_type
	cbz	w0, LBB1_11
; %bb.76:                               ;   in Loop: Header=BB1_74 Depth=3
	ldrb	w8, [x23, x24]
	ldurb	w9, [x29, #-128]
	cmp	w8, w9
	b.ne	LBB1_11
; %bb.77:                               ;   in Loop: Header=BB1_74 Depth=3
	add	x24, x24, #1
	ldrh	w8, [x26, #8]
	add	x21, x21, #48
	cmp	x24, x8
	b.lo	LBB1_74
	b	LBB1_79
LBB1_78:                                ;   in Loop: Header=BB1_41 Depth=2
	mov	x8, #0                          ; =0x0
LBB1_79:                                ;   in Loop: Header=BB1_41 Depth=2
	ldr	x9, [x22, #48]
	mov	w10, #48                        ; =0x30
	umaddl	x8, w8, w10, x9
	ldr	w9, [x8, #24]
	cmp	w9, #3
	b.ne	LBB1_11
; %bb.80:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x2, [x8, #16]
	add	x0, sp, #56
	sub	x3, x29, #128
	sub	x4, x29, #112
	mov	x1, x28
	bl	_member_type
	ldurb	w8, [x29, #-128]
	cmp	w0, #0
	ccmp	w8, #10, #0, ne
	b.ne	LBB1_11
; %bb.81:                               ;   in Loop: Header=BB1_41 Depth=2
	ldr	x26, [sp, #24]                  ; 8-byte Folded Reload
	add	x26, x26, #1
	ldr	x23, [sp, #8]                   ; 8-byte Folded Reload
	ldr	w0, [x23]
	bl	_nvm_multi_nominal_catalog_methods
	cmp	x26, w0, uxtw
	ldr	x24, [sp, #16]                  ; 8-byte Folded Reload
	mov	w20, #60                        ; =0x3c
	mov	w22, #12                        ; =0xc
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	b.lo	LBB1_41
LBB1_82:                                ;   in Loop: Header=BB1_39 Depth=1
	add	x28, x28, #1
	ldr	w8, [sp, #56]
	cmp	x28, x8
	b.lo	LBB1_39
	b	LBB1_15
LBB1_83:
	sub	x0, x29, #112
	sub	x1, x29, #120
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_11
; %bb.84:
	ldur	w8, [x29, #-120]
	ldr	w9, [x19, #272]
	cmp	w8, w9
	b.ne	LBB1_11
; %bb.85:
	cbz	w8, LBB1_89
; %bb.86:
	ldr	x9, [x19, #256]
	cbz	x9, LBB1_11
; %bb.87:
	sub	x10, x29, #128
	ldp	x9, x10, [x10, #24]
	sub	x9, x9, x10
	mov	x10, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x10, #43691
	umulh	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB1_11
; %bb.88:
	mov	x22, #0                         ; =0x0
	mov	w23, #24                        ; =0x18
	b	LBB1_95
LBB1_89:
	sub	x9, x29, #128
	ldp	x8, x9, [x9, #24]
	cmp	x9, x8
	b.ne	LBB1_11
LBB1_90:
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	umull	x8, w9, w8
	add	x0, x8, #3848
	bl	_malloc
	cbz	x0, LBB1_118
; %bb.91:
	mov	x21, x0
	add	x1, sp, #56
	mov	w2, #3844                       ; =0xf04
	bl	_memcpy
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	w8, [x21, #3844]
	stur	wzr, [x29, #-112]
	add	x1, sp, #56
	sub	x2, x29, #112
	add	x3, x21, #3848
	mov	x0, x19
	bl	_layouts_read
	cbnz	w0, LBB1_119
; %bb.92:
	ldur	w8, [x29, #-112]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	cmp	w8, w9
	b.ne	LBB1_119
; %bb.93:
	mov	w0, #0                          ; =0x0
	str	x21, [x25]
	b	LBB1_12
LBB1_94:                                ;   in Loop: Header=BB1_95 Depth=1
	add	x22, x22, #1
	ldur	w8, [x29, #-120]
	cmp	x22, x8
	b.hs	LBB1_120
LBB1_95:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_113 Depth 2
	ldr	x20, [x19, #256]
	sub	x0, x29, #112
	sub	x1, x29, #130
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_11
; %bb.96:                               ;   in Loop: Header=BB1_95 Depth=1
	sub	x0, x29, #112
	sub	x1, x29, #132
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_11
; %bb.97:                               ;   in Loop: Header=BB1_95 Depth=1
	madd	x8, x22, x23, x20
	ldurh	w9, [x29, #-130]
	ldrh	w10, [x8, #16]
	cmp	w9, w10
	b.ne	LBB1_11
; %bb.98:                               ;   in Loop: Header=BB1_95 Depth=1
	ldurh	w10, [x29, #-132]
	cmp	w10, w9
	b.hi	LBB1_11
; %bb.99:                               ;   in Loop: Header=BB1_95 Depth=1
	ldrh	w11, [x8, #4]
	cmp	w10, w11
	b.ne	LBB1_11
; %bb.100:                              ;   in Loop: Header=BB1_95 Depth=1
	ldrb	w10, [x8, #21]
	cmp	w10, #1
	b.hi	LBB1_11
; %bb.101:                              ;   in Loop: Header=BB1_95 Depth=1
	sub	x12, x29, #128
	ldp	x11, x12, [x12, #24]
	sub	x11, x11, x12
	cmp	x9, x11, lsr #3
	b.hs	LBB1_11
; %bb.102:                              ;   in Loop: Header=BB1_95 Depth=1
	cbz	w10, LBB1_104
; %bb.103:                              ;   in Loop: Header=BB1_95 Depth=1
	ldrb	w3, [x8, #20]
	b	LBB1_105
LBB1_104:                               ;   in Loop: Header=BB1_95 Depth=1
	mov	w3, #0                          ; =0x0
LBB1_105:                               ;   in Loop: Header=BB1_95 Depth=1
	sub	x0, x29, #112
	add	x1, sp, #56
	mov	w2, #0                          ; =0x0
	bl	_descriptor_read
	cbz	w0, LBB1_11
; %bb.106:                              ;   in Loop: Header=BB1_95 Depth=1
	ldr	x8, [x19, #264]
	cbz	x8, LBB1_108
; %bb.107:                              ;   in Loop: Header=BB1_95 Depth=1
	ldr	x20, [x8, x22, lsl #3]
	b	LBB1_109
LBB1_108:                               ;   in Loop: Header=BB1_95 Depth=1
	mov	x20, #0                         ; =0x0
LBB1_109:                               ;   in Loop: Header=BB1_95 Depth=1
	ldurh	w8, [x29, #-132]
	cbz	w8, LBB1_111
; %bb.110:                              ;   in Loop: Header=BB1_95 Depth=1
	cbz	x20, LBB1_11
LBB1_111:                               ;   in Loop: Header=BB1_95 Depth=1
	ldurh	w8, [x29, #-130]
	cbz	w8, LBB1_94
; %bb.112:                              ;   in Loop: Header=BB1_95 Depth=1
	mov	x21, #0                         ; =0x0
LBB1_113:                               ;   Parent Loop BB1_95 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-132]
	cmp	x21, x8
	b.hs	LBB1_115
; %bb.114:                              ;   in Loop: Header=BB1_113 Depth=2
	ldrb	w3, [x20, x21]
	b	LBB1_116
LBB1_115:                               ;   in Loop: Header=BB1_113 Depth=2
	mov	w3, #-1                         ; =0xffffffff
LBB1_116:                               ;   in Loop: Header=BB1_113 Depth=2
	cmp	x21, x8
	cset	w2, lo
	sub	x0, x29, #112
	add	x1, sp, #56
	bl	_descriptor_read
	tbz	w0, #0, LBB1_11
; %bb.117:                              ;   in Loop: Header=BB1_113 Depth=2
	add	x21, x21, #1
	ldurh	w8, [x29, #-130]
	cmp	x21, x8
	b.lo	LBB1_113
	b	LBB1_94
LBB1_118:
	mov	w0, #3                          ; =0x3
	b	LBB1_12
LBB1_119:
	mov	x0, x21
	bl	_free
	b	LBB1_11
LBB1_120:
	sub	x8, x29, #128
	ldp	x8, x9, [x8, #24]
	cmp	x9, x8
	b.ne	LBB1_11
	b	LBB1_90
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_read
_layouts_read:                          ; @layouts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	ldr	x1, [x0, #312]
	cbz	x1, LBB2_3
; %bb.1:
	ldr	w8, [x0, #320]
	cbz	w8, LBB2_3
; %bb.2:
	mov	x26, x3
	mov	x19, x0
	mov	x25, x2
	add	x0, sp, #72
	mov	x2, x8
	bl	_nvm_v2_cursor_init
	add	x0, sp, #72
	add	x1, sp, #68
	bl	_nvm_v2_u32
	cbz	w0, LBB2_5
LBB2_3:
	mov	w0, #1                          ; =0x1
LBB2_4:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB2_5:
	ldr	w9, [sp, #68]
	cmp	w9, #16, lsl #12                ; =65536
	b.ls	LBB2_7
; %bb.6:
	mov	w0, #2                          ; =0x2
	b	LBB2_4
LBB2_7:
	ldr	w8, [x20]
	cbz	w8, LBB2_14
; %bb.8:
	mov	x23, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	add	x21, x20, #4
	mov	w24, #4                         ; =0x4
LBB2_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w0, [x20, x24]
	bl	_nvm_multi_nominal_catalog_types
	add	w22, w0, w22
	add	x23, x23, #1
	ldr	w8, [x20]
	add	x24, x24, #60
	cmp	x23, x8
	b.lo	LBB2_9
; %bb.10:
	ldr	w9, [sp, #68]
	cmp	w9, w22
	b.lo	LBB2_3
; %bb.11:
	ldp	x10, x11, [sp, #80]
	sub	x10, x10, x11
	cmp	x9, x10, lsr #3
	b.hi	LBB2_3
; %bb.12:
	cbz	w8, LBB2_20
; %bb.13:
	mov	x22, #0                         ; =0x0
	add	x23, x20, #28
	mov	w24, #60                        ; =0x3c
	b	LBB2_16
LBB2_14:
	ldp	x8, x10, [sp, #80]
	sub	x8, x8, x10
	cmp	x9, x8, lsr #3
	mov	x8, x25
	b.ls	LBB2_22
	b	LBB2_3
LBB2_15:                                ;   in Loop: Header=BB2_16 Depth=1
	add	x22, x22, #1
	ldr	w8, [x20]
	add	x23, x23, #60
	cmp	x22, x8
	b.hs	LBB2_81
LBB2_16:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_18 Depth 2
	madd	x27, x22, x24, x21
	ldr	w0, [x27]
	bl	_nvm_multi_nominal_catalog_types
	cbz	w0, LBB2_15
; %bb.17:                               ;   in Loop: Header=BB2_16 Depth=1
	mov	x28, #0                         ; =0x0
LBB2_18:                                ;   Parent Loop BB2_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x23, x28, lsl #2]
	ldr	w9, [sp, #68]
	cmp	w8, w9
	b.hs	LBB2_3
; %bb.19:                               ;   in Loop: Header=BB2_18 Depth=2
	add	x28, x28, #1
	ldr	w0, [x27]
	bl	_nvm_multi_nominal_catalog_types
	cmp	x28, w0, uxtw
	b.lo	LBB2_18
	b	LBB2_15
LBB2_20:
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
LBB2_21:
	mov	x8, x25
LBB2_22:
	cbz	w9, LBB2_75
; %bb.23:
	mov	x21, #0                         ; =0x0
	str	wzr, [sp, #28]                  ; 4-byte Folded Spill
	mov	w28, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	add	x8, x20, #4
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB2_24:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_48 Depth 2
	add	x0, sp, #72
	add	x1, sp, #67
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.25:                               ;   in Loop: Header=BB2_24 Depth=1
	add	x0, sp, #72
	add	x1, sp, #66
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.26:                               ;   in Loop: Header=BB2_24 Depth=1
	add	x0, sp, #72
	add	x1, sp, #64
	bl	_nvm_v2_u16
	cbnz	w0, LBB2_3
; %bb.27:                               ;   in Loop: Header=BB2_24 Depth=1
	add	x0, sp, #72
	add	x1, sp, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.28:                               ;   in Loop: Header=BB2_24 Depth=1
	ldrb	w8, [sp, #66]
	cbnz	w8, LBB2_3
; %bb.29:                               ;   in Loop: Header=BB2_24 Depth=1
	ldrb	w8, [sp, #67]
	cmp	w8, #3
	b.hi	LBB2_3
; %bb.30:                               ;   in Loop: Header=BB2_24 Depth=1
	ldr	w8, [sp, #60]
	cmn	w8, #1
	b.eq	LBB2_32
; %bb.31:                               ;   in Loop: Header=BB2_24 Depth=1
	ldr	w9, [x19, #248]
	cmp	w8, w9
	b.hs	LBB2_3
LBB2_32:                                ;   in Loop: Header=BB2_24 Depth=1
	ldrh	w8, [sp, #64]
	ldp	x9, x10, [sp, #80]
	sub	x9, x9, x10
	mov	x10, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x10, #43691
	umulh	x9, x9, x10
	cmp	x8, x9, lsr #3
	b.hi	LBB2_3
; %bb.33:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	x0, x20
	mov	x1, x21
	bl	_catalog_at
	mov	x22, x0
	ldrb	w8, [sp, #67]
	cmp	w8, #3
	b.eq	LBB2_38
; %bb.34:                               ;   in Loop: Header=BB2_24 Depth=1
	cmp	w8, #2
	b.eq	LBB2_37
; %bb.35:                               ;   in Loop: Header=BB2_24 Depth=1
	cbnz	w8, LBB2_39
; %bb.36:                               ;   in Loop: Header=BB2_24 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	add	w8, w8, #1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB2_40
LBB2_37:                                ;   in Loop: Header=BB2_24 Depth=1
	str	w27, [sp, #16]                  ; 4-byte Folded Spill
	add	w27, w27, #1
	b	LBB2_40
LBB2_38:                                ;   in Loop: Header=BB2_24 Depth=1
	add	w28, w28, #1
LBB2_39:                                ;   in Loop: Header=BB2_24 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
LBB2_40:                                ;   in Loop: Header=BB2_24 Depth=1
	cmn	w22, #1
	b.eq	LBB2_45
; %bb.41:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	x0, x20
	mov	x1, x22
	bl	_type_at
	cbz	x0, LBB2_3
; %bb.42:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	x23, x0
	ldrb	w24, [sp, #67]
	mov	x0, x20
	mov	x1, x22
	bl	_type_kind
	cmp	w24, w0
	b.ne	LBB2_3
; %bb.43:                               ;   in Loop: Header=BB2_24 Depth=1
	ldrh	w24, [sp, #64]
	ldr	x8, [x23, #32]
	cmp	x8, x24
	b.ne	LBB2_3
; %bb.44:                               ;   in Loop: Header=BB2_24 Depth=1
	ldr	w1, [sp, #60]
	ldr	x2, [x23]
	mov	x0, x19
	bl	_text
	cbnz	w0, LBB2_46
	b	LBB2_3
LBB2_45:                                ;   in Loop: Header=BB2_24 Depth=1
	mov	x23, #0                         ; =0x0
	ldrh	w24, [sp, #64]
LBB2_46:                                ;   in Loop: Header=BB2_24 Depth=1
	stp	w28, w27, [sp, #20]             ; 8-byte Folded Spill
	cbz	w24, LBB2_68
; %bb.47:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	x27, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w22, w8
	lsr	x8, x8, #33
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
LBB2_48:                                ;   Parent Loop BB2_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #72
	add	x1, sp, #59
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.49:                               ;   in Loop: Header=BB2_48 Depth=2
	add	x0, sp, #72
	add	x1, sp, #58
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.50:                               ;   in Loop: Header=BB2_48 Depth=2
	add	x0, sp, #72
	add	x1, sp, #57
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.51:                               ;   in Loop: Header=BB2_48 Depth=2
	add	x0, sp, #72
	add	x1, sp, #56
	bl	_nvm_v2_u8
	cbnz	w0, LBB2_3
; %bb.52:                               ;   in Loop: Header=BB2_48 Depth=2
	add	x0, sp, #72
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.53:                               ;   in Loop: Header=BB2_48 Depth=2
	add	x0, sp, #72
	add	x1, sp, #48
	bl	_nvm_v2_u32
	cbnz	w0, LBB2_3
; %bb.54:                               ;   in Loop: Header=BB2_48 Depth=2
	ldrb	w8, [sp, #59]
	cmp	w8, #15
	b.hi	LBB2_3
; %bb.55:                               ;   in Loop: Header=BB2_48 Depth=2
	ldrb	w8, [sp, #58]
	cbnz	w8, LBB2_3
; %bb.56:                               ;   in Loop: Header=BB2_48 Depth=2
	ldrb	w8, [sp, #57]
	cbnz	w8, LBB2_3
; %bb.57:                               ;   in Loop: Header=BB2_48 Depth=2
	ldrb	w8, [sp, #56]
	cbnz	w8, LBB2_3
; %bb.58:                               ;   in Loop: Header=BB2_48 Depth=2
	ldr	w8, [sp, #48]
	cmn	w8, #1
	b.eq	LBB2_60
; %bb.59:                               ;   in Loop: Header=BB2_48 Depth=2
	ldr	w9, [x19, #248]
	cmp	w8, w9
	b.hs	LBB2_3
LBB2_60:                                ;   in Loop: Header=BB2_48 Depth=2
	ldr	w8, [sp, #52]
	cmn	w8, #1
	b.eq	LBB2_62
; %bb.61:                               ;   in Loop: Header=BB2_48 Depth=2
	cmp	x21, x8
	b.ls	LBB2_3
LBB2_62:                                ;   in Loop: Header=BB2_48 Depth=2
	cbz	x23, LBB2_67
; %bb.63:                               ;   in Loop: Header=BB2_48 Depth=2
	ldr	x24, [x23, #24]
	add	x8, x24, x27
	ldr	x2, [x8, #16]
	add	x3, sp, #47
	add	x4, sp, #40
	mov	x0, x20
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_member_type
	cbz	w0, LBB2_3
; %bb.64:                               ;   in Loop: Header=BB2_48 Depth=2
	ldrb	w8, [sp, #59]
	ldrb	w9, [sp, #47]
	cmp	w8, w9
	b.ne	LBB2_3
; %bb.65:                               ;   in Loop: Header=BB2_48 Depth=2
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #40]
	cmp	w8, w9
	b.ne	LBB2_3
; %bb.66:                               ;   in Loop: Header=BB2_48 Depth=2
	ldr	w1, [sp, #48]
	ldr	x2, [x24, x27]
	mov	x0, x19
	bl	_text
	cbz	w0, LBB2_3
LBB2_67:                                ;   in Loop: Header=BB2_48 Depth=2
	add	x28, x28, #1
	ldrh	w8, [sp, #64]
	add	x27, x27, #32
	cmp	x28, x8
	b.lo	LBB2_48
LBB2_68:                                ;   in Loop: Header=BB2_24 Depth=1
	mov	x8, x25
	ldp	w28, w27, [sp, #20]             ; 8-byte Folded Reload
	cbz	x26, LBB2_73
; %bb.69:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	x9, x26
	mov	w10, #36409                     ; =0x8e39
	movk	w10, #14563, lsl #16
	umull	x10, w22, w10
	lsr	x12, x10, #33
	cmn	w22, #1
	csinv	w10, w12, wzr, ne
	b.eq	LBB2_71
; %bb.70:                               ;   in Loop: Header=BB2_24 Depth=1
	mov	w11, #60                        ; =0x3c
	umull	x11, w12, w11
	ldr	x13, [sp, #8]                   ; 8-byte Folded Reload
	ldr	w11, [x13, x11]
	add	w12, w12, w12, lsl #3
	sub	w13, w22, w12
	cmp	w13, #3
	ccmp	w13, #0, #4, ne
	mov	w12, #3                         ; =0x3
	csinc	w12, w12, wzr, eq
	b	LBB2_72
LBB2_71:                                ;   in Loop: Header=BB2_24 Depth=1
	mov	w11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	w13, #-1                        ; =0xffffffff
LBB2_72:                                ;   in Loop: Header=BB2_24 Depth=1
	ldrb	w14, [sp, #67]
	mov	w15, #24                        ; =0x18
	madd	x9, x21, x15, x9
	stp	w21, w10, [x9]
	stp	w11, w13, [x9, #8]
	ldr	w10, [sp, #16]                  ; 4-byte Folded Reload
	str	w10, [x9, #16]
	strb	w14, [x9, #20]
	strb	w12, [x9, #21]
	strh	wzr, [x9, #22]
LBB2_73:                                ;   in Loop: Header=BB2_24 Depth=1
	add	x21, x21, #1
	ldr	w9, [sp, #68]
	cmp	x21, x9
	b.lo	LBB2_24
; %bb.74:
	ldr	w12, [sp, #28]                  ; 4-byte Folded Reload
	b	LBB2_76
LBB2_75:
	mov	w27, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
LBB2_76:
	ldp	x11, x10, [sp, #80]
	cmp	x10, x11
	b.ne	LBB2_3
; %bb.77:
	ldr	w10, [x19, #468]
	cmp	w12, w10
	b.ne	LBB2_3
; %bb.78:
	ldr	w10, [x19, #472]
	cmp	w28, w10
	b.ne	LBB2_3
; %bb.79:
	ldr	w10, [x19, #476]
	cmp	w27, w10
	b.ne	LBB2_3
; %bb.80:
	mov	w0, #0                          ; =0x0
	str	w9, [x8]
	b	LBB2_4
LBB2_81:
	ldr	w9, [sp, #68]
	b	LBB2_21
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_plan_free ; -- Begin function nvm_multi_nominal_plan_free
	.globl	_nvm_multi_nominal_plan_free
	.p2align	2
_nvm_multi_nominal_plan_free:           ; @nvm_multi_nominal_plan_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_layout_count ; -- Begin function nvm_multi_nominal_layout_count
	.globl	_nvm_multi_nominal_layout_count
	.p2align	2
_nvm_multi_nominal_layout_count:        ; @nvm_multi_nominal_layout_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_2
; %bb.1:
	ldr	w0, [x0, #3844]
LBB4_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_layout ; -- Begin function nvm_multi_nominal_layout
	.globl	_nvm_multi_nominal_layout
	.p2align	2
_nvm_multi_nominal_layout:              ; @nvm_multi_nominal_layout
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB5_4
; %bb.1:
	cbz	x2, LBB5_4
; %bb.2:
	ldr	w9, [x8, #3844]
	cmp	w1, w9
	b.hs	LBB5_5
; %bb.3:
	mov	w9, #24                         ; =0x18
	umaddl	x8, w1, w9, x8
	add	x9, x8, #3848
	ldr	q0, [x9]
	ldr	x8, [x8, #3864]
	str	x8, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB5_4:
	ret
LBB5_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_type ; -- Begin function nvm_multi_nominal_type
	.globl	_nvm_multi_nominal_type
	.p2align	2
_nvm_multi_nominal_type:                ; @nvm_multi_nominal_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_7
; %bb.1:
	ldr	w8, [x0]
	cmp	w1, w8
	b.hs	LBB6_6
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x3
	mov	w8, #60                         ; =0x3c
	mov	x19, x0
	umaddl	x20, w1, w8, x0
	ldr	w0, [x20, #4]!
	mov	x22, x2
	bl	_nvm_multi_nominal_catalog_types
	cmp	w22, w0
	b.hs	LBB6_8
; %bb.3:
	cbz	x21, LBB6_8
; %bb.4:
	add	x9, x20, w22, uxtw #2
	ldr	w9, [x9, #24]
	ldr	w10, [x19, #3844]
	cmp	w9, w10
	b.hs	LBB6_8
; %bb.5:
	mov	w10, #24                        ; =0x18
	umaddl	x9, w9, w10, x19
	add	x10, x9, #3848
	ldr	q0, [x10]
	ldr	x9, [x9, #3864]
	str	x9, [x21, #16]
	str	q0, [x21]
	mov	w0, #1                          ; =0x1
	b	LBB6_9
LBB6_6:
	mov	w0, #0                          ; =0x0
LBB6_7:
	ret
LBB6_8:
	mov	w0, #0                          ; =0x0
LBB6_9:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_import ; -- Begin function nvm_multi_nominal_import
	.globl	_nvm_multi_nominal_import
	.p2align	2
_nvm_multi_nominal_import:              ; @nvm_multi_nominal_import
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB7_6
; %bb.1:
	cbz	x3, LBB7_6
; %bb.2:
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB7_5
; %bb.3:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	mov	w9, #60                         ; =0x3c
	umaddl	x20, w1, w9, x8
	ldr	w0, [x20, #4]!
	mov	x21, x2
	bl	_nvm_multi_nominal_catalog_methods
	cmp	w21, w0
	b.hs	LBB7_7
; %bb.4:
	add	x8, x20, w21, uxtw #2
	ldr	w8, [x8, #4]
	str	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB7_8
LBB7_5:
	mov	w0, #0                          ; =0x0
LBB7_6:
	ret
LBB7_7:
	mov	w0, #0                          ; =0x0
LBB7_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_instance_count ; -- Begin function nvm_multi_nominal_instance_count
	.globl	_nvm_multi_nominal_instance_count
	.p2align	2
_nvm_multi_nominal_instance_count:      ; @nvm_multi_nominal_instance_count
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_2
; %bb.1:
	ldr	w0, [x0]
LBB8_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function text
_text:                                  ; @text
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB9_6
; %bb.1:
	ldr	x8, [x0, #232]
	cbz	x8, LBB9_6
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x21, [x0, #240]
	cbz	x21, LBB9_7
; %bb.3:
	ldr	x19, [x8, w1, uxtw #3]
	cbz	x19, LBB9_7
; %bb.4:
	mov	x20, x2
	mov	x0, x2
	mov	x22, x1
	bl	_strlen
	ldr	w8, [x21, w22, uxtw #2]
	cmp	x0, x8
	b.ne	LBB9_7
; %bb.5:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	b	LBB9_8
LBB9_6:
	mov	w0, #0                          ; =0x0
	ret
LBB9_7:
	mov	w0, #0                          ; =0x0
LBB9_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function member_type
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x3
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x4]
	cbz	x2, LBB10_15
; %bb.1:
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	str	x4, [sp, #8]                    ; 8-byte Folded Spill
Lloh0:
	adrp	x1, l_.str@PAGE
Lloh1:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x2
	bl	_strcmp
	cbz	w0, LBB10_16
; %bb.2:
Lloh2:
	adrp	x1, l_.str.1@PAGE
Lloh3:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_17
; %bb.3:
Lloh4:
	adrp	x1, l_.str.2@PAGE
Lloh5:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_18
; %bb.4:
	add	x25, x22, #4
	mov	w8, #60                         ; =0x3c
	umaddl	x22, w21, w8, x25
	ldr	w0, [x22]
	bl	_nvm_multi_nominal_catalog_types
	cbz	w0, LBB10_20
; %bb.5:
	mov	x24, #0                         ; =0x0
	mov	w27, #60                        ; =0x3c
	add	w28, w21, w21, lsl #3
LBB10_6:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x28, x24
	mov	w8, w9
	mov	w10, #36409                     ; =0x8e39
	movk	w10, #14563, lsl #16
	umull	x8, w8, w10
	lsr	x10, x8, #33
	umaddl	x23, w10, w27, x25
	ldr	w8, [x23]
	add	w10, w10, w10, lsl #3
	sub	w21, w9, w10
	mov	x0, x21
	cmp	w8, #2
	b.eq	LBB10_9
; %bb.7:                                ;   in Loop: Header=BB10_6 Depth=1
	cmp	w8, #1
	b.ne	LBB10_10
; %bb.8:                                ;   in Loop: Header=BB10_6 Depth=1
	bl	_nl_file_catalog_type
	b	LBB10_11
LBB10_9:                                ;   in Loop: Header=BB10_6 Depth=1
	bl	_nl_socket_catalog_type
	b	LBB10_11
LBB10_10:                               ;   in Loop: Header=BB10_6 Depth=1
	bl	_nl_websocket_catalog_type
LBB10_11:                               ;   in Loop: Header=BB10_6 Depth=1
	cmp	x0, #0
	cset	w26, eq
	cbz	x0, LBB10_14
; %bb.12:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	x1, [x0]
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB10_21
; %bb.13:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	w0, [x22]
	bl	_nvm_multi_nominal_catalog_types
	add	x24, x24, #1
	cmp	w24, w0
	b.lo	LBB10_6
LBB10_14:
	mov	w8, #0                          ; =0x0
	b	LBB10_27
LBB10_15:
	strb	wzr, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB10_28
LBB10_16:
	mov	w0, #1                          ; =0x1
	strb	w0, [x19]
	b	LBB10_28
LBB10_17:
	mov	w8, #4                          ; =0x4
	b	LBB10_19
LBB10_18:
	mov	w8, #5                          ; =0x5
LBB10_19:
	strb	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB10_28
LBB10_20:
	mov	w26, #0                         ; =0x0
                                        ; implicit-def: $w8
	b	LBB10_27
LBB10_21:
	ldr	w8, [x23]
	mov	x0, x21
	cmp	w8, #2
	b.eq	LBB10_24
; %bb.22:
	cmp	w8, #1
	b.ne	LBB10_25
; %bb.23:
	bl	_nl_file_catalog_type
	b	LBB10_26
LBB10_24:
	bl	_nl_socket_catalog_type
	b	LBB10_26
LBB10_25:
	bl	_nl_websocket_catalog_type
LBB10_26:
	ldr	w8, [x0, #16]
	mov	w9, #8                          ; =0x8
	mov	w10, #10                        ; =0xa
	cmp	w8, #2
	csel	w8, w10, w9, eq
	strb	w8, [x19]
	add	x8, x22, x24, lsl #2
	ldr	w9, [x8, #24]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	w9, [x8]
	mov	w26, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
LBB10_27:
	and	w0, w26, w8
LBB10_28:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_at
_type_at:                               ; @type_at
	.cfi_startproc
; %bb.0:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x9, x8, #33
	mov	w8, #60                         ; =0x3c
	umaddl	x8, w9, w8, x0
	ldr	w8, [x8, #4]
	add	w9, w9, w9, lsl #3
	sub	w0, w1, w9
	cmp	w8, #2
	b.eq	LBB11_3
; %bb.1:
	cmp	w8, #1
	b.ne	LBB11_4
; %bb.2:
	b	_nl_file_catalog_type
LBB11_3:
	b	_nl_socket_catalog_type
LBB11_4:
	b	_nl_websocket_catalog_type
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_tag
_type_tag:                              ; @type_tag
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x9, x8, #33
	mov	w8, #60                         ; =0x3c
	umaddl	x8, w9, w8, x0
	ldr	w8, [x8, #4]
	add	w9, w9, w9, lsl #3
	sub	w0, w1, w9
	cmp	w8, #2
	b.eq	LBB12_3
; %bb.1:
	cmp	w8, #1
	b.ne	LBB12_4
; %bb.2:
	bl	_nl_file_catalog_type
	b	LBB12_5
LBB12_3:
	bl	_nl_socket_catalog_type
	b	LBB12_5
LBB12_4:
	bl	_nl_websocket_catalog_type
LBB12_5:
	ldr	w8, [x0, #16]
	mov	w9, #8                          ; =0x8
	mov	w10, #10                        ; =0xa
	cmp	w8, #2
	csel	w0, w10, w9, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_kind
_type_kind:                             ; @type_kind
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x9, x8, #33
	mov	w8, #60                         ; =0x3c
	umaddl	x8, w9, w8, x0
	ldr	w8, [x8, #4]
	add	w9, w9, w9, lsl #3
	sub	w0, w1, w9
	cmp	w8, #2
	b.eq	LBB13_3
; %bb.1:
	cmp	w8, #1
	b.ne	LBB13_4
; %bb.2:
	bl	_nl_file_catalog_type
	b	LBB13_5
LBB13_3:
	bl	_nl_socket_catalog_type
	b	LBB13_5
LBB13_4:
	bl	_nl_websocket_catalog_type
LBB13_5:
	ldr	w8, [x0, #16]
	cmp	w8, #2
	csel	w0, w8, wzr, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_at
_catalog_at:                            ; @catalog_at
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w8, [x0]
	cbz	w8, LBB14_7
; %bb.1:
	mov	x19, x1
	mov	x20, x0
	mov	w22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	add	x24, x0, #4
	add	x25, x0, #28
	mov	w26, #60                        ; =0x3c
	b	LBB14_3
LBB14_2:                                ;   in Loop: Header=BB14_3 Depth=1
	add	x23, x23, #1
	ldr	w8, [x20]
	add	w22, w22, #9
	add	x25, x25, #60
	cmp	x23, x8
	b.hs	LBB14_7
LBB14_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_5 Depth 2
	madd	x27, x23, x26, x24
	ldr	w0, [x27]
	bl	_nvm_multi_nominal_catalog_types
	cbz	w0, LBB14_2
; %bb.4:                                ;   in Loop: Header=BB14_3 Depth=1
	mov	x28, #0                         ; =0x0
	mov	x21, x22
LBB14_5:                                ;   Parent Loop BB14_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x25, x28, lsl #2]
	cmp	w8, w19
	b.eq	LBB14_8
; %bb.6:                                ;   in Loop: Header=BB14_5 Depth=2
	add	x28, x28, #1
	ldr	w0, [x27]
	bl	_nvm_multi_nominal_catalog_types
	add	w21, w21, #1
	cmp	x28, w0, uxtw
	b.lo	LBB14_5
	b	LBB14_2
LBB14_7:
	mov	w21, #-1                        ; =0xffffffff
LBB14_8:
	mov	x0, x21
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor_read
_descriptor_read:                       ; @descriptor_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x21, x2
	mov	x19, x1
	mov	x22, x0
	add	x1, sp, #15
	bl	_nvm_v2_u8
	cbnz	w0, LBB15_3
; %bb.1:
	add	x1, sp, #14
	mov	x0, x22
	bl	_nvm_v2_u8
	cbnz	w0, LBB15_3
; %bb.2:
	add	x1, sp, #12
	mov	x0, x22
	bl	_nvm_v2_u16
	cbz	w0, LBB15_5
LBB15_3:
	mov	w0, #0                          ; =0x0
LBB15_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB15_5:
	add	x1, sp, #8
	mov	x0, x22
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [sp, #14]
	cmp	w9, #3
	cset	w10, lo
	cmp	w9, #0
	cset	w9, eq
	cmp	w21, #0
	csel	w9, w10, w9, ne
	cbnz	w8, LBB15_4
; %bb.6:
	ldrh	w8, [sp, #12]
	cbnz	w8, LBB15_4
; %bb.7:
	ldrb	w8, [sp, #15]
	cmp	w8, #15
	b.hi	LBB15_4
; %bb.8:
	cbz	w9, LBB15_4
; %bb.9:
	tbnz	w20, #31, LBB15_11
; %bb.10:
	cmp	w20, w8
	b.ne	LBB15_3
LBB15_11:
	ldr	w1, [sp, #8]
	cmn	w1, #1
	b.eq	LBB15_15
; %bb.12:
	mov	x0, x19
	bl	_catalog_at
	mov	x20, x0
	ldr	w8, [sp, #8]
	cmn	w8, #1
	b.eq	LBB15_16
; %bb.13:
	cmn	w20, #1
	b.eq	LBB15_3
; %bb.14:
	ldrb	w21, [sp, #15]
	mov	x0, x19
	mov	x1, x20
	bl	_type_tag
	cmp	w21, w0
	b.ne	LBB15_3
	b	LBB15_16
LBB15_15:
	mov	w20, #-1                        ; =0xffffffff
LBB15_16:
	ldrb	w8, [sp, #14]
	mov	w9, #36409                      ; =0x8e39
	movk	w9, #14563, lsl #16
	umull	x9, w20, w9
	lsr	x9, x9, #33
	add	w9, w9, w9, lsl #3
	sub	w9, w20, w9
	cmp	w8, #0
	ccmp	w9, #0, #4, ne
	cset	w0, eq
	b	LBB15_4
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

.subsections_via_symbols
