	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_file_host_enter_query      ; -- Begin function nvm_file_host_enter_query
	.p2align	2
_nvm_file_host_enter_query:             ; @nvm_file_host_enter_query
	.cfi_startproc
; %bb.0:
Lloh0:
	adrp	x8, _file_host_gate@PAGE
Lloh1:
	add	x8, x8, _file_host_gate@PAGEOFF
	mov	w9, #1                          ; =0x1
	swpab	w9, w8, [x8]
	tst	w8, #0x1
	mov	w8, #5                          ; =0x5
	csel	w0, w8, wzr, ne
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_host_leave            ; -- Begin function nvm_file_host_leave
	.p2align	2
_nvm_file_host_leave:                   ; @nvm_file_host_leave
	.cfi_startproc
; %bb.0:
Lloh2:
	adrp	x8, _file_host_gate@PAGE
Lloh3:
	add	x8, x8, _file_host_gate@PAGEOFF
	stlrb	wzr, [x8]
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_host_enter            ; -- Begin function nvm_file_host_enter
	.p2align	2
_nvm_file_host_enter:                   ; @nvm_file_host_enter
	.cfi_startproc
; %bb.0:
Lloh4:
	adrp	x9, _file_host_gate@PAGE
Lloh5:
	add	x9, x9, _file_host_gate@PAGEOFF
	mov	w10, #1                         ; =0x1
	swpab	w10, w10, [x9]
	tbz	w10, #0, LBB2_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	ret
LBB2_2:
	mov	x8, x0
	cbz	x0, LBB2_11
; %bb.3:
	mov	w0, #4                          ; =0x4
	cmp	w2, #1
	b.ne	LBB2_13
; %bb.4:
	cmp	w1, #1
	b.ne	LBB2_13
; %bb.5:
	ldr	x10, [x8]
Lloh6:
	adrp	x11, _file_host_identity@PAGE
Lloh7:
	add	x11, x11, _file_host_identity@PAGEOFF
	cmp	x10, x11
	b.ne	LBB2_13
; %bb.6:
	ldr	w10, [x8, #8]
	cmp	w10, #1
	b.ne	LBB2_13
; %bb.7:
	ldr	w10, [x8, #12]
	cmp	w10, #1
	b.ne	LBB2_13
; %bb.8:
	ldr	w10, [x8, #16]
	cmp	w10, #1
	b.ne	LBB2_13
; %bb.9:
	ldrb	w8, [x8, #20]
	tbz	w8, #0, LBB2_12
; %bb.10:
	mov	w0, #0                          ; =0x0
	ret
LBB2_11:
	mov	w0, #1                          ; =0x1
	stlrb	wzr, [x9]
	ret
LBB2_12:
	mov	w0, #3                          ; =0x3
LBB2_13:
	stlrb	wzr, [x9]
	ret
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_host_grant_create_temporary_files ; -- Begin function nvm_file_host_grant_create_temporary_files
	.p2align	2
_nvm_file_host_grant_create_temporary_files: ; @nvm_file_host_grant_create_temporary_files
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh8:
	adrp	x19, _file_host_gate@PAGE
Lloh9:
	add	x19, x19, _file_host_gate@PAGEOFF
	mov	w8, #1                          ; =0x1
	swpab	w8, w8, [x19]
	tbz	w8, #0, LBB3_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB3_8
LBB3_2:
	cbz	x0, LBB3_5
; %bb.3:
	mov	x20, x0
	mov	w0, #24                         ; =0x18
	bl	_malloc
	cbz	x0, LBB3_6
; %bb.4:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
Lloh10:
	adrp	x9, _file_host_identity@PAGE
Lloh11:
	add	x9, x9, _file_host_identity@PAGEOFF
	str	x9, [x8]
	movi.2s	v0, #1
	str	d0, [x8, #8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #16]
	strb	w9, [x8, #20]
	str	x8, [x20]
	b	LBB3_7
LBB3_5:
	mov	w0, #1                          ; =0x1
	b	LBB3_7
LBB3_6:
	mov	w0, #2                          ; =0x2
LBB3_7:
	stlrb	wzr, [x19]
LBB3_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_host_grant_revoke     ; -- Begin function nvm_file_host_grant_revoke
	.p2align	2
_nvm_file_host_grant_revoke:            ; @nvm_file_host_grant_revoke
	.cfi_startproc
; %bb.0:
Lloh12:
	adrp	x8, _file_host_gate@PAGE
Lloh13:
	add	x8, x8, _file_host_gate@PAGEOFF
	mov	w9, #1                          ; =0x1
	swpab	w9, w9, [x8]
	tbz	w9, #0, LBB4_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	ret
LBB4_2:
	cbz	x0, LBB4_9
; %bb.3:
	ldr	x9, [x0]
Lloh14:
	adrp	x10, _file_host_identity@PAGE
Lloh15:
	add	x10, x10, _file_host_identity@PAGEOFF
	cmp	x9, x10
	b.ne	LBB4_8
; %bb.4:
	ldr	w9, [x0, #8]
	cmp	w9, #1
	b.ne	LBB4_8
; %bb.5:
	ldr	w9, [x0, #12]
	cmp	w9, #1
	b.ne	LBB4_8
; %bb.6:
	ldr	w9, [x0, #16]
	cmp	w9, #1
	b.ne	LBB4_8
; %bb.7:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	strb	wzr, [x9, #20]
	stlrb	wzr, [x8]
	ret
LBB4_8:
	mov	w0, #4                          ; =0x4
	stlrb	wzr, [x8]
	ret
LBB4_9:
	mov	w0, #1                          ; =0x1
	stlrb	wzr, [x8]
	ret
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_host_grant_destroy    ; -- Begin function nvm_file_host_grant_destroy
	.p2align	2
_nvm_file_host_grant_destroy:           ; @nvm_file_host_grant_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh16:
	adrp	x19, _file_host_gate@PAGE
Lloh17:
	add	x19, x19, _file_host_gate@PAGEOFF
	mov	w8, #1                          ; =0x1
	swpab	w8, w8, [x19]
	tbz	w8, #0, LBB5_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB5_13
LBB5_2:
	cbz	x0, LBB5_9
; %bb.3:
	ldr	x8, [x0]
	cbz	x8, LBB5_11
; %bb.4:
	ldr	x9, [x8]
Lloh18:
	adrp	x10, _file_host_identity@PAGE
Lloh19:
	add	x10, x10, _file_host_identity@PAGEOFF
	cmp	x9, x10
	b.ne	LBB5_10
; %bb.5:
	ldr	w9, [x8, #8]
	cmp	w9, #1
	b.ne	LBB5_10
; %bb.6:
	ldr	w9, [x8, #12]
	cmp	w9, #1
	b.ne	LBB5_10
; %bb.7:
	ldr	w9, [x8, #16]
	cmp	w9, #1
	b.ne	LBB5_10
; %bb.8:
	mov	x20, x0
	mov	x0, x8
	bl	_free
	mov	w0, #0                          ; =0x0
	str	xzr, [x20]
	b	LBB5_12
LBB5_9:
	mov	w0, #1                          ; =0x1
	b	LBB5_12
LBB5_10:
	mov	w0, #4                          ; =0x4
	b	LBB5_12
LBB5_11:
	mov	w0, #0                          ; =0x0
LBB5_12:
	stlrb	wzr, [x19]
LBB5_13:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_file_host_gate,1,0 ; @file_host_gate
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @file_host_identity
_file_host_identity:
	.long	1                               ; 0x1

.subsections_via_symbols
