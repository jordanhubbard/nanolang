	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_file_execute_bytes         ; -- Begin function nvm_file_execute_bytes
	.p2align	2
_nvm_file_execute_bytes:                ; @nvm_file_execute_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1136
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x19, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	bl	_nvm_file_host_enter
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w0, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w0, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w0, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w0, #4                          ; =0x4
	b	LBB0_10
LBB0_5:
	cbz	w0, LBB0_13
; %bb.6:
	cmp	w0, #1
	b.eq	LBB0_10
LBB0_7:
	mov	w0, #2                          ; =0x2
	b	LBB0_10
LBB0_8:
	mov	w0, #11                         ; =0xb
	b	LBB0_10
LBB0_9:
	mov	w0, #5                          ; =0x5
LBB0_10:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	str	w0, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
LBB0_11:
	ldur	x8, [x29, #-104]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_250
; %bb.12:
	add	sp, sp, #1136
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_13:
	str	xzr, [sp, #80]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	cbz	x20, LBB0_16
; %bb.14:
	add	x23, sp, #224
	str	xzr, [sp, #216]
	add	x3, sp, #216
	mov	x0, x22
	mov	x1, x21
	mov	w2, #0                          ; =0x0
	bl	_nvm_file_runtime_create
	cbz	w0, LBB0_17
; %bb.15:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #224]
	str	xzr, [sp, #320]
	stp	q0, q0, [sp, #288]
	stp	q0, q0, [sp, #256]
	str	w0, [sp, #224]
	b	LBB0_28
LBB0_16:
	str	wzr, [x19, #100]
	stur	q0, [x19, #84]
	stur	q0, [x19, #68]
	stur	q0, [x19, #52]
	stur	q0, [x19, #36]
	stur	q0, [x19, #20]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	stur	xzr, [x19, #4]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
	b	LBB0_47
LBB0_17:
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_plan
	mov	x21, x0
	add	x1, sp, #88
	bl	_nvm_file_hosted_startup
	cbz	w0, LBB0_27
; %bb.18:
	ldr	w8, [sp, #96]
	cbz	w8, LBB0_48
; %bb.19:
	mov	w22, #0                         ; =0x0
	b	LBB0_21
LBB0_20:                                ;   in Loop: Header=BB0_21 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #96]
	cmp	w22, w8
	b.hs	LBB0_48
LBB0_21:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
	add	x2, sp, #832
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_hosted_function
	cbz	w0, LBB0_27
; %bb.22:                               ;   in Loop: Header=BB0_21 Depth=1
	ldrh	w8, [sp, #840]
	cbz	w8, LBB0_20
; %bb.23:                               ;   in Loop: Header=BB0_21 Depth=1
	mov	w24, #0                         ; =0x0
LBB0_24:                                ;   Parent Loop BB0_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w2, w24, #0xffff
	add	x3, sp, #224
	add	x4, sp, #928
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_hosted_instruction
	cbz	w0, LBB0_27
; %bb.25:                               ;   in Loop: Header=BB0_24 Depth=2
	add	x1, sp, #224
	add	x2, sp, #928
	mov	x0, x21
	bl	_fvm_fact
	cbz	w0, LBB0_27
; %bb.26:                               ;   in Loop: Header=BB0_24 Depth=2
	add	w24, w24, #1
	ldrh	w8, [sp, #840]
	cmp	w8, w24, uxth
	b.hi	LBB0_24
	b	LBB0_20
LBB0_27:
	add	x8, sp, #224
	add	x0, sp, #216
	mov	x1, #0                          ; =0x0
	bl	_nvm_file_runtime_destroy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #256]
	stp	q0, q0, [sp, #288]
	str	xzr, [sp, #320]
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #224]
LBB0_28:
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x23, #12]
LBB0_29:
	ldp	q0, q1, [sp, #288]
	stp	q0, q1, [x19, #64]
	ldr	x8, [sp, #320]
	str	x8, [x19, #96]
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x19]
	ldp	q1, q0, [sp, #256]
	stp	q1, q0, [x19, #32]
	ldr	w8, [x19]
	cbnz	w8, LBB0_46
; %bb.30:
	ldrb	w8, [x19, #4]
	tbz	w8, #0, LBB0_45
; %bb.31:
	ldr	w9, [x19, #8]
	mov	w8, #10                         ; =0xa
	cbnz	w9, LBB0_46
; %bb.32:
	ldr	w9, [x19, #24]
	cbnz	w9, LBB0_46
; %bb.33:
	ldr	x9, [x19, #32]
	cbnz	x9, LBB0_46
; %bb.34:
	ldrb	w9, [sp]
	mov	w8, #6                          ; =0x6
	tbz	w9, #0, LBB0_46
; %bb.35:
	ldrb	w9, [sp, #1]
	tbnz	w9, #0, LBB0_46
; %bb.36:
	ldrb	w9, [sp, #2]
	tbnz	w9, #0, LBB0_46
; %bb.37:
	ldrb	w9, [sp, #5]
	cbnz	w9, LBB0_46
; %bb.38:
	ldr	w9, [sp, #16]
	cbnz	w9, LBB0_46
; %bb.39:
	ldr	w9, [sp, #8]
	cmn	w9, #1
	b.ne	LBB0_46
; %bb.40:
	ldr	w9, [sp, #12]
	cmn	w9, #1
	b.ne	LBB0_46
; %bb.41:
	ldrb	w9, [sp, #24]
	cmp	w9, #1
	b.ne	LBB0_46
; %bb.42:
	ldrb	w9, [sp, #4]
	cmp	w9, #4
	b.eq	LBB0_242
; %bb.43:
	cmp	w9, #1
	b.ne	LBB0_46
; %bb.44:
	ldr	x10, [sp, #32]
	b	LBB0_243
LBB0_45:
	mov	w8, #5                          ; =0x5
LBB0_46:
	ldur	q0, [x19, #40]
	ldur	q1, [x19, #56]
	stp	q0, q1, [sp, #224]
	ldur	q0, [x19, #72]
	ldur	q1, [x19, #88]
	stp	q0, q1, [sp, #256]
	ldp	q1, q0, [sp, #256]
	stur	q0, [x19, #88]
	stur	q1, [x19, #72]
	ldp	q1, q0, [sp, #224]
	stur	q0, [x19, #56]
	ldurh	w9, [x19, #5]
	strh	w9, [sp, #832]
	ldurb	w9, [x19, #7]
	strb	w9, [sp, #834]
	ldur	x9, [x19, #12]
	str	x9, [sp, #928]
	ldur	w9, [x19, #20]
	str	w9, [sp, #936]
	str	w8, [x19]
	ldrb	w8, [sp, #834]
	sturb	w8, [x19, #7]
	mov	w8, w9
	stur	w8, [x19, #20]
	ldr	x8, [sp, #928]
	stur	x8, [x19, #12]
	stur	q1, [x19, #40]
LBB0_47:
	bl	_nvm_file_host_leave
	b	LBB0_11
LBB0_48:
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_begin
	cbnz	w0, LBB0_247
; %bb.49:
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_frame_start
	cbnz	w0, LBB0_247
; %bb.50:
	mov	x25, #0                         ; =0x0
	mov	w28, #-1                        ; =0xffffffff
Lloh6:
	adrp	x26, lJTI0_0@PAGE
Lloh7:
	add	x26, x26, lJTI0_0@PAGEOFF
	b	LBB0_52
LBB0_51:                                ;   in Loop: Header=BB0_52 Depth=1
	cbnz	w1, LBB0_248
LBB0_52:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #216]
	add	x1, sp, #168
	bl	_nvm_file_runtime_frame_view
	ldr	w8, [sp, #168]
	cmp	w0, #0
	ccmp	w8, #0, #0, ne
	b.ne	LBB0_244
; %bb.53:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #172]
	ldrh	w2, [sp, #176]
	add	x3, sp, #224
	add	x4, sp, #88
	mov	x0, x21
	bl	_nvm_file_hosted_instruction
	mov	w1, #5                          ; =0x5
	cbz	w0, LBB0_246
; %bb.54:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #88]
	tbz	w8, #0, LBB0_246
; %bb.55:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w8, [sp, #92]
	ldr	w9, [sp, #204]
	cmp	w9, w8
	b.ne	LBB0_246
; %bb.56:                               ;   in Loop: Header=BB0_52 Depth=1
	add	x1, sp, #224
	add	x2, sp, #88
	mov	x0, x21
	bl	_fvm_fact
	cbz	w0, LBB0_244
; %bb.57:                               ;   in Loop: Header=BB0_52 Depth=1
	subs	x25, x25, #1
	b.eq	LBB0_245
; %bb.58:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w1, #0                          ; =0x0
	ldr	x22, [sp, #216]
	ldr	w23, [sp, #204]
	ldrb	w27, [sp, #232]
	str	w28, [sp, #924]
	str	w28, [sp, #920]
	mov	w8, #2                          ; =0x2
	cmp	w27, #255
	b.eq	LBB0_70
; %bb.59:                               ;   in Loop: Header=BB0_52 Depth=1
	adr	x9, LBB0_60
	ldrh	w10, [x26, x27, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB0_60:                                ;   in Loop: Header=BB0_52 Depth=1
	cbz	w23, LBB0_204
; %bb.61:                               ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, #1
	and	w1, w8, #0xffff
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	tbz	w0, #0, LBB0_204
; %bb.62:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	w27, #252
	b.eq	LBB0_64
; %bb.63:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	w27, #106
	b.ne	LBB0_158
LBB0_64:                                ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	ldrh	w2, [sp, #240]
	mov	x0, x22
	mov	x3, x1
	bl	_nvm_file_runtime_project
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_65:                                ;   in Loop: Header=BB0_52 Depth=1
	and	w1, w23, #0xffff
	add	x2, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_204
; %bb.66:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	w27, #3
	mov	w8, #4                          ; =0x4
	csel	w8, w8, wzr, eq
	cmp	w27, #1
	csinc	w2, w8, wzr, ne
	b.ne	LBB0_156
; %bb.67:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	x3, [sp, #240]
	b	LBB0_166
LBB0_68:                                ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_call
	b	LBB0_206
LBB0_69:                                ;   in Loop: Header=BB0_52 Depth=1
	mov	w1, #1                          ; =0x1
	mov	w8, #1                          ; =0x1
LBB0_70:                                ;   in Loop: Header=BB0_52 Depth=1
	subs	w24, w23, w8
	b.lo	LBB0_204
; %bb.71:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x23, x1
	and	w1, w24, #0xffff
	sub	x2, x29, #112
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	tbz	w0, #0, LBB0_204
; %bb.72:                               ;   in Loop: Header=BB0_52 Depth=1
	ldur	w1, [x29, #-112]
	add	x2, sp, #928
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_204
; %bb.73:                               ;   in Loop: Header=BB0_52 Depth=1
	tbz	w23, #0, LBB0_172
LBB0_74:                                ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w27, #0xfe
	cmp	w27, #50
	mov	w9, #48                         ; =0x30
	ccmp	w8, w9, #4, ne
	cset	w9, eq
	sub	w10, w27, #48
	cmp	w10, #3
	cset	w11, lo
	cmp	w8, #40
	ldrb	w10, [sp, #932]
	and	w8, w10, #0xff
	ccmp	w8, #4, #0, eq
	csinc	w9, w9, wzr, ne
	csinc	w8, w11, wzr, ne
	cmp	w9, #0
	mov	w9, #4                          ; =0x4
	csinc	w9, w9, wzr, ne
	ldrb	w11, [sp, #928]
	cmp	w11, #1
	b.ne	LBB0_127
; %bb.75:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w11, [sp, #929]
	tbnz	w11, #0, LBB0_127
; %bb.76:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w11, [sp, #930]
	tbnz	w11, #0, LBB0_127
; %bb.77:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w11, [sp, #933]
	cbnz	w11, LBB0_127
; %bb.78:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w11, [sp, #944]
	cbnz	w11, LBB0_127
; %bb.79:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	w9, w10, uxtb
	b.ne	LBB0_127
; %bb.80:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w10, [sp, #936]
	cmn	w10, #1
	b.ne	LBB0_127
; %bb.81:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w10, [sp, #940]
	cmn	w10, #1
	b.ne	LBB0_127
; %bb.82:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #952]
	cmp	w10, #1
	b.ne	LBB0_127
; %bb.83:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	w8, LBB0_85
; %bb.84:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	x10, [sp, #960]
	cmp	x10, #2
	b.hs	LBB0_127
LBB0_85:                                ;   in Loop: Header=BB0_52 Depth=1
	tbz	w23, #0, LBB0_188
LBB0_86:                                ;   in Loop: Header=BB0_52 Depth=1
	ldr	x10, [sp, #1048]
	cmp	w23, #0
	csel	x9, xzr, x10, ne
	sub	w11, w27, #32
	cmp	w11, #181
	b.hi	LBB0_204
; %bb.87:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	x8, [sp, #960]
Lloh8:
	adrp	x14, lJTI0_1@PAGE
Lloh9:
	add	x14, x14, lJTI0_1@PAGEOFF
	adr	x12, LBB0_88
	ldrh	w13, [x14, x11, lsl #1]
	add	x12, x12, x13, lsl #2
	br	x12
LBB0_88:                                ;   in Loop: Header=BB0_52 Depth=1
	add	x24, x9, x8
	b	LBB0_228
LBB0_89:                                ;   in Loop: Header=BB0_52 Depth=1
	cbz	w23, LBB0_204
; %bb.90:                               ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, #1
	and	w1, w8, #0xffff
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.91:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #832
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_204
; %bb.92:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #832]
	cmp	w8, #1
	b.ne	LBB0_127
; %bb.93:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #833]
	tbnz	w8, #0, LBB0_127
; %bb.94:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #834]
	tbnz	w8, #0, LBB0_127
; %bb.95:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #837]
	cbnz	w8, LBB0_127
; %bb.96:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #848]
	cbnz	w8, LBB0_127
; %bb.97:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #836]
	cmp	w8, #4
	b.ne	LBB0_127
; %bb.98:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #840]
	cmn	w8, #1
	b.ne	LBB0_127
; %bb.99:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #844]
	cmn	w8, #1
	b.ne	LBB0_127
; %bb.100:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #856]
	cmp	w8, #1
	b.ne	LBB0_127
; %bb.101:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	x8, [sp, #864]
	cmp	x8, #2
	b.hs	LBB0_127
; %bb.102:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_247
; %bb.103:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	x8, [sp, #864]
	cmp	w27, #161
	b.ne	LBB0_187
; %bb.104:                              ;   in Loop: Header=BB0_52 Depth=1
	cbz	x8, LBB0_212
; %bb.105:                              ;   in Loop: Header=BB0_52 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB0_171
LBB0_106:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w8, [sp, #256]
	ldrh	w9, [sp, #248]
	cmp	w27, #251
	csel	w27, w8, w9, eq
	ldrh	w9, [sp, #264]
	csel	w24, w9, w8, eq
	and	w8, w24, #0xffff
	cmp	w8, #7
	b.hi	LBB0_204
; %bb.107:                              ;   in Loop: Header=BB0_52 Depth=1
	cmp	w23, w8
	b.lo	LBB0_204
; %bb.108:                              ;   in Loop: Header=BB0_52 Depth=1
	tst	w24, #0xffff
	b.eq	LBB0_168
; %bb.109:                              ;   in Loop: Header=BB0_52 Depth=1
	sub	w23, w23, w24
	and	w1, w23, #0xffff
	add	x2, sp, #928
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.110:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #1
	b.ne	LBB0_176
LBB0_111:                               ;   in Loop: Header=BB0_52 Depth=1
	and	x4, x24, #0xffff
	ldr	w5, [sp, #928]
	str	w5, [sp, #920]
	b	LBB0_170
LBB0_112:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_borrow
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_113:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w1, [sp, #240]
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	cbz	w0, LBB0_204
; %bb.114:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w1, w23, #0xffff
	add	x2, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	cbz	w0, LBB0_204
; %bb.115:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #832
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_204
; %bb.116:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #832]
	cmp	w8, #1
	b.ne	LBB0_127
; %bb.117:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #834]
	tbnz	w8, #0, LBB0_127
; %bb.118:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #833]
	cmp	w27, #11
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.119:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	ldr	w2, [sp, #920]
	mov	x0, x22
	cmp	w27, #16
	b.ne	LBB0_203
; %bb.120:                              ;   in Loop: Header=BB0_52 Depth=1
	bl	_nvm_file_runtime_copy
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_121:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	w23, LBB0_204
; %bb.122:                              ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, #1
	and	w1, w8, #0xffff
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.123:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #832
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_204
; %bb.124:                              ;   in Loop: Header=BB0_52 Depth=1
	cmp	w27, #8
	b.ne	LBB0_130
; %bb.125:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #833]
	tbnz	w8, #0, LBB0_127
; %bb.126:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #834]
	tbz	w8, #0, LBB0_130
LBB0_127:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	mov	w1, #6                          ; =0x6
	b	LBB0_205
LBB0_128:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_store
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_129:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w1, [sp, #240]
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	tbz	w0, #0, LBB0_204
LBB0_130:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_131:                               ;   in Loop: Header=BB0_52 Depth=1
	stur	w28, [x29, #-112]
	mov	x0, x22
	bl	_nvm_file_runtime_plan
	ldr	w1, [sp, #240]
	add	x2, sp, #928
	bl	_nvm_file_hosted_import
	cbz	w0, LBB0_204
; %bb.132:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #928]
	ldr	w9, [sp, #816]
	cmp	w8, w9
	b.ne	LBB0_204
; %bb.133:                              ;   in Loop: Header=BB0_52 Depth=1
	add	x1, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_scratch
	cbz	w0, LBB0_204
; %bb.134:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #928]
	cmp	w8, #1
	cset	w9, eq
	cmp	w8, #4
	csinc	w24, w9, wzr, ne
	b.eq	LBB0_136
; %bb.135:                              ;   in Loop: Header=BB0_52 Depth=1
	cmp	w8, #1
	b.ne	LBB0_139
LBB0_136:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	w23, LBB0_204
; %bb.137:                              ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, #1
	and	w1, w8, #0xffff
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.138:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #928]
LBB0_139:                               ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w8, #1
	cmp	w8, #2
	b.hi	LBB0_199
; %bb.140:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w1, [sp, #248]
	sub	x2, x29, #112
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reference
	cbz	w0, LBB0_204
; %bb.141:                              ;   in Loop: Header=BB0_52 Depth=1
	ldur	w2, [x29, #-112]
	b	LBB0_200
LBB0_142:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	w23, LBB0_204
; %bb.143:                              ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, #1
	and	w1, w8, #0xffff
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.144:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w1, w23, #0xffff
	add	x2, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_204
; %bb.145:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	ldr	w2, [sp, #920]
	mov	x0, x22
	bl	_nvm_file_runtime_copy
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_146:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_end_reference
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_147:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_region_begin
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_148:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_region_end
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_149:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_return
	b	LBB0_206
LBB0_150:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w1, [sp, #240]
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	tbz	w0, #0, LBB0_204
; %bb.151:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #928
	mov	x0, x22
	bl	_nvm_file_runtime_result_arm
	mov	x1, x0
	cbnz	w0, LBB0_207
; %bb.152:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #928]
	cmp	w8, #3
	cset	w1, eq
	b	LBB0_171
LBB0_153:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w1, [sp, #240]
	add	x2, sp, #924
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	cbz	w0, LBB0_204
; %bb.154:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w1, w23, #0xffff
	add	x2, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_204
; %bb.155:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	ldrb	w8, [sp, #248]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w2, w8, ne
	ldr	w3, [sp, #920]
	mov	x0, x22
	bl	_nvm_file_runtime_take
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_156:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	w27, #3
	b.ne	LBB0_165
; %bb.157:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w3, [sp, #240]
	b	LBB0_166
LBB0_158:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #832
	mov	x0, x22
	bl	_nvm_file_runtime_view
	cbz	w0, LBB0_174
; %bb.159:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #833]
	mov	w1, #6                          ; =0x6
	tbnz	w8, #0, LBB0_175
; %bb.160:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #834]
	tbnz	w8, #0, LBB0_175
; %bb.161:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #848]
	cmp	w8, #3
	b.ne	LBB0_175
; %bb.162:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	add	x2, sp, #928
	mov	x0, x22
	bl	_nvm_file_runtime_result_arm
	cbnz	w0, LBB0_206
; %bb.163:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_206
; %bb.164:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #924]
	ldr	w8, [sp, #928]
	cmp	w8, #3
	cset	w3, eq
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	b	LBB0_167
LBB0_165:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x3, #0                          ; =0x0
LBB0_166:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #920]
	mov	x0, x22
LBB0_167:                               ;   in Loop: Header=BB0_52 Depth=1
	bl	_nvm_file_runtime_scalar
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_168:                               ;   in Loop: Header=BB0_52 Depth=1
	and	w1, w23, #0xffff
	add	x2, sp, #920
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	cbz	w0, LBB0_204
; %bb.169:                              ;   in Loop: Header=BB0_52 Depth=1
	mov	x4, #0                          ; =0x0
	ldr	w5, [sp, #920]
LBB0_170:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #816]
	and	w2, w27, #0xffff
	add	x3, sp, #928
	mov	x0, x22
	bl	_nvm_file_runtime_construct
	mov	x1, x0
	cbnz	w0, LBB0_248
LBB0_171:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_next
	b	LBB0_206
LBB0_172:                               ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w24, #1
	and	w1, w8, #0xffff
	sub	x8, x29, #112
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.173:                              ;   in Loop: Header=BB0_52 Depth=1
	ldur	w1, [x29, #-108]
	add	x8, sp, #928
	add	x2, x8, #88
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbnz	w0, #0, LBB0_74
	b	LBB0_204
LBB0_174:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w1, #5                          ; =0x5
LBB0_175:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	b	LBB0_205
LBB0_176:                               ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #1
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.177:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #2
	b.eq	LBB0_111
; %bb.178:                              ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #2
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #8
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.179:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #3
	b.eq	LBB0_111
; %bb.180:                              ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #3
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #12
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.181:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #4
	b.eq	LBB0_111
; %bb.182:                              ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #4
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #16
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.183:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #5
	b.eq	LBB0_111
; %bb.184:                              ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #5
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #20
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_204
; %bb.185:                              ;   in Loop: Header=BB0_52 Depth=1
	and	w8, w24, #0xffff
	cmp	w8, #6
	b.eq	LBB0_111
; %bb.186:                              ;   in Loop: Header=BB0_52 Depth=1
	add	w8, w23, #6
	and	w1, w8, #0xffff
	add	x8, sp, #928
	add	x2, x8, #24
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbnz	w0, LBB0_111
	b	LBB0_204
LBB0_187:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, #0
	cset	w8, ne
	cmp	w27, #57
	cset	w9, ne
	eor	w1, w9, w8
	b	LBB0_171
LBB0_188:                               ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #1016]
	cmp	w10, #1
	b.ne	LBB0_127
; %bb.189:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #1017]
	tbnz	w10, #0, LBB0_127
; %bb.190:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #1018]
	tbnz	w10, #0, LBB0_127
; %bb.191:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #1021]
	cbnz	w10, LBB0_127
; %bb.192:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w10, [sp, #1032]
	cbnz	w10, LBB0_127
; %bb.193:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w10, [sp, #1020]
	cmp	w10, w9
	b.ne	LBB0_127
; %bb.194:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w9, [sp, #1024]
	cmn	w9, #1
	b.ne	LBB0_127
; %bb.195:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w9, [sp, #1028]
	cmn	w9, #1
	b.ne	LBB0_127
; %bb.196:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w9, [sp, #1040]
	cmp	w9, #1
	b.ne	LBB0_127
; %bb.197:                              ;   in Loop: Header=BB0_52 Depth=1
	cbz	w8, LBB0_86
; %bb.198:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	x8, [sp, #1048]
	cmp	x8, #1
	b.hi	LBB0_127
	b	LBB0_86
LBB0_199:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w2, #-1                         ; =0xffffffff
LBB0_200:                               ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #240]
	ldr	w3, [sp, #924]
	ldr	w4, [sp, #920]
	mov	x0, x22
	bl	_nvm_file_runtime_service
	mov	x1, x0
	cbnz	w0, LBB0_207
; %bb.201:                              ;   in Loop: Header=BB0_52 Depth=1
	sub	w8, w23, w24
	and	w1, w8, #0xffff
	add	x2, sp, #828
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_204
; %bb.202:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	w1, [sp, #920]
	ldr	w2, [sp, #828]
	mov	x0, x22
LBB0_203:                               ;   in Loop: Header=BB0_52 Depth=1
	bl	_nvm_file_runtime_move
	mov	x1, x0
	cbz	w0, LBB0_171
	b	LBB0_248
LBB0_204:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	mov	w1, #5                          ; =0x5
LBB0_205:                               ;   in Loop: Header=BB0_52 Depth=1
	bl	_nvm_file_runtime_fail
LBB0_206:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x1, x0
LBB0_207:                               ;   in Loop: Header=BB0_52 Depth=1
	cbnz	w1, LBB0_248
; %bb.208:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrb	w8, [sp, #232]
	cmp	w8, #61
	b.ne	LBB0_51
; %bb.209:                              ;   in Loop: Header=BB0_52 Depth=1
	ldrh	w8, [sp, #184]
	cmp	w8, #1
	b.ne	LBB0_51
; %bb.210:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	x0, [sp, #216]
	add	x1, sp, #928
	bl	_nvm_file_runtime_current_root
	tbz	w0, #0, LBB0_249
; %bb.211:                              ;   in Loop: Header=BB0_52 Depth=1
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_frame_start
	mov	x1, x0
	b	LBB0_51
LBB0_212:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x0, x22
	mov	w1, #9                          ; =0x9
	b	LBB0_205
LBB0_213:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	cset	w24, ge
	b	LBB0_237
LBB0_214:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	x9, LBB0_227
; %bb.215:                              ;   in Loop: Header=BB0_52 Depth=1
	mov	x11, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x11
	b.ne	LBB0_217
; %bb.216:                              ;   in Loop: Header=BB0_52 Depth=1
	cmn	x9, #1
	b.eq	LBB0_227
LBB0_217:                               ;   in Loop: Header=BB0_52 Depth=1
	sdiv	x9, x8, x10
	msub	x24, x9, x10, x8
	b	LBB0_228
LBB0_218:                               ;   in Loop: Header=BB0_52 Depth=1
	neg	x24, x8
	b	LBB0_228
LBB0_219:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	cset	w24, le
	b	LBB0_237
LBB0_220:                               ;   in Loop: Header=BB0_52 Depth=1
	mul	x24, x9, x8
	b	LBB0_228
LBB0_221:                               ;   in Loop: Header=BB0_52 Depth=1
	sub	x24, x8, x9
	b	LBB0_228
LBB0_222:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	b	LBB0_234
LBB0_223:                               ;   in Loop: Header=BB0_52 Depth=1
	cbz	x9, LBB0_227
; %bb.224:                              ;   in Loop: Header=BB0_52 Depth=1
	mov	x24, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x24
	b.ne	LBB0_226
; %bb.225:                              ;   in Loop: Header=BB0_52 Depth=1
	cmn	x9, #1
	b.eq	LBB0_228
LBB0_226:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w27, #1                         ; =0x1
	sdiv	x24, x8, x10
	b	LBB0_238
LBB0_227:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	x24, #0                         ; =0x0
LBB0_228:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w27, #1                         ; =0x1
	b	LBB0_238
LBB0_229:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	b	LBB0_236
LBB0_230:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	cset	w24, lt
	b	LBB0_237
LBB0_231:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, x9
	cset	w24, gt
	b	LBB0_237
LBB0_232:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, #0
	ccmp	x9, #0, #4, ne
	b	LBB0_236
LBB0_233:                               ;   in Loop: Header=BB0_52 Depth=1
	cmp	x8, #0
LBB0_234:                               ;   in Loop: Header=BB0_52 Depth=1
	cset	w24, eq
	b	LBB0_237
LBB0_235:                               ;   in Loop: Header=BB0_52 Depth=1
	orr	x8, x8, x9
	cmp	x8, #0
LBB0_236:                               ;   in Loop: Header=BB0_52 Depth=1
	cset	w24, ne
LBB0_237:                               ;   in Loop: Header=BB0_52 Depth=1
	mov	w27, #4                         ; =0x4
LBB0_238:                               ;   in Loop: Header=BB0_52 Depth=1
	ldur	w1, [x29, #-112]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_206
; %bb.239:                              ;   in Loop: Header=BB0_52 Depth=1
	tbnz	w23, #0, LBB0_241
; %bb.240:                              ;   in Loop: Header=BB0_52 Depth=1
	ldur	w1, [x29, #-108]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_206
LBB0_241:                               ;   in Loop: Header=BB0_52 Depth=1
	ldur	w1, [x29, #-112]
	mov	x0, x22
	mov	x2, x27
	mov	x3, x24
	bl	_nvm_file_runtime_scalar
	mov	x1, x0
	cbnz	w0, LBB0_207
	b	LBB0_171
LBB0_242:
	ldr	x10, [sp, #32]
	cmp	x10, #1
	b.hi	LBB0_46
LBB0_243:
	mov	w8, #0                          ; =0x0
	strb	w9, [x20]
	stur	wzr, [x20, #1]
	str	wzr, [x20, #4]
	str	x10, [x20, #8]
	b	LBB0_46
LBB0_244:
	mov	w1, #5                          ; =0x5
	b	LBB0_246
LBB0_245:
	mov	w1, #3                          ; =0x3
LBB0_246:
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_fail
	cbz	w0, LBB0_249
LBB0_247:
	mov	x1, x0
LBB0_248:
	ldr	x0, [sp, #216]
	bl	_nvm_file_runtime_fail
LBB0_249:
	add	x8, sp, #224
	add	x0, sp, #216
	mov	x1, sp
	bl	_nvm_file_runtime_destroy
	b	LBB0_29
LBB0_250:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_171-LBB0_60)>>2
	.short	(LBB0_65-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_65-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_65-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_142-LBB0_60)>>2
	.short	(LBB0_121-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_113-LBB0_60)>>2
	.short	(LBB0_128-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_68-LBB0_60)>>2
	.short	(LBB0_113-LBB0_60)>>2
	.short	(LBB0_128-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_147-LBB0_60)>>2
	.short	(LBB0_148-LBB0_60)>>2
	.short	(LBB0_112-LBB0_60)>>2
	.short	(LBB0_112-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_69-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_69-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_171-LBB0_60)>>2
	.short	(LBB0_89-LBB0_60)>>2
	.short	(LBB0_89-LBB0_60)>>2
	.short	(LBB0_68-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_149-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_106-LBB0_60)>>2
	.short	(LBB0_60-LBB0_60)>>2
	.short	(LBB0_60-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_131-LBB0_60)>>2
	.short	(LBB0_150-LBB0_60)>>2
	.short	(LBB0_153-LBB0_60)>>2
	.short	(LBB0_129-LBB0_60)>>2
	.short	(LBB0_121-LBB0_60)>>2
	.short	(LBB0_146-LBB0_60)>>2
	.short	(LBB0_68-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_89-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_69-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_106-LBB0_60)>>2
	.short	(LBB0_60-LBB0_60)>>2
	.short	(LBB0_70-LBB0_60)>>2
	.short	(LBB0_60-LBB0_60)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_88-LBB0_88)>>2
	.short	(LBB0_221-LBB0_88)>>2
	.short	(LBB0_220-LBB0_88)>>2
	.short	(LBB0_223-LBB0_88)>>2
	.short	(LBB0_214-LBB0_88)>>2
	.short	(LBB0_218-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_222-LBB0_88)>>2
	.short	(LBB0_229-LBB0_88)>>2
	.short	(LBB0_230-LBB0_88)>>2
	.short	(LBB0_219-LBB0_88)>>2
	.short	(LBB0_231-LBB0_88)>>2
	.short	(LBB0_213-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_232-LBB0_88)>>2
	.short	(LBB0_235-LBB0_88)>>2
	.short	(LBB0_233-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_88-LBB0_88)>>2
	.short	(LBB0_221-LBB0_88)>>2
	.short	(LBB0_220-LBB0_88)>>2
	.short	(LBB0_223-LBB0_88)>>2
	.short	(LBB0_214-LBB0_88)>>2
	.short	(LBB0_218-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_204-LBB0_88)>>2
	.short	(LBB0_222-LBB0_88)>>2
	.short	(LBB0_229-LBB0_88)>>2
	.short	(LBB0_230-LBB0_88)>>2
	.short	(LBB0_219-LBB0_88)>>2
	.short	(LBB0_231-LBB0_88)>>2
	.short	(LBB0_213-LBB0_88)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fvm_fact
_fvm_fact:                              ; @fvm_fact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #0                          ; =0x0
	ldrb	w9, [x1, #8]
	cmp	w9, #255
	b.eq	LBB1_36
; %bb.1:
Lloh10:
	adrp	x10, lJTI1_0@PAGE
Lloh11:
	add	x10, x10, lJTI1_0@PAGEOFF
	adr	x11, LBB1_2
	ldrb	w12, [x10, x9]
	add	x11, x11, x12, lsl #2
	br	x11
LBB1_2:
	ldrb	w8, [x2]
	cmp	w8, #1
	b.ne	LBB1_8
; %bb.3:
	cmp	w9, #147
	b.gt	LBB1_9
; %bb.4:
	cmp	w9, #60
	b.gt	LBB1_11
; %bb.5:
	cmp	w9, #15
	b.eq	LBB1_14
; %bb.6:
	cmp	w9, #59
	b.eq	LBB1_14
; %bb.7:
	mov	w8, #0                          ; =0x0
	b	LBB1_15
LBB1_8:
	mov	w8, #1                          ; =0x1
	b	LBB1_36
LBB1_9:
	cmp	w9, #150
	b.gt	LBB1_12
; %bb.10:
	mov	w8, #1                          ; =0x1
	mov	w10, #2                         ; =0x2
	cmp	w9, #149
	csel	w10, w10, wzr, eq
	cmp	w9, #148
	csel	w8, w8, w10, eq
	b	LBB1_15
LBB1_11:
	mov	w8, #4                          ; =0x4
	mov	w10, #6                         ; =0x6
	cmp	w9, #145
	csel	w10, w10, wzr, eq
	cmp	w9, #61
	csel	w8, w8, w10, eq
	b	LBB1_15
LBB1_12:
	cmp	w9, #151
	b.eq	LBB1_14
; %bb.13:
	mov	w8, #3                          ; =0x3
	cmp	w9, #161
	csel	w8, w8, wzr, eq
	b	LBB1_15
LBB1_14:
	mov	w8, #5                          ; =0x5
LBB1_15:
	ldr	w10, [x2, #12]
	cmp	w10, w8
	b.ne	LBB1_35
; %bb.16:
	ldrb	w8, [x2, #2]
	cmp	w9, #146
	cset	w10, eq
	cmp	w8, w10
	b.ne	LBB1_35
; %bb.17:
	ldrb	w8, [x2, #1]
	cmp	w9, #61
	cset	w10, eq
	cmp	w8, w10
	b.ne	LBB1_35
; %bb.18:
	mov	w8, #1                          ; =0x1
	cmp	w9, #15
	mov	w10, #151                       ; =0x97
	ccmp	w9, w10, #4, ne
	cset	w10, eq
	cmp	w9, #59
	csel	w8, w8, w10, eq
	cmp	w9, #145
	ldrb	w10, [x2, #3]
	csinc	w8, w8, wzr, ne
	cmp	w10, w8
	b.ne	LBB1_35
; %bb.19:
	cbz	w8, LBB1_30
; %bb.20:
	ldr	w8, [x2, #28]
	ldr	w10, [x1]
	cmp	w8, w10
	b.ne	LBB1_35
; %bb.21:
	ldr	w8, [x2, #32]
	ldr	w10, [x1, #16]
	cmp	w8, w10
	b.ne	LBB1_35
; %bb.22:
	cmp	w9, #145
	cset	w10, ne
	ldr	w11, [x2, #24]
	cmp	w11, w10
	b.ne	LBB1_35
; %bb.23:
	cmp	w9, #145
	b.ne	LBB1_33
; %bb.24:
	mov	x20, x1
	mov	x19, x2
	add	x2, sp, #12
	mov	x1, x8
	bl	_nvm_file_hosted_import
	cbz	w0, LBB1_35
; %bb.25:
	ldr	w0, [sp, #12]
	ldr	w8, [x20, #592]
	cmp	w0, w8
	b.ne	LBB1_35
; %bb.26:
	bl	_nl_file_catalog_method
	cbz	x0, LBB1_35
; %bb.27:
	ldr	w8, [x19, #40]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB1_35
; %bb.28:
	ldr	w8, [x19, #44]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB1_35
; %bb.29:
	mov	w8, #0                          ; =0x0
	ldr	w9, [sp, #12]
	subs	w10, w9, #1
	mov	w11, #399                       ; =0x18f
	mov	w12, #415                       ; =0x19f
	cmp	w10, #3
	csel	w10, w12, w11, lo
	orr	w11, w10, #0x20
	cmp	w9, #1
	csel	w9, w11, w10, eq
	mov	x2, x19
	b	LBB1_34
LBB1_30:
	mov	w9, #128                        ; =0x80
LBB1_31:
	ldr	w10, [x2, #16]
	cmp	w10, w8
	b.ne	LBB1_35
; %bb.32:
	ldr	w10, [x2, #20]
	bic	w8, w9, w8
	cmp	w10, w8
	cset	w8, eq
	b	LBB1_36
LBB1_33:
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
LBB1_34:
	ldr	w10, [x2, #36]
	cmp	w10, w9
	b.eq	LBB1_31
LBB1_35:
	mov	w8, #0                          ; =0x0
LBB1_36:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
	.section	__TEXT,__const
lJTI1_0:
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_36-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
                                        ; -- End function
.subsections_via_symbols
