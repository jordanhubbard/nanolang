	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_file_service_storage_bound  ; -- Begin function nl_file_service_storage_bound
	.p2align	2
_nl_file_service_storage_bound:         ; @nl_file_service_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, sp, #8
	bl	_nl_cap_private_storage_bound
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB0_4
; %bb.2:
	ldr	x8, [sp, #8]
	cmn	x8, #2073
	b.hi	LBB0_4
; %bb.3:
	add	x8, x8, #2072
	str	x8, [x19]
	mov	w0, #1                          ; =0x1
LBB0_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB0_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_service_create         ; -- Begin function nl_file_service_create
	.p2align	2
_nl_file_service_create:                ; @nl_file_service_create
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB1_5
; %bb.1:
	adrp	x21, _file_context_counter@PAGE
	ldr	x8, [x21, _file_context_counter@PAGEOFF]
	cmn	x8, #1
	b.eq	LBB1_6
; %bb.2:
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #2072                       ; =0x818
	bl	_calloc
	cbz	x0, LBB1_8
; %bb.3:
	mov	x20, x0
	bl	_nl_cap_table_create
	str	x0, [x20]
	cbz	x0, LBB1_7
; %bb.4:
	ldr	x8, [x21, _file_context_counter@PAGEOFF]
	add	x8, x8, #1
	str	x8, [x21, _file_context_counter@PAGEOFF]
	str	x8, [x20, #8]
	str	x20, [x22]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB1_10
LBB1_5:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	b	LBB1_9
LBB1_6:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #6                          ; =0x6
	b	LBB1_9
LBB1_7:
	mov	x0, x20
	bl	_free
LBB1_8:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #7                          ; =0x7
LBB1_9:
	str	w8, [x19]
LBB1_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_acquire_temp           ; -- Begin function nl_file_acquire_temp
	.p2align	2
_nl_file_acquire_temp:                  ; @nl_file_acquire_temp
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_3
; %bb.1:
	ldrb	w9, [x0, #16]
	cbz	w9, LBB2_5
; %bb.2:
	lsl	w9, w9, #1
	b	LBB2_4
LBB2_3:
	mov	w9, #1                          ; =0x1
LBB2_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	w9, [x8]
	ret
LBB2_5:
	cbz	x2, LBB2_11
; %bb.6:
	mov	w9, #-20                        ; =0xffffffec
	and	w9, w1, w9
	cbnz	w9, LBB2_11
; %bb.7:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	add	x22, x0, #24
	mov	w9, #24                         ; =0x18
LBB2_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x0, x9]
	cbz	x10, LBB2_12
; %bb.9:                                ;   in Loop: Header=BB2_8 Depth=1
	add	x9, x9, #32
	cmp	x9, #2072
	b.ne	LBB2_8
; %bb.10:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	mov	w9, #5                          ; =0x5
	str	w9, [x8]
	b	LBB2_28
LBB2_11:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	ret
LBB2_12:
	mov	x20, x1
	mov	x24, x0
	mov	x23, x2
	mov	x21, x8
	bl	___error
	str	wzr, [x0]
	bl	_tmpfile
	mov	x19, x0
	bl	___error
	cbz	x19, LBB2_16
; %bb.13:
	ldr	x0, [x24]
Lloh0:
	adrp	x1, l_.str@PAGE
Lloh1:
	add	x1, x1, l_.str@PAGEOFF
Lloh2:
	adrp	x2, l_.str.1@PAGE
Lloh3:
	add	x2, x2, l_.str.1@PAGEOFF
	mov	x4, sp
	mov	x3, x20
	bl	_nl_cap_private_mint
	cmp	w0, #5
	b.gt	LBB2_17
; %bb.14:
	sub	w8, w0, #4
	cmp	w8, #2
	b.hs	LBB2_21
; %bb.15:
	mov	w9, #4                          ; =0x4
	mov	x8, x21
	b	LBB2_26
LBB2_16:
	ldr	w8, [x0]
	stp	xzr, xzr, [x21, #16]
	str	xzr, [x21, #8]
	mov	w9, #8                          ; =0x8
	stp	w9, w8, [x21]
	b	LBB2_28
LBB2_17:
	cmp	w0, #6
	b.eq	LBB2_23
; %bb.18:
	cmp	w0, #8
	mov	x8, x21
	b.eq	LBB2_25
; %bb.19:
	cmp	w0, #9
	b.ne	LBB2_24
; %bb.20:
	mov	w9, #8                          ; =0x8
	b	LBB2_26
LBB2_21:
	mov	x8, x21
	cbnz	w0, LBB2_24
; %bb.22:
	ldr	w9, [sp, #8]
	add	x9, x22, x9, lsl #5
	str	x19, [x9]
	ldr	q0, [sp]
	stur	q0, [x9, #8]
	str	xzr, [x9, #24]
	ldr	x9, [x24, #8]
	str	x9, [x23]
	stur	q0, [x23, #8]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	b	LBB2_28
LBB2_23:
	mov	w9, #5                          ; =0x5
	mov	x8, x21
	b	LBB2_26
LBB2_24:
	mov	w9, #3                          ; =0x3
	b	LBB2_26
LBB2_25:
	mov	w9, #6                          ; =0x6
LBB2_26:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	w9, [x8]
	bl	___error
	str	wzr, [x0]
	mov	x0, x19
	bl	_fclose
	mov	x19, x0
	bl	___error
	cbz	w19, LBB2_28
; %bb.27:
	ldr	w8, [x0]
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #26]
	str	w8, [x21, #8]
LBB2_28:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_read                   ; -- Begin function nl_file_read
	.p2align	2
_nl_file_read:                          ; @nl_file_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
	cmp	x2, #0
	ccmp	x3, #0, #4, eq
	cset	w8, ne
	tbnz	x3, #63, LBB3_4
; %bb.1:
	cbnz	w8, LBB3_4
; %bb.2:
	mov	x20, x3
	mov	x21, x2
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	w2, #1                          ; =0x1
	bl	_file_resolve
	cbz	w0, LBB3_7
; %bb.3:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB3_6
LBB3_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
LBB3_5:
	str	w8, [x19]
LBB3_6:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB3_7:
	cbz	x20, LBB3_10
; %bb.8:
	ldr	x22, [sp, #8]
	ldr	w8, [x22, #24]
	cmp	w8, #2
	b.ne	LBB3_11
; %bb.9:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #9                          ; =0x9
	b	LBB3_5
LBB3_10:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB3_6
LBB3_11:
	bl	___error
	str	wzr, [x0]
	ldr	x3, [x22]
	mov	w23, #1                         ; =0x1
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	mov	x2, x20
	bl	_fread
	mov	x20, x0
	bl	___error
	ldr	w21, [x0]
	str	w23, [x22, #24]
	ldr	x0, [x22]
	bl	_feof
	cmp	w0, #0
	cset	w23, ne
	ldr	x0, [x22]
	bl	_ferror
	cmp	w0, #0
	csel	w8, wzr, w21, eq
	mov	w9, #8                          ; =0x8
	csel	w9, wzr, w9, eq
	stp	w9, w8, [x19]
	stp	xzr, x20, [x19, #8]
	strb	w23, [x19, #24]
	stur	wzr, [x19, #25]
	str	wzr, [x19, #28]
	b	LBB3_6
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_resolve
_file_resolve:                          ; @file_resolve
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_7
; %bb.1:
	ldrb	w8, [x0, #16]
	cbz	w8, LBB4_3
; %bb.2:
	lsl	w0, w8, #1
	ret
LBB4_3:
	cbz	x1, LBB4_7
; %bb.4:
	ldr	x8, [x1]
	ldr	x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB4_6
; %bb.5:
	ldr	w8, [x1, #16]
	cmp	w8, #63
	b.ls	LBB4_8
LBB4_6:
	mov	w0, #3                          ; =0x3
	ret
LBB4_7:
	mov	w0, #1                          ; =0x1
	ret
LBB4_8:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	mov	x21, x0
	ldr	x0, [x0]
	mov	x20, x1
	add	x1, x1, #8
	bl	_nl_cap_check
	cmp	w0, #5
	b.gt	LBB4_11
; %bb.9:
	sub	w8, w0, #4
	cmp	w8, #2
	b.hs	LBB4_15
; %bb.10:
	mov	w0, #4                          ; =0x4
	b	LBB4_23
LBB4_11:
	cmp	w0, #6
	b.eq	LBB4_21
; %bb.12:
	cmp	w0, #8
	b.eq	LBB4_22
; %bb.13:
	cmp	w0, #9
	b.ne	LBB4_20
; %bb.14:
	mov	w0, #8                          ; =0x8
	b	LBB4_23
LBB4_15:
	cbnz	w0, LBB4_20
; %bb.16:
	ldr	w10, [x20, #16]
	add	x22, x21, x10, lsl #5
	ldr	x10, [x22, #24]!
	cbz	x10, LBB4_20
; %bb.17:
	mov	x8, x20
	ldp	x10, x11, [x22, #8]
	ldp	x12, x13, [x20, #8]
	cmp	x11, x13
	ccmp	x10, x12, #0, eq
	b.ne	LBB4_20
; %bb.18:
	ldr	x0, [x21]
	add	x1, x8, #8
	bl	_nl_cap_type_id
Lloh4:
	adrp	x1, l_.str@PAGE
Lloh5:
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB4_20
; %bb.19:
	ldr	x0, [x21]
	add	x1, x20, #8
	bl	_nl_cap_service_id
Lloh6:
	adrp	x1, l_.str.1@PAGE
Lloh7:
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB4_24
LBB4_20:
	mov	w0, #3                          ; =0x3
	b	LBB4_23
LBB4_21:
	mov	w0, #5                          ; =0x5
	b	LBB4_23
LBB4_22:
	mov	w0, #6                          ; =0x6
LBB4_23:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB4_24:
	str	x22, [x19]
	b	LBB4_23
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_write                  ; -- Begin function nl_file_write
	.p2align	2
_nl_file_write:                         ; @nl_file_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
	cmp	x2, #0
	ccmp	x3, #0, #4, eq
	cset	w8, ne
	tbnz	x3, #63, LBB5_4
; %bb.1:
	cbnz	w8, LBB5_4
; %bb.2:
	mov	x20, x3
	mov	x21, x2
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	w2, #2                          ; =0x2
	bl	_file_resolve
	cbz	w0, LBB5_7
; %bb.3:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB5_6
LBB5_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
LBB5_5:
	str	w8, [x19]
LBB5_6:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB5_7:
	cbz	x20, LBB5_10
; %bb.8:
	ldr	x22, [sp, #8]
	ldr	w8, [x22, #24]
	cmp	w8, #1
	b.ne	LBB5_11
; %bb.9:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #9                          ; =0x9
	b	LBB5_5
LBB5_10:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB5_6
LBB5_11:
	bl	___error
	str	wzr, [x0]
	ldr	x3, [x22]
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	mov	x2, x20
	bl	_fwrite
	mov	x21, x0
	bl	___error
	ldr	w23, [x0]
	mov	w8, #2                          ; =0x2
	str	w8, [x22, #24]
	cmp	x21, x20
	b.ne	LBB5_13
; %bb.12:
	ldr	x0, [x22]
	bl	_ferror
	cbz	w0, LBB5_15
LBB5_13:
	mov	w8, #8                          ; =0x8
LBB5_14:
	stp	w8, w23, [x19]
	stp	xzr, x21, [x19, #8]
	str	xzr, [x19, #24]
	b	LBB5_6
LBB5_15:
	mov	w23, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	b	LBB5_14
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_rewind                 ; -- Begin function nl_file_rewind
	.p2align	2
_nl_file_rewind:                        ; @nl_file_rewind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	w2, #1                          ; =0x1
	bl	_file_resolve
	cbz	w0, LBB6_2
; %bb.1:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB6_5
LBB6_2:
	bl	___error
	str	wzr, [x0]
	ldr	x21, [sp, #8]
	ldr	x0, [x21]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_fseek
	mov	x20, x0
	bl	___error
	cbz	w20, LBB6_4
; %bb.3:
	ldr	w8, [x0]
	stp	xzr, xzr, [x19, #16]
	str	xzr, [x19, #8]
	mov	w9, #8                          ; =0x8
	stp	w9, w8, [x19]
	b	LBB6_5
LBB6_4:
	ldr	x0, [x21]
	bl	_clearerr
	str	wzr, [x21, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
LBB6_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_transfer               ; -- Begin function nl_file_transfer
	.p2align	2
_nl_file_transfer:                      ; @nl_file_transfer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
	cbz	x2, LBB7_3
; %bb.1:
	mov	x20, x0
	mov	x22, x2
	str	xzr, [sp, #56]
	add	x3, sp, #56
	mov	w2, #16                         ; =0x10
	bl	_file_resolve
	cbz	w0, LBB7_4
; %bb.2:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB7_11
LBB7_3:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	b	LBB7_10
LBB7_4:
	ldr	x23, [sp, #56]
	ldp	q1, q0, [x23]
	stp	q1, q0, [sp, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23]
	ldr	x0, [x20]
	add	x8, sp, #16
	orr	x21, x8, #0x8
	mov	x2, sp
	mov	x1, x21
	bl	_nl_cap_private_transfer
	cbz	w0, LBB7_7
; %bb.5:
	ldp	q0, q1, [sp, #16]
	stp	q0, q1, [x23]
	sub	w8, w0, #4
	cmp	w8, #5
	b.hi	LBB7_8
; %bb.6:
Lloh8:
	adrp	x9, l_switch.table.nl_file_consume_close@PAGE
Lloh9:
	add	x9, x9, l_switch.table.nl_file_consume_close@PAGEOFF
	ldr	w8, [x9, w8, uxtw #2]
	b	LBB7_9
LBB7_7:
	ldr	q0, [sp]
	str	q0, [x21]
	ldr	w8, [sp, #8]
	add	x8, x20, x8, lsl #5
	ldp	q2, q1, [sp, #16]
	stur	q1, [x8, #40]
	stur	q2, [x8, #24]
	ldr	x8, [x20, #8]
	str	x8, [x22]
	stur	q0, [x22, #8]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #25]
	b	LBB7_11
LBB7_8:
	mov	w8, #3                          ; =0x3
LBB7_9:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
LBB7_10:
	str	w8, [x19]
LBB7_11:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_consume_close          ; -- Begin function nl_file_consume_close
	.p2align	2
_nl_file_consume_close:                 ; @nl_file_consume_close
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	mov	x19, x8
	str	xzr, [sp, #40]
	add	x3, sp, #40
	mov	w2, #0                          ; =0x0
	bl	_file_resolve
	cbz	w0, LBB8_2
; %bb.1:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB8_9
LBB8_2:
	ldr	x21, [sp, #40]
	ldp	q1, q0, [x21]
	stp	q1, q0, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x21]
	ldr	x0, [x20]
	mov	x8, sp
	orr	x1, x8, #0x8
	bl	_nl_cap_private_consume
	cbz	w0, LBB8_5
; %bb.3:
	ldp	q0, q1, [sp]
	stp	q0, q1, [x21]
	sub	w8, w0, #4
	cmp	w8, #5
	b.hi	LBB8_7
; %bb.4:
Lloh10:
	adrp	x9, l_switch.table.nl_file_consume_close@PAGE
Lloh11:
	add	x9, x9, l_switch.table.nl_file_consume_close@PAGEOFF
	ldr	w8, [x9, w8, uxtw #2]
	b	LBB8_8
LBB8_5:
	bl	___error
	str	wzr, [x0]
	ldr	x0, [sp]
	bl	_fclose
	mov	x20, x0
	bl	___error
	ldr	w8, [x0]
	mov	w9, #8                          ; =0x8
	cmp	w20, #0
	csel	w9, wzr, w9, eq
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w9, [x19]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, #25]
	cbz	w20, LBB8_9
; %bb.6:
	str	w8, [x19, #4]
	b	LBB8_9
LBB8_7:
	mov	w8, #3                          ; =0x3
LBB8_8:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	w8, [x19]
LBB8_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_service_dispose        ; -- Begin function nl_file_service_dispose
	.p2align	2
_nl_file_service_dispose:               ; @nl_file_service_dispose
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	cbz	x0, LBB9_21
; %bb.1:
	mov	x20, x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	ldrb	w8, [x0, #16]
	tbnz	w8, #0, LBB9_24
; %bb.2:
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #16]
	strb	w8, [x19, #25]
	mov	x26, sp
	mov	w27, #24                        ; =0x18
	b	LBB9_5
LBB9_3:                                 ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #0                         ; =0x0
LBB9_4:                                 ;   in Loop: Header=BB9_5 Depth=1
	add	x27, x27, #32
	cmp	x27, #2072
	b.eq	LBB9_22
LBB9_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x8, x20, x27
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp]
	ldr	x9, [sp]
	cbz	x9, LBB9_4
; %bb.6:                                ;   in Loop: Header=BB9_5 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ldr	x0, [x20]
	add	x1, x26, #8
	bl	_nl_cap_private_consume
	mov	x22, x0
	bl	___error
	str	wzr, [x0]
	ldr	x0, [sp]
	bl	_fclose
	mov	x21, x0
	bl	___error
	cbnz	w28, LBB9_4
; %bb.7:                                ;   in Loop: Header=BB9_5 Depth=1
	orr	w8, w21, w22
	cbz	w8, LBB9_3
; %bb.8:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	w8, [x0]
	cmp	w22, #5
	b.gt	LBB9_11
; %bb.9:                                ;   in Loop: Header=BB9_5 Depth=1
	sub	w9, w22, #4
	cmp	w9, #2
	b.hs	LBB9_15
; %bb.10:                               ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #4                         ; =0x4
	b	LBB9_20
LBB9_11:                                ;   in Loop: Header=BB9_5 Depth=1
	cmp	w22, #6
	b.eq	LBB9_17
; %bb.12:                               ;   in Loop: Header=BB9_5 Depth=1
	cmp	w22, #8
	b.eq	LBB9_19
; %bb.13:                               ;   in Loop: Header=BB9_5 Depth=1
	cmp	w22, #9
	b.ne	LBB9_18
; %bb.14:                               ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #8                         ; =0x8
	b	LBB9_20
LBB9_15:                                ;   in Loop: Header=BB9_5 Depth=1
	cbnz	w22, LBB9_18
; %bb.16:                               ;   in Loop: Header=BB9_5 Depth=1
	cmp	w21, #0
	csel	w25, w25, w8, eq
	mov	w28, #8                         ; =0x8
	b	LBB9_4
LBB9_17:                                ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #5                         ; =0x5
	b	LBB9_20
LBB9_18:                                ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #3                         ; =0x3
	b	LBB9_20
LBB9_19:                                ;   in Loop: Header=BB9_5 Depth=1
	mov	w28, #6                         ; =0x6
LBB9_20:                                ;   in Loop: Header=BB9_5 Depth=1
	cmp	w21, #0
	csel	w23, w23, w8, eq
	csinc	w24, w24, wzr, eq
	b	LBB9_4
LBB9_21:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w28, #1                         ; =0x1
	b	LBB9_23
LBB9_22:
	strb	w24, [x19, #26]
	stp	w25, w23, [x19, #4]
LBB9_23:
	str	w28, [x19]
LBB9_24:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_service_destroy        ; -- Begin function nl_file_service_destroy
	.p2align	2
_nl_file_service_destroy:               ; @nl_file_service_destroy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nl_file_service_dispose
	ldr	x0, [x19]
	bl	_nl_cap_table_destroy
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB10_2:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_file_context_counter,8,3 ; @file_context_counter
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/filesystem#File"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:nanolang/filesystem"

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @switch.table.nl_file_consume_close
l_switch.table.nl_file_consume_close:
	.long	4                               ; 0x4
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	3                               ; 0x3
	.long	6                               ; 0x6
	.long	8                               ; 0x8

.subsections_via_symbols
