	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_multi_nominal_storage_bound ; -- Begin function nvm_multi_nominal_storage_bound
	.p2align	2
_nvm_multi_nominal_storage_bound:       ; @nvm_multi_nominal_storage_bound
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	w0, [x29, #-8]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB0_3
	b	LBB0_1
LBB0_1:
	ldur	w8, [x29, #-8]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.hi	LBB0_3
	b	LBB0_2
LBB0_2:
	ldur	w8, [x29, #-8]
	mov	x0, x8
	add	x1, sp, #8
	bl	_plan_extent
	tbnz	w0, #0, LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_5
LBB0_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB0_5
LBB0_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function plan_extent
_plan_extent:                           ; @plan_extent
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43530
	movk	x9, #2730, lsl #48
	subs	x8, x8, x9
	b.ls	LBB1_2
	b	LBB1_1
LBB1_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_2:
	ldr	x8, [sp, #16]
	mov	x9, #24                         ; =0x18
	mul	x8, x8, x9
	add	x8, x8, #3848
	ldr	x9, [sp, #8]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB1_3
LBB1_3:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_plan         ; -- Begin function nvm_multi_nominal_plan
	.p2align	2
_nvm_multi_nominal_plan:                ; @nvm_multi_nominal_plan
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3920
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #40
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [x8, #8]
	str	x1, [x8]
	ldr	x8, [x8, #8]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB2_3
	b	LBB2_2
LBB2_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	ldr	x0, [x9, #328]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #336]
	mov	x1, x8
	add	x2, sp, #52
	bl	_nvm_multi_nominal_decode
	cbnz	w0, LBB2_5
	b	LBB2_4
LBB2_4:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	add	x1, sp, #52
	bl	_imports_valid
	tbnz	w0, #0, LBB2_6
	b	LBB2_5
LBB2_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x2, sp, #48
	str	wzr, [sp, #48]
	ldr	x0, [x8, #8]
	add	x1, sp, #52
	mov	x3, #0                          ; =0x0
	bl	_layouts_read
	str	w0, [sp, #44]
	ldr	w8, [sp, #44]
	cbz	w8, LBB2_8
	b	LBB2_7
LBB2_7:
	ldr	w8, [sp, #44]
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_8:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	ldr	w2, [sp, #48]
	add	x1, sp, #52
	bl	_ownership_valid
	tbnz	w0, #0, LBB2_10
	b	LBB2_9
LBB2_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_10:
	ldr	w8, [sp, #48]
	mov	x0, x8
	add	x1, sp, #32
	bl	_plan_extent
	tbnz	w0, #0, LBB2_12
	b	LBB2_11
LBB2_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_12:
	ldr	x0, [sp, #32]
	bl	_malloc
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_14:
	ldr	x0, [sp, #24]
	add	x1, sp, #52
	str	x1, [sp]                        ; 8-byte Folded Spill
	mov	x2, #3844                       ; =0xf04
	bl	_memcpy
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	w9, [sp, #48]
	ldr	x10, [sp, #24]
	str	w9, [x10, #3844]
	add	x2, sp, #20
	str	wzr, [sp, #20]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #24]
	add	x3, x8, #3848
	bl	_layouts_read
	str	w0, [sp, #44]
	ldr	w8, [sp, #44]
	cbnz	w8, LBB2_16
	b	LBB2_15
LBB2_15:
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	b.eq	LBB2_17
	b	LBB2_16
LBB2_16:
	ldr	x0, [sp, #24]
	bl	_free
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB2_18
LBB2_17:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #24]
	ldr	x9, [x9]
	str	x8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB2_18
LBB2_18:
	ldur	w0, [x29, #-20]
	add	sp, sp, #3920
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function imports_valid
_imports_valid:                         ; @imports_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	wzr, [x29, #-28]
	stur	wzr, [x29, #-32]
	b	LBB3_1
LBB3_1:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-32]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB3_4
	b	LBB3_2
LBB3_2:                                 ;   in Loop: Header=BB3_1 Depth=1
	ldur	x8, [x29, #-24]
	add	x8, x8, #4
	ldur	w9, [x29, #-32]
                                        ; kill: def $x9 killed $w9
	mov	x10, #60                        ; =0x3c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w0, [x8, x9]
	bl	_nvm_multi_nominal_catalog_methods
	ldur	w8, [x29, #-28]
	add	w8, w8, w0
	stur	w8, [x29, #-28]
	b	LBB3_3
LBB3_3:                                 ;   in Loop: Header=BB3_1 Depth=1
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB3_1
LBB3_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #432]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB3_8
	b	LBB3_5
LBB3_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #400]
	cbz	x8, LBB3_8
	b	LBB3_6
LBB3_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB3_8
	b	LBB3_7
LBB3_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #424]
	cbz	w8, LBB3_9
	b	LBB3_8
LBB3_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_9:
	stur	wzr, [x29, #-36]
	b	LBB3_10
LBB3_10:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_12 Depth 2
                                        ;       Child Loop BB3_42 Depth 3
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB3_57
	b	LBB3_11
LBB3_11:                                ;   in Loop: Header=BB3_10 Depth=1
	stur	wzr, [x29, #-40]
	b	LBB3_12
LBB3_12:                                ;   Parent Loop BB3_10 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_42 Depth 3
	ldur	w8, [x29, #-40]
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-24]
	add	x8, x8, #4
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #60                        ; =0x3c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w0, [x8, x9]
	bl	_nvm_multi_nominal_catalog_methods
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.hs	LBB3_55
	b	LBB3_13
LBB3_13:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-24]
	add	x10, x8, #4
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x8, x8, #4
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-52]
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.lo	LBB3_15
	b	LBB3_14
LBB3_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_15:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB3_17
	b	LBB3_16
LBB3_16:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	w8, [x29, #-40]
	mov	x0, x8
	bl	_nl_file_catalog_method
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB3_21
LBB3_17:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB3_19
	b	LBB3_18
LBB3_18:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	w8, [x29, #-40]
	mov	x0, x8
	bl	_nl_socket_catalog_method
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB3_20
LBB3_19:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	w8, [x29, #-40]
	mov	x0, x8
	bl	_nl_websocket_catalog_method
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB3_20
LBB3_20:                                ;   in Loop: Header=BB3_12 Depth=2
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB3_21
LBB3_21:                                ;   in Loop: Header=BB3_12 Depth=2
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-72]
	cbz	x8, LBB3_34
	b	LBB3_22
LBB3_22:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #56]
	cbz	x8, LBB3_34
	b	LBB3_23
LBB3_23:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #56]
	subs	x8, x8, #1
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB3_34
	b	LBB3_24
LBB3_24:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #3
	b.ne	LBB3_34
	b	LBB3_25
LBB3_25:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #10
	b.ne	LBB3_34
	b	LBB3_26
LBB3_26:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-16]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-64]
	ldr	w8, [x8]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB3_28
	b	LBB3_27
LBB3_27:                                ;   in Loop: Header=BB3_12 Depth=2
	bl	_nl_file_catalog_interface
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB3_32
LBB3_28:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB3_30
	b	LBB3_29
LBB3_29:                                ;   in Loop: Header=BB3_12 Depth=2
	bl	_nl_socket_catalog_interface
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_31
LBB3_30:                                ;   in Loop: Header=BB3_12 Depth=2
	bl	_nl_websocket_catalog_interface
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_31
LBB3_31:                                ;   in Loop: Header=BB3_12 Depth=2
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB3_32
LBB3_32:                                ;   in Loop: Header=BB3_12 Depth=2
	ldr	w1, [sp, #44]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	bl	_text
	tbz	w0, #0, LBB3_34
	b	LBB3_33
LBB3_33:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-64]
	ldr	w1, [x8, #4]
	ldur	x8, [x29, #-72]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB3_35
	b	LBB3_34
LBB3_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_35:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	cbz	x8, LBB3_37
	b	LBB3_36
LBB3_36:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_38
LBB3_37:                                ;   in Loop: Header=BB3_12 Depth=2
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB3_38
LBB3_38:                                ;   in Loop: Header=BB3_12 Depth=2
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-80]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #8]
	cbz	w8, LBB3_41
	b	LBB3_39
LBB3_39:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-80]
	cbnz	x8, LBB3_41
	b	LBB3_40
LBB3_40:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_41:                                ;   in Loop: Header=BB3_12 Depth=2
	sturh	wzr, [x29, #-82]
	b	LBB3_42
LBB3_42:                                ;   Parent Loop BB3_10 Depth=1
                                        ;     Parent Loop BB3_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldurh	w8, [x29, #-82]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB3_49
	b	LBB3_43
LBB3_43:                                ;   in Loop: Header=BB3_42 Depth=3
	ldur	x8, [x29, #-72]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #24]
	cbnz	w8, LBB3_46
	b	LBB3_44
LBB3_44:                                ;   in Loop: Header=BB3_42 Depth=3
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-36]
	ldur	x8, [x29, #-72]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x2, [x8, #16]
	sub	x3, x29, #83
	add	x4, sp, #88
	bl	_member_type
	tbz	w0, #0, LBB3_46
	b	LBB3_45
LBB3_45:                                ;   in Loop: Header=BB3_42 Depth=3
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldurb	w9, [x29, #-83]
	subs	w8, w8, w9
	b.eq	LBB3_47
	b	LBB3_46
LBB3_46:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_47:                                ;   in Loop: Header=BB3_42 Depth=3
	b	LBB3_48
LBB3_48:                                ;   in Loop: Header=BB3_42 Depth=3
	ldurh	w8, [x29, #-82]
	add	w8, w8, #1
	sturh	w8, [x29, #-82]
	b	LBB3_42
LBB3_49:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x8, [x29, #-72]
	mov	x9, #48                         ; =0x30
	ldr	x10, [x8, #48]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #24]
	subs	w8, w8, #3
	b.ne	LBB3_52
	b	LBB3_50
LBB3_50:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-36]
	ldr	x8, [sp, #72]
	ldr	x2, [x8, #16]
	add	x3, sp, #87
	add	x4, sp, #80
	bl	_member_type
	tbz	w0, #0, LBB3_52
	b	LBB3_51
LBB3_51:                                ;   in Loop: Header=BB3_12 Depth=2
	ldrb	w8, [sp, #87]
	subs	w8, w8, #10
	b.eq	LBB3_53
	b	LBB3_52
LBB3_52:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_53:                                ;   in Loop: Header=BB3_12 Depth=2
	b	LBB3_54
LBB3_54:                                ;   in Loop: Header=BB3_12 Depth=2
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB3_12
LBB3_55:                                ;   in Loop: Header=BB3_10 Depth=1
	b	LBB3_56
LBB3_56:                                ;   in Loop: Header=BB3_10 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB3_10
LBB3_57:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_58
LBB3_58:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_read
_layouts_read:                          ; @layouts_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #312]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB4_3
	b	LBB4_2
LBB4_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_3:
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #312]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #80
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	stur	wzr, [x29, #-88]
	stur	wzr, [x29, #-92]
	stur	wzr, [x29, #-96]
	sub	x1, x29, #84
	bl	_nvm_v2_u32
	cbz	w0, LBB4_5
	b	LBB4_4
LBB4_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_5:
	ldur	w8, [x29, #-84]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB4_7
	b	LBB4_6
LBB4_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_7:
	stur	wzr, [x29, #-100]
	stur	wzr, [x29, #-104]
	b	LBB4_8
LBB4_8:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-104]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB4_11
	b	LBB4_9
LBB4_9:                                 ;   in Loop: Header=BB4_8 Depth=1
	ldur	x8, [x29, #-40]
	add	x10, x8, #4
	ldur	w8, [x29, #-104]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_type_count
	ldur	w8, [x29, #-100]
	add	w8, w8, w0
	stur	w8, [x29, #-100]
	b	LBB4_10
LBB4_10:                                ;   in Loop: Header=BB4_8 Depth=1
	ldur	w8, [x29, #-104]
	add	w8, w8, #1
	stur	w8, [x29, #-104]
	b	LBB4_8
LBB4_11:
	ldur	w8, [x29, #-84]
	ldur	w9, [x29, #-100]
	subs	w8, w8, w9
	b.lo	LBB4_13
	b	LBB4_12
LBB4_12:
	ldur	w8, [x29, #-84]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-72]
	ldur	x10, [x29, #-64]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_14
	b	LBB4_13
LBB4_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_14:
	stur	wzr, [x29, #-108]
	b	LBB4_15
LBB4_15:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_17 Depth 2
	ldur	w8, [x29, #-108]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB4_24
	b	LBB4_16
LBB4_16:                                ;   in Loop: Header=BB4_15 Depth=1
	stur	wzr, [x29, #-112]
	b	LBB4_17
LBB4_17:                                ;   Parent Loop BB4_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-112]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-40]
	add	x10, x8, #4
	ldur	w8, [x29, #-108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_type_count
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.hs	LBB4_22
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_17 Depth=2
	ldur	x8, [x29, #-40]
	add	x10, x8, #4
	ldur	w8, [x29, #-108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #24
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.lo	LBB4_20
	b	LBB4_19
LBB4_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_20:                                ;   in Loop: Header=BB4_17 Depth=2
	b	LBB4_21
LBB4_21:                                ;   in Loop: Header=BB4_17 Depth=2
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB4_17
LBB4_22:                                ;   in Loop: Header=BB4_15 Depth=1
	b	LBB4_23
LBB4_23:                                ;   in Loop: Header=BB4_15 Depth=1
	ldur	w8, [x29, #-108]
	add	w8, w8, #1
	stur	w8, [x29, #-108]
	b	LBB4_15
LBB4_24:
	stur	wzr, [x29, #-116]
	b	LBB4_25
LBB4_25:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_53 Depth 2
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB4_90
	b	LBB4_26
LBB4_26:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x0, x29, #80
	sub	x1, x29, #117
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_34
	b	LBB4_27
LBB4_27:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x0, x29, #80
	sub	x1, x29, #118
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_34
	b	LBB4_28
LBB4_28:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x0, x29, #80
	sub	x1, x29, #120
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_34
	b	LBB4_29
LBB4_29:                                ;   in Loop: Header=BB4_25 Depth=1
	sub	x0, x29, #80
	sub	x1, x29, #124
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_34
	b	LBB4_30
LBB4_30:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-118]
	cbnz	w8, LBB4_34
	b	LBB4_31
LBB4_31:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-117]
	subs	w8, w8, #3
	b.gt	LBB4_34
	b	LBB4_32
LBB4_32:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-124]
	bl	_name_index
	tbz	w0, #0, LBB4_34
	b	LBB4_33
LBB4_33:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurh	w8, [x29, #-120]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-72]
	ldur	x10, [x29, #-64]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_35
	b	LBB4_34
LBB4_34:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_35:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x0, [x29, #-40]
	ldur	w1, [x29, #-116]
	bl	_catalog_at
	str	w0, [sp, #128]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #124]
	ldurb	w8, [x29, #-117]
	cbnz	w8, LBB4_37
	b	LBB4_36
LBB4_36:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-88]
	add	w9, w8, #1
	stur	w9, [x29, #-88]
	str	w8, [sp, #124]
	b	LBB4_43
LBB4_37:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-117]
	subs	w8, w8, #3
	b.ne	LBB4_39
	b	LBB4_38
LBB4_38:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB4_42
LBB4_39:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-117]
	subs	w8, w8, #2
	b.ne	LBB4_41
	b	LBB4_40
LBB4_40:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-96]
	add	w9, w8, #1
	stur	w9, [x29, #-96]
	str	w8, [sp, #124]
	b	LBB4_41
LBB4_41:                                ;   in Loop: Header=BB4_25 Depth=1
	b	LBB4_42
LBB4_42:                                ;   in Loop: Header=BB4_25 Depth=1
	b	LBB4_43
LBB4_43:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #128]
	adds	w8, w8, #1
	b.ne	LBB4_45
	b	LBB4_44
LBB4_44:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB4_46
LBB4_45:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x0, [x29, #-40]
	ldr	w1, [sp, #128]
	bl	_type_at
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB4_46
LBB4_46:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #112]
	ldr	w8, [sp, #128]
	adds	w8, w8, #1
	b.eq	LBB4_52
	b	LBB4_47
LBB4_47:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	x8, [sp, #112]
	cbz	x8, LBB4_51
	b	LBB4_48
LBB4_48:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x29, #-117]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x0, [x29, #-40]
	ldr	w1, [sp, #128]
	bl	_type_kind
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB4_51
	b	LBB4_49
LBB4_49:                                ;   in Loop: Header=BB4_25 Depth=1
	ldurh	w8, [x29, #-120]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #112]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB4_51
	b	LBB4_50
LBB4_50:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-124]
	ldr	x8, [sp, #112]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB4_52
	b	LBB4_51
LBB4_51:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_52:                                ;   in Loop: Header=BB4_25 Depth=1
	str	wzr, [sp, #108]
	b	LBB4_53
LBB4_53:                                ;   Parent Loop BB4_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #108]
	ldurh	w9, [x29, #-120]
	subs	w8, w8, w9
	b.hs	LBB4_77
	b	LBB4_54
LBB4_54:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #107
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_67
	b	LBB4_55
LBB4_55:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #106
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_67
	b	LBB4_56
LBB4_56:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #105
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_67
	b	LBB4_57
LBB4_57:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #104
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_67
	b	LBB4_58
LBB4_58:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_67
	b	LBB4_59
LBB4_59:                                ;   in Loop: Header=BB4_53 Depth=2
	sub	x0, x29, #80
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_67
	b	LBB4_60
LBB4_60:                                ;   in Loop: Header=BB4_53 Depth=2
	ldrb	w8, [sp, #107]
	subs	w8, w8, #16
	b.ge	LBB4_67
	b	LBB4_61
LBB4_61:                                ;   in Loop: Header=BB4_53 Depth=2
	ldrb	w8, [sp, #106]
	cbnz	w8, LBB4_67
	b	LBB4_62
LBB4_62:                                ;   in Loop: Header=BB4_53 Depth=2
	ldrb	w8, [sp, #105]
	cbnz	w8, LBB4_67
	b	LBB4_63
LBB4_63:                                ;   in Loop: Header=BB4_53 Depth=2
	ldrb	w8, [sp, #104]
	cbnz	w8, LBB4_67
	b	LBB4_64
LBB4_64:                                ;   in Loop: Header=BB4_53 Depth=2
	ldur	x0, [x29, #-32]
	ldr	w1, [sp, #96]
	bl	_name_index
	tbz	w0, #0, LBB4_67
	b	LBB4_65
LBB4_65:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	w8, [sp, #100]
	adds	w8, w8, #1
	b.eq	LBB4_68
	b	LBB4_66
LBB4_66:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	w8, [sp, #100]
	ldur	w9, [x29, #-116]
	subs	w8, w8, w9
	b.lo	LBB4_68
	b	LBB4_67
LBB4_67:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_68:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	x8, [sp, #112]
	cbz	x8, LBB4_75
	b	LBB4_69
LBB4_69:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	x8, [sp, #112]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #80]
	ldur	x0, [x29, #-40]
	ldr	w8, [sp, #128]
	mov	w9, #9                          ; =0x9
	udiv	w1, w8, w9
	ldr	x8, [sp, #80]
	ldr	x2, [x8, #16]
	add	x3, sp, #95
	add	x4, sp, #88
	bl	_member_type
	tbz	w0, #0, LBB4_73
	b	LBB4_70
LBB4_70:                                ;   in Loop: Header=BB4_53 Depth=2
	ldrb	w8, [sp, #107]
	ldrb	w9, [sp, #95]
	subs	w8, w8, w9
	b.ne	LBB4_73
	b	LBB4_71
LBB4_71:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #88]
	subs	w8, w8, w9
	b.ne	LBB4_73
	b	LBB4_72
LBB4_72:                                ;   in Loop: Header=BB4_53 Depth=2
	ldur	x0, [x29, #-32]
	ldr	w1, [sp, #96]
	ldr	x8, [sp, #80]
	ldr	x2, [x8]
	bl	_text
	tbnz	w0, #0, LBB4_74
	b	LBB4_73
LBB4_73:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_74:                                ;   in Loop: Header=BB4_53 Depth=2
	b	LBB4_75
LBB4_75:                                ;   in Loop: Header=BB4_53 Depth=2
	b	LBB4_76
LBB4_76:                                ;   in Loop: Header=BB4_53 Depth=2
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB4_53
LBB4_77:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x8, [x29, #-56]
	cbz	x8, LBB4_88
	b	LBB4_78
LBB4_78:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x10, [x29, #-56]
	ldur	w8, [x29, #-116]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	w8, [x29, #-116]
	str	w8, [sp, #56]
	ldr	w8, [sp, #128]
	adds	w8, w8, #1
	b.ne	LBB4_80
	b	LBB4_79
LBB4_79:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB4_81
LBB4_80:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #128]
	mov	w9, #9                          ; =0x9
	udiv	w8, w8, w9
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB4_81
LBB4_81:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #60]
	ldr	w8, [sp, #128]
	adds	w8, w8, #1
	b.ne	LBB4_83
	b	LBB4_82
LBB4_82:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_84
LBB4_83:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #4
	ldr	w9, [sp, #128]
	mov	w10, #9                         ; =0x9
	udiv	w9, w9, w10
	mov	w10, #60                        ; =0x3c
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_84
LBB4_84:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #64]
	ldr	w8, [sp, #128]
	adds	w8, w8, #1
	b.ne	LBB4_86
	b	LBB4_85
LBB4_85:                                ;   in Loop: Header=BB4_25 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB4_87
LBB4_86:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #128]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB4_87
LBB4_87:                                ;   in Loop: Header=BB4_25 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #68]
	ldr	w8, [sp, #124]
	str	w8, [sp, #72]
	ldurb	w8, [x29, #-117]
	strb	w8, [sp, #76]
	ldr	w0, [sp, #128]
	bl	_type_flags
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	strb	w0, [sp, #77]
	strh	wzr, [sp, #78]
	ldur	q0, [sp, #56]
	str	q0, [x9]
	ldr	x8, [sp, #72]
	str	x8, [x9, #16]
	b	LBB4_88
LBB4_88:                                ;   in Loop: Header=BB4_25 Depth=1
	b	LBB4_89
LBB4_89:                                ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB4_25
LBB4_90:
	ldur	x8, [x29, #-64]
	ldur	x9, [x29, #-72]
	subs	x8, x8, x9
	b.ne	LBB4_94
	b	LBB4_91
LBB4_91:
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.ne	LBB4_94
	b	LBB4_92
LBB4_92:
	ldur	w8, [x29, #-92]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.ne	LBB4_94
	b	LBB4_93
LBB4_93:
	ldur	w8, [x29, #-96]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.eq	LBB4_95
	b	LBB4_94
LBB4_94:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB4_96
LBB4_95:
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-48]
	str	w8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB4_96
LBB4_96:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_valid
_ownership_valid:                       ; @ownership_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB5_3
	b	LBB5_2
LBB5_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_3:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #56
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_9
	b	LBB5_4
LBB5_4:
	ldur	w8, [x29, #-60]
	subs	w8, w8, #1
	b.ne	LBB5_9
	b	LBB5_5
LBB5_5:
	sub	x0, x29, #56
	sub	x1, x29, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_9
	b	LBB5_6
LBB5_6:
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB5_9
	b	LBB5_7
LBB5_7:
	ldur	w8, [x29, #-64]
	mov	x1, x8
	sub	x0, x29, #56
	sub	x2, x29, #72
	bl	_nvm_v2_take
	cbnz	w0, LBB5_9
	b	LBB5_8
LBB5_8:
	sub	x0, x29, #56
	bl	_nvm_v2_align4
	cbz	w0, LBB5_10
	b	LBB5_9
LBB5_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_10:
	stur	wzr, [x29, #-76]
	b	LBB5_11
LBB5_11:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-76]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.hs	LBB5_16
	b	LBB5_12
LBB5_12:                                ;   in Loop: Header=BB5_11 Depth=1
	ldur	x8, [x29, #-72]
	ldur	w9, [x29, #-76]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-76]
	bl	_catalog_at
	bl	_type_flags
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.eq	LBB5_14
	b	LBB5_13
LBB5_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_14:                                ;   in Loop: Header=BB5_11 Depth=1
	b	LBB5_15
LBB5_15:                                ;   in Loop: Header=BB5_11 Depth=1
	ldur	w8, [x29, #-76]
	add	w8, w8, #1
	stur	w8, [x29, #-76]
	b	LBB5_11
LBB5_16:
	sub	x0, x29, #56
	sub	x1, x29, #64
	bl	_nvm_v2_u32
	cbnz	w0, LBB5_21
	b	LBB5_17
LBB5_17:
	ldur	w8, [x29, #-64]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB5_21
	b	LBB5_18
LBB5_18:
	ldur	w8, [x29, #-64]
	cbz	w8, LBB5_20
	b	LBB5_19
LBB5_19:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB5_21
	b	LBB5_20
LBB5_20:
	ldur	w8, [x29, #-64]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-40]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB5_22
	b	LBB5_21
LBB5_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_22:
	stur	wzr, [x29, #-80]
	b	LBB5_23
LBB5_23:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_44 Depth 2
	ldur	w8, [x29, #-80]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.hs	LBB5_54
	b	LBB5_24
LBB5_24:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #80]
	sub	x0, x29, #56
	sub	x1, x29, #82
	bl	_nvm_v2_u16
	cbnz	w0, LBB5_31
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_23 Depth=1
	sub	x0, x29, #56
	sub	x1, x29, #84
	bl	_nvm_v2_u16
	cbnz	w0, LBB5_31
	b	LBB5_26
LBB5_26:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-82]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB5_31
	b	LBB5_27
LBB5_27:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-84]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB5_31
	b	LBB5_28
LBB5_28:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-84]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	b.gt	LBB5_31
	b	LBB5_29
LBB5_29:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB5_31
	b	LBB5_30
LBB5_30:                                ;   in Loop: Header=BB5_23 Depth=1
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-40]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB5_32
	b	LBB5_31
LBB5_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_32:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-24]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB5_34
	b	LBB5_33
LBB5_33:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #80]
	ldrb	w8, [x8, #20]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB5_35
LBB5_34:                                ;   in Loop: Header=BB5_23 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB5_35
LBB5_35:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w3, [sp, #36]                   ; 4-byte Folded Reload
	sub	x0, x29, #56
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_descriptor_read
	tbnz	w0, #0, LBB5_37
	b	LBB5_36
LBB5_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_37:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB5_39
	b	LBB5_38
LBB5_38:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-80]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB5_40
LBB5_39:                                ;   in Loop: Header=BB5_23 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB5_40
LBB5_40:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #72]
	ldurh	w8, [x29, #-84]
	cbz	w8, LBB5_43
	b	LBB5_41
LBB5_41:                                ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [sp, #72]
	cbnz	x8, LBB5_43
	b	LBB5_42
LBB5_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_43:                                ;   in Loop: Header=BB5_23 Depth=1
	str	wzr, [sp, #68]
	b	LBB5_44
LBB5_44:                                ;   Parent Loop BB5_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	b.hs	LBB5_52
	b	LBB5_45
LBB5_45:                                ;   in Loop: Header=BB5_44 Depth=2
	ldur	x8, [x29, #-24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-84]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #68]
	ldurh	w9, [x29, #-84]
	subs	w8, w8, w9
	b.hs	LBB5_47
	b	LBB5_46
LBB5_46:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB5_48
LBB5_47:                                ;   in Loop: Header=BB5_44 Depth=2
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB5_48
LBB5_48:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	w2, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w3, [sp, #4]                    ; 4-byte Folded Reload
	sub	x0, x29, #56
	bl	_descriptor_read
	tbnz	w0, #0, LBB5_50
	b	LBB5_49
LBB5_49:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_50:                                ;   in Loop: Header=BB5_44 Depth=2
	b	LBB5_51
LBB5_51:                                ;   in Loop: Header=BB5_44 Depth=2
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB5_44
LBB5_52:                                ;   in Loop: Header=BB5_23 Depth=1
	b	LBB5_53
LBB5_53:                                ;   in Loop: Header=BB5_23 Depth=1
	ldur	w8, [x29, #-80]
	add	w8, w8, #1
	stur	w8, [x29, #-80]
	b	LBB5_23
LBB5_54:
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-48]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_55
LBB5_55:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_plan_free    ; -- Begin function nvm_multi_nominal_plan_free
	.p2align	2
_nvm_multi_nominal_plan_free:           ; @nvm_multi_nominal_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_layout_count ; -- Begin function nvm_multi_nominal_layout_count
	.p2align	2
_nvm_multi_nominal_layout_count:        ; @nvm_multi_nominal_layout_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #3844]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB7_3
LBB7_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB7_3
LBB7_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_layout       ; -- Begin function nvm_multi_nominal_layout
	.p2align	2
_nvm_multi_nominal_layout:              ; @nvm_multi_nominal_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp]
	cbz	x8, LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #3844]
	subs	w8, w8, w9
	b.lo	LBB8_4
	b	LBB8_3
LBB8_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB8_5
LBB8_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	add	x11, x8, #3848
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB8_5
LBB8_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_type         ; -- Begin function nvm_multi_nominal_type
	.p2align	2
_nvm_multi_nominal_type:                ; @nvm_multi_nominal_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	w2, [sp, #16]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB9_4
	b	LBB9_1
LBB9_1:
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB9_4
	b	LBB9_2
LBB9_2:
	ldr	w8, [sp, #16]
	str	w8, [sp]                        ; 4-byte Folded Spill
	ldur	x8, [x29, #-8]
	add	x10, x8, #4
	ldur	w8, [x29, #-12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_type_count
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB9_4
	b	LBB9_3
LBB9_3:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	add	x10, x8, #4
	ldur	w8, [x29, #-12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #24
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	ldr	x2, [sp, #8]
	bl	_nvm_multi_nominal_layout
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB9_4
LBB9_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_count
_type_count:                            ; @type_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	w0, [x8]
	bl	_nvm_multi_nominal_catalog_types
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_import       ; -- Begin function nvm_multi_nominal_import
	.p2align	2
_nvm_multi_nominal_import:              ; @nvm_multi_nominal_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	w2, [sp, #24]
	str	x3, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB11_4
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB11_4
	b	LBB11_2
LBB11_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB11_4
	b	LBB11_3
LBB11_3:
	ldr	w8, [sp, #24]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	add	x8, x8, #4
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #60                        ; =0x3c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w0, [x8, x9]
	bl	_nvm_multi_nominal_catalog_methods
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.lo	LBB11_5
	b	LBB11_4
LBB11_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_6
LBB11_5:
	ldur	x8, [x29, #-16]
	add	x10, x8, #4
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #4
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_6
LBB11_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_instance_count ; -- Begin function nvm_multi_nominal_instance_count
	.p2align	2
_nvm_multi_nominal_instance_count:      ; @nvm_multi_nominal_instance_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB12_3
LBB12_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB12_3
LBB12_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function text
_text:                                  ; @text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB13_4
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	cbz	x8, LBB13_4
	b	LBB13_2
LBB13_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	cbz	x8, LBB13_4
	b	LBB13_3
LBB13_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB13_5
	b	LBB13_4
LBB13_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_8
LBB13_5:
	ldr	x0, [sp, #16]
	bl	_strlen
	str	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x9, x8
	ldr	x10, [sp, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB13_7
	b	LBB13_6
LBB13_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	bl	_memcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB13_7
LBB13_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_8
LBB13_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function member_type
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	str	x3, [sp, #40]
	str	x4, [sp, #32]
	ldr	x9, [sp, #32]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	ldr	x8, [sp, #40]
	strb	wzr, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_2:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB14_4
	b	LBB14_3
LBB14_3:
	ldr	x9, [sp, #40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_4:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB14_6
	b	LBB14_5
LBB14_5:
	ldr	x9, [sp, #40]
	mov	w8, #4                          ; =0x4
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_6:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB14_8
	b	LBB14_7
LBB14_7:
	ldr	x9, [sp, #40]
	mov	w8, #5                          ; =0x5
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_8:
	str	wzr, [sp, #28]
	b	LBB14_9
LBB14_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-16]
	add	x10, x8, #4
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_type_count
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.hs	LBB14_16
	b	LBB14_10
LBB14_10:                               ;   in Loop: Header=BB14_9 Depth=1
	ldur	x0, [x29, #-16]
	ldur	w8, [x29, #-20]
	mov	w9, #9                          ; =0x9
	mul	w8, w8, w9
	ldr	w9, [sp, #28]
	add	w1, w8, w9
	bl	_type_at
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB14_12
	b	LBB14_11
LBB14_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_12:                               ;   in Loop: Header=BB14_9 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #16]
	ldr	x1, [x8]
	bl	_strcmp
	cbnz	w0, LBB14_14
	b	LBB14_13
LBB14_13:
	ldur	x0, [x29, #-16]
	ldur	w8, [x29, #-20]
	mov	w9, #9                          ; =0x9
	mul	w8, w8, w9
	ldr	w9, [sp, #28]
	add	w1, w8, w9
	bl	_type_tag
	ldr	x8, [sp, #40]
	strb	w0, [x8]
	ldur	x8, [x29, #-16]
	add	x10, x8, #4
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #24
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #32]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_14:                               ;   in Loop: Header=BB14_9 Depth=1
	b	LBB14_15
LBB14_15:                               ;   in Loop: Header=BB14_9 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB14_9
LBB14_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB14_17
LBB14_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_at
_type_at:                               ; @type_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldur	w8, [x29, #-12]
	mov	w10, #9                         ; =0x9
	udiv	w8, w8, w10
	add	x10, x9, #4
	mov	w9, #60                         ; =0x3c
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB15_2
	b	LBB15_1
LBB15_1:
	ldur	w8, [x29, #-12]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	mov	w8, w8
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB15_6
LBB15_2:
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB15_4
	b	LBB15_3
LBB15_3:
	ldur	w8, [x29, #-12]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	mov	w8, w8
	mov	x0, x8
	bl	_nl_socket_catalog_type
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB15_5
LBB15_4:
	ldur	w8, [x29, #-12]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	mov	w8, w8
	mov	x0, x8
	bl	_nl_websocket_catalog_type
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB15_5
LBB15_5:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB15_6
LBB15_6:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_tag
_type_tag:                              ; @type_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_type_kind
	mov	w9, #10                         ; =0xa
	mov	w8, #8                          ; =0x8
	subs	w10, w0, #0
	csel	w0, w8, w9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_kind
_type_kind:                             ; @type_kind
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_type_at
	ldr	w10, [x0, #16]
	mov	w8, #2                          ; =0x2
	mov	w9, #0                          ; =0x0
	subs	w10, w10, #2
	csel	w0, w8, w9, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function name_index
_name_index:                            ; @name_index
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	w9, [sp, #4]
	mov	w8, #1                          ; =0x1
	adds	w9, w9, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB18_2
	b	LBB18_1
LBB18_1:
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB18_2
LBB18_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_at
_catalog_at:                            ; @catalog_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	wzr, [sp, #8]
	b	LBB19_1
LBB19_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB19_3 Depth 2
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB19_10
	b	LBB19_2
LBB19_2:                                ;   in Loop: Header=BB19_1 Depth=1
	str	wzr, [sp, #4]
	b	LBB19_3
LBB19_3:                                ;   Parent Loop BB19_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #4]
	str	w8, [sp]                        ; 4-byte Folded Spill
	ldr	x8, [sp, #16]
	add	x10, x8, #4
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_type_count
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.hs	LBB19_8
	b	LBB19_4
LBB19_4:                                ;   in Loop: Header=BB19_3 Depth=2
	ldr	x8, [sp, #16]
	add	x10, x8, #4
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #24
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.ne	LBB19_6
	b	LBB19_5
LBB19_5:
	ldr	w8, [sp, #8]
	mov	w9, #9                          ; =0x9
	mul	w8, w8, w9
	ldr	w9, [sp, #4]
	add	w8, w8, w9
	stur	w8, [x29, #-4]
	b	LBB19_11
LBB19_6:                                ;   in Loop: Header=BB19_3 Depth=2
	b	LBB19_7
LBB19_7:                                ;   in Loop: Header=BB19_3 Depth=2
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB19_3
LBB19_8:                                ;   in Loop: Header=BB19_1 Depth=1
	b	LBB19_9
LBB19_9:                                ;   in Loop: Header=BB19_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB19_1
LBB19_10:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB19_11
LBB19_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function type_flags
_type_flags:                            ; @type_flags
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	adds	w8, w8, #1
	b.ne	LBB20_2
	b	LBB20_1
LBB20_1:
	strb	wzr, [sp, #15]
	b	LBB20_5
LBB20_2:
	ldr	w8, [sp, #8]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB20_4
	b	LBB20_3
LBB20_3:
	ldr	w8, [sp, #8]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB20_4
LBB20_4:
	ldr	w11, [sp, #4]                   ; 4-byte Folded Reload
	mov	w9, #2                          ; =0x2
	mov	w10, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w9, w9, w10, ne
	orr	w8, w8, w9
	strb	w8, [sp, #15]
	b	LBB20_5
LBB20_5:
	ldrb	w0, [sp, #15]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function descriptor_read
_descriptor_read:                       ; @descriptor_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturb	w2, [x29, #-25]
	str	w3, [sp, #32]
	ldur	x0, [x29, #-16]
	add	x1, sp, #31
	bl	_nvm_v2_u8
	cbnz	w0, LBB21_11
	b	LBB21_1
LBB21_1:
	ldur	x0, [x29, #-16]
	add	x1, sp, #30
	bl	_nvm_v2_u8
	cbnz	w0, LBB21_11
	b	LBB21_2
LBB21_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB21_11
	b	LBB21_3
LBB21_3:
	ldur	x0, [x29, #-16]
	add	x1, sp, #24
	bl	_nvm_v2_u32
	cbnz	w0, LBB21_11
	b	LBB21_4
LBB21_4:
	ldrh	w8, [sp, #28]
	cbnz	w8, LBB21_11
	b	LBB21_5
LBB21_5:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #16
	b.ge	LBB21_11
	b	LBB21_6
LBB21_6:
	ldrb	w8, [sp, #30]
	subs	w8, w8, #2
	b.gt	LBB21_11
	b	LBB21_7
LBB21_7:
	ldurb	w8, [x29, #-25]
	tbnz	w8, #0, LBB21_9
	b	LBB21_8
LBB21_8:
	ldrb	w8, [sp, #30]
	cbnz	w8, LBB21_11
	b	LBB21_9
LBB21_9:
	ldr	w8, [sp, #32]
	tbnz	w8, #31, LBB21_12
	b	LBB21_10
LBB21_10:
	ldrb	w8, [sp, #31]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	b.eq	LBB21_12
	b	LBB21_11
LBB21_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_24
LBB21_12:
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.ne	LBB21_14
	b	LBB21_13
LBB21_13:
	mov	w0, #-1                         ; =0xffffffff
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB21_15
LBB21_14:
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #24]
	bl	_catalog_at
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB21_15
LBB21_15:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #20]
	ldr	w8, [sp, #24]
	adds	w8, w8, #1
	b.eq	LBB21_19
	b	LBB21_16
LBB21_16:
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.eq	LBB21_18
	b	LBB21_17
LBB21_17:
	ldrb	w8, [sp, #31]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #20]
	bl	_type_tag
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.eq	LBB21_19
	b	LBB21_18
LBB21_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_24
LBB21_19:
	ldrb	w8, [sp, #30]
	cbz	w8, LBB21_23
	b	LBB21_20
LBB21_20:
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.eq	LBB21_22
	b	LBB21_21
LBB21_21:
	ldr	w8, [sp, #20]
	mov	w10, #9                         ; =0x9
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbz	w8, LBB21_23
	b	LBB21_22
LBB21_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_24
LBB21_23:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB21_24
LBB21_24:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

.subsections_via_symbols
