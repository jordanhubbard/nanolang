	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_file_execute_cyclic_bytes
lCPI0_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_file_execute_cyclic_bytes
	.p2align	2
_nvm_file_execute_cyclic_bytes:         ; @nvm_file_execute_cyclic_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1248
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x19, x8
Lloh0:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	bl	_nvm_file_host_enter
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w0, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w0, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w0, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w8, #4                          ; =0x4
	b	LBB0_10
LBB0_5:
	cbz	w0, LBB0_16
; %bb.6:
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB0_10
LBB0_7:
	mov	w8, #2                          ; =0x2
	b	LBB0_10
LBB0_8:
	mov	x9, #0                          ; =0x0
	str	xzr, [x19, #128]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	mov	w10, #1                         ; =0x1
	mov	w8, #11                         ; =0xb
	str	w10, [x19]
	b	LBB0_13
LBB0_9:
	mov	w8, #5                          ; =0x5
LBB0_10:
	mov	x9, #0                          ; =0x0
	str	xzr, [x19, #128]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	mov	w10, #1                         ; =0x1
	str	w10, [x19]
	cbz	x21, LBB0_13
; %bb.11:
	cmp	w0, #5
	b.eq	LBB0_13
; %bb.12:
	ldr	x9, [x21, #8]
LBB0_13:
	str	x9, [x19, #112]
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	str	wzr, [x19, #108]
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
LBB0_14:
	ldur	x8, [x29, #-104]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_331
; %bb.15:
	add	sp, sp, #1248
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_16:
	cbz	x21, LBB0_22
; %bb.17:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB0_24
; %bb.18:
	ldr	x8, [x21, #8]
	cbz	x20, LBB0_23
; %bb.19:
	mov	w9, #16961                      ; =0x4241
	movk	w9, #15, lsl #16
	cmp	x8, x9
	b.hs	LBB0_23
; %bb.20:
	add	x24, sp, #336
	ldr	q0, [x21]
	str	q0, [sp, #112]
	str	xzr, [sp, #96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	str	q0, [sp, #16]
	str	xzr, [sp, #240]
	add	x3, sp, #112
	add	x4, sp, #240
	mov	x0, x23
	mov	x1, x22
	mov	w2, #0                          ; =0x0
	bl	_nvm_file_runtime_cyclic_create
	cbz	w0, LBB0_27
; %bb.21:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #336]
	stp	q0, q0, [sp, #432]
	stp	q0, q0, [sp, #400]
	stp	q0, q0, [sp, #368]
	ldr	x8, [sp, #120]
	str	xzr, [sp, #464]
	str	x8, [sp, #448]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #336]
	str	w0, [sp, #344]
	b	LBB0_116
LBB0_22:
	mov	x8, #0                          ; =0x0
LBB0_23:
	stp	xzr, xzr, [sp, #336]
	b	LBB0_25
LBB0_24:
	stp	xzr, xzr, [sp, #336]
	ldr	x8, [x21, #8]
LBB0_25:
Lloh6:
	adrp	x9, lCPI0_0@PAGE
Lloh7:
	ldr	d0, [x9, lCPI0_0@PAGEOFF]
	str	d0, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #28]
	stur	q0, [x19, #44]
	stur	q0, [x19, #60]
	stur	q0, [x19, #76]
	stur	q0, [x19, #92]
	str	wzr, [x19, #108]
	str	x8, [x19, #112]
	ldr	q0, [sp, #336]
	stur	q0, [x19, #120]
LBB0_26:
	bl	_nvm_file_host_leave
	b	LBB0_14
LBB0_27:
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_cyclic_plan
	mov	x21, x0
	add	x1, sp, #136
	bl	_nvm_file_cyclic_hosted_startup
	cbz	w0, LBB0_115
; %bb.28:
	ldrb	w8, [sp, #224]
	tbnz	w8, #0, LBB0_115
; %bb.29:
	ldr	w8, [sp, #148]
	cbz	w8, LBB0_110
; %bb.30:
	mov	w22, #0                         ; =0x0
	mov	w26, #415                       ; =0x19f
	mov	w27, #151                       ; =0x97
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_43 Depth 3
	add	x2, sp, #944
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB0_115
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrb	w8, [sp, #1024]
	cbnz	w8, LBB0_115
; %bb.33:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrh	w8, [sp, #952]
	cbz	w8, LBB0_109
; %bb.34:                               ;   in Loop: Header=BB0_31 Depth=1
	mov	w28, #0                         ; =0x0
LBB0_35:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_43 Depth 3
	and	w2, w28, #0xffff
	add	x3, sp, #336
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_instruction
	cbz	w0, LBB0_115
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w0, [sp, #344]
	bl	_fcd_supported
	ldrb	w8, [sp, #412]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_115
; %bb.37:                               ;   in Loop: Header=BB0_35 Depth=2
	and	w2, w28, #0xffff
	sub	x3, x29, #112
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_115
; %bb.38:                               ;   in Loop: Header=BB0_35 Depth=2
	ldurb	w8, [x29, #-112]
	cmp	w8, #16
	b.hi	LBB0_115
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=2
	tst	w28, #0xffff
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_115
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_108
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=2
	mov	w25, #0                         ; =0x0
LBB0_43:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w2, w28, #0xffff
	and	w3, w25, #0xff
	add	x4, sp, #1040
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_variant
	cbz	w0, LBB0_115
; %bb.44:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1060]
	tbz	w8, #0, LBB0_115
; %bb.45:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w23, [sp, #344]
	mov	x0, x23
	bl	_fcd_supported
	cbz	w0, LBB0_115
; %bb.46:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w23, #147
	b.gt	LBB0_50
; %bb.47:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #60
	b.gt	LBB0_54
; %bb.48:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #15
	b.eq	LBB0_60
; %bb.49:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #59
	b.eq	LBB0_60
	b	LBB0_63
LBB0_50:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #150
	b.gt	LBB0_57
; %bb.51:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #148
	b.eq	LBB0_61
; %bb.52:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #149
	b.ne	LBB0_63
; %bb.53:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_63
LBB0_54:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #61
	b.eq	LBB0_62
; %bb.55:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	b.ne	LBB0_63
; %bb.56:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_63
LBB0_57:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #151
	b.eq	LBB0_60
; %bb.58:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #161
	b.ne	LBB0_63
; %bb.59:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_63
LBB0_60:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #5                          ; =0x5
	b	LBB0_63
LBB0_61:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_63
LBB0_62:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #4                          ; =0x4
LBB0_63:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #1072]
	cmp	w9, w8
	b.ne	LBB0_115
; %bb.64:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1062]
	cmp	w23, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.65:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1061]
	cmp	w23, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.66:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #59
	b.ne	LBB0_68
; %bb.67:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_69
LBB0_68:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #15
	ccmp	w23, w27, #4, ne
	cset	w8, eq
LBB0_69:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	ldrb	w9, [sp, #1063]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_115
; %bb.70:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w8, LBB0_81
; %bb.71:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1088]
	ldr	w9, [sp, #336]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.72:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1092]
	ldr	w9, [sp, #352]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.73:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	cset	w8, ne
	ldr	w9, [sp, #1084]
	cmp	w9, w8
	b.ne	LBB0_115
; %bb.74:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w23, #145
	b.ne	LBB0_82
; %bb.75:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w23, [sp, #928]
	add	x2, sp, #248
	mov	x0, x21
	mov	x1, x23
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB0_115
; %bb.76:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #248]
	ldr	w9, [sp, #1092]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.77:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	x0, x23
	bl	_nl_file_catalog_method
	cbz	x0, LBB0_115
; %bb.78:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1100]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.79:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #1104]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.80:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	subs	w9, w23, #1
	cmp	w9, #3
	mov	w9, #399                        ; =0x18f
	csel	w9, w26, w9, lo
	orr	w10, w9, #0x20
	cmp	w23, #1
	csel	w9, w10, w9, eq
	b	LBB0_83
LBB0_81:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #128                        ; =0x80
	b	LBB0_84
LBB0_82:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
LBB0_83:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1096]
	cmp	w10, w9
	b.ne	LBB0_115
LBB0_84:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1076]
	cmp	w10, w8
	b.ne	LBB0_115
; %bb.85:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #1080]
	bic	w8, w9, w8
	cmp	w10, w8
	b.ne	LBB0_115
; %bb.86:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #1064]
	ldrh	w9, [sp, #1042]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.87:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #1066]
	ldrh	w9, [sp, #1052]
	cmp	w8, w9
	b.ne	LBB0_115
; %bb.88:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1140]
	ldrb	w9, [sp, #412]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_115
; %bb.89:                               ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #0, LBB0_91
; %bb.90:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w9, [sp, #1141]
	cmp	w9, #255
	b.eq	LBB0_96
	b	LBB0_115
LBB0_91:                                ;   in Loop: Header=BB0_43 Depth=3
	cbz	w9, LBB0_115
; %bb.92:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #408]
	ldrh	w8, [sp, #952]
	cmp	w2, w8
	b.hs	LBB0_115
; %bb.93:                               ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #248
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_115
; %bb.94:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1141]
	ldrb	w9, [sp, #248]
	cmp	w8, w9
	b.hs	LBB0_115
; %bb.95:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1140]
LBB0_96:                                ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #1, LBB0_98
; %bb.97:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1142]
	cmp	w8, #255
	b.eq	LBB0_102
	b	LBB0_115
LBB0_98:                                ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #412]
	cmp	w8, #2
	b.lo	LBB0_115
; %bb.99:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #410]
	ldrh	w8, [sp, #952]
	cmp	w2, w8
	b.hs	LBB0_115
; %bb.100:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #248
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_115
; %bb.101:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #1142]
	ldrb	w9, [sp, #248]
	cmp	w8, w9
	b.hs	LBB0_115
LBB0_102:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #344]
	cmp	w8, #15
	b.eq	LBB0_105
; %bb.103:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #151
	b.eq	LBB0_105
; %bb.104:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #59
	b.ne	LBB0_107
LBB0_105:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #352]
	add	x2, sp, #248
	mov	x0, x21
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB0_115
; %bb.106:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #328]
	cbnz	w8, LBB0_115
LBB0_107:                               ;   in Loop: Header=BB0_43 Depth=3
	add	w25, w25, #1
	ldurb	w8, [x29, #-112]
	cmp	w8, w25, uxtb
	b.hi	LBB0_43
LBB0_108:                               ;   in Loop: Header=BB0_35 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #952]
	cmp	w8, w28, uxth
	b.hi	LBB0_35
LBB0_109:                               ;   in Loop: Header=BB0_31 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #148]
	cmp	w22, w8
	b.lo	LBB0_31
LBB0_110:
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_begin
	cbnz	w0, LBB0_112
; %bb.111:
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_frame_start
	cbz	w0, LBB0_135
LBB0_112:
	mov	x1, x0
LBB0_113:
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_fail
LBB0_114:
	add	x8, sp, #336
	add	x0, sp, #240
	add	x1, sp, #16
	bl	_nvm_file_runtime_cyclic_destroy
	b	LBB0_117
LBB0_115:
	add	x8, sp, #336
	add	x0, sp, #240
	mov	x1, #0                          ; =0x0
	bl	_nvm_file_runtime_cyclic_destroy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #336]
	stp	q0, q0, [sp, #368]
	stp	q0, q0, [sp, #400]
	stp	q0, q0, [sp, #432]
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #120]
	str	xzr, [sp, #464]
	str	x9, [sp, #448]
	mov	w9, #2                          ; =0x2
	str	w8, [sp, #336]
	str	w9, [sp, #344]
LBB0_116:
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x24, #20]
LBB0_117:
	ldp	q0, q1, [sp, #432]
	stp	q0, q1, [x19, #96]
	ldr	x8, [sp, #464]
	str	x8, [x19, #128]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [sp, #400]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [sp, #336]
	stp	q1, q0, [x19]
	ldr	w8, [x19, #8]
	cbnz	w8, LBB0_134
; %bb.118:
	ldrb	w8, [x19, #12]
	tbz	w8, #0, LBB0_133
; %bb.119:
	ldr	w9, [x19, #16]
	mov	w8, #10                         ; =0xa
	cbnz	w9, LBB0_134
; %bb.120:
	ldr	w9, [x19, #32]
	cbnz	w9, LBB0_134
; %bb.121:
	ldr	x9, [x19, #40]
	cbnz	x9, LBB0_134
; %bb.122:
	ldrb	w9, [sp, #16]
	mov	w8, #6                          ; =0x6
	tbz	w9, #0, LBB0_134
; %bb.123:
	ldrb	w9, [sp, #17]
	tbnz	w9, #0, LBB0_134
; %bb.124:
	ldrb	w9, [sp, #18]
	tbnz	w9, #0, LBB0_134
; %bb.125:
	ldrb	w9, [sp, #21]
	cbnz	w9, LBB0_134
; %bb.126:
	ldr	w9, [sp, #32]
	cbnz	w9, LBB0_134
; %bb.127:
	ldr	w9, [sp, #24]
	cmn	w9, #1
	b.ne	LBB0_134
; %bb.128:
	ldr	w9, [sp, #28]
	cmn	w9, #1
	b.ne	LBB0_134
; %bb.129:
	ldrb	w9, [sp, #40]
	cmp	w9, #1
	b.ne	LBB0_134
; %bb.130:
	ldrb	w9, [sp, #20]
	cmp	w9, #4
	b.eq	LBB0_328
; %bb.131:
	cmp	w9, #1
	b.ne	LBB0_134
; %bb.132:
	ldr	x10, [sp, #48]
	b	LBB0_329
LBB0_133:
	mov	w8, #5                          ; =0x5
LBB0_134:
	ldurh	w9, [x19, #13]
	strh	w9, [sp, #136]
	ldurb	w9, [x19, #15]
	strb	w9, [sp, #138]
	ldur	x9, [x19, #20]
	str	x9, [sp, #1040]
	ldur	w9, [x19, #28]
	str	w9, [sp, #1048]
	ldp	q0, q1, [x19, #48]
	stp	q0, q1, [sp, #336]
	ldp	q0, q1, [x19, #80]
	stp	q0, q1, [sp, #368]
	str	w8, [x19, #8]
	ldrb	w8, [sp, #138]
	sturb	w8, [x19, #15]
	mov	w8, w9
	stur	w8, [x19, #28]
	ldr	x8, [sp, #1040]
	stur	x8, [x19, #20]
	ldp	q1, q0, [sp, #368]
	stp	q1, q0, [x19, #80]
	ldp	q1, q0, [sp, #336]
	stp	q1, q0, [x19, #48]
	b	LBB0_26
LBB0_135:
	mov	w27, #-1                        ; =0xffffffff
	mov	w24, #4                         ; =0x4
Lloh8:
	adrp	x26, lJTI0_0@PAGE
Lloh9:
	add	x26, x26, lJTI0_0@PAGEOFF
	b	LBB0_137
LBB0_136:                               ;   in Loop: Header=BB0_137 Depth=1
	cbnz	w1, LBB0_113
LBB0_137:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #240]
	add	x1, sp, #248
	bl	_nvm_file_runtime_cyclic_frame_view
	cbz	w0, LBB0_330
; %bb.138:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #301]
	tbnz	w8, #0, LBB0_330
; %bb.139:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #252]
	cbnz	w8, LBB0_330
; %bb.140:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #256]
	ldrh	w2, [sp, #260]
	add	x3, sp, #336
	mov	x0, x21
	bl	_nvm_file_cyclic_hosted_instruction
	cbz	w0, LBB0_330
; %bb.141:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #256]
	ldrh	w2, [sp, #260]
	ldrb	w3, [sp, #300]
	add	x4, sp, #136
	mov	x0, x21
	bl	_nvm_file_cyclic_hosted_variant
	cbz	w0, LBB0_330
; %bb.142:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #156]
	tbz	w8, #0, LBB0_330
; %bb.143:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w8, [sp, #138]
	ldr	w9, [sp, #288]
	cmp	w9, w8
	b.ne	LBB0_330
; %bb.144:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_cyclic_enter
	mov	x1, x0
	cbnz	w0, LBB0_113
; %bb.145:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x22, [sp, #240]
	ldr	w28, [sp, #288]
	ldrb	w23, [sp, #344]
	str	w27, [sp, #1036]
	str	w27, [sp, #1032]
	mov	w8, #2                          ; =0x2
	cmp	w23, #255
	b.eq	LBB0_157
; %bb.146:                              ;   in Loop: Header=BB0_137 Depth=1
	adr	x9, LBB0_147
	ldrh	w10, [x26, x23, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB0_147:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	w28, LBB0_290
; %bb.148:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	tbz	w0, #0, LBB0_290
; %bb.149:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #252
	b.eq	LBB0_151
; %bb.150:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #106
	b.ne	LBB0_244
LBB0_151:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	ldrh	w2, [sp, #352]
	mov	x0, x22
	mov	x3, x1
	bl	_nvm_file_runtime_project
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_152:                               ;   in Loop: Header=BB0_137 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_290
; %bb.153:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #3
	csel	w8, w24, wzr, eq
	cmp	w23, #1
	csinc	w2, w8, wzr, ne
	b.ne	LBB0_242
; %bb.154:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x3, [sp, #352]
	b	LBB0_252
LBB0_155:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_call
	b	LBB0_292
LBB0_156:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w1, #1                          ; =0x1
	mov	w8, #1                          ; =0x1
LBB0_157:                               ;   in Loop: Header=BB0_137 Depth=1
	subs	w28, w28, w8
	b.lo	LBB0_290
; %bb.158:                              ;   in Loop: Header=BB0_137 Depth=1
	mov	x25, x1
	and	w1, w28, #0xffff
	sub	x2, x29, #112
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	tbz	w0, #0, LBB0_290
; %bb.159:                              ;   in Loop: Header=BB0_137 Depth=1
	ldur	w1, [x29, #-112]
	add	x2, sp, #1040
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_290
; %bb.160:                              ;   in Loop: Header=BB0_137 Depth=1
	tbz	w25, #0, LBB0_258
LBB0_161:                               ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w23, #0xfe
	cmp	w23, #50
	mov	w9, #48                         ; =0x30
	ccmp	w8, w9, #4, ne
	cset	w9, eq
	sub	w10, w23, #48
	cmp	w10, #3
	cset	w11, lo
	cmp	w8, #40
	ldrb	w10, [sp, #1044]
	and	w8, w10, #0xff
	ccmp	w8, #4, #0, eq
	csinc	w9, w9, wzr, ne
	csinc	w8, w11, wzr, ne
	cmp	w9, #0
	csinc	w9, w24, wzr, ne
	ldrb	w11, [sp, #1040]
	cmp	w11, #1
	b.ne	LBB0_214
; %bb.162:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w11, [sp, #1041]
	tbnz	w11, #0, LBB0_214
; %bb.163:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w11, [sp, #1042]
	tbnz	w11, #0, LBB0_214
; %bb.164:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w11, [sp, #1045]
	cbnz	w11, LBB0_214
; %bb.165:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w11, [sp, #1056]
	cbnz	w11, LBB0_214
; %bb.166:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w9, w10, uxtb
	b.ne	LBB0_214
; %bb.167:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w10, [sp, #1048]
	cmn	w10, #1
	b.ne	LBB0_214
; %bb.168:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w10, [sp, #1052]
	cmn	w10, #1
	b.ne	LBB0_214
; %bb.169:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1064]
	cmp	w10, #1
	b.ne	LBB0_214
; %bb.170:                              ;   in Loop: Header=BB0_137 Depth=1
	cbz	w8, LBB0_172
; %bb.171:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x10, [sp, #1072]
	cmp	x10, #2
	b.hs	LBB0_214
LBB0_172:                               ;   in Loop: Header=BB0_137 Depth=1
	tbz	w25, #0, LBB0_274
LBB0_173:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	x10, [sp, #1160]
	cmp	w25, #0
	csel	x9, xzr, x10, ne
	sub	w11, w23, #32
	cmp	w11, #181
	b.hi	LBB0_290
; %bb.174:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x8, [sp, #1072]
Lloh10:
	adrp	x14, lJTI0_1@PAGE
Lloh11:
	add	x14, x14, lJTI0_1@PAGEOFF
	adr	x12, LBB0_175
	ldrh	w13, [x14, x11, lsl #1]
	add	x12, x12, x13, lsl #2
	br	x12
LBB0_175:                               ;   in Loop: Header=BB0_137 Depth=1
	add	x28, x9, x8
	b	LBB0_314
LBB0_176:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	w28, LBB0_290
; %bb.177:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.178:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #944
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_290
; %bb.179:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #944]
	cmp	w8, #1
	b.ne	LBB0_214
; %bb.180:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #945]
	tbnz	w8, #0, LBB0_214
; %bb.181:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #946]
	tbnz	w8, #0, LBB0_214
; %bb.182:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #949]
	cbnz	w8, LBB0_214
; %bb.183:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #960]
	cbnz	w8, LBB0_214
; %bb.184:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #948]
	cmp	w8, #4
	b.ne	LBB0_214
; %bb.185:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #952]
	cmn	w8, #1
	b.ne	LBB0_214
; %bb.186:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #956]
	cmn	w8, #1
	b.ne	LBB0_214
; %bb.187:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #968]
	cmp	w8, #1
	b.ne	LBB0_214
; %bb.188:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x8, [sp, #976]
	cmp	x8, #2
	b.hs	LBB0_214
; %bb.189:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_112
; %bb.190:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x8, [sp, #976]
	cmp	w23, #161
	b.ne	LBB0_273
; %bb.191:                              ;   in Loop: Header=BB0_137 Depth=1
	cbz	x8, LBB0_298
; %bb.192:                              ;   in Loop: Header=BB0_137 Depth=1
	mov	w1, #0                          ; =0x0
	b	LBB0_257
LBB0_193:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w8, [sp, #368]
	ldrh	w9, [sp, #360]
	cmp	w23, #251
	csel	w23, w8, w9, eq
	ldrh	w9, [sp, #376]
	csel	w25, w9, w8, eq
	and	w8, w25, #0xffff
	cmp	w8, #7
	b.hi	LBB0_290
; %bb.194:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w28, w8
	b.lo	LBB0_290
; %bb.195:                              ;   in Loop: Header=BB0_137 Depth=1
	tst	w25, #0xffff
	b.eq	LBB0_254
; %bb.196:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w28, w28, w25
	and	w1, w28, #0xffff
	add	x2, sp, #1040
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.197:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #1
	b.ne	LBB0_262
LBB0_198:                               ;   in Loop: Header=BB0_137 Depth=1
	and	x4, x25, #0xffff
	ldr	w5, [sp, #1040]
	str	w5, [sp, #1032]
	b	LBB0_256
LBB0_199:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_borrow
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_200:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w1, [sp, #352]
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	cbz	w0, LBB0_290
; %bb.201:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	cbz	w0, LBB0_290
; %bb.202:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #944
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_290
; %bb.203:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #944]
	cmp	w8, #1
	b.ne	LBB0_214
; %bb.204:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #946]
	tbnz	w8, #0, LBB0_214
; %bb.205:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #945]
	cmp	w23, #11
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_214
; %bb.206:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	ldr	w2, [sp, #1032]
	mov	x0, x22
	cmp	w23, #16
	b.ne	LBB0_289
; %bb.207:                              ;   in Loop: Header=BB0_137 Depth=1
	bl	_nvm_file_runtime_copy
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_208:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	w28, LBB0_290
; %bb.209:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.210:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #944
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbz	w0, #0, LBB0_290
; %bb.211:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #8
	b.ne	LBB0_217
; %bb.212:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #945]
	tbnz	w8, #0, LBB0_214
; %bb.213:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #946]
	tbz	w8, #0, LBB0_217
LBB0_214:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	mov	w1, #6                          ; =0x6
	b	LBB0_291
LBB0_215:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_store
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_216:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w1, [sp, #352]
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	tbz	w0, #0, LBB0_290
LBB0_217:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_218:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w23, [sp, #928]
	stur	w27, [x29, #-112]
	mov	x0, x22
	bl	_nvm_file_runtime_cyclic_plan
	add	x2, sp, #1040
	mov	x1, x23
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB0_290
; %bb.219:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #1040]
	ldr	w9, [sp, #352]
	cmp	w8, w9
	b.ne	LBB0_290
; %bb.220:                              ;   in Loop: Header=BB0_137 Depth=1
	add	x1, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_scratch
	cbz	w0, LBB0_290
; %bb.221:                              ;   in Loop: Header=BB0_137 Depth=1
	subs	w25, w23, #1
	cset	w8, eq
	cmp	w23, #4
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB0_223
; %bb.222:                              ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #1
	b.ne	LBB0_225
LBB0_223:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	w28, LBB0_290
; %bb.224:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
LBB0_225:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	w25, #2
	b.hi	LBB0_285
; %bb.226:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w1, [sp, #360]
	sub	x2, x29, #112
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reference
	cbz	w0, LBB0_290
; %bb.227:                              ;   in Loop: Header=BB0_137 Depth=1
	ldur	w2, [x29, #-112]
	b	LBB0_286
LBB0_228:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	w28, LBB0_290
; %bb.229:                              ;   in Loop: Header=BB0_137 Depth=1
	sub	w8, w28, #1
	and	w1, w8, #0xffff
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.230:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_290
; %bb.231:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	ldr	w2, [sp, #1032]
	mov	x0, x22
	bl	_nvm_file_runtime_copy
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_232:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_end_reference
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_233:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_region_begin
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_234:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_region_end
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_235:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_return
	b	LBB0_292
LBB0_236:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w1, [sp, #352]
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	tbz	w0, #0, LBB0_290
; %bb.237:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #1040
	mov	x0, x22
	bl	_nvm_file_runtime_result_arm
	mov	x1, x0
	cbnz	w0, LBB0_293
; %bb.238:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #1040]
	cmp	w8, #3
	cset	w1, eq
	b	LBB0_257
LBB0_239:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w1, [sp, #352]
	add	x2, sp, #1036
	mov	x0, x22
	bl	_nvm_file_runtime_frame_local
	cbz	w0, LBB0_290
; %bb.240:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_290
; %bb.241:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	ldrb	w8, [sp, #360]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w2, w8, ne
	ldr	w3, [sp, #1032]
	mov	x0, x22
	bl	_nvm_file_runtime_take
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_242:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	w23, #3
	b.ne	LBB0_251
; %bb.243:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w3, [sp, #352]
	b	LBB0_252
LBB0_244:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #944
	mov	x0, x22
	bl	_nvm_file_runtime_view
	cbz	w0, LBB0_260
; %bb.245:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #945]
	mov	w1, #6                          ; =0x6
	tbnz	w8, #0, LBB0_261
; %bb.246:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #946]
	tbnz	w8, #0, LBB0_261
; %bb.247:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #960]
	cmp	w8, #3
	b.ne	LBB0_261
; %bb.248:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	add	x2, sp, #1040
	mov	x0, x22
	bl	_nvm_file_runtime_result_arm
	cbnz	w0, LBB0_292
; %bb.249:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_292
; %bb.250:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1036]
	ldr	w8, [sp, #1040]
	cmp	w8, #3
	cset	w3, eq
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	b	LBB0_253
LBB0_251:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x3, #0                          ; =0x0
LBB0_252:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1032]
	mov	x0, x22
LBB0_253:                               ;   in Loop: Header=BB0_137 Depth=1
	bl	_nvm_file_runtime_scalar
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_254:                               ;   in Loop: Header=BB0_137 Depth=1
	and	w1, w28, #0xffff
	add	x2, sp, #1032
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	cbz	w0, LBB0_290
; %bb.255:                              ;   in Loop: Header=BB0_137 Depth=1
	mov	x4, #0                          ; =0x0
	ldr	w5, [sp, #1032]
LBB0_256:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #928]
	and	w2, w23, #0xffff
	add	x3, sp, #1040
	mov	x0, x22
	bl	_nvm_file_runtime_construct
	mov	x1, x0
	cbnz	w0, LBB0_113
LBB0_257:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	bl	_nvm_file_runtime_frame_next
	b	LBB0_292
LBB0_258:                               ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #1
	and	w1, w8, #0xffff
	sub	x8, x29, #112
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.259:                              ;   in Loop: Header=BB0_137 Depth=1
	ldur	w1, [x29, #-108]
	add	x8, sp, #1040
	add	x2, x8, #88
	mov	x0, x22
	bl	_nvm_file_runtime_view
	tbnz	w0, #0, LBB0_161
	b	LBB0_290
LBB0_260:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w1, #5                          ; =0x5
LBB0_261:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	b	LBB0_291
LBB0_262:                               ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #1
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #4
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.263:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #2
	b.eq	LBB0_198
; %bb.264:                              ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #2
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #8
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.265:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #3
	b.eq	LBB0_198
; %bb.266:                              ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #3
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #12
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.267:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #4
	b.eq	LBB0_198
; %bb.268:                              ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #4
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #16
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.269:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #5
	b.eq	LBB0_198
; %bb.270:                              ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #5
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #20
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbz	w0, LBB0_290
; %bb.271:                              ;   in Loop: Header=BB0_137 Depth=1
	and	w8, w25, #0xffff
	cmp	w8, #6
	b.eq	LBB0_198
; %bb.272:                              ;   in Loop: Header=BB0_137 Depth=1
	add	w8, w28, #6
	and	w1, w8, #0xffff
	add	x8, sp, #1040
	add	x2, x8, #24
	mov	x0, x22
	bl	_nvm_file_runtime_frame_operand
	cbnz	w0, LBB0_198
	b	LBB0_290
LBB0_273:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, #0
	cset	w8, ne
	cmp	w23, #57
	cset	w9, ne
	eor	w1, w9, w8
	b	LBB0_257
LBB0_274:                               ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1128]
	cmp	w10, #1
	b.ne	LBB0_214
; %bb.275:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1129]
	tbnz	w10, #0, LBB0_214
; %bb.276:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1130]
	tbnz	w10, #0, LBB0_214
; %bb.277:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1133]
	cbnz	w10, LBB0_214
; %bb.278:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w10, [sp, #1144]
	cbnz	w10, LBB0_214
; %bb.279:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w10, [sp, #1132]
	cmp	w10, w9
	b.ne	LBB0_214
; %bb.280:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w9, [sp, #1136]
	cmn	w9, #1
	b.ne	LBB0_214
; %bb.281:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w9, [sp, #1140]
	cmn	w9, #1
	b.ne	LBB0_214
; %bb.282:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w9, [sp, #1152]
	cmp	w9, #1
	b.ne	LBB0_214
; %bb.283:                              ;   in Loop: Header=BB0_137 Depth=1
	cbz	w8, LBB0_173
; %bb.284:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x8, [sp, #1160]
	cmp	x8, #1
	b.hi	LBB0_214
	b	LBB0_173
LBB0_285:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w2, #-1                         ; =0xffffffff
LBB0_286:                               ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #352]
	ldr	w3, [sp, #1036]
	ldr	w4, [sp, #1032]
	mov	x0, x22
	bl	_nvm_file_runtime_service
	mov	x1, x0
	cbnz	w0, LBB0_293
; %bb.287:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	sub	w8, w28, w8
	and	w1, w8, #0xffff
	add	x2, sp, #940
	mov	x0, x22
	bl	_nvm_file_runtime_frame_reserve
	tbz	w0, #0, LBB0_290
; %bb.288:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	w1, [sp, #1032]
	ldr	w2, [sp, #940]
	mov	x0, x22
LBB0_289:                               ;   in Loop: Header=BB0_137 Depth=1
	bl	_nvm_file_runtime_move
	mov	x1, x0
	cbz	w0, LBB0_257
	b	LBB0_113
LBB0_290:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	mov	w1, #5                          ; =0x5
LBB0_291:                               ;   in Loop: Header=BB0_137 Depth=1
	bl	_nvm_file_runtime_fail
LBB0_292:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x1, x0
LBB0_293:                               ;   in Loop: Header=BB0_137 Depth=1
	cbnz	w1, LBB0_113
; %bb.294:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrb	w8, [sp, #344]
	cmp	w8, #61
	b.ne	LBB0_136
; %bb.295:                              ;   in Loop: Header=BB0_137 Depth=1
	ldrh	w8, [sp, #268]
	cmp	w8, #1
	b.ne	LBB0_136
; %bb.296:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x0, [sp, #240]
	add	x1, sp, #1040
	bl	_nvm_file_runtime_current_root
	tbz	w0, #0, LBB0_114
; %bb.297:                              ;   in Loop: Header=BB0_137 Depth=1
	ldr	x0, [sp, #240]
	bl	_nvm_file_runtime_frame_start
	mov	x1, x0
	b	LBB0_136
LBB0_298:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x0, x22
	mov	w1, #9                          ; =0x9
	b	LBB0_291
LBB0_299:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	cset	w28, ge
	b	LBB0_323
LBB0_300:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	x9, LBB0_313
; %bb.301:                              ;   in Loop: Header=BB0_137 Depth=1
	mov	x11, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x11
	b.ne	LBB0_303
; %bb.302:                              ;   in Loop: Header=BB0_137 Depth=1
	cmn	x9, #1
	b.eq	LBB0_313
LBB0_303:                               ;   in Loop: Header=BB0_137 Depth=1
	sdiv	x9, x8, x10
	msub	x28, x9, x10, x8
	b	LBB0_314
LBB0_304:                               ;   in Loop: Header=BB0_137 Depth=1
	neg	x28, x8
	b	LBB0_314
LBB0_305:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	cset	w28, le
	b	LBB0_323
LBB0_306:                               ;   in Loop: Header=BB0_137 Depth=1
	sub	x28, x8, x9
	b	LBB0_314
LBB0_307:                               ;   in Loop: Header=BB0_137 Depth=1
	mul	x28, x9, x8
	b	LBB0_314
LBB0_308:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	b	LBB0_320
LBB0_309:                               ;   in Loop: Header=BB0_137 Depth=1
	cbz	x9, LBB0_313
; %bb.310:                              ;   in Loop: Header=BB0_137 Depth=1
	mov	x28, #-9223372036854775808      ; =0x8000000000000000
	cmp	x8, x28
	b.ne	LBB0_312
; %bb.311:                              ;   in Loop: Header=BB0_137 Depth=1
	cmn	x9, #1
	b.eq	LBB0_314
LBB0_312:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w23, #1                         ; =0x1
	sdiv	x28, x8, x10
	b	LBB0_324
LBB0_313:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	x28, #0                         ; =0x0
LBB0_314:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w23, #1                         ; =0x1
	b	LBB0_324
LBB0_315:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	b	LBB0_322
LBB0_316:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	cset	w28, lt
	b	LBB0_323
LBB0_317:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, x9
	cset	w28, gt
	b	LBB0_323
LBB0_318:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, #0
	ccmp	x9, #0, #4, ne
	b	LBB0_322
LBB0_319:                               ;   in Loop: Header=BB0_137 Depth=1
	cmp	x8, #0
LBB0_320:                               ;   in Loop: Header=BB0_137 Depth=1
	cset	w28, eq
	b	LBB0_323
LBB0_321:                               ;   in Loop: Header=BB0_137 Depth=1
	orr	x8, x8, x9
	cmp	x8, #0
LBB0_322:                               ;   in Loop: Header=BB0_137 Depth=1
	cset	w28, ne
LBB0_323:                               ;   in Loop: Header=BB0_137 Depth=1
	mov	w23, #4                         ; =0x4
LBB0_324:                               ;   in Loop: Header=BB0_137 Depth=1
	ldur	w1, [x29, #-112]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_292
; %bb.325:                              ;   in Loop: Header=BB0_137 Depth=1
	tbnz	w25, #0, LBB0_327
; %bb.326:                              ;   in Loop: Header=BB0_137 Depth=1
	ldur	w1, [x29, #-108]
	mov	x0, x22
	bl	_nvm_file_runtime_drop
	cbnz	w0, LBB0_292
LBB0_327:                               ;   in Loop: Header=BB0_137 Depth=1
	ldur	w1, [x29, #-112]
	mov	x0, x22
	mov	x2, x23
	mov	x3, x28
	bl	_nvm_file_runtime_scalar
	mov	x1, x0
	cbnz	w0, LBB0_293
	b	LBB0_257
LBB0_328:
	ldr	x10, [sp, #48]
	cmp	x10, #1
	b.hi	LBB0_134
LBB0_329:
	mov	w8, #0                          ; =0x0
	strb	w9, [x20]
	stur	wzr, [x20, #1]
	str	wzr, [x20, #4]
	str	x10, [x20, #8]
	b	LBB0_134
LBB0_330:
	ldr	x0, [sp, #240]
	mov	w1, #5                          ; =0x5
	bl	_nvm_file_runtime_fail
	cbnz	w0, LBB0_112
	b	LBB0_114
LBB0_331:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_257-LBB0_147)>>2
	.short	(LBB0_152-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_152-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_152-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_228-LBB0_147)>>2
	.short	(LBB0_208-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_200-LBB0_147)>>2
	.short	(LBB0_215-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_155-LBB0_147)>>2
	.short	(LBB0_200-LBB0_147)>>2
	.short	(LBB0_215-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_233-LBB0_147)>>2
	.short	(LBB0_234-LBB0_147)>>2
	.short	(LBB0_199-LBB0_147)>>2
	.short	(LBB0_199-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_156-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_156-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_257-LBB0_147)>>2
	.short	(LBB0_176-LBB0_147)>>2
	.short	(LBB0_176-LBB0_147)>>2
	.short	(LBB0_155-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_235-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_193-LBB0_147)>>2
	.short	(LBB0_147-LBB0_147)>>2
	.short	(LBB0_147-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_218-LBB0_147)>>2
	.short	(LBB0_236-LBB0_147)>>2
	.short	(LBB0_239-LBB0_147)>>2
	.short	(LBB0_216-LBB0_147)>>2
	.short	(LBB0_208-LBB0_147)>>2
	.short	(LBB0_232-LBB0_147)>>2
	.short	(LBB0_155-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_176-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_156-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_193-LBB0_147)>>2
	.short	(LBB0_147-LBB0_147)>>2
	.short	(LBB0_157-LBB0_147)>>2
	.short	(LBB0_147-LBB0_147)>>2
	.p2align	1, 0x0
lJTI0_1:
	.short	(LBB0_175-LBB0_175)>>2
	.short	(LBB0_306-LBB0_175)>>2
	.short	(LBB0_307-LBB0_175)>>2
	.short	(LBB0_309-LBB0_175)>>2
	.short	(LBB0_300-LBB0_175)>>2
	.short	(LBB0_304-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_308-LBB0_175)>>2
	.short	(LBB0_315-LBB0_175)>>2
	.short	(LBB0_316-LBB0_175)>>2
	.short	(LBB0_305-LBB0_175)>>2
	.short	(LBB0_317-LBB0_175)>>2
	.short	(LBB0_299-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_318-LBB0_175)>>2
	.short	(LBB0_321-LBB0_175)>>2
	.short	(LBB0_319-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_175-LBB0_175)>>2
	.short	(LBB0_306-LBB0_175)>>2
	.short	(LBB0_307-LBB0_175)>>2
	.short	(LBB0_309-LBB0_175)>>2
	.short	(LBB0_300-LBB0_175)>>2
	.short	(LBB0_304-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_290-LBB0_175)>>2
	.short	(LBB0_308-LBB0_175)>>2
	.short	(LBB0_315-LBB0_175)>>2
	.short	(LBB0_316-LBB0_175)>>2
	.short	(LBB0_305-LBB0_175)>>2
	.short	(LBB0_317-LBB0_175)>>2
	.short	(LBB0_299-LBB0_175)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB1_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh12:
	adrp	x9, lJTI1_0@PAGE
Lloh13:
	add	x9, x9, lJTI1_0@PAGEOFF
	adr	x10, LBB1_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB1_2:
	ret
LBB1_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
	.section	__TEXT,__const
lJTI1_0:
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
	.byte	(LBB1_3-LBB1_2)>>2
	.byte	(LBB1_2-LBB1_2)>>2
                                        ; -- End function
.subsections_via_symbols
