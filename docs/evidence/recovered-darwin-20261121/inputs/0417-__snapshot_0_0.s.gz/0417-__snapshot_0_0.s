	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_fs_walkdir                     ; -- Begin function fs_walkdir
	.p2align	2
_fs_walkdir:                            ; @fs_walkdir
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_nl_fs_walkdir
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_fs_walkdir
_nl_fs_walkdir:                         ; @nl_fs_walkdir
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #464
	stp	x28, x27, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	mov	w0, #3                          ; =0x3
	mov	x1, #128                        ; =0x80
	bl	_dyn_array_new_with_capacity
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbz	x8, LBB1_3
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB1_3
	b	LBB1_2
LBB1_2:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbnz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-24]
	b	LBB1_43
LBB1_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-48]
	stur	xzr, [x29, #-56]
	stur	xzr, [x29, #-64]
	ldur	x0, [x29, #-32]
	bl	_strdup
	stur	x0, [x29, #-72]
	ldur	x8, [x29, #-72]
	cbnz	x8, LBB1_6
	b	LBB1_5
LBB1_5:
	bl	_abort
LBB1_6:
	ldur	x3, [x29, #-72]
	sub	x0, x29, #48
	sub	x1, x29, #56
	sub	x2, x29, #64
	bl	_nl_walk_enqueue
	stur	xzr, [x29, #-80]
	b	LBB1_7
LBB1_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_11 Depth 2
                                        ;     Child Loop BB1_20 Depth 2
	ldur	x8, [x29, #-80]
	ldur	x9, [x29, #-56]
	subs	x8, x8, x9
	b.hs	LBB1_42
	b	LBB1_8
LBB1_8:                                 ;   in Loop: Header=BB1_7 Depth=1
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-80]
	lsl	x9, x9, #5
	ldr	x8, [x8, x9]
	stur	x8, [x29, #-88]
	ldur	x0, [x29, #-88]
	bl	_opendir
	stur	x0, [x29, #-96]
	strb	wzr, [sp, #207]
	ldur	x8, [x29, #-96]
	cbz	x8, LBB1_38
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_7 Depth=1
	ldur	x0, [x29, #-96]
	bl	_dirfd
	add	x1, sp, #208
	bl	_fstat
	cbnz	w0, LBB1_38
	b	LBB1_10
LBB1_10:                                ;   in Loop: Header=BB1_7 Depth=1
	str	xzr, [sp, #192]
	b	LBB1_11
LBB1_11:                                ;   Parent Loop BB1_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #192]
	ldur	x9, [x29, #-80]
	subs	x8, x8, x9
	b.hs	LBB1_18
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_11 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x9, [sp, #192]
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB1_16
	b	LBB1_13
LBB1_13:                                ;   in Loop: Header=BB1_11 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x9, [sp, #192]
	add	x8, x8, x9, lsl #5
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #208]
	subs	w8, w8, w9
	b.ne	LBB1_16
	b	LBB1_14
LBB1_14:                                ;   in Loop: Header=BB1_11 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x9, [sp, #192]
	add	x8, x8, x9, lsl #5
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #216]
	subs	x8, x8, x9
	b.ne	LBB1_16
	b	LBB1_15
LBB1_15:                                ;   in Loop: Header=BB1_7 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #207]
	b	LBB1_18
LBB1_16:                                ;   in Loop: Header=BB1_11 Depth=2
	b	LBB1_17
LBB1_17:                                ;   in Loop: Header=BB1_11 Depth=2
	ldr	x8, [sp, #192]
	add	x8, x8, #1
	str	x8, [sp, #192]
	b	LBB1_11
LBB1_18:                                ;   in Loop: Header=BB1_7 Depth=1
	ldrb	w8, [sp, #207]
	tbnz	w8, #0, LBB1_37
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_7 Depth=1
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-80]
	add	x9, x8, x9, lsl #5
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
	ldr	w8, [sp, #208]
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-80]
	add	x9, x9, x10, lsl #5
	str	w8, [x9, #8]
	ldr	x8, [sp, #216]
	ldur	x9, [x29, #-48]
	ldur	x10, [x29, #-80]
	add	x9, x9, x10, lsl #5
	str	x8, [x9, #16]
	b	LBB1_20
LBB1_20:                                ;   Parent Loop BB1_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x0, [x29, #-96]
	bl	_readdir
	str	x0, [sp, #184]
	cbz	x0, LBB1_36
	b	LBB1_21
LBB1_21:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x8, [sp, #184]
	add	x0, x8, #21
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB1_23
	b	LBB1_22
LBB1_22:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x8, [sp, #184]
	add	x0, x8, #21
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB1_24
	b	LBB1_23
LBB1_23:                                ;   in Loop: Header=BB1_20 Depth=2
	b	LBB1_20
LBB1_24:                                ;   in Loop: Header=BB1_20 Depth=2
	ldur	x0, [x29, #-88]
	bl	_strlen
	str	x0, [sp, #176]
	ldr	x8, [sp, #184]
	add	x0, x8, #21
	bl	_strlen
	str	x0, [sp, #168]
	ldr	x8, [sp, #176]
	ldr	x10, [sp, #168]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x9, x9, #2
	subs	x8, x8, x9
	b.ls	LBB1_26
	b	LBB1_25
LBB1_25:
	bl	_abort
LBB1_26:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x8, [sp, #176]
	ldr	x9, [sp, #168]
	add	x8, x8, x9
	add	x0, x8, #2
	bl	_malloc
	str	x0, [sp, #160]
	ldr	x8, [sp, #160]
	cbnz	x8, LBB1_28
	b	LBB1_27
LBB1_27:
	bl	_abort
LBB1_28:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x0, [sp, #160]
	ldur	x1, [x29, #-88]
	ldr	x2, [sp, #176]
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #160]
	ldr	x9, [sp, #176]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	ldr	x8, [sp, #160]
	ldr	x9, [sp, #176]
	add	x8, x8, x9
	add	x0, x8, #1
	ldr	x8, [sp, #184]
	add	x1, x8, #21
	ldr	x8, [sp, #168]
	add	x2, x8, #1
	bl	___memcpy_chk
	ldr	x0, [sp, #160]
	add	x1, sp, #16
	bl	_stat
	cbnz	w0, LBB1_35
	b	LBB1_29
LBB1_29:                                ;   in Loop: Header=BB1_20 Depth=2
	ldrh	w8, [sp, #20]
	and	w8, w8, #0xf000
	subs	w8, w8, #8, lsl #12             ; =32768
	b.ne	LBB1_31
	b	LBB1_30
LBB1_30:                                ;   in Loop: Header=BB1_20 Depth=2
	ldur	x0, [x29, #-40]
	ldr	x1, [sp, #160]
	bl	_dyn_array_push_string_copy
	b	LBB1_34
LBB1_31:                                ;   in Loop: Header=BB1_20 Depth=2
	ldrh	w8, [sp, #20]
	and	w8, w8, #0xf000
	subs	w8, w8, #4, lsl #12             ; =16384
	b.ne	LBB1_33
	b	LBB1_32
LBB1_32:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x3, [sp, #160]
	sub	x0, x29, #48
	sub	x1, x29, #56
	sub	x2, x29, #64
	bl	_nl_walk_enqueue
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #160]
	b	LBB1_33
LBB1_33:                                ;   in Loop: Header=BB1_20 Depth=2
	b	LBB1_34
LBB1_34:                                ;   in Loop: Header=BB1_20 Depth=2
	b	LBB1_35
LBB1_35:                                ;   in Loop: Header=BB1_20 Depth=2
	ldr	x0, [sp, #160]
	bl	_free
	b	LBB1_20
LBB1_36:                                ;   in Loop: Header=BB1_7 Depth=1
	b	LBB1_37
LBB1_37:                                ;   in Loop: Header=BB1_7 Depth=1
	b	LBB1_38
LBB1_38:                                ;   in Loop: Header=BB1_7 Depth=1
	ldur	x8, [x29, #-96]
	cbz	x8, LBB1_40
	b	LBB1_39
LBB1_39:                                ;   in Loop: Header=BB1_7 Depth=1
	ldur	x0, [x29, #-96]
	bl	_closedir
	b	LBB1_40
LBB1_40:                                ;   in Loop: Header=BB1_7 Depth=1
	ldur	x0, [x29, #-88]
	bl	_free
	ldur	x9, [x29, #-48]
	ldur	x8, [x29, #-80]
	lsl	x10, x8, #5
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10]
	b	LBB1_41
LBB1_41:                                ;   in Loop: Header=BB1_7 Depth=1
	ldur	x8, [x29, #-80]
	add	x8, x8, #1
	stur	x8, [x29, #-80]
	b	LBB1_7
LBB1_42:
	ldur	x0, [x29, #-48]
	bl	_free
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-24]
	b	LBB1_43
LBB1_43:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #432]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_fs_walkdir_release             ; -- Begin function fs_walkdir_release
	.p2align	2
_fs_walkdir_release:                    ; @fs_walkdir_release
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x0, [sp, #16]
	bl	_gc_is_managed
	tbnz	w0, #0, LBB2_3
	b	LBB2_2
LBB2_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_12
LBB2_3:
	ldr	x0, [sp, #16]
	bl	_gc_get_header
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #4]
	subs	w8, w8, #1
	b.ne	LBB2_6
	b	LBB2_4
LBB2_4:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB2_6
	b	LBB2_5
LBB2_5:
	ldr	x0, [sp, #16]
	mov	w1, #3                          ; =0x3
	mov	x2, #8                          ; =0x8
	mov	x3, #0                          ; =0x0
	bl	_dyn_array_has_storage
	tbnz	w0, #0, LBB2_7
	b	LBB2_6
LBB2_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_12
LBB2_7:
	str	xzr, [sp]
	b	LBB2_8
LBB2_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ge	LBB2_11
	b	LBB2_9
LBB2_9:                                 ;   in Loop: Header=BB2_8 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [sp]
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	ldr	x8, [sp, #16]
	ldr	x9, [x8, #24]
	ldr	x10, [sp]
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	b	LBB2_10
LBB2_10:                                ;   in Loop: Header=BB2_8 Depth=1
	ldr	x8, [sp]
	add	x8, x8, #1
	str	x8, [sp]
	b	LBB2_8
LBB2_11:
	ldr	x8, [sp, #16]
	str	xzr, [x8]
	ldr	x0, [sp, #16]
	bl	_gc_release
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_12
LBB2_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function gc_get_header
_gc_get_header:                         ; @gc_get_header
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x0, x8, #40
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dyn_array_has_storage
_dyn_array_has_storage:                 ; @dyn_array_has_storage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	ldr	x8, [sp, #32]
	cbz	x8, LBB4_8
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB4_8
	b	LBB4_2
LBB4_2:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.ne	LBB4_8
	b	LBB4_3
LBB4_3:
	ldr	x8, [sp, #16]
	cbz	x8, LBB4_8
	b	LBB4_4
LBB4_4:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #20]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	LBB4_8
	b	LBB4_5
LBB4_5:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	tbnz	x8, #63, LBB4_8
	b	LBB4_6
LBB4_6:
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #32]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.lt	LBB4_8
	b	LBB4_7
LBB4_7:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x10, [sp, #16]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB4_9
	b	LBB4_8
LBB4_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB4_10
LBB4_9:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x9, [x9]
	ldr	x10, [sp, #16]
	mul	x9, x9, x10
	subs	x8, x8, x9
	cset	w8, ls
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB4_10
LBB4_10:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_canonical                 ; -- Begin function path_canonical
	.p2align	2
_path_canonical:                        ; @path_canonical
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	cbnz	w8, LBB5_3
	b	LBB5_2
LBB5_2:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB5_7
LBB5_3:
	ldr	x0, [sp, #16]
	mov	x1, #0                          ; =0x0
	bl	_realpath
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB5_5
	b	LBB5_4
LBB5_4:
	ldr	x0, [sp, #8]
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB5_6
LBB5_5:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	bl	_strdup
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB5_6
LBB5_6:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	stur	x8, [x29, #-8]
	b	LBB5_7
LBB5_7:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_compare_identity          ; -- Begin function file_compare_identity
	.p2align	2
_file_compare_identity:                 ; @file_compare_identity
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB6_4
	b	LBB6_1
LBB6_1:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbz	w8, LBB6_4
	b	LBB6_2
LBB6_2:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB6_4
	b	LBB6_3
LBB6_3:
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	cbnz	w8, LBB6_5
	b	LBB6_4
LBB6_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB6_14
LBB6_5:
	ldur	x0, [x29, #-32]
	add	x1, sp, #152
	bl	_stat
	cbz	w0, LBB6_7
	b	LBB6_6
LBB6_6:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB6_14
LBB6_7:
	ldur	x0, [x29, #-40]
	add	x1, sp, #8
	bl	_stat
	cbz	w0, LBB6_11
	b	LBB6_8
LBB6_8:
	bl	___error
	ldr	w9, [x0]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB6_10
	b	LBB6_9
LBB6_9:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #20
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB6_10
LBB6_10:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	csetm	w9, eq
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	stur	x8, [x29, #-24]
	b	LBB6_14
LBB6_11:
	ldr	w9, [sp, #152]
	ldr	w10, [sp, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB6_13
	b	LBB6_12
LBB6_12:
	ldr	x8, [sp, #160]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB6_13
LBB6_13:
	ldr	w9, [sp]                        ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w9, w8, wzr, eq
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	stur	x8, [x29, #-24]
	b	LBB6_14
LBB6_14:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_compare_destinations      ; -- Begin function file_compare_destinations
	.p2align	2
_file_compare_destinations:             ; @file_compare_destinations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB7_4
	b	LBB7_1
LBB7_1:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbz	w8, LBB7_4
	b	LBB7_2
LBB7_2:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB7_4
	b	LBB7_3
LBB7_3:
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	cbnz	w8, LBB7_5
	b	LBB7_4
LBB7_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_5:
	ldur	x0, [x29, #-32]
	add	x1, sp, #168
	bl	_destination_stat
	str	w0, [sp, #20]
	ldur	x0, [x29, #-40]
	add	x1, sp, #24
	bl	_destination_stat
	str	w0, [sp, #16]
	ldr	w8, [sp, #20]
	tbnz	w8, #31, LBB7_7
	b	LBB7_6
LBB7_6:
	ldr	w8, [sp, #16]
	tbz	w8, #31, LBB7_8
	b	LBB7_7
LBB7_7:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_8:
	ldr	w8, [sp, #20]
	cbz	w8, LBB7_13
	b	LBB7_9
LBB7_9:
	ldr	w8, [sp, #16]
	cbz	w8, LBB7_13
	b	LBB7_10
LBB7_10:
	ldr	w9, [sp, #168]
	ldr	w10, [sp, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB7_12
	b	LBB7_11
LBB7_11:
	ldr	x8, [sp, #176]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB7_12
LBB7_12:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
                                        ; kill: def $x8 killed $w8
	and	x8, x8, #0x1
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_13:
	ldr	w8, [sp, #20]
	cbnz	w8, LBB7_15
	b	LBB7_14
LBB7_14:
	ldr	w8, [sp, #16]
	cbz	w8, LBB7_16
	b	LBB7_15
LBB7_15:
	stur	xzr, [x29, #-24]
	b	LBB7_30
LBB7_16:
	ldur	x0, [x29, #-32]
	mov	w1, #448                        ; =0x1c0
	bl	_mkdir
	cbz	w0, LBB7_18
	b	LBB7_17
LBB7_17:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_18:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #8]
	ldur	x0, [x29, #-32]
	add	x1, sp, #168
	bl	_stat
	cbnz	w0, LBB7_27
	b	LBB7_19
LBB7_19:
	ldur	x0, [x29, #-40]
	add	x1, sp, #24
	bl	_destination_stat
	str	w0, [sp, #16]
	ldr	w8, [sp, #16]
	cbnz	w8, LBB7_21
	b	LBB7_20
LBB7_20:
	str	xzr, [sp, #8]
	b	LBB7_26
LBB7_21:
	ldr	w8, [sp, #16]
	subs	w8, w8, #0
	b.le	LBB7_25
	b	LBB7_22
LBB7_22:
	ldr	w9, [sp, #168]
	ldr	w10, [sp, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB7_24
	b	LBB7_23
LBB7_23:
	ldr	x8, [sp, #176]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB7_24
LBB7_24:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
                                        ; kill: def $x8 killed $w8
	and	x8, x8, #0x1
	str	x8, [sp, #8]
	b	LBB7_25
LBB7_25:
	b	LBB7_26
LBB7_26:
	b	LBB7_27
LBB7_27:
	ldur	x0, [x29, #-32]
	bl	_rmdir
	cbz	w0, LBB7_29
	b	LBB7_28
LBB7_28:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_29:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-24]
	b	LBB7_30
LBB7_30:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function destination_stat
_destination_stat:                      ; @destination_stat
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_stat
	cbnz	w0, LBB8_2
	b	LBB8_1
LBB8_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB8_8
LBB8_2:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #2
	b.eq	LBB8_4
	b	LBB8_3
LBB8_3:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB8_8
LBB8_4:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #8]
	bl	_lstat
	cbz	w0, LBB8_6
	b	LBB8_5
LBB8_5:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #2
	b.eq	LBB8_7
	b	LBB8_6
LBB8_6:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB8_8
LBB8_7:
	stur	wzr, [x29, #-4]
	b	LBB8_8
LBB8_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_normalize                 ; -- Begin function path_normalize
	.p2align	2
_path_normalize:                        ; @path_normalize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_nl_normalize_path
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_normalize_path
_nl_normalize_path:                     ; @nl_normalize_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	stur	x8, [x29, #-16]
	b	LBB10_2
LBB10_2:
	ldur	x0, [x29, #-16]
	bl	_strlen
	stur	x0, [x29, #-24]
	ldur	x8, [x29, #-24]
	mov	x9, #2                          ; =0x2
	udiv	x8, x8, x9
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	adds	x8, x8, #3
	b.hi	LBB10_4
	b	LBB10_3
LBB10_3:
	ldur	x8, [x29, #-32]
	mov	x9, #2305843009213693951        ; =0x1fffffffffffffff
	subs	x8, x8, x9
	b.ls	LBB10_5
	b	LBB10_4
LBB10_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_45
LBB10_5:
	ldur	x8, [x29, #-24]
	add	x0, x8, #2
	bl	_malloc
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-32]
	lsl	x0, x8, #3
	bl	_malloc
	stur	x0, [x29, #-48]
	ldur	x8, [x29, #-40]
	cbz	x8, LBB10_7
	b	LBB10_6
LBB10_6:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB10_8
	b	LBB10_7
LBB10_7:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_45
LBB10_8:
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	cset	w8, eq
	stur	w8, [x29, #-52]
	str	xzr, [sp, #48]
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB10_10
	b	LBB10_9
LBB10_9:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	b	LBB10_10
LBB10_10:
	b	LBB10_11
LBB10_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_15 Depth 2
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.hs	LBB10_42
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.ne	LBB10_14
	b	LBB10_13
LBB10_13:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB10_11
LBB10_14:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #32]
	str	x8, [sp, #24]
	b	LBB10_15
LBB10_15:                               ;   Parent Loop BB10_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #32]
	ldur	x10, [x29, #-24]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.hs	LBB10_17
	b	LBB10_16
LBB10_16:                               ;   in Loop: Header=BB10_15 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB10_17
LBB10_17:                               ;   in Loop: Header=BB10_15 Depth=2
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB10_19
	b	LBB10_18
LBB10_18:                               ;   in Loop: Header=BB10_15 Depth=2
	ldr	x8, [sp, #32]
	add	x8, x8, #1
	str	x8, [sp, #32]
	b	LBB10_15
LBB10_19:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	subs	x8, x8, #1
	b.ne	LBB10_22
	b	LBB10_20
LBB10_20:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB10_22
	b	LBB10_21
LBB10_21:                               ;   in Loop: Header=BB10_11 Depth=1
	b	LBB10_11
LBB10_22:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #2
	b.ne	LBB10_36
	b	LBB10_23
LBB10_23:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB10_36
	b	LBB10_24
LBB10_24:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	add	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB10_36
	b	LBB10_25
LBB10_25:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #40]
	cbz	x8, LBB10_33
	b	LBB10_26
LBB10_26:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x9, [sp, #40]
	subs	x9, x9, #1
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #8]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #8]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.ne	LBB10_28
	b	LBB10_27
LBB10_27:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #1
	str	x8, [sp, #8]
	b	LBB10_28
LBB10_28:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	subs	x8, x8, #2
	b.ne	LBB10_31
	b	LBB10_29
LBB10_29:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #8]
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #46
	b.ne	LBB10_31
	b	LBB10_30
LBB10_30:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #8]
	add	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #46
	b.eq	LBB10_32
	b	LBB10_31
LBB10_31:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x9, [sp, #40]
	subs	x9, x9, #1
	str	x9, [sp, #40]
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #48]
	b	LBB10_11
LBB10_32:                               ;   in Loop: Header=BB10_11 Depth=1
	b	LBB10_33
LBB10_33:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	w8, [x29, #-52]
	cbz	w8, LBB10_35
	b	LBB10_34
LBB10_34:                               ;   in Loop: Header=BB10_11 Depth=1
	b	LBB10_11
LBB10_35:                               ;   in Loop: Header=BB10_11 Depth=1
	b	LBB10_36
LBB10_36:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	b.lo	LBB10_38
	b	LBB10_37
LBB10_37:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_45
LBB10_38:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-48]
	ldr	x10, [sp, #40]
	add	x11, x10, #1
	str	x11, [sp, #40]
	str	x8, [x9, x10, lsl #3]
	ldr	x8, [sp, #48]
	cbz	x8, LBB10_41
	b	LBB10_39
LBB10_39:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	subs	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.eq	LBB10_41
	b	LBB10_40
LBB10_40:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	b	LBB10_41
LBB10_41:                               ;   in Loop: Header=BB10_11 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	add	x0, x8, x9
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	add	x1, x8, x9
	ldr	x2, [sp, #16]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #48]
	add	x8, x8, x9
	str	x8, [sp, #48]
	b	LBB10_11
LBB10_42:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB10_44
	b	LBB10_43
LBB10_43:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #46                         ; =0x2e
	strb	w8, [x9]
	b	LBB10_44
LBB10_44:
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #48]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x0, [x29, #-48]
	bl	_free
	ldur	x8, [x29, #-40]
	stur	x8, [x29, #-8]
	b	LBB10_45
LBB10_45:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_join                      ; -- Begin function path_join
	.p2align	2
_path_join:                             ; @path_join
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	ldr	x8, [sp, #72]
	cbz	x8, LBB11_2
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp, #72]
	ldrsb	w8, [x8]
	cbnz	w8, LBB11_6
	b	LBB11_2
LBB11_2:
	ldr	x8, [sp, #64]
	cbz	x8, LBB11_4
	b	LBB11_3
LBB11_3:
	ldr	x8, [sp, #64]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB11_5
LBB11_4:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB11_5
LBB11_5:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #88
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_strdup
	str	x0, [sp, #80]
	b	LBB11_13
LBB11_6:
	ldr	x8, [sp, #64]
	cbz	x8, LBB11_8
	b	LBB11_7
LBB11_7:
	ldr	x8, [sp, #64]
	ldrsb	w8, [x8]
	cbnz	w8, LBB11_9
	b	LBB11_8
LBB11_8:
	ldr	x8, [sp, #72]
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #88
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_strdup
	str	x0, [sp, #80]
	b	LBB11_13
LBB11_9:
	ldr	x0, [sp, #72]
	bl	_strlen
	str	x0, [sp, #56]
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #56]
	subs	x9, x9, #1
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.ne	LBB11_11
	b	LBB11_10
LBB11_10:
	ldr	x10, [sp, #72]
	ldr	x8, [sp, #64]
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	add	x0, sp, #88
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.2@PAGE
	add	x4, x4, l_.str.2@PAGEOFF
	bl	___snprintf_chk
	b	LBB11_12
LBB11_11:
	ldr	x10, [sp, #72]
	ldr	x8, [sp, #64]
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	add	x0, sp, #88
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.3@PAGE
	add	x4, x4, l_.str.3@PAGEOFF
	bl	___snprintf_chk
	b	LBB11_12
LBB11_12:
	add	x0, sp, #88
	bl	_strdup
	str	x0, [sp, #80]
	b	LBB11_13
LBB11_13:
	ldr	x8, [sp, #80]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB11_15
	b	LBB11_14
LBB11_14:
	bl	___stack_chk_fail
LBB11_15:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	sp, sp, #2144
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_basename                  ; -- Begin function path_basename
	.p2align	2
_path_basename:                         ; @path_basename
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	cbnz	w8, LBB12_3
	b	LBB12_2
LBB12_2:
	adrp	x0, l_.str.4@PAGE
	add	x0, x0, l_.str.4@PAGEOFF
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB12_6
LBB12_3:
	ldur	x0, [x29, #-16]
	bl	_strdup
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB12_5
	b	LBB12_4
LBB12_4:
	ldur	x0, [x29, #-16]
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB12_6
LBB12_5:
	ldr	x0, [sp, #24]
	bl	_basename
	str	x0, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_strdup
	str	x0, [sp, #8]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB12_6
LBB12_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_dirname                   ; -- Begin function path_dirname
	.p2align	2
_path_dirname:                          ; @path_dirname
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	cbnz	w8, LBB13_3
	b	LBB13_2
LBB13_2:
	adrp	x0, l_.str.4@PAGE
	add	x0, x0, l_.str.4@PAGEOFF
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB13_6
LBB13_3:
	ldur	x0, [x29, #-16]
	bl	_strdup
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB13_5
	b	LBB13_4
LBB13_4:
	ldur	x0, [x29, #-16]
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB13_6
LBB13_5:
	ldr	x0, [sp, #24]
	bl	_dirname
	str	x0, [sp, #16]
	ldr	x0, [sp, #16]
	bl	_strdup
	str	x0, [sp, #8]
	ldr	x0, [sp, #24]
	bl	_free
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB13_6
LBB13_6:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_relpath                   ; -- Begin function path_relpath
	.p2align	2
_path_relpath:                          ; @path_relpath
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB14_3
	b	LBB14_2
LBB14_2:
	adrp	x0, l_.str.4@PAGE
	add	x0, x0, l_.str.4@PAGEOFF
	bl	_strdup
	stur	x0, [x29, #-8]
	b	LBB14_35
LBB14_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB14_5
	b	LBB14_4
LBB14_4:
	ldur	x8, [x29, #-24]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.eq	LBB14_8
	b	LBB14_5
LBB14_5:
	bl	_relative_path_cwd
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB14_7
	b	LBB14_6
LBB14_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB14_35
LBB14_7:
	b	LBB14_8
LBB14_8:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	bl	_relative_path_absolute
	stur	x0, [x29, #-40]
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-32]
	bl	_relative_path_absolute
	stur	x0, [x29, #-48]
	ldur	x0, [x29, #-32]
	bl	_free
	ldur	x8, [x29, #-40]
	cbz	x8, LBB14_10
	b	LBB14_9
LBB14_9:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB14_11
	b	LBB14_10
LBB14_10:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB14_35
LBB14_11:
	ldur	x0, [x29, #-40]
	bl	_strlen
	stur	x0, [x29, #-56]
	ldur	x0, [x29, #-48]
	bl	_strlen
	stur	x0, [x29, #-64]
	ldur	x8, [x29, #-56]
	adds	x8, x8, #3
	b.hi	LBB14_13
	b	LBB14_12
LBB14_12:
	ldur	x8, [x29, #-64]
	ldur	x10, [x29, #-56]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x9, x9, #2
	mov	x10, #3                         ; =0x3
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB14_14
	b	LBB14_13
LBB14_13:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB14_35
LBB14_14:
	ldur	x8, [x29, #-56]
	ldur	x9, [x29, #-64]
	mov	x10, #3                         ; =0x3
	mul	x9, x9, x10
	add	x8, x8, x9
	add	x0, x8, #2
	bl	_malloc
	stur	x0, [x29, #-72]
	ldur	x8, [x29, #-72]
	cbnz	x8, LBB14_16
	b	LBB14_15
LBB14_15:
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB14_35
LBB14_16:
	add	x2, sp, #80
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #80]
	add	x8, sp, #72
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	xzr, [sp, #72]
	ldur	x0, [x29, #-40]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	bl	_strtok_r
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	str	x0, [sp, #64]
	ldur	x0, [x29, #-48]
	bl	_strtok_r
	str	x0, [sp, #56]
	b	LBB14_17
LBB14_17:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #64]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	x8, LBB14_20
	b	LBB14_18
LBB14_18:                               ;   in Loop: Header=BB14_17 Depth=1
	ldr	x8, [sp, #56]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	x8, LBB14_20
	b	LBB14_19
LBB14_19:                               ;   in Loop: Header=BB14_17 Depth=1
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #56]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB14_20
LBB14_20:                               ;   in Loop: Header=BB14_17 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_22
	b	LBB14_21
LBB14_21:                               ;   in Loop: Header=BB14_17 Depth=1
	mov	x0, #0                          ; =0x0
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	str	x1, [sp]                        ; 8-byte Folded Spill
	add	x2, sp, #80
	bl	_strtok_r
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #64]
	add	x2, sp, #72
	bl	_strtok_r
	str	x0, [sp, #56]
	b	LBB14_17
LBB14_22:
	str	xzr, [sp, #48]
	b	LBB14_23
LBB14_23:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #56]
	cbz	x8, LBB14_27
	b	LBB14_24
LBB14_24:                               ;   in Loop: Header=BB14_23 Depth=1
	ldr	x8, [sp, #48]
	cbz	x8, LBB14_26
	b	LBB14_25
LBB14_25:                               ;   in Loop: Header=BB14_23 Depth=1
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	b	LBB14_26
LBB14_26:                               ;   in Loop: Header=BB14_23 Depth=1
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #46                         ; =0x2e
	strb	w8, [x9]
	ldur	x9, [x29, #-72]
	ldr	x10, [sp, #48]
	add	x11, x10, #1
	str	x11, [sp, #48]
	add	x9, x9, x10
	strb	w8, [x9]
	mov	x0, #0                          ; =0x0
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	add	x2, sp, #72
	bl	_strtok_r
	str	x0, [sp, #56]
	b	LBB14_23
LBB14_27:
	b	LBB14_28
LBB14_28:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #64]
	cbz	x8, LBB14_32
	b	LBB14_29
LBB14_29:                               ;   in Loop: Header=BB14_28 Depth=1
	ldr	x8, [sp, #48]
	cbz	x8, LBB14_31
	b	LBB14_30
LBB14_30:                               ;   in Loop: Header=BB14_28 Depth=1
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	b	LBB14_31
LBB14_31:                               ;   in Loop: Header=BB14_28 Depth=1
	ldr	x0, [sp, #64]
	bl	_strlen
	str	x0, [sp, #40]
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x0, x8, x9
	ldr	x1, [sp, #64]
	ldr	x2, [sp, #40]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #40]
	ldr	x8, [sp, #48]
	add	x8, x8, x9
	str	x8, [sp, #48]
	mov	x0, #0                          ; =0x0
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	add	x2, sp, #80
	bl	_strtok_r
	str	x0, [sp, #64]
	b	LBB14_28
LBB14_32:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB14_34
	b	LBB14_33
LBB14_33:
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x10, x9, #1
	str	x10, [sp, #48]
	add	x9, x8, x9
	mov	w8, #46                         ; =0x2e
	strb	w8, [x9]
	b	LBB14_34
LBB14_34:
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x0, [x29, #-48]
	bl	_free
	ldur	x8, [x29, #-72]
	stur	x8, [x29, #-8]
	b	LBB14_35
LBB14_35:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function relative_path_cwd
_relative_path_cwd:                     ; @relative_path_cwd
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, #256                        ; =0x100
	str	x8, [sp, #16]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #16]
	bl	_malloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_9
LBB15_3:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	bl	_getcwd
	cbz	x0, LBB15_5
	b	LBB15_4
LBB15_4:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB15_9
LBB15_5:                                ;   in Loop: Header=BB15_1 Depth=1
	bl	___error
	ldr	w8, [x0]
	str	w8, [sp, #4]
	ldr	x0, [sp, #8]
	bl	_free
	ldr	w8, [sp, #4]
	subs	w8, w8, #34
	b.ne	LBB15_7
	b	LBB15_6
LBB15_6:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x8, [sp, #16]
	mov	x9, #9223372036854775807        ; =0x7fffffffffffffff
	subs	x8, x8, x9
	b.ls	LBB15_8
	b	LBB15_7
LBB15_7:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB15_9
LBB15_8:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x8, [sp, #16]
	lsl	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB15_1
LBB15_9:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function relative_path_absolute
_relative_path_absolute:                ; @relative_path_absolute
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB16_2
	b	LBB16_1
LBB16_1:
	ldur	x0, [x29, #-16]
	bl	_nl_normalize_path
	stur	x0, [x29, #-8]
	b	LBB16_8
LBB16_2:
	ldur	x0, [x29, #-24]
	bl	_strlen
	str	x0, [sp, #32]
	ldur	x0, [x29, #-16]
	bl	_strlen
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	adds	x8, x8, #3
	b.hi	LBB16_4
	b	LBB16_3
LBB16_3:
	ldr	x8, [sp, #32]
	ldr	x10, [sp, #24]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x9, x9, #2
	subs	x8, x8, x9
	b.ls	LBB16_5
	b	LBB16_4
LBB16_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB16_8
LBB16_5:
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #24]
	add	x8, x8, x9
	add	x0, x8, #2
	bl	_malloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB16_7
	b	LBB16_6
LBB16_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB16_8
LBB16_7:
	ldr	x0, [sp, #16]
	ldur	x1, [x29, #-24]
	ldr	x2, [sp, #32]
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp]                        ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	add	x9, x8, x9
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	add	x8, x8, x9
	add	x0, x8, #1
	ldur	x1, [x29, #-16]
	ldr	x8, [sp, #24]
	add	x2, x8, #1
	bl	___memcpy_chk
	ldr	x0, [sp, #16]
	bl	_nl_normalize_path
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	bl	_free
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB16_8
LBB16_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_normalize__nano_string_release_v1 ; -- Begin function path_normalize__nano_string_release_v1
	.p2align	2
_path_normalize__nano_string_release_v1: ; @path_normalize__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_canonical__nano_string_release_v1 ; -- Begin function path_canonical__nano_string_release_v1
	.p2align	2
_path_canonical__nano_string_release_v1: ; @path_canonical__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_join__nano_string_release_v1 ; -- Begin function path_join__nano_string_release_v1
	.p2align	2
_path_join__nano_string_release_v1:     ; @path_join__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_basename__nano_string_release_v1 ; -- Begin function path_basename__nano_string_release_v1
	.p2align	2
_path_basename__nano_string_release_v1: ; @path_basename__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_dirname__nano_string_release_v1 ; -- Begin function path_dirname__nano_string_release_v1
	.p2align	2
_path_dirname__nano_string_release_v1:  ; @path_dirname__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_path_relpath__nano_string_release_v1 ; -- Begin function path_relpath__nano_string_release_v1
	.p2align	2
_path_relpath__nano_string_release_v1:  ; @path_relpath__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_read                      ; -- Begin function file_read
	.p2align	2
_file_read:                             ; @file_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x0, [x29, #-8]
	bl	_nl_read_file_text
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	ldr	x8, [sp, #16]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB23_3
LBB23_2:
	adrp	x8, _file_read_empty_result@PAGE
	add	x8, x8, _file_read_empty_result@PAGEOFF
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB23_3
LBB23_3:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_read_file_text
_nl_read_file_text:                     ; @nl_read_file_text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB24_2
	b	LBB24_1
LBB24_1:
	ldr	x0, [sp, #8]
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_fopen
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB24_3
LBB24_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB24_3
LBB24_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_nl_read_text_stream
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_read__nano_string_release_v1 ; -- Begin function file_read__nano_string_release_v1
	.p2align	2
_file_read__nano_string_release_v1:     ; @file_read__nano_string_release_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	adrp	x9, _file_read_empty_result@PAGE
	add	x9, x9, _file_read_empty_result@PAGEOFF
	subs	x8, x8, x9
	b.eq	LBB25_2
	b	LBB25_1
LBB25_1:
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB25_2
LBB25_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_write                     ; -- Begin function file_write
	.p2align	2
_file_write:                            ; @file_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	adrp	x2, l_.str.6@PAGE
	add	x2, x2, l_.str.6@PAGEOFF
	bl	_nl_write_file_text
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_write_file_text
_nl_write_file_text:                    ; @nl_write_file_text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB27_2
	b	LBB27_1
LBB27_1:
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB27_3
	b	LBB27_2
LBB27_2:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-8]
	b	LBB27_8
LBB27_3:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_fopen
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB27_5
	b	LBB27_4
LBB27_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
	stur	x8, [x29, #-8]
	b	LBB27_8
LBB27_5:
	ldur	x0, [x29, #-24]
	bl	_strlen
	str	x0, [sp, #16]
	ldur	x0, [x29, #-24]
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #24]
	mov	x1, #1                          ; =0x1
	bl	_fwrite
	str	x0, [sp, #8]
	ldr	x0, [sp, #24]
	bl	_fclose
	str	w0, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #16]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB27_7
	b	LBB27_6
LBB27_6:
	ldr	w8, [sp, #4]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB27_7
LBB27_7:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	csetm	w9, eq
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	stur	x8, [x29, #-8]
	b	LBB27_8
LBB27_8:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_append                    ; -- Begin function file_append
	.p2align	2
_file_append:                           ; @file_append
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	adrp	x2, l_.str.7@PAGE
	add	x2, x2, l_.str.7@PAGEOFF
	bl	_nl_write_file_text
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_exists                    ; -- Begin function file_exists
	.p2align	2
_file_exists:                           ; @file_exists
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	bl	_access
	subs	w8, w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_delete                    ; -- Begin function file_delete
	.p2align	2
_file_delete:                           ; @file_delete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_remove
                                        ; implicit-def: $x8
	mov	x8, x0
	sxtw	x0, w8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_fs_mkdir_p                     ; -- Begin function fs_mkdir_p
	.p2align	2
_fs_mkdir_p:                            ; @fs_mkdir_p
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbz	x8, LBB31_2
	b	LBB31_1
LBB31_1:
	ldr	x8, [sp, #40]
	ldrsb	w8, [x8]
	cbnz	w8, LBB31_3
	b	LBB31_2
LBB31_2:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB31_20
LBB31_3:
	ldr	x8, [sp, #40]
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #56
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_strlen
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB31_5
	b	LBB31_4
LBB31_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB31_20
LBB31_5:
	ldr	x8, [sp, #32]
	subs	x9, x8, #1
	add	x8, sp, #56
	ldrsb	w8, [x8, x9]
	subs	w8, w8, #47
	b.ne	LBB31_7
	b	LBB31_6
LBB31_6:
	ldr	x8, [sp, #32]
	subs	x9, x8, #1
	add	x8, sp, #56
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB31_7
LBB31_7:
	add	x8, sp, #56
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB31_8
LBB31_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	cbz	w8, LBB31_16
	b	LBB31_9
LBB31_9:                                ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #24]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB31_14
	b	LBB31_10
LBB31_10:                               ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #24]
	strb	wzr, [x8]
	add	x0, sp, #56
	mov	w1, #493                        ; =0x1ed
	bl	_mkdir
	cbz	w0, LBB31_13
	b	LBB31_11
LBB31_11:                               ;   in Loop: Header=BB31_8 Depth=1
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #17
	b.eq	LBB31_13
	b	LBB31_12
LBB31_12:
	ldr	x9, [sp, #24]
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB31_20
LBB31_13:                               ;   in Loop: Header=BB31_8 Depth=1
	ldr	x9, [sp, #24]
	mov	w8, #47                         ; =0x2f
	strb	w8, [x9]
	b	LBB31_14
LBB31_14:                               ;   in Loop: Header=BB31_8 Depth=1
	b	LBB31_15
LBB31_15:                               ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #24]
	add	x8, x8, #1
	str	x8, [sp, #24]
	b	LBB31_8
LBB31_16:
	add	x0, sp, #56
	mov	w1, #493                        ; =0x1ed
	bl	_mkdir
	cbz	w0, LBB31_19
	b	LBB31_17
LBB31_17:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #17
	b.eq	LBB31_19
	b	LBB31_18
LBB31_18:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB31_20
LBB31_19:
	str	xzr, [sp, #48]
	b	LBB31_20
LBB31_20:
	ldr	x8, [sp, #48]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB31_22
	b	LBB31_21
LBB31_21:
	bl	___stack_chk_fail
LBB31_22:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #2112
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_file_copy                      ; -- Begin function file_copy
	.p2align	2
_file_copy:                             ; @file_copy
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #8256                       ; =0x2040
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	ldr	x0, [sp, #40]
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_fopen
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB32_2
	b	LBB32_1
LBB32_1:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB32_12
LBB32_2:
	ldr	x0, [sp, #32]
	adrp	x1, l_.str.9@PAGE
	add	x1, x1, l_.str.9@PAGEOFF
	bl	_fopen
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB32_4
	b	LBB32_3
LBB32_3:
	ldr	x0, [sp, #24]
	bl	_fclose
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB32_12
LBB32_4:
	str	xzr, [sp, #8]
	b	LBB32_5
LBB32_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x3, [sp, #24]
	add	x0, sp, #56
	mov	x1, #1                          ; =0x1
	mov	x2, #8192                       ; =0x2000
	bl	_fread
	str	x0, [sp, #8]
	subs	x8, x0, #0
	b.ls	LBB32_9
	b	LBB32_6
LBB32_6:                                ;   in Loop: Header=BB32_5 Depth=1
	ldr	x2, [sp, #8]
	ldr	x3, [sp, #16]
	add	x0, sp, #56
	mov	x1, #1                          ; =0x1
	bl	_fwrite
	ldr	x8, [sp, #8]
	subs	x8, x0, x8
	b.eq	LBB32_8
	b	LBB32_7
LBB32_7:
	ldr	x0, [sp, #24]
	bl	_fclose
	ldr	x0, [sp, #16]
	bl	_fclose
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB32_12
LBB32_8:                                ;   in Loop: Header=BB32_5 Depth=1
	b	LBB32_5
LBB32_9:
	ldr	x0, [sp, #24]
	bl	_ferror
	cbz	w0, LBB32_11
	b	LBB32_10
LBB32_10:
	ldr	x0, [sp, #24]
	bl	_fclose
	ldr	x0, [sp, #16]
	bl	_fclose
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	b	LBB32_12
LBB32_11:
	ldr	x0, [sp, #24]
	bl	_fclose
	ldr	x0, [sp, #16]
	bl	_fclose
	str	xzr, [sp, #48]
	b	LBB32_12
LBB32_12:
	ldr	x8, [sp, #48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB32_14
	b	LBB32_13
LBB32_13:
	bl	___stack_chk_fail
LBB32_14:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #64
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_dir_copy                       ; -- Begin function dir_copy
	.p2align	2
_dir_copy:                              ; @dir_copy
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #4352                       ; =0x1100
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #232]
	str	x1, [sp, #224]
	ldr	x0, [sp, #232]
	add	x1, sp, #80
	bl	_stat
	cbnz	w0, LBB33_2
	b	LBB33_1
LBB33_1:
	ldrh	w8, [sp, #84]
	and	w8, w8, #0xf000
	subs	w8, w8, #4, lsl #12             ; =16384
	b.eq	LBB33_3
	b	LBB33_2
LBB33_2:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_3:
	ldr	x0, [sp, #224]
	bl	_fs_mkdir_p
	cbz	x0, LBB33_5
	b	LBB33_4
LBB33_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_5:
	ldr	x0, [sp, #232]
	bl	_opendir
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbnz	x8, LBB33_7
	b	LBB33_6
LBB33_6:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_7:
	b	LBB33_8
LBB33_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #72]
	bl	_readdir
	str	x0, [sp, #64]
	cbz	x0, LBB33_24
	b	LBB33_9
LBB33_9:                                ;   in Loop: Header=BB33_8 Depth=1
	ldr	x8, [sp, #64]
	add	x0, x8, #21
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_strcmp
	cbz	w0, LBB33_11
	b	LBB33_10
LBB33_10:                               ;   in Loop: Header=BB33_8 Depth=1
	ldr	x8, [sp, #64]
	add	x0, x8, #21
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB33_12
	b	LBB33_11
LBB33_11:                               ;   in Loop: Header=BB33_8 Depth=1
	b	LBB33_8
LBB33_12:                               ;   in Loop: Header=BB33_8 Depth=1
	ldr	x10, [sp, #232]
	ldr	x8, [sp, #64]
	add	x8, x8, #21
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	add	x0, sp, #2296
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x3, #2048                       ; =0x800
	str	x3, [sp, #40]                   ; 8-byte Folded Spill
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	str	w2, [sp, #36]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.3@PAGE
	add	x4, x4, l_.str.3@PAGEOFF
	str	x4, [sp, #48]                   ; 8-byte Folded Spill
	bl	___snprintf_chk
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x4, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #224]
	ldr	x8, [sp, #64]
	add	x8, x8, #21
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	add	x0, sp, #248
	mov	x1, x3
	bl	___snprintf_chk
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	add	x1, sp, #80
	bl	_stat
	cbz	w0, LBB33_14
	b	LBB33_13
LBB33_13:
	ldr	x0, [sp, #72]
	bl	_closedir
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_14:                               ;   in Loop: Header=BB33_8 Depth=1
	ldrh	w8, [sp, #84]
	and	w8, w8, #0xf000
	subs	w8, w8, #4, lsl #12             ; =16384
	b.ne	LBB33_18
	b	LBB33_15
LBB33_15:                               ;   in Loop: Header=BB33_8 Depth=1
	add	x0, sp, #2296
	add	x1, sp, #248
	bl	_dir_copy
	cbz	x0, LBB33_17
	b	LBB33_16
LBB33_16:
	ldr	x0, [sp, #72]
	bl	_closedir
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_17:                               ;   in Loop: Header=BB33_8 Depth=1
	b	LBB33_23
LBB33_18:                               ;   in Loop: Header=BB33_8 Depth=1
	ldrh	w8, [sp, #84]
	and	w8, w8, #0xf000
	subs	w8, w8, #8, lsl #12             ; =32768
	b.ne	LBB33_22
	b	LBB33_19
LBB33_19:                               ;   in Loop: Header=BB33_8 Depth=1
	add	x0, sp, #2296
	add	x1, sp, #248
	bl	_file_copy
	cbz	x0, LBB33_21
	b	LBB33_20
LBB33_20:
	ldr	x0, [sp, #72]
	bl	_closedir
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #240]
	b	LBB33_25
LBB33_21:                               ;   in Loop: Header=BB33_8 Depth=1
	b	LBB33_22
LBB33_22:                               ;   in Loop: Header=BB33_8 Depth=1
	b	LBB33_23
LBB33_23:                               ;   in Loop: Header=BB33_8 Depth=1
	b	LBB33_8
LBB33_24:
	ldr	x0, [sp, #72]
	bl	_closedir
	str	xzr, [sp, #240]
	b	LBB33_25
LBB33_25:
	ldr	x8, [sp, #240]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB33_27
	b	LBB33_26
LBB33_26:
	bl	___stack_chk_fail
LBB33_27:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #256
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_walk_enqueue
_nl_walk_enqueue:                       ; @nl_walk_enqueue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	stur	x3, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB34_9
	b	LBB34_1
LBB34_1:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	mov	x9, #288230376151711743         ; =0x3ffffffffffffff
	subs	x8, x8, x9
	b.ls	LBB34_3
	b	LBB34_2
LBB34_2:
	bl	_abort
LBB34_3:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	cbz	x8, LBB34_5
	b	LBB34_4
LBB34_4:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	lsl	x8, x8, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB34_6
LBB34_5:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB34_6
LBB34_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	x8, [x29, #-40]
	lsl	x1, x8, #5
	bl	_realloc
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB34_8
	b	LBB34_7
LBB34_7:
	bl	_abort
LBB34_8:
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-8]
	str	x8, [x9]
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	b	LBB34_9
LBB34_9:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldur	x11, [x29, #-16]
	ldr	x9, [x11]
	add	x10, x9, #1
	str	x10, [x11]
	add	x8, x8, x9, lsl #5
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #16]
	str	q0, [sp, #32]
	ldur	x9, [x29, #-32]
	str	x9, [sp, #16]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	ldr	q0, [sp, #32]
	str	q0, [x8, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_read_text_stream
_nl_read_text_stream:                   ; @nl_read_text_stream
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x0, [x29, #-16]
	bl	_nl_read_byte_stream
	str	x0, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB35_2
	b	LBB35_1
LBB35_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB35_13
LBB35_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB35_5
	b	LBB35_3
LBB35_3:
	ldr	x8, [sp, #24]
	ldr	x0, [x8, #24]
	ldr	x2, [sp, #16]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB35_5
	b	LBB35_4
LBB35_4:
	str	xzr, [sp, #16]
	b	LBB35_5
LBB35_5:
	ldr	x8, [sp, #16]
	adds	x8, x8, #1
	b.hs	LBB35_7
	b	LBB35_6
LBB35_6:
	ldr	x8, [sp, #16]
	add	x0, x8, #1
	bl	_malloc
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB35_8
LBB35_7:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB35_8
LBB35_8:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB35_12
	b	LBB35_9
LBB35_9:
	ldr	x8, [sp, #16]
	cbz	x8, LBB35_11
	b	LBB35_10
LBB35_10:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8, #24]
	ldr	x2, [sp, #16]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB35_11
LBB35_11:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	add	x8, x8, x9
	strb	wzr, [x8]
	b	LBB35_12
LBB35_12:
	ldr	x0, [sp, #24]
	bl	_gc_release
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB35_13
LBB35_13:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_read_byte_stream
_nl_read_byte_stream:                   ; @nl_read_byte_stream
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #4160                       ; =0x1040
Lloh4:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh5:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #40]
	mov	w0, #8                          ; =0x8
	bl	_dyn_array_new
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbz	x8, LBB36_2
	b	LBB36_1
LBB36_1:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB36_5
	b	LBB36_2
LBB36_2:
	ldr	x8, [sp, #40]
	cbz	x8, LBB36_4
	b	LBB36_3
LBB36_3:
	ldr	x0, [sp, #40]
	bl	_fclose
	b	LBB36_4
LBB36_4:
	ldr	x8, [sp, #32]
	str	x8, [sp, #48]
	b	LBB36_17
LBB36_5:
	b	LBB36_6
LBB36_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_8 Depth 2
	ldr	x3, [sp, #40]
	add	x0, sp, #56
	mov	x1, #1                          ; =0x1
	mov	x2, #4096                       ; =0x1000
	bl	_fread
	str	x0, [sp, #24]
	cbz	x0, LBB36_12
	b	LBB36_7
LBB36_7:                                ;   in Loop: Header=BB36_6 Depth=1
	str	xzr, [sp, #16]
	b	LBB36_8
LBB36_8:                                ;   Parent Loop BB36_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	subs	x8, x8, x9
	b.hs	LBB36_11
	b	LBB36_9
LBB36_9:                                ;   in Loop: Header=BB36_8 Depth=2
	ldr	x0, [sp, #32]
	ldr	x9, [sp, #16]
	add	x8, sp, #56
	ldrb	w1, [x8, x9]
	bl	_dyn_array_push_u8
	b	LBB36_10
LBB36_10:                               ;   in Loop: Header=BB36_8 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB36_8
LBB36_11:                               ;   in Loop: Header=BB36_6 Depth=1
	b	LBB36_6
LBB36_12:
	ldr	x0, [sp, #40]
	bl	_ferror
	str	w0, [sp, #12]
	ldr	x0, [sp, #40]
	bl	_fclose
	cbz	w0, LBB36_14
	b	LBB36_13
LBB36_13:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB36_14
LBB36_14:
	ldr	w8, [sp, #12]
	cbz	w8, LBB36_16
	b	LBB36_15
LBB36_15:
	ldr	x8, [sp, #32]
	str	xzr, [x8]
	b	LBB36_16
LBB36_16:
	ldr	x8, [sp, #32]
	str	x8, [sp, #48]
	b	LBB36_17
LBB36_17:
	ldr	x8, [sp, #48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB36_19
	b	LBB36_18
LBB36_18:
	bl	___stack_chk_fail
LBB36_19:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #64
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.globl	_fs_walkdir__nano_array_abi     ; @fs_walkdir__nano_array_abi
	.p2align	2, 0x0
_fs_walkdir__nano_array_abi:
	.long	1                               ; 0x1

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

l_.str.1:                               ; @.str.1
	.asciz	"%s"

l_.str.2:                               ; @.str.2
	.asciz	"%s%s"

l_.str.3:                               ; @.str.3
	.asciz	"%s/%s"

l_.str.4:                               ; @.str.4
	.asciz	"."

l_.str.5:                               ; @.str.5
	.asciz	"/"

	.section	__TEXT,__const
_file_read_empty_result:                ; @file_read_empty_result
	.space	1

	.section	__TEXT,__cstring,cstring_literals
l_.str.6:                               ; @.str.6
	.asciz	"w"

l_.str.7:                               ; @.str.7
	.asciz	"a"

l_.str.8:                               ; @.str.8
	.asciz	"rb"

l_.str.9:                               ; @.str.9
	.asciz	"wb"

l_.str.10:                              ; @.str.10
	.asciz	".."

.subsections_via_symbols
