	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_multi_nominal_catalog_types ; -- Begin function nvm_multi_nominal_catalog_types
	.globl	_nvm_multi_nominal_catalog_types
	.p2align	2
_nvm_multi_nominal_catalog_types:       ; @nvm_multi_nominal_catalog_types
	.cfi_startproc
; %bb.0:
	mov	w8, #8                          ; =0x8
	mov	w9, #9                          ; =0x9
	mov	w10, #7                         ; =0x7
	cmp	w0, #3
	csel	w10, w10, wzr, eq
	cmp	w0, #2
	csel	w9, w9, w10, eq
	cmp	w0, #1
	csel	w0, w8, w9, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_catalog_methods ; -- Begin function nvm_multi_nominal_catalog_methods
	.globl	_nvm_multi_nominal_catalog_methods
	.p2align	2
_nvm_multi_nominal_catalog_methods:     ; @nvm_multi_nominal_catalog_methods
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #1
	mov	w9, #4                          ; =0x4
	cmp	w0, #3
	csel	w9, w9, wzr, eq
	mov	w10, #5                         ; =0x5
	cmp	w8, #2
	csel	w0, w10, w9, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_check ; -- Begin function nvm_multi_nominal_check
	.globl	_nvm_multi_nominal_check
	.p2align	2
_nvm_multi_nominal_check:               ; @nvm_multi_nominal_check
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_3
; %bb.1:
	ldr	w8, [x0]
	sub	x9, x8, #65
	cmn	x9, #64
	b.hs	LBB2_4
; %bb.2:
	mov	w0, #5                          ; =0x5
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
LBB2_3:
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
LBB2_4:
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	mov	x9, #0                          ; =0x0
	add	x10, x0, #4
	add	x11, x0, #8
	add	x12, x0, #28
	mov	w13, #1                         ; =0x1
	mov	w14, #60                        ; =0x3c
	mov	w15, #8                         ; =0x8
	mov	w16, #9                         ; =0x9
	mov	w17, #7                         ; =0x7
	mov	w1, #4                          ; =0x4
	mov	x2, x11
Lloh0:
	adrp	x3, l_switch.table.nvm_multi_nominal_check@PAGE
Lloh1:
	add	x3, x3, l_switch.table.nvm_multi_nominal_check@PAGEOFF
LBB2_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_24 Depth 2
                                        ;     Child Loop BB2_42 Depth 2
                                        ;       Child Loop BB2_48 Depth 3
                                        ;     Child Loop BB2_53 Depth 2
                                        ;       Child Loop BB2_59 Depth 3
                                        ;     Child Loop BB2_64 Depth 2
                                        ;       Child Loop BB2_70 Depth 3
                                        ;     Child Loop BB2_75 Depth 2
                                        ;       Child Loop BB2_81 Depth 3
                                        ;     Child Loop BB2_87 Depth 2
                                        ;       Child Loop BB2_93 Depth 3
                                        ;     Child Loop BB2_28 Depth 2
                                        ;       Child Loop BB2_31 Depth 3
                                        ;         Child Loop BB2_36 Depth 4
	madd	x5, x9, x14, x10
	ldr	w6, [x5]
	cmp	w6, #3
	csel	w0, w17, wzr, eq
	cmp	w6, #2
	csel	w0, w16, w0, eq
	subs	w7, w6, #1
	csel	w4, w15, w0, eq
	cmp	w6, #3
	mov	w0, #4                          ; =0x4
	csel	x19, x0, xzr, eq
	cmp	w7, #2
	ccmp	w4, #0, #4, ls
	b.eq	LBB2_98
; %bb.6:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w4, #8
	b.hi	LBB2_22
; %bb.7:                                ;   in Loop: Header=BB2_5 Depth=1
	add	x0, x5, #24
	ldr	w20, [x0, w4, uxtw #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.8:                                ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #1
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.9:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.10:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #2
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.11:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.12:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #3
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.13:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.14:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #4
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.15:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.16:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #5
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.17:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.18:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #6
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.19:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w20, [x0, x20, lsl #2]
	cmn	w20, #1
	b.ne	LBB2_97
; %bb.20:                               ;   in Loop: Header=BB2_5 Depth=1
	add	x20, x4, #7
	cmp	x20, #9
	b.eq	LBB2_22
; %bb.21:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x0, x20, lsl #2]
	cmn	w0, #1
	b.ne	LBB2_97
LBB2_22:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w7, #2
	b.lo	LBB2_26
; %bb.23:                               ;   in Loop: Header=BB2_5 Depth=1
	lsl	x0, x19, #2
LBB2_24:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w19, [x2, x0]
	cmn	w19, #1
	b.ne	LBB2_97
; %bb.25:                               ;   in Loop: Header=BB2_24 Depth=2
	add	x0, x0, #4
	cmp	x0, #20
	b.ne	LBB2_24
LBB2_26:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w6, #3
	cset	w0, eq
	cmp	w7, #1
	cset	w7, hi
	eor	w0, w0, w7
	tbz	w0, #0, LBB2_40
LBB2_27:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	x0, #0                          ; =0x0
	add	x5, x5, #24
LBB2_28:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_31 Depth 3
                                        ;         Child Loop BB2_36 Depth 4
	ldr	w6, [x5, x0, lsl #2]
	cmn	w6, #1
	b.eq	LBB2_96
; %bb.29:                               ;   in Loop: Header=BB2_28 Depth=2
	mov	x7, #0                          ; =0x0
	mov	x19, x12
	b	LBB2_31
LBB2_30:                                ;   in Loop: Header=BB2_31 Depth=3
	add	x7, x7, #1
	add	x19, x19, #60
	cmp	x7, x13
	b.eq	LBB2_38
LBB2_31:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_28 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB2_36 Depth 4
	cmp	x7, x9
	b.ne	LBB2_33
; %bb.32:                               ;   in Loop: Header=BB2_31 Depth=3
	mov	x20, x0
	cbnz	x0, LBB2_35
	b	LBB2_30
LBB2_33:                                ;   in Loop: Header=BB2_31 Depth=3
	madd	x20, x7, x14, x10
	ldr	w20, [x20]
	sub	w20, w20, #1
	cmp	w20, #3
	b.hs	LBB2_30
; %bb.34:                               ;   in Loop: Header=BB2_31 Depth=3
	ubfiz	x20, x20, #3, #32
	ldr	w20, [x3, x20]
LBB2_35:                                ;   in Loop: Header=BB2_31 Depth=3
	mov	w20, w20
	mov	x21, x19
LBB2_36:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_28 Depth=2
                                        ;       Parent Loop BB2_31 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w22, [x21], #4
	cmp	w6, w22
	b.eq	LBB2_96
; %bb.37:                               ;   in Loop: Header=BB2_36 Depth=4
	subs	x20, x20, #1
	b.ne	LBB2_36
	b	LBB2_30
LBB2_38:                                ;   in Loop: Header=BB2_28 Depth=2
	add	x0, x0, #1
	cmp	x0, x4
	b.ne	LBB2_28
; %bb.39:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	w0, #0                          ; =0x0
	add	x9, x9, #1
	add	x13, x13, #1
	add	x2, x2, #60
	cmp	x9, x8
	b.ne	LBB2_5
	b	LBB2_98
LBB2_40:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x5, #4]
	cmn	w0, #1
	b.eq	LBB2_96
; %bb.41:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	x7, #0                          ; =0x0
	mov	x19, x11
LBB2_42:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_48 Depth 3
	cmp	x7, x9
	b.ne	LBB2_44
; %bb.43:                               ;   in Loop: Header=BB2_42 Depth=2
	mov	x20, #0                         ; =0x0
	b	LBB2_46
LBB2_44:                                ;   in Loop: Header=BB2_42 Depth=2
	madd	x20, x7, x14, x10
	ldr	w20, [x20]
	sub	x21, x20, #1
	cmp	w20, #3
	csel	x20, x1, xzr, eq
	cmp	x21, #2
	b.hs	LBB2_46
; %bb.45:                               ;   in Loop: Header=BB2_42 Depth=2
	mov	w20, #5                         ; =0x5
	b	LBB2_47
LBB2_46:                                ;   in Loop: Header=BB2_42 Depth=2
	cbz	x20, LBB2_50
LBB2_47:                                ;   in Loop: Header=BB2_42 Depth=2
	mov	x21, x19
LBB2_48:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_42 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w22, [x21], #4
	cmp	w0, w22
	b.eq	LBB2_96
; %bb.49:                               ;   in Loop: Header=BB2_48 Depth=3
	subs	x20, x20, #1
	b.ne	LBB2_48
LBB2_50:                                ;   in Loop: Header=BB2_42 Depth=2
	add	x7, x7, #1
	add	x19, x19, #60
	cmp	x7, x13
	b.ne	LBB2_42
; %bb.51:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x5, #8]
	cmn	w0, #1
	b.eq	LBB2_96
; %bb.52:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	x7, #0                          ; =0x0
	mov	x19, x11
LBB2_53:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_59 Depth 3
	cmp	x7, x9
	b.ne	LBB2_55
; %bb.54:                               ;   in Loop: Header=BB2_53 Depth=2
	mov	w20, #1                         ; =0x1
	b	LBB2_57
LBB2_55:                                ;   in Loop: Header=BB2_53 Depth=2
	madd	x20, x7, x14, x10
	ldr	w20, [x20]
	sub	x21, x20, #1
	cmp	w20, #3
	csel	x20, x1, xzr, eq
	cmp	x21, #2
	b.hs	LBB2_57
; %bb.56:                               ;   in Loop: Header=BB2_53 Depth=2
	mov	w20, #5                         ; =0x5
	b	LBB2_58
LBB2_57:                                ;   in Loop: Header=BB2_53 Depth=2
	cbz	x20, LBB2_61
LBB2_58:                                ;   in Loop: Header=BB2_53 Depth=2
	mov	x21, x19
LBB2_59:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_53 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w22, [x21], #4
	cmp	w0, w22
	b.eq	LBB2_96
; %bb.60:                               ;   in Loop: Header=BB2_59 Depth=3
	subs	x20, x20, #1
	b.ne	LBB2_59
LBB2_61:                                ;   in Loop: Header=BB2_53 Depth=2
	add	x7, x7, #1
	add	x19, x19, #60
	cmp	x7, x13
	b.ne	LBB2_53
; %bb.62:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x5, #12]
	cmn	w0, #1
	b.eq	LBB2_96
; %bb.63:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	x7, #0                          ; =0x0
	mov	x19, x11
LBB2_64:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_70 Depth 3
	cmp	x7, x9
	b.ne	LBB2_66
; %bb.65:                               ;   in Loop: Header=BB2_64 Depth=2
	mov	w20, #2                         ; =0x2
	b	LBB2_68
LBB2_66:                                ;   in Loop: Header=BB2_64 Depth=2
	madd	x20, x7, x14, x10
	ldr	w20, [x20]
	sub	x21, x20, #1
	cmp	w20, #3
	csel	x20, x1, xzr, eq
	cmp	x21, #2
	b.hs	LBB2_68
; %bb.67:                               ;   in Loop: Header=BB2_64 Depth=2
	mov	w20, #5                         ; =0x5
	b	LBB2_69
LBB2_68:                                ;   in Loop: Header=BB2_64 Depth=2
	cbz	x20, LBB2_72
LBB2_69:                                ;   in Loop: Header=BB2_64 Depth=2
	mov	x21, x19
LBB2_70:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_64 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w22, [x21], #4
	cmp	w0, w22
	b.eq	LBB2_96
; %bb.71:                               ;   in Loop: Header=BB2_70 Depth=3
	subs	x20, x20, #1
	b.ne	LBB2_70
LBB2_72:                                ;   in Loop: Header=BB2_64 Depth=2
	add	x7, x7, #1
	add	x19, x19, #60
	cmp	x7, x13
	b.ne	LBB2_64
; %bb.73:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x5, #16]
	cmn	w0, #1
	b.eq	LBB2_96
; %bb.74:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	x7, #0                          ; =0x0
	mov	x19, x11
LBB2_75:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_81 Depth 3
	cmp	x7, x9
	b.ne	LBB2_77
; %bb.76:                               ;   in Loop: Header=BB2_75 Depth=2
	mov	w20, #3                         ; =0x3
	b	LBB2_79
LBB2_77:                                ;   in Loop: Header=BB2_75 Depth=2
	madd	x20, x7, x14, x10
	ldr	w20, [x20]
	sub	x21, x20, #1
	cmp	w20, #3
	csel	x20, x1, xzr, eq
	cmp	x21, #2
	b.hs	LBB2_79
; %bb.78:                               ;   in Loop: Header=BB2_75 Depth=2
	mov	w20, #5                         ; =0x5
	b	LBB2_80
LBB2_79:                                ;   in Loop: Header=BB2_75 Depth=2
	cbz	x20, LBB2_83
LBB2_80:                                ;   in Loop: Header=BB2_75 Depth=2
	mov	x21, x19
LBB2_81:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_75 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w22, [x21], #4
	cmp	w0, w22
	b.eq	LBB2_96
; %bb.82:                               ;   in Loop: Header=BB2_81 Depth=3
	subs	x20, x20, #1
	b.ne	LBB2_81
LBB2_83:                                ;   in Loop: Header=BB2_75 Depth=2
	add	x7, x7, #1
	add	x19, x19, #60
	cmp	x7, x13
	b.ne	LBB2_75
; %bb.84:                               ;   in Loop: Header=BB2_5 Depth=1
	cmp	w6, #3
	b.eq	LBB2_27
; %bb.85:                               ;   in Loop: Header=BB2_5 Depth=1
	ldr	w0, [x5, #20]
	cmn	w0, #1
	b.eq	LBB2_96
; %bb.86:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	x6, #0                          ; =0x0
	mov	x7, x11
LBB2_87:                                ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_93 Depth 3
	cmp	x6, x9
	b.ne	LBB2_89
; %bb.88:                               ;   in Loop: Header=BB2_87 Depth=2
	mov	w19, #4                         ; =0x4
	b	LBB2_91
LBB2_89:                                ;   in Loop: Header=BB2_87 Depth=2
	madd	x19, x6, x14, x10
	ldr	w19, [x19]
	sub	x20, x19, #1
	cmp	w19, #3
	csel	x19, x1, xzr, eq
	cmp	x20, #2
	b.hs	LBB2_91
; %bb.90:                               ;   in Loop: Header=BB2_87 Depth=2
	mov	w19, #5                         ; =0x5
	b	LBB2_92
LBB2_91:                                ;   in Loop: Header=BB2_87 Depth=2
	cbz	x19, LBB2_95
LBB2_92:                                ;   in Loop: Header=BB2_87 Depth=2
	mov	x20, x7
LBB2_93:                                ;   Parent Loop BB2_5 Depth=1
                                        ;     Parent Loop BB2_87 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w21, [x20], #4
	cmp	w0, w21
	b.eq	LBB2_96
; %bb.94:                               ;   in Loop: Header=BB2_93 Depth=3
	subs	x19, x19, #1
	b.ne	LBB2_93
LBB2_95:                                ;   in Loop: Header=BB2_87 Depth=2
	add	x6, x6, #1
	add	x7, x7, #60
	cmp	x6, x13
	b.ne	LBB2_87
	b	LBB2_27
LBB2_96:
	mov	w0, #8                          ; =0x8
	b	LBB2_98
LBB2_97:
	mov	w0, #6                          ; =0x6
LBB2_98:
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
                                        ; kill: def $w0 killed $w0 killed $x0
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_decode ; -- Begin function nvm_multi_nominal_decode
	.globl	_nvm_multi_nominal_decode
	.p2align	2
_nvm_multi_nominal_decode:              ; @nvm_multi_nominal_decode
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x8, LBB3_4
; %bb.1:
	cbz	x2, LBB3_4
; %bb.2:
	mov	x9, #-4113                      ; =0xffffffffffffefef
	mov	x10, #-4097                     ; =0xffffffffffffefff
	add	x9, x1, x9
	cmp	x9, x10
	b.hs	LBB3_5
; %bb.3:
	mov	w0, #2                          ; =0x2
LBB3_4:
	ret
LBB3_5:
	ldrh	w9, [x8]
	cmp	w9, #3
	b.ne	LBB3_9
; %bb.6:
	ldrb	w9, [x8, #2]
	ldrb	w10, [x8, #3]
	orr	w9, w10, w9
	cbnz	w9, LBB3_8
; %bb.7:
	ldr	w9, [x8, #12]
	cbz	w9, LBB3_10
LBB3_8:
	mov	w0, #6                          ; =0x6
	ret
LBB3_9:
	mov	w0, #3                          ; =0x3
	ret
LBB3_10:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #3856
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	ldr	w20, [x8, #4]
	sub	w9, w20, #65
	cmn	w9, #64
	b.hs	LBB3_12
; %bb.11:
	mov	w0, #5                          ; =0x5
	b	LBB3_21
LBB3_12:
	ldr	w9, [x8, #8]
	cmp	w9, #64
	b.ne	LBB3_20
; %bb.13:
	mov	w9, #16                         ; =0x10
	orr	x9, x9, x20, lsl #6
	cmp	x1, x9
	b.ne	LBB3_20
; %bb.14:
	mov	x19, x2
	add	x21, sp, #12
	mov	x22, x8
	add	x0, x21, #4
	mov	w1, #3840                       ; =0xf00
	bl	_bzero
	mov	x8, #0                          ; =0x0
	str	w20, [sp, #12]
	add	x9, x21, #28
	add	x10, x22, #22
LBB3_15:                                ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-6]
	cmp	x8, x11
	b.ne	LBB3_22
; %bb.16:                               ;   in Loop: Header=BB3_15 Depth=1
	ldurh	w11, [x10, #-2]
	stur	w11, [x9, #-24]
	ldrb	w11, [x10]
	ldrb	w12, [x10, #1]
	orr	w11, w12, w11
	cbnz	w11, LBB3_23
; %bb.17:                               ;   in Loop: Header=BB3_15 Depth=1
	sub	x11, x9, #20
	ldur	q0, [x10, #2]
	str	q0, [x11]
	ldur	w12, [x10, #18]
	str	w12, [x11, #16]
	ldur	q0, [x10, #22]
	ldur	q1, [x10, #38]
	stp	q0, q1, [x9]
	ldur	w11, [x10, #54]
	str	w11, [x9, #32]
	add	x8, x8, #1
	add	x9, x9, #60
	add	x10, x10, #64
	cmp	x20, x8
	b.ne	LBB3_15
; %bb.18:
	add	x0, sp, #12
	bl	_nvm_multi_nominal_check
	cbnz	w0, LBB3_21
; %bb.19:
	add	x1, sp, #12
	mov	x0, x19
	mov	w2, #3844                       ; =0xf04
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	b	LBB3_21
LBB3_20:
	mov	w0, #2                          ; =0x2
LBB3_21:
	add	sp, sp, #3856
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB3_22:
	mov	w0, #7                          ; =0x7
	b	LBB3_21
LBB3_23:
	mov	w0, #6                          ; =0x6
	b	LBB3_21
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_multi_nominal_encode ; -- Begin function nvm_multi_nominal_encode
	.globl	_nvm_multi_nominal_encode
	.p2align	2
_nvm_multi_nominal_encode:              ; @nvm_multi_nominal_encode
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	mov	w9, #4128                       ; =0x1020
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
Lloh4:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh5:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh6:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	cbz	x3, LBB4_5
; %bb.1:
	mov	x19, x3
	mov	x23, x2
	mov	x20, x1
	mov	x22, x0
	bl	_nvm_multi_nominal_check
	cbnz	w0, LBB4_11
; %bb.2:
	ldr	w24, [x22]
	mov	w8, #16                         ; =0x10
	orr	x21, x8, x24, lsl #6
	cbz	x20, LBB4_10
; %bb.3:
	cmp	x23, x21
	b.hs	LBB4_6
; %bb.4:
	mov	w0, #2                          ; =0x2
	b	LBB4_11
LBB4_5:
	mov	w0, #1                          ; =0x1
	b	LBB4_11
LBB4_6:
	add	x23, sp, #8
	add	x0, x23, #1
	mov	w1, #4111                       ; =0x100f
	bl	_bzero
	mov	w8, #3                          ; =0x3
	strb	w8, [sp, #8]
	strb	w24, [sp, #12]
	lsr	w8, w24, #8
	strb	w8, [sp, #13]
	lsr	w8, w24, #16
	strb	w8, [sp, #14]
	lsr	w8, w24, #24
	strb	w8, [sp, #15]
	mov	w8, #64                         ; =0x40
	strb	w8, [sp, #16]
	strb	wzr, [sp, #18]
	cbz	w24, LBB4_9
; %bb.7:
	mov	x8, #0                          ; =0x0
	add	x9, x23, #16
	add	x10, x22, #4
	mov	w11, #60                        ; =0x3c
LBB4_8:                                 ; =>This Inner Loop Header: Depth=1
	madd	x12, x8, x11, x10
	ldp	w13, w14, [x12]
	lsl	w15, w8, #6
	add	x15, x9, x15
	strb	w13, [x15, #4]
	str	w14, [x15, #8]
	ldp	x13, x14, [x12, #40]
	stur	x13, [x15, #44]
	str	w8, [x15]
	ldur	q0, [x12, #8]
	stur	q0, [x15, #12]
	ldur	q0, [x12, #24]
	stur	q0, [x15, #28]
	stur	x14, [x15, #52]
	ldr	w12, [x12, #56]
	str	w12, [x15, #60]
	add	x8, x8, #1
	cmp	x8, x24
	b.ne	LBB4_8
LBB4_9:
	add	x1, sp, #8
	mov	x0, x20
	mov	x2, x21
	bl	_memcpy
LBB4_10:
	mov	w0, #0                          ; =0x0
	str	x21, [x19]
LBB4_11:
	ldur	x8, [x29, #-72]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_13
; %bb.12:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #32
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB4_13:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh4, Lloh5, Lloh6
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	3, 0x0                          ; @switch.table.nvm_multi_nominal_check
l_switch.table.nvm_multi_nominal_check:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
	.quad	7                               ; 0x7

.subsections_via_symbols
