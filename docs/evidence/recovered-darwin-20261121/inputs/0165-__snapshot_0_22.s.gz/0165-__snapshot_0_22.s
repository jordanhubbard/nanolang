	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_service_storage_bound ; -- Begin function nl_socket_service_storage_bound
	.p2align	2
_nl_socket_service_storage_bound:       ; @nl_socket_service_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_5
; %bb.1:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, sp, #8
	bl	_nl_cap_private_storage_bound
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB0_4
; %bb.2:
	ldr	x8, [sp, #8]
	cmn	x8, #2585
	b.hi	LBB0_4
; %bb.3:
	add	x8, x8, #2584
	str	x8, [x19]
	mov	w0, #1                          ; =0x1
LBB0_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB0_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_service_create       ; -- Begin function nl_socket_service_create
	.p2align	2
_nl_socket_service_create:              ; @nl_socket_service_create
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB1_7
; %bb.1:
	adrp	x21, _socket_context_counter@PAGE
	ldr	x8, [x21, _socket_context_counter@PAGEOFF]
	cmn	x8, #1
	b.eq	LBB1_8
; %bb.2:
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #2584                       ; =0xa18
	bl	_calloc
	cbz	x0, LBB1_10
; %bb.3:
	mov	x20, x0
	bl	_nl_cap_table_create
	str	x0, [x20]
	cbz	x0, LBB1_9
; %bb.4:
	mov	x8, #0                          ; =0x0
	mov	w9, #-1                         ; =0xffffffff
LBB1_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x10, x20, x8
	str	w9, [x10, #24]
	str	w9, [x10, #64]
	str	w9, [x10, #104]
	str	w9, [x10, #144]
	add	x8, x8, #160
	cmp	x8, #2560
	b.ne	LBB1_5
; %bb.6:
	ldr	x8, [x21, _socket_context_counter@PAGEOFF]
	add	x8, x8, #1
	str	x8, [x21, _socket_context_counter@PAGEOFF]
	str	x8, [x20, #8]
	str	x20, [x22]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
	b	LBB1_12
LBB1_7:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #4                          ; =0x4
	b	LBB1_11
LBB1_8:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #9                          ; =0x9
	b	LBB1_11
LBB1_9:
	mov	x0, x20
	bl	_free
LBB1_10:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #10                         ; =0xa
LBB1_11:
	str	w8, [x19]
LBB1_12:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_acquire_pair         ; -- Begin function nl_socket_acquire_pair
	.p2align	2
_nl_socket_acquire_pair:                ; @nl_socket_acquire_pair
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh0:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x9, [x9]
	str	x9, [sp, #40]
	cbz	x0, LBB2_3
; %bb.1:
	ldrb	w9, [x0, #16]
	cmp	w9, #1
	b.ne	LBB2_5
; %bb.2:
	mov	w9, #5                          ; =0x5
	b	LBB2_4
LBB2_3:
	mov	w9, #4                          ; =0x4
LBB2_4:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	b	LBB2_8
LBB2_5:
	cbz	x3, LBB2_7
; %bb.6:
	orr	w9, w2, w1
	mov	w10, #-20                       ; =0xffffffec
	tst	w9, w10
	b.eq	LBB2_11
LBB2_7:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #4                          ; =0x4
LBB2_8:
	str	w9, [x8]
LBB2_9:
	ldr	x8, [sp, #40]
Lloh3:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh4:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh5:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_40
; %bb.10:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB2_11:
	add	x9, x0, #1988
	add	x10, x0, #2028
	add	x11, x0, #2068
	add	x12, x0, #2108
	add	x13, x0, #2148
	add	x14, x0, #2188
	add	x15, x0, #2228
	add	x16, x0, #2308
	add	x17, x0, #2348
	add	x4, x0, #2388
	add	x5, x0, #2428
	add	x6, x0, #2468
	add	x7, x0, #2508
	ldr	b0, [x0, #1948]
	ld1.b	{ v0 }[1], [x9]
	ld1.b	{ v0 }[2], [x10]
	ld1.b	{ v0 }[3], [x11]
	ld1.b	{ v0 }[4], [x12]
	ld1.b	{ v0 }[5], [x13]
	ld1.b	{ v0 }[6], [x14]
	add	x9, x0, #2548
	ld1.b	{ v0 }[7], [x15]
	ldr	b1, [x0, #2268]
	ld1.b	{ v1 }[1], [x16]
	ld1.b	{ v1 }[2], [x17]
	ld1.b	{ v1 }[3], [x4]
	ld1.b	{ v1 }[4], [x5]
	ld1.b	{ v1 }[5], [x6]
	ld1.b	{ v1 }[6], [x7]
	ld1.b	{ v1 }[7], [x9]
	zip1.2d	v0, v0, v1
	movi.16b	v1, #1
	eor.16b	v3, v0, v1
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	udot.4s	v2, v3, v1
	add	x9, x0, #1348
	add	x10, x0, #1388
	add	x11, x0, #1428
	add	x12, x0, #1468
	add	x13, x0, #1508
	add	x14, x0, #1548
	add	x15, x0, #1588
	add	x16, x0, #1668
	add	x17, x0, #1708
	add	x4, x0, #1748
	add	x5, x0, #1788
	add	x6, x0, #1828
	add	x7, x0, #1868
	ldr	b3, [x0, #1308]
	ld1.b	{ v3 }[1], [x9]
	ld1.b	{ v3 }[2], [x10]
	ld1.b	{ v3 }[3], [x11]
	ld1.b	{ v3 }[4], [x12]
	ld1.b	{ v3 }[5], [x13]
	add	x9, x0, #1908
	ld1.b	{ v3 }[6], [x14]
	ld1.b	{ v3 }[7], [x15]
	ldr	b4, [x0, #1628]
	ld1.b	{ v4 }[1], [x16]
	ld1.b	{ v4 }[2], [x17]
	ld1.b	{ v4 }[3], [x4]
	ld1.b	{ v4 }[4], [x5]
	ld1.b	{ v4 }[5], [x6]
	ld1.b	{ v4 }[6], [x7]
	ld1.b	{ v4 }[7], [x9]
	zip1.2d	v3, v3, v4
	eor.16b	v4, v3, v1
	movi.2d	v3, #0000000000000000
	udot.4s	v3, v4, v1
	add	x9, x0, #708
	add	x10, x0, #748
	add	x11, x0, #788
	add	x12, x0, #828
	add	x13, x0, #868
	add	x14, x0, #908
	add	x15, x0, #948
	add	x16, x0, #1028
	add	x17, x0, #1068
	add	x4, x0, #1108
	add	x5, x0, #1148
	add	x6, x0, #1188
	add	x7, x0, #1228
	ldr	b4, [x0, #668]
	ld1.b	{ v4 }[1], [x9]
	ld1.b	{ v4 }[2], [x10]
	ld1.b	{ v4 }[3], [x11]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x13]
	add	x9, x0, #1268
	ld1.b	{ v4 }[6], [x14]
	ld1.b	{ v4 }[7], [x15]
	ldr	b5, [x0, #988]
	ld1.b	{ v5 }[1], [x16]
	ld1.b	{ v5 }[2], [x17]
	ld1.b	{ v5 }[3], [x4]
	ld1.b	{ v5 }[4], [x5]
	ld1.b	{ v5 }[5], [x6]
	ld1.b	{ v5 }[6], [x7]
	ld1.b	{ v5 }[7], [x9]
	zip1.2d	v4, v4, v5
	eor.16b	v4, v4, v1
	movi.2d	v5, #0000000000000000
	udot.4s	v5, v4, v1
	add	x9, x0, #68
	add	x10, x0, #108
	add	x11, x0, #148
	add	x12, x0, #188
	add	x13, x0, #228
	add	x14, x0, #268
	add	x15, x0, #308
	add	x16, x0, #388
	add	x17, x0, #428
	add	x4, x0, #468
	add	x5, x0, #508
	add	x6, x0, #548
	add	x7, x0, #588
	ldr	b4, [x0, #28]
	ld1.b	{ v4 }[1], [x9]
	ld1.b	{ v4 }[2], [x10]
	ld1.b	{ v4 }[3], [x11]
	ld1.b	{ v4 }[4], [x12]
	ld1.b	{ v4 }[5], [x13]
	add	x9, x0, #628
	ld1.b	{ v4 }[6], [x14]
	ld1.b	{ v4 }[7], [x15]
	ldr	b6, [x0, #348]
	ld1.b	{ v6 }[1], [x16]
	ld1.b	{ v6 }[2], [x17]
	ld1.b	{ v6 }[3], [x4]
	ld1.b	{ v6 }[4], [x5]
	ld1.b	{ v6 }[5], [x6]
	ld1.b	{ v6 }[6], [x7]
	ld1.b	{ v6 }[7], [x9]
	zip1.2d	v4, v4, v6
	eor.16b	v4, v4, v1
	movi.2d	v6, #0000000000000000
	udot.4s	v6, v4, v1
	add.4s	v1, v5, v6
	add.4s	v2, v2, v3
	add.4s	v1, v2, v1
	addv.4s	s1, v1
	fmov	w9, s1
	cmp	w9, #2
	b.hs	LBB2_13
; %bb.12:
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #8                          ; =0x8
	b	LBB2_8
LBB2_13:
	mov	x20, x2
	mov	x22, x3
	mov	x21, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp]
	mov	x19, x0
	ldr	x0, [x0]
Lloh6:
	adrp	x8, l_.str@PAGE
Lloh7:
	add	x8, x8, l_.str@PAGEOFF
Lloh8:
	adrp	x2, l_.str.1@PAGE
Lloh9:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x4, sp, #8
	mov	x3, x1
	mov	x1, x8
	bl	_nl_cap_private_mint
	mov	x8, x0
	mov	w2, #0                          ; =0x0
	cmp	w0, #5
	b.gt	LBB2_16
; %bb.14:
	sub	w9, w8, #4
	cmp	w9, #2
	b.hs	LBB2_20
LBB2_15:
	mov	x4, x21
	mov	x0, x19
	mov	w8, #7                          ; =0x7
	b	LBB2_35
LBB2_16:
	cmp	w8, #6
	b.eq	LBB2_28
; %bb.17:
	cmp	w8, #9
	mov	x0, x19
	b.eq	LBB2_29
; %bb.18:
	cmp	w8, #8
	mov	x4, x21
	b.ne	LBB2_34
LBB2_19:
	mov	w8, #9                          ; =0x9
	b	LBB2_35
LBB2_20:
	mov	x4, x21
	mov	x0, x19
	cbnz	w8, LBB2_34
; %bb.21:
	ldr	x0, [x0]
	add	x23, sp, #8
Lloh10:
	adrp	x1, l_.str@PAGE
Lloh11:
	add	x1, x1, l_.str@PAGEOFF
Lloh12:
	adrp	x2, l_.str.1@PAGE
Lloh13:
	add	x2, x2, l_.str.1@PAGEOFF
	add	x4, x23, #16
	mov	x3, x20
	bl	_nl_cap_private_mint
	mov	x8, x0
	mov	w2, #1                          ; =0x1
	cmp	w0, #5
	b.gt	LBB2_31
; %bb.22:
	sub	w9, w8, #4
	cmp	w9, #2
	b.lo	LBB2_15
; %bb.23:
	mov	x4, x21
	mov	x0, x19
	cbnz	w8, LBB2_34
; %bb.24:
	bl	___error
	str	wzr, [x0]
	mov	x3, sp
	mov	w0, #1                          ; =0x1
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	bl	_socketpair
	mov	x20, x0
	bl	___error
	cbnz	w20, LBB2_39
; %bb.25:
	str	wzr, [x0]
	ldr	w0, [sp]
	bl	_socket_configure
	tbz	w0, #0, LBB2_38
; %bb.26:
	bl	___error
	str	wzr, [x0]
	ldr	w0, [sp, #4]
	bl	_socket_configure
	cbz	w0, LBB2_38
; %bb.27:
	add	x8, x19, #24
	mov	w9, #40                         ; =0x28
	ldr	w10, [sp, #16]
	ldr	w11, [sp, #32]
	umaddl	x10, w10, w9, x8
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #8]
	stur	q0, [x10, #8]
	umaddl	x8, w11, w9, x8
	ldur	q0, [x23, #16]
	stur	q0, [x8, #8]
	ldr	x9, [x19, #8]
	ldp	w11, w12, [sp]
	str	w11, [x10]
	mov	w11, #1                         ; =0x1
	strb	w11, [x10, #4]
	sturh	wzr, [x10, #5]
	strb	wzr, [x10, #7]
	stp	xzr, xzr, [x10, #24]
	str	w12, [x8]
	strb	w11, [x8, #4]
	sturh	wzr, [x8, #5]
	strb	wzr, [x8, #7]
	stp	xzr, xzr, [x8, #24]
	str	x9, [x22]
	stur	q1, [x22, #8]
	str	x9, [x22, #24]
	ldur	q0, [x23, #16]
	str	q0, [x22, #32]
	str	xzr, [x21, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x21]
	b	LBB2_9
LBB2_28:
	mov	w8, #8                          ; =0x8
	mov	x4, x21
	mov	x0, x19
	b	LBB2_35
LBB2_29:
	mov	x4, x21
LBB2_30:
	mov	w8, #11                         ; =0xb
	b	LBB2_35
LBB2_31:
	cmp	w8, #6
	mov	x4, x21
	b.eq	LBB2_37
; %bb.32:
	cmp	w8, #8
	mov	x0, x19
	b.eq	LBB2_19
; %bb.33:
	cmp	w8, #9
	b.eq	LBB2_30
LBB2_34:
	mov	w8, #6                          ; =0x6
LBB2_35:
	movi.2d	v0, #0000000000000000
	str	xzr, [x4, #32]
	stp	q0, q0, [x4]
	str	w8, [x4]
	add	x1, sp, #8
	mov	x3, sp
LBB2_36:
	bl	_socket_rollback
	b	LBB2_9
LBB2_37:
	mov	w8, #8                          ; =0x8
	mov	x0, x19
	b	LBB2_35
LBB2_38:
	bl	___error
LBB2_39:
	ldr	w8, [x0]
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	mov	w10, #3                         ; =0x3
	movi.2d	v0, #0000000000000000
	mov	x4, x21
	stur	q0, [x21, #8]
	stur	q0, [x21, #24]
	cmp	w8, #4
	csel	w9, w10, w9, eq
	stp	w9, w8, [x21]
	add	x1, sp, #8
	mov	x3, sp
	mov	x0, x19
	mov	w2, #2                          ; =0x2
	b	LBB2_36
LBB2_40:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpLdrGotLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_rollback
_socket_rollback:                       ; @socket_rollback
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x4
	mov	x21, x3
	mov	x20, x0
	cbz	w2, LBB3_10
; %bb.1:
	mov	x23, x2
	mov	x22, x1
	ldr	x0, [x20]
	bl	_nl_cap_private_consume
	cbz	w0, LBB3_5
; %bb.2:
	ldrb	w8, [x19, #34]
	tbnz	w8, #0, LBB3_4
; %bb.3:
	str	wzr, [x19, #8]
LBB3_4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #34]
LBB3_5:
	cmp	w23, #1
	b.eq	LBB3_10
; %bb.6:
	ldr	x0, [x20]
	add	x1, x22, #16
	bl	_nl_cap_private_consume
	cbz	w0, LBB3_10
; %bb.7:
	ldrb	w8, [x19, #34]
	tbnz	w8, #0, LBB3_9
; %bb.8:
	str	wzr, [x19, #8]
LBB3_9:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #34]
LBB3_10:
	ldr	w22, [x21]
	tbnz	w22, #31, LBB3_17
; %bb.11:
	ldr	w8, [x19, #24]
	add	w8, w8, #1
	str	w8, [x19, #24]
	bl	___error
	str	wzr, [x0]
	mov	x0, x22
	bl	_close
	mov	x22, x0
	bl	___error
	cbz	w22, LBB3_24
; %bb.12:
	ldr	w8, [x0]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, #35]
	ldrb	w10, [x20, #17]
	tbnz	w10, #0, LBB3_14
; %bb.13:
	str	w8, [x20, #20]
LBB3_14:
	strb	w9, [x20, #17]
	ldrb	w9, [x19, #34]
	tbnz	w9, #0, LBB3_16
; %bb.15:
	str	w8, [x19, #8]
LBB3_16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #34]
LBB3_17:
	ldr	w21, [x21, #4]
	tbnz	w21, #31, LBB3_26
LBB3_18:
	ldr	w8, [x19, #24]
	add	w8, w8, #1
	str	w8, [x19, #24]
	bl	___error
	str	wzr, [x0]
	mov	x0, x21
	bl	_close
	mov	x21, x0
	bl	___error
	cbz	w21, LBB3_25
; %bb.19:
	ldr	w8, [x0]
	mov	w9, #1                          ; =0x1
	strb	w9, [x19, #35]
	ldrb	w10, [x20, #17]
	tbnz	w10, #0, LBB3_21
; %bb.20:
	str	w8, [x20, #20]
LBB3_21:
	strb	w9, [x20, #17]
	ldrb	w9, [x19, #34]
	tbnz	w9, #0, LBB3_23
; %bb.22:
	str	w8, [x19, #8]
LBB3_23:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #34]
	b	LBB3_26
LBB3_24:
	ldr	w8, [x19, #28]
	add	w8, w8, #1
	str	w8, [x19, #28]
	ldr	w21, [x21, #4]
	tbz	w21, #31, LBB3_18
	b	LBB3_26
LBB3_25:
	ldr	w8, [x19, #28]
	add	w8, w8, #1
	str	w8, [x19, #28]
LBB3_26:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_configure
_socket_configure:                      ; @socket_configure
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w1, #3                          ; =0x3
	bl	_fcntl
	tbnz	w0, #31, LBB4_5
; %bb.1:
	orr	w8, w0, #0x4
	str	x8, [sp]
	mov	x0, x19
	mov	w1, #4                          ; =0x4
	bl	_fcntl
	tbnz	w0, #31, LBB4_5
; %bb.2:
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	bl	_fcntl
	tbnz	w0, #31, LBB4_5
; %bb.3:
	orr	w8, w0, #0x1
	str	x8, [sp]
	mov	x0, x19
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbnz	w0, #31, LBB4_5
; %bb.4:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	add	x3, sp, #12
	mov	x0, x19
	mov	w1, #65535                      ; =0xffff
	mov	w2, #4130                       ; =0x1022
	mov	w4, #4                          ; =0x4
	bl	_setsockopt
	cmp	w0, #0
	cset	w0, eq
	b	LBB4_6
LBB4_5:
	mov	w0, #0                          ; =0x0
LBB4_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_acquire_tcp          ; -- Begin function nl_socket_acquire_tcp
	.p2align	2
_nl_socket_acquire_tcp:                 ; @nl_socket_acquire_tcp
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh14:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh15:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh16:
	ldr	x9, [x9]
	str	x9, [sp, #56]
	cbz	x0, LBB5_3
; %bb.1:
	ldrb	w9, [x0, #16]
	cmp	w9, #1
	b.ne	LBB5_5
; %bb.2:
	mov	w9, #5                          ; =0x5
	b	LBB5_4
LBB5_3:
	mov	w9, #4                          ; =0x4
LBB5_4:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	b	LBB5_26
LBB5_5:
	mov	w9, #-20                        ; =0xffffffec
	tst	w2, w9
	b.ne	LBB5_25
; %bb.6:
	cbz	x1, LBB5_25
; %bb.7:
	cbz	x3, LBB5_25
; %bb.8:
	ldrh	w10, [x1, #20]
	cbz	w10, LBB5_25
; %bb.9:
	sub	x9, x3, x1
	cmp	x9, #28
	cset	w9, lo
	subs	x11, x1, x3
	cmp	x11, #24
	cset	w11, lo
	cmp	x1, x3
	csel	w9, w11, w9, hi
	cmp	w9, #1
	b.eq	LBB5_25
; %bb.10:
	stp	xzr, xzr, [sp, #16]
	str	wzr, [sp, #40]
	str	xzr, [sp, #32]
	ldr	w9, [x1]
	cmp	w9, #6
	b.eq	LBB5_29
; %bb.11:
	cmp	w9, #4
	b.ne	LBB5_25
; %bb.12:
	ldr	w9, [x1, #24]
	cbnz	w9, LBB5_25
; %bb.13:
	ldrb	w9, [x1, #8]
	cbnz	w9, LBB5_25
; %bb.14:
	ldrb	w9, [x1, #9]
	cbnz	w9, LBB5_25
; %bb.15:
	ldrb	w9, [x1, #10]
	cbnz	w9, LBB5_25
; %bb.16:
	ldrb	w9, [x1, #11]
	cbnz	w9, LBB5_25
; %bb.17:
	ldrb	w9, [x1, #12]
	cbnz	w9, LBB5_25
; %bb.18:
	ldrb	w9, [x1, #13]
	cbnz	w9, LBB5_25
; %bb.19:
	ldrb	w9, [x1, #14]
	cbnz	w9, LBB5_25
; %bb.20:
	ldrb	w9, [x1, #15]
	cbnz	w9, LBB5_25
; %bb.21:
	ldrb	w9, [x1, #16]
	cbnz	w9, LBB5_25
; %bb.22:
	ldrb	w9, [x1, #17]
	cbnz	w9, LBB5_25
; %bb.23:
	ldrb	w9, [x1, #18]
	cbnz	w9, LBB5_25
; %bb.24:
	ldrb	w9, [x1, #19]
	cbz	w9, LBB5_51
LBB5_25:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #4                          ; =0x4
LBB5_26:
	str	w9, [x8]
LBB5_27:
	ldr	x8, [sp, #56]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_50
; %bb.28:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB5_29:
	mov	x9, x2
	mov	x22, x3
	mov	x23, x8
	mov	w21, #30                        ; =0x1e
	strb	w21, [sp, #17]
	rev16	w8, w10
	strh	w8, [sp, #18]
	ldr	w8, [x1, #24]
	str	w8, [sp, #40]
	ldur	q0, [x1, #4]
	stur	q0, [sp, #24]
	mov	w20, #28                        ; =0x1c
LBB5_30:
	strb	w20, [sp, #16]
	mov	x19, x0
	ldr	x0, [x0]
Lloh20:
	adrp	x1, l_.str@PAGE
Lloh21:
	add	x1, x1, l_.str@PAGEOFF
Lloh22:
	adrp	x2, l_.str.2@PAGE
Lloh23:
	add	x2, x2, l_.str.2@PAGEOFF
	mov	x4, sp
	mov	x3, x9
	bl	_nl_cap_private_mint
	cmp	w0, #5
	b.gt	LBB5_33
; %bb.31:
	sub	w8, w0, #4
	cmp	w8, #2
	b.hs	LBB5_37
; %bb.32:
	mov	w8, #7                          ; =0x7
	b	LBB5_46
LBB5_33:
	cmp	w0, #6
	b.eq	LBB5_43
; %bb.34:
	cmp	w0, #8
	b.eq	LBB5_45
; %bb.35:
	cmp	w0, #9
	b.ne	LBB5_44
; %bb.36:
	mov	w8, #11                         ; =0xb
	b	LBB5_46
LBB5_37:
	cbnz	w0, LBB5_44
; %bb.38:
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #48]
	bl	___error
	str	wzr, [x0]
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_socket
	str	w0, [sp, #48]
	tbnz	w0, #31, LBB5_47
; %bb.39:
	mov	x21, x0
	bl	_socket_configure
	tbz	w0, #0, LBB5_47
; %bb.40:
	bl	___error
	str	wzr, [x0]
	add	x1, sp, #16
	mov	x0, x21
	mov	x2, x20
	bl	_connect
	mov	x20, x0
	bl	___error
	cbz	w20, LBB5_49
; %bb.41:
	ldr	w8, [x0]
	cmp	w8, #36
	b.eq	LBB5_49
; %bb.42:
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	mov	w10, #3                         ; =0x3
	movi.2d	v0, #0000000000000000
	mov	x4, x23
	stur	q0, [x23, #24]
	stur	q0, [x23, #8]
	b	LBB5_48
LBB5_43:
	mov	w8, #8                          ; =0x8
	b	LBB5_46
LBB5_44:
	mov	w8, #6                          ; =0x6
	b	LBB5_46
LBB5_45:
	mov	w8, #9                          ; =0x9
LBB5_46:
	movi.2d	v0, #0000000000000000
	str	xzr, [x23, #32]
	stp	q0, q0, [x23]
	str	w8, [x23]
	b	LBB5_27
LBB5_47:
	bl	___error
	ldr	w8, [x0]
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	mov	w10, #3                         ; =0x3
	movi.2d	v0, #0000000000000000
	mov	x4, x23
	stur	q0, [x23, #8]
	stur	q0, [x23, #24]
LBB5_48:
	cmp	w8, #4
	csel	w9, w10, w9, eq
	stp	w9, w8, [x23]
	mov	x1, sp
	add	x3, sp, #48
	mov	x0, x19
	mov	w2, #1                          ; =0x1
	bl	_socket_rollback
	b	LBB5_27
LBB5_49:
	mov	w8, #40                         ; =0x28
	ldr	w9, [sp, #8]
	umaddl	x8, w9, w8, x19
	str	w21, [x8, #24]
	cmp	w20, #0
	cset	w9, ne
	mov	w10, #1                         ; =0x1
	strb	w10, [x8, #28]
	strb	wzr, [x8, #31]
	sturh	wzr, [x8, #29]
	ldr	q0, [sp]
	str	q0, [x8, #32]
	strb	w10, [x8, #48]
	strb	wzr, [x8, #51]
	sturh	wzr, [x8, #49]
	str	xzr, [x8, #56]
	str	w9, [x8, #52]
	ldr	x8, [x19, #8]
	str	x8, [x22]
	stur	q0, [x22, #8]
	str	xzr, [x23, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23]
	strb	w9, [x23, #36]
	b	LBB5_27
LBB5_50:
	bl	___stack_chk_fail
LBB5_51:
	mov	x9, x2
	mov	x22, x3
	mov	x23, x8
	mov	w21, #2                         ; =0x2
	strb	w21, [sp, #17]
	rev16	w8, w10
	strh	w8, [sp, #18]
	ldr	w8, [x1, #4]
	str	w8, [sp, #20]
	mov	w20, #16                        ; =0x10
	b	LBB5_30
	.loh AdrpLdrGotLdr	Lloh14, Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_socket_finish_connect
lCPI6_0:
	.long	2                               ; 0x2
	.long	9                               ; 0x9
lCPI6_1:
	.long	11                              ; 0xb
	.long	9                               ; 0x9
lCPI6_2:
	.long	2                               ; 0x2
	.long	5                               ; 0x5
lCPI6_3:
	.long	11                              ; 0xb
	.long	5                               ; 0x5
lCPI6_4:
	.long	2                               ; 0x2
	.long	53                              ; 0x35
lCPI6_5:
	.long	11                              ; 0xb
	.long	53                              ; 0x35
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_finish_connect
	.p2align	2
_nl_socket_finish_connect:              ; @nl_socket_finish_connect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x8
	str	xzr, [sp, #24]
	add	x3, sp, #24
	mov	w2, #0                          ; =0x0
	bl	_socket_resolve
	cbz	w0, LBB6_2
; %bb.1:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB6_15
LBB6_2:
	ldr	x20, [sp, #24]
	ldr	w8, [x20, #28]
	cmp	w8, #1
	b.ne	LBB6_14
; %bb.3:
	ldr	w8, [x20]
	mov	w9, #4                          ; =0x4
	stp	w8, w9, [sp, #16]
	bl	___error
	str	wzr, [x0]
	add	x0, sp, #16
	mov	w1, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	bl	_poll
	tbnz	w0, #31, LBB6_9
; %bb.4:
	cbz	w0, LBB6_12
; %bb.5:
	ldrh	w8, [sp, #22]
	tbnz	w8, #5, LBB6_16
; %bb.6:
	tst	w8, #0x1c
	b.eq	LBB6_12
; %bb.7:
	mov	w8, #4                          ; =0x4
	stp	w8, wzr, [sp, #8]
	bl	___error
	str	wzr, [x0]
	ldr	w0, [x20]
	add	x3, sp, #12
	add	x4, sp, #8
	mov	w1, #65535                      ; =0xffff
	mov	w2, #4103                       ; =0x1007
	bl	_getsockopt
	cbz	w0, LBB6_17
; %bb.8:
	bl	___error
	ldr	w1, [x0]
	mov	x8, x19
	mov	x0, x20
	bl	_socket_connect_error
	b	LBB6_15
LBB6_9:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #35
	b.eq	LBB6_11
; %bb.10:
	cmp	w8, #4
	b.ne	LBB6_19
LBB6_11:
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #24]
	mov	w10, #3                         ; =0x3
	cmp	w8, #4
	csel	w9, w10, w9, eq
	stur	q0, [x19, #8]
	stp	w9, w8, [x19]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #36]
	b	LBB6_15
LBB6_12:
	ldr	w8, [x20, #28]
	cmp	w8, #1
	b.ne	LBB6_14
; %bb.13:
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	strb	w8, [x19, #36]
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
	b	LBB6_15
LBB6_14:
	mov	w9, #11                         ; =0xb
	cmp	w8, #2
	csel	w8, w9, wzr, eq
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #24]
	stur	q0, [x19, #8]
	ldr	w9, [x20, #32]
	stp	w8, w9, [x19]
LBB6_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB6_16:
Lloh24:
	adrp	x8, lCPI6_0@PAGE
Lloh25:
	ldr	d0, [x8, lCPI6_0@PAGEOFF]
	stur	d0, [x20, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
Lloh26:
	adrp	x8, lCPI6_1@PAGE
Lloh27:
	ldr	d0, [x8, lCPI6_1@PAGEOFF]
	str	d0, [x19]
	b	LBB6_15
LBB6_17:
	ldr	w8, [sp, #8]
	cmp	w8, #4
	b.ne	LBB6_20
; %bb.18:
	ldr	w8, [sp, #12]
	cbz	w8, LBB6_21
LBB6_19:
	mov	w9, #2                          ; =0x2
	stp	w9, w8, [x20, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
	mov	w9, #11                         ; =0xb
	stp	w9, w8, [x19]
	b	LBB6_15
LBB6_20:
Lloh28:
	adrp	x8, lCPI6_2@PAGE
Lloh29:
	ldr	d0, [x8, lCPI6_2@PAGEOFF]
	stur	d0, [x20, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
Lloh30:
	adrp	x8, lCPI6_3@PAGE
Lloh31:
	ldr	d0, [x8, lCPI6_3@PAGEOFF]
	str	d0, [x19]
	b	LBB6_15
LBB6_21:
	ldrh	w8, [sp, #22]
	and	w8, w8, #0x1c
	cmp	w8, #4
	b.ne	LBB6_23
; %bb.22:
	str	wzr, [x20, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
	ldr	w8, [x20, #32]
	stp	wzr, w8, [x19]
	b	LBB6_15
LBB6_23:
Lloh32:
	adrp	x8, lCPI6_4@PAGE
Lloh33:
	ldr	d0, [x8, lCPI6_4@PAGEOFF]
	stur	d0, [x20, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
Lloh34:
	adrp	x8, lCPI6_5@PAGE
Lloh35:
	ldr	d0, [x8, lCPI6_5@PAGEOFF]
	str	d0, [x19]
	b	LBB6_15
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_resolve
_socket_resolve:                        ; @socket_resolve
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_7
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB7_3
; %bb.2:
	mov	w0, #5                          ; =0x5
	ret
LBB7_3:
	cbz	x1, LBB7_7
; %bb.4:
	ldr	x8, [x1]
	ldr	x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB7_6
; %bb.5:
	ldr	w8, [x1, #16]
	cmp	w8, #63
	b.ls	LBB7_8
LBB7_6:
	mov	w0, #6                          ; =0x6
	ret
LBB7_7:
	mov	w0, #4                          ; =0x4
	ret
LBB7_8:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	mov	x21, x0
	ldr	x0, [x0]
	mov	x20, x1
	add	x1, x1, #8
	bl	_nl_cap_check
	cmp	w0, #5
	b.gt	LBB7_11
; %bb.9:
	sub	w8, w0, #4
	cmp	w8, #2
	b.hs	LBB7_15
; %bb.10:
	mov	w0, #7                          ; =0x7
	b	LBB7_23
LBB7_11:
	cmp	w0, #6
	b.eq	LBB7_21
; %bb.12:
	cmp	w0, #8
	b.eq	LBB7_22
; %bb.13:
	cmp	w0, #9
	b.ne	LBB7_20
; %bb.14:
	mov	w0, #11                         ; =0xb
	b	LBB7_23
LBB7_15:
	cbnz	w0, LBB7_20
; %bb.16:
	mov	w10, #40                        ; =0x28
	ldr	w11, [x20, #16]
	umaddl	x10, w11, w10, x21
	ldrb	w11, [x10, #28]
	cmp	w11, #1
	b.ne	LBB7_20
; %bb.17:
	mov	x8, x20
	add	x22, x10, #24
	ldp	x10, x11, [x22, #8]
	ldp	x12, x13, [x20, #8]
	cmp	x11, x13
	ccmp	x10, x12, #0, eq
	b.ne	LBB7_20
; %bb.18:
	ldr	x0, [x21]
	add	x1, x8, #8
	bl	_nl_cap_type_id
Lloh36:
	adrp	x1, l_.str@PAGE
Lloh37:
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB7_20
; %bb.19:
	ldr	x0, [x21]
	add	x1, x20, #8
	bl	_nl_cap_service_id
	ldrb	w8, [x22, #24]
Lloh38:
	adrp	x9, l_.str.1@PAGE
Lloh39:
	add	x9, x9, l_.str.1@PAGEOFF
Lloh40:
	adrp	x10, l_.str.2@PAGE
Lloh41:
	add	x10, x10, l_.str.2@PAGEOFF
	cmp	w8, #0
	csel	x1, x10, x9, ne
	bl	_strcmp
	cbz	w0, LBB7_24
LBB7_20:
	mov	w0, #6                          ; =0x6
	b	LBB7_23
LBB7_21:
	mov	w0, #8                          ; =0x8
	b	LBB7_23
LBB7_22:
	mov	w0, #9                          ; =0x9
LBB7_23:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB7_24:
	str	x22, [x19]
	b	LBB7_23
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_connect_error
_socket_connect_error:                  ; @socket_connect_error
	.cfi_startproc
; %bb.0:
	cmp	w1, #35
	b.eq	LBB8_2
; %bb.1:
	cmp	w1, #4
	b.ne	LBB8_3
LBB8_2:
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w1, #35
	csel	w9, w10, w9, eq
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #24]
	mov	w10, #3                         ; =0x3
	cmp	w1, #4
	csel	w9, w10, w9, eq
	stur	q0, [x8, #8]
	stp	w9, w1, [x8]
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #36]
	ret
LBB8_3:
	mov	w9, #2                          ; =0x2
	stp	w9, w1, [x0, #28]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #8]
	stur	q0, [x8, #24]
	mov	w9, #11                         ; =0xb
	stp	w9, w1, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_send                 ; -- Begin function nl_socket_send
	.p2align	2
_nl_socket_send:                        ; @nl_socket_send
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB9_5
; %bb.1:
	cmp	x3, #16, lsl #12                ; =65536
	b.hi	LBB9_5
; %bb.2:
	cbz	x3, LBB9_6
; %bb.3:
	cbz	x2, LBB9_5
; %bb.4:
	sub	x9, x1, x2
	cmp	x9, x3
	cset	w9, lo
	subs	x10, x2, x1
	cmp	x10, #24
	cset	w10, lo
	cmp	x2, x1
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB9_6
LBB9_5:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #4                          ; =0x4
	str	w9, [x8]
	ret
LBB9_6:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x22, x3
	mov	x21, x8
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	w2, #2                          ; =0x2
	bl	_socket_resolve
	cbz	w0, LBB9_9
; %bb.7:
	movi.2d	v0, #0000000000000000
	str	xzr, [x21, #32]
	stp	q0, q0, [x21]
	str	w0, [x21]
LBB9_8:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB9_9:
	ldr	x23, [sp, #8]
	ldr	w9, [x23, #28]
	mov	x8, x21
	cbz	w9, LBB9_12
; %bb.10:
	cmp	w9, #1
	b.ne	LBB9_16
; %bb.11:
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	strb	w9, [x8, #36]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	b	LBB9_8
LBB9_12:
	cbz	x22, LBB9_17
; %bb.13:
	bl	___error
	str	wzr, [x0]
	ldr	w0, [x23]
	mov	x1, x19
	mov	x2, x22
	mov	w3, #0                          ; =0x0
	bl	_send
	tbnz	x0, #63, LBB9_18
; %bb.14:
	sub	x8, x0, #1
	movi.2d	v0, #0000000000000000
	cmp	x8, x22
	b.hs	LBB9_19
; %bb.15:
	str	xzr, [x21, #32]
	stp	q0, q0, [x21]
	str	x0, [x21, #16]
	b	LBB9_8
LBB9_16:
	mov	w10, #11                        ; =0xb
	cmp	w9, #2
	csel	w9, w10, wzr, eq
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	ldr	w10, [x23, #32]
	stp	w9, w10, [x8]
	b	LBB9_8
LBB9_17:
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	b	LBB9_8
LBB9_18:
	bl	___error
	ldr	w8, [x0]
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	mov	w10, #3                         ; =0x3
	movi.2d	v0, #0000000000000000
	stur	q0, [x21, #8]
	stur	q0, [x21, #24]
	cmp	w8, #4
	csel	w9, w10, w9, eq
	stp	w9, w8, [x21]
	b	LBB9_8
LBB9_19:
	str	xzr, [x21, #32]
	stp	q0, q0, [x21]
	mov	w8, #11                         ; =0xb
	str	w8, [x21]
	b	LBB9_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_receive              ; -- Begin function nl_socket_receive
	.p2align	2
_nl_socket_receive:                     ; @nl_socket_receive
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB10_5
; %bb.1:
	cmp	x3, #16, lsl #12                ; =65536
	b.hi	LBB10_5
; %bb.2:
	cbz	x3, LBB10_6
; %bb.3:
	cbz	x2, LBB10_5
; %bb.4:
	sub	x9, x1, x2
	cmp	x9, x3
	cset	w9, lo
	subs	x10, x2, x1
	cmp	x10, #24
	cset	w10, lo
	cmp	x2, x1
	csel	w9, w10, w9, hi
	cmp	w9, #1
	b.ne	LBB10_6
LBB10_5:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #4                          ; =0x4
	str	w9, [x8]
	ret
LBB10_6:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x22, x3
	mov	x21, x8
	str	xzr, [sp, #8]
	add	x3, sp, #8
	mov	w2, #1                          ; =0x1
	bl	_socket_resolve
	cbz	w0, LBB10_9
; %bb.7:
	movi.2d	v0, #0000000000000000
	str	xzr, [x21, #32]
	stp	q0, q0, [x21]
	str	w0, [x21]
LBB10_8:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB10_9:
	ldr	x23, [sp, #8]
	ldr	w9, [x23, #28]
	mov	x8, x21
	cbz	w9, LBB10_12
; %bb.10:
	cmp	w9, #1
	b.ne	LBB10_16
; %bb.11:
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	strb	w9, [x8, #36]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	b	LBB10_8
LBB10_12:
	cbz	x22, LBB10_17
; %bb.13:
	bl	___error
	str	wzr, [x0]
	ldr	w0, [x23]
	mov	x1, x19
	mov	x2, x22
	mov	w3, #0                          ; =0x0
	bl	_recv
	tbnz	x0, #63, LBB10_18
; %bb.14:
	cmp	x0, x22
	b.ls	LBB10_19
; %bb.15:
	movi.2d	v0, #0000000000000000
	str	xzr, [x21, #32]
	stp	q0, q0, [x21]
	mov	w8, #11                         ; =0xb
	str	w8, [x21]
	b	LBB10_8
LBB10_16:
	mov	w10, #11                        ; =0xb
	cmp	w9, #2
	csel	w9, w10, wzr, eq
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #24]
	stur	q0, [x8, #8]
	ldr	w10, [x23, #32]
	stp	w9, w10, [x8]
	b	LBB10_8
LBB10_17:
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	b	LBB10_8
LBB10_18:
	bl	___error
	ldr	w8, [x0]
	mov	w9, #11                         ; =0xb
	mov	w10, #2                         ; =0x2
	cmp	w8, #35
	csel	w9, w10, w9, eq
	mov	w10, #3                         ; =0x3
	movi.2d	v0, #0000000000000000
	stur	q0, [x21, #8]
	stur	q0, [x21, #24]
	cmp	w8, #4
	csel	w9, w10, w9, eq
	stp	w9, w8, [x21]
	b	LBB10_8
LBB10_19:
	cmp	x0, #0
	cset	w8, eq
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x21]
	str	xzr, [x21, #32]
	str	w8, [x21]
	str	x0, [x21, #16]
	strb	w8, [x21, #32]
	b	LBB10_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_send_byte            ; -- Begin function nl_socket_send_byte
	.p2align	2
_nl_socket_send_byte:                   ; @nl_socket_send_byte
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w2, [x29, #-1]
	sub	x2, x29, #1
	mov	w3, #1                          ; =0x1
	bl	_nl_socket_send
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_receive_byte         ; -- Begin function nl_socket_receive_byte
	.p2align	2
_nl_socket_receive_byte:                ; @nl_socket_receive_byte
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x2
	mov	x20, x8
	mov	w3, #1                          ; =0x1
	bl	_nl_socket_receive
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB12_2
; %bb.1:
	strb	wzr, [x19]
LBB12_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nl_socket_resolve_tcp
lCPI13_0:
	.long	4096                            ; 0x1000
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	6                               ; 0x6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_socket_resolve_tcp
	.p2align	2
_nl_socket_resolve_tcp:                 ; @nl_socket_resolve_tcp
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #832
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh42:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh43:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh44:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cbz	x0, LBB13_9
; %bb.1:
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB13_3
; %bb.2:
	mov	x8, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w9, #5                          ; =0x5
	b	LBB13_11
LBB13_3:
	mov	x19, x3
	mov	x8, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
	cbz	w3, LBB13_10
; %bb.4:
	sub	x10, x2, #1
	cmp	x10, #252
	b.hi	LBB13_10
; %bb.5:
	cbz	x1, LBB13_10
; %bb.6:
	mov	x21, x1
	mov	x1, x8
	cbz	x5, LBB13_11
; %bb.7:
	sub	x8, x5, x21
	cmp	x8, x2
	cset	w8, lo
	subs	x9, x21, x5
	cmp	x9, #456
	cset	w9, lo
	cmp	x21, x5
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB13_9
; %bb.8:
	mov	x0, x21
	mov	x25, x4
	mov	x22, x5
	mov	w1, #0                          ; =0x0
	mov	x20, x2
	bl	_memchr
	cbz	x0, LBB13_13
LBB13_9:
	mov	x8, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
	b	LBB13_11
LBB13_10:
	mov	x1, x8
LBB13_11:
	ldur	x10, [x29, #-88]
Lloh45:
	adrp	x11, ___stack_chk_guard@GOTPAGE
Lloh46:
	ldr	x11, [x11, ___stack_chk_guard@GOTPAGEOFF]
Lloh47:
	ldr	x11, [x11]
	cmp	x11, x10
	b.ne	LBB13_70
; %bb.12:
	orr	x0, x8, x9
	add	sp, sp, #832
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB13_13:
	add	x23, sp, #80
	add	x26, sp, #570
	add	x0, sp, #570
	mov	x1, x21
	mov	x2, x20
	mov	w3, #254                        ; =0xfe
	bl	___memcpy_chk
	strb	wzr, [x26, x20]
	str	xzr, [sp, #528]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #416]
	stp	q0, q0, [x23, #384]
	stp	q0, q0, [x23, #352]
	stp	q0, q0, [x23, #320]
	stp	q0, q0, [x23, #288]
	stp	q0, q0, [x23, #256]
	stp	q0, q0, [x23, #224]
	stp	q0, q0, [x23, #192]
	stp	q0, q0, [x23, #160]
	stp	q0, q0, [x23, #128]
	stp	q0, q0, [x23, #96]
	stp	q0, q0, [x23, #64]
	stp	q0, q0, [sp, #112]
	stp	q0, q0, [sp, #80]
	strh	w19, [sp, #108]
	add	x0, sp, #570
	add	x1, sp, #76
	bl	_socket_ipv4_literal
	cbz	w0, LBB13_18
; %bb.14:
	ldr	w8, [sp, #76]
	str	w8, [sp, #92]
	mov	w8, #4                          ; =0x4
LBB13_15:
	mov	x0, x22
	str	w8, [sp, #88]
LBB13_16:
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #80]
	add	x1, sp, #80
	mov	w2, #456                        ; =0x1c8
	bl	_memcpy
	mov	w9, #0                          ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
LBB13_17:
	mov	w9, w9
	b	LBB13_11
LBB13_18:
	add	x23, sp, #536
	add	x8, sp, #80
	orr	x24, x8, #0x8
	add	x0, sp, #570
	mov	w1, #58                         ; =0x3a
	bl	_strrchr
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	cmp	x0, #0
	cset	w27, ne
	mov	x9, x20
LBB13_19:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x26, x8]
	sub	w11, w10, #48
	sub	w12, w10, #97
	sub	w13, w10, #65
	cmp	w10, #58
	csel	w14, w27, wzr, eq
	cmp	w10, #46
	csel	w10, w27, w14, eq
	cmp	w13, #6
	csel	w10, w27, w10, lo
	cmp	w11, #10
	ccmp	w12, #6, #0, hs
	csel	w27, w27, w10, lo
	add	x8, x8, #1
	cmp	x9, x8
	b.ne	LBB13_19
; %bb.20:
	add	x0, sp, #570
	mov	w1, #46                         ; =0x2e
	bl	_strchr
	mov	x8, x0
	cmp	x0, #0
	cset	w0, eq
	cbz	x8, LBB13_23
; %bb.21:
	cbz	x21, LBB13_23
; %bb.22:
	add	x0, x21, #1
	add	x1, sp, #76
	bl	_socket_ipv4_literal
LBB13_23:
	and	w8, w27, w0
	tbz	w8, #0, LBB13_27
; %bb.24:
	add	x8, sp, #80
	add	x1, sp, #570
	orr	x2, x8, #0xc
	mov	w0, #30                         ; =0x1e
	bl	_inet_pton
	cmp	w0, #1
	b.ne	LBB13_26
; %bb.25:
	mov	w8, #6                          ; =0x6
	b	LBB13_15
LBB13_26:
	ldr	w8, [sp, #88]
	mov	x0, x22
	cbnz	w8, LBB13_16
LBB13_27:
	add	x0, sp, #570
	mov	x1, x20
	bl	_socket_hostname
	mov	x8, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
	mov	w10, #7                         ; =0x7
	cmp	w0, #0
	csel	w9, w10, w9, ne
	mov	x1, #0                          ; =0x0
	cbz	w25, LBB13_17
; %bb.28:
	cbz	w0, LBB13_17
; %bb.29:
	str	x19, [sp]
Lloh48:
	adrp	x2, l_.str.3@PAGE
Lloh49:
	add	x2, x2, l_.str.3@PAGEOFF
	add	x0, sp, #70
	mov	w1, #6                          ; =0x6
	bl	_snprintf
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]
	str	xzr, [sp, #8]
Lloh50:
	adrp	x8, lCPI13_0@PAGE
Lloh51:
	ldr	q1, [x8, lCPI13_0@PAGEOFF]
	str	q1, [sp, #16]
	bl	___error
	str	wzr, [x0]
	add	x0, sp, #570
	add	x1, sp, #70
	add	x2, sp, #16
	add	x3, sp, #8
	bl	_getaddrinfo
	mov	x20, x0
	bl	___error
	ldr	w8, [x0]
	cmp	w20, #6
	b.eq	LBB13_58
; %bb.30:
	cbnz	w20, LBB13_59
; %bb.31:
	ldr	x0, [sp, #8]
	cbz	x0, LBB13_61
; %bb.32:
	add	x8, sp, #536
	add	x9, sp, #80
	ldr	x12, [sp, #80]
	add	x9, x9, #32
	mov	w10, #1                         ; =0x1
	mov	w11, #28                        ; =0x1c
	mov	x13, x0
LBB13_33:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_49 Depth 2
	ldr	w14, [x13, #8]
	cmp	w14, #1
	b.ne	LBB13_55
; %bb.34:                               ;   in Loop: Header=BB13_33 Depth=1
	ldr	w14, [x13, #12]
	cmp	w14, #6
	b.ne	LBB13_55
; %bb.35:                               ;   in Loop: Header=BB13_33 Depth=1
	ldr	w14, [x13, #4]
	cmp	w14, #30
	ccmp	w14, #2, #4, ne
	b.ne	LBB13_55
; %bb.36:                               ;   in Loop: Header=BB13_33 Depth=1
	str	xzr, [sp, #552]
	str	xzr, [sp, #544]
	str	xzr, [sp, #536]
	str	wzr, [sp, #560]
	strh	w19, [sp, #556]
	ldr	x16, [x13, #32]
	cbz	x16, LBB13_63
; %bb.37:                               ;   in Loop: Header=BB13_33 Depth=1
	ldr	w15, [x13, #16]
	cmp	w14, #2
	b.ne	LBB13_42
; %bb.38:                               ;   in Loop: Header=BB13_33 Depth=1
	cmp	w15, #16
	b.lo	LBB13_63
; %bb.39:                               ;   in Loop: Header=BB13_33 Depth=1
	ldrb	w14, [x16, #1]
	mov	w20, #11                        ; =0xb
	cmp	w14, #2
	b.ne	LBB13_64
; %bb.40:                               ;   in Loop: Header=BB13_33 Depth=1
	ldrh	w14, [x16, #2]
	rev16	w14, w14
	cmp	w19, w14, uxth
	b.ne	LBB13_64
; %bb.41:                               ;   in Loop: Header=BB13_33 Depth=1
	mov	w14, #0                         ; =0x0
	ldr	w16, [x16, #4]
	mov	w15, #4                         ; =0x4
	str	w15, [sp, #536]
	str	w16, [sp, #540]
	b	LBB13_46
LBB13_42:                               ;   in Loop: Header=BB13_33 Depth=1
	cmp	w15, #28
	b.lo	LBB13_63
; %bb.43:                               ;   in Loop: Header=BB13_33 Depth=1
	ldrb	w14, [x16, #1]
	mov	w20, #11                        ; =0xb
	cmp	w14, #30
	b.ne	LBB13_64
; %bb.44:                               ;   in Loop: Header=BB13_33 Depth=1
	ldrh	w14, [x16, #2]
	rev16	w14, w14
	cmp	w19, w14, uxth
	b.ne	LBB13_64
; %bb.45:                               ;   in Loop: Header=BB13_33 Depth=1
	ldr	w14, [x16, #24]
	mov	w15, #6                         ; =0x6
	str	w15, [sp, #536]
	str	w14, [sp, #560]
	ldur	q0, [x16, #8]
	stur	q0, [x8, #4]
LBB13_46:                               ;   in Loop: Header=BB13_33 Depth=1
	cbz	x12, LBB13_54
; %bb.47:                               ;   in Loop: Header=BB13_33 Depth=1
	mov	w16, #0                         ; =0x0
	mov	x17, x9
	mov	x1, x12
	b	LBB13_49
LBB13_48:                               ;   in Loop: Header=BB13_49 Depth=2
	add	x17, x17, #28
	subs	x1, x1, #1
	b.eq	LBB13_52
LBB13_49:                               ;   Parent Loop BB13_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w2, [x17, #-24]
	cmp	w2, w15
	b.ne	LBB13_48
; %bb.50:                               ;   in Loop: Header=BB13_49 Depth=2
	ldr	w2, [x17]
	cmp	w2, w14
	b.ne	LBB13_48
; %bb.51:                               ;   in Loop: Header=BB13_49 Depth=2
	ldur	x2, [x17, #-20]
	ldur	x3, [x23, #4]
	ldur	x4, [x17, #-12]
	ldur	x5, [x23, #12]
	cmp	x2, x3
	ccmp	x4, x5, #0, eq
	cset	w2, eq
	orr	w16, w2, w16
	b	LBB13_48
LBB13_52:                               ;   in Loop: Header=BB13_33 Depth=1
	tbnz	w16, #0, LBB13_55
; %bb.53:                               ;   in Loop: Header=BB13_33 Depth=1
	cmp	x12, #16
	b.eq	LBB13_69
LBB13_54:                               ;   in Loop: Header=BB13_33 Depth=1
	madd	x14, x12, x11, x24
	add	x12, x12, #1
	str	x12, [sp, #80]
	add	x15, sp, #281
	ldur	q0, [x15, #255]
	str	q0, [x14]
	ldur	q0, [x23, #12]
	stur	q0, [x14, #12]
LBB13_55:                               ;   in Loop: Header=BB13_33 Depth=1
	ldr	x13, [x13, #40]
	cbz	x13, LBB13_62
; %bb.56:                               ;   in Loop: Header=BB13_33 Depth=1
	cmp	w10, #256
	add	w10, w10, #1
	b.ne	LBB13_33
; %bb.57:
	mov	w20, #9                         ; =0x9
	b	LBB13_64
LBB13_58:
	mov	w9, #10                         ; =0xa
	b	LBB13_60
LBB13_59:
	mov	w9, #11                         ; =0xb
	cmp	w20, #2
	csel	w9, w20, w9, eq
LBB13_60:
	cmp	w20, #11
	csel	w1, w8, wzr, eq
	b	LBB13_68
LBB13_61:
	mov	w20, #0                         ; =0x0
	b	LBB13_65
LBB13_62:
	mov	w20, #0                         ; =0x0
	b	LBB13_64
LBB13_63:
	mov	w20, #11                        ; =0xb
LBB13_64:
	bl	_freeaddrinfo
LBB13_65:
	mov	x0, x22
	cmp	w20, #0
	ldr	x8, [sp, #80]
	ccmp	x8, #0, #0, eq
	mov	w8, #11                         ; =0xb
	csel	w9, w20, w8, ne
	mov	w8, #8                          ; =0x8
	csel	w20, wzr, w8, ne
	cbnz	w9, LBB13_67
; %bb.66:
	add	x1, sp, #80
	mov	w2, #456                        ; =0x1c8
	bl	_memcpy
	mov	w9, #0                          ; =0x0
LBB13_67:
	mov	x1, #0                          ; =0x0
LBB13_68:
	lsl	x8, x20, #32
	b	LBB13_17
LBB13_69:
	mov	w20, #8                         ; =0x8
	b	LBB13_64
LBB13_70:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh42, Lloh43, Lloh44
	.loh AdrpLdrGotLdr	Lloh45, Lloh46, Lloh47
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_ipv4_literal
_socket_ipv4_literal:                   ; @socket_ipv4_literal
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	sub	w8, w8, #48
	cmp	w8, #9
	b.hi	LBB14_7
; %bb.1:
	and	w9, w8, #0xff
	mov	x8, x0
	ldrb	w10, [x8, #1]!
	sub	w10, w10, #48
	cmp	w10, #9
	b.hi	LBB14_8
; %bb.2:
	mov	w8, #10                         ; =0xa
	mul	w8, w9, w8
	add	w9, w8, w10, uxtb
	cmp	w9, #255
	b.hi	LBB14_50
; %bb.3:
	mov	x8, x0
	ldrb	w10, [x8, #2]!
	sub	w10, w10, #48
	cmp	w10, #9
	b.hi	LBB14_20
; %bb.4:
	mov	w8, #10                         ; =0xa
	mul	w8, w9, w8
	add	w9, w8, w10, uxtb
	cmp	w9, #255
	b.hi	LBB14_50
; %bb.5:
	mov	x8, x0
	ldrb	w10, [x8, #3]!
	sub	w10, w10, #48
	cmp	w10, #10
	b.lo	LBB14_50
; %bb.6:
	mov	w10, #3                         ; =0x3
	cbnz	w10, LBB14_9
	b	LBB14_50
LBB14_7:
	mov	w9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	mov	x8, x0
	cbnz	w10, LBB14_9
	b	LBB14_50
LBB14_8:
	mov	w10, #1                         ; =0x1
	cbz	w10, LBB14_50
LBB14_9:
	cmp	w10, #1
	b.eq	LBB14_11
; %bb.10:
	ldrb	w10, [x0]
	cmp	w10, #48
	b.eq	LBB14_50
LBB14_11:
	strb	w9, [x1]
	mov	x10, x8
	ldrb	w9, [x10], #1
	cmp	w9, #46
	b.ne	LBB14_50
; %bb.12:
	ldrb	w9, [x10]
	sub	w9, w9, #48
	cmp	w9, #10
	b.hs	LBB14_19
; %bb.13:
	and	w11, w9, #0xff
	mov	x9, x8
	ldrb	w12, [x9, #2]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_21
; %bb.14:
	mov	w9, #10                         ; =0xa
	mul	w9, w11, w9
	add	w11, w9, w12, uxtb
	cmp	w11, #255
	b.hi	LBB14_50
; %bb.15:
	mov	x9, x8
	ldrb	w12, [x9, #3]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_33
; %bb.16:
	mov	w9, #10                         ; =0xa
	mul	w9, w11, w9
	add	w11, w9, w12, uxtb
	cmp	w11, #255
	b.hi	LBB14_50
; %bb.17:
	ldrb	w9, [x8, #4]!
	sub	w9, w9, #48
	cmp	w9, #10
	b.lo	LBB14_50
; %bb.18:
	mov	w12, #3                         ; =0x3
	mov	x9, x8
	cbnz	w12, LBB14_22
	b	LBB14_50
LBB14_19:
	mov	w11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x9, x10
	cbnz	w12, LBB14_22
	b	LBB14_50
LBB14_20:
	mov	w10, #2                         ; =0x2
	cbnz	w10, LBB14_9
	b	LBB14_50
LBB14_21:
	mov	w12, #1                         ; =0x1
	cbz	w12, LBB14_50
LBB14_22:
	cmp	w12, #1
	b.eq	LBB14_24
; %bb.23:
	ldrb	w8, [x10]
	cmp	w8, #48
	b.eq	LBB14_50
LBB14_24:
	strb	w11, [x1, #1]
	mov	x10, x9
	ldrb	w8, [x10], #1
	cmp	w8, #46
	b.ne	LBB14_50
; %bb.25:
	ldrb	w8, [x10]
	sub	w8, w8, #48
	cmp	w8, #10
	b.hs	LBB14_32
; %bb.26:
	and	w11, w8, #0xff
	mov	x8, x9
	ldrb	w12, [x8, #2]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_34
; %bb.27:
	mov	w8, #10                         ; =0xa
	mul	w8, w11, w8
	add	w11, w8, w12, uxtb
	cmp	w11, #255
	b.hi	LBB14_50
; %bb.28:
	mov	x8, x9
	ldrb	w12, [x8, #3]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_46
; %bb.29:
	mov	w8, #10                         ; =0xa
	mul	w8, w11, w8
	add	w11, w8, w12, uxtb
	cmp	w11, #255
	b.hi	LBB14_50
; %bb.30:
	ldrb	w8, [x9, #4]!
	sub	w8, w8, #48
	cmp	w8, #10
	b.lo	LBB14_50
; %bb.31:
	mov	w12, #3                         ; =0x3
	mov	x8, x9
	cbnz	w12, LBB14_35
	b	LBB14_50
LBB14_32:
	mov	w11, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x8, x10
	cbnz	w12, LBB14_35
	b	LBB14_50
LBB14_33:
	mov	w12, #2                         ; =0x2
	cbnz	w12, LBB14_22
	b	LBB14_50
LBB14_34:
	mov	w12, #1                         ; =0x1
	cbz	w12, LBB14_50
LBB14_35:
	cmp	w12, #1
	b.eq	LBB14_37
; %bb.36:
	ldrb	w9, [x10]
	cmp	w9, #48
	b.eq	LBB14_50
LBB14_37:
	strb	w11, [x1, #2]
	mov	x9, x8
	ldrb	w10, [x9], #1
	cmp	w10, #46
	b.ne	LBB14_50
; %bb.38:
	ldrb	w10, [x9]
	sub	w10, w10, #48
	cmp	w10, #10
	b.hs	LBB14_45
; %bb.39:
	and	w10, w10, #0xff
	mov	x11, x8
	ldrb	w12, [x11, #2]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_47
; %bb.40:
	mov	w11, #10                        ; =0xa
	mul	w10, w10, w11
	add	w10, w10, w12, uxtb
	cmp	w10, #255
	b.hi	LBB14_50
; %bb.41:
	mov	x11, x8
	ldrb	w12, [x11, #3]!
	sub	w12, w12, #48
	cmp	w12, #9
	b.hi	LBB14_52
; %bb.42:
	mov	w11, #10                        ; =0xa
	mul	w10, w10, w11
	add	w10, w10, w12, uxtb
	cmp	w10, #255
	b.hi	LBB14_50
; %bb.43:
	ldrb	w11, [x8, #4]!
	sub	w11, w11, #48
	cmp	w11, #9
	b.ls	LBB14_50
; %bb.44:
	mov	w12, #3                         ; =0x3
	mov	x11, x8
	cbnz	w12, LBB14_48
	b	LBB14_50
LBB14_45:
	mov	w10, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x11, x9
	cbnz	w12, LBB14_48
	b	LBB14_50
LBB14_46:
	mov	w12, #2                         ; =0x2
	cbnz	w12, LBB14_35
	b	LBB14_50
LBB14_47:
	mov	w12, #1                         ; =0x1
	cbz	w12, LBB14_50
LBB14_48:
	cmp	w12, #1
	b.eq	LBB14_51
; %bb.49:
	ldrb	w8, [x9]
	cmp	w8, #48
	b.ne	LBB14_51
LBB14_50:
	mov	w0, #0                          ; =0x0
	ret
LBB14_51:
	strb	w10, [x1, #3]
	ldrb	w8, [x11]
	cmp	w8, #0
	cset	w0, eq
	ret
LBB14_52:
	mov	w12, #2                         ; =0x2
	cbnz	w12, LBB14_48
	b	LBB14_50
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function socket_hostname
_socket_hostname:                       ; @socket_hostname
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB15_12
; %bb.1:
	mov	x12, #0                         ; =0x0
	mov	w9, #1                          ; =0x1
	mov	x10, x0
	mov	x11, x1
	b	LBB15_4
LBB15_2:                                ;   in Loop: Header=BB15_4 Depth=1
	add	x12, x12, #1
	and	w9, w8, w9
LBB15_3:                                ;   in Loop: Header=BB15_4 Depth=1
	add	x10, x10, #1
	subs	x11, x11, #1
	b.eq	LBB15_11
LBB15_4:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w14, [x10]
	cmp	w14, #46
	b.ne	LBB15_8
; %bb.5:                                ;   in Loop: Header=BB15_4 Depth=1
	cbz	x12, LBB15_12
; %bb.6:                                ;   in Loop: Header=BB15_4 Depth=1
	ldurb	w8, [x10, #-1]
	cmp	w8, #45
	b.eq	LBB15_12
; %bb.7:                                ;   in Loop: Header=BB15_4 Depth=1
	mov	x12, #0                         ; =0x0
	b	LBB15_3
LBB15_8:                                ;   in Loop: Header=BB15_4 Depth=1
	mov	w8, #0                          ; =0x0
	sub	w13, w14, #48
	and	w15, w14, #0xffffffdf
	sub	w15, w15, #65
	cmp	w15, #26
	ccmp	w13, #10, #0, hs
	cset	w15, lo
	cmp	x12, #0
	cset	w16, eq
	cmp	w14, #45
	csel	w16, wzr, w16, ne
	csinc	w14, w15, wzr, ne
	tbnz	w16, #0, LBB15_13
; %bb.9:                                ;   in Loop: Header=BB15_4 Depth=1
	cbz	w14, LBB15_13
; %bb.10:                               ;   in Loop: Header=BB15_4 Depth=1
	cmp	w13, #10
	cset	w8, lo
	cmp	x12, #62
	b.ls	LBB15_2
	b	LBB15_12
LBB15_11:
	tbz	w9, #0, LBB15_14
LBB15_12:
	mov	w8, #0                          ; =0x0
LBB15_13:
	mov	x0, x8
	ret
LBB15_14:
	add	x8, x0, x1
	ldurb	w8, [x8, #-1]
	cmp	w8, #45
	cset	w0, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_transfer             ; -- Begin function nl_socket_transfer
	.p2align	2
_nl_socket_transfer:                    ; @nl_socket_transfer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
	cbz	x2, LBB16_3
; %bb.1:
	mov	x20, x0
	mov	x22, x2
	str	xzr, [sp, #56]
	add	x3, sp, #56
	mov	w2, #16                         ; =0x10
	bl	_socket_resolve
	cbz	w0, LBB16_4
; %bb.2:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB16_11
LBB16_3:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #4                          ; =0x4
	b	LBB16_10
LBB16_4:
	ldr	x23, [sp, #56]
	ldr	x8, [x23, #32]
	ldp	q1, q0, [x23]
	stp	q1, q0, [sp, #16]
	str	x8, [sp, #48]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23]
	str	wzr, [x23, #36]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #20]
	stur	q0, [x23, #4]
	ldr	x0, [x20]
	add	x8, sp, #16
	orr	x21, x8, #0x8
	mov	x2, sp
	mov	x1, x21
	bl	_nl_cap_private_transfer
	cbz	w0, LBB16_7
; %bb.5:
	ldp	q0, q1, [sp, #16]
	ldr	x8, [sp, #48]
	str	x8, [x23, #32]
	stp	q0, q1, [x23]
	sub	w8, w0, #4
	cmp	w8, #5
	b.hi	LBB16_8
; %bb.6:
Lloh52:
	adrp	x9, l_switch.table.nl_socket_consume_close@PAGE
Lloh53:
	add	x9, x9, l_switch.table.nl_socket_consume_close@PAGEOFF
	ldr	w8, [x9, w8, uxtw #2]
	b	LBB16_9
LBB16_7:
	ldr	q0, [sp]
	str	q0, [x21]
	mov	w8, #40                         ; =0x28
	ldr	w9, [sp, #8]
	umaddl	x8, w9, w8, x20
	ldp	q2, q1, [sp, #16]
	stur	q1, [x8, #40]
	ldr	x9, [sp, #48]
	str	x9, [x8, #56]
	stur	q2, [x8, #24]
	ldr	x8, [x20, #8]
	str	x8, [x22]
	stur	q0, [x22, #8]
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #33]
	b	LBB16_11
LBB16_8:
	mov	w8, #6                          ; =0x6
LBB16_9:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
LBB16_10:
	str	w8, [x19]
LBB16_11:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpAdd	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_consume_close        ; -- Begin function nl_socket_consume_close
	.p2align	2
_nl_socket_consume_close:               ; @nl_socket_consume_close
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	mov	x19, x8
	str	xzr, [sp, #40]
	add	x3, sp, #40
	mov	w2, #0                          ; =0x0
	bl	_socket_resolve
	cbz	w0, LBB17_2
; %bb.1:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	str	w0, [x19]
	b	LBB17_11
LBB17_2:
	ldr	x21, [sp, #40]
	ldr	x8, [x21, #32]
	ldp	q1, q0, [x21]
	stp	q1, q0, [sp]
	str	x8, [sp, #32]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x21]
	str	wzr, [x21, #36]
	movi.2d	v0, #0000000000000000
	stur	q0, [x21, #20]
	stur	q0, [x21, #4]
	ldr	x0, [x20]
	mov	x8, sp
	orr	x1, x8, #0x8
	bl	_nl_cap_private_consume
	cbz	w0, LBB17_5
; %bb.3:
	ldp	q0, q1, [sp]
	ldr	x8, [sp, #32]
	str	x8, [x21, #32]
	stp	q0, q1, [x21]
	sub	w8, w0, #4
	cmp	w8, #5
	b.hi	LBB17_9
; %bb.4:
Lloh54:
	adrp	x9, l_switch.table.nl_socket_consume_close@PAGE
Lloh55:
	add	x9, x9, l_switch.table.nl_socket_consume_close@PAGEOFF
	ldr	w8, [x9, w8, uxtw #2]
	b	LBB17_10
LBB17_5:
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	mov	w22, #1                         ; =0x1
	strb	w22, [x19, #33]
	ldr	w21, [sp]
	str	w22, [x19, #24]
	bl	___error
	str	wzr, [x0]
	mov	x0, x21
	bl	_close
	mov	x21, x0
	bl	___error
	cbz	w21, LBB17_12
; %bb.6:
	ldr	w8, [x0]
	strb	w22, [x19, #35]
	ldrb	w9, [x20, #17]
	tbnz	w9, #0, LBB17_8
; %bb.7:
	str	w8, [x20, #20]
LBB17_8:
	mov	w9, #1                          ; =0x1
	strb	w9, [x20, #17]
	mov	w9, #11                         ; =0xb
	stp	w9, w8, [x19]
	b	LBB17_11
LBB17_9:
	mov	w8, #6                          ; =0x6
LBB17_10:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	str	w8, [x19]
LBB17_11:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB17_12:
	str	w22, [x19, #28]
	b	LBB17_11
	.loh AdrpAdd	Lloh54, Lloh55
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_service_dispose      ; -- Begin function nl_socket_service_dispose
	.p2align	2
_nl_socket_service_dispose:             ; @nl_socket_service_dispose
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	cbz	x0, LBB18_4
; %bb.1:
	mov	x20, x0
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	ldrb	w8, [x0, #16]
	tbz	w8, #0, LBB18_5
; %bb.2:
	ldrb	w8, [x20, #17]
	cmp	w8, #1
	b.ne	LBB18_29
; %bb.3:
	strb	w8, [x19, #35]
	b	LBB18_28
LBB18_4:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	b	LBB18_29
LBB18_5:
	mov	x25, #0                         ; =0x0
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
	mov	w23, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	mov	w28, #1                         ; =0x1
	strb	w28, [x20, #16]
	strb	w28, [x19, #33]
	b	LBB18_8
LBB18_6:                                ;   in Loop: Header=BB18_8 Depth=1
	tst	w27, #0x1
	strb	w28, [x20, #17]
	csel	w9, w26, w8, ne
	cmp	w22, #0
	csel	w23, w8, w23, eq
	mov	w8, w28
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	csel	w26, w26, w9, eq
	csel	w27, w27, w28, eq
	mov	w8, #11                         ; =0xb
	csel	w22, w8, w22, eq
LBB18_7:                                ;   in Loop: Header=BB18_8 Depth=1
	add	x25, x25, #40
	cmp	x25, #2560
	b.eq	LBB18_26
LBB18_8:                                ; =>This Inner Loop Header: Depth=1
	add	x8, x20, x25
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	stp	q0, q1, [sp, #16]
	ldr	x9, [x8, #56]
	str	x9, [sp, #48]
	ldrb	w9, [sp, #20]
	cmp	w9, #1
	b.ne	LBB18_7
; %bb.9:                                ;   in Loop: Header=BB18_8 Depth=1
	mov	w9, #-1                         ; =0xffffffff
	stur	w9, [x8, #24]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #28]
	stur	q0, [x8, #44]
	str	wzr, [x8, #60]
	ldr	x0, [x20]
	add	x8, sp, #16
	add	x1, x8, #8
	bl	_nl_cap_private_consume
	cbz	w0, LBB18_12
; %bb.10:                               ;   in Loop: Header=BB18_8 Depth=1
	cbz	w22, LBB18_16
; %bb.11:                               ;   in Loop: Header=BB18_8 Depth=1
	tst	w27, #0x1
	csel	w26, w26, wzr, ne
	mov	w27, #1                         ; =0x1
LBB18_12:                               ;   in Loop: Header=BB18_8 Depth=1
	ldr	w21, [sp, #16]
	add	w24, w24, #1
	bl	___error
	str	wzr, [x0]
	mov	x0, x21
	bl	_close
	mov	x21, x0
	bl	___error
	cbz	w21, LBB18_15
; %bb.13:                               ;   in Loop: Header=BB18_8 Depth=1
	ldr	w8, [x0]
	ldrb	w9, [x20, #17]
	tbnz	w9, #0, LBB18_6
; %bb.14:                               ;   in Loop: Header=BB18_8 Depth=1
	str	w8, [x20, #20]
	b	LBB18_6
LBB18_15:                               ;   in Loop: Header=BB18_8 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB18_7
LBB18_16:                               ;   in Loop: Header=BB18_8 Depth=1
	cmp	w0, #7
	b.gt	LBB18_19
; %bb.17:                               ;   in Loop: Header=BB18_8 Depth=1
	sub	w8, w0, #4
	cmp	w8, #2
	b.hs	LBB18_22
; %bb.18:                               ;   in Loop: Header=BB18_8 Depth=1
	mov	w22, #7                         ; =0x7
	b	LBB18_12
LBB18_19:                               ;   in Loop: Header=BB18_8 Depth=1
	cmp	w0, #8
	b.eq	LBB18_24
; %bb.20:                               ;   in Loop: Header=BB18_8 Depth=1
	cmp	w0, #9
	b.ne	LBB18_25
; %bb.21:                               ;   in Loop: Header=BB18_8 Depth=1
	mov	w22, #11                        ; =0xb
	b	LBB18_12
LBB18_22:                               ;   in Loop: Header=BB18_8 Depth=1
	cmp	w0, #6
	b.ne	LBB18_25
; %bb.23:                               ;   in Loop: Header=BB18_8 Depth=1
	mov	w22, #8                         ; =0x8
	b	LBB18_12
LBB18_24:                               ;   in Loop: Header=BB18_8 Depth=1
	mov	w22, #9                         ; =0x9
	b	LBB18_12
LBB18_25:                               ;   in Loop: Header=BB18_8 Depth=1
	mov	w22, #6                         ; =0x6
	b	LBB18_12
LBB18_26:
	strb	w27, [x19, #34]
	stp	w23, w26, [x19, #4]
	ldp	w9, w8, [sp, #8]                ; 8-byte Folded Reload
	strb	w9, [x19, #35]
	stp	w24, w8, [x19, #24]
	str	w22, [x19]
	ldrb	w8, [x20, #17]
	tbz	w8, #0, LBB18_29
; %bb.27:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #35]
	cbnz	w22, LBB18_29
LBB18_28:
	mov	w8, #11                         ; =0xb
	ldr	w9, [x20, #20]
	stp	w8, w9, [x19]
LBB18_29:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_socket_service_destroy      ; -- Begin function nl_socket_service_destroy
	.p2align	2
_nl_socket_service_destroy:             ; @nl_socket_service_destroy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB19_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_nl_socket_service_dispose
	ldr	x0, [x19]
	bl	_nl_cap_table_destroy
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB19_2:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #4                          ; =0x4
	str	w9, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_socket_context_counter,8,3 ; @socket_context_counter
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/net#Socket"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:nanolang/net/local-socket"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/net/tcp-socket"

l_.str.3:                               ; @.str.3
	.asciz	"%u"

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @switch.table.nl_socket_consume_close
l_switch.table.nl_socket_consume_close:
	.long	7                               ; 0x7
	.long	7                               ; 0x7
	.long	8                               ; 0x8
	.long	6                               ; 0x6
	.long	9                               ; 0x9
	.long	11                              ; 0xb

.subsections_via_symbols
