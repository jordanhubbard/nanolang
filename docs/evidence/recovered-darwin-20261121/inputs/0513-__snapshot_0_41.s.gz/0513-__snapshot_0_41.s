	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_vm_gc_note_suspect             ; -- Begin function vm_gc_note_suspect
	.p2align	2
_vm_gc_note_suspect:                    ; @vm_gc_note_suspect
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	stur	x0, [x29, #-24]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldurb	w0, [x29, #-16]
	bl	_can_hold_children
	tbnz	w0, #0, LBB0_3
	b	LBB0_2
LBB0_2:
	b	LBB0_18
LBB0_3:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #3
	b.ne	LBB0_6
	b	LBB0_4
LBB0_4:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB0_6
	b	LBB0_5
LBB0_5:
	b	LBB0_18
LBB0_6:
	ldr	x9, [sp, #32]
	mov	w8, #3                          ; =0x3
	strb	w8, [x9, #5]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB0_8
	b	LBB0_7
LBB0_7:
	b	LBB0_18
LBB0_8:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #72]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #76]
	subs	w8, w8, w9
	b.ne	LBB0_15
	b	LBB0_9
LBB0_9:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #76]
	cbz	w8, LBB0_11
	b	LBB0_10
LBB0_10:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #76]
	lsl	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_12
LBB0_11:
	mov	w8, #64                         ; =0x40
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_12
LBB0_12:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #28]
	ldur	x8, [x29, #-24]
	ldr	x0, [x8, #64]
	ldr	w8, [sp, #28]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	bl	_realloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB0_14
	b	LBB0_13
LBB0_13:
	b	LBB0_18
LBB0_14:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #64]
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-24]
	str	w8, [x9, #76]
	b	LBB0_15
LBB0_15:
	ldur	x8, [x29, #-8]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	ldur	x12, [x29, #-24]
	ldr	w10, [x12, #72]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #72]
	str	x8, [x9, x10, lsl #3]
	ldr	x9, [sp, #32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #6]
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #88]
	tbnz	w8, #0, LBB0_18
	b	LBB0_16
LBB0_16:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #72]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.lo	LBB0_18
	b	LBB0_17
LBB0_17:
	ldur	x0, [x29, #-24]
	bl	_vm_gc_collect_cycles
	b	LBB0_18
LBB0_18:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function header_of
_header_of:                             ; @header_of
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_val_is_heap_obj
	tbz	w0, #0, LBB1_3
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #24]
	cbz	x8, LBB1_3
	b	LBB1_2
LBB1_2:
	ldr	x8, [sp, #24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_4
LBB1_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB1_4
LBB1_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function can_hold_children
_can_hold_children:                     ; @can_hold_children
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	ldrb	w8, [sp, #14]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	subs	w8, w8, #7
	subs	w8, w8, #1
	b.ls	LBB2_4
	b	LBB2_1
LBB2_1:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB2_4
	b	LBB2_2
LBB2_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #12
	subs	w8, w8, #1
	b.ls	LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.ne	LBB2_5
	b	LBB2_4
LBB2_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB2_6
LBB2_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB2_6
LBB2_6:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_gc_collect_cycles           ; -- Begin function vm_gc_collect_cycles
	.p2align	2
_vm_gc_collect_cycles:                  ; @vm_gc_collect_cycles
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_3
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #72]
	cbz	w8, LBB3_3
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #88]
	tbz	w8, #0, LBB3_4
	b	LBB3_3
LBB3_3:
	stur	xzr, [x29, #-24]
	b	LBB3_52
LBB3_4:
	ldur	x9, [x29, #-32]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #88]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #72]
	stur	w8, [x29, #-44]
	ldur	x8, [x29, #-32]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #64]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #72]
	ldur	x8, [x29, #-32]
	str	wzr, [x8, #76]
	stur	xzr, [x29, #-56]
	stur	wzr, [x29, #-60]
	stur	wzr, [x29, #-64]
	b	LBB3_5
LBB3_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-44]
	subs	w8, w8, w9
	b.hs	LBB3_15
	b	LBB3_6
LBB3_6:                                 ;   in Loop: Header=BB3_5 Depth=1
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	stur	x0, [x29, #-80]
	stur	x1, [x29, #-72]
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_header_of
	stur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	cbnz	x8, LBB3_8
	b	LBB3_7
LBB3_7:                                 ;   in Loop: Header=BB3_5 Depth=1
	b	LBB3_14
LBB3_8:                                 ;   in Loop: Header=BB3_5 Depth=1
	ldur	x8, [x29, #-88]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #3
	b.ne	LBB3_11
	b	LBB3_9
LBB3_9:                                 ;   in Loop: Header=BB3_5 Depth=1
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB3_11
	b	LBB3_10
LBB3_10:                                ;   in Loop: Header=BB3_5 Depth=1
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-40]
	ldur	w10, [x29, #-60]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-60]
	str	x8, [x9, x10, lsl #3]
	b	LBB3_14
LBB3_11:                                ;   in Loop: Header=BB3_5 Depth=1
	ldur	x8, [x29, #-88]
	strb	wzr, [x8, #6]
	ldur	x8, [x29, #-88]
	ldr	w8, [x8]
	cbnz	w8, LBB3_13
	b	LBB3_12
LBB3_12:                                ;   in Loop: Header=BB3_5 Depth=1
	ldur	x9, [x29, #-88]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x8, x8, #1
	stur	x8, [x29, #-56]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-80]
	ldur	x2, [x29, #-72]
	bl	_vm_release
	b	LBB3_13
LBB3_13:                                ;   in Loop: Header=BB3_5 Depth=1
	b	LBB3_14
LBB3_14:                                ;   in Loop: Header=BB3_5 Depth=1
	ldur	w8, [x29, #-64]
	add	w8, w8, #1
	stur	w8, [x29, #-64]
	b	LBB3_5
LBB3_15:
	stur	wzr, [x29, #-92]
	b	LBB3_16
LBB3_16:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-92]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB3_19
	b	LBB3_17
LBB3_17:                                ;   in Loop: Header=BB3_16 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-92]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-112]
	stur	x1, [x29, #-104]
	ldur	x1, [x29, #-112]
	ldur	x2, [x29, #-104]
	bl	_mark_gray
	b	LBB3_18
LBB3_18:                                ;   in Loop: Header=BB3_16 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB3_16
LBB3_19:
	stur	wzr, [x29, #-116]
	b	LBB3_20
LBB3_20:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-116]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB3_23
	b	LBB3_21
LBB3_21:                                ;   in Loop: Header=BB3_20 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-136]
	stur	x1, [x29, #-128]
	ldur	x1, [x29, #-136]
	ldur	x2, [x29, #-128]
	bl	_scan
	b	LBB3_22
LBB3_22:                                ;   in Loop: Header=BB3_20 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB3_20
LBB3_23:
	stur	wzr, [x29, #-140]
	b	LBB3_24
LBB3_24:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-140]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #72]
	subs	w8, w8, w9
	b.hs	LBB3_31
	b	LBB3_25
LBB3_25:                                ;   in Loop: Header=BB3_24 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	ldur	w9, [x29, #-140]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	str	x0, [sp, #144]
	str	x1, [sp, #152]
	ldr	x0, [sp, #144]
	ldr	x1, [sp, #152]
	bl	_header_of
	str	x0, [sp, #136]
	ldr	x8, [sp, #136]
	cbz	x8, LBB3_29
	b	LBB3_26
LBB3_26:                                ;   in Loop: Header=BB3_24 Depth=1
	ldr	x8, [sp, #136]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.eq	LBB3_28
	b	LBB3_27
LBB3_27:                                ;   in Loop: Header=BB3_24 Depth=1
	ldr	x8, [sp, #136]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB3_29
	b	LBB3_28
LBB3_28:                                ;   in Loop: Header=BB3_24 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #144]
	ldr	x2, [sp, #152]
	bl	_scan_black
	b	LBB3_29
LBB3_29:                                ;   in Loop: Header=BB3_24 Depth=1
	b	LBB3_30
LBB3_30:                                ;   in Loop: Header=BB3_24 Depth=1
	ldur	w8, [x29, #-140]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	b	LBB3_24
LBB3_31:
	str	wzr, [sp, #132]
	b	LBB3_32
LBB3_32:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #132]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #72]
	subs	w8, w8, w9
	b.hs	LBB3_37
	b	LBB3_33
LBB3_33:                                ;   in Loop: Header=BB3_32 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #64]
	ldr	w9, [sp, #132]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #120]
	ldr	x8, [sp, #120]
	cbz	x8, LBB3_35
	b	LBB3_34
LBB3_34:                                ;   in Loop: Header=BB3_32 Depth=1
	ldr	x8, [sp, #120]
	ldr	w10, [x8]
	mov	w9, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
	subs	w10, w10, #0
	csel	w8, w8, w9, hi
	ldr	x9, [sp, #120]
	strb	w8, [x9, #5]
	b	LBB3_35
LBB3_35:                                ;   in Loop: Header=BB3_32 Depth=1
	b	LBB3_36
LBB3_36:                                ;   in Loop: Header=BB3_32 Depth=1
	ldr	w8, [sp, #132]
	add	w8, w8, #1
	str	w8, [sp, #132]
	b	LBB3_32
LBB3_37:
	str	wzr, [sp, #116]
	b	LBB3_38
LBB3_38:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #116]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB3_43
	b	LBB3_39
LBB3_39:                                ;   in Loop: Header=BB3_38 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #116]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #104]
	ldr	x8, [sp, #104]
	cbz	x8, LBB3_41
	b	LBB3_40
LBB3_40:                                ;   in Loop: Header=BB3_38 Depth=1
	ldr	x8, [sp, #104]
	strb	wzr, [x8, #6]
	b	LBB3_41
LBB3_41:                                ;   in Loop: Header=BB3_38 Depth=1
	b	LBB3_42
LBB3_42:                                ;   in Loop: Header=BB3_38 Depth=1
	ldr	w8, [sp, #116]
	add	w8, w8, #1
	str	w8, [sp, #116]
	b	LBB3_38
LBB3_43:
	str	xzr, [sp, #88]
	str	xzr, [sp, #96]
	str	wzr, [sp, #84]
	b	LBB3_44
LBB3_44:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #84]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB3_47
	b	LBB3_45
LBB3_45:                                ;   in Loop: Header=BB3_44 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_value_from_obj
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #64]
	str	x1, [sp, #72]
	ldr	x1, [sp, #64]
	ldr	x2, [sp, #72]
	add	x3, sp, #88
	bl	_collect_white
	b	LBB3_46
LBB3_46:                                ;   in Loop: Header=BB3_44 Depth=1
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB3_44
LBB3_47:
	str	wzr, [sp, #60]
	b	LBB3_48
LBB3_48:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	w9, [sp, #96]
	subs	w8, w8, w9
	b.hs	LBB3_51
	b	LBB3_49
LBB3_49:                                ;   in Loop: Header=BB3_48 Depth=1
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #48]
	str	xzr, [sp, #32]
	str	xzr, [sp, #40]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #4]
	strb	w8, [sp, #32]
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #40]
	ldr	x9, [sp, #48]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-56]
	add	x8, x8, #1
	stur	x8, [x29, #-56]
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #40]
	bl	_vm_release
	b	LBB3_50
LBB3_50:                                ;   in Loop: Header=BB3_48 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB3_48
LBB3_51:
	ldr	x0, [sp, #88]
	bl	_free
	ldur	x0, [x29, #-40]
	bl	_free
	ldur	x10, [x29, #-56]
	ldur	x9, [x29, #-32]
	ldr	x8, [x9, #80]
	add	x8, x8, x10
	str	x8, [x9, #80]
	ldur	x8, [x29, #-32]
	strb	wzr, [x8, #88]
	ldur	x8, [x29, #-56]
	stur	x8, [x29, #-24]
	b	LBB3_52
LBB3_52:
	ldur	x0, [x29, #-24]
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function value_from_obj
_value_from_obj:                        ; @value_from_obj
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldr	x8, [sp, #8]
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8, #4]
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_gray
_mark_gray:                             ; @mark_gray
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.ne	LBB5_3
	b	LBB5_2
LBB5_2:
	b	LBB5_4
LBB5_3:
	ldr	x9, [sp]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _mark_gray_child@PAGE
	add	x3, x3, _mark_gray_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB5_4
LBB5_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan
_scan:                                  ; @scan
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #1
	b.eq	LBB6_3
	b	LBB6_2
LBB6_2:
	b	LBB6_6
LBB6_3:
	ldr	x8, [sp]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB6_5
	b	LBB6_4
LBB6_4:
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_scan_black
	b	LBB6_6
LBB6_5:
	ldr	x9, [sp]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _scan_child@PAGE
	add	x3, x3, _scan_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB6_6
LBB6_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_black
_scan_black:                            ; @scan_black
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_header_of
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	b	LBB7_3
LBB7_2:
	ldr	x8, [sp]
	strb	wzr, [x8, #5]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	adrp	x3, _scan_black_child@PAGE
	add	x3, x3, _scan_black_child@PAGEOFF
	mov	x4, #0                          ; =0x0
	bl	_for_each_child
	b	LBB7_3
LBB7_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_white
_collect_white:                         ; @collect_white
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	cbz	w8, LBB8_4
	b	LBB8_3
LBB8_3:
	b	LBB8_6
LBB8_4:
	ldr	x8, [sp, #8]
	strb	wzr, [x8, #5]
	ldr	x0, [sp, #24]
	ldr	x4, [sp, #16]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	adrp	x3, _collect_white_slot@PAGE
	add	x3, x3, _collect_white_slot@PAGEOFF
	bl	_for_each_child_slot
	ldr	x0, [sp, #16]
	ldur	x1, [x29, #-8]
	bl	_dead_push
	tbnz	w0, #0, LBB8_6
	b	LBB8_5
LBB8_5:
	ldr	x9, [sp, #8]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #5]
	b	LBB8_6
LBB8_6:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_vm_gc_cycle_buffer_free        ; -- Begin function vm_gc_cycle_buffer_free
	.p2align	2
_vm_gc_cycle_buffer_free:               ; @vm_gc_cycle_buffer_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	b	LBB9_3
LBB9_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #64]
	bl	_free
	ldr	x8, [sp, #8]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #64]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #72]
	ldr	x8, [sp, #8]
	str	wzr, [x8, #76]
	b	LBB9_3
LBB9_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_is_heap_obj
_val_is_heap_obj:                       ; @val_is_heap_obj
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #5
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_1
LBB10_1:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #6
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_2
LBB10_2:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #7
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_3
LBB10_3:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #8
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_4
LBB10_4:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_5
LBB10_5:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #12
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_6
LBB10_6:
	ldrb	w9, [sp, #16]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #13
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB10_8
	b	LBB10_7
LBB10_7:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #15
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB10_8
LBB10_8:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function for_each_child
_for_each_child:                        ; @for_each_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x1, [x8]
	str	x2, [x8, #8]
	stur	x0, [x29, #-24]
	stur	x3, [x29, #-32]
	stur	x4, [x29, #-40]
	ldurb	w8, [x29, #-16]
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	subs	w8, w8, #7
	b.eq	LBB11_6
	b	LBB11_1
LBB11_1:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB11_14
	b	LBB11_2
LBB11_2:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB11_29
	b	LBB11_3
LBB11_3:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB11_36
	b	LBB11_4
LBB11_4:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB11_43
	b	LBB11_5
LBB11_5:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB11_53
	b	LBB11_60
LBB11_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB11_8
	b	LBB11_7
LBB11_7:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB11_9
	b	LBB11_8
LBB11_8:
	b	LBB11_61
LBB11_9:
	stur	wzr, [x29, #-52]
	b	LBB11_10
LBB11_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB11_13
	b	LBB11_11
LBB11_11:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB11_12
LBB11_12:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB11_10
LBB11_13:
	b	LBB11_61
LBB11_14:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbnz	x8, LBB11_16
	b	LBB11_15
LBB11_15:
	b	LBB11_61
LBB11_16:
	stur	wzr, [x29, #-68]
	b	LBB11_17
LBB11_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB11_20
	b	LBB11_18
LBB11_18:                               ;   in Loop: Header=BB11_17 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-68]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB11_19
LBB11_19:                               ;   in Loop: Header=BB11_17 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB11_17
LBB11_20:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	cbz	x8, LBB11_28
	b	LBB11_21
LBB11_21:
	stur	wzr, [x29, #-72]
	b	LBB11_22
LBB11_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-72]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB11_27
	b	LBB11_23
LBB11_23:                               ;   in Loop: Header=BB11_22 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB11_25
	b	LBB11_24
LBB11_24:                               ;   in Loop: Header=BB11_22 Depth=1
	ldur	x8, [x29, #-32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_string
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	x9, [x29, #-88]
	stur	x1, [x29, #-80]
	ldur	x3, [x29, #-40]
	ldur	x1, [x29, #-88]
	ldur	x2, [x29, #-80]
	blr	x8
	b	LBB11_25
LBB11_25:                               ;   in Loop: Header=BB11_22 Depth=1
	b	LBB11_26
LBB11_26:                               ;   in Loop: Header=BB11_22 Depth=1
	ldur	w8, [x29, #-72]
	add	w8, w8, #1
	stur	w8, [x29, #-72]
	b	LBB11_22
LBB11_27:
	b	LBB11_28
LBB11_28:
	b	LBB11_61
LBB11_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB11_31
	b	LBB11_30
LBB11_30:
	b	LBB11_61
LBB11_31:
	str	wzr, [sp, #92]
	b	LBB11_32
LBB11_32:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #96]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB11_35
	b	LBB11_33
LBB11_33:                               ;   in Loop: Header=BB11_32 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #92]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB11_34
LBB11_34:                               ;   in Loop: Header=BB11_32 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB11_32
LBB11_35:
	b	LBB11_61
LBB11_36:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB11_38
	b	LBB11_37
LBB11_37:
	b	LBB11_61
LBB11_38:
	str	wzr, [sp, #76]
	b	LBB11_39
LBB11_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #80]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB11_42
	b	LBB11_40
LBB11_40:                               ;   in Loop: Header=BB11_39 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #80]
	add	x9, x9, #16
	ldr	w10, [sp, #76]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB11_41
LBB11_41:                               ;   in Loop: Header=BB11_39 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB11_39
LBB11_42:
	b	LBB11_61
LBB11_43:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	cbz	x8, LBB11_45
	b	LBB11_44
LBB11_44:
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB11_46
	b	LBB11_45
LBB11_45:
	b	LBB11_61
LBB11_46:
	str	wzr, [sp, #60]
	b	LBB11_47
LBB11_47:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB11_52
	b	LBB11_48
LBB11_48:                               ;   in Loop: Header=BB11_47 Depth=1
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.eq	LBB11_50
	b	LBB11_49
LBB11_49:                               ;   in Loop: Header=BB11_47 Depth=1
	b	LBB11_51
LBB11_50:                               ;   in Loop: Header=BB11_47 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldur	x3, [x29, #-40]
	ldr	x1, [x9, #8]
	ldr	x2, [x9, #16]
	blr	x8
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldur	x3, [x29, #-40]
	ldr	x1, [x9, #24]
	ldr	x2, [x9, #32]
	blr	x8
	b	LBB11_51
LBB11_51:                               ;   in Loop: Header=BB11_47 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB11_47
LBB11_52:
	b	LBB11_61
LBB11_53:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB11_55
	b	LBB11_54
LBB11_54:
	b	LBB11_61
LBB11_55:
	strh	wzr, [sp, #46]
	b	LBB11_56
LBB11_56:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB11_59
	b	LBB11_57
LBB11_57:                               ;   in Loop: Header=BB11_56 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	add	x9, x9, #24
	ldrh	w10, [sp, #46]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldur	x3, [x29, #-40]
	ldr	x1, [x9]
	ldr	x2, [x9, #8]
	blr	x8
	b	LBB11_58
LBB11_58:                               ;   in Loop: Header=BB11_56 Depth=1
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB11_56
LBB11_59:
	b	LBB11_61
LBB11_60:
	b	LBB11_61
LBB11_61:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_gray_child
_mark_gray_child:                       ; @mark_gray_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	b	LBB12_5
LBB12_2:
	ldr	x8, [sp, #8]
	ldr	w8, [x8]
	subs	w8, w8, #0
	b.ls	LBB12_4
	b	LBB12_3
LBB12_3:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	b	LBB12_4
LBB12_4:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	bl	_mark_gray
	b	LBB12_5
LBB12_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_string
_val_string:                            ; @val_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	mov	w8, #5                          ; =0x5
	strb	w8, [sp, #16]
	ldr	x8, [sp, #8]
	str	x8, [sp, #24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_child
_scan_child:                            ; @scan_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]
	str	x2, [sp, #24]
	str	x0, [sp, #8]
	str	x3, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_scan
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scan_black_child
_scan_black_child:                      ; @scan_black_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-8]
	str	x0, [sp, #24]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-8]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	b	LBB15_4
LBB15_2:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	cbz	w8, LBB15_4
	b	LBB15_3
LBB15_3:
	ldr	x0, [sp, #24]
	ldur	x1, [x29, #-16]
	ldur	x2, [x29, #-8]
	bl	_scan_black
	b	LBB15_4
LBB15_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function for_each_child_slot
_for_each_child_slot:                   ; @for_each_child_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	x1, [x8]
	str	x2, [x8, #8]
	stur	x0, [x29, #-24]
	stur	x3, [x29, #-32]
	stur	x4, [x29, #-40]
	ldurb	w8, [x29, #-16]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	subs	w8, w8, #7
	b.eq	LBB16_6
	b	LBB16_1
LBB16_1:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #8
	b.eq	LBB16_14
	b	LBB16_2
LBB16_2:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB16_27
	b	LBB16_3
LBB16_3:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #12
	b.eq	LBB16_34
	b	LBB16_4
LBB16_4:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB16_41
	b	LBB16_5
LBB16_5:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB16_51
	b	LBB16_58
LBB16_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB16_8
	b	LBB16_7
LBB16_7:
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8, #9]
	cbz	w8, LBB16_9
	b	LBB16_8
LBB16_8:
	b	LBB16_59
LBB16_9:
	stur	wzr, [x29, #-52]
	b	LBB16_10
LBB16_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB16_13
	b	LBB16_11
LBB16_11:                               ;   in Loop: Header=BB16_10 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_12
LBB16_12:                               ;   in Loop: Header=BB16_10 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB16_10
LBB16_13:
	b	LBB16_59
LBB16_14:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbnz	x8, LBB16_16
	b	LBB16_15
LBB16_15:
	b	LBB16_59
LBB16_16:
	stur	wzr, [x29, #-68]
	b	LBB16_17
LBB16_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB16_20
	b	LBB16_18
LBB16_18:                               ;   in Loop: Header=BB16_17 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #24]
	ldur	w10, [x29, #-68]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_19
LBB16_19:                               ;   in Loop: Header=BB16_17 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB16_17
LBB16_20:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	cbz	x8, LBB16_26
	b	LBB16_21
LBB16_21:
	stur	wzr, [x29, #-72]
	b	LBB16_22
LBB16_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-72]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB16_25
	b	LBB16_23
LBB16_23:                               ;   in Loop: Header=BB16_22 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-72]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_val_string
	mov	x8, x1
	add	x1, sp, #88
	str	x0, [sp, #88]
	str	x8, [sp, #96]
	ldur	x8, [x29, #-64]
	ldr	x9, [x8, #16]
	ldur	w8, [x29, #-72]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_24
LBB16_24:                               ;   in Loop: Header=BB16_22 Depth=1
	ldur	w8, [x29, #-72]
	add	w8, w8, #1
	stur	w8, [x29, #-72]
	b	LBB16_22
LBB16_25:
	b	LBB16_26
LBB16_26:
	b	LBB16_59
LBB16_27:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #80]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB16_29
	b	LBB16_28
LBB16_28:
	b	LBB16_59
LBB16_29:
	str	wzr, [sp, #76]
	b	LBB16_30
LBB16_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #80]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB16_33
	b	LBB16_31
LBB16_31:                               ;   in Loop: Header=BB16_30 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #80]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #76]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_32
LBB16_32:                               ;   in Loop: Header=BB16_30 Depth=1
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB16_30
LBB16_33:
	b	LBB16_59
LBB16_34:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB16_36
	b	LBB16_35
LBB16_35:
	b	LBB16_59
LBB16_36:
	str	wzr, [sp, #60]
	b	LBB16_37
LBB16_37:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB16_40
	b	LBB16_38
LBB16_38:                               ;   in Loop: Header=BB16_37 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #64]
	add	x9, x9, #16
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_39
LBB16_39:                               ;   in Loop: Header=BB16_37 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB16_37
LBB16_40:
	b	LBB16_59
LBB16_41:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	cbz	x8, LBB16_43
	b	LBB16_42
LBB16_42:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #24]
	cbnz	x8, LBB16_44
	b	LBB16_43
LBB16_43:
	b	LBB16_59
LBB16_44:
	str	wzr, [sp, #44]
	b	LBB16_45
LBB16_45:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB16_50
	b	LBB16_46
LBB16_46:                               ;   in Loop: Header=BB16_45 Depth=1
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.eq	LBB16_48
	b	LBB16_47
LBB16_47:                               ;   in Loop: Header=BB16_45 Depth=1
	b	LBB16_49
LBB16_48:                               ;   in Loop: Header=BB16_45 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x1, x9, #8
	ldur	x2, [x29, #-40]
	blr	x8
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #48]
	ldr	x11, [x9, #24]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x1, x9, #24
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_49
LBB16_49:                               ;   in Loop: Header=BB16_45 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB16_45
LBB16_50:
	b	LBB16_59
LBB16_51:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB16_53
	b	LBB16_52
LBB16_52:
	b	LBB16_59
LBB16_53:
	strh	wzr, [sp, #30]
	b	LBB16_54
LBB16_54:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB16_57
	b	LBB16_55
LBB16_55:                               ;   in Loop: Header=BB16_54 Depth=1
	ldur	x8, [x29, #-32]
	ldur	x0, [x29, #-24]
	ldr	x9, [sp, #32]
	add	x9, x9, #24
	ldrh	w10, [sp, #30]
                                        ; kill: def $x10 killed $w10
	add	x1, x9, x10, lsl #4
	ldur	x2, [x29, #-40]
	blr	x8
	b	LBB16_56
LBB16_56:                               ;   in Loop: Header=BB16_54 Depth=1
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB16_54
LBB16_57:
	b	LBB16_59
LBB16_58:
	b	LBB16_59
LBB16_59:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_white_slot
_collect_white_slot:                    ; @collect_white_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	q0, [x8]
	str	q0, [sp, #32]
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	bl	_val_void
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	bl	_header_of
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB17_4
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #5]
	subs	w8, w8, #2
	b.ne	LBB17_4
	b	LBB17_2
LBB17_2:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8, #6]
	cbnz	w8, LBB17_4
	b	LBB17_3
LBB17_3:
	ldur	x0, [x29, #-8]
	ldur	x3, [x29, #-24]
	ldr	x1, [sp, #32]
	ldr	x2, [sp, #40]
	bl	_collect_white
	b	LBB17_4
LBB17_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function dead_push
_dead_push:                             ; @dead_push
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB18_7
	b	LBB18_1
LBB18_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	cbz	w8, LBB18_3
	b	LBB18_2
LBB18_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	lsl	w8, w8, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB18_4
LBB18_3:
	mov	w8, #32                         ; =0x20
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB18_4
LBB18_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #20]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #3
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB18_6
	b	LBB18_5
LBB18_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_8
LBB18_6:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9]
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #12]
	b	LBB18_7
LBB18_7:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x10, [x9]
	ldur	x13, [x29, #-16]
	ldr	w9, [x13, #8]
	mov	x11, x9
	mov	x12, x11
	mov	w9, #1                          ; =0x1
	add	w12, w12, #1
	str	w12, [x13, #8]
	str	x8, [x10, x11, lsl #3]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB18_8
LBB18_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function val_void
_val_void:                              ; @val_void
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	xzr, [sp]
	str	xzr, [sp, #8]
	strb	wzr, [sp]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
