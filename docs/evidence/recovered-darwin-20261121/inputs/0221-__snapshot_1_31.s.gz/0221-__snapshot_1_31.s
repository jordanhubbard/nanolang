	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_vm_decoded_function_free ; -- Begin function vm_decoded_function_free
	.globl	_vm_decoded_function_free
	.p2align	2
_vm_decoded_function_free:              ; @vm_decoded_function_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_vm_decoded_module_free ; -- Begin function vm_decoded_module_free
	.globl	_vm_decoded_module_free
	.p2align	2
_vm_decoded_module_free:                ; @vm_decoded_module_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB1_6
; %bb.2:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB1_4
LBB1_3:                                 ;   in Loop: Header=BB1_4 Depth=1
	add	x21, x21, #1
	add	x20, x20, #32
	cmp	x21, x8
	b.hs	LBB1_6
LBB1_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cbz	x9, LBB1_3
; %bb.5:                                ;   in Loop: Header=BB1_4 Depth=1
	add	x22, x9, x20
	ldr	x0, [x22]
	bl	_free
	ldr	x0, [x22, #16]
	bl	_free
	ldr	x0, [x22, #24]
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22]
	ldr	w8, [x19, #8]
	b	LBB1_3
LBB1_6:
	ldr	x0, [x19]
	bl	_free
	stp	xzr, xzr, [x19]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB1_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_vm_decoded_function_has_boundary ; -- Begin function vm_decoded_function_has_boundary
	.globl	_vm_decoded_function_has_boundary
	.p2align	2
_vm_decoded_function_has_boundary:      ; @vm_decoded_function_has_boundary
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_5
; %bb.1:
	ldr	w8, [x0, #12]
	cmp	w1, w8
	b.hi	LBB2_4
; %bb.2:
	ldr	x8, [x0, #16]
	cbz	x8, LBB2_4
; %bb.3:
	ldrb	w8, [x8, w1, uxtw]
	cmp	w8, #0
	cset	w0, ne
	ret
LBB2_4:
	mov	w0, #0                          ; =0x0
LBB2_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_vm_decode_function     ; -- Begin function vm_decode_function
	.globl	_vm_decode_function
	.p2align	2
_vm_decode_function:                    ; @vm_decode_function
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB3_12
; %bb.1:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x2]
	cbz	x0, LBB3_10
; %bb.2:
	ldr	w8, [x0, #272]
	cmp	w19, w8
	b.hs	LBB3_10
; %bb.3:
	ldr	x8, [x0, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x22, w19, w9, x8
	ldr	w20, [x22, #8]
	ldr	w8, [x0, #288]
	cmp	w8, w20
	b.lo	LBB3_13
; %bb.4:
	ldr	w25, [x22, #12]
	sub	w8, w8, w20
	cmp	w25, w8
	b.hi	LBB3_13
; %bb.5:
	ldr	x26, [x0, #280]
	cmp	w25, #0
	ccmp	x26, #0, #0, ne
	b.eq	LBB3_13
; %bb.6:
	mov	x23, x0
	str	x3, [sp, #24]                   ; 8-byte Folded Spill
	str	w25, [x2, #12]
	add	x0, x25, #1
	mov	w1, #1                          ; =0x1
	mov	x24, x2
	bl	_calloc
	mov	x21, x0
	str	x0, [x24, #16]
	add	x0, x25, #1
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x8, x24
	str	x0, [x24, #24]
	cmp	x21, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB3_19
; %bb.7:
	mov	x0, x8
	bl	_vm_decoded_function_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x0, LBB3_18
; %bb.8:
	ldr	w8, [x22, #8]
LBB3_9:
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	stp	x19, x8, [sp]
Lloh0:
	adrp	x2, l_.str.2@PAGE
Lloh1:
	add	x2, x2, l_.str.2@PAGEOFF
	b	LBB3_16
LBB3_10:
	cbz	x3, LBB3_17
; %bb.11:
	stp	x19, xzr, [sp]
Lloh2:
	adrp	x2, l_.str@PAGE
Lloh3:
	add	x2, x2, l_.str@PAGEOFF
	b	LBB3_15
LBB3_12:
	mov	w0, #0                          ; =0x0
	ret
LBB3_13:
	cbz	x3, LBB3_17
; %bb.14:
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	stp	x19, x20, [sp]
Lloh4:
	adrp	x2, l_.str.1@PAGE
Lloh5:
	add	x2, x2, l_.str.1@PAGEOFF
LBB3_15:
	mov	x0, x3
LBB3_16:
	mov	w1, #256                        ; =0x100
	bl	_snprintf
LBB3_17:
	mov	w0, #0                          ; =0x0
LBB3_18:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB3_19:
	add	x9, x26, x20
	cmp	w25, #0
	csel	x26, xzr, x9, eq
	cbz	w25, LBB3_27
; %bb.20:
	mov	w27, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	ldr	w11, [x8, #8]
LBB3_21:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x8]
	cmp	w11, w27
	b.ne	LBB3_24
; %bb.22:                               ;   in Loop: Header=BB3_21 Depth=1
	lsl	w8, w11, #1
	cmp	w11, #0
	mov	w9, #16                         ; =0x10
	csel	w27, w9, w8, eq
	mov	w8, #104                        ; =0x68
	umull	x1, w27, w8
	bl	_realloc
	cbz	x0, LBB3_55
; %bb.23:                               ;   in Loop: Header=BB3_21 Depth=1
	str	x0, [x24]
	ldr	w11, [x24, #8]
	ldr	w25, [x22, #12]
LBB3_24:                                ;   in Loop: Header=BB3_21 Depth=1
	mov	w8, #104                        ; =0x68
	umaddl	x28, w11, w8, x0
	mov	w20, w21
	sub	w1, w25, w21
	add	x0, x26, x20
	add	x2, x28, #40
	bl	_isa_decode
	cbz	w0, LBB3_53
; %bb.25:                               ;   in Loop: Header=BB3_21 Depth=1
	str	w21, [x28]
	add	w21, w0, w21
	mov	w8, #-1                         ; =0xffffffff
	stp	w21, w8, [x28, #4]
	stp	xzr, xzr, [x28, #16]
	stur	xzr, [x28, #29]
	mov	x8, x24
	ldr	x9, [x24, #16]
	mov	w10, #1                         ; =0x1
	strb	w10, [x9, x20]
	ldr	w9, [x24, #8]
	add	w9, w9, #1
	ldr	x10, [x24, #24]
	str	w9, [x10, x20, lsl #2]
	ldr	w9, [x24, #8]
	add	w11, w9, #1
	str	w11, [x24, #8]
	ldr	w25, [x22, #12]
	cmp	w21, w25
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	b.lo	LBB3_21
; %bb.26:
	mov	x10, x23
	ldr	x21, [x8, #16]
	b	LBB3_28
LBB3_27:
	mov	x25, #0                         ; =0x0
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	x10, x23
LBB3_28:
	mov	w11, #1                         ; =0x1
	strb	w11, [x21, x25]
	ldr	w11, [x8, #8]
	cbz	w11, LBB3_50
; %bb.29:
	ldr	x12, [x8]
	mov	w13, #1                         ; =0x1
	mov	x14, #1                         ; =0x1
	movk	x14, #128, lsl #32
	movk	x14, #1024, lsl #48
LBB3_30:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w16, [x12, #40]
	sub	w15, w16, #107
	cmp	w15, #58
	lsl	x15, x13, x15
	and	x15, x15, x14
	ccmp	x15, #0, #4, ls
	b.ne	LBB3_33
; %bb.31:                               ;   in Loop: Header=BB3_30 Depth=1
	sub	w15, w16, #56
	cmp	w15, #3
	b.hs	LBB3_44
; %bb.32:                               ;   in Loop: Header=BB3_30 Depth=1
	mov	w15, #48                        ; =0x30
	b	LBB3_34
LBB3_33:                                ;   in Loop: Header=BB3_30 Depth=1
	mov	w15, #56                        ; =0x38
LBB3_34:                                ;   in Loop: Header=BB3_30 Depth=1
	ldrsw	x15, [x12, x15]
	ldr	w20, [x12]
	add	x15, x20, x15
	lsr	x17, x15, #32
	cbnz	x17, LBB3_48
; %bb.35:                               ;   in Loop: Header=BB3_30 Depth=1
	cmp	w16, #146
	b.ne	LBB3_38
; %bb.36:                               ;   in Loop: Header=BB3_30 Depth=1
	ldr	w16, [x22, #12]
	cmp	x15, x16
	b.hs	LBB3_48
; %bb.37:                               ;   in Loop: Header=BB3_30 Depth=1
	ldr	w17, [x12, #4]
	cmp	w17, w16
	b.hs	LBB3_48
LBB3_38:                                ;   in Loop: Header=BB3_30 Depth=1
	ldr	w16, [x8, #12]
	cmp	w16, w15
	b.lo	LBB3_48
; %bb.39:                               ;   in Loop: Header=BB3_30 Depth=1
	ldr	x16, [x8, #16]
	cbz	x16, LBB3_48
; %bb.40:                               ;   in Loop: Header=BB3_30 Depth=1
	ldrb	w16, [x16, x15]
	cbz	w16, LBB3_48
; %bb.41:                               ;   in Loop: Header=BB3_30 Depth=1
	ldr	w16, [x22, #8]
	add	w15, w16, w15
LBB3_42:                                ;   in Loop: Header=BB3_30 Depth=1
	str	w15, [x12, #8]
LBB3_43:                                ;   in Loop: Header=BB3_30 Depth=1
	add	x12, x12, #104
	subs	x11, x11, #1
	b.ne	LBB3_30
	b	LBB3_50
LBB3_44:                                ;   in Loop: Header=BB3_30 Depth=1
	and	w15, w16, #0xfffffff7
	cmp	w15, #51
	b.ne	LBB3_43
; %bb.45:                               ;   in Loop: Header=BB3_30 Depth=1
	ldr	w15, [x12, #48]
	ldr	w16, [x10, #272]
	cmp	w15, w16
	b.lo	LBB3_42
; %bb.46:
	ldr	w20, [x22, #8]
	ldr	w21, [x12]
	mov	x0, x8
	mov	x22, x9
	bl	_vm_decoded_function_free
	cbz	x22, LBB3_17
; %bb.47:
	add	w8, w21, w20
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	stp	x19, x8, [sp]
Lloh6:
	adrp	x2, l_.str.5@PAGE
Lloh7:
	add	x2, x2, l_.str.5@PAGEOFF
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB3_16
LBB3_48:
	ldr	w21, [x22, #8]
	mov	x0, x8
	bl	_vm_decoded_function_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x0, LBB3_18
; %bb.49:
	add	w8, w21, w20
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	stp	x19, x8, [sp]
Lloh8:
	adrp	x2, l_.str.4@PAGE
Lloh9:
	add	x2, x2, l_.str.4@PAGEOFF
	b	LBB3_16
LBB3_50:
	cbz	x9, LBB3_52
; %bb.51:
	strb	wzr, [x9]
LBB3_52:
	mov	w0, #1                          ; =0x1
	b	LBB3_18
LBB3_53:
	ldr	x0, [x24]
	bl	_free
	ldr	x0, [x24, #16]
	bl	_free
	ldr	x0, [x24, #24]
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x0, LBB3_18
; %bb.54:
	ldr	w8, [x22, #8]
	add	w8, w8, w21
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	stp	x19, x8, [sp]
Lloh10:
	adrp	x2, l_.str.3@PAGE
Lloh11:
	add	x2, x2, l_.str.3@PAGEOFF
	b	LBB3_16
LBB3_55:
	ldr	x0, [x24]
	bl	_free
	ldr	x0, [x24, #16]
	bl	_free
	ldr	x0, [x24, #24]
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x0, LBB3_18
; %bb.56:
	ldr	w8, [x22, #8]
	add	w8, w8, w21
	b	LBB3_9
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_vm_decoded_function_at ; -- Begin function vm_decoded_function_at
	.globl	_vm_decoded_function_at
	.p2align	2
_vm_decoded_function_at:                ; @vm_decoded_function_at
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_6
; %bb.1:
	ldr	w8, [x0, #12]
	cmp	w1, w8
	b.hs	LBB4_5
; %bb.2:
	ldr	x8, [x0, #24]
	cbz	x8, LBB4_5
; %bb.3:
	ldr	w8, [x8, w1, uxtw #2]
	cbz	w8, LBB4_5
; %bb.4:
	ldr	x9, [x0]
	sub	w8, w8, #1
	mov	w10, #104                       ; =0x68
	umaddl	x0, w8, w10, x9
	ret
LBB4_5:
	mov	x0, #0                          ; =0x0
LBB4_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_vm_decode_module       ; -- Begin function vm_decode_module
	.globl	_vm_decode_module
	.p2align	2
_vm_decode_module:                      ; @vm_decode_module
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB5_10
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x2
	mov	x19, x1
	mov	x21, x0
	stp	xzr, xzr, [x1]
	cbz	x0, LBB5_11
; %bb.2:
	ldr	w23, [x21, #272]
	cbz	w23, LBB5_7
; %bb.3:
	mov	x0, x23
	mov	w1, #32                         ; =0x20
	bl	_calloc
	str	x0, [x19]
	cbz	x0, LBB5_13
; %bb.4:
	mov	x24, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	str	w23, [x19, #8]
LBB5_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19]
	add	x2, x8, x24
	mov	x0, x21
	mov	x1, x22
	mov	x3, x20
	bl	_vm_decode_function
	tbz	w0, #0, LBB5_15
; %bb.6:                                ;   in Loop: Header=BB5_5 Depth=1
	add	x22, x22, #1
	ldr	w8, [x21, #272]
	add	x24, x24, #32
	cmp	x22, x8
	b.lo	LBB5_5
LBB5_7:
	cbz	x20, LBB5_9
; %bb.8:
	strb	wzr, [x20]
LBB5_9:
	mov	w0, #1                          ; =0x1
	b	LBB5_21
LBB5_10:
	mov	w0, #0                          ; =0x0
	ret
LBB5_11:
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB5_21
; %bb.12:
Lloh12:
	adrp	x8, l_.str.6@PAGE
Lloh13:
	add	x8, x8, l_.str.6@PAGEOFF
	ldr	x9, [x8]
	str	x9, [x20]
	ldur	x8, [x8, #7]
	stur	x8, [x20, #7]
	b	LBB5_21
LBB5_13:
	mov	w0, #0                          ; =0x0
	cbz	x20, LBB5_21
; %bb.14:
Lloh14:
	adrp	x8, l_.str.7@PAGE
Lloh15:
	add	x8, x8, l_.str.7@PAGEOFF
	ldr	q0, [x8]
	str	q0, [x20]
	ldur	q0, [x8, #9]
	stur	q0, [x20, #9]
	b	LBB5_21
LBB5_15:
	ldr	w8, [x19, #8]
	cbz	w8, LBB5_20
; %bb.16:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB5_18
LBB5_17:                                ;   in Loop: Header=BB5_18 Depth=1
	add	x21, x21, #1
	add	x20, x20, #32
	cmp	x21, x8
	b.hs	LBB5_20
LBB5_18:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cbz	x9, LBB5_17
; %bb.19:                               ;   in Loop: Header=BB5_18 Depth=1
	add	x22, x9, x20
	ldr	x0, [x22]
	bl	_free
	ldr	x0, [x22, #16]
	bl	_free
	ldr	x0, [x22, #24]
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22]
	ldr	w8, [x19, #8]
	b	LBB5_17
LBB5_20:
	ldr	x0, [x19]
	bl	_free
	mov	w0, #0                          ; =0x0
	stp	xzr, xzr, [x19]
LBB5_21:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"function index %u is invalid at offset %u"

l_.str.1:                               ; @.str.1
	.asciz	"function[%u] has an invalid code range at offset %u"

l_.str.2:                               ; @.str.2
	.asciz	"function[%u] allocation failed at offset %u"

l_.str.3:                               ; @.str.3
	.asciz	"function[%u] invalid instruction at offset %u"

l_.str.4:                               ; @.str.4
	.asciz	"function[%u] branch targets a non-instruction boundary at offset %u"

l_.str.5:                               ; @.str.5
	.asciz	"function[%u] direct call has an invalid target at offset %u"

l_.str.6:                               ; @.str.6
	.asciz	"module is NULL"

l_.str.7:                               ; @.str.7
	.asciz	"module allocation failed"

.subsections_via_symbols
