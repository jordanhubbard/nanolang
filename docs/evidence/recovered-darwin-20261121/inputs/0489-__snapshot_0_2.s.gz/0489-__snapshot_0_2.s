	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_layouts_have_facts         ; -- Begin function nvm_layouts_have_facts
	.p2align	2
_nvm_layouts_have_facts:                ; @nvm_layouts_have_facts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB0_3
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #8]
	cbz	w8, LBB0_4
	b	LBB0_2
LBB0_2:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	cbnz	x8, LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_12
LBB0_4:
	str	wzr, [sp, #12]
	b	LBB0_5
LBB0_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB0_11
	b	LBB0_6
LBB0_6:                                 ;   in Loop: Header=BB0_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.ne	LBB0_8
	b	LBB0_7
LBB0_7:                                 ;   in Loop: Header=BB0_5 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	cbz	w8, LBB0_9
	b	LBB0_8
LBB0_8:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_12
LBB0_9:                                 ;   in Loop: Header=BB0_5 Depth=1
	b	LBB0_10
LBB0_10:                                ;   in Loop: Header=BB0_5 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB0_5
LBB0_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB0_12
LBB0_12:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_retained_layouts_valid     ; -- Begin function nvm_retained_layouts_valid
	.p2align	2
_nvm_retained_layouts_valid:            ; @nvm_retained_layouts_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_11
LBB1_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_11
LBB1_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbnz	x8, LBB1_6
	b	LBB1_5
LBB1_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_11
LBB1_6:
	add	x2, sp, #16
	str	xzr, [sp, #16]
	str	xzr, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbz	w8, LBB1_8
	b	LBB1_7
LBB1_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_11
LBB1_8:
	add	x0, sp, #16
	bl	_nvm_v2_layouts_encoded_size
	mov	x8, x0
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #320]
                                        ; kill: def $x9 killed $w9
	mov	w0, #0                          ; =0x0
	subs	x8, x8, x9
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB1_10
	b	LBB1_9
LBB1_9:
	ldur	x0, [x29, #-16]
	add	x1, sp, #16
	bl	_table_valid
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB1_10
LBB1_10:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #11]
	add	x0, sp, #16
	bl	_nvm_v2_layouts_free
	ldrb	w8, [sp, #11]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_11
LBB1_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function table_valid
_table_valid:                           ; @table_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	wzr, [x29, #-28]
	str	wzr, [sp, #32]
	str	wzr, [sp, #28]
	str	wzr, [sp, #24]
	b	LBB2_1
LBB2_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_14 Depth 2
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB2_21
	b	LBB2_2
LBB2_2:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	w0, [x8, #4]
	ldur	x1, [x29, #-16]
	bl	_name_valid
	tbnz	w0, #0, LBB2_4
	b	LBB2_3
LBB2_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_25
LBB2_4:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB2_8
	b	LBB2_5
LBB2_5:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB2_11
	b	LBB2_6
LBB2_6:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB2_10
	b	LBB2_7
LBB2_7:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB2_9
	b	LBB2_12
LBB2_8:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB2_13
LBB2_9:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB2_13
LBB2_10:                                ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB2_13
LBB2_11:                                ;   in Loop: Header=BB2_1 Depth=1
	b	LBB2_13
LBB2_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_25
LBB2_13:                                ;   in Loop: Header=BB2_1 Depth=1
	strh	wzr, [sp, #14]
	b	LBB2_14
LBB2_14:                                ;   Parent Loop BB2_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB2_19
	b	LBB2_15
LBB2_15:                                ;   in Loop: Header=BB2_14 Depth=2
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w0, [x8, #8]
	ldur	x1, [x29, #-16]
	bl	_name_valid
	tbnz	w0, #0, LBB2_17
	b	LBB2_16
LBB2_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_25
LBB2_17:                                ;   in Loop: Header=BB2_14 Depth=2
	b	LBB2_18
LBB2_18:                                ;   in Loop: Header=BB2_14 Depth=2
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB2_14
LBB2_19:                                ;   in Loop: Header=BB2_1 Depth=1
	b	LBB2_20
LBB2_20:                                ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB2_1
LBB2_21:
	ldur	w9, [x29, #-28]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #468]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB2_24
	b	LBB2_22
LBB2_22:
	ldr	w9, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	w10, [x8, #472]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB2_24
	b	LBB2_23
LBB2_23:
	ldr	w8, [sp, #28]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB2_24
LBB2_24:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB2_25
LBB2_25:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_retain_layouts             ; -- Begin function nvm_retain_layouts
	.p2align	2
_nvm_retain_layouts:                    ; @nvm_retain_layouts
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #544
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_4
	b	LBB3_1
LBB3_1:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB3_4
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #8]
	cbz	w8, LBB3_5
	b	LBB3_3
LBB3_3:
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	cbnz	x8, LBB3_5
	b	LBB3_4
LBB3_4:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_5:
	stur	wzr, [x29, #-44]
	b	LBB3_6
LBB3_6:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB3_12
	b	LBB3_7
LBB3_7:                                 ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	cbz	w8, LBB3_10
	b	LBB3_8
LBB3_8:                                 ;   in Loop: Header=BB3_6 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x8, [x8]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	cbnz	x8, LBB3_10
	b	LBB3_9
LBB3_9:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_10:                                ;   in Loop: Header=BB3_6 Depth=1
	b	LBB3_11
LBB3_11:                                ;   in Loop: Header=BB3_6 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB3_6
LBB3_12:
	ldur	x0, [x29, #-40]
	bl	_nvm_v2_layouts_encoded_size
	stur	x0, [x29, #-56]
	ldur	x8, [x29, #-56]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.ls	LBB3_14
	b	LBB3_13
LBB3_13:
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_14:
	ldur	x0, [x29, #-56]
	bl	_malloc
	stur	x0, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbnz	x8, LBB3_16
	b	LBB3_15
LBB3_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_16:
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-64]
	ldur	x2, [x29, #-56]
	bl	_nvm_v2_layouts_encode
	stur	w0, [x29, #-68]
	ldur	w8, [x29, #-68]
	cbz	w8, LBB3_18
	b	LBB3_17
LBB3_17:
	ldur	x0, [x29, #-64]
	bl	_free
	ldur	w8, [x29, #-68]
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_18:
	ldur	x1, [x29, #-32]
	add	x0, sp, #8
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x2, #480                        ; =0x1e0
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x29, #-64]
	str	x8, [sp, #320]
	ldur	x8, [x29, #-56]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #328]
	bl	_nvm_retained_layouts_valid
	tbnz	w0, #0, LBB3_20
	b	LBB3_19
LBB3_19:
	ldur	x0, [x29, #-64]
	bl	_free
	mov	w8, #13                         ; =0xd
	stur	w8, [x29, #-20]
	b	LBB3_21
LBB3_20:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #312]
	bl	_free
	ldur	x8, [x29, #-64]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #312]
	ldur	x8, [x29, #-56]
	ldur	x9, [x29, #-32]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, #320]
	stur	wzr, [x29, #-20]
	b	LBB3_21
LBB3_21:
	ldur	w0, [x29, #-20]
	add	sp, sp, #544
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_plan_free           ; -- Begin function nvm_record_plan_free
	.p2align	2
_nvm_record_plan_free:                  ; @nvm_record_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	b	LBB4_3
LBB4_2:
	ldr	x0, [sp, #8]
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #24]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB4_3
LBB4_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_describe_managed_records   ; -- Begin function nvm_describe_managed_records
	.p2align	2
_nvm_describe_managed_records:          ; @nvm_describe_managed_records
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1392
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #192
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #352]
	str	x1, [sp, #344]
	ldr	x8, [sp, #352]
	cbz	x8, LBB5_4
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #344]
	cbz	x8, LBB5_4
	b	LBB5_2
LBB5_2:
	ldr	x8, [sp, #352]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #352]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB5_4
	b	LBB5_3
LBB5_3:
	ldr	x8, [sp, #352]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #352]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB5_5
	b	LBB5_4
LBB5_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str@PAGE
	add	x3, x3, l_.str@PAGEOFF
	bl	_record_result
	b	LBB5_76
LBB5_5:
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB5_7
	b	LBB5_6
LBB5_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.1@PAGE
	add	x3, x3, l_.str.1@PAGEOFF
	bl	_record_result
	b	LBB5_76
LBB5_7:
	add	x1, sp, #343
	strb	wzr, [sp, #343]
	ldr	x0, [sp, #352]
	add	x8, sp, #304
	bl	_record_preflight
	ldr	w8, [sp, #304]
	cbz	w8, LBB5_9
	b	LBB5_8
LBB5_8:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [x8, #112]
	str	q0, [x9]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB5_76
LBB5_9:
	add	x2, sp, #288
	str	xzr, [sp, #288]
	str	xzr, [sp, #296]
	ldr	x8, [sp, #352]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #284]
	ldr	w8, [sp, #284]
	cbz	w8, LBB5_11
	b	LBB5_10
LBB5_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #284]
	mov	w10, #2                         ; =0x2
	mov	w9, #4                          ; =0x4
	subs	w11, w11, #1
	csel	w0, w9, w10, eq
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.2@PAGE
	add	x3, x3, l_.str.2@PAGEOFF
	bl	_record_result
	b	LBB5_76
LBB5_11:
	str	wzr, [sp, #280]
	b	LBB5_12
LBB5_12:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_16 Depth 2
	ldr	w8, [sp, #280]
	ldr	w9, [sp, #296]
	subs	w8, w8, w9
	b.hs	LBB5_43
	b	LBB5_13
LBB5_13:                                ;   in Loop: Header=BB5_12 Depth=1
	ldr	x8, [sp, #288]
	ldr	w9, [sp, #280]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #272]
	ldr	x8, [sp, #272]
	ldrb	w8, [x8]
	cbz	w8, LBB5_15
	b	LBB5_14
LBB5_14:                                ;   in Loop: Header=BB5_12 Depth=1
	b	LBB5_42
LBB5_15:                                ;   in Loop: Header=BB5_12 Depth=1
	strh	wzr, [sp, #270]
	b	LBB5_16
LBB5_16:                                ;   Parent Loop BB5_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #270]
	ldr	x9, [sp, #272]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB5_41
	b	LBB5_17
LBB5_17:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #272]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #270]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #256]
	ldr	x8, [sp, #256]
	ldrb	w8, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	w8, LBB5_26
	b	LBB5_18
LBB5_18:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_19
LBB5_19:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_20
LBB5_20:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_21
LBB5_21:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_22
LBB5_22:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #5
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_23
LBB5_23:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #7
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_24
LBB5_24:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #9
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB5_26
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB5_26
LBB5_26:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #255]
	ldrb	w8, [sp, #255]
	tbnz	w8, #0, LBB5_28
	b	LBB5_27
LBB5_27:
	ldr	w1, [sp, #280]
	ldrh	w2, [sp, #270]
	add	x8, sp, #224
	mov	w0, #1                          ; =0x1
	adrp	x3, l_.str.3@PAGE
	add	x3, x3, l_.str.3@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [x8, #32]
	str	q0, [x8, #112]
	ldr	x8, [sp, #240]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_28:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #4]
	str	w8, [sp, #220]
	ldr	x8, [sp, #256]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB5_32
	b	LBB5_29
LBB5_29:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w9, [sp, #220]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB5_31
	b	LBB5_30
LBB5_30:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #288]
	ldr	w9, [sp, #220]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB5_31
LBB5_31:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB5_37
LBB5_32:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w9, [sp, #220]
	mov	w8, #1                          ; =0x1
	adds	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB5_36
	b	LBB5_33
LBB5_33:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #256]
	ldrb	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #9
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB5_35
	b	LBB5_34
LBB5_34:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	x8, [sp, #288]
	ldr	w9, [sp, #220]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB5_35
LBB5_35:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB5_36
LBB5_36:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB5_37
LBB5_37:                                ;   in Loop: Header=BB5_16 Depth=2
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #219]
	ldrb	w8, [sp, #219]
	tbnz	w8, #0, LBB5_39
	b	LBB5_38
LBB5_38:
	ldr	w1, [sp, #280]
	ldrh	w2, [sp, #270]
	add	x8, sp, #192
	mov	w0, #2                          ; =0x2
	adrp	x3, l_.str.4@PAGE
	add	x3, x3, l_.str.4@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [x8]
	str	q0, [x8, #112]
	ldr	x8, [sp, #208]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_39:                                ;   in Loop: Header=BB5_16 Depth=2
	b	LBB5_40
LBB5_40:                                ;   in Loop: Header=BB5_16 Depth=2
	ldrh	w8, [sp, #270]
	add	w8, w8, #1
	strh	w8, [sp, #270]
	b	LBB5_16
LBB5_41:                                ;   in Loop: Header=BB5_12 Depth=1
	b	LBB5_42
LBB5_42:                                ;   in Loop: Header=BB5_12 Depth=1
	ldr	w8, [sp, #280]
	add	w8, w8, #1
	str	w8, [sp, #280]
	b	LBB5_12
LBB5_43:
	str	wzr, [sp, #188]
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #304]
	cbz	w8, LBB5_54
	b	LBB5_44
LBB5_44:
	ldr	x0, [sp, #352]
	ldr	w1, [sp, #296]
	add	x2, sp, #360
	bl	_nvm_ownership_layout_authorities
	cbz	w0, LBB5_46
	b	LBB5_45
LBB5_45:
	add	x8, sp, #160
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.5@PAGE
	add	x3, x3, l_.str.5@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #160]
	str	q0, [x8, #112]
	ldr	x8, [sp, #176]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_46:
	str	wzr, [sp, #156]
	b	LBB5_47
LBB5_47:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #156]
	ldr	w9, [sp, #296]
	subs	w8, w8, w9
	b.hs	LBB5_53
	b	LBB5_48
LBB5_48:                                ;   in Loop: Header=BB5_47 Depth=1
	ldr	x8, [sp, #288]
	ldr	w9, [sp, #156]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB5_51
	b	LBB5_49
LBB5_49:                                ;   in Loop: Header=BB5_47 Depth=1
	ldr	w8, [sp, #156]
	mov	x9, x8
	add	x8, sp, #360
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #1
	b.eq	LBB5_51
	b	LBB5_50
LBB5_50:
	ldr	w1, [sp, #156]
	add	x8, sp, #128
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.6@PAGE
	add	x3, x3, l_.str.6@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #128]
	str	q0, [x8, #112]
	ldr	x8, [sp, #144]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_51:                                ;   in Loop: Header=BB5_47 Depth=1
	b	LBB5_52
LBB5_52:                                ;   in Loop: Header=BB5_47 Depth=1
	ldr	w8, [sp, #156]
	add	w8, w8, #1
	str	w8, [sp, #156]
	b	LBB5_47
LBB5_53:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #188]
	b	LBB5_54
LBB5_54:
	ldrb	w8, [sp, #343]
	tbz	w8, #0, LBB5_57
	b	LBB5_55
LBB5_55:
	ldr	w8, [sp, #188]
	subs	w8, w8, #1
	b.eq	LBB5_57
	b	LBB5_56
LBB5_56:
	add	x8, sp, #104
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.7@PAGE
	add	x3, x3, l_.str.7@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [sp, #104]
	str	q0, [x8, #112]
	ldr	x8, [sp, #120]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_57:
	mov	x0, #1                          ; =0x1
	mov	x1, #48                         ; =0x30
	bl	_calloc
	str	x0, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB5_59
	b	LBB5_58
LBB5_58:
	add	x8, sp, #72
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.8@PAGE
	add	x3, x3, l_.str.8@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [sp, #72]
	str	q0, [x8, #112]
	ldr	x8, [sp, #88]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_59:
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #468]
	ldr	x9, [sp, #96]
	str	w8, [x9, #16]
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #468]
	cbz	w8, LBB5_61
	b	LBB5_60
LBB5_60:
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #468]
	mov	x0, x8
	mov	x1, #4                          ; =0x4
	bl	_calloc
	ldr	x8, [sp, #96]
	str	x0, [x8, #24]
	b	LBB5_61
LBB5_61:
	ldr	w8, [sp, #296]
	cbz	w8, LBB5_63
	b	LBB5_62
LBB5_62:
	ldr	w8, [sp, #296]
	mov	x0, x8
	mov	x1, #4                          ; =0x4
	bl	_calloc
	ldr	x8, [sp, #96]
	str	x0, [x8, #32]
	b	LBB5_63
LBB5_63:
	ldr	x8, [sp, #352]
	ldr	w8, [x8, #468]
	cbz	w8, LBB5_65
	b	LBB5_64
LBB5_64:
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #24]
	cbz	x8, LBB5_67
	b	LBB5_65
LBB5_65:
	ldr	w8, [sp, #296]
	cbz	w8, LBB5_68
	b	LBB5_66
LBB5_66:
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB5_68
	b	LBB5_67
LBB5_67:
	ldr	x0, [sp, #96]
	bl	_nvm_record_plan_free
	add	x8, sp, #48
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.9@PAGE
	add	x3, x3, l_.str.9@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #48]
	str	q0, [x8, #112]
	ldr	x8, [sp, #64]
	str	x8, [sp, #320]
	b	LBB5_75
LBB5_68:
	str	wzr, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB5_69
LBB5_69:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #296]
	subs	w8, w8, w9
	b.hs	LBB5_74
	b	LBB5_70
LBB5_70:                                ;   in Loop: Header=BB5_69 Depth=1
	ldr	x8, [sp, #96]
	ldr	x9, [x8, #32]
	ldr	w8, [sp, #44]
	mov	x10, x8
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, x10, lsl #2]
	ldr	x8, [sp, #288]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB5_72
	b	LBB5_71
LBB5_71:                                ;   in Loop: Header=BB5_69 Depth=1
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #24]
	ldr	w10, [sp, #40]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #40]
	add	w9, w8, #1
	str	w9, [sp, #40]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #32]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	b	LBB5_72
LBB5_72:                                ;   in Loop: Header=BB5_69 Depth=1
	b	LBB5_73
LBB5_73:                                ;   in Loop: Header=BB5_69 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB5_69
LBB5_74:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #96]
	ldr	q0, [x10, #96]
	str	q0, [x9]
	ldr	w9, [sp, #188]
	ldr	x10, [sp, #96]
	str	w9, [x10, #40]
	ldr	x9, [sp, #96]
	ldr	x10, [sp, #344]
	str	x9, [x10]
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.10@PAGE
	add	x3, x3, l_.str.10@PAGEOFF
	bl	_record_result
	b	LBB5_76
LBB5_75:
	add	x0, sp, #288
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	q0, [x8, #112]
	str	q0, [x9]
	ldr	x8, [sp, #320]
	str	x8, [x9, #16]
	b	LBB5_76
LBB5_76:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB5_78
	b	LBB5_77
LBB5_77:
	bl	___stack_chk_fail
LBB5_78:
	add	sp, sp, #1392
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_result
_record_result:                         ; @record_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	mov	x9, x8
	str	w0, [sp, #28]
	str	w1, [sp, #24]
	str	w2, [sp, #20]
	str	x3, [sp, #8]
	ldr	w8, [sp, #28]
	str	w8, [x9]
	ldr	w8, [sp, #24]
	str	w8, [x9, #4]
	ldr	w8, [sp, #20]
	str	w8, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #8]
	str	x8, [x9, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_preflight
_record_preflight:                      ; @record_preflight
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3216
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #128]
	str	x1, [sp, #120]
	ldr	x8, [sp, #128]
	ldr	x1, [x8, #312]
	ldr	x8, [sp, #128]
	ldr	w8, [x8, #320]
	mov	x2, x8
	add	x0, sp, #96
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [sp, #88]
	str	wzr, [sp, #84]
	str	wzr, [sp, #80]
	str	wzr, [sp, #76]
	strb	wzr, [sp, #75]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #74]
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbz	w0, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.26@PAGE
	add	x3, x3, l_.str.26@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_2:
	ldr	w8, [sp, #92]
	subs	w8, w8, #256
	b.ls	LBB7_4
	b	LBB7_3
LBB7_3:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.40@PAGE
	add	x3, x3, l_.str.40@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_4:
	str	wzr, [sp, #68]
	b	LBB7_5
LBB7_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_17 Depth 2
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.hs	LBB7_50
	b	LBB7_6
LBB7_6:                                 ;   in Loop: Header=BB7_5 Depth=1
	add	x0, sp, #96
	add	x1, sp, #67
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_13
	b	LBB7_7
LBB7_7:                                 ;   in Loop: Header=BB7_5 Depth=1
	add	x0, sp, #96
	add	x1, sp, #66
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_13
	b	LBB7_8
LBB7_8:                                 ;   in Loop: Header=BB7_5 Depth=1
	add	x0, sp, #96
	add	x1, sp, #64
	bl	_nvm_v2_u16
	cbnz	w0, LBB7_13
	b	LBB7_9
LBB7_9:                                 ;   in Loop: Header=BB7_5 Depth=1
	add	x0, sp, #96
	add	x1, sp, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB7_13
	b	LBB7_10
LBB7_10:                                ;   in Loop: Header=BB7_5 Depth=1
	ldrb	w8, [sp, #66]
	cbnz	w8, LBB7_13
	b	LBB7_11
LBB7_11:                                ;   in Loop: Header=BB7_5 Depth=1
	ldrb	w8, [sp, #67]
	subs	w8, w8, #3
	b.gt	LBB7_13
	b	LBB7_12
LBB7_12:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	w0, [sp, #60]
	ldr	x1, [sp, #128]
	bl	_name_valid
	tbnz	w0, #0, LBB7_14
	b	LBB7_13
LBB7_13:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #68]
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.41@PAGE
	add	x3, x3, l_.str.41@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_14:                                ;   in Loop: Header=BB7_5 Depth=1
	ldrb	w9, [sp, #67]
	ldr	w8, [sp, #88]
	subs	w9, w9, #0
	cinc	w8, w8, eq
	str	w8, [sp, #88]
	ldrb	w9, [sp, #67]
	ldr	w8, [sp, #84]
	subs	w9, w9, #3
	cinc	w8, w8, eq
	str	w8, [sp, #84]
	ldrb	w9, [sp, #67]
	ldr	w8, [sp, #80]
	subs	w9, w9, #2
	cinc	w8, w8, eq
	str	w8, [sp, #80]
	ldrh	w8, [sp, #64]
	ldr	w10, [sp, #76]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB7_16
	b	LBB7_15
LBB7_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #68]
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.42@PAGE
	add	x3, x3, l_.str.42@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_16:                                ;   in Loop: Header=BB7_5 Depth=1
	ldrh	w9, [sp, #64]
	ldr	w8, [sp, #76]
	add	w8, w8, w9
	str	w8, [sp, #76]
	ldr	x8, [sp, #112]
	ldr	w9, [sp, #68]
	mov	x10, x9
	add	x9, sp, #1160
	str	x8, [x9, x10, lsl #3]
	ldrh	w8, [sp, #64]
	ldr	w9, [sp, #68]
	mov	x10, x9
	add	x9, sp, #136
	str	w8, [x9, x10, lsl #2]
	ldrb	w8, [sp, #67]
	subs	w8, w8, #0
	cset	w9, eq
	ldrb	w8, [sp, #74]
	and	w8, w8, #0x1
	ands	w8, w8, w9
	cset	w8, ne
	strb	w8, [sp, #74]
	str	wzr, [sp, #56]
	b	LBB7_17
LBB7_17:                                ;   Parent Loop BB7_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #56]
	ldrh	w9, [sp, #64]
	subs	w8, w8, w9
	b.hs	LBB7_48
	b	LBB7_18
LBB7_18:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #55
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_32
	b	LBB7_19
LBB7_19:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #54
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_32
	b	LBB7_20
LBB7_20:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #53
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_32
	b	LBB7_21
LBB7_21:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #52
	bl	_nvm_v2_u8
	cbnz	w0, LBB7_32
	b	LBB7_22
LBB7_22:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #48
	bl	_nvm_v2_u32
	cbnz	w0, LBB7_32
	b	LBB7_23
LBB7_23:                                ;   in Loop: Header=BB7_17 Depth=2
	add	x0, sp, #96
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB7_32
	b	LBB7_24
LBB7_24:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #54]
	cbnz	w8, LBB7_32
	b	LBB7_25
LBB7_25:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #53]
	cbnz	w8, LBB7_32
	b	LBB7_26
LBB7_26:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #52]
	cbnz	w8, LBB7_32
	b	LBB7_27
LBB7_27:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #55]
	subs	w8, w8, #16
	b.ge	LBB7_32
	b	LBB7_28
LBB7_28:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	adds	w8, w8, #1
	b.eq	LBB7_31
	b	LBB7_29
LBB7_29:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.hs	LBB7_32
	b	LBB7_30
LBB7_30:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.eq	LBB7_32
	b	LBB7_31
LBB7_31:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w0, [sp, #44]
	ldr	x1, [sp, #128]
	bl	_name_valid
	tbnz	w0, #0, LBB7_33
	b	LBB7_32
LBB7_32:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #68]
	ldr	w2, [sp, #56]
	mov	w0, #2                          ; =0x2
	adrp	x3, l_.str.43@PAGE
	add	x3, x3, l_.str.43@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_33:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	adds	w8, w8, #1
	b.eq	LBB7_36
	b	LBB7_34
LBB7_34:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.ls	LBB7_36
	b	LBB7_35
LBB7_35:                                ;   in Loop: Header=BB7_17 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #75]
	b	LBB7_36
LBB7_36:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w9, [sp, #55]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB7_41
	b	LBB7_37
LBB7_37:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w9, [sp, #55]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB7_41
	b	LBB7_38
LBB7_38:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w9, [sp, #55]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB7_41
	b	LBB7_39
LBB7_39:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w9, [sp, #55]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB7_41
	b	LBB7_40
LBB7_40:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #55]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB7_41
LBB7_41:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #43]
	ldrb	w8, [sp, #55]
	subs	w8, w8, #8
	b.ne	LBB7_43
	b	LBB7_42
LBB7_42:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	adds	w8, w8, #1
	cset	w8, ne
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB7_46
LBB7_43:                                ;   in Loop: Header=BB7_17 Depth=2
	ldrb	w8, [sp, #43]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB7_45
	b	LBB7_44
LBB7_44:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #48]
	adds	w8, w8, #1
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_45
LBB7_45:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB7_46
LBB7_46:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	ldrb	w8, [sp, #74]
	and	w8, w8, #0x1
	ands	w8, w8, w9
	cset	w8, ne
	strb	w8, [sp, #74]
	b	LBB7_47
LBB7_47:                                ;   in Loop: Header=BB7_17 Depth=2
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB7_17
LBB7_48:                                ;   in Loop: Header=BB7_5 Depth=1
	b	LBB7_49
LBB7_49:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB7_5
LBB7_50:
	ldr	x8, [sp, #112]
	ldr	x9, [sp, #104]
	subs	x8, x8, x9
	b.ne	LBB7_54
	b	LBB7_51
LBB7_51:
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #128]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.ne	LBB7_54
	b	LBB7_52
LBB7_52:
	ldr	w8, [sp, #84]
	ldr	x9, [sp, #128]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.ne	LBB7_54
	b	LBB7_53
LBB7_53:
	ldr	w8, [sp, #80]
	ldr	x9, [sp, #128]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.eq	LBB7_55
	b	LBB7_54
LBB7_54:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.44@PAGE
	add	x3, x3, l_.str.44@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_55:
	ldrb	w8, [sp, #75]
	tbz	w8, #0, LBB7_61
	b	LBB7_56
LBB7_56:
	ldrb	w8, [sp, #74]
	tbnz	w8, #0, LBB7_58
	b	LBB7_57
LBB7_57:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.45@PAGE
	add	x3, x3, l_.str.45@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_58:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #128]
	ldr	w1, [sp, #92]
	add	x2, sp, #1160
	add	x3, sp, #136
	bl	_record_forward_preflight
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cbz	w8, LBB7_60
	b	LBB7_59
LBB7_59:
	b	LBB7_62
LBB7_60:
	b	LBB7_61
LBB7_61:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w9, [sp, #75]
	ldr	x10, [sp, #120]
	and	w9, w9, #0x1
	strb	w9, [x10]
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.46@PAGE
	add	x3, x3, l_.str.46@PAGEOFF
	bl	_record_result
	b	LBB7_62
LBB7_62:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB7_64
	b	LBB7_63
LBB7_63:
	bl	___stack_chk_fail
LBB7_64:
	add	sp, sp, #3216
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_layout_view_free     ; -- Begin function nvm_mixed_layout_view_free
	.p2align	2
_nvm_mixed_layout_view_free:            ; @nvm_mixed_layout_view_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
	b	LBB8_3
LBB8_2:
	ldr	x0, [sp, #8]
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #5144]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB8_3
LBB8_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_describe_mixed_layouts     ; -- Begin function nvm_describe_mixed_layouts
	.p2align	2
_nvm_describe_mixed_layouts:            ; @nvm_describe_mixed_layouts
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1024
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #240]
	str	x1, [sp, #232]
	ldr	x8, [sp, #240]
	cbz	x8, LBB9_4
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #232]
	cbz	x8, LBB9_4
	b	LBB9_2
LBB9_2:
	ldr	x8, [sp, #240]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #240]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB9_4
	b	LBB9_3
LBB9_3:
	ldr	x8, [sp, #240]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #240]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB9_5
	b	LBB9_4
LBB9_4:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.11@PAGE
	add	x3, x3, l_.str.11@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_5:
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB9_7
	b	LBB9_6
LBB9_6:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.12@PAGE
	add	x3, x3, l_.str.12@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_7:
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB9_9
	b	LBB9_8
LBB9_8:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.13@PAGE
	add	x3, x3, l_.str.13@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_9:
	ldr	x0, [sp, #240]
	add	x8, sp, #192
	add	x1, sp, #231
	bl	_record_preflight
	ldr	w8, [sp, #192]
	cbz	w8, LBB9_11
	b	LBB9_10
LBB9_10:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #192]
	str	q0, [x9]
	ldr	x8, [sp, #208]
	str	x8, [x9, #16]
	b	LBB9_53
LBB9_11:
	ldr	x8, [sp, #240]
	ldr	x1, [x8, #312]
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #320]
	mov	x2, x8
	add	x0, sp, #168
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #164
	bl	_nvm_v2_u32
	cbz	w0, LBB9_13
	b	LBB9_12
LBB9_12:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.14@PAGE
	add	x3, x3, l_.str.14@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_13:
	add	x0, sp, #760
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #256                        ; =0x100
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #240]
	ldr	w1, [sp, #164]
	mov	x2, #0                          ; =0x0
	bl	_mixed_ownership_read
	tbnz	w0, #0, LBB9_15
	b	LBB9_14
LBB9_14:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.15@PAGE
	add	x3, x3, l_.str.15@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_15:
	mov	x0, #1                          ; =0x1
	mov	x1, #5160                       ; =0x1428
	bl	_calloc
	str	x0, [sp, #152]
	ldr	x8, [sp, #152]
	cbnz	x8, LBB9_17
	b	LBB9_16
LBB9_16:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.16@PAGE
	add	x3, x3, l_.str.16@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_17:
	ldr	x8, [sp, #240]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x2, [sp, #152]
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #148]
	ldr	w8, [sp, #148]
	cbz	w8, LBB9_19
	b	LBB9_18
LBB9_18:
	ldr	w10, [sp, #148]
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #1
	csel	w0, w8, w9, eq
	add	x8, sp, #120
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.17@PAGE
	add	x3, x3, l_.str.17@PAGEOFF
	bl	_record_result
	ldur	q0, [sp, #120]
	str	q0, [sp, #192]
	ldr	x8, [sp, #136]
	str	x8, [sp, #208]
	b	LBB9_52
LBB9_19:
	ldr	x0, [sp, #240]
	ldr	w1, [sp, #164]
	ldr	x2, [sp, #152]
	add	x3, sp, #760
	bl	_mixed_ownership_read
	tbnz	w0, #0, LBB9_21
	b	LBB9_20
LBB9_20:
	b	LBB9_51
LBB9_21:
	strb	wzr, [sp, #119]
	str	wzr, [sp, #112]
	b	LBB9_22
LBB9_22:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #112]
	ldr	w9, [sp, #164]
	subs	w8, w8, w9
	b.hs	LBB9_25
	b	LBB9_23
LBB9_23:                                ;   in Loop: Header=BB9_22 Depth=1
	ldr	w8, [sp, #112]
	mov	x9, x8
	add	x8, sp, #760
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w9, ne
	ldrb	w8, [sp, #119]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #119]
	b	LBB9_24
LBB9_24:                                ;   in Loop: Header=BB9_22 Depth=1
	ldr	w8, [sp, #112]
	add	w8, w8, #1
	str	w8, [sp, #112]
	b	LBB9_22
LBB9_25:
	ldrb	w8, [sp, #119]
	tbz	w8, #0, LBB9_28
	b	LBB9_26
LBB9_26:
	ldrb	w8, [sp, #231]
	tbz	w8, #0, LBB9_28
	b	LBB9_27
LBB9_27:
	b	LBB9_51
LBB9_28:
	add	x0, sp, #504
	mov	x2, #256                        ; =0x100
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, sp, #248
	bl	_memset
	str	wzr, [sp, #108]
	b	LBB9_29
LBB9_29:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #108]
	ldr	w9, [sp, #164]
	subs	w8, w8, w9
	b.hs	LBB9_34
	b	LBB9_30
LBB9_30:                                ;   in Loop: Header=BB9_29 Depth=1
	ldr	x0, [sp, #152]
	ldr	w1, [sp, #108]
	add	x2, sp, #760
	add	x3, sp, #504
	add	x4, sp, #248
	bl	_mixed_classify
	tbnz	w0, #0, LBB9_32
	b	LBB9_31
LBB9_31:
	b	LBB9_51
LBB9_32:                                ;   in Loop: Header=BB9_29 Depth=1
	b	LBB9_33
LBB9_33:                                ;   in Loop: Header=BB9_29 Depth=1
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB9_29
LBB9_34:
	str	wzr, [sp, #104]
	b	LBB9_35
LBB9_35:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #104]
	subs	w8, w8, #256
	b.hs	LBB9_38
	b	LBB9_36
LBB9_36:                                ;   in Loop: Header=BB9_35 Depth=1
	ldr	x8, [sp, #152]
	add	x9, x8, #1048
	ldr	w8, [sp, #104]
	mov	x10, x8
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, x10, lsl #2]
	ldr	x9, [sp, #152]
	add	x9, x9, #24
	ldr	w10, [sp, #104]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	x9, [sp, #152]
	add	x9, x9, #3096
	ldr	w10, [sp, #104]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	x9, [sp, #152]
	add	x9, x9, #2072
	ldr	w10, [sp, #104]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	b	LBB9_37
LBB9_37:                                ;   in Loop: Header=BB9_35 Depth=1
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB9_35
LBB9_38:
	str	wzr, [sp, #100]
	b	LBB9_39
LBB9_39:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #164]
	subs	w8, w8, w9
	b.hs	LBB9_46
	b	LBB9_40
LBB9_40:                                ;   in Loop: Header=BB9_39 Depth=1
	ldr	x8, [sp, #152]
	ldr	x8, [x8]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbz	w8, LBB9_42
	b	LBB9_41
LBB9_41:                                ;   in Loop: Header=BB9_39 Depth=1
	b	LBB9_45
LBB9_42:                                ;   in Loop: Header=BB9_39 Depth=1
	ldr	x8, [sp, #152]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #152]
	add	x9, x9, #1048
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #100]
	ldr	x9, [sp, #152]
	add	x9, x9, #24
	ldr	x12, [sp, #152]
	ldr	w10, [x12, #16]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #16]
	str	w8, [x9, x10, lsl #2]
	ldr	x8, [sp, #152]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #2
	b.ne	LBB9_44
	b	LBB9_43
LBB9_43:                                ;   in Loop: Header=BB9_39 Depth=1
	ldr	x8, [sp, #152]
	ldr	w8, [x8, #20]
	ldr	x9, [sp, #152]
	add	x9, x9, #3096
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #100]
	ldr	x9, [sp, #152]
	add	x9, x9, #2072
	ldr	x12, [sp, #152]
	ldr	w10, [x12, #20]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #20]
	str	w8, [x9, x10, lsl #2]
	b	LBB9_44
LBB9_44:                                ;   in Loop: Header=BB9_39 Depth=1
	b	LBB9_45
LBB9_45:                                ;   in Loop: Header=BB9_39 Depth=1
	ldr	w8, [sp, #100]
	add	w8, w8, #1
	str	w8, [sp, #100]
	b	LBB9_39
LBB9_46:
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #304]
	cbz	w8, LBB9_50
	b	LBB9_47
LBB9_47:
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #304]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #152]
	str	x0, [x8, #5144]
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #5144]
	cbnz	x8, LBB9_49
	b	LBB9_48
LBB9_48:
	add	x8, sp, #72
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.18@PAGE
	add	x3, x3, l_.str.18@PAGEOFF
	bl	_record_result
	ldur	q0, [sp, #72]
	str	q0, [sp, #192]
	ldr	x8, [sp, #88]
	str	x8, [sp, #208]
	b	LBB9_52
LBB9_49:
	ldr	x8, [sp, #152]
	ldr	x0, [x8, #5144]
	ldr	x8, [sp, #240]
	ldr	x1, [x8, #296]
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #304]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #304]
	ldr	x9, [sp, #152]
	str	w8, [x9, #5152]
	b	LBB9_50
LBB9_50:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #152]
	ldr	x10, [sp, #232]
	str	x9, [x10]
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.19@PAGE
	add	x3, x3, l_.str.19@PAGEOFF
	bl	_record_result
	b	LBB9_53
LBB9_51:
	add	x8, sp, #48
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.20@PAGE
	add	x3, x3, l_.str.20@PAGEOFF
	bl	_record_result
	ldr	q0, [sp, #48]
	str	q0, [sp, #192]
	ldr	x8, [sp, #64]
	str	x8, [sp, #208]
	b	LBB9_52
LBB9_52:
	ldr	x0, [sp, #152]
	bl	_nvm_mixed_layout_view_free
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #192]
	str	q0, [x9]
	ldr	x8, [sp, #208]
	str	x8, [x9, #16]
	b	LBB9_53
LBB9_53:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB9_55
	b	LBB9_54
LBB9_54:
	bl	___stack_chk_fail
LBB9_55:
	add	sp, sp, #1024
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mixed_ownership_read
_mixed_ownership_read:                  ; @mixed_ownership_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #64
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x8, #48]
	stur	w1, [x29, #-20]
	str	x2, [x8, #32]
	str	x3, [x8, #24]
	ldr	x8, [x8, #48]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB10_2
	b	LBB10_1
LBB10_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_2:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #48]
	ldr	x1, [x9, #296]
	ldr	x8, [x8, #48]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #64
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_8
	b	LBB10_3
LBB10_3:
	ldur	w8, [x29, #-68]
	subs	w8, w8, #1
	b.eq	LBB10_5
	b	LBB10_4
LBB10_4:
	ldur	w8, [x29, #-68]
	subs	w8, w8, #2
	b.ne	LBB10_8
	b	LBB10_5
LBB10_5:
	sub	x0, x29, #64
	sub	x1, x29, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_8
	b	LBB10_6
LBB10_6:
	ldur	w8, [x29, #-72]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB10_8
	b	LBB10_7
LBB10_7:
	ldur	w8, [x29, #-72]
	mov	x1, x8
	sub	x0, x29, #64
	sub	x2, x29, #80
	bl	_nvm_v2_take
	cbz	w0, LBB10_9
	b	LBB10_8
LBB10_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	ldur	x1, [x29, #-80]
	ldur	w8, [x29, #-72]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	stur	wzr, [x29, #-84]
	b	LBB10_10
LBB10_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-84]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.hs	LBB10_17
	b	LBB10_11
LBB10_11:                               ;   in Loop: Header=BB10_10 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w8, w8, #0xfffffffc
	cbnz	w8, LBB10_14
	b	LBB10_12
LBB10_12:                               ;   in Loop: Header=BB10_10 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #1, LBB10_15
	b	LBB10_13
LBB10_13:                               ;   in Loop: Header=BB10_10 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB10_15
	b	LBB10_14
LBB10_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_15:                               ;   in Loop: Header=BB10_10 Depth=1
	b	LBB10_16
LBB10_16:                               ;   in Loop: Header=BB10_10 Depth=1
	ldur	w8, [x29, #-84]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	b	LBB10_10
LBB10_17:
	sub	x0, x29, #64
	bl	_nvm_v2_align4
	cbnz	w0, LBB10_22
	b	LBB10_18
LBB10_18:
	sub	x0, x29, #64
	sub	x1, x29, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_22
	b	LBB10_19
LBB10_19:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-72]
	ldr	x9, [x9, #48]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB10_22
	b	LBB10_20
LBB10_20:
	ldur	w8, [x29, #-72]
	cbz	w8, LBB10_23
	b	LBB10_21
LBB10_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB10_23
	b	LBB10_22
LBB10_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_23:
	stur	wzr, [x29, #-88]
	b	LBB10_24
LBB10_24:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_33 Depth 2
	ldur	w8, [x29, #-88]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.hs	LBB10_80
	b	LBB10_25
LBB10_25:                               ;   in Loop: Header=BB10_24 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-88]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-104]
	sub	x0, x29, #64
	sub	x1, x29, #90
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_31
	b	LBB10_26
LBB10_26:                               ;   in Loop: Header=BB10_24 Depth=1
	sub	x0, x29, #64
	sub	x1, x29, #92
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_31
	b	LBB10_27
LBB10_27:                               ;   in Loop: Header=BB10_24 Depth=1
	ldurh	w8, [x29, #-90]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB10_31
	b	LBB10_28
LBB10_28:                               ;   in Loop: Header=BB10_24 Depth=1
	ldurh	w8, [x29, #-92]
	ldur	x9, [x29, #-104]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB10_31
	b	LBB10_29
LBB10_29:                               ;   in Loop: Header=BB10_24 Depth=1
	ldurh	w8, [x29, #-92]
	ldurh	w9, [x29, #-90]
	subs	w8, w8, w9
	b.gt	LBB10_31
	b	LBB10_30
LBB10_30:                               ;   in Loop: Header=BB10_24 Depth=1
	ldur	x8, [x29, #-104]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.le	LBB10_32
	b	LBB10_31
LBB10_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_32:                               ;   in Loop: Header=BB10_24 Depth=1
	stur	wzr, [x29, #-108]
	b	LBB10_33
LBB10_33:                               ;   Parent Loop BB10_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-108]
	ldurh	w9, [x29, #-90]
	subs	w8, w8, w9
	b.hi	LBB10_78
	b	LBB10_34
LBB10_34:                               ;   in Loop: Header=BB10_33 Depth=2
	ldur	w8, [x29, #-108]
	cbnz	w8, LBB10_39
	b	LBB10_35
LBB10_35:                               ;   in Loop: Header=BB10_33 Depth=2
	ldur	x8, [x29, #-104]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB10_37
	b	LBB10_36
LBB10_36:                               ;   in Loop: Header=BB10_33 Depth=2
	ldur	x8, [x29, #-104]
	ldrb	w8, [x8, #20]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB10_38
LBB10_37:                               ;   in Loop: Header=BB10_33 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB10_38
LBB10_38:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB10_40
LBB10_39:                               ;   in Loop: Header=BB10_33 Depth=2
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB10_40
LBB10_40:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #104]
	ldur	w9, [x29, #-108]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ls	LBB10_42
	b	LBB10_41
LBB10_41:                               ;   in Loop: Header=BB10_33 Depth=2
	ldur	w8, [x29, #-108]
	ldurh	w9, [x29, #-92]
	subs	w8, w8, w9
	cset	w8, ls
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB10_42
LBB10_42:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #103]
	ldrb	w8, [sp, #103]
	tbz	w8, #0, LBB10_48
	b	LBB10_43
LBB10_43:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #264]
	cbz	x8, LBB10_46
	b	LBB10_44
LBB10_44:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB10_46
	b	LBB10_45
LBB10_45:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	w9, [x29, #-108]
	subs	w9, w9, #1
	ldrb	w8, [x8, w9, uxtw]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB10_47
LBB10_46:                               ;   in Loop: Header=BB10_33 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB10_47
LBB10_47:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #104]
	b	LBB10_48
LBB10_48:                               ;   in Loop: Header=BB10_33 Depth=2
	sub	x0, x29, #64
	sub	x1, x29, #109
	bl	_nvm_v2_u8
	cbnz	w0, LBB10_59
	b	LBB10_49
LBB10_49:                               ;   in Loop: Header=BB10_33 Depth=2
	sub	x0, x29, #64
	sub	x1, x29, #110
	bl	_nvm_v2_u8
	cbnz	w0, LBB10_59
	b	LBB10_50
LBB10_50:                               ;   in Loop: Header=BB10_33 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #112
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_59
	b	LBB10_51
LBB10_51:                               ;   in Loop: Header=BB10_33 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #108
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_59
	b	LBB10_52
LBB10_52:                               ;   in Loop: Header=BB10_33 Depth=2
	ldrh	w8, [sp, #112]
	cbnz	w8, LBB10_59
	b	LBB10_53
LBB10_53:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-109]
	subs	w8, w8, #16
	b.ge	LBB10_59
	b	LBB10_54
LBB10_54:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-110]
	subs	w8, w8, #2
	b.gt	LBB10_59
	b	LBB10_55
LBB10_55:                               ;   in Loop: Header=BB10_33 Depth=2
	ldrb	w8, [sp, #103]
	tbnz	w8, #0, LBB10_57
	b	LBB10_56
LBB10_56:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-110]
	cbnz	w8, LBB10_59
	b	LBB10_57
LBB10_57:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #104]
	tbnz	w8, #31, LBB10_60
	b	LBB10_58
LBB10_58:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-109]
	ldr	w9, [sp, #104]
	subs	w8, w8, w9
	b.eq	LBB10_60
	b	LBB10_59
LBB10_59:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_60:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #108]
	adds	w8, w8, #1
	b.eq	LBB10_67
	b	LBB10_61
LBB10_61:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #108]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB10_66
	b	LBB10_62
LBB10_62:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-109]
	subs	w8, w8, #8
	b.ne	LBB10_66
	b	LBB10_63
LBB10_63:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB10_66
	b	LBB10_64
LBB10_64:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	cbz	x8, LBB10_67
	b	LBB10_65
LBB10_65:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbz	w8, LBB10_67
	b	LBB10_66
LBB10_66:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_67:                               ;   in Loop: Header=BB10_33 Depth=2
	ldurb	w8, [x29, #-110]
	cbz	w8, LBB10_76
	b	LBB10_68
LBB10_68:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	w8, [sp, #108]
	adds	w8, w8, #1
	b.eq	LBB10_70
	b	LBB10_69
LBB10_69:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #1, LBB10_71
	b	LBB10_70
LBB10_70:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_71:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	cbz	x8, LBB10_75
	b	LBB10_72
LBB10_72:                               ;   in Loop: Header=BB10_33 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	x2, sp, #56
	mov	x9, #1                          ; =0x1
	str	x9, [sp, #56]
	strh	wzr, [sp, #64]
	strh	wzr, [sp, #66]
	ldr	w9, [sp, #108]
	str	w9, [sp, #68]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [sp, #72]
	strh	wzr, [sp, #80]
	strh	wzr, [sp, #82]
	ldr	w9, [sp, #108]
	str	w9, [sp, #84]
	ldurb	w9, [x29, #-110]
	str	w9, [sp, #88]
	str	wzr, [sp, #92]
	ldr	x0, [x8, #32]
	ldr	w1, [sp, #108]
	bl	_nvm_reference_place_valid
	tbnz	w0, #0, LBB10_74
	b	LBB10_73
LBB10_73:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_74:                               ;   in Loop: Header=BB10_33 Depth=2
	b	LBB10_75
LBB10_75:                               ;   in Loop: Header=BB10_33 Depth=2
	b	LBB10_76
LBB10_76:                               ;   in Loop: Header=BB10_33 Depth=2
	b	LBB10_77
LBB10_77:                               ;   in Loop: Header=BB10_33 Depth=2
	ldur	w8, [x29, #-108]
	add	w8, w8, #1
	stur	w8, [x29, #-108]
	b	LBB10_33
LBB10_78:                               ;   in Loop: Header=BB10_24 Depth=1
	b	LBB10_79
LBB10_79:                               ;   in Loop: Header=BB10_24 Depth=1
	ldur	w8, [x29, #-88]
	add	w8, w8, #1
	stur	w8, [x29, #-88]
	b	LBB10_24
LBB10_80:
	ldur	w8, [x29, #-68]
	subs	w8, w8, #2
	b.ne	LBB10_103
	b	LBB10_81
LBB10_81:
	sub	x0, x29, #64
	sub	x1, x29, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB10_83
	b	LBB10_82
LBB10_82:
	ldur	w8, [x29, #-72]
	subs	w8, w8, #256
	b.ls	LBB10_84
	b	LBB10_83
LBB10_83:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_84:
	str	wzr, [sp, #52]
	b	LBB10_85
LBB10_85:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_93 Depth 2
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-72]
	subs	w8, w8, w9
	b.hs	LBB10_102
	b	LBB10_86
LBB10_86:                               ;   in Loop: Header=BB10_85 Depth=1
	sub	x0, x29, #64
	add	x1, sp, #50
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_91
	b	LBB10_87
LBB10_87:                               ;   in Loop: Header=BB10_85 Depth=1
	sub	x0, x29, #64
	add	x1, sp, #48
	bl	_nvm_v2_u16
	cbnz	w0, LBB10_91
	b	LBB10_88
LBB10_88:                               ;   in Loop: Header=BB10_85 Depth=1
	ldrh	w8, [sp, #48]
	cbnz	w8, LBB10_91
	b	LBB10_89
LBB10_89:                               ;   in Loop: Header=BB10_85 Depth=1
	ldrh	w8, [sp, #50]
	cbz	w8, LBB10_91
	b	LBB10_90
LBB10_90:                               ;   in Loop: Header=BB10_85 Depth=1
	ldrh	w8, [sp, #50]
	subs	w8, w8, #32
	b.ls	LBB10_92
	b	LBB10_91
LBB10_91:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_92:                               ;   in Loop: Header=BB10_85 Depth=1
	strh	wzr, [sp, #44]
	b	LBB10_93
LBB10_93:                               ;   Parent Loop BB10_85 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #44]
	ldrh	w9, [sp, #50]
	subs	w8, w8, w9
	b.ge	LBB10_98
	b	LBB10_94
LBB10_94:                               ;   in Loop: Header=BB10_93 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #46
	bl	_nvm_v2_u16
	cbz	w0, LBB10_96
	b	LBB10_95
LBB10_95:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_96:                               ;   in Loop: Header=BB10_93 Depth=2
	b	LBB10_97
LBB10_97:                               ;   in Loop: Header=BB10_93 Depth=2
	ldrh	w8, [sp, #44]
	add	w8, w8, #1
	strh	w8, [sp, #44]
	b	LBB10_93
LBB10_98:                               ;   in Loop: Header=BB10_85 Depth=1
	sub	x0, x29, #64
	bl	_nvm_v2_align4
	cbz	w0, LBB10_100
	b	LBB10_99
LBB10_99:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_100:                              ;   in Loop: Header=BB10_85 Depth=1
	b	LBB10_101
LBB10_101:                              ;   in Loop: Header=BB10_85 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB10_85
LBB10_102:
	b	LBB10_103
LBB10_103:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-56]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB10_104
LBB10_104:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mixed_classify
_mixed_classify:                        ; @mixed_classify
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB11_2
	b	LBB11_1
LBB11_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_2:
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_4:
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	str	x9, [sp, #56]
	ldur	x9, [x29, #-32]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	mov	w10, #1                         ; =0x1
	ands	w9, w9, #0x1
	cset	w9, ne
	strb	w9, [sp, #55]
	ldur	x9, [x29, #-32]
	ldur	w11, [x29, #-20]
                                        ; kill: def $x11 killed $w11
	ldrb	w9, [x9, x11]
	ands	w9, w9, #0x2
	cset	w9, ne
	strb	w9, [sp, #54]
	ldrb	w9, [sp, #55]
	eor	w9, w9, w10
	and	w9, w9, w10
	strb	w9, [sp, #53]
	strb	wzr, [sp, #52]
	strb	w8, [sp, #51]
	ldrb	w8, [sp, #55]
	tbz	w8, #0, LBB11_7
	b	LBB11_5
LBB11_5:
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	cbz	w8, LBB11_7
	b	LBB11_6
LBB11_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_7:
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	cbz	w8, LBB11_9
	b	LBB11_8
LBB11_8:
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_9:
	strh	wzr, [sp, #48]
	b	LBB11_10
LBB11_10:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #48]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB11_38
	b	LBB11_11
LBB11_11:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #4]
	str	w8, [sp, #36]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB11_24
	b	LBB11_12
LBB11_12:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	w8, [sp, #36]
	adds	w8, w8, #1
	b.ne	LBB11_16
	b	LBB11_13
LBB11_13:                               ;   in Loop: Header=BB11_10 Depth=1
	ldrb	w8, [sp, #55]
	tbz	w8, #0, LBB11_15
	b	LBB11_14
LBB11_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_15:                               ;   in Loop: Header=BB11_10 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #53]
	strb	wzr, [sp, #51]
	b	LBB11_37
LBB11_16:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB11_18
	b	LBB11_17
LBB11_17:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #36]
	ldur	x2, [x29, #-32]
	ldur	x3, [x29, #-40]
	ldur	x4, [x29, #-48]
	bl	_mixed_classify
	tbnz	w0, #0, LBB11_19
	b	LBB11_18
LBB11_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_19:                               ;   in Loop: Header=BB11_10 Depth=1
	ldrb	w8, [sp, #55]
	tbz	w8, #0, LBB11_23
	b	LBB11_20
LBB11_20:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #1, LBB11_23
	b	LBB11_21
LBB11_21:                               ;   in Loop: Header=BB11_10 Depth=1
	ldrb	w8, [sp, #54]
	tbnz	w8, #0, LBB11_23
	b	LBB11_22
LBB11_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_23:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	subs	w8, w8, #0
	cset	w10, eq
	ldrb	w8, [sp, #53]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #53]
	ldur	x8, [x29, #-16]
	add	x8, x8, x9
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #3
	cset	w9, eq
	ldrb	w8, [sp, #52]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #52]
	ldur	x8, [x29, #-48]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #0
	cset	w9, ne
	ldrb	w8, [sp, #51]
	and	w8, w8, #0x1
	ands	w8, w8, w9
	cset	w8, ne
	strb	w8, [sp, #51]
	b	LBB11_36
LBB11_24:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	w8, [sp, #36]
	adds	w8, w8, #1
	b.eq	LBB11_28
	b	LBB11_25
LBB11_25:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #9
	b.ne	LBB11_27
	b	LBB11_26
LBB11_26:                               ;   in Loop: Header=BB11_10 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	subs	w8, w8, #3
	b.eq	LBB11_28
	b	LBB11_27
LBB11_27:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_28:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b.eq	LBB11_32
	b	LBB11_29
LBB11_29:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b.eq	LBB11_32
	b	LBB11_30
LBB11_30:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b.eq	LBB11_32
	b	LBB11_31
LBB11_31:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	cset	w8, eq
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB11_32
LBB11_32:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #35]
	ldrb	w8, [sp, #35]
	and	w9, w8, #0x1
	ldrb	w8, [sp, #51]
	and	w8, w8, #0x1
	ands	w8, w8, w9
	cset	w8, ne
	strb	w8, [sp, #51]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	cset	w9, eq
	ldrb	w8, [sp, #52]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #52]
	ldrb	w8, [sp, #35]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB11_35
	b	LBB11_33
LBB11_33:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w9, [x8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #5
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b.eq	LBB11_35
	b	LBB11_34
LBB11_34:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	cset	w8, ne
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB11_35
LBB11_35:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldrb	w8, [sp, #53]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #53]
	b	LBB11_36
LBB11_36:                               ;   in Loop: Header=BB11_10 Depth=1
	b	LBB11_37
LBB11_37:                               ;   in Loop: Header=BB11_10 Depth=1
	ldrh	w8, [sp, #48]
	add	w8, w8, #1
	strh	w8, [sp, #48]
	b	LBB11_10
LBB11_38:
	ldrb	w8, [sp, #54]
	tbz	w8, #0, LBB11_43
	b	LBB11_39
LBB11_39:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB11_42
	b	LBB11_40
LBB11_40:
	ldrb	w8, [sp, #53]
	tbnz	w8, #0, LBB11_42
	b	LBB11_41
LBB11_41:
	ldrb	w8, [sp, #52]
	tbz	w8, #0, LBB11_43
	b	LBB11_42
LBB11_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_43:
	ldrb	w8, [sp, #51]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_46
	b	LBB11_44
LBB11_44:
	ldrb	w8, [sp, #55]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB11_46
	b	LBB11_45
LBB11_45:
	ldrb	w8, [sp, #53]
	eor	w8, w8, #0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB11_46
LBB11_46:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ldur	x9, [x29, #-48]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	ldrb	w8, [sp, #53]
	tbz	w8, #0, LBB11_48
	b	LBB11_47
LBB11_47:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_52
LBB11_48:
	ldrb	w8, [sp, #54]
	tbz	w8, #0, LBB11_50
	b	LBB11_49
LBB11_49:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB11_51
LBB11_50:
	ldrb	w10, [sp, #52]
	mov	w8, #3                          ; =0x3
	mov	w9, #2                          ; =0x2
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB11_51
LBB11_51:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB11_52
LBB11_52:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	ldur	x9, [x29, #-16]
	mov	x10, #4120                      ; =0x1018
	add	x9, x9, x10
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldur	x8, [x29, #-40]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_53
LBB11_53:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_layouts_free   ; -- Begin function nvm_owned_array_layouts_free
	.p2align	2
_nvm_owned_array_layouts_free:          ; @nvm_owned_array_layouts_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	b	LBB12_3
LBB12_2:
	ldr	x0, [sp, #8]
	bl	_nvm_v2_layouts_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #10272]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #10280]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #10288]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB12_3
LBB12_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_describe_owned_array_layouts ; -- Begin function nvm_describe_owned_array_layouts
	.p2align	2
_nvm_describe_owned_array_layouts:      ; @nvm_describe_owned_array_layouts
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #208
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #256]
	str	x1, [sp, #248]
	ldr	x8, [sp, #256]
	cbz	x8, LBB13_4
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #248]
	cbz	x8, LBB13_4
	b	LBB13_2
LBB13_2:
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #312]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #256]
	ldr	w9, [x9, #320]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB13_4
	b	LBB13_3
LBB13_3:
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #296]
	subs	x8, x8, #0
	cset	w8, eq
	ldr	x9, [sp, #256]
	ldr	w9, [x9, #304]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB13_5
	b	LBB13_4
LBB13_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.21@PAGE
	add	x3, x3, l_.str.21@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_5:
	ldr	x0, [sp, #256]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB13_7
	b	LBB13_6
LBB13_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.22@PAGE
	add	x3, x3, l_.str.22@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_7:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	cbz	w8, LBB13_9
	b	LBB13_8
LBB13_8:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB13_10
	b	LBB13_9
LBB13_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.23@PAGE
	add	x3, x3, l_.str.23@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_10:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB13_12
	b	LBB13_11
LBB13_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.24@PAGE
	add	x3, x3, l_.str.24@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_12:
	add	x1, sp, #247
	strb	wzr, [sp, #247]
	ldr	x0, [sp, #256]
	add	x8, sp, #208
	bl	_record_preflight
	ldr	w8, [sp, #208]
	cbz	w8, LBB13_14
	b	LBB13_13
LBB13_13:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [sp, #224]
	str	x8, [x9, #16]
	b	LBB13_35
LBB13_14:
	ldrb	w8, [sp, #247]
	tbz	w8, #0, LBB13_16
	b	LBB13_15
LBB13_15:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.25@PAGE
	add	x3, x3, l_.str.25@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_16:
	ldr	x8, [sp, #256]
	ldr	x1, [x8, #312]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	mov	x2, x8
	add	x0, sp, #184
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #180
	bl	_nvm_v2_u32
	cbz	w0, LBB13_18
	b	LBB13_17
LBB13_17:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.26@PAGE
	add	x3, x3, l_.str.26@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_18:
	add	x0, sp, #264
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #256                        ; =0x100
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #180]
	mov	x2, #0                          ; =0x0
	bl	_mixed_ownership_read
	tbnz	w0, #0, LBB13_20
	b	LBB13_19
LBB13_19:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.15@PAGE
	add	x3, x3, l_.str.15@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_20:
	mov	x0, #1                          ; =0x1
	mov	x1, #10304                      ; =0x2840
	bl	_calloc
	str	x0, [sp, #168]
	ldr	x8, [sp, #168]
	cbnz	x8, LBB13_22
	b	LBB13_21
LBB13_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.27@PAGE
	add	x3, x3, l_.str.27@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_22:
	ldr	x8, [sp, #256]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	mov	x1, x8
	ldr	x2, [sp, #168]
	bl	_nvm_v2_layouts_decode
	str	w0, [sp, #164]
	ldr	w8, [sp, #164]
	cbz	w8, LBB13_24
	b	LBB13_23
LBB13_23:
	ldr	w10, [sp, #164]
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #1
	csel	w0, w8, w9, eq
	add	x8, sp, #136
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.28@PAGE
	add	x3, x3, l_.str.28@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [sp, #136]
	str	q0, [x8]
	ldr	x8, [sp, #152]
	str	x8, [sp, #224]
	b	LBB13_34
LBB13_24:
	ldr	w8, [sp, #180]
	ldr	x9, [sp, #168]
	str	w8, [x9, #16]
	ldr	x0, [sp, #168]
	add	x8, sp, #112
	add	x1, sp, #264
	bl	_oa_classify
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #112]
	str	q0, [x8]
	ldr	x8, [sp, #128]
	str	x8, [sp, #224]
	ldr	w8, [sp, #208]
	cbz	w8, LBB13_26
	b	LBB13_25
LBB13_25:
	b	LBB13_34
LBB13_26:
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #180]
	ldr	x2, [sp, #168]
	add	x3, sp, #264
	bl	_mixed_ownership_read
	tbnz	w0, #0, LBB13_28
	b	LBB13_27
LBB13_27:
	add	x8, sp, #88
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.29@PAGE
	add	x3, x3, l_.str.29@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [sp, #88]
	str	q0, [x8]
	ldr	x8, [sp, #104]
	str	x8, [sp, #224]
	b	LBB13_34
LBB13_28:
	ldr	x0, [sp, #168]
	add	x8, sp, #64
	bl	_oa_paths
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #64]
	str	q0, [x8]
	ldr	x8, [sp, #80]
	str	x8, [sp, #224]
	ldr	w8, [sp, #208]
	cbz	w8, LBB13_30
	b	LBB13_29
LBB13_29:
	b	LBB13_34
LBB13_30:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #168]
	str	x0, [x8, #10280]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #168]
	str	x0, [x8, #10288]
	ldr	x8, [sp, #168]
	ldr	x8, [x8, #10280]
	cbz	x8, LBB13_32
	b	LBB13_31
LBB13_31:
	ldr	x8, [sp, #168]
	ldr	x8, [x8, #10288]
	cbnz	x8, LBB13_33
	b	LBB13_32
LBB13_32:
	add	x8, sp, #40
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.30@PAGE
	add	x3, x3, l_.str.30@PAGEOFF
	bl	_record_result
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [sp, #40]
	str	q0, [x8]
	ldr	x8, [sp, #56]
	str	x8, [sp, #224]
	b	LBB13_34
LBB13_33:
	ldr	x8, [sp, #168]
	ldr	x0, [x8, #10280]
	ldr	x8, [sp, #256]
	ldr	x1, [x8, #312]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp]                        ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	ldr	x9, [sp, #168]
	str	w8, [x9, #10296]
	ldr	x8, [sp, #168]
	ldr	x0, [x8, #10288]
	ldr	x8, [sp, #256]
	ldr	x1, [x8, #296]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	mov	x2, x8
	bl	___memcpy_chk
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #256]
	ldr	w9, [x9, #304]
	ldr	x10, [sp, #168]
	str	w9, [x10, #10300]
	ldr	x9, [sp, #168]
	ldr	x10, [sp, #248]
	str	x9, [x10]
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.31@PAGE
	add	x3, x3, l_.str.31@PAGEOFF
	bl	_record_result
	b	LBB13_35
LBB13_34:
	ldr	x0, [sp, #168]
	bl	_nvm_owned_array_layouts_free
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [sp, #224]
	str	x8, [x9, #16]
	b	LBB13_35
LBB13_35:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB13_37
	b	LBB13_36
LBB13_36:
	bl	___stack_chk_fail
LBB13_37:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oa_classify
_oa_classify:                           ; @oa_classify
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	wzr, [x29, #-20]
	b	LBB14_1
LBB14_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_9 Depth 2
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB14_50
	b	LBB14_2
LBB14_2:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-8]
	add	x8, x8, #32
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-40]
	ldur	x8, [x29, #-40]
	ldur	w10, [x29, #-20]
	add	x9, sp, #72
	str	w10, [sp, #72]
	mov	w10, #-1                        ; =0xffffffff
	str	w10, [sp, #76]
	str	w10, [sp, #80]
	ldur	x10, [x29, #-32]
	ldrh	w10, [x10, #2]
	str	w10, [sp, #84]
	str	wzr, [sp, #88]
	str	wzr, [sp, #92]
	ldur	x10, [x29, #-16]
	ldur	w11, [x29, #-20]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11
	ldrb	w10, [x10]
	strb	w10, [sp, #96]
	strb	wzr, [sp, #97]
	strb	wzr, [sp, #98]
	strb	wzr, [sp, #99]
	strb	wzr, [sp, #100]
	add	x9, x9, #29
	strh	wzr, [x9]
	strb	wzr, [sp, #103]
	ldur	q0, [sp, #72]
	str	q0, [x8]
	ldur	q0, [sp, #88]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8]
	cbz	w8, LBB14_6
	b	LBB14_3
LBB14_3:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB14_5
	b	LBB14_4
LBB14_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.51@PAGE
	add	x3, x3, l_.str.51@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_5:                                ;   in Loop: Header=BB14_1 Depth=1
	b	LBB14_49
LBB14_6:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB14_8
	b	LBB14_7
LBB14_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.52@PAGE
	add	x3, x3, l_.str.52@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_8:                                ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w8, ne
	strb	w8, [sp, #71]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #20]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #4]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-8]
	mov	x10, #8224                      ; =0x2020
	add	x9, x9, x10
	ldur	x12, [x29, #-8]
	ldr	w10, [x12, #20]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #20]
	str	w8, [x9, x10, lsl #2]
	strh	wzr, [sp, #68]
	b	LBB14_9
LBB14_9:                                ;   Parent Loop BB14_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #68]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB14_39
	b	LBB14_10
LBB14_10:                               ;   in Loop: Header=BB14_9 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]
	ldrb	w9, [sp, #71]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #52]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB14_23
	b	LBB14_11
LBB14_11:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	str	w8, [sp, #48]
	ldr	w8, [sp, #48]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB14_15
	b	LBB14_12
LBB14_12:                               ;   in Loop: Header=BB14_9 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #4
	ldrb	w8, [x8, x9]
	cbnz	w8, LBB14_15
	b	LBB14_13
LBB14_13:                               ;   in Loop: Header=BB14_9 Depth=2
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB14_15
	b	LBB14_14
LBB14_14:                               ;   in Loop: Header=BB14_9 Depth=2
	ldrb	w8, [sp, #71]
	and	w8, w8, #0x1
	ldur	x9, [x29, #-16]
	ldr	w10, [sp, #48]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	ands	w9, w9, #0x2
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB14_16
	b	LBB14_15
LBB14_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldrh	w2, [sp, #68]
	mov	w0, #1                          ; =0x1
	adrp	x3, l_.str.53@PAGE
	add	x3, x3, l_.str.53@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_16:                               ;   in Loop: Header=BB14_9 Depth=2
	ldur	x8, [x29, #-8]
	add	x8, x8, #32
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #26]
	and	w10, w8, #0x1
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9, #26]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9, #26]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #27]
	and	w10, w8, #0x1
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9, #27]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9, #27]
	ldrb	w8, [sp, #71]
	tbz	w8, #0, LBB14_22
	b	LBB14_17
LBB14_17:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #25]
	subs	w8, w8, #32
	b.lo	LBB14_19
	b	LBB14_18
LBB14_18:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldrh	w2, [sp, #68]
	mov	w0, #3                          ; =0x3
	adrp	x3, l_.str.54@PAGE
	add	x3, x3, l_.str.54@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_19:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #25]
	add	w8, w8, #1
	strb	w8, [sp, #39]
	ldrb	w8, [sp, #39]
	ldur	x9, [x29, #-40]
	ldrb	w9, [x9, #25]
	subs	w8, w8, w9
	b.le	LBB14_21
	b	LBB14_20
LBB14_20:                               ;   in Loop: Header=BB14_9 Depth=2
	ldrb	w8, [sp, #39]
	ldur	x9, [x29, #-40]
	strb	w8, [x9, #25]
	b	LBB14_21
LBB14_21:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #20]
	str	w8, [sp, #52]
	b	LBB14_22
LBB14_22:                               ;   in Loop: Header=BB14_9 Depth=2
	b	LBB14_35
LBB14_23:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB14_29
	b	LBB14_24
LBB14_24:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB14_29
	b	LBB14_25
LBB14_25:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.eq	LBB14_29
	b	LBB14_26
LBB14_26:                               ;   in Loop: Header=BB14_9 Depth=2
	ldrb	w8, [sp, #71]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB14_28
	b	LBB14_27
LBB14_27:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB14_28
LBB14_28:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB14_29
LBB14_29:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #38]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	adds	w8, w8, #1
	b.ne	LBB14_33
	b	LBB14_30
LBB14_30:                               ;   in Loop: Header=BB14_9 Depth=2
	ldrb	w8, [sp, #38]
	tbnz	w8, #0, LBB14_34
	b	LBB14_31
LBB14_31:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.eq	LBB14_34
	b	LBB14_32
LBB14_32:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.eq	LBB14_34
	b	LBB14_33
LBB14_33:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldrh	w2, [sp, #68]
	mov	w0, #1                          ; =0x1
	adrp	x3, l_.str.55@PAGE
	add	x3, x3, l_.str.55@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_34:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	cset	w10, eq
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9, #26]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9, #26]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	cset	w10, eq
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9, #27]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9, #27]
	b	LBB14_35
LBB14_35:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-40]
	ldr	w10, [x9, #20]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB14_37
	b	LBB14_36
LBB14_36:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldrh	w2, [sp, #68]
	mov	w0, #3                          ; =0x3
	adrp	x3, l_.str.56@PAGE
	add	x3, x3, l_.str.56@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_37:                               ;   in Loop: Header=BB14_9 Depth=2
	ldr	w10, [sp, #52]
	ldur	x9, [x29, #-40]
	ldr	w8, [x9, #20]
	add	w8, w8, w10
	str	w8, [x9, #20]
	b	LBB14_38
LBB14_38:                               ;   in Loop: Header=BB14_9 Depth=2
	ldrh	w8, [sp, #68]
	add	w8, w8, #1
	strh	w8, [sp, #68]
	b	LBB14_9
LBB14_39:                               ;   in Loop: Header=BB14_1 Depth=1
	ldrb	w8, [sp, #71]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB14_43
	b	LBB14_40
LBB14_40:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #26]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbnz	w8, #0, LBB14_42
	b	LBB14_41
LBB14_41:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #27]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB14_42
LBB14_42:                               ;   in Loop: Header=BB14_1 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB14_43
LBB14_43:                               ;   in Loop: Header=BB14_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldur	x9, [x29, #-40]
	and	w8, w8, #0x1
	strb	w8, [x9, #28]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #28]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #16]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #20]
	ldur	x9, [x29, #-8]
	ldr	w10, [x9, #28]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB14_45
	b	LBB14_44
LBB14_44:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.57@PAGE
	add	x3, x3, l_.str.57@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_45:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w10, [x8, #20]
	ldur	x9, [x29, #-8]
	ldr	w8, [x9, #28]
	add	w8, w8, w10
	str	w8, [x9, #28]
	ldrb	w8, [sp, #71]
	tbnz	w8, #0, LBB14_48
	b	LBB14_46
LBB14_46:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #26]
	tbnz	w8, #0, LBB14_48
	b	LBB14_47
LBB14_47:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #24]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #8]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-8]
	mov	x10, #9248                      ; =0x2420
	add	x9, x9, x10
	ldur	x12, [x29, #-8]
	ldr	w10, [x12, #24]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	str	w11, [x12, #24]
	str	w8, [x9, x10, lsl #2]
	b	LBB14_48
LBB14_48:                               ;   in Loop: Header=BB14_1 Depth=1
	b	LBB14_49
LBB14_49:                               ;   in Loop: Header=BB14_1 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB14_1
LBB14_50:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.58@PAGE
	add	x3, x3, l_.str.58@PAGEOFF
	bl	_record_result
	b	LBB14_51
LBB14_51:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oa_paths
_oa_paths:                              ; @oa_paths
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp]                        ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #28]
	stur	w8, [x29, #-12]
	ldur	w8, [x29, #-12]
	cbz	w8, LBB15_3
	b	LBB15_1
LBB15_1:
	ldur	w8, [x29, #-12]
	mov	x9, x8
	mov	x8, #-1                         ; =0xffffffffffffffff
	udiv	x9, x8, x9
	mov	x8, #76                         ; =0x4c
	subs	x8, x8, x9
	b.ls	LBB15_3
	b	LBB15_2
LBB15_2:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.59@PAGE
	add	x3, x3, l_.str.59@PAGEOFF
	bl	_record_result
	b	LBB15_29
LBB15_3:
	ldur	w8, [x29, #-12]
	cbz	w8, LBB15_7
	b	LBB15_4
LBB15_4:
	ldur	w8, [x29, #-12]
	mov	x0, x8
	mov	x1, #76                         ; =0x4c
	bl	_calloc
	ldur	x8, [x29, #-8]
	str	x0, [x8, #10272]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #10272]
	cbnz	x8, LBB15_6
	b	LBB15_5
LBB15_5:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	mov	w2, #0                          ; =0x0
	mov	x1, x2
	adrp	x3, l_.str.60@PAGE
	add	x3, x3, l_.str.60@PAGEOFF
	bl	_record_result
	b	LBB15_29
LBB15_6:
	b	LBB15_7
LBB15_7:
	stur	wzr, [x29, #-16]
	b	LBB15_8
LBB15_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB15_12 Depth 2
                                        ;       Child Loop BB15_15 Depth 3
	ldur	w8, [x29, #-16]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB15_28
	b	LBB15_9
LBB15_9:                                ;   in Loop: Header=BB15_8 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #32
	ldur	w9, [x29, #-16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #24]
	tbnz	w8, #1, LBB15_11
	b	LBB15_10
LBB15_10:                               ;   in Loop: Header=BB15_8 Depth=1
	b	LBB15_27
LBB15_11:                               ;   in Loop: Header=BB15_8 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldur	w9, [x29, #-16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #16]
	stur	w8, [x29, #-36]
	sturh	wzr, [x29, #-38]
	b	LBB15_12
LBB15_12:                               ;   Parent Loop BB15_8 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB15_15 Depth 3
	ldurh	w8, [x29, #-38]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB15_24
	b	LBB15_13
LBB15_13:                               ;   in Loop: Header=BB15_12 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-38]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB15_21
	b	LBB15_14
LBB15_14:                               ;   in Loop: Header=BB15_12 Depth=2
	ldur	x8, [x29, #-8]
	add	x8, x8, #32
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB15_15
LBB15_15:                               ;   Parent Loop BB15_8 Depth=1
                                        ;     Parent Loop BB15_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #36]
	ldr	x9, [sp, #40]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.hs	LBB15_20
	b	LBB15_16
LBB15_16:                               ;   in Loop: Header=BB15_15 Depth=3
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #10272]
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #16]
	ldr	w9, [sp, #36]
	add	w8, w8, w9
	mov	w9, #76                         ; =0x4c
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #32
	b.lo	LBB15_18
	b	LBB15_17
LBB15_17:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	w1, [x29, #-16]
	ldurh	w2, [x29, #-38]
	mov	w0, #3                          ; =0x3
	adrp	x3, l_.str.61@PAGE
	add	x3, x3, l_.str.61@PAGEOFF
	bl	_record_result
	b	LBB15_29
LBB15_18:                               ;   in Loop: Header=BB15_15 Depth=3
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #10272]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	stur	w9, [x29, #-36]
	mov	x9, #76                         ; =0x4c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldur	w8, [x29, #-16]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #16]
	str	w8, [x9, #4]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #10]
	ldr	x9, [sp, #16]
	strb	w8, [x9, #10]
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #8]
	add	w8, w8, #1
	ldr	x9, [sp, #16]
	strh	w8, [x9, #8]
	ldurh	w8, [x29, #-38]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #12]
	ldr	x8, [sp, #16]
	add	x0, x8, #14
	ldr	x8, [sp, #24]
	add	x1, x8, #12
	ldr	x8, [sp, #24]
	ldrh	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #1
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB15_19
LBB15_19:                               ;   in Loop: Header=BB15_15 Depth=3
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB15_15
LBB15_20:                               ;   in Loop: Header=BB15_12 Depth=2
	b	LBB15_22
LBB15_21:                               ;   in Loop: Header=BB15_12 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #10272]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	stur	w9, [x29, #-36]
	mov	x9, #76                         ; =0x4c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldur	w8, [x29, #-16]
	ldr	x9, [sp, #8]
	str	w8, [x9, #4]
	ldr	x9, [sp, #8]
	str	w8, [x9]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	strb	w8, [x9, #10]
	ldr	x9, [sp, #8]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #8]
	ldurh	w8, [x29, #-38]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #12]
	b	LBB15_22
LBB15_22:                               ;   in Loop: Header=BB15_12 Depth=2
	b	LBB15_23
LBB15_23:                               ;   in Loop: Header=BB15_12 Depth=2
	ldurh	w8, [x29, #-38]
	add	w8, w8, #1
	sturh	w8, [x29, #-38]
	b	LBB15_12
LBB15_24:                               ;   in Loop: Header=BB15_8 Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #16]
	ldur	x10, [x29, #-24]
	ldr	w10, [x10, #20]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.eq	LBB15_26
	b	LBB15_25
LBB15_25:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	w1, [x29, #-16]
	mov	w0, #2                          ; =0x2
	mov	w2, #0                          ; =0x0
	adrp	x3, l_.str.62@PAGE
	add	x3, x3, l_.str.62@PAGEOFF
	bl	_record_result
	b	LBB15_29
LBB15_26:                               ;   in Loop: Header=BB15_8 Depth=1
	b	LBB15_27
LBB15_27:                               ;   in Loop: Header=BB15_8 Depth=1
	ldur	w8, [x29, #-16]
	add	w8, w8, #1
	stur	w8, [x29, #-16]
	b	LBB15_8
LBB15_28:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.63@PAGE
	add	x3, x3, l_.str.63@PAGEOFF
	bl	_record_result
	b	LBB15_29
LBB15_29:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_layout_counts  ; -- Begin function nvm_owned_array_layout_counts
	.p2align	2
_nvm_owned_array_layout_counts:         ; @nvm_owned_array_layout_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB16_2
	b	LBB16_1
LBB16_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB16_3
	b	LBB16_2
LBB16_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB16_4
LBB16_3:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	q0, [x9, #16]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB16_4
LBB16_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_layout_fact    ; -- Begin function nvm_owned_array_layout_fact
	.p2align	2
_nvm_owned_array_layout_fact:           ; @nvm_owned_array_layout_fact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB17_3
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp]
	cbz	x8, LBB17_3
	b	LBB17_2
LBB17_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB17_4
	b	LBB17_3
LBB17_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_5
LBB17_4:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	add	x9, x9, #32
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	q0, [x9, #16]
	str	q0, [x8, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_5
LBB17_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_source_layout  ; -- Begin function nvm_owned_array_source_layout
	.p2align	2
_nvm_owned_array_source_layout:         ; @nvm_owned_array_source_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB18_3
	b	LBB18_1
LBB18_1:
	ldr	x8, [sp]
	cbz	x8, LBB18_3
	b	LBB18_2
LBB18_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.lo	LBB18_4
	b	LBB18_3
LBB18_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB18_5
LBB18_4:
	ldr	x8, [sp, #16]
	mov	x9, #8224                       ; =0x2020
	add	x8, x8, x9
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB18_5
LBB18_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_managed_layout ; -- Begin function nvm_owned_array_managed_layout
	.p2align	2
_nvm_owned_array_managed_layout:        ; @nvm_owned_array_managed_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB19_3
	b	LBB19_1
LBB19_1:
	ldr	x8, [sp]
	cbz	x8, LBB19_3
	b	LBB19_2
LBB19_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB19_4
	b	LBB19_3
LBB19_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB19_5
LBB19_4:
	ldr	x8, [sp, #16]
	mov	x9, #9248                       ; =0x2420
	add	x8, x8, x9
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB19_5
LBB19_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_leaf_path      ; -- Begin function nvm_owned_array_leaf_path
	.p2align	2
_nvm_owned_array_leaf_path:             ; @nvm_owned_array_leaf_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB20_3
	b	LBB20_1
LBB20_1:
	ldr	x8, [sp]
	cbz	x8, LBB20_3
	b	LBB20_2
LBB20_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.lo	LBB20_4
	b	LBB20_3
LBB20_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_5
LBB20_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #10272]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #76                         ; =0x4c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #76                         ; =0x4c
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB20_5
LBB20_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_layout_field   ; -- Begin function nvm_owned_array_layout_field
	.p2align	2
_nvm_owned_array_layout_field:          ; @nvm_owned_array_layout_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB21_4
	b	LBB21_1
LBB21_1:
	ldr	x8, [sp]
	cbz	x8, LBB21_4
	b	LBB21_2
LBB21_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB21_4
	b	LBB21_3
LBB21_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB21_5
	b	LBB21_4
LBB21_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_6
LBB21_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #4
	ldr	x11, [x8, #8]
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_6
LBB21_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_transport      ; -- Begin function nvm_owned_array_transport
	.p2align	2
_nvm_owned_array_transport:             ; @nvm_owned_array_transport
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	ldr	x8, [sp, #32]
	cbz	x8, LBB22_2
	b	LBB22_1
LBB22_1:
	ldr	x8, [sp, #24]
	cbnz	x8, LBB22_3
	b	LBB22_2
LBB22_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB22_4
LBB22_3:
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #10280]
	str	x8, [sp]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #10288]
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #10296]
	str	w8, [sp, #16]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #10300]
	str	w8, [sp, #20]
	ldr	q0, [sp]
	str	q0, [x9]
	ldr	x8, [sp, #16]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB22_4
LBB22_4:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origins_free   ; -- Begin function nvm_owned_array_origins_free
	.p2align	2
_nvm_owned_array_origins_free:          ; @nvm_owned_array_origins_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	b	LBB23_3
LBB23_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_owned_array_layouts_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB23_3
LBB23_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_analyze_owned_array_origins ; -- Begin function nvm_analyze_owned_array_origins
	.p2align	2
_nvm_analyze_owned_array_origins:       ; @nvm_analyze_owned_array_origins
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x9, x29, #16
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x9, x8
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	str	x0, [x8, #8]
	str	x1, [x8]
	adrp	x9, l___const.nvm_analyze_owned_array_origins.invalid@PAGE
	add	x9, x9, l___const.nvm_analyze_owned_array_origins.invalid@PAGEOFF
	ldr	q0, [x9]
	stur	q0, [x29, #-48]
	ldr	x9, [x9, #16]
	stur	x9, [x29, #-32]
	ldr	x8, [x8, #8]
	cbz	x8, LBB24_2
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB24_3
	b	LBB24_2
LBB24_2:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [x29, #-48]
	str	q0, [x9]
	ldur	x8, [x29, #-32]
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB24_5
	b	LBB24_4
LBB24_4:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.33@PAGE
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #256]
	cbz	x8, LBB24_14
	b	LBB24_6
LBB24_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #280]
	cbz	x8, LBB24_14
	b	LBB24_7
LBB24_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #272]
	cbz	w8, LBB24_14
	b	LBB24_8
LBB24_8:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #288]
	cbz	w8, LBB24_14
	b	LBB24_9
LBB24_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #78
	b.ne	LBB24_14
	b	LBB24_10
LBB24_10:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #86
	b.ne	LBB24_14
	b	LBB24_11
LBB24_11:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #2]
	subs	w8, w8, #77
	b.ne	LBB24_14
	b	LBB24_12
LBB24_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #1
	b.ne	LBB24_14
	b	LBB24_13
LBB24_13:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #4]
	subs	w8, w8, #2
	b.eq	LBB24_15
	b	LBB24_14
LBB24_14:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [x29, #-48]
	str	q0, [x9]
	ldur	x8, [x29, #-32]
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_15:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #272]
	subs	w8, w8, #8
	b.hi	LBB24_24
	b	LBB24_16
LBB24_16:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB24_24
	b	LBB24_17
LBB24_17:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB24_24
	b	LBB24_18
LBB24_18:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	mov	w9, #-6                         ; =0xfffffffa
	and	w8, w8, w9
	cbnz	w8, LBB24_24
	b	LBB24_19
LBB24_19:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB24_24
	b	LBB24_20
LBB24_20:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB24_24
	b	LBB24_21
LBB24_21:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #424]
	cbnz	w8, LBB24_24
	b	LBB24_22
LBB24_22:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB24_24
	b	LBB24_23
LBB24_23:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #344]
	cbz	x8, LBB24_25
	b	LBB24_24
LBB24_24:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.34@PAGE
	add	x8, x8, l_.str.34@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_25:
	stur	wzr, [x29, #-52]
	b	LBB24_26
LBB24_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-52]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB24_38
	b	LBB24_27
LBB24_27:                               ;   in Loop: Header=BB24_26 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.hi	LBB24_29
	b	LBB24_28
LBB24_28:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #4]
	subs	w8, w8, #8
	b.le	LBB24_30
	b	LBB24_29
LBB24_29:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9]
	ldur	w8, [x29, #-52]
	str	w8, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.35@PAGE
	add	x8, x8, l_.str.35@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_30:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.gt	LBB24_35
	b	LBB24_31
LBB24_31:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB24_35
	b	LBB24_32
LBB24_32:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB24_35
	b	LBB24_33
LBB24_33:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	w8, [x29, #-52]
	cbnz	w8, LBB24_36
	b	LBB24_34
LBB24_34:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB24_36
	b	LBB24_35
LBB24_35:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	q0, [x29, #-48]
	str	q0, [x9]
	ldur	x8, [x29, #-32]
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_36:                               ;   in Loop: Header=BB24_26 Depth=1
	b	LBB24_37
LBB24_37:                               ;   in Loop: Header=BB24_26 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB24_26
LBB24_38:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	sub	x1, x29, #72
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-72]
	ldr	x0, [x8, #8]
	add	x8, sp, #96
	bl	_nvm_describe_owned_array_layouts
	ldr	w8, [sp, #96]
	cbz	w8, LBB24_46
	b	LBB24_39
LBB24_39:
	ldr	w8, [sp, #96]
	subs	w8, w8, #4
	b.ne	LBB24_41
	b	LBB24_40
LBB24_40:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_45
LBB24_41:
	ldr	w8, [sp, #96]
	subs	w8, w8, #3
	b.ne	LBB24_43
	b	LBB24_42
LBB24_42:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB24_44
LBB24_43:
	ldr	w9, [sp, #96]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #2
	csinc	w8, w8, wzr, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB24_44
LBB24_44:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB24_45
LBB24_45:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #92]
	ldr	w8, [sp, #92]
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #112]
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_46:
	mov	x0, #1                          ; =0x1
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x1, #35744                      ; =0x8ba0
	movk	x1, #6, lsl #16
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #80]
	mov	x1, #17624                      ; =0x44d8
	movk	x1, #9, lsl #16
	bl	_calloc
	str	x0, [sp, #72]
	ldr	x8, [sp, #80]
	cbz	x8, LBB24_48
	b	LBB24_47
LBB24_47:
	ldr	x8, [sp, #72]
	cbnz	x8, LBB24_49
	b	LBB24_48
LBB24_48:
	ldr	x0, [sp, #80]
	bl	_free
	ldr	x0, [sp, #72]
	bl	_free
	ldur	x0, [x29, #-72]
	bl	_nvm_owned_array_layouts_free
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.36@PAGE
	add	x8, x8, l_.str.36@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_77
LBB24_49:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #8]
	ldr	x10, [sp, #80]
	str	x9, [x10]
	ldr	x9, [sp, #72]
	ldr	x10, [sp, #80]
	str	x9, [x10, #8]
	ldr	x9, [sp, #80]
	mov	x10, #35720                     ; =0x8b88
	movk	x10, #6, lsl #16
	add	x10, x9, x10
	ldur	q0, [x29, #-48]
	str	q0, [x10]
	ldur	x9, [x29, #-32]
	str	x9, [x10, #16]
	ldur	x9, [x29, #-72]
	ldr	x10, [sp, #72]
	str	x9, [x10]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #272]
	ldr	x9, [sp, #72]
	str	w8, [x9, #8]
	ldr	x0, [sp, #80]
	bl	_oq_paths
	tbz	w0, #0, LBB24_52
	b	LBB24_50
LBB24_50:
	ldr	x0, [sp, #80]
	bl	_oq_descriptors
	tbz	w0, #0, LBB24_52
	b	LBB24_51
LBB24_51:
	ldr	x0, [sp, #80]
	bl	_oq_decode
	tbnz	w0, #0, LBB24_53
	b	LBB24_52
LBB24_52:
	b	LBB24_69
LBB24_53:
	str	wzr, [sp, #68]
	b	LBB24_54
LBB24_54:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #68]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB24_59
	b	LBB24_55
LBB24_55:                               ;   in Loop: Header=BB24_54 Depth=1
	ldr	x0, [sp, #80]
	ldr	w1, [sp, #68]
	bl	_oq_function
	tbnz	w0, #0, LBB24_57
	b	LBB24_56
LBB24_56:
	b	LBB24_69
LBB24_57:                               ;   in Loop: Header=BB24_54 Depth=1
	b	LBB24_58
LBB24_58:                               ;   in Loop: Header=BB24_54 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB24_54
LBB24_59:
	ldr	x0, [sp, #80]
	mov	w1, #0                          ; =0x0
	bl	_oq_reachable
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #64]
	b	LBB24_60
LBB24_60:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #64]
	subs	w8, w8, #5
	b.hs	LBB24_65
	b	LBB24_61
LBB24_61:                               ;   in Loop: Header=BB24_60 Depth=1
	ldr	x8, [sp, #72]
	add	x8, x8, #808
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB24_63
	b	LBB24_62
LBB24_62:
	ldr	x0, [sp, #80]
	mov	w1, #1                          ; =0x1
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.37@PAGE
	add	x4, x4, l_.str.37@PAGEOFF
	bl	_oq_stop
	b	LBB24_69
LBB24_63:                               ;   in Loop: Header=BB24_60 Depth=1
	b	LBB24_64
LBB24_64:                               ;   in Loop: Header=BB24_60 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB24_60
LBB24_65:
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #12]
	subs	w8, w8, #64
	b.hs	LBB24_68
	b	LBB24_66
LBB24_66:
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #808]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	lsr	x8, x8, x9
	cbz	x8, LBB24_68
	b	LBB24_67
LBB24_67:
	ldr	x0, [sp, #80]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.38@PAGE
	add	x4, x4, l_.str.38@PAGEOFF
	bl	_oq_stop
	b	LBB24_69
LBB24_68:
	ldr	x8, [sp, #80]
	mov	x9, #17248                      ; =0x4360
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldr	x9, [sp, #72]
	str	w8, [x9, #16]
	ldr	x8, [sp, #80]
	mov	x9, #35720                      ; =0x8b88
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	str	wzr, [sp, #40]
	str	wzr, [sp, #44]
	str	wzr, [sp, #48]
	str	wzr, [sp, #52]
	adrp	x8, l_.str.39@PAGE
	add	x8, x8, l_.str.39@PAGEOFF
	str	x8, [sp, #56]
	ldur	q0, [sp, #40]
	str	q0, [x9]
	ldr	x8, [sp, #56]
	str	x8, [x9, #16]
	b	LBB24_69
LBB24_69:
	str	wzr, [sp, #36]
	b	LBB24_70
LBB24_70:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	x9, [sp, #80]
	mov	x10, #17248                     ; =0x4360
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB24_73
	b	LBB24_71
LBB24_71:                               ;   in Loop: Header=BB24_70 Depth=1
	ldr	x8, [sp, #80]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8, #88]
	bl	_free
	b	LBB24_72
LBB24_72:                               ;   in Loop: Header=BB24_70 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB24_70
LBB24_73:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #80]
	mov	x10, #35720                     ; =0x8b88
	movk	x10, #6, lsl #16
	add	x8, x8, x10
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x8, [sp, #80]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x8, [sp, #80]
	mov	x9, #19312                      ; =0x4b70
	movk	x9, #6, lsl #16
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x0, [sp, #80]
	bl	_free
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cbnz	w8, LBB24_75
	b	LBB24_74
LBB24_74:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	ldr	x9, [x9]
	str	x8, [x9]
	b	LBB24_76
LBB24_75:
	ldr	x0, [sp, #72]
	bl	_nvm_owned_array_origins_free
	b	LBB24_76
LBB24_76:
	b	LBB24_77
LBB24_77:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_paths
_oq_paths:                              ; @oq_paths
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sub	x1, x29, #32
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	bl	_nvm_owned_array_layout_counts
	ldur	w8, [x29, #-20]
	cbz	w8, LBB25_4
	b	LBB25_1
LBB25_1:
	ldur	w8, [x29, #-20]
	mov	x0, x8
	mov	x1, #4                          ; =0x4
	bl	_calloc
	ldur	x8, [x29, #-16]
	mov	x9, #19312                      ; =0x4b70
	movk	x9, #6, lsl #16
	str	x0, [x8, x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, x9]
	cbnz	x8, LBB25_3
	b	LBB25_2
LBB25_2:
	ldur	x0, [x29, #-16]
	mov	w1, #4                          ; =0x4
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.64@PAGE
	add	x4, x4, l_.str.64@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB25_17
LBB25_3:
	b	LBB25_4
LBB25_4:
	stur	wzr, [x29, #-36]
	stur	wzr, [x29, #-40]
	b	LBB25_5
LBB25_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_7 Depth 2
	ldur	w8, [x29, #-40]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.hs	LBB25_14
	b	LBB25_6
LBB25_6:                                ;   in Loop: Header=BB25_5 Depth=1
	movi.2d	v0, #0000000000000000
	sub	x2, x29, #80
	stur	q0, [x29, #-80]
	stur	q0, [x29, #-64]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-40]
	bl	_nvm_owned_array_layout_fact
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-16]
	mov	x10, #18284                     ; =0x476c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldur	w10, [x29, #-40]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	stur	wzr, [x29, #-84]
	b	LBB25_7
LBB25_7:                                ;   Parent Loop BB25_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-84]
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.hs	LBB25_12
	b	LBB25_8
LBB25_8:                                ;   in Loop: Header=BB25_7 Depth=2
	add	x0, sp, #16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #76                         ; =0x4c
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-84]
	add	w1, w8, w9
	bl	_nvm_owned_array_leaf_path
	ldrb	w8, [sp, #26]
	subs	w8, w8, #7
	b.ne	LBB25_10
	b	LBB25_9
LBB25_9:                                ;   in Loop: Header=BB25_7 Depth=2
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-84]
	add	w8, w8, w9
	ldur	x9, [x29, #-16]
	mov	x10, #19312                     ; =0x4b70
	movk	x10, #6, lsl #16
	ldr	x9, [x9, x10]
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-36]
	str	w8, [x9, x10, lsl #2]
	ldur	x8, [x29, #-16]
	mov	x9, #17260                      ; =0x436c
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldur	w8, [x29, #-40]
	mov	x10, x8
	ldr	w8, [x9, x10, lsl #2]
	add	w8, w8, #1
	str	w8, [x9, x10, lsl #2]
	b	LBB25_10
LBB25_10:                               ;   in Loop: Header=BB25_7 Depth=2
	b	LBB25_11
LBB25_11:                               ;   in Loop: Header=BB25_7 Depth=2
	ldur	w8, [x29, #-84]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	b	LBB25_7
LBB25_12:                               ;   in Loop: Header=BB25_5 Depth=1
	b	LBB25_13
LBB25_13:                               ;   in Loop: Header=BB25_5 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB25_5
LBB25_14:
	mov	x0, #65536                      ; =0x10000
	mov	x1, #40                         ; =0x28
	bl	_calloc
	ldur	x8, [x29, #-16]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	str	x0, [x8, x9]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, x9]
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbnz	x8, LBB25_16
	b	LBB25_15
LBB25_15:
	ldur	x0, [x29, #-16]
	mov	w1, #4                          ; =0x4
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.65@PAGE
	add	x4, x4, l_.str.65@PAGEOFF
	bl	_oq_stop
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB25_16
LBB25_16:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB25_17
LBB25_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_descriptors
_oq_descriptors:                        ; @oq_descriptors
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sub	x1, x29, #40
	stur	xzr, [x29, #-40]
	stur	xzr, [x29, #-32]
	stur	xzr, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	bl	_nvm_owned_array_transport
	ldur	x1, [x29, #-32]
	ldur	w8, [x29, #-20]
	mov	x2, x8
	sub	x0, x29, #64
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB26_6
	b	LBB26_1
LBB26_1:
	sub	x0, x29, #64
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	cbnz	w0, LBB26_6
	b	LBB26_2
LBB26_2:
	ldur	w8, [x29, #-68]
	mov	x1, x8
	sub	x0, x29, #64
	add	x2, sp, #64
	bl	_nvm_v2_take
	cbnz	w0, LBB26_6
	b	LBB26_3
LBB26_3:
	sub	x0, x29, #64
	bl	_nvm_v2_align4
	cbnz	w0, LBB26_6
	b	LBB26_4
LBB26_4:
	sub	x0, x29, #64
	sub	x1, x29, #68
	bl	_nvm_v2_u32
	cbnz	w0, LBB26_6
	b	LBB26_5
LBB26_5:
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB26_7
	b	LBB26_6
LBB26_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_7:
	str	wzr, [sp, #60]
	b	LBB26_8
LBB26_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_15 Depth 2
	ldr	w8, [sp, #60]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hs	LBB26_58
	b	LBB26_9
LBB26_9:                                ;   in Loop: Header=BB26_8 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	sub	x0, x29, #64
	add	x1, sp, #46
	bl	_nvm_v2_u16
	cbnz	w0, LBB26_13
	b	LBB26_10
LBB26_10:                               ;   in Loop: Header=BB26_8 Depth=1
	sub	x0, x29, #64
	add	x1, sp, #44
	bl	_nvm_v2_u16
	cbnz	w0, LBB26_13
	b	LBB26_11
LBB26_11:                               ;   in Loop: Header=BB26_8 Depth=1
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB26_13
	b	LBB26_12
LBB26_12:                               ;   in Loop: Header=BB26_8 Depth=1
	ldrh	w8, [sp, #44]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB26_14
	b	LBB26_13
LBB26_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_14:                               ;   in Loop: Header=BB26_8 Depth=1
	str	wzr, [sp, #40]
	b	LBB26_15
LBB26_15:                               ;   Parent Loop BB26_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #40]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.hi	LBB26_56
	b	LBB26_16
LBB26_16:                               ;   in Loop: Header=BB26_15 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #32
	bl	_nvm_v2_u8
	cbnz	w0, LBB26_20
	b	LBB26_17
LBB26_17:                               ;   in Loop: Header=BB26_15 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #31
	bl	_nvm_v2_u8
	cbnz	w0, LBB26_20
	b	LBB26_18
LBB26_18:                               ;   in Loop: Header=BB26_15 Depth=2
	sub	x0, x29, #64
	add	x1, sp, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB26_20
	b	LBB26_19
LBB26_19:                               ;   in Loop: Header=BB26_15 Depth=2
	add	x8, sp, #32
	add	x1, x8, #4
	sub	x0, x29, #64
	bl	_nvm_v2_u32
	cbz	w0, LBB26_21
	b	LBB26_20
LBB26_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_21:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #31]
	cbnz	w8, LBB26_23
	b	LBB26_22
LBB26_22:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrh	w8, [sp, #28]
	cbz	w8, LBB26_24
	b	LBB26_23
LBB26_23:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #60]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.66@PAGE
	add	x4, x4, l_.str.66@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_24:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #40]
	cbz	w8, LBB26_26
	b	LBB26_25
LBB26_25:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #40]
	ldrh	w9, [sp, #44]
	subs	w8, w8, w9
	b.hi	LBB26_31
	b	LBB26_26
LBB26_26:                               ;   in Loop: Header=BB26_15 Depth=2
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_oq_signature
	tbz	w0, #0, LBB26_29
	b	LBB26_27
LBB26_27:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #40]
	cbz	w8, LBB26_30
	b	LBB26_28
LBB26_28:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	cbnz	w8, LBB26_30
	b	LBB26_29
LBB26_29:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #60]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.67@PAGE
	add	x4, x4, l_.str.67@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_30:                               ;   in Loop: Header=BB26_15 Depth=2
	b	LBB26_37
LBB26_31:                               ;   in Loop: Header=BB26_15 Depth=2
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_oq_signature
	tbnz	w0, #0, LBB26_36
	b	LBB26_32
LBB26_32:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #36]
	adds	w8, w8, #1
	b.ne	LBB26_35
	b	LBB26_33
LBB26_33:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #7
	b.eq	LBB26_36
	b	LBB26_34
LBB26_34:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #3
	b.eq	LBB26_36
	b	LBB26_35
LBB26_35:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #60]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.68@PAGE
	add	x4, x4, l_.str.68@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_36:                               ;   in Loop: Header=BB26_15 Depth=2
	b	LBB26_37
LBB26_37:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #40]
	cbnz	w8, LBB26_53
	b	LBB26_38
LBB26_38:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #21]
	cbnz	w8, LBB26_40
	b	LBB26_39
LBB26_39:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	cbnz	w8, LBB26_42
	b	LBB26_40
LBB26_40:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB26_43
	b	LBB26_41
LBB26_41:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #20]
	ldrb	w9, [sp, #32]
	subs	w8, w8, w9
	b.eq	LBB26_43
	b	LBB26_42
LBB26_42:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_43:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #60]
	cbnz	w8, LBB26_49
	b	LBB26_44
LBB26_44:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #1
	b.eq	LBB26_49
	b	LBB26_45
LBB26_45:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #4
	b.eq	LBB26_49
	b	LBB26_46
LBB26_46:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #2
	b.eq	LBB26_49
	b	LBB26_47
LBB26_47:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	cbz	w8, LBB26_49
	b	LBB26_48
LBB26_48:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #60]
	mov	w1, #1                          ; =0x1
	str	w1, [sp]                        ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.69@PAGE
	add	x4, x4, l_.str.69@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_49:                               ;   in Loop: Header=BB26_15 Depth=2
	ldrb	w8, [sp, #32]
	subs	w8, w8, #8
	b.ne	LBB26_52
	b	LBB26_50
LBB26_50:                               ;   in Loop: Header=BB26_15 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #17260                      ; =0x436c
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #256
	b.ls	LBB26_52
	b	LBB26_51
LBB26_51:
	ldur	x0, [x29, #-16]
	ldr	w2, [sp, #60]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.70@PAGE
	add	x4, x4, l_.str.70@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_52:                               ;   in Loop: Header=BB26_15 Depth=2
	ldur	x8, [x29, #-16]
	add	x9, x8, #16
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x10, #2152                      ; =0x868
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x10, w8, w10
	ldr	x8, [sp, #32]
	str	x8, [x9, x10]
	b	LBB26_54
LBB26_53:                               ;   in Loop: Header=BB26_15 Depth=2
	ldur	x8, [x29, #-16]
	add	x10, x8, #16
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x9, x8, #8
	ldr	w8, [sp, #40]
	subs	w10, w8, #1
	ldr	x8, [sp, #32]
	str	x8, [x9, w10, uxtw #3]
	b	LBB26_54
LBB26_54:                               ;   in Loop: Header=BB26_15 Depth=2
	b	LBB26_55
LBB26_55:                               ;   in Loop: Header=BB26_15 Depth=2
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB26_15
LBB26_56:                               ;   in Loop: Header=BB26_8 Depth=1
	b	LBB26_57
LBB26_57:                               ;   in Loop: Header=BB26_8 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB26_8
LBB26_58:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB26_59
LBB26_59:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_decode
_oq_decode:                             ; @oq_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x9, x29, #48
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x9, #32]
	ldr	x8, [x9, #32]
	ldr	x8, [x8]
	str	x8, [x9, #24]
	stur	wzr, [x29, #-28]
	b	LBB27_1
LBB27_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB27_13 Depth 2
                                        ;     Child Loop BB27_20 Depth 2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-28]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB27_67
	b	LBB27_2
LBB27_2:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #24]
	ldr	x11, [x8, #256]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [x9, #8]
	ldr	x8, [x9, #32]
	add	x11, x8, #16
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x10, #2152                      ; =0x868
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [x9]
	ldr	x8, [x9, #32]
	mov	x10, #17248                     ; =0x4360
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	ldr	x10, [x9]
	str	w8, [x10, #2056]
	ldr	x8, [x9, #8]
	ldr	w8, [x8]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB27_5
	b	LBB27_3
LBB27_3:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	x8, [x8, #232]
	cbz	x8, LBB27_5
	b	LBB27_4
LBB27_4:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #24]
	ldr	x8, [x8, #232]
	ldr	x9, [x9, #8]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB27_6
	b	LBB27_5
LBB27_5:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.71@PAGE
	add	x4, x4, l_.str.71@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_6:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #24]
	ldr	x8, [x8, #232]
	ldr	x9, [x9, #8]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, l_.str.72@PAGE
	add	x1, x1, l_.str.72@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB27_8
	b	LBB27_7
LBB27_7:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.73@PAGE
	add	x4, x4, l_.str.73@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_8:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB27_11
	b	LBB27_9
LBB27_9:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x8, [x10, #8]
	ldr	w8, [x8, #12]
	ldr	x9, [x10, #24]
	ldr	w9, [x9, #288]
	ldr	x10, [x10, #8]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB27_11
	b	LBB27_10
LBB27_10:                               ;   in Loop: Header=BB27_1 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB27_12
	b	LBB27_11
LBB27_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.74@PAGE
	add	x4, x4, l_.str.74@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_12:                               ;   in Loop: Header=BB27_1 Depth=1
	stur	wzr, [x29, #-52]
	b	LBB27_13
LBB27_13:                               ;   Parent Loop BB27_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-52]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.hs	LBB27_19
	b	LBB27_14
LBB27_14:                               ;   in Loop: Header=BB27_13 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #24]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	stur	x9, [x29, #-64]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-64]
	ldr	w10, [x10, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	subs	x8, x8, x9
	b.hs	LBB27_17
	b	LBB27_15
LBB27_15:                               ;   in Loop: Header=BB27_13 Depth=2
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [x10, #8]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [x10, #8]
	ldr	w10, [x10, #12]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	subs	x8, x8, x9
	b.hs	LBB27_17
	b	LBB27_16
LBB27_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #24]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.75@PAGE
	add	x4, x4, l_.str.75@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_17:                               ;   in Loop: Header=BB27_13 Depth=2
	b	LBB27_18
LBB27_18:                               ;   in Loop: Header=BB27_13 Depth=2
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB27_13
LBB27_19:                               ;   in Loop: Header=BB27_1 Depth=1
	stur	wzr, [x29, #-68]
	b	LBB27_20
LBB27_20:                               ;   Parent Loop BB27_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-68]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB27_65
	b	LBB27_21
LBB27_21:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	mov	x9, #17248                      ; =0x4360
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ne	LBB27_23
	b	LBB27_22
LBB27_22:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.76@PAGE
	add	x4, x4, l_.str.76@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_23:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #32]
	mov	x10, #17232                     ; =0x4350
	add	x11, x9, x10
	ldr	x9, [x8, #32]
	mov	x10, #17248                     ; =0x4360
	movk	x10, #6, lsl #16
	add	x12, x9, x10
	ldr	w9, [x12]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [x12]
	mov	x10, #96                        ; =0x60
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	stur	x9, [x29, #-80]
	ldur	w9, [x29, #-28]
	ldur	x10, [x29, #-80]
	str	w9, [x10, #64]
	ldur	w9, [x29, #-68]
	ldur	x10, [x29, #-80]
	str	w9, [x10, #68]
	ldur	x10, [x29, #-80]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [x10, #82]
	ldur	x10, [x29, #-80]
	strh	w9, [x10, #80]
	ldr	x9, [x8, #24]
	ldr	x9, [x9, #280]
	ldr	x10, [x8, #8]
	ldr	w10, [x10, #8]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	ldur	w10, [x29, #-68]
                                        ; kill: def $x10 killed $w10
	add	x0, x9, x10
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldur	x2, [x29, #-80]
	bl	_isa_decode
	stur	w0, [x29, #-84]
	ldur	w8, [x29, #-84]
	cbnz	w8, LBB27_25
	b	LBB27_24
LBB27_24:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.77@PAGE
	add	x4, x4, l_.str.77@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_25:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #32]
	ldr	x9, [x9, #8]
	mov	x10, #34008                     ; =0x84d8
	movk	x10, #7, lsl #16
	add	x10, x9, x10
	ldr	x8, [x8, #32]
	mov	x9, #17248                      ; =0x4360
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	subs	w8, w8, #1
	mov	w9, #28                         ; =0x1c
	umaddl	x8, w8, w9, x10
	ldur	w10, [x29, #-28]
	add	x9, sp, #112
	str	w10, [sp, #112]
	ldur	w10, [x29, #-68]
	str	w10, [sp, #116]
	strh	wzr, [sp, #120]
	strh	wzr, [sp, #122]
	strh	wzr, [sp, #124]
	stur	wzr, [x9, #14]
	stur	wzr, [x9, #18]
	ldur	x10, [x29, #-80]
	ldrb	w10, [x10]
	strb	w10, [sp, #134]
	strb	wzr, [sp, #135]
	strb	wzr, [sp, #136]
	add	x10, x9, #25
	strh	wzr, [x10]
	strb	wzr, [sp, #139]
	ldr	q0, [sp, #112]
	str	q0, [x8]
	ldur	q0, [x9, #12]
	stur	q0, [x8, #12]
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	strb	w8, [sp, #111]
	ldrb	w0, [sp, #111]
	bl	_oq_supported
	tbnz	w0, #0, LBB27_27
	b	LBB27_26
LBB27_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.78@PAGE
	add	x4, x4, l_.str.78@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_27:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #3
	b.ne	LBB27_30
	b	LBB27_28
LBB27_28:                               ;   in Loop: Header=BB27_20 Depth=2
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.le	LBB27_30
	b	LBB27_29
LBB27_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.79@PAGE
	add	x4, x4, l_.str.79@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_30:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #4
	b.ne	LBB27_34
	b	LBB27_31
LBB27_31:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB27_33
	b	LBB27_32
LBB27_32:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	x8, [x8, #232]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB27_34
	b	LBB27_33
LBB27_33:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.80@PAGE
	add	x4, x4, l_.str.80@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_34:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #16
	b.eq	LBB27_39
	b	LBB27_35
LBB27_35:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #17
	b.eq	LBB27_39
	b	LBB27_36
LBB27_36:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #11
	b.eq	LBB27_39
	b	LBB27_37
LBB27_37:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #12
	b.eq	LBB27_39
	b	LBB27_38
LBB27_38:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #14
	b.ne	LBB27_42
	b	LBB27_39
LBB27_39:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #8]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.lt	LBB27_41
	b	LBB27_40
LBB27_40:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.81@PAGE
	add	x4, x4, l_.str.81@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_41:                               ;   in Loop: Header=BB27_20 Depth=2
	b	LBB27_42
LBB27_42:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #59
	b.ne	LBB27_48
	b	LBB27_43
LBB27_43:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	str	w8, [sp, #104]
	ldr	w8, [sp, #104]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB27_45
	b	LBB27_44
LBB27_44:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.82@PAGE
	add	x4, x4, l_.str.82@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_45:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	w8, [sp, #104]
	cbnz	w8, LBB27_47
	b	LBB27_46
LBB27_46:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #16]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.83@PAGE
	add	x4, x4, l_.str.83@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_47:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w10, [sp, #104]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w10, w9, #0xff
	ldr	x9, [x8]
	ldrb	w8, [x9, #2080]
	orr	w8, w8, w10
	strb	w8, [x9, #2080]
	b	LBB27_48
LBB27_48:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #13
	b.eq	LBB27_50
	b	LBB27_49
LBB27_49:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #14
	b.ne	LBB27_57
	b	LBB27_50
LBB27_50:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #13
	b.ne	LBB27_52
	b	LBB27_51
LBB27_51:                               ;   in Loop: Header=BB27_20 Depth=2
	add	x8, sp, #96
	mov	w9, #8                          ; =0x8
	strb	w9, [sp, #96]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #99]
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	str	w8, [sp, #100]
	b	LBB27_53
LBB27_52:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	x8, x8, #8
	ldur	x9, [x29, #-80]
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #96]
	b	LBB27_53
LBB27_53:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #96]
	subs	w8, w8, #8
	b.ne	LBB27_55
	b	LBB27_54
LBB27_54:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldr	w1, [sp, #100]
	bl	_oq_owner_layout
	tbnz	w0, #0, LBB27_56
	b	LBB27_55
LBB27_55:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.84@PAGE
	add	x4, x4, l_.str.84@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_56:                               ;   in Loop: Header=BB27_20 Depth=2
	b	LBB27_57
LBB27_57:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #80
	b.eq	LBB27_59
	b	LBB27_58
LBB27_58:                               ;   in Loop: Header=BB27_20 Depth=2
	ldrb	w8, [sp, #111]
	subs	w8, w8, #88
	b.ne	LBB27_64
	b	LBB27_59
LBB27_59:                               ;   in Loop: Header=BB27_20 Depth=2
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #3
	b.eq	LBB27_61
	b	LBB27_60
LBB27_60:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.85@PAGE
	add	x4, x4, l_.str.85@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_61:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
	subs	w8, w8, #64
	b.ne	LBB27_63
	b	LBB27_62
LBB27_62:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.86@PAGE
	add	x4, x4, l_.str.86@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_63:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #32]
	ldr	x11, [x9, #8]
	ldr	w9, [x11, #12]
	add	w10, w9, #1
	str	w10, [x11, #12]
	ldur	x10, [x29, #-80]
	strh	w9, [x10, #80]
	ldr	x8, [x8, #32]
	ldr	x8, [x8, #8]
	add	x8, x8, #20
	ldur	x9, [x29, #-80]
	ldrsh	x9, [x9, #80]
	mov	x10, #12                        ; =0xc
	mul	x9, x9, x10
	add	x9, x8, x9
	ldur	w10, [x29, #-28]
	add	x8, sp, #84
	str	w10, [sp, #84]
	ldur	w10, [x29, #-68]
	str	w10, [sp, #88]
	ldrb	w10, [sp, #111]
	strb	w10, [sp, #92]
	add	x8, x8, #9
	strh	wzr, [x8]
	strb	wzr, [sp, #95]
	ldur	x8, [sp, #84]
	str	x8, [x9]
	ldr	w8, [sp, #92]
	str	w8, [x9, #8]
	b	LBB27_64
LBB27_64:                               ;   in Loop: Header=BB27_20 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w10, [x29, #-84]
	ldur	w9, [x29, #-68]
	add	w9, w9, w10
	stur	w9, [x29, #-68]
	ldr	x8, [x8, #32]
	mov	x9, #17248                      ; =0x4360
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-80]
	str	w8, [x9, #72]
	ldur	x9, [x29, #-80]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #76]
	b	LBB27_20
LBB27_65:                               ;   in Loop: Header=BB27_1 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #32]
	mov	x10, #17248                     ; =0x4360
	movk	x10, #6, lsl #16
	ldr	w8, [x8, x10]
	ldr	x9, [x9]
	str	w8, [x9, #2060]
	b	LBB27_66
LBB27_66:                               ;   in Loop: Header=BB27_1 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB27_1
LBB27_67:
	str	wzr, [sp, #80]
	b	LBB27_68
LBB27_68:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB27_70 Depth 2
                                        ;       Child Loop BB27_75 Depth 3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #80]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB27_91
	b	LBB27_69
LBB27_69:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	add	x10, x8, #16
	ldr	w8, [sp, #80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #2056]
	str	w8, [sp, #76]
	b	LBB27_70
LBB27_70:                               ;   Parent Loop BB27_68 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB27_75 Depth 3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #76]
	ldr	x9, [x9, #32]
	add	x11, x9, #16
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	mov	x10, #2152                      ; =0x868
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #2060]
	subs	w8, w8, w9
	b.hs	LBB27_89
	b	LBB27_71
LBB27_71:                               ;   in Loop: Header=BB27_70 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	strb	w8, [sp, #63]
	ldrb	w8, [sp, #63]
	subs	w8, w8, #56
	b.eq	LBB27_74
	b	LBB27_72
LBB27_72:                               ;   in Loop: Header=BB27_70 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #57
	b.eq	LBB27_74
	b	LBB27_73
LBB27_73:                               ;   in Loop: Header=BB27_70 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #58
	b.ne	LBB27_83
	b	LBB27_74
LBB27_74:                               ;   in Loop: Header=BB27_70 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #68]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #64]
	ldrsw	x10, [x10, #8]
	add	x9, x9, x10
	str	x9, [sp, #48]
	ldr	x8, [x8, #32]
	add	x10, x8, #16
	ldr	w8, [sp, #80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #2056]
	str	w8, [sp, #44]
	b	LBB27_75
LBB27_75:                               ;   Parent Loop BB27_68 Depth=1
                                        ;     Parent Loop BB27_70 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #44]
	ldr	x9, [x9, #32]
	add	x11, x9, #16
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	mov	x10, #2152                      ; =0x868
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #2060]
	subs	w8, w8, w9
	b.hs	LBB27_80
	b	LBB27_76
LBB27_76:                               ;   in Loop: Header=BB27_75 Depth=3
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #48]
	ldr	x9, [x9, #32]
	mov	x10, #17232                     ; =0x4350
	add	x11, x9, x10
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	mov	x10, #96                        ; =0x60
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #68]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ne	LBB27_78
	b	LBB27_77
LBB27_77:                               ;   in Loop: Header=BB27_75 Depth=3
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #64]
	str	w8, [x9, #76]
	b	LBB27_78
LBB27_78:                               ;   in Loop: Header=BB27_75 Depth=3
	b	LBB27_79
LBB27_79:                               ;   in Loop: Header=BB27_75 Depth=3
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB27_75
LBB27_80:                               ;   in Loop: Header=BB27_70 Depth=2
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #76]
	adds	w8, w8, #1
	b.ne	LBB27_82
	b	LBB27_81
LBB27_81:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldr	w2, [sp, #80]
	ldr	x8, [sp, #64]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.87@PAGE
	add	x4, x4, l_.str.87@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_82:                               ;   in Loop: Header=BB27_70 Depth=2
	b	LBB27_83
LBB27_83:                               ;   in Loop: Header=BB27_70 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #72]
	ldr	x9, [x9, #32]
	add	x11, x9, #16
	ldr	w9, [sp, #80]
                                        ; kill: def $x9 killed $w9
	mov	x10, #2152                      ; =0x868
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #2060]
	subs	w8, w8, w9
	b.ne	LBB27_87
	b	LBB27_84
LBB27_84:                               ;   in Loop: Header=BB27_70 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #56
	b.eq	LBB27_87
	b	LBB27_85
LBB27_85:                               ;   in Loop: Header=BB27_70 Depth=2
	ldrb	w8, [sp, #63]
	subs	w8, w8, #61
	b.eq	LBB27_87
	b	LBB27_86
LBB27_86:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldr	w2, [sp, #80]
	ldr	x8, [sp, #64]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.88@PAGE
	add	x4, x4, l_.str.88@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_87:                               ;   in Loop: Header=BB27_70 Depth=2
	b	LBB27_88
LBB27_88:                               ;   in Loop: Header=BB27_70 Depth=2
	ldr	w8, [sp, #76]
	add	w8, w8, #1
	str	w8, [sp, #76]
	b	LBB27_70
LBB27_89:                               ;   in Loop: Header=BB27_68 Depth=1
	b	LBB27_90
LBB27_90:                               ;   in Loop: Header=BB27_68 Depth=1
	ldr	w8, [sp, #80]
	add	w8, w8, #1
	str	w8, [sp, #80]
	b	LBB27_68
LBB27_91:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB27_92
LBB27_92:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_function
_oq_function:                           ; @oq_function
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #33408                      ; =0x8280
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #640
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #616]
	str	w1, [sp, #612]
	ldr	x10, [sp, #616]
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
	add	x10, x10, #16
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #600]
	ldr	x8, [sp, #600]
	ldrb	w8, [x8, #2081]
	subs	w8, w8, #2
	b.ne	LBB28_2
	b	LBB28_1
LBB28_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_2:
	ldr	x8, [sp, #600]
	ldrb	w8, [x8, #2081]
	subs	w8, w8, #1
	b.ne	LBB28_4
	b	LBB28_3
LBB28_3:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #612]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #116]                  ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.89@PAGE
	add	x4, x4, l_.str.89@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_4:
	ldr	x9, [sp, #600]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2081]
	str	wzr, [sp, #596]
	b	LBB28_5
LBB28_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #596]
	ldr	x9, [sp, #616]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB28_11
	b	LBB28_6
LBB28_6:                                ;   in Loop: Header=BB28_5 Depth=1
	ldr	x8, [sp, #600]
	ldrb	w8, [x8, #2080]
	ldr	w10, [sp, #596]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB28_9
	b	LBB28_7
LBB28_7:                                ;   in Loop: Header=BB28_5 Depth=1
	ldr	x0, [sp, #616]
	ldr	w1, [sp, #596]
	bl	_oq_function
	tbnz	w0, #0, LBB28_9
	b	LBB28_8
LBB28_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_9:                                ;   in Loop: Header=BB28_5 Depth=1
	b	LBB28_10
LBB28_10:                               ;   in Loop: Header=BB28_5 Depth=1
	ldr	w8, [sp, #596]
	add	w8, w8, #1
	str	w8, [sp, #596]
	b	LBB28_5
LBB28_11:
	ldr	x8, [sp, #616]
	ldr	x8, [x8, #8]
	add	x10, x8, #792
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #584]
	ldr	w8, [sp, #612]
	subs	w8, w8, #0
	cset	w8, ne
	ldr	x9, [sp, #584]
	strb	w8, [x9, #9]
	add	x0, sp, #632
	mov	x1, #32768                      ; =0x8000
	bl	_bzero
	ldr	x8, [sp, #616]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #576]
	strh	wzr, [sp, #574]
	b	LBB28_12
LBB28_12:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #574]
	ldr	x9, [sp, #576]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB28_15
	b	LBB28_13
LBB28_13:                               ;   in Loop: Header=BB28_12 Depth=1
	ldrh	w8, [sp, #574]
	mov	x9, x8
	add	x8, sp, #632
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	add	x8, sp, #504
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_oq_tag
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldrh	w9, [sp, #574]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #6
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #57]
	b	LBB28_14
LBB28_14:                               ;   in Loop: Header=BB28_12 Depth=1
	ldrh	w8, [sp, #574]
	add	w8, w8, #1
	strh	w8, [sp, #574]
	b	LBB28_12
LBB28_15:
	strh	wzr, [sp, #502]
	b	LBB28_16
LBB28_16:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB28_24 Depth 2
	ldrh	w8, [sp, #502]
	ldr	x9, [sp, #576]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB28_29
	b	LBB28_17
LBB28_17:                               ;   in Loop: Header=BB28_16 Depth=1
	ldr	x8, [sp, #600]
	add	x8, x8, #8
	ldrh	w9, [sp, #502]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #488]
	ldrh	w8, [sp, #502]
	mov	x9, x8
	add	x8, sp, #632
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldrb	w0, [sp, #488]
	add	x8, sp, #424
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	bl	_oq_tag
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #80]                   ; 8-byte Folded Reload
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w8, [sp, #488]
	subs	w8, w8, #8
	b.eq	LBB28_19
	b	LBB28_18
LBB28_18:                               ;   in Loop: Header=BB28_16 Depth=1
	b	LBB28_28
LBB28_19:                               ;   in Loop: Header=BB28_16 Depth=1
	ldr	x8, [sp, #584]
	ldr	w8, [x8]
	ldr	x9, [sp, #600]
	add	x9, x9, #2064
	ldrh	w10, [sp, #502]
                                        ; kill: def $x10 killed $w10
	strh	w8, [x9, x10, lsl #1]
	ldr	x8, [sp, #616]
	mov	x9, #17260                      ; =0x436c
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	w9, [sp, #492]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #584]
	ldr	w10, [x9]
	mov	w9, #256                        ; =0x100
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB28_21
	b	LBB28_20
LBB28_20:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #612]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.90@PAGE
	add	x4, x4, l_.str.90@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_21:                               ;   in Loop: Header=BB28_16 Depth=1
	ldr	x0, [sp, #616]
	ldr	w1, [sp, #492]
	ldrh	w8, [sp, #502]
	mov	x9, x8
	add	x8, sp, #632
	add	x2, x8, x9, lsl #6
	bl	_oq_make_owner
	tbnz	w0, #0, LBB28_23
	b	LBB28_22
LBB28_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_23:                               ;   in Loop: Header=BB28_16 Depth=1
	str	wzr, [sp, #420]
	b	LBB28_24
LBB28_24:                               ;   Parent Loop BB28_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #420]
	ldr	x9, [sp, #616]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #492]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hs	LBB28_27
	b	LBB28_25
LBB28_25:                               ;   in Loop: Header=BB28_24 Depth=2
	ldr	x10, [sp, #584]
	ldr	w8, [x10]
	add	w9, w8, #1
	str	w9, [x10]
	str	w8, [sp, #416]
	add	x0, sp, #376
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #416]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	ldr	w9, [sp, #416]
	udiv	w9, w9, w10
	add	w9, w9, #1
	str	x8, [x1, w9, uxtw #3]
	ldr	x8, [sp, #616]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x10, [x8, x9]
	ldrh	w8, [sp, #502]
	mov	x9, x8
	add	x8, sp, #632
	add	x8, x8, x9, lsl #6
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #420]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x0, w8, w9, x10
	bl	_memcpy
	ldr	x8, [sp, #616]
	ldr	x8, [x8, #8]
	add	x10, x8, #1240
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #30720                      ; =0x7800
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	w8, [sp, #416]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldrh	w9, [sp, #502]
	add	x8, sp, #256
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	strh	w9, [sp, #256]
	strh	wzr, [sp, #258]
	add	x8, x8, #4
	ldr	x0, [sp, #616]
	ldr	w1, [sp, #492]
	ldr	w2, [sp, #420]
	bl	_oq_path
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x0, x8, #80
	bl	_memcpy
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	mov	x2, #120                        ; =0x78
	bl	_memcpy
	b	LBB28_26
LBB28_26:                               ;   in Loop: Header=BB28_24 Depth=2
	ldr	w8, [sp, #420]
	add	w8, w8, #1
	str	w8, [sp, #420]
	b	LBB28_24
LBB28_27:                               ;   in Loop: Header=BB28_16 Depth=1
	b	LBB28_28
LBB28_28:                               ;   in Loop: Header=BB28_16 Depth=1
	ldrh	w8, [sp, #502]
	add	w8, w8, #1
	strh	w8, [sp, #502]
	b	LBB28_16
LBB28_29:
	ldr	x0, [sp, #616]
	ldr	x8, [sp, #600]
	ldr	w1, [x8, #2056]
	add	x2, sp, #632
	mov	w3, #0                          ; =0x0
	bl	_oq_join
	tbnz	w0, #0, LBB28_31
	b	LBB28_30
LBB28_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_31:
	b	LBB28_32
LBB28_32:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #616]
	mov	x9, #35712                      ; =0x8b80
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	cbz	w8, LBB28_38
	b	LBB28_33
LBB28_33:                               ;   in Loop: Header=BB28_32 Depth=1
	ldr	x8, [sp, #616]
	mov	x9, #17252                      ; =0x4364
	movk	x9, #6, lsl #16
	add	x10, x8, x9
	ldr	w8, [x10]
	add	w9, w8, #1
	str	w9, [x10]
	subs	w8, w8, #64, lsl #12            ; =262144
	b.ne	LBB28_35
	b	LBB28_34
LBB28_34:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #612]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.91@PAGE
	add	x4, x4, l_.str.91@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_35:                               ;   in Loop: Header=BB28_32 Depth=1
	ldr	x8, [sp, #616]
	mov	x9, #19320                      ; =0x4b78
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	x9, [sp, #616]
	mov	x10, #35704                     ; =0x8b78
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #252]
	ldr	x8, [sp, #616]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #616]
	str	w8, [x9, x10]
	ldr	x8, [sp, #616]
	mov	x9, #35712                      ; =0x8b80
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp, #616]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #252]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	strb	wzr, [x8, #84]
	ldr	x0, [sp, #616]
	ldr	w1, [sp, #252]
	bl	_oq_step
	tbnz	w0, #0, LBB28_37
	b	LBB28_36
LBB28_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_37:                               ;   in Loop: Header=BB28_32 Depth=1
	b	LBB28_32
LBB28_38:
	ldr	x8, [sp, #600]
	ldr	w8, [x8, #2056]
	str	w8, [sp, #248]
	b	LBB28_39
LBB28_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #248]
	ldr	x9, [sp, #600]
	ldr	w9, [x9, #2060]
	subs	w8, w8, w9
	b.hs	LBB28_44
	b	LBB28_40
LBB28_40:                               ;   in Loop: Header=BB28_39 Depth=1
	ldr	x8, [sp, #616]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #248]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #88]
	cbnz	x8, LBB28_42
	b	LBB28_41
LBB28_41:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #612]
	ldr	x8, [sp, #616]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #248]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.92@PAGE
	add	x4, x4, l_.str.92@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_42:                               ;   in Loop: Header=BB28_39 Depth=1
	b	LBB28_43
LBB28_43:                               ;   in Loop: Header=BB28_39 Depth=1
	ldr	w8, [sp, #248]
	add	w8, w8, #1
	str	w8, [sp, #248]
	b	LBB28_39
LBB28_44:
	ldr	x8, [sp, #600]
	ldrb	w8, [x8, #2082]
	tbnz	w8, #0, LBB28_46
	b	LBB28_45
LBB28_45:
	ldr	x0, [sp, #616]
	ldr	w2, [sp, #612]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #32]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.93@PAGE
	add	x4, x4, l_.str.93@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_46:
	ldr	x8, [sp, #600]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.ne	LBB28_52
	b	LBB28_47
LBB28_47:
	ldr	x8, [sp, #616]
	mov	x9, #17260                      ; =0x436c
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldr	x9, [sp, #600]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #584]
	str	w8, [x9, #4]
	str	wzr, [sp, #244]
	b	LBB28_48
LBB28_48:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #244]
	ldr	x9, [sp, #584]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB28_51
	b	LBB28_49
LBB28_49:                               ;   in Loop: Header=BB28_48 Depth=1
	ldr	x8, [sp, #616]
	ldr	x8, [x8, #8]
	mov	x9, #50392                      ; =0xc4d8
	movk	x9, #3, lsl #16
	add	x10, x8, x9
	ldr	w8, [sp, #612]
                                        ; kill: def $x8 killed $w8
	mov	x9, #30720                      ; =0x7800
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	w8, [sp, #244]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x8, sp, #120
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	strh	wzr, [sp, #120]
	strh	wzr, [sp, #122]
	add	x8, x8, #4
	ldr	x0, [sp, #616]
	ldr	x9, [sp, #600]
	ldr	w1, [x9, #4]
	ldr	w2, [sp, #244]
	bl	_oq_path
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x0, x8, #80
	ldr	x8, [sp, #616]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x10, [x8, x9]
	ldr	x8, [sp, #600]
	ldr	w8, [x8, #2096]
	ldr	w9, [sp, #244]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #120                        ; =0x78
	bl	_memcpy
	b	LBB28_50
LBB28_50:                               ;   in Loop: Header=BB28_48 Depth=1
	ldr	w8, [sp, #244]
	add	w8, w8, #1
	str	w8, [sp, #244]
	b	LBB28_48
LBB28_51:
	b	LBB28_52
LBB28_52:
	ldr	x9, [sp, #600]
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #2081]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #631]
	b	LBB28_53
LBB28_53:
	ldrb	w8, [sp, #631]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB28_55
	b	LBB28_54
LBB28_54:
	bl	___stack_chk_fail
LBB28_55:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #640
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_reachable
_oq_reachable:                          ; @oq_reachable
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	add	x10, x10, #792
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #8]
	tbz	w8, #0, LBB29_2
	b	LBB29_1
LBB29_1:
	b	LBB29_8
LBB29_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	add	x10, x8, #792
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #8]
	str	wzr, [sp]
	b	LBB29_3
LBB29_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB29_8
	b	LBB29_4
LBB29_4:                                ;   in Loop: Header=BB29_3 Depth=1
	ldr	x8, [sp, #8]
	add	x10, x8, #16
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #2080]
	ldr	w10, [sp]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB29_6
	b	LBB29_5
LBB29_5:                                ;   in Loop: Header=BB29_3 Depth=1
	ldr	x0, [sp, #8]
	ldr	w1, [sp]
	bl	_oq_reachable
	b	LBB29_6
LBB29_6:                                ;   in Loop: Header=BB29_3 Depth=1
	b	LBB29_7
LBB29_7:                                ;   in Loop: Header=BB29_3 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB29_3
LBB29_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_stop
_oq_stop:                               ; @oq_stop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #56]
	str	w1, [sp, #52]
	str	w2, [sp, #48]
	str	w3, [sp, #44]
	str	x4, [sp, #32]
	ldr	x9, [sp, #56]
	ldr	w8, [sp, #52]
	str	w8, [sp, #8]
	ldr	w8, [sp, #48]
	str	w8, [sp, #12]
	ldr	w8, [sp, #44]
	str	w8, [sp, #16]
	mov	w8, #0                          ; =0x0
	str	wzr, [sp, #20]
	ldr	x10, [sp, #32]
	str	x10, [sp, #24]
	ldur	q0, [sp, #8]
	mov	x10, #35720                     ; =0x8b88
	movk	x10, #6, lsl #16
	add	x10, x9, x10
	str	q0, [x10]
	ldr	x9, [sp, #24]
	str	x9, [x10, #16]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_counts  ; -- Begin function nvm_owned_array_origin_counts
	.p2align	2
_nvm_owned_array_origin_counts:         ; @nvm_owned_array_origin_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB31_2
	b	LBB31_1
LBB31_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB31_3
	b	LBB31_2
LBB31_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB31_4
LBB31_3:
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	str	x10, [x9]
	ldr	w8, [x8, #16]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB31_4
LBB31_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_site    ; -- Begin function nvm_owned_array_origin_site
	.p2align	2
_nvm_owned_array_origin_site:           ; @nvm_owned_array_origin_site
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB32_3
	b	LBB32_1
LBB32_1:
	ldr	x8, [sp]
	cbz	x8, LBB32_3
	b	LBB32_2
LBB32_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB32_4
	b	LBB32_3
LBB32_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB32_5
LBB32_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	add	x11, x8, #20
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB32_5
LBB32_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_summary ; -- Begin function nvm_owned_array_origin_summary
	.p2align	2
_nvm_owned_array_origin_summary:        ; @nvm_owned_array_origin_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB33_3
	b	LBB33_1
LBB33_1:
	ldr	x8, [sp]
	cbz	x8, LBB33_3
	b	LBB33_2
LBB33_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB33_4
	b	LBB33_3
LBB33_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_5
LBB33_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #792
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB33_5
LBB33_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_input   ; -- Begin function nvm_owned_array_origin_input
	.p2align	2
_nvm_owned_array_origin_input:          ; @nvm_owned_array_origin_input
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB34_4
	b	LBB34_1
LBB34_1:
	ldr	x8, [sp]
	cbz	x8, LBB34_4
	b	LBB34_2
LBB34_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB34_4
	b	LBB34_3
LBB34_3:
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	add	x9, x9, #792
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, #56                        ; =0x38
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB34_5
	b	LBB34_4
LBB34_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB34_6
LBB34_5:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #1240
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #30720                      ; =0x7800
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #120                        ; =0x78
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB34_6
LBB34_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_result  ; -- Begin function nvm_owned_array_origin_result
	.p2align	2
_nvm_owned_array_origin_result:         ; @nvm_owned_array_origin_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB35_4
	b	LBB35_1
LBB35_1:
	ldr	x8, [sp]
	cbz	x8, LBB35_4
	b	LBB35_2
LBB35_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB35_4
	b	LBB35_3
LBB35_3:
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	add	x11, x9, #792
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #56                        ; =0x38
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB35_5
	b	LBB35_4
LBB35_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_6
LBB35_5:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	mov	x9, #50392                      ; =0xc4d8
	movk	x9, #3, lsl #16
	add	x10, x8, x9
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #30720                      ; =0x7800
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldr	w8, [sp, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #120                        ; =0x78
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB35_6
LBB35_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_origin_obligation ; -- Begin function nvm_owned_array_origin_obligation
	.p2align	2
_nvm_owned_array_origin_obligation:     ; @nvm_owned_array_origin_obligation
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB36_3
	b	LBB36_1
LBB36_1:
	ldr	x8, [sp]
	cbz	x8, LBB36_3
	b	LBB36_2
LBB36_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB36_4
	b	LBB36_3
LBB36_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_5
LBB36_4:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	mov	x10, #34008                     ; =0x84d8
	movk	x10, #7, lsl #16
	add	x11, x9, x10
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #28                        ; =0x1c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	q0, [x9]
	str	q0, [x8]
	ldur	q0, [x9, #12]
	stur	q0, [x8, #12]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB36_5
LBB36_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function name_valid
_name_valid:                            ; @name_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	w0, [sp, #28]
	str	x1, [sp, #16]
	ldr	w9, [sp, #28]
	mov	w8, #1                          ; =0x1
	adds	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB37_2
	b	LBB37_1
LBB37_1:
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB37_2
LBB37_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_forward_preflight
_record_forward_preflight:              ; @record_forward_preflight
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #64]
	str	w1, [sp, #60]
	str	x2, [sp, #48]
	str	x3, [sp, #40]
	add	x0, sp, #2120
	mov	x2, #256                        ; =0x100
	mov	w1, #0                          ; =0x0
	bl	_memset
	str	wzr, [sp, #36]
	b	LBB38_1
LBB38_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_5 Depth 2
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.hs	LBB38_23
	b	LBB38_2
LBB38_2:                                ;   in Loop: Header=BB38_1 Depth=1
	ldr	w8, [sp, #36]
	mov	x9, x8
	add	x8, sp, #2120
	add	x8, x8, x9
	ldrb	w8, [x8]
	cbz	w8, LBB38_4
	b	LBB38_3
LBB38_3:                                ;   in Loop: Header=BB38_1 Depth=1
	b	LBB38_22
LBB38_4:                                ;   in Loop: Header=BB38_1 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #32]
	ldr	w8, [sp, #36]
	str	w8, [sp, #72]
	str	wzr, [sp, #76]
	ldr	w8, [sp, #36]
	mov	x9, x8
	add	x8, sp, #2120
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB38_5
LBB38_5:                                ;   Parent Loop BB38_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #32]
	cbz	w8, LBB38_21
	b	LBB38_6
LBB38_6:                                ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #32]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #72
	ldr	w9, [x8, x9]
	str	w9, [sp, #28]
	ldr	w9, [sp, #32]
	subs	w9, w9, #1
	add	x8, x8, w9, uxtw #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #24]
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.ne	LBB38_8
	b	LBB38_7
LBB38_7:                                ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #28]
	mov	x9, x8
	add	x8, sp, #2120
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	ldr	w8, [sp, #32]
	subs	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB38_5
LBB38_8:                                ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hi	LBB38_10
	b	LBB38_9
LBB38_9:                                ;   in Loop: Header=BB38_5 Depth=2
	ldr	x0, [sp, #64]
	ldr	x8, [sp, #48]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	ldr	w2, [sp, #24]
	add	x3, sp, #20
	bl	_record_nested_at
	tbnz	w0, #0, LBB38_11
	b	LBB38_10
LBB38_10:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [sp, #28]
	ldr	w2, [sp, #24]
	mov	w0, #2                          ; =0x2
	adrp	x3, l_.str.47@PAGE
	add	x3, x3, l_.str.47@PAGEOFF
	bl	_record_result
	b	LBB38_24
LBB38_11:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #32]
	subs	w9, w8, #1
	add	x8, sp, #72
	add	x9, x8, w9, uxtw #3
	ldr	w8, [x9, #4]
	add	w8, w8, #1
	str	w8, [x9, #4]
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB38_13
	b	LBB38_12
LBB38_12:                               ;   in Loop: Header=BB38_5 Depth=2
	b	LBB38_5
LBB38_13:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #20]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.hs	LBB38_15
	b	LBB38_14
LBB38_14:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #20]
	mov	x9, x8
	add	x8, sp, #2120
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB38_16
	b	LBB38_15
LBB38_15:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [sp, #28]
	ldr	w2, [sp, #24]
	mov	w0, #2                          ; =0x2
	adrp	x3, l_.str.48@PAGE
	add	x3, x3, l_.str.48@PAGEOFF
	bl	_record_result
	b	LBB38_24
LBB38_16:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #20]
	mov	x9, x8
	add	x8, sp, #2120
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB38_18
	b	LBB38_17
LBB38_17:                               ;   in Loop: Header=BB38_5 Depth=2
	b	LBB38_5
LBB38_18:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #32]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.lo	LBB38_20
	b	LBB38_19
LBB38_19:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w1, [sp, #28]
	ldr	w2, [sp, #24]
	mov	w0, #2                          ; =0x2
	adrp	x3, l_.str.49@PAGE
	add	x3, x3, l_.str.49@PAGEOFF
	bl	_record_result
	b	LBB38_24
LBB38_20:                               ;   in Loop: Header=BB38_5 Depth=2
	ldr	w8, [sp, #20]
	mov	x9, x8
	add	x8, sp, #2120
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldr	w9, [sp, #20]
	ldr	w8, [sp, #32]
                                        ; kill: def $x8 killed $w8
	lsl	x10, x8, #3
	add	x8, sp, #72
	str	w9, [x8, x10]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	wzr, [x8, #4]
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB38_5
LBB38_21:                               ;   in Loop: Header=BB38_1 Depth=1
	b	LBB38_22
LBB38_22:                               ;   in Loop: Header=BB38_1 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB38_1
LBB38_23:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w2, #0                          ; =0x0
	mov	x0, x2
	mov	x1, x2
	adrp	x3, l_.str.50@PAGE
	add	x3, x3, l_.str.50@PAGEOFF
	bl	_record_result
	b	LBB38_24
LBB38_24:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB38_26
	b	LBB38_25
LBB38_25:
	bl	___stack_chk_fail
LBB38_26:
	add	sp, sp, #2384
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_nested_at
_record_nested_at:                      ; @record_nested_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.hi	LBB39_3
	b	LBB39_1
LBB39_1:
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	subs	x8, x8, #12
	b.lo	LBB39_3
	b	LBB39_2
LBB39_2:
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #32]
	ldur	x10, [x29, #-24]
	subs	x9, x9, x10
	subs	x9, x9, #12
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB39_4
	b	LBB39_3
LBB39_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_5
LBB39_4:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #312]
	ldr	x2, [sp, #32]
	add	x0, sp, #8
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldur	x10, [x29, #-24]
	ldur	w8, [x29, #-28]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #4
	str	x8, [sp, #24]
	ldr	x1, [sp, #40]
	bl	_nvm_v2_u32
	subs	w8, w0, #0
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB39_5
LBB39_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_signature
_oq_signature:                          ; @oq_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-12]
	str	x0, [sp, #8]
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB40_2
	b	LBB40_1
LBB40_1:
	ldr	x0, [sp, #8]
	ldur	w1, [x29, #-8]
	bl	_oq_owner_layout
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB40_10
LBB40_2:
	ldur	w9, [x29, #-8]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.ne	LBB40_9
	b	LBB40_3
LBB40_3:
	ldurb	w8, [x29, #-12]
	mov	w9, #1                          ; =0x1
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	w8, LBB40_8
	b	LBB40_4
LBB40_4:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB40_8
	b	LBB40_5
LBB40_5:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB40_8
	b	LBB40_6
LBB40_6:
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.eq	LBB40_8
	b	LBB40_7
LBB40_7:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB40_8
LBB40_8:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB40_9
LBB40_9:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB40_10
LBB40_10:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_owner_layout
_oq_owner_layout:                       ; @oq_owner_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	add	x2, sp, #4
	bl	_nvm_owned_array_layout_fact
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbz	w0, #0, LBB41_2
	b	LBB41_1
LBB41_1:
	ldrb	w8, [sp, #28]
	ands	w8, w8, #0x2
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB41_2
LBB41_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_supported
_oq_supported:                          ; @oq_supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-2]
	ldurb	w0, [x29, #-2]
	sub	x1, x29, #4
	bl	_oq_scalar
	tbnz	w0, #31, LBB42_2
	b	LBB42_1
LBB42_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_6
LBB42_2:
	ldurb	w8, [x29, #-2]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB42_5
; %bb.3:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI42_0@PAGE
	add	x10, x10, lJTI42_0@PAGEOFF
Ltmp13:
	adr	x8, Ltmp13
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB42_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_6
LBB42_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB42_6
LBB42_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI42_0:
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_5-Ltmp13
	.long	LBB42_4-Ltmp13
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_scalar
_oq_scalar:                             ; @oq_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #27]
	str	x1, [sp, #16]
	ldr	x8, [sp, #16]
	strh	wzr, [x8]
	ldrb	w8, [sp, #27]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	subs	x8, x8, #225
	b.hi	LBB43_13
; %bb.1:
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	adrp	x10, lJTI43_0@PAGE
	add	x10, x10, lJTI43_0@PAGEOFF
Ltmp15:
	adr	x8, Ltmp15
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB43_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_3:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_4:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_5:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_6:
	str	wzr, [sp, #28]
	b	LBB43_14
LBB43_7:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_8:
	ldr	x9, [sp, #16]
	mov	w8, #8                          ; =0x8
	strh	w8, [x9]
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_9:
	ldr	x9, [sp, #16]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_10:
	ldr	x9, [sp, #16]
	mov	w8, #8                          ; =0x8
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_11:
	ldr	x9, [sp, #16]
	mov	w8, #16                         ; =0x10
	strh	w8, [x9]
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_12:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_13:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]
	b	LBB43_14
LBB43_14:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI43_0:
	.long	LBB43_2-Ltmp15
	.long	LBB43_3-Ltmp15
	.long	LBB43_5-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_6-Ltmp15
	.long	LBB43_4-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_12-Ltmp15
	.long	LBB43_12-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_7-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_8-Ltmp15
	.long	LBB43_8-Ltmp15
	.long	LBB43_8-Ltmp15
	.long	LBB43_8-Ltmp15
	.long	LBB43_8-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_9-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_10-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_13-Ltmp15
	.long	LBB43_11-Ltmp15
	.long	LBB43_11-Ltmp15
	.long	LBB43_11-Ltmp15
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_tag
_oq_tag:                                ; @oq_tag
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	sturb	w8, [x29, #-1]
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldurb	w10, [x29, #-1]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w10
	strh	w8, [x9]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_make_owner
_oq_make_owner:                         ; @oq_make_owner
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	add	x8, sp, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #8                          ; =0x8
	bl	_oq_tag
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #72]
	ldur	w9, [x29, #-20]
	str	w9, [sp, #20]
	ldur	x0, [x29, #-16]
	ldur	x9, [x29, #-16]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	mov	x11, #17260                     ; =0x436c
	movk	x11, #6, lsl #16
	add	x9, x9, x11
	ldr	w1, [x9, x10, lsl #2]
	add	x2, x8, #8
	bl	_oq_vector
	tbnz	w0, #0, LBB45_2
	b	LBB45_1
LBB45_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_3
LBB45_2:
	ldur	x0, [x29, #-32]
	add	x1, sp, #16
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB45_3
LBB45_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_path
_oq_path:                               ; @oq_path
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-8]
	stur	w1, [x29, #-12]
	str	w2, [sp, #16]
	mov	x2, #76                         ; =0x4c
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	x8, [x29, #-8]
	mov	x9, #19312                      ; =0x4b70
	movk	x9, #6, lsl #16
	ldr	x8, [x8, x9]
	ldur	x9, [x29, #-8]
	ldur	w10, [x29, #-12]
                                        ; kill: def $x10 killed $w10
	mov	x11, #18284                     ; =0x476c
	movk	x11, #6, lsl #16
	add	x9, x9, x11
	ldr	w9, [x9, x10, lsl #2]
	ldr	w10, [sp, #16]
	add	w9, w9, w10
	ldr	w1, [x8, w9, uxtw #2]
	bl	_nvm_owned_array_leaf_path
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_join
_oq_join:                               ; @oq_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	sturh	w3, [x29, #-34]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	mov	x10, #17248                     ; =0x4360
	movk	x10, #6, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB47_2
	b	LBB47_1
LBB47_1:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.96@PAGE
	add	x4, x4, l_.str.96@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_2:
	ldur	x8, [x29, #-16]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-52]
	ldurh	w8, [x29, #-34]
	subs	w8, w8, #256
	b.ls	LBB47_4
	b	LBB47_3
LBB47_3:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-48]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.97@PAGE
	add	x4, x4, l_.str.97@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_4:
	ldur	x8, [x29, #-48]
	ldrsh	w8, [x8, #82]
	tbnz	w8, #31, LBB47_7
	b	LBB47_5
LBB47_5:
	ldur	x8, [x29, #-48]
	ldrsh	w8, [x8, #82]
	ldurh	w9, [x29, #-34]
	subs	w8, w8, w9
	b.eq	LBB47_7
	b	LBB47_6
LBB47_6:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-48]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.98@PAGE
	add	x4, x4, l_.str.98@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_7:
	sturb	wzr, [x29, #-53]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #88]
	cbnz	x8, LBB47_13
	b	LBB47_8
LBB47_8:
	ldur	w8, [x29, #-52]
	add	w8, w8, #256
	stur	w8, [x29, #-60]
	ldur	w8, [x29, #-60]
	ldur	x9, [x29, #-16]
	mov	x10, #17244                     ; =0x435c
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #1048576                    ; =0x100000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB47_10
	b	LBB47_9
LBB47_9:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-48]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.99@PAGE
	add	x4, x4, l_.str.99@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_10:
	ldur	w8, [x29, #-60]
	mov	x0, x8
	mov	x1, #64                         ; =0x40
	bl	_calloc
	ldur	x8, [x29, #-48]
	str	x0, [x8, #88]
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #88]
	cbnz	x8, LBB47_12
	b	LBB47_11
LBB47_11:
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-48]
	ldr	w2, [x8, #64]
	ldur	x8, [x29, #-48]
	ldr	w3, [x8, #68]
	mov	w1, #4                          ; =0x4
	adrp	x4, l_.str.100@PAGE
	add	x4, x4, l_.str.100@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_12:
	ldur	w10, [x29, #-60]
	ldur	x8, [x29, #-16]
	mov	x9, #17244                      ; =0x435c
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	ldurh	w8, [x29, #-34]
	ldur	x9, [x29, #-48]
	strh	w8, [x9, #82]
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #88]
	ldur	x1, [x29, #-32]
	ldur	w8, [x29, #-52]
	ldurh	w9, [x29, #-34]
	add	w8, w8, w9
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #6
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-53]
	b	LBB47_20
LBB47_13:
	stur	wzr, [x29, #-64]
	b	LBB47_14
LBB47_14:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-64]
	ldur	w9, [x29, #-52]
	ldurh	w10, [x29, #-34]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB47_19
	b	LBB47_15
LBB47_15:                               ;   in Loop: Header=BB47_14 Depth=1
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #88]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-32]
	ldur	w9, [x29, #-64]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #64]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #68]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	add	x0, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w4, [sp, #24]                   ; 4-byte Folded Reload
	ldr	w5, [sp, #28]                   ; 4-byte Folded Reload
	sub	x3, x29, #53
	bl	_oq_merge_value
	tbnz	w0, #0, LBB47_17
	b	LBB47_16
LBB47_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_17:                               ;   in Loop: Header=BB47_14 Depth=1
	b	LBB47_18
LBB47_18:                               ;   in Loop: Header=BB47_14 Depth=1
	ldur	w8, [x29, #-64]
	add	w8, w8, #1
	stur	w8, [x29, #-64]
	b	LBB47_14
LBB47_19:
	b	LBB47_20
LBB47_20:
	ldurb	w8, [x29, #-53]
	tbz	w8, #0, LBB47_22
	b	LBB47_21
LBB47_21:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_oq_enqueue
	b	LBB47_22
LBB47_22:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_23
LBB47_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_step
_oq_step:                               ; @oq_step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #36224                      ; =0x8d80
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #3456
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #3432]
	str	w1, [sp, #3428]
	ldr	x10, [sp, #3432]
	ldr	w8, [sp, #3428]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
	mov	x11, #17232                     ; =0x4350
	add	x10, x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #3416]
	ldr	x8, [sp, #3416]
	ldr	w8, [x8, #64]
	str	w8, [sp, #3412]
	ldr	x10, [sp, #3432]
	ldr	w8, [sp, #3412]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
	add	x10, x10, #16
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #3400]
	ldr	x8, [sp, #3432]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #3412]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #3392]
	ldr	x8, [sp, #3416]
	ldr	x1, [x8, #88]
	ldr	x8, [sp, #3392]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #3416]
	ldrh	w9, [x9, #82]
	add	w9, w8, w9
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	lsl	x2, x8, #6
	add	x0, sp, #3448
	str	x0, [sp, #856]                  ; 8-byte Folded Spill
	mov	x3, #32768                      ; =0x8000
	bl	___memcpy_chk
	ldr	x8, [sp, #856]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #3392]
	ldrh	w10, [x9, #16]
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #3384]
	ldr	x8, [sp, #3416]
	ldrh	w8, [x8, #82]
	strh	w8, [sp, #3382]
	ldr	x8, [sp, #3416]
	str	x8, [sp, #3368]
	ldr	x8, [sp, #3368]
	ldrb	w8, [x8]
	strb	w8, [sp, #3367]
	ldrb	w0, [sp, #3367]
	bl	_isa_get_info
	str	x0, [sp, #3352]
	ldr	x8, [sp, #3352]
	cbnz	x8, LBB48_2
	b	LBB48_1
LBB48_1:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.102@PAGE
	add	x4, x4, l_.str.102@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_2:
	ldr	x8, [sp, #3352]
	ldrsb	w8, [x8, #28]
	str	w8, [sp, #3348]
	ldr	x8, [sp, #3352]
	ldrsb	w8, [x8, #29]
	str	w8, [sp, #3344]
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #88
	b.ne	LBB48_4
	b	LBB48_3
LBB48_3:
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #3348]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #3344]
	b	LBB48_4
LBB48_4:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #13
	b.eq	LBB48_6
	b	LBB48_5
LBB48_5:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #14
	b.ne	LBB48_13
	b	LBB48_6
LBB48_6:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #13
	b.ne	LBB48_8
	b	LBB48_7
LBB48_7:
	ldr	x8, [sp, #3368]
	ldr	w8, [x8, #8]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	b	LBB48_9
LBB48_8:
	ldr	x8, [sp, #3400]
	add	x8, x8, #8
	ldr	x9, [sp, #3368]
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	b	LBB48_9
LBB48_9:
	ldr	w8, [sp, #852]                  ; 4-byte Folded Reload
	str	w8, [sp, #3340]
	movi.2d	v0, #0000000000000000
	add	x2, sp, #3296
	str	q0, [sp, #3296]
	str	q0, [sp, #3312]
	ldr	x8, [sp, #3432]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldr	w1, [sp, #3340]
	bl	_nvm_owned_array_layout_fact
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #13
	b.ne	LBB48_11
	b	LBB48_10
LBB48_10:
	ldr	w8, [sp, #3308]
	str	w8, [sp, #3348]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #3344]
	b	LBB48_12
LBB48_11:
	str	wzr, [sp, #3348]
	ldr	w8, [sp, #3308]
	str	w8, [sp, #3344]
	b	LBB48_12
LBB48_12:
	b	LBB48_13
LBB48_13:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #59
	b.ne	LBB48_15
	b	LBB48_14
LBB48_14:
	ldr	x8, [sp, #3432]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #3368]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #3288]
	ldr	x8, [sp, #3288]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #3348]
	ldr	x8, [sp, #3288]
	ldrb	w8, [x8, #21]
	str	w8, [sp, #3344]
	b	LBB48_15
LBB48_15:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #61
	b.ne	LBB48_34
	b	LBB48_16
LBB48_16:
	ldrh	w8, [sp, #3382]
	ldr	x9, [sp, #3392]
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.eq	LBB48_18
	b	LBB48_17
LBB48_17:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.103@PAGE
	add	x4, x4, l_.str.103@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_18:
	ldrh	w8, [sp, #3382]
	cbz	w8, LBB48_21
	b	LBB48_19
LBB48_19:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	x1, [sp, #3384]
	ldr	x8, [sp, #3400]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	add	x0, sp, #3224
	str	x0, [sp, #840]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #824]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #840]                  ; 8-byte Folded Reload
	ldr	x2, [x8]
	bl	_oq_type
	tbnz	w0, #0, LBB48_21
	b	LBB48_20
LBB48_20:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #820]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.104@PAGE
	add	x4, x4, l_.str.104@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #820]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_21:
	ldrh	w8, [sp, #3382]
	cbz	w8, LBB48_24
	b	LBB48_22
LBB48_22:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #804]                  ; 4-byte Folded Spill
	ldr	x1, [sp, #3384]
	add	x0, sp, #3160
	str	x0, [sp, #808]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #792]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #804]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #808]                  ; 8-byte Folded Reload
	bl	_oq_require
	tbnz	w0, #0, LBB48_24
	b	LBB48_23
LBB48_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_24:
	ldr	x8, [sp, #3400]
	ldrb	w8, [x8, #2082]
	tbnz	w8, #0, LBB48_28
	b	LBB48_25
LBB48_25:
	ldr	x9, [sp, #3400]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2082]
	ldrh	w8, [sp, #3382]
	cbz	w8, LBB48_27
	b	LBB48_26
LBB48_26:
	ldr	x8, [sp, #3400]
	add	x0, x8, #2088
	ldr	x1, [sp, #3384]
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_27
LBB48_27:
	b	LBB48_33
LBB48_28:
	ldrh	w8, [sp, #3382]
	cbz	w8, LBB48_32
	b	LBB48_29
LBB48_29:
	add	x8, sp, #3159
	str	x8, [sp, #776]                  ; 8-byte Folded Spill
	strb	wzr, [sp, #3159]
	ldr	x8, [sp, #3432]
	str	x8, [sp, #752]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	add	x8, x8, #2088
	str	x8, [sp, #760]                  ; 8-byte Folded Spill
	ldr	x1, [sp, #3384]
	ldr	w8, [sp, #3412]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3416]
	ldr	w8, [x8, #68]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	add	x0, sp, #3088
	str	x0, [sp, #768]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #752]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #760]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #768]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #776]                  ; 8-byte Folded Reload
	ldr	w4, [sp, #784]                  ; 4-byte Folded Reload
	ldr	w5, [sp, #788]                  ; 4-byte Folded Reload
	bl	_oq_merge_value
	tbnz	w0, #0, LBB48_31
	b	LBB48_30
LBB48_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_31:
	b	LBB48_32
LBB48_32:
	b	LBB48_33
LBB48_33:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_34:
	ldr	w8, [sp, #3348]
	tbnz	w8, #31, LBB48_37
	b	LBB48_35
LBB48_35:
	ldr	w8, [sp, #3344]
	tbnz	w8, #31, LBB48_37
	b	LBB48_36
LBB48_36:
	ldrh	w8, [sp, #3382]
	ldr	w9, [sp, #3348]
	subs	w8, w8, w9
	b.ge	LBB48_38
	b	LBB48_37
LBB48_37:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.105@PAGE
	add	x4, x4, l_.str.105@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_38:
	ldrh	w8, [sp, #3382]
	ldr	w9, [sp, #3348]
	subs	w8, w8, w9
	ldr	w9, [sp, #3344]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.ls	LBB48_40
	b	LBB48_39
LBB48_39:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #3                          ; =0x3
	adrp	x4, l_.str.106@PAGE
	add	x4, x4, l_.str.106@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_40:
	ldrh	w8, [sp, #3382]
	ldr	w9, [sp, #3348]
	subs	w8, w8, w9
	strh	w8, [sp, #3086]
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #3432]
	ldr	x8, [x8, #8]
	mov	x9, #34008                      ; =0x84d8
	movk	x9, #7, lsl #16
	add	x10, x8, x9
	ldr	w8, [sp, #3428]
                                        ; kill: def $x8 killed $w8
	mov	x9, #28                         ; =0x1c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #3000]
	ldrb	w0, [sp, #3367]
	add	x1, sp, #3014
	bl	_oq_scalar
	str	w0, [sp, #2996]
	ldr	w8, [sp, #2996]
	tbnz	w8, #31, LBB48_61
	b	LBB48_41
LBB48_41:
	ldr	w9, [sp, #2996]
	add	x8, sp, #2928
	str	x8, [sp, #744]                  ; 8-byte Folded Spill
	and	w0, w9, #0xff
	bl	_oq_tag
	ldr	x1, [sp, #744]                  ; 8-byte Folded Reload
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	w8, [sp, #3348]
	subs	w8, w8, #2
	b.le	LBB48_43
	b	LBB48_42
LBB48_42:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.107@PAGE
	add	x4, x4, l_.str.107@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_43:
	ldr	w8, [sp, #3348]
	ldr	x9, [sp, #3000]
	strb	w8, [x9, #23]
	ldrh	w8, [sp, #3086]
	strh	w8, [sp, #2926]
	b	LBB48_44
LBB48_44:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #2926]
	ldrh	w9, [sp, #3382]
	subs	w8, w8, w9
	b.ge	LBB48_60
	b	LBB48_45
LBB48_45:                               ;   in Loop: Header=BB48_44 Depth=1
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #2926]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #2856
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w8, [sp, #2912]
	cbnz	w8, LBB48_50
	b	LBB48_46
LBB48_46:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrb	w8, [sp, #2913]
	cbnz	w8, LBB48_50
	b	LBB48_47
LBB48_47:                               ;   in Loop: Header=BB48_44 Depth=1
	add	x8, sp, #2856
	add	x1, x8, #16
	add	x0, sp, #2816
	str	x0, [sp, #736]                  ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #736]                  ; 8-byte Folded Reload
	bl	_oq_nonempty
	tbnz	w0, #0, LBB48_50
	b	LBB48_48
LBB48_48:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2856]
	cbz	w8, LBB48_50
	b	LBB48_49
LBB48_49:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2856]
	and	w8, w8, #0xffffffe0
	cbz	w8, LBB48_51
	b	LBB48_50
LBB48_50:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #732]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.108@PAGE
	add	x4, x4, l_.str.108@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #732]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_51:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2926]
	ldrh	w9, [sp, #3086]
	subs	w8, w8, w9
	strh	w8, [sp, #2814]
	ldrh	w10, [sp, #2856]
	ldr	x9, [sp, #3000]
	ldrh	w8, [x9, #8]
	orr	w8, w8, w10
	strh	w8, [x9, #8]
	ldrh	w10, [sp, #3014]
	ldr	x9, [sp, #3000]
	ldrh	w8, [x9, #10]
	orr	w8, w8, w10
	strh	w8, [x9, #10]
	ldrh	w11, [sp, #2856]
	ldr	x8, [sp, #3000]
	add	x9, x8, #14
	ldrh	w8, [sp, #2814]
	mov	x10, x8
	ldrh	w8, [x9, x10, lsl #1]
	orr	w8, w8, w11
	strh	w8, [x9, x10, lsl #1]
	ldrh	w8, [sp, #3014]
	ldr	x9, [sp, #3000]
	add	x9, x9, #18
	ldrh	w10, [sp, #2814]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	ldrh	w8, [sp, #3014]
	cbz	w8, LBB48_58
	b	LBB48_52
LBB48_52:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2856]
	ldrh	w9, [sp, #3014]
	subs	w8, w8, w9
	b.eq	LBB48_58
	b	LBB48_53
LBB48_53:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrb	w0, [sp, #3367]
	bl	_oq_optional_comparison
	tbz	w0, #0, LBB48_56
	b	LBB48_54
LBB48_54:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2856]
	tbz	w8, #3, LBB48_56
	b	LBB48_55
LBB48_55:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2856]
	mov	w9, #-10                        ; =0xfffffff6
	and	w8, w8, w9
	cbz	w8, LBB48_57
	b	LBB48_56
LBB48_56:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #728]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.109@PAGE
	add	x4, x4, l_.str.109@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #728]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_57:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w9, [sp, #2814]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	and	w10, w8, #0xff
	ldr	x9, [sp, #3000]
	ldrb	w8, [x9, #24]
	orr	w8, w8, w10
	strb	w8, [x9, #24]
	b	LBB48_58
LBB48_58:                               ;   in Loop: Header=BB48_44 Depth=1
	b	LBB48_59
LBB48_59:                               ;   in Loop: Header=BB48_44 Depth=1
	ldrh	w8, [sp, #2926]
	add	w8, w8, #1
	strh	w8, [sp, #2926]
	b	LBB48_44
LBB48_60:
	b	LBB48_197
LBB48_61:
	ldrb	w8, [sp, #3367]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #720]                  ; 8-byte Folded Spill
	subs	x8, x8, #252
	b.hi	LBB48_195
; %bb.62:
	ldr	x11, [sp, #720]                 ; 8-byte Folded Reload
	adrp	x10, lJTI48_0@PAGE
	add	x10, x10, lJTI48_0@PAGEOFF
Ltmp16:
	adr	x8, Ltmp16
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB48_63:
	b	LBB48_196
LBB48_64:
	add	x8, sp, #2744
	str	x8, [sp, #712]                  ; 8-byte Folded Spill
	mov	w0, #5                          ; =0x5
	bl	_oq_tag
	ldr	x1, [sp, #712]                  ; 8-byte Folded Reload
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_196
LBB48_65:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	cbz	w8, LBB48_67
	b	LBB48_66
LBB48_66:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #708]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.110@PAGE
	add	x4, x4, l_.str.110@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #708]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_67:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #6
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrh	w8, [sp, #3382]
	add	w8, w8, #1
	strh	w8, [sp, #3382]
	b	LBB48_200
LBB48_68:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #3016
	str	x0, [sp, #688]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #696]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x2, [sp, #696]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x0, x8, x9, lsl #6
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #2
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	bl	_memcpy
	ldr	x1, [sp, #688]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #696]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #2
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x0, x8, x9, lsl #6
	bl	_memcpy
	b	LBB48_200
LBB48_69:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #3016
	str	x0, [sp, #672]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #680]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x2, [sp, #680]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x0, x8, x9, lsl #6
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #2
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	bl	_memcpy
	ldr	x2, [sp, #680]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #2
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x0, x8, x9, lsl #6
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #3
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	bl	_memcpy
	ldr	x1, [sp, #672]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #680]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #3
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x0, x8, x9, lsl #6
	bl	_memcpy
	b	LBB48_200
LBB48_70:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	cbz	w8, LBB48_72
	b	LBB48_71
LBB48_71:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #668]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.111@PAGE
	add	x4, x4, l_.str.111@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #668]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_72:
	b	LBB48_196
LBB48_73:
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #2742]
	ldrh	w8, [sp, #2742]
	mov	x9, x8
	add	x8, sp, #3448
	add	x1, x8, x9, lsl #6
	add	x0, sp, #3016
	str	x0, [sp, #616]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #624]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #616]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #624]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3432]
	str	x8, [sp, #632]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	add	x8, x8, #8
	str	x8, [sp, #648]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #2742]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #640]                  ; 8-byte Folded Spill
	add	x0, sp, #2672
	str	x0, [sp, #656]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #632]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #640]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #648]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #656]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_oq_type
	tbnz	w0, #0, LBB48_75
	b	LBB48_74
LBB48_74:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #612]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.112@PAGE
	add	x4, x4, l_.str.112@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #612]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_75:
	ldrb	w8, [sp, #3072]
	cbz	w8, LBB48_77
	b	LBB48_76
LBB48_76:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #3072]
	ldrh	w8, [sp, #2742]
	strh	w8, [sp, #3018]
	b	LBB48_77
LBB48_77:
	b	LBB48_196
LBB48_78:
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #2670]
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w8, [sp, #3072]
	cbnz	w8, LBB48_81
	b	LBB48_79
LBB48_79:
	ldrh	w8, [sp, #2670]
	mov	x9, x8
	add	x8, sp, #3448
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	cbnz	w8, LBB48_81
	b	LBB48_80
LBB48_80:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #576]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	add	x8, x8, #8
	str	x8, [sp, #592]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #2670]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #584]                  ; 8-byte Folded Spill
	add	x0, sp, #2600
	str	x0, [sp, #600]                  ; 8-byte Folded Spill
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #576]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #584]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #600]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_oq_type
	tbnz	w0, #0, LBB48_82
	b	LBB48_81
LBB48_81:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #572]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.113@PAGE
	add	x4, x4, l_.str.113@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #572]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_82:
	ldrh	w8, [sp, #2670]
	mov	x9, x8
	add	x8, sp, #3448
	add	x0, x8, x9, lsl #6
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_196
LBB48_83:
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #2598]
	ldrh	w8, [sp, #2598]
	mov	x9, x8
	add	x8, sp, #3448
	add	x1, x8, x9, lsl #6
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	strh	wzr, [sp, #2596]
	b	LBB48_84
LBB48_84:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #2596]
	ldrh	w9, [sp, #3382]
	subs	w8, w8, w9
	b.ge	LBB48_90
	b	LBB48_85
LBB48_85:                               ;   in Loop: Header=BB48_84 Depth=1
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #2596]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	subs	w8, w8, #2
	b.ne	LBB48_88
	b	LBB48_86
LBB48_86:                               ;   in Loop: Header=BB48_84 Depth=1
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #2596]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #6
	ldrh	w8, [x8, #2]
	ldrh	w9, [sp, #2598]
	subs	w8, w8, w9
	b.ne	LBB48_88
	b	LBB48_87
LBB48_87:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #568]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.114@PAGE
	add	x4, x4, l_.str.114@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #568]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_88:                               ;   in Loop: Header=BB48_84 Depth=1
	b	LBB48_89
LBB48_89:                               ;   in Loop: Header=BB48_84 Depth=1
	ldrh	w8, [sp, #2596]
	add	w8, w8, #1
	strh	w8, [sp, #2596]
	b	LBB48_84
LBB48_90:
	ldrb	w8, [sp, #3072]
	subs	w8, w8, #1
	b.ne	LBB48_92
	b	LBB48_91
LBB48_91:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #536]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	add	x8, x8, #8
	str	x8, [sp, #552]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #2598]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #544]                  ; 8-byte Folded Spill
	add	x0, sp, #2528
	str	x0, [sp, #560]                  ; 8-byte Folded Spill
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #544]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #560]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_oq_type
	tbnz	w0, #0, LBB48_93
	b	LBB48_92
LBB48_92:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #532]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.115@PAGE
	add	x4, x4, l_.str.115@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #532]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_93:
	ldrh	w8, [sp, #2598]
	mov	x9, x8
	add	x8, sp, #3448
	str	x8, [sp, #520]                  ; 8-byte Folded Spill
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #504]                  ; 8-byte Folded Spill
	add	x8, sp, #2464
	str	x8, [sp, #512]                  ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_oq_tag
	ldr	x0, [sp, #504]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #512]                  ; 8-byte Folded Reload
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x8, [sp, #520]                  ; 8-byte Folded Reload
	ldrh	w9, [sp, #2598]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #6
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #57]
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #14
	b.ne	LBB48_101
	b	LBB48_94
LBB48_94:
	str	wzr, [sp, #2460]
	b	LBB48_95
LBB48_95:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #2460]
	ldr	w9, [sp, #3344]
	subs	w8, w8, w9
	b.ge	LBB48_100
	b	LBB48_96
LBB48_96:                               ;   in Loop: Header=BB48_95 Depth=1
	ldr	x8, [sp, #3432]
	str	x8, [sp, #472]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2460]
	str	w8, [sp, #492]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	strh	w10, [sp, #3382]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #496]                  ; 8-byte Folded Spill
	add	x0, sp, #2392
	str	x0, [sp, #480]                  ; 8-byte Folded Spill
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #472]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #480]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #492]                  ; 4-byte Folded Reload
	ldr	x3, [sp, #496]                  ; 8-byte Folded Reload
	and	w2, w8, #0xffff
	bl	_oq_child
	tbnz	w0, #0, LBB48_98
	b	LBB48_97
LBB48_97:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_98:                               ;   in Loop: Header=BB48_95 Depth=1
	b	LBB48_99
LBB48_99:                               ;   in Loop: Header=BB48_95 Depth=1
	ldr	w8, [sp, #2460]
	add	w8, w8, #1
	str	w8, [sp, #2460]
	b	LBB48_95
LBB48_100:
	b	LBB48_200
LBB48_101:
	b	LBB48_196
LBB48_102:
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #2390]
	ldrh	w8, [sp, #2390]
	mov	x9, x8
	add	x8, sp, #3448
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	cbnz	w8, LBB48_106
	b	LBB48_103
LBB48_103:
	ldrh	w8, [sp, #2390]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #6
	add	x8, sp, #3448
	ldrh	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB48_106
	b	LBB48_104
LBB48_104:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	subs	w8, w8, #1
	b.ne	LBB48_106
	b	LBB48_105
LBB48_105:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #440]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	ldr	x8, [sp, #3400]
	add	x8, x8, #8
	str	x8, [sp, #456]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #2390]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	add	x0, sp, #2320
	str	x0, [sp, #464]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #440]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #448]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #456]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #464]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_oq_type
	tbnz	w0, #0, LBB48_107
	b	LBB48_106
LBB48_106:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #436]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.116@PAGE
	add	x4, x4, l_.str.116@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #436]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_107:
	ldrh	w8, [sp, #2390]
	mov	x9, x8
	add	x8, sp, #3448
	add	x0, x8, x9, lsl #6
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_196
LBB48_108:
	ldr	x8, [sp, #3368]
	ldr	w8, [x8, #8]
	str	w8, [sp, #2316]
	ldr	x0, [sp, #3432]
	ldr	w1, [sp, #2316]
	add	x2, sp, #3016
	bl	_oq_make_owner
	tbnz	w0, #0, LBB48_110
	b	LBB48_109
LBB48_109:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_110:
	str	wzr, [sp, #2312]
	strh	wzr, [sp, #2310]
	b	LBB48_111
LBB48_111:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB48_120 Depth 2
	ldrh	w8, [sp, #2310]
	ldr	w9, [sp, #3348]
	subs	w8, w8, w9, uxth
	b.ge	LBB48_127
	b	LBB48_112
LBB48_112:                              ;   in Loop: Header=BB48_111 Depth=1
	add	x3, sp, #2296
	str	xzr, [sp, #2296]
	str	wzr, [sp, #2304]
	ldr	x8, [sp, #3432]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldr	w1, [sp, #2316]
	ldrh	w2, [sp, #2310]
	bl	_nvm_owned_array_layout_field
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
	ldrh	w10, [sp, #2310]
	add	w10, w9, w10
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #2232
	str	x0, [sp, #400]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #408]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #400]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #408]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #3432]
	str	x8, [sp, #416]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2296]
	add	x8, sp, #2224
	strb	w9, [sp, #2224]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #2227]
	ldr	w8, [sp, #2300]
	str	w8, [sp, #2228]
	add	x0, sp, #2160
	str	x0, [sp, #424]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #416]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #424]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #2224]
	bl	_oq_type
	tbnz	w0, #0, LBB48_114
	b	LBB48_113
LBB48_113:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #396]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.117@PAGE
	add	x4, x4, l_.str.117@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #396]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_114:                              ;   in Loop: Header=BB48_111 Depth=1
	ldr	x8, [sp, #3432]
	str	x8, [sp, #368]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	add	x0, sp, #2096
	str	x0, [sp, #384]                  ; 8-byte Folded Spill
	add	x1, sp, #2232
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #368]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #380]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #384]                  ; 8-byte Folded Reload
	bl	_oq_require
	tbnz	w0, #0, LBB48_116
	b	LBB48_115
LBB48_115:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_116:                              ;   in Loop: Header=BB48_111 Depth=1
	ldrb	w8, [sp, #2296]
	subs	w8, w8, #7
	b.ne	LBB48_118
	b	LBB48_117
LBB48_117:                              ;   in Loop: Header=BB48_111 Depth=1
	ldr	x8, [sp, #3432]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x10, [x8, x9]
	ldr	w8, [sp, #3024]
	ldr	w9, [sp, #2312]
	add	w11, w9, #1
	str	w11, [sp, #2312]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x0, w8, w9, x10
	add	x8, sp, #2232
	add	x1, x8, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB48_125
LBB48_118:                              ;   in Loop: Header=BB48_111 Depth=1
	ldrb	w8, [sp, #2296]
	subs	w8, w8, #8
	b.ne	LBB48_124
	b	LBB48_119
LBB48_119:                              ;   in Loop: Header=BB48_111 Depth=1
	str	wzr, [sp, #2092]
	b	LBB48_120
LBB48_120:                              ;   Parent Loop BB48_111 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #2092]
	ldr	x9, [sp, #3432]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #2236]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hs	LBB48_123
	b	LBB48_121
LBB48_121:                              ;   in Loop: Header=BB48_120 Depth=2
	ldr	x8, [sp, #3432]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x11, [x8, x9]
	ldr	w8, [sp, #3024]
	ldr	w10, [sp, #2312]
	add	w12, w10, #1
	str	w12, [sp, #2312]
	add	w8, w8, w10
	mov	w10, #40                        ; =0x28
	umaddl	x0, w8, w10, x11
	ldr	x8, [sp, #3432]
	ldr	x10, [x8, x9]
	ldr	w8, [sp, #2240]
	ldr	w9, [sp, #2092]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB48_122
LBB48_122:                              ;   in Loop: Header=BB48_120 Depth=2
	ldr	w8, [sp, #2092]
	add	w8, w8, #1
	str	w8, [sp, #2092]
	b	LBB48_120
LBB48_123:                              ;   in Loop: Header=BB48_111 Depth=1
	b	LBB48_124
LBB48_124:                              ;   in Loop: Header=BB48_111 Depth=1
	b	LBB48_125
LBB48_125:                              ;   in Loop: Header=BB48_111 Depth=1
	b	LBB48_126
LBB48_126:                              ;   in Loop: Header=BB48_111 Depth=1
	ldrh	w8, [sp, #2310]
	add	w8, w8, #1
	strh	w8, [sp, #2310]
	b	LBB48_111
LBB48_127:
	ldr	w8, [sp, #2312]
	ldr	x9, [sp, #3432]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #2316]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.eq	LBB48_129
	b	LBB48_128
LBB48_128:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #2                          ; =0x2
	adrp	x4, l_.str.118@PAGE
	add	x4, x4, l_.str.118@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_129:
	b	LBB48_196
LBB48_130:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #2024
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w8, [sp, #2080]
	subs	w8, w8, #2
	b.ne	LBB48_134
	b	LBB48_131
LBB48_131:
	ldrb	w8, [sp, #2081]
	cbnz	w8, LBB48_134
	b	LBB48_132
LBB48_132:
	ldrh	w8, [sp, #2026]
	ldr	x9, [sp, #3392]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB48_134
	b	LBB48_133
LBB48_133:
	ldrh	w8, [sp, #2026]
	mov	x9, x8
	add	x8, sp, #3448
	add	x8, x8, x9, lsl #6
	ldrb	w8, [x8, #56]
	subs	w8, w8, #1
	b.eq	LBB48_135
	b	LBB48_134
LBB48_134:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #364]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.119@PAGE
	add	x4, x4, l_.str.119@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_135:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #344]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3368]
	ldrh	w8, [x8, #8]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	add	x0, sp, #1960
	str	x0, [sp, #352]                  ; 8-byte Folded Spill
	add	x1, sp, #2024
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #344]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #352]                  ; 8-byte Folded Reload
	ldr	w2, [sp, #360]                  ; 4-byte Folded Reload
	add	x3, sp, #3016
	bl	_oq_child
	tbnz	w0, #0, LBB48_137
	b	LBB48_136
LBB48_136:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_137:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	add	x0, sp, #1896
	str	x0, [sp, #336]                  ; 8-byte Folded Spill
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #320]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #332]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #336]                  ; 8-byte Folded Reload
	bl	_oq_require
	tbnz	w0, #0, LBB48_139
	b	LBB48_138
LBB48_138:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_139:
	b	LBB48_196
LBB48_140:
	ldrh	w8, [sp, #3086]
	strh	w8, [sp, #1894]
	b	LBB48_141
LBB48_141:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1894]
	ldrh	w9, [sp, #3382]
	subs	w8, w8, w9
	b.ge	LBB48_146
	b	LBB48_142
LBB48_142:                              ;   in Loop: Header=BB48_141 Depth=1
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #1894]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #1824
	str	x0, [sp, #312]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #312]                  ; 8-byte Folded Reload
	mov	w1, #8                          ; =0x8
	bl	_oq_exact
	tbnz	w0, #0, LBB48_144
	b	LBB48_143
LBB48_143:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #308]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.120@PAGE
	add	x4, x4, l_.str.120@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #308]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_144:                              ;   in Loop: Header=BB48_141 Depth=1
	b	LBB48_145
LBB48_145:                              ;   in Loop: Header=BB48_141 Depth=1
	ldrh	w8, [sp, #1894]
	add	w8, w8, #1
	strh	w8, [sp, #1894]
	b	LBB48_141
LBB48_146:
	add	x8, sp, #1760
	str	x8, [sp, #296]                  ; 8-byte Folded Spill
	mov	w0, #7                          ; =0x7
	bl	_oq_tag
	ldr	x1, [sp, #296]                  ; 8-byte Folded Reload
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x8, [sp, #3416]
	ldrsh	w9, [x8, #80]
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #3032]
	b	LBB48_196
LBB48_147:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #1696
	str	x0, [sp, #272]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #280]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #272]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #280]                  ; 8-byte Folded Reload
	add	x0, sp, #1632
	str	x0, [sp, #288]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #288]                  ; 8-byte Folded Reload
	bl	_oq_array
	tbnz	w0, #0, LBB48_149
	b	LBB48_148
LBB48_148:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #268]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.121@PAGE
	add	x4, x4, l_.str.121@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #268]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_149:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #240]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	add	x0, sp, #1568
	str	x0, [sp, #256]                  ; 8-byte Folded Spill
	add	x1, sp, #1696
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #240]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #252]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #256]                  ; 8-byte Folded Reload
	bl	_oq_require
	tbnz	w0, #0, LBB48_151
	b	LBB48_150
LBB48_150:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_151:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #84
	b.eq	LBB48_153
	b	LBB48_152
LBB48_152:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #83
	b.ne	LBB48_155
	b	LBB48_153
LBB48_153:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
	add	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #1504
	str	x0, [sp, #232]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #232]                  ; 8-byte Folded Reload
	mov	w1, #2                          ; =0x2
	bl	_oq_exact
	tbnz	w0, #0, LBB48_155
	b	LBB48_154
LBB48_154:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #228]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.122@PAGE
	add	x4, x4, l_.str.122@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_155:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #84
	b.eq	LBB48_157
	b	LBB48_156
LBB48_156:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #81
	b.ne	LBB48_159
	b	LBB48_157
LBB48_157:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3382]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #1440
	str	x0, [sp, #216]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #216]                  ; 8-byte Folded Reload
	mov	w1, #8                          ; =0x8
	bl	_oq_exact
	tbnz	w0, #0, LBB48_159
	b	LBB48_158
LBB48_158:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #212]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.123@PAGE
	add	x4, x4, l_.str.123@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_159:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #83
	b.ne	LBB48_161
	b	LBB48_160
LBB48_160:
	add	x8, sp, #1376
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	mov	w0, #3                          ; =0x3
	bl	_oq_tag
	ldr	x1, [sp, #200]                  ; 8-byte Folded Reload
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrh	w8, [sp, #3016]
	orr	w8, w8, #0x1
	strh	w8, [sp, #3016]
	ldrh	w8, [sp, #3016]
	ldr	x9, [sp, #3000]
	strh	w8, [x9, #12]
	b	LBB48_165
LBB48_161:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #85
	b.ne	LBB48_163
	b	LBB48_162
LBB48_162:
	add	x8, sp, #1312
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	bl	_oq_tag
	ldr	x1, [sp, #192]                  ; 8-byte Folded Reload
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_164
LBB48_163:
	add	x1, sp, #1696
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_164
LBB48_164:
	b	LBB48_165
LBB48_165:
	b	LBB48_196
LBB48_166:
	ldr	x8, [sp, #3368]
	ldr	w8, [x8, #8]
	str	w8, [sp, #1308]
	ldr	x8, [sp, #3432]
	add	x10, x8, #16
	ldr	w8, [sp, #1308]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #1296]
	strh	wzr, [sp, #1294]
	b	LBB48_167
LBB48_167:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1294]
	ldr	w9, [sp, #3348]
	subs	w8, w8, w9, uxth
	b.ge	LBB48_174
	b	LBB48_168
LBB48_168:                              ;   in Loop: Header=BB48_167 Depth=1
	ldr	x8, [sp, #3432]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
	ldrh	w10, [sp, #1294]
	add	w10, w9, w10
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	ldr	x8, [sp, #1296]
	add	x8, x8, #8
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #1294]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	add	x0, sp, #1224
	str	x0, [sp, #184]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_oq_type
	tbnz	w0, #0, LBB48_170
	b	LBB48_169
LBB48_169:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #156]                  ; 4-byte Folded Spill
	adrp	x4, l_.str.124@PAGE
	add	x4, x4, l_.str.124@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #156]                  ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_170:                              ;   in Loop: Header=BB48_167 Depth=1
	ldr	x8, [sp, #3432]
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
	ldrh	w10, [sp, #1294]
	add	w10, w9, w10
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #1160
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #144]                  ; 8-byte Folded Reload
	bl	_oq_require
	tbnz	w0, #0, LBB48_172
	b	LBB48_171
LBB48_171:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_172:                              ;   in Loop: Header=BB48_167 Depth=1
	b	LBB48_173
LBB48_173:                              ;   in Loop: Header=BB48_167 Depth=1
	ldrh	w8, [sp, #1294]
	add	w8, w8, #1
	strh	w8, [sp, #1294]
	b	LBB48_167
LBB48_174:
	ldr	x8, [sp, #3432]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #104]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1308]
	str	w8, [sp, #108]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w10, [sp, #3086]
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3432]
	ldr	x8, [x8, #8]
	add	x10, x8, #792
	ldr	w8, [sp, #1308]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x1, x8, #16
	add	x0, sp, #1080
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	ldr	w2, [sp, #108]                  ; 4-byte Folded Reload
	ldr	x3, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x4, [sp, #120]                  ; 8-byte Folded Reload
	add	x5, sp, #1120
	bl	_oq_substitute
	tbnz	w0, #0, LBB48_176
	b	LBB48_175
LBB48_175:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_176:
	ldr	x8, [sp, #3432]
	ldr	x8, [x8, #8]
	add	x10, x8, #792
	ldr	w8, [sp, #3412]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #16
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	add	x0, sp, #1040
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	add	x1, sp, #1120
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	bl	_oq_union
	ldr	w8, [sp, #3344]
	cbz	w8, LBB48_188
	b	LBB48_177
LBB48_177:
	ldr	x8, [sp, #1296]
	add	x1, x8, #2088
	add	x0, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w8, [sp, #3072]
	cbz	w8, LBB48_187
	b	LBB48_178
LBB48_178:
	ldr	x0, [sp, #3432]
	add	x2, sp, #3016
	ldr	w1, [sp, #3020]
	bl	_oq_make_owner
	tbnz	w0, #0, LBB48_180
	b	LBB48_179
LBB48_179:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_180:
	str	wzr, [sp, #1036]
	b	LBB48_181
LBB48_181:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #1036]
	ldr	x9, [sp, #3432]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #3020]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hs	LBB48_186
	b	LBB48_182
LBB48_182:                              ;   in Loop: Header=BB48_181 Depth=1
	ldr	x8, [sp, #3432]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #1308]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldrh	w10, [sp, #3086]
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #3432]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x11, [x8, x9]
	ldr	x8, [sp, #1296]
	ldr	w8, [x8, #2096]
	ldr	w10, [sp, #1036]
	add	w8, w8, w10
	mov	w10, #40                        ; =0x28
	umaddl	x1, w8, w10, x11
	ldr	x8, [sp, #3432]
	ldr	x10, [x8, x9]
	ldr	w8, [sp, #3024]
	ldr	w9, [sp, #1036]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	add	x0, sp, #992
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	ldr	w2, [sp, #52]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x4, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x5, [sp, #72]                   ; 8-byte Folded Reload
	bl	_oq_substitute
	tbnz	w0, #0, LBB48_184
	b	LBB48_183
LBB48_183:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_184:                              ;   in Loop: Header=BB48_181 Depth=1
	b	LBB48_185
LBB48_185:                              ;   in Loop: Header=BB48_181 Depth=1
	ldr	w8, [sp, #1036]
	add	w8, w8, #1
	str	w8, [sp, #1036]
	b	LBB48_181
LBB48_186:
	b	LBB48_187
LBB48_187:
	b	LBB48_188
LBB48_188:
	b	LBB48_196
LBB48_189:
	ldr	x9, [sp, #3000]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #23]
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #6
	ldrh	w10, [x8, x9]
	ldr	x9, [sp, #3000]
	ldrh	w8, [x9, #14]
	orr	w8, w8, w10
	strh	w8, [x9, #14]
	ldr	x9, [sp, #3000]
	mov	w8, #2                          ; =0x2
	strh	w8, [x9, #18]
	ldr	x9, [sp, #3384]
	ldrh	w10, [sp, #3086]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #6
	ldrh	w11, [x9, x10]
	ldr	x10, [sp, #3000]
	ldrh	w9, [x10, #8]
	orr	w9, w9, w11
	strh	w9, [x10, #8]
	ldr	x9, [sp, #3000]
	strh	w8, [x9, #10]
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #928
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	w1, #2                          ; =0x2
	bl	_oq_exact
	tbnz	w0, #0, LBB48_191
	b	LBB48_190
LBB48_190:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #28]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.125@PAGE
	add	x4, x4, l_.str.125@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_191:
	b	LBB48_196
LBB48_192:
	ldr	x9, [sp, #3000]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #23]
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #6
	ldrh	w10, [x8, x9]
	ldr	x9, [sp, #3000]
	ldrh	w8, [x9, #14]
	orr	w8, w8, w10
	strh	w8, [x9, #14]
	ldr	x9, [sp, #3000]
	mov	w8, #16                         ; =0x10
	strh	w8, [x9, #18]
	ldr	x9, [sp, #3384]
	ldrh	w10, [sp, #3086]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #6
	ldrh	w11, [x9, x10]
	ldr	x10, [sp, #3000]
	ldrh	w9, [x10, #8]
	orr	w9, w9, w11
	strh	w9, [x10, #8]
	ldr	x9, [sp, #3000]
	strh	w8, [x9, #10]
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #864
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	w1, #16                         ; =0x10
	bl	_oq_exact
	tbnz	w0, #0, LBB48_194
	b	LBB48_193
LBB48_193:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.126@PAGE
	add	x4, x4, l_.str.126@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_194:
	b	LBB48_196
LBB48_195:
	ldr	x0, [sp, #3432]
	ldr	w2, [sp, #3412]
	ldr	x8, [sp, #3416]
	ldr	w3, [x8, #68]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #8]                    ; 4-byte Folded Spill
	adrp	x4, l_.str.127@PAGE
	add	x4, x4, l_.str.127@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w0, w8
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_196:
	b	LBB48_197
LBB48_197:
	ldrh	w8, [sp, #3086]
	ldr	w9, [sp, #3344]
	add	w8, w8, w9
	strh	w8, [sp, #3382]
	ldr	w8, [sp, #3344]
	cbz	w8, LBB48_199
	b	LBB48_198
LBB48_198:
	ldr	x8, [sp, #3384]
	ldrh	w9, [sp, #3086]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #6
	add	x1, sp, #3016
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	b	LBB48_199
LBB48_199:
	b	LBB48_200
LBB48_200:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #56
	b.eq	LBB48_203
	b	LBB48_201
LBB48_201:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #57
	b.eq	LBB48_203
	b	LBB48_202
LBB48_202:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #58
	b.ne	LBB48_208
	b	LBB48_203
LBB48_203:
	ldr	x0, [sp, #3432]
	ldr	x8, [sp, #3416]
	ldr	w1, [x8, #76]
	ldrh	w3, [sp, #3382]
	add	x2, sp, #3448
	bl	_oq_join
	tbnz	w0, #0, LBB48_205
	b	LBB48_204
LBB48_204:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_205:
	ldrb	w8, [sp, #3367]
	subs	w8, w8, #56
	b.ne	LBB48_207
	b	LBB48_206
LBB48_206:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_207:
	b	LBB48_208
LBB48_208:
	ldr	x0, [sp, #3432]
	ldr	x8, [sp, #3416]
	ldr	w1, [x8, #72]
	ldrh	w3, [sp, #3382]
	add	x2, sp, #3448
	bl	_oq_join
	and	w8, w0, #0x1
	strb	w8, [sp, #3447]
	b	LBB48_209
LBB48_209:
	ldrb	w8, [sp, #3447]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB48_211
	b	LBB48_210
LBB48_210:
	bl	___stack_chk_fail
LBB48_211:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #3456
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
	.p2align	2
lJTI48_0:
	.long	LBB48_63-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_64-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_65-Ltmp16
	.long	LBB48_70-Ltmp16
	.long	LBB48_68-Ltmp16
	.long	LBB48_69-Ltmp16
	.long	LBB48_83-Ltmp16
	.long	LBB48_102-Ltmp16
	.long	LBB48_108-Ltmp16
	.long	LBB48_83-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_73-Ltmp16
	.long	LBB48_78-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_63-Ltmp16
	.long	LBB48_192-Ltmp16
	.long	LBB48_192-Ltmp16
	.long	LBB48_166-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_140-Ltmp16
	.long	LBB48_147-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_147-Ltmp16
	.long	LBB48_147-Ltmp16
	.long	LBB48_147-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_140-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_189-Ltmp16
	.long	LBB48_192-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_189-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_195-Ltmp16
	.long	LBB48_130-Ltmp16
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_vector
_oq_vector:                             ; @oq_vector
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #17240                     ; =0x4358
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB49_2
	b	LBB49_1
LBB49_1:
	ldr	x0, [sp, #16]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.94@PAGE
	add	x4, x4, l_.str.94@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB49_5
LBB49_2:
	ldr	x0, [sp, #16]
	ldr	w1, [sp, #12]
	bl	_oq_work
	tbnz	w0, #0, LBB49_4
	b	LBB49_3
LBB49_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB49_5
LBB49_4:
	ldr	x8, [sp, #16]
	mov	x9, #17240                      ; =0x4358
	movk	x9, #6, lsl #16
	ldr	w8, [x8, x9]
	ldr	x10, [sp]
	str	w8, [x10]
	ldr	w10, [sp, #12]
	ldr	x8, [sp, #16]
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB49_5
LBB49_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_work
_oq_work:                               ; @oq_work
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #17256                     ; =0x4368
	movk	x10, #6, lsl #16
	ldr	w10, [x9, x10]
	mov	w9, #262144                     ; =0x40000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB50_2
	b	LBB50_1
LBB50_1:
	ldr	x0, [sp, #16]
	mov	w1, #3                          ; =0x3
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.95@PAGE
	add	x4, x4, l_.str.95@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB50_3
LBB50_2:
	ldr	w10, [sp, #12]
	ldr	x8, [sp, #16]
	mov	x9, #17256                      ; =0x4368
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, w10
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB50_3
LBB50_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_merge_value
_oq_merge_value:                        ; @oq_merge_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x2, [sp, #88]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	stur	w4, [x29, #-60]
	stur	w5, [x29, #-64]
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #56]
	cbnz	w8, LBB51_2
	b	LBB51_1
LBB51_1:
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #56]
	cbz	w8, LBB51_7
	b	LBB51_2
LBB51_2:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #56]
	ldrb	w9, [x9, #56]
	subs	w8, w8, w9
	b.ne	LBB51_6
	b	LBB51_3
LBB51_3:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #4]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB51_6
	b	LBB51_4
LBB51_4:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #2]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB51_6
	b	LBB51_5
LBB51_5:
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB51_7
	b	LBB51_6
LBB51_6:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-60]
	ldur	w3, [x29, #-64]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #84]                   ; 4-byte Folded Spill
	adrp	x4, l_.str.101@PAGE
	add	x4, x4, l_.str.101@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-17]
	b	LBB51_26
LBB51_7:
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9]
	sturh	w9, [x29, #-66]
	ldur	x9, [x29, #-40]
	ldrb	w9, [x9, #57]
	sturb	w9, [x29, #-67]
	ldrh	w11, [x8]
	ldur	x10, [x29, #-40]
	ldrh	w9, [x10]
	orr	w9, w9, w11
	strh	w9, [x10]
	ldrb	w10, [x8, #57]
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9, #57]
	orr	w8, w8, w10
	strb	w8, [x9, #57]
	ldurh	w9, [x29, #-66]
	ldur	x8, [x29, #-40]
	ldrh	w10, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
	b.ne	LBB51_9
	b	LBB51_8
LBB51_8:
	ldurb	w8, [x29, #-67]
	ldur	x9, [x29, #-40]
	ldrb	w9, [x9, #57]
	subs	w8, w8, w9
	cset	w8, ne
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
	b	LBB51_9
LBB51_9:
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #80]                   ; 4-byte Folded Reload
	and	w11, w9, #0x1
	ldur	x10, [x29, #-56]
	ldrb	w9, [x10]
	and	w9, w9, #0x1
	orr	w9, w9, w11
	subs	w9, w9, #0
	cset	w9, ne
	strb	w9, [x10]
	ldur	x9, [x29, #-40]
	add	x9, x9, #16
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	add	x1, x8, #16
	sub	x0, x29, #112
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	bl	_oq_union
	ldur	x9, [x29, #-56]
	ldrb	w8, [x9]
	and	w8, w8, #0x1
	orr	w8, w8, w0
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #56]
	cbz	w8, LBB51_25
	b	LBB51_10
LBB51_10:
	ldur	x8, [x29, #-32]
	mov	x9, #17260                      ; =0x436c
	movk	x9, #6, lsl #16
	add	x8, x8, x9
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-116]
	sturb	wzr, [x29, #-117]
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-116]
	bl	_oq_work
	tbnz	w0, #0, LBB51_12
	b	LBB51_11
LBB51_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB51_26
LBB51_12:
	stur	wzr, [x29, #-124]
	b	LBB51_13
LBB51_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-124]
	ldur	w9, [x29, #-116]
	subs	w8, w8, w9
	b.hs	LBB51_16
	b	LBB51_14
LBB51_14:                               ;   in Loop: Header=BB51_13 Depth=1
	ldur	x8, [x29, #-32]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x10, [x8, x9]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-124]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #168
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	ldr	x10, [x9, x10]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-124]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	add	x0, sp, #144
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	bl	_oq_union
	ldurb	w8, [x29, #-117]
	and	w8, w8, #0x1
	orr	w8, w8, w0
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-117]
	b	LBB51_15
LBB51_15:                               ;   in Loop: Header=BB51_13 Depth=1
	ldur	w8, [x29, #-124]
	add	w8, w8, #1
	stur	w8, [x29, #-124]
	b	LBB51_13
LBB51_16:
	ldurb	w8, [x29, #-117]
	tbz	w8, #0, LBB51_24
	b	LBB51_17
LBB51_17:
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-116]
	add	x2, sp, #140
	bl	_oq_vector
	tbnz	w0, #0, LBB51_19
	b	LBB51_18
LBB51_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB51_26
LBB51_19:
	str	wzr, [sp, #136]
	b	LBB51_20
LBB51_20:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #136]
	ldur	w9, [x29, #-116]
	subs	w8, w8, w9
	b.hs	LBB51_23
	b	LBB51_21
LBB51_21:                               ;   in Loop: Header=BB51_20 Depth=1
	ldur	x8, [x29, #-32]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	str	x9, [sp]                        ; 8-byte Folded Spill
	ldr	x11, [x8, x9]
	ldr	w8, [sp, #140]
	ldr	w10, [sp, #136]
	add	w8, w8, w10
	mov	w10, #40                        ; =0x28
	umaddl	x0, w8, w10, x11
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, x9]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #136]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	ldr	x12, [x9, x10]
	ldr	w9, [sp, #140]
	ldr	w11, [sp, #136]
	add	w9, w9, w11
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x12
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x9, [x29, #-32]
	ldr	x10, [x9, x10]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #136]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	add	x0, sp, #96
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	bl	_oq_union
	b	LBB51_22
LBB51_22:                               ;   in Loop: Header=BB51_20 Depth=1
	ldr	w8, [sp, #136]
	add	w8, w8, #1
	str	w8, [sp, #136]
	b	LBB51_20
LBB51_23:
	ldr	w8, [sp, #140]
	ldur	x9, [x29, #-40]
	str	w8, [x9, #8]
	ldur	x9, [x29, #-56]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB51_24
LBB51_24:
	b	LBB51_25
LBB51_25:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB51_26
LBB51_26:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_enqueue
_oq_enqueue:                            ; @oq_enqueue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x10, [sp, #8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
	mov	x11, #17232                     ; =0x4350
	add	x10, x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #84]
	tbz	w8, #0, LBB52_2
	b	LBB52_1
LBB52_1:
	b	LBB52_3
LBB52_2:
	ldr	x8, [sp, #8]
	mov	x9, #17232                      ; =0x4350
	add	x10, x8, x9
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #96                         ; =0x60
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #84]
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	mov	x10, #19320                     ; =0x4b78
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	x11, [sp, #8]
	mov	x10, #35708                     ; =0x8b7c
	movk	x10, #6, lsl #16
	ldr	w11, [x11, x10]
                                        ; kill: def $x11 killed $w11
	str	w8, [x9, x11, lsl #2]
	ldr	x8, [sp, #8]
	ldr	w8, [x8, x10]
	add	w8, w8, #1
	mov	w11, #4096                      ; =0x1000
	udiv	w9, w8, w11
	mul	w9, w9, w11
	subs	w8, w8, w9
	ldr	x9, [sp, #8]
	str	w8, [x9, x10]
	ldr	x8, [sp, #8]
	mov	x9, #35712                      ; =0x8b80
	movk	x9, #6, lsl #16
	add	x9, x8, x9
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB52_3
LBB52_3:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_union
_oq_union:                              ; @oq_union
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [sp, #40]
	str	x1, [sp, #32]
	strb	wzr, [sp, #31]
	str	wzr, [sp, #24]
	b	LBB53_1
LBB53_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	subs	w8, w8, #5
	b.hs	LBB53_4
	b	LBB53_2
LBB53_2:                                ;   in Loop: Header=BB53_1 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	w10, [sp, #24]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	ldr	w10, [sp, #24]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	orr	x8, x8, x9
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #24]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	subs	x8, x8, x9
	cset	w9, ne
	ldrb	w8, [sp, #31]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #31]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #40]
	ldr	w10, [sp, #24]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB53_3
LBB53_3:                                ;   in Loop: Header=BB53_1 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB53_1
LBB53_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_type
_oq_type:                               ; @oq_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	stur	x2, [x29, #-12]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #8
	b.ne	LBB54_7
	b	LBB54_1
LBB54_1:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w9, [x8, #56]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b.ne	LBB54_6
	b	LBB54_2
LBB54_2:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #57]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #36]                   ; 4-byte Folded Spill
	cbnz	w8, LBB54_6
	b	LBB54_3
LBB54_3:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrh	w8, [x8]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #256
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b.ne	LBB54_6
	b	LBB54_4
LBB54_4:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-8]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b.ne	LBB54_6
	b	LBB54_5
LBB54_5:
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-8]
	bl	_oq_owner_layout
	str	w0, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB54_6
LBB54_6:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_10
LBB54_7:
	ldurb	w8, [x29, #-12]
	subs	w8, w8, #7
	b.ne	LBB54_9
	b	LBB54_8
LBB54_8:
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	sub	x0, x29, #96
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_oq_array
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB54_10
LBB54_9:
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldurb	w9, [x29, #-12]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	lsl	w8, w8, w9
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	add	x0, sp, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w1, w8, #0xffff
	bl	_oq_exact
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-1]
	b	LBB54_10
LBB54_10:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_require
_oq_require:                            ; @oq_require
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x2, [sp, #80]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	mov	x8, x2
	stur	x8, [x29, #-48]
	ldrb	w8, [x2, #56]
	cbz	w8, LBB55_10
	b	LBB55_1
LBB55_1:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x8, x8, x10
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_oq_work
	tbnz	w0, #0, LBB55_3
	b	LBB55_2
LBB55_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB55_16
LBB55_3:
	stur	wzr, [x29, #-52]
	b	LBB55_4
LBB55_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-32]
	mov	x11, #17260                     ; =0x436c
	movk	x11, #6, lsl #16
	add	x9, x9, x11
	ldr	w10, [x10, #4]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hs	LBB55_9
	b	LBB55_5
LBB55_5:                                ;   in Loop: Header=BB55_4 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	mov	x10, #17232                     ; =0x4350
	movk	x10, #6, lsl #16
	ldr	x10, [x9, x10]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-52]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #96
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #64]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #64]                   ; 8-byte Folded Reload
	sub	x0, x29, #136
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	bl	_oq_nonempty
	tbnz	w0, #0, LBB55_7
	b	LBB55_6
LBB55_6:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-36]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.128@PAGE
	add	x4, x4, l_.str.128@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-17]
	b	LBB55_16
LBB55_7:                                ;   in Loop: Header=BB55_4 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	add	x10, x8, #792
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	sub	x0, x29, #176
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	sub	x1, x29, #96
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_oq_union
	b	LBB55_8
LBB55_8:                                ;   in Loop: Header=BB55_4 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB55_4
LBB55_9:
	b	LBB55_15
LBB55_10:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldrh	w8, [x8]
	subs	w8, w8, #128
	b.ne	LBB55_14
	b	LBB55_11
LBB55_11:
	ldr	x1, [sp, #80]                   ; 8-byte Folded Reload
	add	x0, sp, #128
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_oq_array
	tbnz	w0, #0, LBB55_13
	b	LBB55_12
LBB55_12:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-36]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.129@PAGE
	add	x4, x4, l_.str.129@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-17]
	b	LBB55_16
LBB55_13:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #8]
	add	x11, x9, #792
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #56                        ; =0x38
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x9, x9, #16
	str	x9, [sp]                        ; 8-byte Folded Spill
	add	x1, x8, #16
	add	x0, sp, #88
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	bl	_oq_union
	b	LBB55_14
LBB55_14:
	b	LBB55_15
LBB55_15:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB55_16
LBB55_16:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_nonempty
_oq_nonempty:                           ; @oq_nonempty
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp]                        ; 8-byte Folded Spill
	str	x0, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB56_1
LBB56_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #5
	b.hs	LBB56_6
	b	LBB56_2
LBB56_2:                                ;   in Loop: Header=BB56_1 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB56_4
	b	LBB56_3
LBB56_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB56_7
LBB56_4:                                ;   in Loop: Header=BB56_1 Depth=1
	b	LBB56_5
LBB56_5:                                ;   in Loop: Header=BB56_1 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB56_1
LBB56_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB56_7
LBB56_7:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_optional_comparison
_oq_optional_comparison:                ; @oq_optional_comparison
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	ldrb	w8, [sp, #14]
	subs	w8, w8, #216
	subs	w8, w8, #5
	b.hi	LBB57_2
	b	LBB57_1
LBB57_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB57_3
LBB57_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB57_3
LBB57_3:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_child
_oq_child:                              ; @oq_child
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	sturh	w2, [x29, #-26]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldr	w1, [x1, #4]
	ldurh	w2, [x29, #-26]
	sub	x3, x29, #52
	bl	_nvm_owned_array_layout_field
	tbnz	w0, #0, LBB58_2
	b	LBB58_1
LBB58_1:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.130@PAGE
	add	x4, x4, l_.str.130@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_23
LBB58_2:
	ldurb	w0, [x29, #-52]
	add	x8, sp, #104
	bl	_oq_tag
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	wzr, [sp, #100]
	str	wzr, [sp, #96]
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x8, x8, x10
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_oq_work
	tbnz	w0, #0, LBB58_4
	b	LBB58_3
LBB58_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_23
LBB58_4:
	str	wzr, [sp, #92]
	b	LBB58_5
LBB58_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #92]
	ldur	x9, [x29, #-16]
	mov	x11, #17260                     ; =0x436c
	movk	x11, #6, lsl #16
	add	x9, x9, x11
	ldr	w10, [x10, #4]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.hs	LBB58_13
	b	LBB58_6
LBB58_6:                                ;   in Loop: Header=BB58_5 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8, #4]
	ldr	w2, [sp, #92]
	add	x8, sp, #16
	bl	_oq_path
	ldrh	w8, [sp, #28]
	ldurh	w9, [x29, #-26]
	subs	w8, w8, w9
	b.ge	LBB58_8
	b	LBB58_7
LBB58_7:                                ;   in Loop: Header=BB58_5 Depth=1
	ldr	w8, [sp, #100]
	add	w8, w8, #1
	str	w8, [sp, #100]
	b	LBB58_11
LBB58_8:                                ;   in Loop: Header=BB58_5 Depth=1
	ldrh	w8, [sp, #28]
	ldurh	w9, [x29, #-26]
	subs	w8, w8, w9
	b.ne	LBB58_10
	b	LBB58_9
LBB58_9:                                ;   in Loop: Header=BB58_5 Depth=1
	ldr	w8, [sp, #96]
	add	w8, w8, #1
	str	w8, [sp, #96]
	b	LBB58_10
LBB58_10:                               ;   in Loop: Header=BB58_5 Depth=1
	b	LBB58_11
LBB58_11:                               ;   in Loop: Header=BB58_5 Depth=1
	b	LBB58_12
LBB58_12:                               ;   in Loop: Header=BB58_5 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB58_5
LBB58_13:
	ldurb	w8, [x29, #-52]
	subs	w8, w8, #7
	b.ne	LBB58_17
	b	LBB58_14
LBB58_14:
	ldr	w8, [sp, #96]
	subs	w8, w8, #1
	b.eq	LBB58_16
	b	LBB58_15
LBB58_15:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.131@PAGE
	add	x4, x4, l_.str.131@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_23
LBB58_16:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x9, sp, #104
	add	x0, x9, #16
	ldur	x9, [x29, #-16]
	mov	x10, #17232                     ; =0x4350
	movk	x10, #6, lsl #16
	ldr	x10, [x9, x10]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #100]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB58_22
LBB58_17:
	ldurb	w8, [x29, #-52]
	subs	w8, w8, #8
	b.ne	LBB58_21
	b	LBB58_18
LBB58_18:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x8, #56]
	strb	w9, [sp, #160]
	ldrh	w9, [x8, #2]
	strh	w9, [sp, #106]
	ldur	w9, [x29, #-48]
	str	w9, [sp, #108]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #100]
	add	w8, w8, w9
	str	w8, [sp, #112]
	ldr	w8, [sp, #96]
	ldur	x9, [x29, #-16]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.eq	LBB58_20
	b	LBB58_19
LBB58_19:
	ldur	x0, [x29, #-16]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	mov	x2, x3
	adrp	x4, l_.str.132@PAGE
	add	x4, x4, l_.str.132@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_23
LBB58_20:
	b	LBB58_21
LBB58_21:
	b	LBB58_22
LBB58_22:
	ldur	x0, [x29, #-40]
	add	x1, sp, #104
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB58_23
LBB58_23:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_exact
_oq_exact:                              ; @oq_exact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	stur	x8, [x29, #-8]
	sturh	w1, [x29, #-10]
	ldrb	w8, [x0, #57]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbnz	w8, LBB59_4
	b	LBB59_1
LBB59_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #56]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbnz	w8, LBB59_4
	b	LBB59_2
LBB59_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, x8, #16
	add	x0, sp, #24
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	bl	_oq_nonempty
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB59_4
	b	LBB59_3
LBB59_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w8, [x8]
	ldurh	w9, [x29, #-10]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB59_4
LBB59_4:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_array
_oq_array:                              ; @oq_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, x0
	stur	x8, [x29, #-8]
	ldrb	w8, [x0, #56]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	cbnz	w8, LBB60_4
	b	LBB60_1
LBB60_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #57]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	cbnz	w8, LBB60_4
	b	LBB60_2
LBB60_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, #128
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b.ne	LBB60_4
	b	LBB60_3
LBB60_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, x8, #16
	add	x0, sp, #32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_oq_nonempty
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB60_4
LBB60_4:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function oq_substitute
_oq_substitute:                         ; @oq_substitute
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x4, [sp, #56]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	stur	x3, [x29, #-48]
	stur	x4, [x29, #-56]
	stur	x5, [x29, #-64]
	sub	x0, x29, #104
	mov	x2, #40                         ; =0x28
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x4, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [x4]
	stur	x8, [x29, #-104]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	add	x10, x10, #792
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-112]
	ldur	x0, [x29, #-32]
	mov	w1, #256                        ; =0x100
	bl	_oq_work
	tbnz	w0, #0, LBB61_2
	b	LBB61_1
LBB61_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB61_17
LBB61_2:
	stur	wzr, [x29, #-116]
	b	LBB61_3
LBB61_3:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-116]
	subs	w8, w8, #256
	b.hs	LBB61_16
	b	LBB61_4
LBB61_4:                                ;   in Loop: Header=BB61_3 Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-116]
	mov	w11, #64                        ; =0x40
	udiv	w9, w9, w11
	add	w9, w9, #1
	ldr	x8, [x8, w9, uxtw #3]
	ldur	w9, [x29, #-116]
	udiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB61_14
	b	LBB61_5
LBB61_5:                                ;   in Loop: Header=BB61_3 Depth=1
	ldur	w8, [x29, #-116]
	ldur	x9, [x29, #-112]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.lo	LBB61_7
	b	LBB61_6
LBB61_6:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-36]
	mov	w1, #2                          ; =0x2
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.133@PAGE
	add	x4, x4, l_.str.133@PAGEOFF
	bl	_oq_stop
	and	w8, w0, #0x1
	sturb	w8, [x29, #-17]
	b	LBB61_17
LBB61_7:                                ;   in Loop: Header=BB61_3 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	add	x10, x8, #1240
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #30720                      ; =0x7800
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldur	w8, [x29, #-116]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-128]
	ldur	x8, [x29, #-48]
	ldur	x9, [x29, #-128]
	ldrh	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #6
	add	x0, sp, #192
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldur	x8, [x29, #-32]
	add	x10, x8, #16
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
	mov	x9, #2152                       ; =0x868
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #2064
	ldur	x9, [x29, #-128]
	ldrh	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	str	w8, [sp, #188]
	ldr	w8, [sp, #196]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB61_10
	b	LBB61_8
LBB61_8:                                ;   in Loop: Header=BB61_3 Depth=1
	ldur	w8, [x29, #-116]
	ldr	w9, [sp, #188]
	subs	w8, w8, w9
	b.lo	LBB61_10
	b	LBB61_9
LBB61_9:                                ;   in Loop: Header=BB61_3 Depth=1
	ldur	w8, [x29, #-116]
	ldr	w9, [sp, #188]
	subs	w8, w8, w9
	ldur	x9, [x29, #-32]
	mov	x10, #17260                     ; =0x436c
	movk	x10, #6, lsl #16
	add	x9, x9, x10
	ldr	w10, [sp, #196]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.lo	LBB61_11
	b	LBB61_10
LBB61_10:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-36]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #52]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.134@PAGE
	add	x4, x4, l_.str.134@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-17]
	b	LBB61_17
LBB61_11:                               ;   in Loop: Header=BB61_3 Depth=1
	ldur	x8, [x29, #-32]
	mov	x9, #17232                      ; =0x4350
	movk	x9, #6, lsl #16
	ldr	x10, [x8, x9]
	ldr	w8, [sp, #200]
	ldur	w9, [x29, #-116]
	add	w8, w8, w9
	ldr	w9, [sp, #188]
	subs	w8, w8, w9
	mov	w9, #40                         ; =0x28
	umaddl	x1, w8, w9, x10
	add	x0, sp, #144
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #32]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	add	x0, sp, #104
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_oq_nonempty
	tbnz	w0, #0, LBB61_13
	b	LBB61_12
LBB61_12:
	ldur	x0, [x29, #-32]
	ldur	w2, [x29, #-36]
	mov	w1, #1                          ; =0x1
	str	w1, [sp, #20]                   ; 4-byte Folded Spill
	mov	w3, #0                          ; =0x0
	adrp	x4, l_.str.135@PAGE
	add	x4, x4, l_.str.135@PAGEOFF
	bl	_oq_stop
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w0, w8
	sturb	w8, [x29, #-17]
	b	LBB61_17
LBB61_13:                               ;   in Loop: Header=BB61_3 Depth=1
	add	x0, sp, #64
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	add	x1, sp, #144
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	sub	x0, x29, #104
	bl	_oq_union
	b	LBB61_14
LBB61_14:                               ;   in Loop: Header=BB61_3 Depth=1
	b	LBB61_15
LBB61_15:                               ;   in Loop: Header=BB61_3 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB61_3
LBB61_16:
	ldur	x0, [x29, #-64]
	sub	x1, x29, #104
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB61_17
LBB61_17:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require a consistent module and plan output."

l_.str.1:                               ; @.str.1
	.asciz	"I require retained layout facts, not count-only placeholders."

l_.str.2:                               ; @.str.2
	.asciz	"I could not own the preflighted retained fields."

l_.str.3:                               ; @.str.3
	.asciz	"I have not described this record field kind."

l_.str.4:                               ; @.str.4
	.asciz	"I require nested kind identity to match the field tag."

l_.str.5:                               ; @.str.5
	.asciz	"I could not establish checked ownership declarations."

l_.str.6:                               ; @.str.6
	.asciz	"I require explicit ordinary authority for every record."

l_.str.7:                               ; @.str.7
	.asciz	"I require explicit ordinary authority for forward records."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate my record plan."

l_.str.9:                               ; @.str.9
	.asciz	"I could not allocate my exact record maps."

l_.str.10:                              ; @.str.10
	.asciz	"I described record identities without executable admission."

l_.str.11:                              ; @.str.11
	.asciz	"I require consistent mixed descriptor inputs."

l_.str.12:                              ; @.str.12
	.asciz	"I require retained mixed layout facts."

l_.str.13:                              ; @.str.13
	.asciz	"I reached my mixed ownership byte budget."

l_.str.14:                              ; @.str.14
	.asciz	"I require a complete mixed layout count."

l_.str.15:                              ; @.str.15
	.asciz	"I require exact ownership transport before allocation."

l_.str.16:                              ; @.str.16
	.asciz	"I could not allocate my mixed descriptor view."

l_.str.17:                              ; @.str.17
	.asciz	"I could not materialize my checked retained layouts."

l_.str.18:                              ; @.str.18
	.asciz	"I could not retain my exact ownership descriptors."

l_.str.19:                              ; @.str.19
	.asciz	"I described mixed identities without executable authority."

l_.str.20:                              ; @.str.20
	.asciz	"I require consistent acyclic mixed declaration facts."

l_.str.21:                              ; @.str.21
	.asciz	"I require consistent owner-array descriptor inputs."

l_.str.22:                              ; @.str.22
	.asciz	"I refuse service claims before owner-array description."

l_.str.23:                              ; @.str.23
	.asciz	"I require retained layouts and explicit ownership facts."

l_.str.24:                              ; @.str.24
	.asciz	"I reached my ownership transport budget."

l_.str.25:                              ; @.str.25
	.asciz	"I retain prior-only owner-array layout dependencies."

l_.str.26:                              ; @.str.26
	.asciz	"I require a complete layout count."

l_.str.27:                              ; @.str.27
	.asciz	"I could not allocate my owner-array descriptor view."

l_.str.28:                              ; @.str.28
	.asciz	"I could not materialize preflighted owner-array layouts."

l_.str.29:                              ; @.str.29
	.asciz	"I retain exact scalar-only borrowed roots."

l_.str.30:                              ; @.str.30
	.asciz	"I could not retain original descriptor transport."

l_.str.31:                              ; @.str.31
	.asciz	"I described pending owner ARRAY fields without runtime admission."

l_.str.32:                              ; @.str.32
	.asciz	"I require a complete immutable module envelope and output."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @__const.nvm_analyze_owned_array_origins.invalid
l___const.nvm_analyze_owned_array_origins.invalid:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.32

	.section	__TEXT,__cstring,cstring_literals
l_.str.33:                              ; @.str.33
	.asciz	"I refuse service claims before origin analysis."

l_.str.34:                              ; @.str.34
	.asciz	"I require one explicit standalone entry and at most eight functions."

l_.str.35:                              ; @.str.35
	.asciz	"I reached my local or argument limit."

l_.str.36:                              ; @.str.36
	.asciz	"I could not allocate my bounded origin query."

l_.str.37:                              ; @.str.37
	.asciz	"I require closed entry obligations without formal bits."

l_.str.38:                              ; @.str.38
	.asciz	"I require existing concrete entry origins."

l_.str.39:                              ; @.str.39
	.asciz	"I proved conditional owner origins and a closed entry only; execution authority remains separate."

l_.str.40:                              ; @.str.40
	.asciz	"I reached my record layout limit."

l_.str.41:                              ; @.str.41
	.asciz	"I require canonical layout headers and names."

l_.str.42:                              ; @.str.42
	.asciz	"I reached my retained field limit."

l_.str.43:                              ; @.str.43
	.asciz	"I require canonical closed fields and names."

l_.str.44:                              ; @.str.44
	.asciz	"I require exact retained bytes and per-kind counts."

l_.str.45:                              ; @.str.45
	.asciz	"I require exact all-record scalar/string forward layouts."

l_.str.46:                              ; @.str.46
	.asciz	"I validated only retained byte structure."

l_.str.47:                              ; @.str.47
	.asciz	"I require a complete preflighted field."

l_.str.48:                              ; @.str.48
	.asciz	"I require an exact acyclic record graph."

l_.str.49:                              ; @.str.49
	.asciz	"I require bounded record graph depth."

l_.str.50:                              ; @.str.50
	.asciz	"I validated the exact forward record graph."

l_.str.51:                              ; @.str.51
	.asciz	"I retain passive non-record declarations without owner authority."

l_.str.52:                              ; @.str.52
	.asciz	"I require explicit complete record declarations."

l_.str.53:                              ; @.str.53
	.asciz	"I require prior children in the same owner or ordinary category."

l_.str.54:                              ; @.str.54
	.asciz	"I reached my owner nesting limit."

l_.str.55:                              ; @.str.55
	.asciz	"I require exact scalar, STRING or pending ARRAY leaves."

l_.str.56:                              ; @.str.56
	.asciz	"I reached my expanded owner leaf-path budget."

l_.str.57:                              ; @.str.57
	.asciz	"I reached my total owner leaf-path budget."

l_.str.58:                              ; @.str.58
	.asciz	"I described pending owner leaves without element proof."

l_.str.59:                              ; @.str.59
	.asciz	"I cannot represent my owner leaf-path storage."

l_.str.60:                              ; @.str.60
	.asciz	"I could not allocate my bounded owner leaf paths."

l_.str.61:                              ; @.str.61
	.asciz	"I reached my retained leaf-path length limit."

l_.str.62:                              ; @.str.62
	.asciz	"I require exact expanded leaf-path counts."

l_.str.63:                              ; @.str.63
	.asciz	"I retained bounded owner leaf paths."

l_.str.64:                              ; @.str.64
	.asciz	"I could not allocate ARRAY path indices."

l_.str.65:                              ; @.str.65
	.asciz	"I could not allocate bounded intermediate field facts."

l_.str.66:                              ; @.str.66
	.asciz	"I keep borrowed modes outside owner ARRAY origins."

l_.str.67:                              ; @.str.67
	.asciz	"I require exact scalar or owner signatures."

l_.str.68:                              ; @.str.68
	.asciz	"I require modeled exact local types."

l_.str.69:                              ; @.str.69
	.asciz	"I retain a scalar or VOID entry result."

l_.str.70:                              ; @.str.70
	.asciz	"I reached my result ARRAY path budget."

l_.str.71:                              ; @.str.71
	.asciz	"I require complete function names."

l_.str.72:                              ; @.str.72
	.asciz	"__init__"

l_.str.73:                              ; @.str.73
	.asciz	"I keep initializer entry roots outside this query."

l_.str.74:                              ; @.str.74
	.asciz	"I require complete nonempty code ranges."

l_.str.75:                              ; @.str.75
	.asciz	"I require distinct function code ranges."

l_.str.76:                              ; @.str.76
	.asciz	"I reached my instruction budget."

l_.str.77:                              ; @.str.77
	.asciz	"I require complete decoded instructions."

l_.str.78:                              ; @.str.78
	.asciz	"I have no owner-origin transfer for this opcode."

l_.str.79:                              ; @.str.79
	.asciz	"I require canonical BOOL immediates."

l_.str.80:                              ; @.str.80
	.asciz	"I require an existing STRING constant."

l_.str.81:                              ; @.str.81
	.asciz	"I require an existing local."

l_.str.82:                              ; @.str.82
	.asciz	"I require an existing callee."

l_.str.83:                              ; @.str.83
	.asciz	"I do not call my selected entry."

l_.str.84:                              ; @.str.84
	.asciz	"I require an exact owner declaration."

l_.str.85:                              ; @.str.85
	.asciz	"I require declared FLOAT array sites."

l_.str.86:                              ; @.str.86
	.asciz	"I reached my concrete origin budget."

l_.str.87:                              ; @.str.87
	.asciz	"I require an instruction-boundary branch target."

l_.str.88:                              ; @.str.88
	.asciz	"I require explicit terminal control flow."

l_.str.89:                              ; @.str.89
	.asciz	"I require an acyclic complete call graph."

l_.str.90:                              ; @.str.90
	.asciz	"I reached my formal ARRAY path budget."

l_.str.91:                              ; @.str.91
	.asciz	"I reached my origin fixed-point visit budget."

l_.str.92:                              ; @.str.92
	.asciz	"I require checked state for every declared instruction."

l_.str.93:                              ; @.str.93
	.asciz	"I require at least one checked return per function."

l_.str.94:                              ; @.str.94
	.asciz	"I reached my intermediate owner-field fact budget."

l_.str.95:                              ; @.str.95
	.asciz	"I reached my field-transfer work budget."

l_.str.96:                              ; @.str.96
	.asciz	"I require a valid state destination."

l_.str.97:                              ; @.str.97
	.asciz	"I reached my stack limit."

l_.str.98:                              ; @.str.98
	.asciz	"I require equal join stack heights."

l_.str.99:                              ; @.str.99
	.asciz	"I reached my state cell budget."

l_.str.100:                             ; @.str.100
	.asciz	"I could not allocate instruction state."

l_.str.101:                             ; @.str.101
	.asciz	"I require matching initialized owner identities at joins."

l_.str.102:                             ; @.str.102
	.asciz	"I require opcode metadata."

l_.str.103:                             ; @.str.103
	.asciz	"I require the declared return count."

l_.str.104:                             ; @.str.104
	.asciz	"I require an exact complete returned value."

l_.str.105:                             ; @.str.105
	.asciz	"I require complete operand stacks."

l_.str.106:                             ; @.str.106
	.asciz	"I reached my stack budget."

l_.str.107:                             ; @.str.107
	.asciz	"I require bounded scalar operand rows."

l_.str.108:                             ; @.str.108
	.asciz	"I require modeled scalar operand alternatives."

l_.str.109:                             ; @.str.109
	.asciz	"I require exact typed scalar operands or a checked optional FLOAT comparison."

l_.str.110:                             ; @.str.110
	.asciz	"I do not duplicate owners or observations."

l_.str.111:                             ; @.str.111
	.asciz	"I require explicit owner consumption."

l_.str.112:                             ; @.str.112
	.asciz	"I require initialized exact local alternatives."

l_.str.113:                             ; @.str.113
	.asciz	"I require an exact ordinary local store."

l_.str.114:                             ; @.str.114
	.asciz	"I keep an observed owner live until projection completes."

l_.str.115:                             ; @.str.115
	.asciz	"I require an intact exact owner source."

l_.str.116:                             ; @.str.116
	.asciz	"I require an empty exact owner destination."

l_.str.117:                             ; @.str.117
	.asciz	"I require exact owner constructor field facts."

l_.str.118:                             ; @.str.118
	.asciz	"I require exact constructor path counts."

l_.str.119:                             ; @.str.119
	.asciz	"I require a live exact owner observation."

l_.str.120:                             ; @.str.120
	.asciz	"I require exact FLOAT literal elements."

l_.str.121:                             ; @.str.121
	.asciz	"I require concrete or conditional FLOAT array origins."

l_.str.122:                             ; @.str.122
	.asciz	"I require exact INT indices."

l_.str.123:                             ; @.str.123
	.asciz	"I require FLOAT writes through every alias."

l_.str.124:                             ; @.str.124
	.asciz	"I require exact positional call field facts."

l_.str.125:                             ; @.str.125
	.asciz	"I require exact INT output operands."

l_.str.126:                             ; @.str.126
	.asciz	"I require exact BOOL control operands."

l_.str.127:                             ; @.str.127
	.asciz	"I require an explicit origin transfer."

l_.str.128:                             ; @.str.128
	.asciz	"I require every owner ARRAY path origin."

l_.str.129:                             ; @.str.129
	.asciz	"I require positive ARRAY origins."

l_.str.130:                             ; @.str.130
	.asciz	"I require an existing exact owner field."

l_.str.131:                             ; @.str.131
	.asciz	"I require one direct ARRAY leaf."

l_.str.132:                             ; @.str.132
	.asciz	"I require exact child path expansion."

l_.str.133:                             ; @.str.133
	.asciz	"I refuse an unbound callee formal bit."

l_.str.134:                             ; @.str.134
	.asciz	"I require exact actual nominal path indexing."

l_.str.135:                             ; @.str.135
	.asciz	"I require initialized actual field origins."

.subsections_via_symbols
