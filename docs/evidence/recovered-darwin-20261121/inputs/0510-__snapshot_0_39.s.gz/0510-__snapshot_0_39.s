	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_val_print                      ; -- Begin function val_print
	.p2align	2
_val_print:                             ; @val_print
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-8]
	stur	x2, [x29, #-24]
	ldurb	w8, [x29, #-16]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	subs	x8, x8, #15
	b.hi	LBB0_69
; %bb.1:
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	adrp	x10, lJTI0_0@PAGE
	add	x10, x10, lJTI0_0@PAGEOFF
Ltmp0:
	adr	x8, Ltmp0
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB0_2:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_3:
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-8]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_4:
	ldur	x0, [x29, #-24]
	ldurb	w10, [x29, #-8]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_5:
	ldur	d0, [x29, #-8]
	stur	d0, [x29, #-32]
	ldur	d0, [x29, #-32]
	bl	_nano_rt_f64_nonfinite
	stur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	cbz	x8, LBB0_7
	b	LBB0_6
LBB0_6:
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-24]
	bl	_fputs
	b	LBB0_13
LBB0_7:
	ldur	d0, [x29, #-32]
	mov	x8, #640942080                  ; =0x26340000
	movk	x8, #27637, lsl #32
	movk	x8, #49932, lsl #48
	fmov	d1, x8
	fcmp	d0, d1
	b.lt	LBB0_11
	b	LBB0_8
LBB0_8:
	ldur	d0, [x29, #-32]
	mov	x8, #640942080                  ; =0x26340000
	movk	x8, #27637, lsl #32
	movk	x8, #17164, lsl #48
	fmov	d1, x8
	fcmp	d0, d1
	b.hi	LBB0_11
	b	LBB0_9
LBB0_9:
	ldur	d0, [x29, #-32]
	ldur	d1, [x29, #-32]
	fcvtzs	d1, d1
	scvtf	d1, d1
	fcmp	d0, d1
	b.ne	LBB0_11
	b	LBB0_10
LBB0_10:
	ldur	x0, [x29, #-24]
	ldur	d0, [x29, #-32]
	mov	x8, sp
	str	d0, [x8]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_fprintf
	b	LBB0_12
LBB0_11:
	ldur	x0, [x29, #-24]
	ldur	d0, [x29, #-32]
	mov	x8, sp
	str	d0, [x8]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_fprintf
	b	LBB0_12
LBB0_12:
	b	LBB0_13
LBB0_13:
	b	LBB0_70
LBB0_14:
	ldur	x0, [x29, #-24]
	ldurb	w10, [x29, #-8]
	adrp	x9, l_.str.7@PAGE
	add	x9, x9, l_.str.7@PAGEOFF
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	x8, x8, x9, ne
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_15:
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_17
	b	LBB0_16
LBB0_16:
	ldur	x8, [x29, #-24]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-8]
	bl	_vmstring_cstr
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_fprintf
	b	LBB0_18
LBB0_17:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_fprintf
	b	LBB0_18
LBB0_18:
	b	LBB0_70
LBB0_19:
	ldur	x1, [x29, #-24]
	adrp	x0, l_.str.9@PAGE
	add	x0, x0, l_.str.9@PAGEOFF
	bl	_fputs
	b	LBB0_70
LBB0_20:
	ldur	x0, [x29, #-24]
	ldur	w8, [x29, #-8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_21:
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_29
	b	LBB0_22
LBB0_22:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.11@PAGE
	add	x1, x1, l_.str.11@PAGEOFF
	bl	_fprintf
	stur	wzr, [x29, #-44]
	b	LBB0_23
LBB0_23:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB0_28
	b	LBB0_24
LBB0_24:                                ;   in Loop: Header=BB0_23 Depth=1
	ldur	w8, [x29, #-44]
	subs	w8, w8, #0
	b.ls	LBB0_26
	b	LBB0_25
LBB0_25:                                ;   in Loop: Header=BB0_23 Depth=1
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_fprintf
	b	LBB0_26
LBB0_26:                                ;   in Loop: Header=BB0_23 Depth=1
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-44]
	bl	_vm_array_get
	str	x0, [sp, #64]
	str	x1, [sp, #72]
	ldur	x2, [x29, #-24]
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #72]
	bl	_val_print
	b	LBB0_27
LBB0_27:                                ;   in Loop: Header=BB0_23 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB0_23
LBB0_28:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.13@PAGE
	add	x1, x1, l_.str.13@PAGEOFF
	bl	_fprintf
	b	LBB0_30
LBB0_29:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.14@PAGE
	add	x1, x1, l_.str.14@PAGEOFF
	bl	_fprintf
	b	LBB0_30
LBB0_30:
	b	LBB0_70
LBB0_31:
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_42
	b	LBB0_32
LBB0_32:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.15@PAGE
	add	x1, x1, l_.str.15@PAGEOFF
	bl	_fprintf
	str	wzr, [sp, #60]
	b	LBB0_33
LBB0_33:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB0_41
	b	LBB0_34
LBB0_34:                                ;   in Loop: Header=BB0_33 Depth=1
	ldr	w8, [sp, #60]
	subs	w8, w8, #0
	b.ls	LBB0_36
	b	LBB0_35
LBB0_35:                                ;   in Loop: Header=BB0_33 Depth=1
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_fprintf
	b	LBB0_36
LBB0_36:                                ;   in Loop: Header=BB0_33 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB0_39
	b	LBB0_37
LBB0_37:                                ;   in Loop: Header=BB0_33 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB0_39
	b	LBB0_38
LBB0_38:                                ;   in Loop: Header=BB0_33 Depth=1
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_vmstring_cstr
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	b	LBB0_39
LBB0_39:                                ;   in Loop: Header=BB0_33 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #24]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldur	x2, [x29, #-24]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_val_print
	b	LBB0_40
LBB0_40:                                ;   in Loop: Header=BB0_33 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB0_33
LBB0_41:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.17@PAGE
	add	x1, x1, l_.str.17@PAGEOFF
	bl	_fprintf
	b	LBB0_43
LBB0_42:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.18@PAGE
	add	x1, x1, l_.str.18@PAGEOFF
	bl	_fprintf
	b	LBB0_43
LBB0_43:
	b	LBB0_70
LBB0_44:
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_50
	b	LBB0_45
LBB0_45:
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-8]
	ldrh	w10, [x8, #12]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.19@PAGE
	add	x1, x1, l_.str.19@PAGEOFF
	bl	_fprintf
	str	wzr, [sp, #56]
	b	LBB0_46
LBB0_46:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #56]
	ldur	x9, [x29, #-8]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.hs	LBB0_49
	b	LBB0_47
LBB0_47:                                ;   in Loop: Header=BB0_46 Depth=1
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_fprintf
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldur	x2, [x29, #-24]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_val_print
	b	LBB0_48
LBB0_48:                                ;   in Loop: Header=BB0_46 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB0_46
LBB0_49:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_fprintf
	b	LBB0_51
LBB0_50:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.21@PAGE
	add	x1, x1, l_.str.21@PAGEOFF
	bl	_fprintf
	b	LBB0_51
LBB0_51:
	b	LBB0_70
LBB0_52:
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_60
	b	LBB0_53
LBB0_53:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.22@PAGE
	add	x1, x1, l_.str.22@PAGEOFF
	bl	_fprintf
	str	wzr, [sp, #52]
	b	LBB0_54
LBB0_54:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB0_59
	b	LBB0_55
LBB0_55:                                ;   in Loop: Header=BB0_54 Depth=1
	ldr	w8, [sp, #52]
	subs	w8, w8, #0
	b.ls	LBB0_57
	b	LBB0_56
LBB0_56:                                ;   in Loop: Header=BB0_54 Depth=1
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_fprintf
	b	LBB0_57
LBB0_57:                                ;   in Loop: Header=BB0_54 Depth=1
	ldur	x8, [x29, #-8]
	add	x8, x8, #16
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldur	x2, [x29, #-24]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_val_print
	b	LBB0_58
LBB0_58:                                ;   in Loop: Header=BB0_54 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB0_54
LBB0_59:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_fprintf
	b	LBB0_61
LBB0_60:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.23@PAGE
	add	x1, x1, l_.str.23@PAGEOFF
	bl	_fprintf
	b	LBB0_61
LBB0_61:
	b	LBB0_70
LBB0_62:
	ldur	x0, [x29, #-24]
	adrp	x1, l_.str.24@PAGE
	add	x1, x1, l_.str.24@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_63:
	ldur	x0, [x29, #-24]
	ldur	w8, [x29, #-8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.25@PAGE
	add	x1, x1, l_.str.25@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_64:
	ldur	x8, [x29, #-24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	cbz	x8, LBB0_66
	b	LBB0_65
LBB0_65:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #8]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_67
LBB0_66:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_67
LBB0_67:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.26@PAGE
	add	x1, x1, l_.str.26@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_68:
	ldur	x0, [x29, #-24]
	ldur	w8, [x29, #-8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.27@PAGE
	add	x1, x1, l_.str.27@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_69:
	ldur	x0, [x29, #-24]
	ldurb	w10, [x29, #-16]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.28@PAGE
	add	x1, x1, l_.str.28@PAGEOFF
	bl	_fprintf
	b	LBB0_70
LBB0_70:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
	.p2align	2
lJTI0_0:
	.long	LBB0_2-Ltmp0
	.long	LBB0_3-Ltmp0
	.long	LBB0_4-Ltmp0
	.long	LBB0_5-Ltmp0
	.long	LBB0_14-Ltmp0
	.long	LBB0_15-Ltmp0
	.long	LBB0_19-Ltmp0
	.long	LBB0_21-Ltmp0
	.long	LBB0_31-Ltmp0
	.long	LBB0_20-Ltmp0
	.long	LBB0_44-Ltmp0
	.long	LBB0_63-Ltmp0
	.long	LBB0_52-Ltmp0
	.long	LBB0_62-Ltmp0
	.long	LBB0_68-Ltmp0
	.long	LBB0_64-Ltmp0
                                        ; -- End function
	.p2align	2                               ; -- Begin function nano_rt_f64_nonfinite
_nano_rt_f64_nonfinite:                 ; @nano_rt_f64_nonfinite
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	d0, [sp, #16]
	ldr	d0, [sp, #16]
	str	d0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	x9, #9218868437227405312        ; =0x7ff0000000000000
	and	x8, x8, #0x7ff0000000000000
	subs	x8, x8, x9
	b.eq	LBB1_2
	b	LBB1_1
LBB1_1:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB1_5
LBB1_2:
	ldr	x8, [sp, #8]
	and	x8, x8, #0xfffffffffffff
	cbz	x8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldr	x8, [sp, #8]
	lsr	x10, x8, #63
	adrp	x9, l_.str.32@PAGE
	add	x9, x9, l_.str.32@PAGEOFF
	adrp	x8, l_.str.31@PAGE
	add	x8, x8, l_.str.31@PAGEOFF
	subs	x10, x10, #0
	csel	x8, x8, x9, ne
	str	x8, [sp, #24]
	b	LBB1_5
LBB1_4:
	ldr	x8, [sp, #8]
	lsr	x10, x8, #63
	adrp	x9, l_.str.34@PAGE
	add	x9, x9, l_.str.34@PAGEOFF
	adrp	x8, l_.str.33@PAGE
	add	x8, x8, l_.str.33@PAGEOFF
	subs	x10, x10, #0
	csel	x8, x8, x9, ne
	str	x8, [sp, #24]
	b	LBB1_5
LBB1_5:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_val_println                    ; -- Begin function val_println
	.p2align	2
_val_println:                           ; @val_println
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	str	x1, [sp, #8]
	adrp	x8, ___stdoutp@GOTPAGE
	ldr	x8, [x8, ___stdoutp@GOTPAGEOFF]
	ldr	x2, [x8]
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	bl	_val_print
	adrp	x0, l_.str.29@PAGE
	add	x0, x0, l_.str.29@PAGEOFF
	bl	_printf
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_val_equal                      ; -- Begin function val_equal
	.p2align	2
_val_equal:                             ; @val_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
	str	x3, [sp, #32]
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #14
	b.ne	LBB3_5
	b	LBB3_1
LBB3_1:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #1
	b.ne	LBB3_5
	b	LBB3_2
LBB3_2:
	ldur	x8, [x29, #-16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbnz	x8, LBB3_4
	b	LBB3_3
LBB3_3:
	ldr	x8, [sp, #32]
	subs	x8, x8, #0
	cset	w8, eq
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB3_4
LBB3_4:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_5:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #1
	b.ne	LBB3_10
	b	LBB3_6
LBB3_6:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #14
	b.ne	LBB3_10
	b	LBB3_7
LBB3_7:
	ldur	x8, [x29, #-16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbnz	x8, LBB3_9
	b	LBB3_8
LBB3_8:
	ldr	x8, [sp, #32]
	subs	x8, x8, #0
	cset	w8, eq
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB3_9
LBB3_9:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_10:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #9
	b.ne	LBB3_13
	b	LBB3_11
LBB3_11:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #1
	b.ne	LBB3_13
	b	LBB3_12
LBB3_12:
	ldursw	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_13:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #1
	b.ne	LBB3_16
	b	LBB3_14
LBB3_14:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #9
	b.ne	LBB3_16
	b	LBB3_15
LBB3_15:
	ldur	x8, [x29, #-16]
	ldrsw	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_16:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #1
	b.ne	LBB3_19
	b	LBB3_17
LBB3_17:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #3
	b.ne	LBB3_19
	b	LBB3_18
LBB3_18:
	ldur	d0, [x29, #-16]
	scvtf	d0, d0
	ldr	d1, [sp, #32]
	fcmp	d0, d1
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_19:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #3
	b.ne	LBB3_22
	b	LBB3_20
LBB3_20:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #1
	b.ne	LBB3_22
	b	LBB3_21
LBB3_21:
	ldur	d0, [x29, #-16]
	ldr	d1, [sp, #32]
	scvtf	d1, d1
	fcmp	d0, d1
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_22:
	ldurb	w8, [x29, #-24]
	ldrb	w9, [sp, #24]
	subs	w8, w8, w9
	b.eq	LBB3_24
	b	LBB3_23
LBB3_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_24:
	ldurb	w8, [x29, #-24]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	cbz	w8, LBB3_32
	b	LBB3_25
LBB3_25:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB3_33
	b	LBB3_26
LBB3_26:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB3_34
	b	LBB3_27
LBB3_27:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB3_35
	b	LBB3_28
LBB3_28:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB3_36
	b	LBB3_29
LBB3_29:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB3_41
	b	LBB3_30
LBB3_30:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #9
	b.eq	LBB3_37
	b	LBB3_31
LBB3_31:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #11
	b.eq	LBB3_38
	b	LBB3_47
LBB3_32:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_33:
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_34:
	ldurb	w8, [x29, #-16]
	ldrb	w9, [sp, #32]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_35:
	ldur	d0, [x29, #-16]
	ldr	d1, [sp, #32]
	fcmp	d0, d1
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_36:
	ldurb	w8, [x29, #-16]
	and	w8, w8, #0x1
	ldrb	w9, [sp, #32]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_37:
	ldur	w8, [x29, #-16]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_38:
	ldur	w9, [x29, #-20]
	ldr	w10, [sp, #28]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB3_40
	b	LBB3_39
LBB3_39:
	ldur	w8, [x29, #-16]
	ldr	w9, [sp, #32]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB3_40
LBB3_40:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_41:
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	b.ne	LBB3_43
	b	LBB3_42
LBB3_42:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_43:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB3_45
	b	LBB3_44
LBB3_44:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB3_46
	b	LBB3_45
LBB3_45:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_46:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_vmstring_equal
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_47:
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #32]
	subs	x8, x8, x9
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB3_48
LBB3_48:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_val_compare                    ; -- Begin function val_compare
	.p2align	2
_val_compare:                           ; @val_compare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	stur	x2, [x29, #-40]
	stur	x3, [x29, #-32]
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #11
	b.ne	LBB4_8
	b	LBB4_1
LBB4_1:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #11
	b.ne	LBB4_8
	b	LBB4_2
LBB4_2:
	ldur	w8, [x29, #-20]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.eq	LBB4_4
	b	LBB4_3
LBB4_3:
	ldur	w9, [x29, #-20]
	ldur	w10, [x29, #-36]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	csinv	w8, w8, wzr, hs
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_4:
	ldur	w8, [x29, #-16]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.hs	LBB4_6
	b	LBB4_5
LBB4_5:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB4_7
LBB4_6:
	ldur	w9, [x29, #-16]
	ldur	w10, [x29, #-32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	csinc	w8, w8, wzr, ls
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB4_7
LBB4_7:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_8:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #9
	b.ne	LBB4_14
	b	LBB4_9
LBB4_9:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #1
	b.ne	LBB4_14
	b	LBB4_10
LBB4_10:
	ldursw	x8, [x29, #-16]
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	b.ge	LBB4_12
	b	LBB4_11
LBB4_11:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB4_13
LBB4_12:
	ldr	x9, [sp, #48]
	ldur	x10, [x29, #-32]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	csinc	w8, w8, wzr, le
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB4_13
LBB4_13:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_14:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #1
	b.ne	LBB4_20
	b	LBB4_15
LBB4_15:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #9
	b.ne	LBB4_20
	b	LBB4_16
LBB4_16:
	ldursw	x8, [x29, #-32]
	str	x8, [sp, #40]
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #40]
	subs	x8, x8, x9
	b.ge	LBB4_18
	b	LBB4_17
LBB4_17:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB4_19
LBB4_18:
	ldur	x9, [x29, #-16]
	ldr	x10, [sp, #40]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	csinc	w8, w8, wzr, le
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB4_19
LBB4_19:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_20:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #1
	b.ne	LBB4_26
	b	LBB4_21
LBB4_21:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #3
	b.ne	LBB4_26
	b	LBB4_22
LBB4_22:
	ldur	d0, [x29, #-16]
	scvtf	d0, d0
	str	d0, [sp, #32]
	ldr	d0, [sp, #32]
	ldur	d1, [x29, #-32]
	fcmp	d0, d1
	b.pl	LBB4_24
	b	LBB4_23
LBB4_23:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_25
LBB4_24:
	ldr	d0, [sp, #32]
	ldur	d1, [x29, #-32]
	mov	w8, #0                          ; =0x0
	fcmp	d0, d1
	csinc	w8, w8, wzr, le
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_25
LBB4_25:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_26:
	ldurb	w8, [x29, #-24]
	subs	w8, w8, #3
	b.ne	LBB4_32
	b	LBB4_27
LBB4_27:
	ldurb	w8, [x29, #-40]
	subs	w8, w8, #1
	b.ne	LBB4_32
	b	LBB4_28
LBB4_28:
	ldur	d0, [x29, #-32]
	scvtf	d0, d0
	str	d0, [sp, #24]
	ldur	d0, [x29, #-16]
	ldr	d1, [sp, #24]
	fcmp	d0, d1
	b.pl	LBB4_30
	b	LBB4_29
LBB4_29:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB4_31
LBB4_30:
	ldur	d0, [x29, #-16]
	ldr	d1, [sp, #24]
	mov	w8, #0                          ; =0x0
	fcmp	d0, d1
	csinc	w8, w8, wzr, le
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB4_31
LBB4_31:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_32:
	ldurb	w8, [x29, #-24]
	ldurb	w9, [x29, #-40]
	subs	w8, w8, w9
	b.eq	LBB4_34
	b	LBB4_33
LBB4_33:
	ldurb	w8, [x29, #-24]
	ldurb	w9, [x29, #-40]
	subs	w8, w8, w9
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_34:
	ldurb	w8, [x29, #-24]
	str	w8, [sp]                        ; 4-byte Folded Spill
	subs	w8, w8, #1
	b.eq	LBB4_40
	b	LBB4_35
LBB4_35:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB4_39
	b	LBB4_36
LBB4_36:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB4_45
	b	LBB4_37
LBB4_37:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB4_50
	b	LBB4_38
LBB4_38:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB4_51
	b	LBB4_58
LBB4_39:
	ldurb	w8, [x29, #-16]
	ldurb	w9, [x29, #-32]
	subs	w8, w8, w9
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_40:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	b.ge	LBB4_42
	b	LBB4_41
LBB4_41:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_42:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	b.le	LBB4_44
	b	LBB4_43
LBB4_43:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_44:
	stur	wzr, [x29, #-4]
	b	LBB4_59
LBB4_45:
	ldur	d0, [x29, #-16]
	ldur	d1, [x29, #-32]
	fcmp	d0, d1
	b.pl	LBB4_47
	b	LBB4_46
LBB4_46:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_47:
	ldur	d0, [x29, #-16]
	ldur	d1, [x29, #-32]
	fcmp	d0, d1
	b.le	LBB4_49
	b	LBB4_48
LBB4_48:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_49:
	stur	wzr, [x29, #-4]
	b	LBB4_59
LBB4_50:
	ldurb	w8, [x29, #-16]
	and	w8, w8, #0x1
	ldurb	w9, [x29, #-32]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_51:
	ldur	x8, [x29, #-16]
	ldur	x9, [x29, #-32]
	subs	x8, x8, x9
	b.ne	LBB4_53
	b	LBB4_52
LBB4_52:
	stur	wzr, [x29, #-4]
	b	LBB4_59
LBB4_53:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB4_55
	b	LBB4_54
LBB4_54:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_55:
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB4_57
	b	LBB4_56
LBB4_56:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB4_59
LBB4_57:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	bl	_vmstring_compare
	stur	w0, [x29, #-4]
	b	LBB4_59
LBB4_58:
	stur	wzr, [x29, #-4]
	b	LBB4_59
LBB4_59:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_val_truthy                     ; -- Begin function val_truthy
	.p2align	2
_val_truthy:                            ; @val_truthy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]
	str	x1, [sp, #16]
	ldrb	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB5_6
	b	LBB5_1
LBB5_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB5_7
	b	LBB5_2
LBB5_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB5_8
	b	LBB5_3
LBB5_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB5_9
	b	LBB5_4
LBB5_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB5_10
	b	LBB5_5
LBB5_5:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB5_11
	b	LBB5_12
LBB5_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_7:
	ldr	x8, [sp, #16]
	subs	x8, x8, #0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_8:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_9:
	ldr	d0, [sp, #16]
	fcmp	d0, #0.0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_10:
	ldrb	w8, [sp, #16]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_11:
	ldr	x8, [sp, #16]
	subs	x8, x8, #0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_12:
	ldr	x8, [sp, #16]
	subs	x8, x8, #0
	cset	w8, ne
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB5_13
LBB5_13:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_val_to_cstring                 ; -- Begin function val_to_cstring
	.p2align	2
_val_to_cstring:                        ; @val_to_cstring
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #48]
	str	x1, [sp, #56]
	ldrb	w8, [sp, #48]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	cbz	w8, LBB6_5
	b	LBB6_1
LBB6_1:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB6_6
	b	LBB6_2
LBB6_2:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB6_7
	b	LBB6_3
LBB6_3:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB6_8
	b	LBB6_4
LBB6_4:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB6_9
	b	LBB6_12
LBB6_5:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_6:
	ldr	x8, [sp, #56]
	mov	x9, sp
	str	x8, [x9]
	add	x0, sp, #72
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x3, #256                        ; =0x100
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_7:
	ldr	d0, [sp, #56]
	add	x0, sp, #72
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x1, #256                        ; =0x100
	bl	_nano_rt_f64_format
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_8:
	ldrb	w10, [sp, #56]
	adrp	x9, l_.str.7@PAGE
	add	x9, x9, l_.str.7@PAGEOFF
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	x0, x8, x9, ne
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_9:
	ldr	x8, [sp, #56]
	cbz	x8, LBB6_11
	b	LBB6_10
LBB6_10:
	ldr	x0, [sp, #56]
	bl	_vmstring_cstr
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_11:
	adrp	x0, l_.str.8@PAGE
	add	x0, x0, l_.str.8@PAGEOFF
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_12:
	ldrb	w0, [sp, #48]
	bl	_isa_tag_name
	mov	x8, sp
	str	x0, [x8]
	add	x0, sp, #72
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x3, #256                        ; =0x100
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.30@PAGE
	add	x4, x4, l_.str.30@PAGEOFF
	bl	___snprintf_chk
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_strdup
	str	x0, [sp, #64]
	b	LBB6_13
LBB6_13:
	ldr	x8, [sp, #64]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB6_15
	b	LBB6_14
LBB6_14:
	bl	___stack_chk_fail
LBB6_15:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nano_rt_f64_format
_nano_rt_f64_format:                    ; @nano_rt_f64_format
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	d0, [sp, #24]
	ldr	d0, [sp, #24]
	bl	_nano_rt_f64_nonfinite
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldr	x8, [sp, #16]
	mov	x9, sp
	str	x8, [x9]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_3
LBB7_2:
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldr	d0, [sp, #24]
	mov	x8, sp
	str	d0, [x8]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.4@PAGE
	add	x4, x4, l_.str.4@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB7_3
LBB7_3:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"void"

l_.str.1:                               ; @.str.1
	.asciz	"%lld"

l_.str.2:                               ; @.str.2
	.asciz	"%u"

l_.str.3:                               ; @.str.3
	.asciz	"%.1f"

l_.str.4:                               ; @.str.4
	.asciz	"%g"

l_.str.5:                               ; @.str.5
	.asciz	"%s"

l_.str.6:                               ; @.str.6
	.asciz	"true"

l_.str.7:                               ; @.str.7
	.asciz	"false"

l_.str.8:                               ; @.str.8
	.asciz	"null"

l_.str.9:                               ; @.str.9
	.asciz	"<bstring>"

l_.str.10:                              ; @.str.10
	.asciz	"enum(%d)"

l_.str.11:                              ; @.str.11
	.asciz	"["

l_.str.12:                              ; @.str.12
	.asciz	", "

l_.str.13:                              ; @.str.13
	.asciz	"]"

l_.str.14:                              ; @.str.14
	.asciz	"[]"

l_.str.15:                              ; @.str.15
	.asciz	"{"

l_.str.16:                              ; @.str.16
	.asciz	"%s: "

l_.str.17:                              ; @.str.17
	.asciz	"}"

l_.str.18:                              ; @.str.18
	.asciz	"{}"

l_.str.19:                              ; @.str.19
	.asciz	"variant(%u"

l_.str.20:                              ; @.str.20
	.asciz	")"

l_.str.21:                              ; @.str.21
	.asciz	"union(null)"

l_.str.22:                              ; @.str.22
	.asciz	"("

l_.str.23:                              ; @.str.23
	.asciz	"()"

l_.str.24:                              ; @.str.24
	.asciz	"hashmap(...)"

l_.str.25:                              ; @.str.25
	.asciz	"fn(%u)"

l_.str.26:                              ; @.str.26
	.asciz	"closure(%u)"

l_.str.27:                              ; @.str.27
	.asciz	"opaque(%u)"

l_.str.28:                              ; @.str.28
	.asciz	"unknown(%u)"

l_.str.29:                              ; @.str.29
	.asciz	"\n"

l_.str.30:                              ; @.str.30
	.asciz	"<%s>"

l_.str.31:                              ; @.str.31
	.asciz	"-nan"

l_.str.32:                              ; @.str.32
	.asciz	"nan"

l_.str.33:                              ; @.str.33
	.asciz	"-inf"

l_.str.34:                              ; @.str.34
	.asciz	"inf"

.subsections_via_symbols
