	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_imports_decode  ; -- Begin function nvm_v2_imports_decode
	.globl	_nvm_v2_imports_decode
	.p2align	2
_nvm_v2_imports_decode:                 ; @nvm_v2_imports_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB0_2
LBB0_1:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB0_2:
	ldr	w8, [sp, #4]
	cbz	w8, LBB0_19
; %bb.3:
	ldr	x9, [sp, #24]
	sub	x9, x20, x9
	lsr	x9, x9, #4
	cmp	x9, x8
	cset	w0, lo
	b.lo	LBB0_1
; %bb.4:
	mov	x0, x8
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB0_20
; %bb.5:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	add	x21, x0, #8
LBB0_6:                                 ; =>This Inner Loop Header: Depth=1
	sub	x1, x21, #8
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.7:                                ;   in Loop: Header=BB0_6 Depth=1
	sub	x1, x21, #4
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.8:                                ;   in Loop: Header=BB0_6 Depth=1
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_22
; %bb.9:                                ;   in Loop: Header=BB0_6 Depth=1
	add	x0, sp, #8
	add	x1, sp, #3
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_22
; %bb.10:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x0, sp, #8
	add	x1, sp, #2
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_22
; %bb.11:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x0, sp, #8
	add	x1, sp, #1
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_22
; %bb.12:                               ;   in Loop: Header=BB0_6 Depth=1
	add	x0, sp, #8
	mov	x1, sp
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_22
; %bb.13:                               ;   in Loop: Header=BB0_6 Depth=1
	ldrb	w8, [sp, #3]
	cmp	w8, #3
	b.hi	LBB0_21
; %bb.14:                               ;   in Loop: Header=BB0_6 Depth=1
	ldrb	w9, [sp, #2]
	mov	w0, #7                          ; =0x7
	cbnz	w9, LBB0_22
; %bb.15:                               ;   in Loop: Header=BB0_6 Depth=1
	ldrb	w9, [sp, #1]
	cbnz	w9, LBB0_22
; %bb.16:                               ;   in Loop: Header=BB0_6 Depth=1
	ldrb	w9, [sp]
	cbnz	w9, LBB0_22
; %bb.17:                               ;   in Loop: Header=BB0_6 Depth=1
	strb	w8, [x21, #4]
	add	x22, x22, #1
	ldr	w8, [sp, #4]
	add	x21, x21, #16
	cmp	x22, x8
	b.lo	LBB0_6
; %bb.18:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB0_1
LBB0_19:
	mov	w0, #0                          ; =0x0
	b	LBB0_1
LBB0_20:
	mov	w0, #1                          ; =0x1
	b	LBB0_1
LBB0_21:
	mov	w0, #8                          ; =0x8
LBB0_22:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
	b	LBB0_1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_imports_free    ; -- Begin function nvm_v2_imports_free
	.globl	_nvm_v2_imports_free
	.p2align	2
_nvm_v2_imports_free:                   ; @nvm_v2_imports_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB1_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_imports_encoded_size ; -- Begin function nvm_v2_imports_encoded_size
	.globl	_nvm_v2_imports_encoded_size
	.p2align	2
_nvm_v2_imports_encoded_size:           ; @nvm_v2_imports_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #4
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_imports_encode  ; -- Begin function nvm_v2_imports_encode
	.globl	_nvm_v2_imports_encode
	.p2align	2
_nvm_v2_imports_encode:                 ; @nvm_v2_imports_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x1, x9, x8, lsl #4
	cmp	x2, x1
	b.hs	LBB3_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB3_6
LBB3_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB3_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	ldr	w10, [x10, x8]
	add	x11, x19, x8
	str	w10, [x11, #4]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldr	w10, [x10, #4]
	str	w10, [x11, #8]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldr	w10, [x10, #8]
	str	w10, [x11, #12]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldrb	w10, [x10, #12]
	strb	w10, [x11, #16]
	add	x9, x9, #1
	ldr	w10, [x20, #8]
	add	x8, x8, #16
	cmp	x9, x10
	b.lo	LBB3_4
LBB3_5:
	mov	w0, #0                          ; =0x0
LBB3_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_callbacks_decode ; -- Begin function nvm_v2_callbacks_decode
	.globl	_nvm_v2_callbacks_decode
	.p2align	2
_nvm_v2_callbacks_decode:               ; @nvm_v2_callbacks_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x2
	mov	x19, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x19
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB4_2
LBB4_1:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB4_2:
	ldr	w0, [sp, #4]
	cbz	w0, LBB4_5
; %bb.3:
	ldr	x8, [sp, #24]
	sub	x8, x19, x8
	cmp	x0, x8, lsr #4
	b.ls	LBB4_8
LBB4_4:
	mov	w0, #1                          ; =0x1
	b	LBB4_1
LBB4_5:
	ldr	x8, [sp, #24]
	cmp	x19, x8
	b.ne	LBB4_18
; %bb.6:
	mov	x19, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
LBB4_7:
	mov	w0, #0                          ; =0x0
	str	x19, [x20]
	str	w8, [x20, #8]
	b	LBB4_1
LBB4_8:
	cmp	x8, x0, lsl #4
	b.ne	LBB4_18
; %bb.9:
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB4_4
; %bb.10:
	mov	x19, x0
	add	x0, sp, #8
	mov	x1, x19
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_16
; %bb.11:
	add	x0, sp, #8
	add	x1, x19, #4
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_16
; %bb.12:
	add	x0, sp, #8
	add	x1, x19, #6
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_16
; %bb.13:
	add	x0, sp, #8
	add	x1, x19, #7
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_16
; %bb.14:
	add	x0, sp, #8
	add	x1, x19, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_16
; %bb.15:
	add	x0, sp, #8
	add	x1, x19, #12
	bl	_nvm_v2_u32
	cbz	w0, LBB4_19
LBB4_16:
	mov	x23, x0
LBB4_17:
	mov	x0, x19
	bl	_free
	mov	x0, x23
	b	LBB4_1
LBB4_18:
	mov	w0, #9                          ; =0x9
	b	LBB4_1
LBB4_19:
	ldurb	w8, [x19, #6]
	cmp	w8, #1
	b.ne	LBB4_21
; %bb.20:
	ldurb	w8, [x19, #7]
	cmp	w8, #1
	b.ls	LBB4_22
LBB4_21:
	mov	w23, #7                         ; =0x7
	b	LBB4_17
LBB4_22:
	ldr	w8, [sp, #4]
	cmp	w8, #2
	b.lo	LBB4_7
; %bb.23:
	mov	x21, #0                         ; =0x0
	mov	w22, #1                         ; =0x1
	b	LBB4_25
LBB4_24:                                ;   in Loop: Header=BB4_25 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #4]
	add	x21, x21, #16
	cmp	w22, w8
	b.hs	LBB4_7
LBB4_25:                                ; =>This Inner Loop Header: Depth=1
	add	x24, x19, x21
	add	x0, sp, #8
	add	x1, x24, #16
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_16
; %bb.26:                               ;   in Loop: Header=BB4_25 Depth=1
	add	x0, sp, #8
	add	x1, x24, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_16
; %bb.27:                               ;   in Loop: Header=BB4_25 Depth=1
	add	x25, x19, x21
	add	x0, sp, #8
	add	x1, x25, #22
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_16
; %bb.28:                               ;   in Loop: Header=BB4_25 Depth=1
	add	x0, sp, #8
	add	x1, x25, #23
	bl	_nvm_v2_u8
	cbnz	w0, LBB4_16
; %bb.29:                               ;   in Loop: Header=BB4_25 Depth=1
	add	x26, x19, x21
	add	x0, sp, #8
	add	x1, x26, #24
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_16
; %bb.30:                               ;   in Loop: Header=BB4_25 Depth=1
	add	x0, sp, #8
	add	x1, x26, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_16
; %bb.31:                               ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x25, #22]
	cmp	w8, #1
	b.ne	LBB4_21
; %bb.32:                               ;   in Loop: Header=BB4_25 Depth=1
	ldurb	w8, [x25, #23]
	cmp	w8, #1
	b.hi	LBB4_21
; %bb.33:                               ;   in Loop: Header=BB4_25 Depth=1
	ldur	w8, [x24, #16]
	ldr	w9, [x19, x21]
	cmp	w8, w9
	b.lo	LBB4_36
; %bb.34:                               ;   in Loop: Header=BB4_25 Depth=1
	b.ne	LBB4_24
; %bb.35:                               ;   in Loop: Header=BB4_25 Depth=1
	ldurh	w8, [x24, #20]
	add	x9, x19, x21
	ldrh	w9, [x9, #4]
	cmp	w8, w9
	b.hi	LBB4_24
LBB4_36:
	mov	w23, #13                        ; =0xd
	b	LBB4_17
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_callbacks_free  ; -- Begin function nvm_v2_callbacks_free
	.globl	_nvm_v2_callbacks_free
	.p2align	2
_nvm_v2_callbacks_free:                 ; @nvm_v2_callbacks_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB5_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_callbacks_encoded_size ; -- Begin function nvm_v2_callbacks_encoded_size
	.globl	_nvm_v2_callbacks_encoded_size
	.p2align	2
_nvm_v2_callbacks_encoded_size:         ; @nvm_v2_callbacks_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #4
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_callbacks_encode ; -- Begin function nvm_v2_callbacks_encode
	.globl	_nvm_v2_callbacks_encode
	.p2align	2
_nvm_v2_callbacks_encode:               ; @nvm_v2_callbacks_encode
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x9, x9, x8, lsl #4
	cmp	x2, x9
	b.hs	LBB7_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB7_2:
	str	w8, [x1]
	ldr	w8, [x0, #8]
	cbz	w8, LBB7_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB7_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x0]
	add	x10, x10, x8
	add	x11, x1, x8
	ldr	w12, [x10]
	str	w12, [x11, #4]
	ldrb	w12, [x10, #4]
	strb	w12, [x11, #8]
	ldrb	w12, [x10, #5]
	strb	w12, [x11, #9]
	ldrb	w12, [x10, #6]
	strb	w12, [x11, #10]
	ldrb	w12, [x10, #7]
	strb	w12, [x11, #11]
	ldr	w12, [x10, #8]
	str	w12, [x11, #12]
	ldr	w10, [x10, #12]
	str	w10, [x11, #16]
	add	x9, x9, #1
	ldr	w10, [x0, #8]
	add	x8, x8, #16
	cmp	x9, x10
	b.lo	LBB7_4
LBB7_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_links_decode    ; -- Begin function nvm_v2_links_decode
	.globl	_nvm_v2_links_decode
	.p2align	2
_nvm_v2_links_decode:                   ; @nvm_v2_links_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB8_2
LBB8_1:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB8_2:
	ldr	w8, [sp, #4]
	cbz	w8, LBB8_13
; %bb.3:
	ldr	x9, [sp, #24]
	sub	x9, x20, x9
	lsr	x9, x9, #4
	cmp	x9, x8
	cset	w0, lo
	b.lo	LBB8_1
; %bb.4:
	mov	x0, x8
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB8_16
; %bb.5:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	add	x21, x0, #12
LBB8_6:                                 ; =>This Inner Loop Header: Depth=1
	sub	x1, x21, #12
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_14
; %bb.7:                                ;   in Loop: Header=BB8_6 Depth=1
	sub	x1, x21, #8
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_14
; %bb.8:                                ;   in Loop: Header=BB8_6 Depth=1
	sub	x1, x21, #4
	add	x0, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_14
; %bb.9:                                ;   in Loop: Header=BB8_6 Depth=1
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB8_14
; %bb.10:                               ;   in Loop: Header=BB8_6 Depth=1
	ldr	w8, [x21], #16
	cmp	w8, #2
	b.hs	LBB8_17
; %bb.11:                               ;   in Loop: Header=BB8_6 Depth=1
	add	x22, x22, #1
	ldr	w8, [sp, #4]
	cmp	x22, x8
	b.lo	LBB8_6
; %bb.12:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB8_1
LBB8_13:
	mov	w0, #0                          ; =0x0
	b	LBB8_1
LBB8_14:
	mov	x19, x0
LBB8_15:
	mov	x0, x20
	bl	_free
	mov	x0, x19
	b	LBB8_1
LBB8_16:
	mov	w0, #1                          ; =0x1
	b	LBB8_1
LBB8_17:
	mov	w19, #7                         ; =0x7
	b	LBB8_15
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_links_free      ; -- Begin function nvm_v2_links_free
	.globl	_nvm_v2_links_free
	.p2align	2
_nvm_v2_links_free:                     ; @nvm_v2_links_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB9_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_links_encoded_size ; -- Begin function nvm_v2_links_encoded_size
	.globl	_nvm_v2_links_encoded_size
	.p2align	2
_nvm_v2_links_encoded_size:             ; @nvm_v2_links_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #4
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_links_encode    ; -- Begin function nvm_v2_links_encode
	.globl	_nvm_v2_links_encode
	.p2align	2
_nvm_v2_links_encode:                   ; @nvm_v2_links_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x1, x9, x8, lsl #4
	cmp	x2, x1
	b.hs	LBB11_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB11_6
LBB11_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB11_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB11_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	ldr	w10, [x10, x8]
	add	x11, x19, x8
	str	w10, [x11, #4]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldr	w10, [x10, #4]
	str	w10, [x11, #8]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldr	w10, [x10, #8]
	str	w10, [x11, #12]
	ldr	x10, [x20]
	add	x10, x10, x8
	ldr	w10, [x10, #12]
	str	w10, [x11, #16]
	add	x9, x9, #1
	ldr	w10, [x20, #8]
	add	x8, x8, #16
	cmp	x9, x10
	b.lo	LBB11_4
LBB11_5:
	mov	w0, #0                          ; =0x0
LBB11_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_metadata_decode ; -- Begin function nvm_v2_metadata_decode
	.globl	_nvm_v2_metadata_decode
	.p2align	2
_nvm_v2_metadata_decode:                ; @nvm_v2_metadata_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB12_2
LBB12_1:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB12_2:
	ldr	w8, [sp, #4]
	cbz	w8, LBB12_10
; %bb.3:
	ldr	x9, [sp, #24]
	sub	x9, x20, x9
	lsr	x9, x9, #3
	cmp	x9, x8
	cset	w0, lo
	b.lo	LBB12_1
; %bb.4:
	mov	x0, x8
	mov	w1, #8                          ; =0x8
	bl	_calloc
	cbz	x0, LBB12_12
; %bb.5:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	mov	x21, x0
LBB12_6:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u32
	cbnz	w0, LBB12_11
; %bb.7:                                ;   in Loop: Header=BB12_6 Depth=1
	add	x0, sp, #8
	add	x1, x21, #4
	bl	_nvm_v2_u32
	cbnz	w0, LBB12_11
; %bb.8:                                ;   in Loop: Header=BB12_6 Depth=1
	add	x22, x22, #1
	ldr	w8, [sp, #4]
	add	x21, x21, #8
	cmp	x22, x8
	b.lo	LBB12_6
; %bb.9:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB12_1
LBB12_10:
	mov	w0, #0                          ; =0x0
	b	LBB12_1
LBB12_11:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
	b	LBB12_1
LBB12_12:
	mov	w0, #1                          ; =0x1
	b	LBB12_1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_metadata_free   ; -- Begin function nvm_v2_metadata_free
	.globl	_nvm_v2_metadata_free
	.p2align	2
_nvm_v2_metadata_free:                  ; @nvm_v2_metadata_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB13_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_metadata_encoded_size ; -- Begin function nvm_v2_metadata_encoded_size
	.globl	_nvm_v2_metadata_encoded_size
	.p2align	2
_nvm_v2_metadata_encoded_size:          ; @nvm_v2_metadata_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #3
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_metadata_encode ; -- Begin function nvm_v2_metadata_encode
	.globl	_nvm_v2_metadata_encode
	.p2align	2
_nvm_v2_metadata_encode:                ; @nvm_v2_metadata_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x1, x9, x8, lsl #3
	cmp	x2, x1
	b.hs	LBB15_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB15_6
LBB15_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB15_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB15_4:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x8
	ldr	x11, [x20]
	ldr	w11, [x11, x8]
	str	w11, [x10, #4]
	ldr	x11, [x20]
	add	x11, x11, x8
	ldr	w11, [x11, #4]
	str	w11, [x10, #8]
	add	x9, x9, #1
	ldr	w10, [x20, #8]
	add	x8, x8, #8
	cmp	x9, x10
	b.lo	LBB15_4
LBB15_5:
	mov	w0, #0                          ; =0x0
LBB15_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_debug_decode    ; -- Begin function nvm_v2_debug_decode
	.globl	_nvm_v2_debug_decode
	.p2align	2
_nvm_v2_debug_decode:                   ; @nvm_v2_debug_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #8
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #8
	add	x1, sp, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB16_2
LBB16_1:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB16_2:
	ldr	w8, [sp, #4]
	cbz	w8, LBB16_11
; %bb.3:
	ldr	x9, [sp, #24]
	sub	x9, x20, x9
	lsr	x9, x9, #4
	cmp	x9, x8
	cset	w0, lo
	b.lo	LBB16_1
; %bb.4:
	mov	x0, x8
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB16_13
; %bb.5:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	mov	x21, x0
LBB16_6:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #8
	mov	x1, x21
	bl	_nvm_v2_u64
	cbnz	w0, LBB16_12
; %bb.7:                                ;   in Loop: Header=BB16_6 Depth=1
	add	x0, sp, #8
	add	x1, x21, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB16_12
; %bb.8:                                ;   in Loop: Header=BB16_6 Depth=1
	add	x0, sp, #8
	add	x1, x21, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB16_12
; %bb.9:                                ;   in Loop: Header=BB16_6 Depth=1
	add	x22, x22, #1
	ldr	w8, [sp, #4]
	add	x21, x21, #16
	cmp	x22, x8
	b.lo	LBB16_6
; %bb.10:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB16_1
LBB16_11:
	mov	w0, #0                          ; =0x0
	b	LBB16_1
LBB16_12:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
	b	LBB16_1
LBB16_13:
	mov	w0, #1                          ; =0x1
	b	LBB16_1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_debug_free      ; -- Begin function nvm_v2_debug_free
	.globl	_nvm_v2_debug_free
	.p2align	2
_nvm_v2_debug_free:                     ; @nvm_v2_debug_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB17_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_debug_encoded_size ; -- Begin function nvm_v2_debug_encoded_size
	.globl	_nvm_v2_debug_encoded_size
	.p2align	2
_nvm_v2_debug_encoded_size:             ; @nvm_v2_debug_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x0, x9, x8, lsl #4
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_debug_encode    ; -- Begin function nvm_v2_debug_encode
	.globl	_nvm_v2_debug_encode
	.p2align	2
_nvm_v2_debug_encode:                   ; @nvm_v2_debug_encode
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	ldr	w8, [x0, #8]
	mov	w9, #4                          ; =0x4
	orr	x1, x9, x8, lsl #4
	cmp	x2, x1
	b.hs	LBB19_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB19_6
LBB19_2:
	mov	x20, x0
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB19_5
; %bb.3:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB19_4:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x8
	ldr	x11, [x20]
	ldr	x11, [x11, x8]
	stur	x11, [x10, #4]
	ldr	x11, [x20]
	add	x11, x11, x8
	ldr	w11, [x11, #8]
	str	w11, [x10, #12]
	ldr	x11, [x20]
	add	x11, x11, x8
	ldr	w11, [x11, #12]
	str	w11, [x10, #16]
	add	x9, x9, #1
	ldr	w10, [x20, #8]
	add	x8, x8, #16
	cmp	x9, x10
	b.lo	LBB19_4
LBB19_5:
	mov	w0, #0                          ; =0x0
LBB19_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
