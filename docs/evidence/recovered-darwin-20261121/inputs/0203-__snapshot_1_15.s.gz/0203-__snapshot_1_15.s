	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_signature_equal ; -- Begin function nvm_v2_signature_equal
	.globl	_nvm_v2_signature_equal
	.p2align	2
_nvm_v2_signature_equal:                ; @nvm_v2_signature_equal
	.cfi_startproc
; %bb.0:
	ldrh	w2, [x0]
	ldrh	w8, [x1]
	cmp	w2, w8
	b.ne	LBB0_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldrh	w19, [x0, #2]
	ldrh	w8, [x1, #2]
	cmp	w19, w8
	b.ne	LBB0_6
; %bb.2:
	cbz	w2, LBB0_4
; %bb.3:
	ldr	x8, [x0, #8]
	ldr	x9, [x1, #8]
	mov	x20, x0
	mov	x0, x8
	mov	x21, x1
	mov	x1, x9
	bl	_memcmp
	mov	x1, x21
	mov	x8, x0
	mov	x0, x20
	cbnz	w8, LBB0_6
LBB0_4:
	cbz	w19, LBB0_9
; %bb.5:
	ldr	x0, [x0, #16]
	ldr	x1, [x1, #16]
	mov	x2, x19
	bl	_memcmp
	cbz	w0, LBB0_9
LBB0_6:
	mov	w0, #0                          ; =0x0
LBB0_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB0_8:
	mov	w0, #0                          ; =0x0
	ret
LBB0_9:
	mov	w0, #1                          ; =0x1
	b	LBB0_7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_signatures_decode ; -- Begin function nvm_v2_signatures_decode
	.globl	_nvm_v2_signatures_decode
	.p2align	2
_nvm_v2_signatures_decode:              ; @nvm_v2_signatures_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #16
	mov	x2, x20
	bl	_nvm_v2_cursor_init
	add	x0, sp, #16
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_24
; %bb.1:
	ldr	w0, [sp, #12]
	cbz	w0, LBB1_24
; %bb.2:
	ldr	x8, [sp, #32]
	sub	x8, x20, x8
	cmp	x0, x8, lsr #2
	b.hi	LBB1_21
; %bb.3:
	mov	w1, #24                         ; =0x18
	bl	_calloc
	cbz	x0, LBB1_21
; %bb.4:
	mov	x20, x0
	mov	x22, #0                         ; =0x0
	mov	w23, #24                        ; =0x18
LBB1_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_10 Depth 2
                                        ;     Child Loop BB1_16 Depth 2
	add	x0, sp, #16
	add	x1, sp, #10
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_23
; %bb.6:                                ;   in Loop: Header=BB1_5 Depth=1
	add	x0, sp, #16
	add	x1, sp, #8
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_23
; %bb.7:                                ;   in Loop: Header=BB1_5 Depth=1
	ldrh	w21, [sp, #10]
	str	xzr, [sp, #40]
	add	x0, sp, #16
	add	x2, sp, #40
	mov	x1, x21
	bl	_nvm_v2_take
	cbnz	w0, LBB1_23
; %bb.8:                                ;   in Loop: Header=BB1_5 Depth=1
	cbz	w21, LBB1_12
; %bb.9:                                ;   in Loop: Header=BB1_5 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, x21
LBB1_10:                                ;   Parent Loop BB1_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x8], #1
	cmp	w10, #15
	b.hi	LBB1_22
; %bb.11:                               ;   in Loop: Header=BB1_10 Depth=2
	subs	x9, x9, #1
	b.ne	LBB1_10
LBB1_12:                                ;   in Loop: Header=BB1_5 Depth=1
	add	x0, sp, #16
	bl	_nvm_v2_align4
	cbnz	w0, LBB1_23
; %bb.13:                               ;   in Loop: Header=BB1_5 Depth=1
	ldr	x8, [sp, #40]
	cmp	w21, #0
	csel	x24, xzr, x8, eq
	ldrh	w21, [sp, #8]
	str	xzr, [sp, #40]
	add	x0, sp, #16
	add	x2, sp, #40
	mov	x1, x21
	bl	_nvm_v2_take
	cbnz	w0, LBB1_23
; %bb.14:                               ;   in Loop: Header=BB1_5 Depth=1
	cbz	w21, LBB1_18
; %bb.15:                               ;   in Loop: Header=BB1_5 Depth=1
	ldr	x8, [sp, #40]
	mov	x9, x21
LBB1_16:                                ;   Parent Loop BB1_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x8], #1
	cmp	w10, #15
	b.hi	LBB1_22
; %bb.17:                               ;   in Loop: Header=BB1_16 Depth=2
	subs	x9, x9, #1
	b.ne	LBB1_16
LBB1_18:                                ;   in Loop: Header=BB1_5 Depth=1
	add	x0, sp, #16
	bl	_nvm_v2_align4
	cbnz	w0, LBB1_23
; %bb.19:                               ;   in Loop: Header=BB1_5 Depth=1
	ldr	x8, [sp, #40]
	cmp	w21, #0
	csel	x8, xzr, x8, eq
	ldrh	w9, [sp, #10]
	madd	x10, x22, x23, x20
	strh	w9, [x10]
	ldrh	w9, [sp, #8]
	strh	w9, [x10, #2]
	stp	x24, x8, [x10, #8]
	add	x22, x22, #1
	ldr	w8, [sp, #12]
	cmp	x22, x8
	b.lo	LBB1_5
; %bb.20:
	mov	w0, #0                          ; =0x0
	str	x20, [x19]
	str	w8, [x19, #8]
	b	LBB1_24
LBB1_21:
	mov	w0, #1                          ; =0x1
	b	LBB1_24
LBB1_22:
	mov	w0, #8                          ; =0x8
LBB1_23:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
LBB1_24:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_signatures_free ; -- Begin function nvm_v2_signatures_free
	.globl	_nvm_v2_signatures_free
	.p2align	2
_nvm_v2_signatures_free:                ; @nvm_v2_signatures_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB2_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_signatures_encoded_size ; -- Begin function nvm_v2_signatures_encoded_size
	.globl	_nvm_v2_signatures_encoded_size
	.p2align	2
_nvm_v2_signatures_encoded_size:        ; @nvm_v2_signatures_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	cbz	w8, LBB3_3
; %bb.1:
	ldr	x9, [x0]
	cmp	w8, #4
	b.hs	LBB3_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w0, #4                          ; =0x4
	b	LBB3_7
LBB3_3:
	mov	w0, #4                          ; =0x4
	ret
LBB3_4:
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x8, #0xfffffffc
	add	x11, x9, #48
	mov	w16, #4                         ; =0x4
	mov	x15, x10
LBB3_5:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w17, [x11, #-48]
	ldurh	w0, [x11, #-24]
	ldrh	w1, [x11]
	ldrh	w2, [x11, #24]
	add	w17, w17, #3
	add	w0, w0, #3
	add	w1, w1, #3
	add	w2, w2, #3
	and	x17, x17, #0x1fffc
	and	x0, x0, #0x1fffc
	and	x1, x1, #0x1fffc
	and	x2, x2, #0x1fffc
	ldurh	w3, [x11, #-46]
	ldurh	w4, [x11, #-22]
	ldrh	w5, [x11, #2]
	add	w3, w3, #3
	add	w4, w4, #3
	add	w5, w5, #3
	ldrh	w6, [x11, #26]
	add	w6, w6, #3
	and	x3, x3, #0x1fffc
	and	x4, x4, #0x1fffc
	and	x5, x5, #0x1fffc
	and	x6, x6, #0x1fffc
	add	x16, x16, x17
	add	x16, x16, x3
	add	x12, x12, x0
	add	x12, x12, x4
	add	x13, x13, x1
	add	x13, x13, x5
	add	x14, x14, x2
	add	x14, x14, x6
	add	x16, x16, #4
	add	x12, x12, #4
	add	x13, x13, #4
	add	x14, x14, #4
	add	x11, x11, #96
	subs	x15, x15, #4
	b.ne	LBB3_5
; %bb.6:
	add	x11, x12, x16
	add	x11, x13, x11
	add	x0, x14, x11
	cmp	x10, x8
	b.eq	LBB3_9
LBB3_7:
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	add	x9, x9, #2
	sub	x8, x8, x10
LBB3_8:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w10, [x9, #-2]
	add	w10, w10, #3
	and	x10, x10, #0x1fffc
	ldrh	w11, [x9], #24
	add	w11, w11, #3
	and	x11, x11, #0x1fffc
	add	x10, x0, x10
	add	x10, x10, x11
	add	x0, x10, #4
	subs	x8, x8, #1
	b.ne	LBB3_8
LBB3_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_signatures_encode ; -- Begin function nvm_v2_signatures_encode
	.globl	_nvm_v2_signatures_encode
	.p2align	2
_nvm_v2_signatures_encode:              ; @nvm_v2_signatures_encode
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x1
	mov	x20, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB4_3
; %bb.1:
	ldr	x9, [x20]
	cmp	w8, #4
	b.hs	LBB4_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w1, #4                          ; =0x4
	b	LBB4_7
LBB4_3:
	mov	w1, #4                          ; =0x4
	b	LBB4_9
LBB4_4:
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	x10, x8, #0xfffffffc
	add	x11, x9, #48
	mov	w16, #4                         ; =0x4
	mov	x15, x10
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w17, [x11, #-48]
	ldurh	w0, [x11, #-24]
	ldrh	w1, [x11]
	ldrh	w3, [x11, #24]
	add	w17, w17, #3
	add	w0, w0, #3
	add	w1, w1, #3
	add	w3, w3, #3
	and	x17, x17, #0x1fffc
	and	x0, x0, #0x1fffc
	and	x1, x1, #0x1fffc
	and	x3, x3, #0x1fffc
	ldurh	w4, [x11, #-46]
	ldurh	w5, [x11, #-22]
	ldrh	w6, [x11, #2]
	add	w4, w4, #3
	add	w5, w5, #3
	add	w6, w6, #3
	ldrh	w7, [x11, #26]
	add	w7, w7, #3
	and	x4, x4, #0x1fffc
	and	x5, x5, #0x1fffc
	and	x6, x6, #0x1fffc
	and	x7, x7, #0x1fffc
	add	x16, x16, x17
	add	x16, x16, x4
	add	x12, x12, x0
	add	x12, x12, x5
	add	x13, x13, x1
	add	x13, x13, x6
	add	x14, x14, x3
	add	x14, x14, x7
	add	x16, x16, #4
	add	x12, x12, #4
	add	x13, x13, #4
	add	x14, x14, #4
	add	x11, x11, #96
	subs	x15, x15, #4
	b.ne	LBB4_5
; %bb.6:
	add	x11, x12, x16
	add	x11, x13, x11
	add	x1, x14, x11
	cmp	x10, x8
	b.eq	LBB4_9
LBB4_7:
	sub	x8, x8, x10
	mov	w11, #24                        ; =0x18
	umaddl	x9, w10, w11, x9
	add	x9, x9, #2
LBB4_8:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w10, [x9, #-2]
	add	w10, w10, #3
	and	x10, x10, #0x1fffc
	ldrh	w11, [x9], #24
	add	w11, w11, #3
	and	x11, x11, #0x1fffc
	add	x10, x1, x10
	add	x10, x10, x11
	add	x1, x10, #4
	subs	x8, x8, #1
	b.ne	LBB4_8
LBB4_9:
	cmp	x2, x1
	b.hs	LBB4_11
; %bb.10:
	mov	w0, #1                          ; =0x1
	b	LBB4_20
LBB4_11:
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	strb	w8, [x19]
	ldr	w8, [x20, #8]
	lsr	w8, w8, #8
	strb	w8, [x19, #1]
	ldrh	w8, [x20, #10]
	strb	w8, [x19, #2]
	ldrb	w8, [x20, #11]
	strb	w8, [x19, #3]
	ldr	w8, [x20, #8]
	cbz	w8, LBB4_19
; %bb.12:
	mov	x23, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	w8, #4                          ; =0x4
	b	LBB4_15
LBB4_13:                                ;   in Loop: Header=BB4_15 Depth=1
	mov	x8, #0                          ; =0x0
LBB4_14:                                ;   in Loop: Header=BB4_15 Depth=1
	add	x8, x22, x8
	add	x24, x24, #1
	ldr	w9, [x20, #8]
	add	x23, x23, #24
	cmp	x24, x9
	b.hs	LBB4_19
LBB4_15:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20]
	add	x9, x9, x23
	ldrh	w22, [x9]
	ldrh	w21, [x9, #2]
	add	x9, x19, x8
	strb	w22, [x9]
	lsr	w10, w22, #8
	strb	w10, [x9, #1]
	strb	w21, [x9, #2]
	lsr	w10, w21, #8
	add	x25, x8, #4
	strb	w10, [x9, #3]
	cbz	w22, LBB4_17
; %bb.16:                               ;   in Loop: Header=BB4_15 Depth=1
	ldr	x8, [x20]
	add	x8, x8, x23
	ldr	x1, [x8, #8]
	add	x0, x19, x25
	mov	x2, x22
	bl	_memcpy
	add	w8, w22, #3
	and	x8, x8, #0x1fffc
	add	x22, x8, x25
	cbnz	w21, LBB4_18
	b	LBB4_13
LBB4_17:                                ;   in Loop: Header=BB4_15 Depth=1
	mov	x8, #0                          ; =0x0
	add	x22, x8, x25
	cbz	w21, LBB4_13
LBB4_18:                                ;   in Loop: Header=BB4_15 Depth=1
	ldr	x8, [x20]
	add	x8, x8, x23
	ldr	x1, [x8, #16]
	add	x0, x19, x22
	mov	x2, x21
	bl	_memcpy
	add	w8, w21, #3
	and	x8, x8, #0x1fffc
	b	LBB4_14
LBB4_19:
	mov	w0, #0                          ; =0x0
LBB4_20:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
