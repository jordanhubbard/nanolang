	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nano_module_build_dir_at       ; -- Begin function nano_module_build_dir_at
	.p2align	2
_nano_module_build_dir_at:              ; @nano_module_build_dir_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-136]
	stur	x1, [x29, #-144]
	stur	x2, [x29, #-152]
	stur	x3, [x29, #-160]
	ldur	x8, [x29, #-152]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldur	x8, [x29, #-160]
	cbnz	x8, LBB0_3
	b	LBB0_2
LBB0_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_3:
	ldur	x8, [x29, #-152]
	strb	wzr, [x8]
	ldur	x8, [x29, #-136]
	cbz	x8, LBB0_5
	b	LBB0_4
LBB0_4:
	ldur	x8, [x29, #-136]
	ldrb	w8, [x8]
	cbnz	w8, LBB0_6
	b	LBB0_5
LBB0_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_6:
	ldur	x8, [x29, #-144]
	cbz	x8, LBB0_22
	b	LBB0_7
LBB0_7:
	ldur	x8, [x29, #-144]
	ldrsb	w8, [x8]
	cbz	w8, LBB0_22
	b	LBB0_8
LBB0_8:
	ldur	x0, [x29, #-136]
	mov	x1, #0                          ; =0x0
	bl	_realpath$DARWIN_EXTSN
	stur	x0, [x29, #-168]
	ldur	x8, [x29, #-168]
	cbz	x8, LBB0_11
	b	LBB0_9
LBB0_9:
	ldur	x0, [x29, #-168]
	add	x1, sp, #72
	bl	_stat
	cbnz	w0, LBB0_11
	b	LBB0_10
LBB0_10:
	ldrh	w8, [sp, #76]
	and	w8, w8, #0xf000
	subs	w8, w8, #4, lsl #12             ; =16384
	b.eq	LBB0_12
	b	LBB0_11
LBB0_11:
	ldur	x0, [x29, #-168]
	bl	_free
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_12:
	ldur	x8, [x29, #-168]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-168]
	bl	_strlen
	mov	x1, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	sub	x2, x29, #56
	bl	_SHA256
	subs	x8, x0, #0
	cset	w8, ne
	strb	w8, [sp, #71]
	ldur	x0, [x29, #-168]
	bl	_free
	ldrb	w8, [sp, #71]
	tbnz	w8, #0, LBB0_14
	b	LBB0_13
LBB0_13:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_14:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #56]
	str	xzr, [sp, #48]
	b	LBB0_15
LBB0_15:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #48]
	subs	x8, x8, #32
	b.hs	LBB0_18
	b	LBB0_16
LBB0_16:                                ;   in Loop: Header=BB0_15 Depth=1
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #48]
	sub	x10, x29, #56
	ldrb	w9, [x10, x9]
	asr	w9, w9, #4
	add	x8, x8, w9, sxtw
	ldrb	w8, [x8]
	ldr	x12, [sp, #48]
	sub	x9, x29, #121
	mov	x11, x9
	add	x11, x11, x12, lsl #1
	strb	w8, [x11]
	ldr	x8, [sp, #56]
	ldr	x11, [sp, #48]
	ldrb	w10, [x10, x11]
	and	w10, w10, #0xf
	add	x8, x8, w10, sxtw
	ldrb	w8, [x8]
	ldr	x10, [sp, #48]
	lsl	x10, x10, #1
	add	x10, x10, #1
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB0_17
LBB0_17:                                ;   in Loop: Header=BB0_15 Depth=1
	ldr	x8, [sp, #48]
	add	x8, x8, #1
	str	x8, [sp, #48]
	b	LBB0_15
LBB0_18:
	sub	x8, x29, #121
	sturb	wzr, [x29, #-57]
	ldur	x0, [x29, #-152]
	ldur	x1, [x29, #-160]
	ldur	x10, [x29, #-144]
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #44]
	ldr	w8, [sp, #44]
	tbnz	w8, #31, LBB0_21
	b	LBB0_19
LBB0_19:
	ldrsw	x8, [sp, #44]
	ldur	x9, [x29, #-160]
	subs	x8, x8, x9
	b.hs	LBB0_21
	b	LBB0_20
LBB0_20:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_21:
	ldur	x8, [x29, #-152]
	strb	wzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_22:
	ldur	x0, [x29, #-152]
	ldur	x1, [x29, #-160]
	ldur	x8, [x29, #-136]
	mov	x9, sp
	str	x8, [x9]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.2@PAGE
	add	x4, x4, l_.str.2@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #40]
	ldr	w8, [sp, #40]
	tbnz	w8, #31, LBB0_25
	b	LBB0_23
LBB0_23:
	ldrsw	x8, [sp, #40]
	ldur	x9, [x29, #-160]
	subs	x8, x8, x9
	b.hs	LBB0_25
	b	LBB0_24
LBB0_24:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_25:
	ldur	x8, [x29, #-152]
	strb	wzr, [x8]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-122]
	b	LBB0_26
LBB0_26:
	ldurb	w8, [x29, #-122]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_28
	b	LBB0_27
LBB0_27:
	bl	___stack_chk_fail
LBB0_28:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nano_module_build_dir          ; -- Begin function nano_module_build_dir
	.p2align	2
_nano_module_build_dir:                 ; @nano_module_build_dir
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	adrp	x0, l_.str.3@PAGE
	add	x0, x0, l_.str.3@PAGEOFF
	bl	_getenv
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #16]
	ldr	x3, [sp, #8]
	bl	_nano_module_build_dir_at
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nano_module_artifact_dir       ; -- Begin function nano_module_artifact_dir
	.p2align	2
_nano_module_artifact_dir:              ; @nano_module_artifact_dir
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #6448                       ; =0x1930
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #216]
	str	x1, [sp, #208]
	str	x2, [sp, #200]
	ldr	x8, [sp, #208]
	cbz	x8, LBB2_3
	b	LBB2_1
LBB2_1:
	ldr	x8, [sp, #200]
	cbz	x8, LBB2_3
	b	LBB2_2
LBB2_2:
	ldr	x0, [sp, #216]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #296
	mov	x2, #2048                       ; =0x800
	bl	_nano_module_build_dir
	tbnz	w0, #0, LBB2_4
	b	LBB2_3
LBB2_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_4:
	mov	x9, sp
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #296
	str	x8, [x9]
	add	x0, sp, #2344
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.4@PAGE
	add	x4, x4, l_.str.4@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #196]
	ldr	w8, [sp, #196]
	tbnz	w8, #31, LBB2_6
	b	LBB2_5
LBB2_5:
	ldrsw	x8, [sp, #196]
	subs	x8, x8, #2048
	b.lo	LBB2_7
	b	LBB2_6
LBB2_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_7:
	add	x0, sp, #2344
	add	x1, sp, #2280
	mov	x2, #63                         ; =0x3f
	bl	_readlink
	str	x0, [sp, #184]
	ldr	x8, [sp, #184]
	tbz	x8, #63, LBB2_13
	b	LBB2_8
LBB2_8:
	bl	___error
	ldr	w8, [x0]
	subs	w8, w8, #2
	b.eq	LBB2_10
	b	LBB2_9
LBB2_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_10:
	ldr	x0, [sp, #208]
	ldr	x1, [sp, #200]
	mov	x9, sp
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #296
	str	x8, [x9]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #196]
	ldr	w8, [sp, #196]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	tbnz	w8, #31, LBB2_12
	b	LBB2_11
LBB2_11:
	ldrsw	x8, [sp, #196]
	ldr	x9, [sp, #200]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB2_12
LBB2_12:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_13:
	ldr	x9, [sp, #184]
	add	x8, sp, #2280
	add	x8, x8, x9
	strb	wzr, [x8]
	ldr	x8, [sp, #184]
	subs	x8, x8, #16
	b.ne	LBB2_16
	b	LBB2_14
LBB2_14:
	add	x0, sp, #2280
	adrp	x1, l_.str.6@PAGE
	add	x1, x1, l_.str.6@PAGEOFF
	mov	x2, #10                         ; =0xa
	bl	_strncmp
	cbnz	w0, LBB2_16
	b	LBB2_15
LBB2_15:
	add	x8, sp, #2280
	add	x0, x8, #10
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	bl	_strspn
	subs	x8, x0, #6
	b.eq	LBB2_17
	b	LBB2_16
LBB2_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_17:
	mov	x9, sp
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #296
	str	x8, [x9]
	add	x8, sp, #2280
	str	x8, [x9, #8]
	add	x0, sp, #232
	mov	x3, #2048                       ; =0x800
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.8@PAGE
	add	x4, x4, l_.str.8@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #196]
	ldr	w8, [sp, #196]
	tbnz	w8, #31, LBB2_19
	b	LBB2_18
LBB2_18:
	ldrsw	x8, [sp, #196]
	subs	x8, x8, #2048
	b.lo	LBB2_20
	b	LBB2_19
LBB2_19:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_20:
	add	x0, sp, #232
	add	x1, sp, #40
	bl	_lstat
	cbnz	w0, LBB2_22
	b	LBB2_21
LBB2_21:
	ldrh	w8, [sp, #44]
	and	w8, w8, #0xf000
	subs	w8, w8, #4, lsl #12             ; =16384
	b.eq	LBB2_23
	b	LBB2_22
LBB2_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_23:
	add	x0, sp, #232
	mov	x1, #0                          ; =0x0
	bl	_realpath$DARWIN_EXTSN
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB2_25
	b	LBB2_24
LBB2_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_25:
	ldr	x0, [sp, #208]
	ldr	x1, [sp, #200]
	ldr	x8, [sp, #32]
	mov	x9, sp
	str	x8, [x9]
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.5@PAGE
	add	x4, x4, l_.str.5@PAGEOFF
	bl	___snprintf_chk
	str	w0, [sp, #196]
	ldr	x0, [sp, #32]
	bl	_free
	ldr	w8, [sp, #196]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #31, LBB2_27
	b	LBB2_26
LBB2_26:
	ldrsw	x8, [sp, #196]
	ldr	x9, [sp, #200]
	subs	x8, x8, x9
	cset	w8, lo
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB2_27
LBB2_27:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #231]
	b	LBB2_28
LBB2_28:
	ldrb	w8, [sp, #231]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB2_30
	b	LBB2_29
LBB2_29:
	bl	___stack_chk_fail
LBB2_30:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2352
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"0123456789abcdef"

l_.str.1:                               ; @.str.1
	.asciz	"%s/v2-%s"

l_.str.2:                               ; @.str.2
	.asciz	"%s/.build"

l_.str.3:                               ; @.str.3
	.asciz	"NANO_BUILD_CACHE"

l_.str.4:                               ; @.str.4
	.asciz	"%s/current"

l_.str.5:                               ; @.str.5
	.asciz	"%s"

l_.str.6:                               ; @.str.6
	.asciz	".nano-gen-"

l_.str.7:                               ; @.str.7
	.asciz	"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

l_.str.8:                               ; @.str.8
	.asciz	"%s/%s"

.subsections_via_symbols
