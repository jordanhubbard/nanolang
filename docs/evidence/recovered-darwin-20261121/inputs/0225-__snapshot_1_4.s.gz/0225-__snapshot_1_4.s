	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_record_eligibility_free ; -- Begin function nvm_record_eligibility_free
	.globl	_nvm_record_eligibility_free
	.p2align	2
_nvm_record_eligibility_free:           ; @nvm_record_eligibility_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #3096]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB0_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_array_eligibility_free ; -- Begin function nvm_array_eligibility_free
	.globl	_nvm_array_eligibility_free
	.p2align	2
_nvm_array_eligibility_free:            ; @nvm_array_eligibility_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_array_graph_eligibility_free ; -- Begin function nvm_array_graph_eligibility_free
	.globl	_nvm_array_graph_eligibility_free
	.p2align	2
_nvm_array_graph_eligibility_free:      ; @nvm_array_graph_eligibility_free
	.cfi_startproc
; %bb.0:
	b	_free
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_opcode_supported ; -- Begin function nvm_record_array_opcode_supported
	.globl	_nvm_record_array_opcode_supported
	.p2align	2
_nvm_record_array_opcode_supported:     ; @nvm_record_array_opcode_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #108
	b.ne	LBB3_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB3_2:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_supported
	mov	w8, #1                          ; =0x1
	mov	w9, #1                          ; =0x1
	sub	w10, w19, #96
	sub	w11, w19, #251
	cmp	w19, #253
	mov	w12, #51                        ; =0x33
	ccmp	w19, w12, #4, ne
	cset	w12, eq
	cmp	w11, #2
	csel	w11, w9, w12, lo
	cmp	w10, #4
	csel	w9, w9, w11, lo
	cmp	w0, #0
	csel	w0, w8, w9, ne
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function supported
_supported:                             ; @supported
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_fixed_result
	tbnz	w0, #31, LBB4_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	b	LBB4_4
LBB4_2:
	cmp	w19, #161
	b.hi	LBB4_5
; %bb.3:
	mov	w0, #1                          ; =0x1
	mov	w8, w19
Lloh0:
	adrp	x9, lJTI4_0@PAGE
Lloh1:
	add	x9, x9, lJTI4_0@PAGEOFF
	adr	x10, LBB4_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB4_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB4_5:
	mov	w0, #0                          ; =0x0
	b	LBB4_4
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
	.section	__TEXT,__const
lJTI4_0:
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_5-LBB4_4)>>2
	.byte	(LBB4_4-LBB4_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function record_operation
_record_operation:                      ; @record_operation
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	sub	w9, w0, #96
	sub	w10, w0, #251
	cmp	w0, #253
	cset	w11, eq
	cmp	w10, #2
	csel	w10, w8, w11, lo
	cmp	w9, #4
	csel	w0, w8, w10, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_origins_free ; -- Begin function nvm_record_array_origins_free
	.globl	_nvm_record_array_origins_free
	.p2align	2
_nvm_record_array_origins_free:         ; @nvm_record_array_origins_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x0, [x0]
	bl	_nvm_ownership_declarations_free
	ldr	x20, [x19, #8]
	cbz	x20, LBB6_3
; %bb.2:
	ldr	x0, [x20, #3096]
	bl	_free
	mov	x0, x20
	bl	_free
LBB6_3:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB6_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_origins_counts ; -- Begin function nvm_record_array_origins_counts
	.globl	_nvm_record_array_origins_counts
	.p2align	2
_nvm_record_array_origins_counts:       ; @nvm_record_array_origins_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB7_2
; %bb.1:
	ldp	q0, q1, [x8, #144]
	ldr	x8, [x8, #176]
	str	x8, [x1, #32]
	stp	q0, q1, [x1]
LBB7_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_origin ; -- Begin function nvm_record_array_origin
	.globl	_nvm_record_array_origin
	.p2align	2
_nvm_record_array_origin:               ; @nvm_record_array_origin
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB8_4
; %bb.1:
	cbz	x2, LBB8_4
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB8_5
; %bb.3:
	mov	w9, #48                         ; =0x30
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	ldur	q2, [x8, #56]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB8_4:
	ret
LBB8_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_field_value ; -- Begin function nvm_record_array_field_value
	.globl	_nvm_record_array_field_value
	.p2align	2
_nvm_record_array_field_value:          ; @nvm_record_array_field_value
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB9_4
; %bb.1:
	cbz	x2, LBB9_4
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB9_5
; %bb.3:
	ldr	x8, [x8, #3096]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB9_4:
	ret
LBB9_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_required_elements ; -- Begin function nvm_record_array_required_elements
	.globl	_nvm_record_array_required_elements
	.p2align	2
_nvm_record_array_required_elements:    ; @nvm_record_array_required_elements
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB10_4
; %bb.1:
	cbz	x2, LBB10_4
; %bb.2:
	ldr	x9, [x8, #8]
	ldr	w9, [x9]
	cmp	w1, w9
	b.hs	LBB10_5
; %bb.3:
	add	x8, x8, w1, uxtw #1
	ldrh	w8, [x8, #16]
	strh	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB10_4:
	ret
LBB10_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_counts ; -- Begin function nvm_record_array_declaration_counts
	.globl	_nvm_record_array_declaration_counts
	.p2align	2
_nvm_record_array_declaration_counts:   ; @nvm_record_array_declaration_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_counts
LBB11_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_layout ; -- Begin function nvm_record_array_declaration_layout
	.globl	_nvm_record_array_declaration_layout
	.p2align	2
_nvm_record_array_declaration_layout:   ; @nvm_record_array_declaration_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB12_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_layout
LBB12_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_field ; -- Begin function nvm_record_array_declaration_field
	.globl	_nvm_record_array_declaration_field
	.p2align	2
_nvm_record_array_declaration_field:    ; @nvm_record_array_declaration_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_field
LBB13_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_type ; -- Begin function nvm_record_array_declaration_type
	.globl	_nvm_record_array_declaration_type
	.p2align	2
_nvm_record_array_declaration_type:     ; @nvm_record_array_declaration_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB14_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_type
LBB14_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_binding ; -- Begin function nvm_record_array_declaration_binding
	.globl	_nvm_record_array_declaration_binding
	.p2align	2
_nvm_record_array_declaration_binding:  ; @nvm_record_array_declaration_binding
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_binding
LBB15_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_declaration_variant ; -- Begin function nvm_record_array_declaration_variant
	.globl	_nvm_record_array_declaration_variant
	.p2align	2
_nvm_record_array_declaration_variant:  ; @nvm_record_array_declaration_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_ownership_declarations_variant
LBB16_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_free ; -- Begin function nvm_union_field_proof_free
	.globl	_nvm_union_field_proof_free
	.p2align	2
_nvm_union_field_proof_free:            ; @nvm_union_field_proof_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB17_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_union_field_declarations_free
	ldr	x0, [x19, #8]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	ldr	x0, [x19, #32]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB17_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_counts ; -- Begin function nvm_union_field_proof_counts
	.globl	_nvm_union_field_proof_counts
	.p2align	2
_nvm_union_field_proof_counts:          ; @nvm_union_field_proof_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB18_2
; %bb.1:
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #56]
	stp	q0, q1, [x1]
LBB18_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_origin ; -- Begin function nvm_union_field_proof_origin
	.globl	_nvm_union_field_proof_origin
	.p2align	2
_nvm_union_field_proof_origin:          ; @nvm_union_field_proof_origin
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB19_5
; %bb.1:
	cbz	x2, LBB19_5
; %bb.2:
	ldr	w9, [x8, #40]
	cmp	w1, w9
	b.hs	LBB19_4
; %bb.3:
	ldr	x8, [x8, #8]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB19_4:
	mov	w0, #0                          ; =0x0
LBB19_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_global ; -- Begin function nvm_union_field_proof_global
	.globl	_nvm_union_field_proof_global
	.p2align	2
_nvm_union_field_proof_global:          ; @nvm_union_field_proof_global
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB20_5
; %bb.1:
	cbz	x2, LBB20_5
; %bb.2:
	ldr	w9, [x8, #44]
	cmp	w1, w9
	b.hs	LBB20_4
; %bb.3:
	ldr	x8, [x8, #16]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB20_4:
	mov	w0, #0                          ; =0x0
LBB20_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_result ; -- Begin function nvm_union_field_proof_result
	.globl	_nvm_union_field_proof_result
	.p2align	2
_nvm_union_field_proof_result:          ; @nvm_union_field_proof_result
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB21_5
; %bb.1:
	cbz	x2, LBB21_5
; %bb.2:
	ldr	w9, [x8, #48]
	cmp	w1, w9
	b.hs	LBB21_4
; %bb.3:
	ldr	x8, [x8, #24]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB21_4:
	mov	w0, #0                          ; =0x0
LBB21_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_stack ; -- Begin function nvm_union_field_proof_stack
	.globl	_nvm_union_field_proof_stack
	.p2align	2
_nvm_union_field_proof_stack:           ; @nvm_union_field_proof_stack
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB22_5
; %bb.1:
	cbz	x2, LBB22_5
; %bb.2:
	ldr	w9, [x8, #48]
	cmp	w1, w9
	b.hs	LBB22_4
; %bb.3:
	ldr	x8, [x8, #32]
	ldrh	w8, [x8, w1, uxtw #1]
	strh	w8, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB22_4:
	mov	w0, #0                          ; =0x0
LBB22_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_layout ; -- Begin function nvm_union_field_proof_layout
	.globl	_nvm_union_field_proof_layout
	.p2align	2
_nvm_union_field_proof_layout:          ; @nvm_union_field_proof_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB23_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_union_field_declarations_layout
LBB23_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_field ; -- Begin function nvm_union_field_proof_field
	.globl	_nvm_union_field_proof_field
	.p2align	2
_nvm_union_field_proof_field:           ; @nvm_union_field_proof_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_union_field_declarations_field
LBB24_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_variant ; -- Begin function nvm_union_field_proof_variant
	.globl	_nvm_union_field_proof_variant
	.p2align	2
_nvm_union_field_proof_variant:         ; @nvm_union_field_proof_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB25_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_union_field_declarations_variant
LBB25_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_nominal ; -- Begin function nvm_union_field_proof_nominal
	.globl	_nvm_union_field_proof_nominal
	.p2align	2
_nvm_union_field_proof_nominal:         ; @nvm_union_field_proof_nominal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB26_2
; %bb.1:
	ldr	x0, [x0]
	b	_nvm_union_field_declarations_nominal
LBB26_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_frozen_free ; -- Begin function nvm_record_map_frozen_free
	.globl	_nvm_record_map_frozen_free
	.p2align	2
_nvm_record_map_frozen_free:            ; @nvm_record_map_frozen_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB27_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB27_5
; %bb.2:
	ldr	x0, [x20]
	bl	_nvm_ownership_declarations_free
	ldr	x21, [x20, #8]
	cbz	x21, LBB27_4
; %bb.3:
	ldr	x0, [x21, #3096]
	bl	_free
	mov	x0, x21
	bl	_free
LBB27_4:
	mov	x0, x20
	bl	_free
LBB27_5:
	ldr	x0, [x19, #8]
	bl	_nvm_map_declarations_free
	ldr	x0, [x19, #16]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB27_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_frozen_counts ; -- Begin function nvm_record_map_frozen_counts
	.globl	_nvm_record_map_frozen_counts
	.p2align	2
_nvm_record_map_frozen_counts:          ; @nvm_record_map_frozen_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB28_2
; %bb.1:
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	stp	q0, q1, [x1]
LBB28_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_frozen_origin ; -- Begin function nvm_record_map_frozen_origin
	.globl	_nvm_record_map_frozen_origin
	.p2align	2
_nvm_record_map_frozen_origin:          ; @nvm_record_map_frozen_origin
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cmp	x2, x3
	b.eq	LBB29_16
; %bb.1:
	cbz	x0, LBB29_16
; %bb.2:
	cbz	x2, LBB29_16
; %bb.3:
	cbz	x3, LBB29_16
; %bb.4:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	w8, [x0, #28]
	cbz	w8, LBB29_8
; %bb.5:
	ldr	x9, [x0, #16]
	add	x9, x9, #4
LBB29_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x9, #-4]
	cmp	w10, w1
	b.eq	LBB29_9
; %bb.7:                                ;   in Loop: Header=BB29_6 Depth=1
	add	x9, x9, #8
	subs	x8, x8, #1
	b.ne	LBB29_6
LBB29_8:
	mov	w9, #0                          ; =0x0
                                        ; implicit-def: $w8
	b	LBB29_15
LBB29_9:
	mov	x20, x2
	mov	x19, x3
	mov	x21, x0
	ldr	x0, [x0, #8]
	ldr	w1, [x9]
	add	x2, sp, #8
	bl	_nvm_map_declarations_pair
	cbz	w0, LBB29_13
; %bb.10:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #8]
	add	x2, sp, #7
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB29_13
; %bb.11:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #12]
	add	x2, sp, #6
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB29_13
; %bb.12:
	ldrb	w8, [sp, #7]
	strb	w8, [x20]
	ldrb	w8, [sp, #6]
	strb	w8, [x19]
	mov	w8, #1                          ; =0x1
	b	LBB29_14
LBB29_13:
	mov	w8, #0                          ; =0x0
LBB29_14:
	mov	w9, #1                          ; =0x1
LBB29_15:
	and	w8, w9, w8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB29_16:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_frozen_field ; -- Begin function nvm_record_map_frozen_field
	.globl	_nvm_record_map_frozen_field
	.p2align	2
_nvm_record_map_frozen_field:           ; @nvm_record_map_frozen_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	w0, #0                          ; =0x0
	cmp	x3, x4
	b.eq	LBB30_8
; %bb.1:
	cbz	x19, LBB30_8
; %bb.2:
	cbz	x3, LBB30_8
; %bb.3:
	cbz	x4, LBB30_8
; %bb.4:
	mov	x21, x3
	mov	x20, x4
	ldr	x0, [x19, #8]
	add	x3, sp, #8
	bl	_nvm_map_declarations_field
	cbz	w0, LBB30_8
; %bb.5:
	ldr	x0, [x19, #8]
	ldr	w1, [sp, #8]
	add	x2, sp, #7
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB30_8
; %bb.6:
	ldr	x0, [x19, #8]
	ldr	w1, [sp, #12]
	add	x2, sp, #6
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB30_8
; %bb.7:
	ldrb	w8, [sp, #7]
	strb	w8, [x21]
	ldrb	w8, [sp, #6]
	strb	w8, [x20]
	mov	w0, #1                          ; =0x1
LBB30_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_heap_origin ; -- Begin function nvm_record_map_heap_origin
	.globl	_nvm_record_map_heap_origin
	.p2align	2
_nvm_record_map_heap_origin:            ; @nvm_record_map_heap_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB31_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB31_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB31_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB31_6
; %bb.4:
	mov	w9, #48                         ; =0x30
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	ldur	q2, [x8, #56]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB31_5:
	ret
LBB31_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_field_value ; -- Begin function nvm_record_map_field_value
	.globl	_nvm_record_map_field_value
	.p2align	2
_nvm_record_map_field_value:            ; @nvm_record_map_field_value
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB32_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB32_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB32_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB32_6
; %bb.4:
	ldr	x8, [x8, #3096]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB32_5:
	ret
LBB32_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_proof_prepare ; -- Begin function nvm_union_field_proof_prepare
	.globl	_nvm_union_field_proof_prepare
	.p2align	2
_nvm_union_field_proof_prepare:         ; @nvm_union_field_proof_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	xzr, xzr, [sp]
	stp	x1, xzr, [sp, #16]
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_analyze_managed_arrays ; -- Begin function nvm_analyze_managed_arrays
	.globl	_nvm_analyze_managed_arrays
	.p2align	2
_nvm_analyze_managed_arrays:            ; @nvm_analyze_managed_arrays
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_analyze_managed_array_graphs ; -- Begin function nvm_analyze_managed_array_graphs
	.globl	_nvm_analyze_managed_array_graphs
	.p2align	2
_nvm_analyze_managed_array_graphs:      ; @nvm_analyze_managed_array_graphs
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x2, x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x1, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_analyze_managed_records ; -- Begin function nvm_analyze_managed_records
	.globl	_nvm_analyze_managed_records
	.p2align	2
_nvm_analyze_managed_records:           ; @nvm_analyze_managed_records
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_analyze_record_array_origins ; -- Begin function nvm_analyze_record_array_origins
	.globl	_nvm_analyze_record_array_origins
	.p2align	2
_nvm_analyze_record_array_origins:      ; @nvm_analyze_record_array_origins
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_select_managed_array_mode ; -- Begin function nvm_select_managed_array_mode
	.globl	_nvm_select_managed_array_mode
	.p2align	2
_nvm_select_managed_array_mode:         ; @nvm_select_managed_array_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x1, LBB38_4
; %bb.1:
	mov	x20, x1
	str	xzr, [sp, #40]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	add	x1, sp, #40
	mov	x8, x19
	mov	x21, x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	x0, [sp, #40]
	bl	_free
	ldr	w8, [x19]
	cmp	w8, #1
	b.eq	LBB38_5
; %bb.2:
	cbnz	w8, LBB38_7
; %bb.3:
	str	wzr, [x20]
	b	LBB38_7
LBB38_4:
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #20]
	stur	q0, [x19, #4]
	stur	q0, [x19, #36]
	stur	q0, [x19, #180]
	stur	q0, [x19, #164]
	stur	q0, [x19, #148]
	stur	q0, [x19, #132]
	stur	q0, [x19, #116]
	stur	q0, [x19, #100]
	stur	q0, [x19, #84]
	stur	q0, [x19, #68]
	stur	q0, [x19, #52]
Lloh2:
	adrp	x8, l_.str@PAGE
Lloh3:
	add	x8, x8, l_.str@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	xzr, [x19, #196]
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
	stur	q1, [x19, #28]
	b	LBB38_7
LBB38_5:
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	add	x2, sp, #32
	mov	x8, x19
	mov	x0, x21
	mov	x1, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	x0, [sp, #32]
	bl	_free
	ldr	w8, [x19]
	cbnz	w8, LBB38_7
; %bb.6:
	mov	w8, #1                          ; =0x1
	str	w8, [x20]
LBB38_7:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_managed_heap_plan_free ; -- Begin function nvm_managed_heap_plan_free
	.globl	_nvm_managed_heap_plan_free
	.p2align	2
_nvm_managed_heap_plan_free:            ; @nvm_managed_heap_plan_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB39_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x0, [x0, #8]
	bl	_nvm_record_plan_free
	ldr	x20, [x19, #16]
	cbz	x20, LBB39_3
; %bb.2:
	ldr	x0, [x20, #3096]
	bl	_free
	mov	x0, x20
	bl	_free
LBB39_3:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB39_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_select_managed_heap ; -- Begin function nvm_select_managed_heap
	.globl	_nvm_select_managed_heap
	.p2align	2
_nvm_select_managed_heap:               ; @nvm_select_managed_heap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #416
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #368]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #384]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #400]            ; 16-byte Folded Spill
	add	x29, sp, #400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x8
Lloh4:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh5:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh6:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #20]
	stur	q0, [x19, #4]
	stur	q0, [x19, #36]
	stur	q0, [x19, #52]
	stur	q0, [x19, #180]
	stur	q0, [x19, #164]
	stur	q0, [x19, #148]
	stur	q0, [x19, #132]
	stur	q0, [x19, #116]
	stur	q0, [x19, #100]
	stur	q0, [x19, #84]
	stur	q0, [x19, #68]
Lloh7:
	adrp	x8, l_.str.1@PAGE
Lloh8:
	add	x8, x8, l_.str.1@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	mov	w9, #2                          ; =0x2
	str	w9, [x19]
	stur	xzr, [x19, #196]
	stur	q1, [x19, #28]
	ldur	q0, [x8, #25]
	stur	q0, [x19, #37]
	cbz	x0, LBB40_12
; %bb.1:
	cbz	x2, LBB40_12
; %bb.2:
	mov	x20, x0
	mov	x22, x1
	mov	x21, x2
	add	x8, sp, #87
	bl	_nvm_verify
	ldrb	w8, [sp, #87]
	cmp	w8, #1
	b.ne	LBB40_12
; %bb.3:
	stp	xzr, xzr, [sp, #56]
	str	xzr, [sp, #72]
	ldr	w8, [x20, #468]
	cbnz	w8, LBB40_6
; %bb.4:
	ldr	w8, [x20, #320]
	cbnz	w8, LBB40_6
; %bb.5:
	ldr	w8, [x20, #304]
	cbz	w8, LBB40_15
LBB40_6:
	add	x9, sp, #56
	add	x8, sp, #32
	add	x1, x9, #8
	mov	x0, x20
	bl	_nvm_describe_managed_records
	ldr	w8, [sp, #32]
	sub	w9, w8, #3
	cmp	w9, #2
	b.lo	LBB40_11
; %bb.7:
	cbnz	w8, LBB40_10
; %bb.8:
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #40]
	cmp	w8, #1
	b.ne	LBB40_14
; %bb.9:
	add	x8, sp, #56
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	add	x3, x8, #16
	mov	x8, x19
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	mov	w8, #2                          ; =0x2
	b	LBB40_17
LBB40_10:
	cmp	w8, #2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
LBB40_11:
	str	w8, [x19]
	ldr	x8, [sp, #48]
	str	x8, [sp]
Lloh9:
	adrp	x2, l_.str.2@PAGE
Lloh10:
	add	x2, x2, l_.str.2@PAGEOFF
	add	x0, x19, #12
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB40_12:
	ldur	x8, [x29, #-56]
Lloh11:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh12:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh13:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB40_24
; %bb.13:
	ldp	x29, x30, [sp, #400]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #384]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #416
	ret
LBB40_14:
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
Lloh14:
	adrp	x8, l_.str.3@PAGE
Lloh15:
	add	x8, x8, l_.str.3@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldur	q0, [x8, #29]
	stur	q0, [x19, #41]
	mov	w8, #2                          ; =0x2
	b	LBB40_17
LBB40_15:
	cbz	w22, LBB40_23
; %bb.16:
	str	wzr, [sp, #32]
	add	x1, sp, #32
	mov	x8, x19
	mov	x0, x20
	bl	_nvm_select_managed_array_mode
	ldr	w8, [sp, #32]
	cmp	w8, #0
	cset	w8, ne
LBB40_17:
	str	w8, [sp, #56]
	ldr	w8, [x19]
	cbnz	w8, LBB40_21
LBB40_18:
	mov	w0, #1                          ; =0x1
	mov	w1, #24                         ; =0x18
	bl	_calloc
	cbz	x0, LBB40_20
; %bb.19:
	ldur	q0, [sp, #56]
	str	q0, [x0]
	ldr	x8, [sp, #72]
	str	x8, [x0, #16]
	str	x0, [x21]
	b	LBB40_12
LBB40_20:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
Lloh16:
	adrp	x8, l_.str.4@PAGE
Lloh17:
	add	x8, x8, l_.str.4@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldur	q0, [x8, #26]
	stur	q0, [x19, #38]
LBB40_21:
	ldr	x0, [sp, #64]
	bl	_nvm_record_plan_free
	ldr	x19, [sp, #72]
	cbz	x19, LBB40_12
; %bb.22:
	ldr	x0, [x19, #3096]
	bl	_free
	mov	x0, x19
	bl	_free
	b	LBB40_12
LBB40_23:
	str	wzr, [x19]
	b	LBB40_18
LBB40_24:
	bl	___stack_chk_fail
	.loh AdrpAdd	Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh4, Lloh5, Lloh6
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpLdrGotLdr	Lloh11, Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_free ; -- Begin function nvm_record_array_execution_free
	.globl	_nvm_record_array_execution_free
	.p2align	2
_nvm_record_array_execution_free:       ; @nvm_record_array_execution_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB41_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	bl	_rae_snapshot_free
	ldr	x20, [x19, #480]
	cbz	x20, LBB41_5
; %bb.2:
	ldr	x0, [x20]
	bl	_nvm_ownership_declarations_free
	ldr	x21, [x20, #8]
	cbz	x21, LBB41_4
; %bb.3:
	ldr	x0, [x21, #3096]
	bl	_free
	mov	x0, x21
	bl	_free
LBB41_4:
	mov	x0, x20
	bl	_free
LBB41_5:
	ldr	x0, [x19, #13352]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB41_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_snapshot_free
_rae_snapshot_free:                     ; @rae_snapshot_free
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x8, [x0, #232]
	cbz	x8, LBB42_4
; %bb.1:
	ldr	w8, [x19, #248]
	cbz	w8, LBB42_4
; %bb.2:
	mov	x20, #0                         ; =0x0
LBB42_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #232]
	ldr	x0, [x8, x20, lsl #3]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #248]
	cmp	x20, x8
	b.lo	LBB42_3
LBB42_4:
	ldr	x8, [x19, #264]
	cbz	x8, LBB42_8
; %bb.5:
	ldr	w8, [x19, #272]
	cbz	w8, LBB42_8
; %bb.6:
	mov	x20, #0                         ; =0x0
LBB42_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #264]
	ldr	x0, [x8, x20, lsl #3]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #272]
	cmp	x20, x8
	b.lo	LBB42_7
LBB42_8:
	ldr	x0, [x19, #232]
	bl	_free
	ldr	x0, [x19, #240]
	bl	_free
	ldr	x0, [x19, #256]
	bl	_free
	ldr	x0, [x19, #264]
	bl	_free
	ldr	x0, [x19, #280]
	bl	_free
	ldr	x0, [x19, #296]
	bl	_free
	ldr	x0, [x19, #312]
	bl	_free
	ldr	x0, [x19, #360]
	bl	_free
	ldr	x0, [x19, #376]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_prepare_record_array_execution
lCPI43_0:
	.quad	67187784                        ; 0x4013448
	.quad	16856136                        ; 0x1013448
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_prepare_record_array_execution
	.globl	_nvm_prepare_record_array_execution
	.p2align	2
_nvm_prepare_record_array_execution:    ; @nvm_prepare_record_array_execution
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #52]
	stur	q0, [x8, #20]
	stur	q0, [x8, #4]
	stur	q0, [x8, #36]
	stur	q0, [x8, #180]
	stur	q0, [x8, #164]
	stur	q0, [x8, #148]
	stur	q0, [x8, #132]
	stur	q0, [x8, #116]
	stur	q0, [x8, #100]
	stur	q0, [x8, #84]
Lloh18:
	adrp	x8, l_.str.5@PAGE
Lloh19:
	add	x8, x8, l_.str.5@PAGEOFF
	stur	q0, [x19, #68]
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	mov	w9, #2                          ; =0x2
	str	w9, [x19]
	mov	w9, #29813                      ; =0x7475
	movk	w9, #46, lsl #16
	str	w9, [x19, #60]
	stur	xzr, [x19, #196]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	cbz	x0, LBB43_34
; %bb.1:
	cbz	x1, LBB43_34
; %bb.2:
	mov	x21, x0
	mov	x23, x1
	mov	w0, #1                          ; =0x1
	mov	w1, #13384                      ; =0x3448
	bl	_calloc
	cbz	x0, LBB43_13
; %bb.3:
	mov	x20, x0
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #13376]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x0, #500]
Lloh20:
	adrp	x8, lCPI43_0@PAGE
Lloh21:
	ldr	q0, [x8, lCPI43_0@PAGEOFF]
	str	q0, [x0, #13360]
	mov	x1, x21
	bl	_rae_snapshot
	cbz	w0, LBB43_33
; %bb.4:
	ldr	w22, [x20, #272]
	cbz	w22, LBB43_11
; %bb.5:
	ldr	x24, [x20, #256]
	ldr	w25, [x20, #248]
	mov	w26, #134217728                 ; =0x8000000
	mov	w27, #33554432                  ; =0x2000000
LBB43_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24], #24
	cmp	w8, w25
	b.hs	LBB43_33
; %bb.7:                                ;   in Loop: Header=BB43_6 Depth=1
	ldr	x9, [x20, #13360]
	cmp	x9, x26
	b.hi	LBB43_16
; %bb.8:                                ;   in Loop: Header=BB43_6 Depth=1
	ldr	x9, [x20, #240]
	ldr	w2, [x9, x8, lsl #2]
	ldr	x9, [x20, #13368]
	sub	x10, x27, x9
	cmp	x9, x27
	ccmp	x10, x2, #0, ls
	b.ls	LBB43_16
; %bb.9:                                ;   in Loop: Header=BB43_6 Depth=1
	add	x10, x2, #1
	add	x9, x10, x9
	str	x9, [x20, #13368]
	ldr	x9, [x20, #232]
	ldr	x0, [x9, x8, lsl #3]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB43_31
; %bb.10:                               ;   in Loop: Header=BB43_6 Depth=1
	subs	x22, x22, #1
	b.ne	LBB43_6
LBB43_11:
	mov	w8, #9768                       ; =0x2628
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	add	x4, x20, #480
	add	x5, x20, x8
	mov	x8, x19
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	w8, [x19]
	cbz	w8, LBB43_14
; %bb.12:
	mov	x0, x20
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	b	_nvm_record_array_execution_free
LBB43_13:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	b	LBB43_34
LBB43_14:
	ldr	x8, [x20, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB43_16
; %bb.15:
	ldr	x8, [x20, #13368]
	mov	w9, #65281                      ; =0xff01
	movk	w9, #511, lsl #16
	cmp	x8, x9
	b.lo	LBB43_17
LBB43_16:
	mov	w8, #3                          ; =0x3
	b	LBB43_32
LBB43_17:
	mov	w22, #0                         ; =0x0
	add	x8, x8, #256
	str	x8, [x20, #13368]
	mov	w24, #1                         ; =0x1
	mov	w25, #51                        ; =0x33
LBB43_18:                               ; =>This Inner Loop Header: Depth=1
	cmp	w22, #108
	b.ne	LBB43_20
; %bb.19:                               ;   in Loop: Header=BB43_18 Depth=1
	mov	w26, #0                         ; =0x0
	b	LBB43_21
LBB43_20:                               ;   in Loop: Header=BB43_18 Depth=1
	mov	x0, x22
	bl	_supported
	sub	w8, w22, #96
	sub	w9, w22, #251
	cmp	w22, #253
	ccmp	w22, w25, #4, ne
	cset	w10, eq
	cmp	w9, #2
	csel	w9, w24, w10, lo
	cmp	w8, #4
	csel	w8, w24, w9, lo
	cmp	w0, #0
	csel	w26, w24, w8, ne
LBB43_21:                               ;   in Loop: Header=BB43_18 Depth=1
	add	x1, sp, #56
	mov	x0, x22
	bl	_rae_recipe
	cmp	w0, w26
	b.ne	LBB43_31
; %bb.22:                               ;   in Loop: Header=BB43_18 Depth=1
	add	w22, w22, #1
	cmp	w22, #256
	b.ne	LBB43_18
; %bb.23:
	ldr	x8, [x20, #480]
	cbz	x8, LBB43_33
; %bb.24:
	ldr	x0, [x8]
	add	x1, sp, #36
	bl	_nvm_ownership_declarations_counts
	cbz	w0, LBB43_33
; %bb.25:
	ldr	w8, [sp, #36]
	cmp	w8, #256
	b.hi	LBB43_33
; %bb.26:
	ldr	x9, [x20, #13360]
	mov	w10, #134217728                 ; =0x8000000
	cmp	x9, x10
	b.hi	LBB43_16
; %bb.27:
	ldr	x9, [x20, #13368]
	mov	w10, #33554432                  ; =0x2000000
	cmp	x9, x10
	b.hi	LBB43_16
; %bb.28:
	lsl	x11, x8, #2
	sub	x10, x10, x9
	cmp	x10, x11
	b.lo	LBB43_16
; %bb.29:
	add	x9, x9, x11
	str	x9, [x20, #13368]
	cbz	w8, LBB43_40
; %bb.30:
	mov	w22, #0                         ; =0x0
	mov	w8, #10280                      ; =0x2828
	add	x24, x20, x8
	mov	w25, #12                        ; =0xc
	b	LBB43_36
LBB43_31:
	mov	w8, #1                          ; =0x1
LBB43_32:
	str	w8, [x20, #13376]
LBB43_33:
	ldr	w8, [x20, #13376]
	str	w8, [x19]
Lloh22:
	adrp	x8, l_.str.7@PAGE
Lloh23:
	add	x8, x8, l_.str.7@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	ldur	q0, [x8, #41]
	stur	q0, [x19, #53]
	mov	x0, x20
	bl	_nvm_record_array_execution_free
LBB43_34:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB43_35:                               ;   in Loop: Header=BB43_36 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #36]
	cmp	w22, w8
	b.hs	LBB43_40
LBB43_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #480]
	cbz	x8, LBB43_33
; %bb.37:                               ;   in Loop: Header=BB43_36 Depth=1
	ldr	x0, [x8]
	add	x2, sp, #56
	mov	x1, x22
	bl	_nvm_ownership_declarations_layout
	cbz	w0, LBB43_33
; %bb.38:                               ;   in Loop: Header=BB43_36 Depth=1
	ldrb	w8, [sp, #56]
	cbnz	w8, LBB43_35
; %bb.39:                               ;   in Loop: Header=BB43_36 Depth=1
	ldr	w8, [x20, #528]
	add	w9, w8, #1
	str	w9, [x20, #528]
	umaddl	x9, w8, w25, x24
	ldrh	w10, [sp, #58]
	stp	w8, w22, [x9]
	strh	w10, [x9, #8]
	strh	wzr, [x9, #10]
	b	LBB43_35
LBB43_40:
	ldr	w8, [x20, #528]
	ldr	w9, [x20, #468]
	cmp	w8, w9
	b.ne	LBB43_33
; %bb.41:
Lloh24:
	adrp	x1, _rae_old_recipe@PAGE
Lloh25:
	add	x1, x1, _rae_old_recipe@PAGEOFF
	mov	x0, x20
	mov	w2, #0                          ; =0x0
	bl	_rae_instructions_policy
	cbz	w0, LBB43_33
; %bb.42:
	mov	x0, x20
	mov	x1, x21
	bl	_rae_same
	cbz	w0, LBB43_33
; %bb.43:
	ldr	w8, [x20, #248]
	str	w8, [x20, #512]
	ldr	w8, [x20, #224]
	str	w8, [x20, #516]
	ldr	w8, [x20, #368]
	str	w8, [x20, #520]
	ldr	w8, [x20, #384]
	str	w8, [x20, #524]
	ldr	w8, [x20, #272]
	str	w8, [x20, #488]
	ldr	w8, [x20, #12]
	str	w8, [x20, #504]
	mov	w8, #1024                       ; =0x400
	str	w8, [x20, #508]
	add	x8, x20, #536
	ldr	q0, [x20, #13360]
	str	q0, [x8]
	str	x20, [x23]
	str	wzr, [x19]
	mov	w8, #28271                      ; =0x6e6f
	movk	w8, #46, lsl #16
	stur	w8, [x19, #76]
Lloh26:
	adrp	x8, l_.str.6@PAGE
Lloh27:
	add	x8, x8, l_.str.6@PAGEOFF
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stur	q3, [x19, #60]
	stur	q2, [x19, #44]
	stur	q1, [x19, #28]
	stur	q0, [x19, #12]
	b	LBB43_34
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_snapshot
_rae_snapshot:                          ; @rae_snapshot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x1, #328]
	cbnz	x8, LBB44_9
; %bb.1:
	ldr	w8, [x1, #336]
	cbnz	w8, LBB44_9
; %bb.2:
	ldr	x8, [x1, #344]
	cbnz	x8, LBB44_9
; %bb.3:
	ldr	w8, [x1, #352]
	cbnz	w8, LBB44_9
; %bb.4:
	ldr	w8, [x1, #432]
	cbnz	w8, LBB44_9
; %bb.5:
	ldr	w8, [x1, #448]
	cbnz	w8, LBB44_9
; %bb.6:
	ldr	w8, [x1, #424]
	cbnz	w8, LBB44_9
; %bb.7:
	ldr	x8, [x1, #456]
	cbnz	x8, LBB44_9
; %bb.8:
	ldr	w8, [x1, #464]
	cbz	w8, LBB44_12
LBB44_9:
	mov	w9, #1                          ; =0x1
LBB44_10:
	mov	w8, #0                          ; =0x0
	str	w9, [x0, #13376]
LBB44_11:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB44_12:
	ldr	w9, [x1, #272]
	cmp	w9, #256
	b.ls	LBB44_14
; %bb.13:
	mov	w9, #3                          ; =0x3
	b	LBB44_10
LBB44_14:
	stp	x0, x1, [sp]                    ; 16-byte Folded Spill
	ldr	w8, [x1, #248]
	cmp	w8, #1, lsl #12                 ; =4096
	b.hi	LBB44_16
; %bb.15:
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	w10, [x10, #288]
	mov	w11, #16777216                  ; =0x1000000
	cmp	w10, w11
	b.ls	LBB44_17
LBB44_16:
	mov	w9, #3                          ; =0x3
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	b	LBB44_10
LBB44_17:
	cbz	w9, LBB44_40
; %bb.18:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #256]
	cbz	x9, LBB44_40
; %bb.19:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #224]
	cmp	w9, #16
	b.hi	LBB44_40
; %bb.20:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #16]
	cmp	w9, #16
	b.hi	LBB44_40
; %bb.21:
	cbz	w8, LBB44_24
; %bb.22:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #232]
	cbz	x8, LBB44_11
; %bb.23:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #240]
	cbz	x8, LBB44_11
LBB44_24:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldp	q0, q1, [x8]
	stp	q0, q1, [x19]
	ldp	q0, q1, [x8, #128]
	ldp	q3, q2, [x8, #96]
	stp	q0, q1, [x19, #128]
	stp	q3, q2, [x19, #96]
	ldp	q0, q1, [x8, #192]
	ldp	q3, q2, [x8, #160]
	stp	q0, q1, [x19, #192]
	stp	q3, q2, [x19, #160]
	ldp	q0, q1, [x8, #32]
	ldp	q2, q3, [x8, #64]
	stp	q2, q3, [x19, #64]
	stp	q0, q1, [x19, #32]
	ldr	w9, [x8, #224]
	str	w9, [x19, #224]
	ldr	d0, [x8, #248]
	str	d0, [x19, #248]
	ldr	d0, [x8, #272]
	ldr	w2, [x8, #272]
	str	d0, [x19, #272]
	ldr	d0, [x8, #288]
	str	d0, [x19, #288]
	ldr	w9, [x8, #304]
	str	w9, [x19, #304]
	ldr	w9, [x8, #320]
	str	w9, [x19, #320]
	ldr	d0, [x8, #368]
	str	d0, [x19, #368]
	ldr	d0, [x8, #384]
	str	d0, [x19, #384]
	ldr	w9, [x8, #392]
	str	w9, [x19, #392]
	ldr	w9, [x8, #436]
	str	w9, [x19, #436]
	ldr	w9, [x8, #452]
	str	w9, [x19, #452]
	ldr	w9, [x8, #428]
	str	w9, [x19, #428]
	ldr	w9, [x8, #468]
	str	w9, [x19, #468]
	ldr	d0, [x8, #472]
	str	d0, [x19, #472]
	ldr	x1, [x8, #256]
	mov	x0, x19
	mov	w3, #24                         ; =0x18
	bl	_rae_copy
	str	x0, [x19, #256]
	cbnz	x0, LBB44_26
; %bb.25:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #272]
	cbnz	w8, LBB44_40
LBB44_26:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	x1, [x8, #280]
	ldr	w2, [x8, #288]
	mov	x0, x19
	mov	w3, #1                          ; =0x1
	bl	_rae_copy
	str	x0, [x19, #280]
	cbnz	x0, LBB44_28
; %bb.27:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #288]
	cbnz	w8, LBB44_40
LBB44_28:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	x1, [x8, #296]
	ldr	w2, [x8, #304]
	mov	x0, x19
	mov	w3, #1                          ; =0x1
	bl	_rae_copy
	str	x0, [x19, #296]
	cbnz	x0, LBB44_30
; %bb.29:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #304]
	cbnz	w8, LBB44_40
LBB44_30:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	x1, [x8, #312]
	ldr	w2, [x8, #320]
	mov	x0, x19
	mov	w3, #1                          ; =0x1
	bl	_rae_copy
	str	x0, [x19, #312]
	cbnz	x0, LBB44_32
; %bb.31:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #320]
	cbnz	w8, LBB44_40
LBB44_32:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	x1, [x8, #360]
	ldr	w2, [x8, #368]
	mov	x0, x19
	mov	w3, #8                          ; =0x8
	bl	_rae_copy
	str	x0, [x19, #360]
	cbnz	x0, LBB44_34
; %bb.33:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #368]
	cbnz	w8, LBB44_40
LBB44_34:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	x1, [x8, #376]
	ldr	w2, [x8, #384]
	mov	x0, x19
	mov	w3, #12                         ; =0xc
	bl	_rae_copy
	str	x0, [x19, #376]
	cbnz	x0, LBB44_36
; %bb.35:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #384]
	cbnz	w8, LBB44_40
LBB44_36:
	ldp	x19, x20, [sp]                  ; 16-byte Folded Reload
	ldr	x1, [x20, #240]
	ldr	w2, [x20, #248]
	mov	x0, x19
	mov	w3, #4                          ; =0x4
	bl	_rae_copy
	str	x0, [x19, #240]
	ldr	w1, [x20, #248]
	cbnz	x0, LBB44_38
; %bb.37:
	cbnz	w1, LBB44_40
LBB44_38:
	ldr	x19, [sp]                       ; 8-byte Folded Reload
	mov	x0, x19
	mov	w2, #8                          ; =0x8
	bl	_rae_zero
	str	x0, [x19, #232]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cbnz	x0, LBB44_41
; %bb.39:
	cbz	w8, LBB44_41
LBB44_40:
	mov	w8, #0                          ; =0x0
	b	LBB44_11
LBB44_41:
	cbz	w8, LBB44_45
; %bb.42:
	mov	x20, #0                         ; =0x0
LBB44_43:                               ; =>This Inner Loop Header: Depth=1
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldp	x8, x9, [x8, #232]
	ldr	w9, [x9, x20, lsl #2]
	ldr	x1, [x8, x20, lsl #3]
	add	x2, x9, #1
	mov	x0, x19
	mov	w3, #1                          ; =0x1
	bl	_rae_copy
	ldr	x8, [x19, #232]
	str	x0, [x8, x20, lsl #3]
	cbz	x0, LBB44_40
; %bb.44:                               ;   in Loop: Header=BB44_43 Depth=1
	add	x20, x20, #1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cmp	x20, x8
	b.lo	LBB44_43
LBB44_45:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #264]
	cbz	x8, LBB44_47
; %bb.46:
	ldp	x19, x8, [sp]                   ; 16-byte Folded Reload
	ldr	w1, [x8, #272]
	mov	x0, x19
	mov	w2, #8                          ; =0x8
	bl	_rae_zero
	str	x0, [x19, #264]
	cbz	x0, LBB44_40
LBB44_47:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x8, #272]
	cbz	w9, LBB44_59
; %bb.48:
	mov	x19, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	b	LBB44_50
LBB44_49:                               ;   in Loop: Header=BB44_50 Depth=1
	add	x20, x20, #1
	add	x19, x19, #24
	mov	w8, #1                          ; =0x1
	cmp	x20, x9
	b.hs	LBB44_11
LBB44_50:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	add	x8, x8, x19
	ldrh	w2, [x8, #4]
	cmp	w2, #256
	b.hi	LBB44_16
; %bb.51:                               ;   in Loop: Header=BB44_50 Depth=1
	ldrh	w8, [x8, #16]
	cmp	w8, #256
	b.hi	LBB44_16
; %bb.52:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #264]
	cbz	x8, LBB44_49
; %bb.53:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x1, [x8, x20, lsl #3]
	cbz	x1, LBB44_49
; %bb.54:                               ;   in Loop: Header=BB44_50 Depth=1
	cbz	w2, LBB44_56
; %bb.55:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	mov	w3, #1                          ; =0x1
	bl	_rae_copy
	b	LBB44_57
LBB44_56:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	bl	_rae_zero
LBB44_57:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [x8, #264]
	str	x0, [x8, x20, lsl #3]
	cbz	x0, LBB44_40
; %bb.58:                               ;   in Loop: Header=BB44_50 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x8, #272]
	b	LBB44_49
LBB44_59:
	mov	w8, #1                          ; =0x1
	b	LBB44_11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_recipe
_rae_recipe:                            ; @rae_recipe
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	w9, #65                         ; =0x41
	strh	w9, [x1, #28]
	cmp	w8, #253
	b.hi	LBB45_32
; %bb.1:
	mov	w8, w8
Lloh28:
	adrp	x9, lJTI45_0@PAGE
Lloh29:
	add	x9, x9, lJTI45_0@PAGEOFF
	adr	x10, LBB45_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB45_2:
	strb	wzr, [x1, #31]
	b	LBB45_31
LBB45_3:
	mov	w8, #10                         ; =0xa
LBB45_4:
	strb	w8, [x1, #31]
	mov	w8, #89                         ; =0x59
	b	LBB45_30
LBB45_5:
	mov	w0, #1                          ; =0x1
	strb	w0, [x1, #31]
	mov	w8, #64                         ; =0x40
	strh	w8, [x1, #28]
	ret
LBB45_6:
	mov	w8, #7                          ; =0x7
	strb	w8, [x1, #31]
	b	LBB45_31
LBB45_7:
	mov	w8, #11                         ; =0xb
	strb	w8, [x1, #31]
	mov	w8, #93                         ; =0x5d
	b	LBB45_30
LBB45_8:
	mov	w8, #13                         ; =0xd
	b	LBB45_14
LBB45_9:
	mov	w8, #6                          ; =0x6
	strb	w8, [x1, #31]
	b	LBB45_31
LBB45_10:
	mov	w8, #2                          ; =0x2
	b	LBB45_23
LBB45_11:
	mov	w8, #3                          ; =0x3
	b	LBB45_23
LBB45_12:
	mov	w8, #11                         ; =0xb
	b	LBB45_4
LBB45_13:
	mov	w8, #12                         ; =0xc
LBB45_14:
	strb	w8, [x1, #31]
	mov	w8, #103                        ; =0x67
	b	LBB45_30
LBB45_15:
	mov	w8, #16                         ; =0x10
	strb	w8, [x1, #31]
	mov	w8, #91                         ; =0x5b
	b	LBB45_30
LBB45_16:
	mov	w8, #8                          ; =0x8
	b	LBB45_28
LBB45_17:
	mov	w8, #13                         ; =0xd
	strb	w8, [x1, #31]
	mov	w8, #123                        ; =0x7b
	b	LBB45_30
LBB45_18:
	strb	wzr, [x1, #31]
	mov	w8, #64                         ; =0x40
	b	LBB45_30
LBB45_19:
	mov	w8, #5                          ; =0x5
	strb	w8, [x1, #31]
	b	LBB45_31
LBB45_20:
	mov	w0, #1                          ; =0x1
	strb	w0, [x1, #31]
	mov	w8, #97                         ; =0x61
	strh	w8, [x1, #28]
	ret
LBB45_21:
	mov	w8, #15                         ; =0xf
	b	LBB45_25
LBB45_22:
	mov	w8, #4                          ; =0x4
LBB45_23:
	strb	w8, [x1, #31]
	mov	w8, #97                         ; =0x61
	b	LBB45_30
LBB45_24:
	mov	w8, #12                         ; =0xc
LBB45_25:
	strb	w8, [x1, #31]
	mov	w8, #99                         ; =0x63
	b	LBB45_30
LBB45_26:
	mov	w8, #17                         ; =0x11
	strb	w8, [x1, #31]
	mov	w8, #113                        ; =0x71
	b	LBB45_30
LBB45_27:
	mov	w8, #9                          ; =0x9
LBB45_28:
	strb	w8, [x1, #31]
	mov	w8, #81                         ; =0x51
	b	LBB45_30
LBB45_29:
	mov	w8, #14                         ; =0xe
	strb	w8, [x1, #31]
	mov	w8, #121                        ; =0x79
LBB45_30:
	strh	w8, [x1, #28]
LBB45_31:
	mov	w0, #1                          ; =0x1
LBB45_32:
	ret
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc
	.section	__TEXT,__const
lJTI45_0:
	.byte	(LBB45_18-LBB45_2)>>2
	.byte	(LBB45_5-LBB45_2)>>2
	.byte	(LBB45_5-LBB45_2)>>2
	.byte	(LBB45_5-LBB45_2)>>2
	.byte	(LBB45_20-LBB45_2)>>2
	.byte	(LBB45_5-LBB45_2)>>2
	.byte	(LBB45_5-LBB45_2)>>2
	.byte	(LBB45_22-LBB45_2)>>2
	.byte	(LBB45_9-LBB45_2)>>2
	.byte	(LBB45_19-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_10-LBB45_2)>>2
	.byte	(LBB45_11-LBB45_2)>>2
	.byte	(LBB45_10-LBB45_2)>>2
	.byte	(LBB45_11-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_26-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_6-LBB45_2)>>2
	.byte	(LBB45_6-LBB45_2)>>2
	.byte	(LBB45_6-LBB45_2)>>2
	.byte	(LBB45_16-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_27-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_12-LBB45_2)>>2
	.byte	(LBB45_29-LBB45_2)>>2
	.byte	(LBB45_21-LBB45_2)>>2
	.byte	(LBB45_24-LBB45_2)>>2
	.byte	(LBB45_17-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_15-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_12-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_7-LBB45_2)>>2
	.byte	(LBB45_13-LBB45_2)>>2
	.byte	(LBB45_8-LBB45_2)>>2
	.byte	(LBB45_7-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_3-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_9-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_2-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_32-LBB45_2)>>2
	.byte	(LBB45_7-LBB45_2)>>2
	.byte	(LBB45_13-LBB45_2)>>2
	.byte	(LBB45_8-LBB45_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function rae_same
_rae_same:                              ; @rae_same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x8, [x0, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB46_2
; %bb.1:
	ldr	x8, [x0, #13368]
	mov	w9, #64513                      ; =0xfc01
	movk	w9, #511, lsl #16
	cmp	x8, x9
	b.lo	LBB46_4
LBB46_2:
	mov	w8, #3                          ; =0x3
	str	w8, [x0, #13376]
LBB46_3:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB46_4:
	add	x8, x8, #1024
	str	x8, [x0, #13368]
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.5:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.6:
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.7:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.8:
	ldr	w8, [x0, #20]
	ldr	w9, [x1, #20]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.9:
	ldr	w8, [x0, #24]
	ldr	w9, [x1, #24]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.10:
	ldr	w8, [x0, #28]
	ldr	w9, [x1, #28]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.11:
	ldr	w8, [x0, #224]
	ldr	w9, [x1, #224]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.12:
	ldr	w8, [x0, #248]
	ldr	w9, [x1, #248]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.13:
	ldr	w8, [x0, #252]
	ldr	w9, [x1, #252]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.14:
	ldr	w8, [x0, #272]
	ldr	w9, [x1, #272]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.15:
	ldr	w8, [x0, #276]
	ldr	w9, [x1, #276]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.16:
	ldr	w8, [x0, #288]
	ldr	w9, [x1, #288]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.17:
	ldr	w8, [x0, #292]
	ldr	w9, [x1, #292]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.18:
	ldr	w8, [x0, #304]
	ldr	w9, [x1, #304]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.19:
	ldr	w8, [x0, #320]
	ldr	w9, [x1, #320]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.20:
	ldr	w8, [x0, #336]
	ldr	w9, [x1, #336]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.21:
	ldr	w8, [x0, #352]
	ldr	w9, [x1, #352]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.22:
	ldr	w8, [x0, #368]
	ldr	w9, [x1, #368]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.23:
	ldr	w8, [x0, #372]
	ldr	w9, [x1, #372]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.24:
	ldr	w8, [x0, #384]
	ldr	w9, [x1, #384]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.25:
	ldr	w8, [x0, #388]
	ldr	w9, [x1, #388]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.26:
	ldr	w8, [x0, #392]
	ldr	w9, [x1, #392]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.27:
	ldr	w8, [x0, #432]
	ldr	w9, [x1, #432]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.28:
	ldr	w8, [x0, #436]
	ldr	w9, [x1, #436]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.29:
	ldr	w8, [x0, #448]
	ldr	w9, [x1, #448]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.30:
	ldr	w8, [x0, #452]
	ldr	w9, [x1, #452]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.31:
	ldr	w8, [x0, #424]
	ldr	w9, [x1, #424]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.32:
	ldr	w8, [x0, #428]
	ldr	w9, [x1, #428]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.33:
	ldr	w8, [x0, #464]
	ldr	w9, [x1, #464]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.34:
	ldr	w8, [x0, #468]
	ldr	w9, [x1, #468]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.35:
	ldr	w8, [x0, #472]
	ldr	w9, [x1, #472]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.36:
	ldr	w8, [x0, #476]
	ldr	w9, [x1, #476]
	cmp	w8, w9
	b.ne	LBB46_3
; %bb.37:
	ldr	x8, [x1, #328]
	cbnz	x8, LBB46_3
; %bb.38:
	ldr	x8, [x1, #344]
	cbnz	x8, LBB46_3
; %bb.39:
	ldr	x8, [x1, #456]
	cbnz	x8, LBB46_3
; %bb.40:
	ldr	x8, [x0, #264]
	cmp	x8, #0
	cset	w8, ne
	ldr	x9, [x1, #264]
	cmp	x9, #0
	cset	w9, eq
	cmp	w8, w9
	b.eq	LBB46_3
; %bb.41:
	stp	x1, x0, [sp]                    ; 16-byte Folded Spill
	mov	x1, x0
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	mov	w3, #4                          ; =0x4
	bl	_rae_equal_bytes
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	w0, LBB46_3
; %bb.42:
	ldr	w8, [x8, #224]
	cbz	w8, LBB46_48
; %bb.43:
	ldp	x9, x10, [sp]                   ; 16-byte Folded Reload
	add	x9, x9, #40
	add	x10, x10, #40
LBB46_44:                               ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-8]
	ldur	w12, [x9, #-8]
	cmp	w11, w12
	b.ne	LBB46_3
; %bb.45:                               ;   in Loop: Header=BB46_44 Depth=1
	ldur	w11, [x10, #-4]
	ldur	w12, [x9, #-4]
	cmp	w11, w12
	b.ne	LBB46_3
; %bb.46:                               ;   in Loop: Header=BB46_44 Depth=1
	ldr	w11, [x10], #12
	ldr	w12, [x9], #12
	cmp	w11, w12
	b.ne	LBB46_3
; %bb.47:                               ;   in Loop: Header=BB46_44 Depth=1
	subs	x8, x8, #1
	b.ne	LBB46_44
LBB46_48:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #272]
	cbz	w8, LBB46_66
; %bb.49:
	mov	x20, #0                         ; =0x0
	mov	w21, #21                        ; =0x15
	mov	w22, #134217728                 ; =0x8000000
	mov	w23, #65521                     ; =0xfff1
	movk	w23, #511, lsl #16
	b	LBB46_51
LBB46_50:                               ;   in Loop: Header=BB46_51 Depth=1
	add	x20, x20, #1
	add	x21, x21, #24
	cmp	x20, x8
	b.hs	LBB46_66
LBB46_51:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #13360]
	cmp	x9, x22
	b.hi	LBB46_82
; %bb.52:                               ;   in Loop: Header=BB46_51 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #13368]
	cmp	x9, x23
	b.hs	LBB46_82
; %bb.53:                               ;   in Loop: Header=BB46_51 Depth=1
	add	x10, x9, #16
	ldp	x11, x9, [sp]                   ; 16-byte Folded Reload
	str	x10, [x9, #13368]
	ldr	x10, [x9, #256]
	add	x12, x10, x21
	ldr	x11, [x11, #256]
	add	x13, x11, x21
	ldur	w14, [x12, #-21]
	ldur	w15, [x13, #-21]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.54:                               ;   in Loop: Header=BB46_51 Depth=1
	ldurh	w3, [x12, #-17]
	ldurh	w12, [x13, #-17]
	cmp	w3, w12
	b.ne	LBB46_3
; %bb.55:                               ;   in Loop: Header=BB46_51 Depth=1
	add	x12, x10, x21
	ldur	w14, [x12, #-13]
	add	x13, x11, x21
	ldur	w15, [x13, #-13]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.56:                               ;   in Loop: Header=BB46_51 Depth=1
	ldur	w12, [x12, #-9]
	ldur	w13, [x13, #-9]
	cmp	w12, w13
	b.ne	LBB46_3
; %bb.57:                               ;   in Loop: Header=BB46_51 Depth=1
	add	x12, x10, x21
	ldurh	w14, [x12, #-5]
	add	x13, x11, x21
	ldurh	w15, [x13, #-5]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.58:                               ;   in Loop: Header=BB46_51 Depth=1
	ldurh	w12, [x12, #-3]
	ldurh	w13, [x13, #-3]
	cmp	w12, w13
	b.ne	LBB46_3
; %bb.59:                               ;   in Loop: Header=BB46_51 Depth=1
	add	x12, x10, x21
	ldurb	w12, [x12, #-1]
	add	x13, x11, x21
	ldurb	w13, [x13, #-1]
	cmp	w12, w13
	b.ne	LBB46_3
; %bb.60:                               ;   in Loop: Header=BB46_51 Depth=1
	ldrb	w10, [x10, x21]
	ldrb	w11, [x11, x21]
	cmp	w10, w11
	b.ne	LBB46_3
; %bb.61:                               ;   in Loop: Header=BB46_51 Depth=1
	ldr	x9, [x9, #264]
	cbz	x9, LBB46_50
; %bb.62:                               ;   in Loop: Header=BB46_51 Depth=1
	ldr	x1, [x9, x20, lsl #3]
	cmp	x1, #0
	cset	w10, ne
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [x9, #264]
	ldr	x2, [x9, x20, lsl #3]
	cmp	x2, #0
	cset	w9, eq
	cmp	w10, w9
	b.eq	LBB46_3
; %bb.63:                               ;   in Loop: Header=BB46_51 Depth=1
	cbz	x1, LBB46_50
; %bb.64:                               ;   in Loop: Header=BB46_51 Depth=1
	ldr	x19, [sp, #8]                   ; 8-byte Folded Reload
	mov	x0, x19
	bl	_rae_equal_bytes
	cbz	w0, LBB46_3
; %bb.65:                               ;   in Loop: Header=BB46_51 Depth=1
	ldr	w8, [x19, #272]
	b	LBB46_50
LBB46_66:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #248]
	cbz	w8, LBB46_73
; %bb.67:
	mov	x19, #0                         ; =0x0
	mov	w20, #134217728                 ; =0x8000000
LBB46_68:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #13360]
	cmp	x8, x20
	b.hi	LBB46_82
; %bb.69:                               ;   in Loop: Header=BB46_68 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #13368]
	lsr	x9, x8, #25
	cbnz	x9, LBB46_82
; %bb.70:                               ;   in Loop: Header=BB46_68 Depth=1
	add	x8, x8, #1
	ldp	x10, x9, [sp]                   ; 16-byte Folded Reload
	str	x8, [x9, #13368]
	ldr	x8, [x9, #240]
	ldr	w8, [x8, x19, lsl #2]
	ldr	x11, [x10, #240]
	ldr	w11, [x11, x19, lsl #2]
	cmp	w8, w11
	b.ne	LBB46_3
; %bb.71:                               ;   in Loop: Header=BB46_68 Depth=1
	ldr	x9, [x9, #232]
	ldr	x1, [x9, x19, lsl #3]
	ldr	x9, [x10, #232]
	ldr	x2, [x9, x19, lsl #3]
	add	x3, x8, #1
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_rae_equal_bytes
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	w0, LBB46_3
; %bb.72:                               ;   in Loop: Header=BB46_68 Depth=1
	add	x19, x19, #1
	ldr	w8, [x8, #248]
	cmp	x19, x8
	b.lo	LBB46_68
LBB46_73:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w10, [x8, #368]
	cbz	w10, LBB46_80
; %bb.74:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB46_82
; %bb.75:
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #13368]
	lsl	x10, x10, #3
	mov	w11, #33554431                  ; =0x1ffffff
LBB46_76:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x11
	b.hs	LBB46_82
; %bb.77:                               ;   in Loop: Header=BB46_76 Depth=1
	add	x12, x9, #2
	ldp	x13, x15, [sp]                  ; 16-byte Folded Reload
	str	x12, [x15, #13368]
	ldr	x12, [x15, #360]
	ldr	w14, [x12, x8]
	ldr	x13, [x13, #360]
	ldr	w15, [x13, x8]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.78:                               ;   in Loop: Header=BB46_76 Depth=1
	add	x12, x12, x8
	ldr	w12, [x12, #4]
	add	x13, x13, x8
	ldr	w13, [x13, #4]
	cmp	w12, w13
	b.ne	LBB46_3
; %bb.79:                               ;   in Loop: Header=BB46_76 Depth=1
	add	x8, x8, #8
	add	x9, x9, #2
	cmp	x10, x8
	b.ne	LBB46_76
LBB46_80:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w10, [x8, #384]
	cbz	w10, LBB46_89
; %bb.81:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.ls	LBB46_83
LBB46_82:
	mov	w9, #3                          ; =0x3
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	w9, [x8, #13376]
	b	LBB46_3
LBB46_83:
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #13368]
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #2
	mov	w11, #33554430                  ; =0x1fffffe
LBB46_84:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x11
	b.hs	LBB46_82
; %bb.85:                               ;   in Loop: Header=BB46_84 Depth=1
	add	x12, x9, #3
	ldp	x13, x15, [sp]                  ; 16-byte Folded Reload
	str	x12, [x15, #13368]
	ldr	x12, [x15, #376]
	ldr	w14, [x12, x8]
	ldr	x13, [x13, #376]
	ldr	w15, [x13, x8]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.86:                               ;   in Loop: Header=BB46_84 Depth=1
	add	x12, x12, x8
	ldr	w14, [x12, #4]
	add	x13, x13, x8
	ldr	w15, [x13, #4]
	cmp	w14, w15
	b.ne	LBB46_3
; %bb.87:                               ;   in Loop: Header=BB46_84 Depth=1
	ldr	w12, [x12, #8]
	ldr	w13, [x13, #8]
	cmp	w12, w13
	b.ne	LBB46_3
; %bb.88:                               ;   in Loop: Header=BB46_84 Depth=1
	add	x8, x8, #12
	add	x9, x9, #3
	cmp	x10, x8
	b.ne	LBB46_84
LBB46_89:
	ldp	x20, x19, [sp]                  ; 16-byte Folded Reload
	ldr	x1, [x19, #280]
	ldr	x2, [x20, #280]
	ldr	w3, [x19, #288]
	mov	x0, x19
	bl	_rae_equal_bytes
	cbz	w0, LBB46_3
; %bb.90:
	ldr	x1, [x19, #312]
	ldr	x2, [x20, #312]
	ldr	w3, [x19, #320]
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_rae_equal_bytes
	mov	x8, x0
	ldp	x9, x0, [sp]                    ; 16-byte Folded Reload
	cbz	w8, LBB46_3
; %bb.91:
	ldr	x1, [x0, #296]
	ldr	x2, [x9, #296]
	ldr	w3, [x0, #304]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	b	_rae_equal_bytes
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_counts ; -- Begin function nvm_record_array_execution_counts
	.globl	_nvm_record_array_execution_counts
	.p2align	2
_nvm_record_array_execution_counts:     ; @nvm_record_array_execution_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB47_2
; %bb.1:
	add	x8, x8, #488
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x1, #32]
	stp	q0, q1, [x1]
LBB47_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_function ; -- Begin function nvm_record_array_execution_function
	.globl	_nvm_record_array_execution_function
	.p2align	2
_nvm_record_array_execution_function:   ; @nvm_record_array_execution_function
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB48_4
; %bb.1:
	cbz	x2, LBB48_4
; %bb.2:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB48_5
; %bb.3:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	add	x9, x8, #552
	ldp	q0, q1, [x9]
	ldr	w8, [x8, #584]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB48_4:
	ret
LBB48_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_instruction ; -- Begin function nvm_record_array_execution_instruction
	.globl	_nvm_record_array_execution_instruction
	.p2align	2
_nvm_record_array_execution_instruction: ; @nvm_record_array_execution_instruction
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB49_5
; %bb.1:
	cbz	x2, LBB49_5
; %bb.2:
	ldr	w9, [x8, #492]
	cmp	w1, w9
	b.hs	LBB49_4
; %bb.3:
	ldr	x8, [x8, #13352]
	mov	w9, #72                         ; =0x48
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8]
	str	q0, [x2]
	ldp	q0, q1, [x8, #16]
	ldr	q2, [x8, #48]
	ldr	x8, [x8, #64]
	str	x8, [x2, #64]
	stp	q1, q2, [x2, #32]
	str	q0, [x2, #16]
	mov	w0, #1                          ; =0x1
	ret
LBB49_4:
	mov	w0, #0                          ; =0x0
LBB49_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_parameter ; -- Begin function nvm_record_array_execution_parameter
	.globl	_nvm_record_array_execution_parameter
	.p2align	2
_nvm_record_array_execution_parameter:  ; @nvm_record_array_execution_parameter
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB50_7
; %bb.1:
	cbz	x3, LBB50_7
; %bb.2:
	ldr	w8, [x0, #488]
	cmp	w1, w8
	b.hs	LBB50_6
; %bb.3:
	mov	w8, #36                         ; =0x24
	umaddl	x8, w1, w8, x0
	ldrb	w8, [x8, #586]
	cbz	w8, LBB50_7
; %bb.4:
	mov	w8, w1
	ldr	x9, [x0, #256]
	mov	w10, #24                        ; =0x18
	umaddl	x9, w8, w10, x9
	ldrh	w9, [x9, #4]
	cmp	w2, w9
	b.hs	LBB50_6
; %bb.5:
	ldr	x9, [x0, #264]
	ldr	x8, [x9, x8, lsl #3]
	ldrb	w8, [x8, w2, uxtw]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB50_6:
	mov	w8, #0                          ; =0x0
LBB50_7:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_bytes ; -- Begin function nvm_record_array_execution_bytes
	.globl	_nvm_record_array_execution_bytes
	.p2align	2
_nvm_record_array_execution_bytes:      ; @nvm_record_array_execution_bytes
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB51_22
; %bb.1:
	cbz	x5, LBB51_22
; %bb.2:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB51_7
; %bb.3:
	cbz	w1, LBB51_11
; %bb.4:
	cmp	w1, #1
	b.ne	LBB51_22
; %bb.5:
	cbz	w2, LBB51_15
; %bb.6:
	mov	w0, #0                          ; =0x0
	ret
LBB51_7:
	cmp	w1, #2
	b.eq	LBB51_13
; %bb.8:
	cmp	w1, #3
	b.ne	LBB51_22
; %bb.9:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB51_14
; %bb.10:
	ldp	x9, x8, [x8, #232]
	add	x9, x9, w2, uxtw #3
	add	x8, x8, w2, uxtw #2
	b	LBB51_18
LBB51_11:
	cbz	w2, LBB51_16
; %bb.12:
	mov	w0, #0                          ; =0x0
	ret
LBB51_13:
	cbz	w2, LBB51_17
LBB51_14:
	mov	w0, #0                          ; =0x0
	ret
LBB51_15:
	add	x9, x8, #312
	add	x8, x8, #320
	b	LBB51_18
LBB51_16:
	add	x9, x8, #280
	add	x8, x8, #288
	b	LBB51_18
LBB51_17:
	add	x9, x8, #296
	add	x8, x8, #304
LBB51_18:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x8]
	subs	w8, w8, w3
	b.lo	LBB51_22
; %bb.19:
	cmp	w4, w8
	b.hi	LBB51_22
; %bb.20:
	cbz	w4, LBB51_23
; %bb.21:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x9]
	add	x1, x8, w3, uxtw
	mov	w2, w4
	mov	x0, x5
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB51_22:
	ret
LBB51_23:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_origin ; -- Begin function nvm_record_array_execution_origin
	.globl	_nvm_record_array_execution_origin
	.p2align	2
_nvm_record_array_execution_origin:     ; @nvm_record_array_execution_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB52_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB52_5
; %bb.2:
	ldr	x8, [x8, #480]
	cbz	x8, LBB52_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB52_6
; %bb.4:
	mov	w9, #48                         ; =0x30
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	ldur	q2, [x8, #56]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB52_5:
	ret
LBB52_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_field_value ; -- Begin function nvm_record_array_execution_field_value
	.globl	_nvm_record_array_execution_field_value
	.p2align	2
_nvm_record_array_execution_field_value: ; @nvm_record_array_execution_field_value
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB53_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB53_5
; %bb.2:
	ldr	x8, [x8, #480]
	cbz	x8, LBB53_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB53_6
; %bb.4:
	ldr	x8, [x8, #3096]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB53_5:
	ret
LBB53_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_required_elements ; -- Begin function nvm_record_array_execution_required_elements
	.globl	_nvm_record_array_execution_required_elements
	.p2align	2
_nvm_record_array_execution_required_elements: ; @nvm_record_array_execution_required_elements
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB54_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB54_5
; %bb.2:
	ldr	x8, [x8, #480]
	cbz	x8, LBB54_5
; %bb.3:
	ldr	x9, [x8, #8]
	ldr	w9, [x9]
	cmp	w1, w9
	b.hs	LBB54_6
; %bb.4:
	add	x8, x8, w1, uxtw #1
	ldrh	w8, [x8, #16]
	strh	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB54_5:
	ret
LBB54_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_layout ; -- Begin function nvm_record_array_execution_layout
	.globl	_nvm_record_array_execution_layout
	.p2align	2
_nvm_record_array_execution_layout:     ; @nvm_record_array_execution_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB55_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB55_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_layout
LBB55_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_type ; -- Begin function nvm_record_array_execution_type
	.globl	_nvm_record_array_execution_type
	.p2align	2
_nvm_record_array_execution_type:       ; @nvm_record_array_execution_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB56_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB56_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_type
LBB56_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_binding ; -- Begin function nvm_record_array_execution_binding
	.globl	_nvm_record_array_execution_binding
	.p2align	2
_nvm_record_array_execution_binding:    ; @nvm_record_array_execution_binding
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB57_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB57_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_binding
LBB57_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_declaration_counts ; -- Begin function nvm_record_array_execution_declaration_counts
	.globl	_nvm_record_array_execution_declaration_counts
	.p2align	2
_nvm_record_array_execution_declaration_counts: ; @nvm_record_array_execution_declaration_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB58_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB58_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_counts
LBB58_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_field ; -- Begin function nvm_record_array_execution_field
	.globl	_nvm_record_array_execution_field
	.p2align	2
_nvm_record_array_execution_field:      ; @nvm_record_array_execution_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB59_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB59_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_field
LBB59_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_variant ; -- Begin function nvm_record_array_execution_variant
	.globl	_nvm_record_array_execution_variant
	.p2align	2
_nvm_record_array_execution_variant:    ; @nvm_record_array_execution_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB60_3
; %bb.1:
	ldr	x8, [x0, #480]
	cbz	x8, LBB60_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_variant
LBB60_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_header ; -- Begin function nvm_record_array_execution_header
	.globl	_nvm_record_array_execution_header
	.p2align	2
_nvm_record_array_execution_header:     ; @nvm_record_array_execution_header
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB61_2
; %bb.1:
	ldp	q0, q1, [x8]
	stp	q0, q1, [x1]
LBB61_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_section ; -- Begin function nvm_record_array_execution_section
	.globl	_nvm_record_array_execution_section
	.p2align	2
_nvm_record_array_execution_section:    ; @nvm_record_array_execution_section
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB62_4
; %bb.1:
	cbz	x2, LBB62_4
; %bb.2:
	ldr	w9, [x8, #224]
	cmp	w1, w9
	b.hs	LBB62_5
; %bb.3:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8, #32]
	ldr	w8, [x8, #40]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB62_4:
	ret
LBB62_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_metadata ; -- Begin function nvm_record_array_execution_metadata
	.globl	_nvm_record_array_execution_metadata
	.p2align	2
_nvm_record_array_execution_metadata:   ; @nvm_record_array_execution_metadata
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB63_5
; %bb.1:
	cbz	x2, LBB63_5
; %bb.2:
	ldr	w9, [x8, #368]
	cmp	w1, w9
	b.hs	LBB63_4
; %bb.3:
	ldr	x8, [x8, #360]
	ldr	x8, [x8, w1, uxtw #3]
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB63_4:
	mov	w0, #0                          ; =0x0
LBB63_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_debug ; -- Begin function nvm_record_array_execution_debug
	.globl	_nvm_record_array_execution_debug
	.p2align	2
_nvm_record_array_execution_debug:      ; @nvm_record_array_execution_debug
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB64_5
; %bb.1:
	cbz	x2, LBB64_5
; %bb.2:
	ldr	w9, [x8, #384]
	cmp	w1, w9
	b.hs	LBB64_4
; %bb.3:
	ldr	x8, [x8, #376]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB64_4:
	mov	w0, #0                          ; =0x0
LBB64_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_size ; -- Begin function nvm_record_array_execution_size
	.globl	_nvm_record_array_execution_size
	.p2align	2
_nvm_record_array_execution_size:       ; @nvm_record_array_execution_size
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB65_15
; %bb.1:
	cbz	x3, LBB65_15
; %bb.2:
	mov	w8, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB65_7
; %bb.3:
	cbz	w1, LBB65_11
; %bb.4:
	cmp	w1, #1
	b.ne	LBB65_15
; %bb.5:
	cbnz	w2, LBB65_14
; %bb.6:
	add	x8, x0, #320
	b	LBB65_17
LBB65_7:
	cmp	w1, #2
	b.eq	LBB65_13
; %bb.8:
	cmp	w1, #3
	b.ne	LBB65_15
; %bb.9:
	ldr	w8, [x0, #248]
	cmp	w2, w8
	b.hs	LBB65_14
; %bb.10:
	ldr	x8, [x0, #240]
	add	x8, x8, w2, uxtw #2
	b	LBB65_17
LBB65_11:
	cbnz	w2, LBB65_14
; %bb.12:
	add	x8, x0, #288
	b	LBB65_17
LBB65_13:
	cbz	w2, LBB65_16
LBB65_14:
	mov	w8, #0                          ; =0x0
LBB65_15:
	mov	x0, x8
	ret
LBB65_16:
	add	x8, x0, #304
LBB65_17:
	ldr	w8, [x8]
	str	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_origin_counts ; -- Begin function nvm_record_array_execution_origin_counts
	.globl	_nvm_record_array_execution_origin_counts
	.p2align	2
_nvm_record_array_execution_origin_counts: ; @nvm_record_array_execution_origin_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB66_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB66_4
; %bb.2:
	ldr	x8, [x8, #480]
	cbz	x8, LBB66_4
; %bb.3:
	ldp	q0, q1, [x8, #144]
	ldr	x8, [x8, #176]
	str	x8, [x1, #32]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB66_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_execution_descriptor ; -- Begin function nvm_record_array_execution_descriptor
	.globl	_nvm_record_array_execution_descriptor
	.p2align	2
_nvm_record_array_execution_descriptor: ; @nvm_record_array_execution_descriptor
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB67_4
; %bb.1:
	cbz	x2, LBB67_4
; %bb.2:
	ldr	w9, [x8, #528]
	cmp	w1, w9
	b.hs	LBB67_5
; %bb.3:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8, #10280]
	ldr	w8, [x8, #10288]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB67_4:
	ret
LBB67_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_image_bound ; -- Begin function nvm_record_array_image_bound
	.globl	_nvm_record_array_image_bound
	.p2align	2
_nvm_record_array_image_bound:          ; @nvm_record_array_image_bound
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB68_25
; %bb.1:
	cbz	x1, LBB68_25
; %bb.2:
	stp	d13, d12, [sp, #-48]!           ; 16-byte Folded Spill
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset b8, -8
	.cfi_offset b9, -16
	.cfi_offset b10, -24
	.cfi_offset b11, -32
	.cfi_offset b12, -40
	.cfi_offset b13, -48
	ldr	w10, [x0, #272]
	ldr	w9, [x0, #288]
	ldr	w11, [x0, #304]
	ldr	w12, [x0, #320]
	ldr	w14, [x0, #368]
	ldr	w15, [x0, #384]
	ldr	w8, [x0, #248]
	add	x13, x15, x15, lsl #1
	add	x16, x11, x9
	add	x9, x16, x10, lsl #4
	add	x9, x9, x12
	add	x9, x9, x14, lsl #1
	add	x9, x9, x13
	add	x13, x9, #1028
	ldr	x11, [x0, #264]
	lsl	x9, x10, #3
	cmp	x11, #0
	csel	x17, xzr, x9, eq
	add	x15, x8, x15
	mov	w2, #12                         ; =0xc
	mov	w3, #24                         ; =0x18
	umaddl	x16, w10, w3, x16
	add	x12, x16, x12
	add	x12, x12, x14, lsl #3
	add	x12, x12, x17
	madd	x12, x15, x2, x12
	mov	w14, #13384                     ; =0x3448
	add	x12, x12, x14
	cbz	w10, LBB68_8
; %bb.3:
	mov	w14, #4                         ; =0x4
	mov	x15, x11
	b	LBB68_5
LBB68_4:                                ;   in Loop: Header=BB68_5 Depth=1
	add	x15, x15, #8
	add	x14, x14, #24
	subs	x10, x10, #1
	b.eq	LBB68_8
LBB68_5:                                ; =>This Inner Loop Header: Depth=1
	cbz	x11, LBB68_4
; %bb.6:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x16, [x15]
	cbz	x16, LBB68_4
; %bb.7:                                ;   in Loop: Header=BB68_5 Depth=1
	ldr	x16, [x0, #256]
	ldrh	w16, [x16, x14]
	cmp	w16, #0
	csinc	x17, x16, xzr, ne
	add	x12, x17, x12
	add	x13, x13, x16
	b	LBB68_4
LBB68_8:
	cbz	w8, LBB68_22
; %bb.9:
	ldr	x10, [x0, #240]
	cmp	w8, #1
	b.ne	LBB68_11
; %bb.10:
	mov	x11, #0                         ; =0x0
	b	LBB68_20
LBB68_11:
	cmp	w8, #16
	b.hs	LBB68_13
; %bb.12:
	mov	x11, #0                         ; =0x0
	b	LBB68_17
LBB68_13:
	and	x11, x8, #0xfffffff0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.d	v1[0], x12
	movi.2d	v2, #0000000000000000
	mov.d	v2[0], x13
	mov	w12, #2                         ; =0x2
	dup.2d	v3, x12
	add	x12, x10, #32
	movi.2d	v4, #0000000000000000
	mov	x13, x11
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB68_14:                               ; =>This Inner Loop Header: Depth=1
	ldp	q25, q26, [x12, #-32]
	ushll.2d	v27, v25, #0
	ushll2.2d	v28, v25, #0
	ushll.2d	v29, v26, #0
	ushll2.2d	v30, v26, #0
	ldp	q31, q8, [x12], #64
	ushll.2d	v9, v31, #0
	ushll2.2d	v10, v31, #0
	ushll.2d	v11, v8, #0
	ushll2.2d	v12, v8, #0
	mvn.16b	v0, v0
	sub.2d	v0, v28, v0
	mvn.16b	v1, v1
	sub.2d	v1, v27, v1
	mvn.16b	v6, v6
	sub.2d	v6, v30, v6
	mvn.16b	v4, v4
	sub.2d	v4, v29, v4
	mvn.16b	v5, v5
	sub.2d	v5, v10, v5
	mvn.16b	v7, v7
	sub.2d	v7, v9, v7
	mvn.16b	v16, v16
	sub.2d	v16, v12, v16
	mvn.16b	v17, v17
	sub.2d	v17, v11, v17
	uaddw.2d	v2, v2, v25
	uaddw2.2d	v18, v18, v25
	uaddw.2d	v23, v23, v26
	uaddw2.2d	v19, v19, v26
	uaddw.2d	v21, v21, v31
	uaddw2.2d	v22, v22, v31
	uaddw.2d	v24, v24, v8
	uaddw2.2d	v20, v20, v8
	add.2d	v18, v18, v3
	add.2d	v2, v2, v3
	add.2d	v19, v19, v3
	add.2d	v23, v23, v3
	add.2d	v22, v22, v3
	add.2d	v21, v21, v3
	add.2d	v20, v20, v3
	add.2d	v24, v24, v3
	subs	x13, x13, #16
	b.ne	LBB68_14
; %bb.15:
	add.2d	v1, v4, v1
	add.2d	v0, v6, v0
	add.2d	v3, v17, v7
	add.2d	v1, v3, v1
	add.2d	v3, v16, v5
	add.2d	v0, v3, v0
	add.2d	v0, v1, v0
	addp.2d	d0, v0
	fmov	x12, d0
	add.2d	v0, v23, v2
	add.2d	v1, v19, v18
	add.2d	v1, v22, v1
	add.2d	v0, v21, v0
	add.2d	v0, v24, v0
	add.2d	v1, v20, v1
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x13, d0
	cmp	x11, x8
	b.eq	LBB68_22
; %bb.16:
	tst	x8, #0xe
	b.eq	LBB68_20
LBB68_17:
	mov	x14, x11
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.d	v1[0], x12
	mov.d	v0[0], x13
	and	x11, x8, #0xfffffffe
	sub	x12, x14, x11
	add	x13, x10, x14, lsl #2
	mov	w14, #2                         ; =0x2
	dup.2d	v2, x14
LBB68_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	d3, [x13], #8
	ushll.2d	v4, v3, #0
	mvn.16b	v1, v1
	sub.2d	v1, v4, v1
	uaddw.2d	v0, v0, v3
	add.2d	v0, v0, v2
	adds	x12, x12, #2
	b.ne	LBB68_18
; %bb.19:
	addp.2d	d1, v1
	fmov	x12, d1
	addp.2d	d0, v0
	fmov	x13, d0
	cmp	x11, x8
	b.eq	LBB68_22
LBB68_20:
	add	x10, x10, x11, lsl #2
	sub	x11, x8, x11
LBB68_21:                               ; =>This Inner Loop Header: Depth=1
	ldr	w14, [x10], #4
	add	x12, x12, x14
	add	x12, x12, #1
	add	x13, x13, x14
	add	x13, x13, #2
	subs	x11, x11, #1
	b.ne	LBB68_21
LBB68_22:
	add	x8, x9, x8, lsl #2
	add	x8, x8, x13
	add	x8, x8, x12
	add	x8, x8, #1024
	mov	w9, #134217728                  ; =0x8000000
	cmp	x12, x9
	mov	w9, #1                          ; =0x1
	movk	w9, #512, lsl #16
	ccmp	x8, x9, #2, ls
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp], #48             ; 16-byte Folded Reload
	b.lo	LBB68_24
; %bb.23:
	mov	w0, #0                          ; =0x0
	ret
LBB68_24:
	stp	x12, x8, [x1]
	mov	w8, #1                          ; =0x1
LBB68_25:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_image_copy ; -- Begin function nvm_record_array_image_copy
	.globl	_nvm_record_array_image_copy
	.p2align	2
_nvm_record_array_image_copy:           ; @nvm_record_array_image_copy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
Lloh30:
	adrp	x8, l___const.nvm_record_array_image_copy.result@PAGE
Lloh31:
	add	x8, x8, l___const.nvm_record_array_image_copy.result@PAGEOFF
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x19, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x19]
	cbz	x0, LBB69_14
; %bb.1:
	cbz	x1, LBB69_14
; %bb.2:
	mov	x20, x0
	mov	x22, x1
	mov	x1, sp
	bl	_nvm_record_array_image_bound
	tbz	w0, #0, LBB69_9
; %bb.3:
	mov	w0, #1                          ; =0x1
	mov	w1, #13384                      ; =0x3448
	bl	_calloc
	cbz	x0, LBB69_12
; %bb.4:
	mov	x21, x0
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #13376]
	mov	w8, #13384                      ; =0x3448
	dup.2d	v0, x8
	str	q0, [x0, #13360]
	mov	x1, x20
	bl	_rae_snapshot
	cbz	w0, LBB69_10
; %bb.5:
	mov	x0, x21
	mov	x1, x20
	bl	_rae_same
	cbz	w0, LBB69_10
; %bb.6:
	ldr	x9, [x21, #13360]
	ldr	x8, [sp]
	cmp	x9, x8
	b.hi	LBB69_8
; %bb.7:
	ldr	x10, [x21, #13368]
	ldr	x9, [sp, #8]
	cmp	x10, x9
	b.ls	LBB69_15
LBB69_8:
	mov	w8, #3                          ; =0x3
	b	LBB69_11
LBB69_9:
	mov	w8, #3                          ; =0x3
	b	LBB69_13
LBB69_10:
	ldr	w8, [x21, #13376]
LBB69_11:
	str	w8, [x19]
	mov	x0, x21
	bl	_rae_snapshot_free
	mov	x0, x21
	bl	_free
	b	LBB69_14
LBB69_12:
	mov	w8, #4                          ; =0x4
LBB69_13:
	str	w8, [x19]
LBB69_14:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB69_15:
	str	x8, [x21, #13360]
	str	x9, [x21, #13368]
	str	x21, [x22]
	str	wzr, [x19]
Lloh32:
	adrp	x8, l_.str.8@PAGE
Lloh33:
	add	x8, x8, l_.str.8@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	ldur	q0, [x8, #46]
	stur	q0, [x19, #58]
	b	LBB69_14
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_image_free ; -- Begin function nvm_record_array_image_free
	.globl	_nvm_record_array_image_free
	.p2align	2
_nvm_record_array_image_free:           ; @nvm_record_array_image_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB70_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_rae_snapshot_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB70_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_image_borrow ; -- Begin function nvm_record_array_image_borrow
	.globl	_nvm_record_array_image_borrow
	.p2align	2
_nvm_record_array_image_borrow:         ; @nvm_record_array_image_borrow
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_image_cost ; -- Begin function nvm_record_array_image_cost
	.globl	_nvm_record_array_image_cost
	.p2align	2
_nvm_record_array_image_cost:           ; @nvm_record_array_image_cost
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB72_2
; %bb.1:
	ldr	q0, [x8, #13360]
	str	q0, [x1]
LBB72_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_free ; -- Begin function nvm_union_field_execution_free
	.globl	_nvm_union_field_execution_free
	.p2align	2
_nvm_union_field_execution_free:        ; @nvm_union_field_execution_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB73_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x0, [x0]
	bl	_nvm_record_array_execution_free
	ldr	x20, [x19, #8]
	cbz	x20, LBB73_3
; %bb.2:
	ldr	x0, [x20]
	bl	_nvm_union_field_declarations_free
	ldr	x0, [x20, #8]
	bl	_free
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #24]
	bl	_free
	ldr	x0, [x20, #32]
	bl	_free
	mov	x0, x20
	bl	_free
LBB73_3:
	ldr	x0, [x19, #16]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB73_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_union_field_execution ; -- Begin function nvm_prepare_union_field_execution
	.globl	_nvm_prepare_union_field_execution
	.p2align	2
_nvm_prepare_union_field_execution:     ; @nvm_prepare_union_field_execution
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_ufe_prepare_reserved
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufe_prepare_reserved
_ufe_prepare_reserved:                  ; @ufe_prepare_reserved
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2816
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh34:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh35:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh36:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
Lloh37:
	adrp	x8, l___const.ufe_prepare_reserved.result@PAGE
Lloh38:
	add	x8, x8, l___const.ufe_prepare_reserved.result@PAGEOFF
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x19, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x19]
	cbz	x0, LBB75_26
; %bb.1:
	cbz	x1, LBB75_26
; %bb.2:
	mov	w8, #52120                      ; =0xcb98
	movk	w8, #1022, lsl #16
	cmp	x2, x8
	b.hi	LBB75_18
; %bb.3:
	mov	w8, #52121                      ; =0xcb99
	movk	w8, #254, lsl #16
	cmp	x3, x8
	b.hs	LBB75_18
; %bb.4:
	mov	x24, x2
	mov	x23, x3
	mov	x22, x0
	mov	x27, x1
	mov	w0, #1                          ; =0x1
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB75_19
; %bb.5:
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #13384                      ; =0x3448
	bl	_calloc
	str	x0, [x20]
	cbz	x0, LBB75_20
; %bb.6:
	mov	x21, x0
	mov	w8, #13416                      ; =0x3468
	movk	w8, #1025, lsl #16
	add	x8, x24, x8
	mov	w9, #13416                      ; =0x3468
	movk	w9, #257, lsl #16
	add	x9, x23, x9
	str	x8, [x0, #13360]
	str	x9, [x0, #13368]
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #13376]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x0, #500]
	mov	x1, x22
	bl	_rae_snapshot
	cbz	w0, LBB75_24
; %bb.7:
	ldr	w23, [x21, #272]
	cbz	w23, LBB75_14
; %bb.8:
	ldr	x24, [x21, #256]
	ldr	w25, [x21, #248]
	mov	w26, #134217728                 ; =0x8000000
	mov	w28, #33554432                  ; =0x2000000
LBB75_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x24], #24
	cmp	w8, w25
	b.hs	LBB75_24
; %bb.10:                               ;   in Loop: Header=BB75_9 Depth=1
	ldr	x9, [x21, #13360]
	cmp	x9, x26
	b.hi	LBB75_17
; %bb.11:                               ;   in Loop: Header=BB75_9 Depth=1
	ldr	x9, [x21, #240]
	ldr	w2, [x9, x8, lsl #2]
	ldr	x9, [x21, #13368]
	sub	x10, x28, x9
	cmp	x9, x28
	ccmp	x10, x2, #0, ls
	b.ls	LBB75_17
; %bb.12:                               ;   in Loop: Header=BB75_9 Depth=1
	add	x10, x2, #1
	add	x9, x10, x9
	str	x9, [x21, #13368]
	ldr	x9, [x21, #232]
	ldr	x0, [x9, x8, lsl #3]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB75_22
; %bb.13:                               ;   in Loop: Header=BB75_9 Depth=1
	subs	x23, x23, #1
	b.ne	LBB75_9
LBB75_14:
	stp	xzr, xzr, [x29, #-136]
	add	x24, x20, #8
	stp	xzr, xzr, [sp]
	sub	x8, x29, #136
	stp	x24, x8, [sp, #16]
	mov	x8, x19
	mov	x0, x21
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	w8, [x19]
	cbnz	w8, LBB75_25
; %bb.15:
	ldur	x8, [x29, #-136]
	str	x8, [x20, #16]
	ldur	w11, [x29, #-128]
	str	w11, [x20, #24]
	cmp	w11, #16, lsl #12               ; =65536
	b.hi	LBB75_24
; %bb.16:
	ldr	x10, [x21, #13360]
	mov	w8, #134217728                  ; =0x8000000
	cmp	x10, x8
	b.ls	LBB75_28
LBB75_17:
	mov	w8, #3                          ; =0x3
	b	LBB75_23
LBB75_18:
	mov	w8, #3                          ; =0x3
	str	w8, [x19]
	b	LBB75_26
LBB75_19:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	b	LBB75_26
LBB75_20:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	ldur	x8, [x29, #-96]
Lloh39:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh40:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh41:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB75_88
; %bb.21:
	mov	x0, x20
	add	sp, sp, #2816
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_nvm_union_field_execution_free
LBB75_22:
	mov	w8, #1                          ; =0x1
LBB75_23:
	str	w8, [x21, #13376]
LBB75_24:
	ldr	w8, [x21, #13376]
	str	w8, [x19]
Lloh42:
	adrp	x8, l_.str.177@PAGE
Lloh43:
	add	x8, x8, l_.str.177@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldur	q0, [x8, #30]
	stur	q0, [x19, #42]
LBB75_25:
	mov	x0, x20
	bl	_nvm_union_field_execution_free
LBB75_26:
	ldur	x8, [x29, #-96]
Lloh44:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh45:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh46:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB75_88
; %bb.27:
	add	sp, sp, #2816
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB75_28:
	ldr	x9, [x21, #13368]
	mov	w8, #3                          ; =0x3
	mov	w12, #33554432                  ; =0x2000000
	cmp	x9, x12
	b.hi	LBB75_23
; %bb.29:
	add	x11, x11, x11, lsl #3
	lsl	x11, x11, #3
	mov	w12, #134217728                 ; =0x8000000
	sub	x12, x12, x10
	cmp	x12, x11
	b.lo	LBB75_23
; %bb.30:
	add	x8, x10, x11
	str	x8, [x21, #13360]
	ldr	w10, [x21, #272]
	lsl	x8, x10, #2
	mov	w11, #33554432                  ; =0x2000000
	sub	x11, x11, x9
	cmp	x8, x11
	b.hi	LBB75_17
; %bb.31:
	add	x26, x9, x8
	str	x26, [x21, #13368]
	cbz	w10, LBB75_36
; %bb.32:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.33:
	mov	x9, #0                          ; =0x0
	mov	w11, #9768                      ; =0x2628
	add	x11, x21, x11
	ldr	w12, [x8, #48]
	lsl	x12, x12, #1
	lsl	x10, x10, #1
LBB75_34:                               ; =>This Inner Loop Header: Depth=1
	cmp	x12, x9
	b.eq	LBB75_24
; %bb.35:                               ;   in Loop: Header=BB75_34 Depth=1
	ldr	x13, [x8, #32]
	ldrh	w13, [x13, x9]
	strh	w13, [x11, x9]
	add	x9, x9, #2
	cmp	x10, x9
	b.ne	LBB75_34
LBB75_36:
	mov	w8, #33554176                   ; =0x1ffff00
	cmp	x26, x8
	b.hi	LBB75_17
; %bb.37:
	mov	w23, #0                         ; =0x0
	mov	w25, #10288                     ; =0x2830
	add	x8, x21, #536
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x8, x26, #256
	str	x8, [x21, #13368]
LBB75_38:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x23
	bl	_nvm_record_array_opcode_supported
	cmp	w23, #254
	csinc	w8, w0, wzr, ne
	cmp	w23, #163
	csinc	w28, w8, wzr, ne
	sub	x1, x29, #208
	mov	x0, x23
	bl	_ufe_recipe
	cmp	w0, w28
	b.ne	LBB75_24
; %bb.39:                               ;   in Loop: Header=BB75_38 Depth=1
	add	w23, w23, #1
	cmp	w23, #256
	b.ne	LBB75_38
; %bb.40:
	mov	w8, #65248                      ; =0xfee0
	movk	w8, #511, lsl #16
	cmp	x26, x8
	b.hi	LBB75_17
; %bb.41:
	add	x8, x26, #288
	str	x8, [x21, #13368]
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.42:
	ldr	x0, [x8]
	sub	x3, x29, #212
	mov	w1, #8                          ; =0x8
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB75_24
; %bb.43:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.44:
	ldr	x0, [x8]
	sub	x3, x29, #216
	mov	w1, #10                         ; =0xa
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB75_24
; %bb.45:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.46:
	ldur	w1, [x29, #-212]
	ldr	x0, [x8]
	sub	x2, x29, #224
	bl	_nvm_union_field_declarations_layout
	cbz	w0, LBB75_24
; %bb.47:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.48:
	ldur	w1, [x29, #-216]
	ldr	x0, [x8]
	sub	x2, x29, #232
	bl	_nvm_union_field_declarations_layout
	cbz	w0, LBB75_24
; %bb.49:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.50:
	ldr	x0, [x8]
	sub	x3, x29, #120
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_variant
	cbz	w0, LBB75_24
; %bb.51:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.52:
	sub	x9, x29, #120
	ldr	x0, [x8]
	add	x3, x9, #12
	mov	w1, #0                          ; =0x0
	mov	w2, #1                          ; =0x1
	bl	_nvm_union_field_declarations_variant
	cbz	w0, LBB75_24
; %bb.53:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.54:
	ldur	w1, [x29, #-212]
	ldr	x0, [x8]
	sub	x3, x29, #244
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_field
	cbz	w0, LBB75_24
; %bb.55:
	ldr	x8, [x24]
	cbz	x8, LBB75_24
; %bb.56:
	ldur	w1, [x29, #-216]
	ldr	x0, [x8]
	sub	x3, x29, #256
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_field
	cbz	w0, LBB75_24
; %bb.57:
	ldp	w26, w23, [x29, #-216]
	cmp	w23, w26
	b.eq	LBB75_24
; %bb.58:
	ldurh	w8, [x29, #-222]
	cmp	w8, #1
	b.ne	LBB75_24
; %bb.59:
	ldurh	w8, [x29, #-230]
	cmp	w8, #1
	b.ne	LBB75_24
; %bb.60:
	ldr	w8, [x21, #468]
	cmp	w8, #1
	b.ne	LBB75_24
; %bb.61:
	ldr	w8, [x21, #476]
	cmp	w8, #1
	b.ne	LBB75_24
; %bb.62:
	str	w8, [x21, #528]
	str	wzr, [x21, #10280]
	str	w23, [x21, #10284]
	str	w8, [x21, x25]
	add	x0, sp, #48
	mov	w1, #2592                       ; =0xa20
	bl	_bzero
	ldr	x8, [x21, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB75_17
; %bb.63:
	ldr	x8, [x21, #13368]
	mov	w9, #33554428                   ; =0x1fffffc
	cmp	x8, x9
	b.hi	LBB75_17
; %bb.64:
	add	x9, x8, #4
	str	x9, [x21, #13368]
	ldr	x12, [x24]
	cbz	x12, LBB75_24
; %bb.65:
	ldr	w10, [x12, #40]
	cmp	w10, #64
	b.hi	LBB75_24
; %bb.66:
	str	w10, [sp, #2632]
	add	x13, x10, x10, lsl #2
	mov	w11, #33554428                  ; =0x1fffffc
	sub	x8, x11, x8
	cmp	x8, x13
	b.lo	LBB75_17
; %bb.67:
	add	x8, x9, x13
	str	x8, [x21, #13368]
	cbz	w10, LBB75_94
; %bb.68:
	mov	x9, #0                          ; =0x0
	add	x10, sp, #48
	add	x11, x10, #2568
	ldr	x12, [x12, #8]
	lsl	x13, x13, #3
	mov	w14, #1                         ; =0x1
	mov	w15, #12                        ; =0xc
	sub	x16, x29, #120
	mov	w17, #1                         ; =0x1
LBB75_69:                               ; =>This Inner Loop Header: Depth=1
	add	x1, x10, x9
	add	x0, x12, x9
	ldp	q0, q1, [x0]
	stp	q0, q1, [x1]
	ldr	x0, [x0, #32]
	str	x0, [x1, #32]
	ldr	w0, [x1, #8]
	cbnz	w0, LBB75_24
; %bb.70:                               ;   in Loop: Header=BB75_69 Depth=1
	ldrb	w0, [x1, #34]
	cbnz	w0, LBB75_24
; %bb.71:                               ;   in Loop: Header=BB75_69 Depth=1
	sub	x0, x17, #1
	ldrb	w2, [x1, #16]
	cmp	w2, #3
	b.eq	LBB75_78
; %bb.72:                               ;   in Loop: Header=BB75_69 Depth=1
	cmp	w2, #1
	b.ne	LBB75_24
; %bb.73:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x1, x10, x9
	ldr	w2, [x1, #12]
	cmp	w2, w23
	b.ne	LBB75_24
; %bb.74:                               ;   in Loop: Header=BB75_69 Depth=1
	ldrb	w1, [x1, #17]
	cmp	w1, #255
	b.ne	LBB75_24
; %bb.75:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x1, x10, x9
	ldrh	w2, [x1, #18]
	cmp	w2, #1
	b.ne	LBB75_24
; %bb.76:                               ;   in Loop: Header=BB75_69 Depth=1
	ldrh	w1, [x1, #32]
	cmp	w1, #1024
	b.ne	LBB75_24
; %bb.77:                               ;   in Loop: Header=BB75_69 Depth=1
	lsl	x0, x14, x0
	ldr	x1, [sp, #2608]
	orr	x0, x1, x0
	str	x0, [sp, #2608]
	b	LBB75_86
LBB75_78:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x2, x10, x9
	ldr	w3, [x2, #12]
	cmp	w3, w26
	b.ne	LBB75_24
; %bb.79:                               ;   in Loop: Header=BB75_69 Depth=1
	ldrb	w2, [x2, #17]
	cmp	x2, #1
	b.hi	LBB75_24
; %bb.80:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x3, x10, x9
	ldrh	w3, [x3, #18]
	umaddl	x4, w2, w15, x16
	ldrh	w4, [x4, #10]
	cmp	w3, w4
	b.ne	LBB75_24
; %bb.81:                               ;   in Loop: Header=BB75_69 Depth=1
	cbz	w3, LBB75_84
; %bb.82:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x3, x10, x9
	ldrh	w3, [x3, #32]
	cmp	w3, #2
	b.ne	LBB75_24
; %bb.83:                               ;   in Loop: Header=BB75_69 Depth=1
	ldr	x1, [x1, #24]
	cbz	x1, LBB75_85
	b	LBB75_24
LBB75_84:                               ;   in Loop: Header=BB75_69 Depth=1
	ldr	x1, [x1, #24]
	add	x3, x10, x9
	ldr	x3, [x3, #32]
	and	x3, x3, #0xffffff
	orr	x1, x3, x1
	cbnz	x1, LBB75_24
LBB75_85:                               ;   in Loop: Header=BB75_69 Depth=1
	lsl	x0, x14, x0
	ldr	x1, [x11, x2, lsl #3]
	orr	x0, x1, x0
	str	x0, [x11, x2, lsl #3]
LBB75_86:                               ;   in Loop: Header=BB75_69 Depth=1
	ldr	w24, [sp, #2632]
	cmp	x17, x24
	b.hs	LBB75_89
; %bb.87:                               ;   in Loop: Header=BB75_69 Depth=1
	add	x9, x9, #40
	add	x17, x17, #1
	cmp	x13, x9
	b.ne	LBB75_69
	b	LBB75_24
LBB75_88:
	bl	___stack_chk_fail
LBB75_89:
	mov	w9, #33554432                   ; =0x2000000
	sub	x9, x9, x8
	cmp	x9, x24
	b.lo	LBB75_17
; %bb.90:
	add	x8, x8, x24
	str	x8, [x21, #13368]
	cbz	w24, LBB75_94
; %bb.91:
	add	x8, sp, #48
	add	x23, x8, #32
LBB75_92:                               ; =>This Inner Loop Header: Depth=1
	ldp	x1, x2, [x23, #-8]
	add	x0, sp, #48
	bl	_ufe_origins_value
	cbz	w0, LBB75_24
; %bb.93:                               ;   in Loop: Header=BB75_92 Depth=1
	add	x23, x23, #40
	subs	x24, x24, #1
	b.ne	LBB75_92
LBB75_94:
Lloh47:
	adrp	x1, _ufe_recipe@PAGE
Lloh48:
	add	x1, x1, _ufe_recipe@PAGEOFF
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_rae_instructions_policy
	cbz	w0, LBB75_24
; %bb.95:
	ldr	w25, [x21, #492]
	ldr	w8, [x20, #24]
	cmp	w25, w8
	b.ne	LBB75_24
; %bb.96:
	ldr	x8, [x21, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB75_17
; %bb.97:
	ldr	x9, [x21, #13368]
	mov	w10, #33554432                  ; =0x2000000
	mov	w8, #3                          ; =0x3
	cmp	x9, x10
	b.hi	LBB75_23
; %bb.98:
	add	x11, x25, x25, lsl #2
	lsl	x11, x11, #4
	sub	x10, x10, x9
	cmp	x11, x10
	b.hi	LBB75_23
; %bb.99:
	add	x8, x9, x11
	str	x8, [x21, #13368]
	cbz	w25, LBB75_103
; %bb.100:
	ldr	x23, [x21, #13352]
	ldr	x24, [x20, #16]
	ldp	w26, w28, [x29, #-216]
LBB75_101:                              ; =>This Inner Loop Header: Depth=1
	sub	x4, x29, #120
	add	x5, sp, #48
	mov	x0, x23
	mov	x1, x24
	mov	x2, x28
	mov	x3, x26
	bl	_ufe_corresponds
	cbz	w0, LBB75_24
; %bb.102:                              ;   in Loop: Header=BB75_101 Depth=1
	add	x23, x23, #72
	add	x24, x24, #72
	subs	x25, x25, #1
	b.ne	LBB75_101
LBB75_103:
	mov	x0, x21
	mov	x1, x22
	bl	_rae_same
	cbz	w0, LBB75_24
; %bb.104:
	ldr	w8, [x21, #248]
	str	w8, [x21, #512]
	ldr	w8, [x21, #224]
	str	w8, [x21, #516]
	ldr	w8, [x21, #368]
	str	w8, [x21, #520]
	ldr	w8, [x21, #384]
	str	w8, [x21, #524]
	ldr	w8, [x21, #272]
	str	w8, [x21, #488]
	ldr	w8, [x21, #12]
	str	w8, [x21, #504]
	mov	w8, #1024                       ; =0x400
	str	w8, [x21, #508]
	ldr	q0, [x21, #13360]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	q0, [x8]
	str	x20, [x27]
	str	wzr, [x19]
Lloh49:
	adrp	x8, l_.str.176@PAGE
Lloh50:
	add	x8, x8, l_.str.176@PAGEOFF
	ldp	q0, q1, [x8]
	ldr	q2, [x8, #32]
	ldur	x8, [x8, #45]
	stur	x8, [x19, #57]
	stur	q2, [x19, #44]
	stur	q1, [x19, #28]
	stur	q0, [x19, #12]
	b	LBB75_26
	.loh AdrpAdd	Lloh37, Lloh38
	.loh AdrpLdrGotLdr	Lloh34, Lloh35, Lloh36
	.loh AdrpLdrGotLdr	Lloh39, Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpLdrGotLdr	Lloh44, Lloh45, Lloh46
	.loh AdrpAdd	Lloh47, Lloh48
	.loh AdrpAdd	Lloh49, Lloh50
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_counts ; -- Begin function nvm_union_field_execution_counts
	.globl	_nvm_union_field_execution_counts
	.p2align	2
_nvm_union_field_execution_counts:      ; @nvm_union_field_execution_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB76_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB76_4
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB76_4
; %bb.3:
	add	x8, x8, #488
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x1, #32]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB76_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_instruction ; -- Begin function nvm_union_field_execution_instruction
	.globl	_nvm_union_field_execution_instruction
	.p2align	2
_nvm_union_field_execution_instruction: ; @nvm_union_field_execution_instruction
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB77_5
; %bb.1:
	cbz	x2, LBB77_5
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w1, w8
	b.hs	LBB77_6
; %bb.3:
	ldr	x8, [x0]
	ldr	w9, [x8, #492]
	cmp	w1, w9
	b.hs	LBB77_6
; %bb.4:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	ldr	x8, [x8, #13352]
	mov	w9, #72                         ; =0x48
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [sp, #32]
	ldp	q1, q0, [x8]
	stp	q1, q0, [sp]
	ldr	x10, [x0, #16]
	umaddl	x9, w1, w9, x10
	ldp	q0, q1, [x9, #32]
	stur	q0, [sp, #104]
	ldp	q2, q0, [x9]
	stur	q0, [sp, #88]
	ldr	x8, [x8, #64]
	str	x8, [sp, #64]
	stur	q1, [sp, #120]
	ldr	x8, [x9, #64]
	str	x8, [sp, #136]
	stur	q2, [sp, #72]
	ldr	q2, [sp, #128]
	ldp	q1, q0, [sp, #64]
	stp	q1, q0, [x2, #64]
	ldp	q1, q0, [sp, #32]
	stp	q1, q0, [x2, #32]
	ldp	q1, q0, [sp]
	stp	q1, q0, [x2]
	ldp	q1, q0, [sp, #96]
	mov	w8, #1                          ; =0x1
	stp	q0, q2, [x2, #112]
	str	q1, [x2, #96]
	add	sp, sp, #144
LBB77_5:
	mov	x0, x8
	ret
LBB77_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_function ; -- Begin function nvm_union_field_execution_function
	.globl	_nvm_union_field_execution_function
	.p2align	2
_nvm_union_field_execution_function:    ; @nvm_union_field_execution_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB78_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB78_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB78_5
; %bb.3:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB78_6
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	add	x9, x8, #552
	ldp	q0, q1, [x9]
	ldr	w8, [x8, #584]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB78_5:
	ret
LBB78_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_parameter ; -- Begin function nvm_union_field_execution_parameter
	.globl	_nvm_union_field_execution_parameter
	.p2align	2
_nvm_union_field_execution_parameter:   ; @nvm_union_field_execution_parameter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB79_7
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB79_7
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB79_7
; %bb.3:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB79_8
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrb	w9, [x9, #586]
	cbz	w9, LBB79_8
; %bb.5:
	mov	w9, w1
	ldr	x10, [x8, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w9, w11, x10
	ldrh	w10, [x10, #4]
	cmp	w2, w10
	b.hs	LBB79_8
; %bb.6:
	ldr	x8, [x8, #264]
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, w2, uxtw]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB79_7:
	ret
LBB79_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_header ; -- Begin function nvm_union_field_execution_header
	.globl	_nvm_union_field_execution_header
	.p2align	2
_nvm_union_field_execution_header:      ; @nvm_union_field_execution_header
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB80_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB80_4
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB80_4
; %bb.3:
	ldp	q0, q1, [x8]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB80_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_size ; -- Begin function nvm_union_field_execution_size
	.globl	_nvm_union_field_execution_size
	.p2align	2
_nvm_union_field_execution_size:        ; @nvm_union_field_execution_size
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB81_20
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB81_20
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB81_20
; %bb.3:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB81_8
; %bb.4:
	cbz	w1, LBB81_12
; %bb.5:
	cmp	w1, #1
	b.ne	LBB81_20
; %bb.6:
	cbz	w2, LBB81_16
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB81_8:
	cmp	w1, #2
	b.eq	LBB81_14
; %bb.9:
	cmp	w1, #3
	b.ne	LBB81_20
; %bb.10:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB81_15
; %bb.11:
	ldr	x8, [x8, #240]
	add	x8, x8, w2, uxtw #2
	b	LBB81_19
LBB81_12:
	cbz	w2, LBB81_17
; %bb.13:
	mov	w0, #0                          ; =0x0
	ret
LBB81_14:
	cbz	w2, LBB81_18
LBB81_15:
	mov	w0, #0                          ; =0x0
	ret
LBB81_16:
	add	x8, x8, #320
	b	LBB81_19
LBB81_17:
	add	x8, x8, #288
	b	LBB81_19
LBB81_18:
	add	x8, x8, #304
LBB81_19:
	ldr	w8, [x8]
	str	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB81_20:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_bytes ; -- Begin function nvm_union_field_execution_bytes
	.globl	_nvm_union_field_execution_bytes
	.p2align	2
_nvm_union_field_execution_bytes:       ; @nvm_union_field_execution_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB82_22
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB82_22
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB82_22
; %bb.3:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB82_8
; %bb.4:
	cbz	w1, LBB82_12
; %bb.5:
	cmp	w1, #1
	b.ne	LBB82_22
; %bb.6:
	cbz	w2, LBB82_16
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB82_8:
	cmp	w1, #2
	b.eq	LBB82_14
; %bb.9:
	cmp	w1, #3
	b.ne	LBB82_22
; %bb.10:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB82_19
; %bb.11:
	ldp	x9, x8, [x8, #232]
	add	x9, x9, w2, uxtw #3
	add	x8, x8, w2, uxtw #2
	b	LBB82_18
LBB82_12:
	cbz	w2, LBB82_17
; %bb.13:
	mov	w0, #0                          ; =0x0
	ret
LBB82_14:
	cbnz	w2, LBB82_19
; %bb.15:
	add	x9, x8, #296
	add	x8, x8, #304
	b	LBB82_18
LBB82_16:
	add	x9, x8, #312
	add	x8, x8, #320
	b	LBB82_18
LBB82_17:
	add	x9, x8, #280
	add	x8, x8, #288
LBB82_18:
	ldr	w8, [x8]
	subs	w8, w8, w3
	ccmp	w4, w8, #2, hs
	b.ls	LBB82_20
LBB82_19:
	mov	w0, #0                          ; =0x0
	ret
LBB82_20:
	cbz	w4, LBB82_23
; %bb.21:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x9]
	add	x1, x8, w3, uxtw
	mov	w2, w4
	mov	x0, x5
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB82_22:
	ret
LBB82_23:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_proof_counts ; -- Begin function nvm_union_field_execution_proof_counts
	.globl	_nvm_union_field_execution_proof_counts
	.p2align	2
_nvm_union_field_execution_proof_counts: ; @nvm_union_field_execution_proof_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB83_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB83_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB83_4
; %bb.3:
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #56]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB83_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_origin ; -- Begin function nvm_union_field_execution_origin
	.globl	_nvm_union_field_execution_origin
	.p2align	2
_nvm_union_field_execution_origin:      ; @nvm_union_field_execution_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB84_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB84_5
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB84_5
; %bb.3:
	ldr	w9, [x8, #40]
	cmp	w1, w9
	b.hs	LBB84_6
; %bb.4:
	ldr	x8, [x8, #8]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB84_5:
	ret
LBB84_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_global ; -- Begin function nvm_union_field_execution_global
	.globl	_nvm_union_field_execution_global
	.p2align	2
_nvm_union_field_execution_global:      ; @nvm_union_field_execution_global
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB85_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB85_5
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB85_5
; %bb.3:
	ldr	w9, [x8, #44]
	cmp	w1, w9
	b.hs	LBB85_6
; %bb.4:
	ldr	x8, [x8, #16]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB85_5:
	ret
LBB85_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_result ; -- Begin function nvm_union_field_execution_result
	.globl	_nvm_union_field_execution_result
	.p2align	2
_nvm_union_field_execution_result:      ; @nvm_union_field_execution_result
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB86_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB86_5
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB86_5
; %bb.3:
	ldr	w9, [x8, #48]
	cmp	w1, w9
	b.hs	LBB86_6
; %bb.4:
	ldr	x8, [x8, #24]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB86_5:
	ret
LBB86_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_layout ; -- Begin function nvm_union_field_execution_layout
	.globl	_nvm_union_field_execution_layout
	.p2align	2
_nvm_union_field_execution_layout:      ; @nvm_union_field_execution_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB87_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB87_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_layout
LBB87_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_field ; -- Begin function nvm_union_field_execution_field
	.globl	_nvm_union_field_execution_field
	.p2align	2
_nvm_union_field_execution_field:       ; @nvm_union_field_execution_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB88_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB88_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_field
LBB88_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_variant ; -- Begin function nvm_union_field_execution_variant
	.globl	_nvm_union_field_execution_variant
	.p2align	2
_nvm_union_field_execution_variant:     ; @nvm_union_field_execution_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB89_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB89_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_variant
LBB89_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_execution_nominal ; -- Begin function nvm_union_field_execution_nominal
	.globl	_nvm_union_field_execution_nominal
	.p2align	2
_nvm_union_field_execution_nominal:     ; @nvm_union_field_execution_nominal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB90_3
; %bb.1:
	ldr	x8, [x0, #8]
	cbz	x8, LBB90_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_nominal
LBB90_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_free ; -- Begin function nvm_union_field_image_free
	.globl	_nvm_union_field_image_free
	.p2align	2
_nvm_union_field_image_free:            ; @nvm_union_field_image_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB91_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_union_field_execution_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB91_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_copy_reserved ; -- Begin function nvm_union_field_image_copy_reserved
	.globl	_nvm_union_field_image_copy_reserved
	.p2align	2
_nvm_union_field_image_copy_reserved:   ; @nvm_union_field_image_copy_reserved
	.cfi_startproc
; %bb.0:
Lloh51:
	adrp	x9, l___const.nvm_union_field_image_copy_reserved.result@PAGE
Lloh52:
	add	x9, x9, l___const.nvm_union_field_image_copy_reserved.result@PAGEOFF
	ldp	q0, q1, [x9, #160]
	stp	q0, q1, [x8, #160]
	ldur	q0, [x9, #188]
	stur	q0, [x8, #188]
	ldp	q0, q1, [x9, #96]
	stp	q0, q1, [x8, #96]
	ldp	q1, q0, [x9, #128]
	stp	q1, q0, [x8, #128]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x9, #64]
	stp	q1, q0, [x8, #64]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x8]
	cbz	x0, LBB92_18
; %bb.1:
	cbz	x3, LBB92_18
; %bb.2:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	adrp	x9, l___const.rme_image_copy_reserved.w@PAGE
	add	x9, x9, l___const.rme_image_copy_reserved.w@PAGEOFF
	str	xzr, [sp, #32]
	ldr	q0, [x9]
	str	q0, [sp, #16]
	add	x9, sp, #16
	add	x10, sp, #8
	subs	x9, x10, x9
	b.lo	LBB92_4
; %bb.3:
	cmp	x9, #24
	b.lo	LBB92_16
LBB92_4:
	ldr	x10, [x0]
	cbz	x10, LBB92_16
; %bb.5:
	mov	x14, x0
	ldr	x0, [x0, #8]
	cbz	x0, LBB92_16
; %bb.6:
	ldr	w9, [x14, #28]
	cbnz	w9, LBB92_16
; %bb.7:
	ldr	x9, [x10, #480]
	cbnz	x9, LBB92_16
; %bb.8:
	ldr	w11, [x10, #272]
	sub	w9, w11, #257
	cmn	w9, #256
	b.lo	LBB92_16
; %bb.9:
	ldr	w9, [x10, #248]
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB92_16
; %bb.10:
	ldr	w12, [x10, #224]
	cmp	w12, #16
	b.hi	LBB92_16
; %bb.11:
	ldr	w13, [x10, #16]
	cmp	w13, #16
	b.hi	LBB92_16
; %bb.12:
	ldr	w13, [x10, #288]
	mov	w15, #16777216                  ; =0x1000000
	cmp	w13, w15
	b.hi	LBB92_16
; %bb.13:
	ldr	w15, [x10, #320]
	mov	w17, #134217728                 ; =0x8000000
	cmp	w15, w17
	b.hi	LBB92_16
; %bb.14:
	ldr	w16, [x10, #304]
	cmp	w16, w17
	b.hi	LBB92_16
; %bb.15:
	str	x14, [sp]                       ; 8-byte Folded Spill
	ldr	w17, [x10, #368]
	mov	w14, #16777216                  ; =0x1000000
	cmp	w17, w14
	b.ls	LBB92_19
LBB92_16:
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
LBB92_17:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB92_18:
	ret
LBB92_19:
	mov	x23, x1
	mov	x22, x8
	ldr	w1, [x10, #384]
	mov	w8, #43690                      ; =0xaaaa
	movk	w8, #170, lsl #16
	cmp	w1, w8
	b.hi	LBB92_78
; %bb.20:
	ldr	w8, [x10, #488]
	cmp	w8, w11
	b.ne	LBB92_78
; %bb.21:
	ldr	w8, [x10, #512]
	cmp	w8, w9
	b.ne	LBB92_78
; %bb.22:
	ldr	w8, [x10, #516]
	cmp	w8, w12
	b.ne	LBB92_78
; %bb.23:
	ldr	w8, [x10, #520]
	cmp	w8, w17
	b.ne	LBB92_78
; %bb.24:
	ldr	w8, [x10, #524]
	cmp	w8, w1
	b.ne	LBB92_78
; %bb.25:
	ldr	w8, [x10, #492]
	cmp	w8, #16, lsl #12                ; =65536
	b.hi	LBB92_78
; %bb.26:
	ldr	x12, [sp]                       ; 8-byte Folded Reload
	ldr	w12, [x12, #24]
	cmp	w12, w8
	b.ne	LBB92_78
; %bb.27:
	ldr	w12, [x0, #48]
	cmp	w12, w11
	b.ne	LBB92_78
; %bb.28:
	ldr	w12, [x0, #44]
	ldr	w14, [x10, #496]
	cmp	w12, w14
	b.ne	LBB92_78
; %bb.29:
	ldr	w12, [x10, #468]
	cmp	w12, #1
	b.ne	LBB92_78
; %bb.30:
	ldr	w12, [x10, #476]
	cmp	w12, #1
	b.ne	LBB92_78
; %bb.31:
	ldr	w12, [x10, #472]
	cbnz	w12, LBB92_78
; %bb.32:
	ldr	w12, [x10, #528]
	cmp	w12, #1
	b.ne	LBB92_78
; %bb.33:
	ldr	x12, [x10, #328]
	cbnz	x12, LBB92_78
; %bb.34:
	ldr	w12, [x10, #336]
	cbnz	w12, LBB92_78
; %bb.35:
	ldr	x12, [x10, #344]
	cbnz	x12, LBB92_78
; %bb.36:
	ldr	w12, [x10, #352]
	cbnz	w12, LBB92_78
; %bb.37:
	ldr	w12, [x10, #432]
	cbnz	w12, LBB92_78
; %bb.38:
	ldr	w12, [x10, #448]
	cbnz	w12, LBB92_78
; %bb.39:
	ldr	w12, [x10, #424]
	cbnz	w12, LBB92_78
; %bb.40:
	ldr	x12, [x10, #456]
	cbnz	x12, LBB92_78
; %bb.41:
	ldr	w12, [x10, #464]
	cbnz	w12, LBB92_78
; %bb.42:
	ldr	x12, [x10, #13352]
	cmp	x12, #0
	cset	w12, ne
	cmp	w8, #0
	cset	w14, eq
	cmp	w14, w12
	b.eq	LBB92_78
; %bb.43:
	cmp	w8, #0
	cset	w14, eq
	ldr	x12, [sp]                       ; 8-byte Folded Reload
	ldr	x12, [x12, #16]
	cmp	x12, #0
	cset	w12, ne
	cmp	w14, w12
	b.eq	LBB92_78
; %bb.44:
	ldr	x5, [x10, #256]
	cbz	x5, LBB92_78
; %bb.45:
	ldr	x12, [x10, #280]
	cmp	x12, #0
	cset	w12, ne
	cmp	w13, #0
	cset	w14, eq
	cmp	w12, w14
	b.eq	LBB92_78
; %bb.46:
	ldr	x12, [x10, #312]
	cmp	x12, #0
	cset	w12, ne
	cmp	w15, #0
	cset	w14, eq
	cmp	w12, w14
	b.eq	LBB92_78
; %bb.47:
	ldr	x12, [x10, #296]
	mov	w14, #64                        ; =0x40
	str	x14, [sp, #16]
	cmp	x12, #0
	cset	w12, ne
	cmp	w16, #0
	cset	w14, eq
	cmp	w12, w14
	b.eq	LBB92_78
; %bb.48:
	ldr	x12, [x10, #360]
	cmp	x12, #0
	cset	w12, ne
	cmp	w17, #0
	cset	w14, eq
	cmp	w12, w14
	b.eq	LBB92_78
; %bb.49:
	ldr	x12, [x10, #376]
	cmp	x12, #0
	cset	w12, ne
	cmp	w1, #0
	cset	w14, eq
	cmp	w12, w14
	b.eq	LBB92_78
; %bb.50:
	mov	x20, x2
	ldr	x12, [x10, #240]
	cmp	x12, #0
	cset	w14, ne
	cmp	w9, #0
	cset	w2, eq
	cmp	w14, w2
	b.eq	LBB92_78
; %bb.51:
	mov	x21, x3
	cmp	w9, #0
	cset	w2, eq
	ldr	x14, [x10, #232]
	cmp	x14, #0
	cset	w3, ne
	cmp	w2, w3
	b.eq	LBB92_78
; %bb.52:
	ldr	x2, [x10, #264]
	cmp	x2, #0
	csel	x6, xzr, x11, eq
	cset	w3, ne
	cmp	x6, #0
	cset	w4, eq
	cmp	w3, w4
	b.eq	LBB92_78
; %bb.53:
	mov	x4, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w7, #24                         ; =0x18
	umull	x7, w11, w7
	mov	w19, #144                       ; =0x90
	umaddl	x7, w8, w19, x7
	add	x13, x13, x15
	add	x13, x13, x16
	add	x13, x7, x13
	add	x13, x13, x17, lsl #3
	mov	w15, #12                        ; =0xc
	umaddl	x13, w1, w15, x13
	add	x13, x13, x9, lsl #2
	mov	w15, #13416                     ; =0x3468
	add	x15, x13, x15
	mov	w13, #65436                     ; =0xff9c
	movk	w13, #511, lsl #16
	add	x16, x6, x9
	add	x19, x15, x16, lsl #3
	add	x11, x11, x11, lsl #3
	lsl	x15, x11, #2
	add	x16, x5, #16
	mov	w11, #104                       ; =0x68
	mov	w17, #33554416                  ; =0x1fffff0
	mov	x1, x2
	mov	w5, #65436                      ; =0xff9c
	movk	w5, #511, lsl #16
LBB92_54:                               ; =>This Inner Loop Header: Depth=1
	sub	x6, x11, #20
	cmp	x6, x17
	b.hi	LBB92_90
; %bb.55:                               ;   in Loop: Header=BB92_54 Depth=1
	cbz	x2, LBB92_57
; %bb.56:                               ;   in Loop: Header=BB92_54 Depth=1
	ldr	x6, [x1]
	cmp	x6, #0
	cset	w6, ne
	b	LBB92_58
LBB92_57:                               ;   in Loop: Header=BB92_54 Depth=1
	mov	w6, #0                          ; =0x0
LBB92_58:                               ;   in Loop: Header=BB92_54 Depth=1
	ldurh	w7, [x16, #-12]
	cmp	w7, #256
	b.hi	LBB92_78
; %bb.59:                               ;   in Loop: Header=BB92_54 Depth=1
	ldrh	w24, [x16], #24
	cmp	w24, #256
	b.hi	LBB92_78
; %bb.60:                               ;   in Loop: Header=BB92_54 Depth=1
	add	x25, x10, x4
	ldrh	w26, [x25, #556]
	cmp	w26, w7
	b.ne	LBB92_78
; %bb.61:                               ;   in Loop: Header=BB92_54 Depth=1
	ldrh	w25, [x25, #568]
	cmp	w25, w24
	b.ne	LBB92_78
; %bb.62:                               ;   in Loop: Header=BB92_54 Depth=1
	add	x24, x10, x4
	ldrb	w25, [x24, #586]
	cmp	w25, w6
	b.ne	LBB92_78
; %bb.63:                               ;   in Loop: Header=BB92_54 Depth=1
	ldr	w24, [x24, #576]
	cmp	w24, w3
	b.ne	LBB92_78
; %bb.64:                               ;   in Loop: Header=BB92_54 Depth=1
	add	x24, x10, x4
	ldr	w24, [x24, #580]
	sub	w25, w8, w3
	cmp	w24, w25
	b.hi	LBB92_78
; %bb.65:                               ;   in Loop: Header=BB92_54 Depth=1
	cmp	w7, #1
	csinc	w7, w7, wzr, hi
	cmp	w6, #0
	csel	x6, x7, xzr, ne
	cbz	x5, LBB92_90
; %bb.66:                               ;   in Loop: Header=BB92_54 Depth=1
	str	x11, [sp, #16]
	cmn	x19, x6
	b.hs	LBB92_90
; %bb.67:                               ;   in Loop: Header=BB92_54 Depth=1
	add	x19, x6, x19
	add	w3, w24, w3
	sub	x5, x5, #20
	add	x11, x11, #20
	add	x4, x4, #36
	add	x1, x1, #8
	cmp	x15, x4
	b.ne	LBB92_54
; %bb.68:
	cmp	w3, w8
	b.ne	LBB92_78
; %bb.69:
	cbz	w9, LBB92_76
; %bb.70:
	sub	x8, x11, #20
	mov	w10, #33554424                  ; =0x1fffff8
LBB92_71:                               ; =>This Inner Loop Header: Depth=1
	cmp	x8, x10
	b.hi	LBB92_90
; %bb.72:                               ;   in Loop: Header=BB92_71 Depth=1
	add	x11, x13, #88
	cmp	x8, x11
	b.hi	LBB92_90
; %bb.73:                               ;   in Loop: Header=BB92_71 Depth=1
	ldr	w11, [x12], #4
	ldr	x15, [x14], #8
	add	x16, x8, #12
	str	x16, [sp, #16]
	cbz	x15, LBB92_78
; %bb.74:                               ;   in Loop: Header=BB92_71 Depth=1
	mvn	x15, x19
	cmp	x11, x15
	b.hs	LBB92_90
; %bb.75:                               ;   in Loop: Header=BB92_71 Depth=1
	add	x11, x19, x11
	add	x19, x11, #1
	add	x8, x8, #12
	subs	x9, x9, #1
	b.ne	LBB92_71
LBB92_76:
	add	x1, sp, #16
	add	x2, sp, #40
	bl	_ufe_proof_retained_cost
	cbz	w0, LBB92_80
; %bb.77:
	cmp	w0, #2
	b.eq	LBB92_90
LBB92_78:
	mov	w9, #2                          ; =0x2
LBB92_79:
	str	w9, [x22]
	b	LBB92_17
LBB92_80:
	ldr	x8, [sp, #40]
	cmn	x19, x8
	b.hs	LBB92_90
; %bb.81:
	add	x8, x8, x19
	str	x8, [sp, #8]
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x19, [x9]
	ldr	w9, [x19, #488]
	mov	w10, #52                        ; =0x34
	umull	x10, w9, w10
	add	x10, x10, #160
	cbz	w9, LBB92_85
; %bb.82:
	ldr	x11, [x19, #256]
	add	x11, x11, #4
	mov	x12, x9
LBB92_83:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w13, [x11], #24
	add	x13, x13, x13, lsl #3
	cmn	x10, x13
	b.hs	LBB92_90
; %bb.84:                               ;   in Loop: Header=BB92_83 Depth=1
	add	x10, x13, x10
	subs	x12, x12, #1
	b.ne	LBB92_83
LBB92_85:
	ldr	w11, [x19, #492]
	mov	w12, #168                       ; =0xa8
	umull	x13, w11, w12
	cmn	x10, x13
	b.hs	LBB92_90
; %bb.86:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	ldr	x12, [x11, #8]
	ldr	w11, [x12, #40]
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	add	x10, x13, x10
	cmn	x10, x11
	b.hs	LBB92_90
; %bb.87:
	ldp	w13, w12, [x12, #44]
	add	x12, x12, x13
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #3
	add	x10, x11, x10
	cmn	x10, x12
	b.hs	LBB92_90
; %bb.88:
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #1
	add	x10, x12, x10
	cmn	x10, x9
	b.hs	LBB92_90
; %bb.89:
	add	x9, x10, x9
	cmn	x9, #137
	b.ls	LBB92_91
LBB92_90:
	mov	w9, #3                          ; =0x3
	b	LBB92_79
LBB92_91:
	cmn	x8, x23
	b.hs	LBB92_101
; %bb.92:
	ldr	x10, [sp, #16]
	cmn	x10, x20
	b.hs	LBB92_101
; %bb.93:
	add	x23, x8, x23
	cmn	x23, #33
	b.hi	LBB92_101
; %bb.94:
	add	x8, x10, x20
	cmn	x8, #33
	b.hi	LBB92_101
; %bb.95:
	add	x10, x9, #136
	mov	x11, #-33                       ; =0xffffffffffffffdf
	sub	x11, x11, x8
	cmp	x10, x11
	b.hi	LBB92_101
; %bb.96:
	mov	w10, #52088                     ; =0xcb78
	movk	w10, #1022, lsl #16
	cmp	x23, x10
	b.hi	LBB92_101
; %bb.97:
	add	x8, x9, x8
	add	x24, x8, #168
	mov	w8, #52121                      ; =0xcb99
	movk	w8, #254, lsl #16
	cmp	x24, x8
	b.hs	LBB92_101
; %bb.98:
	mov	w0, #1                          ; =0x1
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB92_102
; %bb.99:
	mov	x20, x0
	str	xzr, [sp, #40]
	add	x1, sp, #40
	add	x2, x23, #32
	mov	x8, x22
	mov	x0, x19
	mov	x3, x24
	bl	_ufe_prepare_reserved
	ldr	w8, [x22]
	cbz	w8, LBB92_103
; %bb.100:
	mov	x0, x20
	bl	_free
	b	LBB92_17
LBB92_101:
	mov	w8, #3                          ; =0x3
	str	w8, [x22]
	b	LBB92_17
LBB92_102:
	mov	w8, #4                          ; =0x4
	str	w8, [x22]
	b	LBB92_17
LBB92_103:
	ldr	x19, [sp, #40]
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	mov	x1, x19
	bl	_ufi_same
	tbz	w0, #0, LBB92_105
; %bb.104:
	ldr	x8, [x19]
	add	x8, x8, #536
	ldr	q0, [x8]
	str	q0, [x20, #16]
Lloh53:
	adrp	x8, l_.str.10@PAGE
Lloh54:
	add	x8, x8, l_.str.10@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x22, #28]
	ldp	q0, q2, [x8, #32]
	stur	q0, [x22, #44]
	stur	q2, [x22, #60]
	ldur	q0, [x8, #60]
	stur	q0, [x22, #72]
	ldr	x8, [sp, #8]
	stp	x19, x8, [x20]
	str	x20, [x21]
	stur	q1, [x22, #12]
	b	LBB92_17
LBB92_105:
	mov	x0, x19
	bl	_nvm_union_field_execution_free
	mov	x0, x20
	bl	_free
	mov	w8, #2                          ; =0x2
	str	w8, [x22]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x22, #76]
Lloh55:
	adrp	x8, l_.str.9@PAGE
Lloh56:
	add	x8, x8, l_.str.9@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x22, #12]
	stur	q1, [x22, #28]
	ldp	q0, q1, [x8, #32]
	stur	q0, [x22, #44]
	stur	q1, [x22, #60]
	b	LBB92_17
	.loh AdrpAdd	Lloh51, Lloh52
	.loh AdrpAdd	Lloh53, Lloh54
	.loh AdrpAdd	Lloh55, Lloh56
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufi_same
_ufi_same:                              ; @ufi_same
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #576
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x26, [x0]
	cbz	x26, LBB93_6
; %bb.1:
	cbz	x1, LBB93_6
; %bb.2:
	ldr	x27, [x1]
	cbz	x27, LBB93_6
; %bb.3:
	ldr	x23, [x0, #8]
	cbz	x23, LBB93_6
; %bb.4:
	ldr	x24, [x1, #8]
	cbz	x24, LBB93_6
; %bb.5:
	add	x8, x26, #488
	ldp	q1, q0, [x8]
	ldr	w9, [x26, #520]
	ldur	d2, [x8, #36]
	add	x8, x27, #488
	ldp	q4, q3, [x8]
	ldr	w10, [x27, #520]
	ldur	d5, [x8, #36]
	ldr	w28, [x23, #48]
	ldr	d6, [x23, #40]
	ldr	w8, [x24, #48]
	cmeq.4s	v1, v1, v4
	cmeq.4s	v0, v0, v3
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	cmp	w9, w10
	cset	w9, eq
	ldr	d1, [x24, #40]
	mov.d	v2[1], v6[0]
	mov.d	v5[1], v1[0]
	cmeq.4s	v1, v2, v5
	xtn.4h	v1, v1
	zip1.8b	v2, v0, v0
	and.8b	v1, v2, v1
	uzp1.8b	v1, v1, v0
	mov.s	v1[1], v0[1]
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	uminv.8b	b0, v0
	fmov	w10, s0
	and	w9, w10, w9
	cmp	w9, #1
	ccmp	w28, w8, #0, eq
	b.eq	LBB93_8
LBB93_6:
	mov	w8, #0                          ; =0x0
LBB93_7:
	mov	x0, x8
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB93_8:
	mov	w8, #0                          ; =0x0
	ldp	w9, w10, [x27, #20]
	ldp	w12, w11, [x26, #20]
	cmp	w12, w9
	ldur	q0, [x26, #4]
	ldur	q1, [x27, #4]
	cmeq.4s	v0, v0, v1
	xtn.4h	v0, v0
	cset	w9, eq
	cmp	w11, w10
	cset	w10, eq
	ldr	s1, [x27]
	ushll.8h	v1, v1, #0
	ldr	s2, [x26]
	ushll.8h	v2, v2, #0
	cmeq.4h	v1, v2, v1
	and.8b	v0, v0, v1
	uminv.4h	h0, v0
	fmov	w11, s0
	tbz	w11, #0, LBB93_7
; %bb.9:
	cbz	w9, LBB93_7
; %bb.10:
	cbz	w10, LBB93_7
; %bb.11:
	ldr	w9, [x27, #28]
	ldr	w10, [x26, #28]
	cmp	w10, w9
	b.ne	LBB93_7
; %bb.12:
	ldr	w25, [x26, #492]
	ldr	w21, [x26, #488]
	ldr	w8, [x23, #44]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	w8, [x23, #40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stp	x0, x1, [sp, #72]               ; 16-byte Folded Spill
	cbz	w21, LBB93_28
; %bb.13:
	mov	x19, #0                         ; =0x0
	add	x9, x26, #552
	add	x8, x26, #586
	stp	x8, x25, [sp, #24]              ; 16-byte Folded Spill
	mov	w8, #9768                       ; =0x2628
	add	x8, x26, x8
	stp	x8, x28, [sp, #40]              ; 16-byte Folded Spill
	add	x8, x27, #552
	stp	x8, x9, [sp, #56]               ; 16-byte Folded Spill
LBB93_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB93_19 Depth 2
	cmp	x19, x21
	b.eq	LBB93_6
; %bb.15:                               ;   in Loop: Header=BB93_14 Depth=1
	add	x8, x19, x19, lsl #3
	lsl	x11, x8, #2
	ldp	x3, x8, [sp, #56]               ; 16-byte Folded Reload
	add	x12, x8, x11
	ldr	w13, [x12]
	ldrh	w8, [x12, #4]
	and	w9, w8, #0xffff
	ldrh	w10, [x12, #16]
	and	w14, w10, #0xffff
	ldrh	w10, [x12, #18]
	and	w15, w10, #0xffff
	ldrb	w10, [x12, #20]
	and	w16, w10, #0xff
	ldrb	w10, [x12, #21]
	and	w17, w10, #0xff
	ldrh	w10, [x12, #32]
	and	w2, w10, #0xffff
	ldrb	w10, [x12, #34]
	add	x11, x3, x11
	ldr	w3, [x11]
	ldrh	w4, [x11, #4]
	ldrh	w5, [x11, #16]
	ldrh	w6, [x11, #18]
	ldrb	w7, [x11, #20]
	and	w7, w7, #0xff
	ldrb	w20, [x11, #21]
	ldrh	w22, [x11, #32]
	and	w22, w22, #0xffff
	ldrb	w25, [x11, #34]
	cmp	w13, w3
	cset	w13, eq
	cmp	w9, w4, uxth
	ldr	d0, [x12, #8]
	ldr	d1, [x12, #24]
	ldr	d2, [x11, #8]
	ldr	d3, [x11, #24]
	mov.d	v0[1], v1[0]
	mov.d	v2[1], v3[0]
	cmeq.4s	v0, v0, v2
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w11, s0
	and	w11, w13, w11
	csel	w11, wzr, w11, ne
	cmp	w14, w5, uxth
	csel	w11, wzr, w11, ne
	cmp	w15, w6, uxth
	ccmp	w2, w22, #0, eq
	ccmp	w16, w7, #0, eq
	csel	w11, wzr, w11, ne
	cmp	w17, w20, uxtb
	csel	w11, wzr, w11, ne
	cmp	w11, #1
	ccmp	w10, w25, #0, eq
	b.ne	LBB93_6
; %bb.16:                               ;   in Loop: Header=BB93_14 Depth=1
	cbz	w10, LBB93_24
; %bb.17:                               ;   in Loop: Header=BB93_14 Depth=1
	cbz	w9, LBB93_24
; %bb.18:                               ;   in Loop: Header=BB93_14 Depth=1
	mov	x20, #0                         ; =0x0
	and	x22, x8, #0xffff
	mov	w8, #36                         ; =0x24
	mul	x8, x19, x8
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w28, [x9, x8]
LBB93_19:                               ;   Parent Loop BB93_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	w28, LBB93_6
; %bb.20:                               ;   in Loop: Header=BB93_19 Depth=2
	ldr	x8, [x26, #256]
	mov	w9, #24                         ; =0x18
	madd	x8, x19, x9, x8
	ldrh	w8, [x8, #4]
	cmp	x20, x8
	b.hs	LBB93_6
; %bb.21:                               ;   in Loop: Header=BB93_19 Depth=2
	ldr	x8, [x26, #264]
	ldr	x8, [x8, x19, lsl #3]
	ldrb	w25, [x8, x20]
	sub	x3, x29, #240
	mov	x0, x1
	mov	x1, x19
	mov	x2, x20
	bl	_nvm_union_field_execution_parameter
	mov	x8, x0
	ldp	x0, x1, [sp, #72]               ; 16-byte Folded Reload
	cbz	w8, LBB93_6
; %bb.22:                               ;   in Loop: Header=BB93_19 Depth=2
	ldurb	w8, [x29, #-240]
	cmp	w25, w8
	b.ne	LBB93_6
; %bb.23:                               ;   in Loop: Header=BB93_19 Depth=2
	add	x20, x20, #1
	cmp	x22, x20
	b.ne	LBB93_19
LBB93_24:                               ;   in Loop: Header=BB93_14 Depth=1
	ldr	x28, [sp, #48]                  ; 8-byte Folded Reload
	cmp	x19, x28
	b.hs	LBB93_6
; %bb.25:                               ;   in Loop: Header=BB93_14 Depth=1
	ldr	x8, [x23, #32]
	ldrh	w8, [x8, x19, lsl #1]
	ldr	x9, [x24, #32]
	ldrh	w9, [x9, x19, lsl #1]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.26:                               ;   in Loop: Header=BB93_14 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldrh	w9, [x9, x19, lsl #1]
	cmp	w9, w8
	b.ne	LBB93_6
; %bb.27:                               ;   in Loop: Header=BB93_14 Depth=1
	add	x19, x19, #1
	cmp	x19, x21
	ldr	x25, [sp, #32]                  ; 8-byte Folded Reload
	b.ne	LBB93_14
LBB93_28:
	cbz	w25, LBB93_35
; %bb.29:
	mov	x19, #0                         ; =0x0
	add	x20, sp, #128
	ldr	w21, [x0, #24]
	sub	x22, x29, #240
LBB93_30:                               ; =>This Inner Loop Header: Depth=1
	cmp	x19, x21
	b.eq	LBB93_6
; %bb.31:                               ;   in Loop: Header=BB93_30 Depth=1
	cmp	x19, x25
	b.hs	LBB93_6
; %bb.32:                               ;   in Loop: Header=BB93_30 Depth=1
	ldr	x9, [x26, #13352]
	add	x8, x19, x19, lsl #3
	lsl	x8, x8, #3
	add	x9, x9, x8
	ldr	q0, [x9, #16]
	str	q0, [x20, #304]
	ldr	q0, [x9, #32]
	str	q0, [x20, #320]
	ldr	q0, [x9, #48]
	str	q0, [x20, #336]
	ldr	x10, [x9, #64]
	str	x10, [x20, #352]
	ldr	q0, [x9]
	str	q0, [x20, #288]
	ldr	x9, [x0, #16]
	add	x9, x9, x8
	ldr	x10, [x9, #64]
	stur	x10, [x22, #136]
	ldr	q0, [x9, #48]
	stur	q0, [x22, #120]
	ldr	q0, [x9, #32]
	stur	q0, [x22, #104]
	ldr	q0, [x9, #16]
	stur	q0, [x22, #88]
	ldr	q0, [x9]
	stur	q0, [x22, #72]
	ldp	q0, q1, [x20, #288]
	ldp	q2, q3, [x20, #320]
	stp	q2, q3, [x20, #176]
	stp	q0, q1, [x20, #144]
	ldp	q0, q1, [x20, #352]
	ldp	q3, q2, [x20, #400]
	stp	q3, q2, [x20, #256]
	ldr	q2, [x20, #384]
	stp	q1, q2, [x20, #224]
	str	q0, [x20, #208]
	ldr	w9, [x1, #24]
	cmp	x19, x9
	b.hs	LBB93_6
; %bb.33:                               ;   in Loop: Header=BB93_30 Depth=1
	ldr	x9, [x27, #13352]
	add	x9, x9, x8
	ldr	q0, [x9, #16]
	str	q0, [x20, #304]
	ldr	q0, [x9, #32]
	str	q0, [x20, #320]
	ldr	q0, [x9, #48]
	str	q0, [x20, #336]
	ldr	x10, [x9, #64]
	str	x10, [x20, #352]
	ldr	q0, [x9]
	str	q0, [x20, #288]
	ldr	x9, [x1, #16]
	add	x8, x9, x8
	ldr	x9, [x8, #64]
	stur	x9, [x22, #136]
	ldr	q0, [x8, #48]
	stur	q0, [x22, #120]
	ldr	q0, [x8, #32]
	stur	q0, [x22, #104]
	ldr	q0, [x8, #16]
	stur	q0, [x22, #88]
	ldr	q0, [x8]
	stur	q0, [x22, #72]
	ldp	q0, q1, [x20, #288]
	ldp	q2, q3, [x20, #320]
	stp	q2, q3, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x20, #352]
	ldp	q3, q2, [x20, #400]
	stp	q3, q2, [x20, #112]
	ldr	q2, [x20, #384]
	str	q2, [x20, #96]
	stp	q0, q1, [sp, #192]
	add	x0, sp, #272
	add	x1, sp, #128
	bl	_ufi_rows_same
	mov	x8, x0
	ldp	x0, x1, [sp, #72]               ; 16-byte Folded Reload
	cbz	w8, LBB93_6
; %bb.34:                               ;   in Loop: Header=BB93_30 Depth=1
	add	x19, x19, #1
	cmp	x19, x25
	b.ne	LBB93_30
LBB93_35:
	ldp	x8, x1, [sp, #8]                ; 16-byte Folded Reload
	cbz	w8, LBB93_42
; %bb.36:
	mov	x9, #0                          ; =0x0
	add	x8, x8, x8, lsl #2
	lsl	x10, x8, #3
LBB93_37:                               ; =>This Inner Loop Header: Depth=1
	cmp	x10, x9
	b.eq	LBB93_6
; %bb.38:                               ;   in Loop: Header=BB93_37 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	x11, [x23, #8]
	add	x13, x11, x9
	ldrb	w12, [x13, #16]
	and	w15, w12, #0xff
	ldrb	w12, [x13, #17]
	and	w16, w12, #0xff
	ldr	x12, [x24, #8]
	add	x14, x12, x9
	ldrb	w17, [x14, #16]
	cmp	w15, w17, uxtb
	ldrb	w17, [x14, #17]
	ldr	q0, [x13]
	ldr	q1, [x14]
	cset	w15, eq
	cmp	w16, w17, uxtb
	cset	w16, eq
	cmeq.4s	v0, v0, v1
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w17, s0
	tbz	w17, #0, LBB93_7
; %bb.39:                               ;   in Loop: Header=BB93_37 Depth=1
	ldrh	w13, [x13, #18]
	ldrh	w14, [x14, #18]
	cmp	w15, #0
	ccmp	w16, #0, #4, ne
	ccmp	w13, w14, #0, ne
	b.ne	LBB93_7
; %bb.40:                               ;   in Loop: Header=BB93_37 Depth=1
	add	x8, x11, x9
	ldr	w11, [x8, #32]
	ldr	x8, [x8, #24]
	add	x12, x12, x9
	ldr	w13, [x12, #32]
	ldr	x12, [x12, #24]
	eor	w11, w13, w11
	and	x11, x11, #0xffffff
	cmp	x11, #0
	ccmp	x8, x12, #0, eq
	b.ne	LBB93_6
; %bb.41:                               ;   in Loop: Header=BB93_37 Depth=1
	add	x9, x9, #40
	cmp	x10, x9
	b.ne	LBB93_37
LBB93_42:
	cbz	w1, LBB93_47
; %bb.43:
	mov	x8, #0                          ; =0x0
	lsl	x9, x1, #4
LBB93_44:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x8
	b.eq	LBB93_6
; %bb.45:                               ;   in Loop: Header=BB93_44 Depth=1
	ldr	x10, [x23, #16]
	add	x10, x10, x8
	ldr	x11, [x10]
	ldr	w10, [x10, #8]
	ldr	x12, [x24, #16]
	add	x12, x12, x8
	ldr	x13, [x12]
	ldr	w12, [x12, #8]
	eor	w10, w12, w10
	and	x10, x10, #0xffffff
	cmp	x10, #0
	ccmp	x11, x13, #0, eq
	b.ne	LBB93_6
; %bb.46:                               ;   in Loop: Header=BB93_44 Depth=1
	add	x8, x8, #16
	cmp	x9, x8
	b.ne	LBB93_44
LBB93_47:
	cbz	w28, LBB93_52
; %bb.48:
	mov	x8, #0                          ; =0x0
	lsl	x9, x28, #4
LBB93_49:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x8
	b.eq	LBB93_6
; %bb.50:                               ;   in Loop: Header=BB93_49 Depth=1
	ldr	x10, [x23, #24]
	add	x10, x10, x8
	ldr	x11, [x10]
	ldr	w10, [x10, #8]
	ldr	x12, [x24, #24]
	add	x12, x12, x8
	ldr	x13, [x12]
	ldr	w12, [x12, #8]
	eor	w10, w12, w10
	and	x10, x10, #0xffffff
	cmp	x10, #0
	ccmp	x11, x13, #0, eq
	b.ne	LBB93_6
; %bb.51:                               ;   in Loop: Header=BB93_49 Depth=1
	add	x8, x8, #16
	cmp	x9, x8
	b.ne	LBB93_49
LBB93_52:
	mov	w19, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	mov	w23, #10                        ; =0xa
	mov	w24, #8                         ; =0x8
LBB93_53:                               ; =>This Inner Loop Header: Depth=1
	mov	x25, x8
	tst	w8, #0x1
	csel	w20, w24, w23, ne
	ldr	x8, [x0, #8]
	cbz	x8, LBB93_6
; %bb.54:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x3, sp, #124
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB93_6
; %bb.55:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.56:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x3, sp, #120
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB93_6
; %bb.57:                               ;   in Loop: Header=BB93_53 Depth=1
	ldp	w9, w8, [sp, #120]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.58:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.59:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x2, sp, #112
	mov	x1, x19
	bl	_nvm_union_field_declarations_layout
	cbz	w0, LBB93_6
; %bb.60:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.61:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x2, sp, #104
	mov	x1, x19
	bl	_nvm_union_field_declarations_layout
	cbz	w0, LBB93_6
; %bb.62:                               ;   in Loop: Header=BB93_53 Depth=1
	ldrb	w8, [sp, #112]
	ldrb	w9, [sp, #104]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.63:                               ;   in Loop: Header=BB93_53 Depth=1
	ldrb	w8, [sp, #113]
	ldrb	w9, [sp, #105]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.64:                               ;   in Loop: Header=BB93_53 Depth=1
	ldrh	w8, [sp, #114]
	ldrh	w9, [sp, #106]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.65:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	w8, [sp, #116]
	ldr	w9, [sp, #108]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.66:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.67:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	sub	x3, x29, #240
	mov	w1, #0                          ; =0x0
	mov	x2, x19
	bl	_nvm_union_field_declarations_variant
	cbz	w0, LBB93_6
; %bb.68:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.69:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x3, sp, #272
	mov	w1, #0                          ; =0x0
	mov	x2, x19
	bl	_nvm_union_field_declarations_variant
	cbz	w0, LBB93_6
; %bb.70:                               ;   in Loop: Header=BB93_53 Depth=1
	ldur	w8, [x29, #-240]
	ldr	w9, [sp, #272]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.71:                               ;   in Loop: Header=BB93_53 Depth=1
	ldur	w8, [x29, #-236]
	ldr	w9, [sp, #276]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.72:                               ;   in Loop: Header=BB93_53 Depth=1
	ldurh	w8, [x29, #-232]
	ldrh	w9, [sp, #280]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.73:                               ;   in Loop: Header=BB93_53 Depth=1
	ldurh	w8, [x29, #-230]
	ldrh	w9, [sp, #282]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.74:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.75:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x3, sp, #128
	mov	x1, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_field
	cbz	w0, LBB93_6
; %bb.76:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB93_6
; %bb.77:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	x0, [x8]
	add	x3, sp, #92
	mov	x1, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_field
	cbz	w0, LBB93_6
; %bb.78:                               ;   in Loop: Header=BB93_53 Depth=1
	ldrb	w8, [sp, #128]
	ldrb	w9, [sp, #92]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.79:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	w8, [sp, #132]
	ldr	w9, [sp, #96]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.80:                               ;   in Loop: Header=BB93_53 Depth=1
	ldr	w8, [sp, #136]
	ldr	w9, [sp, #100]
	cmp	w8, w9
	b.ne	LBB93_6
; %bb.81:                               ;   in Loop: Header=BB93_53 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w19, #1                         ; =0x1
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	tbnz	w25, #0, LBB93_53
; %bb.82:
	ldr	x8, [x0]
	ldr	w10, [x8, #10280]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	ldr	w11, [x9, #10280]
	cmp	w10, w11
	b.ne	LBB93_6
; %bb.83:
	ldr	w10, [x8, #10284]
	ldr	w11, [x9, #10284]
	cmp	w10, w11
	b.ne	LBB93_6
; %bb.84:
	mov	w10, #10288                     ; =0x2830
	ldrh	w8, [x8, x10]
	ldrh	w9, [x9, x10]
	cmp	w8, w9
	cset	w8, eq
	b	LBB93_7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_copy ; -- Begin function nvm_union_field_image_copy
	.globl	_nvm_union_field_image_copy
	.p2align	2
_nvm_union_field_image_copy:            ; @nvm_union_field_image_copy
	.cfi_startproc
; %bb.0:
	mov	x3, x1
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	b	_nvm_union_field_image_copy_reserved
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_module_internal ; -- Begin function nvm_union_field_image_module_internal
	.globl	_nvm_union_field_image_module_internal
	.p2align	2
_nvm_union_field_image_module_internal: ; @nvm_union_field_image_module_internal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB95_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB95_3
; %bb.2:
	ldr	x0, [x8]
	ret
LBB95_3:
	mov	x0, #0                          ; =0x0
LBB95_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_cost ; -- Begin function nvm_union_field_image_cost
	.globl	_nvm_union_field_image_cost
	.p2align	2
_nvm_union_field_image_cost:            ; @nvm_union_field_image_cost
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB96_2
; %bb.1:
	ldur	q0, [x8, #8]
	ldr	x8, [x8, #24]
	str	x8, [x1, #16]
	str	q0, [x1]
LBB96_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_counts ; -- Begin function nvm_union_field_image_counts
	.globl	_nvm_union_field_image_counts
	.p2align	2
_nvm_union_field_image_counts:          ; @nvm_union_field_image_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB97_6
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB97_5
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB97_6
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB97_6
; %bb.4:
	add	x8, x8, #488
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x1, #32]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB97_5:
	mov	w0, #0                          ; =0x0
LBB97_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_header ; -- Begin function nvm_union_field_image_header
	.globl	_nvm_union_field_image_header
	.p2align	2
_nvm_union_field_image_header:          ; @nvm_union_field_image_header
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB98_6
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB98_5
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB98_6
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB98_6
; %bb.4:
	ldp	q0, q1, [x8]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB98_5:
	mov	w0, #0                          ; =0x0
LBB98_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_proof_counts ; -- Begin function nvm_union_field_image_proof_counts
	.globl	_nvm_union_field_image_proof_counts
	.p2align	2
_nvm_union_field_image_proof_counts:    ; @nvm_union_field_image_proof_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB99_6
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB99_5
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB99_6
; %bb.3:
	ldr	x8, [x8, #8]
	cbz	x8, LBB99_6
; %bb.4:
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #56]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
	ret
LBB99_5:
	mov	w0, #0                          ; =0x0
LBB99_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_instruction ; -- Begin function nvm_union_field_image_instruction
	.globl	_nvm_union_field_image_instruction
	.p2align	2
_nvm_union_field_image_instruction:     ; @nvm_union_field_image_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB100_6
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB100_6
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB100_6
; %bb.3:
	ldr	w9, [x8, #24]
	cmp	w1, w9
	b.hs	LBB100_7
; %bb.4:
	ldr	x9, [x8]
	ldr	w10, [x9, #492]
	cmp	w1, w10
	b.hs	LBB100_7
; %bb.5:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	ldr	x9, [x9, #13352]
	mov	w10, #72                        ; =0x48
	umaddl	x9, w1, w10, x9
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [sp, #32]
	ldp	q1, q0, [x9]
	stp	q1, q0, [sp]
	ldr	x8, [x8, #16]
	umaddl	x8, w1, w10, x8
	ldp	q0, q1, [x8, #32]
	stur	q0, [sp, #104]
	ldp	q2, q0, [x8]
	stur	q0, [sp, #88]
	ldr	x9, [x9, #64]
	str	x9, [sp, #64]
	stur	q1, [sp, #120]
	ldr	x8, [x8, #64]
	str	x8, [sp, #136]
	stur	q2, [sp, #72]
	ldr	q2, [sp, #128]
	ldp	q1, q0, [sp, #64]
	stp	q1, q0, [x2, #64]
	ldp	q1, q0, [sp, #32]
	stp	q1, q0, [x2, #32]
	ldp	q1, q0, [sp]
	stp	q1, q0, [x2]
	ldp	q1, q0, [sp, #96]
	mov	w0, #1                          ; =0x1
	stp	q0, q2, [x2, #112]
	str	q1, [x2, #96]
	add	sp, sp, #144
LBB100_6:
	ret
LBB100_7:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_function ; -- Begin function nvm_union_field_image_function
	.globl	_nvm_union_field_image_function
	.p2align	2
_nvm_union_field_image_function:        ; @nvm_union_field_image_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB101_7
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB101_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB101_7
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB101_7
; %bb.4:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB101_6
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	add	x9, x8, #552
	ldp	q0, q1, [x9]
	ldr	w8, [x8, #584]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB101_6:
	mov	w0, #0                          ; =0x0
LBB101_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_origin ; -- Begin function nvm_union_field_image_origin
	.globl	_nvm_union_field_image_origin
	.p2align	2
_nvm_union_field_image_origin:          ; @nvm_union_field_image_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB102_7
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB102_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB102_7
; %bb.3:
	ldr	x8, [x8, #8]
	cbz	x8, LBB102_7
; %bb.4:
	ldr	w9, [x8, #40]
	cmp	w1, w9
	b.hs	LBB102_6
; %bb.5:
	ldr	x8, [x8, #8]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldr	x8, [x8, #32]
	str	x8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB102_6:
	mov	w0, #0                          ; =0x0
LBB102_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_global ; -- Begin function nvm_union_field_image_global
	.globl	_nvm_union_field_image_global
	.p2align	2
_nvm_union_field_image_global:          ; @nvm_union_field_image_global
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB103_7
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB103_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB103_7
; %bb.3:
	ldr	x8, [x8, #8]
	cbz	x8, LBB103_7
; %bb.4:
	ldr	w9, [x8, #44]
	cmp	w1, w9
	b.hs	LBB103_6
; %bb.5:
	ldr	x8, [x8, #16]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB103_6:
	mov	w0, #0                          ; =0x0
LBB103_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_result ; -- Begin function nvm_union_field_image_result
	.globl	_nvm_union_field_image_result
	.p2align	2
_nvm_union_field_image_result:          ; @nvm_union_field_image_result
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB104_7
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB104_6
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB104_7
; %bb.3:
	ldr	x8, [x8, #8]
	cbz	x8, LBB104_7
; %bb.4:
	ldr	w9, [x8, #48]
	cmp	w1, w9
	b.hs	LBB104_6
; %bb.5:
	ldr	x8, [x8, #24]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB104_6:
	mov	w0, #0                          ; =0x0
LBB104_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_layout ; -- Begin function nvm_union_field_image_layout
	.globl	_nvm_union_field_image_layout
	.p2align	2
_nvm_union_field_image_layout:          ; @nvm_union_field_image_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB105_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB105_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB105_4
; %bb.3:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_layout
LBB105_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_parameter ; -- Begin function nvm_union_field_image_parameter
	.globl	_nvm_union_field_image_parameter
	.p2align	2
_nvm_union_field_image_parameter:       ; @nvm_union_field_image_parameter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB106_9
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB106_8
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB106_9
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB106_9
; %bb.4:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB106_8
; %bb.5:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrb	w9, [x9, #586]
	cbz	w9, LBB106_8
; %bb.6:
	mov	w9, w1
	ldr	x10, [x8, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w9, w11, x10
	ldrh	w10, [x10, #4]
	cmp	w2, w10
	b.hs	LBB106_8
; %bb.7:
	ldr	x8, [x8, #264]
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, w2, uxtw]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB106_8:
	mov	w0, #0                          ; =0x0
LBB106_9:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_size ; -- Begin function nvm_union_field_image_size
	.globl	_nvm_union_field_image_size
	.p2align	2
_nvm_union_field_image_size:            ; @nvm_union_field_image_size
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB107_17
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB107_16
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB107_17
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB107_17
; %bb.4:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB107_9
; %bb.5:
	cbz	w1, LBB107_13
; %bb.6:
	cmp	w1, #1
	b.ne	LBB107_17
; %bb.7:
	cbnz	w2, LBB107_16
; %bb.8:
	add	x8, x8, #320
	b	LBB107_19
LBB107_9:
	cmp	w1, #2
	b.eq	LBB107_15
; %bb.10:
	cmp	w1, #3
	b.ne	LBB107_17
; %bb.11:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB107_16
; %bb.12:
	ldr	x8, [x8, #240]
	add	x8, x8, w2, uxtw #2
	b	LBB107_19
LBB107_13:
	cbnz	w2, LBB107_16
; %bb.14:
	add	x8, x8, #288
	b	LBB107_19
LBB107_15:
	cbz	w2, LBB107_18
LBB107_16:
	mov	w0, #0                          ; =0x0
LBB107_17:
	ret
LBB107_18:
	add	x8, x8, #304
LBB107_19:
	ldr	w8, [x8]
	str	w8, [x3]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_bytes ; -- Begin function nvm_union_field_image_bytes
	.globl	_nvm_union_field_image_bytes
	.p2align	2
_nvm_union_field_image_bytes:           ; @nvm_union_field_image_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB108_21
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB108_18
; %bb.2:
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB108_21
; %bb.3:
	ldr	x8, [x8]
	cbz	x8, LBB108_21
; %bb.4:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB108_9
; %bb.5:
	cbz	w1, LBB108_13
; %bb.6:
	cmp	w1, #1
	b.ne	LBB108_21
; %bb.7:
	cbnz	w2, LBB108_18
; %bb.8:
	add	x9, x8, #312
	add	x8, x8, #320
	b	LBB108_17
LBB108_9:
	cmp	w1, #2
	b.eq	LBB108_15
; %bb.10:
	cmp	w1, #3
	b.ne	LBB108_21
; %bb.11:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB108_18
; %bb.12:
	ldp	x9, x8, [x8, #232]
	add	x9, x9, w2, uxtw #3
	add	x8, x8, w2, uxtw #2
	b	LBB108_17
LBB108_13:
	cbnz	w2, LBB108_18
; %bb.14:
	add	x9, x8, #280
	add	x8, x8, #288
	b	LBB108_17
LBB108_15:
	cbnz	w2, LBB108_18
; %bb.16:
	add	x9, x8, #296
	add	x8, x8, #304
LBB108_17:
	ldr	w8, [x8]
	subs	w8, w8, w3
	ccmp	w4, w8, #2, hs
	b.ls	LBB108_19
LBB108_18:
	mov	w0, #0                          ; =0x0
	ret
LBB108_19:
	cbz	w4, LBB108_22
; %bb.20:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x9]
	add	x1, x8, w3, uxtw
	mov	w2, w4
	mov	x0, x5
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB108_21:
	ret
LBB108_22:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_field ; -- Begin function nvm_union_field_image_field
	.globl	_nvm_union_field_image_field
	.p2align	2
_nvm_union_field_image_field:           ; @nvm_union_field_image_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB109_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB109_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB109_4
; %bb.3:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_field
LBB109_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_variant ; -- Begin function nvm_union_field_image_variant
	.globl	_nvm_union_field_image_variant
	.p2align	2
_nvm_union_field_image_variant:         ; @nvm_union_field_image_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB110_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB110_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB110_4
; %bb.3:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_variant
LBB110_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_union_field_image_nominal ; -- Begin function nvm_union_field_image_nominal
	.globl	_nvm_union_field_image_nominal
	.p2align	2
_nvm_union_field_image_nominal:         ; @nvm_union_field_image_nominal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB111_4
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB111_4
; %bb.2:
	ldr	x8, [x8, #8]
	cbz	x8, LBB111_4
; %bb.3:
	ldr	x0, [x8]
	b	_nvm_union_field_declarations_nominal
LBB111_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_free ; -- Begin function nvm_record_map_execution_free
	.globl	_nvm_record_map_execution_free
	.p2align	2
_nvm_record_map_execution_free:         ; @nvm_record_map_execution_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB112_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_nvm_record_array_execution_free
	ldr	x0, [x19, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x19, #16]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB112_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_record_map_execution ; -- Begin function nvm_prepare_record_map_execution
	.globl	_nvm_prepare_record_map_execution
	.p2align	2
_nvm_prepare_record_map_execution:      ; @nvm_prepare_record_map_execution
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	b	_rme_prepare_boundary
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_counts ; -- Begin function nvm_record_map_execution_counts
	.globl	_nvm_record_map_execution_counts
	.p2align	2
_nvm_record_map_execution_counts:       ; @nvm_record_map_execution_counts
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB114_6
; %bb.1:
	cbz	x1, LBB114_6
; %bb.2:
	ldr	x8, [x0]
	cbz	x8, LBB114_6
; %bb.3:
	add	x8, x8, #488
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #-96]!
	.cfi_def_cfa_offset 96
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [sp, #32]
	ldr	x8, [x0, #8]
	cbz	x8, LBB114_5
; %bb.4:
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	stp	q0, q1, [sp, #64]
	ldp	q2, q3, [sp, #32]
	stp	q2, q3, [x1, #32]
	stp	q0, q1, [x1, #64]
	ldp	q0, q1, [sp]
	mov	w8, #1                          ; =0x1
	stp	q0, q1, [x1]
LBB114_5:
	add	sp, sp, #96
LBB114_6:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_instruction ; -- Begin function nvm_record_map_execution_instruction
	.globl	_nvm_record_map_execution_instruction
	.p2align	2
_nvm_record_map_execution_instruction:  ; @nvm_record_map_execution_instruction
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB115_4
; %bb.1:
	cbz	x2, LBB115_4
; %bb.2:
	ldr	x9, [x8]
	ldr	w9, [x9, #492]
	cmp	w1, w9
	b.hs	LBB115_5
; %bb.3:
	ldr	x8, [x8, #16]
	mov	w9, #80                         ; =0x50
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8]
	str	q0, [x2]
	ldp	q0, q1, [x8, #16]
	ldp	q2, q3, [x8, #48]
	stp	q2, q3, [x2, #48]
	stp	q0, q1, [x2, #16]
	mov	w0, #1                          ; =0x1
LBB115_4:
	ret
LBB115_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_map_field ; -- Begin function nvm_record_map_execution_map_field
	.globl	_nvm_record_map_execution_map_field
	.p2align	2
_nvm_record_map_execution_map_field:    ; @nvm_record_map_execution_map_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB116_10
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cmp	x3, x4
	b.eq	LBB116_10
; %bb.2:
	cbz	x4, LBB116_10
; %bb.3:
	cbz	x3, LBB116_10
; %bb.4:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x21, [x8, #8]
	cbz	x21, LBB116_9
; %bb.5:
	mov	x20, x3
	mov	x19, x4
	ldr	x0, [x21, #8]
	add	x3, sp, #8
	bl	_nvm_map_declarations_field
	cbz	w0, LBB116_9
; %bb.6:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #8]
	add	x2, sp, #7
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB116_9
; %bb.7:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #12]
	add	x2, sp, #6
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB116_9
; %bb.8:
	ldrb	w8, [sp, #7]
	strb	w8, [x20]
	ldrb	w8, [sp, #6]
	strb	w8, [x19]
	mov	w0, #1                          ; =0x1
LBB116_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB116_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_map_origin ; -- Begin function nvm_record_map_execution_map_origin
	.globl	_nvm_record_map_execution_map_origin
	.p2align	2
_nvm_record_map_execution_map_origin:   ; @nvm_record_map_execution_map_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB117_2
; %bb.1:
	ldr	x0, [x0, #8]
	b	_nvm_record_map_frozen_origin
LBB117_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_function ; -- Begin function nvm_record_map_execution_function
	.globl	_nvm_record_map_execution_function
	.p2align	2
_nvm_record_map_execution_function:     ; @nvm_record_map_execution_function
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB118_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB118_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB118_5
; %bb.3:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB118_6
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x8, w1, w9, x8
	add	x9, x8, #552
	ldp	q0, q1, [x9]
	ldr	w8, [x8, #584]
	str	w8, [x2, #32]
	stp	q0, q1, [x2]
	mov	w0, #1                          ; =0x1
LBB118_5:
	ret
LBB118_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_parameter ; -- Begin function nvm_record_map_execution_parameter
	.globl	_nvm_record_map_execution_parameter
	.p2align	2
_nvm_record_map_execution_parameter:    ; @nvm_record_map_execution_parameter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB119_7
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB119_7
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB119_7
; %bb.3:
	ldr	w9, [x8, #488]
	cmp	w1, w9
	b.hs	LBB119_8
; %bb.4:
	mov	w9, #36                         ; =0x24
	umaddl	x9, w1, w9, x8
	ldrb	w9, [x9, #586]
	cbz	w9, LBB119_8
; %bb.5:
	mov	w9, w1
	ldr	x10, [x8, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w9, w11, x10
	ldrh	w10, [x10, #4]
	cmp	w2, w10
	b.hs	LBB119_8
; %bb.6:
	ldr	x8, [x8, #264]
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, w2, uxtw]
	strb	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB119_7:
	ret
LBB119_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_bytes ; -- Begin function nvm_record_map_execution_bytes
	.globl	_nvm_record_map_execution_bytes
	.p2align	2
_nvm_record_map_execution_bytes:        ; @nvm_record_map_execution_bytes
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB120_22
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x5, LBB120_22
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB120_22
; %bb.3:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB120_8
; %bb.4:
	cbz	w1, LBB120_12
; %bb.5:
	cmp	w1, #1
	b.ne	LBB120_22
; %bb.6:
	cbz	w2, LBB120_16
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB120_8:
	cmp	w1, #2
	b.eq	LBB120_14
; %bb.9:
	cmp	w1, #3
	b.ne	LBB120_22
; %bb.10:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB120_19
; %bb.11:
	ldp	x9, x8, [x8, #232]
	add	x9, x9, w2, uxtw #3
	add	x8, x8, w2, uxtw #2
	b	LBB120_18
LBB120_12:
	cbz	w2, LBB120_17
; %bb.13:
	mov	w0, #0                          ; =0x0
	ret
LBB120_14:
	cbnz	w2, LBB120_19
; %bb.15:
	add	x9, x8, #296
	add	x8, x8, #304
	b	LBB120_18
LBB120_16:
	add	x9, x8, #312
	add	x8, x8, #320
	b	LBB120_18
LBB120_17:
	add	x9, x8, #280
	add	x8, x8, #288
LBB120_18:
	ldr	w8, [x8]
	subs	w8, w8, w3
	ccmp	w4, w8, #2, hs
	b.ls	LBB120_20
LBB120_19:
	mov	w0, #0                          ; =0x0
	ret
LBB120_20:
	cbz	w4, LBB120_23
; %bb.21:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x9]
	add	x1, x8, w3, uxtw
	mov	w2, w4
	mov	x0, x5
	bl	_memcpy
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB120_22:
	ret
LBB120_23:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_size ; -- Begin function nvm_record_map_execution_size
	.globl	_nvm_record_map_execution_size
	.p2align	2
_nvm_record_map_execution_size:         ; @nvm_record_map_execution_size
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB121_20
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB121_20
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB121_20
; %bb.3:
	mov	w0, #0                          ; =0x0
	cmp	w1, #1
	b.gt	LBB121_8
; %bb.4:
	cbz	w1, LBB121_12
; %bb.5:
	cmp	w1, #1
	b.ne	LBB121_20
; %bb.6:
	cbz	w2, LBB121_16
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB121_8:
	cmp	w1, #2
	b.eq	LBB121_14
; %bb.9:
	cmp	w1, #3
	b.ne	LBB121_20
; %bb.10:
	ldr	w9, [x8, #248]
	cmp	w2, w9
	b.hs	LBB121_15
; %bb.11:
	ldr	x8, [x8, #240]
	add	x8, x8, w2, uxtw #2
	b	LBB121_19
LBB121_12:
	cbz	w2, LBB121_17
; %bb.13:
	mov	w0, #0                          ; =0x0
	ret
LBB121_14:
	cbz	w2, LBB121_18
LBB121_15:
	mov	w0, #0                          ; =0x0
	ret
LBB121_16:
	add	x8, x8, #320
	b	LBB121_19
LBB121_17:
	add	x8, x8, #288
	b	LBB121_19
LBB121_18:
	add	x8, x8, #304
LBB121_19:
	ldr	w8, [x8]
	str	w8, [x3]
	mov	w0, #1                          ; =0x1
LBB121_20:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_descriptor ; -- Begin function nvm_record_map_execution_descriptor
	.globl	_nvm_record_map_execution_descriptor
	.p2align	2
_nvm_record_map_execution_descriptor:   ; @nvm_record_map_execution_descriptor
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB122_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB122_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB122_5
; %bb.3:
	ldr	w9, [x8, #528]
	cmp	w1, w9
	b.hs	LBB122_6
; %bb.4:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8, #10280]
	ldr	w8, [x8, #10288]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB122_5:
	ret
LBB122_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_header ; -- Begin function nvm_record_map_execution_header
	.globl	_nvm_record_map_execution_header
	.p2align	2
_nvm_record_map_execution_header:       ; @nvm_record_map_execution_header
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB123_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB123_4
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB123_4
; %bb.3:
	ldp	q0, q1, [x8]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB123_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_section ; -- Begin function nvm_record_map_execution_section
	.globl	_nvm_record_map_execution_section
	.p2align	2
_nvm_record_map_execution_section:      ; @nvm_record_map_execution_section
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB124_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB124_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB124_5
; %bb.3:
	ldr	w9, [x8, #224]
	cmp	w1, w9
	b.hs	LBB124_6
; %bb.4:
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8, #32]
	ldr	w8, [x8, #40]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB124_5:
	ret
LBB124_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_metadata ; -- Begin function nvm_record_map_execution_metadata
	.globl	_nvm_record_map_execution_metadata
	.p2align	2
_nvm_record_map_execution_metadata:     ; @nvm_record_map_execution_metadata
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB125_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB125_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB125_5
; %bb.3:
	ldr	w9, [x8, #368]
	cmp	w1, w9
	b.hs	LBB125_6
; %bb.4:
	ldr	x8, [x8, #360]
	ldr	x8, [x8, w1, uxtw #3]
	str	x8, [x2]
	mov	w0, #1                          ; =0x1
LBB125_5:
	ret
LBB125_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_debug ; -- Begin function nvm_record_map_execution_debug
	.globl	_nvm_record_map_execution_debug
	.p2align	2
_nvm_record_map_execution_debug:        ; @nvm_record_map_execution_debug
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB126_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB126_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB126_5
; %bb.3:
	ldr	w9, [x8, #384]
	cmp	w1, w9
	b.hs	LBB126_6
; %bb.4:
	ldr	x8, [x8, #376]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w1, w9, x8
	ldr	x9, [x8]
	ldr	w8, [x8, #8]
	str	w8, [x2, #8]
	str	x9, [x2]
	mov	w0, #1                          ; =0x1
LBB126_5:
	ret
LBB126_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_origin_counts ; -- Begin function nvm_record_map_execution_origin_counts
	.globl	_nvm_record_map_execution_origin_counts
	.p2align	2
_nvm_record_map_execution_origin_counts: ; @nvm_record_map_execution_origin_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB127_4
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB127_4
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	cbz	x8, LBB127_4
; %bb.3:
	ldp	q0, q1, [x8, #144]
	ldr	x8, [x8, #176]
	str	x8, [x1, #32]
	stp	q0, q1, [x1]
	mov	w0, #1                          ; =0x1
LBB127_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_origin ; -- Begin function nvm_record_map_execution_origin
	.globl	_nvm_record_map_execution_origin
	.p2align	2
_nvm_record_map_execution_origin:       ; @nvm_record_map_execution_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB128_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB128_5
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	cbz	x8, LBB128_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8]
	cmp	w1, w9
	b.hs	LBB128_6
; %bb.4:
	mov	w9, #48                         ; =0x30
	umaddl	x8, w1, w9, x8
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	ldur	q2, [x8, #56]
	stp	q1, q2, [x2, #16]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB128_5:
	ret
LBB128_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_field_value ; -- Begin function nvm_record_map_execution_field_value
	.globl	_nvm_record_map_execution_field_value
	.p2align	2
_nvm_record_map_execution_field_value:  ; @nvm_record_map_execution_field_value
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB129_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB129_5
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	cbz	x8, LBB129_5
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	w9, [x8, #4]
	cmp	w1, w9
	b.hs	LBB129_6
; %bb.4:
	ldr	x8, [x8, #3096]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
LBB129_5:
	ret
LBB129_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_required_elements ; -- Begin function nvm_record_map_execution_required_elements
	.globl	_nvm_record_map_execution_required_elements
	.p2align	2
_nvm_record_map_execution_required_elements: ; @nvm_record_map_execution_required_elements
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB130_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB130_5
; %bb.2:
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	cbz	x8, LBB130_5
; %bb.3:
	ldr	x9, [x8, #8]
	ldr	w9, [x9]
	cmp	w1, w9
	b.hs	LBB130_6
; %bb.4:
	add	x8, x8, w1, uxtw #1
	ldrh	w8, [x8, #16]
	strh	w8, [x2]
	mov	w0, #1                          ; =0x1
LBB130_5:
	ret
LBB130_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_declaration_counts ; -- Begin function nvm_record_map_execution_declaration_counts
	.globl	_nvm_record_map_execution_declaration_counts
	.p2align	2
_nvm_record_map_execution_declaration_counts: ; @nvm_record_map_execution_declaration_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB131_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB131_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_counts
LBB131_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_layout ; -- Begin function nvm_record_map_execution_layout
	.globl	_nvm_record_map_execution_layout
	.p2align	2
_nvm_record_map_execution_layout:       ; @nvm_record_map_execution_layout
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB132_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB132_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_layout
LBB132_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_field ; -- Begin function nvm_record_map_execution_field
	.globl	_nvm_record_map_execution_field
	.p2align	2
_nvm_record_map_execution_field:        ; @nvm_record_map_execution_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB133_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB133_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_field
LBB133_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_type ; -- Begin function nvm_record_map_execution_type
	.globl	_nvm_record_map_execution_type
	.p2align	2
_nvm_record_map_execution_type:         ; @nvm_record_map_execution_type
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB134_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB134_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_type
LBB134_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_binding ; -- Begin function nvm_record_map_execution_binding
	.globl	_nvm_record_map_execution_binding
	.p2align	2
_nvm_record_map_execution_binding:      ; @nvm_record_map_execution_binding
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB135_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB135_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_binding
LBB135_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_variant ; -- Begin function nvm_record_map_execution_variant
	.globl	_nvm_record_map_execution_variant
	.p2align	2
_nvm_record_map_execution_variant:      ; @nvm_record_map_execution_variant
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB136_3
; %bb.1:
	ldr	x8, [x0, #8]
	ldr	x8, [x8]
	cbz	x8, LBB136_3
; %bb.2:
	ldr	x0, [x8]
	b	_nvm_ownership_declarations_variant
LBB136_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_boundary_free ; -- Begin function nvm_record_map_boundary_free
	.globl	_nvm_record_map_boundary_free
	.p2align	2
_nvm_record_map_boundary_free:          ; @nvm_record_map_boundary_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB137_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x20, [x0]
	cbz	x20, LBB137_3
; %bb.2:
	ldr	x0, [x20]
	bl	_nvm_record_array_execution_free
	ldr	x0, [x20, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x20, #16]
	bl	_free
	mov	x0, x20
	bl	_free
LBB137_3:
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB137_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_record_map_boundary_reserved_private ; -- Begin function nvm_prepare_record_map_boundary_reserved_private
	.globl	_nvm_prepare_record_map_boundary_reserved_private
	.p2align	2
_nvm_prepare_record_map_boundary_reserved_private: ; @nvm_prepare_record_map_boundary_reserved_private
	.cfi_startproc
; %bb.0:
	b	_rmb_prepare_reserved
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rmb_prepare_reserved
_rmb_prepare_reserved:                  ; @rmb_prepare_reserved
	.cfi_startproc
; %bb.0:
Lloh57:
	adrp	x9, l___const.rmb_prepare_reserved.r@PAGE
Lloh58:
	add	x9, x9, l___const.rmb_prepare_reserved.r@PAGEOFF
	ldp	q0, q1, [x9, #160]
	stp	q0, q1, [x8, #160]
	ldur	q0, [x9, #188]
	stur	q0, [x8, #188]
	ldp	q0, q1, [x9, #96]
	stp	q0, q1, [x8, #96]
	ldp	q1, q0, [x9, #128]
	stp	q1, q0, [x8, #128]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x9, #64]
	stp	q1, q0, [x8, #64]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x8]
	cbz	x0, LBB139_12
; %bb.1:
	cbz	x1, LBB139_12
; %bb.2:
	cmn	x2, #41
	b.hi	LBB139_7
; %bb.3:
	cmn	x3, #40
	b.hs	LBB139_7
; %bb.4:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	stp	xzr, xzr, [sp, #16]
	str	xzr, [sp, #8]
	add	x1, sp, #24
	add	x2, x2, #40
	add	x3, x3, #40
	add	x4, sp, #8
	mov	x19, x8
	bl	_rme_prepare_boundary
	ldr	w8, [x19]
	cbnz	w8, LBB139_11
; %bb.5:
	mov	w0, #1                          ; =0x1
	mov	w1, #40                         ; =0x28
	bl	_calloc
	cbz	x0, LBB139_8
; %bb.6:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	stp	x8, x9, [x0]
	ldr	w9, [sp, #16]
	str	w9, [x0, #16]
	ldr	x8, [x8]
	ldr	q0, [x8, #13360]
	stur	q0, [x0, #24]
	str	x0, [x20]
	b	LBB139_11
LBB139_7:
	mov	w9, #3                          ; =0x3
	str	w9, [x8]
	ret
LBB139_8:
	ldr	x0, [sp, #8]
	bl	_free
	ldr	x20, [sp, #24]
	cbz	x20, LBB139_10
; %bb.9:
	ldr	x0, [x20]
	bl	_nvm_record_array_execution_free
	ldr	x0, [x20, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x20, #16]
	bl	_free
	mov	x0, x20
	bl	_free
LBB139_10:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
Lloh59:
	adrp	x8, l_.str.181@PAGE
Lloh60:
	add	x8, x8, l_.str.181@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldur	q0, [x8, #31]
	stur	q0, [x19, #43]
LBB139_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB139_12:
	ret
	.loh AdrpAdd	Lloh57, Lloh58
	.loh AdrpAdd	Lloh59, Lloh60
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_prepare_record_map_boundary ; -- Begin function nvm_prepare_record_map_boundary
	.globl	_nvm_prepare_record_map_boundary
	.p2align	2
_nvm_prepare_record_map_boundary:       ; @nvm_prepare_record_map_boundary
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_rmb_prepare_reserved
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_boundary_counts ; -- Begin function nvm_record_map_boundary_counts
	.globl	_nvm_record_map_boundary_counts
	.p2align	2
_nvm_record_map_boundary_counts:        ; @nvm_record_map_boundary_counts
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB141_2
; %bb.1:
	ldr	w9, [x8, #16]
	ldur	q0, [x8, #24]
	stp	w9, wzr, [x1]
	stur	q0, [x1, #8]
LBB141_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_boundary_global ; -- Begin function nvm_record_map_boundary_global
	.globl	_nvm_record_map_boundary_global
	.p2align	2
_nvm_record_map_boundary_global:        ; @nvm_record_map_boundary_global
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB142_5
; %bb.1:
	cbz	x2, LBB142_5
; %bb.2:
	ldr	w9, [x8, #16]
	cmp	w1, w9
	b.hs	LBB142_4
; %bb.3:
	ldr	x8, [x8, #8]
	ldr	q0, [x8, w1, uxtw #4]
	str	q0, [x2]
	mov	w0, #1                          ; =0x1
	ret
LBB142_4:
	mov	w0, #0                          ; =0x0
LBB142_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_boundary_execution ; -- Begin function nvm_record_map_boundary_execution
	.globl	_nvm_record_map_boundary_execution
	.p2align	2
_nvm_record_map_boundary_execution:     ; @nvm_record_map_boundary_execution
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB143_2
; %bb.1:
	ldr	x0, [x0]
LBB143_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_execution_uniform_pair ; -- Begin function nvm_record_map_execution_uniform_pair
	.globl	_nvm_record_map_execution_uniform_pair
	.p2align	2
_nvm_record_map_execution_uniform_pair: ; @nvm_record_map_execution_uniform_pair
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB144_12
; %bb.1:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB144_11
; %bb.2:
	ldr	x8, [x19, #8]
	cbz	x8, LBB144_11
; %bb.3:
	mov	x20, x1
	ldr	x0, [x8, #8]
	add	x1, sp, #20
	bl	_nvm_map_declarations_counts
	ldr	w8, [sp, #24]
	cmp	w0, #0
	ccmp	w8, #1, #0, ne
	b.eq	LBB144_5
LBB144_4:
	mov	w0, #0                          ; =0x0
	b	LBB144_11
LBB144_5:
	ldr	x8, [x19, #8]
	ldr	x0, [x8, #8]
	add	x2, sp, #12
	mov	w1, #0                          ; =0x0
	bl	_nvm_map_declarations_pair
	cbz	w0, LBB144_11
; %bb.6:
	ldr	x8, [x19, #8]
	ldr	x0, [x8, #8]
	ldr	w1, [sp, #12]
	add	x2, sp, #11
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB144_11
; %bb.7:
	ldr	x8, [x19, #8]
	ldr	x0, [x8, #8]
	ldr	w1, [sp, #16]
	add	x2, sp, #10
	bl	_nvm_map_declarations_scalar
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB144_11
; %bb.8:
	ldrb	w8, [sp, #11]
	cmp	w8, #5
	b.ne	LBB144_11
; %bb.9:
	ldrb	w8, [sp, #10]
	and	w9, w8, #0xfffffffb
	cmp	w9, #1
	b.ne	LBB144_4
; %bb.10:
	strb	w8, [x20]
	mov	w0, #1                          ; =0x1
LBB144_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
LBB144_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_free ; -- Begin function nvm_record_map_image_free
	.globl	_nvm_record_map_image_free
	.p2align	2
_nvm_record_map_image_free:             ; @nvm_record_map_image_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB145_4
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x19, [x0]
	cbz	x19, LBB145_3
; %bb.2:
	ldr	x8, [x19]
	mov	x20, x0
	mov	x0, x8
	bl	_nvm_record_array_execution_free
	ldr	x0, [x19, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x19, #16]
	bl	_free
	mov	x0, x19
	bl	_free
	mov	x0, x20
LBB145_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB145_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_copy ; -- Begin function nvm_record_map_image_copy
	.globl	_nvm_record_map_image_copy
	.p2align	2
_nvm_record_map_image_copy:             ; @nvm_record_map_image_copy
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_rme_image_copy_reserved
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rme_image_copy_reserved
_rme_image_copy_reserved:               ; @rme_image_copy_reserved
	.cfi_startproc
; %bb.0:
Lloh61:
	adrp	x9, l___const.rme_image_copy_reserved.result@PAGE
Lloh62:
	add	x9, x9, l___const.rme_image_copy_reserved.result@PAGEOFF
	ldp	q0, q1, [x9, #160]
	stp	q0, q1, [x8, #160]
	ldur	q0, [x9, #188]
	stur	q0, [x8, #188]
	ldp	q0, q1, [x9, #96]
	stp	q0, q1, [x8, #96]
	ldp	q1, q0, [x9, #128]
	stp	q1, q0, [x8, #128]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x9, #64]
	stp	q1, q0, [x8, #64]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x8]
	cbz	x0, LBB147_58
; %bb.1:
	cbz	x1, LBB147_58
; %bb.2:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	str	xzr, [sp, #16]
Lloh63:
	adrp	x9, l___const.rme_image_copy_reserved.w@PAGE
Lloh64:
	add	x9, x9, l___const.rme_image_copy_reserved.w@PAGEOFF
Lloh65:
	ldr	q0, [x9]
	str	q0, [sp]
	ldr	x15, [x0]
	cbz	x15, LBB147_55
; %bb.3:
	mov	x23, x0
	ldr	x0, [x0, #8]
	cbz	x0, LBB147_55
; %bb.4:
	ldr	x9, [x15, #480]
	cbnz	x9, LBB147_55
; %bb.5:
	ldr	w10, [x15, #272]
	sub	w9, w10, #257
	cmn	w9, #256
	b.lo	LBB147_55
; %bb.6:
	ldr	w9, [x15, #248]
	cmp	w9, #1, lsl #12                 ; =4096
	b.hi	LBB147_55
; %bb.7:
	ldr	w11, [x15, #488]
	cmp	w11, w10
	b.ne	LBB147_55
; %bb.8:
	ldr	w11, [x15, #512]
	cmp	w11, w9
	b.ne	LBB147_55
; %bb.9:
	ldr	w14, [x15, #520]
	ldr	w11, [x15, #368]
	cmp	w14, w11
	b.ne	LBB147_55
; %bb.10:
	ldr	w4, [x15, #524]
	ldr	w11, [x15, #384]
	cmp	w4, w11
	b.ne	LBB147_55
; %bb.11:
	ldr	w13, [x15, #516]
	ldr	w12, [x15, #224]
	mov	w11, #2                         ; =0x2
	cmp	w13, w12
	b.ne	LBB147_56
; %bb.12:
	cmp	w12, #16
	b.hi	LBB147_56
; %bb.13:
	ldr	w11, [x15, #492]
	cmp	w11, #16, lsl #12               ; =65536
	b.hi	LBB147_55
; %bb.14:
	ldr	w5, [x15, #288]
	mov	w12, #16777216                  ; =0x1000000
	cmp	w5, w12
	b.hi	LBB147_55
; %bb.15:
	ldr	x12, [x15, #13352]
	cmp	x12, #0
	cset	w12, ne
	cmp	w11, #0
	cset	w13, eq
	cmp	w13, w12
	b.eq	LBB147_55
; %bb.16:
	cmp	w11, #0
	cset	w12, eq
	ldr	x13, [x23, #16]
	cmp	x13, #0
	cset	w13, ne
	cmp	w12, w13
	b.eq	LBB147_55
; %bb.17:
	ldr	x6, [x15, #256]
	cbz	x6, LBB147_55
; %bb.18:
	ldr	x12, [x15, #280]
	cmp	x12, #0
	cset	w12, ne
	cmp	w5, #0
	cset	w13, eq
	cmp	w13, w12
	b.eq	LBB147_55
; %bb.19:
	ldr	x12, [x15, #312]
	ldr	w7, [x15, #320]
	cmp	x7, #0
	cset	w13, eq
	cmp	x12, #0
	cset	w12, ne
	cmp	w12, w13
	b.eq	LBB147_55
; %bb.20:
	ldr	x12, [x15, #296]
	ldr	w24, [x15, #304]
	cmp	x24, #0
	cset	w13, eq
	cmp	x12, #0
	cset	w12, ne
	cmp	w12, w13
	b.eq	LBB147_55
; %bb.21:
	ldr	x12, [x15, #360]
	cmp	x12, #0
	cset	w12, ne
	cmp	w14, #0
	cset	w13, eq
	cmp	w13, w12
	b.eq	LBB147_55
; %bb.22:
	ldr	x12, [x15, #376]
	cmp	x12, #0
	cset	w12, ne
	cmp	w4, #0
	cset	w13, eq
	cmp	w13, w12
	b.eq	LBB147_55
; %bb.23:
	ldr	x12, [x15, #240]
	cmp	x12, #0
	cset	w13, ne
	cmp	w9, #0
	cset	w16, eq
	cmp	w16, w13
	b.eq	LBB147_55
; %bb.24:
	cmp	w9, #0
	cset	w16, eq
	ldr	x13, [x15, #232]
	cmp	x13, #0
	cset	w17, ne
	cmp	w16, w17
	b.eq	LBB147_55
; %bb.25:
	ldr	x16, [x15, #264]
	cmp	x16, #0
	csel	x25, xzr, x10, eq
	cset	w17, ne
	cmp	x25, #0
	cset	w19, eq
	cmp	w17, w19
	b.eq	LBB147_55
; %bb.26:
	mov	x20, x2
	mov	x21, x3
	mov	x19, x1
	mov	x22, x8
	mov	w17, #0                         ; =0x0
	add	x8, x10, x10, lsl #1
	lsl	x1, x8, #3
	add	x2, x4, x4, lsl #1
	lsl	x2, x2, #2
	add	x14, x14, x9
	add	x14, x14, x25
	lsl	x3, x9, #2
	add	x1, x1, x3
	add	x2, x2, x5
	add	x1, x1, x2
	add	x2, x7, x24
	add	x1, x1, x2
	mov	w2, #152                        ; =0x98
	umaddl	x1, w11, w2, x1
	add	x14, x1, x14, lsl #3
	mov	w1, #13408                      ; =0x3460
	add	x24, x14, x1
	lsl	x1, x8, #2
	add	x14, x1, #68
	add	x15, x15, #580
	add	x2, x6, #16
	mov	w3, #68                         ; =0x44
	mov	w4, #33554368                   ; =0x1ffffc0
	mov	w5, #33554424                   ; =0x1fffff8
	mov	x6, x16
LBB147_27:                              ; =>This Inner Loop Header: Depth=1
	cmp	x3, x5
	b.hi	LBB147_60
; %bb.28:                               ;   in Loop: Header=BB147_27 Depth=1
	ldurh	w25, [x2, #-12]
	cmp	w25, #256
	mov	x8, x22
	b.hi	LBB147_55
; %bb.29:                               ;   in Loop: Header=BB147_27 Depth=1
	ldrh	w7, [x2]
	cmp	w7, #256
	b.hi	LBB147_55
; %bb.30:                               ;   in Loop: Header=BB147_27 Depth=1
	ldurh	w26, [x15, #-24]
	cmp	w26, w25
	b.ne	LBB147_55
; %bb.31:                               ;   in Loop: Header=BB147_27 Depth=1
	ldurh	w26, [x15, #-12]
	cmp	w26, w7
	b.ne	LBB147_55
; %bb.32:                               ;   in Loop: Header=BB147_27 Depth=1
	ldur	w7, [x15, #-4]
	cmp	w7, w17
	b.ne	LBB147_55
; %bb.33:                               ;   in Loop: Header=BB147_27 Depth=1
	ldr	w7, [x15]
	sub	w26, w11, w17
	cmp	w7, w26
	b.hi	LBB147_55
; %bb.34:                               ;   in Loop: Header=BB147_27 Depth=1
	cbz	x16, LBB147_37
; %bb.35:                               ;   in Loop: Header=BB147_27 Depth=1
	ldr	x8, [x6]
	cbz	x8, LBB147_38
; %bb.36:                               ;   in Loop: Header=BB147_27 Depth=1
	cmp	w25, #1
	csinc	w25, w25, wzr, hi
	mov	w8, #1                          ; =0x1
	b	LBB147_39
LBB147_37:                              ;   in Loop: Header=BB147_27 Depth=1
	mov	w8, #0                          ; =0x0
LBB147_38:                              ;   in Loop: Header=BB147_27 Depth=1
	mov	x25, #0                         ; =0x0
LBB147_39:                              ;   in Loop: Header=BB147_27 Depth=1
	sub	x4, x4, #12
	cbz	x4, LBB147_60
; %bb.40:                               ;   in Loop: Header=BB147_27 Depth=1
	cmp	x25, #0
	cset	w26, eq
	cmp	w8, w26
	mov	x8, x22
	b.eq	LBB147_55
; %bb.41:                               ;   in Loop: Header=BB147_27 Depth=1
	cmn	x24, x25
	b.hs	LBB147_60
; %bb.42:                               ;   in Loop: Header=BB147_27 Depth=1
	add	w17, w7, w17
	add	x6, x6, #8
	add	x15, x15, #36
	add	x2, x2, #24
	add	x3, x3, #12
	add	x24, x25, x24
	sub	x10, x10, #1
	cbnz	x10, LBB147_27
; %bb.43:
	str	x14, [sp]
	cmp	w17, w11
	mov	x8, x22
	b.ne	LBB147_55
; %bb.44:
	cbz	w9, LBB147_52
; %bb.45:
	mov	w8, #12                         ; =0xc
	umaddl	x10, w9, w8, x14
	mov	w8, #33554368                   ; =0x1ffffc0
	sub	x11, x8, x1
	mov	w15, #33554424                  ; =0x1fffff8
LBB147_46:                              ; =>This Inner Loop Header: Depth=1
	cmp	x14, x15
	b.hi	LBB147_60
; %bb.47:                               ;   in Loop: Header=BB147_46 Depth=1
	sub	x11, x11, #12
	cbz	x11, LBB147_60
; %bb.48:                               ;   in Loop: Header=BB147_46 Depth=1
	ldr	x16, [x13], #8
	mov	x8, x22
	cbz	x16, LBB147_55
; %bb.49:                               ;   in Loop: Header=BB147_46 Depth=1
	ldr	w8, [x12], #4
	mvn	x16, x24
	cmp	x8, x16
	b.hs	LBB147_60
; %bb.50:                               ;   in Loop: Header=BB147_46 Depth=1
	add	x14, x14, #12
	add	x8, x24, x8
	add	x24, x8, #1
	sub	x9, x9, #1
	cbnz	x9, LBB147_46
; %bb.51:
	str	x10, [sp]
LBB147_52:
	mov	x1, sp
	add	x2, sp, #24
	bl	_rme_frozen_retained_cost
	cbz	w0, LBB147_59
; %bb.53:
	cmp	w0, #2
	b.eq	LBB147_60
; %bb.54:
	mov	w11, #2                         ; =0x2
	b	LBB147_61
LBB147_55:
	mov	w11, #2                         ; =0x2
LBB147_56:
	str	w11, [x8]
LBB147_57:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB147_58:
	ret
LBB147_59:
	ldr	x8, [sp, #24]
	cmn	x24, x8
	b.lo	LBB147_62
LBB147_60:
	mov	w11, #3                         ; =0x3
LBB147_61:
	mov	x8, x22
	b	LBB147_56
LBB147_62:
	add	x25, x8, x24
	cmn	x25, #33
	b.hi	LBB147_66
; %bb.63:
	ldr	x8, [sp]
	cmn	x8, #33
	b.hi	LBB147_66
; %bb.64:
	mov	x9, #-33                        ; =0xffffffffffffffdf
	sub	x9, x9, x25
	cmp	x20, x9
	b.hi	LBB147_66
; %bb.65:
	mov	x9, #-33                        ; =0xffffffffffffffdf
	sub	x9, x9, x8
	cmp	x21, x9
	b.ls	LBB147_67
LBB147_66:
	mov	w8, #3                          ; =0x3
	str	w8, [x22]
	b	LBB147_57
LBB147_67:
	add	x9, x20, x25
	add	x20, x9, #32
	mov	w9, #52128                      ; =0xcba0
	movk	w9, #1022, lsl #16
	cmp	x20, x9
	b.hi	LBB147_66
; %bb.68:
	add	x8, x21, x8
	add	x21, x8, #32
	mov	w8, #52129                      ; =0xcba1
	movk	w8, #254, lsl #16
	cmp	x21, x8
	b.hs	LBB147_66
; %bb.69:
	mov	w0, #1                          ; =0x1
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB147_72
; %bb.70:
	mov	x24, x0
	ldr	x0, [x23]
	mov	x8, x22
	mov	x1, x24
	mov	x2, x20
	mov	x3, x21
	mov	x4, #0                          ; =0x0
	bl	_rme_prepare_boundary
	ldr	w8, [x22]
	cbz	w8, LBB147_73
; %bb.71:
	mov	x0, x24
	bl	_nvm_record_map_image_free
	b	LBB147_57
LBB147_72:
	mov	w8, #4                          ; =0x4
	str	w8, [x22]
	b	LBB147_57
LBB147_73:
	ldr	x8, [x24]
	ldr	x8, [x8]
	add	x8, x8, #536
	ldr	q0, [x8]
	str	q0, [x24, #16]
Lloh66:
	adrp	x8, l_.str.182@PAGE
Lloh67:
	add	x8, x8, l_.str.182@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x22, #28]
	ldp	q0, q2, [x8, #32]
	stur	q0, [x22, #44]
	stur	q2, [x22, #60]
	str	x25, [x24, #8]
	str	x24, [x19]
	ldur	x8, [x8, #61]
	stur	x8, [x22, #73]
	stur	q1, [x22, #12]
	b	LBB147_57
	.loh AdrpAdd	Lloh61, Lloh62
	.loh AdrpAddLdr	Lloh63, Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_cost ; -- Begin function nvm_record_map_image_cost
	.globl	_nvm_record_map_image_cost
	.p2align	2
_nvm_record_map_image_cost:             ; @nvm_record_map_image_cost
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB148_2
; %bb.1:
	ldur	q0, [x8, #8]
	ldr	x8, [x8, #24]
	str	x8, [x1, #16]
	str	q0, [x1]
LBB148_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_borrow ; -- Begin function nvm_record_map_image_borrow
	.globl	_nvm_record_map_image_borrow
	.p2align	2
_nvm_record_map_image_borrow:           ; @nvm_record_map_image_borrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB149_2
; %bb.1:
	ldr	x8, [x0]
	ldr	x0, [x8]
LBB149_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_counts ; -- Begin function nvm_record_map_image_counts
	.globl	_nvm_record_map_image_counts
	.p2align	2
_nvm_record_map_image_counts:           ; @nvm_record_map_image_counts
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB150_8
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB150_8
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB150_8
; %bb.3:
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	ldr	x9, [x8]
	cbz	x9, LBB150_6
; %bb.4:
	add	x9, x9, #488
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [sp, #32]
	ldr	x8, [x8, #8]
	cbz	x8, LBB150_6
; %bb.5:
	ldur	q0, [x8, #24]
	ldur	q1, [x8, #40]
	stp	q0, q1, [sp, #64]
	ldp	q2, q3, [sp, #32]
	stp	q2, q3, [x1, #32]
	stp	q0, q1, [x1, #64]
	ldp	q0, q1, [sp]
	mov	w0, #1                          ; =0x1
	stp	q0, q1, [x1]
	b	LBB150_7
LBB150_6:
	mov	w0, #0                          ; =0x0
LBB150_7:
	add	sp, sp, #96
LBB150_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_instruction ; -- Begin function nvm_record_map_image_instruction
	.globl	_nvm_record_map_image_instruction
	.p2align	2
_nvm_record_map_image_instruction:      ; @nvm_record_map_image_instruction
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB151_5
; %bb.1:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x2, LBB151_5
; %bb.2:
	ldr	x8, [x8]
	cbz	x8, LBB151_5
; %bb.3:
	ldr	x9, [x8]
	ldr	w9, [x9, #492]
	cmp	w1, w9
	b.hs	LBB151_6
; %bb.4:
	ldr	x8, [x8, #16]
	mov	w9, #80                         ; =0x50
	umaddl	x8, w1, w9, x8
	ldr	q0, [x8]
	str	q0, [x2]
	ldp	q0, q1, [x8, #16]
	ldp	q2, q3, [x8, #48]
	stp	q2, q3, [x2, #48]
	stp	q0, q1, [x2, #16]
	mov	w0, #1                          ; =0x1
LBB151_5:
	ret
LBB151_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_field ; -- Begin function nvm_record_map_image_field
	.globl	_nvm_record_map_image_field
	.p2align	2
_nvm_record_map_image_field:            ; @nvm_record_map_image_field
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB152_12
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB152_11
; %bb.2:
	mov	w0, #0                          ; =0x0
	cmp	x3, x4
	b.eq	LBB152_12
; %bb.3:
	cbz	x4, LBB152_12
; %bb.4:
	cbz	x3, LBB152_12
; %bb.5:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x21, [x8, #8]
	cbz	x21, LBB152_10
; %bb.6:
	mov	x20, x3
	mov	x19, x4
	ldr	x0, [x21, #8]
	add	x3, sp, #8
	bl	_nvm_map_declarations_field
	cbz	w0, LBB152_10
; %bb.7:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #8]
	add	x2, sp, #7
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB152_10
; %bb.8:
	ldr	x0, [x21, #8]
	ldr	w1, [sp, #12]
	add	x2, sp, #6
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB152_10
; %bb.9:
	ldrb	w8, [sp, #7]
	strb	w8, [x20]
	ldrb	w8, [sp, #6]
	strb	w8, [x19]
	mov	w0, #1                          ; =0x1
LBB152_10:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB152_11:
	mov	w0, #0                          ; =0x0
LBB152_12:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_origin ; -- Begin function nvm_record_map_image_origin
	.globl	_nvm_record_map_image_origin
	.p2align	2
_nvm_record_map_image_origin:           ; @nvm_record_map_image_origin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB153_3
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB153_3
; %bb.2:
	ldr	x0, [x8, #8]
	b	_nvm_record_map_frozen_origin
LBB153_3:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_copy_reserved ; -- Begin function nvm_record_map_image_copy_reserved
	.globl	_nvm_record_map_image_copy_reserved
	.p2align	2
_nvm_record_map_image_copy_reserved:    ; @nvm_record_map_image_copy_reserved
	.cfi_startproc
; %bb.0:
	mov	x9, x2
	mov	x2, x1
	mov	x1, x3
	mov	x3, x9
	b	_rme_image_copy_reserved
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_image_plan ; -- Begin function nvm_record_map_image_plan
	.globl	_nvm_record_map_image_plan
	.p2align	2
_nvm_record_map_image_plan:             ; @nvm_record_map_image_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB155_2
; %bb.1:
	ldr	x0, [x0]
LBB155_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_candidate ; -- Begin function nvm_record_array_candidate
	.globl	_nvm_record_array_candidate
	.p2align	2
_nvm_record_array_candidate:            ; @nvm_record_array_candidate
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB156_15
; %bb.1:
	ldr	x1, [x0, #296]
	cbz	x1, LBB156_16
; %bb.2:
	ldr	x8, [x0, #312]
	cbz	x8, LBB156_16
; %bb.3:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	ldr	w2, [x0, #304]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB156_14
; %bb.4:
	ldr	w8, [sp, #36]
	cmp	w8, #3
	b.ne	LBB156_14
; %bb.5:
	add	x0, sp, #40
	add	x1, sp, #32
	bl	_nvm_v2_u32
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB156_14
; %bb.6:
	ldr	w1, [sp, #32]
	cmp	w1, #256
	b.hi	LBB156_14
; %bb.7:
	add	x0, sp, #40
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbnz	w0, LBB156_13
; %bb.8:
	ldr	w8, [sp, #32]
	mov	x9, x19
	cbz	w8, LBB156_12
; %bb.9:
	ldr	x10, [sp, #16]
LBB156_10:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #1
	tbnz	w11, #1, LBB156_13
; %bb.11:                               ;   in Loop: Header=BB156_10 Depth=1
	subs	x8, x8, #1
	b.ne	LBB156_10
LBB156_12:
	ldr	x1, [x9, #312]
	ldr	w2, [x9, #320]
	add	x0, sp, #40
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbz	w0, LBB156_17
LBB156_13:
	mov	w0, #0                          ; =0x0
LBB156_14:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB156_15:
	ret
LBB156_16:
	mov	w0, #0                          ; =0x0
	ret
LBB156_17:
	ldp	w9, w8, [sp, #28]
	cmp	w9, w8
	b.ne	LBB156_14
; %bb.18:
	cbz	w8, LBB156_14
; %bb.19:
	mov	w20, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	mov	w22, #65536                     ; =0x10000
LBB156_20:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB156_27 Depth 2
	add	x0, sp, #40
	add	x1, sp, #15
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_13
; %bb.21:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #14
	bl	_nvm_v2_u8
	cbnz	w0, LBB156_13
; %bb.22:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #12
	bl	_nvm_v2_u16
	cbnz	w0, LBB156_13
; %bb.23:                               ;   in Loop: Header=BB156_20 Depth=1
	add	x0, sp, #40
	add	x1, sp, #8
	bl	_nvm_v2_u32
	cbnz	w0, LBB156_13
; %bb.24:                               ;   in Loop: Header=BB156_20 Depth=1
	ldrh	w23, [sp, #12]
	sub	w8, w22, w21
	cmp	w8, w23
	b.lo	LBB156_13
; %bb.25:                               ;   in Loop: Header=BB156_20 Depth=1
	cbz	w23, LBB156_30
; %bb.26:                               ;   in Loop: Header=BB156_20 Depth=1
	mov	w24, #0                         ; =0x0
LBB156_27:                              ;   Parent Loop BB156_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #40
	mov	x2, sp
	mov	w1, #12                         ; =0xc
	bl	_nvm_v2_take
	cbnz	w0, LBB156_13
; %bb.28:                               ;   in Loop: Header=BB156_27 Depth=2
	ldr	x8, [sp]
	ldrb	w8, [x8]
	cmp	w8, #7
	b.eq	LBB156_31
; %bb.29:                               ;   in Loop: Header=BB156_27 Depth=2
	add	w24, w24, #1
	ldrh	w8, [sp, #12]
	cmp	w24, w8
	b.lo	LBB156_27
LBB156_30:                              ;   in Loop: Header=BB156_20 Depth=1
	mov	w0, #0                          ; =0x0
	add	w21, w21, w23
	add	w20, w20, #1
	ldr	w8, [sp, #32]
	cmp	w20, w8
	b.lo	LBB156_20
	b	LBB156_14
LBB156_31:
	mov	x0, x19
	bl	_nvm_service_execution_pending
	eor	w0, w0, #0x1
	b	LBB156_14
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_array_admit ; -- Begin function nvm_record_array_admit
	.globl	_nvm_record_array_admit
	.p2align	2
_nvm_record_array_admit:                ; @nvm_record_array_admit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
Lloh68:
	adrp	x8, l___const.nvm_record_array_admit.result@PAGE
Lloh69:
	add	x8, x8, l___const.nvm_record_array_admit.result@PAGEOFF
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x19, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x19]
	cbz	x1, LBB157_23
; %bb.1:
	mov	x21, x1
	mov	x20, x0
	bl	_nvm_record_array_candidate
	cbz	w0, LBB157_25
; %bb.2:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x8, x19
	mov	x0, x20
	bl	_nvm_prepare_record_array_execution
	ldr	w8, [x19]
	cbnz	w8, LBB157_25
; %bb.3:
	ldr	x0, [sp, #8]
	cbz	x0, LBB157_24
; %bb.4:
	ldr	w8, [x0, #488]
	cmp	w8, #256
	b.hi	LBB157_24
; %bb.5:
	ldr	w10, [x0, #504]
	cmp	w10, w8
	b.hs	LBB157_24
; %bb.6:
	add	x9, x0, #552
	mov	w11, #36                        ; =0x24
	umaddl	x10, w10, w11, x9
	ldrh	w11, [x10, #4]
	cbnz	w11, LBB157_24
; %bb.7:
	ldrb	w11, [x10, #20]
	ldrb	w10, [x10, #21]
	cmp	w10, #1
	ccmp	w11, #1, #0, eq
	b.ne	LBB157_24
; %bb.8:
	ldr	w13, [x0, #492]
	ldr	w11, [x0, #500]
	ldr	w12, [x0, #528]
	mov	x10, x21
	cbz	w13, LBB157_13
; %bb.9:
	mov	w14, #30                        ; =0x1e
LBB157_10:                              ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB157_26
; %bb.11:                               ;   in Loop: Header=BB157_10 Depth=1
	ldr	x15, [x0, #13352]
	ldrb	w15, [x15, x14]
	sub	w15, w15, #97
	cmp	w15, #2
	b.ls	LBB157_26
; %bb.12:                               ;   in Loop: Header=BB157_10 Depth=1
	add	x14, x14, #72
	subs	x13, x13, #1
	b.ne	LBB157_10
LBB157_13:
	cbz	w12, LBB157_18
; %bb.14:
	mov	w13, #10284                     ; =0x282c
	add	x13, x0, x13
LBB157_15:                              ; =>This Inner Loop Header: Depth=1
	cbz	x12, LBB157_27
; %bb.16:                               ;   in Loop: Header=BB157_15 Depth=1
	ldp	w14, w15, [x13, #-4]
	cmp	w14, w15
	b.ne	LBB157_27
; %bb.17:                               ;   in Loop: Header=BB157_15 Depth=1
	add	x13, x13, #12
	subs	x12, x12, #1
	b.ne	LBB157_15
LBB157_18:
	cmn	w11, #1
	b.eq	LBB157_22
; %bb.19:
	cmp	w11, w8
	b.hs	LBB157_28
; %bb.20:
	mov	w8, #36                         ; =0x24
	umaddl	x8, w11, w8, x9
	ldrh	w9, [x8, #4]
	cbnz	w9, LBB157_28
; %bb.21:
	ldrb	w9, [x8, #21]
	ldrb	w8, [x8, #20]
	cmp	w9, #0
	ccmp	w8, #1, #4, ne
	b.ne	LBB157_28
LBB157_22:
	str	x0, [x10]
	b	LBB157_25
LBB157_23:
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
	b	LBB157_25
LBB157_24:
	bl	_nvm_record_array_execution_free
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
Lloh70:
	adrp	x8, l_.str.11@PAGE
Lloh71:
	add	x8, x8, l_.str.11@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	ldur	q0, [x8, #42]
	stur	q0, [x19, #54]
LBB157_25:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB157_26:
	bl	_nvm_record_array_execution_free
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #29541                      ; =0x7365
	movk	w8, #46, lsl #16
	stur	w8, [x19, #75]
Lloh72:
	adrp	x8, l_.str.12@PAGE
Lloh73:
	add	x8, x8, l_.str.12@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldp	q0, q1, [x8, #32]
	stur	q0, [x19, #44]
	stur	q1, [x19, #60]
	b	LBB157_25
LBB157_27:
	bl	_nvm_record_array_execution_free
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
Lloh74:
	adrp	x8, l_.str.13@PAGE
Lloh75:
	add	x8, x8, l_.str.13@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q0, [x19, #28]
	ldp	q0, q2, [x8, #32]
	stur	q0, [x19, #44]
	stur	q2, [x19, #60]
	ldur	x8, [x8, #61]
	stur	x8, [x19, #73]
	stur	q1, [x19, #12]
	b	LBB157_25
LBB157_28:
	bl	_nvm_record_array_execution_free
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
Lloh76:
	adrp	x8, l_.str.14@PAGE
Lloh77:
	add	x8, x8, l_.str.14@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	ldur	q0, [x8, #43]
	stur	q0, [x19, #55]
	b	LBB157_25
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_select_portable_read_heap ; -- Begin function nvm_select_portable_read_heap
	.globl	_nvm_select_portable_read_heap
	.p2align	2
_nvm_select_portable_read_heap:         ; @nvm_select_portable_read_heap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	stur	xzr, [x8, #196]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #180]
	stur	q0, [x8, #164]
	stur	q0, [x8, #148]
	stur	q0, [x8, #132]
	stur	q0, [x8, #116]
	stur	q0, [x8, #100]
	stur	q0, [x8, #84]
	stur	q0, [x8, #68]
	stur	q0, [x8, #52]
	stur	q0, [x8, #36]
	stur	q0, [x8, #20]
	stur	q0, [x8, #4]
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
	cbz	x0, LBB158_8
; %bb.1:
	cbz	x1, LBB158_8
; %bb.2:
	mov	x21, x1
	str	xzr, [sp, #40]
	stp	q0, q0, [sp]
	add	x1, sp, #40
	mov	x8, x19
	mov	x20, x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #1                          ; =0x1
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	x0, [sp, #40]
	bl	_free
	ldr	w22, [x19]
	mov	x8, x22
	cmp	w22, #1
	b.ne	LBB158_4
; %bb.3:
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	add	x2, sp, #32
	mov	x8, x19
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #1                          ; =0x1
	mov	x7, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	x0, [sp, #32]
	bl	_free
	ldr	w8, [x19]
LBB158_4:
	cbnz	w8, LBB158_8
; %bb.5:
	mov	w0, #1                          ; =0x1
	mov	w1, #24                         ; =0x18
	bl	_calloc
	cbz	x0, LBB158_7
; %bb.6:
	cmp	w22, #1
	cset	w8, eq
	str	w8, [x0]
	str	x0, [x21]
	b	LBB158_8
LBB158_7:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
LBB158_8:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_analyze_record_map_origins
lCPI159_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_analyze_record_map_origins
	.globl	_nvm_analyze_record_map_origins
	.p2align	2
_nvm_analyze_record_map_origins:        ; @nvm_analyze_record_map_origins
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB159_2
; %bb.1:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	bl	_analyze_context_sites
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB159_2:
Lloh78:
	adrp	x9, lCPI159_0@PAGE
Lloh79:
	ldr	d0, [x9, lCPI159_0@PAGEOFF]
	str	d0, [x8]
Lloh80:
	adrp	x9, l_.str.15@PAGE
Lloh81:
	add	x9, x9, l_.str.15@PAGEOFF
	ldp	q0, q1, [x9, #128]
	stur	q0, [x8, #140]
	stur	q1, [x8, #156]
	ldp	q0, q1, [x9, #160]
	stur	q0, [x8, #172]
	stur	q1, [x8, #188]
	ldp	q0, q1, [x9, #64]
	stur	q0, [x8, #76]
	stur	q1, [x8, #92]
	ldp	q0, q1, [x9, #96]
	stur	q0, [x8, #108]
	stur	q1, [x8, #124]
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	stur	q1, [x8, #28]
	ldp	q0, q1, [x9, #32]
	stur	q0, [x8, #44]
	str	wzr, [x8, #8]
	stur	q1, [x8, #60]
	ret
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_admit   ; -- Begin function nvm_record_map_admit
	.globl	_nvm_record_map_admit
	.p2align	2
_nvm_record_map_admit:                  ; @nvm_record_map_admit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
Lloh82:
	adrp	x8, l___const.nvm_record_map_admit.r@PAGE
Lloh83:
	add	x8, x8, l___const.nvm_record_map_admit.r@PAGEOFF
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x19, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x19]
	cbz	x1, LBB160_4
; %bb.1:
	mov	x21, x1
	mov	x20, x0
	bl	_nvm_record_map_route
	cmp	w0, #1
	b.eq	LBB160_6
; %bb.2:
	cmp	w0, #3
	b.eq	LBB160_5
; %bb.3:
	cmp	w0, #2
	b.ne	LBB160_15
LBB160_4:
	mov	w8, #2                          ; =0x2
	str	w8, [x19]
	b	LBB160_15
LBB160_5:
	mov	w8, #3                          ; =0x3
	str	w8, [x19]
	b	LBB160_15
LBB160_6:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x8, x19
	mov	x0, x20
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_rme_prepare_boundary
	ldr	w8, [x19]
	cbnz	w8, LBB160_15
; %bb.7:
	ldr	x20, [sp, #8]
	cbz	x20, LBB160_14
; %bb.8:
	ldr	x0, [x20]
	cbz	x0, LBB160_13
; %bb.9:
	ldr	x8, [x20, #8]
	cbz	x8, LBB160_13
; %bb.10:
	ldr	w8, [x0, #488]
	cmp	w8, #256
	b.hi	LBB160_13
; %bb.11:
	ldr	w10, [x0, #504]
	cmp	w10, w8
	b.hs	LBB160_13
; %bb.12:
	add	x9, x0, #552
	mov	w11, #36                        ; =0x24
	umaddl	x11, w10, w11, x9
	ldrh	w10, [x11, #4]
	ldrh	w12, [x11, #18]
	ldrb	w13, [x11, #21]
	cmp	w10, #0
	ccmp	w12, #0, #0, eq
	ccmp	w13, #1, #0, eq
	b.eq	LBB160_16
LBB160_13:
	bl	_nvm_record_array_execution_free
	ldr	x0, [x20, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x20, #16]
	bl	_free
	mov	x0, x20
	bl	_free
LBB160_14:
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #46                         ; =0x2e
	strh	w8, [x19, #76]
Lloh84:
	adrp	x8, l_.str.16@PAGE
Lloh85:
	add	x8, x8, l_.str.16@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldp	q0, q1, [x8, #32]
	stur	q0, [x19, #44]
	stur	q1, [x19, #60]
LBB160_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB160_16:
	ldr	w10, [x0, #500]
	ldrb	w11, [x11, #20]
	cmp	w11, #1
	ccmn	w10, #1, #4, eq
	b.ne	LBB160_19
; %bb.17:
	cmp	w11, #1
	b.ne	LBB160_13
LBB160_18:
	str	x20, [x21]
	b	LBB160_15
LBB160_19:
	cmp	w10, w8
	b.hs	LBB160_13
; %bb.20:
	mov	w8, #36                         ; =0x24
	umaddl	x8, w10, w8, x9
	ldrh	w9, [x8, #4]
	cbnz	w9, LBB160_13
; %bb.21:
	ldrh	w9, [x8, #18]
	cbnz	w9, LBB160_13
; %bb.22:
	ldrb	w9, [x8, #21]
	cmp	w9, #1
	b.hi	LBB160_13
; %bb.23:
	ldrb	w8, [x8, #20]
	orr	w10, w9, w8
	cbz	w10, LBB160_18
; %bb.24:
	cmp	w9, #1
	ccmp	w8, #1, #0, eq
	b.ne	LBB160_13
	b	LBB160_18
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_native_target_pair ; -- Begin function nvm_record_map_native_target_pair
	.globl	_nvm_record_map_native_target_pair
	.p2align	2
_nvm_record_map_native_target_pair:     ; @nvm_record_map_native_target_pair
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #480
	stp	x28, x27, [sp, #384]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #400]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #416]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #432]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #448]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #464]            ; 16-byte Folded Spill
	add	x29, sp, #464
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	xzr, [x8, #208]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	cmp	x1, #63
	b.hi	LBB161_2
LBB161_1:
	mov	w9, #3                          ; =0x3
	str	w9, [x8]
	b	LBB161_26
LBB161_2:
	mov	w9, #64                         ; =0x40
	str	x9, [x8, #208]
	cbz	x0, LBB161_25
; %bb.3:
	ldr	x19, [x0]
	ldr	x21, [x19]
	cbz	x21, LBB161_25
; %bb.4:
	ldr	x9, [x19, #8]
	cbz	x9, LBB161_25
; %bb.5:
	ldr	w20, [x21, #504]
	ldr	w9, [x21, #488]
	ldr	w10, [x21, #272]
	cmp	w9, w10
	ccmp	w20, w10, #2, eq
	b.hs	LBB161_25
; %bb.6:
	ldr	w26, [x21, #528]
	ldr	w10, [x21, #468]
	cmp	w26, w10
	b.ne	LBB161_25
; %bb.7:
	ldr	x10, [x21, #256]
	cbz	x10, LBB161_25
; %bb.8:
	cmp	w9, #256
	stp	x2, x8, [sp, #104]              ; 16-byte Folded Spill
	stp	x0, x1, [sp, #88]               ; 16-byte Folded Spill
	b.hi	LBB161_10
; %bb.9:
	ldr	w8, [x21, #432]
	cbz	w8, LBB161_27
LBB161_10:
Lloh86:
	adrp	x24, l_.str.17@PAGE
Lloh87:
	add	x24, x24, l_.str.17@PAGEOFF
	mov	x22, x24
LBB161_11:
	ldr	w25, [x21, #492]
	ldr	w23, [x21, #500]
	sturb	wzr, [x29, #-97]
	sub	x1, x29, #97
	mov	x0, x19
	bl	_nvm_record_map_execution_uniform_pair
	ldp	x10, x8, [sp, #104]             ; 16-byte Folded Reload
	cbz	w0, LBB161_26
; %bb.12:
	ldr	x9, [x21, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x11, w20, w11, x9
	ldrh	w12, [x11, #4]
	cbnz	w12, LBB161_16
; %bb.13:
	ldrh	w12, [x11, #18]
	cbnz	w12, LBB161_16
; %bb.14:
	ldrb	w12, [x11, #21]
	cmp	w12, #1
	b.ne	LBB161_16
; %bb.15:
	ldrb	w11, [x11, #20]
	cmp	w11, #1
	b.eq	LBB161_17
LBB161_16:
	mov	x22, x24
LBB161_17:
	cmn	w23, #1
	b.eq	LBB161_28
; %bb.18:
	ldr	w11, [x21, #272]
	cmp	w23, w11
	b.hs	LBB161_26
; %bb.19:
	mov	w11, #24                        ; =0x18
	umaddl	x11, w23, w11, x9
	ldrh	w12, [x11, #4]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	cbnz	w12, LBB161_24
; %bb.20:
	ldrh	w12, [x11, #18]
	cbnz	w12, LBB161_24
; %bb.21:
	ldrb	w12, [x11, #21]
	cmp	w12, #1
	b.hi	LBB161_24
; %bb.22:
	cbz	w12, LBB161_29
; %bb.23:
	ldrb	w11, [x11, #20]
	cmp	w11, #1
	b.eq	LBB161_29
LBB161_24:
Lloh88:
	adrp	x11, l_.str.19@PAGE
Lloh89:
	add	x11, x11, l_.str.19@PAGEOFF
	cmp	x22, #0
	csel	x22, x11, x22, eq
	b	LBB161_29
LBB161_25:
Lloh90:
	adrp	x9, l_.str.17@PAGE
Lloh91:
	add	x9, x9, l_.str.17@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	stur	q1, [x8, #28]
	ldur	q0, [x9, #29]
	stur	q0, [x8, #41]
LBB161_26:
	ldp	x29, x30, [sp, #464]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #448]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #432]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #416]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #400]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #480
	ret
LBB161_27:
	mov	x22, #0                         ; =0x0
Lloh92:
	adrp	x24, l_.str.18@PAGE
Lloh93:
	add	x24, x24, l_.str.18@PAGEOFF
	b	LBB161_11
LBB161_28:
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
LBB161_29:
	cbz	w26, LBB161_41
; %bb.30:
	str	x25, [sp, #56]                  ; 8-byte Folded Spill
	mov	w25, #0                         ; =0x0
	sub	w10, w26, #1
	ubfiz	x10, x10, #5, #32
	add	x10, x10, #96
	str	x10, [sp, #80]                  ; 8-byte Folded Spill
	sub	x28, x9, #64
	mov	w24, #64                        ; =0x40
	mov	w23, #10288                     ; =0x2830
LBB161_31:                              ; =>This Inner Loop Header: Depth=1
	cmp	x24, x9
	b.hi	LBB161_134
; %bb.32:                               ;   in Loop: Header=BB161_31 Depth=1
	cmp	x28, #31
	b.ls	LBB161_134
; %bb.33:                               ;   in Loop: Header=BB161_31 Depth=1
	ldr	x9, [x19]
	cbz	x9, LBB161_40
; %bb.34:                               ;   in Loop: Header=BB161_31 Depth=1
	ldr	w10, [x9, #528]
	cmp	w25, w10
	b.hs	LBB161_40
; %bb.35:                               ;   in Loop: Header=BB161_31 Depth=1
	add	x9, x9, x23
	ldur	w10, [x9, #-8]
	cmp	w25, w10
	b.ne	LBB161_40
; %bb.36:                               ;   in Loop: Header=BB161_31 Depth=1
	ldr	x10, [x19, #8]
	ldr	x10, [x10]
	cbz	x10, LBB161_40
; %bb.37:                               ;   in Loop: Header=BB161_31 Depth=1
	ldur	w20, [x9, #-4]
	ldrh	w27, [x9]
	ldr	x0, [x10]
	add	x2, sp, #208
	mov	x1, x20
	bl	_nvm_ownership_declarations_layout
	ldp	x9, x10, [sp, #96]              ; 16-byte Folded Reload
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	ldrb	w11, [sp, #208]
	ldrh	w12, [sp, #210]
	cmp	w0, #0
	ccmp	w11, #0, #0, ne
	ccmp	w12, w27, #0, eq
	b.ne	LBB161_40
; %bb.38:                               ;   in Loop: Header=BB161_31 Depth=1
	cmp	x22, #0
Lloh94:
	adrp	x11, l_.str.20@PAGE
Lloh95:
	add	x11, x11, l_.str.20@PAGEOFF
	csel	x11, x11, x22, eq
	cmp	w25, w20
	csel	x22, x22, x11, eq
	add	w25, w25, #1
	add	x23, x23, #12
	sub	x28, x28, #32
	add	x24, x24, #32
	cmp	w26, w25
	b.ne	LBB161_31
; %bb.39:
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #80]                  ; 8-byte Folded Reload
	b	LBB161_42
LBB161_40:
	add	x9, x24, #32
	str	x9, [x8, #208]
	strb	wzr, [x8, #76]
Lloh96:
	adrp	x9, l_.str.20@PAGE
Lloh97:
	add	x9, x9, l_.str.20@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	stur	q1, [x8, #28]
	ldp	q0, q1, [x9, #32]
	stur	q0, [x8, #44]
	stur	q1, [x8, #60]
	b	LBB161_26
LBB161_41:
	mov	w24, #64                        ; =0x40
LBB161_42:
	str	x24, [x8, #208]
	ldr	w11, [x21, #272]
	cbz	w11, LBB161_129
; %bb.43:
	mov	x28, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	add	x12, sp, #208
	add	x13, x12, #34
	add	x12, x12, #40
	stp	x12, x13, [sp, #72]             ; 16-byte Folded Spill
	ldurb	w13, [x29, #-97]
	mov	w12, #1                         ; =0x1
	str	x13, [sp, #16]                  ; 8-byte Folded Spill
	lsl	w12, w12, w13
	str	w12, [sp, #36]                  ; 4-byte Folded Spill
	and	w12, w12, #0xfffe
	orr	w12, w12, #0x1
	str	w12, [sp, #28]                  ; 4-byte Folded Spill
	mov	w14, #24                        ; =0x18
LBB161_44:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB161_50 Depth 2
                                        ;       Child Loop BB161_67 Depth 3
	subs	x12, x9, x24
	b.lo	LBB161_134
; %bb.45:                               ;   in Loop: Header=BB161_44 Depth=1
	cmp	x12, #15
	b.ls	LBB161_134
; %bb.46:                               ;   in Loop: Header=BB161_44 Depth=1
	add	x24, x24, #16
	ldr	x12, [x21, #256]
	madd	x13, x27, x14, x12
	ldr	w12, [x13, #12]
	cbz	w12, LBB161_127
; %bb.47:                               ;   in Loop: Header=BB161_44 Depth=1
	ldr	x10, [x21, #280]
	cbz	x10, LBB161_136
; %bb.48:                               ;   in Loop: Header=BB161_44 Depth=1
	ldr	w10, [x13, #8]
	ldr	w11, [x21, #288]
	subs	w10, w11, w10
	ccmp	w12, w10, #2, hs
	b.hi	LBB161_136
; %bb.49:                               ;   in Loop: Header=BB161_44 Depth=1
	mov	w23, #0                         ; =0x0
	str	x13, [sp, #64]                  ; 8-byte Folded Spill
LBB161_50:                              ;   Parent Loop BB161_44 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB161_67 Depth 3
	subs	x9, x9, x24
	b.lo	LBB161_134
; %bb.51:                               ;   in Loop: Header=BB161_50 Depth=2
	cmp	x9, #127
	b.ls	LBB161_134
; %bb.52:                               ;   in Loop: Header=BB161_50 Depth=2
	add	x20, x24, #128
	ldr	x8, [x21, #280]
	ldr	w9, [x13, #8]
	add	x8, x8, x9
	add	x0, x8, w23, uxtw
	sub	w1, w12, w23
	sub	x2, x29, #168
	bl	_isa_decode
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	subs	x8, x8, x20
	b.lo	LBB161_139
; %bb.53:                               ;   in Loop: Header=BB161_50 Depth=2
	mov	w26, w0
	cmp	x8, x26
	b.lo	LBB161_139
; %bb.54:                               ;   in Loop: Header=BB161_50 Depth=2
	add	x24, x20, x26
	cbz	w26, LBB161_135
; %bb.55:                               ;   in Loop: Header=BB161_50 Depth=2
	ldurb	w0, [x29, #-168]
	bl	_isa_get_info
	cbz	x0, LBB161_135
; %bb.56:                               ;   in Loop: Header=BB161_50 Depth=2
	cmp	w26, #32
	b.hi	LBB161_135
; %bb.57:                               ;   in Loop: Header=BB161_50 Depth=2
	mov	x20, x0
	ldrb	w8, [x0, #9]
	cmp	w8, #4
	ccmp	x28, x25, #2, ls
	b.hs	LBB161_135
; %bb.58:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	cbz	x9, LBB161_135
; %bb.59:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	x10, [x9]
	ldr	w10, [x10, #492]
	cmp	x28, x10
	b.hs	LBB161_135
; %bb.60:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	x9, [x9, #16]
	mov	w10, #80                        ; =0x50
	madd	x9, x28, x10, x9
	ldr	q0, [x9]
	str	q0, [sp, #208]
	ldr	q0, [x9, #16]
	str	q0, [sp, #224]
	ldr	q0, [x9, #32]
	str	q0, [sp, #240]
	ldr	q0, [x9, #48]
	add	x10, sp, #208
	str	q0, [x10, #48]
	ldr	q0, [x9, #64]
	str	q0, [x10, #64]
	ldr	w9, [sp, #208]
	cmp	x9, x27
	b.ne	LBB161_135
; %bb.61:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	w9, [sp, #212]
	cmp	w9, w23
	b.ne	LBB161_135
; %bb.62:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	w10, [sp, #216]
	add	w9, w26, w23
	str	w10, [sp, #32]                  ; 4-byte Folded Spill
	cmp	w10, w9
	b.ne	LBB161_135
; %bb.63:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrb	w9, [sp, #238]
	ldurb	w10, [x29, #-168]
	cmp	w9, w10
	b.ne	LBB161_135
; %bb.64:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrb	w9, [sp, #241]
	cmp	w9, w8
	b.ne	LBB161_135
; %bb.65:                               ;   in Loop: Header=BB161_50 Depth=2
	stp	x27, x28, [sp, #40]             ; 16-byte Folded Spill
	str	x25, [sp, #56]                  ; 8-byte Folded Spill
	cbz	w8, LBB161_81
; %bb.66:                               ;   in Loop: Header=BB161_50 Depth=2
	mov	x25, #0                         ; =0x0
	add	x27, x20, #12
	mov	w28, #1                         ; =0x1
LBB161_67:                              ;   Parent Loop BB161_44 Depth=1
                                        ;     Parent Loop BB161_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w0, [x27, x25, lsl #2]
	bl	_isa_operand_size
	sub	w8, w26, w28
	cmp	w0, #8
	ccmp	w28, w26, #2, ls
	ccmp	w0, w8, #2, ls
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	b.hi	LBB161_136
; %bb.68:                               ;   in Loop: Header=BB161_67 Depth=3
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, x25]
	lsl	x10, x25, #2
	ldrb	w10, [x27, x10]
	cmp	w9, w10
	b.ne	LBB161_136
; %bb.69:                               ;   in Loop: Header=BB161_67 Depth=3
	cbz	w0, LBB161_78
; %bb.70:                               ;   in Loop: Header=BB161_67 Depth=3
	ldr	x10, [x21, #280]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	add	w11, w28, w23
	add	w11, w11, w9
	ldrb	w9, [x10, w11, uxtw]
	cmp	w0, #1
	b.eq	LBB161_79
; %bb.71:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #1
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #8
	cmp	w0, #2
	b.eq	LBB161_79
; %bb.72:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #2
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #16
	cmp	w0, #3
	b.eq	LBB161_79
; %bb.73:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #3
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #24
	cmp	w0, #4
	b.eq	LBB161_79
; %bb.74:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #4
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #32
	cmp	w0, #5
	b.eq	LBB161_79
; %bb.75:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #5
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #40
	cmp	w0, #6
	b.eq	LBB161_79
; %bb.76:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w12, w11, #6
	ldrb	w12, [x10, w12, uxtw]
	orr	x9, x9, x12, lsl #48
	cmp	w0, #7
	b.eq	LBB161_79
; %bb.77:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w11, w11, #7
	ldrb	w10, [x10, w11, uxtw]
	orr	x9, x9, x10, lsl #56
	b	LBB161_79
LBB161_78:                              ;   in Loop: Header=BB161_67 Depth=3
	mov	x9, #0                          ; =0x0
LBB161_79:                              ;   in Loop: Header=BB161_67 Depth=3
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x10, [x10, x25, lsl #3]
	cmp	x9, x10
	b.ne	LBB161_136
; %bb.80:                               ;   in Loop: Header=BB161_67 Depth=3
	add	w28, w0, w28
	add	x25, x25, #1
	ldrb	w8, [x20, #9]
	cmp	x25, x8
	b.lo	LBB161_67
	b	LBB161_82
LBB161_81:                              ;   in Loop: Header=BB161_50 Depth=2
	mov	w28, #1                         ; =0x1
LBB161_82:                              ;   in Loop: Header=BB161_50 Depth=2
	cmp	w28, w26
	ldp	x28, x25, [sp, #48]             ; 16-byte Folded Reload
	ldr	x27, [sp, #40]                  ; 8-byte Folded Reload
	b.ne	LBB161_135
; %bb.83:                               ;   in Loop: Header=BB161_50 Depth=2
	str	xzr, [sp, #192]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	ldurb	w20, [x29, #-168]
	add	x1, sp, #128
	mov	x0, x20
	bl	_rme_recipe
	ldp	x10, x8, [sp, #104]             ; 16-byte Folded Reload
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	cbz	w0, LBB161_136
; %bb.84:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrb	w11, [sp, #239]
	ldrb	w12, [sp, #159]
	cmp	w12, w11, uxtb
	b.ne	LBB161_136
; %bb.85:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrh	w12, [sp, #236]
	ldrh	w13, [sp, #156]
	cmp	w12, w13
	b.ne	LBB161_136
; %bb.86:                               ;   in Loop: Header=BB161_50 Depth=2
	cmp	w20, #65
	b.eq	LBB161_88
; %bb.87:                               ;   in Loop: Header=BB161_50 Depth=2
	and	w12, w11, #0xff
	cmp	w12, #10
	b.eq	LBB161_90
LBB161_88:                              ;   in Loop: Header=BB161_50 Depth=2
	sub	w12, w20, #96
	cmp	w12, #4
	b.lo	LBB161_90
; %bb.89:                               ;   in Loop: Header=BB161_50 Depth=2
	cmp	w20, #139
	b.ne	LBB161_91
LBB161_90:                              ;   in Loop: Header=BB161_50 Depth=2
	cmp	x22, #0
Lloh98:
	adrp	x12, l_.str.21@PAGE
Lloh99:
	add	x12, x12, l_.str.21@PAGEOFF
	csel	x22, x12, x22, eq
LBB161_91:                              ;   in Loop: Header=BB161_50 Depth=2
	sxtb	w12, w20
	sub	w13, w20, #120
	cmp	w12, #119
	cset	w12, gt
	mov	w14, #143                       ; =0x8f
	lsr	w14, w14, w13
	and	x13, x13, #0xff
	cmp	w20, #124
	mov	w15, #6                         ; =0x6
	csel	w15, w15, wzr, eq
	lsl	x13, x13, #3
	mov	x16, #769                       ; =0x301
	movk	x16, #1026, lsl #16
	movk	x16, #1280, lsl #48
	lsr	x13, x16, x13
	tst	w12, w14
	csel	w13, w13, w15, ne
	and	w12, w13, #0x7
	ldrb	w14, [sp, #286]
	cmp	w14, w12
	b.ne	LBB161_136
; %bb.92:                               ;   in Loop: Header=BB161_50 Depth=2
	ands	w14, w13, #0xff
	b.eq	LBB161_101
; %bb.93:                               ;   in Loop: Header=BB161_50 Depth=2
	cmp	w14, #4
	b.eq	LBB161_96
; %bb.94:                               ;   in Loop: Header=BB161_50 Depth=2
	ldr	w12, [sp, #28]                  ; 4-byte Folded Reload
	cmp	w14, #3
	b.eq	LBB161_97
; %bb.95:                               ;   in Loop: Header=BB161_50 Depth=2
	and	w12, w13, #0xff
	cmp	w12, #5
	mov	w12, #8192                      ; =0x2000
	mov	w13, #2                         ; =0x2
	csel	w12, w13, w12, eq
	b	LBB161_97
LBB161_96:                              ;   in Loop: Header=BB161_50 Depth=2
	mov	w12, #16                        ; =0x10
LBB161_97:                              ;   in Loop: Header=BB161_50 Depth=2
	mov	w13, #255                       ; =0xff
	bics	wzr, w13, w11
	b.ne	LBB161_136
; %bb.98:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrh	w11, [sp, #280]
	cmp	w11, #32
	b.ne	LBB161_136
; %bb.99:                               ;   in Loop: Header=BB161_50 Depth=2
	ldrh	w11, [sp, #282]
	ldr	w13, [sp, #36]                  ; 4-byte Folded Reload
	cmp	w13, w11
	b.ne	LBB161_136
; %bb.100:                              ;   in Loop: Header=BB161_50 Depth=2
	ldrh	w11, [sp, #284]
	cmp	w12, w11
	b.eq	LBB161_102
	b	LBB161_136
LBB161_101:                             ;   in Loop: Header=BB161_50 Depth=2
	and	w11, w11, #0xff
	cmp	w11, #17
	b.hi	LBB161_136
LBB161_102:                             ;   in Loop: Header=BB161_50 Depth=2
	cmp	w20, #4
	b.eq	LBB161_117
; %bb.103:                              ;   in Loop: Header=BB161_50 Depth=2
	cmp	w20, #251
	b.eq	LBB161_107
; %bb.104:                              ;   in Loop: Header=BB161_50 Depth=2
	cmp	w20, #120
	b.ne	LBB161_125
; %bb.105:                              ;   in Loop: Header=BB161_50 Depth=2
	ldurb	w11, [x29, #-160]
	cmp	w11, #5
	b.ne	LBB161_136
; %bb.106:                              ;   in Loop: Header=BB161_50 Depth=2
	ldurb	w11, [x29, #-152]
	ldr	x12, [sp, #16]                  ; 8-byte Folded Reload
	cmp	w11, w12
	b.eq	LBB161_125
	b	LBB161_136
LBB161_107:                             ;   in Loop: Header=BB161_50 Depth=2
	ldurb	w8, [x29, #-160]
	cbnz	w8, LBB161_135
; %bb.108:                              ;   in Loop: Header=BB161_50 Depth=2
	ldurh	w8, [x29, #-144]
	cbnz	w8, LBB161_135
; %bb.109:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	x8, [x19]
	cbz	x8, LBB161_135
; %bb.110:                              ;   in Loop: Header=BB161_50 Depth=2
	ldur	w9, [x29, #-152]
	ldr	w10, [x8, #528]
	cmp	w9, w10
	b.hs	LBB161_135
; %bb.111:                              ;   in Loop: Header=BB161_50 Depth=2
	mov	w10, #12                        ; =0xc
	umaddl	x8, w9, w10, x8
	ldr	w10, [x8, #10280]
	cmp	w10, w9
	b.ne	LBB161_135
; %bb.112:                              ;   in Loop: Header=BB161_50 Depth=2
	mov	w9, #10280                      ; =0x2828
	add	x9, x8, x9
	ldrh	w20, [x9, #8]
	ldurh	w9, [x29, #-136]
	cmp	w20, w9
	b.ne	LBB161_135
; %bb.113:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	x9, [x19, #8]
	ldr	x9, [x9]
	cbz	x9, LBB161_135
; %bb.114:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	w1, [x8, #10284]
	ldr	x0, [x9]
	add	x2, sp, #120
	bl	_nvm_ownership_declarations_layout
	cbz	w0, LBB161_135
; %bb.115:                              ;   in Loop: Header=BB161_50 Depth=2
	ldrb	w8, [sp, #120]
	cbnz	w8, LBB161_135
; %bb.116:                              ;   in Loop: Header=BB161_50 Depth=2
	ldrh	w8, [sp, #122]
	cmp	w8, w20
	b.eq	LBB161_124
	b	LBB161_135
LBB161_117:                             ;   in Loop: Header=BB161_50 Depth=2
	ldur	w10, [x29, #-160]
	ldr	w11, [x21, #248]
	cmp	w10, w11
	b.hs	LBB161_140
; %bb.118:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	x12, [x21, #232]
	cbz	x12, LBB161_140
; %bb.119:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	x11, [x21, #240]
	cbz	x11, LBB161_140
; %bb.120:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	x0, [x12, x10, lsl #3]
	cbz	x0, LBB161_140
; %bb.121:                              ;   in Loop: Header=BB161_50 Depth=2
	subs	x8, x9, x24
	b.lo	LBB161_141
; %bb.122:                              ;   in Loop: Header=BB161_50 Depth=2
	ldr	w2, [x11, x10, lsl #2]
	cmp	x8, x2
	b.lo	LBB161_141
; %bb.123:                              ;   in Loop: Header=BB161_50 Depth=2
	add	x24, x24, x2
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cmp	x22, #0
Lloh100:
	adrp	x8, l_.str.22@PAGE
Lloh101:
	add	x8, x8, l_.str.22@PAGEOFF
	csel	x8, x8, x22, eq
	cmp	x0, #0
	csel	x22, x22, x8, eq
LBB161_124:                             ;   in Loop: Header=BB161_50 Depth=2
	ldp	x10, x8, [sp, #104]             ; 16-byte Folded Reload
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
LBB161_125:                             ;   in Loop: Header=BB161_50 Depth=2
	ldr	w11, [sp, #32]                  ; 4-byte Folded Reload
	add	x28, x28, #1
	ldr	x13, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w12, [x13, #12]
	mov	x23, x11
	cmp	w11, w12
	mov	w14, #24                        ; =0x18
	b.lo	LBB161_50
; %bb.126:                              ;   in Loop: Header=BB161_44 Depth=1
	ldr	w11, [x21, #272]
	b	LBB161_128
LBB161_127:                             ;   in Loop: Header=BB161_44 Depth=1
	ldr	w12, [x13, #8]
	ldr	w13, [x21, #288]
	cmp	w12, w13
	b.hi	LBB161_136
LBB161_128:                             ;   in Loop: Header=BB161_44 Depth=1
	add	x27, x27, #1
	cmp	x27, x11
	b.lo	LBB161_44
	b	LBB161_130
LBB161_129:
	mov	x28, #0                         ; =0x0
LBB161_130:
	str	x24, [x8, #208]
	cmp	x28, x25
	b.ne	LBB161_26
; %bb.131:
	cmp	x22, #0
	cset	w9, ne
	str	w9, [x8]
	cbz	x10, LBB161_137
; %bb.132:
	cbnz	x22, LBB161_137
; %bb.133:
	ldurb	w8, [x29, #-97]
	strb	w8, [x10]
	b	LBB161_26
LBB161_134:
	str	x24, [x8, #208]
	b	LBB161_1
LBB161_135:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
LBB161_136:
	str	x24, [x8, #208]
	b	LBB161_26
LBB161_137:
	cbz	x22, LBB161_26
; %bb.138:
	str	x22, [sp]
Lloh102:
	adrp	x2, l_.str.2@PAGE
Lloh103:
	add	x2, x2, l_.str.2@PAGEOFF
	add	x0, x8, #12
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB161_26
LBB161_139:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	str	x20, [x8, #208]
	b	LBB161_1
LBB161_140:
	str	x24, [x8, #208]
Lloh104:
	adrp	x9, l_.str.22@PAGE
Lloh105:
	add	x9, x9, l_.str.22@PAGEOFF
	ldp	q0, q1, [x9]
	stur	q0, [x8, #12]
	stur	q1, [x8, #28]
	ldr	q0, [x9, #32]
	stur	q0, [x8, #44]
	ldur	q0, [x9, #42]
	stur	q0, [x8, #54]
	b	LBB161_26
LBB161_141:
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	str	x24, [x8, #208]
	b	LBB161_1
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rme_recipe
_rme_recipe:                            ; @rme_recipe
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	sub	w8, w0, #120
	cmp	w8, #5
	b.hs	LBB162_5
LBB162_1:
	mov	w8, #255                        ; =0xff
	strb	w8, [x1, #31]
	and	w8, w0, #0xfffffffd
	mov	w9, #81                         ; =0x51
	mov	w10, #89                        ; =0x59
	cmp	w8, #120
	csel	w8, w10, w9, eq
	strh	w8, [x1, #28]
	sub	w9, w0, #121
	and	w9, w9, #0xff
	cmp	w9, #1
	b.hi	LBB162_3
; %bb.2:
	orr	w8, w8, #0x20
	strh	w8, [x1, #28]
LBB162_3:
	mov	w0, #1                          ; =0x1
LBB162_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB162_5:
	cmp	w0, #108
	b.eq	LBB162_12
; %bb.6:
	cmp	w0, #127
	b.eq	LBB162_1
; %bb.7:
	mov	x19, x1
	mov	x20, x0
	bl	_supported
	cbnz	w0, LBB162_11
; %bb.8:
	sub	w8, w20, #51
	cmp	w8, #48
	b.hi	LBB162_10
; %bb.9:
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	x9, #527765581332480            ; =0x1e00000000000
	movk	x9, #1
	tst	x8, x9
	b.ne	LBB162_11
LBB162_10:
	sub	w8, w20, #251
	cmp	w8, #3
	b.hs	LBB162_12
LBB162_11:
	mov	x0, x20
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_rae_recipe
LBB162_12:
	mov	w0, #0                          ; =0x0
	b	LBB162_4
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_native_target ; -- Begin function nvm_record_map_native_target
	.globl	_nvm_record_map_native_target
	.p2align	2
_nvm_record_map_native_target:          ; @nvm_record_map_native_target
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	b	_nvm_record_map_native_target_pair
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_record_map_publication ; -- Begin function nvm_record_map_publication
	.globl	_nvm_record_map_publication
	.p2align	2
_nvm_record_map_publication:            ; @nvm_record_map_publication
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
Lloh106:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh107:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh108:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cbz	x0, LBB164_4
; %bb.1:
	mov	x20, x0
	bl	_nvm_record_map_route
	cmp	w0, #1
	b.eq	LBB164_5
; %bb.2:
	cmp	w0, #2
	b.ne	LBB164_7
; %bb.3:
	mov	w8, #2                          ; =0x2
	b	LBB164_8
LBB164_4:
Lloh109:
	adrp	x8, l___const.nvm_record_map_publication.result@PAGE+4
Lloh110:
	add	x8, x8, l___const.nvm_record_map_publication.result@PAGEOFF+4
	ldp	q0, q1, [x8, #128]
	stur	q0, [x19, #132]
	stur	q1, [x19, #148]
	ldp	q0, q1, [x8, #160]
	stur	q0, [x19, #164]
	stur	q1, [x19, #180]
	ldp	q0, q1, [x8, #64]
	stur	q0, [x19, #68]
	stur	q1, [x19, #84]
	ldp	q0, q1, [x8, #96]
	stur	q0, [x19, #100]
	stur	q1, [x19, #116]
	ldp	q0, q1, [x8]
	stur	q0, [x19, #4]
	stur	q1, [x19, #20]
	ldp	q0, q1, [x8, #32]
	stur	q0, [x19, #36]
	mov	w8, #2                          ; =0x2
	b	LBB164_9
LBB164_5:
	add	x21, sp, #240
	add	x22, sp, #24
	stp	xzr, xzr, [sp, #8]
	add	x8, sp, #24
	add	x1, sp, #16
	mov	x0, x20
	bl	_nvm_record_map_admit
	ldr	w8, [sp, #24]
	ldur	q0, [x22, #148]
	ldur	q1, [x22, #164]
	ldur	q2, [x22, #180]
	stp	q1, q2, [x21, #160]
	ldur	x9, [x22, #196]
	str	x9, [sp, #432]
	ldur	q1, [sp, #108]
	ldur	q2, [sp, #124]
	ldur	q3, [x22, #116]
	stp	q2, q3, [x21, #96]
	ldur	q2, [x22, #132]
	stp	q2, q0, [x21, #128]
	ldur	q0, [sp, #44]
	ldur	q2, [sp, #60]
	ldur	q3, [sp, #76]
	stp	q2, q3, [x21, #32]
	ldur	q2, [sp, #92]
	stp	q2, q1, [x21, #64]
	ldur	q1, [sp, #28]
	stp	q1, q0, [x21]
	cbz	w8, LBB164_11
; %bb.6:
	ldp	q1, q0, [x21, #128]
	stur	q0, [x19, #148]
	ldp	q0, q2, [x21, #160]
	stur	q0, [x19, #164]
	stur	q2, [x19, #180]
	ldp	q2, q0, [x21, #64]
	stur	q0, [x19, #84]
	ldp	q0, q3, [x21, #96]
	stur	q0, [x19, #100]
	stur	q3, [x19, #116]
	stur	q1, [x19, #132]
	ldp	q1, q0, [x21]
	stur	q0, [x19, #20]
	ldp	q0, q3, [x21, #32]
	stur	q0, [x19, #36]
	stur	q3, [x19, #52]
	stur	q2, [x19, #68]
	str	w8, [x19]
	b	LBB164_15
LBB164_7:
	mov	w8, #1                          ; =0x1
LBB164_8:
Lloh111:
	adrp	x9, l___const.nvm_record_map_publication.result@PAGE+4
Lloh112:
	add	x9, x9, l___const.nvm_record_map_publication.result@PAGEOFF+4
	ldp	q0, q1, [x9, #128]
	stur	q0, [x19, #132]
	stur	q1, [x19, #148]
	ldp	q0, q1, [x9, #160]
	stur	q0, [x19, #164]
	stur	q1, [x19, #180]
	ldp	q0, q1, [x9, #64]
	stur	q0, [x19, #68]
	stur	q1, [x19, #84]
	ldp	q0, q1, [x9, #96]
	stur	q0, [x19, #100]
	stur	q1, [x19, #116]
	ldp	q0, q1, [x9]
	stur	q0, [x19, #4]
	stur	q1, [x19, #20]
	ldp	q0, q1, [x9, #32]
	stur	q0, [x19, #36]
	cmp	w0, #3
	csel	w8, w0, w8, eq
LBB164_9:
	str	w8, [x19]
	stur	xzr, [x19, #196]
	stur	q1, [x19, #52]
Lloh113:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh114:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh115:
	ldr	x8, [x8]
	ldur	x9, [x29, #-56]
	cmp	x8, x9
	b.ne	LBB164_17
LBB164_10:
	add	sp, sp, #448
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB164_11:
	ldr	x20, [sp, #16]
	add	x8, sp, #24
	add	x1, sp, #8
	mov	x0, x20
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_rme_image_copy_reserved
	ldr	w23, [sp, #24]
	ldur	q0, [x22, #148]
	ldur	q1, [x22, #164]
	ldur	q2, [x22, #180]
	stp	q1, q2, [x21, #160]
	ldur	x8, [x22, #196]
	str	x8, [sp, #432]
	ldur	q1, [sp, #108]
	ldur	q2, [sp, #124]
	ldur	q3, [x22, #116]
	stp	q2, q3, [x21, #96]
	ldur	q2, [x22, #132]
	stp	q2, q0, [x21, #128]
	ldur	q0, [sp, #44]
	ldur	q2, [sp, #60]
	ldur	q3, [sp, #76]
	stp	q2, q3, [x21, #32]
	ldur	q2, [sp, #92]
	stp	q2, q1, [x21, #64]
	ldur	q1, [sp, #28]
	stp	q1, q0, [x21]
	cbz	x20, LBB164_13
; %bb.12:
	ldr	x0, [x20]
	bl	_nvm_record_array_execution_free
	ldr	x0, [x20, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x20, #16]
	bl	_free
	mov	x0, x20
	bl	_free
LBB164_13:
	cbz	w23, LBB164_18
; %bb.14:
	ldp	q1, q0, [x21, #128]
	stur	q0, [x19, #148]
	ldp	q0, q2, [x21, #160]
	stur	q0, [x19, #164]
	stur	q2, [x19, #180]
	ldp	q2, q0, [x21, #64]
	stur	q0, [x19, #84]
	ldp	q0, q3, [x21, #96]
	stur	q0, [x19, #100]
	stur	q3, [x19, #116]
	stur	q1, [x19, #132]
	ldp	q1, q0, [x21]
	stur	q0, [x19, #20]
	ldp	q0, q3, [x21, #32]
	stur	q0, [x19, #36]
	stur	q3, [x19, #52]
	stur	q2, [x19, #68]
	str	w23, [x19]
LBB164_15:
	ldr	x8, [sp, #432]
	stur	x8, [x19, #196]
	stur	q1, [x19, #4]
LBB164_16:
	ldur	x8, [x29, #-56]
Lloh116:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh117:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh118:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB164_10
LBB164_17:
	bl	___stack_chk_fail
LBB164_18:
	ldr	x20, [sp, #8]
	add	x8, sp, #24
	mov	x0, x20
	mov	w1, #33554432                   ; =0x2000000
	mov	x2, #0                          ; =0x0
	bl	_nvm_record_map_native_target_pair
	cbz	x20, LBB164_22
; %bb.19:
	ldr	x21, [x20]
	cbz	x21, LBB164_21
; %bb.20:
	ldr	x0, [x21]
	bl	_nvm_record_array_execution_free
	ldr	x0, [x21, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x21, #16]
	bl	_free
	mov	x0, x21
	bl	_free
LBB164_21:
	mov	x0, x20
	bl	_free
LBB164_22:
	ldur	q0, [sp, #184]
	ldur	q1, [sp, #200]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x22, #188]
	stur	q0, [x19, #188]
	ldur	q0, [sp, #120]
	ldur	q1, [sp, #136]
	stp	q0, q1, [x19, #96]
	ldur	q0, [sp, #168]
	ldur	q1, [sp, #152]
	stp	q1, q0, [x19, #128]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [x19, #32]
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #88]
	stp	q1, q0, [x19, #64]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #24]
	stp	q1, q0, [x19]
	b	LBB164_16
	.loh AdrpLdrGotLdr	Lloh106, Lloh107, Lloh108
	.loh AdrpAdd	Lloh109, Lloh110
	.loh AdrpAdd	Lloh111, Lloh112
	.loh AdrpLdrGotLdr	Lloh113, Lloh114, Lloh115
	.loh AdrpLdrGotLdr	Lloh116, Lloh117, Lloh118
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fixed_result
_fixed_result:                          ; @fixed_result
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #1
	cmp	w8, #225
	b.hi	LBB165_8
; %bb.1:
	mov	w0, #1                          ; =0x1
Lloh119:
	adrp	x9, lJTI165_0@PAGE
Lloh120:
	add	x9, x9, lJTI165_0@PAGEOFF
	adr	x10, LBB165_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB165_2:
	mov	w0, #4                          ; =0x4
	ret
LBB165_3:
	mov	w0, #5                          ; =0x5
	ret
LBB165_4:
	mov	w0, #3                          ; =0x3
	ret
LBB165_5:
	mov	w0, #2                          ; =0x2
	ret
LBB165_6:
	mov	w0, #9                          ; =0x9
	ret
LBB165_7:
	mov	w0, #0                          ; =0x0
	ret
LBB165_8:
	mov	w0, #-1                         ; =0xffffffff
LBB165_9:
	ret
	.loh AdrpAdd	Lloh119, Lloh120
	.cfi_endproc
	.section	__TEXT,__const
lJTI165_0:
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_7-LBB165_2)>>2
	.byte	(LBB165_5-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_6-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_3-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_5-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_9-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_4-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_8-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
	.byte	(LBB165_2-LBB165_2)>>2
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function analyze_context_sites
lCPI166_0:
	.quad	0                               ; 0x0
	.quad	32                              ; 0x20
lCPI166_1:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI166_2:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI166_3:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_analyze_context_sites:                 ; @analyze_context_sites
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #4704                       ; =0x1260
Lloh121:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh122:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #608
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh123:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh124:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh125:
	ldr	x9, [x9]
	stur	x9, [x29, #-104]
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #368
	stur	wzr, [x21, #207]
Lloh126:
	adrp	x9, l___const.analyze_context_sites.early@PAGE+4
Lloh127:
	add	x9, x9, l___const.analyze_context_sites.early@PAGEOFF+4
	ldp	q0, q1, [x9]
	stp	q0, q1, [x21, #160]
	ldr	q2, [x9, #32]
	add	x22, sp, #368
	str	q2, [x21, #192]
	movi.2d	v3, #0000000000000000
	str	q3, [x22, #4096]
	str	q3, [x22, #4112]
	str	q3, [x22, #4128]
	str	q3, [x22, #4144]
	str	q3, [x22, #4160]
	str	q3, [x22, #4176]
	str	q3, [x22, #4192]
	str	q3, [x22, #4208]
	str	q3, [x22, #4224]
	stur	xzr, [x21, #141]
	cbz	x0, LBB166_5
; %bb.1:
	ldr	x23, [x29, #32]
	ldr	x20, [x29, #16]
	orr	x9, x1, x2
	orr	x10, x3, x4
	orr	x9, x9, x10
	orr	x10, x9, x7
	cmp	x10, #0
	cset	w9, ne
	orr	x10, x10, x23
	cmp	x10, #0
	cset	w10, ne
	cmp	x20, #0
	ccmp	x7, #0, #0, ne
	b.eq	LBB166_5
; %bb.2:
	cbz	w10, LBB166_5
; %bb.3:
	ldr	x28, [x29, #40]
	ldr	x25, [x29, #24]
	cbz	x23, LBB166_7
; %bb.4:
	cmp	x5, #0
	ccmp	w6, #0, #0, eq
	ccmp	x20, #0, #0, eq
	ccmp	x25, #0, #0, eq
	csinc	w9, w9, wzr, eq
	cmp	w9, #1
	b.ne	LBB166_8
LBB166_5:
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	stur	wzr, [x8, #51]
	stur	q0, [x8, #4]
	stur	q1, [x8, #20]
	stur	q2, [x8, #36]
	stur	q3, [x8, #55]
	stur	q3, [x8, #71]
	stur	q3, [x8, #87]
	stur	q3, [x8, #103]
	stur	q3, [x8, #119]
	stur	q3, [x8, #135]
	stur	q3, [x8, #151]
	stur	q3, [x8, #167]
	stur	q3, [x8, #183]
	stur	xzr, [x8, #196]
Lloh128:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh129:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh130:
	ldr	x8, [x8]
	ldur	x9, [x29, #-104]
	cmp	x8, x9
	b.ne	LBB166_105
LBB166_6:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #608
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB166_7:
	cbnz	x28, LBB166_11
	b	LBB166_12
LBB166_8:
	cbz	x28, LBB166_12
; %bb.9:
	sub	x9, x28, x23
	cmp	x9, #7
	cset	w9, hi
	subs	x10, x23, x28
	cmp	x10, #15
	cset	w10, hi
	cmp	x23, x28
	csel	w9, w10, w9, hi
	tbz	w9, #0, LBB166_11
; %bb.10:
	mov	w26, #0                         ; =0x0
	b	LBB166_13
LBB166_11:
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	stur	wzr, [x8, #51]
	stur	q0, [x8, #4]
	stur	q1, [x8, #20]
	stur	q2, [x8, #36]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #55]
	stur	q0, [x8, #71]
	stur	q0, [x8, #87]
	stur	q0, [x8, #103]
	stur	q0, [x8, #119]
	stur	q0, [x8, #135]
	stur	q0, [x8, #151]
	stur	q0, [x8, #167]
	stur	q0, [x8, #183]
	stur	xzr, [x8, #196]
	b	LBB166_104
LBB166_12:
	mov	w26, #1                         ; =0x1
LBB166_13:
	stp	xzr, xzr, [sp, #352]
	str	xzr, [sp, #344]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #304]
	stp	xzr, xzr, [sp, #288]
	str	xzr, [sp, #280]
	stp	x7, x2, [sp, #240]              ; 16-byte Folded Spill
	str	x3, [sp, #256]                  ; 8-byte Folded Spill
	str	w6, [sp, #264]                  ; 4-byte Folded Spill
	cbnz	x4, LBB166_25
; %bb.14:
	cbnz	x7, LBB166_25
; %bb.15:
	cbnz	x23, LBB166_25
LBB166_16:
	stp	x1, x5, [sp, #192]              ; 16-byte Folded Spill
	str	x4, [sp, #216]                  ; 8-byte Folded Spill
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
	mov	x27, x0
	mov	w24, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #39840                      ; =0x9ba0
	bl	_calloc
	cbz	x0, LBB166_28
; %bb.17:
	mov	x19, x0
	str	w26, [sp, #228]                 ; 4-byte Folded Spill
	mov	w8, #35856                      ; =0x8c10
	add	x21, x0, x8
	mov	w8, #30824                      ; =0x7868
	add	x26, x0, x8
	strb	w24, [sp, #279]
	str	x27, [x0]
	ldr	x24, [sp, #296]
	str	x24, [x21, #1744]
	add	x11, x21, #1752
	ldp	q0, q1, [sp, #304]
	stp	q0, q1, [x11]
	ldr	w10, [sp, #264]                 ; 4-byte Folded Reload
	str	w10, [x21, #8]
	ldp	x9, x12, [sp, #248]             ; 16-byte Folded Reload
	cbz	x23, LBB166_31
; %bb.18:
	cbz	x24, LBB166_32
; %bb.19:
	ldrb	w8, [x21, #1776]
	tbnz	w8, #0, LBB166_21
; %bb.20:
	ldrb	w8, [x21, #1777]
	tbz	w8, #0, LBB166_72
LBB166_21:
	mov	x22, #0                         ; =0x0
LBB166_22:
Lloh131:
	adrp	x8, l_.str.24@PAGE
Lloh132:
	add	x8, x8, l_.str.24@PAGEOFF
LBB166_23:
	ldrb	w9, [x21, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	cinc	w9, w9, eq
LBB166_24:
	add	x20, x21, #1532
	str	w9, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w9, #37400                      ; =0x9218
	mov	w10, #191                       ; =0xbf
	stp	x10, x8, [sp]
Lloh133:
	adrp	x2, l_.str.52@PAGE
Lloh134:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x9
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x25, #0                         ; =0x0
	ldp	q0, q1, [x20, #160]
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	stp	q0, q1, [x8, #160]
	ldur	q0, [x20, #188]
	stur	q0, [x8, #188]
	ldp	q0, q1, [x20, #96]
	stp	q0, q1, [x8, #96]
	ldp	q1, q0, [x20, #128]
	stp	q1, q0, [x8, #128]
	ldp	q0, q1, [x20, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x20, #64]
	stp	q1, q0, [x8, #64]
	ldp	q1, q0, [x20]
	stp	q1, q0, [x8]
	b	LBB166_95
LBB166_25:
	str	w26, [sp, #228]                 ; 4-byte Folded Spill
	str	x25, [sp, #208]                 ; 8-byte Folded Spill
	mov	x27, x4
	mov	x19, x1
	mov	x25, x5
	mov	x26, x8
	add	x8, sp, #368
	add	x1, sp, #304
	cbz	x23, LBB166_29
; %bb.26:
	add	x2, sp, #280
	mov	x24, x0
	bl	_nvm_record_union_structure_prepare
	mov	x8, x26
	ldr	w9, [sp, #368]
	add	x10, sp, #117
	ldur	q0, [x10, #255]
	add	x10, sp, #133
	ldur	q1, [x10, #255]
	stp	q0, q1, [x21, #160]
	add	x10, sp, #149
	ldur	q0, [x10, #255]
	str	q0, [x21, #192]
	ldur	w10, [x22, #51]
	stur	w10, [x21, #207]
	ldur	q0, [x22, #151]
	ldur	q1, [x22, #167]
	stp	q0, q1, [x21, #96]
	ldur	q0, [x22, #183]
	str	q0, [x21, #128]
	ldur	x10, [x22, #196]
	stur	x10, [x21, #141]
	ldur	q0, [x22, #87]
	ldur	q1, [x22, #103]
	stp	q0, q1, [x21, #32]
	ldur	q0, [x22, #119]
	ldur	q1, [x22, #135]
	stp	q0, q1, [x21, #64]
	ldur	q0, [x22, #55]
	ldur	q1, [x22, #71]
	stp	q0, q1, [x21]
	cbnz	w9, LBB166_40
; %bb.27:
	ldr	x9, [sp, #280]
	ldr	x10, [x9]
	str	x10, [sp, #296]
	str	xzr, [x9]
	b	LBB166_41
LBB166_28:
	ldr	x0, [sp, #280]
	bl	_nvm_record_union_structure_free
	ldr	x0, [sp, #288]
	bl	_nvm_map_declarations_free
	ldr	x0, [sp, #296]
	bl	_nvm_record_array_structure_free
Lloh135:
	adrp	x8, l_.str.23@PAGE
Lloh136:
	add	x8, x8, l_.str.23@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x21, #168]
	stur	q1, [x21, #184]
	ldur	q0, [x8, #27]
	stur	q0, [x21, #195]
	mov	w8, #4                          ; =0x4
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	str	w8, [x9]
	ldp	q0, q1, [x21, #160]
	stur	q0, [x9, #4]
	stur	q1, [x9, #20]
	ldr	q0, [x21, #192]
	stur	q0, [x9, #36]
	ldur	w8, [x21, #207]
	stur	w8, [x9, #51]
	ldp	q0, q1, [x21]
	stur	q1, [x9, #71]
	stur	q0, [x9, #55]
	ldp	q0, q1, [x21, #32]
	ldp	q2, q3, [x21, #64]
	stur	q3, [x9, #135]
	stur	q2, [x9, #119]
	stur	q1, [x9, #103]
	stur	q0, [x9, #87]
	ldp	q0, q1, [x21, #96]
	ldr	q2, [x21, #128]
	ldur	x8, [x21, #141]
	stur	x8, [x9, #196]
	stur	q2, [x9, #183]
	stur	q1, [x9, #167]
	stur	q0, [x9, #151]
	b	LBB166_104
LBB166_29:
	add	x2, sp, #296
	cbz	x7, LBB166_38
; %bb.30:
	add	x3, sp, #288
	mov	x24, x0
	bl	_nvm_record_map_structure_prepare
	b	LBB166_39
LBB166_31:
	mov	x8, x27
	str	xzr, [sp, #184]                 ; 8-byte Folded Spill
	ldr	x11, [sp, #240]                 ; 8-byte Folded Reload
	ldr	x13, [sp, #216]                 ; 8-byte Folded Reload
	b	LBB166_34
LBB166_32:
	mov	w0, #1                          ; =0x1
	mov	w1, #1096                       ; =0x448
	bl	_calloc
	str	x0, [sp, #184]                  ; 8-byte Folded Spill
	cbz	x0, LBB166_77
LBB166_33:
	ldr	x8, [sp, #280]
	ldr	x9, [x8, #8]
	ldr	x10, [sp, #184]                 ; 8-byte Folded Reload
	str	x9, [x10]
	str	xzr, [x8, #8]
	ldp	x11, x9, [sp, #240]             ; 16-byte Folded Reload
	ldr	x13, [sp, #216]                 ; 8-byte Folded Reload
	ldr	x12, [sp, #256]                 ; 8-byte Folded Reload
	mov	x8, x27
	ldr	w10, [sp, #264]                 ; 4-byte Folded Reload
LBB166_34:
	cbz	x11, LBB166_46
; %bb.35:
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	mov	w2, #2064                       ; =0x810
	bl	_analysis_alloc
	mov	x24, x0
	ldr	x0, [sp, #288]
	cbz	x24, LBB166_70
; %bb.36:
	str	x0, [x24]
	add	x2, sp, #279
	mov	x0, x19
	mov	x1, x24
	bl	_map_declarations_exact
	cbz	w0, LBB166_78
; %bb.37:
	str	x24, [sp, #176]                 ; 8-byte Folded Spill
	ldr	x24, [x21, #1744]
	ldp	x11, x9, [sp, #240]             ; 16-byte Folded Reload
	ldr	x13, [sp, #216]                 ; 8-byte Folded Reload
	ldr	x12, [sp, #256]                 ; 8-byte Folded Reload
	mov	x8, x27
	ldr	w10, [sp, #264]                 ; 4-byte Folded Reload
	b	LBB166_47
LBB166_38:
	mov	x24, x0
	bl	_nvm_record_array_structure_prepare
LBB166_39:
	ldr	w9, [sp, #368]
	add	x8, sp, #117
	ldur	q0, [x8, #255]
	add	x8, sp, #133
	ldur	q1, [x8, #255]
	stp	q0, q1, [x21, #160]
	add	x8, sp, #149
	ldur	q0, [x8, #255]
	str	q0, [x21, #192]
	ldur	w8, [x22, #51]
	stur	w8, [x21, #207]
	ldur	q0, [x22, #151]
	ldur	q1, [x22, #167]
	stp	q0, q1, [x21, #96]
	ldur	q0, [x22, #183]
	str	q0, [x21, #128]
	ldur	x8, [x22, #196]
	stur	x8, [x21, #141]
	ldur	q0, [x22, #87]
	ldur	q1, [x22, #103]
	stp	q0, q1, [x21, #32]
	ldur	q0, [x22, #119]
	ldur	q1, [x22, #135]
	stp	q0, q1, [x21, #64]
	ldur	q0, [x22, #55]
	ldur	q1, [x22, #71]
	stp	q0, q1, [x21]
	mov	x8, x26
	cbz	w9, LBB166_41
LBB166_40:
	ldp	q0, q1, [x21, #160]
	stur	q0, [x8, #4]
	stur	q1, [x8, #20]
	ldr	q0, [x21, #192]
	stur	q0, [x8, #36]
	ldp	q0, q1, [x21, #96]
	stur	q0, [x8, #151]
	stur	q1, [x8, #167]
	ldr	q0, [x21, #128]
	stur	q0, [x8, #183]
	ldp	q0, q1, [x21, #32]
	stur	q0, [x8, #87]
	stur	q1, [x8, #103]
	ldp	q0, q1, [x21, #64]
	stur	q0, [x8, #119]
	stur	q1, [x8, #135]
	ldp	q0, q1, [x21]
	stur	q0, [x8, #55]
	str	w9, [x8]
	ldur	w9, [x21, #207]
	stur	w9, [x8, #51]
	ldur	x9, [x21, #141]
	stur	x9, [x8, #196]
	stur	q1, [x8, #71]
	b	LBB166_104
LBB166_41:
	ldrb	w9, [sp, #328]
	tbnz	w9, #0, LBB166_45
; %bb.42:
	ldrb	w9, [sp, #329]
	tbnz	w9, #0, LBB166_45
; %bb.43:
	ldr	x9, [sp, #304]
	mov	w10, #25697                     ; =0x6461
	movk	w10, #1023, lsl #16
	cmp	x9, x10
	b.lo	LBB166_68
; %bb.44:
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #328]
LBB166_45:
	ldr	x0, [sp, #280]
	mov	x19, x8
	bl	_nvm_record_union_structure_free
	ldr	x0, [sp, #288]
	bl	_nvm_map_declarations_free
	ldr	x0, [sp, #296]
	bl	_nvm_record_array_structure_free
	ldp	q0, q1, [x21, #160]
	stur	q0, [x19, #4]
	stur	q1, [x19, #20]
	ldr	q0, [x21, #192]
	stur	q0, [x19, #36]
	ldp	q0, q1, [x21, #96]
	stur	q0, [x19, #151]
	stur	q1, [x19, #167]
	ldr	q0, [x21, #128]
	stur	q0, [x19, #183]
	ldp	q0, q1, [x21, #32]
	stur	q0, [x19, #87]
	stur	q1, [x19, #103]
	ldp	q0, q1, [x21, #64]
	stur	q0, [x19, #119]
	stur	q1, [x19, #135]
	ldp	q0, q1, [x21]
	stur	q0, [x19, #55]
	mov	w8, #3                          ; =0x3
	str	w8, [x19]
	ldur	w8, [x21, #207]
	stur	w8, [x19, #51]
	ldur	x8, [x21, #141]
	stur	x8, [x19, #196]
	stur	q1, [x19, #71]
	b	LBB166_104
LBB166_46:
	str	xzr, [sp, #176]                 ; 8-byte Folded Spill
LBB166_47:
	orr	x12, x12, x13
	orr	x11, x12, x11
	orr	x11, x11, x23
	cmp	x11, #0
	cset	w11, ne
	cmp	x9, #0
	csinc	w9, w11, wzr, eq
	stp	w9, w11, [x21]
	cbnz	x24, LBB166_49
; %bb.48:
	add	x8, sp, #368
	mov	x0, x27
	bl	_nvm_verify
	add	x1, sp, #368
	mov	x0, x19
	bl	_verified
	ldr	w10, [sp, #264]                 ; 4-byte Folded Reload
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	mov	x8, x27
	cbz	w0, LBB166_51
LBB166_49:
	ldr	w9, [x8, #272]
	cmp	w9, #257
	b.lo	LBB166_53
; %bb.50:
Lloh137:
	adrp	x8, lCPI166_3@PAGE
Lloh138:
	ldr	d0, [x8, lCPI166_3@PAGEOFF]
	add	x8, x21, #1532
	str	d0, [x8]
	str	wzr, [x21, #1540]
	mov	w8, #37400                      ; =0x9218
Lloh139:
	adrp	x9, l_.str.26@PAGE
Lloh140:
	add	x9, x9, l_.str.26@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh141:
	adrp	x2, l_.str.52@PAGE
Lloh142:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
LBB166_51:
	mov	x25, #0                         ; =0x0
LBB166_52:
	ldp	x24, x22, [sp, #176]            ; 16-byte Folded Reload
	b	LBB166_93
LBB166_53:
	str	x25, [sp, #208]                 ; 8-byte Folded Spill
	ldrb	w9, [x8, #8]
	tbz	w9, #0, LBB166_88
; %bb.54:
	ldr	x9, [x8, #256]
	ldr	w11, [x8, #12]
	mov	w12, #24                        ; =0x18
	umaddl	x9, w11, w12, x9
	ldrh	w9, [x9, #4]
	cbnz	w9, LBB166_88
; %bb.55:
	cbz	w10, LBB166_83
LBB166_56:
	ldr	w9, [x8, #448]
	cbnz	w9, LBB166_88
; %bb.57:
	ldr	x24, [x21, #1744]
	cbz	x24, LBB166_84
LBB166_58:
	ldr	w9, [x8, #352]
	cbnz	w9, LBB166_88
; %bb.59:
	ldr	w9, [x21, #4]
	str	w9, [sp, #172]                  ; 4-byte Folded Spill
	cbz	w9, LBB166_85
LBB166_60:
	str	x26, [sp, #144]                 ; 8-byte Folded Spill
	cbz	w10, LBB166_65
; %bb.61:
	ldr	w26, [x8, #432]
	cbz	w26, LBB166_65
; %bb.62:
	mov	w1, #0                          ; =0x0
LBB166_63:                              ; =>This Inner Loop Header: Depth=1
	mov	x0, x8
	mov	x25, x1
	bl	_nvm_portable_file_read_import
	cbz	w0, LBB166_106
; %bb.64:                               ;   in Loop: Header=BB166_63 Depth=1
	add	w1, w25, #1
	cmp	w26, w1
	mov	x8, x27
	b.ne	LBB166_63
LBB166_65:
	ldr	w8, [sp, #172]                  ; 4-byte Folded Reload
	cbz	w8, LBB166_109
; %bb.66:
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_108
; %bb.67:
	mov	x0, x19
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	bl	_uf_prepare_records
	cbnz	w0, LBB166_109
	b	LBB166_261
LBB166_68:
	mov	w10, #39840                     ; =0x9ba0
	ldr	x11, [sp, #312]
	add	x9, x9, x10
	cmp	x11, x9
	str	x9, [sp, #304]
	mov	x5, x25
	mov	x1, x19
	mov	x4, x27
	mov	x0, x24
	ldr	x25, [sp, #208]                 ; 8-byte Folded Reload
	ldr	w26, [sp, #228]                 ; 4-byte Folded Reload
	b.hs	LBB166_16
; %bb.69:
	str	x9, [sp, #312]
	b	LBB166_16
LBB166_70:
	bl	_nvm_map_declarations_free
	ldr	x9, [x21, #1744]
Lloh143:
	adrp	x8, l_.str.25@PAGE
Lloh144:
	add	x8, x8, l_.str.25@PAGEOFF
	cbz	x9, LBB166_80
; %bb.71:
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
	b	LBB166_23
LBB166_72:
	ldr	x8, [x11]
	mov	w9, #64441                      ; =0xfbb9
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB166_76
; %bb.73:
	add	x8, x8, #1096
	str	x8, [x21, #1752]
	ldr	x9, [x21, #1760]
	cmp	x9, x8
	b.hs	LBB166_75
; %bb.74:
	str	x8, [x21, #1760]
LBB166_75:
	ldr	x8, [x21, #1768]
	lsr	x9, x8, #24
	cbz	x9, LBB166_81
LBB166_76:
	mov	x22, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1776]
	b	LBB166_22
LBB166_77:
	mov	x22, #0                         ; =0x0
Lloh145:
	adrp	x8, l_.str.24@PAGE
Lloh146:
	add	x8, x8, l_.str.24@PAGEOFF
	mov	w9, #4                          ; =0x4
	b	LBB166_24
LBB166_78:
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
LBB166_79:
	mov	x25, #0                         ; =0x0
	mov	w9, #37388                      ; =0x920c
	add	x9, x19, x9
	ldp	q0, q1, [x9, #160]
	stp	q0, q1, [x8, #160]
	ldur	q0, [x9, #188]
	stur	q0, [x8, #188]
	ldp	q0, q1, [x9, #96]
	stp	q0, q1, [x8, #96]
	ldp	q1, q0, [x9, #128]
	stp	q1, q0, [x8, #128]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x9, #64]
	stp	q1, q0, [x8, #64]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x8]
	b	LBB166_94
LBB166_80:
	mov	w9, #4                          ; =0x4
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
	b	LBB166_24
LBB166_81:
	add	x8, x8, #1
	str	x8, [x21, #1768]
	mov	w0, #1                          ; =0x1
	mov	w1, #1096                       ; =0x448
	bl	_calloc
	str	x0, [sp, #184]                  ; 8-byte Folded Spill
	cbnz	x0, LBB166_33
; %bb.82:
	mov	x22, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1777]
	b	LBB166_22
LBB166_83:
	ldr	w9, [x8, #432]
	cbnz	w9, LBB166_88
	b	LBB166_56
LBB166_84:
	ldr	w9, [x8, #476]
	cbnz	w9, LBB166_88
	b	LBB166_58
LBB166_85:
	ldr	w9, [x8, #468]
	cbnz	w9, LBB166_88
; %bb.86:
	ldr	w9, [x8, #304]
	cbnz	w9, LBB166_88
; %bb.87:
	ldr	w9, [x8, #320]
	cbz	w9, LBB166_60
LBB166_88:
	ldr	x8, [x21, #1744]
	ldr	x24, [sp, #176]                 ; 8-byte Folded Reload
	cbz	x8, LBB166_90
; %bb.89:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB166_91
LBB166_90:
	mov	w8, #1                          ; =0x1
LBB166_91:
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh147:
	adrp	x9, l_.str.27@PAGE
Lloh148:
	add	x9, x9, l_.str.27@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh149:
	adrp	x2, l_.str.52@PAGE
Lloh150:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x25, #0                         ; =0x0
LBB166_92:
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
LBB166_93:
	mov	w8, #37388                      ; =0x920c
	add	x8, x19, x8
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x9, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x9, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x9, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x9, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x9, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x9, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x9]
	cbz	x24, LBB166_95
LBB166_94:
	ldr	x0, [x24]
	bl	_nvm_map_declarations_free
	mov	x0, x24
	bl	_free
LBB166_95:
	cbz	x22, LBB166_97
; %bb.96:
	ldr	x0, [x22]
	bl	_nvm_union_field_declarations_free
	mov	x0, x22
	bl	_free
LBB166_97:
	ldr	x0, [sp, #280]
	bl	_nvm_record_union_structure_free
	ldr	x0, [sp, #352]
	bl	_free
	ldr	x20, [sp, #344]
	cbz	x20, LBB166_99
; %bb.98:
	ldr	x0, [x20]
	bl	_nvm_union_field_declarations_free
	ldr	x0, [x20, #8]
	bl	_free
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x0, [x20, #24]
	bl	_free
	ldr	x0, [x20, #32]
	bl	_free
	mov	x0, x20
	bl	_free
LBB166_99:
	mov	x0, x25
	bl	_free
	add	x20, x19, #120
	mov	w22, #256                       ; =0x100
LBB166_100:                             ; =>This Inner Loop Header: Depth=1
	sub	x0, x20, #112
	bl	_vm_decoded_function_free
	ldur	x0, [x20, #-80]
	bl	_free
	ldur	x0, [x20, #-56]
	bl	_free
	ldur	x0, [x20, #-40]
	bl	_free
	ldur	x0, [x20, #-16]
	bl	_free
	ldur	x0, [x20, #-8]
	bl	_free
	ldr	x0, [x20], #120
	bl	_free
	subs	x22, x22, #1
	b.ne	LBB166_100
; %bb.101:
	ldr	x0, [x21, #1744]
	bl	_nvm_record_array_structure_free
	ldr	x0, [x21, #2808]
	bl	_free
	ldr	x0, [x21, #2816]
	bl	_free
	ldr	x8, [x26, #4000]
	cbz	x8, LBB166_103
; %bb.102:
	ldr	x0, [x8]
	bl	_free
	ldr	x0, [x26, #4000]
	bl	_free
LBB166_103:
	ldr	x0, [x21, #16]
	bl	_nvm_record_plan_free
	ldr	x0, [x21, #24]
	bl	_free
	mov	x0, x19
	bl	_free
LBB166_104:
	ldur	x8, [x29, #-104]
Lloh151:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh152:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh153:
	ldr	x9, [x9]
	cmp	x9, x8
	b.eq	LBB166_6
LBB166_105:
	bl	___stack_chk_fail
LBB166_106:
	cbz	x24, LBB166_199
; %bb.107:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB166_200
LBB166_108:
	mov	x0, x19
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	bl	_prepare_records
	cbz	w0, LBB166_261
LBB166_109:
	mov	x0, x19
	bl	_global_prepare
	cbz	w0, LBB166_261
; %bb.110:
	ldr	w8, [x27, #272]
	cbz	w8, LBB166_193
; %bb.111:
	str	wzr, [sp, #172]                 ; 4-byte Folded Spill
	str	wzr, [sp, #136]                 ; 4-byte Folded Spill
	add	x9, x19, #8
	mov	w8, #36620                      ; =0x8f0c
	add	x8, x19, x8
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	mov	w8, #34832                      ; =0x8810
	add	x8, x19, x8
	stp	x8, x9, [sp, #64]               ; 16-byte Folded Spill
	mov	w8, #35904                      ; =0x8c40
	add	x8, x19, x8
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
Lloh154:
	adrp	x8, l_.str.38@PAGE
Lloh155:
	add	x8, x8, l_.str.38@PAGEOFF
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
Lloh156:
	adrp	x8, lCPI166_0@PAGE
Lloh157:
	ldr	q0, [x8, lCPI166_0@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh158:
	adrp	x8, lCPI166_1@PAGE
Lloh159:
	ldr	q0, [x8, lCPI166_1@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh160:
	adrp	x8, l_.str.34@PAGE
Lloh161:
	add	x8, x8, l_.str.34@PAGEOFF
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
LBB166_112:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB166_123 Depth 2
                                        ;     Child Loop BB166_163 Depth 2
	ldr	x8, [x27, #256]
	ldr	w9, [sp, #136]                  ; 4-byte Folded Reload
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldr	w8, [x8, #12]
	lsl	x8, x8, #1
	add	x1, x8, #1024
	mov	x0, x19
	bl	_analysis_work
	cbz	w0, LBB166_261
; %bb.113:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	mov	w10, w8
	ldr	x8, [x27, #256]
	mov	w9, #24                         ; =0x18
	str	x10, [sp, #128]                 ; 8-byte Folded Spill
	umaddl	x8, w10, w9, x8
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	ldrh	w8, [x8, #16]
	cmp	w8, #257
	b.hs	LBB166_272
; %bb.114:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB166_265
; %bb.115:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #21]
	cmp	w8, #2
	b.hs	LBB166_265
; %bb.116:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w1, [x8]
	mov	x0, x27
	bl	_nvm_get_string
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	tbz	w8, #31, LBB166_120
; %bb.117:                              ;   in Loop: Header=BB166_112 Depth=1
	cbz	x0, LBB166_120
; %bb.118:                              ;   in Loop: Header=BB166_112 Depth=1
Lloh162:
	adrp	x1, l_.str.31@PAGE
Lloh163:
	add	x1, x1, l_.str.31@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB166_120
; %bb.119:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, #4]
	ldr	w9, [sp, #136]                  ; 4-byte Folded Reload
	str	w9, [sp, #116]                  ; 4-byte Folded Spill
	cbnz	w8, LBB166_309
LBB166_120:                             ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cbz	w8, LBB166_142
; %bb.121:                              ;   in Loop: Header=BB166_112 Depth=1
	mov	w25, #0                         ; =0x0
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	b	LBB166_123
LBB166_122:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	ldr	w8, [x10, #12]
	add	w25, w26, w25
	cmp	w25, w8
	b.hs	LBB166_142
LBB166_123:                             ;   Parent Loop BB166_112 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v0, #0000000000000000
	str	q0, [x22, #48]
	stp	q0, q0, [sp, #384]
	str	q0, [sp, #368]
	ldr	x8, [x27, #280]
	ldp	w9, w10, [x10, #8]
	add	x8, x8, x9
	add	x0, x8, w25, uxtw
	sub	w1, w10, w25
	add	x2, sp, #368
	bl	_isa_decode
	cbz	w0, LBB166_202
; %bb.124:                              ;   in Loop: Header=BB166_123 Depth=2
	ldr	w8, [sp, #172]                  ; 4-byte Folded Reload
	add	w8, w8, #1
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	cmp	w8, #16, lsl #12                ; =65536
	b.hi	LBB166_204
; %bb.125:                              ;   in Loop: Header=BB166_123 Depth=2
	mov	x26, x0
	ldrb	w0, [sp, #368]
	mov	x24, x0
	bl	_supported
	cbz	w0, LBB166_130
LBB166_126:                             ;   in Loop: Header=BB166_123 Depth=2
	and	w8, w24, #0xfe
	cmp	w8, #18
	b.ne	LBB166_122
; %bb.127:                              ;   in Loop: Header=BB166_123 Depth=2
	ldr	w8, [sp, #376]
	cmp	w8, #255
	b.hi	LBB166_257
; %bb.128:                              ;   in Loop: Header=BB166_123 Depth=2
	ldr	w9, [x21, #1736]
	cmp	w8, w9
	b.lo	LBB166_122
; %bb.129:                              ;   in Loop: Header=BB166_123 Depth=2
	add	w8, w8, #1
	str	w8, [x21, #1736]
	b	LBB166_122
LBB166_130:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_133
; %bb.131:                              ;   in Loop: Header=BB166_123 Depth=2
	cmp	w24, #163
	b.eq	LBB166_126
; %bb.132:                              ;   in Loop: Header=BB166_123 Depth=2
	cmp	w24, #254
	b.eq	LBB166_126
LBB166_133:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_136
; %bb.134:                              ;   in Loop: Header=BB166_123 Depth=2
	sub	w8, w24, #120
	cmp	w8, #5
	b.lo	LBB166_126
; %bb.135:                              ;   in Loop: Header=BB166_123 Depth=2
	cmp	w24, #127
	b.eq	LBB166_126
LBB166_136:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	x8, [x21, #1744]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	cmp	w24, #51
	b.ne	LBB166_138
; %bb.137:                              ;   in Loop: Header=BB166_123 Depth=2
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	cbnz	x8, LBB166_122
LBB166_138:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	w8, [x21, #4]
	cbz	w8, LBB166_140
; %bb.139:                              ;   in Loop: Header=BB166_123 Depth=2
	mov	x0, x24
	bl	_record_operation
	cbnz	w0, LBB166_126
LBB166_140:                             ;   in Loop: Header=BB166_123 Depth=2
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	cbz	w8, LBB166_311
; %bb.141:                              ;   in Loop: Header=BB166_123 Depth=2
	cmp	w24, #62
	b.eq	LBB166_122
	b	LBB166_311
LBB166_142:                             ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	mov	w9, #120                        ; =0x78
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	umaddl	x8, w10, w9, x8
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_144
; %bb.143:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #1
	mov	w9, #8208                       ; =0x2010
	ldrh	w8, [x8, x9]
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	strh	w8, [x9, #64]
	b	LBB166_146
LBB166_144:                             ;   in Loop: Header=BB166_112 Depth=1
	add	x8, sp, #368
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	add	x2, x9, #64
	mov	x0, x27
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	bl	_nvm_verify_function_max_stack
	add	x1, sp, #368
	mov	x0, x19
	bl	_verified
	cbz	w0, LBB166_261
; %bb.145:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldurh	w8, [x8, #64]
LBB166_146:                             ;   in Loop: Header=BB166_112 Depth=1
	cmp	w8, #257
	b.hs	LBB166_282
; %bb.147:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_149
; %bb.148:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #5
	ldp	q0, q1, [x8, #16]
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	stp	q0, q1, [x9]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #16]
	b	LBB166_150
LBB166_149:                             ;   in Loop: Header=BB166_112 Depth=1
	add	x3, sp, #368
	mov	x0, x27
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #160]                  ; 8-byte Folded Reload
	bl	_vm_decode_function
	tbz	w0, #0, LBB166_307
LBB166_150:                             ;   in Loop: Header=BB166_112 Depth=1
	ldp	x8, x9, [sp, #152]              ; 16-byte Folded Reload
	ldrh	w8, [x8, #16]
	strh	w8, [x9, #66]
	ldrh	w9, [x9, #64]
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x10, [x10, #4000]
	cbz	x10, LBB166_152
; %bb.151:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	w10, [x21, #1736]
LBB166_152:                             ;   in Loop: Header=BB166_112 Depth=1
	add	w8, w9, w8
	add	w8, w8, w10
	cmp	w8, #1
	csinc	w8, w8, wzr, hi
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	str	w8, [x9, #92]
	ldr	w9, [x9, #8]
	add	w25, w9, #1
	ldr	x9, [x21, #40]
	umaddl	x9, w25, w8, x9
	str	x9, [x21, #40]
	ldr	w10, [x21, #32]
	add	x9, x9, x10
	cmp	x9, #256, lsl #12               ; =1048576
	b.hi	LBB166_283
; %bb.153:                              ;   in Loop: Header=BB166_112 Depth=1
	umull	x1, w25, w8
	mov	x0, x19
	mov	w2, #16                         ; =0x10
	bl	_analysis_alloc
	ldr	x24, [sp, #160]                 ; 8-byte Folded Reload
	str	x0, [x24, #32]
	mov	x0, x19
	mov	x1, x25
	mov	w2, #2                          ; =0x2
	bl	_analysis_alloc
	str	x0, [x24, #56]
	mov	x0, x19
	mov	x1, x25
	mov	w2, #4                          ; =0x4
	bl	_analysis_alloc
	str	x0, [x24, #72]
	mov	x0, x19
	mov	x1, x25
	mov	w2, #1                          ; =0x1
	bl	_analysis_alloc
	str	x0, [x24, #96]
	mov	x0, x19
	mov	x1, x25
	mov	w2, #1                          ; =0x1
	bl	_analysis_alloc
	str	x0, [x24, #104]
	mov	x0, x19
	mov	x1, x25
	mov	w2, #2                          ; =0x2
	bl	_analysis_alloc
	str	x0, [x24, #112]
	ldr	x8, [x24, #32]
	cbz	x8, LBB166_263
; %bb.154:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #56]
	cbz	x8, LBB166_263
; %bb.155:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #72]
	cbz	x8, LBB166_263
; %bb.156:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #96]
	cbz	x8, LBB166_263
; %bb.157:                              ;   in Loop: Header=BB166_112 Depth=1
	cbz	x0, LBB166_263
; %bb.158:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #104]
	cbz	x8, LBB166_263
; %bb.159:                              ;   in Loop: Header=BB166_112 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	cbz	w8, LBB166_191
; %bb.160:                              ;   in Loop: Header=BB166_112 Depth=1
	str	xzr, [sp, #152]                 ; 8-byte Folded Spill
	mov	x26, #0                         ; =0x0
	b	LBB166_163
LBB166_161:                             ;   in Loop: Header=BB166_163 Depth=2
	mov	x0, x19
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	mov	x2, x26
	bl	_record_site
	cbz	w0, LBB166_261
LBB166_162:                             ;   in Loop: Header=BB166_163 Depth=2
	add	x10, x26, #1
	ldp	x9, x8, [sp, #152]              ; 16-byte Folded Reload
	ldr	w8, [x8, #8]
	add	x9, x9, #104
	str	x9, [sp, #152]                  ; 8-byte Folded Spill
	mov	x26, x10
	cmp	x10, x8
	b.hs	LBB166_191
LBB166_163:                             ;   Parent Loop BB166_112 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	x9, x8, [sp, #152]              ; 16-byte Folded Reload
	ldr	x25, [x8]
	add	x9, x25, x9
	str	x9, [sp, #128]                  ; 8-byte Folded Spill
	ldrb	w24, [x9, #40]
	ldr	x9, [x8, #112]
	mov	w8, #65535                      ; =0xffff
	str	x9, [sp, #120]                  ; 8-byte Folded Spill
	strh	w8, [x9, x26, lsl #1]
	ldr	w8, [x21, #4]
	cbz	w8, LBB166_169
; %bb.164:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #96
	b.eq	LBB166_167
; %bb.165:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #251
	b.eq	LBB166_167
; %bb.166:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #99
	b.ne	LBB166_169
LBB166_167:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_161
; %bb.168:                              ;   in Loop: Header=BB166_163 Depth=2
	mov	x0, x19
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	ldr	w2, [sp, #136]                  ; 4-byte Folded Reload
	mov	x3, x26
	bl	_uf_site
	cbnz	w0, LBB166_162
	b	LBB166_261
LBB166_169:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_175
; %bb.170:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #120
	b.ne	LBB166_175
; %bb.171:                              ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	add	x8, x25, x8
	ldrb	w9, [x8, #48]
	cmp	w9, #5
	b.ne	LBB166_267
; %bb.172:                              ;   in Loop: Header=BB166_163 Depth=2
	ldrb	w8, [x8, #56]
	ldrb	w9, [sp, #279]
	cmp	w8, w9
	b.ne	LBB166_267
; %bb.173:                              ;   in Loop: Header=BB166_163 Depth=2
	ldr	w8, [x21, #752]
	cmp	w8, #64
	b.eq	LBB166_276
; %bb.174:                              ;   in Loop: Header=BB166_163 Depth=2
	add	w9, w8, #1
	str	w9, [x21, #752]
	ldr	x9, [sp, #120]                  ; 8-byte Folded Reload
	strh	w8, [x9, x26, lsl #1]
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	mov	w10, #2                         ; =0x2
	strb	w10, [x9, x8]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	mov	w10, #12                        ; =0xc
	umaddl	x8, w8, w10, x9
	ldr	x9, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w9, [x9]
	ldr	w10, [sp, #136]                 ; 4-byte Folded Reload
	stp	w10, w9, [x8]
	strh	wzr, [x8, #8]
	mov	w9, #13                         ; =0xd
	strh	w9, [x8, #10]
	b	LBB166_162
LBB166_175:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	cmp	w8, #0
	mov	w8, #62                         ; =0x3e
	ccmp	w24, w8, #0, ne
	cset	w8, eq
	str	w8, [sp, #100]                  ; 4-byte Folded Spill
	b.ne	LBB166_178
; %bb.176:                              ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	add	x8, x25, x8
	ldr	w1, [x8, #48]
	mov	x0, x27
	bl	_nvm_portable_file_read_import
	cmp	w0, #2
	b.ne	LBB166_162
; %bb.177:                              ;   in Loop: Header=BB166_163 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB166_183
LBB166_178:                             ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #77
	b.eq	LBB166_182
; %bb.179:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #88
	b.eq	LBB166_181
; %bb.180:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #80
	b.ne	LBB166_162
LBB166_181:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	add	x8, x25, x8
	ldrb	w8, [x8, #48]
	b	LBB166_183
LBB166_182:                             ;   in Loop: Header=BB166_163 Depth=2
	mov	w8, #5                          ; =0x5
LBB166_183:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	x10, [x21, #1744]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w8
	cbz	x10, LBB166_185
; %bb.184:                              ;   in Loop: Header=BB166_163 Depth=2
	ldrb	w10, [x21, #2824]
	cmp	w10, #0
	mov	w10, #62                        ; =0x3e
	mov	w11, #190                       ; =0xbe
	csel	w10, w10, w11, eq
	tst	w10, w9
	b.ne	LBB166_186
	b	LBB166_284
LBB166_185:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	w10, [x21]
	cmp	w10, #0
	mov	w10, #703                       ; =0x2bf
	mov	w11, #575                       ; =0x23f
	csel	w10, w11, w10, eq
	tst	w10, w9
	b.eq	LBB166_291
LBB166_186:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	w9, [x21, #752]
	cmp	w9, #64
	b.eq	LBB166_280
; %bb.187:                              ;   in Loop: Header=BB166_163 Depth=2
	cmp	w24, #77
	mov	w10, #32                        ; =0x20
	csel	w10, w10, wzr, eq
	ldr	w11, [sp, #100]                 ; 4-byte Folded Reload
	cmp	w11, #0
	mov	w11, #4                         ; =0x4
	csel	w10, w11, w10, ne
	sub	w11, w8, #1
	cmp	w11, #4
	add	w11, w9, #1
	str	w11, [x21, #752]
	ldr	x11, [sp, #120]                 ; 8-byte Folded Reload
	strh	w9, [x11, x26, lsl #1]
	ldr	x11, [sp, #128]                 ; 8-byte Folded Reload
	ldr	w11, [x11]
	ldr	x12, [sp, #104]                 ; 8-byte Folded Reload
	mov	w13, #12                        ; =0xc
	umaddl	x12, w9, w13, x12
	ldr	w13, [sp, #136]                 ; 4-byte Folded Reload
	stp	w13, w11, [x12]
	cset	w11, lo
	strh	w10, [x12, #8]
	strb	w8, [x12, #10]
	strb	w11, [x12, #11]
	cmp	w24, #77
	b.ne	LBB166_189
; %bb.188:                              ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #32]                   ; 16-byte Folded Reload
	str	q0, [x8, w9, uxtw #4]
LBB166_189:                             ;   in Loop: Header=BB166_163 Depth=2
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	cbz	w8, LBB166_162
; %bb.190:                              ;   in Loop: Header=BB166_163 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	str	q0, [x8, w9, uxtw #4]
	b	LBB166_162
LBB166_191:                             ;   in Loop: Header=BB166_112 Depth=1
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	add	w8, w8, #1
	ldr	w9, [x27, #272]
	str	w8, [sp, #136]                  ; 4-byte Folded Spill
	cmp	w8, w9
	b.lo	LBB166_112
; %bb.192:
	mov	x26, x9
	b	LBB166_194
LBB166_193:
	mov	w26, #0                         ; =0x0
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
LBB166_194:
	ldr	w1, [x21, #32]
	cbz	w1, LBB166_196
; %bb.195:
	mov	x0, x19
	mov	w2, #16                         ; =0x10
	bl	_analysis_alloc
	str	x0, [x21, #24]
	cbz	x0, LBB166_255
LBB166_196:
	ldr	w8, [x21, #1736]
	cbz	w8, LBB166_210
; %bb.197:
	adrp	x10, lCPI166_2@PAGE
	cmp	w8, #8
	b.hs	LBB166_205
; %bb.198:
	mov	x9, #0                          ; =0x0
	b	LBB166_208
LBB166_199:
	mov	w8, #1                          ; =0x1
LBB166_200:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh164:
	adrp	x9, l_.str.28@PAGE
Lloh165:
	add	x9, x9, l_.str.28@PAGEOFF
LBB166_201:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
	b	LBB166_259
LBB166_202:
	ldr	x9, [x21, #1744]
Lloh166:
	adrp	x8, l_.str.33@PAGE
Lloh167:
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB166_258
LBB166_203:
	ldrb	w9, [x21, #1776]
	mov	w10, #3                         ; =0x3
	cmp	w9, #0
	csel	w8, w10, w8, ne
	b	LBB166_258
LBB166_204:
	mov	w8, #3                          ; =0x3
	b	LBB166_258
LBB166_205:
	and	x9, x8, #0xfffffff8
	ldr	q0, [x10, lCPI166_2@PAGEOFF]
	mov	x11, x9
	ldr	x12, [sp, #144]                 ; 8-byte Folded Reload
LBB166_206:                             ; =>This Inner Loop Header: Depth=1
	stp	q0, q0, [x12, #-96]
	stp	q0, q0, [x12, #-64]
	stp	q0, q0, [x12, #-32]
	stp	q0, q0, [x12], #128
	subs	x11, x11, #8
	b.ne	LBB166_206
; %bb.207:
	cmp	x9, x8
	b.eq	LBB166_210
LBB166_208:
	mov	w11, #30728                     ; =0x7808
	add	x11, x19, x11
	ldr	q0, [x10, lCPI166_2@PAGEOFF]
LBB166_209:                             ; =>This Inner Loop Header: Depth=1
	str	q0, [x11, x9, lsl #4]
	add	x9, x9, #1
	cmp	x9, x8
	b.lo	LBB166_209
LBB166_210:
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #4000]
	cbnz	x8, LBB166_215
; %bb.211:
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	tbnz	w8, #31, LBB166_213
; %bb.212:
	mov	x0, x19
	ldr	w1, [sp, #116]                  ; 4-byte Folded Reload
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_seed
	cbz	w0, LBB166_261
LBB166_213:
	ldr	w1, [x27, #12]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_seed
	cbz	w0, LBB166_261
; %bb.214:
	ldr	w26, [x27, #272]
LBB166_215:
	str	wzr, [sp, #172]                 ; 4-byte Folded Spill
	mov	w8, #30728                      ; =0x7808
	add	x8, x19, x8
	str	x8, [sp, #264]                  ; 8-byte Folded Spill
	add	x22, x19, #104
	add	x8, sp, #368
	add	x9, x8, #42
	str	x9, [sp, #136]                  ; 8-byte Folded Spill
	add	x9, x8, #10
	mov	w24, #1                         ; =0x1
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	mov	w8, w8
	stp	x8, x9, [sp, #152]              ; 16-byte Folded Spill
LBB166_216:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB166_230 Depth 2
                                        ;     Child Loop BB166_240 Depth 2
                                        ;       Child Loop BB166_245 Depth 3
                                        ;       Child Loop BB166_248 Depth 3
	mov	w8, w26
	mov	w9, #256                        ; =0x100
	orr	x1, x9, x8, lsl #9
	mov	x0, x19
	bl	_analysis_work
	cbz	w0, LBB166_261
; %bb.217:                              ;   in Loop: Header=BB166_216 Depth=1
	str	wzr, [x21, #1740]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #4000]
	cbz	x8, LBB166_226
; %bb.218:                              ;   in Loop: Header=BB166_216 Depth=1
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	tbnz	w8, #31, LBB166_224
; %bb.219:                              ;   in Loop: Header=BB166_216 Depth=1
	mov	x0, x19
	ldr	w1, [sp, #116]                  ; 4-byte Folded Reload
	mov	x2, #0                          ; =0x0
	ldr	x3, [sp, #264]                  ; 8-byte Folded Reload
	bl	_seed
	cbz	w0, LBB166_261
; %bb.220:                              ;   in Loop: Header=BB166_216 Depth=1
	ldp	x8, x9, [sp, #144]              ; 16-byte Folded Reload
	ldr	x8, [x8, #4000]
	add	x9, x8, x9
	mov	w10, #8200                      ; =0x2008
	ldrb	w9, [x9, x10]
	cbz	w9, LBB166_226
; %bb.221:                              ;   in Loop: Header=BB166_216 Depth=1
	ldr	w9, [x21, #1736]
	ldr	x3, [sp, #264]                  ; 8-byte Folded Reload
	cbz	w9, LBB166_223
; %bb.222:                              ;   in Loop: Header=BB166_216 Depth=1
	ldr	x8, [x8]
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	umull	x9, w9, w10
	add	x3, x8, x9, lsl #4
LBB166_223:                             ;   in Loop: Header=BB166_216 Depth=1
	ldr	w1, [x27, #12]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	b	LBB166_225
LBB166_224:                             ;   in Loop: Header=BB166_216 Depth=1
	ldr	w1, [x27, #12]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	ldr	x3, [sp, #264]                  ; 8-byte Folded Reload
LBB166_225:                             ;   in Loop: Header=BB166_216 Depth=1
	bl	_seed
	cbz	w0, LBB166_261
LBB166_226:                             ;   in Loop: Header=BB166_216 Depth=1
	ldr	w8, [x27, #272]
	cbz	w8, LBB166_234
; %bb.227:                              ;   in Loop: Header=BB166_216 Depth=1
	mov	w25, #0                         ; =0x0
	b	LBB166_230
LBB166_228:                             ;   in Loop: Header=BB166_230 Depth=2
	mov	x0, x19
	mov	x1, x25
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	ldr	x4, [sp, #184]                  ; 8-byte Folded Reload
	bl	_walk_context
	cbz	w0, LBB166_261
LBB166_229:                             ;   in Loop: Header=BB166_230 Depth=2
	add	w25, w25, #1
	ldr	w8, [x27, #272]
	cmp	w25, w8
	b.hs	LBB166_236
LBB166_230:                             ;   Parent Loop BB166_216 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	cbnz	x8, LBB166_228
; %bb.231:                              ;   in Loop: Header=BB166_230 Depth=2
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_233
; %bb.232:                              ;   in Loop: Header=BB166_230 Depth=2
	ldrb	w3, [sp, #279]
	mov	x0, x19
	mov	x1, x25
	ldr	x2, [sp, #176]                  ; 8-byte Folded Reload
	mov	x4, #0                          ; =0x0
	bl	_walk_context
	cbnz	w0, LBB166_229
	b	LBB166_269
LBB166_233:                             ;   in Loop: Header=BB166_230 Depth=2
	mov	x0, x19
	mov	x1, x25
	mov	x2, #0                          ; =0x0
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_walk_context
	cbnz	w0, LBB166_229
	b	LBB166_273
LBB166_234:                             ;   in Loop: Header=BB166_216 Depth=1
	ldr	w8, [x21, #1740]
	ldr	w9, [sp, #172]                  ; 4-byte Folded Reload
	orr	w9, w8, w9
	cbz	w9, LBB166_253
; %bb.235:                              ;   in Loop: Header=BB166_216 Depth=1
	mov	w26, #0                         ; =0x0
	b	LBB166_252
LBB166_236:                             ;   in Loop: Header=BB166_216 Depth=1
	mov	x26, x8
	ldr	w8, [x21, #1740]
	ldr	w9, [sp, #172]                  ; 4-byte Folded Reload
	orr	w9, w8, w9
	cbnz	w9, LBB166_252
; %bb.237:                              ;   in Loop: Header=BB166_216 Depth=1
	cbz	w26, LBB166_253
; %bb.238:                              ;   in Loop: Header=BB166_216 Depth=1
	mov	x25, #0                         ; =0x0
	b	LBB166_240
LBB166_239:                             ;   in Loop: Header=BB166_240 Depth=2
	add	x8, x25, #1
	mov	x25, x8
	cmp	x8, w26, uxtw
	b.hs	LBB166_251
LBB166_240:                             ;   Parent Loop BB166_216 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB166_245 Depth 3
                                        ;       Child Loop BB166_248 Depth 3
	mov	w8, #120                        ; =0x78
	mul	x8, x25, x8
	ldr	x8, [x22, x8]
	ldrb	w8, [x8]
	cbnz	w8, LBB166_239
; %bb.241:                              ;   in Loop: Header=BB166_240 Depth=2
	add	x0, sp, #368
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	ldr	x8, [x27, #256]
	mov	w9, #24                         ; =0x18
	madd	x8, x25, x9, x8
	ldrh	w8, [x8, #4]
	cbz	w8, LBB166_249
; %bb.242:                              ;   in Loop: Header=BB166_240 Depth=2
	cmp	w8, #4
	b.hs	LBB166_244
; %bb.243:                              ;   in Loop: Header=BB166_240 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB166_247
LBB166_244:                             ;   in Loop: Header=BB166_240 Depth=2
	and	x9, x8, #0xfffc
	mov	x10, x9
	ldr	x11, [sp, #136]                 ; 8-byte Folded Reload
LBB166_245:                             ;   Parent Loop BB166_216 Depth=1
                                        ;     Parent Loop BB166_240 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sturb	w24, [x11, #-32]
	sturb	w24, [x11, #-16]
	strb	w24, [x11]
	strb	w24, [x11, #16]
	add	x11, x11, #64
	subs	x10, x10, #4
	b.ne	LBB166_245
; %bb.246:                              ;   in Loop: Header=BB166_240 Depth=2
	cmp	x9, x8
	b.eq	LBB166_249
LBB166_247:                             ;   in Loop: Header=BB166_240 Depth=2
	ldr	x10, [sp, #160]                 ; 8-byte Folded Reload
	add	x10, x10, x9, lsl #4
	sub	x8, x8, x9
LBB166_248:                             ;   Parent Loop BB166_216 Depth=1
                                        ;     Parent Loop BB166_240 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	strb	w24, [x10], #16
	subs	x8, x8, #1
	b.ne	LBB166_248
LBB166_249:                             ;   in Loop: Header=BB166_240 Depth=2
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #4000]
	cmp	x8, #0
	ldr	x8, [sp, #264]                  ; 8-byte Folded Reload
	csel	x3, xzr, x8, eq
	add	x2, sp, #368
	mov	x0, x19
	mov	x1, x25
	bl	_seed
	cbz	w0, LBB166_261
; %bb.250:                              ;   in Loop: Header=BB166_240 Depth=2
	ldr	w26, [x27, #272]
	b	LBB166_239
LBB166_251:                             ;   in Loop: Header=BB166_216 Depth=1
	ldr	w8, [x21, #1740]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #172]                  ; 4-byte Folded Spill
LBB166_252:                             ;   in Loop: Header=BB166_216 Depth=1
	cbnz	w8, LBB166_216
LBB166_253:
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_285
; %bb.254:
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldr	x3, [sp, #184]                  ; 8-byte Folded Reload
	b	LBB166_286
LBB166_255:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_270
; %bb.256:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB166_271
LBB166_257:
	mov	w8, #3                          ; =0x3
Lloh168:
	adrp	x9, l_.str.36@PAGE
Lloh169:
	add	x9, x9, l_.str.36@PAGEOFF
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
LBB166_258:
	str	w8, [x21, #1532]
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
	str	w25, [x21, #1540]
	mov	w9, #191                        ; =0xbf
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	stp	x9, x10, [sp]
LBB166_259:
Lloh170:
	adrp	x2, l_.str.52@PAGE
Lloh171:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
LBB166_260:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB166_261:
	mov	x25, #0                         ; =0x0
LBB166_262:
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	b	LBB166_52
LBB166_263:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_274
; %bb.264:
	mov	w8, #0                          ; =0x0
	ldrb	w9, [x21, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	cinc	w9, w9, eq
Lloh172:
	adrp	x10, l_.str.39@PAGE
Lloh173:
	add	x10, x10, l_.str.39@PAGEOFF
	b	LBB166_293
LBB166_265:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_277
; %bb.266:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB166_278
LBB166_267:
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w8, [x25, x8]
	ldr	x9, [x21, #1744]
	cbz	x9, LBB166_279
; %bb.268:
	ldrb	w9, [x21, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
Lloh174:
	adrp	x10, l_.str.40@PAGE
Lloh175:
	add	x10, x10, l_.str.40@PAGEOFF
	b	LBB166_293
LBB166_269:
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	ldp	x24, x22, [sp, #176]            ; 16-byte Folded Reload
	b	LBB166_79
LBB166_270:
	mov	w8, #4                          ; =0x4
LBB166_271:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh176:
	adrp	x9, l_.str.44@PAGE
Lloh177:
	add	x9, x9, l_.str.44@PAGEOFF
	b	LBB166_201
LBB166_272:
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #1532]
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [x21, #1536]
	str	wzr, [x21, #1540]
	mov	w8, #37400                      ; =0x9218
Lloh178:
	adrp	x9, l_.str.29@PAGE
Lloh179:
	add	x9, x9, l_.str.29@PAGEOFF
	b	LBB166_201
LBB166_273:
	mov	x25, #0                         ; =0x0
	mov	w8, #37388                      ; =0x920c
	add	x8, x19, x8
	ldp	q0, q1, [x8, #160]
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	stp	q0, q1, [x9, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x9, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x9, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x9, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x9, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x9, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x9]
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	b	LBB166_97
LBB166_274:
Lloh180:
	adrp	x9, l_.str.39@PAGE
Lloh181:
	add	x9, x9, l_.str.39@PAGEOFF
LBB166_275:
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	mov	w9, #4                          ; =0x4
	b	LBB166_294
LBB166_276:
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w8, [x25, x8]
Lloh182:
	adrp	x9, l_.str.41@PAGE
Lloh183:
	add	x9, x9, l_.str.41@PAGEOFF
	b	LBB166_281
LBB166_277:
	mov	w8, #1                          ; =0x1
LBB166_278:
	str	w8, [x21, #1532]
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
	str	wzr, [x21, #1540]
Lloh184:
	adrp	x9, l_.str.30@PAGE
Lloh185:
	add	x9, x9, l_.str.30@PAGEOFF
	b	LBB166_201
LBB166_279:
Lloh186:
	adrp	x9, l_.str.40@PAGE
Lloh187:
	add	x9, x9, l_.str.40@PAGEOFF
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
	b	LBB166_294
LBB166_280:
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w8, [x25, x8]
Lloh188:
	adrp	x9, l_.str.43@PAGE
Lloh189:
	add	x9, x9, l_.str.43@PAGEOFF
LBB166_281:
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	mov	w9, #3                          ; =0x3
	b	LBB166_294
LBB166_282:
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #1532]
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [x21, #1536]
	str	wzr, [x21, #1540]
	mov	w8, #37400                      ; =0x9218
Lloh190:
	adrp	x9, l_.str.37@PAGE
Lloh191:
	add	x9, x9, l_.str.37@PAGEOFF
	b	LBB166_201
LBB166_283:
	mov	w8, #0                          ; =0x0
	mov	w9, #3                          ; =0x3
	b	LBB166_294
LBB166_284:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
	b	LBB166_292
LBB166_285:
	ldrb	w2, [sp, #279]
	mov	x0, x19
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	mov	x3, #0                          ; =0x0
LBB166_286:
	bl	_final_check_context
	cbz	w0, LBB166_261
; %bb.287:
	cbz	x23, LBB166_295
; %bb.288:
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB166_312
; %bb.289:
	mov	x0, x19
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
	mov	x1, x22
	mov	x2, x23
	bl	_uf_freeze
	mov	x25, #0                         ; =0x0
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
LBB166_290:
	ldr	x24, [sp, #176]                 ; 8-byte Folded Reload
	cbnz	w0, LBB166_316
	b	LBB166_93
LBB166_291:
	mov	w9, #1                          ; =0x1
LBB166_292:
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	ldr	w8, [x25, x8]
Lloh192:
	adrp	x10, l_.str.42@PAGE
Lloh193:
	add	x10, x10, l_.str.42@PAGEOFF
LBB166_293:
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
LBB166_294:
	str	w9, [x21, #1532]
	ldr	w9, [sp, #136]                  ; 4-byte Folded Reload
	str	w9, [x21, #1536]
	mov	w9, #37400                      ; =0x9218
	str	w8, [x21, #1540]
	mov	w8, #191                        ; =0xbf
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	stp	x8, x10, [sp]
Lloh194:
	adrp	x2, l_.str.52@PAGE
Lloh195:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x9
	b	LBB166_260
LBB166_295:
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_317
; %bb.296:
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_298
; %bb.297:
	mov	x0, x19
	mov	w1, #256                        ; =0x100
	bl	_analysis_work
	cbz	w0, LBB166_261
LBB166_298:
	mov	x0, x19
	bl	_ra_check_constraints
	cbz	w0, LBB166_261
; %bb.299:
	ldrb	w2, [sp, #279]
	mov	x0, x19
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	str	w2, [sp, #264]                  ; 4-byte Folded Spill
	bl	_map_final
	cbz	w0, LBB166_261
; %bb.300:
	cbz	x20, LBB166_353
; %bb.301:
	ldr	w8, [x21, #1736]
	cmp	w8, #256
	b.hi	LBB166_261
; %bb.302:
	ldr	w9, [x21, #752]
	cmp	w9, #64
	b.hi	LBB166_261
; %bb.303:
	lsl	x8, x8, #3
	add	x1, x8, #128
	mov	x0, x19
	bl	_analysis_work
	cbz	w0, LBB166_261
; %bb.304:
	ldr	w8, [x21, #752]
	cbz	w8, LBB166_346
; %bb.305:
	mov	x9, #0                          ; =0x0
	mov	x27, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	w10, #35904                     ; =0x8c40
	add	x10, x19, x10
	mov	w11, #1                         ; =0x1
LBB166_306:                             ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10, x9]
	lsl	x13, x11, x9
	orr	x13, x13, x27
	lsl	x14, x11, x9
	orr	x14, x14, x24
	cmp	w12, #0
	csel	x14, x24, x14, ne
	cmp	w12, #1
	csel	x24, x24, x14, eq
	csel	x27, x13, x27, eq
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB166_306
	b	LBB166_347
LBB166_307:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_324
; %bb.308:
	mov	w8, #0                          ; =0x0
	ldrb	w9, [x21, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	cinc	w9, w9, eq
	add	x10, sp, #368
	b	LBB166_293
LBB166_309:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_325
; %bb.310:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB166_326
LBB166_311:
Lloh196:
	adrp	x8, l_.str.35@PAGE
Lloh197:
	add	x8, x8, l_.str.35@PAGEOFF
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	ldr	x9, [sp, #160]                  ; 8-byte Folded Reload
	cbnz	x9, LBB166_203
	b	LBB166_258
LBB166_312:
	add	x2, sp, #352
	mov	x0, x19
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	bl	_uf_export_sites
	cbz	w0, LBB166_261
; %bb.313:
	add	x2, sp, #344
	mov	x0, x19
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	bl	_uf_freeze
	cbz	w0, LBB166_261
; %bb.314:
	mov	x25, #0                         ; =0x0
	ldr	x8, [sp, #344]
	str	x8, [x23]
	ldr	q0, [sp, #352]
	str	q0, [x28]
	stp	xzr, xzr, [sp, #344]
LBB166_315:
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	ldp	x24, x22, [sp, #176]            ; 16-byte Folded Reload
LBB166_316:
	str	wzr, [x21, #1532]
	mov	w8, #37400                      ; =0x9218
Lloh198:
	adrp	x9, l_.str.50@PAGE
Lloh199:
	add	x9, x9, l_.str.50@PAGEOFF
Lloh200:
	adrp	x10, l_.str.51@PAGE
Lloh201:
	add	x10, x10, l_.str.51@PAGEOFF
	cmp	x24, #0
	csel	x9, x10, x9, eq
Lloh202:
	adrp	x10, l_.str.49@PAGE
Lloh203:
	add	x10, x10, l_.str.49@PAGEOFF
	cmp	x22, #0
	csel	x9, x9, x10, eq
	str	x9, [sp]
Lloh204:
	adrp	x2, l_.str.2@PAGE
Lloh205:
	add	x2, x2, l_.str.2@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB166_92
LBB166_317:
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_327
; %bb.318:
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_320
; %bb.319:
	mov	x0, x19
	mov	w1, #256                        ; =0x100
	bl	_analysis_work
	cbz	w0, LBB166_261
LBB166_320:
	mov	x0, x19
	bl	_ra_check_constraints
	cbz	w0, LBB166_261
; %bb.321:
	mov	x0, x19
	ldr	x1, [sp, #216]                  ; 8-byte Folded Reload
	bl	_ra_publish
	cbz	w0, LBB166_261
; %bb.322:
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_339
; %bb.323:
	ldr	x8, [x21, #1744]
	mov	w9, #8208                       ; =0x2010
	add	x1, x8, x9
	ldr	x0, [sp, #200]                  ; 8-byte Folded Reload
	mov	w2, #512                        ; =0x200
	bl	_memcpy
	mov	x25, #0                         ; =0x0
	b	LBB166_315
LBB166_324:
	add	x9, sp, #368
	b	LBB166_275
LBB166_325:
	mov	w8, #1                          ; =0x1
LBB166_326:
	str	w8, [x21, #1532]
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
	str	wzr, [x21, #1540]
Lloh206:
	adrp	x9, l_.str.32@PAGE
Lloh207:
	add	x9, x9, l_.str.32@PAGEOFF
	b	LBB166_201
LBB166_327:
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_329
; %bb.328:
	mov	x0, x19
	ldr	x1, [sp, #256]                  ; 8-byte Folded Reload
	bl	_publish_records
	mov	x25, #0                         ; =0x0
	ldr	x9, [sp, #232]                  ; 8-byte Folded Reload
	ldr	x26, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #184]                 ; 8-byte Folded Reload
	b	LBB166_290
LBB166_329:
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_340
; %bb.330:
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	mov	w2, #1360                       ; =0x550
	bl	_analysis_alloc
	cbz	x0, LBB166_342
; %bb.331:
	mov	x22, x0
	add	x1, x21, #752
	mov	w2, #780                        ; =0x30c
	bl	_memcpy
	ldr	w8, [x21, #752]
	cbz	w8, LBB166_338
; %bb.332:
	cmp	w8, #4
	b.ls	LBB166_335
; %bb.333:
	add	x10, x22, #784
	add	x11, x22, #1296
	add	x9, x22, x8
	add	x9, x9, #1296
	cmp	x10, x9
	b.hs	LBB166_365
; %bb.334:
	add	x9, x22, x8, lsl #3
	add	x9, x9, #784
	cmp	x11, x9
	b.hs	LBB166_365
LBB166_335:
	mov	x9, #0                          ; =0x0
LBB166_336:
	add	x10, x19, x9, lsl #4
	mov	w11, #34842                     ; =0x881a
	add	x10, x10, x11
	add	x11, x22, x9, lsl #3
	add	x11, x11, #784
	add	x12, x9, x22
	add	x12, x12, #1296
	sub	x8, x8, x9
LBB166_337:                             ; =>This Inner Loop Header: Depth=1
	ldur	x9, [x10, #-10]
	str	x9, [x11], #8
	ldrb	w9, [x10], #16
	strb	w9, [x12], #1
	subs	x8, x8, #1
	b.ne	LBB166_337
LBB166_338:
	mov	x25, #0                         ; =0x0
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x22, [x8]
	b	LBB166_315
LBB166_339:
	mov	x25, #0                         ; =0x0
	b	LBB166_315
LBB166_340:
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	mov	w2, #780                        ; =0x30c
	bl	_analysis_alloc
	cbz	x0, LBB166_344
; %bb.341:
	mov	x22, x0
	mov	w8, #36608                      ; =0x8f00
	add	x1, x19, x8
	mov	w2, #780                        ; =0x30c
	bl	_memcpy
	mov	x25, #0                         ; =0x0
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	str	x22, [x8]
	b	LBB166_315
LBB166_342:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_361
; %bb.343:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB166_362
LBB166_344:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_367
; %bb.345:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB166_368
LBB166_346:
	mov	x24, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
LBB166_347:
	ldr	w1, [x21, #1736]
	cbz	w1, LBB166_353
; %bb.348:
	mov	x0, x19
	mov	w2, #16                         ; =0x10
	bl	_analysis_alloc
	cbz	x0, LBB166_363
; %bb.349:
	mov	x25, x0
	ldr	w8, [x21, #1736]
	str	x8, [sp, #248]                  ; 8-byte Folded Spill
	cbz	w8, LBB166_369
; %bb.350:
	mov	w8, #30736                      ; =0x7810
	add	x26, x19, x8
	add	x22, x25, #8
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
LBB166_351:                             ; =>This Inner Loop Header: Depth=1
	ldp	x23, x28, [x26, #-8]
	mov	x0, x23
	mov	x1, x28
	mov	x2, x24
	mov	x3, x27
	bl	_map_boundary_value_valid
	cbz	w0, LBB166_370
; %bb.352:                              ;   in Loop: Header=BB166_351 Depth=1
	add	x26, x26, #16
	stur	x23, [x22, #-8]
	strh	w28, [x22], #16
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	subs	x8, x8, #1
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	b.ne	LBB166_351
	b	LBB166_354
LBB166_353:
	str	xzr, [sp, #248]                 ; 8-byte Folded Spill
	mov	x25, #0                         ; =0x0
LBB166_354:
	mov	x0, x19
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #240]                  ; 8-byte Folded Reload
	bl	_map_freeze
	cbz	w0, LBB166_262
; %bb.355:
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_357
; %bb.356:
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #264]                  ; 4-byte Folded Reload
	strb	w9, [x8]
LBB166_357:
	cbz	x20, LBB166_359
; %bb.358:
	str	x25, [x20]
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	stp	w8, wzr, [x20, #8]
	mov	x25, #0                         ; =0x0
LBB166_359:
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	cbz	x8, LBB166_315
; %bb.360:
	ldr	x8, [x21, #1744]
	mov	w9, #8208                       ; =0x2010
	add	x1, x8, x9
	ldr	x0, [sp, #200]                  ; 8-byte Folded Reload
	mov	w2, #512                        ; =0x200
	bl	_memcpy
	b	LBB166_315
LBB166_361:
	mov	w8, #4                          ; =0x4
LBB166_362:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh208:
	adrp	x9, l_.str.47@PAGE
Lloh209:
	add	x9, x9, l_.str.47@PAGEOFF
	b	LBB166_201
LBB166_363:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_377
; %bb.364:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB166_378
LBB166_365:
	cmp	w8, #17
	b.hs	LBB166_372
; %bb.366:
	mov	x9, #0                          ; =0x0
	b	LBB166_375
LBB166_367:
	mov	w8, #4                          ; =0x4
LBB166_368:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh210:
	adrp	x9, l_.str.48@PAGE
Lloh211:
	add	x9, x9, l_.str.48@PAGEOFF
	b	LBB166_201
LBB166_369:
	str	xzr, [sp, #248]                 ; 8-byte Folded Spill
	b	LBB166_354
LBB166_370:
	ldr	x8, [x21, #1744]
	cbz	x8, LBB166_379
; %bb.371:
	ldrb	w8, [x21, #1776]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB166_380
LBB166_372:
	mov	w9, #34832                      ; =0x8810
	add	x12, x19, x9
	ands	x9, x8, #0xf
	mov	w13, #16                        ; =0x10
	csel	x13, x13, x9, eq
	sub	x9, x8, x13
	mov	x14, x8
LBB166_373:                             ; =>This Inner Loop Header: Depth=1
	mov	x15, x12
	ld2.2d	{ v0, v1 }, [x15], #32
	ld2.2d	{ v2, v3 }, [x15]
	add	x15, x12, #64
	ld2.2d	{ v4, v5 }, [x15]
	add	x15, x12, #96
	ld2.2d	{ v6, v7 }, [x15]
	add	x15, x12, #128
	ld2.2d	{ v16, v17 }, [x15]
	add	x15, x12, #160
	ld2.2d	{ v18, v19 }, [x15]
	add	x15, x12, #192
	ld2.2d	{ v20, v21 }, [x15]
	add	x15, x12, #224
	ld2.2d	{ v22, v23 }, [x15]
	stp	q20, q22, [x10, #96]
	stp	q16, q18, [x10, #64]
	stp	q4, q6, [x10, #32]
	stp	q0, q2, [x10], #128
	add	x15, x12, #26
	add	x16, x12, #42
	add	x17, x12, #58
	add	x0, x12, #74
	add	x1, x12, #90
	add	x2, x12, #106
	add	x3, x12, #122
	add	x4, x12, #154
	add	x5, x12, #170
	add	x6, x12, #186
	add	x7, x12, #202
	add	x20, x12, #218
	ldr	b0, [x12, #10]
	ld1.b	{ v0 }[1], [x15]
	ld1.b	{ v0 }[2], [x16]
	ld1.b	{ v0 }[3], [x17]
	ld1.b	{ v0 }[4], [x0]
	ld1.b	{ v0 }[5], [x1]
	ld1.b	{ v0 }[6], [x2]
	ld1.b	{ v0 }[7], [x3]
	add	x15, x12, #234
	ldur	b1, [x12, #138]
	ld1.b	{ v1 }[1], [x4]
	ld1.b	{ v1 }[2], [x5]
	ld1.b	{ v1 }[3], [x6]
	ld1.b	{ v1 }[4], [x7]
	ld1.b	{ v1 }[5], [x20]
	add	x16, x12, #250
	ld1.b	{ v1 }[6], [x15]
	ld1.b	{ v1 }[7], [x16]
	zip1.2d	v0, v0, v1
	str	q0, [x11], #16
	sub	x14, x14, #16
	add	x12, x12, #256
	cmp	x13, x14
	b.ne	LBB166_373
; %bb.374:
	cmp	x13, #5
	b.lo	LBB166_336
LBB166_375:
	mov	x10, x9
	ands	x9, x8, #0x3
	mov	w11, #4                         ; =0x4
	csel	x11, x11, x9, eq
	add	x12, x19, x10, lsl #4
	add	x13, x10, x22
	add	x14, x22, x10, lsl #3
	sub	x9, x8, x11
	add	x10, x11, x10
	sub	x10, x10, x8
	mov	w11, #34832                     ; =0x8810
	add	x11, x12, x11
	add	x12, x13, #1296
	add	x13, x14, #784
LBB166_376:                             ; =>This Inner Loop Header: Depth=1
	mov	x14, x11
	ld2.2d	{ v0, v1 }, [x14], #32
	ld2.2d	{ v2, v3 }, [x14]
	stp	q0, q2, [x13], #32
	add	x14, x11, #26
	add	x15, x11, #42
	ldr	b0, [x11, #10]
	ld1.b	{ v0 }[2], [x14]
	add	x14, x11, #58
	ld1.b	{ v0 }[4], [x15]
	ld1.b	{ v0 }[6], [x14]
	xtn.8b	v0, v0
	st1.s	{ v0 }[0], [x12], #4
	add	x11, x11, #64
	adds	x10, x10, #4
	b.ne	LBB166_376
	b	LBB166_336
LBB166_377:
	mov	w8, #4                          ; =0x4
LBB166_378:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh212:
	adrp	x9, l_.str.45@PAGE
Lloh213:
	add	x9, x9, l_.str.45@PAGEOFF
	b	LBB166_201
LBB166_379:
	mov	w8, #1                          ; =0x1
LBB166_380:
	str	w8, [x21, #1532]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1536]
	mov	w8, #37400                      ; =0x9218
Lloh214:
	adrp	x9, l_.str.46@PAGE
Lloh215:
	add	x9, x9, l_.str.46@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh216:
	adrp	x2, l_.str.52@PAGE
Lloh217:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB166_262
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpLdrGotLdr	Lloh123, Lloh124, Lloh125
	.loh AdrpLdrGotLdr	Lloh128, Lloh129, Lloh130
	.loh AdrpAdd	Lloh131, Lloh132
	.loh AdrpAdd	Lloh133, Lloh134
	.loh AdrpAdd	Lloh135, Lloh136
	.loh AdrpAdd	Lloh141, Lloh142
	.loh AdrpAdd	Lloh139, Lloh140
	.loh AdrpLdr	Lloh137, Lloh138
	.loh AdrpAdd	Lloh143, Lloh144
	.loh AdrpAdd	Lloh145, Lloh146
	.loh AdrpAdd	Lloh149, Lloh150
	.loh AdrpAdd	Lloh147, Lloh148
	.loh AdrpLdrGotLdr	Lloh151, Lloh152, Lloh153
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh192, Lloh193
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh196, Lloh197
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpLdrGot	Lloh121, Lloh122
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function analysis_alloc
_analysis_alloc:                        ; @analysis_alloc
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x19, x0, #9, lsl #12            ; =36864
	umulh	x9, x2, x1
	ldr	x8, [x19, #736]
	cbz	x9, LBB167_3
; %bb.1:
	cbz	x8, LBB167_6
LBB167_2:
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #768]
	b	LBB167_7
LBB167_3:
	cbz	x8, LBB167_8
; %bb.4:
	ldrb	w8, [x19, #768]
	tbnz	w8, #0, LBB167_6
; %bb.5:
	ldrb	w8, [x19, #769]
	tbz	w8, #0, LBB167_9
LBB167_6:
	mov	x0, #0                          ; =0x0
LBB167_7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB167_8:
	mov	x0, x1
	mov	x1, x2
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_calloc
LBB167_9:
	ldr	x8, [x19, #744]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB167_2
; %bb.10:
	mul	x9, x2, x1
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB167_2
; %bb.11:
	ldr	x10, [x19, #752]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x19, #744]
	b.hs	LBB167_13
; %bb.12:
	str	x8, [x19, #752]
LBB167_13:
	ldr	x8, [x19, #760]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB167_2
; %bb.14:
	sub	x9, x9, x8
	cmp	x1, x9
	b.hi	LBB167_2
; %bb.15:
	add	x8, x8, x1
	str	x8, [x19, #760]
	mov	x0, x1
	mov	x1, x2
	bl	_calloc
	cbnz	x0, LBB167_7
; %bb.16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #769]
	b	LBB167_7
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function map_declarations_exact
lCPI168_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_map_declarations_exact:                ; @map_declarations_exact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	add	x23, x0, #9, lsl #12            ; =36864
	ldr	x8, [x23, #736]
	cbz	x8, LBB168_7
; %bb.1:
	ldrb	w8, [x23, #768]
	tbnz	w8, #0, LBB168_5
; %bb.2:
	ldrb	w8, [x23, #769]
	tbnz	w8, #0, LBB168_5
; %bb.3:
	ldr	x8, [x23, #760]
	lsr	x9, x8, #24
	cbz	x9, LBB168_6
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #768]
LBB168_5:
Lloh218:
	adrp	x8, lCPI168_0@PAGE
Lloh219:
	ldr	d0, [x8, lCPI168_0@PAGEOFF]
	add	x8, x23, #524
	str	d0, [x8]
	str	wzr, [x23, #532]
	mov	w8, #37400                      ; =0x9218
Lloh220:
	adrp	x9, l_.str.101@PAGE
Lloh221:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh222:
	adrp	x2, l_.str.52@PAGE
Lloh223:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB168_21
LBB168_6:
	add	x8, x8, #1
	str	x8, [x23, #760]
LBB168_7:
	ldr	x0, [x21]
	add	x1, sp, #36
	bl	_nvm_map_declarations_counts
	tbz	w0, #0, LBB168_21
; %bb.8:
	ldr	w8, [sp, #40]
	cmp	w8, #1
	b.ne	LBB168_27
; %bb.9:
	mov	w22, #0                         ; =0x0
Lloh224:
	adrp	x24, l_.str.101@PAGE
Lloh225:
	add	x24, x24, l_.str.101@PAGEOFF
	mov	w25, #16777214                  ; =0xfffffe
LBB168_10:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #736]
	cbz	x8, LBB168_15
; %bb.11:                               ;   in Loop: Header=BB168_10 Depth=1
	ldrb	w8, [x23, #768]
	tbnz	w8, #0, LBB168_38
; %bb.12:                               ;   in Loop: Header=BB168_10 Depth=1
	ldrb	w8, [x23, #769]
	tbnz	w8, #0, LBB168_38
; %bb.13:                               ;   in Loop: Header=BB168_10 Depth=1
	ldr	x8, [x23, #760]
	cmp	x8, x25
	b.hs	LBB168_37
; %bb.14:                               ;   in Loop: Header=BB168_10 Depth=1
	add	x8, x8, #3
	str	x8, [x23, #760]
LBB168_15:                              ;   in Loop: Header=BB168_10 Depth=1
	ldr	x0, [x21]
	add	x2, sp, #28
	mov	x1, x22
	bl	_nvm_map_declarations_pair
	cbz	w0, LBB168_29
; %bb.16:                               ;   in Loop: Header=BB168_10 Depth=1
	ldr	x0, [x21]
	ldr	w1, [sp, #28]
	add	x2, sp, #27
	bl	_nvm_map_declarations_scalar
	cbz	w0, LBB168_29
; %bb.17:                               ;   in Loop: Header=BB168_10 Depth=1
	ldr	x0, [x21]
	ldr	w1, [sp, #32]
	add	x2, sp, #26
	bl	_nvm_map_declarations_scalar
	tbz	w0, #0, LBB168_29
; %bb.18:                               ;   in Loop: Header=BB168_10 Depth=1
	ldrb	w8, [sp, #27]
	cmp	w8, #5
	b.ne	LBB168_34
; %bb.19:                               ;   in Loop: Header=BB168_10 Depth=1
	ldrb	w8, [sp, #26]
	and	w9, w8, #0xfffffffb
	cmp	w9, #1
	b.ne	LBB168_34
; %bb.20:                               ;   in Loop: Header=BB168_10 Depth=1
	strb	w8, [x20]
	add	w22, w22, #1
	ldr	w8, [sp, #40]
	mov	w0, #1                          ; =0x1
	cmp	w22, w8
	b.lo	LBB168_10
	b	LBB168_26
LBB168_21:
	ldr	x9, [x23, #736]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB168_23
; %bb.22:
	ldrb	w9, [x23, #768]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB168_23:
	str	w8, [x23, #524]
	movi.2d	v0, #0000000000000000
	str	d0, [x23, #528]
	mov	w8, #37400                      ; =0x9218
Lloh226:
	adrp	x9, l_.str.53@PAGE
Lloh227:
	add	x9, x9, l_.str.53@PAGEOFF
LBB168_24:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
LBB168_25:
Lloh228:
	adrp	x2, l_.str.52@PAGE
Lloh229:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB168_26:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB168_27:
	ldr	x8, [x23, #736]
	cbz	x8, LBB168_32
; %bb.28:
	ldrb	w8, [x23, #768]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB168_33
LBB168_29:
	ldr	x9, [x23, #736]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB168_31
; %bb.30:
	ldrb	w9, [x23, #768]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB168_31:
Lloh230:
	adrp	x24, l_.str.55@PAGE
Lloh231:
	add	x24, x24, l_.str.55@PAGEOFF
	b	LBB168_39
LBB168_32:
	mov	w8, #1                          ; =0x1
LBB168_33:
	str	w8, [x23, #524]
	movi.2d	v0, #0000000000000000
	str	d0, [x23, #528]
	mov	w8, #37400                      ; =0x9218
Lloh232:
	adrp	x9, l_.str.54@PAGE
Lloh233:
	add	x9, x9, l_.str.54@PAGEOFF
	b	LBB168_24
LBB168_34:
	ldr	x8, [x23, #736]
	cbz	x8, LBB168_36
; %bb.35:
	ldrb	w8, [x23, #768]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
Lloh234:
	adrp	x24, l_.str.56@PAGE
Lloh235:
	add	x24, x24, l_.str.56@PAGEOFF
	b	LBB168_39
LBB168_36:
Lloh236:
	adrp	x24, l_.str.56@PAGE
Lloh237:
	add	x24, x24, l_.str.56@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB168_39
LBB168_37:
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #768]
Lloh238:
	adrp	x24, l_.str.101@PAGE
Lloh239:
	add	x24, x24, l_.str.101@PAGEOFF
LBB168_38:
	mov	w8, #3                          ; =0x3
LBB168_39:
	str	w8, [x23, #524]
	movi.2d	v0, #0000000000000000
	str	d0, [x23, #528]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x24, [sp]
	b	LBB168_25
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh238, Lloh239
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verified
_verified:                              ; @verified
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1]
	tbz	w8, #0, LBB169_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB169_2:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	add	x21, x0, #9, lsl #12            ; =36864
	add	x20, x1, #1
Lloh240:
	adrp	x1, l_.str.57@PAGE
Lloh241:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x20
	bl	_strstr
	mov	w22, #4                         ; =0x4
	cbnz	x0, LBB169_4
; %bb.3:
Lloh242:
	adrp	x1, l_.str.58@PAGE
Lloh243:
	add	x1, x1, l_.str.58@PAGEOFF
	mov	x0, x20
	bl	_strstr
	cmp	x0, #0
	mov	w8, #2                          ; =0x2
	csel	w22, w8, w22, eq
LBB169_4:
	ldr	x8, [x21, #736]
	cbz	x8, LBB169_6
; %bb.5:
	ldrb	w8, [x21, #768]
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w22, w9, w22, ne
LBB169_6:
	str	w22, [x21, #524]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #528]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x20, [sp]
Lloh244:
	adrp	x2, l_.str.52@PAGE
Lloh245:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_portable_file_read_import
_nvm_portable_file_read_import:         ; @nvm_portable_file_read_import
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB170_15
; %bb.1:
	ldr	w8, [x0, #432]
	cmp	w1, w8
	b.hs	LBB170_14
; %bb.2:
	ldr	x9, [x0, #400]
	cbz	x9, LBB170_14
; %bb.3:
	ldr	x11, [x0, #408]
	cbz	x11, LBB170_14
; %bb.4:
	ldr	x10, [x0, #232]
	cbz	x10, LBB170_14
; %bb.5:
	ldr	x8, [x0, #240]
	cbz	x8, LBB170_14
; %bb.6:
	mov	w12, #12                        ; =0xc
	umaddl	x13, w1, w12, x9
	ldr	w12, [x13]
	ldr	w14, [x0, #248]
	cmp	w12, w14
	b.hs	LBB170_14
; %bb.7:
	ldr	w9, [x13, #4]
	cmp	w9, w14
	b.hs	LBB170_14
; %bb.8:
	ldrb	w14, [x13, #11]
	cbnz	w14, LBB170_14
; %bb.9:
	ldrh	w14, [x13, #8]
	cmp	w14, #1
	b.ne	LBB170_14
; %bb.10:
	ldrb	w13, [x13, #10]
	orr	w14, w13, #0x2
	cmp	w14, #7
	b.ne	LBB170_14
; %bb.11:
	ldr	x11, [x11, w1, uxtw #3]
	cbz	x11, LBB170_14
; %bb.12:
	ldrb	w11, [x11]
	cmp	w11, #5
	b.ne	LBB170_14
; %bb.13:
	ldr	w11, [x8, x12, lsl #2]
	cbz	w11, LBB170_16
LBB170_14:
	mov	w0, #0                          ; =0x0
LBB170_15:
	ret
LBB170_16:
	ldr	x10, [x10, x9, lsl #3]
	cbz	x10, LBB170_14
; %bb.17:
	cmp	w13, #7
	b.eq	LBB170_23
; %bb.18:
	cmp	w13, #5
	b.ne	LBB170_14
; %bb.19:
	ldr	w11, [x8, x9, lsl #2]
	cmp	w11, #12
	b.eq	LBB170_34
; %bb.20:
	cmp	w11, #9
	b.ne	LBB170_35
; %bb.21:
	ldr	x8, [x10]
	ldrb	w9, [x10, #8]
	mov	x10, #26982                     ; =0x6966
	movk	x10, #25964, lsl #16
	movk	x10, #29279, lsl #32
	movk	x10, #24933, lsl #48
	cmp	x8, x10
	mov	w8, #100                        ; =0x64
	ccmp	w9, w8, #0, eq
	b.ne	LBB170_14
; %bb.22:
	mov	w0, #1                          ; =0x1
	ret
LBB170_23:
	ldr	w11, [x8, x9, lsl #2]
	cmp	w11, #18
	b.eq	LBB170_28
; %bb.24:
	cmp	w11, #15
	b.ne	LBB170_30
; %bb.25:
	ldr	x12, [x10]
	ldrb	w13, [x10, #8]
	mov	x14, #26982                     ; =0x6966
	movk	x14, #25964, lsl #16
	movk	x14, #29279, lsl #32
	movk	x14, #24933, lsl #48
	cmp	x12, x14
	mov	w12, #100                       ; =0x64
	ccmp	w13, w12, #0, eq
	b.ne	LBB170_14
; %bb.26:
	ldur	w12, [x10, #9]
	ldurh	w13, [x10, #13]
	mov	w14, #25183                     ; =0x625f
	movk	w14, #29817, lsl #16
	cmp	w12, w14
	mov	w12, #29541                     ; =0x7365
	ccmp	w13, w12, #0, eq
	b.eq	LBB170_33
; %bb.27:
	cmp	w11, #18
	b.ne	LBB170_30
LBB170_28:
	ldr	x11, [x10]
	ldr	w12, [x10, #8]
	mov	x13, #28022                     ; =0x6d76
	movk	x13, #26207, lsl #16
	movk	x13, #27753, lsl #32
	movk	x13, #24421, lsl #48
	cmp	x11, x13
	mov	w11, #25970                     ; =0x6572
	movk	w11, #25697, lsl #16
	ccmp	w12, w11, #0, eq
	b.ne	LBB170_30
; %bb.29:
	ldr	w11, [x10, #12]
	ldrh	w12, [x10, #16]
	mov	w13, #25183                     ; =0x625f
	movk	w13, #29817, lsl #16
	cmp	w11, w13
	mov	w11, #29541                     ; =0x7365
	ccmp	w12, w11, #0, eq
	b.eq	LBB170_33
LBB170_30:
	ldr	w8, [x8, x9, lsl #2]
	cmp	w8, #21
	b.ne	LBB170_14
; %bb.31:
	ldr	x8, [x10]
	ldur	x9, [x10, #7]
	mov	x11, #27758                     ; =0x6c6e
	movk	x11, #28511, lsl #16
	movk	x11, #24435, lsl #32
	movk	x11, #26982, lsl #48
	cmp	x8, x11
	mov	x8, #27753                      ; =0x6c69
	movk	x8, #24421, lsl #16
	movk	x8, #25970, lsl #32
	movk	x8, #25697, lsl #48
	ccmp	x9, x8, #0, eq
	b.ne	LBB170_14
; %bb.32:
	ldur	w8, [x10, #15]
	ldurh	w9, [x10, #19]
	mov	w10, #25183                     ; =0x625f
	movk	w10, #29817, lsl #16
	cmp	w8, w10
	mov	w8, #29541                      ; =0x7365
	ccmp	w9, w8, #0, eq
	b.ne	LBB170_14
LBB170_33:
	mov	w0, #2                          ; =0x2
	ret
LBB170_34:
	ldr	x11, [x10]
	ldr	w12, [x10, #8]
	mov	x13, #28022                     ; =0x6d76
	movk	x13, #26207, lsl #16
	movk	x13, #27753, lsl #32
	movk	x13, #24421, lsl #48
	cmp	x11, x13
	mov	w11, #25970                     ; =0x6572
	movk	w11, #25697, lsl #16
	ccmp	w12, w11, #0, eq
	b.eq	LBB170_37
LBB170_35:
	ldr	w8, [x8, x9, lsl #2]
	cmp	w8, #15
	b.ne	LBB170_14
; %bb.36:
	ldr	x8, [x10]
	ldur	x9, [x10, #7]
	mov	x10, #27758                     ; =0x6c6e
	movk	x10, #28511, lsl #16
	movk	x10, #24435, lsl #32
	movk	x10, #26982, lsl #48
	cmp	x8, x10
	mov	x8, #27753                      ; =0x6c69
	movk	x8, #24421, lsl #16
	movk	x8, #25970, lsl #32
	movk	x8, #25697, lsl #48
	ccmp	x9, x8, #0, eq
	b.ne	LBB170_14
LBB170_37:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function uf_prepare_records
lCPI171_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_uf_prepare_records:                    ; @uf_prepare_records
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x19, x0
	mov	w8, #35872                      ; =0x8c20
	add	x24, x0, x8
	ldr	x26, [x24, #1728]
	cbz	x26, LBB171_4
; %bb.1:
	ldrb	w8, [x24, #1760]
	tbnz	w8, #0, LBB171_22
; %bb.2:
	ldrb	w8, [x24, #1761]
	tbz	w8, #0, LBB171_17
LBB171_3:
	mov	w8, #4                          ; =0x4
	str	xzr, [x24]
	b	LBB171_24
LBB171_4:
	mov	w0, #1                          ; =0x1
	mov	w1, #48                         ; =0x30
	bl	_calloc
	str	x0, [x24]
	cbz	x0, LBB171_23
; %bb.5:
	mov	x21, x0
	mov	w0, #2                          ; =0x2
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x23, x0
	str	x0, [x21]
	mov	w0, #1                          ; =0x1
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x22, x0
	mov	x25, x21
	str	x0, [x25, #24]!
	mov	w0, #2                          ; =0x2
	mov	w1, #4                          ; =0x4
	bl	_calloc
LBB171_6:
	mov	x27, x21
	str	x0, [x27, #32]!
	cbz	x23, LBB171_15
; %bb.7:
	cbz	x22, LBB171_15
; %bb.8:
	cbz	x0, LBB171_15
; %bb.9:
	mov	w8, #2                          ; =0x2
	str	w8, [x21, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x21, #16]
	str	w8, [x21, #40]
	cbz	x26, LBB171_39
; %bb.10:
	ldrb	w8, [x24, #1760]
	tbnz	w8, #0, LBB171_14
LBB171_11:
	ldrb	w8, [x24, #1761]
	tbnz	w8, #0, LBB171_14
; %bb.12:
	ldr	x8, [x24, #1752]
	mov	w9, #65533                      ; =0xfffd
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.lo	LBB171_38
; %bb.13:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
LBB171_14:
Lloh246:
	adrp	x8, lCPI171_0@PAGE
Lloh247:
	ldr	d0, [x8, lCPI171_0@PAGEOFF]
	add	x8, x24, #1516
	str	d0, [x8]
	str	wzr, [x24, #1524]
	mov	w8, #37400                      ; =0x9218
Lloh248:
	adrp	x9, l_.str.101@PAGE
Lloh249:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB171_25
LBB171_15:
	cbz	x26, LBB171_28
LBB171_16:
	ldrb	w8, [x24, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB171_29
LBB171_17:
	mov	w25, #65444                     ; =0xffa4
	movk	w25, #1023, lsl #16
	ldr	x27, [x24, #1736]
	add	x8, x25, #44
	cmp	x27, x8
	b.hi	LBB171_21
; %bb.18:
	add	x8, x27, #48
	str	x8, [x24, #1736]
	ldr	x28, [x24, #1744]
	cmp	x28, x8
	b.hs	LBB171_20
; %bb.19:
	str	x8, [x24, #1744]
	mov	x28, x8
LBB171_20:
	ldr	x23, [x24, #1752]
	lsr	x8, x23, #24
	cbz	x8, LBB171_30
LBB171_21:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
LBB171_22:
	mov	w8, #3                          ; =0x3
	str	xzr, [x24]
	b	LBB171_24
LBB171_23:
	mov	w8, #4                          ; =0x4
LBB171_24:
	str	w8, [x24, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x24, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh250:
	adrp	x9, l_.str.63@PAGE
Lloh251:
	add	x9, x9, l_.str.63@PAGEOFF
LBB171_25:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
LBB171_26:
Lloh252:
	adrp	x2, l_.str.52@PAGE
Lloh253:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w22, #0                         ; =0x0
LBB171_27:
	mov	x0, x22
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB171_28:
	mov	w8, #4                          ; =0x4
LBB171_29:
	str	w8, [x24, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x24, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh254:
	adrp	x9, l_.str.64@PAGE
Lloh255:
	add	x9, x9, l_.str.64@PAGEOFF
	b	LBB171_25
LBB171_30:
	add	x8, x23, #1
	str	x8, [x24, #1752]
	mov	w22, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #48                         ; =0x30
	bl	_calloc
	cbz	x0, LBB171_37
; %bb.31:
	mov	x21, x0
	str	x0, [x24]
	add	x8, x25, #12
	cmp	x27, x8
	b.hi	LBB171_35
; %bb.32:
	add	x8, x27, #80
	str	x8, [x24, #1736]
	cmp	x28, x8
	b.hs	LBB171_34
; %bb.33:
	str	x8, [x24, #1744]
	mov	x28, x8
LBB171_34:
	mov	w22, #65533                     ; =0xfffd
	movk	w22, #255, lsl #16
	cmp	x23, x22
	b.ls	LBB171_62
LBB171_35:
	mov	x23, #0                         ; =0x0
LBB171_36:
	mov	x22, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
	add	x25, x21, #24
	b	LBB171_6
LBB171_37:
	strb	w22, [x24, #1761]
	b	LBB171_3
LBB171_38:
	add	x8, x8, #4
	str	x8, [x24, #1752]
LBB171_39:
	ldr	x0, [x20]
	mov	w1, #8                          ; =0x8
	mov	w2, #0                          ; =0x0
	mov	x3, x22
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB171_59
; %bb.40:
	mov	x22, #0                         ; =0x0
	mov	w8, #65444                      ; =0xffa4
	movk	w8, #1023, lsl #16
	add	x28, x8, #80
	mov	w8, #1                          ; =0x1
LBB171_41:                              ; =>This Inner Loop Header: Depth=1
	mov	x23, x8
	ldr	x8, [x24, #1728]
	cbz	x8, LBB171_46
; %bb.42:                               ;   in Loop: Header=BB171_41 Depth=1
	ldrb	w8, [x24, #1760]
	tbnz	w8, #0, LBB171_73
; %bb.43:                               ;   in Loop: Header=BB171_41 Depth=1
	ldrb	w8, [x24, #1761]
	tbnz	w8, #0, LBB171_73
; %bb.44:                               ;   in Loop: Header=BB171_41 Depth=1
	ldr	x8, [x24, #1752]
	mov	w9, #65529                      ; =0xfff9
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.hs	LBB171_82
; %bb.45:                               ;   in Loop: Header=BB171_41 Depth=1
	add	x8, x8, #8
	str	x8, [x24, #1752]
LBB171_46:                              ;   in Loop: Header=BB171_41 Depth=1
	ldr	x0, [x20]
	add	x2, sp, #24
	mov	x1, x22
	bl	_nvm_union_field_declarations_layout
	ldrh	w8, [sp, #26]
	cmp	w0, #0
	ccmp	w8, #1, #0, ne
	b.ne	LBB171_76
; %bb.47:                               ;   in Loop: Header=BB171_41 Depth=1
	ldr	x8, [x25]
	ldr	w8, [x8]
	cmp	x22, x8
	csetm	w8, ne
	ldr	x9, [x27]
	str	w8, [x9, x22, lsl #2]
	ldr	x8, [x21]
	add	x26, x8, x22, lsl #4
	ldrb	w8, [sp, #24]
	strb	w8, [x26]
	ldr	w8, [sp, #28]
	str	w8, [x26, #4]
	ldr	x8, [x24, #1728]
	cbz	x8, LBB171_56
; %bb.48:                               ;   in Loop: Header=BB171_41 Depth=1
	ldrb	w8, [x24, #1760]
	tbnz	w8, #0, LBB171_83
; %bb.49:                               ;   in Loop: Header=BB171_41 Depth=1
	ldrb	w8, [x24, #1761]
	tbnz	w8, #0, LBB171_85
; %bb.50:                               ;   in Loop: Header=BB171_41 Depth=1
	ldr	x8, [x24, #1736]
	cmp	x8, x28
	b.hi	LBB171_75
; %bb.51:                               ;   in Loop: Header=BB171_41 Depth=1
	add	x8, x8, #12
	str	x8, [x24, #1736]
	ldr	x9, [x24, #1744]
	cmp	x9, x8
	b.hs	LBB171_53
; %bb.52:                               ;   in Loop: Header=BB171_41 Depth=1
	str	x8, [x24, #1744]
LBB171_53:                              ;   in Loop: Header=BB171_41 Depth=1
	ldr	x8, [x24, #1752]
	lsr	x9, x8, #24
	cbnz	x9, LBB171_75
; %bb.54:                               ;   in Loop: Header=BB171_41 Depth=1
	add	x8, x8, #1
	str	x8, [x24, #1752]
	mov	w0, #1                          ; =0x1
	mov	w1, #12                         ; =0xc
	bl	_calloc
	cbz	x0, LBB171_84
; %bb.55:                               ;   in Loop: Header=BB171_41 Depth=1
	mov	x3, x0
	str	x0, [x26, #8]
	b	LBB171_57
LBB171_56:                              ;   in Loop: Header=BB171_41 Depth=1
	mov	w0, #1                          ; =0x1
	mov	w1, #12                         ; =0xc
	bl	_calloc
	mov	x3, x0
	str	x0, [x26, #8]
	cbz	x0, LBB171_89
LBB171_57:                              ;   in Loop: Header=BB171_41 Depth=1
	mov	w8, #1                          ; =0x1
	strh	w8, [x26, #2]
	ldr	x0, [x20]
	mov	x1, x22
	mov	w2, #0                          ; =0x0
	bl	_nvm_union_field_declarations_field
	tbz	w0, #0, LBB171_79
; %bb.58:                               ;   in Loop: Header=BB171_41 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w22, #1                         ; =0x1
	tbnz	w23, #0, LBB171_41
	b	LBB171_27
LBB171_59:
	ldr	x9, [x24, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB171_61
; %bb.60:
	ldrb	w9, [x24, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB171_61:
	str	w8, [x24, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x24, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh256:
	adrp	x9, l_.str.65@PAGE
Lloh257:
	add	x9, x9, l_.str.65@PAGEOFF
	b	LBB171_25
LBB171_62:
	str	x23, [sp, #16]                  ; 8-byte Folded Spill
	add	x8, x23, #3
	str	x8, [x24, #1752]
	mov	w0, #2                          ; =0x2
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x23, x0
	cbz	x0, LBB171_74
; %bb.63:
	str	x23, [x21]
	add	x8, x25, #8
	cmp	x27, x8
	b.hi	LBB171_36
; %bb.64:
	add	x8, x27, #84
	str	x8, [x24, #1736]
	cmp	x28, x8
	b.hs	LBB171_66
; %bb.65:
	str	x8, [x24, #1744]
	mov	x28, x8
LBB171_66:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x8, x22
	b.eq	LBB171_36
; %bb.67:
	add	x8, x8, #4
	str	x8, [x24, #1752]
	mov	w0, #1                          ; =0x1
	mov	w1, #4                          ; =0x4
	bl	_calloc
	cbz	x0, LBB171_74
; %bb.68:
	mov	x22, x0
	mov	w8, #65444                      ; =0xffa4
	movk	w8, #1023, lsl #16
	mov	x25, x21
	str	x0, [x25, #24]!
	cmp	x27, x8
	b.hi	LBB171_72
; %bb.69:
	add	x8, x27, #92
	str	x8, [x24, #1736]
	cmp	x28, x8
	b.hs	LBB171_71
; %bb.70:
	str	x8, [x24, #1744]
LBB171_71:
	mov	w8, #65533                      ; =0xfffd
	movk	w8, #255, lsl #16
	sub	x8, x8, #3
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x9, x8
	b.ls	LBB171_90
LBB171_72:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
	b	LBB171_16
LBB171_73:
	mov	w8, #3                          ; =0x3
Lloh258:
	adrp	x10, l_.str.101@PAGE
Lloh259:
	add	x10, x10, l_.str.101@PAGEOFF
	b	LBB171_88
LBB171_74:
	mov	x22, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1761]
	add	x25, x21, #24
	b	LBB171_6
LBB171_75:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
	mov	w8, #3                          ; =0x3
	b	LBB171_86
LBB171_76:
	ldr	x9, [x24, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB171_78
; %bb.77:
	ldrb	w9, [x24, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB171_78:
Lloh260:
	adrp	x10, l_.str.66@PAGE
Lloh261:
	add	x10, x10, l_.str.66@PAGEOFF
	b	LBB171_88
LBB171_79:
	ldr	x9, [x24, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB171_81
; %bb.80:
	ldrb	w9, [x24, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB171_81:
Lloh262:
	adrp	x10, l_.str.68@PAGE
Lloh263:
	add	x10, x10, l_.str.68@PAGEOFF
	b	LBB171_88
LBB171_82:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1760]
Lloh264:
	adrp	x10, l_.str.101@PAGE
Lloh265:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w8, #3                          ; =0x3
	b	LBB171_88
LBB171_83:
	mov	w8, #3                          ; =0x3
	b	LBB171_86
LBB171_84:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1761]
LBB171_85:
	mov	w8, #4                          ; =0x4
LBB171_86:
	str	xzr, [x26, #8]
LBB171_87:
Lloh266:
	adrp	x10, l_.str.67@PAGE
Lloh267:
	add	x10, x10, l_.str.67@PAGEOFF
LBB171_88:
	str	w8, [x24, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x24, #1520]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x10, [sp]
	b	LBB171_26
LBB171_89:
	mov	w8, #4                          ; =0x4
	b	LBB171_87
LBB171_90:
	add	x8, x9, #6
	str	x8, [x24, #1752]
	mov	w23, #2                         ; =0x2
	mov	w0, #2                          ; =0x2
	mov	w1, #4                          ; =0x4
	bl	_calloc
	cbz	x0, LBB171_92
; %bb.91:
	mov	x27, x21
	str	x0, [x27, #32]!
	stur	w23, [x27, #-24]
	mov	w8, #1                          ; =0x1
	stur	w8, [x27, #-16]
	str	w8, [x27, #8]
	ldrb	w8, [x24, #1760]
	tbz	w8, #0, LBB171_11
	b	LBB171_14
LBB171_92:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #1761]
	b	LBB171_16
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh266, Lloh267
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function prepare_records
_prepare_records:                       ; @prepare_records
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w8, #35872                      ; =0x8c20
	add	x20, x0, x8
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_7
; %bb.1:
	mov	x25, x1
	ldr	x0, [x8]
	add	x1, sp, #48
	bl	_nvm_ownership_declarations_counts
	ldr	x27, [x20, #1728]
	cbz	w0, LBB172_14
; %bb.2:
	ldr	w28, [sp, #48]
	cmp	w28, #257
	b.hs	LBB172_14
; %bb.3:
	cbz	x27, LBB172_17
; %bb.4:
	ldrb	w8, [x20, #1760]
	tbnz	w8, #0, LBB172_68
; %bb.5:
	ldrb	w8, [x20, #1761]
	tbz	w8, #0, LBB172_63
LBB172_6:
	mov	w8, #4                          ; =0x4
	str	xzr, [x20]
	b	LBB172_72
LBB172_7:
	ldr	x0, [x19]
	add	x8, sp, #48
	mov	x1, x20
	bl	_nvm_describe_managed_records
	ldr	w8, [sp, #48]
	sub	w9, w8, #3
	cmp	w9, #2
	b.lo	LBB172_55
; %bb.8:
	cbnz	w8, LBB172_54
; %bb.9:
	ldr	x8, [x20]
	ldr	w8, [x8, #40]
	cmp	w8, #1
	b.ne	LBB172_69
; %bb.10:
	sturb	wzr, [x29, #-92]
	ldr	x0, [x19]
	sub	x1, x29, #92
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB172_78
; %bb.11:
	ldurb	w8, [x29, #-92]
	tbnz	w8, #0, LBB172_78
; %bb.12:
	ldr	x11, [x20]
	ldr	w8, [x11, #16]
	mov	w0, #1                          ; =0x1
	cbz	w8, LBB172_77
; %bb.13:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x11]
	ldr	x11, [x11, #24]
	mov	w12, #575                       ; =0x23f
	b	LBB172_59
LBB172_14:
	mov	w8, #2                          ; =0x2
	cbz	x27, LBB172_16
; %bb.15:
	ldrb	w9, [x20, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB172_16:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh268:
	adrp	x9, l_.str.72@PAGE
Lloh269:
	add	x9, x9, l_.str.72@PAGEOFF
	b	LBB172_73
LBB172_17:
	mov	w0, #1                          ; =0x1
	mov	w1, #48                         ; =0x30
	bl	_calloc
	str	x0, [x20]
	cbz	x0, LBB172_71
; %bb.18:
	mov	x26, x0
	cmp	w28, #1
	csinc	w24, w28, wzr, hi
	mov	x0, x24
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x23, x0
	str	x0, [x26]
	mov	x0, x24
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x22, x0
	mov	x8, x26
	str	x0, [x8, #24]!
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	mov	x0, x24
	mov	w1, #4                          ; =0x4
	bl	_calloc
LBB172_19:
	mov	x21, x26
	str	x0, [x21, #32]!
	cbz	x23, LBB172_210
; %bb.20:
	cbz	x22, LBB172_210
LBB172_21:
	cbz	x0, LBB172_210
; %bb.22:
	str	w28, [x26, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x26, #40]
	cbz	w28, LBB172_92
; %bb.23:
	mov	x22, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	mov	w8, #37640                      ; =0x9308
	add	x8, x19, x8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w24, #16777216                  ; =0x1000000
LBB172_24:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB172_51 Depth 2
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	sub	x2, x29, #92
	mov	x1, x22
	bl	_nvm_ownership_declarations_layout
	tbz	w0, #0, LBB172_127
; %bb.25:                               ;   in Loop: Header=BB172_24 Depth=1
	ldurh	w23, [x29, #-90]
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_31
; %bb.26:                               ;   in Loop: Header=BB172_24 Depth=1
	ldrb	w9, [x20, #1760]
	tbnz	w9, #0, LBB172_126
; %bb.27:                               ;   in Loop: Header=BB172_24 Depth=1
	ldrb	w9, [x20, #1761]
	tbnz	w9, #0, LBB172_126
; %bb.28:                               ;   in Loop: Header=BB172_24 Depth=1
	ldr	x9, [x20, #1752]
	cmp	x9, x24
	b.hi	LBB172_144
; %bb.29:                               ;   in Loop: Header=BB172_24 Depth=1
	lsl	x10, x23, #2
	sub	x11, x24, x9
	cmp	x10, x11
	b.hs	LBB172_144
; %bb.30:                               ;   in Loop: Header=BB172_24 Depth=1
	mov	w10, #1                         ; =0x1
	bfi	x10, x23, #2, #16
	add	x9, x10, x9
	str	x9, [x20, #1752]
LBB172_31:                              ;   in Loop: Header=BB172_24 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	str	w27, [x9, x22, lsl #2]
	mov	w9, #65536                      ; =0x10000
	sub	w9, w9, w27
	cmp	w9, w23
	b.lo	LBB172_130
; %bb.32:                               ;   in Loop: Header=BB172_24 Depth=1
	ldr	x10, [x21]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x10, x22, lsl #2]
	ldurb	w9, [x29, #-92]
	cbz	w9, LBB172_35
; %bb.33:                               ;   in Loop: Header=BB172_24 Depth=1
	cmp	w9, #2
	b.ne	LBB172_145
; %bb.34:                               ;   in Loop: Header=BB172_24 Depth=1
	ldurb	w10, [x29, #-91]
	cbz	w10, LBB172_36
	b	LBB172_145
LBB172_35:                              ;   in Loop: Header=BB172_24 Depth=1
	ldr	w11, [x26, #16]
	str	w11, [x10, x22, lsl #2]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x10, [x10]
	add	w12, w11, #1
	str	w12, [x26, #16]
	str	w22, [x10, x11, lsl #2]
	ldurb	w10, [x29, #-91]
	cmp	w10, #1
	b.ne	LBB172_152
LBB172_36:                              ;   in Loop: Header=BB172_24 Depth=1
	str	w27, [sp, #32]                  ; 4-byte Folded Spill
	ldr	x10, [x26]
	add	x28, x10, x22, lsl #4
	strb	w9, [x28]
	ldur	w9, [x29, #-88]
	str	w9, [x28, #4]
	cbz	w23, LBB172_48
; %bb.37:                               ;   in Loop: Header=BB172_24 Depth=1
	cbz	x8, LBB172_49
; %bb.38:                               ;   in Loop: Header=BB172_24 Depth=1
	ldrb	w8, [x20, #1760]
	mov	w10, #67108864                  ; =0x4000000
	tbnz	w8, #0, LBB172_151
; %bb.39:                               ;   in Loop: Header=BB172_24 Depth=1
	ldrb	w8, [x20, #1761]
	tbnz	w8, #0, LBB172_201
; %bb.40:                               ;   in Loop: Header=BB172_24 Depth=1
	ldr	x8, [x20, #1736]
	cmp	x8, x10
	b.hi	LBB172_143
; %bb.41:                               ;   in Loop: Header=BB172_24 Depth=1
	add	x9, x23, x23, lsl #1
	lsl	x9, x9, #2
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB172_143
; %bb.42:                               ;   in Loop: Header=BB172_24 Depth=1
	ldr	x10, [x20, #1744]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x20, #1736]
	b.hs	LBB172_44
; %bb.43:                               ;   in Loop: Header=BB172_24 Depth=1
	str	x8, [x20, #1744]
LBB172_44:                              ;   in Loop: Header=BB172_24 Depth=1
	ldr	x8, [x20, #1752]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB172_143
; %bb.45:                               ;   in Loop: Header=BB172_24 Depth=1
	sub	x9, x9, x8
	cmp	x9, x23
	b.lo	LBB172_143
; %bb.46:                               ;   in Loop: Header=BB172_24 Depth=1
	add	x8, x8, x23
	str	x8, [x20, #1752]
	mov	x0, x23
	mov	w1, #12                         ; =0xc
	bl	_calloc
	cbz	x0, LBB172_200
; %bb.47:                               ;   in Loop: Header=BB172_24 Depth=1
	str	x0, [x28, #8]
	b	LBB172_50
LBB172_48:                              ;   in Loop: Header=BB172_24 Depth=1
	strh	wzr, [x28, #2]
	b	LBB172_53
LBB172_49:                              ;   in Loop: Header=BB172_24 Depth=1
	mov	x0, x23
	mov	w1, #12                         ; =0xc
	bl	_calloc
	str	x0, [x28, #8]
	cbz	x0, LBB172_207
LBB172_50:                              ;   in Loop: Header=BB172_24 Depth=1
	mov	x27, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	strh	w23, [x28, #2]
LBB172_51:                              ;   Parent Loop BB172_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	ldr	x8, [x28, #8]
	add	x3, x8, x27
	mov	x1, x22
	mov	x2, x24
	bl	_nvm_ownership_declarations_field
	tbz	w0, #0, LBB172_98
; %bb.52:                               ;   in Loop: Header=BB172_51 Depth=2
	add	x24, x24, #1
	ldurh	w8, [x29, #-90]
	add	x27, x27, #12
	cmp	x24, x8
	b.lo	LBB172_51
LBB172_53:                              ;   in Loop: Header=BB172_24 Depth=1
	ldr	w27, [sp, #32]                  ; 4-byte Folded Reload
	add	w27, w27, w23
	add	x22, x22, #1
	ldr	w8, [sp, #48]
	cmp	x22, x8
	mov	w24, #16777216                  ; =0x1000000
	b.lo	LBB172_24
	b	LBB172_93
LBB172_54:
	cmp	w8, #2
	mov	w8, #1                          ; =0x1
	cinc	w8, w8, eq
LBB172_55:
	ldr	x9, [sp, #64]
	ldr	x10, [x20, #1728]
	cbz	x10, LBB172_57
; %bb.56:
	ldrb	w10, [x20, #1760]
	mov	w11, #3                         ; =0x3
	cmp	w10, #0
	csel	w8, w11, w8, ne
LBB172_57:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
	b	LBB172_73
LBB172_58:                              ;   in Loop: Header=BB172_59 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB172_199
LBB172_59:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB172_61 Depth 2
	ldr	w13, [x11, x9, lsl #2]
	add	x14, x10, x13, lsl #4
	ldrh	w13, [x14, #2]
	cbz	x13, LBB172_58
; %bb.60:                               ;   in Loop: Header=BB172_59 Depth=1
	ldr	x14, [x14, #8]
LBB172_61:                              ;   Parent Loop BB172_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w15, [x14], #12
	cmp	w15, #8
	lsl	w15, w0, w15
	and	w15, w15, w12
	ccmp	w15, #0, #0, ne
	b.eq	LBB172_82
; %bb.62:                               ;   in Loop: Header=BB172_61 Depth=2
	subs	x13, x13, #1
	b.ne	LBB172_61
	b	LBB172_58
LBB172_63:
	mov	w22, #65488                     ; =0xffd0
	movk	w22, #1023, lsl #16
	ldr	x24, [x20, #1736]
	cmp	x24, x22
	b.hi	LBB172_67
; %bb.64:
	add	x21, x24, #48
	str	x21, [x20, #1736]
	ldr	x9, [x20, #1744]
	cmp	x9, x21
	b.hs	LBB172_66
; %bb.65:
	str	x21, [x20, #1744]
	mov	x9, x21
LBB172_66:
	ldr	x23, [x20, #1752]
	lsr	x8, x23, #24
	cbz	x8, LBB172_85
LBB172_67:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
LBB172_68:
	mov	w8, #3                          ; =0x3
	str	xzr, [x20]
	b	LBB172_72
LBB172_69:
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_80
; %bb.70:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB172_81
LBB172_71:
	mov	w8, #4                          ; =0x4
LBB172_72:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh270:
	adrp	x9, l_.str.73@PAGE
Lloh271:
	add	x9, x9, l_.str.73@PAGEOFF
LBB172_73:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
LBB172_74:
Lloh272:
	adrp	x2, l_.str.52@PAGE
Lloh273:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
LBB172_75:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB172_76:
	mov	w0, #0                          ; =0x0
LBB172_77:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB172_78:
	ldr	x9, [x20, #1728]
Lloh274:
	adrp	x8, l_.str.70@PAGE
Lloh275:
	add	x8, x8, l_.str.70@PAGEOFF
	cbz	x9, LBB172_83
LBB172_79:
	ldrb	w9, [x20, #1760]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	b	LBB172_84
LBB172_80:
	mov	w8, #1                          ; =0x1
LBB172_81:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh276:
	adrp	x9, l_.str.69@PAGE
Lloh277:
	add	x9, x9, l_.str.69@PAGEOFF
	b	LBB172_73
LBB172_82:
	ldr	x9, [x20, #1728]
Lloh278:
	adrp	x8, l_.str.71@PAGE
Lloh279:
	add	x8, x8, l_.str.71@PAGEOFF
	cbnz	x9, LBB172_79
LBB172_83:
	mov	w9, #1                          ; =0x1
LBB172_84:
	str	w9, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w9, #37400                      ; =0x9218
	mov	w10, #191                       ; =0xbf
	stp	x10, x8, [sp]
Lloh280:
	adrp	x2, l_.str.52@PAGE
Lloh281:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x9
	b	LBB172_75
LBB172_85:
	add	x8, x23, #1
	stp	x9, x8, [sp, #32]               ; 16-byte Folded Spill
	str	x8, [x20, #1752]
	mov	w0, #1                          ; =0x1
	mov	w1, #48                         ; =0x30
	bl	_calloc
	cbz	x0, LBB172_104
; %bb.86:
	mov	x26, x0
	str	x0, [x20]
	cmp	w28, #1
	csinc	w0, w28, wzr, hi
	ubfiz	x8, x0, #4, #32
	sub	x9, x22, x24
	cmp	x8, x9
	b.hi	LBB172_90
; %bb.87:
	add	x22, x21, x8
	ldr	x24, [sp, #32]                  ; 8-byte Folded Reload
	cmp	x24, x22
	str	x22, [x20, #1736]
	b.hs	LBB172_89
; %bb.88:
	str	x22, [x20, #1744]
	mov	x24, x22
LBB172_89:
	mov	w8, #16777215                   ; =0xffffff
	sub	x8, x8, x23
	cmp	x8, x0
	b.hs	LBB172_105
LBB172_90:
	mov	x23, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
	str	xzr, [x26]
LBB172_91:
	mov	x22, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	add	x8, x26, #24
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB172_19
LBB172_92:
	mov	w27, #0                         ; =0x0
LBB172_93:
	ldr	w8, [x26, #16]
	ldr	x9, [x19]
	ldr	w9, [x9, #468]
	cmp	w8, w9
	b.ne	LBB172_101
; %bb.94:
	cmp	w27, #1
	csinc	w0, w27, wzr, hi
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_121
; %bb.95:
	ldrb	w8, [x20, #1760]
	tbnz	w8, #0, LBB172_148
; %bb.96:
	ldrb	w8, [x20, #1761]
	tbz	w8, #0, LBB172_132
LBB172_97:
	mov	w8, #4                          ; =0x4
	b	LBB172_149
LBB172_98:
	ldr	x9, [x20, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB172_100
; %bb.99:
	ldrb	w9, [x20, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB172_100:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh282:
	adrp	x9, l_.str.80@PAGE
Lloh283:
	add	x9, x9, l_.str.80@PAGEOFF
	b	LBB172_73
LBB172_101:
	ldr	x9, [x20, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB172_103
; %bb.102:
	ldrb	w9, [x20, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB172_103:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh284:
	adrp	x9, l_.str.81@PAGE
Lloh285:
	add	x9, x9, l_.str.81@PAGEOFF
	b	LBB172_73
LBB172_104:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1761]
	b	LBB172_6
LBB172_105:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x21, x8, x0
	str	x21, [x20, #1752]
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x23, x0
	cbz	x0, LBB172_140
; %bb.106:
	str	x23, [x26]
	mov	w8, #67108864                   ; =0x4000000
	cmp	x22, x8
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	b.hi	LBB172_131
; %bb.107:
	lsl	x9, x0, #2
	sub	x8, x8, x22
	cmp	x9, x8
	b.hi	LBB172_131
; %bb.108:
	add	x10, x22, x9
	cmp	x24, x10
	str	x10, [x20, #1736]
	b.hs	LBB172_110
; %bb.109:
	str	x10, [x20, #1744]
	mov	x24, x10
LBB172_110:
	str	x24, [sp, #32]                  ; 8-byte Folded Spill
	mov	w8, #16777216                   ; =0x1000000
	cmp	x21, x8
	b.hi	LBB172_131
; %bb.111:
	sub	x8, x8, x21
	cmp	x8, x0
	b.lo	LBB172_131
; %bb.112:
	mov	x24, x10
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	add	x21, x21, x0
	str	x21, [x20, #1752]
	mov	w1, #4                          ; =0x4
	bl	_calloc
	cbz	x0, LBB172_215
; %bb.113:
	mov	x22, x0
	mov	x8, x26
	str	x0, [x8, #24]!
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	mov	w8, #67108864                   ; =0x4000000
	mov	x9, x24
	cmp	x24, x8
	ldr	x24, [sp, #16]                  ; 8-byte Folded Reload
	b.hi	LBB172_208
; %bb.114:
	sub	x8, x8, x9
	cmp	x24, x8
	b.hi	LBB172_208
; %bb.115:
	add	x8, x9, x24
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	cmp	x9, x8
	str	x8, [x20, #1736]
	b.hs	LBB172_117
; %bb.116:
	str	x8, [x20, #1744]
LBB172_117:
	mov	w8, #16777216                   ; =0x1000000
	cmp	x21, x8
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	b.hi	LBB172_208
; %bb.118:
	sub	x8, x8, x21
	cmp	x8, x0
	b.lo	LBB172_208
; %bb.119:
	add	x8, x21, x0
	str	x8, [x20, #1752]
	mov	w1, #4                          ; =0x4
	bl	_calloc
	cbnz	x0, LBB172_209
; %bb.120:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1761]
	b	LBB172_209
LBB172_121:
	mov	w1, #1                          ; =0x1
	bl	_calloc
	str	x0, [x20, #2792]
	cbz	x0, LBB172_142
; %bb.122:
	add	x24, x20, #2792
LBB172_123:
	ldr	w8, [sp, #56]
	lsl	x8, x8, #2
	add	x1, x8, w27, uxtw
	mov	x0, x19
	bl	_analysis_work
	cbz	w0, LBB172_77
; %bb.124:
	ldr	w8, [sp, #56]
	cbz	w8, LBB172_181
; %bb.125:
	mov	w22, #0                         ; =0x0
	add	w8, w27, #7
	lsr	w23, w8, #3
	mov	w8, #37640                      ; =0x9308
	add	x21, x19, x8
	mov	w27, #1                         ; =0x1
	mov	w28, #17                        ; =0x11
	b	LBB172_156
LBB172_126:
	mov	w8, #3                          ; =0x3
Lloh286:
	adrp	x10, l_.str.101@PAGE
Lloh287:
	add	x10, x10, l_.str.101@PAGEOFF
	b	LBB172_204
LBB172_127:
	ldr	x9, [x20, #1728]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB172_129
; %bb.128:
	ldrb	w9, [x20, #1760]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB172_129:
Lloh288:
	adrp	x10, l_.str.75@PAGE
Lloh289:
	add	x10, x10, l_.str.75@PAGEOFF
	b	LBB172_204
LBB172_130:
	mov	w8, #3                          ; =0x3
Lloh290:
	adrp	x10, l_.str.76@PAGE
Lloh291:
	add	x10, x10, l_.str.76@PAGEOFF
	b	LBB172_204
LBB172_131:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
	b	LBB172_91
LBB172_132:
	ldr	x8, [x20, #1736]
	mov	w9, #67108864                   ; =0x4000000
	cmp	x8, x9
	b.hi	LBB172_147
; %bb.133:
	sub	x9, x9, x8
	cmp	x9, x0
	b.lo	LBB172_147
; %bb.134:
	ldr	x9, [x20, #1744]
	add	x8, x8, x0
	cmp	x9, x8
	str	x8, [x20, #1736]
	b.hs	LBB172_136
; %bb.135:
	str	x8, [x20, #1744]
LBB172_136:
	ldr	x8, [x20, #1752]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB172_147
; %bb.137:
	sub	x9, x9, x8
	cmp	x9, x0
	b.lo	LBB172_147
; %bb.138:
	add	x8, x8, x0
	str	x8, [x20, #1752]
	mov	w21, #1                         ; =0x1
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB172_218
; %bb.139:
	add	x24, x20, #2792
	str	x0, [x20, #2792]
	b	LBB172_123
LBB172_140:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1761]
	str	xzr, [x26]
LBB172_141:
	mov	x22, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	x8, x26
	str	xzr, [x8, #24]!
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB172_19
LBB172_142:
	mov	w8, #4                          ; =0x4
	b	LBB172_150
LBB172_143:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
	mov	w8, #3                          ; =0x3
	b	LBB172_202
LBB172_144:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
Lloh292:
	adrp	x10, l_.str.101@PAGE
Lloh293:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w8, #3                          ; =0x3
	b	LBB172_204
LBB172_145:
	cbz	x8, LBB172_206
; %bb.146:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
Lloh294:
	adrp	x10, l_.str.78@PAGE
Lloh295:
	add	x10, x10, l_.str.78@PAGEOFF
	b	LBB172_204
LBB172_147:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
LBB172_148:
	mov	w8, #3                          ; =0x3
LBB172_149:
	str	xzr, [x20, #2792]
LBB172_150:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh296:
	adrp	x9, l_.str.82@PAGE
Lloh297:
	add	x9, x9, l_.str.82@PAGEOFF
	b	LBB172_73
LBB172_151:
	mov	w8, #3                          ; =0x3
	b	LBB172_202
LBB172_152:
	cbz	x8, LBB172_214
; %bb.153:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
Lloh298:
	adrp	x10, l_.str.77@PAGE
Lloh299:
	add	x10, x10, l_.str.77@PAGEOFF
	b	LBB172_204
LBB172_154:                             ;   in Loop: Header=BB172_156 Depth=1
	ldur	w9, [x29, #-92]
	ldr	w9, [x21, x9, lsl #2]
	ldurh	w10, [x29, #-88]
	add	w9, w9, w10
	cmp	w8, #3
	mov	w10, #-14                       ; =0xfffffff2
	cinc	w10, w10, ne
	cmp	w8, #2
	mov	w8, #-15                        ; =0xfffffff1
	csel	w8, w8, w10, eq
	ldr	x10, [x20, #2792]
	strb	w8, [x10, w9, uxtw]
	ldrb	w8, [sp, #84]
	cmp	w8, #3
	mov	w9, #8                          ; =0x8
	mov	w10, #4                         ; =0x4
	csel	w9, w10, w9, eq
	cmp	w8, #2
	csel	w8, w8, w9, eq
	ldrb	w9, [x20, #2808]
	orr	w8, w8, w9
	strb	w8, [x20, #2808]
LBB172_155:                             ;   in Loop: Header=BB172_156 Depth=1
	add	w22, w22, #1
	ldr	w8, [sp, #56]
	cmp	w22, w8
	b.hs	LBB172_181
LBB172_156:                             ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	sub	x2, x29, #92
	mov	x1, x22
	bl	_nvm_ownership_declarations_binding
	cbz	w0, LBB172_205
; %bb.157:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	ldur	w1, [x29, #-84]
	add	x2, sp, #92
	bl	_nvm_ownership_declarations_type
	cbz	w0, LBB172_205
; %bb.158:                              ;   in Loop: Header=BB172_156 Depth=1
	ldur	w8, [x29, #-92]
	ldr	w9, [x26, #8]
	cmp	w8, w9
	b.hs	LBB172_205
; %bb.159:                              ;   in Loop: Header=BB172_156 Depth=1
	ldurh	w9, [x29, #-88]
	ldr	x10, [x26]
	add	x10, x10, x8, lsl #4
	ldrh	w10, [x10, #2]
	cmp	w9, w10
	b.hs	LBB172_205
; %bb.160:                              ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w10, [sp, #92]
	cmp	w10, #7
	b.ne	LBB172_168
; %bb.161:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	ldr	w1, [sp, #96]
	add	x2, sp, #84
	bl	_nvm_ownership_declarations_type
	tbz	w0, #0, LBB172_219
; %bb.162:                              ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w8, [sp, #84]
	cmp	w8, #7
	b.ne	LBB172_171
; %bb.163:                              ;   in Loop: Header=BB172_156 Depth=1
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	bl	_analysis_work
	cbz	w0, LBB172_76
; %bb.164:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	x8, [x20, #1728]
	ldr	x0, [x8]
	ldr	w1, [sp, #88]
	add	x2, sp, #76
	bl	_nvm_ownership_declarations_type
	cbz	w0, LBB172_227
; %bb.165:                              ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w8, [sp, #76]
	sub	w9, w8, #6
	and	w9, w9, #0xff
	cmp	w9, #251
	b.lo	LBB172_227
; %bb.166:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	w9, [sp, #80]
	cmn	w9, #1
	b.ne	LBB172_227
; %bb.167:                              ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w9, [x20, #2808]
	sub	w10, w8, #2
	ubfiz	x11, x10, #3, #5
	mov	w12, #5395                      ; =0x1513
	movk	w12, #12569, lsl #16
	lsr	w11, w12, w11
	tst	w10, #0xfc
	csel	w10, w11, w28, eq
	orr	w9, w9, w10
	strb	w9, [x20, #2808]
	sub	w8, w8, #13
	ldr	x9, [x20, #2792]
	ldur	w10, [x29, #-92]
	ldr	w10, [x21, x10, lsl #2]
	ldurh	w11, [x29, #-88]
	add	w10, w10, w11
	strb	w8, [x9, w10, uxtw]
	b	LBB172_155
LBB172_168:                             ;   in Loop: Header=BB172_156 Depth=1
	sub	w11, w10, #1
	cmp	w11, #4
	b.hi	LBB172_220
; %bb.169:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	w11, [sp, #96]
	cmn	w11, #1
	b.ne	LBB172_220
LBB172_170:                             ;   in Loop: Header=BB172_156 Depth=1
	lsl	w10, w27, w10
	ldr	x11, [x24]
	ldr	w8, [x21, x8, lsl #2]
	add	w8, w8, w9
	strb	w10, [x11, w8, uxtw]
	b	LBB172_155
LBB172_171:                             ;   in Loop: Header=BB172_156 Depth=1
	sub	w9, w8, #6
	cmn	w9, #5
	b.lo	LBB172_219
; %bb.172:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	w9, [sp, #88]
	cmn	w9, #1
	b.ne	LBB172_219
; %bb.173:                              ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w9, [x20, #2808]
	orr	w9, w9, #0x1
	strb	w9, [x20, #2808]
	sub	w9, w8, #2
	cmp	w9, #3
	b.lo	LBB172_154
; %bb.174:                              ;   in Loop: Header=BB172_156 Depth=1
	cmp	w8, #5
	b.ne	LBB172_180
; %bb.175:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	x8, [x20, #2800]
	cbnz	x8, LBB172_179
; %bb.176:                              ;   in Loop: Header=BB172_156 Depth=1
	mov	x0, x19
	mov	x1, x23
	mov	w2, #1                          ; =0x1
	bl	_analysis_alloc
	str	x0, [x20, #2800]
	cbz	x0, LBB172_233
; %bb.177:                              ;   in Loop: Header=BB172_156 Depth=1
	mov	x0, x19
	mov	x1, x23
	bl	_analysis_work
	cbz	w0, LBB172_76
; %bb.178:                              ;   in Loop: Header=BB172_156 Depth=1
	ldr	x8, [x20, #2800]
LBB172_179:                             ;   in Loop: Header=BB172_156 Depth=1
	ldur	w9, [x29, #-92]
	ldr	w9, [x21, x9, lsl #2]
	ldurh	w10, [x29, #-88]
	add	w9, w9, w10
	and	w10, w9, #0x7
	lsl	w10, w27, w10
	lsr	x9, x9, #3
	ldrb	w11, [x8, x9]
	orr	w10, w11, w10
	strb	w10, [x8, x9]
	b	LBB172_155
LBB172_180:                             ;   in Loop: Header=BB172_156 Depth=1
	ldrb	w10, [sp, #92]
	ldur	w8, [x29, #-92]
	ldurh	w9, [x29, #-88]
	b	LBB172_170
LBB172_181:
	ldr	w8, [x26, #8]
	cbz	w8, LBB172_199
; %bb.182:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x26]
	mov	w11, #37640                     ; =0x9308
	add	x11, x19, x11
	mov	w12, #2048                      ; =0x800
	b	LBB172_184
LBB172_183:                             ;   in Loop: Header=BB172_184 Depth=1
	add	x9, x9, #1
	mov	w0, #1                          ; =0x1
	cmp	x9, x8
	b.eq	LBB172_77
LBB172_184:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB172_189 Depth 2
	add	x15, x10, x9, lsl #4
	ldrb	w13, [x15]
	cbnz	w13, LBB172_183
; %bb.185:                              ;   in Loop: Header=BB172_184 Depth=1
	ldrh	w13, [x15, #2]
	cbz	x13, LBB172_183
; %bb.186:                              ;   in Loop: Header=BB172_184 Depth=1
	mov	x14, #0                         ; =0x0
	ldr	x15, [x15, #8]
	b	LBB172_189
LBB172_187:                             ;   in Loop: Header=BB172_189 Depth=2
	tst	w16, #0xffff
	b.eq	LBB172_225
LBB172_188:                             ;   in Loop: Header=BB172_189 Depth=2
	add	x14, x14, #1
	cmp	x13, x14
	b.eq	LBB172_183
LBB172_189:                             ;   Parent Loop BB172_184 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w16, [x15], #12
	sub	w17, w16, #1
	cmp	w17, #5
	ccmp	w16, #8, #4, hs
	b.eq	LBB172_188
; %bb.190:                              ;   in Loop: Header=BB172_189 Depth=2
	cmp	w16, #7
	b.ne	LBB172_196
; %bb.191:                              ;   in Loop: Header=BB172_189 Depth=2
	ldr	w16, [x11, x9, lsl #2]
	add	x16, x14, x16
	ldr	x17, [x20, #2800]
	cbz	x17, LBB172_193
; %bb.192:                              ;   in Loop: Header=BB172_189 Depth=2
	lsr	w0, w16, #3
	ldrb	w17, [x17, x0]
	and	w0, w16, #0x7
	lsr	w17, w17, w0
	tbnz	w17, #0, LBB172_188
LBB172_193:                             ;   in Loop: Header=BB172_189 Depth=2
	ldr	x17, [x24]
	ldrb	w16, [x17, w16, uxtw]
	add	w17, w16, #12
	and	w17, w17, #0xff
	cmp	w17, #4
	b.hi	LBB172_198
; %bb.194:                              ;   in Loop: Header=BB172_189 Depth=2
	add	w16, w16, #13
	and	w17, w16, #0xff
	cmp	w17, #5
	b.eq	LBB172_188
; %bb.195:                              ;   in Loop: Header=BB172_189 Depth=2
	lsl	w16, w12, w16
	b	LBB172_187
LBB172_196:                             ;   in Loop: Header=BB172_189 Depth=2
	cbz	x25, LBB172_216
; %bb.197:                              ;   in Loop: Header=BB172_189 Depth=2
	cmp	w16, #13
	b.eq	LBB172_188
	b	LBB172_216
LBB172_198:                             ;   in Loop: Header=BB172_189 Depth=2
	add	w17, w16, #15
	and	w17, w17, #0xff
	cmp	w17, #3
	b.lo	LBB172_188
	b	LBB172_187
LBB172_199:
	mov	w0, #1                          ; =0x1
	b	LBB172_77
LBB172_200:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1761]
LBB172_201:
	mov	w8, #4                          ; =0x4
LBB172_202:
	str	xzr, [x28, #8]
LBB172_203:
Lloh300:
	adrp	x10, l_.str.79@PAGE
Lloh301:
	add	x10, x10, l_.str.79@PAGEOFF
LBB172_204:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x10, [sp]
	b	LBB172_74
LBB172_205:
	ldr	x10, [x20, #1728]
Lloh302:
	adrp	x8, l_.str.83@PAGE
Lloh303:
	add	x8, x8, l_.str.83@PAGEOFF
	mov	w9, #2                          ; =0x2
	cbnz	x10, LBB172_222
	b	LBB172_84
LBB172_206:
Lloh304:
	adrp	x10, l_.str.78@PAGE
Lloh305:
	add	x10, x10, l_.str.78@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB172_204
LBB172_207:
	mov	w8, #4                          ; =0x4
	b	LBB172_203
LBB172_208:
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1760]
LBB172_209:
	mov	x21, x26
	str	x0, [x21, #32]!
	cbnz	x22, LBB172_21
LBB172_210:
	cbz	x27, LBB172_212
; %bb.211:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB172_213
LBB172_212:
	mov	w8, #4                          ; =0x4
LBB172_213:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh306:
	adrp	x9, l_.str.74@PAGE
Lloh307:
	add	x9, x9, l_.str.74@PAGEOFF
	b	LBB172_73
LBB172_214:
Lloh308:
	adrp	x10, l_.str.77@PAGE
Lloh309:
	add	x10, x10, l_.str.77@PAGEOFF
	mov	w8, #1                          ; =0x1
	b	LBB172_204
LBB172_215:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1761]
	b	LBB172_141
LBB172_216:
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_223
; %bb.217:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB172_224
LBB172_218:
	strb	w21, [x20, #1761]
	b	LBB172_97
LBB172_219:
	ldr	x10, [x20, #1728]
Lloh310:
	adrp	x8, l_.str.84@PAGE
Lloh311:
	add	x8, x8, l_.str.84@PAGEOFF
	b	LBB172_221
LBB172_220:
	ldr	x10, [x20, #1728]
Lloh312:
	adrp	x8, l_.str.87@PAGE
Lloh313:
	add	x8, x8, l_.str.87@PAGEOFF
LBB172_221:
	mov	w9, #1                          ; =0x1
	cbz	x10, LBB172_84
LBB172_222:
	ldrb	w10, [x20, #1760]
	mov	w11, #3                         ; =0x3
	cmp	w10, #0
	csel	w9, w11, w9, ne
	b	LBB172_84
LBB172_223:
	mov	w8, #1                          ; =0x1
LBB172_224:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh314:
	adrp	x9, l_.str.89@PAGE
Lloh315:
	add	x9, x9, l_.str.89@PAGEOFF
	b	LBB172_73
LBB172_225:
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_229
; %bb.226:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB172_230
LBB172_227:
	ldr	x8, [x20, #1728]
	cbz	x8, LBB172_231
; %bb.228:
	ldrb	w8, [x20, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB172_232
LBB172_229:
	mov	w8, #1                          ; =0x1
LBB172_230:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh316:
	adrp	x9, l_.str.88@PAGE
Lloh317:
	add	x9, x9, l_.str.88@PAGEOFF
	b	LBB172_73
LBB172_231:
	mov	w8, #1                          ; =0x1
LBB172_232:
	str	w8, [x20, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x20, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh318:
	adrp	x9, l_.str.85@PAGE
Lloh319:
	add	x9, x9, l_.str.85@PAGEOFF
	b	LBB172_73
LBB172_233:
	ldr	x10, [x20, #1728]
Lloh320:
	adrp	x8, l_.str.86@PAGE
Lloh321:
	add	x8, x8, l_.str.86@PAGEOFF
	mov	w9, #4                          ; =0x4
	cbnz	x10, LBB172_222
	b	LBB172_84
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh320, Lloh321
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function global_prepare
lCPI173_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_global_prepare:                        ; @global_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w8, #34824                      ; =0x8808
	add	x21, x0, x8
	ldr	x23, [x21, #2776]
	cbz	x23, LBB173_113
; %bb.1:
	ldrb	w8, [x21, #2808]
	tbnz	w8, #0, LBB173_5
; %bb.2:
	ldrb	w8, [x21, #2809]
	tbnz	w8, #0, LBB173_5
; %bb.3:
	mov	w9, #57080                      ; =0xdef8
	movk	w9, #255, lsl #16
	ldr	x8, [x21, #2800]
	cmp	x8, x9
	b.ls	LBB173_8
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2808]
LBB173_5:
Lloh322:
	adrp	x8, lCPI173_0@PAGE
Lloh323:
	ldr	d0, [x8, lCPI173_0@PAGEOFF]
	add	x8, x21, #2564
	str	d0, [x8]
	str	wzr, [x21, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh324:
	adrp	x9, l_.str.101@PAGE
Lloh325:
	add	x9, x9, l_.str.101@PAGEOFF
LBB173_6:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh326:
	adrp	x2, l_.str.52@PAGE
Lloh327:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
LBB173_7:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	b	LBB173_114
LBB173_8:
	mov	w10, #8456                      ; =0x2108
	add	x10, x8, x10
	str	x10, [x21, #2800]
	ldr	x10, [x21, #2784]
	mov	w11, #57081                     ; =0xdef9
	movk	w11, #1023, lsl #16
	cmp	x10, x11
	b.hs	LBB173_12
; %bb.9:
	mov	w11, #8456                      ; =0x2108
	ldr	x12, [x21, #2792]
	add	x10, x10, x11
	cmp	x12, x10
	str	x10, [x21, #2784]
	b.hs	LBB173_11
; %bb.10:
	str	x10, [x21, #2792]
LBB173_11:
	cmp	x8, x9
	b.ne	LBB173_14
LBB173_12:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2808]
	mov	w8, #3                          ; =0x3
LBB173_13:
	str	xzr, [x21]
	str	w8, [x21, #2564]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #2568]
	mov	w8, #37400                      ; =0x9218
Lloh328:
	adrp	x9, l_.str.90@PAGE
Lloh329:
	add	x9, x9, l_.str.90@PAGEOFF
	b	LBB173_6
LBB173_14:
	mov	x22, x0
	mov	w9, #8457                       ; =0x2109
	add	x8, x8, x9
	str	x8, [x21, #2800]
	mov	w19, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #8456                       ; =0x2108
	bl	_calloc
	cbz	x0, LBB173_28
; %bb.15:
	str	x0, [x21]
	mov	x8, x22
	ldr	x9, [x22]
	ldr	w19, [x9, #272]
	cbz	w19, LBB173_81
; %bb.16:
	mov	x9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	add	x20, x23, #16
	mov	w11, #104                       ; =0x68
	mov	w12, #16777215                  ; =0xffffff
	mov	w13, #1                         ; =0x1
	b	LBB173_18
LBB173_17:                              ;   in Loop: Header=BB173_18 Depth=1
	add	x9, x9, #1
	cmp	x9, x19
	b.eq	LBB173_30
LBB173_18:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_21 Depth 2
	add	x14, x20, x9, lsl #5
	ldr	w16, [x14, #8]
	cbz	w16, LBB173_17
; %bb.19:                               ;   in Loop: Header=BB173_18 Depth=1
	mov	x15, #0                         ; =0x0
	umull	x16, w16, w11
	b	LBB173_21
LBB173_20:                              ;   in Loop: Header=BB173_21 Depth=2
	orr	w10, w10, w17
	add	x15, x15, #104
	cmp	x16, x15
	b.eq	LBB173_17
LBB173_21:                              ;   Parent Loop BB173_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x17, [x21, #2800]
	cmp	x17, x12
	b.hs	LBB173_115
; %bb.22:                               ;   in Loop: Header=BB173_21 Depth=2
	add	x17, x17, #2
	str	x17, [x21, #2800]
	ldr	x2, [x14]
	add	x0, x2, x15
	ldrb	w1, [x0, #40]
	cmp	w1, #51
	cset	w17, eq
	and	w3, w1, #0xfe
	cmp	w3, #18
	b.ne	LBB173_20
; %bb.23:                               ;   in Loop: Header=BB173_21 Depth=2
	ldr	w0, [x0, #48]
	cmp	w0, #256
	b.hs	LBB173_29
; %bb.24:                               ;   in Loop: Header=BB173_21 Depth=2
	ldr	w2, [x21, #2768]
	cmp	w2, w0
	b.hi	LBB173_26
; %bb.25:                               ;   in Loop: Header=BB173_21 Depth=2
	add	w2, w0, #1
	str	w2, [x21, #2768]
LBB173_26:                              ;   in Loop: Header=BB173_21 Depth=2
	cmp	w1, #19
	b.ne	LBB173_20
; %bb.27:                               ;   in Loop: Header=BB173_21 Depth=2
	lsl	x1, x13, x0
	ldr	x2, [x21]
	add	x2, x2, x9, lsl #5
	lsr	w0, w0, #6
	add	x0, x2, w0, uxtw #3
	ldr	x2, [x0, #8]
	orr	x1, x2, x1
	str	x1, [x0, #8]
	b	LBB173_20
LBB173_28:
	strb	w19, [x21, #2809]
	mov	w8, #4                          ; =0x4
	mov	x0, x22
	b	LBB173_13
LBB173_29:
	ldr	w10, [x2, x15]
	mov	w11, #3                         ; =0x3
	str	w11, [x21, #2564]
	str	w9, [x21, #2568]
	str	w10, [x21, #2572]
	mov	w9, #37400                      ; =0x9218
Lloh330:
	adrp	x10, l_.str.91@PAGE
Lloh331:
	add	x10, x10, l_.str.91@PAGEOFF
	b	LBB173_117
LBB173_30:
	cbz	w10, LBB173_81
; %bb.31:
	lsl	x9, x19, #5
	ldr	x10, [x21, #2784]
	mov	w11, #67108864                  ; =0x4000000
	sub	x12, x11, x10
	cmp	x10, x11
	ccmp	x9, x12, #2, ls
	b.ls	LBB173_33
; %bb.32:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #2808]
	mov	w9, #3                          ; =0x3
	b	LBB173_51
LBB173_33:
	str	x23, [sp, #24]                  ; 8-byte Folded Spill
	ldr	x11, [x21, #2792]
	add	x8, x10, x9
	cmp	x11, x8
	str	x8, [x21, #2784]
	b.hs	LBB173_35
; %bb.34:
	str	x8, [x21, #2792]
LBB173_35:
	ldr	x8, [x21, #2800]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB173_39
; %bb.36:
	sub	x9, x9, x8
	cmp	x9, x19
	b.lo	LBB173_39
; %bb.37:
	add	x24, x8, x19
	str	x24, [x21, #2800]
	mov	x0, x19
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB173_49
; %bb.38:
	mov	x23, x0
	mov	x8, #0                          ; =0x0
	mov	w9, #16777216                   ; =0x1000000
	mov	x10, #-16777216                 ; =0xffffffffff000000
	mov	w11, #104                       ; =0x68
	mov	w12, #1                         ; =0x1
	b	LBB173_41
LBB173_39:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2808]
	mov	w9, #3                          ; =0x3
	b	LBB173_50
LBB173_40:                              ;   in Loop: Header=BB173_41 Depth=1
	add	x8, x8, #1
	cmp	x8, x19
	b.eq	LBB173_52
LBB173_41:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_45 Depth 2
	add	x13, x20, x8, lsl #5
	ldr	w16, [x13, #8]
	cbz	w16, LBB173_40
; %bb.42:                               ;   in Loop: Header=BB173_41 Depth=1
	mov	x14, #0                         ; =0x0
	cmp	x24, x9
	csel	x15, x24, x9, lo
	add	x15, x15, x10
	umull	x16, w16, w11
	add	x17, x23, x8, lsl #5
	b	LBB173_45
LBB173_43:                              ;   in Loop: Header=BB173_45 Depth=2
	lsl	x1, x12, x0
	lsr	w0, w0, #6
	ldr	x2, [x17, w0, uxtw #3]
	orr	x1, x2, x1
	str	x1, [x17, w0, uxtw #3]
LBB173_44:                              ;   in Loop: Header=BB173_45 Depth=2
	add	x15, x15, #1
	add	x14, x14, #104
	cmp	x16, x14
	b.eq	LBB173_40
LBB173_45:                              ;   Parent Loop BB173_41 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x15, LBB173_122
; %bb.46:                               ;   in Loop: Header=BB173_45 Depth=2
	add	x24, x24, #1
	str	x24, [x21, #2800]
	ldr	x0, [x13]
	add	x0, x0, x14
	ldrb	w1, [x0, #40]
	orr	w1, w1, #0x8
	cmp	w1, #59
	b.ne	LBB173_44
; %bb.47:                               ;   in Loop: Header=BB173_45 Depth=2
	ldr	w0, [x0, #48]
	cmp	w0, w19
	b.lo	LBB173_43
; %bb.48:
	mov	w9, #0                          ; =0x0
Lloh332:
	adrp	x10, l_.str.97@PAGE
Lloh333:
	add	x10, x10, l_.str.97@PAGEOFF
	mov	w11, #2                         ; =0x2
	b	LBB173_123
LBB173_49:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2809]
	mov	w9, #4                          ; =0x4
LBB173_50:
	mov	x8, x22
LBB173_51:
	str	w9, [x21, #2564]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #2568]
	mov	w9, #37400                      ; =0x9218
Lloh334:
	adrp	x10, l_.str.96@PAGE
Lloh335:
	add	x10, x10, l_.str.96@PAGEOFF
	b	LBB173_117
LBB173_52:
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	mov	w10, #16777212                  ; =0xfffffc
LBB173_53:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_55 Depth 2
	lsr	w11, w8, #6
	lsl	x12, x9, x8
	mov	x13, x23
	mov	x14, x19
	add	x15, x23, x8, lsl #5
	b	LBB173_55
LBB173_54:                              ;   in Loop: Header=BB173_55 Depth=2
	add	x13, x13, #32
	subs	x14, x14, #1
	b.eq	LBB173_58
LBB173_55:                              ;   Parent Loop BB173_53 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x24, x10
	b.hs	LBB173_122
; %bb.56:                               ;   in Loop: Header=BB173_55 Depth=2
	add	x24, x24, #5
	str	x24, [x21, #2800]
	ldr	x16, [x13, x11, lsl #3]
	tst	x16, x12
	b.eq	LBB173_54
; %bb.57:                               ;   in Loop: Header=BB173_55 Depth=2
	ldr	q0, [x15]
	ldp	q1, q2, [x13]
	orr.16b	v0, v1, v0
	str	q0, [x13]
	ldur	q0, [x15, #16]
	orr.16b	v0, v2, v0
	str	q0, [x13, #16]
	b	LBB173_54
LBB173_58:                              ;   in Loop: Header=BB173_53 Depth=1
	add	x8, x8, #1
	cmp	x8, x19
	b.ne	LBB173_53
; %bb.59:
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	mov	w10, #104                       ; =0x68
	mov	w11, #1                         ; =0x1
	movk	w11, #256, lsl #16
LBB173_60:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_64 Depth 2
                                        ;       Child Loop BB173_69 Depth 3
                                        ;       Child Loop BB173_75 Depth 3
	add	x12, x20, x8, lsl #5
	ldr	w13, [x12, #8]
	cbz	w13, LBB173_78
; %bb.61:                               ;   in Loop: Header=BB173_60 Depth=1
	mov	x14, #0                         ; =0x0
	lsr	w15, w8, #6
	add	x16, x23, x15, lsl #3
	lsl	x17, x9, x8
	b	LBB173_64
LBB173_62:                              ;   in Loop: Header=BB173_64 Depth=2
	add	x2, x23, x3, lsl #5
	ldr	x2, [x2, x15, lsl #3]
	tst	x2, x17
	b.ne	LBB173_126
LBB173_63:                              ;   in Loop: Header=BB173_64 Depth=2
	add	x14, x14, #1
	mov	x24, x0
	cmp	x14, x13
	b.eq	LBB173_79
LBB173_64:                              ;   Parent Loop BB173_60 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB173_69 Depth 3
                                        ;       Child Loop BB173_75 Depth 3
	lsr	x0, x24, #24
	cbnz	x0, LBB173_122
; %bb.65:                               ;   in Loop: Header=BB173_64 Depth=2
	add	x0, x24, #1
	str	x0, [x21, #2800]
	ldr	x2, [x12]
	madd	x1, x14, x10, x2
	ldrb	w3, [x1, #40]
	cmp	w3, #51
	b.ne	LBB173_63
; %bb.66:                               ;   in Loop: Header=BB173_64 Depth=2
	ldr	w3, [x1, #48]
	cmp	x8, x3
	b.ne	LBB173_62
; %bb.67:                               ;   in Loop: Header=BB173_64 Depth=2
	mov	x3, #0                          ; =0x0
	add	x0, x24, #2
	mov	x4, x16
	b	LBB173_69
LBB173_68:                              ;   in Loop: Header=BB173_69 Depth=3
	add	x3, x3, #1
	add	x0, x0, #1
	add	x4, x4, #32
	cmp	x19, x3
	b.eq	LBB173_73
LBB173_69:                              ;   Parent Loop BB173_60 Depth=1
                                        ;     Parent Loop BB173_64 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x0, x11
	b.eq	LBB173_122
; %bb.70:                               ;   in Loop: Header=BB173_69 Depth=3
	str	x0, [x21, #2800]
	cmp	x8, x3
	b.eq	LBB173_68
; %bb.71:                               ;   in Loop: Header=BB173_69 Depth=3
	lsr	w5, w3, #6
	add	x6, x23, x8, lsl #5
	ldr	x5, [x6, x5, lsl #3]
	lsr	x5, x5, x3
	tbz	w5, #0, LBB173_68
; %bb.72:                               ;   in Loop: Header=BB173_69 Depth=3
	ldr	x5, [x4]
	tst	x5, x17
	b.eq	LBB173_68
	b	LBB173_124
LBB173_73:                              ;   in Loop: Header=BB173_64 Depth=2
	sub	x0, x0, #1
	add	x1, x2, #48
	mov	x2, x13
	b	LBB173_75
LBB173_74:                              ;   in Loop: Header=BB173_75 Depth=3
	add	x1, x1, #104
	subs	x2, x2, #1
	b.eq	LBB173_63
LBB173_75:                              ;   Parent Loop BB173_60 Depth=1
                                        ;     Parent Loop BB173_64 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x3, x0, #24
	cbnz	x3, LBB173_122
; %bb.76:                               ;   in Loop: Header=BB173_75 Depth=3
	add	x0, x0, #1
	str	x0, [x21, #2800]
	ldurb	w3, [x1, #-8]
	cmp	w3, #59
	b.ne	LBB173_74
; %bb.77:                               ;   in Loop: Header=BB173_75 Depth=3
	ldr	w3, [x1]
	cmp	x8, x3
	b.ne	LBB173_74
	b	LBB173_125
LBB173_78:                              ;   in Loop: Header=BB173_60 Depth=1
	mov	x0, x24
LBB173_79:                              ;   in Loop: Header=BB173_60 Depth=1
	add	x8, x8, #1
	mov	x24, x0
	cmp	x8, x19
	b.ne	LBB173_60
; %bb.80:
	mov	x0, x23
	bl	_free
	mov	x8, x22
	ldr	x23, [sp, #24]                  ; 8-byte Folded Reload
LBB173_81:
	ldr	w9, [x21, #2768]
	umull	x0, w19, w9
	ldr	x9, [x21, #1072]
	mov	w10, #1048576                   ; =0x100000
	sub	x10, x10, x9
	cmp	x0, x10
	b.ls	LBB173_83
; %bb.82:
Lloh336:
	adrp	x9, lCPI173_0@PAGE
Lloh337:
	ldr	d0, [x9, lCPI173_0@PAGEOFF]
	add	x9, x21, #2564
	str	d0, [x9]
	str	wzr, [x21, #2572]
	mov	w9, #37400                      ; =0x9218
Lloh338:
	adrp	x10, l_.str.92@PAGE
Lloh339:
	add	x10, x10, l_.str.92@PAGEOFF
	b	LBB173_117
LBB173_83:
	add	x9, x0, x9
	str	x9, [x21, #1072]
	cbz	x0, LBB173_95
; %bb.84:
	lsr	x9, x0, #60
	cbz	x9, LBB173_87
LBB173_85:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #2808]
	mov	w9, #3                          ; =0x3
LBB173_86:
	ldr	x10, [x21]
	str	xzr, [x10]
	str	w9, [x21, #2564]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #2568]
	mov	w9, #37400                      ; =0x9218
Lloh340:
	adrp	x10, l_.str.93@PAGE
Lloh341:
	add	x10, x10, l_.str.93@PAGEOFF
	b	LBB173_117
LBB173_87:
	ldr	x9, [x21, #2784]
	mov	w11, #67108864                  ; =0x4000000
	cmp	x9, x11
	b.hi	LBB173_85
; %bb.88:
	lsl	x10, x0, #4
	sub	x11, x11, x9
	cmp	x10, x11
	b.hi	LBB173_85
; %bb.89:
	ldr	x11, [x21, #2792]
	add	x9, x9, x10
	cmp	x11, x9
	str	x9, [x21, #2784]
	b.hs	LBB173_91
; %bb.90:
	str	x9, [x21, #2792]
LBB173_91:
	ldr	x9, [x21, #2800]
	mov	w10, #16777216                  ; =0x1000000
	cmp	x9, x10
	b.hi	LBB173_85
; %bb.92:
	sub	x10, x10, x9
	cmp	x0, x10
	b.hi	LBB173_85
; %bb.93:
	add	x8, x9, x0
	str	x8, [x21, #2800]
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB173_118
; %bb.94:
	ldr	x8, [x21]
	str	x0, [x8]
	mov	x8, x22
LBB173_95:
	ldr	x9, [x21, #2784]
	mov	w10, #28672                     ; =0x7000
	movk	w10, #1023, lsl #16
	cmp	x9, x10
	b.ls	LBB173_97
; %bb.96:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #2808]
	add	x9, x21, #2564
Lloh342:
	adrp	x10, lCPI173_0@PAGE
Lloh343:
	ldr	d0, [x10, lCPI173_0@PAGEOFF]
	str	d0, [x9]
	str	wzr, [x21, #2572]
	mov	w9, #37400                      ; =0x9218
Lloh344:
	adrp	x10, l_.str.94@PAGE
Lloh345:
	add	x10, x10, l_.str.94@PAGEOFF
	b	LBB173_117
LBB173_97:
	add	x9, x9, #9, lsl #12             ; =36864
	str	x9, [x21, #2784]
	ldr	x10, [x21, #2792]
	cmp	x10, x9
	b.hs	LBB173_99
; %bb.98:
	str	x9, [x21, #2792]
LBB173_99:
	cbz	w19, LBB173_113
; %bb.100:
	mov	x9, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	add	x10, x23, #16
	mov	w11, #104                       ; =0x68
	mov	w12, #65533                     ; =0xfffd
	movk	w12, #255, lsl #16
LBB173_101:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_105 Depth 2
	add	x14, x10, x9, lsl #5
	ldr	w13, [x14, #8]
	cbz	w13, LBB173_110
; %bb.102:                              ;   in Loop: Header=BB173_101 Depth=1
	mov	x15, #0                         ; =0x0
	lsl	x16, x9, #5
	umull	x17, w13, w11
	mov	x13, x1
	b	LBB173_105
LBB173_103:                             ;   in Loop: Header=BB173_105 Depth=2
	add	x1, x1, #4
	str	x1, [x21, #2800]
	ldr	x1, [x21]
	add	x1, x1, #8
	ldr	x2, [x1, x16]
	add	x0, x1, x0, lsl #5
	ldp	x3, x4, [x0]
	orr	x3, x3, x2
	str	x3, [x1, x16]
	cmp	x2, x3
	add	x1, x1, x16
	ldp	x2, x3, [x1, #8]
	orr	x4, x4, x2
	ccmp	x2, x4, #0, eq
	ldp	x2, x0, [x0, #16]
	orr	x2, x2, x3
	stp	x4, x2, [x1, #8]
	ccmp	x3, x2, #0, eq
	ldr	x2, [x1, #24]
	orr	x0, x0, x2
	str	x0, [x1, #24]
	ccmp	x2, x0, #0, eq
	cset	w0, ne
	orr	w13, w13, w0
LBB173_104:                             ;   in Loop: Header=BB173_105 Depth=2
	add	x15, x15, #104
	cmp	x17, x15
	b.eq	LBB173_111
LBB173_105:                             ;   Parent Loop BB173_101 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [x21, #2800]
	lsr	x1, x0, #24
	cbnz	x1, LBB173_115
; %bb.106:                              ;   in Loop: Header=BB173_105 Depth=2
	add	x0, x0, #1
	str	x0, [x21, #2800]
	ldr	x0, [x14]
	add	x0, x0, x15
	ldrb	w1, [x0, #40]
	orr	w1, w1, #0x8
	cmp	w1, #59
	b.ne	LBB173_104
; %bb.107:                              ;   in Loop: Header=BB173_105 Depth=2
	ldr	w0, [x0, #48]
	cmp	w0, w19
	b.hs	LBB173_119
; %bb.108:                              ;   in Loop: Header=BB173_105 Depth=2
	ldrb	w1, [x21, #2808]
	tbnz	w1, #0, LBB173_121
; %bb.109:                              ;   in Loop: Header=BB173_105 Depth=2
	ldr	x1, [x21, #2800]
	cmp	x1, x12
	b.lo	LBB173_103
	b	LBB173_120
LBB173_110:                             ;   in Loop: Header=BB173_101 Depth=1
	mov	x13, x1
LBB173_111:                             ;   in Loop: Header=BB173_101 Depth=1
	add	x9, x9, #1
	mov	x1, x13
	cmp	x9, x19
	b.ne	LBB173_101
; %bb.112:                              ;   in Loop: Header=BB173_101 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	cbnz	w13, LBB173_101
	b	LBB173_114
LBB173_113:
	mov	w0, #1                          ; =0x1
LBB173_114:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB173_115:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #2808]
	add	x9, x21, #2564
Lloh346:
	adrp	x10, lCPI173_0@PAGE
Lloh347:
	ldr	d0, [x10, lCPI173_0@PAGEOFF]
LBB173_116:
	str	d0, [x9]
	str	wzr, [x21, #2572]
	mov	w9, #37400                      ; =0x9218
Lloh348:
	adrp	x10, l_.str.101@PAGE
Lloh349:
	add	x10, x10, l_.str.101@PAGEOFF
LBB173_117:
	mov	w11, #191                       ; =0xbf
	stp	x11, x10, [sp]
Lloh350:
	adrp	x2, l_.str.52@PAGE
Lloh351:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x8, x9
	b	LBB173_7
LBB173_118:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #2809]
	mov	w9, #4                          ; =0x4
	mov	x8, x22
	b	LBB173_86
LBB173_119:
	mov	w10, #2                         ; =0x2
	str	w10, [x21, #2564]
	str	w9, [x21, #2568]
	str	wzr, [x21, #2572]
	mov	w9, #37400                      ; =0x9218
Lloh352:
	adrp	x10, l_.str.95@PAGE
Lloh353:
	add	x10, x10, l_.str.95@PAGEOFF
	b	LBB173_117
LBB173_120:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #2808]
LBB173_121:
Lloh354:
	adrp	x9, lCPI173_0@PAGE
Lloh355:
	ldr	d0, [x9, lCPI173_0@PAGEOFF]
	add	x9, x21, #2564
	b	LBB173_116
LBB173_122:
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	strb	w10, [x21, #2808]
Lloh356:
	adrp	x10, l_.str.101@PAGE
Lloh357:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w11, #3                         ; =0x3
LBB173_123:
	str	w11, [x21, #2564]
	str	w8, [x21, #2568]
	mov	w8, #37400                      ; =0x9218
	str	w9, [x21, #2572]
	mov	w9, #191                        ; =0xbf
	stp	x9, x10, [sp]
Lloh358:
	adrp	x2, l_.str.52@PAGE
Lloh359:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x22, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x0, x23
	bl	_free
	mov	w0, #0                          ; =0x0
	b	LBB173_114
LBB173_124:
	ldr	w9, [x1]
Lloh360:
	adrp	x10, l_.str.98@PAGE
Lloh361:
	add	x10, x10, l_.str.98@PAGEOFF
	b	LBB173_127
LBB173_125:
	ldur	w9, [x1, #-48]
Lloh362:
	adrp	x10, l_.str.99@PAGE
Lloh363:
	add	x10, x10, l_.str.99@PAGEOFF
	b	LBB173_127
LBB173_126:
	ldr	w9, [x1]
Lloh364:
	adrp	x10, l_.str.100@PAGE
Lloh365:
	add	x10, x10, l_.str.100@PAGEOFF
LBB173_127:
	mov	w11, #1                         ; =0x1
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB173_123
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpAdd	Lloh326, Lloh327
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpLdr	Lloh336, Lloh337
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdrp	Lloh342, Lloh344
	.loh AdrpLdr	Lloh342, Lloh343
	.loh AdrpLdr	Lloh346, Lloh347
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh352, Lloh353
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh364, Lloh365
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function analysis_work
lCPI174_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_analysis_work:                         ; @analysis_work
	.cfi_startproc
; %bb.0:
	add	x8, x0, #9, lsl #12             ; =36864
	ldr	x9, [x8, #736]
	cbz	x9, LBB174_6
; %bb.1:
	ldrb	w9, [x8, #768]
	tbnz	w9, #0, LBB174_5
; %bb.2:
	ldrb	w9, [x8, #769]
	tbnz	w9, #0, LBB174_5
; %bb.3:
	ldr	x9, [x8, #760]
	mov	w10, #16777216                  ; =0x1000000
	sub	x11, x10, x9
	cmp	x9, x10
	ccmp	x1, x11, #2, ls
	b.ls	LBB174_7
; %bb.4:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #768]
LBB174_5:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh366:
	adrp	x9, lCPI174_0@PAGE
Lloh367:
	ldr	d0, [x9, lCPI174_0@PAGEOFF]
	add	x9, x8, #524
	str	d0, [x9]
	str	wzr, [x8, #532]
	mov	w8, #37400                      ; =0x9218
Lloh368:
	adrp	x9, l_.str.101@PAGE
Lloh369:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh370:
	adrp	x2, l_.str.52@PAGE
Lloh371:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB174_6:
	mov	w0, #1                          ; =0x1
	ret
LBB174_7:
	add	x9, x9, x1
	str	x9, [x8, #760]
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpLdr	Lloh366, Lloh367
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function uf_site
lCPI175_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_uf_site:                               ; @uf_site
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	w8, #120                        ; =0x78
	umaddl	x22, w2, w8, x0
	ldr	x8, [x22, #8]!
	mov	w9, #104                        ; =0x68
	umaddl	x19, w3, w9, x8
	ldrb	w8, [x19, #40]
	cmp	w8, #251
	b.ne	LBB175_8
; %bb.1:
	ldrb	w8, [x19, #48]
	cmp	w8, #1
	b.ne	LBB175_8
; %bb.2:
	mov	w8, #36608                      ; =0x8f00
	add	x20, x0, x8
	ldr	x8, [x20, #992]
	cbz	x8, LBB175_10
; %bb.3:
	ldrb	w8, [x20, #1024]
	tbnz	w8, #0, LBB175_7
; %bb.4:
	ldrb	w8, [x20, #1025]
	tbnz	w8, #0, LBB175_7
; %bb.5:
	ldr	x8, [x20, #1016]
	mov	w9, #65529                      ; =0xfff9
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.lo	LBB175_9
; %bb.6:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #1024]
LBB175_7:
Lloh372:
	adrp	x8, lCPI175_0@PAGE
Lloh373:
	ldr	d0, [x8, lCPI175_0@PAGEOFF]
	add	x8, x20, #780
	str	d0, [x8]
	str	wzr, [x20, #788]
	mov	w8, #37400                      ; =0x9218
Lloh374:
	adrp	x9, l_.str.101@PAGE
Lloh375:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh376:
	adrp	x2, l_.str.52@PAGE
Lloh377:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	b	LBB175_20
LBB175_8:
	mov	x1, x2
	mov	x2, x3
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_record_site
LBB175_9:
	add	x8, x8, #8
	str	x8, [x20, #1016]
LBB175_10:
	mov	x25, x3
	mov	x21, x2
	mov	x23, x0
	mov	x24, x1
	ldr	x0, [x1]
	ldr	w2, [x19, #56]
	add	x3, sp, #16
	mov	w1, #10                         ; =0xa
	bl	_nvm_union_field_declarations_nominal
	cbz	w0, LBB175_16
; %bb.11:
	ldr	x0, [x24]
	ldr	w1, [x19, #56]
	ldrh	w2, [x19, #64]
	add	x3, sp, #20
	bl	_nvm_union_field_declarations_variant
	cbz	w0, LBB175_16
; %bb.12:
	ldp	w9, w8, [sp, #16]
	cmp	w8, w9
	b.ne	LBB175_16
; %bb.13:
	ldrh	w8, [sp, #30]
	ldrh	w9, [x19, #72]
	cmp	w8, w9
	b.ne	LBB175_16
; %bb.14:
	ldr	w8, [x20]
	cmp	w8, #64
	b.ne	LBB175_22
; %bb.15:
	ldr	w8, [x19]
	mov	w9, #3                          ; =0x3
	str	w9, [x20, #780]
	str	w21, [x20, #784]
	str	w8, [x20, #788]
	mov	w8, #37400                      ; =0x9218
Lloh378:
	adrp	x9, l_.str.103@PAGE
Lloh379:
	add	x9, x9, l_.str.103@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh380:
	adrp	x2, l_.str.52@PAGE
Lloh381:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x23, x8
	b	LBB175_20
LBB175_16:
	ldr	w8, [x19]
	ldr	x9, [x20, #992]
	cbz	x9, LBB175_18
; %bb.17:
	ldrb	w9, [x20, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	b	LBB175_19
LBB175_18:
	mov	w9, #1                          ; =0x1
LBB175_19:
	str	w9, [x20, #780]
	str	w21, [x20, #784]
	mov	w9, #37400                      ; =0x9218
	str	w8, [x20, #788]
Lloh382:
	adrp	x8, l_.str.102@PAGE
Lloh383:
	add	x8, x8, l_.str.102@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x8, [sp]
Lloh384:
	adrp	x2, l_.str.52@PAGE
Lloh385:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x23, x9
LBB175_20:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB175_21:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB175_22:
	add	w9, w8, #1
	ldr	x10, [x22, #112]
	strh	w8, [x10, w25, uxtw #1]
	str	w9, [x20]
	add	x9, x23, x8
	mov	w10, #35904                     ; =0x8c40
	mov	w11, #3                         ; =0x3
	strb	w11, [x9, x10]
	ldr	w9, [x19, #56]
	add	x10, x23, x8, lsl #2
	mov	w11, #35968                     ; =0x8c80
	str	w9, [x10, x11]
	ldrh	w9, [sp, #30]
	add	x10, x23, x8, lsl #1
	mov	w11, #36480                     ; =0x8e80
	strh	w9, [x10, x11]
	ldrb	w9, [x19, #64]
	add	x10, x24, x8
	strb	w9, [x10, #1032]
	mov	w9, #12                         ; =0xc
	umaddl	x8, w8, w9, x23
	mov	w9, #36620                      ; =0x8f0c
	add	x8, x8, x9
	ldr	w9, [x19]
	stp	w21, w9, [x8]
	mov	w9, #655360                     ; =0xa0000
	str	w9, [x8, #8]
	mov	w0, #1                          ; =0x1
	b	LBB175_21
	.loh AdrpAdd	Lloh376, Lloh377
	.loh AdrpAdd	Lloh374, Lloh375
	.loh AdrpLdr	Lloh372, Lloh373
	.loh AdrpAdd	Lloh380, Lloh381
	.loh AdrpAdd	Lloh378, Lloh379
	.loh AdrpAdd	Lloh384, Lloh385
	.loh AdrpAdd	Lloh382, Lloh383
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_site
_record_site:                           ; @record_site
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #35872                      ; =0x8c20
	add	x8, x0, x8
	mov	w9, #120                        ; =0x78
	umaddl	x10, w1, w9, x0
	ldr	x9, [x10, #8]!
	mov	w11, #104                       ; =0x68
	umaddl	x9, w2, w11, x9
	ldrb	w12, [x9, #40]
	cmp	w12, #251
	b.ne	LBB176_5
; %bb.1:
	ldrb	w11, [x9, #48]
	cbnz	w11, LBB176_3
; %bb.2:
	ldrh	w11, [x9, #64]
	cbz	w11, LBB176_5
LBB176_3:
	ldr	w9, [x9]
	ldr	x10, [x8, #1728]
	cbz	x10, LBB176_10
; %bb.4:
	ldrb	w10, [x8, #1760]
	cmp	w10, #0
	mov	w10, #3                         ; =0x3
	csinc	w10, w10, wzr, ne
	b	LBB176_11
LBB176_5:
	cmp	w12, #251
	cset	w11, eq
	add	x13, x9, #48
	ubfiz	x11, x11, #3, #32
	ldr	w11, [x13, x11]
	ldr	x15, [x8]
	ldr	w14, [x15, #16]
	cmp	w11, w14
	b.hs	LBB176_8
; %bb.6:
	ldr	x14, [x15]
	ldr	x15, [x15, #24]
	ldr	w15, [x15, w11, uxtw #2]
	cmp	w12, #96
	b.ne	LBB176_12
; %bb.7:
	mov	w12, #0                         ; =0x0
	b	LBB176_13
LBB176_8:
	ldr	w9, [x9]
	ldr	x10, [x8, #1728]
	cbz	x10, LBB176_20
; %bb.9:
	ldrb	w10, [x8, #1760]
	cmp	w10, #0
	mov	w10, #3                         ; =0x3
	csinc	w10, w10, wzr, ne
	b	LBB176_21
LBB176_10:
	mov	w10, #1                         ; =0x1
LBB176_11:
	str	w10, [x8, #1516]
	str	w1, [x8, #1520]
	mov	w10, #37400                     ; =0x9218
	str	w9, [x8, #1524]
Lloh386:
	adrp	x8, l_.str.104@PAGE
Lloh387:
	add	x8, x8, l_.str.104@PAGEOFF
	b	LBB176_24
LBB176_12:
	cmp	w12, #251
	mov	w12, #8                         ; =0x8
	mov	w16, #24                        ; =0x18
	csel	x12, x16, x12, eq
	ldrh	w12, [x13, x12]
LBB176_13:
	add	x13, x14, x15, lsl #4
	ldrh	w13, [x13, #2]
	cmp	w12, w13
	b.ne	LBB176_18
; %bb.14:
	ldr	w13, [x8, #736]
	cmp	w13, #64
	b.eq	LBB176_17
; %bb.15:
	ldr	w14, [x8, #16]
	mov	w15, #65536                     ; =0x10000
	sub	w15, w15, w14
	cmp	w15, w12
	b.lo	LBB176_17
; %bb.16:
	ldr	x15, [x8, #24]
	add	x16, x14, w12, uxtw
	add	x15, x16, x15
	cmp	x15, #256, lsl #12              ; =1048576
	b.ls	LBB176_27
LBB176_17:
	ldr	w9, [x9]
	mov	w10, #3                         ; =0x3
	str	w10, [x8, #1516]
	str	w1, [x8, #1520]
	str	w9, [x8, #1524]
	mov	w8, #37400                      ; =0x9218
Lloh388:
	adrp	x9, l_.str.107@PAGE
Lloh389:
	add	x9, x9, l_.str.107@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh390:
	adrp	x2, l_.str.52@PAGE
Lloh391:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	b	LBB176_25
LBB176_18:
	ldr	w9, [x9]
	ldr	x10, [x8, #1728]
	cbz	x10, LBB176_22
; %bb.19:
	ldrb	w10, [x8, #1760]
	cmp	w10, #0
	mov	w10, #3                         ; =0x3
	csinc	w10, w10, wzr, ne
	b	LBB176_23
LBB176_20:
	mov	w10, #1                         ; =0x1
LBB176_21:
	str	w10, [x8, #1516]
	str	w1, [x8, #1520]
	mov	w10, #37400                     ; =0x9218
	str	w9, [x8, #1524]
Lloh392:
	adrp	x8, l_.str.105@PAGE
Lloh393:
	add	x8, x8, l_.str.105@PAGEOFF
	b	LBB176_24
LBB176_22:
	mov	w10, #1                         ; =0x1
LBB176_23:
	str	w10, [x8, #1516]
	str	w1, [x8, #1520]
	mov	w10, #37400                     ; =0x9218
	str	w9, [x8, #1524]
Lloh394:
	adrp	x8, l_.str.106@PAGE
Lloh395:
	add	x8, x8, l_.str.106@PAGEOFF
LBB176_24:
	mov	w9, #191                        ; =0xbf
	stp	x9, x8, [sp]
Lloh396:
	adrp	x2, l_.str.52@PAGE
Lloh397:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x10
LBB176_25:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB176_26:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB176_27:
	add	w15, w13, #1
	ldr	x10, [x10, #112]
	strh	w13, [x10, w2, uxtw #1]
	str	w15, [x8, #736]
	add	x10, x0, x13
	mov	w15, #35904                     ; =0x8c40
	mov	w16, #1                         ; =0x1
	strb	w16, [x10, x15]
	add	x10, x0, x13, lsl #2
	mov	w15, #35968                     ; =0x8c80
	str	w11, [x10, x15]
	add	x11, x0, x13, lsl #1
	mov	w15, #36480                     ; =0x8e80
	strh	w12, [x11, x15]
	mov	w11, #36224                     ; =0x8d80
	str	w14, [x10, x11]
	add	w10, w14, w12
	str	w10, [x8, #16]
	mov	w8, #12                         ; =0xc
	umaddl	x8, w13, w8, x0
	mov	w0, #1                          ; =0x1
	ldr	w9, [x9]
	mov	w10, #36620                     ; =0x8f0c
	add	x8, x8, x10
	stp	w1, w9, [x8]
	strh	wzr, [x8, #8]
	mov	w9, #8                          ; =0x8
	strh	w9, [x8, #10]
	b	LBB176_26
	.loh AdrpAdd	Lloh386, Lloh387
	.loh AdrpAdd	Lloh390, Lloh391
	.loh AdrpAdd	Lloh388, Lloh389
	.loh AdrpAdd	Lloh392, Lloh393
	.loh AdrpAdd	Lloh394, Lloh395
	.loh AdrpAdd	Lloh396, Lloh397
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function seed
lCPI177_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI177_1:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_seed:                                  ; @seed
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x23, x3
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
Lloh398:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh399:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh400:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	mov	w8, #34824                      ; =0x8808
	add	x25, x0, x8
	ldr	x24, [x25]
	mov	w8, #768                        ; =0x300
	mov	w9, #512                        ; =0x200
	cmp	x24, #0
	csel	x26, x9, x8, eq
	lsl	x2, x26, #4
	mov	x9, x2
Lloh401:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh402:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	mov	x8, sp
	sub	x22, x8, x2
	mov	sp, x22
	mov	x0, x22
	mov	w1, #0                          ; =0x0
	mov	w3, #12288                      ; =0x3000
	bl	___memset_chk
	ldr	x8, [x25, #2776]
	cbz	x8, LBB177_6
; %bb.1:
	ldrb	w8, [x25, #2808]
	tbnz	w8, #0, LBB177_31
; %bb.2:
	ldrb	w8, [x25, #2809]
	tbnz	w8, #0, LBB177_31
; %bb.3:
	ldr	x8, [x25, #2800]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB177_30
; %bb.4:
	sub	x9, x9, x8
	cmp	x26, x9
	b.hi	LBB177_30
; %bb.5:
	add	x8, x8, x26
	str	x8, [x25, #2800]
LBB177_6:
	mov	w8, #120                        ; =0x78
	umaddl	x9, w20, w8, x19
	mov	w8, w20
	cbz	x24, LBB177_15
; %bb.7:
	ldr	w10, [x25, #2768]
	cbz	w10, LBB177_15
; %bb.8:
	ldurh	w11, [x9, #74]
	ldurh	w12, [x9, #72]
	cmp	w10, #4
	b.hs	LBB177_10
; %bb.9:
	mov	x13, #0                         ; =0x0
	b	LBB177_13
LBB177_10:
	and	x13, x10, #0xfffffffc
	lsl	x14, x12, #4
	add	x14, x14, x11, lsl #4
	add	x14, x14, x22
	add	x14, x14, #32
	add	x15, x23, #32
	movi.2d	v0, #0xffff000000ffffff
	mov	x16, x13
LBB177_11:                              ; =>This Inner Loop Header: Depth=1
	sub	x17, x15, #32
	ld2.2d	{ v1, v2 }, [x17]
	ld2.2d	{ v3, v4 }, [x15]
	sub	x17, x14, #32
	and.16b	v2, v2, v0
	st2.2d	{ v1, v2 }, [x17]
	and.16b	v4, v4, v0
	st2.2d	{ v3, v4 }, [x14]
	add	x14, x14, #64
	add	x15, x15, #64
	subs	x16, x16, #4
	b.ne	LBB177_11
; %bb.12:
	cmp	x13, x10
	b.eq	LBB177_15
LBB177_13:
	sub	x10, x10, x13
	lsl	x13, x13, #4
	add	x12, x13, x12, lsl #4
	add	x11, x12, x11, lsl #4
	add	x11, x11, x22
	add	x11, x11, #8
	add	x12, x13, x23
	add	x12, x12, #8
LBB177_14:                              ; =>This Inner Loop Header: Depth=1
	ldp	x13, x14, [x12, #-8]
	and	x14, x14, #0xffff000000ffffff
	stp	x13, x14, [x11, #-8]
	add	x11, x11, #16
	add	x12, x12, #16
	subs	x10, x10, #1
	b.ne	LBB177_14
LBB177_15:
	ldurh	w9, [x9, #74]
	cbz	w9, LBB177_23
; %bb.16:
	adrp	x10, lCPI177_1@PAGE
	cmp	w9, #8
	b.hs	LBB177_18
; %bb.17:
	mov	x11, #0                         ; =0x0
	b	LBB177_21
LBB177_18:
	and	x11, x9, #0xfff8
	add	x12, x22, #64
	ldr	q0, [x10, lCPI177_1@PAGEOFF]
	mov	x13, x11
LBB177_19:                              ; =>This Inner Loop Header: Depth=1
	stp	q0, q0, [x12, #-64]
	stp	q0, q0, [x12, #-32]
	stp	q0, q0, [x12]
	stp	q0, q0, [x12, #32]
	add	x12, x12, #128
	subs	x13, x13, #8
	b.ne	LBB177_19
; %bb.20:
	cmp	x11, x9
	b.eq	LBB177_23
LBB177_21:
	add	x12, x22, x11, lsl #4
	sub	x9, x9, x11
	ldr	q0, [x10, lCPI177_1@PAGEOFF]
LBB177_22:                              ; =>This Inner Loop Header: Depth=1
	str	q0, [x12], #16
	subs	x9, x9, #1
	b.ne	LBB177_22
LBB177_23:
	ldr	x9, [x19]
	ldr	x10, [x9, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w8, w11, x10
	ldrh	w10, [x10, #4]
	cbz	w10, LBB177_29
; %bb.24:
	mov	x10, #0                         ; =0x0
	mov	w11, #24                        ; =0x18
	mov	x12, x22
	b	LBB177_27
LBB177_25:                              ;   in Loop: Header=BB177_27 Depth=1
	ldr	q0, [x21]
	str	q0, [x12]
LBB177_26:                              ;   in Loop: Header=BB177_27 Depth=1
	add	x10, x10, #1
	ldr	x13, [x9, #256]
	umaddl	x13, w8, w11, x13
	ldrh	w13, [x13, #4]
	add	x12, x12, #16
	add	x21, x21, #16
	cmp	x10, x13
	b.hs	LBB177_29
LBB177_27:                              ; =>This Inner Loop Header: Depth=1
	cbz	x24, LBB177_25
; %bb.28:                               ;   in Loop: Header=BB177_27 Depth=1
	ldp	x13, x14, [x21]
	and	x14, x14, #0xffff000000ffffff
	stp	x13, x14, [x12]
	b	LBB177_26
LBB177_29:
	mov	x0, x19
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	mov	x3, x22
	mov	w4, #0                          ; =0x0
	bl	_join
	b	LBB177_32
LBB177_30:
	mov	w8, #1                          ; =0x1
	strb	w8, [x25, #2808]
LBB177_31:
Lloh403:
	adrp	x8, lCPI177_0@PAGE
Lloh404:
	ldr	d0, [x8, lCPI177_0@PAGEOFF]
	add	x8, x25, #2564
	str	d0, [x8]
	str	wzr, [x25, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh405:
	adrp	x9, l_.str.101@PAGE
Lloh406:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp, #-16]!
Lloh407:
	adrp	x2, l_.str.52@PAGE
Lloh408:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	add	sp, sp, #16
	mov	w0, #0                          ; =0x0
LBB177_32:
	ldur	x8, [x29, #-72]
Lloh409:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh410:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh411:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB177_34
; %bb.33:
	sub	sp, x29, #64
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB177_34:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh398, Lloh399, Lloh400
	.loh AdrpAdd	Lloh407, Lloh408
	.loh AdrpAdd	Lloh405, Lloh406
	.loh AdrpLdr	Lloh403, Lloh404
	.loh AdrpLdrGotLdr	Lloh409, Lloh410, Lloh411
	.loh AdrpLdrGot	Lloh401, Lloh402
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function walk_context
lCPI178_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI178_1:
	.quad	0                               ; 0x0
	.quad	2                               ; 0x2
lCPI178_2:
	.quad	0                               ; 0x0
	.quad	16                              ; 0x10
lCPI178_3:
	.quad	0                               ; 0x0
	.quad	32                              ; 0x20
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_walk_context:                          ; @walk_context
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #12528                      ; =0x30f0
Lloh412:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh413:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #240
	mov	x19, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x4, [x19, #184]                 ; 8-byte Folded Spill
	mov	x21, x1
	mov	x26, x0
Lloh414:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh415:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh416:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w8, #34824                      ; =0x8808
	add	x28, x0, x8
	mov	w8, #120                        ; =0x78
	umaddl	x24, w1, w8, x0
	ldr	x8, [x0]
	ldr	x10, [x8, #256]
	ldr	w8, [x24, #16]
	ldr	x9, [x28, #2776]
	cbz	x9, LBB178_11
; %bb.1:
	ldrb	w9, [x28, #2808]
	tbnz	w9, #0, LBB178_5
; %bb.2:
	ldrb	w9, [x28, #2809]
	tbnz	w9, #0, LBB178_5
; %bb.3:
	ldr	x9, [x28, #2800]
	mov	w11, #16777216                  ; =0x1000000
	sub	x12, x11, x9
	cmp	x9, x11
	ccmp	x12, x8, #0, ls
	b.hi	LBB178_10
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x28, #2808]
LBB178_5:
Lloh417:
	adrp	x8, lCPI178_0@PAGE
Lloh418:
	ldr	d0, [x8, lCPI178_0@PAGEOFF]
	add	x8, x28, #2564
	str	d0, [x8]
	str	wzr, [x28, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh419:
	adrp	x9, l_.str.101@PAGE
Lloh420:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp, #-16]!
Lloh421:
	adrp	x2, l_.str.52@PAGE
Lloh422:
	add	x2, x2, l_.str.52@PAGEOFF
LBB178_6:
	add	x0, x26, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	add	sp, sp, #16
LBB178_7:
	mov	w0, #0                          ; =0x0
LBB178_8:
	ldur	x8, [x29, #-96]
Lloh423:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh424:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh425:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB178_215
; %bb.9:
                                        ; kill: def $w0 killed $w0 killed $x0
	sub	sp, x29, #80
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB178_10:
	add	x11, x8, #1
	add	x9, x11, x9
	str	x9, [x28, #2800]
LBB178_11:
	str	x2, [x19, #120]                 ; 8-byte Folded Spill
	mov	w9, #0                          ; =0x0
	mov	w11, #24                        ; =0x18
	umaddl	x10, w21, w11, x10
	str	x10, [x19, #168]                ; 8-byte Folded Spill
	mov	w10, #1                         ; =0x1
	b	LBB178_13
LBB178_12:                              ;   in Loop: Header=BB178_13 Depth=1
	add	w9, w9, #1
	cmp	w9, w8
	b.hi	LBB178_16
LBB178_13:                              ; =>This Inner Loop Header: Depth=1
	ldur	x11, [x24, #104]
	ldrb	w11, [x11, w9, uxtw]
	cbz	w11, LBB178_12
; %bb.14:                               ;   in Loop: Header=BB178_13 Depth=1
	ldur	x11, [x24, #112]
	ldrb	w12, [x11, w9, uxtw]
	cbnz	w12, LBB178_12
; %bb.15:                               ;   in Loop: Header=BB178_13 Depth=1
	ldur	x12, [x24, #80]
	ldur	w13, [x24, #92]
	str	w9, [x12, x13, lsl #2]
	add	w8, w8, #1
	ldur	w12, [x24, #92]
	add	w12, w12, #1
	udiv	w13, w12, w8
	msub	w8, w13, w8, w12
	stur	w8, [x24, #92]
	strb	w10, [x11, w9, uxtw]
	ldur	w8, [x24, #96]
	add	w8, w8, #1
	stur	w8, [x24, #96]
	ldur	w8, [x24, #16]
	b	LBB178_12
LBB178_16:
	ldur	w8, [x24, #96]
	mov	w0, #1                          ; =0x1
	cbz	w8, LBB178_8
; %bb.17:
	add	x11, x26, #48
	lsl	w9, w0, w3
	and	w10, w9, #0xffff
	str	x10, [x19, #56]                 ; 8-byte Folded Spill
	add	x10, x28, #2564
	str	x10, [x19, #112]                ; 8-byte Folded Spill
	mov	w10, #35904                     ; =0x8c40
	add	x10, x26, x10
	str	x10, [x19, #24]                 ; 8-byte Folded Spill
	mov	w10, #30728                     ; =0x7808
	add	x10, x26, x10
	stp	x11, x10, [x19, #88]            ; 16-byte Folded Spill
	ldr	x10, [x19, #184]                ; 8-byte Folded Reload
	add	x10, x10, #8
	str	x10, [x19, #16]                 ; 8-byte Folded Spill
	orr	w9, w9, #0x1
	str	w9, [x19, #52]                  ; 4-byte Folded Spill
Lloh426:
	adrp	x9, lCPI178_1@PAGE
Lloh427:
	ldr	q0, [x9, lCPI178_1@PAGEOFF]
	str	q0, [x19, #64]                  ; 16-byte Folded Spill
Lloh428:
	adrp	x9, lCPI178_3@PAGE
Lloh429:
	ldr	q0, [x9, lCPI178_3@PAGEOFF]
	str	q0, [x19]                       ; 16-byte Folded Spill
Lloh430:
	adrp	x9, lCPI178_2@PAGE
Lloh431:
	ldr	q0, [x9, lCPI178_2@PAGEOFF]
	str	q0, [x19, #32]                  ; 16-byte Folded Spill
	str	x26, [x19, #160]                ; 8-byte Folded Spill
	str	w21, [x19, #144]                ; 4-byte Folded Spill
LBB178_18:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB178_121 Depth 2
                                        ;     Child Loop BB178_84 Depth 2
                                        ;     Child Loop BB178_95 Depth 2
                                        ;     Child Loop BB178_79 Depth 2
                                        ;     Child Loop BB178_140 Depth 2
	ldr	x9, [x28]
	cmp	x9, #0
	mov	w9, #4096                       ; =0x1000
	mov	w10, #2048                      ; =0x800
	csel	x9, x10, x9, eq
	ldr	x10, [x28, #2776]
	cbz	x10, LBB178_23
; %bb.19:                               ;   in Loop: Header=BB178_18 Depth=1
	ldrb	w10, [x28, #2808]
	tbnz	w10, #0, LBB178_193
; %bb.20:                               ;   in Loop: Header=BB178_18 Depth=1
	ldrb	w10, [x28, #2809]
	tbnz	w10, #0, LBB178_193
; %bb.21:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x10, [x28, #2800]
	mov	w12, #16777216                  ; =0x1000000
	sub	x11, x12, x10
	cmp	x10, x12
	ccmp	x9, x11, #2, ls
	b.hi	LBB178_192
; %bb.22:                               ;   in Loop: Header=BB178_18 Depth=1
	add	x9, x10, x9
	str	x9, [x28, #2800]
LBB178_23:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	x9, sp
	str	x9, [x19, #192]                 ; 8-byte Folded Spill
	ldur	w9, [x24, #88]
	add	w10, w9, #1
	ldur	w11, [x24, #16]
	add	w11, w11, #1
	udiv	w12, w10, w11
	msub	w10, w12, w11, w10
	ldur	x11, [x24, #80]
	ldr	w22, [x11, x9, lsl #2]
	stur	w10, [x24, #88]
	sub	w8, w8, #1
	stur	w8, [x24, #96]
	ldur	x8, [x24, #112]
	strb	wzr, [x8, x22]
	ldr	x8, [x28]
	cmp	x8, #0
	mov	w8, #12288                      ; =0x3000
	mov	w9, #8192                       ; =0x2000
	csel	x2, x9, x8, eq
	mov	x9, x2
Lloh432:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh433:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	mov	x8, sp
	sub	x25, x8, x2
	mov	sp, x25
	mov	x0, x25
	mov	w1, #0                          ; =0x0
	mov	w3, #12288                      ; =0x3000
	bl	___memset_chk
	ldur	x8, [x24, #64]
	ldrh	w27, [x8, x22, lsl #1]
	ldur	x8, [x24, #40]
	ldur	w9, [x24, #100]
	umull	x9, w9, w22
	add	x23, x8, x9, lsl #4
	ldurh	w20, [x24, #74]
	add	x8, x20, x27
	lsl	x2, x8, #4
	mov	x0, x25
	mov	x1, x23
	mov	w3, #12288                      ; =0x3000
	bl	___memcpy_chk
	ldr	x8, [x28]
	cbz	x8, LBB178_25
; %bb.24:                               ;   in Loop: Header=BB178_18 Depth=1
	lsl	x8, x20, #4
	ldurh	w9, [x24, #72]
	lsl	x9, x9, #4
	add	x8, x8, x9
	ldr	w9, [x28, #2768]
	lsl	x2, x9, #4
	add	x0, x25, x8
	add	x1, x23, x8
	bl	_memcpy
LBB178_25:                              ;   in Loop: Header=BB178_18 Depth=1
	add	x10, x25, x20, lsl #4
	ldur	w8, [x24, #16]
	cmp	w22, w8
	b.ne	LBB178_32
; %bb.26:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x9, [x28, #2776]
	ldr	x8, [x19, #168]                 ; 8-byte Folded Reload
	ldrb	w8, [x8, #21]
	cbz	x9, LBB178_28
; %bb.27:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w27, w8
	b.ne	LBB178_196
LBB178_28:                              ;   in Loop: Header=BB178_18 Depth=1
	cbz	w8, LBB178_31
; %bb.29:                               ;   in Loop: Header=BB178_18 Depth=1
	add	x8, x10, x27, lsl #4
LBB178_30:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x9, x8, [x8, #-16]
	ldur	x10, [x24, #48]
	ldurh	w11, [x24, #56]
	ldurb	w12, [x24, #58]
	and	w13, w12, #0xff
	orr	w14, w11, w8
	sturh	w14, [x24, #56]
	orr	x9, x10, x9
	stur	x9, [x24, #48]
	lsr	x8, x8, #16
	orr	w8, w12, w8
	and	w12, w8, #0xff
	sturb	w8, [x24, #58]
	cmp	w11, w14, uxth
	ccmp	x10, x9, #0, eq
	ccmp	w13, w12, #0, eq
	cset	w8, ne
	ldr	w9, [x28, #2772]
	orr	w8, w9, w8
	str	w8, [x28, #2772]
LBB178_31:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	x0, x26
	mov	x1, x21
	mov	x2, x25
	bl	_global_return
	cbnz	w0, LBB178_186
	b	LBB178_200
LBB178_32:                              ;   in Loop: Header=BB178_18 Depth=1
	str	x10, [x19, #152]                ; 8-byte Folded Spill
	ldur	x8, [x24, #8]
	mov	w9, #104                        ; =0x68
	umaddl	x8, w22, w9, x8
	str	x8, [x19, #176]                 ; 8-byte Folded Spill
	ldrb	w23, [x8, #40]
	mov	x0, x23
	bl	_isa_get_info
	ldr	x8, [x19, #184]                 ; 8-byte Folded Reload
	cbz	x8, LBB178_34
; %bb.33:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #163
	b.eq	LBB178_186
LBB178_34:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #88
	b.eq	LBB178_37
; %bb.35:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #251
	b.eq	LBB178_42
; %bb.36:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #99
	b.ne	LBB178_43
LBB178_37:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w21, [x8, #56]
	mov	w9, #1                          ; =0x1
	cmp	w23, #60
	b.gt	LBB178_44
LBB178_38:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #51
	b.eq	LBB178_40
; %bb.39:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #59
	b.ne	LBB178_47
LBB178_40:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x26]
	ldr	x8, [x8, #256]
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w9, [x9, #48]
	mov	w10, #24                        ; =0x18
	umaddl	x8, w9, w10, x8
	ldrh	w21, [x8, #4]
	cmp	w23, #51
	b.eq	LBB178_48
; %bb.41:                               ;   in Loop: Header=BB178_18 Depth=1
	str	w23, [x19, #148]                ; 4-byte Folded Spill
	mov	w23, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	ldrb	w9, [x8, #21]
	tbz	w21, #31, LBB178_55
	b	LBB178_194
LBB178_42:                              ;   in Loop: Header=BB178_18 Depth=1
	str	w23, [x19, #148]                ; 4-byte Folded Spill
	mov	w11, #0                         ; =0x0
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w21, [x8, #72]
	mov	w23, #1                         ; =0x1
	mov	w9, #1                          ; =0x1
	tbz	w21, #31, LBB178_55
	b	LBB178_194
LBB178_43:                              ;   in Loop: Header=BB178_18 Depth=1
	ldrsb	w21, [x0, #28]
	ldrsb	w9, [x0, #29]
	cmp	w23, #60
	b.le	LBB178_38
LBB178_44:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #61
	b.eq	LBB178_50
; %bb.45:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #62
	b.ne	LBB178_47
; %bb.46:                               ;   in Loop: Header=BB178_18 Depth=1
	str	w23, [x19, #148]                ; 4-byte Folded Spill
	mov	w23, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	ldr	w8, [x28, #1040]
	cmp	w8, #0
	csinc	w9, w9, wzr, eq
	csinc	w21, w21, wzr, eq
	tbz	w21, #31, LBB178_55
	b	LBB178_194
LBB178_47:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w23, #51
	b.ne	LBB178_54
LBB178_48:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w21, w27
	b.ne	LBB178_201
; %bb.49:                               ;   in Loop: Header=BB178_18 Depth=1
	str	w23, [x19, #148]                ; 4-byte Folded Spill
	mov	w23, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w11, #1                         ; =0x1
	tbz	w21, #31, LBB178_55
	b	LBB178_194
LBB178_50:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x9, [x28, #2776]
	ldr	x8, [x19, #168]                 ; 8-byte Folded Reload
	ldrb	w8, [x8, #21]
	cbz	x9, LBB178_52
; %bb.51:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w27, w8
	b.ne	LBB178_202
LBB178_52:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w21, [x19, #144]                ; 4-byte Folded Reload
	cbz	w8, LBB178_31
; %bb.53:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	add	x8, x8, x27, lsl #4
	b	LBB178_30
LBB178_54:                              ;   in Loop: Header=BB178_18 Depth=1
	str	w23, [x19, #148]                ; 4-byte Folded Spill
	mov	w23, #0                         ; =0x0
	mov	w11, #0                         ; =0x0
	tbnz	w21, #31, LBB178_194
LBB178_55:                              ;   in Loop: Header=BB178_18 Depth=1
	tbnz	w9, #31, LBB178_194
; %bb.56:                               ;   in Loop: Header=BB178_18 Depth=1
	subs	w10, w27, w21
	b.lo	LBB178_194
; %bb.57:                               ;   in Loop: Header=BB178_18 Depth=1
	ldurh	w26, [x24, #72]
	add	w8, w10, w9
	str	w8, [x19, #132]                 ; 4-byte Folded Spill
	cmp	w8, w26
	b.hi	LBB178_194
; %bb.58:                               ;   in Loop: Header=BB178_18 Depth=1
	str	w11, [x19, #108]                ; 4-byte Folded Spill
	str	x10, [x19, #136]                ; 8-byte Folded Spill
	str	w9, [x19, #128]                 ; 4-byte Folded Spill
	stp	xzr, xzr, [x19, #208]
	ldr	w0, [x19, #148]                 ; 4-byte Folded Reload
	bl	_fixed_result
	mov	w8, #1                          ; =0x1
	tbnz	w0, #31, LBB178_60
; %bb.59:                               ;   in Loop: Header=BB178_18 Depth=1
	lsl	w8, w8, w0
	str	x8, [x19, #216]
LBB178_60:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #184]                 ; 8-byte Folded Reload
	cbz	x8, LBB178_73
; %bb.61:                               ;   in Loop: Header=BB178_18 Depth=1
	cbz	w23, LBB178_68
; %bb.62:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrb	w8, [x8, #48]
	cmp	w8, #1
	b.ne	LBB178_68
; %bb.63:                               ;   in Loop: Header=BB178_18 Depth=1
	ldur	x8, [x24, #120]
	ldrsh	x20, [x8, x22, lsl #1]
	cbz	w21, LBB178_86
; %bb.64:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x21, x8, w9, uxtw #4
	ldrb	w8, [x21, #10]
	cbnz	w8, LBB178_185
; %bb.65:                               ;   in Loop: Header=BB178_18 Depth=1
	ldrh	w8, [x21, #8]
	cbz	w8, LBB178_185
; %bb.66:                               ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w5, [x8]
	ldp	x1, x2, [x21]
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	w3, #1                          ; =0x1
	ldr	w4, [x19, #144]                 ; 4-byte Folded Reload
	bl	_uf_value
	cbz	w0, LBB178_200
; %bb.67:                               ;   in Loop: Header=BB178_18 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	x8, x8, x20
	mov	w9, #1024                       ; =0x400
	stp	x8, x9, [x19, #208]
	ldr	x8, [x19, #16]                  ; 8-byte Folded Reload
	add	x8, x8, w20, uxtw #4
	ldp	x9, x10, [x21]
	ldr	x11, [x8]
	ldrh	w12, [x8, #8]
	ldrb	w13, [x8, #10]
	and	w14, w13, #0xff
	orr	w15, w12, w10
	strh	w15, [x8, #8]
	orr	x9, x11, x9
	str	x9, [x8]
	lsr	x10, x10, #16
	orr	w10, w13, w10
	and	w13, w10, #0xff
	strb	w10, [x8, #10]
	cmp	w12, w15, uxth
	ccmp	x11, x9, #0, eq
	ccmp	w14, w13, #0, eq
	cset	w8, ne
	ldr	w9, [x28, #2772]
	orr	w8, w9, w8
	str	w8, [x28, #2772]
	b	LBB178_160
LBB178_68:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x19, #148]                 ; 4-byte Folded Reload
	sub	w8, w8, #7
	cmp	w8, #247
	b.hi	LBB178_160
; %bb.69:                               ;   in Loop: Header=BB178_18 Depth=1
Lloh434:
	adrp	x11, lJTI178_1@PAGE
Lloh435:
	add	x11, x11, lJTI178_1@PAGEOFF
	adr	x9, LBB178_70
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB178_70:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w9, [x19, #148]                 ; 4-byte Folded Reload
	cmp	w9, #253
	mov	w8, #98                         ; =0x62
	ccmp	w9, w8, #4, ne
	cset	w5, eq
	cmp	w9, #253
	b.eq	LBB178_72
; %bb.71:                               ;   in Loop: Header=BB178_18 Depth=1
	cmp	w9, #98
	b.ne	LBB178_148
LBB178_72:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x9, x0, [x19, #152]             ; 16-byte Folded Reload
	add	x8, x9, x27, lsl #4
	ldp	x6, x7, [x8, #-16]
	b	LBB178_149
LBB178_73:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x19, #148]                 ; 4-byte Folded Reload
	sub	w8, w8, #7
	cmp	w8, #246
	b.hi	LBB178_160
; %bb.74:                               ;   in Loop: Header=BB178_18 Depth=1
Lloh436:
	adrp	x11, lJTI178_0@PAGE
Lloh437:
	add	x11, x11, lJTI178_0@PAGEOFF
	adr	x9, LBB178_75
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB178_75:                              ;   in Loop: Header=BB178_18 Depth=1
	ldur	x8, [x24, #120]
	ldrsh	x8, [x8, x22, lsl #1]
	mov	w9, #1                          ; =0x1
	lsl	x23, x9, x8
	mov	w8, #128                        ; =0x80
	stp	x23, x8, [x19, #208]
	ldr	w8, [x19, #148]                 ; 4-byte Folded Reload
	cmp	w8, #88
	b.ne	LBB178_160
; %bb.76:                               ;   in Loop: Header=BB178_18 Depth=1
	cbz	w21, LBB178_160
; %bb.77:                               ;   in Loop: Header=BB178_18 Depth=1
	lsl	x8, x20, #4
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	add	x8, x25, x8
	add	x20, x8, #8
	b	LBB178_79
LBB178_78:                              ;   in Loop: Header=BB178_79 Depth=2
	add	x20, x20, #16
	subs	w21, w21, #1
	b.eq	LBB178_160
LBB178_79:                              ;   Parent Loop BB178_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	x3, x4, [x20, #-8]
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	x1, x23
	mov	w2, #128                        ; =0x80
	bl	_write_array
	ldr	x8, [x28, #2776]
	cbz	x8, LBB178_78
; %bb.80:                               ;   in Loop: Header=BB178_79 Depth=2
	ldrb	w8, [x28, #2808]
	tbz	w8, #0, LBB178_78
	b	LBB178_200
LBB178_81:                              ;   in Loop: Header=BB178_18 Depth=1
	cbz	w21, LBB178_92
; %bb.82:                               ;   in Loop: Header=BB178_18 Depth=1
	lsl	x8, x20, #4
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	add	x8, x25, x8
	add	x8, x8, #10
	sub	x10, x27, w9, uxtw
	mov	w9, #1                          ; =0x1
	b	LBB178_84
LBB178_83:                              ;   in Loop: Header=BB178_84 Depth=2
	add	x8, x8, #16
	subs	x10, x10, #1
	b.eq	LBB178_91
LBB178_84:                              ;   Parent Loop BB178_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w11, [x8, #-2]
	cbnz	w11, LBB178_83
; %bb.85:                               ;   in Loop: Header=BB178_84 Depth=2
	ldrb	w11, [x8]
	cmp	w11, #0
	csel	w9, wzr, w9, eq
	b	LBB178_83
LBB178_86:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	x8, x8, x20
	mov	w9, #1024                       ; =0x400
	b	LBB178_157
LBB178_87:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28]
	cbz	x8, LBB178_132
; %bb.88:                               ;   in Loop: Header=BB178_18 Depth=1
	ldurh	w8, [x24, #74]
	add	x8, x25, x8, lsl #4
	add	x3, x8, x26, lsl #4
	b	LBB178_133
LBB178_89:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x20, x8, w9, uxtw #4
	add	x8, x8, x27, lsl #4
	ldp	x1, x2, [x20]
	ldp	x3, x4, [x8, #-16]
	bl	_write_array
	ldr	q0, [x20]
	b	LBB178_159
LBB178_90:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldp	x1, x2, [x8]
	bl	_read_array
	b	LBB178_130
LBB178_91:                              ;   in Loop: Header=BB178_18 Depth=1
	cbz	w9, LBB178_160
LBB178_92:                              ;   in Loop: Header=BB178_18 Depth=1
	ldur	x8, [x24, #120]
	ldrsh	x8, [x8, x22, lsl #1]
	mov	w9, #1                          ; =0x1
	lsl	x23, x9, x8
	mov	w8, #256                        ; =0x100
	stp	x23, x8, [x19, #208]
	cbz	w21, LBB178_160
; %bb.93:                               ;   in Loop: Header=BB178_18 Depth=1
	mov	w26, #0                         ; =0x0
	lsl	x8, x20, #4
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	add	x8, x25, x8
	add	x20, x8, #8
	b	LBB178_95
LBB178_94:                              ;   in Loop: Header=BB178_95 Depth=2
	add	x20, x20, #16
	add	w26, w26, #1
	cmp	w21, w26
	b.eq	LBB178_160
LBB178_95:                              ;   Parent Loop BB178_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	x4, x5, [x20, #-8]
	and	w3, w26, #0xffff
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	x1, x23
	mov	w2, #256                        ; =0x100
	bl	_write_record
	ldr	x8, [x28, #2776]
	cbz	x8, LBB178_94
; %bb.96:                               ;   in Loop: Header=BB178_95 Depth=2
	ldrb	w8, [x28, #2808]
	tbz	w8, #0, LBB178_94
	b	LBB178_200
LBB178_97:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #56]                  ; 8-byte Folded Reload
	stp	xzr, x8, [x19, #208]
	ldr	w8, [x19, #52]                  ; 4-byte Folded Reload
	strh	w8, [x19, #216]
	b	LBB178_160
LBB178_98:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w8, [x8, #48]
	ldr	q0, [x25, x8, lsl #4]
	b	LBB178_159
LBB178_99:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w23, [x8, #48]
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldp	x20, x21, [x8]
	ldr	x8, [x19, #96]                  ; 8-byte Folded Reload
	add	x8, x8, x23, lsl #4
	ldr	x9, [x8]
	ldrh	w10, [x8, #8]
	ldrb	w11, [x8, #10]
	and	w12, w11, #0xff
	orr	w13, w10, w21
	strh	w13, [x8, #8]
	orr	x14, x9, x20
	str	x14, [x8]
	lsr	x15, x21, #16
	orr	w11, w11, w15
	and	w15, w11, #0xff
	strb	w11, [x8, #10]
	cmp	w10, w13, uxth
	ccmp	x9, x14, #0, eq
	ccmp	w12, w15, #0, eq
	cset	w8, ne
	ldr	w9, [x28, #2772]
	orr	w8, w9, w8
	str	w8, [x28, #2772]
	ldr	x8, [x28]
	cbz	x8, LBB178_160
; %bb.100:                              ;   in Loop: Header=BB178_18 Depth=1
	add	x1, x24, #8
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x23
	bl	_global_invalidates
	cbz	w0, LBB178_200
; %bb.101:                              ;   in Loop: Header=BB178_18 Depth=1
	ldurh	w8, [x24, #74]
	add	x8, x25, x8, lsl #4
	ldurh	w9, [x24, #72]
	add	x8, x8, x9, lsl #4
	add	x8, x8, x23, lsl #4
	and	x9, x21, #0xffff000000ffffff
	stp	x20, x9, [x8]
	b	LBB178_160
LBB178_102:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #120]                 ; 8-byte Folded Reload
	cbz	x8, LBB178_203
; %bb.103:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	ldr	q0, [x8, w9, uxtw #4]
	b	LBB178_159
LBB178_104:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	add	x8, x8, x27, lsl #4
	ldur	q0, [x8, #-16]
	str	q0, [x19, #208]
	str	q0, [x8]
	add	w27, w27, #1
	b	LBB178_106
LBB178_105:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	add	x8, x8, x27, lsl #4
	ldp	q1, q0, [x8, #-32]
	str	q0, [x19, #208]
	stp	q0, q1, [x8, #-32]
LBB178_106:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x26, [x19, #160]                ; 8-byte Folded Reload
	ldr	w21, [x19, #144]                ; 4-byte Folded Reload
	b	LBB178_184
LBB178_107:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w8, [x8, #48]
	ldr	x9, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x10, [x19, #136]                ; 8-byte Folded Reload
	ldr	q0, [x9, w10, uxtw #4]
	str	q0, [x25, x8, lsl #4]
	b	LBB178_160
LBB178_108:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28]
	cbz	x8, LBB178_158
; %bb.109:                              ;   in Loop: Header=BB178_18 Depth=1
	ldurh	w8, [x24, #74]
	add	x8, x25, x8, lsl #4
	add	x8, x8, x26, lsl #4
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w9, [x9, #48]
	ldr	q0, [x8, x9, lsl #4]
	str	q0, [x19, #208]
	add	w8, w9, #1
	strh	w8, [x19, #220]
	strb	wzr, [x19, #219]
	b	LBB178_160
LBB178_110:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x28, #1040]
	cbz	w8, LBB178_205
; %bb.111:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #160]                 ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w1, [x8, #48]
	bl	_nvm_portable_file_read_import
	cmp	w0, #1
	b.ne	LBB178_156
; %bb.112:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	q0, [x19]                       ; 16-byte Folded Reload
	b	LBB178_159
LBB178_113:                             ;   in Loop: Header=BB178_18 Depth=1
	ldur	x8, [x24, #120]
	ldrsh	x8, [x8, x22, lsl #1]
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	w9, #8192                       ; =0x2000
	b	LBB178_157
LBB178_114:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	q0, [x19, #32]                  ; 16-byte Folded Reload
	b	LBB178_159
LBB178_115:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w2, [x8]
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldp	x3, x4, [x8]
	add	x5, x19, #208
	ldr	w1, [x19, #144]                 ; 4-byte Folded Reload
	bl	_slice_origins
	cbnz	w0, LBB178_160
	b	LBB178_200
LBB178_116:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #120]                 ; 8-byte Folded Reload
	cbz	x8, LBB178_207
; %bb.117:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	w1, #128                        ; =0x80
	bl	_analysis_work
	cbz	w0, LBB178_200
; %bb.118:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w12, [x28, #1784]
	ldr	x4, [x19, #24]                  ; 8-byte Folded Reload
	ldr	x5, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x6, [x19, #136]                 ; 8-byte Folded Reload
	cbz	w12, LBB178_128
; %bb.119:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x5, x6, lsl #4
	ldr	x11, [x10]
	lsl	x12, x12, #4
	b	LBB178_121
LBB178_120:                             ;   in Loop: Header=BB178_121 Depth=2
	add	x9, x9, #1
	add	x8, x8, #16
	cmp	x12, x8
	b.eq	LBB178_128
LBB178_121:                             ;   Parent Loop BB178_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsr	x13, x11, x9
	tbz	w13, #0, LBB178_120
; %bb.122:                              ;   in Loop: Header=BB178_121 Depth=2
	ldrb	w13, [x4, x9]
	cmp	w13, #2
	b.ne	LBB178_120
; %bb.123:                              ;   in Loop: Header=BB178_121 Depth=2
	ldr	x13, [x19, #120]                ; 8-byte Folded Reload
	add	x13, x13, x8
	ldp	x14, x15, [x10, #16]
	ldr	x16, [x13, #8]
	ldrh	w17, [x13, #16]
	ldrb	w0, [x13, #18]
	and	w1, w0, #0xff
	orr	w2, w17, w15
	strh	w2, [x13, #16]
	orr	x14, x16, x14
	str	x14, [x13, #8]
	lsr	x15, x15, #16
	orr	w15, w0, w15
	and	w0, w15, #0xff
	strb	w15, [x13, #18]
	cmp	w17, w2, uxth
	ccmp	x16, x14, #0, eq
	ccmp	w1, w0, #0, eq
	cset	w14, ne
	ldr	w15, [x28, #2772]
	orr	w14, w15, w14
	str	w14, [x28, #2772]
	ldp	x15, x16, [x10, #32]
	ldr	x17, [x13, #1032]
	ldrh	w0, [x13, #1040]
	ldrb	w1, [x13, #1042]
	and	w2, w1, #0xff
	orr	w3, w0, w16
	strh	w3, [x13, #1040]
	orr	x15, x17, x15
	str	x15, [x13, #1032]
	lsr	x16, x16, #16
	orr	w16, w1, w16
	and	w1, w16, #0xff
	strb	w16, [x13, #1042]
	cmp	w0, w3, uxth
	ccmp	x17, x15, #0, eq
	ccmp	w2, w1, #0, eq
	cset	w13, ne
	orr	w13, w14, w13
	str	w13, [x28, #2772]
	b	LBB178_120
LBB178_124:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28]
	cbz	x8, LBB178_160
; %bb.125:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldrh	w8, [x8, #12]
	cbz	w8, LBB178_160
; %bb.126:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w9, [x28, #2768]
	cmp	w9, w8
	b.lo	LBB178_160
; %bb.127:                              ;   in Loop: Header=BB178_18 Depth=1
	add	w8, w8, #256
	strh	w8, [x19, #220]
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldrb	w8, [x8, #48]
	strb	w8, [x19, #219]
	b	LBB178_160
LBB178_128:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	q0, [x5, x6, lsl #4]
	b	LBB178_159
LBB178_129:                             ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w3, [x9, #48]
	ldp	x1, x2, [x8]
	bl	_read_record
LBB178_130:                             ;   in Loop: Header=BB178_18 Depth=1
	stp	x0, x1, [x19, #208]
	b	LBB178_160
LBB178_131:                             ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x20, x8, w9, uxtw #4
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w3, [x9, #48]
	add	x8, x8, x27, lsl #4
	ldp	x1, x2, [x20]
	ldp	x4, x5, [x8, #-16]
	bl	_write_record
	ldr	q0, [x20]
	b	LBB178_159
LBB178_132:                             ;   in Loop: Header=BB178_18 Depth=1
	mov	x3, #0                          ; =0x0
LBB178_133:                             ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x0, [x19, #152]             ; 16-byte Folded Reload
	ldr	x10, [x19, #136]                ; 8-byte Folded Reload
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w20, [x9, #48]
	add	x2, x8, w10, uxtw #4
	mov	x1, x20
	bl	_seed
	cbz	w0, LBB178_200
; %bb.134:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28]
	cbz	x8, LBB178_144
; %bb.135:                              ;   in Loop: Header=BB178_18 Depth=1
	add	x8, x8, x20
	mov	w9, #8200                       ; =0x2008
	ldrb	w8, [x8, x9]
	cbz	w8, LBB178_185
; %bb.136:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x28, #2768]
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	cbz	w8, LBB178_144
; %bb.137:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	b	LBB178_140
LBB178_138:                             ;   in Loop: Header=BB178_140 Depth=2
	ldr	w8, [x28, #2768]
LBB178_139:                             ;   in Loop: Header=BB178_140 Depth=2
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	add	x27, x27, #1
	add	x21, x21, #16
	cmp	x27, x8
	b.hs	LBB178_144
LBB178_140:                             ;   Parent Loop BB178_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w1, #1                          ; =0x1
	bl	_analysis_work
	cbz	w0, LBB178_200
; %bb.141:                              ;   in Loop: Header=BB178_140 Depth=2
	ldr	x8, [x28]
	add	x8, x8, x20, lsl #5
	lsr	x9, x27, #6
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	lsr	x8, x8, x27
	tbz	w8, #0, LBB178_138
; %bb.142:                              ;   in Loop: Header=BB178_140 Depth=2
	add	x1, x24, #8
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x27
	bl	_global_invalidates
	cbz	w0, LBB178_200
; %bb.143:                              ;   in Loop: Header=BB178_140 Depth=2
	ldurh	w8, [x24, #74]
	ldurh	w9, [x24, #72]
	lsl	x8, x8, #4
	add	x8, x8, x9, lsl #4
	add	x8, x25, x8
	add	x9, x8, x21
	ldr	x8, [x28]
	ldr	x10, [x8]
	ldr	w8, [x28, #2768]
	umull	x11, w8, w20
	add	x10, x10, x11, lsl #4
	add	x10, x10, x21
	ldp	x11, x10, [x10]
	and	x10, x10, #0xffff000000ffffff
	stp	x11, x10, [x9]
	b	LBB178_139
LBB178_144:                             ;   in Loop: Header=BB178_18 Depth=1
	mov	w8, #120                        ; =0x78
	umull	x8, w20, w8
	ldr	x9, [x19, #88]                  ; 8-byte Folded Reload
	ldr	q0, [x9, x8]
	str	q0, [x19, #208]
	ldr	w8, [x19, #108]                 ; 4-byte Folded Reload
	cbz	w8, LBB178_160
; %bb.145:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #168]                 ; 8-byte Folded Reload
	ldrb	w8, [x8, #21]
	cbz	w8, LBB178_147
; %bb.146:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x8, x9, [x19, #208]
	ldur	x10, [x24, #48]
	ldurh	w11, [x24, #56]
	ldurb	w12, [x24, #58]
	and	w13, w12, #0xff
	orr	w14, w11, w9
	sturh	w14, [x24, #56]
	orr	x8, x10, x8
	stur	x8, [x24, #48]
	lsr	x9, x9, #16
	orr	w9, w12, w9
	and	w12, w9, #0xff
	sturb	w9, [x24, #58]
	cmp	w11, w14, uxth
	ccmp	x10, x8, #0, eq
	ccmp	w13, w12, #0, eq
	cset	w8, ne
	ldr	w9, [x28, #2772]
	orr	w8, w9, w8
	str	w8, [x28, #2772]
LBB178_147:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	ldr	w1, [x19, #144]                 ; 4-byte Folded Reload
	mov	x2, x25
	bl	_global_return
	cbnz	w0, LBB178_185
	b	LBB178_200
LBB178_148:                             ;   in Loop: Header=BB178_18 Depth=1
	mov	x6, #0                          ; =0x0
	mov	x7, #0                          ; =0x0
	ldp	x9, x0, [x19, #152]             ; 16-byte Folded Reload
LBB178_149:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	w10, [x19, #144]                ; 4-byte Folded Reload
	ldr	x8, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x9, w8, uxtw #4
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldrh	w4, [x9, #48]
	ldr	w9, [x9]
	ldp	x2, x3, [x8]
	sub	sp, sp, #32
	add	x8, x19, #208
	str	x8, [sp, #16]
	stp	w9, wzr, [sp, #4]
	str	w10, [sp]
	ldr	x1, [x19, #184]                 ; 8-byte Folded Reload
	bl	_uf_access
	add	sp, sp, #32
	cmp	w0, #2
	b.eq	LBB178_185
; %bb.150:                              ;   in Loop: Header=BB178_18 Depth=1
	cbnz	w0, LBB178_160
	b	LBB178_200
LBB178_151:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	add	x8, x8, w9, uxtw #4
	ldrb	w9, [x8, #10]
	cbnz	w9, LBB178_185
; %bb.152:                              ;   in Loop: Header=BB178_18 Depth=1
	ldrh	w9, [x8, #8]
	cbz	w9, LBB178_185
; %bb.153:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x1, [x8]
	cbz	x1, LBB178_185
; %bb.154:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	x9, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w5, [x9]
	ldr	x2, [x8, #8]
	ldr	x0, [x19, #160]                 ; 8-byte Folded Reload
	mov	w3, #10                         ; =0xa
	ldr	w4, [x19, #144]                 ; 4-byte Folded Reload
	bl	_uf_value
	cbz	w0, LBB178_200
LBB178_155:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	q0, [x19, #64]                  ; 16-byte Folded Reload
	b	LBB178_159
LBB178_156:                             ;   in Loop: Header=BB178_18 Depth=1
	ldur	x8, [x24, #120]
	ldrsh	x8, [x8, x22, lsl #1]
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	w9, #128                        ; =0x80
LBB178_157:                             ;   in Loop: Header=BB178_18 Depth=1
	stp	x8, x9, [x19, #208]
	b	LBB178_160
LBB178_158:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8, #48]
	ldr	x9, [x19, #96]                  ; 8-byte Folded Reload
	ldr	q0, [x9, x8, lsl #4]
LBB178_159:                             ;   in Loop: Header=BB178_18 Depth=1
	str	q0, [x19, #208]
LBB178_160:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28, #2776]
	cbz	x8, LBB178_162
; %bb.161:                              ;   in Loop: Header=BB178_18 Depth=1
	ldrb	w8, [x28, #2808]
	tbnz	w8, #0, LBB178_200
LBB178_162:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #152]                 ; 8-byte Folded Reload
	ldr	w9, [x19, #128]                 ; 4-byte Folded Reload
	cbz	w9, LBB178_164
; %bb.163:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	q0, [x19, #208]
	ldr	x9, [x19, #136]                 ; 8-byte Folded Reload
	str	q0, [x8, w9, uxtw #4]
LBB178_164:                             ;   in Loop: Header=BB178_18 Depth=1
	ldp	w21, w20, [x19, #144]           ; 8-byte Folded Reload
	sub	w8, w20, #56
	cmp	w8, #2
	ldr	x26, [x19, #160]                ; 8-byte Folded Reload
	b.hi	LBB178_183
; %bb.165:                              ;   in Loop: Header=BB178_18 Depth=1
	ldp	x9, x8, [x19, #168]             ; 16-byte Folded Reload
	ldr	w8, [x8, #8]
	ldr	w9, [x9, #8]
	ldur	w10, [x24, #20]
	sub	w8, w8, w9
	cmp	w8, w10
	b.ne	LBB178_167
; %bb.166:                              ;   in Loop: Header=BB178_18 Depth=1
	ldur	w23, [x24, #16]
	cmp	w20, #56
	b.ne	LBB178_168
	b	LBB178_172
LBB178_167:                             ;   in Loop: Header=BB178_18 Depth=1
	ldur	x9, [x24, #32]
	ldr	w8, [x9, w8, uxtw #2]
	sub	w23, w8, #1
	cmp	w20, #56
	b.eq	LBB178_172
LBB178_168:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x28]
	cbz	x8, LBB178_172
; %bb.169:                              ;   in Loop: Header=BB178_18 Depth=1
	mov	x0, x26
	mov	w1, #768                        ; =0x300
	bl	_analysis_work
	cbz	w0, LBB178_200
; %bb.170:                              ;   in Loop: Header=BB178_18 Depth=1
	cmp	w20, #57
	cset	w27, eq
	add	x0, x19, #224
	mov	x1, x25
	mov	w2, #12288                      ; =0x3000
	bl	_memcpy
	ldr	w8, [x19, #132]                 ; 4-byte Folded Reload
	and	w8, w8, #0xffff
	ldr	x9, [x19, #152]                 ; 8-byte Folded Reload
	add	x8, x9, w8, uxtw #4
	ldp	x3, x4, [x8]
	ldr	x8, [x19, #184]                 ; 8-byte Folded Reload
	str	x4, [x19, #176]                 ; 8-byte Folded Spill
	str	x3, [x19, #152]                 ; 8-byte Folded Spill
	cbz	x8, LBB178_174
; %bb.171:                              ;   in Loop: Header=BB178_18 Depth=1
	str	x8, [sp, #-16]!
	add	x1, x24, #8
	add	x2, x19, #224
	add	x6, x19, #204
	mov	x0, x26
	mov	x5, x27
	mov	x7, #0                          ; =0x0
	b	LBB178_175
LBB178_172:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x19, #132]                 ; 4-byte Folded Reload
	and	w4, w8, #0xffff
	mov	x0, x26
	mov	x1, x21
	mov	x2, x23
	mov	x3, x25
	bl	_join
	cmp	w0, #0
	mov	w8, #5                          ; =0x5
	csinc	w8, w8, wzr, ne
	cmp	w20, #56
	b.eq	LBB178_189
; %bb.173:                              ;   in Loop: Header=BB178_18 Depth=1
	cbnz	w0, LBB178_183
	b	LBB178_189
LBB178_174:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x7, [x19, #120]                 ; 8-byte Folded Reload
	str	xzr, [sp, #-16]!
	add	x1, x24, #8
	add	x2, x19, #224
	add	x6, x19, #204
	mov	x0, x26
	mov	x5, x27
LBB178_175:                             ;   in Loop: Header=BB178_18 Depth=1
	bl	_global_refine_context
	add	sp, sp, #16
	cbz	w0, LBB178_188
; %bb.176:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x19, #204]
	cbz	w8, LBB178_178
; %bb.177:                              ;   in Loop: Header=BB178_18 Depth=1
	add	x3, x19, #224
	ldr	w8, [x19, #132]                 ; 4-byte Folded Reload
	and	w4, w8, #0xffff
	mov	x0, x26
	mov	x1, x21
	mov	x2, x23
	bl	_join
	cbz	w0, LBB178_188
LBB178_178:                             ;   in Loop: Header=BB178_18 Depth=1
	cmp	w20, #58
	cset	w5, eq
	ldr	x8, [x19, #184]                 ; 8-byte Folded Reload
	cbz	x8, LBB178_180
; %bb.179:                              ;   in Loop: Header=BB178_18 Depth=1
	str	x8, [sp, #-16]!
	add	x1, x24, #8
	add	x6, x19, #204
	mov	x0, x26
	mov	x2, x25
	ldr	x3, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x4, [x19, #176]                 ; 8-byte Folded Reload
	mov	x7, #0                          ; =0x0
	b	LBB178_181
LBB178_180:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x7, [x19, #120]                 ; 8-byte Folded Reload
	str	xzr, [sp, #-16]!
	add	x1, x24, #8
	add	x6, x19, #204
	mov	x0, x26
	mov	x2, x25
	ldr	x3, [x19, #152]                 ; 8-byte Folded Reload
	ldr	x4, [x19, #176]                 ; 8-byte Folded Reload
LBB178_181:                             ;   in Loop: Header=BB178_18 Depth=1
	bl	_global_refine_context
	add	sp, sp, #16
	cbz	w0, LBB178_188
; %bb.182:                              ;   in Loop: Header=BB178_18 Depth=1
	ldr	w8, [x19, #204]
	cbz	w8, LBB178_190
LBB178_183:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	w27, [x19, #132]                ; 4-byte Folded Reload
LBB178_184:                             ;   in Loop: Header=BB178_18 Depth=1
	add	w2, w22, #1
	and	w4, w27, #0xffff
	mov	x0, x26
	mov	x1, x21
	mov	x3, x25
	bl	_join
	cbz	w0, LBB178_200
LBB178_185:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x26, [x19, #160]                ; 8-byte Folded Reload
	ldr	w21, [x19, #144]                ; 4-byte Folded Reload
LBB178_186:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x8, [x19, #192]                 ; 8-byte Folded Reload
	mov	sp, x8
LBB178_187:                             ;   in Loop: Header=BB178_18 Depth=1
	ldur	w8, [x24, #96]
	cbnz	w8, LBB178_18
	b	LBB178_191
LBB178_188:                             ;   in Loop: Header=BB178_18 Depth=1
	mov	w8, #1                          ; =0x1
LBB178_189:                             ;   in Loop: Header=BB178_18 Depth=1
	ldr	x9, [x19, #192]                 ; 8-byte Folded Reload
	mov	sp, x9
	cmp	w8, #5
	b.eq	LBB178_187
	b	LBB178_7
LBB178_190:                             ;   in Loop: Header=BB178_18 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB178_189
LBB178_191:
	mov	w0, #1                          ; =0x1
	b	LBB178_8
LBB178_192:
	mov	w8, #1                          ; =0x1
	strb	w8, [x28, #2808]
LBB178_193:
Lloh438:
	adrp	x8, lCPI178_0@PAGE
Lloh439:
	ldr	d0, [x8, lCPI178_0@PAGEOFF]
	ldr	x8, [x19, #112]                 ; 8-byte Folded Reload
	str	d0, [x8]
	str	wzr, [x28, #2572]
Lloh440:
	adrp	x8, l_.str.101@PAGE
Lloh441:
	add	x8, x8, l_.str.101@PAGEOFF
	mov	w9, #191                        ; =0xbf
	stp	x9, x8, [sp, #-16]!
Lloh442:
	adrp	x2, l_.str.52@PAGE
Lloh443:
	add	x2, x2, l_.str.52@PAGEOFF
	mov	w8, #37400                      ; =0x9218
	b	LBB178_6
LBB178_194:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x11, [x28, #2776]
Lloh444:
	adrp	x9, l_.str.113@PAGE
Lloh445:
	add	x9, x9, l_.str.113@PAGEOFF
	mov	w10, #2                         ; =0x2
	ldr	x26, [x19, #160]                ; 8-byte Folded Reload
LBB178_195:
	ldr	w21, [x19, #144]                ; 4-byte Folded Reload
	cbnz	x11, LBB178_197
	b	LBB178_198
LBB178_196:
	ldr	x8, [x19, #168]                 ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
Lloh446:
	adrp	x9, l_.str.110@PAGE
Lloh447:
	add	x9, x9, l_.str.110@PAGEOFF
	mov	w10, #2                         ; =0x2
LBB178_197:
	ldrb	w11, [x28, #2808]
	mov	w12, #3                         ; =0x3
	cmp	w11, #0
	csel	w10, w12, w10, ne
LBB178_198:
	str	w10, [x28, #2564]
	str	w21, [x28, #2568]
	str	w8, [x28, #2572]
	mov	w8, #191                        ; =0xbf
	stp	x8, x9, [sp, #-16]!
Lloh448:
	adrp	x2, l_.str.52@PAGE
Lloh449:
	add	x2, x2, l_.str.52@PAGEOFF
	mov	w8, #37400                      ; =0x9218
	add	x0, x26, x8
LBB178_199:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	add	sp, sp, #16
LBB178_200:
	ldr	x8, [x19, #192]                 ; 8-byte Folded Reload
	mov	sp, x8
	b	LBB178_7
LBB178_201:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x11, [x28, #2776]
Lloh450:
	adrp	x9, l_.str.112@PAGE
Lloh451:
	add	x9, x9, l_.str.112@PAGEOFF
	mov	w10, #1                         ; =0x1
	b	LBB178_195
LBB178_202:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
Lloh452:
	adrp	x9, l_.str.111@PAGE
Lloh453:
	add	x9, x9, l_.str.111@PAGEOFF
	mov	w10, #2                         ; =0x2
	ldr	w21, [x19, #144]                ; 4-byte Folded Reload
	b	LBB178_197
LBB178_203:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x9, [x28, #2776]
	cbz	x9, LBB178_209
; %bb.204:
	ldrb	w9, [x28, #2808]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	ldr	x10, [x19, #160]                ; 8-byte Folded Reload
	b	LBB178_213
LBB178_205:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x9, [x28, #2776]
	ldr	x10, [x19, #160]                ; 8-byte Folded Reload
	ldr	w11, [x19, #144]                ; 4-byte Folded Reload
	cbz	x9, LBB178_210
; %bb.206:
	ldrb	w9, [x28, #2808]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	b	LBB178_211
LBB178_207:
	ldr	x8, [x19, #176]                 ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x9, [x28, #2776]
	ldr	x10, [x19, #160]                ; 8-byte Folded Reload
	cbz	x9, LBB178_212
; %bb.208:
	ldrb	w9, [x28, #2808]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	b	LBB178_213
LBB178_209:
	mov	w9, #1                          ; =0x1
	ldr	x10, [x19, #160]                ; 8-byte Folded Reload
	b	LBB178_213
LBB178_210:
	mov	w9, #1                          ; =0x1
LBB178_211:
	mov	w12, #37400                     ; =0x9218
	str	w9, [x28, #2564]
	str	w11, [x28, #2568]
	str	w8, [x28, #2572]
	sub	sp, sp, #16
Lloh454:
	adrp	x8, l_.str.114@PAGE
Lloh455:
	add	x8, x8, l_.str.114@PAGEOFF
	b	LBB178_214
LBB178_212:
	mov	w9, #1                          ; =0x1
LBB178_213:
	ldr	w11, [x19, #144]                ; 4-byte Folded Reload
	mov	w12, #37400                     ; =0x9218
	str	w9, [x28, #2564]
	str	w11, [x28, #2568]
	str	w8, [x28, #2572]
	sub	sp, sp, #16
Lloh456:
	adrp	x8, l_.str.115@PAGE
Lloh457:
	add	x8, x8, l_.str.115@PAGEOFF
LBB178_214:
	mov	w9, #191                        ; =0xbf
	stp	x9, x8, [sp]
Lloh458:
	adrp	x2, l_.str.52@PAGE
Lloh459:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x10, x12
	b	LBB178_199
LBB178_215:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh414, Lloh415, Lloh416
	.loh AdrpAdd	Lloh421, Lloh422
	.loh AdrpAdd	Lloh419, Lloh420
	.loh AdrpLdr	Lloh417, Lloh418
	.loh AdrpLdrGotLdr	Lloh423, Lloh424, Lloh425
	.loh AdrpLdr	Lloh430, Lloh431
	.loh AdrpAdrp	Lloh428, Lloh430
	.loh AdrpLdr	Lloh428, Lloh429
	.loh AdrpAdrp	Lloh426, Lloh428
	.loh AdrpLdr	Lloh426, Lloh427
	.loh AdrpAdd	Lloh434, Lloh435
	.loh AdrpAdd	Lloh436, Lloh437
	.loh AdrpAdd	Lloh442, Lloh443
	.loh AdrpAdd	Lloh440, Lloh441
	.loh AdrpLdr	Lloh438, Lloh439
	.loh AdrpAdd	Lloh444, Lloh445
	.loh AdrpAdd	Lloh446, Lloh447
	.loh AdrpAdd	Lloh448, Lloh449
	.loh AdrpAdd	Lloh450, Lloh451
	.loh AdrpAdd	Lloh452, Lloh453
	.loh AdrpAdd	Lloh454, Lloh455
	.loh AdrpAdd	Lloh456, Lloh457
	.loh AdrpAdd	Lloh458, Lloh459
	.loh AdrpLdrGot	Lloh412, Lloh413
	.loh AdrpLdrGot	Lloh432, Lloh433
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI178_0:
	.short	(LBB178_104-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_105-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_98-LBB178_75)>>2
	.short	(LBB178_107-LBB178_75)>>2
	.short	(LBB178_108-LBB178_75)>>2
	.short	(LBB178_99-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_87-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_87-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_110-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_75-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_75-LBB178_75)>>2
	.short	(LBB178_89-LBB178_75)>>2
	.short	(LBB178_90-LBB178_75)>>2
	.short	(LBB178_90-LBB178_75)>>2
	.short	(LBB178_89-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_115-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_75-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_81-LBB178_75)>>2
	.short	(LBB178_129-LBB178_75)>>2
	.short	(LBB178_131-LBB178_75)>>2
	.short	(LBB178_81-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_113-LBB178_75)>>2
	.short	(LBB178_97-LBB178_75)>>2
	.short	(LBB178_116-LBB178_75)>>2
	.short	(LBB178_114-LBB178_75)>>2
	.short	(LBB178_102-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_155-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_124-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_160-LBB178_75)>>2
	.short	(LBB178_81-LBB178_75)>>2
	.short	(LBB178_129-LBB178_75)>>2
	.short	(LBB178_131-LBB178_75)>>2
	.p2align	1, 0x0
lJTI178_1:
	.short	(LBB178_104-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_105-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_98-LBB178_70)>>2
	.short	(LBB178_107-LBB178_70)>>2
	.short	(LBB178_108-LBB178_70)>>2
	.short	(LBB178_99-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_87-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_87-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_110-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_75-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_75-LBB178_70)>>2
	.short	(LBB178_89-LBB178_70)>>2
	.short	(LBB178_90-LBB178_70)>>2
	.short	(LBB178_90-LBB178_70)>>2
	.short	(LBB178_89-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_115-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_75-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_81-LBB178_70)>>2
	.short	(LBB178_70-LBB178_70)>>2
	.short	(LBB178_70-LBB178_70)>>2
	.short	(LBB178_81-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_113-LBB178_70)>>2
	.short	(LBB178_97-LBB178_70)>>2
	.short	(LBB178_116-LBB178_70)>>2
	.short	(LBB178_114-LBB178_70)>>2
	.short	(LBB178_102-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_155-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_124-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_160-LBB178_70)>>2
	.short	(LBB178_81-LBB178_70)>>2
	.short	(LBB178_70-LBB178_70)>>2
	.short	(LBB178_70-LBB178_70)>>2
	.short	(LBB178_151-LBB178_70)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function final_check_context
_final_check_context:                   ; @final_check_context
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x7, x1
	mov	x19, x0
	mov	w8, #35860                      ; =0x8c14
	add	x25, x0, x8
	mov	w17, #37600                     ; =0x92e0
	ldr	x8, [x0, x17]
	cbz	x8, LBB179_7
; %bb.1:
	ldrb	w9, [x25, #1772]
	tbnz	w9, #0, LBB179_3
; %bb.2:
	ldrb	w9, [x25, #1773]
	tbz	w9, #0, LBB179_4
LBB179_3:
	mov	w20, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w9, #3                          ; =0x3
Lloh460:
	adrp	x10, l_.str.101@PAGE
Lloh461:
	add	x10, x10, l_.str.101@PAGEOFF
	b	LBB179_170
LBB179_4:
	add	x9, x25, #1764
	ldr	x10, [x9]
	mov	w11, #65025                     ; =0xfe01
	movk	w11, #255, lsl #16
	cmp	x10, x11
	b.lo	LBB179_6
LBB179_5:
	mov	w20, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x25, #1772]
Lloh462:
	adrp	x10, l_.str.101@PAGE
Lloh463:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w9, #3                          ; =0x3
	b	LBB179_170
LBB179_6:
	add	x10, x10, #512
	str	x10, [x9]
LBB179_7:
	mov	w9, #30738                      ; =0x7812
	add	x9, x19, x9
	ldr	w10, [x25, #1732]
	cbz	w10, LBB179_11
; %bb.8:
	mov	x11, x9
LBB179_9:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #16
	cbnz	w12, LBB179_140
; %bb.10:                               ;   in Loop: Header=BB179_9 Depth=1
	subs	x10, x10, #1
	b.ne	LBB179_9
LBB179_11:
	ldr	x8, [x19]
	ldr	w10, [x8, #272]
	mov	w30, #1                         ; =0x1
	cbz	w10, LBB179_142
; %bb.12:
	mov	x20, #0                         ; =0x0
	add	x13, x19, #8
	add	x10, x25, #1764
	stur	x10, [x29, #-120]               ; 8-byte Folded Spill
	add	x10, x9, #4086
	lsl	w9, w30, w2
	str	w9, [sp, #52]                   ; 4-byte Folded Spill
	mov	w9, #36480                      ; =0x8e80
	add	x9, x19, x9
	stp	x9, x10, [sp, #112]             ; 16-byte Folded Spill
	mov	w9, #35904                      ; =0x8c40
	add	x9, x19, x9
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	mov	w9, #35968                      ; =0x8c80
	add	x9, x19, x9
	str	x9, [sp, #104]                  ; 8-byte Folded Spill
	mov	w9, #37640                      ; =0x9308
	add	x9, x19, x9
	str	x9, [sp, #96]                   ; 8-byte Folded Spill
	add	x9, x25, #2812
	str	x9, [sp, #88]                   ; 8-byte Folded Spill
	add	x9, x25, #2804
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	mov	w14, #120                       ; =0x78
	mov	w15, #24                        ; =0x18
	stur	x7, [x29, #-112]                ; 8-byte Folded Spill
	str	x3, [sp, #128]                  ; 8-byte Folded Spill
	str	x13, [sp, #40]                  ; 8-byte Folded Spill
LBB179_13:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB179_23 Depth 2
                                        ;       Child Loop BB179_37 Depth 3
                                        ;       Child Loop BB179_116 Depth 3
                                        ;       Child Loop BB179_131 Depth 3
                                        ;       Child Loop BB179_91 Depth 3
                                        ;       Child Loop BB179_104 Depth 3
	madd	x26, x20, x14, x13
	ldr	x9, [x19, x17]
	ldr	x10, [x8, #256]
	cbz	x9, LBB179_16
; %bb.14:                               ;   in Loop: Header=BB179_13 Depth=1
	madd	x11, x20, x15, x10
	ldrb	w12, [x11, #21]
	cbz	w12, LBB179_16
; %bb.15:                               ;   in Loop: Header=BB179_13 Depth=1
	ldrh	w12, [x26, #48]
	ldrb	w11, [x11, #20]
	lsl	w11, w30, w11
	cmp	w12, w11, uxth
	b.ne	LBB179_157
LBB179_16:                              ;   in Loop: Header=BB179_13 Depth=1
	madd	x10, x20, x15, x10
	ldrb	w10, [x10, #21]
	cbz	w10, LBB179_19
; %bb.17:                               ;   in Loop: Header=BB179_13 Depth=1
	ldrb	w10, [x26, #50]
	cbnz	w10, LBB179_147
; %bb.18:                               ;   in Loop: Header=BB179_13 Depth=1
	ldrh	w10, [x26, #48]
	cbz	w10, LBB179_147
LBB179_19:                              ;   in Loop: Header=BB179_13 Depth=1
	ldr	w9, [x26, #8]
	cbz	w9, LBB179_139
; %bb.20:                               ;   in Loop: Header=BB179_13 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	b	LBB179_23
LBB179_21:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	w8, [x7, #2056]
	add	w8, w8, #1
	str	w8, [x7, #2056]
LBB179_22:                              ;   in Loop: Header=BB179_23 Depth=2
	add	x28, x28, #1
	ldr	w8, [x26, #8]
	add	x21, x21, #16
	cmp	x28, x8
	b.hs	LBB179_138
LBB179_23:                              ;   Parent Loop BB179_13 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB179_37 Depth 3
                                        ;       Child Loop BB179_116 Depth 3
                                        ;       Child Loop BB179_131 Depth 3
                                        ;       Child Loop BB179_91 Depth 3
                                        ;       Child Loop BB179_104 Depth 3
	ldr	x8, [x19, x17]
	cbz	x8, LBB179_28
; %bb.24:                               ;   in Loop: Header=BB179_23 Depth=2
	ldrb	w9, [x25, #1772]
	tbnz	w9, #0, LBB179_3
; %bb.25:                               ;   in Loop: Header=BB179_23 Depth=2
	ldrb	w9, [x25, #1773]
	tbnz	w9, #0, LBB179_3
; %bb.26:                               ;   in Loop: Header=BB179_23 Depth=2
	ldur	x10, [x29, #-120]               ; 8-byte Folded Reload
	ldr	x9, [x10]
	mov	w11, #65025                     ; =0xfe01
	movk	w11, #255, lsl #16
	cmp	x9, x11
	b.hs	LBB179_5
; %bb.27:                               ;   in Loop: Header=BB179_23 Depth=2
	add	x9, x9, #512
	str	x9, [x10]
LBB179_28:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x9, [x26, #96]
	ldrb	w9, [x9, x28]
	cbz	w9, LBB179_22
; %bb.29:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x9, [x26]
	mov	w10, #104                       ; =0x68
	madd	x27, x28, x10, x9
	ldrb	w24, [x27, #40]
	cbz	x8, LBB179_42
; %bb.30:                               ;   in Loop: Header=BB179_23 Depth=2
	and	w9, w24, #0xfffffff7
	and	w9, w9, #0xff
	cmp	w9, #51
	b.ne	LBB179_42
; %bb.31:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	w9, [x27, #48]
	ldr	x10, [sp, #128]                 ; 8-byte Folded Reload
	cbz	x10, LBB179_34
; %bb.32:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x10, [sp, #120]                 ; 8-byte Folded Reload
	ldr	x10, [x10]
	cbz	x10, LBB179_146
; %bb.33:                               ;   in Loop: Header=BB179_23 Depth=2
	add	x10, x10, x9
	mov	w11, #8200                      ; =0x2008
	ldrb	w10, [x10, x11]
	cbz	w10, LBB179_146
LBB179_34:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x12, [x19]
	ldr	x10, [x12, #256]
	mov	w11, #24                        ; =0x18
	umaddl	x10, w9, w11, x10
	ldrh	w10, [x10, #4]
	cbz	x10, LBB179_42
; %bb.35:                               ;   in Loop: Header=BB179_23 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x13, [x26, #32]
	ldr	w14, [x26, #92]
	ldrh	w15, [x26, #66]
	ldr	x12, [x12, #264]
	mul	x14, x21, x14
	add	x14, x14, x15, lsl #4
	sub	x14, x14, x10, lsl #4
	add	x13, x13, x14
	b	LBB179_37
LBB179_36:                              ;   in Loop: Header=BB179_37 Depth=3
	add	x11, x11, #1
	add	x13, x13, #16
	cmp	x10, x11
	b.eq	LBB179_42
LBB179_37:                              ;   Parent Loop BB179_13 Depth=1
                                        ;     Parent Loop BB179_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x12, LBB179_36
; %bb.38:                               ;   in Loop: Header=BB179_37 Depth=3
	ldr	x14, [x12, x9, lsl #3]
	cbz	x14, LBB179_36
; %bb.39:                               ;   in Loop: Header=BB179_37 Depth=3
	ldrb	w14, [x14, x11]
	cbz	w14, LBB179_36
; %bb.40:                               ;   in Loop: Header=BB179_37 Depth=3
	ldr	x15, [x26, #56]
	ldrh	w15, [x15, x28, lsl #1]
	add	x15, x13, x15, lsl #4
	ldrb	w16, [x15, #10]
	cbnz	w16, LBB179_145
; %bb.41:                               ;   in Loop: Header=BB179_37 Depth=3
	ldrh	w15, [x15, #8]
	lsl	w14, w30, w14
	cmp	w15, w14, uxth
	b.eq	LBB179_36
	b	LBB179_145
LBB179_42:                              ;   in Loop: Header=BB179_23 Depth=2
	cbz	x7, LBB179_52
; %bb.43:                               ;   in Loop: Header=BB179_23 Depth=2
	sub	w9, w24, #120
	cmp	w9, #5
	b.hs	LBB179_51
LBB179_44:                              ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #120
	b.eq	LBB179_22
; %bb.45:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x9, [x26, #56]
	ldrh	w9, [x9, x28, lsl #1]
	cmp	w24, #127
	cinc	w10, w30, ne
	cmp	w24, #122
	mov	w11, #3                         ; =0x3
	csel	w10, w11, w10, eq
	subs	w9, w9, w10
	b.lo	LBB179_149
; %bb.46:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x8, [x26, #32]
	ldr	w10, [x26, #92]
	mul	x10, x28, x10
	add	x8, x8, x10, lsl #4
	ldrh	w10, [x26, #66]
	add	x8, x8, x10, lsl #4
	ldr	w3, [x27]
	add	x22, x8, w9, uxtw #4
	ldp	x4, x5, [x22]
	mov	x0, x19
	mov	x1, x7
	mov	x2, x20
	bl	_map_receiver
	cbz	w0, LBB179_172
; %bb.47:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #127
	mov	w17, #37600                     ; =0x92e0
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	b.eq	LBB179_21
; %bb.48:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	w23, [x27]
	ldp	x8, x9, [x22, #16]
	and	x9, x9, #0xffffff
	cmp	x9, #32
	ccmp	x8, #0, #0, eq
	b.ne	LBB179_152
; %bb.49:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #122
	b.ne	LBB179_21
; %bb.50:                               ;   in Loop: Header=BB179_23 Depth=2
	ldp	x8, x9, [x22, #32]
	and	x10, x9, #0xff0000
	orr	x8, x10, x8
	cmp	x8, #0
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	eor	w8, w8, w9
	and	w8, w8, #0xffff
	ccmp	w8, #0, #0, eq
	b.eq	LBB179_21
	b	LBB179_152
LBB179_51:                              ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #127
	b.eq	LBB179_44
LBB179_52:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x1, [sp, #128]                  ; 8-byte Folded Reload
	cbz	x1, LBB179_68
; %bb.53:                               ;   in Loop: Header=BB179_23 Depth=2
	sub	w9, w24, #96
	cmp	w9, #4
	b.lo	LBB179_55
; %bb.54:                               ;   in Loop: Header=BB179_23 Depth=2
	sub	w9, w24, #251
	cmp	w9, #2
	b.hs	LBB179_67
LBB179_55:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x8, [x26, #32]
	ldr	w9, [x26, #92]
	mul	x9, x28, x9
	add	x8, x8, x9, lsl #4
	ldrh	w9, [x26, #66]
	add	x8, x8, x9, lsl #4
	ldr	x9, [x26, #56]
	ldrh	w9, [x9, x28, lsl #1]
	cmp	w24, #250
	b.gt	LBB179_58
; %bb.56:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #96
	b.eq	LBB179_61
; %bb.57:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #99
	b.eq	LBB179_61
	b	LBB179_64
LBB179_58:                              ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #251
	b.eq	LBB179_61
; %bb.59:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #254
	b.ne	LBB179_64
; %bb.60:                               ;   in Loop: Header=BB179_23 Depth=2
	add	x8, x8, x9, lsl #4
	ldr	w5, [x27]
	ldp	x1, x2, [x8, #-16]
	mov	x0, x19
	mov	w3, #10                         ; =0xa
	b	LBB179_63
LBB179_61:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x10, [x26, #112]
	ldrsh	x11, [x10, x28, lsl #1]
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	ldrh	w10, [x10, w11, uxtw #1]
	cbz	x10, LBB179_22
; %bb.62:                               ;   in Loop: Header=BB179_23 Depth=2
	mov	w11, w11
	sub	x9, x9, x10
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	ldrb	w10, [x10, x11]
	add	x8, x8, x9, lsl #4
	ldr	w5, [x27]
	ldp	x1, x2, [x8]
	cmp	w10, #3
	mov	w8, #10                         ; =0xa
	csinc	w3, w8, wzr, ne
	mov	x0, x19
LBB179_63:                              ;   in Loop: Header=BB179_23 Depth=2
	mov	x4, x20
	bl	_uf_value
	b	LBB179_83
LBB179_64:                              ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #98
	mov	w10, #253                       ; =0xfd
	ccmp	w24, w10, #4, ne
	cset	w5, eq
	mov	x10, #-32                       ; =0xffffffffffffffe0
	mov	x11, #-16                       ; =0xfffffffffffffff0
	csel	x10, x10, x11, eq
	cmp	w24, #253
	b.eq	LBB179_66
; %bb.65:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #98
	b.ne	LBB179_106
LBB179_66:                              ;   in Loop: Header=BB179_23 Depth=2
	add	x11, x8, x9, lsl #4
	ldp	x6, x7, [x11, #-16]
	b	LBB179_107
LBB179_67:                              ;   in Loop: Header=BB179_23 Depth=2
	add	w9, w24, #3
	and	w9, w9, #0xff
	cmp	w9, #1
	b.ls	LBB179_55
LBB179_68:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	w9, [x25]
	cbz	w9, LBB179_70
; %bb.69:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #95
	b.gt	LBB179_84
LBB179_70:                              ;   in Loop: Header=BB179_23 Depth=2
	sub	w8, w24, #81
	cmp	w8, #6
	b.hs	LBB179_101
; %bb.71:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x8, [x26, #56]
	ldrh	w22, [x8, x28, lsl #1]
	mov	x0, x24
	bl	_isa_get_info
	ldrsb	x9, [x0, #28]
	ldr	x8, [x26, #32]
	ldr	w10, [x26, #92]
	mul	x10, x28, x10
	add	x8, x8, x10, lsl #4
	ldrh	w10, [x26, #66]
	add	x8, x8, x10, lsl #4
	sub	x9, x22, x9
	add	x9, x8, x9, lsl #4
	ldr	x4, [x9, #8]
	and	x10, x4, #0xff0000
	and	x11, x4, #0xffff
	cmp	x10, #0
	ccmp	x11, #0, #4, eq
	b.eq	LBB179_155
; %bb.72:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	x3, [x9]
	tbz	w4, #7, LBB179_74
; %bb.73:                               ;   in Loop: Header=BB179_23 Depth=2
	cbz	x3, LBB179_155
LBB179_74:                              ;   in Loop: Header=BB179_23 Depth=2
	and	w10, w4, #0xffff
	cmp	w10, #128
	mov	w17, #37600                     ; =0x92e0
	b.eq	LBB179_76
; %bb.75:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	w10, [x25, #756]
	add	w10, w10, #1
	str	w10, [x25, #756]
LBB179_76:                              ;   in Loop: Header=BB179_23 Depth=2
	sub	w10, w24, #83
	and	w10, w10, #0xff
	cmp	w10, #1
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	b.hi	LBB179_80
; %bb.77:                               ;   in Loop: Header=BB179_23 Depth=2
	ldrh	w10, [x9, #24]
	ldrb	w9, [x9, #26]
	cmp	w9, #0
	ccmp	w10, #0, #4, eq
	b.eq	LBB179_162
; %bb.78:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w10, #2
	b.eq	LBB179_80
; %bb.79:                               ;   in Loop: Header=BB179_23 Depth=2
	ldr	w9, [x25, #756]
	add	w9, w9, #1
	str	w9, [x25, #756]
LBB179_80:                              ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #84
	b.eq	LBB179_82
; %bb.81:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #81
	b.ne	LBB179_22
LBB179_82:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	w2, [x27]
	add	x8, x8, x22, lsl #4
	ldp	x5, x6, [x8, #-16]
	mov	x0, x19
	mov	x1, x20
	bl	_check_write
LBB179_83:                              ;   in Loop: Header=BB179_23 Depth=2
	mov	w30, #1                         ; =0x1
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w17, #37600                     ; =0x92e0
	cbnz	w0, LBB179_22
	b	LBB179_172
LBB179_84:                              ;   in Loop: Header=BB179_23 Depth=2
	sub	w9, w24, #96
	cmp	w9, #4
	b.lo	LBB179_86
; %bb.85:                               ;   in Loop: Header=BB179_23 Depth=2
	sub	w9, w24, #251
	cmp	w9, #2
	b.hi	LBB179_22
LBB179_86:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x9, [x26, #32]
	ldr	w12, [x26, #92]
	ldrh	w10, [x26, #66]
	ldr	x11, [x26, #56]
	ldrh	w11, [x11, x28, lsl #1]
	cmp	w24, #96
	b.eq	LBB179_89
; %bb.87:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #251
	b.eq	LBB179_89
; %bb.88:                               ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #99
	b.ne	LBB179_108
LBB179_89:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x8, [x26, #112]
	ldrsh	x8, [x8, x28, lsl #1]
	ldr	x13, [sp, #112]                 ; 8-byte Folded Reload
	ldrh	w13, [x13, w8, uxtw #1]
	str	x13, [sp, #80]                  ; 8-byte Folded Spill
	cbz	x13, LBB179_22
; %bb.90:                               ;   in Loop: Header=BB179_23 Depth=2
	mov	x24, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	w15, w8
	ldur	x8, [x25, #12]
	ldr	x13, [x8, #24]
	ldr	x14, [sp, #104]                 ; 8-byte Folded Reload
	str	x15, [sp, #32]                  ; 8-byte Folded Spill
	ldr	w14, [x14, x15, lsl #2]
	ldr	w13, [x13, x14, lsl #2]
	ldr	x8, [x8]
	add	x8, x8, x13, lsl #4
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mul	x8, x21, x12
	add	x8, x8, x11, lsl #4
	add	x8, x8, x10, lsl #4
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	sub	x8, x8, x10, lsl #4
	add	x8, x9, x8
	add	x23, x8, #8
LBB179_91:                              ;   Parent Loop BB179_13 Depth=1
                                        ;     Parent Loop BB179_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x8, [x19, x17]
	cbz	x8, LBB179_99
; %bb.92:                               ;   in Loop: Header=BB179_91 Depth=3
	ldur	x8, [x25, #12]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	w9, [x9, x10, lsl #2]
	ldr	w8, [x8, x9, lsl #2]
	ldp	x9, x10, [sp, #88]              ; 16-byte Folded Reload
	ldr	w8, [x10, x8, lsl #2]
	add	x8, x22, x8
	ldr	x9, [x9]
	cbz	x9, LBB179_95
; %bb.93:                               ;   in Loop: Header=BB179_91 Depth=3
	lsr	w10, w8, #3
	ldrb	w9, [x9, x10]
	and	w10, w8, #0x7
	lsr	w9, w9, w10
	tbz	w9, #0, LBB179_95
; %bb.94:                               ;   in Loop: Header=BB179_91 Depth=3
	mov	w8, #256                        ; =0x100
	b	LBB179_99
LBB179_95:                              ;   in Loop: Header=BB179_91 Depth=3
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	ldrb	w8, [x9, w8, uxtw]
	add	w9, w8, #12
	and	w9, w9, #0xff
	cmp	w9, #4
	b.hi	LBB179_97
; %bb.96:                               ;   in Loop: Header=BB179_91 Depth=3
	add	w8, w8, #13
	and	w9, w8, #0xff
	mov	w10, #2048                      ; =0x800
	lsl	w8, w10, w8
	cmp	w9, #5
	mov	w9, #64                         ; =0x40
	csel	w8, w9, w8, eq
	b	LBB179_99
LBB179_97:                              ;   in Loop: Header=BB179_91 Depth=3
	add	w9, w8, #15
	and	w10, w9, #0xff
	cmp	w10, #3
	b.hs	LBB179_99
; %bb.98:                               ;   in Loop: Header=BB179_91 Depth=3
	ubfiz	x8, x9, #4, #4
	mov	x9, #512                        ; =0x200
	movk	x9, #1024, lsl #16
	movk	x9, #2048, lsl #32
	lsr	x8, x9, x8
LBB179_99:                              ;   in Loop: Header=BB179_91 Depth=3
	ldr	w2, [x27]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldur	x9, [x9, #8]
	ldp	x4, x5, [x23, #-8]
	add	x3, x9, x24
	and	w6, w8, #0xffff
	mov	x0, x19
	mov	x1, x20
	bl	_record_value_matches
	cbz	w0, LBB179_172
; %bb.100:                              ;   in Loop: Header=BB179_91 Depth=3
	add	x22, x22, #1
	add	x23, x23, #16
	add	x24, x24, #12
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cmp	x8, x22
	mov	w17, #37600                     ; =0x92e0
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	b.ne	LBB179_91
	b	LBB179_22
LBB179_101:                             ;   in Loop: Header=BB179_23 Depth=2
	cmp	w24, #88
	b.ne	LBB179_22
; %bb.102:                              ;   in Loop: Header=BB179_23 Depth=2
	ldrh	w8, [x27, #56]
	ldr	x9, [x26, #56]
	ldrh	w9, [x9, x28, lsl #1]
	sub	w22, w9, w8
	cmp	w22, w9
	b.hs	LBB179_22
; %bb.103:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x8, [x26, #32]
	ldr	w9, [x26, #92]
	ldrh	w10, [x26, #66]
	ldr	x11, [x26, #112]
	ldrsh	x11, [x11, x28, lsl #1]
	lsl	x23, x30, x11
	mul	x9, x21, x9
	add	x9, x9, x10, lsl #4
	add	x9, x9, w22, uxtw #4
	add	x8, x8, x9
	add	x24, x8, #8
LBB179_104:                             ;   Parent Loop BB179_13 Depth=1
                                        ;     Parent Loop BB179_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w2, [x27]
	ldp	x5, x6, [x24, #-8]
	mov	x0, x19
	mov	x1, x20
	mov	x3, x23
	mov	w4, #128                        ; =0x80
	bl	_check_write
	cbz	w0, LBB179_172
; %bb.105:                              ;   in Loop: Header=BB179_104 Depth=3
	add	x24, x24, #16
	add	x22, x22, #1
	ldr	x8, [x26, #56]
	ldrh	w8, [x8, x28, lsl #1]
	cmp	x22, x8
	mov	w17, #37600                     ; =0x92e0
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	b.lo	LBB179_104
	b	LBB179_22
LBB179_106:                             ;   in Loop: Header=BB179_23 Depth=2
	mov	x7, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
LBB179_107:                             ;   in Loop: Header=BB179_23 Depth=2
	add	x8, x8, x10
	add	x8, x8, x9, lsl #4
	ldrh	w4, [x27, #48]
	ldr	w9, [x27]
	ldp	x2, x3, [x8]
	sub	x8, x29, #104
	str	x8, [sp, #16]
	stp	w9, w30, [sp, #4]
	str	w20, [sp]
	mov	x0, x19
	bl	_uf_access
	mov	w30, #1                         ; =0x1
	cmp	w0, #1
	mov	w17, #37600                     ; =0x92e0
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	b.eq	LBB179_22
	b	LBB179_171
LBB179_108:                             ;   in Loop: Header=BB179_23 Depth=2
	mul	x12, x28, x12
	add	x9, x9, x12, lsl #4
	add	x9, x9, x10, lsl #4
	cmp	w24, #98
	cset	w10, ne
	cmp	w24, #253
	cset	w12, ne
	ands	w10, w10, w12
	mov	x12, #-32                       ; =0xffffffffffffffe0
	mov	x13, #-16                       ; =0xfffffffffffffff0
	csel	x12, x13, x12, ne
	add	x9, x9, x11, lsl #4
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
	add	x9, x9, x12
	ldp	x12, x11, [x9]
	ldr	w23, [x27]
	ldrh	w27, [x27, #48]
	ldur	x13, [x29, #-120]               ; 8-byte Folded Reload
	ldr	x16, [sp, #56]                  ; 8-byte Folded Reload
	cbz	x8, LBB179_113
; %bb.109:                              ;   in Loop: Header=BB179_23 Depth=2
	ldrb	w9, [x25, #1772]
	tbnz	w9, #0, LBB179_3
; %bb.110:                              ;   in Loop: Header=BB179_23 Depth=2
	ldrb	w9, [x25, #1773]
	tbnz	w9, #0, LBB179_3
; %bb.111:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	x9, [x13]
	mov	w14, #65281                     ; =0xff01
	movk	w14, #255, lsl #16
	cmp	x9, x14
	b.hs	LBB179_5
; %bb.112:                              ;   in Loop: Header=BB179_23 Depth=2
	add	x9, x9, #256
	str	x9, [x13]
LBB179_113:                             ;   in Loop: Header=BB179_23 Depth=2
	ldr	w9, [x25, #748]
	cbz	w9, LBB179_118
; %bb.114:                              ;   in Loop: Header=BB179_23 Depth=2
	mov	x13, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	b	LBB179_116
LBB179_115:                             ;   in Loop: Header=BB179_116 Depth=3
	add	x13, x13, #1
	cmp	x9, x13
	b.eq	LBB179_119
LBB179_116:                             ;   Parent Loop BB179_13 Depth=1
                                        ;     Parent Loop BB179_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x14, x30, x13
	tst	x14, x12
	b.eq	LBB179_115
; %bb.117:                              ;   in Loop: Header=BB179_116 Depth=3
	ldrb	w15, [x16, x13]
	cmp	w15, #1
	csel	x14, x14, xzr, eq
	orr	x24, x14, x24
	b	LBB179_115
LBB179_118:                             ;   in Loop: Header=BB179_23 Depth=2
	mov	x24, #0                         ; =0x0
LBB179_119:                             ;   in Loop: Header=BB179_23 Depth=2
	tst	x11, #0xff0000
	b.ne	LBB179_165
; %bb.120:                              ;   in Loop: Header=BB179_23 Depth=2
	and	x12, x11, #0xffff
	cbz	x12, LBB179_165
; %bb.121:                              ;   in Loop: Header=BB179_23 Depth=2
	tbz	w11, #8, LBB179_123
; %bb.122:                              ;   in Loop: Header=BB179_23 Depth=2
	cbz	x24, LBB179_165
LBB179_123:                             ;   in Loop: Header=BB179_23 Depth=2
	and	w8, w11, #0xffff
	cmp	w8, #256
	b.eq	LBB179_125
; %bb.124:                              ;   in Loop: Header=BB179_23 Depth=2
	ldr	w8, [x25, #756]
	add	w8, w8, #1
	str	w8, [x25, #756]
LBB179_125:                             ;   in Loop: Header=BB179_23 Depth=2
	cbz	x9, LBB179_22
; %bb.126:                              ;   in Loop: Header=BB179_23 Depth=2
	mov	x22, #0                         ; =0x0
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	cmp	x8, #16
	cset	w8, eq
	orr	w10, w10, w8
	str	w10, [sp, #64]                  ; 4-byte Folded Spill
	b	LBB179_131
LBB179_127:                             ;   in Loop: Header=BB179_131 Depth=3
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x11, [x11]
	ldrb	w10, [x11, w10, uxtw]
	add	w11, w10, #12
	and	w11, w11, #0xff
	add	w12, w10, #15
	and	w13, w12, #0xff
	ubfiz	x12, x12, #4, #4
	mov	x14, #512                       ; =0x200
	movk	x14, #1024, lsl #16
	movk	x14, #2048, lsl #32
	lsr	x12, x14, x12
	cmp	w13, #3
	csel	w12, w12, w10, lo
	add	w10, w10, #13
	and	w13, w10, #0xff
	mov	w14, #2048                      ; =0x800
	lsl	w10, w14, w10
	cmp	w13, #5
	mov	w13, #64                        ; =0x40
	csel	w10, w13, w10, eq
	cmp	w11, #4
	csel	w10, w12, w10, hi
LBB179_128:                             ;   in Loop: Header=BB179_131 Depth=3
	ldr	x8, [x8]
	add	x8, x8, x9, lsl #4
	ldr	x8, [x8, #8]
	mov	w9, #12                         ; =0xc
	umaddl	x3, w27, w9, x8
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldp	x4, x5, [x8, #-16]
	and	w6, w10, #0xffff
	mov	x0, x19
	mov	x1, x20
	mov	x2, x23
	bl	_record_value_matches
	cbz	w0, LBB179_172
; %bb.129:                              ;   in Loop: Header=BB179_131 Depth=3
	ldr	w9, [x25, #748]
	mov	w17, #37600                     ; =0x92e0
	ldur	x7, [x29, #-112]                ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	ldr	w10, [sp, #64]                  ; 4-byte Folded Reload
LBB179_130:                             ;   in Loop: Header=BB179_131 Depth=3
	add	x22, x22, #1
	cmp	x22, x9
	b.hs	LBB179_22
LBB179_131:                             ;   Parent Loop BB179_13 Depth=1
                                        ;     Parent Loop BB179_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x8, x24, x22
	tbz	w8, #0, LBB179_130
; %bb.132:                              ;   in Loop: Header=BB179_131 Depth=3
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	ldrh	w8, [x8, x22, lsl #1]
	cmp	w27, w8
	b.hs	LBB179_159
; %bb.133:                              ;   in Loop: Header=BB179_131 Depth=3
	tbnz	w10, #0, LBB179_130
; %bb.134:                              ;   in Loop: Header=BB179_131 Depth=3
	ldur	x8, [x25, #12]
	ldr	x9, [x8, #24]
	ldr	x10, [sp, #112]                 ; 8-byte Folded Reload
	add	x10, x10, x22, lsl #2
	sub	x10, x10, #512
	ldr	w10, [x10]
	ldr	w9, [x9, x10, lsl #2]
	ldr	x10, [x19, x17]
	cbz	x10, LBB179_128
; %bb.135:                              ;   in Loop: Header=BB179_131 Depth=3
	ldp	x11, x10, [sp, #88]             ; 16-byte Folded Reload
	ldr	w10, [x10, x9, lsl #2]
	add	w10, w10, w27
	ldr	x11, [x11]
	cbz	x11, LBB179_127
; %bb.136:                              ;   in Loop: Header=BB179_131 Depth=3
	lsr	x12, x10, #3
	ldrb	w11, [x11, x12]
	and	w12, w10, #0x7
	lsr	w11, w11, w12
	tbz	w11, #0, LBB179_127
; %bb.137:                              ;   in Loop: Header=BB179_131 Depth=3
	mov	w10, #256                       ; =0x100
	b	LBB179_128
LBB179_138:                             ;   in Loop: Header=BB179_13 Depth=1
	ldr	x8, [x19]
	ldr	x13, [sp, #40]                  ; 8-byte Folded Reload
	mov	w14, #120                       ; =0x78
	mov	w15, #24                        ; =0x18
LBB179_139:                             ;   in Loop: Header=BB179_13 Depth=1
	add	x20, x20, #1
	ldr	w9, [x8, #272]
	mov	w0, #1                          ; =0x1
	cmp	x20, x9
	b.lo	LBB179_13
	b	LBB179_172
LBB179_140:
	mov	w20, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	cbz	x8, LBB179_143
; %bb.141:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
	b	LBB179_144
LBB179_142:
	mov	w0, #1                          ; =0x1
	b	LBB179_172
LBB179_143:
	mov	w9, #1                          ; =0x1
LBB179_144:
Lloh464:
	adrp	x10, l_.str.128@PAGE
Lloh465:
	add	x10, x10, l_.str.128@PAGEOFF
	b	LBB179_170
LBB179_145:
	ldr	w23, [x27]
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh466:
	adrp	x10, l_.str.132@PAGE
Lloh467:
	add	x10, x10, l_.str.132@PAGEOFF
	b	LBB179_170
LBB179_146:
	ldr	w23, [x27]
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh468:
	adrp	x10, l_.str.131@PAGE
Lloh469:
	add	x10, x10, l_.str.131@PAGEOFF
	b	LBB179_170
LBB179_147:
	mov	w23, #0                         ; =0x0
	cbz	x9, LBB179_154
; %bb.148:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh470:
	adrp	x10, l_.str.130@PAGE
Lloh471:
	add	x10, x10, l_.str.130@PAGEOFF
	b	LBB179_170
LBB179_149:
	ldr	w23, [x27]
	mov	w9, #2                          ; =0x2
	cbz	x8, LBB179_151
; %bb.150:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	cinc	w9, w9, ne
LBB179_151:
Lloh472:
	adrp	x10, l_.str.135@PAGE
Lloh473:
	add	x10, x10, l_.str.135@PAGEOFF
	b	LBB179_170
LBB179_152:
	ldr	x8, [x19, x17]
	cbz	x8, LBB179_158
; %bb.153:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh474:
	adrp	x10, l_.str.139@PAGE
Lloh475:
	add	x10, x10, l_.str.139@PAGEOFF
	b	LBB179_170
LBB179_154:
Lloh476:
	adrp	x10, l_.str.130@PAGE
Lloh477:
	add	x10, x10, l_.str.130@PAGEOFF
	b	LBB179_169
LBB179_155:
	ldr	w23, [x27]
	mov	w8, #37600                      ; =0x92e0
	ldr	x8, [x19, x8]
	cbz	x8, LBB179_161
; %bb.156:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh478:
	adrp	x10, l_.str.133@PAGE
Lloh479:
	add	x10, x10, l_.str.133@PAGEOFF
	b	LBB179_170
LBB179_157:
	mov	w23, #0                         ; =0x0
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh480:
	adrp	x10, l_.str.129@PAGE
Lloh481:
	add	x10, x10, l_.str.129@PAGEOFF
	b	LBB179_170
LBB179_158:
Lloh482:
	adrp	x10, l_.str.139@PAGE
Lloh483:
	add	x10, x10, l_.str.139@PAGEOFF
	b	LBB179_169
LBB179_159:
	ldr	x8, [x19, x17]
	cbz	x8, LBB179_164
; %bb.160:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh484:
	adrp	x10, l_.str.147@PAGE
Lloh485:
	add	x10, x10, l_.str.147@PAGEOFF
	b	LBB179_170
LBB179_161:
Lloh486:
	adrp	x10, l_.str.133@PAGE
Lloh487:
	add	x10, x10, l_.str.133@PAGEOFF
	b	LBB179_169
LBB179_162:
	ldr	w23, [x27]
	ldr	x8, [x19, x17]
	cbz	x8, LBB179_167
; %bb.163:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh488:
	adrp	x10, l_.str.134@PAGE
Lloh489:
	add	x10, x10, l_.str.134@PAGEOFF
	b	LBB179_170
LBB179_164:
Lloh490:
	adrp	x10, l_.str.147@PAGE
Lloh491:
	add	x10, x10, l_.str.147@PAGEOFF
	b	LBB179_169
LBB179_165:
	cbz	x8, LBB179_168
; %bb.166:
	ldrb	w8, [x25, #1772]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh492:
	adrp	x10, l_.str.146@PAGE
Lloh493:
	add	x10, x10, l_.str.146@PAGEOFF
	b	LBB179_170
LBB179_167:
Lloh494:
	adrp	x10, l_.str.134@PAGE
Lloh495:
	add	x10, x10, l_.str.134@PAGEOFF
	b	LBB179_169
LBB179_168:
Lloh496:
	adrp	x10, l_.str.146@PAGE
Lloh497:
	add	x10, x10, l_.str.146@PAGEOFF
LBB179_169:
	mov	w9, #1                          ; =0x1
LBB179_170:
	str	w9, [x25, #1528]
	str	w20, [x25, #1532]
	mov	w8, #37400                      ; =0x9218
	str	w23, [x25, #1536]
	mov	w9, #191                        ; =0xbf
	stp	x9, x10, [sp]
Lloh498:
	adrp	x2, l_.str.52@PAGE
Lloh499:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB179_171:
	mov	w0, #0                          ; =0x0
LBB179_172:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.loh AdrpAdd	Lloh460, Lloh461
	.loh AdrpAdd	Lloh462, Lloh463
	.loh AdrpAdd	Lloh464, Lloh465
	.loh AdrpAdd	Lloh466, Lloh467
	.loh AdrpAdd	Lloh468, Lloh469
	.loh AdrpAdd	Lloh470, Lloh471
	.loh AdrpAdd	Lloh472, Lloh473
	.loh AdrpAdd	Lloh474, Lloh475
	.loh AdrpAdd	Lloh476, Lloh477
	.loh AdrpAdd	Lloh478, Lloh479
	.loh AdrpAdd	Lloh480, Lloh481
	.loh AdrpAdd	Lloh482, Lloh483
	.loh AdrpAdd	Lloh484, Lloh485
	.loh AdrpAdd	Lloh486, Lloh487
	.loh AdrpAdd	Lloh488, Lloh489
	.loh AdrpAdd	Lloh490, Lloh491
	.loh AdrpAdd	Lloh492, Lloh493
	.loh AdrpAdd	Lloh494, Lloh495
	.loh AdrpAdd	Lloh496, Lloh497
	.loh AdrpAdd	Lloh498, Lloh499
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function uf_export_sites
lCPI180_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_uf_export_sites:                       ; @uf_export_sites
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w8, #36608                      ; =0x8f00
	add	x27, x0, x8
	ldr	x19, [x0]
	ldr	w9, [x19, #272]
	ldr	x8, [x27, #992]
	cbz	x8, LBB180_5
; %bb.1:
	ldrb	w10, [x27, #1024]
	tbnz	w10, #0, LBB180_17
; %bb.2:
	ldrb	w10, [x27, #1025]
	tbnz	w10, #0, LBB180_17
; %bb.3:
	ldr	x10, [x27, #1016]
	mov	w11, #16777216                  ; =0x1000000
	sub	x12, x11, x10
	cmp	x10, x11
	ccmp	x12, x9, #0, ls
	b.hs	LBB180_14
LBB180_4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1024]
	b	LBB180_17
LBB180_5:
	cbz	w9, LBB180_12
LBB180_6:
	mov	x10, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	add	x11, x0, #16
	mov	w12, #65536                     ; =0x10000
LBB180_7:                               ; =>This Inner Loop Header: Depth=1
	ldr	w13, [x11], #120
	sub	w14, w12, w20
	cmp	w13, w14
	b.hi	LBB180_11
; %bb.8:                                ;   in Loop: Header=BB180_7 Depth=1
	add	w20, w13, w20
	add	x10, x10, #1
	cmp	x9, x10
	b.ne	LBB180_7
; %bb.9:
	cbz	x8, LBB180_21
; %bb.10:
	mov	w21, #0                         ; =0x0
	ubfiz	x8, x20, #9, #32
	mov	x25, x20
	ldrb	w9, [x27, #1024]
	tbz	w9, #0, LBB180_16
	b	LBB180_17
LBB180_11:
	mov	w8, #3                          ; =0x3
	str	w8, [x27, #780]
	str	w10, [x27, #784]
	str	wzr, [x27, #788]
	mov	w8, #37400                      ; =0x9218
Lloh500:
	adrp	x9, l_.str.152@PAGE
Lloh501:
	add	x9, x9, l_.str.152@PAGEOFF
	b	LBB180_18
LBB180_12:
	mov	x12, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
LBB180_13:
	str	x12, [x2]
	mov	w0, #1                          ; =0x1
	stp	w25, wzr, [x2, #8]
	b	LBB180_20
LBB180_14:
	add	x10, x10, x9
	str	x10, [x27, #1016]
	cbnz	w9, LBB180_6
; %bb.15:
	mov	x8, #0                          ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
	mov	w21, #1                         ; =0x1
	ldrb	w9, [x27, #1024]
	tbnz	w9, #0, LBB180_17
LBB180_16:
	ldrb	w9, [x27, #1025]
	tbz	w9, #0, LBB180_24
LBB180_17:
Lloh502:
	adrp	x8, lCPI180_0@PAGE
Lloh503:
	ldr	d0, [x8, lCPI180_0@PAGEOFF]
	add	x8, x27, #780
	str	d0, [x8]
	str	wzr, [x27, #788]
	mov	w8, #37400                      ; =0x9218
Lloh504:
	adrp	x9, l_.str.101@PAGE
Lloh505:
	add	x9, x9, l_.str.101@PAGEOFF
LBB180_18:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh506:
	adrp	x2, l_.str.52@PAGE
Lloh507:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB180_19:
	mov	w0, #0                          ; =0x0
LBB180_20:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB180_21:
	cbz	w20, LBB180_37
; %bb.22:
	mov	x23, x1
	mov	x24, x2
	mov	x22, x0
	mov	x0, x20
	mov	w1, #72                         ; =0x48
	bl	_calloc
	cbz	x0, LBB180_41
; %bb.23:
	mov	x12, x0
	mov	w21, #0                         ; =0x0
	mov	x25, x20
	mov	x0, x22
	mov	x2, x24
	mov	x1, x23
	b	LBB180_39
LBB180_24:
	ldr	x9, [x27, #1016]
	mov	w10, #16777216                  ; =0x1000000
	cmp	x9, x10
	b.hi	LBB180_4
; %bb.25:
	sub	x10, x10, x9
	cmp	x8, x10
	b.hi	LBB180_4
; %bb.26:
	add	x8, x9, x8
	str	x8, [x27, #1016]
	cbz	w25, LBB180_38
; %bb.27:
	ldrb	w8, [x27, #1024]
	tbnz	w8, #0, LBB180_128
; %bb.28:
	ldrb	w8, [x27, #1025]
	tbnz	w8, #0, LBB180_128
; %bb.29:
	ldr	x8, [x27, #1000]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB180_127
; %bb.30:
	add	x9, x20, x20, lsl #3
	lsl	x9, x9, #3
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB180_127
; %bb.31:
	ldr	x10, [x27, #1008]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x27, #1000]
	b.hs	LBB180_33
; %bb.32:
	str	x8, [x27, #1008]
LBB180_33:
	ldr	x8, [x27, #1016]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB180_127
; %bb.34:
	sub	x9, x9, x8
	cmp	x9, x20
	b.lo	LBB180_127
; %bb.35:
	add	x8, x8, x20
	str	x8, [x27, #1016]
	mov	x22, x0
	mov	x0, x20
	mov	x20, x1
	mov	w1, #72                         ; =0x48
	mov	x23, x2
	bl	_calloc
	mov	x1, x20
	mov	x2, x23
	mov	x12, x0
	mov	x0, x22
	cbnz	x12, LBB180_39
; %bb.36:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1025]
	b	LBB180_128
LBB180_37:
	mov	w21, #0                         ; =0x0
	mov	w25, #0                         ; =0x0
LBB180_38:
	mov	x12, #0                         ; =0x0
LBB180_39:
	tbnz	w21, #0, LBB180_13
; %bb.40:
	str	w25, [sp, #36]                  ; 4-byte Folded Spill
	mov	x3, #0                          ; =0x0
	mov	w21, #0                         ; =0x0
	add	x9, x0, #8
	mov	w8, #36480                      ; =0x8e80
	add	x8, x0, x8
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mov	w8, #35968                      ; =0x8c80
	add	x8, x0, x8
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	mov	w8, #35904                      ; =0x8c40
	add	x8, x0, x8
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	add	x8, x1, #1032
	stur	x8, [x29, #-120]                ; 8-byte Folded Spill
	mov	w10, #120                       ; =0x78
	mov	w13, #104                       ; =0x68
	mov	w14, #72                        ; =0x48
	mov	x15, #-1                        ; =0xffffffffffffffff
	mov	w16, #2                         ; =0x2
	stp	x12, x1, [sp, #88]              ; 16-byte Folded Spill
	str	x2, [sp, #72]                   ; 8-byte Folded Spill
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB180_44
LBB180_41:
	mov	w8, #4                          ; =0x4
	mov	x0, x22
	b	LBB180_129
LBB180_42:                              ;   in Loop: Header=BB180_44 Depth=1
	ldr	x19, [x0]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	mov	w10, #120                       ; =0x78
LBB180_43:                              ;   in Loop: Header=BB180_44 Depth=1
	add	x3, x3, #1
	ldr	w8, [x19, #272]
	cmp	x3, x8
	b.hs	LBB180_134
LBB180_44:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB180_47 Depth 2
                                        ;       Child Loop BB180_95 Depth 3
	madd	x5, x3, x10, x9
	ldr	w8, [x5, #8]
	cbz	w8, LBB180_43
; %bb.45:                               ;   in Loop: Header=BB180_44 Depth=1
	mov	x22, #0                         ; =0x0
	stur	x3, [x29, #-112]                ; 8-byte Folded Spill
	str	x5, [sp, #80]                   ; 8-byte Folded Spill
	b	LBB180_47
LBB180_46:                              ;   in Loop: Header=BB180_47 Depth=2
	add	x22, x22, #1
	add	w21, w21, #1
	cmp	x22, x8
	b.hs	LBB180_42
LBB180_47:                              ;   Parent Loop BB180_44 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB180_95 Depth 3
	mov	w10, #0                         ; =0x0
	ldr	x9, [x5]
	madd	x24, x22, x13, x9
	umaddl	x25, w21, w14, x12
	ldr	w4, [x24]
	stp	w3, w4, [x25]
	mov	x17, x25
	str	x15, [x17, #56]!
	stur	w15, [x25, #63]
	ldrb	w9, [x24, #40]
	sub	w11, w9, #96
	cmp	w11, #4
	b.lo	LBB180_49
; %bb.48:                               ;   in Loop: Header=BB180_47 Depth=2
	sub	w11, w9, #251
	cmp	w11, #3
	b.hs	LBB180_65
LBB180_49:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #1                         ; =0x1
	strb	w11, [x25, #68]
	cmp	w9, #162
	b.gt	LBB180_54
; %bb.50:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #97
	b.gt	LBB180_58
; %bb.51:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #96
	b.eq	LBB180_69
; %bb.52:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #97
	b.ne	LBB180_68
; %bb.53:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #4                         ; =0x4
	b	LBB180_69
LBB180_54:                              ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #252
	b.gt	LBB180_61
; %bb.55:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #163
	b.eq	LBB180_67
; %bb.56:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #251
	b.ne	LBB180_68
; %bb.57:                               ;   in Loop: Header=BB180_47 Depth=2
	ldrb	w11, [x24, #48]
	cmp	w11, #1
	cinc	w11, w16, eq
	b	LBB180_69
LBB180_58:                              ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #98
	b.eq	LBB180_64
; %bb.59:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #99
	b.ne	LBB180_68
; %bb.60:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #2                         ; =0x2
	b	LBB180_69
LBB180_61:                              ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #253
	b.eq	LBB180_64
; %bb.62:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #254
	b.ne	LBB180_68
; %bb.63:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #7                         ; =0x7
	b	LBB180_69
LBB180_64:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #6                         ; =0x6
	b	LBB180_69
LBB180_65:                              ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #163
	cset	w10, eq
	cmp	w9, #254
	b.eq	LBB180_49
; %bb.66:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #163
	b.eq	LBB180_49
	b	LBB180_46
LBB180_67:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #8                         ; =0x8
	b	LBB180_69
LBB180_68:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #0                         ; =0x0
LBB180_69:                              ;   in Loop: Header=BB180_47 Depth=2
	strb	w11, [x25, #67]
	ldr	x11, [x5, #96]
	ldrb	w11, [x11, x22]
	cbz	w11, LBB180_46
; %bb.70:                               ;   in Loop: Header=BB180_47 Depth=2
	strb	w16, [x25, #68]
	tbnz	w10, #0, LBB180_46
; %bb.71:                               ;   in Loop: Header=BB180_47 Depth=2
	stp	xzr, xzr, [x29, #-104]
	ldr	x8, [x5, #56]
	ldrh	w10, [x8, x22, lsl #1]
	ldr	x8, [x5, #32]
	ldr	w11, [x5, #92]
	mul	x11, x22, x11
	add	x8, x8, x11, lsl #4
	ldrh	w11, [x5, #66]
	add	x8, x8, x11, lsl #4
	cmp	w9, #250
	str	x17, [sp, #128]                 ; 8-byte Folded Spill
	b.gt	LBB180_77
; %bb.72:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #96
	b.eq	LBB180_80
; %bb.73:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #98
	b.eq	LBB180_86
; %bb.74:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #99
	b.eq	LBB180_80
LBB180_75:                              ;   in Loop: Header=BB180_47 Depth=2
	cbz	w10, LBB180_124
; %bb.76:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	w5, #0                          ; =0x0
	mov	w19, #0                         ; =0x0
	mov	x7, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	mov	w9, #-1                         ; =0xffffffff
	add	x9, x10, x9
	b	LBB180_88
LBB180_77:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	w11, #2                         ; =0x2
	cmp	w9, #254
	b.eq	LBB180_98
; %bb.78:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #253
	b.eq	LBB180_86
; %bb.79:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w9, #251
	b.ne	LBB180_75
LBB180_80:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	x9, [x5, #112]
	ldrsh	w9, [x9, x22, lsl #1]
	tbnz	w9, #31, LBB180_124
; %bb.81:                               ;   in Loop: Header=BB180_47 Depth=2
	ldr	w11, [x27]
	cmp	w11, w9
	b.ls	LBB180_124
; %bb.82:                               ;   in Loop: Header=BB180_47 Depth=2
	ldp	x12, x11, [sp, #56]             ; 16-byte Folded Reload
	ldrh	w11, [x11, w9, uxtw #1]
	strh	w11, [x25, #64]
	ldr	w12, [x12, w9, uxtw #2]
	str	w12, [x25, #56]
	cmp	w11, #1
	b.hi	LBB180_124
; %bb.83:                               ;   in Loop: Header=BB180_47 Depth=2
	cmp	w10, w11
	b.lo	LBB180_124
; %bb.84:                               ;   in Loop: Header=BB180_47 Depth=2
	cbz	w11, LBB180_101
; %bb.85:                               ;   in Loop: Header=BB180_47 Depth=2
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #4
	ldp	x1, x11, [x8]
	b	LBB180_102
LBB180_86:                              ;   in Loop: Header=BB180_47 Depth=2
	cmp	w10, #2
	b.lo	LBB180_124
; %bb.87:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	w9, #-2                         ; =0xfffffffe
	add	x9, x10, x9
	add	x10, x8, x10, lsl #4
	ldp	x6, x7, [x10, #-16]
	mov	w5, #1                          ; =0x1
	mov	w19, #1                         ; =0x1
LBB180_88:                              ;   in Loop: Header=BB180_47 Depth=2
	add	x8, x8, w9, uxtw #4
	ldp	x23, x26, [x8]
	ldrh	w8, [x24, #48]
	sub	x9, x29, #104
	str	x9, [sp, #16]
	mov	w9, #1                          ; =0x1
	stp	w4, w9, [sp, #4]
	str	w3, [sp]
	mov	x20, x0
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
	mov	x2, x23
	mov	x3, x26
	mov	x4, x8
	str	x6, [sp, #104]                  ; 8-byte Folded Spill
	mov	x28, x7
	bl	_uf_access
	cmp	w0, #1
	b.ne	LBB180_132
; %bb.89:                               ;   in Loop: Header=BB180_47 Depth=2
	and	x12, x26, #0xffff
	cmp	x12, #256
	mov	w8, #4                          ; =0x4
	cinc	w8, w8, ne
	cmp	w19, #0
	mov	w9, #6                          ; =0x6
	csel	w8, w9, w8, ne
	ldrh	w9, [x24, #48]
	strh	w9, [x25, #64]
	str	wzr, [x25, #56]
	strb	w8, [x25, #67]
	cmp	x12, #256
	mov	w8, #10                         ; =0xa
	mov	w9, #8                          ; =0x8
	csel	w13, w9, w8, eq
	b.ne	LBB180_91
; %bb.90:                               ;   in Loop: Header=BB180_47 Depth=2
	ldr	w4, [x24]
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	mov	w8, #256                        ; =0x100
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	mov	x0, x20
	ldur	x3, [x29, #-112]                ; 8-byte Folded Reload
	b	LBB180_108
LBB180_91:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	w8, [x27]
	mov	x0, x20
	ldur	x3, [x29, #-112]                ; 8-byte Folded Reload
	cbz	w8, LBB180_100
; %bb.92:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB180_95
LBB180_93:                              ;   in Loop: Header=BB180_95 Depth=3
	strb	w10, [x25, #66]
LBB180_94:                              ;   in Loop: Header=BB180_95 Depth=3
	add	x9, x9, #1
	cmp	x8, x9
	b.eq	LBB180_105
LBB180_95:                              ;   Parent Loop BB180_44 Depth=1
                                        ;     Parent Loop BB180_47 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x10, x23, x9
	tbz	w10, #0, LBB180_94
; %bb.96:                               ;   in Loop: Header=BB180_95 Depth=3
	ldrb	w11, [x25, #66]
	ldur	x10, [x29, #-120]               ; 8-byte Folded Reload
	ldrb	w10, [x10, x9]
	cmp	w11, #255
	b.eq	LBB180_93
; %bb.97:                               ;   in Loop: Header=BB180_95 Depth=3
	cmp	w11, w10
	mov	x10, x11
	b.eq	LBB180_93
	b	LBB180_124
LBB180_98:                              ;   in Loop: Header=BB180_47 Depth=2
	cbz	w10, LBB180_124
; %bb.99:                               ;   in Loop: Header=BB180_47 Depth=2
	mov	x28, #0                         ; =0x0
	str	xzr, [sp, #104]                 ; 8-byte Folded Spill
	sub	w9, w10, #1
	add	x8, x8, w9, uxtw #4
	ldp	x23, x26, [x8]
	stur	x11, [x29, #-96]
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	str	wzr, [x8]
	and	x12, x26, #0xffff
LBB180_100:                             ;   in Loop: Header=BB180_47 Depth=2
	mov	w8, #10                         ; =0xa
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB180_106
LBB180_101:                             ;   in Loop: Header=BB180_47 Depth=2
	mov	x11, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
LBB180_102:                             ;   in Loop: Header=BB180_47 Depth=2
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, x9]
	cmp	w8, #3
	mov	w8, #256                        ; =0x100
	mov	w10, #1024                      ; =0x400
	csel	x8, x10, x8, eq
	mov	w10, #1                         ; =0x1
	lsl	x10, x10, x9
	stp	x10, x8, [x29, #-104]
	b.ne	LBB180_104
; %bb.103:                              ;   in Loop: Header=BB180_47 Depth=2
	str	xzr, [sp, #112]                 ; 8-byte Folded Spill
	mov	x23, #0                         ; =0x0
	ldur	x8, [x29, #-120]                ; 8-byte Folded Reload
	ldrb	w8, [x8, x9]
	strb	w8, [x25, #66]
	mov	w8, #10                         ; =0xa
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB180_112
LBB180_104:                             ;   in Loop: Header=BB180_47 Depth=2
	str	xzr, [sp, #112]                 ; 8-byte Folded Spill
	mov	x23, #0                         ; =0x0
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB180_112
LBB180_105:                             ;   in Loop: Header=BB180_47 Depth=2
	str	w13, [sp, #124]                 ; 4-byte Folded Spill
LBB180_106:                             ;   in Loop: Header=BB180_47 Depth=2
	ldr	w4, [x24]
	cbz	x12, LBB180_110
; %bb.107:                              ;   in Loop: Header=BB180_47 Depth=2
	str	x12, [sp, #112]                 ; 8-byte Folded Spill
LBB180_108:                             ;   in Loop: Header=BB180_47 Depth=2
	mov	x19, x0
	mov	x1, x23
	mov	x2, x26
                                        ; kill: def $w3 killed $w3 killed $x3
	bl	_uf_summary
	cbz	w0, LBB180_132
; %bb.109:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	w4, [x24]
	mov	x0, x19
	ldur	x3, [x29, #-112]                ; 8-byte Folded Reload
	b	LBB180_111
LBB180_110:                             ;   in Loop: Header=BB180_47 Depth=2
	str	xzr, [sp, #112]                 ; 8-byte Folded Spill
LBB180_111:                             ;   in Loop: Header=BB180_47 Depth=2
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	mov	x11, x28
LBB180_112:                             ;   in Loop: Header=BB180_47 Depth=2
	ands	x8, x11, #0xffff
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	b.eq	LBB180_115
; %bb.113:                              ;   in Loop: Header=BB180_47 Depth=2
	mov	x19, x0
	mov	x28, x1
	mov	x2, x11
                                        ; kill: def $w3 killed $w3 killed $x3
	bl	_uf_summary
	cbz	w0, LBB180_132
; %bb.114:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	w4, [x24]
	mov	x0, x19
	ldur	x3, [x29, #-112]                ; 8-byte Folded Reload
	b	LBB180_116
LBB180_115:                             ;   in Loop: Header=BB180_47 Depth=2
	mov	x28, x1
LBB180_116:                             ;   in Loop: Header=BB180_47 Depth=2
	ldp	x24, x26, [x29, #-104]
	mov	x20, x0
	mov	x1, x24
	mov	x2, x26
                                        ; kill: def $w3 killed $w3 killed $x3
	bl	_uf_summary
	cbz	w0, LBB180_132
; %bb.117:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	x8, [x27, #992]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #124]                  ; 4-byte Folded Reload
	cbz	x8, LBB180_122
; %bb.118:                              ;   in Loop: Header=BB180_47 Depth=2
	ldrb	w10, [x27, #1024]
	mov	x8, x20
	tbnz	w10, #0, LBB180_131
; %bb.119:                              ;   in Loop: Header=BB180_47 Depth=2
	ldrb	w10, [x27, #1025]
	tbnz	w10, #0, LBB180_131
; %bb.120:                              ;   in Loop: Header=BB180_47 Depth=2
	ldr	x10, [x27, #1016]
	mov	w11, #65533                     ; =0xfffd
	movk	w11, #255, lsl #16
	cmp	x10, x11
	b.hs	LBB180_130
; %bb.121:                              ;   in Loop: Header=BB180_47 Depth=2
	add	x8, x10, #4
	str	x8, [x27, #1016]
LBB180_122:                             ;   in Loop: Header=BB180_47 Depth=2
	ldr	x0, [x9]
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w2, [x8]
	add	x3, x25, #60
	bl	_nvm_union_field_declarations_nominal
	mov	x8, x0
	mov	x0, x20
	ldr	x2, [sp, #72]                   ; 8-byte Folded Reload
	ldur	x3, [x29, #-112]                ; 8-byte Folded Reload
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	cbz	w8, LBB180_124
; %bb.123:                              ;   in Loop: Header=BB180_47 Depth=2
	stp	x23, x9, [x25, #8]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	stp	x28, x8, [x25, #24]
	and	x8, x26, #0xffff
	stp	x24, x8, [x25, #40]
	ldp	x5, x12, [sp, #80]              ; 16-byte Folded Reload
	ldr	w8, [x5, #8]
	mov	w13, #104                       ; =0x68
	mov	w14, #72                        ; =0x48
	mov	x15, #-1                        ; =0xffffffffffffffff
	mov	w16, #2                         ; =0x2
	b	LBB180_46
LBB180_124:
	ldr	x9, [x27, #992]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB180_126
; %bb.125:
	ldrb	w9, [x27, #1024]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB180_126:
	ldr	x19, [sp, #88]                  ; 8-byte Folded Reload
	str	w8, [x27, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #784]
	mov	w8, #37400                      ; =0x9218
Lloh508:
	adrp	x9, l_.str.154@PAGE
Lloh509:
	add	x9, x9, l_.str.154@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh510:
	adrp	x2, l_.str.52@PAGE
Lloh511:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB180_133
LBB180_127:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1024]
LBB180_128:
	ldrb	w8, [x27, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
LBB180_129:
	str	w8, [x27, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #784]
	mov	w8, #37400                      ; =0x9218
Lloh512:
	adrp	x9, l_.str.153@PAGE
Lloh513:
	add	x9, x9, l_.str.153@PAGEOFF
	b	LBB180_18
LBB180_130:
	mov	w9, #1                          ; =0x1
	strb	w9, [x27, #1024]
LBB180_131:
Lloh514:
	adrp	x9, lCPI180_0@PAGE
Lloh515:
	ldr	d0, [x9, lCPI180_0@PAGEOFF]
	add	x9, x27, #780
	str	d0, [x9]
	str	wzr, [x27, #788]
	mov	w9, #37400                      ; =0x9218
Lloh516:
	adrp	x10, l_.str.101@PAGE
Lloh517:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w11, #191                       ; =0xbf
	stp	x11, x10, [sp]
Lloh518:
	adrp	x2, l_.str.52@PAGE
Lloh519:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x8, x9
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB180_132:
	ldr	x19, [sp, #88]                  ; 8-byte Folded Reload
LBB180_133:
	mov	x0, x19
	bl	_free
	b	LBB180_19
LBB180_134:
	ldr	w25, [sp, #36]                  ; 4-byte Folded Reload
	b	LBB180_13
	.loh AdrpAdd	Lloh500, Lloh501
	.loh AdrpAdd	Lloh504, Lloh505
	.loh AdrpLdr	Lloh502, Lloh503
	.loh AdrpAdd	Lloh506, Lloh507
	.loh AdrpAdd	Lloh510, Lloh511
	.loh AdrpAdd	Lloh508, Lloh509
	.loh AdrpAdd	Lloh512, Lloh513
	.loh AdrpAdd	Lloh518, Lloh519
	.loh AdrpAdd	Lloh516, Lloh517
	.loh AdrpLdr	Lloh514, Lloh515
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function uf_freeze
lCPI181_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_uf_freeze:                             ; @uf_freeze
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	w8, #35880                      ; =0x8c28
	add	x27, x0, x8
	ldr	w12, [x27, #728]
	ldr	w13, [x27, #1712]
	ldr	x8, [x0]
	ldr	w22, [x8, #272]
	ldr	x8, [x27, #1720]
	cbz	x8, LBB181_11
; %bb.1:
	ldrb	w8, [x27, #1752]
	tbnz	w8, #0, LBB181_5
; %bb.2:
	ldrb	w8, [x27, #1753]
	tbnz	w8, #0, LBB181_5
; %bb.3:
	add	w8, w13, w12
	add	w8, w8, w22
	ldr	x9, [x27, #1744]
	mov	w10, #16777216                  ; =0x1000000
	sub	x11, x10, x9
	cmp	x9, x10
	ccmp	x11, x8, #0, ls
	b.hs	LBB181_10
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
LBB181_5:
Lloh520:
	adrp	x8, lCPI181_0@PAGE
Lloh521:
	ldr	d0, [x8, lCPI181_0@PAGEOFF]
	add	x8, x27, #1508
	str	d0, [x8]
	str	wzr, [x27, #1516]
	mov	w8, #37400                      ; =0x9218
Lloh522:
	adrp	x9, l_.str.101@PAGE
Lloh523:
	add	x9, x9, l_.str.101@PAGEOFF
LBB181_6:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
LBB181_7:
Lloh524:
	adrp	x2, l_.str.52@PAGE
Lloh525:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB181_8:
	mov	w0, #0                          ; =0x0
LBB181_9:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB181_10:
	add	x8, x9, x8
	str	x8, [x27, #1744]
LBB181_11:
	stp	x13, x1, [sp, #72]              ; 16-byte Folded Spill
	str	x2, [sp, #64]                   ; 8-byte Folded Spill
	str	x12, [sp, #88]                  ; 8-byte Folded Spill
	cbz	w12, LBB181_27
; %bb.12:
	add	x26, x27, #24
	add	x28, x27, #740
	add	x20, x27, #344
	ldp	x8, x25, [sp, #80]              ; 16-byte Folded Reload
	add	x21, x8, #16
	mov	w24, #36480                     ; =0x8e80
	mov	w23, #16777152                  ; =0xffffc0
	b	LBB181_14
LBB181_13:                              ;   in Loop: Header=BB181_14 Depth=1
	add	x20, x20, #4
	add	x28, x28, #12
	add	x24, x24, #2
	add	x21, x21, #16
	subs	x25, x25, #1
	b.eq	LBB181_27
LBB181_14:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x26], #1
	cmp	w8, #3
	b.eq	LBB181_17
; %bb.15:                               ;   in Loop: Header=BB181_14 Depth=1
	cmp	w8, #1
	b.ne	LBB181_54
; %bb.16:                               ;   in Loop: Header=BB181_14 Depth=1
	ldr	x8, [x27]
	ldr	w9, [x20]
	add	x8, x8, x9, lsl #4
	ldp	x1, x2, [x8]
	ldp	w4, w5, [x28]
	mov	x0, x19
	mov	w3, #10                         ; =0xa
	bl	_uf_value
	cbnz	w0, LBB181_13
	b	LBB181_9
LBB181_17:                              ;   in Loop: Header=BB181_14 Depth=1
	ldrh	w8, [x19, x24]
	cbz	w8, LBB181_13
; %bb.18:                               ;   in Loop: Header=BB181_14 Depth=1
	ldr	d0, [x28]
	ldp	x8, x9, [x21, #-8]
	ldr	x10, [x27, #1720]
	cbz	x10, LBB181_24
; %bb.19:                               ;   in Loop: Header=BB181_14 Depth=1
	ldrb	w10, [x27, #1752]
	tbnz	w10, #0, LBB181_56
; %bb.20:                               ;   in Loop: Header=BB181_14 Depth=1
	ldrb	w10, [x27, #1753]
	tbnz	w10, #0, LBB181_56
; %bb.21:                               ;   in Loop: Header=BB181_14 Depth=1
	ldr	x10, [x27, #1744]
	cmp	x10, x23
	b.hs	LBB181_59
; %bb.22:                               ;   in Loop: Header=BB181_14 Depth=1
	add	x10, x10, #65
	str	x10, [x27, #1744]
	and	x9, x9, #0xffffff
	cmp	x9, #2
	b.ne	LBB181_60
; %bb.23:                               ;   in Loop: Header=BB181_14 Depth=1
	cbz	x8, LBB181_13
	b	LBB181_61
LBB181_24:                              ;   in Loop: Header=BB181_14 Depth=1
	and	x9, x9, #0xffffff
	cmp	x9, #2
	b.ne	LBB181_63
; %bb.25:                               ;   in Loop: Header=BB181_14 Depth=1
	cbz	x8, LBB181_13
; %bb.26:
	mov	w8, #1                          ; =0x1
	b	LBB181_62
LBB181_27:
	ldr	x23, [sp, #72]                  ; 8-byte Folded Reload
	cbz	w23, LBB181_31
; %bb.28:
	mov	w8, #30736                      ; =0x7810
	add	x20, x19, x8
	mov	x21, x23
LBB181_29:                              ; =>This Inner Loop Header: Depth=1
	ldp	x1, x2, [x20, #-8]
	mov	x0, x19
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	bl	_uf_summary
	cbz	w0, LBB181_9
; %bb.30:                               ;   in Loop: Header=BB181_29 Depth=1
	add	x20, x20, #16
	subs	x21, x21, #1
	b.ne	LBB181_29
LBB181_31:
	cbz	w22, LBB181_36
; %bb.32:
	mov	x25, #0                         ; =0x0
	add	x20, x19, #56
	mov	w21, #21                        ; =0x15
	b	LBB181_34
LBB181_33:                              ;   in Loop: Header=BB181_34 Depth=1
	add	x25, x25, #1
	add	x20, x20, #120
	add	x21, x21, #24
	cmp	x22, x25
	b.eq	LBB181_36
LBB181_34:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19]
	ldr	x8, [x8, #256]
	ldrb	w8, [x8, x21]
	cbz	w8, LBB181_33
; %bb.35:                               ;   in Loop: Header=BB181_34 Depth=1
	ldp	x1, x2, [x20, #-8]
	mov	x0, x19
	mov	x3, x25
	mov	w4, #0                          ; =0x0
	bl	_uf_summary
	cbnz	w0, LBB181_33
	b	LBB181_9
LBB181_36:
	ldr	x28, [x27, #1720]
	cbz	x28, LBB181_45
; %bb.37:
	ldrb	w8, [x27, #1752]
	ldr	x21, [sp, #88]                  ; 8-byte Folded Reload
	tbnz	w8, #0, LBB181_44
; %bb.38:
	ldrb	w8, [x27, #1753]
	tbnz	w8, #0, LBB181_148
; %bb.39:
	ldr	x8, [x27, #1728]
	mov	w9, #65465                      ; =0xffb9
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB181_43
; %bb.40:
	add	x8, x8, #72
	str	x8, [x27, #1728]
	ldr	x9, [x27, #1736]
	cmp	x9, x8
	b.hs	LBB181_42
; %bb.41:
	str	x8, [x27, #1736]
LBB181_42:
	ldr	x8, [x27, #1744]
	lsr	x9, x8, #24
	cbz	x9, LBB181_67
LBB181_43:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
LBB181_44:
	mov	w8, #3                          ; =0x3
	b	LBB181_149
LBB181_45:
	mov	w0, #1                          ; =0x1
	mov	w1, #72                         ; =0x48
	bl	_calloc
	ldr	x21, [sp, #88]                  ; 8-byte Folded Reload
	cbz	x0, LBB181_148
; %bb.46:
	mov	x24, x0
	cbz	w21, LBB181_49
; %bb.47:
	mov	x0, x21
	mov	w1, #40                         ; =0x28
	bl	_calloc
LBB181_48:
	str	x0, [x24, #8]
LBB181_49:
	cbz	w23, LBB181_82
; %bb.50:
	cbz	x28, LBB181_66
LBB181_51:
	ldrb	w8, [x27, #1752]
	tbnz	w8, #0, LBB181_53
; %bb.52:
	ldrb	w8, [x27, #1753]
	tbz	w8, #0, LBB181_72
LBB181_53:
	mov	x0, #0                          ; =0x0
	b	LBB181_81
LBB181_54:
	ldr	x8, [x27, #1720]
	cbz	x8, LBB181_57
; %bb.55:
	ldrb	w8, [x27, #1752]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB181_58
LBB181_56:
	movi.2d	v0, #0000000000000000
	mov	w8, #3                          ; =0x3
Lloh526:
	adrp	x10, l_.str.101@PAGE
Lloh527:
	add	x10, x10, l_.str.101@PAGEOFF
	b	LBB181_65
LBB181_57:
	mov	w8, #1                          ; =0x1
LBB181_58:
	str	w8, [x27, #1508]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #1512]
	mov	w8, #37400                      ; =0x9218
Lloh528:
	adrp	x9, l_.str.158@PAGE
Lloh529:
	add	x9, x9, l_.str.158@PAGEOFF
	b	LBB181_6
LBB181_59:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
	movi.2d	v0, #0000000000000000
Lloh530:
	adrp	x10, l_.str.101@PAGE
Lloh531:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w8, #3                          ; =0x3
	b	LBB181_65
LBB181_60:
	ldrb	w8, [x27, #1752]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB181_64
LBB181_61:
	ldrb	w8, [x27, #1752]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
LBB181_62:
Lloh532:
	adrp	x10, l_.str.117@PAGE
Lloh533:
	add	x10, x10, l_.str.117@PAGEOFF
	b	LBB181_65
LBB181_63:
	mov	w8, #1                          ; =0x1
LBB181_64:
Lloh534:
	adrp	x10, l_.str.116@PAGE
Lloh535:
	add	x10, x10, l_.str.116@PAGEOFF
LBB181_65:
	str	w8, [x27, #1508]
	str	d0, [x27, #1512]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x10, [sp]
	b	LBB181_7
LBB181_66:
	mov	x0, x23
	mov	w1, #16                         ; =0x10
	bl	_calloc
	b	LBB181_81
LBB181_67:
	add	x8, x8, #1
	str	x8, [x27, #1744]
	mov	w20, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #72                         ; =0x48
	bl	_calloc
	cbz	x0, LBB181_147
; %bb.68:
	mov	x24, x0
	cbz	w21, LBB181_170
; %bb.69:
	ldrb	w8, [x27, #1752]
	tbnz	w8, #0, LBB181_71
; %bb.70:
	ldrb	w8, [x27, #1753]
	tbz	w8, #0, LBB181_176
LBB181_71:
	mov	x0, #0                          ; =0x0
	b	LBB181_48
LBB181_72:
	ldr	x8, [x27, #1728]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB181_80
; %bb.73:
	lsl	x9, x23, #4
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB181_80
; %bb.74:
	ldr	x10, [x27, #1736]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x27, #1728]
	b.hs	LBB181_76
; %bb.75:
	str	x8, [x27, #1736]
LBB181_76:
	ldr	x8, [x27, #1744]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB181_80
; %bb.77:
	sub	x9, x9, x8
	cmp	x9, x23
	b.lo	LBB181_80
; %bb.78:
	add	x8, x8, x23
	str	x8, [x27, #1744]
	mov	x0, x23
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbnz	x0, LBB181_81
; %bb.79:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1753]
	b	LBB181_81
LBB181_80:
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
LBB181_81:
	str	x0, [x24, #16]
LBB181_82:
	cbz	x28, LBB181_89
LBB181_83:
	ldrb	w8, [x27, #1752]
	tbnz	w8, #0, LBB181_85
; %bb.84:
	ldrb	w8, [x27, #1753]
	tbz	w8, #0, LBB181_90
LBB181_85:
	mov	x26, #0                         ; =0x0
LBB181_86:
	mov	x20, x24
	str	x26, [x20, #24]!
	ldrb	w8, [x27, #1752]
	tbnz	w8, #0, LBB181_88
; %bb.87:
	ldrb	w8, [x27, #1753]
	tbz	w8, #0, LBB181_98
LBB181_88:
	mov	x0, #0                          ; =0x0
	b	LBB181_108
LBB181_89:
	mov	x0, x22
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x26, x0
	mov	x20, x24
	str	x0, [x20, #24]!
	mov	x0, x22
	mov	w1, #2                          ; =0x2
	bl	_calloc
	b	LBB181_108
LBB181_90:
	ldr	x8, [x27, #1728]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB181_106
; %bb.91:
	lsl	x9, x22, #4
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB181_106
; %bb.92:
	ldr	x10, [x27, #1736]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x27, #1728]
	b.hs	LBB181_94
; %bb.93:
	str	x8, [x27, #1736]
LBB181_94:
	ldr	x8, [x27, #1744]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB181_106
; %bb.95:
	sub	x9, x9, x8
	cmp	x9, x22
	b.lo	LBB181_106
; %bb.96:
	add	x8, x8, x22
	str	x8, [x27, #1744]
	mov	x0, x22
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x26, x0
	cbnz	x0, LBB181_86
; %bb.97:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1753]
	b	LBB181_86
LBB181_98:
	ldr	x8, [x27, #1728]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB181_107
; %bb.99:
	lsl	x9, x22, #1
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB181_107
; %bb.100:
	ldr	x10, [x27, #1736]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x27, #1728]
	b.hs	LBB181_102
; %bb.101:
	str	x8, [x27, #1736]
LBB181_102:
	ldr	x8, [x27, #1744]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB181_107
; %bb.103:
	sub	x9, x9, x8
	cmp	x9, x22
	b.lo	LBB181_107
; %bb.104:
	add	x8, x8, x22
	str	x8, [x27, #1744]
	mov	x0, x22
	mov	w1, #2                          ; =0x2
	bl	_calloc
	cbnz	x0, LBB181_108
; %bb.105:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1753]
	b	LBB181_108
LBB181_106:
	mov	x26, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
	b	LBB181_86
LBB181_107:
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
LBB181_108:
	str	x0, [x24, #32]
	cbz	w21, LBB181_110
; %bb.109:
	ldr	x8, [x24, #8]
	cbz	x8, LBB181_133
LBB181_110:
	cbz	w23, LBB181_114
; %bb.111:
	cbz	x0, LBB181_133
; %bb.112:
	cbz	x26, LBB181_133
; %bb.113:
	ldr	x8, [x24, #16]
	cbnz	x8, LBB181_116
	b	LBB181_133
LBB181_114:
	cbz	x26, LBB181_133
; %bb.115:
	cbz	x0, LBB181_133
LBB181_116:
	add	x8, x21, x21, lsl #2
	cbz	x28, LBB181_122
; %bb.117:
	ldrb	w9, [x27, #1752]
	tbnz	w9, #0, LBB181_172
; %bb.118:
	ldrb	w9, [x27, #1753]
	tbnz	w9, #0, LBB181_172
; %bb.119:
	ldr	x9, [x27, #1744]
	mov	w10, #16777216                  ; =0x1000000
	cmp	x9, x10
	b.hi	LBB181_171
; %bb.120:
	add	x11, x8, x23
	add	x11, x11, x22
	sub	x10, x10, x9
	cmp	x11, x10
	b.hi	LBB181_171
; %bb.121:
	add	x9, x9, x11
	str	x9, [x27, #1744]
LBB181_122:
	str	x20, [sp, #16]                  ; 8-byte Folded Spill
	cbz	w21, LBB181_137
; %bb.123:
	mov	x26, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	add	x25, x27, #740
	mov	w9, #35904                      ; =0x8c40
	add	x9, x19, x9
	stp	x9, x24, [sp, #48]              ; 16-byte Folded Spill
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	add	x11, x10, #1032
	mov	w9, #36480                      ; =0x8e80
	add	x9, x19, x9
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	add	x20, x27, #344
	add	x21, x10, #8
	lsl	x8, x8, #3
	stp	x11, x8, [sp, #24]              ; 16-byte Folded Spill
	b	LBB181_126
LBB181_124:                             ;   in Loop: Header=BB181_126 Depth=1
	add	x9, x23, x26
	ldrh	w10, [x8, #8]
	ldr	x8, [x8]
	stp	x8, x10, [x9, #24]
LBB181_125:                             ;   in Loop: Header=BB181_126 Depth=1
	add	x28, x28, #1
	add	x26, x26, #40
	add	x21, x21, #16
	add	x20, x20, #4
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cmp	x8, x26
	ldr	x24, [sp, #56]                  ; 8-byte Folded Reload
	b.eq	LBB181_137
LBB181_126:                             ; =>This Inner Loop Header: Depth=1
	ldr	x23, [x24, #8]
	add	x24, x23, x26
	ldr	d0, [x25], #12
	str	d0, [x24]
	ldur	w2, [x20, #-256]
	str	w2, [x24, #8]
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, x28]
	strb	w8, [x24, #16]
	cmp	w8, #3
	b.ne	LBB181_128
; %bb.127:                              ;   in Loop: Header=BB181_126 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, x28]
	mov	w1, #10                         ; =0xa
	b	LBB181_129
LBB181_128:                             ;   in Loop: Header=BB181_126 Depth=1
	mov	w8, #255                        ; =0xff
	mov	w1, #8                          ; =0x8
LBB181_129:                             ;   in Loop: Header=BB181_126 Depth=1
	strb	w8, [x24, #17]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, x28, lsl #1]
	strh	w8, [x24, #18]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	add	x3, x24, #12
	bl	_nvm_union_field_declarations_nominal
	tbz	w0, #0, LBB181_150
; %bb.130:                              ;   in Loop: Header=BB181_126 Depth=1
	ldrh	w8, [x24, #18]
	cbz	w8, LBB181_125
; %bb.131:                              ;   in Loop: Header=BB181_126 Depth=1
	ldrb	w9, [x24, #16]
	mov	x8, x21
	cmp	w9, #3
	b.eq	LBB181_124
; %bb.132:                              ;   in Loop: Header=BB181_126 Depth=1
	ldr	x8, [x27]
	ldr	w9, [x20]
	add	x8, x8, x9, lsl #4
	b	LBB181_124
LBB181_133:
	mov	x0, #0                          ; =0x0
	bl	_nvm_union_field_declarations_free
	ldr	x0, [x24, #8]
	bl	_free
	ldr	x0, [x24, #16]
	bl	_free
	ldr	x0, [x20]
	bl	_free
	ldr	x0, [x24, #32]
	bl	_free
	mov	x0, x24
	bl	_free
	ldr	x8, [x27, #1720]
	cbz	x8, LBB181_135
; %bb.134:
	ldrb	w8, [x27, #1752]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
	b	LBB181_136
LBB181_135:
	mov	w8, #4                          ; =0x4
LBB181_136:
	str	w8, [x27, #1508]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #1512]
	mov	w8, #37400                      ; =0x9218
Lloh536:
	adrp	x9, l_.str.160@PAGE
Lloh537:
	add	x9, x9, l_.str.160@PAGEOFF
	b	LBB181_6
LBB181_137:
	ldp	x3, x6, [sp, #64]               ; 16-byte Folded Reload
	ldr	x4, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x7, [sp, #16]                   ; 8-byte Folded Reload
	cbz	w6, LBB181_144
; %bb.138:
	ldr	x8, [x24, #16]
	cmp	w6, #6
	b.lo	LBB181_141
; %bb.139:
	lsl	x9, x6, #4
	mov	w10, #30728                     ; =0x7808
	add	x11, x19, x9
	add	x10, x11, x10
	cmp	x8, x10
	b.hs	LBB181_173
; %bb.140:
	mov	w10, #30728                     ; =0x7808
	add	x10, x19, x10
	add	x9, x8, x9
	cmp	x10, x9
	b.hs	LBB181_173
LBB181_141:
	mov	x9, #0                          ; =0x0
LBB181_142:
	lsl	x10, x9, #4
	add	x8, x10, x8
	add	x8, x8, #8
	mov	w11, #30736                     ; =0x7810
	add	x10, x10, x19
	add	x10, x10, x11
	sub	x9, x6, x9
LBB181_143:                             ; =>This Inner Loop Header: Depth=1
	ldur	x11, [x10, #-8]
	ldrh	w12, [x10], #16
	stp	x11, x12, [x8, #-8]
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB181_143
LBB181_144:
	ldr	x5, [sp, #88]                   ; 8-byte Folded Reload
	cbz	w22, LBB181_169
; %bb.145:
	sub	x9, x22, #1
	and	x8, x22, #0x3
	cmp	x9, #3
	b.hs	LBB181_153
; %bb.146:
	mov	x12, #0                         ; =0x0
	b	LBB181_164
LBB181_147:
	strb	w20, [x27, #1753]
LBB181_148:
	mov	w8, #4                          ; =0x4
LBB181_149:
	str	w8, [x27, #1508]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #1512]
	mov	w8, #37400                      ; =0x9218
Lloh538:
	adrp	x9, l_.str.159@PAGE
Lloh539:
	add	x9, x9, l_.str.159@PAGEOFF
	b	LBB181_6
LBB181_150:
	ldr	x20, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x0, [x20]
	bl	_nvm_union_field_declarations_free
	ldr	x0, [x20, #8]
	bl	_free
	ldr	x0, [x20, #16]
	bl	_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x0, [x20, #32]
	bl	_free
	mov	x0, x20
	bl	_free
	ldr	x9, [x27, #1720]
	mov	w8, #2                          ; =0x2
	cbz	x9, LBB181_152
; %bb.151:
	ldrb	w9, [x27, #1752]
	cmp	w9, #0
	cinc	w8, w8, ne
LBB181_152:
	str	w8, [x27, #1508]
	movi.2d	v0, #0000000000000000
	str	d0, [x27, #1512]
	mov	w8, #37400                      ; =0x9218
Lloh540:
	adrp	x9, l_.str.161@PAGE
Lloh541:
	add	x9, x9, l_.str.161@PAGEOFF
	b	LBB181_6
LBB181_153:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	and	x12, x22, #0xfffffffc
	neg	x12, x12
	add	x13, x19, #288
	mov	w14, #8208                      ; =0x2010
	mov	w15, #8210                      ; =0x2012
	mov	w16, #8212                      ; =0x2014
	mov	w17, #8214                      ; =0x2016
	b	LBB181_155
LBB181_154:                             ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x27, #1720]
	add	x0, x0, x10
	ldrh	w0, [x0, x17]
	ldr	x1, [x24, #32]
	add	x1, x1, x10
	strh	w0, [x1, #6]
	add	x11, x11, #96
	add	x10, x10, #8
	sub	x9, x9, #4
	add	x13, x13, #480
	cmp	x12, x9
	b.eq	LBB181_163
LBB181_155:                             ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x19]
	ldr	x0, [x0, #256]
	add	x0, x0, x11
	ldrb	w0, [x0, #21]
	cbz	w0, LBB181_157
; %bb.156:                              ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x7]
	add	x0, x0, x10, lsl #3
	ldur	x1, [x13, #-240]
	ldurh	w2, [x13, #-232]
	stp	x1, x2, [x0]
LBB181_157:                             ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x27, #1720]
	add	x0, x0, x10
	ldrh	w0, [x0, x14]
	ldr	x1, [x24, #32]
	strh	w0, [x1, x10]
	ldr	x0, [x19]
	ldr	x0, [x0, #256]
	add	x0, x0, x11
	ldrb	w0, [x0, #45]
	cbz	w0, LBB181_159
; %bb.158:                              ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x7]
	add	x0, x0, x10, lsl #3
	ldur	x1, [x13, #-120]
	ldurh	w2, [x13, #-112]
	stp	x1, x2, [x0, #16]
LBB181_159:                             ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x27, #1720]
	add	x0, x0, x10
	ldrh	w0, [x0, x15]
	ldr	x1, [x24, #32]
	add	x1, x1, x10
	strh	w0, [x1, #2]
	ldr	x0, [x19]
	ldr	x0, [x0, #256]
	add	x0, x0, x11
	ldrb	w0, [x0, #69]
	cbz	w0, LBB181_161
; %bb.160:                              ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x7]
	add	x0, x0, x10, lsl #3
	ldr	x1, [x13]
	ldrh	w2, [x13, #8]
	stp	x1, x2, [x0, #32]
LBB181_161:                             ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x27, #1720]
	add	x0, x0, x10
	ldrh	w0, [x0, x16]
	ldr	x1, [x24, #32]
	add	x1, x1, x10
	strh	w0, [x1, #4]
	ldr	x0, [x19]
	ldr	x0, [x0, #256]
	add	x0, x0, x11
	ldrb	w0, [x0, #93]
	cbz	w0, LBB181_154
; %bb.162:                              ;   in Loop: Header=BB181_155 Depth=1
	ldr	x0, [x7]
	add	x0, x0, x10, lsl #3
	ldr	x1, [x13, #120]
	ldrh	w2, [x13, #128]
	stp	x1, x2, [x0, #48]
	b	LBB181_154
LBB181_163:
	neg	x12, x9
LBB181_164:
	cbz	x8, LBB181_169
; %bb.165:
	lsl	x9, x12, #1
	mov	w10, #120                       ; =0x78
	madd	x10, x12, x10, x19
	add	x10, x10, #56
	mov	w11, #8                         ; =0x8
	orr	x11, x11, x12, lsl #4
	mov	w13, #24                        ; =0x18
	mov	x14, #21                        ; =0x15
	madd	x12, x12, x13, x14
	mov	w13, #8208                      ; =0x2010
	b	LBB181_167
LBB181_166:                             ;   in Loop: Header=BB181_167 Depth=1
	ldr	x14, [x27, #1720]
	add	x14, x14, x9
	ldrh	w14, [x14, x13]
	ldr	x15, [x24, #32]
	strh	w14, [x15, x9]
	add	x9, x9, #2
	add	x10, x10, #120
	add	x11, x11, #16
	add	x12, x12, #24
	subs	x8, x8, #1
	b.eq	LBB181_169
LBB181_167:                             ; =>This Inner Loop Header: Depth=1
	ldr	x14, [x19]
	ldr	x14, [x14, #256]
	ldrb	w14, [x14, x12]
	cbz	w14, LBB181_166
; %bb.168:                              ;   in Loop: Header=BB181_167 Depth=1
	ldr	x14, [x7]
	add	x14, x14, x11
	ldur	x15, [x10, #-8]
	ldrh	w16, [x10]
	stp	x15, x16, [x14, #-8]
	b	LBB181_166
LBB181_169:
	stp	w5, w6, [x24, #40]
	ldr	q0, [x19, #37616]
	stp	w22, wzr, [x24, #48]
	stur	q0, [x24, #56]
	ldr	x8, [x4]
	str	x8, [x24]
	str	xzr, [x4]
	str	x24, [x3]
	mov	w0, #1                          ; =0x1
	b	LBB181_9
LBB181_170:
	cbnz	w23, LBB181_51
	b	LBB181_83
LBB181_171:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
LBB181_172:
Lloh542:
	adrp	x8, lCPI181_0@PAGE
Lloh543:
	ldr	d0, [x8, lCPI181_0@PAGEOFF]
	add	x8, x27, #1508
	str	d0, [x8]
	str	wzr, [x27, #1516]
	mov	w8, #37400                      ; =0x9218
Lloh544:
	adrp	x9, l_.str.101@PAGE
Lloh545:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh546:
	adrp	x2, l_.str.52@PAGE
Lloh547:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x0, x24
	bl	_nvm_union_field_proof_free
	b	LBB181_8
LBB181_173:
	and	x9, x6, #0xfffffffc
	add	x10, x8, #32
	mov	w11, #30760                     ; =0x7828
	add	x11, x19, x11
	movi.2d	v0, #0x0000000000ffff
	mov	x12, x9
LBB181_174:                             ; =>This Inner Loop Header: Depth=1
	sub	x13, x11, #32
	ld2.2d	{ v1, v2 }, [x13]
	ld2.2d	{ v3, v4 }, [x11]
	sub	x13, x10, #32
	and.16b	v2, v2, v0
	st2.2d	{ v1, v2 }, [x13]
	and.16b	v4, v4, v0
	st2.2d	{ v3, v4 }, [x10]
	add	x10, x10, #64
	add	x11, x11, #64
	subs	x12, x12, #4
	b.ne	LBB181_174
; %bb.175:
	cmp	x9, x6
	b.eq	LBB181_144
	b	LBB181_142
LBB181_176:
	ldr	x8, [x27, #1728]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB181_184
; %bb.177:
	add	x9, x21, x21, lsl #2
	lsl	x9, x9, #3
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB181_184
; %bb.178:
	ldr	x10, [x27, #1736]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x27, #1728]
	b.hs	LBB181_180
; %bb.179:
	str	x8, [x27, #1736]
LBB181_180:
	ldr	x8, [x27, #1744]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB181_184
; %bb.181:
	sub	x9, x9, x8
	cmp	x9, x21
	b.lo	LBB181_184
; %bb.182:
	add	x8, x8, x21
	str	x8, [x27, #1744]
	mov	x0, x21
	mov	w1, #40                         ; =0x28
	bl	_calloc
	cbnz	x0, LBB181_48
; %bb.183:
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1753]
	b	LBB181_48
LBB181_184:
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x27, #1752]
	b	LBB181_48
	.loh AdrpAdd	Lloh522, Lloh523
	.loh AdrpLdr	Lloh520, Lloh521
	.loh AdrpAdd	Lloh524, Lloh525
	.loh AdrpAdd	Lloh526, Lloh527
	.loh AdrpAdd	Lloh528, Lloh529
	.loh AdrpAdd	Lloh530, Lloh531
	.loh AdrpAdd	Lloh532, Lloh533
	.loh AdrpAdd	Lloh534, Lloh535
	.loh AdrpAdd	Lloh536, Lloh537
	.loh AdrpAdd	Lloh538, Lloh539
	.loh AdrpAdd	Lloh540, Lloh541
	.loh AdrpAdd	Lloh546, Lloh547
	.loh AdrpAdd	Lloh544, Lloh545
	.loh AdrpLdr	Lloh542, Lloh543
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function ra_check_constraints
lCPI182_0:
	.long	128                             ; 0x80
	.long	512                             ; 0x200
lCPI182_1:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI182_2:
	.long	3                               ; 0x3
	.long	7                               ; 0x7
lCPI182_3:
	.long	5                               ; 0x5
	.long	7                               ; 0x7
lCPI182_4:
	.long	256                             ; 0x100
	.long	1024                            ; 0x400
lCPI182_5:
	.long	4096                            ; 0x1000
	.long	2048                            ; 0x800
lCPI182_6:
	.short	65530                           ; 0xfffa
	.short	65529                           ; 0xfff9
	.short	65533                           ; 0xfffd
	.short	65531                           ; 0xfffb
lCPI182_7:
	.short	2                               ; 0x2
	.short	28                              ; 0x1c
	.short	32                              ; 0x20
	.short	128                             ; 0x80
lCPI182_8:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_ra_check_constraints:                  ; @ra_check_constraints
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w8, #36608                      ; =0x8f00
	add	x21, x0, x8
	ldrb	w9, [x21, #2072]
	ldr	x22, [x21, #992]
	tbnz	w9, #4, LBB182_6
; %bb.1:
	cbz	x22, LBB182_61
; %bb.2:
	ldrb	w8, [x21, #1024]
	tbnz	w8, #0, LBB182_51
; %bb.3:
	ldrb	w8, [x21, #1025]
	tbnz	w8, #0, LBB182_51
; %bb.4:
	ldr	x8, [x21, #1016]
	mov	w10, #64513                     ; =0xfc01
	movk	w10, #255, lsl #16
	cmp	x8, x10
	b.lo	LBB182_48
LBB182_5:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1024]
	b	LBB182_51
LBB182_6:
	cbz	x22, LBB182_15
; %bb.7:
	ldrb	w8, [x21, #1024]
	tbnz	w8, #0, LBB182_14
; %bb.8:
	ldrb	w8, [x21, #1025]
	tbnz	w8, #0, LBB182_46
; %bb.9:
	ldr	x8, [x21, #1000]
	mov	w9, #65409                      ; =0xff81
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB182_13
; %bb.10:
	add	x8, x8, #128
	str	x8, [x21, #1000]
	ldr	x9, [x21, #1008]
	cmp	x9, x8
	b.hs	LBB182_12
; %bb.11:
	str	x8, [x21, #1008]
LBB182_12:
	ldr	x20, [x21, #1016]
	mov	w8, #65473                      ; =0xffc1
	movk	w8, #255, lsl #16
	cmp	x20, x8
	b.lo	LBB182_55
LBB182_13:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1024]
LBB182_14:
	mov	w8, #3                          ; =0x3
	b	LBB182_47
LBB182_15:
	mov	x20, x0
	mov	w0, #64                         ; =0x40
	mov	w1, #2                          ; =0x2
	bl	_calloc
	mov	x19, x0
	mov	x0, x20
	cbz	x19, LBB182_46
; %bb.16:
	ldr	w8, [x21]
	cbz	w8, LBB182_141
LBB182_17:
	mov	w9, #35904                      ; =0x8c40
	mov	w10, #36630                     ; =0x8f16
	mov	w11, #38682                     ; =0x971a
	mov	w12, #34832                     ; =0x8810
	mov	w13, #34840                     ; =0x8818
	mov	w14, #34842                     ; =0x881a
	mov	w15, #1                         ; =0x1
	mov	x16, #4611686019501129728       ; =0x4000000040000000
	movk	x16, #16453
	mov	x17, x0
	mov	x1, x0
	mov	x2, x8
	mov	x3, x0
	mov	x4, x0
	mov	x5, x19
	b	LBB182_22
LBB182_18:                              ;   in Loop: Header=BB182_22 Depth=1
	sub	w20, w7, #2
	cmp	w20, #62
	b.hi	LBB182_38
; %bb.19:                               ;   in Loop: Header=BB182_22 Depth=1
	lsl	x20, x15, x20
	tst	x20, x16
	b.eq	LBB182_38
LBB182_20:                              ;   in Loop: Header=BB182_22 Depth=1
	ands	w6, w7, w6
	strh	w6, [x5]
	b.eq	LBB182_44
LBB182_21:                              ;   in Loop: Header=BB182_22 Depth=1
	add	x3, x3, #1
	add	x5, x5, #2
	add	x4, x4, #2
	add	x1, x1, #16
	add	x17, x17, #12
	subs	x2, x2, #1
	b.eq	LBB182_52
LBB182_22:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w6, [x3, x9]
	cbnz	w6, LBB182_21
; %bb.23:                               ;   in Loop: Header=BB182_22 Depth=1
	add	x7, x1, x11
	ldrb	w6, [x1, x14]
	ldur	w20, [x7, #142]
	ubfx	w23, w20, #16, #8
	orr	w6, w6, w23
	cbnz	w6, LBB182_44
; %bb.24:                               ;   in Loop: Header=BB182_22 Depth=1
	ldrb	w6, [x17, x10]
	ldr	x23, [x1, x12]
	ldrh	w24, [x1, x13]
	ldur	x7, [x7, #134]
	and	w20, w20, #0xffff
	orr	w20, w24, w20
	orr	x7, x7, x23
	cmp	w6, #7
	b.ne	LBB182_28
; %bb.25:                               ;   in Loop: Header=BB182_22 Depth=1
	tst	w20, #0xffffff7f
	b.ne	LBB182_44
; %bb.26:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w20, #0
	ccmp	x7, #0, #0, ne
	b.eq	LBB182_44
; %bb.27:                               ;   in Loop: Header=BB182_22 Depth=1
	ldrh	w6, [x5]
	orr	w6, w6, #0xffc0
	b	LBB182_30
LBB182_28:                              ;   in Loop: Header=BB182_22 Depth=1
	sub	w23, w6, #1
	and	w20, w20, #0xffffffc1
	cmp	w23, #4
	ccmp	x7, #0, #0, ls
	ccmp	w20, #0, #0, eq
	b.ne	LBB182_44
; %bb.29:                               ;   in Loop: Header=BB182_22 Depth=1
	lsl	w6, w15, w6
LBB182_30:                              ;   in Loop: Header=BB182_22 Depth=1
	strh	w6, [x5]
	ldrh	w7, [x4, x11]
	cmp	w7, #255
	b.le	LBB182_18
; %bb.31:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #4095
	b.gt	LBB182_35
; %bb.32:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #1023
	b.gt	LBB182_40
; %bb.33:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #256
	b.eq	LBB182_20
; %bb.34:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #512
	b.eq	LBB182_20
	b	LBB182_44
LBB182_35:                              ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #4, lsl #12                 ; =16384
	b.ge	LBB182_42
; %bb.36:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #1, lsl #12                 ; =4096
	b.eq	LBB182_20
; %bb.37:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #2, lsl #12                 ; =8192
	b.eq	LBB182_20
	b	LBB182_44
LBB182_38:                              ;   in Loop: Header=BB182_22 Depth=1
	cbz	w7, LBB182_21
; %bb.39:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #128
	b.eq	LBB182_20
	b	LBB182_44
LBB182_40:                              ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #1024
	b.eq	LBB182_20
; %bb.41:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #2048
	b.eq	LBB182_20
	b	LBB182_44
LBB182_42:                              ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #8, lsl #12                 ; =32768
	b.eq	LBB182_20
; %bb.43:                               ;   in Loop: Header=BB182_22 Depth=1
	cmp	w7, #4, lsl #12                 ; =16384
	b.eq	LBB182_20
LBB182_44:
	cbz	x22, LBB182_54
; %bb.45:
	ldrb	w8, [x21, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w15, w8, wzr, ne
Lloh548:
	adrp	x23, l_.str.168@PAGE
Lloh549:
	add	x23, x23, l_.str.168@PAGEOFF
	b	LBB182_188
LBB182_46:
	mov	w8, #4                          ; =0x4
LBB182_47:
	str	w8, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
Lloh550:
	adrp	x9, l_.str.166@PAGE
Lloh551:
	add	x9, x9, l_.str.166@PAGEOFF
	b	LBB182_106
LBB182_48:
	add	x10, x8, #1024
	str	x10, [x21, #1016]
	cbz	w9, LBB182_61
; %bb.49:
	ldrb	w10, [x21, #1024]
	tbnz	w10, #0, LBB182_51
; %bb.50:
	ldrb	w10, [x21, #1025]
	tbz	w10, #0, LBB182_59
LBB182_51:
Lloh552:
	adrp	x8, lCPI182_8@PAGE
Lloh553:
	ldr	d0, [x8, lCPI182_8@PAGEOFF]
	add	x8, x21, #780
	str	d0, [x8]
	str	wzr, [x21, #788]
	mov	w8, #37400                      ; =0x9218
Lloh554:
	adrp	x9, l_.str.101@PAGE
Lloh555:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB182_106
LBB182_52:
	mov	x24, x8
	cbnz	w8, LBB182_142
LBB182_53:
	mov	w20, #1                         ; =0x1
	b	LBB182_189
LBB182_54:
Lloh556:
	adrp	x23, l_.str.168@PAGE
Lloh557:
	add	x23, x23, l_.str.168@PAGEOFF
	mov	w15, #1                         ; =0x1
	b	LBB182_188
LBB182_55:
	mov	x23, x0
	add	x8, x20, #64
	str	x8, [x21, #1016]
	mov	w0, #64                         ; =0x40
	mov	w1, #2                          ; =0x2
	bl	_calloc
	cbz	x0, LBB182_58
; %bb.56:
	mov	x19, x0
	mov	w8, #64448                      ; =0xfbc0
	movk	w8, #255, lsl #16
	cmp	x20, x8
	mov	x0, x23
	b.ls	LBB182_140
LBB182_57:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1024]
Lloh558:
	adrp	x23, l_.str.101@PAGE
Lloh559:
	add	x23, x23, l_.str.101@PAGEOFF
	mov	w15, #3                         ; =0x3
	b	LBB182_188
LBB182_58:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1025]
	mov	w8, #4                          ; =0x4
	mov	x0, x23
	b	LBB182_47
LBB182_59:
	mov	w10, #48129                     ; =0xbc01
	movk	w10, #255, lsl #16
	cmp	x8, x10
	b.hs	LBB182_5
; %bb.60:
	mov	w10, #17408                     ; =0x4400
	add	x8, x8, x10
	str	x8, [x21, #1016]
LBB182_61:
	ldr	w10, [x21]
	mov	w20, #1                         ; =0x1
	cbz	w10, LBB182_107
; %bb.62:
	mov	x11, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w12, #35904                     ; =0x8c40
	add	x12, x0, x12
	add	x13, x21, #22
	mov	w14, #34832                     ; =0x8810
	add	x14, x0, x14
	mov	w15, #38816                     ; =0x97a0
	add	x15, x0, x15
	mov	w16, #38682                     ; =0x971a
	add	x16, x0, x16
	mov	w17, #12                        ; =0xc
	mov	w1, #65407                      ; =0xff7f
	b	LBB182_64
LBB182_63:                              ;   in Loop: Header=BB182_64 Depth=1
	add	x11, x11, #1
	cmp	x11, x10
	b.eq	LBB182_108
LBB182_64:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB182_89 Depth 2
	ldrb	w2, [x12, x11]
	cbnz	w2, LBB182_63
; %bb.65:                               ;   in Loop: Header=BB182_64 Depth=1
	mul	x2, x11, x17
	ldrb	w2, [x13, x2]
	cmp	w2, #7
	b.ne	LBB182_63
; %bb.66:                               ;   in Loop: Header=BB182_64 Depth=1
	lsl	x3, x11, #4
	add	x2, x14, x3
	ldrh	w4, [x2, #8]
	ldrb	w5, [x2, #10]
	add	x3, x15, x3
	ldr	w6, [x3, #8]
	orr	w4, w4, w6
	ubfx	w6, w6, #16, #8
	orr	w5, w5, w6
	and	w6, w4, w1
	orr	w5, w5, w6
	cbnz	w5, LBB182_135
; %bb.67:                               ;   in Loop: Header=BB182_64 Depth=1
	ldr	x2, [x2]
	ldr	x3, [x3]
	and	w4, w4, #0xffff
	orr	x2, x3, x2
	cmp	w4, #0
	ccmp	x2, #0, #0, ne
	b.eq	LBB182_135
; %bb.68:                               ;   in Loop: Header=BB182_64 Depth=1
	ldrh	w3, [x16, x11, lsl #1]
	mov	w4, #1                          ; =0x1
	cmp	w3, #2047
	b.gt	LBB182_73
; %bb.69:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #255
	b.le	LBB182_78
; %bb.70:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #256
	b.eq	LBB182_83
; %bb.71:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #512
	b.eq	LBB182_77
; %bb.72:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #1024
	b.eq	LBB182_85
	b	LBB182_82
LBB182_73:                              ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #2, lsl #12                 ; =8192
	b.lt	LBB182_80
; %bb.74:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #8, lsl #12                 ; =32768
	b.eq	LBB182_84
; %bb.75:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #4, lsl #12                 ; =16384
	b.eq	LBB182_85
; %bb.76:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #2, lsl #12                 ; =8192
	b.ne	LBB182_82
LBB182_77:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	w4, #2                          ; =0x2
	b	LBB182_86
LBB182_78:                              ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #64
	b.eq	LBB182_83
; %bb.79:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #128
	b.eq	LBB182_86
	b	LBB182_82
LBB182_80:                              ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #2048
	b.eq	LBB182_84
; %bb.81:                               ;   in Loop: Header=BB182_64 Depth=1
	cmp	w3, #1, lsl #12                 ; =4096
	b.eq	LBB182_86
LBB182_82:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	w4, #0                          ; =0x0
	b	LBB182_86
LBB182_83:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	w4, #5                          ; =0x5
	b	LBB182_86
LBB182_84:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	w4, #4                          ; =0x4
	b	LBB182_86
LBB182_85:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	w4, #3                          ; =0x3
LBB182_86:                              ;   in Loop: Header=BB182_64 Depth=1
	mov	x5, #0                          ; =0x0
	mov	x6, x13
	b	LBB182_89
LBB182_87:                              ;   in Loop: Header=BB182_89 Depth=2
	cmp	w3, #512
	csel	x4, x7, xzr, eq
	orr	x8, x4, x8
	lsl	w4, w20, w19
	ldrh	w7, [x16, x5, lsl #1]
	orr	w4, w7, w4
	strh	w4, [x16, x5, lsl #1]
	mov	x4, x19
LBB182_88:                              ;   in Loop: Header=BB182_89 Depth=2
	add	x5, x5, #1
	add	x6, x6, #12
	cmp	x10, x5
	b.eq	LBB182_63
LBB182_89:                              ;   Parent Loop BB182_64 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x7, x20, x5
	tst	x7, x2
	b.eq	LBB182_88
; %bb.90:                               ;   in Loop: Header=BB182_89 Depth=2
	ldrb	w19, [x12, x5]
	cbnz	w19, LBB182_102
; %bb.91:                               ;   in Loop: Header=BB182_89 Depth=2
	ldrb	w19, [x6]
	cmp	w19, #1
	b.eq	LBB182_100
; %bb.92:                               ;   in Loop: Header=BB182_89 Depth=2
	ldr	x23, [x21, #2064]
	cbz	x23, LBB182_94
; %bb.93:                               ;   in Loop: Header=BB182_89 Depth=2
	cmp	w19, #5
	b.eq	LBB182_100
LBB182_94:                              ;   in Loop: Header=BB182_89 Depth=2
	cmp	w19, #4
	b.eq	LBB182_99
; %bb.95:                               ;   in Loop: Header=BB182_89 Depth=2
	cmp	w19, #3
	b.eq	LBB182_98
; %bb.96:                               ;   in Loop: Header=BB182_89 Depth=2
	cmp	w19, #2
	b.ne	LBB182_102
; %bb.97:                               ;   in Loop: Header=BB182_89 Depth=2
	tbnz	w9, #1, LBB182_100
	b	LBB182_102
LBB182_98:                              ;   in Loop: Header=BB182_89 Depth=2
	tbnz	w9, #2, LBB182_100
	b	LBB182_102
LBB182_99:                              ;   in Loop: Header=BB182_89 Depth=2
	tbz	w9, #3, LBB182_102
LBB182_100:                             ;   in Loop: Header=BB182_89 Depth=2
	cbz	w4, LBB182_87
; %bb.101:                              ;   in Loop: Header=BB182_89 Depth=2
	cmp	w19, w4
	b.eq	LBB182_87
LBB182_102:
	cbz	x22, LBB182_104
; %bb.103:
	ldrb	w8, [x21, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB182_105
LBB182_104:
	mov	w8, #1                          ; =0x1
LBB182_105:
	str	w8, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
Lloh560:
	adrp	x9, l_.str.163@PAGE
Lloh561:
	add	x9, x9, l_.str.163@PAGEOFF
LBB182_106:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh562:
	adrp	x2, l_.str.52@PAGE
Lloh563:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w20, #0                         ; =0x0
LBB182_107:
	mov	x0, x20
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB182_108:
	ldr	w14, [x21]
	mov	w9, #1                          ; =0x1
	cbz	w14, LBB182_137
; %bb.109:
	mov	x10, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w13, #38682                     ; =0x971a
	add	x13, x0, x13
	lsl	x14, x14, #4
	mov	w15, #35904                     ; =0x8c40
	mov	w16, #62                        ; =0x3e
	mov	w17, #128                       ; =0x80
	mov	w1, #130                        ; =0x82
	mov	w2, #2                          ; =0x2
	b	LBB182_111
LBB182_110:                             ;   in Loop: Header=BB182_111 Depth=1
	add	x12, x12, #1
	add	x11, x11, #16
	add	x10, x10, #12
	add	x15, x15, #1
	mov	w20, #1                         ; =0x1
	cmp	x14, x11
	b.eq	LBB182_107
LBB182_111:                             ; =>This Inner Loop Header: Depth=1
	ldrb	w3, [x0, x15]
	cbnz	w3, LBB182_110
; %bb.112:                              ;   in Loop: Header=BB182_111 Depth=1
	add	x6, x13, x11
	ldrb	w4, [x6, #144]
	sub	x3, x6, #3840
	ldrb	w19, [x3]
	add	x3, x13, x10
	sub	x3, x3, #2052
	ldrb	w7, [x3]
	cmp	x7, #7
	csel	w5, w17, w16, eq
	lsl	w3, w9, w7
	and	w20, w3, w5
	cmp	w20, #0
	ccmp	w4, #0, #0, ne
	ccmp	w19, #0, #0, eq
	b.ne	LBB182_138
; %bb.113:                              ;   in Loop: Header=BB182_111 Depth=1
	ldrh	w4, [x6, #142]
	sub	x19, x6, #3842
	ldrh	w19, [x19]
	cmp	w7, #7
	b.eq	LBB182_115
; %bb.114:                              ;   in Loop: Header=BB182_111 Depth=1
	ldur	x7, [x6, #134]
	sub	x6, x6, #3850
	ldr	x6, [x6]
	orr	x6, x7, x6
	cbnz	x6, LBB182_138
LBB182_115:                             ;   in Loop: Header=BB182_111 Depth=1
	bic	w6, w4, w5
	bic	w7, w19, w5
	orr	w6, w6, w7
	cbnz	w6, LBB182_138
; %bb.116:                              ;   in Loop: Header=BB182_111 Depth=1
	mvn	w5, w5
	add	x6, x13, x10
	sub	x6, x6, #2054
	ldrh	w6, [x6]
	tst	w6, w5
	b.ne	LBB182_138
; %bb.117:                              ;   in Loop: Header=BB182_111 Depth=1
	ldrh	w5, [x13, x12, lsl #1]
	lsr	x6, x8, x12
	cmp	w5, #2047
	b.gt	LBB182_122
; %bb.118:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #255
	b.le	LBB182_126
; %bb.119:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #256
	b.eq	LBB182_130
; %bb.120:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #512
	b.eq	LBB182_130
; %bb.121:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #1024
	b.eq	LBB182_130
	b	LBB182_133
LBB182_122:                             ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #2, lsl #12                 ; =8192
	b.lt	LBB182_128
; %bb.123:                              ;   in Loop: Header=BB182_111 Depth=1
	b.eq	LBB182_130
; %bb.124:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #8, lsl #12                 ; =32768
	b.eq	LBB182_130
; %bb.125:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #4, lsl #12                 ; =16384
	b.eq	LBB182_130
	b	LBB182_133
LBB182_126:                             ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #64
	b.eq	LBB182_130
; %bb.127:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #128
	b.eq	LBB182_130
	b	LBB182_133
LBB182_128:                             ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #2048
	b.eq	LBB182_130
; %bb.129:                              ;   in Loop: Header=BB182_111 Depth=1
	cmp	w5, #1, lsl #12                 ; =4096
	b.ne	LBB182_133
LBB182_130:                             ;   in Loop: Header=BB182_111 Depth=1
	tst	x6, #0x1
	mov	w5, #128                        ; =0x80
	csel	w6, w5, w1, eq
LBB182_131:                             ;   in Loop: Header=BB182_111 Depth=1
	and	w3, w3, #0xffff
	cmp	w5, w3
	b.ne	LBB182_192
; %bb.132:                              ;   in Loop: Header=BB182_111 Depth=1
	bics	wzr, w4, w6
	b.eq	LBB182_110
	b	LBB182_192
LBB182_133:                             ;   in Loop: Header=BB182_111 Depth=1
	tst	x6, #0x1
	csel	w6, wzr, w2, eq
	cbz	w5, LBB182_110
; %bb.134:                              ;   in Loop: Header=BB182_111 Depth=1
	orr	w6, w6, w5
	b	LBB182_131
LBB182_135:
	cbz	x22, LBB182_190
; %bb.136:
	ldrb	w8, [x21, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB182_191
LBB182_137:
	mov	w20, #1                         ; =0x1
	b	LBB182_107
LBB182_138:
	ldr	x8, [x21, #992]
	cbz	x8, LBB182_194
; %bb.139:
	ldrb	w8, [x21, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB182_195
LBB182_140:
	add	x8, x20, #1088
	str	x8, [x21, #1016]
	ldr	w8, [x21]
	cbnz	w8, LBB182_17
LBB182_141:
	mov	x24, #0                         ; =0x0
	cbz	w8, LBB182_53
LBB182_142:
	mov	w8, #0                          ; =0x0
	mov	x25, #0                         ; =0x0
	mov	w9, #35904                      ; =0x8c40
	add	x26, x0, x9
	mov	w9, #36630                      ; =0x8f16
	add	x9, x0, x9
	mov	w10, #34832                     ; =0x8810
	add	x10, x0, x10
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
	mov	w10, #38816                     ; =0x97a0
	add	x28, x0, x10
	mov	w10, #38682                     ; =0x971a
	add	x27, x0, x10
	mov	w10, #12                        ; =0xc
Lloh564:
	adrp	x11, lCPI182_0@PAGE
Lloh565:
	ldr	d0, [x11, lCPI182_0@PAGEOFF]
	mov	w14, #64448                     ; =0xfbc0
	movk	w14, #255, lsl #16
Lloh566:
	adrp	x11, lCPI182_1@PAGE
Lloh567:
	ldr	d1, [x11, lCPI182_1@PAGEOFF]
	mov	w12, #1                         ; =0x1
Lloh568:
	adrp	x11, lCPI182_2@PAGE
Lloh569:
	ldr	d2, [x11, lCPI182_2@PAGEOFF]
Lloh570:
	adrp	x11, lCPI182_3@PAGE
Lloh571:
	ldr	d3, [x11, lCPI182_3@PAGEOFF]
Lloh572:
	adrp	x11, lCPI182_4@PAGE
Lloh573:
	ldr	d4, [x11, lCPI182_4@PAGEOFF]
Lloh574:
	adrp	x11, lCPI182_5@PAGE
Lloh575:
	ldr	d5, [x11, lCPI182_5@PAGEOFF]
Lloh576:
	adrp	x11, lCPI182_6@PAGE
Lloh577:
	ldr	d6, [x11, lCPI182_6@PAGEOFF]
Lloh578:
	adrp	x11, lCPI182_7@PAGE
Lloh579:
	ldr	d7, [x11, lCPI182_7@PAGEOFF]
	mov	x13, #276                       ; =0x114
	movk	x13, #1, lsl #16
	movk	x13, #1, lsl #32
	add	x14, x14, #1055
Lloh580:
	adrp	x23, l_.str.167@PAGE
Lloh581:
	add	x23, x23, l_.str.167@PAGEOFF
LBB182_143:                             ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB182_145 Depth 2
                                        ;       Child Loop BB182_155 Depth 3
	mov	x15, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	b	LBB182_145
LBB182_144:                             ;   in Loop: Header=BB182_145 Depth=2
	add	x15, x15, #1
	cmp	x15, x24
	b.eq	LBB182_185
LBB182_145:                             ;   Parent Loop BB182_143 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB182_155 Depth 3
	cbz	x22, LBB182_150
; %bb.146:                              ;   in Loop: Header=BB182_145 Depth=2
	ldrb	w17, [x21, #1024]
	tbnz	w17, #0, LBB182_187
; %bb.147:                              ;   in Loop: Header=BB182_145 Depth=2
	ldrb	w17, [x21, #1025]
	tbnz	w17, #0, LBB182_187
; %bb.148:                              ;   in Loop: Header=BB182_145 Depth=2
	ldr	x17, [x21, #1016]
	lsr	x1, x17, #24
	cbnz	x1, LBB182_57
; %bb.149:                              ;   in Loop: Header=BB182_145 Depth=2
	add	x17, x17, #1
	str	x17, [x21, #1016]
LBB182_150:                             ;   in Loop: Header=BB182_145 Depth=2
	ldrb	w17, [x26, x15]
	cbnz	w17, LBB182_144
; %bb.151:                              ;   in Loop: Header=BB182_145 Depth=2
	mul	x17, x15, x10
	ldrb	w17, [x9, x17]
	cmp	w17, #7
	b.ne	LBB182_144
; %bb.152:                              ;   in Loop: Header=BB182_145 Depth=2
	mov	x17, #0                         ; =0x0
	lsl	x1, x15, #4
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x2, [x11, x1]
	ldr	x1, [x28, x1]
	orr	x1, x1, x2
	b	LBB182_155
LBB182_153:                             ;   in Loop: Header=BB182_155 Depth=3
	ldrh	w11, [x27, x15, lsl #1]
	cmp	w11, #512
	csel	x11, x2, xzr, eq
	orr	x25, x11, x25
LBB182_154:                             ;   in Loop: Header=BB182_155 Depth=3
	add	x17, x17, #1
	cmp	x24, x17
	b.eq	LBB182_144
LBB182_155:                             ;   Parent Loop BB182_143 Depth=1
                                        ;     Parent Loop BB182_145 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x22, LBB182_162
; %bb.156:                              ;   in Loop: Header=BB182_155 Depth=3
	ldrb	w2, [x21, #1024]
	tbnz	w2, #0, LBB182_187
; %bb.157:                              ;   in Loop: Header=BB182_155 Depth=3
	ldrb	w2, [x21, #1025]
	tbnz	w2, #0, LBB182_187
; %bb.158:                              ;   in Loop: Header=BB182_155 Depth=3
	ldr	x3, [x21, #1016]
	lsr	x2, x3, #24
	cbnz	x2, LBB182_57
; %bb.159:                              ;   in Loop: Header=BB182_155 Depth=3
	add	x2, x3, #1
	str	x2, [x21, #1016]
	lsl	x2, x12, x17
	tst	x2, x1
	b.eq	LBB182_154
; %bb.160:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	x3, x14
	b.hi	LBB182_57
; %bb.161:                              ;   in Loop: Header=BB182_155 Depth=3
	add	x3, x3, #33
	str	x3, [x21, #1016]
	b	LBB182_163
LBB182_162:                             ;   in Loop: Header=BB182_155 Depth=3
	lsl	x2, x12, x17
	tst	x2, x1
	b.eq	LBB182_154
LBB182_163:                             ;   in Loop: Header=BB182_155 Depth=3
	ldrb	w3, [x26, x17]
	cbnz	w3, LBB182_44
; %bb.164:                              ;   in Loop: Header=BB182_155 Depth=3
	ldrsh	w5, [x19, x15, lsl #1]
	ldrh	w4, [x19, x17, lsl #1]
	dup.2s	v16, w5
	and.8b	v17, v16, v0
	dup.2s	v18, w4
	ushl.2s	v19, v18, v1
	ushl.2s	v20, v18, v2
	ushl.2s	v18, v18, v3
	cmeq.2s	v17, v17, #0
	bic.8b	v17, v19, v17
	and.8b	v17, v17, v0
	and.8b	v19, v16, v4
	cmeq.2s	v19, v19, #0
	bic.8b	v19, v20, v19
	and.8b	v19, v19, v4
	and.8b	v16, v16, v5
	cmeq.2s	v16, v16, #0
	bic.8b	v16, v18, v16
	and.8b	v16, v16, v5
	orr.8b	v16, v19, v16
	orr.8b	v16, v16, v17
	mov.s	w3, v16[1]
	fmov	w6, s16
	orr	w20, w6, w3
	and	w6, w5, w4, lsl #4
	and	w7, w6, #0x2000
	and	w30, w6, #0x4000
	and	w6, w6, #0xf8000
	and	w11, w5, w4, lsr #2
	and	w11, w11, #0x40
	orr	w11, w6, w11
	orr	w6, w30, w7
	orr	w11, w11, w6
	orr	w6, w11, w20
	and	w7, w6, #0xffff
	fmov	w11, s17
	lsr	w3, w3, #7
	orr	w11, w3, w11, lsr #6
	lsr	w3, w20, #3
	and	w3, w3, #0x20
	orr	w11, w11, w3
	lsr	w3, w20, #5
	and	w3, w3, #0x80
	orr	w11, w11, w3
	lsr	w3, w6, #4
	and	w3, w3, #0xe00
	lsl	w20, w6, #2
	and	w20, w20, #0x100
	orr	w3, w3, w20
	orr	w11, w11, w3
	and	w3, w11, w4
	cmp	w7, #0
	ccmp	w3, #0, #4, ne
	b.eq	LBB182_44
; %bb.165:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w7, w5, uxth
	b.ne	LBB182_168
; %bb.166:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w3, w4
	b.ne	LBB182_169
LBB182_167:                             ;   in Loop: Header=BB182_155 Depth=3
	ldrh	w4, [x27, x15, lsl #1]
	cbnz	w4, LBB182_170
	b	LBB182_154
LBB182_168:                             ;   in Loop: Header=BB182_155 Depth=3
	strh	w6, [x19, x15, lsl #1]
	ldrh	w4, [x19, x17, lsl #1]
	mov	w16, #1                         ; =0x1
	cmp	w3, w4
	b.eq	LBB182_167
LBB182_169:                             ;   in Loop: Header=BB182_155 Depth=3
	strh	w3, [x19, x17, lsl #1]
	mov	w16, #1                         ; =0x1
	ldrh	w4, [x27, x15, lsl #1]
	cbz	w4, LBB182_154
LBB182_170:                             ;   in Loop: Header=BB182_155 Depth=3
	dup.4h	v16, w4
	ushl.4h	v16, v16, v6
	and.8b	v16, v16, v7
	fmov	x11, d16
	lsr	w5, w4, #4
	and	w5, w5, #0xe00
	lsl	w4, w4, #2
	and	w4, w4, #0x100
	orr	x11, x11, x11, lsr #32
	lsr	x6, x11, #16
	orr	w11, w11, w5
	orr	w11, w11, w6
	orr	w4, w11, w4
	and	w5, w4, #0xffff
	cmp	w5, #127
	b.gt	LBB182_179
; %bb.171:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #32
	lsl	x11, x12, x5
	and	x11, x11, x13
	ccmp	x11, #0, #4, ls
	b.eq	LBB182_44
LBB182_172:                             ;   in Loop: Header=BB182_155 Depth=3
	tst	w4, w3
	b.eq	LBB182_44
; %bb.173:                              ;   in Loop: Header=BB182_155 Depth=3
	ldrh	w5, [x27, x17, lsl #1]
	cbz	w5, LBB182_175
; %bb.174:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, w4, uxth
	b.ne	LBB182_44
LBB182_175:                             ;   in Loop: Header=BB182_155 Depth=3
	cbnz	w5, LBB182_177
; %bb.176:                              ;   in Loop: Header=BB182_155 Depth=3
	strh	w4, [x27, x17, lsl #1]
	mov	w16, #1                         ; =0x1
LBB182_177:                             ;   in Loop: Header=BB182_155 Depth=3
	cmp	w3, w4, uxth
	b.eq	LBB182_153
; %bb.178:                              ;   in Loop: Header=BB182_155 Depth=3
	strh	w4, [x19, x17, lsl #1]
	mov	w16, #1                         ; =0x1
	b	LBB182_153
LBB182_179:                             ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #511
	b.le	LBB182_183
; %bb.180:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #512
	b.eq	LBB182_172
; %bb.181:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #2048
	b.eq	LBB182_172
; %bb.182:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #1024
	b.eq	LBB182_172
	b	LBB182_44
LBB182_183:                             ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #128
	b.eq	LBB182_172
; %bb.184:                              ;   in Loop: Header=BB182_155 Depth=3
	cmp	w5, #256
	b.eq	LBB182_172
	b	LBB182_44
LBB182_185:                             ;   in Loop: Header=BB182_143 Depth=1
	tbz	w16, #0, LBB182_198
; %bb.186:                              ;   in Loop: Header=BB182_143 Depth=1
	mov	w15, #3                         ; =0x3
	cmp	w8, #1024
	add	w8, w8, #1
	b.ne	LBB182_143
	b	LBB182_188
LBB182_187:
	mov	w15, #3                         ; =0x3
Lloh582:
	adrp	x23, l_.str.101@PAGE
Lloh583:
	add	x23, x23, l_.str.101@PAGEOFF
LBB182_188:
	str	w15, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
	mov	w9, #191                        ; =0xbf
	stp	x9, x23, [sp]
Lloh584:
	adrp	x2, l_.str.52@PAGE
Lloh585:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w20, #0                         ; =0x0
LBB182_189:
	mov	x0, x19
	bl	_free
	b	LBB182_107
LBB182_190:
	mov	w8, #1                          ; =0x1
LBB182_191:
	str	w8, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
Lloh586:
	adrp	x9, l_.str.162@PAGE
Lloh587:
	add	x9, x9, l_.str.162@PAGEOFF
	b	LBB182_106
LBB182_192:
	ldr	x8, [x21, #992]
	cbz	x8, LBB182_196
; %bb.193:
	ldrb	w8, [x21, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB182_197
LBB182_194:
	mov	w8, #1                          ; =0x1
LBB182_195:
	str	w8, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
Lloh588:
	adrp	x9, l_.str.164@PAGE
Lloh589:
	add	x9, x9, l_.str.164@PAGEOFF
	b	LBB182_106
LBB182_196:
	mov	w8, #1                          ; =0x1
LBB182_197:
	str	w8, [x21, #780]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #784]
	mov	w8, #37400                      ; =0x9218
Lloh590:
	adrp	x9, l_.str.165@PAGE
Lloh591:
	add	x9, x9, l_.str.165@PAGEOFF
	b	LBB182_106
LBB182_198:
	mov	x12, #0                         ; =0x0
	mov	w8, #36620                      ; =0x8f0c
	add	x13, x0, x8
	mov	w14, #12                        ; =0xc
	mov	w15, #-63                       ; =0xffffffc1
	mov	w16, #-129                      ; =0xffffff7f
Lloh592:
	adrp	x23, l_.str.101@PAGE
Lloh593:
	add	x23, x23, l_.str.101@PAGEOFF
	stp	x13, x0, [sp, #24]              ; 16-byte Folded Spill
	b	LBB182_200
LBB182_199:                             ;   in Loop: Header=BB182_200 Depth=1
	add	x12, x12, #1
	mov	w20, #1                         ; =0x1
	cmp	x12, x24
	b.eq	LBB182_189
LBB182_200:                             ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x26, x12]
	cbnz	w8, LBB182_199
; %bb.201:                              ;   in Loop: Header=BB182_200 Depth=1
	cbz	x22, LBB182_206
; %bb.202:                              ;   in Loop: Header=BB182_200 Depth=1
	ldrb	w8, [x21, #1024]
	tbnz	w8, #0, LBB182_213
; %bb.203:                              ;   in Loop: Header=BB182_200 Depth=1
	ldrb	w8, [x21, #1025]
	tbnz	w8, #0, LBB182_213
; %bb.204:                              ;   in Loop: Header=BB182_200 Depth=1
	ldr	x8, [x21, #1016]
	mov	w9, #65521                      ; =0xfff1
	movk	w9, #255, lsl #16
	cmp	x8, x9
	b.hs	LBB182_57
; %bb.205:                              ;   in Loop: Header=BB182_200 Depth=1
	add	x8, x8, #16
	str	x8, [x21, #1016]
LBB182_206:                             ;   in Loop: Header=BB182_200 Depth=1
	lsl	x8, x12, #4
	add	x9, x28, x8
	ldrb	w11, [x9, #10]
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	add	x10, x10, x8
	ldrb	w8, [x10, #10]
	and	w8, w8, #0xff
	orr	w8, w11, w8
	cbnz	w8, LBB182_44
; %bb.207:                              ;   in Loop: Header=BB182_200 Depth=1
	madd	x8, x12, x14, x13
	ldrb	w1, [x8, #10]
	ldrh	w10, [x10, #8]
	ldrh	w17, [x9, #8]
	cmp	w1, #7
	csel	w9, w16, w15, eq
	and	w11, w9, w17
	and	w10, w9, w10
	orr	w10, w11, w10
	cbnz	w10, LBB182_44
; %bb.208:                              ;   in Loop: Header=BB182_200 Depth=1
	ldrh	w8, [x8, #8]
	tst	w9, w8
	b.ne	LBB182_44
; %bb.209:                              ;   in Loop: Header=BB182_200 Depth=1
	ldrh	w20, [x27, x12, lsl #1]
	cbz	w20, LBB182_199
; %bb.210:                              ;   in Loop: Header=BB182_200 Depth=1
	mov	x0, x20
	str	x12, [sp, #48]                  ; 8-byte Folded Spill
	stp	w1, w17, [sp, #40]              ; 8-byte Folded Spill
	bl	_nvm_record_array_requirement_depth
	ldp	w11, w10, [sp, #40]             ; 8-byte Folded Reload
	mov	w16, #-129                      ; =0xffffff7f
	mov	w15, #-63                       ; =0xffffffc1
	mov	w14, #12                        ; =0xc
	ldr	x12, [sp, #48]                  ; 8-byte Folded Reload
	mov	x8, x0
	ldp	x13, x0, [sp, #24]              ; 16-byte Folded Reload
	cbz	w8, LBB182_44
; %bb.211:                              ;   in Loop: Header=BB182_200 Depth=1
	cmp	w8, #1
	mov	w8, #128                        ; =0x80
	csel	w8, w20, w8, eq
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w11
	cmp	w8, w9, uxth
	b.ne	LBB182_44
; %bb.212:                              ;   in Loop: Header=BB182_200 Depth=1
	lsr	x9, x25, x12
	tst	x9, #0x1
	mov	w9, #2                          ; =0x2
	csel	w9, wzr, w9, eq
	orr	w8, w8, w9
	bics	wzr, w10, w8
	b.eq	LBB182_199
	b	LBB182_44
LBB182_213:
	mov	w15, #3                         ; =0x3
	b	LBB182_188
	.loh AdrpAdd	Lloh548, Lloh549
	.loh AdrpAdd	Lloh550, Lloh551
	.loh AdrpAdd	Lloh554, Lloh555
	.loh AdrpLdr	Lloh552, Lloh553
	.loh AdrpAdd	Lloh556, Lloh557
	.loh AdrpAdd	Lloh558, Lloh559
	.loh AdrpAdd	Lloh560, Lloh561
	.loh AdrpAdd	Lloh562, Lloh563
	.loh AdrpAdd	Lloh580, Lloh581
	.loh AdrpLdr	Lloh578, Lloh579
	.loh AdrpAdrp	Lloh576, Lloh578
	.loh AdrpLdr	Lloh576, Lloh577
	.loh AdrpAdrp	Lloh574, Lloh576
	.loh AdrpLdr	Lloh574, Lloh575
	.loh AdrpAdrp	Lloh572, Lloh574
	.loh AdrpLdr	Lloh572, Lloh573
	.loh AdrpAdrp	Lloh570, Lloh572
	.loh AdrpLdr	Lloh570, Lloh571
	.loh AdrpAdrp	Lloh568, Lloh570
	.loh AdrpLdr	Lloh568, Lloh569
	.loh AdrpAdrp	Lloh566, Lloh568
	.loh AdrpLdr	Lloh566, Lloh567
	.loh AdrpAdrp	Lloh564, Lloh566
	.loh AdrpLdr	Lloh564, Lloh565
	.loh AdrpAdd	Lloh582, Lloh583
	.loh AdrpAdd	Lloh584, Lloh585
	.loh AdrpAdd	Lloh586, Lloh587
	.loh AdrpAdd	Lloh588, Lloh589
	.loh AdrpAdd	Lloh590, Lloh591
	.loh AdrpAdd	Lloh592, Lloh593
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_final
_map_final:                             ; @map_final
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #35904                      ; =0x8c40
	add	x8, x0, x8
	ldr	w10, [x8, #1688]
	ldr	x9, [x8, #1696]
	cbz	x9, LBB183_8
; %bb.1:
	ldrb	w11, [x8, #1728]
	tbnz	w11, #0, LBB183_5
; %bb.2:
	ldrb	w11, [x8, #1729]
	tbnz	w11, #0, LBB183_5
; %bb.3:
	add	w11, w10, #128
	ldr	x12, [x8, #1720]
	mov	w13, #16777216                  ; =0x1000000
	sub	x14, x13, x12
	cmp	x12, x13
	ccmp	x14, x11, #0, ls
	b.hs	LBB183_7
; %bb.4:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1728]
LBB183_5:
Lloh594:
	adrp	x9, l_.str.101@PAGE
Lloh595:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #3                         ; =0x3
LBB183_6:
	str	w10, [x8, #1484]
	movi.2d	v0, #0000000000000000
	str	d0, [x8, #1488]
	mov	w8, #37400                      ; =0x9218
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh596:
	adrp	x2, l_.str.52@PAGE
Lloh597:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	b	LBB183_21
LBB183_7:
	add	x11, x12, x11
	str	x11, [x8, #1720]
LBB183_8:
	cbz	w10, LBB183_12
; %bb.9:
	mov	w11, #30736                     ; =0x7810
	add	x11, x0, x11
LBB183_10:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w12, [x11], #16
	tbnz	w12, #13, LBB183_22
; %bb.11:                               ;   in Loop: Header=BB183_10 Depth=1
	subs	x10, x10, #1
	b.ne	LBB183_10
LBB183_12:
	ldr	w12, [x8, #704]
	mov	w11, #1                         ; =0x1
	cbz	w12, LBB183_20
; %bb.13:
	mov	x10, #0                         ; =0x0
	lsl	w11, w11, w2
	mvn	w11, w11
	lsl	x12, x12, #4
	mov	x13, x8
	b	LBB183_15
LBB183_14:                              ;   in Loop: Header=BB183_15 Depth=1
	add	x10, x10, #16
	cmp	x12, x10
	b.eq	LBB183_20
LBB183_15:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w14, [x13], #1
	cmp	w14, #2
	b.ne	LBB183_14
; %bb.16:                               ;   in Loop: Header=BB183_15 Depth=1
	add	x14, x1, x10
	ldr	x15, [x14, #8]
	ldrb	w16, [x14, #18]
	ldr	x17, [x14, #1032]
	ldrb	w2, [x14, #1042]
	cmp	w16, #0
	ccmp	w2, #0, #0, eq
	ccmp	x15, #0, #0, eq
	ccmp	x17, #0, #0, eq
	b.ne	LBB183_18
; %bb.17:                               ;   in Loop: Header=BB183_15 Depth=1
	ldrh	w15, [x14, #1040]
	ldrh	w14, [x14, #16]
	and	w14, w14, #0xffffffdf
	and	w15, w15, w11
	and	w15, w15, #0xffff
	orr	w14, w14, w15
	cbz	w14, LBB183_14
LBB183_18:
	cbz	x9, LBB183_25
; %bb.19:
	ldrb	w9, [x8, #1728]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh598:
	adrp	x9, l_.str.170@PAGE
Lloh599:
	add	x9, x9, l_.str.170@PAGEOFF
	b	LBB183_6
LBB183_20:
	mov	w0, #1                          ; =0x1
LBB183_21:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB183_22:
	cbz	x9, LBB183_24
; %bb.23:
	ldrb	w9, [x8, #1728]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh600:
	adrp	x9, l_.str.169@PAGE
Lloh601:
	add	x9, x9, l_.str.169@PAGEOFF
	b	LBB183_6
LBB183_24:
Lloh602:
	adrp	x9, l_.str.169@PAGE
Lloh603:
	add	x9, x9, l_.str.169@PAGEOFF
	mov	w10, #1                         ; =0x1
	b	LBB183_6
LBB183_25:
Lloh604:
	adrp	x9, l_.str.170@PAGE
Lloh605:
	add	x9, x9, l_.str.170@PAGEOFF
	mov	w10, #1                         ; =0x1
	b	LBB183_6
	.loh AdrpAdd	Lloh594, Lloh595
	.loh AdrpAdd	Lloh596, Lloh597
	.loh AdrpAdd	Lloh598, Lloh599
	.loh AdrpAdd	Lloh600, Lloh601
	.loh AdrpAdd	Lloh602, Lloh603
	.loh AdrpAdd	Lloh604, Lloh605
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_boundary_value_valid
_map_boundary_value_valid:              ; @map_boundary_value_valid
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	tst	x1, #0xff0000
	b.ne	LBB184_11
; %bb.1:
	and	x9, x1, #0xffff
	cbz	x9, LBB184_11
; %bb.2:
	mov	w8, #65088                      ; =0xfe40
	tst	w1, w8
	b.eq	LBB184_4
LBB184_3:
	mov	w0, #0                          ; =0x0
	ret
LBB184_4:
	tbnz	w1, #7, LBB184_6
; %bb.5:
	mov	x2, #0                          ; =0x0
	b	LBB184_7
LBB184_6:
	tst	x0, x2
	b.eq	LBB184_3
LBB184_7:
	tbz	w1, #8, LBB184_10
; %bb.8:
	tst	x3, x0
	b.eq	LBB184_3
; %bb.9:
	orr	x2, x2, x3
LBB184_10:
	bics	xzr, x0, x2
	cset	w8, eq
LBB184_11:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function map_freeze
lCPI185_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_map_freeze:                            ; @map_freeze
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	mov	w8, #35888                      ; =0x8c30
	add	x21, x0, x8
	ldr	x25, [x21, #1712]
	cbz	x25, LBB185_9
; %bb.1:
	ldrb	w8, [x21, #1744]
	tbnz	w8, #0, LBB185_8
; %bb.2:
	ldrb	w8, [x21, #1745]
	tbnz	w8, #0, LBB185_45
; %bb.3:
	ldr	x8, [x21, #1720]
	mov	w9, #65481                      ; =0xffc9
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB185_7
; %bb.4:
	add	x8, x8, #56
	str	x8, [x21, #1720]
	ldr	x9, [x21, #1728]
	cmp	x9, x8
	b.hs	LBB185_6
; %bb.5:
	str	x8, [x21, #1728]
LBB185_6:
	ldr	x24, [x21, #1736]
	lsr	x8, x24, #24
	cbz	x8, LBB185_15
LBB185_7:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1744]
LBB185_8:
	mov	w8, #3                          ; =0x3
	b	LBB185_46
LBB185_9:
	mov	x23, x1
	mov	x22, x2
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	mov	x20, x0
	cbz	x0, LBB185_45
; %bb.10:
	ldr	w24, [x21, #720]
	cbz	w24, LBB185_51
LBB185_11:
	cmp	x24, #7
	b.hi	LBB185_13
; %bb.12:
	mov	x8, #0                          ; =0x0
	mov	w26, #0                         ; =0x0
	b	LBB185_25
LBB185_13:
	cmp	x24, #64
	b.hs	LBB185_18
; %bb.14:
	mov	x8, #0                          ; =0x0
	mov	w26, #0                         ; =0x0
	b	LBB185_22
LBB185_15:
	mov	x23, x1
	mov	x22, x2
	add	x8, x24, #1
	str	x8, [x21, #1736]
	mov	w26, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #56                         ; =0x38
	bl	_calloc
	cbz	x0, LBB185_44
; %bb.16:
	mov	x20, x0
	mov	w8, #65407                      ; =0xff7f
	movk	w8, #255, lsl #16
	cmp	x24, x8
	b.ls	LBB185_50
; %bb.17:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1744]
	add	x8, x21, #1500
Lloh606:
	adrp	x9, lCPI185_0@PAGE
Lloh607:
	ldr	d0, [x9, lCPI185_0@PAGEOFF]
	str	d0, [x8]
	str	wzr, [x21, #1508]
	mov	w8, #37400                      ; =0x9218
Lloh608:
	adrp	x9, l_.str.101@PAGE
Lloh609:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh610:
	adrp	x2, l_.str.52@PAGE
Lloh611:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x0, x20
	bl	_free
	b	LBB185_48
LBB185_18:
	movi.2d	v0, #0000000000000000
	and	x8, x24, #0xffffffc0
	movi.16b	v1, #2
	mov	w9, #35952                      ; =0x8c70
	movi.4s	v2, #1
	add	x9, x19, x9
	movi.2d	v4, #0000000000000000
	mov	x10, x8
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
LBB185_19:                              ; =>This Inner Loop Header: Depth=1
	ldp	q27, q26, [x9, #-48]
	cmeq.16b	v27, v27, v1
	ushll.8h	v28, v27, #0
	ushll2.8h	v27, v27, #0
	ushll2.4s	v29, v27, #0
	and.16b	v29, v29, v2
	add.4s	v5, v5, v29
	ushll.4s	v29, v28, #0
	and.16b	v29, v29, v2
	ushll2.4s	v28, v28, #0
	and.16b	v28, v28, v2
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v26, v26, v1
	add.4s	v3, v3, v27
	ushll2.8h	v27, v26, #0
	add.4s	v4, v4, v28
	ushll2.4s	v28, v27, #0
	and.16b	v28, v28, v2
	add.4s	v0, v0, v29
	add.4s	v23, v23, v28
	ldp	q28, q29, [x9, #-16]
	ushll.8h	v26, v26, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v17, v17, v27
	ushll.4s	v27, v26, #0
	and.16b	v27, v27, v2
	ushll2.4s	v26, v26, #0
	and.16b	v26, v26, v2
	cmeq.16b	v28, v28, v1
	add.4s	v20, v20, v26
	ushll2.8h	v26, v28, #0
	add.4s	v6, v6, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v21, v21, v27
	ushll.8h	v27, v28, #0
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v24, v24, v26
	ushll.4s	v26, v27, #0
	and.16b	v26, v26, v2
	ushll2.4s	v27, v27, #0
	and.16b	v27, v27, v2
	cmeq.16b	v28, v29, v1
	add.4s	v7, v7, v27
	ushll2.8h	v27, v28, #0
	add.4s	v18, v18, v26
	ushll2.4s	v26, v27, #0
	and.16b	v26, v26, v2
	add.4s	v25, v25, v26
	ushll.8h	v26, v28, #0
	ushll.4s	v27, v27, #0
	and.16b	v27, v27, v2
	add.4s	v19, v19, v27
	ushll2.4s	v27, v26, #0
	and.16b	v27, v27, v2
	add.4s	v22, v22, v27
	ushll.4s	v26, v26, #0
	and.16b	v26, v26, v2
	add.4s	v16, v16, v26
	add	x9, x9, #64
	subs	x10, x10, #64
	b.ne	LBB185_19
; %bb.20:
	add.4s	v1, v20, v4
	add.4s	v2, v23, v5
	add.4s	v0, v6, v0
	add.4s	v3, v17, v3
	add.4s	v3, v24, v3
	add.4s	v0, v18, v0
	add.4s	v2, v21, v2
	add.4s	v1, v7, v1
	add.4s	v1, v22, v1
	add.4s	v2, v25, v2
	add.4s	v0, v16, v0
	add.4s	v3, v19, v3
	add.4s	v0, v0, v3
	add.4s	v1, v1, v2
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w26, s0
	cmp	x8, x24
	b.eq	LBB185_27
; %bb.21:
	tst	x24, #0x38
	b.eq	LBB185_25
LBB185_22:
	mov	x10, x8
	and	x8, x24, #0xfffffff8
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.s	v1[0], w26
	sub	x9, x10, x8
	mov	w11, #35904                     ; =0x8c40
	add	x10, x10, x19
	add	x10, x10, x11
	movi.8b	v2, #2
	movi.4s	v3, #1
LBB185_23:                              ; =>This Inner Loop Header: Depth=1
	ldr	d4, [x10], #8
	cmeq.8b	v4, v4, v2
	ushll.8h	v4, v4, #0
	ushll.4s	v5, v4, #0
	and.16b	v5, v5, v3
	ushll2.4s	v4, v4, #0
	and.16b	v4, v4, v3
	add.4s	v0, v0, v4
	add.4s	v1, v1, v5
	adds	x9, x9, #8
	b.ne	LBB185_23
; %bb.24:
	add.4s	v0, v1, v0
	addv.4s	s0, v0
	fmov	w26, s0
	cmp	x8, x24
	b.eq	LBB185_27
LBB185_25:
	mov	w9, #35904                      ; =0x8c40
	add	x10, x8, x19
	add	x9, x10, x9
	sub	x8, x24, x8
LBB185_26:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cmp	w10, #2
	cinc	w26, w26, eq
	subs	x8, x8, #1
	b.ne	LBB185_26
LBB185_27:
	cbz	w26, LBB185_40
; %bb.28:
	mov	w0, w26
	cbz	x25, LBB185_39
; %bb.29:
	ldrb	w8, [x21, #1744]
	tbnz	w8, #0, LBB185_56
; %bb.30:
	ldrb	w8, [x21, #1745]
	tbnz	w8, #0, LBB185_58
; %bb.31:
	ldr	x8, [x21, #1720]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB185_55
; %bb.32:
	lsl	x9, x0, #3
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB185_55
; %bb.33:
	ldr	x10, [x21, #1728]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x21, #1720]
	b.hs	LBB185_35
; %bb.34:
	str	x8, [x21, #1728]
LBB185_35:
	ldr	x8, [x21, #1736]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB185_55
; %bb.36:
	sub	x9, x9, x8
	cmp	x9, x0
	b.lo	LBB185_55
; %bb.37:
	add	x8, x8, x0
	str	x8, [x21, #1736]
	mov	w1, #8                          ; =0x8
	bl	_calloc
	cbz	x0, LBB185_57
; %bb.38:
	str	x0, [x20, #16]
	b	LBB185_40
LBB185_39:
	mov	w1, #8                          ; =0x8
	bl	_calloc
	str	x0, [x20, #16]
	cbz	x0, LBB185_58
LBB185_40:
	mov	x8, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w9, #35904                      ; =0x8c40
	add	x9, x19, x9
	b	LBB185_42
LBB185_41:                              ;   in Loop: Header=BB185_42 Depth=1
	add	x8, x8, #1
	cmp	x8, x24
	b.hs	LBB185_52
LBB185_42:                              ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9, x8]
	cmp	w11, #2
	b.ne	LBB185_41
; %bb.43:                               ;   in Loop: Header=BB185_42 Depth=1
	ldr	x11, [x20, #16]
	add	x11, x11, w10, uxtw #3
	add	w10, w10, #1
	stp	w8, wzr, [x11]
	ldr	w24, [x21, #720]
	b	LBB185_41
LBB185_44:
	strb	w26, [x21, #1745]
LBB185_45:
	mov	w8, #4                          ; =0x4
LBB185_46:
	str	w8, [x21, #1500]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1504]
	mov	w8, #37400                      ; =0x9218
Lloh612:
	adrp	x9, l_.str.171@PAGE
Lloh613:
	add	x9, x9, l_.str.171@PAGEOFF
LBB185_47:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh614:
	adrp	x2, l_.str.52@PAGE
Lloh615:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB185_48:
	mov	w0, #0                          ; =0x0
LBB185_49:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB185_50:
	add	x8, x24, #129
	str	x8, [x21, #1736]
	ldr	w24, [x21, #720]
	cbnz	w24, LBB185_11
LBB185_51:
	mov	w26, #0                         ; =0x0
LBB185_52:
	mov	x0, x19
	mov	x1, x20
	bl	_ra_publish
	cbz	w0, LBB185_54
; %bb.53:
	ldr	w8, [x21, #720]
	ldr	w9, [x21]
	ldr	w10, [x23, #2056]
	stp	w8, w26, [x20, #24]
	stp	w9, w10, [x20, #32]
	ldr	q0, [x19, #37616]
	stur	q0, [x20, #40]
	ldr	x8, [x23]
	str	x8, [x20, #8]
	str	xzr, [x23]
	mov	w0, #1                          ; =0x1
	str	x20, [x22]
	b	LBB185_49
LBB185_54:
	mov	x0, x20
	bl	_nvm_record_map_frozen_free
	b	LBB185_48
LBB185_55:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1744]
LBB185_56:
	mov	w22, #3                         ; =0x3
	b	LBB185_59
LBB185_57:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1745]
LBB185_58:
	mov	w22, #4                         ; =0x4
LBB185_59:
	mov	x0, x20
	bl	_free
	str	w22, [x21, #1500]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1504]
	mov	w8, #37400                      ; =0x9218
Lloh616:
	adrp	x9, l_.str.172@PAGE
Lloh617:
	add	x9, x9, l_.str.172@PAGEOFF
	b	LBB185_47
	.loh AdrpAdd	Lloh610, Lloh611
	.loh AdrpAdd	Lloh608, Lloh609
	.loh AdrpAdrp	Lloh606, Lloh608
	.loh AdrpLdr	Lloh606, Lloh607
	.loh AdrpAdd	Lloh612, Lloh613
	.loh AdrpAdd	Lloh614, Lloh615
	.loh AdrpAdd	Lloh616, Lloh617
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function ra_publish
lCPI186_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_ra_publish:                            ; @ra_publish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	mov	w8, #35888                      ; =0x8c30
	add	x21, x0, x8
	ldr	x8, [x21, #1712]
	cbz	x8, LBB186_9
; %bb.1:
	ldrb	w8, [x21, #1744]
	tbnz	w8, #0, LBB186_8
; %bb.2:
	ldrb	w8, [x21, #1745]
	tbnz	w8, #0, LBB186_17
; %bb.3:
	ldr	x8, [x21, #1720]
	mov	w9, #65353                      ; =0xff49
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB186_7
; %bb.4:
	add	x8, x8, #184
	str	x8, [x21, #1720]
	ldr	x9, [x21, #1728]
	cmp	x9, x8
	b.hs	LBB186_6
; %bb.5:
	str	x8, [x21, #1728]
LBB186_6:
	ldr	x23, [x21, #1736]
	lsr	x8, x23, #24
	cbz	x8, LBB186_12
LBB186_7:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1744]
LBB186_8:
	mov	w8, #3                          ; =0x3
	b	LBB186_18
LBB186_9:
	mov	x22, x1
	mov	w0, #1                          ; =0x1
	mov	w1, #184                        ; =0xb8
	bl	_calloc
	mov	x20, x0
	cbz	x0, LBB186_17
LBB186_10:
	add	x1, x20, #8
	mov	x0, x19
	bl	_publish_records
	cbz	w0, LBB186_15
; %bb.11:
	mov	w8, #38682                      ; =0x971a
	add	x8, x19, x8
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x20, #80]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x20, #112]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldr	x8, [x20, #8]
	ldr	w9, [x8, #16]
	ldr	q0, [x8]
	str	q0, [x20, #144]
	stp	w9, wzr, [x20, #160]
	ldr	q0, [x19, #37616]
	ext.16b	v0, v0, v0, #8
	stur	q0, [x20, #168]
	ldr	x8, [x21, #1712]
	ldr	x9, [x8]
	str	x9, [x20]
	str	xzr, [x8]
	str	x20, [x22]
	mov	w0, #1                          ; =0x1
	b	LBB186_20
LBB186_12:
	mov	x22, x1
	add	x24, x23, #1
	str	x24, [x21, #1736]
	mov	w25, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #184                        ; =0xb8
	bl	_calloc
	cbz	x0, LBB186_16
; %bb.13:
	mov	x20, x0
	ldr	w8, [x21]
	add	x8, x8, #128
	mov	w9, #16777215                   ; =0xffffff
	sub	x9, x9, x23
	cmp	x8, x9
	b.ls	LBB186_21
; %bb.14:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1744]
	add	x8, x21, #1500
Lloh618:
	adrp	x9, lCPI186_0@PAGE
Lloh619:
	ldr	d0, [x9, lCPI186_0@PAGEOFF]
	str	d0, [x8]
	str	wzr, [x21, #1508]
	mov	w8, #37400                      ; =0x9218
Lloh620:
	adrp	x9, l_.str.101@PAGE
Lloh621:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh622:
	adrp	x2, l_.str.52@PAGE
Lloh623:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB186_15:
	mov	x0, x20
	bl	_free
	b	LBB186_19
LBB186_16:
	strb	w25, [x21, #1745]
LBB186_17:
	mov	w8, #4                          ; =0x4
LBB186_18:
	str	w8, [x21, #1500]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1504]
	mov	w8, #37400                      ; =0x9218
Lloh624:
	adrp	x9, l_.str.173@PAGE
Lloh625:
	add	x9, x9, l_.str.173@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh626:
	adrp	x2, l_.str.52@PAGE
Lloh627:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB186_19:
	mov	w0, #0                          ; =0x0
LBB186_20:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB186_21:
	add	x8, x24, x8
	str	x8, [x21, #1736]
	b	LBB186_10
	.loh AdrpAdd	Lloh622, Lloh623
	.loh AdrpAdd	Lloh620, Lloh621
	.loh AdrpAdrp	Lloh618, Lloh620
	.loh AdrpLdr	Lloh618, Lloh619
	.loh AdrpAdd	Lloh626, Lloh627
	.loh AdrpAdd	Lloh624, Lloh625
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function publish_records
_publish_records:                       ; @publish_records
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	mov	w8, #35872                      ; =0x8c20
	add	x21, x0, x8
	ldr	x8, [x21, #1728]
	cbz	x8, LBB187_9
; %bb.1:
	ldrb	w8, [x21, #1760]
	tbnz	w8, #0, LBB187_8
; %bb.2:
	ldrb	w8, [x21, #1761]
	tbnz	w8, #0, LBB187_38
; %bb.3:
	ldr	x8, [x21, #1736]
	mov	w9, #62433                      ; =0xf3e1
	movk	w9, #1023, lsl #16
	cmp	x8, x9
	b.hs	LBB187_7
; %bb.4:
	add	x8, x8, #3104
	str	x8, [x21, #1736]
	ldr	x9, [x21, #1744]
	cmp	x9, x8
	b.hs	LBB187_6
; %bb.5:
	str	x8, [x21, #1744]
LBB187_6:
	ldr	x8, [x21, #1752]
	lsr	x9, x8, #24
	cbz	x9, LBB187_14
LBB187_7:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1760]
LBB187_8:
	mov	w8, #3                          ; =0x3
	b	LBB187_39
LBB187_9:
	mov	x22, x1
	mov	w0, #1                          ; =0x1
	mov	w1, #3104                       ; =0xc20
	bl	_calloc
	cbz	x0, LBB187_38
; %bb.10:
	ldr	w20, [x21, #16]
	cbz	w20, LBB187_26
; %bb.11:
	mov	x23, x0
	mov	x0, x20
	mov	w1, #16                         ; =0x10
	bl	_calloc
	mov	x8, x0
	mov	x0, x23
	str	x8, [x23, #3096]
	cbz	x8, LBB187_13
; %bb.12:
	mov	w9, #0                          ; =0x0
                                        ; kill: def $w20 killed $w20 killed $x20 def $x20
	b	LBB187_27
LBB187_13:
	bl	_free
	mov	w8, #4                          ; =0x4
	b	LBB187_44
LBB187_14:
	mov	x22, x1
	add	x8, x8, #1
	str	x8, [x21, #1752]
	mov	w20, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #3104                       ; =0xc20
	bl	_calloc
	cbz	x0, LBB187_37
; %bb.15:
	ldr	w20, [x21, #16]
	cbz	w20, LBB187_26
; %bb.16:
	ldrb	w8, [x21, #1760]
	tbnz	w8, #0, LBB187_43
; %bb.17:
	ldrb	w8, [x21, #1761]
	tbnz	w8, #0, LBB187_43
; %bb.18:
	ldr	x8, [x21, #1736]
	mov	w10, #67108864                  ; =0x4000000
	cmp	x8, x10
	b.hi	LBB187_42
; %bb.19:
	lsl	x9, x20, #4
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB187_42
; %bb.20:
	ldr	x10, [x21, #1744]
	add	x8, x8, x9
	cmp	x10, x8
	str	x8, [x21, #1736]
	b.hs	LBB187_22
; %bb.21:
	str	x8, [x21, #1744]
LBB187_22:
	ldr	x8, [x21, #1752]
	mov	w9, #16777216                   ; =0x1000000
	cmp	x8, x9
	b.hi	LBB187_42
; %bb.23:
	sub	x9, x9, x8
	cmp	x9, x20
	b.lo	LBB187_42
; %bb.24:
	mov	x23, x0
	add	x8, x8, x20
	str	x8, [x21, #1752]
	mov	x0, x20
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB187_45
; %bb.25:
	mov	x8, x0
	mov	w9, #0                          ; =0x0
	mov	x0, x23
	str	x8, [x23, #3096]
	b	LBB187_27
LBB187_26:
	mov	w9, #1                          ; =0x1
LBB187_27:
	mov	x8, x22
	ldr	w11, [x21, #736]
	stp	w11, w20, [x0]
	ldr	w10, [x21, #20]
	str	w10, [x0, #8]
	add	x10, x21, #740
	ldr	d0, [x10]
	stur	d0, [x0, #12]
	cbz	w11, LBB187_33
; %bb.28:
	mov	x10, #0                         ; =0x0
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #4
	mov	w12, #36620                     ; =0x8f0c
	mov	w13, #36628                     ; =0x8f14
	mov	w14, #36631                     ; =0x8f17
	mov	w15, #34832                     ; =0x8810
	mov	w16, #35904                     ; =0x8c40
	mov	w17, #34842                     ; =0x881a
	mov	w1, #36224                      ; =0x8d80
	mov	w2, #36480                      ; =0x8e80
	movi.2d	v0, #0xffffffffffffffff
	b	LBB187_31
LBB187_29:                              ;   in Loop: Header=BB187_31 Depth=1
	add	x4, x19, x1
	ldur	w5, [x4, #-256]
	str	w5, [x3, #32]
	ldr	x6, [x21]
	ldr	x6, [x6, #24]
	ldr	w5, [x6, x5, lsl #2]
	ldr	w4, [x4]
	stp	w5, w4, [x3, #36]
	ldrh	w4, [x19, x2]
	strh	w4, [x3, #44]
LBB187_30:                              ;   in Loop: Header=BB187_31 Depth=1
	add	x12, x12, #12
	add	x13, x13, #12
	add	x10, x10, #48
	add	x15, x15, #16
	add	x17, x17, #16
	add	x1, x1, #4
	add	x2, x2, #2
	add	x16, x16, #1
	add	x14, x14, #12
	cmp	x11, x10
	b.eq	LBB187_33
LBB187_31:                              ; =>This Inner Loop Header: Depth=1
	add	x3, x0, x10
	ldr	d1, [x19, x12]
	ldrb	w4, [x19, x16]
	strb	w4, [x3, #46]
	stp	d1, d0, [x3, #24]
	add	x5, x19, x14
	ldurh	w5, [x5, #-1]
	sturh	w5, [x3, #47]
	cmp	w4, #1
	b.eq	LBB187_29
; %bb.32:                               ;   in Loop: Header=BB187_31 Depth=1
	ldr	x4, [x19, x15]
	ldrh	w5, [x19, x13]
	ldrb	w6, [x19, x17]
	str	x4, [x3, #56]
	strh	w5, [x3, #64]
	strb	w6, [x3, #66]
	stur	wzr, [x3, #67]
	strb	wzr, [x3, #71]
	b	LBB187_30
LBB187_33:
	tbnz	w9, #0, LBB187_36
; %bb.34:
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x11, [x0, #3096]
	add	x11, x11, #11
LBB187_35:                              ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x21, #8]
	add	x12, x12, x9
	ldr	x13, [x12]
	ldrh	w14, [x12, #8]
	ldrb	w12, [x12, #10]
	stur	x13, [x11, #-11]
	sturh	w14, [x11, #-3]
	sturb	w12, [x11, #-1]
	str	wzr, [x11]
	strb	wzr, [x11, #4]
	add	x10, x10, #1
	ldr	w12, [x21, #16]
	add	x11, x11, #16
	add	x9, x9, #16
	cmp	x10, x12
	b.lo	LBB187_35
LBB187_36:
	str	x0, [x8]
	mov	w0, #1                          ; =0x1
	b	LBB187_41
LBB187_37:
	strb	w20, [x21, #1761]
LBB187_38:
	mov	w8, #4                          ; =0x4
LBB187_39:
	str	w8, [x21, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh628:
	adrp	x9, l_.str.174@PAGE
Lloh629:
	add	x9, x9, l_.str.174@PAGEOFF
LBB187_40:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh630:
	adrp	x2, l_.str.52@PAGE
Lloh631:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB187_41:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB187_42:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1760]
LBB187_43:
	bl	_free
	ldrb	w8, [x21, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	cinc	w8, w8, eq
LBB187_44:
	str	w8, [x21, #1516]
	movi.2d	v0, #0000000000000000
	str	d0, [x21, #1520]
	mov	w8, #37400                      ; =0x9218
Lloh632:
	adrp	x9, l_.str.175@PAGE
Lloh633:
	add	x9, x9, l_.str.175@PAGEOFF
	b	LBB187_40
LBB187_45:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #1761]
	mov	x0, x23
	b	LBB187_43
	.loh AdrpAdd	Lloh628, Lloh629
	.loh AdrpAdd	Lloh630, Lloh631
	.loh AdrpAdd	Lloh632, Lloh633
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function join
lCPI188_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_join:                                  ; @join
	.cfi_startproc
; %bb.0:
	mov	w8, #34824                      ; =0x8808
	add	x8, x0, x8
	mov	w9, #120                        ; =0x78
	mov	w12, w4
	ldr	x10, [x8]
	cbz	x10, LBB188_2
; %bb.1:
	ldr	w10, [x8, #2768]
LBB188_2:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	umaddl	x9, w1, w9, x0
	ldr	x13, [x8, #2776]
	cbz	x13, LBB188_9
; %bb.3:
	ldrb	w11, [x8, #2808]
	tbnz	w11, #0, LBB188_7
; %bb.4:
	ldrb	w11, [x8, #2809]
	tbnz	w11, #0, LBB188_7
; %bb.5:
	ldrh	w11, [x9, #74]
	add	x11, x12, x11
	add	x10, x11, x10
	add	x10, x10, #1
	ldr	x11, [x8, #2800]
	mov	w14, #16777216                  ; =0x1000000
	sub	x15, x14, x11
	cmp	x11, x14
	ccmp	x10, x15, #2, ls
	b.ls	LBB188_8
; %bb.6:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #2808]
LBB188_7:
Lloh634:
	adrp	x9, lCPI188_0@PAGE
Lloh635:
	ldr	d0, [x9, lCPI188_0@PAGEOFF]
	add	x9, x8, #2564
	str	d0, [x9]
	str	wzr, [x8, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh636:
	adrp	x9, l_.str.101@PAGE
Lloh637:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh638:
	adrp	x2, l_.str.52@PAGE
Lloh639:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	b	LBB188_15
LBB188_8:
	add	x10, x11, x10
	str	x10, [x8, #2800]
LBB188_9:
	ldur	w10, [x9, #16]
	cmp	w2, w10
	b.hi	LBB188_11
; %bb.10:
	ldurh	w10, [x9, #72]
	cmp	w12, w10
	b.ls	LBB188_17
LBB188_11:
	mov	w9, #2                          ; =0x2
	cbz	x13, LBB188_13
; %bb.12:
	ldrb	w10, [x8, #2808]
	cmp	w10, #0
	cinc	w9, w9, ne
LBB188_13:
	str	w9, [x8, #2564]
	str	w1, [x8, #2568]
	mov	w9, #37400                      ; =0x9218
	str	w2, [x8, #2572]
Lloh640:
	adrp	x8, l_.str.108@PAGE
Lloh641:
	add	x8, x8, l_.str.108@PAGEOFF
LBB188_14:
	mov	w10, #191                       ; =0xbf
	stp	x10, x8, [sp]
Lloh642:
	adrp	x2, l_.str.52@PAGE
Lloh643:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x9
LBB188_15:
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB188_16:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB188_17:
	ldur	x14, [x9, #104]
	mov	w10, w2
	ldrb	w15, [x14, x10]
	cmp	w15, #0
	cset	w11, eq
	cbz	w15, LBB188_19
; %bb.18:
	ldur	x15, [x9, #64]
	ldrh	w15, [x15, x10, lsl #1]
	cmp	w15, w12
	b.ne	LBB188_46
LBB188_19:
	mov	w13, #1                         ; =0x1
	strb	w13, [x14, x10]
	ldur	x13, [x9, #64]
	strh	w12, [x13, x10, lsl #1]
	ldur	x12, [x9, #40]
	ldur	w13, [x9, #100]
	ldurh	w14, [x9, #74]
	ldr	x15, [x8]
	adds	w16, w14, w4
	b.eq	LBB188_32
; %bb.20:
	umull	x17, w13, w10
	add	x17, x12, x17, lsl #4
	add	x17, x17, #8
	add	x0, x3, #8
	b	LBB188_24
LBB188_21:                              ;   in Loop: Header=BB188_24 Depth=1
	strh	w21, [x17, #4]
	strb	w20, [x17, #3]
	mov	x22, x20
	mov	x23, x21
LBB188_22:                              ;   in Loop: Header=BB188_24 Depth=1
	and	w5, w5, #0xffff
	ldur	x20, [x17, #-8]
	ldrb	w21, [x17, #2]
	and	w24, w21, #0xff
	orr	w5, w19, w5
	strh	w5, [x17]
	orr	x4, x20, x4
	stur	x4, [x17, #-8]
	orr	w1, w21, w1
	and	w21, w1, #0xff
	strb	w1, [x17, #2]
	cmp	w19, w5
	ccmp	x20, x4, #0, eq
	ccmp	w24, w21, #0, eq
	ccmp	w7, w23, #0, eq
	ccmp	w6, w22, #0, eq
LBB188_23:                              ;   in Loop: Header=BB188_24 Depth=1
	cset	w1, ne
	add	x0, x0, #16
	orr	w11, w11, w1
	add	x17, x17, #16
	subs	x16, x16, #1
	b.eq	LBB188_32
LBB188_24:                              ; =>This Inner Loop Header: Depth=1
	ldp	x4, x5, [x0, #-8]
	lsr	x1, x5, #16
	cbz	x15, LBB188_31
; %bb.25:                               ;   in Loop: Header=BB188_24 Depth=1
	lsr	w20, w5, #24
	ubfx	x21, x5, #32, #16
	ldrb	w6, [x17, #3]
	ldrh	w7, [x17, #4]
	ldrh	w19, [x17]
	cbnz	w19, LBB188_28
; %bb.26:                               ;   in Loop: Header=BB188_24 Depth=1
	ldur	x22, [x17, #-8]
	cbnz	x22, LBB188_28
; %bb.27:                               ;   in Loop: Header=BB188_24 Depth=1
	ldrb	w22, [x17, #2]
	cbz	w22, LBB188_21
LBB188_28:                              ;   in Loop: Header=BB188_24 Depth=1
	and	x22, x5, #0xffff
	and	x23, x5, #0xff0000
	cmp	x22, #0
	ccmp	x4, #0, #0, eq
	ccmp	x23, #0, #0, eq
	mov	x22, x6
	mov	x23, x7
	b.eq	LBB188_22
; %bb.29:                               ;   in Loop: Header=BB188_24 Depth=1
	cmp	w7, w21
	ccmp	w6, w20, #0, eq
	mov	x22, x20
	mov	x23, x21
	b.eq	LBB188_22
; %bb.30:                               ;   in Loop: Header=BB188_24 Depth=1
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	b	LBB188_21
LBB188_31:                              ;   in Loop: Header=BB188_24 Depth=1
	ldur	x6, [x17, #-8]
	ldrh	w7, [x17]
	ldrb	w19, [x17, #2]
	and	w20, w19, #0xff
	orr	w5, w7, w5
	strh	w5, [x17]
	orr	x4, x6, x4
	stur	x4, [x17, #-8]
	orr	w1, w19, w1
	and	w19, w1, #0xff
	strb	w1, [x17, #2]
	cmp	w7, w5, uxth
	ccmp	x6, x4, #0, eq
	ccmp	w20, w19, #0, eq
	b	LBB188_23
LBB188_32:
	cbz	x15, LBB188_43
; %bb.33:
	ldr	w16, [x8, #2768]
	cbz	w16, LBB188_43
; %bb.34:
	mov	x15, #0                         ; =0x0
	ldurh	w17, [x9, #72]
	lsl	x0, x14, #4
	lsl	x17, x17, #4
	add	x14, x3, x0
	add	x14, x14, x17
	umull	x13, w13, w10
	add	x13, x0, x13, lsl #4
	add	x12, x12, x17
	add	x12, x12, x13
	lsl	x13, x16, #4
	b	LBB188_37
LBB188_35:                              ;   in Loop: Header=BB188_37 Depth=1
	strh	w6, [x4, #12]
	strb	w5, [x4, #11]
	mov	x7, x5
	mov	x19, x6
LBB188_36:                              ;   in Loop: Header=BB188_37 Depth=1
	and	w5, w17, #0xffff
	add	x6, x12, x15
	ldr	x20, [x6]
	ldrb	w21, [x6, #10]
	and	w22, w21, #0xff
	orr	w5, w3, w5
	strh	w5, [x4, #8]
	orr	x0, x20, x0
	str	x0, [x6]
	lsr	x17, x17, #16
	orr	w17, w21, w17
	and	w4, w17, #0xff
	strb	w17, [x6, #10]
	cmp	w3, w5
	ccmp	x20, x0, #0, eq
	ccmp	w22, w4, #0, eq
	ccmp	w1, w19, #0, eq
	ccmp	w16, w7, #0, eq
	cset	w16, ne
	orr	w11, w11, w16
	add	x15, x15, #16
	cmp	x13, x15
	b.eq	LBB188_43
LBB188_37:                              ; =>This Inner Loop Header: Depth=1
	add	x16, x14, x15
	ldp	x0, x17, [x16]
	lsr	w5, w17, #24
	ubfx	x6, x17, #32, #16
	add	x4, x12, x15
	ldrb	w16, [x4, #11]
	ldrh	w1, [x4, #12]
	ldrh	w3, [x4, #8]
	cbnz	w3, LBB188_40
; %bb.38:                               ;   in Loop: Header=BB188_37 Depth=1
	ldr	x7, [x12, x15]
	cbnz	x7, LBB188_40
; %bb.39:                               ;   in Loop: Header=BB188_37 Depth=1
	add	x7, x12, x15
	ldrb	w7, [x7, #10]
	cbz	w7, LBB188_35
LBB188_40:                              ;   in Loop: Header=BB188_37 Depth=1
	and	x7, x17, #0xffff
	and	x19, x17, #0xff0000
	cmp	x7, #0
	ccmp	x0, #0, #0, eq
	ccmp	x19, #0, #0, eq
	mov	x7, x16
	mov	x19, x1
	b.eq	LBB188_36
; %bb.41:                               ;   in Loop: Header=BB188_37 Depth=1
	cmp	w1, w6
	ccmp	w16, w5, #0, eq
	mov	x7, x5
	mov	x19, x6
	b.eq	LBB188_36
; %bb.42:                               ;   in Loop: Header=BB188_37 Depth=1
	mov	w6, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	LBB188_35
LBB188_43:
	mov	w0, #1                          ; =0x1
	cbz	w11, LBB188_16
; %bb.44:
	str	w0, [x8, #2772]
	ldur	x8, [x9, #112]
	ldrb	w11, [x8, x10]
	cbnz	w11, LBB188_16
; %bb.45:
	ldur	w11, [x9, #16]
	ldur	x12, [x9, #80]
	ldur	w13, [x9, #92]
	str	w2, [x12, x13, lsl #2]
	add	w11, w11, #1
	ldur	w12, [x9, #92]
	add	w12, w12, #1
	udiv	w13, w12, w11
	msub	w11, w13, w11, w12
	stur	w11, [x9, #92]
	strb	w0, [x8, x10]
	ldur	w8, [x9, #96]
	add	w8, w8, #1
	stur	w8, [x9, #96]
	b	LBB188_16
LBB188_46:
	mov	w9, #2                          ; =0x2
	cbz	x13, LBB188_48
; %bb.47:
	ldrb	w10, [x8, #2808]
	cmp	w10, #0
	cinc	w9, w9, ne
LBB188_48:
	str	w9, [x8, #2564]
	str	w1, [x8, #2568]
	mov	w9, #37400                      ; =0x9218
	str	w2, [x8, #2572]
Lloh644:
	adrp	x8, l_.str.109@PAGE
Lloh645:
	add	x8, x8, l_.str.109@PAGEOFF
	b	LBB188_14
	.loh AdrpAdd	Lloh638, Lloh639
	.loh AdrpAdd	Lloh636, Lloh637
	.loh AdrpLdr	Lloh634, Lloh635
	.loh AdrpAdd	Lloh640, Lloh641
	.loh AdrpAdd	Lloh642, Lloh643
	.loh AdrpAdd	Lloh644, Lloh645
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function global_return
lCPI189_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_global_return:                         ; @global_return
	.cfi_startproc
; %bb.0:
	mov	w8, #34824                      ; =0x8808
	add	x8, x0, x8
	ldr	x10, [x8]
	cbz	x10, LBB189_7
; %bb.1:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	w9, [x8, #2768]
	ldr	x11, [x8, #2776]
	cbz	x11, LBB189_9
; %bb.2:
	ldrb	w11, [x8, #2808]
	tbnz	w11, #0, LBB189_6
; %bb.3:
	ldrb	w11, [x8, #2809]
	tbnz	w11, #0, LBB189_6
; %bb.4:
	add	w11, w9, #1
	ldr	x12, [x8, #2800]
	mov	w13, #16777216                  ; =0x1000000
	sub	x14, x13, x12
	cmp	x12, x13
	ccmp	x14, x11, #0, ls
	b.hs	LBB189_8
; %bb.5:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #2808]
LBB189_6:
Lloh646:
	adrp	x9, lCPI189_0@PAGE
Lloh647:
	ldr	d0, [x9, lCPI189_0@PAGEOFF]
	add	x9, x8, #2564
	str	d0, [x9]
	str	wzr, [x8, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh648:
	adrp	x9, l_.str.101@PAGE
Lloh649:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh650:
	adrp	x2, l_.str.52@PAGE
Lloh651:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	b	LBB189_15
LBB189_7:
	mov	w0, #1                          ; =0x1
	ret
LBB189_8:
	add	x11, x12, x11
	str	x11, [x8, #2800]
LBB189_9:
	mov	w11, #8200                      ; =0x2008
	add	x10, x10, x11
	mov	w13, w1
	ldrb	w11, [x10, x13]
	cbnz	w11, LBB189_11
; %bb.10:
	mov	w9, #1                          ; =0x1
	strb	w9, [x10, x13]
	str	w9, [x8, #2772]
	ldr	w9, [x8, #2768]
LBB189_11:
	cbz	w9, LBB189_14
; %bb.12:
	mov	w10, #120                       ; =0x78
	umaddl	x10, w13, w10, x0
	ldrh	w12, [x10, #74]
	ldrh	w14, [x10, #72]
	ldr	x10, [x8]
	ldr	x15, [x10]
	mov	w10, w9
	ldr	w11, [x8, #2772]
	lsl	x14, x14, #4
	add	x12, x14, x12, lsl #4
	add	x12, x12, x2
	add	x12, x12, #8
	umull	x9, w13, w9
	add	x9, x15, x9, lsl #4
	add	x9, x9, #10
LBB189_13:                              ; =>This Inner Loop Header: Depth=1
	ldp	x13, x14, [x12, #-8]
	ldur	x15, [x9, #-10]
	ldurh	w16, [x9, #-2]
	ldrb	w17, [x9]
	and	w0, w17, #0xff
	orr	w1, w16, w14
	sturh	w1, [x9, #-2]
	orr	x13, x15, x13
	stur	x13, [x9, #-10]
	lsr	x14, x14, #16
	orr	w14, w17, w14
	and	w17, w14, #0xff
	strb	w14, [x9], #16
	cmp	w16, w1, uxth
	ccmp	x15, x13, #0, eq
	ccmp	w0, w17, #0, eq
	cset	w13, ne
	orr	w11, w11, w13
	str	w11, [x8, #2772]
	add	x12, x12, #16
	subs	x10, x10, #1
	b.ne	LBB189_13
LBB189_14:
	mov	w0, #1                          ; =0x1
LBB189_15:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh650, Lloh651
	.loh AdrpAdd	Lloh648, Lloh649
	.loh AdrpLdr	Lloh646, Lloh647
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function uf_value
_uf_value:                              ; @uf_value
	.cfi_startproc
; %bb.0:
	mov	w8, #36608                      ; =0x8f00
	add	x8, x0, x8
	ldr	x9, [x8, #992]
	cbz	x9, LBB190_7
; %bb.1:
	ldrb	w10, [x8, #1024]
	tbnz	w10, #0, LBB190_3
; %bb.2:
	ldrb	w10, [x8, #1025]
	tbz	w10, #0, LBB190_4
LBB190_3:
	mov	w4, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	mov	w10, #3                         ; =0x3
Lloh652:
	adrp	x9, l_.str.101@PAGE
Lloh653:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB190_23
LBB190_4:
	ldr	x10, [x8, #1016]
	mov	w11, #16777152                  ; =0xffffc0
	cmp	x10, x11
	b.lo	LBB190_6
; %bb.5:
	mov	w4, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1024]
Lloh654:
	adrp	x9, l_.str.101@PAGE
Lloh655:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #3                         ; =0x3
	b	LBB190_23
LBB190_6:
	add	x10, x10, #65
	str	x10, [x8, #1016]
LBB190_7:
	tst	x2, #0xff0000
	b.ne	LBB190_12
; %bb.8:
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w3
	cmp	w10, w2, uxth
	b.ne	LBB190_12
; %bb.9:
	mov	w10, #13                        ; =0xd
	and	w10, w3, w10
	cmp	w10, #8
	b.ne	LBB190_24
; %bb.10:
	cmp	w3, #8
	mov	w10, #3                         ; =0x3
	csinc	w10, w10, wzr, ne
	ldr	w11, [x8]
	cbz	w11, LBB190_30
; %bb.11:
	mov	x13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w14, #35904                     ; =0x8c40
	add	x14, x0, x14
	mov	w15, #35968                     ; =0x8c80
	add	x15, x0, x15
	mov	w16, #1                         ; =0x1
	b	LBB190_16
LBB190_12:
	cbz	x9, LBB190_21
; %bb.13:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh656:
	adrp	x9, l_.str.116@PAGE
Lloh657:
	add	x9, x9, l_.str.116@PAGEOFF
	b	LBB190_23
LBB190_14:                              ;   in Loop: Header=BB190_16 Depth=1
	orr	x12, x17, x12
LBB190_15:                              ;   in Loop: Header=BB190_16 Depth=1
	add	x13, x13, #1
	cmp	x11, x13
	b.eq	LBB190_27
LBB190_16:                              ; =>This Inner Loop Header: Depth=1
	lsl	x17, x16, x13
	tst	x17, x1
	b.eq	LBB190_15
; %bb.17:                               ;   in Loop: Header=BB190_16 Depth=1
	ldrb	w2, [x14, x13]
	cmp	w10, w2
	b.ne	LBB190_19
; %bb.18:                               ;   in Loop: Header=BB190_16 Depth=1
	ldr	w2, [x15, x13, lsl #2]
	cbz	w2, LBB190_14
LBB190_19:
	cbz	x9, LBB190_34
; %bb.20:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh658:
	adrp	x9, l_.str.118@PAGE
Lloh659:
	add	x9, x9, l_.str.118@PAGEOFF
	b	LBB190_23
LBB190_21:
Lloh660:
	adrp	x9, l_.str.116@PAGE
Lloh661:
	add	x9, x9, l_.str.116@PAGEOFF
LBB190_22:
	mov	w10, #1                         ; =0x1
LBB190_23:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	w10, [x8, #780]
	str	w4, [x8, #784]
	mov	w10, #37400                     ; =0x9218
	str	w5, [x8, #788]
	mov	w8, #191                        ; =0xbf
	stp	x8, x9, [sp]
Lloh662:
	adrp	x2, l_.str.52@PAGE
Lloh663:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x10
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB190_24:
	cbz	x1, LBB190_29
; %bb.25:
	cbz	x9, LBB190_32
; %bb.26:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh664:
	adrp	x9, l_.str.117@PAGE
Lloh665:
	add	x9, x9, l_.str.117@PAGEOFF
	b	LBB190_23
LBB190_27:
	cbz	x12, LBB190_30
; %bb.28:
	cmp	x12, x1
	b.ne	LBB190_30
LBB190_29:
	mov	w0, #1                          ; =0x1
	ret
LBB190_30:
	cbz	x9, LBB190_33
; %bb.31:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh666:
	adrp	x9, l_.str.119@PAGE
Lloh667:
	add	x9, x9, l_.str.119@PAGEOFF
	b	LBB190_23
LBB190_32:
Lloh668:
	adrp	x9, l_.str.117@PAGE
Lloh669:
	add	x9, x9, l_.str.117@PAGEOFF
	b	LBB190_22
LBB190_33:
Lloh670:
	adrp	x9, l_.str.119@PAGE
Lloh671:
	add	x9, x9, l_.str.119@PAGEOFF
	b	LBB190_22
LBB190_34:
Lloh672:
	adrp	x9, l_.str.118@PAGE
Lloh673:
	add	x9, x9, l_.str.118@PAGEOFF
	b	LBB190_22
	.loh AdrpAdd	Lloh652, Lloh653
	.loh AdrpAdd	Lloh654, Lloh655
	.loh AdrpAdd	Lloh656, Lloh657
	.loh AdrpAdd	Lloh658, Lloh659
	.loh AdrpAdd	Lloh660, Lloh661
	.loh AdrpAdd	Lloh662, Lloh663
	.loh AdrpAdd	Lloh664, Lloh665
	.loh AdrpAdd	Lloh666, Lloh667
	.loh AdrpAdd	Lloh668, Lloh669
	.loh AdrpAdd	Lloh670, Lloh671
	.loh AdrpAdd	Lloh672, Lloh673
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function uf_access
lCPI191_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_uf_access:                             ; @uf_access
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldp	w20, w27, [x29, #20]
	ldr	w21, [x29, #16]
	mov	w8, #36608                      ; =0x8f00
	add	x26, x0, x8
	tst	x3, #0xff0000
	b.ne	LBB191_8
; %bb.1:
	and	x8, x3, #0xffff
	cbz	x8, LBB191_8
; %bb.2:
	cbz	x2, LBB191_8
; %bb.3:
	mov	x22, x4
	mov	x23, x5
	ldr	x28, [x29, #32]
	cmp	x8, #256
	b.ne	LBB191_11
; %bb.4:
	mov	x25, x6
	mov	x24, x7
	mov	x0, x19
	stp	x2, x3, [sp, #16]               ; 16-byte Folded Spill
	mov	x1, x2
	mov	x2, x3
	mov	w3, #8                          ; =0x8
	mov	x4, x21
	mov	x5, x20
	bl	_uf_value
	cbz	w0, LBB191_65
; %bb.5:
	cbz	w22, LBB191_17
; %bb.6:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_28
; %bb.7:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_29
LBB191_8:
	cbz	w27, LBB191_61
; %bb.9:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_15
; %bb.10:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_16
LBB191_11:
	mov	x24, x1
	mov	x0, x19
	mov	x25, x2
	mov	x1, x2
	mov	x2, x3
	mov	w3, #10                         ; =0xa
	mov	x4, x21
	mov	x5, x20
	bl	_uf_value
	cbz	w0, LBB191_65
; %bb.12:
	cbz	w23, LBB191_25
; %bb.13:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_30
; %bb.14:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_31
LBB191_15:
	mov	w8, #1                          ; =0x1
LBB191_16:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh674:
	adrp	x9, l_.str.120@PAGE
Lloh675:
	add	x9, x9, l_.str.120@PAGEOFF
	b	LBB191_64
LBB191_17:
	cbz	w23, LBB191_32
; %bb.18:
	mov	x2, x24
	tst	x24, #0xff0000
	b.ne	LBB191_44
; %bb.19:
	and	x8, x2, #0xffff
	cbz	x8, LBB191_44
; %bb.20:
	mov	x1, x25
	cbz	x25, LBB191_44
; %bb.21:
	mov	x0, x19
	mov	w3, #10                         ; =0xa
	mov	x4, x21
	mov	x5, x20
	bl	_uf_value
	cbz	w0, LBB191_65
; %bb.22:
	cbnz	w27, LBB191_24
; %bb.23:
	mov	x0, x19
	ldp	x1, x2, [sp, #16]               ; 16-byte Folded Reload
	mov	w3, #0                          ; =0x0
	mov	x4, x25
	mov	x5, x24
	bl	_write_record
LBB191_24:
	ldp	x9, x8, [sp, #16]               ; 16-byte Folded Reload
	stp	x9, x8, [x28]
	b	LBB191_37
LBB191_25:
	ldr	x9, [x26, #992]
	cbz	w22, LBB191_38
; %bb.26:
	cbz	x9, LBB191_47
; %bb.27:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_48
LBB191_28:
	mov	w8, #1                          ; =0x1
LBB191_29:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh676:
	adrp	x9, l_.str.121@PAGE
Lloh677:
	add	x9, x9, l_.str.121@PAGEOFF
	b	LBB191_64
LBB191_30:
	mov	w8, #1                          ; =0x1
LBB191_31:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh678:
	adrp	x9, l_.str.123@PAGE
Lloh679:
	add	x9, x9, l_.str.123@PAGEOFF
	b	LBB191_64
LBB191_32:
	mov	x0, x19
	ldp	x1, x2, [sp, #16]               ; 16-byte Folded Reload
	mov	w3, #0                          ; =0x0
	bl	_read_record
	stp	x0, x1, [x28]
	ubfx	w10, w1, #16, #8
	and	w9, w1, #0xffff
LBB191_33:
	cbnz	w10, LBB191_58
; %bb.34:
	cbz	w9, LBB191_58
; %bb.35:
	cmp	w9, #1024
	b.ne	LBB191_37
; %bb.36:
	cbz	x0, LBB191_58
LBB191_37:
	ldrb	w8, [x26, #1024]
	eor	w0, w8, #0x1
	b	LBB191_65
LBB191_38:
	mov	x8, x25
	mov	x14, x24
	cbz	x9, LBB191_52
; %bb.39:
	ldrb	w9, [x26, #1024]
	tbnz	w9, #0, LBB191_43
; %bb.40:
	ldrb	w9, [x26, #1025]
	tbnz	w9, #0, LBB191_43
; %bb.41:
	ldr	x9, [x26, #1016]
	mov	w10, #65473                     ; =0xffc1
	movk	w10, #255, lsl #16
	cmp	x9, x10
	b.lo	LBB191_51
; %bb.42:
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, #1024]
LBB191_43:
Lloh680:
	adrp	x8, lCPI191_0@PAGE
Lloh681:
	ldr	d0, [x8, lCPI191_0@PAGEOFF]
	add	x8, x26, #780
	str	d0, [x8]
	str	wzr, [x26, #788]
	mov	w8, #37400                      ; =0x9218
Lloh682:
	adrp	x9, l_.str.101@PAGE
Lloh683:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB191_64
LBB191_44:
	cbz	w27, LBB191_61
; %bb.45:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_49
; %bb.46:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_50
LBB191_47:
	mov	w8, #1                          ; =0x1
LBB191_48:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh684:
	adrp	x9, l_.str.124@PAGE
Lloh685:
	add	x9, x9, l_.str.124@PAGEOFF
	b	LBB191_64
LBB191_49:
	mov	w8, #1                          ; =0x1
LBB191_50:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh686:
	adrp	x9, l_.str.122@PAGE
Lloh687:
	add	x9, x9, l_.str.122@PAGEOFF
	b	LBB191_64
LBB191_51:
	add	x9, x9, #64
	str	x9, [x26, #1016]
LBB191_52:
	stp	xzr, xzr, [x28]
	ldr	w11, [x26]
	cbz	w11, LBB191_58
; %bb.53:
	mov	w10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x0, #0                          ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w13, #36480                     ; =0x8e80
	add	x13, x19, x13
	add	x14, x14, #16
	b	LBB191_55
LBB191_54:                              ;   in Loop: Header=BB191_55 Depth=1
	add	x12, x12, #1
	add	x14, x14, #16
	cmp	x11, x12
	b.eq	LBB191_33
LBB191_55:                              ; =>This Inner Loop Header: Depth=1
	lsr	x15, x8, x12
	tbz	w15, #0, LBB191_54
; %bb.56:                               ;   in Loop: Header=BB191_55 Depth=1
	ldrh	w15, [x13, x12, lsl #1]
	cmp	w15, #1
	b.ne	LBB191_66
; %bb.57:                               ;   in Loop: Header=BB191_55 Depth=1
	ldur	x15, [x14, #-8]
	ldr	w16, [x14]
	and	w17, w16, #0xffff
	orr	w9, w9, w17
	strh	w9, [x28, #8]
	orr	x0, x0, x15
	str	x0, [x28]
	ubfx	w15, w16, #16, #8
	orr	w10, w10, w15
	strb	w10, [x28, #10]
	b	LBB191_54
LBB191_58:
	cbz	w27, LBB191_61
; %bb.59:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_62
; %bb.60:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_63
LBB191_61:
	mov	w0, #2                          ; =0x2
	b	LBB191_65
LBB191_62:
	mov	w8, #1                          ; =0x1
LBB191_63:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh688:
	adrp	x9, l_.str.126@PAGE
Lloh689:
	add	x9, x9, l_.str.126@PAGEOFF
LBB191_64:
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh690:
	adrp	x2, l_.str.52@PAGE
Lloh691:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x19, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB191_65:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB191_66:
	ldr	x8, [x26, #992]
	cbz	x8, LBB191_68
; %bb.67:
	ldrb	w8, [x26, #1024]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, ne
	b	LBB191_69
LBB191_68:
	mov	w8, #1                          ; =0x1
LBB191_69:
	str	w8, [x26, #780]
	str	w21, [x26, #784]
	mov	w8, #37400                      ; =0x9218
	str	w20, [x26, #788]
Lloh692:
	adrp	x9, l_.str.125@PAGE
Lloh693:
	add	x9, x9, l_.str.125@PAGEOFF
	b	LBB191_64
	.loh AdrpAdd	Lloh674, Lloh675
	.loh AdrpAdd	Lloh676, Lloh677
	.loh AdrpAdd	Lloh678, Lloh679
	.loh AdrpAdd	Lloh682, Lloh683
	.loh AdrpLdr	Lloh680, Lloh681
	.loh AdrpAdd	Lloh684, Lloh685
	.loh AdrpAdd	Lloh686, Lloh687
	.loh AdrpAdd	Lloh688, Lloh689
	.loh AdrpAdd	Lloh690, Lloh691
	.loh AdrpAdd	Lloh692, Lloh693
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function global_invalidates
lCPI192_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_global_invalidates:                    ; @global_invalidates
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x9, x0, #9, lsl #12             ; =36864
	ldr	w8, [x1, #92]
	ldr	x10, [x9, #736]
	cbz	x10, LBB192_7
; %bb.1:
	ldrb	w10, [x9, #768]
	tbnz	w10, #0, LBB192_5
; %bb.2:
	ldrb	w10, [x9, #769]
	tbnz	w10, #0, LBB192_5
; %bb.3:
	ldr	x10, [x9, #760]
	mov	w11, #16777216                  ; =0x1000000
	sub	x12, x11, x10
	cmp	x10, x11
	ccmp	x12, x8, #0, ls
	b.hs	LBB192_6
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #768]
LBB192_5:
Lloh694:
	adrp	x8, lCPI192_0@PAGE
Lloh695:
	ldr	d0, [x8, lCPI192_0@PAGEOFF]
	add	x8, x9, #524
	str	d0, [x8]
	str	wzr, [x9, #532]
	mov	w8, #37400                      ; =0x9218
Lloh696:
	adrp	x9, l_.str.101@PAGE
Lloh697:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh698:
	adrp	x2, l_.str.52@PAGE
Lloh699:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	b	LBB192_13
LBB192_6:
	add	x10, x10, x8
	str	x10, [x9, #760]
LBB192_7:
	cbz	w8, LBB192_12
; %bb.8:
	add	w9, w3, #1
	add	w10, w3, #257
	add	x11, x2, #12
	b	LBB192_10
LBB192_9:                               ;   in Loop: Header=BB192_10 Depth=1
	add	x11, x11, #16
	subs	x8, x8, #1
	b.eq	LBB192_12
LBB192_10:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w12, [x11]
	cmp	w9, w12
	ccmp	w10, w12, #4, ne
	b.ne	LBB192_9
; %bb.11:                               ;   in Loop: Header=BB192_10 Depth=1
	strh	wzr, [x11]
	sturb	wzr, [x11, #-1]
	b	LBB192_9
LBB192_12:
	mov	w0, #1                          ; =0x1
LBB192_13:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh698, Lloh699
	.loh AdrpAdd	Lloh696, Lloh697
	.loh AdrpLdr	Lloh694, Lloh695
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function write_array
lCPI193_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_write_array:                           ; @write_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w8, #35856                      ; =0x8c10
	add	x8, x0, x8
	ldr	x9, [x8, #1744]
	cbz	x9, LBB193_7
; %bb.1:
	ldrb	w10, [x8, #1776]
	tbnz	w10, #0, LBB193_5
; %bb.2:
	ldrb	w10, [x8, #1777]
	tbnz	w10, #0, LBB193_5
; %bb.3:
	ldr	x10, [x8, #1768]
	mov	w11, #65281                     ; =0xff01
	movk	w11, #255, lsl #16
	cmp	x10, x11
	b.lo	LBB193_6
; %bb.4:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1776]
LBB193_5:
Lloh700:
	adrp	x9, lCPI193_0@PAGE
Lloh701:
	ldr	d0, [x9, lCPI193_0@PAGEOFF]
	add	x9, x8, #1532
	str	d0, [x9]
	str	wzr, [x8, #1540]
	mov	w8, #37400                      ; =0x9218
Lloh702:
	adrp	x9, l_.str.101@PAGE
Lloh703:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh704:
	adrp	x2, l_.str.52@PAGE
Lloh705:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB193_17
LBB193_6:
	add	x10, x10, #256
	str	x10, [x8, #1768]
LBB193_7:
	ldr	w10, [x8, #752]
	cbz	w10, LBB193_17
; %bb.8:
	mov	x11, #0                         ; =0x0
	mov	w12, #35904                     ; =0x8c40
	add	x12, x0, x12
	mov	w13, #36620                     ; =0x8f0c
	add	x13, x0, x13
	mov	w14, #38816                     ; =0x97a0
	add	x14, x0, x14
	and	w15, w4, #0xffff
	ubfx	w16, w4, #16, #8
	mov	w17, #34832                     ; =0x8810
	add	x17, x0, x17
	mov	w0, #12                         ; =0xc
	b	LBB193_10
LBB193_9:                               ;   in Loop: Header=BB193_10 Depth=1
	add	x11, x11, #1
	cmp	x11, x10
	b.eq	LBB193_17
LBB193_10:                              ; =>This Inner Loop Header: Depth=1
	lsr	x2, x1, x11
	tbz	w2, #0, LBB193_9
; %bb.11:                               ;   in Loop: Header=BB193_10 Depth=1
	ldrb	w2, [x12, x11]
	cbnz	w2, LBB193_9
; %bb.12:                               ;   in Loop: Header=BB193_10 Depth=1
	cbz	x9, LBB193_14
; %bb.13:                               ;   in Loop: Header=BB193_10 Depth=1
	add	x2, x14, x11, lsl #4
	ldr	x4, [x2]
	ldrh	w5, [x2, #8]
	ldrb	w6, [x2, #10]
	and	w6, w6, #0xff
	orr	w7, w5, w15
	strh	w7, [x2, #8]
	orr	x19, x4, x3
	str	x19, [x2]
	orr	w20, w6, w16
	strb	w20, [x2, #10]
	cmp	w5, w7
	ccmp	x4, x19, #0, eq
	ccmp	w6, w20, #0, eq
	cset	w2, ne
	ldr	w4, [x8, #1740]
	orr	w2, w4, w2
	str	w2, [x8, #1740]
LBB193_14:                              ;   in Loop: Header=BB193_10 Depth=1
	madd	x2, x11, x0, x13
	ldrb	w4, [x2, #11]
	cbnz	w4, LBB193_9
; %bb.15:                               ;   in Loop: Header=BB193_10 Depth=1
	ldrh	w4, [x2, #8]
	orr	w5, w4, w15
	strh	w5, [x2, #8]
	cmp	w4, w5
	cset	w2, ne
	ldr	w4, [x8, #1740]
	orr	w2, w4, w2
	str	w2, [x8, #1740]
	ldr	w4, [x8]
	cbz	w4, LBB193_9
; %bb.16:                               ;   in Loop: Header=BB193_10 Depth=1
	add	x4, x17, x11, lsl #4
	ldr	x5, [x4]
	ldrh	w6, [x4, #8]
	ldrb	w7, [x4, #10]
	and	w7, w7, #0xff
	orr	w19, w6, w15
	strh	w19, [x4, #8]
	orr	x20, x5, x3
	str	x20, [x4]
	orr	w21, w7, w16
	strb	w21, [x4, #10]
	cmp	w6, w19
	ccmp	x5, x20, #0, eq
	ccmp	w7, w21, #0, eq
	cset	w4, ne
	orr	w2, w2, w4
	str	w2, [x8, #1740]
	b	LBB193_9
LBB193_17:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh704, Lloh705
	.loh AdrpAdd	Lloh702, Lloh703
	.loh AdrpLdr	Lloh700, Lloh701
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function slice_origins
lCPI194_0:
	.quad	0                               ; 0x0
	.quad	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_slice_origins:                         ; @slice_origins
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	w8, #35856                      ; =0x8c10
	add	x8, x0, x8
	ldr	x9, [x8, #1744]
	cbz	x9, LBB194_9
; %bb.1:
	ldrb	w9, [x8, #1776]
	tbnz	w9, #0, LBB194_3
; %bb.2:
	ldrb	w9, [x8, #1777]
	tbz	w9, #0, LBB194_6
LBB194_3:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
LBB194_4:
Lloh706:
	adrp	x9, l_.str.101@PAGE
Lloh707:
	add	x9, x9, l_.str.101@PAGEOFF
LBB194_5:
	mov	w10, #3                         ; =0x3
	str	w10, [x8, #1532]
	str	w1, [x8, #1536]
	str	w2, [x8, #1540]
	mov	w8, #37400                      ; =0x9218
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh708:
	adrp	x2, l_.str.52@PAGE
Lloh709:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	b	LBB194_32
LBB194_6:
	ldr	x9, [x8, #1768]
	mov	w10, #60929                     ; =0xee01
	movk	w10, #255, lsl #16
	cmp	x9, x10
	b.lo	LBB194_8
; %bb.7:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1776]
	b	LBB194_4
LBB194_8:
	mov	w10, #4608                      ; =0x1200
	add	x9, x9, x10
	str	x9, [x8, #1768]
LBB194_9:
Lloh710:
	adrp	x9, lCPI194_0@PAGE
Lloh711:
	ldr	q0, [x9, lCPI194_0@PAGEOFF]
	str	q0, [x5]
	cmp	x3, #0
	cset	w9, eq
	and	w9, w9, w4, lsr #7
	ands	x10, x4, #0xff0000
	mov	w11, #1                         ; =0x1
	csel	w9, w11, w9, ne
	strb	w9, [x5, #10]
	ldr	w9, [x8]
	orr	x10, x10, x3
	and	x11, x4, #0x80
	cmp	w9, #0
	ccmp	x10, #0, #0, ne
	ccmp	x11, #0, #0, eq
	b.ne	LBB194_11
; %bb.10:
	stp	xzr, xzr, [x5]
LBB194_11:
	ldr	w12, [x8, #752]
	cbz	w12, LBB194_31
; %bb.12:
	mov	x10, #0                         ; =0x0
	mov	w9, #35904                      ; =0x8c40
	add	x11, x0, x9
	mov	w9, #36620                      ; =0x8f0c
	add	x13, x0, x9
	mov	w9, #34832                      ; =0x8810
	add	x14, x0, x9
	add	x15, x8, #774
	mov	w16, #12                        ; =0xc
	mov	w17, #1                         ; =0x1
Lloh712:
	adrp	x9, l_.str.127@PAGE
Lloh713:
	add	x9, x9, l_.str.127@PAGEOFF
	b	LBB194_15
LBB194_13:                              ;   in Loop: Header=BB194_15 Depth=1
	lsl	x4, x17, x7
	ldr	x6, [x5]
	orr	x4, x6, x4
	str	x4, [x5]
LBB194_14:                              ;   in Loop: Header=BB194_15 Depth=1
	add	x10, x10, #1
	cmp	x10, w12, uxtw
	b.hs	LBB194_31
LBB194_15:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB194_19 Depth 2
	lsr	x4, x3, x10
	tbz	w4, #0, LBB194_14
; %bb.16:                               ;   in Loop: Header=BB194_15 Depth=1
	ldrb	w4, [x11, x10]
	cbnz	w4, LBB194_14
; %bb.17:                               ;   in Loop: Header=BB194_15 Depth=1
	mov	x20, #0                         ; =0x0
	madd	x6, x10, x16, x13
	ldrh	w4, [x6, #8]
	ldrb	w7, [x6, #10]
	ldrb	w19, [x6, #11]
	cmp	w12, #1
	csinc	w6, w12, wzr, hi
	mov	x21, x15
	b	LBB194_19
LBB194_18:                              ;   in Loop: Header=BB194_19 Depth=2
	add	x20, x20, #1
	add	x21, x21, #12
	cmp	x6, x20
	b.eq	LBB194_24
LBB194_19:                              ;   Parent Loop BB194_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w22, [x11, x20]
	cbnz	w22, LBB194_18
; %bb.20:                               ;   in Loop: Header=BB194_19 Depth=2
	ldur	w22, [x21, #-10]
	cmp	w22, w1
	b.ne	LBB194_18
; %bb.21:                               ;   in Loop: Header=BB194_19 Depth=2
	ldur	w22, [x21, #-6]
	cmp	w22, w2
	b.ne	LBB194_18
; %bb.22:                               ;   in Loop: Header=BB194_19 Depth=2
	ldrb	w22, [x21]
	cmp	w22, w7
	b.ne	LBB194_18
; %bb.23:                               ;   in Loop: Header=BB194_15 Depth=1
	mov	x6, x20
LBB194_24:                              ;   in Loop: Header=BB194_15 Depth=1
	cmp	w6, w12
	b.ne	LBB194_27
; %bb.25:                               ;   in Loop: Header=BB194_15 Depth=1
	cmp	w12, #64
	b.eq	LBB194_5
; %bb.26:                               ;   in Loop: Header=BB194_15 Depth=1
	umaddl	x20, w12, w16, x13
	add	w12, w12, #1
	str	w12, [x8, #752]
	stp	w1, w2, [x20]
	strh	wzr, [x20, #8]
	strb	w7, [x20, #10]
	strb	w19, [x20, #11]
	mov	w19, #1                         ; =0x1
	b	LBB194_28
LBB194_27:                              ;   in Loop: Header=BB194_15 Depth=1
	ldr	w19, [x8, #1740]
LBB194_28:                              ;   in Loop: Header=BB194_15 Depth=1
	mov	w7, w6
	umaddl	x6, w6, w16, x13
	ldrh	w20, [x6, #8]
	orr	w4, w20, w4
	strh	w4, [x6, #8]
	cmp	w20, w4
	cset	w4, ne
	orr	w4, w19, w4
	str	w4, [x8, #1740]
	ldr	w19, [x8]
	cbz	w19, LBB194_13
; %bb.29:                               ;   in Loop: Header=BB194_15 Depth=1
	ldrb	w6, [x6, #11]
	cbnz	w6, LBB194_13
; %bb.30:                               ;   in Loop: Header=BB194_15 Depth=1
	add	x6, x14, x7, lsl #4
	add	x19, x14, x10, lsl #4
	ldp	x20, x19, [x19]
	ldr	x21, [x6]
	ldrh	w22, [x6, #8]
	ldrb	w23, [x6, #10]
	and	w24, w23, #0xff
	orr	w25, w22, w19
	strh	w25, [x6, #8]
	orr	x20, x21, x20
	str	x20, [x6]
	lsr	x19, x19, #16
	orr	w19, w23, w19
	and	w23, w19, #0xff
	strb	w19, [x6, #10]
	cmp	w22, w25, uxth
	ccmp	x21, x20, #0, eq
	ccmp	w24, w23, #0, eq
	cset	w6, ne
	orr	w4, w4, w6
	str	w4, [x8, #1740]
	b	LBB194_13
LBB194_31:
	mov	w0, #1                          ; =0x1
LBB194_32:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh706, Lloh707
	.loh AdrpAdd	Lloh708, Lloh709
	.loh AdrpLdr	Lloh710, Lloh711
	.loh AdrpAdd	Lloh712, Lloh713
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function read_array
lCPI195_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_read_array:                            ; @read_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #34840                      ; =0x8818
	add	x9, x0, x8
	ldr	x8, [x9, #2760]
	cbz	x8, LBB195_7
; %bb.1:
	ldrb	w8, [x9, #2792]
	tbnz	w8, #0, LBB195_5
; %bb.2:
	ldrb	w8, [x9, #2793]
	tbnz	w8, #0, LBB195_5
; %bb.3:
	ldr	x8, [x9, #2784]
	mov	w10, #65281                     ; =0xff01
	movk	w10, #255, lsl #16
	cmp	x8, x10
	b.lo	LBB195_6
; %bb.4:
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2792]
LBB195_5:
Lloh714:
	adrp	x8, lCPI195_0@PAGE
Lloh715:
	ldr	d0, [x8, lCPI195_0@PAGEOFF]
	add	x8, x9, #2548
	str	d0, [x8]
	str	wzr, [x9, #2556]
	mov	w8, #37400                      ; =0x9218
Lloh716:
	adrp	x9, l_.str.101@PAGE
Lloh717:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh718:
	adrp	x2, l_.str.52@PAGE
Lloh719:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w10, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	b	LBB195_18
LBB195_6:
	add	x8, x8, #256
	str	x8, [x9, #2784]
LBB195_7:
	cmp	x1, #0
	cset	w8, eq
	and	w8, w8, w2, lsr #7
	tst	x2, #0xff0000
	mov	w10, #1                         ; =0x1
	csel	w10, w10, w8, ne
	ldr	w11, [x9, #1768]
	mov	w8, #1                          ; =0x1
	cbz	w11, LBB195_17
; %bb.8:
	mov	x12, #0                         ; =0x0
	mov	x13, x0
	mov	x0, #0                          ; =0x0
	mov	w14, #35904                     ; =0x8c40
	add	x13, x13, x14
	add	x14, x9, #1791
	mov	x15, x9
	mov	w16, #1                         ; =0x1
	b	LBB195_11
LBB195_9:                               ;   in Loop: Header=BB195_11 Depth=1
	ldurb	w17, [x14, #-1]
	lsl	w17, w8, w17
	orr	w16, w16, w17
LBB195_10:                              ;   in Loop: Header=BB195_11 Depth=1
	add	x12, x12, #1
	add	x14, x14, #12
	add	x15, x15, #16
	cmp	x11, x12
	b.eq	LBB195_16
LBB195_11:                              ; =>This Inner Loop Header: Depth=1
	lsr	x17, x1, x12
	tbz	w17, #0, LBB195_10
; %bb.12:                               ;   in Loop: Header=BB195_11 Depth=1
	ldrb	w17, [x13, x12]
	cbnz	w17, LBB195_10
; %bb.13:                               ;   in Loop: Header=BB195_11 Depth=1
	ldrb	w17, [x14]
	cbnz	w17, LBB195_9
; %bb.14:                               ;   in Loop: Header=BB195_11 Depth=1
	ldurh	w17, [x14, #-3]
	orr	w16, w17, w16
	ldr	w17, [x9, #1016]
	cbz	w17, LBB195_10
; %bb.15:                               ;   in Loop: Header=BB195_11 Depth=1
	ldp	x17, x2, [x15, #-8]
	orr	w16, w16, w2
	orr	x0, x17, x0
	lsr	x17, x2, #16
	orr	w10, w10, w17
	b	LBB195_10
LBB195_16:
	and	x8, x16, #0xffff
	b	LBB195_18
LBB195_17:
	mov	x0, #0                          ; =0x0
LBB195_18:
	bfi	x8, x10, #16, #8
	mov	x1, x8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh718, Lloh719
	.loh AdrpAdd	Lloh716, Lloh717
	.loh AdrpLdr	Lloh714, Lloh715
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function write_record
lCPI196_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_write_record:                          ; @write_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #35880                      ; =0x8c28
	add	x8, x0, x8
	ldr	x9, [x8, #1720]
	cbz	x9, LBB196_7
; %bb.1:
	ldrb	w9, [x8, #1752]
	tbnz	w9, #0, LBB196_5
; %bb.2:
	ldrb	w9, [x8, #1753]
	tbnz	w9, #0, LBB196_5
; %bb.3:
	ldr	x9, [x8, #1744]
	mov	w10, #65281                     ; =0xff01
	movk	w10, #255, lsl #16
	cmp	x9, x10
	b.lo	LBB196_6
; %bb.4:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1752]
LBB196_5:
Lloh720:
	adrp	x9, lCPI196_0@PAGE
Lloh721:
	ldr	d0, [x9, lCPI196_0@PAGEOFF]
	add	x9, x8, #1508
	str	d0, [x9]
	str	wzr, [x8, #1516]
	mov	w8, #37400                      ; =0x9218
Lloh722:
	adrp	x9, l_.str.101@PAGE
Lloh723:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh724:
	adrp	x2, l_.str.52@PAGE
Lloh725:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	b	LBB196_17
LBB196_6:
	add	x9, x9, #256
	str	x9, [x8, #1744]
LBB196_7:
	ldr	w9, [x8, #728]
	cbz	w9, LBB196_17
; %bb.8:
	mov	x11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w12, #35904                     ; =0x8c40
	add	x12, x0, x12
	mov	w13, #1                         ; =0x1
	b	LBB196_10
LBB196_9:                               ;   in Loop: Header=BB196_10 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB196_12
LBB196_10:                              ; =>This Inner Loop Header: Depth=1
	lsl	x14, x13, x11
	tst	x14, x1
	b.eq	LBB196_9
; %bb.11:                               ;   in Loop: Header=BB196_10 Depth=1
	ldrb	w15, [x12, x11]
	cmp	w15, #1
	csel	x14, x14, xzr, eq
	orr	x10, x14, x10
	b	LBB196_9
LBB196_12:
	mov	x11, #0                         ; =0x0
	mov	w12, #36480                     ; =0x8e80
	add	x12, x0, x12
	mov	w13, #36224                     ; =0x8d80
	add	x13, x0, x13
	and	w14, w5, #0xffff
	ubfx	w15, w5, #16, #8
	b	LBB196_14
LBB196_13:                              ;   in Loop: Header=BB196_14 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB196_17
LBB196_14:                              ; =>This Inner Loop Header: Depth=1
	lsr	x16, x10, x11
	tbz	w16, #0, LBB196_13
; %bb.15:                               ;   in Loop: Header=BB196_14 Depth=1
	ldrh	w16, [x12, x11, lsl #1]
	cmp	w3, w16
	b.hs	LBB196_13
; %bb.16:                               ;   in Loop: Header=BB196_14 Depth=1
	ldr	x16, [x8]
	ldr	w17, [x13, x11, lsl #2]
	add	w17, w17, w3
	add	x16, x16, w17, uxtw #4
	ldr	x17, [x16]
	ldrh	w0, [x16, #8]
	ldrb	w1, [x16, #10]
	and	w1, w1, #0xff
	orr	w2, w0, w14
	strh	w2, [x16, #8]
	orr	x5, x17, x4
	str	x5, [x16]
	orr	w6, w1, w15
	strb	w6, [x16, #10]
	cmp	w0, w2
	ccmp	x17, x5, #0, eq
	ccmp	w1, w6, #0, eq
	cset	w16, ne
	ldr	w17, [x8, #1716]
	orr	w16, w17, w16
	str	w16, [x8, #1716]
	b	LBB196_13
LBB196_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh724, Lloh725
	.loh AdrpAdd	Lloh722, Lloh723
	.loh AdrpLdr	Lloh720, Lloh721
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function read_record
lCPI197_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_read_record:                           ; @read_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #35880                      ; =0x8c28
	add	x8, x0, x8
	ldr	x9, [x8, #1720]
	cbz	x9, LBB197_7
; %bb.1:
	ldrb	w9, [x8, #1752]
	tbnz	w9, #0, LBB197_5
; %bb.2:
	ldrb	w9, [x8, #1753]
	tbnz	w9, #0, LBB197_5
; %bb.3:
	ldr	x9, [x8, #1744]
	mov	w10, #65281                     ; =0xff01
	movk	w10, #255, lsl #16
	cmp	x9, x10
	b.lo	LBB197_6
; %bb.4:
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1752]
LBB197_5:
Lloh726:
	adrp	x9, lCPI197_0@PAGE
Lloh727:
	ldr	d0, [x9, lCPI197_0@PAGEOFF]
	add	x9, x8, #1508
	str	d0, [x9]
	str	wzr, [x8, #1516]
	mov	w8, #37400                      ; =0x9218
Lloh728:
	adrp	x9, l_.str.101@PAGE
Lloh729:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh730:
	adrp	x2, l_.str.52@PAGE
Lloh731:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	b	LBB197_20
LBB197_6:
	add	x9, x9, #256
	str	x9, [x8, #1744]
LBB197_7:
	ldr	w9, [x8, #728]
	cbz	w9, LBB197_12
; %bb.8:
	mov	x11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w12, #35904                     ; =0x8c40
	add	x12, x0, x12
	mov	w13, #1                         ; =0x1
	b	LBB197_10
LBB197_9:                               ;   in Loop: Header=BB197_10 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB197_13
LBB197_10:                              ; =>This Inner Loop Header: Depth=1
	lsl	x14, x13, x11
	tst	x14, x1
	b.eq	LBB197_9
; %bb.11:                               ;   in Loop: Header=BB197_10 Depth=1
	ldrb	w15, [x12, x11]
	cmp	w15, #1
	csel	x14, x14, xzr, eq
	orr	x10, x14, x10
	b	LBB197_9
LBB197_12:
	mov	x10, #0                         ; =0x0
LBB197_13:
	cmp	x10, #0
	cset	w11, eq
	tst	w11, w2, lsr #8
	mov	w11, #65536                     ; =0x10000
	csel	x11, x11, xzr, ne
	tst	x2, #0xff0000
	mov	w12, #65536                     ; =0x10000
	csel	x1, x12, x11, ne
	cbz	w9, LBB197_19
; %bb.14:
	mov	x11, #0                         ; =0x0
	mov	w12, #36480                     ; =0x8e80
	add	x12, x0, x12
	mov	w13, #36224                     ; =0x8d80
	add	x13, x0, x13
	mov	x0, #0                          ; =0x0
	b	LBB197_16
LBB197_15:                              ;   in Loop: Header=BB197_16 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB197_20
LBB197_16:                              ; =>This Inner Loop Header: Depth=1
	lsr	x14, x10, x11
	tbz	w14, #0, LBB197_15
; %bb.17:                               ;   in Loop: Header=BB197_16 Depth=1
	ldrh	w14, [x12, x11, lsl #1]
	cmp	w3, w14
	b.hs	LBB197_15
; %bb.18:                               ;   in Loop: Header=BB197_16 Depth=1
	ldr	w14, [x13, x11, lsl #2]
	ldr	x15, [x8]
	add	w14, w14, w3
	add	x14, x15, w14, uxtw #4
	ldp	x15, x14, [x14]
	and	x16, x14, #0xffff
	orr	x0, x15, x0
	orr	w14, w14, w1
	and	x14, x14, #0xff0000
	and	x15, x1, #0xffffffffff00ffff
	orr	x15, x16, x15
	orr	x1, x15, x14
	b	LBB197_15
LBB197_19:
	mov	x0, #0                          ; =0x0
LBB197_20:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh730, Lloh731
	.loh AdrpAdd	Lloh728, Lloh729
	.loh AdrpLdr	Lloh726, Lloh727
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function global_refine_context
lCPI198_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_global_refine_context:                 ; @global_refine_context
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #34824                      ; =0x8808
	add	x11, x0, x8
	mov	w8, #1                          ; =0x1
	str	w8, [x6]
	ldr	x9, [x11]
	cbz	x9, LBB198_5
; %bb.1:
	ubfx	x9, x4, #32, #16
	cmp	w9, #257
	b.lo	LBB198_5
; %bb.2:
	ldr	w8, [x11, #2768]
	add	w8, w8, #256
	cmp	w9, w8
	b.hi	LBB198_4
; %bb.3:
	lsr	x8, x4, #32
	ldrh	w9, [x1, #66]
	add	x9, x2, x9, lsl #4
	ldrh	w10, [x1, #64]
	add	x9, x9, x10, lsl #4
	add	x8, x9, w8, uxth #4
	mov	x9, #-4102                      ; =0xffffffffffffeffa
	ldrb	w9, [x8, x9]
	cbz	w9, LBB198_6
LBB198_4:
	mov	w8, #1                          ; =0x1
LBB198_5:
	mov	x0, x8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB198_6:
	ldr	x9, [x11, #2776]
	cbz	x9, LBB198_13
; %bb.7:
	ldrb	w9, [x11, #2808]
	tbnz	w9, #0, LBB198_11
; %bb.8:
	ldrb	w9, [x11, #2809]
	tbnz	w9, #0, LBB198_11
; %bb.9:
	ldr	x9, [x11, #2800]
	mov	w10, #65471                     ; =0xffbf
	movk	w10, #255, lsl #16
	cmp	x9, x10
	b.lo	LBB198_12
; %bb.10:
	mov	w8, #1                          ; =0x1
	strb	w8, [x11, #2808]
LBB198_11:
Lloh732:
	adrp	x8, lCPI198_0@PAGE
Lloh733:
	ldr	d0, [x8, lCPI198_0@PAGEOFF]
	add	x8, x11, #2564
	str	d0, [x8]
	str	wzr, [x11, #2572]
	mov	w8, #37400                      ; =0x9218
Lloh734:
	adrp	x9, l_.str.101@PAGE
Lloh735:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #191                       ; =0xbf
	stp	x10, x9, [sp]
Lloh736:
	adrp	x2, l_.str.52@PAGE
Lloh737:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x8
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w8, #0                          ; =0x0
	b	LBB198_5
LBB198_12:
	add	x9, x9, #66
	str	x9, [x11, #2800]
LBB198_13:
	lsr	w9, w4, #28
	cbz	w9, LBB198_15
; %bb.14:
	cbnz	w5, LBB198_31
	b	LBB198_4
LBB198_15:
	lsr	w9, w4, #24
	mov	w10, #1                         ; =0x1
	mov	x12, #-4104                     ; =0xffffffffffffeff8
	ldrh	w13, [x8, x12]
	lsl	w9, w10, w9
	sub	w10, w5, #1
	eor	w9, w9, w10
	ands	w10, w9, w13
	strh	w10, [x8, x12]
	b.eq	LBB198_31
; %bb.16:
	mov	x9, #-4112                      ; =0xffffffffffffeff0
	ldr	w11, [x11, #1784]
	cbz	w11, LBB198_32
; %bb.17:
	mov	x13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	ldr	x14, [x29, #16]
	ldr	x15, [x8, x9]
	mov	w16, #35904                     ; =0x8c40
	add	x16, x0, x16
	mov	w17, #1                         ; =0x1
	b	LBB198_20
LBB198_18:                              ;   in Loop: Header=BB198_20 Depth=1
	orr	x12, x0, x12
LBB198_19:                              ;   in Loop: Header=BB198_20 Depth=1
	add	x13, x13, #1
	cmp	x11, x13
	b.eq	LBB198_33
LBB198_20:                              ; =>This Inner Loop Header: Depth=1
	lsl	x0, x17, x13
	tst	x15, x0
	b.eq	LBB198_19
; %bb.21:                               ;   in Loop: Header=BB198_20 Depth=1
	ldrb	w1, [x16, x13]
	cmp	w1, #1
	b.eq	LBB198_24
; %bb.22:                               ;   in Loop: Header=BB198_20 Depth=1
	cbnz	w1, LBB198_25
; %bb.23:                               ;   in Loop: Header=BB198_20 Depth=1
	tbnz	w10, #7, LBB198_18
	b	LBB198_19
LBB198_24:                              ;   in Loop: Header=BB198_20 Depth=1
	tbz	w10, #8, LBB198_19
	b	LBB198_18
LBB198_25:                              ;   in Loop: Header=BB198_20 Depth=1
	cbz	x7, LBB198_28
; %bb.26:                               ;   in Loop: Header=BB198_20 Depth=1
	cmp	w1, #2
	b.ne	LBB198_28
; %bb.27:                               ;   in Loop: Header=BB198_20 Depth=1
	tbnz	w10, #13, LBB198_18
	b	LBB198_19
LBB198_28:                              ;   in Loop: Header=BB198_20 Depth=1
	cbz	x14, LBB198_19
; %bb.29:                               ;   in Loop: Header=BB198_20 Depth=1
	cmp	w1, #3
	b.ne	LBB198_19
; %bb.30:                               ;   in Loop: Header=BB198_20 Depth=1
	tbnz	w10, #10, LBB198_18
	b	LBB198_19
LBB198_31:
	str	wzr, [x6]
	b	LBB198_4
LBB198_32:
	mov	x12, #0                         ; =0x0
LBB198_33:
	str	x12, [x8, x9]
	b	LBB198_4
	.loh AdrpAdd	Lloh736, Lloh737
	.loh AdrpAdd	Lloh734, Lloh735
	.loh AdrpLdr	Lloh732, Lloh733
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_value_matches
_record_value_matches:                  ; @record_value_matches
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w8, #35872                      ; =0x8c20
	add	x19, x0, x8
	ldr	x9, [x19, #1728]
	cbz	x9, LBB199_7
; %bb.1:
	ldrb	w8, [x19, #1760]
	tbnz	w8, #0, LBB199_3
; %bb.2:
	ldrb	w8, [x19, #1761]
	tbz	w8, #0, LBB199_4
LBB199_3:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	w9, #3                          ; =0x3
Lloh738:
	adrp	x8, l_.str.101@PAGE
Lloh739:
	add	x8, x8, l_.str.101@PAGEOFF
	b	LBB199_13
LBB199_4:
	ldr	x8, [x19, #1752]
	mov	w10, #65281                     ; =0xff01
	movk	w10, #255, lsl #16
	cmp	x8, x10
	b.lo	LBB199_6
; %bb.5:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #1760]
Lloh740:
	adrp	x8, l_.str.101@PAGE
Lloh741:
	add	x8, x8, l_.str.101@PAGEOFF
	mov	w9, #3                          ; =0x3
	b	LBB199_13
LBB199_6:
	add	x8, x8, #256
	str	x8, [x19, #1752]
LBB199_7:
	ldr	w8, [x19, #20]
	add	w8, w8, #1
	str	w8, [x19, #20]
	tst	x5, #0xff0000
	b.ne	LBB199_9
; %bb.8:
	ldrb	w8, [x3]
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w8
	eor	w10, w10, w5
	tst	w10, #0xffff
	b.eq	LBB199_16
LBB199_9:
	cbz	x9, LBB199_11
; %bb.10:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh742:
	adrp	x8, l_.str.140@PAGE
Lloh743:
	add	x8, x8, l_.str.140@PAGEOFF
	b	LBB199_13
LBB199_11:
Lloh744:
	adrp	x8, l_.str.140@PAGE
Lloh745:
	add	x8, x8, l_.str.140@PAGEOFF
LBB199_12:
	mov	w9, #1                          ; =0x1
LBB199_13:
	str	w9, [x19, #1516]
	str	w1, [x19, #1520]
	mov	w9, #37400                      ; =0x9218
	str	w2, [x19, #1524]
	mov	w10, #191                       ; =0xbf
	stp	x10, x8, [sp]
Lloh746:
	adrp	x2, l_.str.52@PAGE
Lloh747:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x9
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
LBB199_14:
	mov	w8, #0                          ; =0x0
LBB199_15:
	mov	x0, x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB199_16:
	cmp	w8, #7
	ccmp	x9, #0, #4, eq
	b.ne	LBB199_26
LBB199_17:
	cmp	w8, #13
	b.ne	LBB199_20
; %bb.18:
	mov	x21, x3
	mov	x20, x0
	mov	x8, x1
	mov	x1, x7
	mov	x3, x2
	mov	x22, x8
	mov	x2, x8
	mov	x23, x3
	mov	x24, x4
	bl	_map_receiver
	cbz	w0, LBB199_14
; %bb.19:
	mov	x3, x21
	ldrb	w8, [x21]
	mov	x0, x20
	mov	x2, x23
	mov	x1, x22
	mov	x4, x24
LBB199_20:
	cmp	w8, #8
	b.ne	LBB199_31
; %bb.21:
	ldr	w9, [x19, #736]
	cbz	w9, LBB199_71
; %bb.22:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w11, #35904                     ; =0x8c40
	add	x11, x0, x11
	mov	w12, #1                         ; =0x1
	b	LBB199_24
LBB199_23:                              ;   in Loop: Header=BB199_24 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB199_63
LBB199_24:                              ; =>This Inner Loop Header: Depth=1
	lsl	x13, x12, x10
	tst	x13, x4
	b.eq	LBB199_23
; %bb.25:                               ;   in Loop: Header=BB199_24 Depth=1
	ldrb	w14, [x11, x10]
	cmp	w14, #1
	csel	x13, x13, xzr, eq
	orr	x8, x13, x8
	b	LBB199_23
LBB199_26:
	ldr	w9, [x19, #736]
	cbz	w9, LBB199_32
; %bb.27:
	mov	x11, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w12, #35904                     ; =0x8c40
	add	x12, x0, x12
	mov	w13, #1                         ; =0x1
	b	LBB199_29
LBB199_28:                              ;   in Loop: Header=BB199_29 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB199_33
LBB199_29:                              ; =>This Inner Loop Header: Depth=1
	lsl	x14, x13, x11
	tst	x14, x4
	b.eq	LBB199_28
; %bb.30:                               ;   in Loop: Header=BB199_29 Depth=1
	ldrb	w15, [x12, x11]
	cmp	w15, #0
	csel	x14, x14, xzr, eq
	orr	x10, x14, x10
	b	LBB199_28
LBB199_31:
	mov	w8, #1                          ; =0x1
	b	LBB199_15
LBB199_32:
	mov	x10, #0                         ; =0x0
LBB199_33:
	cmp	w6, #511
	b.gt	LBB199_59
; %bb.34:
	sub	w11, w6, #2
	cmp	w11, #62
	b.hi	LBB199_76
; %bb.35:
	mov	w12, #1                         ; =0x1
	lsl	x11, x12, x11
	mov	x12, #4611686019501129728       ; =0x4000000040000000
	movk	x12, #16453
	tst	x11, x12
	b.eq	LBB199_76
LBB199_36:
	cbz	x10, LBB199_78
; %bb.37:
	cmp	x10, x4
	b.ne	LBB199_78
; %bb.38:
	cbz	w9, LBB199_17
; %bb.39:
	mov	x10, #0                         ; =0x0
	add	x11, x19, #758
	mov	w12, #38682                     ; =0x971a
	add	x12, x0, x12
	mov	w13, #1                         ; =0x1
	b	LBB199_41
LBB199_40:                              ;   in Loop: Header=BB199_41 Depth=1
	add	x10, x10, #1
	add	x11, x11, #12
	cmp	x9, x10
	b.eq	LBB199_17
LBB199_41:                              ; =>This Inner Loop Header: Depth=1
	lsr	x14, x4, x10
	tbz	w14, #0, LBB199_40
; %bb.42:                               ;   in Loop: Header=BB199_41 Depth=1
	mov	w14, #128                       ; =0x80
	cmp	w6, #2047
	b.gt	LBB199_47
; %bb.43:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #255
	b.le	LBB199_51
; %bb.44:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #256
	b.eq	LBB199_56
; %bb.45:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #512
	b.eq	LBB199_56
; %bb.46:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #1024
	b.eq	LBB199_56
	b	LBB199_55
LBB199_47:                              ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #2, lsl #12                 ; =8192
	b.lt	LBB199_53
; %bb.48:                               ;   in Loop: Header=BB199_41 Depth=1
	b.eq	LBB199_56
; %bb.49:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #4, lsl #12                 ; =16384
	b.eq	LBB199_56
; %bb.50:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #8, lsl #12                 ; =32768
	b.eq	LBB199_56
	b	LBB199_55
LBB199_51:                              ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #64
	b.eq	LBB199_56
; %bb.52:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #128
	b.eq	LBB199_56
	b	LBB199_55
LBB199_53:                              ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #2048
	b.eq	LBB199_56
; %bb.54:                               ;   in Loop: Header=BB199_41 Depth=1
	cmp	w6, #1, lsl #12                 ; =4096
	b.eq	LBB199_56
LBB199_55:                              ;   in Loop: Header=BB199_41 Depth=1
	mov	x14, x6
LBB199_56:                              ;   in Loop: Header=BB199_41 Depth=1
	ldrb	w15, [x11]
	lsl	w15, w13, w15
	cmp	w14, w15, uxth
	b.ne	LBB199_82
; %bb.57:                               ;   in Loop: Header=BB199_41 Depth=1
	ldrh	w14, [x12, x10, lsl #1]
	orr	w14, w14, w6
	strh	w14, [x12, x10, lsl #1]
	cmp	w14, w6
	b.eq	LBB199_40
; %bb.58:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh748:
	adrp	x8, l_.str.143@PAGE
Lloh749:
	add	x8, x8, l_.str.143@PAGEOFF
	b	LBB199_13
LBB199_59:
	cmp	w6, #4095
	b.le	LBB199_73
; %bb.60:
	cmp	w6, #4, lsl #12                 ; =16384
	b.ge	LBB199_80
; %bb.61:
	cmp	w6, #1, lsl #12                 ; =4096
	b.eq	LBB199_36
; %bb.62:
	cmp	w6, #2, lsl #12                 ; =8192
	b.eq	LBB199_36
	b	LBB199_78
LBB199_63:
	cbz	x8, LBB199_71
; %bb.64:
	cmp	x8, x4
	b.ne	LBB199_71
; %bb.65:
	mov	x10, #0                         ; =0x0
	mov	w8, #35968                      ; =0x8c80
	add	x11, x0, x8
	b	LBB199_67
LBB199_66:                              ;   in Loop: Header=BB199_67 Depth=1
	add	x10, x10, #1
	mov	w8, #1                          ; =0x1
	cmp	x9, x10
	b.eq	LBB199_15
LBB199_67:                              ; =>This Inner Loop Header: Depth=1
	lsr	x8, x4, x10
	tbz	w8, #0, LBB199_66
; %bb.68:                               ;   in Loop: Header=BB199_67 Depth=1
	ldr	x8, [x19]
	ldr	x8, [x8, #24]
	ldr	w12, [x11, x10, lsl #2]
	ldr	w8, [x8, x12, lsl #2]
	ldr	w12, [x3, #4]
	cmp	w8, w12
	b.eq	LBB199_66
; %bb.69:
	ldr	x8, [x19, #1728]
	cbz	x8, LBB199_83
; %bb.70:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh750:
	adrp	x8, l_.str.145@PAGE
Lloh751:
	add	x8, x8, l_.str.145@PAGEOFF
	b	LBB199_13
LBB199_71:
	ldr	x8, [x19, #1728]
	cbz	x8, LBB199_79
; %bb.72:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh752:
	adrp	x8, l_.str.144@PAGE
Lloh753:
	add	x8, x8, l_.str.144@PAGEOFF
	b	LBB199_13
LBB199_73:
	cmp	w6, #512
	b.eq	LBB199_36
; %bb.74:
	cmp	w6, #1024
	b.eq	LBB199_36
; %bb.75:
	cmp	w6, #2048
	b.eq	LBB199_36
	b	LBB199_78
LBB199_76:
	cmp	w6, #128
	b.eq	LBB199_36
; %bb.77:
	cmp	w6, #256
	b.eq	LBB199_36
LBB199_78:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh754:
	adrp	x8, l_.str.141@PAGE
Lloh755:
	add	x8, x8, l_.str.141@PAGEOFF
	b	LBB199_13
LBB199_79:
Lloh756:
	adrp	x8, l_.str.144@PAGE
Lloh757:
	add	x8, x8, l_.str.144@PAGEOFF
	b	LBB199_12
LBB199_80:
	cmp	w6, #8, lsl #12                 ; =32768
	b.eq	LBB199_36
; %bb.81:
	cmp	w6, #4, lsl #12                 ; =16384
	b.eq	LBB199_36
	b	LBB199_78
LBB199_82:
	ldrb	w8, [x19, #1760]
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	csinc	w9, w8, wzr, ne
Lloh758:
	adrp	x8, l_.str.142@PAGE
Lloh759:
	add	x8, x8, l_.str.142@PAGEOFF
	b	LBB199_13
LBB199_83:
Lloh760:
	adrp	x8, l_.str.145@PAGE
Lloh761:
	add	x8, x8, l_.str.145@PAGEOFF
	b	LBB199_12
	.loh AdrpAdd	Lloh738, Lloh739
	.loh AdrpAdd	Lloh740, Lloh741
	.loh AdrpAdd	Lloh742, Lloh743
	.loh AdrpAdd	Lloh744, Lloh745
	.loh AdrpAdd	Lloh746, Lloh747
	.loh AdrpAdd	Lloh748, Lloh749
	.loh AdrpAdd	Lloh750, Lloh751
	.loh AdrpAdd	Lloh752, Lloh753
	.loh AdrpAdd	Lloh754, Lloh755
	.loh AdrpAdd	Lloh756, Lloh757
	.loh AdrpAdd	Lloh758, Lloh759
	.loh AdrpAdd	Lloh760, Lloh761
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function check_write
_check_write:                           ; @check_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #35856                      ; =0x8c10
	add	x8, x0, x8
	ldr	x9, [x8, #1744]
	cbz	x9, LBB200_4
; %bb.1:
	ldrb	w10, [x8, #1776]
	tbnz	w10, #0, LBB200_3
; %bb.2:
	ldrb	w10, [x8, #1777]
	tbz	w10, #0, LBB200_10
LBB200_3:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	w9, #3                          ; =0x3
Lloh762:
	adrp	x10, l_.str.101@PAGE
Lloh763:
	add	x10, x10, l_.str.101@PAGEOFF
	b	LBB200_30
LBB200_4:
	ldr	w10, [x8, #756]
	add	w10, w10, #1
	str	w10, [x8, #756]
	ldr	w10, [x8]
	mov	w11, #703                       ; =0x2bf
	mov	w12, #575                       ; =0x23f
LBB200_5:
	cmp	w10, #0
	csel	w11, w12, w11, eq
	tst	x6, #0xff0000
	b.ne	LBB200_8
; %bb.6:
	and	x10, x6, #0xffff
	cbz	x10, LBB200_8
; %bb.7:
	and	w10, w6, #0xffff
	bics	wzr, w10, w11
	b.eq	LBB200_12
LBB200_8:
	ldr	w10, [x8]
Lloh764:
	adrp	x11, l_.str.149@PAGE
Lloh765:
	add	x11, x11, l_.str.149@PAGEOFF
Lloh766:
	adrp	x12, l_.str.148@PAGE
Lloh767:
	add	x12, x12, l_.str.148@PAGEOFF
	cmp	x9, #0
	csel	x12, x12, x11, eq
	cmp	w10, #0
	csel	x10, x11, x12, eq
	cbz	x9, LBB200_29
; %bb.9:
	ldrb	w9, [x8, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
	b	LBB200_30
LBB200_10:
	ldr	x10, [x8, #1768]
	mov	w11, #65281                     ; =0xff01
	movk	w11, #255, lsl #16
	cmp	x10, x11
	b.lo	LBB200_17
; %bb.11:
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1776]
Lloh768:
	adrp	x10, l_.str.101@PAGE
Lloh769:
	add	x10, x10, l_.str.101@PAGEOFF
	mov	w9, #3                          ; =0x3
	b	LBB200_30
LBB200_12:
	ldr	w11, [x8]
	cbz	w11, LBB200_18
; %bb.13:
	tbz	w6, #7, LBB200_18
; %bb.14:
	cbnz	x5, LBB200_18
; %bb.15:
	cbz	x9, LBB200_28
; %bb.16:
	ldrb	w9, [x8, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
Lloh770:
	adrp	x10, l_.str.150@PAGE
Lloh771:
	add	x10, x10, l_.str.150@PAGEOFF
	b	LBB200_30
LBB200_17:
	add	x10, x10, #256
	str	x10, [x8, #1768]
	ldr	w10, [x8, #756]
	add	w10, w10, #1
	str	w10, [x8, #756]
	ldrb	w10, [x8, #2824]
	mov	w11, #190                       ; =0xbe
	mov	w12, #62                        ; =0x3e
	b	LBB200_5
LBB200_18:
	ldr	w11, [x8, #752]
	mov	w12, #1                         ; =0x1
	cbz	w11, LBB200_27
; %bb.19:
	mov	x13, #0                         ; =0x0
	mov	w14, #35904                     ; =0x8c40
	add	x14, x0, x14
	add	x15, x8, #775
	mov	w16, #4                         ; =0x4
	b	LBB200_21
LBB200_20:                              ;   in Loop: Header=BB200_21 Depth=1
	add	x13, x13, #1
	add	x15, x15, #12
	cmp	x11, x13
	b.eq	LBB200_27
LBB200_21:                              ; =>This Inner Loop Header: Depth=1
	lsr	x17, x3, x13
	tbz	w17, #0, LBB200_20
; %bb.22:                               ;   in Loop: Header=BB200_21 Depth=1
	ldrb	w17, [x14, x13]
	cbnz	w17, LBB200_20
; %bb.23:                               ;   in Loop: Header=BB200_21 Depth=1
	ldrb	w17, [x15]
	cbz	w17, LBB200_20
; %bb.24:                               ;   in Loop: Header=BB200_21 Depth=1
	ldurb	w17, [x15, #-1]
	and	w4, w17, #0xfe
	cmp	w4, #2
	csel	w4, w4, wzr, eq
	cmp	w17, #1
	csel	w4, w16, w4, eq
	lsl	w17, w12, w17
	orr	w17, w4, w17
	bics	wzr, w10, w17
	b.eq	LBB200_20
; %bb.25:
	cbz	x9, LBB200_32
; %bb.26:
	ldrb	w9, [x8, #1776]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w9, w9, wzr, ne
Lloh772:
	adrp	x10, l_.str.151@PAGE
Lloh773:
	add	x10, x10, l_.str.151@PAGEOFF
	b	LBB200_30
LBB200_27:
	mov	w0, #1                          ; =0x1
	b	LBB200_31
LBB200_28:
Lloh774:
	adrp	x10, l_.str.150@PAGE
Lloh775:
	add	x10, x10, l_.str.150@PAGEOFF
LBB200_29:
	mov	w9, #1                          ; =0x1
LBB200_30:
	str	w9, [x8, #1532]
	str	w1, [x8, #1536]
	mov	w9, #37400                      ; =0x9218
	str	w2, [x8, #1540]
	mov	w8, #191                        ; =0xbf
	stp	x8, x10, [sp]
Lloh776:
	adrp	x2, l_.str.52@PAGE
Lloh777:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x9
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
LBB200_31:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB200_32:
Lloh778:
	adrp	x10, l_.str.151@PAGE
Lloh779:
	add	x10, x10, l_.str.151@PAGEOFF
	b	LBB200_29
	.loh AdrpAdd	Lloh762, Lloh763
	.loh AdrpAdd	Lloh766, Lloh767
	.loh AdrpAdd	Lloh764, Lloh765
	.loh AdrpAdd	Lloh768, Lloh769
	.loh AdrpAdd	Lloh770, Lloh771
	.loh AdrpAdd	Lloh772, Lloh773
	.loh AdrpAdd	Lloh774, Lloh775
	.loh AdrpAdd	Lloh776, Lloh777
	.loh AdrpAdd	Lloh778, Lloh779
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function map_receiver
_map_receiver:                          ; @map_receiver
	.cfi_startproc
; %bb.0:
	mov	w8, #36608                      ; =0x8f00
	add	x8, x0, x8
	ldr	x9, [x8, #992]
	cbz	x1, LBB201_7
; %bb.1:
	and	x10, x5, #0xffffff
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB201_7
; %bb.2:
	cbz	x4, LBB201_7
; %bb.3:
	cbz	x9, LBB201_15
; %bb.4:
	ldrb	w10, [x8, #1024]
	tbnz	w10, #0, LBB201_6
; %bb.5:
	ldrb	w10, [x8, #1025]
	tbz	w10, #0, LBB201_12
LBB201_6:
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w10, #3                         ; =0x3
Lloh780:
	adrp	x9, l_.str.101@PAGE
Lloh781:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB201_11
LBB201_7:
	cbz	x9, LBB201_9
; %bb.8:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh782:
	adrp	x9, l_.str.136@PAGE
Lloh783:
	add	x9, x9, l_.str.136@PAGEOFF
	b	LBB201_11
LBB201_9:
Lloh784:
	adrp	x9, l_.str.136@PAGE
Lloh785:
	add	x9, x9, l_.str.136@PAGEOFF
LBB201_10:
	mov	w10, #1                         ; =0x1
LBB201_11:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	w10, [x8, #780]
	str	w2, [x8, #784]
	mov	w10, #37400                     ; =0x9218
	str	w3, [x8, #788]
	mov	w8, #191                        ; =0xbf
	stp	x8, x9, [sp]
Lloh786:
	adrp	x2, l_.str.52@PAGE
Lloh787:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x10
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB201_12:
	ldr	x10, [x8, #1016]
	mov	w11, #65473                     ; =0xffc1
	movk	w11, #255, lsl #16
	cmp	x10, x11
	b.lo	LBB201_14
; %bb.13:
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1024]
Lloh788:
	adrp	x9, l_.str.101@PAGE
Lloh789:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #3                         ; =0x3
	b	LBB201_11
LBB201_14:
	add	x10, x10, #64
	str	x10, [x8, #1016]
LBB201_15:
	ldr	w10, [x8]
	cbz	w10, LBB201_21
; %bb.16:
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	mov	w13, #35904                     ; =0x8c40
	add	x13, x0, x13
	mov	w14, #1                         ; =0x1
	b	LBB201_18
LBB201_17:                              ;   in Loop: Header=BB201_18 Depth=1
	add	x12, x12, #1
	cmp	x10, x12
	b.eq	LBB201_22
LBB201_18:                              ; =>This Inner Loop Header: Depth=1
	lsl	x15, x14, x12
	tst	x15, x4
	b.eq	LBB201_17
; %bb.19:                               ;   in Loop: Header=BB201_18 Depth=1
	ldrb	w16, [x13, x12]
	cmp	w16, #2
	b.ne	LBB201_26
; %bb.20:                               ;   in Loop: Header=BB201_18 Depth=1
	orr	x11, x15, x11
	b	LBB201_17
LBB201_21:
	mov	x11, #0                         ; =0x0
LBB201_22:
	cmp	x11, x4
	b.ne	LBB201_24
; %bb.23:
	mov	w0, #1                          ; =0x1
	ret
LBB201_24:
	cbz	x9, LBB201_28
; %bb.25:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh790:
	adrp	x9, l_.str.138@PAGE
Lloh791:
	add	x9, x9, l_.str.138@PAGEOFF
	b	LBB201_11
LBB201_26:
	cbz	x9, LBB201_29
; %bb.27:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh792:
	adrp	x9, l_.str.137@PAGE
Lloh793:
	add	x9, x9, l_.str.137@PAGEOFF
	b	LBB201_11
LBB201_28:
Lloh794:
	adrp	x9, l_.str.138@PAGE
Lloh795:
	add	x9, x9, l_.str.138@PAGEOFF
	b	LBB201_10
LBB201_29:
Lloh796:
	adrp	x9, l_.str.137@PAGE
Lloh797:
	add	x9, x9, l_.str.137@PAGEOFF
	b	LBB201_10
	.loh AdrpAdd	Lloh780, Lloh781
	.loh AdrpAdd	Lloh782, Lloh783
	.loh AdrpAdd	Lloh784, Lloh785
	.loh AdrpAdd	Lloh786, Lloh787
	.loh AdrpAdd	Lloh788, Lloh789
	.loh AdrpAdd	Lloh790, Lloh791
	.loh AdrpAdd	Lloh792, Lloh793
	.loh AdrpAdd	Lloh794, Lloh795
	.loh AdrpAdd	Lloh796, Lloh797
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_array_requirement_depth
_nvm_record_array_requirement_depth:    ; @nvm_record_array_requirement_depth
	.cfi_startproc
; %bb.0:
	cmp	w0, #511
	b.gt	LBB202_4
; %bb.1:
	sub	w8, w0, #2
	cmp	w8, #62
	b.hi	LBB202_15
; %bb.2:
	mov	w9, #1                          ; =0x1
	lsl	x9, x9, x8
	mov	w10, #16453                     ; =0x4045
	movk	w10, #16384, lsl #16
	tst	x9, x10
	b.eq	LBB202_13
; %bb.3:
	mov	w0, #1                          ; =0x1
	ret
LBB202_4:
	cmp	w0, #4095
	b.le	LBB202_8
; %bb.5:
	cmp	w0, #4, lsl #12                 ; =16384
	b.ge	LBB202_11
; %bb.6:
	cmp	w0, #1, lsl #12                 ; =4096
	b.eq	LBB202_14
; %bb.7:
	cmp	w0, #2, lsl #12                 ; =8192
	b.eq	LBB202_14
	b	LBB202_18
LBB202_8:
	cmp	w0, #512
	b.eq	LBB202_17
; %bb.9:
	cmp	w0, #1024
	b.eq	LBB202_17
; %bb.10:
	cmp	w0, #2048
	b.eq	LBB202_17
	b	LBB202_18
LBB202_11:
	b.eq	LBB202_14
; %bb.12:
	cmp	w0, #8, lsl #12                 ; =32768
	b.eq	LBB202_14
	b	LBB202_18
LBB202_13:
	cmp	x8, #62
	b.ne	LBB202_15
LBB202_14:
	mov	w0, #3                          ; =0x3
	ret
LBB202_15:
	cmp	w0, #128
	b.eq	LBB202_17
; %bb.16:
	cmp	w0, #256
	b.ne	LBB202_18
LBB202_17:
	mov	w0, #2                          ; =0x2
	ret
LBB202_18:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function uf_sensitive
_uf_sensitive:                          ; @uf_sensitive
	.cfi_startproc
; %bb.0:
	mov	w8, #1                          ; =0x1
	sub	w9, w0, #96
	sub	w10, w0, #251
	cmp	w10, #3
	csel	w10, w8, wzr, lo
	cmp	w9, #4
	csel	w8, w8, w10, lo
	cmp	w0, #254
	csinc	w8, w8, wzr, ne
	cmp	w0, #163
	csinc	w0, w8, wzr, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function uf_site_operation
_uf_site_operation:                     ; @uf_site_operation
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	cmp	w8, #162
	b.gt	LBB204_5
; %bb.1:
	cmp	w8, #97
	b.gt	LBB204_9
; %bb.2:
	cmp	w8, #96
	b.eq	LBB204_16
; %bb.3:
	cmp	w8, #97
	b.ne	LBB204_18
; %bb.4:
	mov	w8, #4                          ; =0x4
	and	w0, w8, #0xff
	ret
LBB204_5:
	cmp	w8, #252
	b.gt	LBB204_12
; %bb.6:
	cmp	w8, #163
	b.eq	LBB204_17
; %bb.7:
	cmp	w8, #251
	b.ne	LBB204_18
; %bb.8:
	ldrb	w8, [x0, #8]
	cmp	w8, #1
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, eq
	and	w0, w8, #0xff
	ret
LBB204_9:
	cmp	w8, #98
	b.eq	LBB204_15
; %bb.10:
	cmp	w8, #99
	b.ne	LBB204_18
; %bb.11:
	mov	w8, #2                          ; =0x2
	and	w0, w8, #0xff
	ret
LBB204_12:
	cmp	w8, #253
	b.eq	LBB204_15
; %bb.13:
	cmp	w8, #254
	b.ne	LBB204_18
; %bb.14:
	mov	w8, #7                          ; =0x7
	and	w0, w8, #0xff
	ret
LBB204_15:
	mov	w8, #6                          ; =0x6
	and	w0, w8, #0xff
	ret
LBB204_16:
	mov	w8, #1                          ; =0x1
	and	w0, w8, #0xff
	ret
LBB204_17:
	mov	w8, #8                          ; =0x8
	and	w0, w8, #0xff
	ret
LBB204_18:
	and	w0, wzr, #0xff
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function uf_summary
_uf_summary:                            ; @uf_summary
	.cfi_startproc
; %bb.0:
	mov	w8, #36608                      ; =0x8f00
	add	x8, x0, x8
	ldr	x9, [x8, #992]
	cbz	x9, LBB205_7
; %bb.1:
	ldrb	w10, [x8, #1024]
	tbnz	w10, #0, LBB205_3
; %bb.2:
	ldrb	w10, [x8, #1025]
	tbz	w10, #0, LBB205_4
LBB205_3:
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	mov	w10, #3                         ; =0x3
Lloh798:
	adrp	x9, l_.str.101@PAGE
Lloh799:
	add	x9, x9, l_.str.101@PAGEOFF
	b	LBB205_14
LBB205_4:
	ldr	x10, [x8, #1016]
	mov	w11, #16777152                  ; =0xffffc0
	cmp	x10, x11
	b.lo	LBB205_6
; %bb.5:
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #1024]
Lloh800:
	adrp	x9, l_.str.101@PAGE
Lloh801:
	add	x9, x9, l_.str.101@PAGEOFF
	mov	w10, #3                         ; =0x3
	b	LBB205_14
LBB205_6:
	add	x10, x10, #65
	str	x10, [x8, #1016]
LBB205_7:
	tst	x2, #0xff0000
	b.ne	LBB205_10
; %bb.8:
	and	x10, x2, #0xffff
	cbz	x10, LBB205_10
; %bb.9:
	mov	w10, #63680                     ; =0xf8c0
	tst	w2, w10
	b.eq	LBB205_15
LBB205_10:
	cbz	x9, LBB205_12
; %bb.11:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh802:
	adrp	x9, l_.str.155@PAGE
Lloh803:
	add	x9, x9, l_.str.155@PAGEOFF
	b	LBB205_14
LBB205_12:
Lloh804:
	adrp	x9, l_.str.155@PAGE
Lloh805:
	add	x9, x9, l_.str.155@PAGEOFF
LBB205_13:
	mov	w10, #1                         ; =0x1
LBB205_14:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	w10, [x8, #780]
	str	w3, [x8, #784]
	mov	w10, #37400                     ; =0x9218
	str	w4, [x8, #788]
	mov	w8, #191                        ; =0xbf
	stp	x8, x9, [sp]
Lloh806:
	adrp	x2, l_.str.52@PAGE
Lloh807:
	add	x2, x2, l_.str.52@PAGEOFF
	add	x0, x0, x10
	mov	w1, #192                        ; =0xc0
	bl	_snprintf
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB205_15:
	ldr	w11, [x8]
	cbz	w11, LBB205_23
; %bb.16:
	mov	x13, #0                         ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	mov	w14, #35904                     ; =0x8c40
	add	x14, x0, x14
	mov	w15, #1                         ; =0x1
	mov	w16, #1024                      ; =0x400
	mov	w17, #256                       ; =0x100
	b	LBB205_19
LBB205_17:                              ;   in Loop: Header=BB205_19 Depth=1
	orr	x10, x5, x10
	orr	w12, w6, w12
LBB205_18:                              ;   in Loop: Header=BB205_19 Depth=1
	add	x13, x13, #1
	cmp	x11, x13
	b.eq	LBB205_24
LBB205_19:                              ; =>This Inner Loop Header: Depth=1
	lsl	x5, x15, x13
	tst	x5, x1
	b.eq	LBB205_18
; %bb.20:                               ;   in Loop: Header=BB205_19 Depth=1
	ldrb	w6, [x14, x13]
	cmp	w6, #3
	csel	w7, w16, wzr, eq
	cmp	w6, #1
	csel	w6, w17, w7, eq
	cmp	w6, #0
	and	w7, w6, w2
	ccmp	w7, #0, #4, ne
	b.ne	LBB205_17
; %bb.21:
	cbz	x9, LBB205_29
; %bb.22:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh808:
	adrp	x9, l_.str.156@PAGE
Lloh809:
	add	x9, x9, l_.str.156@PAGEOFF
	b	LBB205_14
LBB205_23:
	mov	x10, #0                         ; =0x0
	cmp	x10, x1
	b.eq	LBB205_25
	b	LBB205_27
LBB205_24:
	and	w11, w12, #0xffff
	cmp	x10, x1
	b.ne	LBB205_27
LBB205_25:
	mov	w10, #1280                      ; =0x500
	and	w10, w2, w10
	cmp	w10, w11
	b.ne	LBB205_27
; %bb.26:
	mov	w0, #1                          ; =0x1
	ret
LBB205_27:
	cbz	x9, LBB205_30
; %bb.28:
	ldrb	w9, [x8, #1024]
	cmp	w9, #0
	mov	w9, #3                          ; =0x3
	csinc	w10, w9, wzr, ne
Lloh810:
	adrp	x9, l_.str.157@PAGE
Lloh811:
	add	x9, x9, l_.str.157@PAGEOFF
	b	LBB205_14
LBB205_29:
Lloh812:
	adrp	x9, l_.str.156@PAGE
Lloh813:
	add	x9, x9, l_.str.156@PAGEOFF
	b	LBB205_13
LBB205_30:
Lloh814:
	adrp	x9, l_.str.157@PAGE
Lloh815:
	add	x9, x9, l_.str.157@PAGEOFF
	b	LBB205_13
	.loh AdrpAdd	Lloh798, Lloh799
	.loh AdrpAdd	Lloh800, Lloh801
	.loh AdrpAdd	Lloh802, Lloh803
	.loh AdrpAdd	Lloh804, Lloh805
	.loh AdrpAdd	Lloh806, Lloh807
	.loh AdrpAdd	Lloh808, Lloh809
	.loh AdrpAdd	Lloh810, Lloh811
	.loh AdrpAdd	Lloh812, Lloh813
	.loh AdrpAdd	Lloh814, Lloh815
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_copy
_rae_copy:                              ; @rae_copy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x2, LBB206_6
; %bb.1:
	cbz	x1, LBB206_4
; %bb.2:
	ldr	x8, [x0, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.ls	LBB206_7
LBB206_3:
	mov	w8, #3                          ; =0x3
	b	LBB206_5
LBB206_4:
	mov	w8, #2                          ; =0x2
LBB206_5:
	str	w8, [x0, #13376]
LBB206_6:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB206_7:
	ldr	x9, [x0, #13368]
	mov	w10, #33554432                  ; =0x2000000
	cmp	x9, x10
	b.hi	LBB206_3
; %bb.8:
	mul	x19, x3, x2
	mov	w11, #134217728                 ; =0x8000000
	sub	x11, x11, x8
	cmp	x19, x11
	b.hi	LBB206_3
; %bb.9:
	sub	x10, x10, x9
	cmp	x19, x10
	b.hi	LBB206_3
; %bb.10:
	mov	x20, x1
	add	x8, x8, x19
	str	x8, [x0, #13360]
	add	x8, x9, x19
	mov	x21, x0
	str	x8, [x0, #13368]
	mov	x0, x19
	bl	_malloc
	cbz	x0, LBB206_12
; %bb.11:
	mov	x1, x20
	mov	x2, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_memcpy
LBB206_12:
	mov	w8, #4                          ; =0x4
	str	w8, [x21, #13376]
	b	LBB206_6
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_zero
_rae_zero:                              ; @rae_zero
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB207_6
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB207_3
; %bb.2:
	mul	x9, x2, x1
	ldr	x10, [x0, #13368]
	mov	w11, #134217728                 ; =0x8000000
	sub	x11, x11, x8
	mov	w12, #33554432                  ; =0x2000000
	sub	x13, x12, x10
	cmp	x10, x12
	ccmp	x9, x11, #2, ls
	ccmp	x9, x13, #2, ls
	b.ls	LBB207_7
LBB207_3:
	mov	w9, #3                          ; =0x3
LBB207_4:
	mov	x8, #0                          ; =0x0
	str	w9, [x0, #13376]
LBB207_5:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB207_6:
	mov	x0, #0                          ; =0x0
	ret
LBB207_7:
	add	x8, x8, x9
	str	x8, [x0, #13360]
	add	x8, x10, x9
	mov	x19, x0
	str	x8, [x0, #13368]
	mov	x0, x1
	mov	x1, x2
	bl	_calloc
	mov	x8, x0
	cbnz	x0, LBB207_5
; %bb.8:
	mov	w9, #4                          ; =0x4
	mov	x0, x19
	b	LBB207_4
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_old_recipe
_rae_old_recipe:                        ; @rae_old_recipe
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cmp	w0, #108
	b.ne	LBB208_2
LBB208_1:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB208_2:
	mov	x19, x0
	mov	x20, x1
	bl	_supported
	mov	x1, x20
	cbnz	w0, LBB208_6
; %bb.3:
	sub	w8, w19, #51
	cmp	w8, #48
	b.hi	LBB208_5
; %bb.4:
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	x9, #527765581332480            ; =0x1e00000000000
	movk	x9, #1
	tst	x8, x9
	b.ne	LBB208_6
LBB208_5:
	sub	w8, w19, #251
	cmp	w8, #3
	b.hs	LBB208_1
LBB208_6:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_rae_recipe
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_instructions_policy
_rae_instructions_policy:               ; @rae_instructions_policy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x28, x27, [sp, #144]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldr	w8, [x0, #272]
	cbz	w8, LBB209_20
; %bb.1:
	str	x1, [sp, #72]                   ; 8-byte Folded Spill
	str	w2, [sp, #68]                   ; 4-byte Folded Spill
	mov	w22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	add	x25, x19, #552
	mov	w8, #9768                       ; =0x2628
	add	x24, x19, x8
	ldr	x8, [x19, #13360]
	mov	w12, #24                        ; =0x18
	mov	w27, #134217728                 ; =0x8000000
	mov	w28, #33554432                  ; =0x2000000
	mov	w13, #36                        ; =0x24
	mov	w14, #65529                     ; =0xfff9
	movk	w14, #511, lsl #16
	b	LBB209_3
LBB209_2:                               ;   in Loop: Header=BB209_3 Depth=1
	add	x23, x23, #1
	ldr	w21, [x19, #272]
	cmp	x23, x21
	b.hs	LBB209_21
LBB209_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB209_9 Depth 2
	cmp	x8, x27
	b.hi	LBB209_96
; %bb.4:                                ;   in Loop: Header=BB209_3 Depth=1
	ldr	x9, [x19, #256]
	madd	x26, x23, x12, x9
	ldr	w9, [x26, #12]
	add	x9, x9, #32
	ldr	x10, [x19, #13368]
	sub	x11, x28, x10
	cmp	x10, x28
	ccmp	x9, x11, #2, ls
	b.hi	LBB209_96
; %bb.5:                                ;   in Loop: Header=BB209_3 Depth=1
	add	x9, x10, x9
	str	x9, [x19, #13368]
	madd	x21, x23, x13, x25
	ldr	q0, [x26]
	ldr	x9, [x26, #16]
	str	x9, [x21, #16]
	str	q0, [x21]
	ldrh	w9, [x24, x23, lsl #1]
	strh	w9, [x21, #32]
	str	w22, [x21, #24]
	ldr	x9, [x19, #264]
	cbz	x9, LBB209_7
; %bb.6:                                ;   in Loop: Header=BB209_3 Depth=1
	ldr	x9, [x9, x23, lsl #3]
	cmp	x9, #0
	cset	w9, ne
LBB209_7:                               ;   in Loop: Header=BB209_3 Depth=1
	strb	w9, [x21, #34]
	ldr	w9, [x26, #12]
	cbz	w9, LBB209_13
; %bb.8:                                ;   in Loop: Header=BB209_3 Depth=1
	mov	x20, x25
	mov	w25, #0                         ; =0x0
LBB209_9:                               ;   Parent Loop BB209_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x19, #280]
	ldr	w10, [x26, #8]
	add	x8, x8, x10
	add	x0, x8, w25, uxtw
	sub	w1, w9, w25
	add	x2, sp, #80
	bl	_isa_decode
	cbz	w0, LBB209_19
; %bb.10:                               ;   in Loop: Header=BB209_9 Depth=2
	cmp	w22, #16, lsl #12               ; =65536
	b.eq	LBB209_19
; %bb.11:                               ;   in Loop: Header=BB209_9 Depth=2
	add	w22, w22, #1
	ldr	w8, [x21, #28]
	add	w8, w8, #1
	str	w8, [x21, #28]
	ldr	w9, [x26, #12]
	add	w25, w0, w25
	cmp	w25, w9
	b.lo	LBB209_9
; %bb.12:                               ;   in Loop: Header=BB209_3 Depth=1
	ldr	x8, [x19, #13360]
	cmp	x8, x27
	mov	x25, x20
	mov	w12, #24                        ; =0x18
	mov	w13, #36                        ; =0x24
	mov	w14, #65529                     ; =0xfff9
	movk	w14, #511, lsl #16
	b.hi	LBB209_96
LBB209_13:                              ;   in Loop: Header=BB209_3 Depth=1
	ldr	x10, [x19, #13368]
	cmp	x10, x14
	b.hs	LBB209_96
; %bb.14:                               ;   in Loop: Header=BB209_3 Depth=1
	ldr	w9, [x26]
	add	x10, x10, #8
	str	x10, [x19, #13368]
	ldr	w10, [x19, #500]
	cmn	w10, #1
	b.ne	LBB209_2
; %bb.15:                               ;   in Loop: Header=BB209_3 Depth=1
	ldr	w10, [x19, #248]
	cmp	w9, w10
	b.hs	LBB209_2
; %bb.16:                               ;   in Loop: Header=BB209_3 Depth=1
	ldr	x10, [x19, #240]
	ldr	w10, [x10, x9, lsl #2]
	cmp	w10, #8
	b.ne	LBB209_2
; %bb.17:                               ;   in Loop: Header=BB209_3 Depth=1
	ldr	x10, [x19, #232]
	ldr	x9, [x10, x9, lsl #3]
	ldr	x9, [x9]
	mov	x10, #24415                     ; =0x5f5f
	movk	x10, #28265, lsl #16
	movk	x10, #29801, lsl #32
	movk	x10, #24415, lsl #48
	cmp	x9, x10
	b.ne	LBB209_2
; %bb.18:                               ;   in Loop: Header=BB209_3 Depth=1
	str	w23, [x19, #500]
	b	LBB209_2
LBB209_19:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, ne
	b	LBB209_97
LBB209_20:
	str	wzr, [x19, #492]
	str	xzr, [x19, #13352]
	mov	w0, #1                          ; =0x1
	b	LBB209_98
LBB209_21:
	str	w22, [x19, #492]
	cbz	w22, LBB209_25
; %bb.22:
	ldr	x9, [x19, #13360]
	mov	w8, #134217728                  ; =0x8000000
	cmp	x9, x8
	b.ls	LBB209_26
; %bb.23:
	mov	w8, #3                          ; =0x3
LBB209_24:
	mov	w0, #0                          ; =0x0
	str	w8, [x19, #13376]
	str	xzr, [x19, #13352]
	b	LBB209_98
LBB209_25:
	mov	x0, #0                          ; =0x0
	b	LBB209_30
LBB209_26:
	ldr	x10, [x19, #13368]
	mov	w11, #33554432                  ; =0x2000000
	mov	w8, #3                          ; =0x3
	cmp	x10, x11
	b.hi	LBB209_24
; %bb.27:
	mov	w0, w22
	add	x12, x0, x0, lsl #3
	lsl	x12, x12, #3
	mov	w13, #134217728                 ; =0x8000000
	sub	x13, x13, x9
	cmp	x12, x13
	b.hi	LBB209_24
; %bb.28:
	sub	x11, x11, x10
	cmp	x12, x11
	b.hi	LBB209_24
; %bb.29:
	add	x8, x9, x12
	str	x8, [x19, #13360]
	add	x8, x10, x12
	str	x8, [x19, #13368]
	mov	w1, #72                         ; =0x48
	bl	_calloc
	cbz	x0, LBB209_103
LBB209_30:
	str	x0, [x19, #13352]
	mov	w22, #1                         ; =0x1
	cbz	x21, LBB209_99
; %bb.31:
	mov	x27, #0                         ; =0x0
	ldr	x23, [x19, #13360]
	mov	w24, #24                        ; =0x18
	mov	w26, #36                        ; =0x24
	mov	w28, #134217728                 ; =0x8000000
	mov	w11, #33554432                  ; =0x2000000
LBB209_32:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB209_40 Depth 2
                                        ;       Child Loop BB209_46 Depth 3
                                        ;     Child Loop BB209_91 Depth 2
                                        ;       Child Loop BB209_92 Depth 3
	cmp	x23, x28
	b.hi	LBB209_96
; %bb.33:                               ;   in Loop: Header=BB209_32 Depth=1
	ldr	x8, [x19, #13368]
	cmp	x8, x11
	b.hi	LBB209_96
; %bb.34:                               ;   in Loop: Header=BB209_32 Depth=1
	ldr	x9, [x19, #256]
	madd	x9, x27, x24, x9
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	ldr	w20, [x9, #12]
	madd	x9, x27, x26, x25
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w21, [x9, #28]
	lsl	w9, w21, #6
	add	x9, x9, x20
	sub	x10, x11, x8
	cmp	x9, x10
	b.hi	LBB209_96
; %bb.35:                               ;   in Loop: Header=BB209_32 Depth=1
	add	x8, x8, x9
	sub	x9, x11, x8
	str	x8, [x19, #13368]
	sub	x10, x28, x23
	cmp	x10, x20
	ccmp	x9, x20, #0, hi
	b.ls	LBB209_105
; %bb.36:                               ;   in Loop: Header=BB209_32 Depth=1
	add	x0, x20, #1
	add	x23, x23, x0
	str	x23, [x19, #13360]
	add	x8, x8, x0
	str	x8, [x19, #13368]
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB209_106
; %bb.37:                               ;   in Loop: Header=BB209_32 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w11, [x8, #24]
	cbz	w20, LBB209_84
; %bb.38:                               ;   in Loop: Header=BB209_32 Depth=1
	mov	w28, #0                         ; =0x0
	mov	x22, x11
	ldr	x26, [sp, #48]                  ; 8-byte Folded Reload
	stp	x27, x25, [sp, #8]              ; 16-byte Folded Spill
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB209_40
LBB209_39:                              ;   in Loop: Header=BB209_40 Depth=2
	add	w22, w22, #1
	ldr	w20, [x26, #12]
	cmp	w12, w20
	b.hs	LBB209_95
LBB209_40:                              ;   Parent Loop BB209_32 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB209_46 Depth 3
	ldr	x8, [x19, #280]
	ldr	w9, [x26, #8]
	add	x8, x8, x9
	mov	w21, w28
	sub	w1, w20, w28
	add	x0, x8, x21
	add	x2, sp, #80
	bl	_isa_decode
	cbz	w0, LBB209_100
; %bb.41:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	x25, x0
	ldr	x26, [x19, #13352]
	ldrb	w0, [sp, #80]
	bl	_isa_get_info
	cbz	x0, LBB209_104
; %bb.42:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	x24, x0
	mov	w8, #72                         ; =0x48
	umaddl	x23, w22, w8, x26
	ldrb	w0, [sp, #80]
	mov	x1, x23
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	blr	x8
	cbz	w0, LBB209_104
; %bb.43:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	w20, #1                         ; =0x1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	x21, [sp, #24]                  ; 8-byte Folded Spill
	strb	w20, [x8, x21]
	stp	w27, w28, [x23]
	add	w8, w25, w28
	stp	w8, w22, [sp, #32]              ; 8-byte Folded Spill
	str	w8, [x23, #8]
	ldrb	w8, [sp, #80]
	strb	w8, [x23, #30]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23, #20]
	ldrb	w8, [x24, #9]
	strb	w8, [x23, #33]
	cbz	w8, LBB209_56
; %bb.44:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	x21, #0                         ; =0x0
	mov	w8, #72                         ; =0x48
	umull	x8, w22, w8
	add	x22, x24, #12
	add	x27, x26, x8
	ldr	x26, [sp, #48]                  ; 8-byte Folded Reload
	b	LBB209_46
LBB209_45:                              ;   in Loop: Header=BB209_46 Depth=3
	add	w20, w0, w20
	add	x21, x21, #1
	ldrb	w8, [x24, #9]
	cmp	x21, x8
	b.hs	LBB209_57
LBB209_46:                              ;   Parent Loop BB209_32 Depth=1
                                        ;     Parent Loop BB209_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w0, [x22, x21, lsl #2]
	bl	_isa_operand_size
	sub	w8, w25, w20
	cmp	w0, #8
	ccmp	w25, w20, #0, ls
	ccmp	w0, w8, #2, hs
	b.hi	LBB209_100
; %bb.47:                               ;   in Loop: Header=BB209_46 Depth=3
	ldr	w8, [x22, x21, lsl #2]
	add	x9, x27, x21
	strb	w8, [x9, #34]
	cbz	w0, LBB209_45
; %bb.48:                               ;   in Loop: Header=BB209_46 Depth=3
	ldr	x8, [x19, #280]
	ldr	w9, [x26, #8]
	add	w10, w20, w28
	add	w10, w10, w9
	add	x9, x27, x21, lsl #3
	ldr	x11, [x9, #40]
	ldrb	w12, [x8, w10, uxtw]
	orr	x11, x11, x12
	str	x11, [x9, #40]
	cmp	w0, #1
	b.eq	LBB209_45
; %bb.49:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #1
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #8
	str	x11, [x9, #40]
	cmp	w0, #2
	b.eq	LBB209_45
; %bb.50:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #2
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #16
	str	x11, [x9, #40]
	cmp	w0, #3
	b.eq	LBB209_45
; %bb.51:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #3
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #24
	str	x11, [x9, #40]
	cmp	w0, #4
	b.eq	LBB209_45
; %bb.52:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #4
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #32
	str	x11, [x9, #40]
	cmp	w0, #5
	b.eq	LBB209_45
; %bb.53:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #5
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #40
	str	x11, [x9, #40]
	cmp	w0, #6
	b.eq	LBB209_45
; %bb.54:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w12, w10, #6
	ldrb	w12, [x8, w12, uxtw]
	orr	x11, x11, x12, lsl #48
	str	x11, [x9, #40]
	cmp	w0, #7
	b.eq	LBB209_45
; %bb.55:                               ;   in Loop: Header=BB209_46 Depth=3
	add	w10, w10, #7
	ldrb	w8, [x8, w10, uxtw]
	orr	x8, x11, x8, lsl #56
	str	x8, [x9, #40]
	b	LBB209_45
LBB209_56:                              ;   in Loop: Header=BB209_40 Depth=2
	ldr	x26, [sp, #48]                  ; 8-byte Folded Reload
LBB209_57:                              ;   in Loop: Header=BB209_40 Depth=2
	cmp	w20, w25
	b.ne	LBB209_100
; %bb.58:                               ;   in Loop: Header=BB209_40 Depth=2
	ldrb	w8, [sp, #80]
	cmp	w8, #99
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	b.eq	LBB209_60
; %bb.59:                               ;   in Loop: Header=BB209_40 Depth=2
	cmp	w8, #88
	b.ne	LBB209_61
LBB209_60:                              ;   in Loop: Header=BB209_40 Depth=2
	ldrh	w9, [sp, #96]
	mov	w10, #1                         ; =0x1
	b	LBB209_62
LBB209_61:                              ;   in Loop: Header=BB209_40 Depth=2
	ldrsb	w9, [x24, #28]
	ldrsb	w10, [x24, #29]
LBB209_62:                              ;   in Loop: Header=BB209_40 Depth=2
	ldp	x27, x25, [sp, #8]              ; 16-byte Folded Reload
	mov	w24, #24                        ; =0x18
	ldp	w12, w22, [sp, #32]             ; 8-byte Folded Reload
	ldr	x13, [sp, #24]                  ; 8-byte Folded Reload
	and	w11, w8, #0xfffffff7
	cmp	w11, #51
	b.ne	LBB209_66
; %bb.63:                               ;   in Loop: Header=BB209_40 Depth=2
	ldr	w9, [sp, #88]
	str	w9, [x23, #20]
	ldr	w10, [x19, #272]
	cmp	w9, w10
	b.hs	LBB209_101
; %bb.64:                               ;   in Loop: Header=BB209_40 Depth=2
	ldr	x10, [x19, #256]
	umaddl	x10, w9, w24, x10
	ldrh	w9, [x10, #4]
	cmp	w8, #51
	b.ne	LBB209_68
; %bb.65:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	w10, #0                         ; =0x0
	b	LBB209_69
LBB209_66:                              ;   in Loop: Header=BB209_40 Depth=2
	ldrh	w11, [sp, #112]
	cmp	w8, #251
	csel	w9, w11, w9, eq
	csinc	w10, w10, wzr, ne
	cmp	w8, #61
	b.ne	LBB209_69
; %bb.67:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	w10, #0                         ; =0x0
	ldrb	w9, [x26, #21]
	b	LBB209_69
LBB209_68:                              ;   in Loop: Header=BB209_40 Depth=2
	ldrb	w10, [x10, #21]
LBB209_69:                              ;   in Loop: Header=BB209_40 Depth=2
	cmp	w9, #256
	b.hi	LBB209_101
; %bb.70:                               ;   in Loop: Header=BB209_40 Depth=2
	tbnz	w10, #31, LBB209_101
; %bb.71:                               ;   in Loop: Header=BB209_40 Depth=2
	strh	w9, [x23, #24]
	strh	w10, [x23, #26]
	sub	w9, w8, #56
	cmp	w9, #2
	b.hi	LBB209_75
; %bb.72:                               ;   in Loop: Header=BB209_40 Depth=2
	ldrsw	x9, [sp, #88]
	adds	x9, x9, x13
	b.mi	LBB209_101
; %bb.73:                               ;   in Loop: Header=BB209_40 Depth=2
	ldr	w10, [x26, #12]
	cmp	x9, x10
	b.hi	LBB209_101
; %bb.74:                               ;   in Loop: Header=BB209_40 Depth=2
	ldrb	w10, [x23, #32]
	add	x11, x23, x10, lsl #2
	add	w10, w10, #1
	strb	w10, [x23, #32]
	str	w9, [x11, #12]
LBB209_75:                              ;   in Loop: Header=BB209_40 Depth=2
	mov	x28, x12
	cmp	w8, #61
	b.hi	LBB209_81
; %bb.76:                               ;   in Loop: Header=BB209_40 Depth=2
	mov	w9, #1                          ; =0x1
	lsl	x9, x9, x8
	mov	x10, #2380152403065307136       ; =0x2108000000000000
	tst	x9, x10
	b.eq	LBB209_81
LBB209_77:                              ;   in Loop: Header=BB209_40 Depth=2
	and	w8, w8, #0xfe
	cmp	w8, #18
	b.ne	LBB209_39
; %bb.78:                               ;   in Loop: Header=BB209_40 Depth=2
	ldr	w8, [sp, #88]
	add	w8, w8, #1
	cmp	w8, #256
	b.hi	LBB209_101
; %bb.79:                               ;   in Loop: Header=BB209_40 Depth=2
	ldr	w9, [x19, #496]
	cmp	w8, w9
	b.ls	LBB209_39
; %bb.80:                               ;   in Loop: Header=BB209_40 Depth=2
	str	w8, [x19, #496]
	b	LBB209_39
LBB209_81:                              ;   in Loop: Header=BB209_40 Depth=2
	ldr	w9, [sp, #68]                   ; 4-byte Folded Reload
	cbz	w9, LBB209_83
; %bb.82:                               ;   in Loop: Header=BB209_40 Depth=2
	cmp	w8, #163
	b.eq	LBB209_39
LBB209_83:                              ;   in Loop: Header=BB209_40 Depth=2
	ldrb	w9, [x23, #32]
	add	x10, x23, x9, lsl #2
	add	w9, w9, #1
	strb	w9, [x23, #32]
	str	w28, [x10, #12]
	b	LBB209_77
LBB209_84:                              ;   in Loop: Header=BB209_32 Depth=1
	mov	x20, #0                         ; =0x0
LBB209_85:                              ;   in Loop: Header=BB209_32 Depth=1
	strb	w22, [x0, x20]
	cmp	x23, x28
	mov	w10, #33554432                  ; =0x2000000
	b.hi	LBB209_108
; %bb.86:                               ;   in Loop: Header=BB209_32 Depth=1
	ldr	x8, [x19, #13368]
	cmp	x8, x10
	b.hi	LBB209_108
; %bb.87:                               ;   in Loop: Header=BB209_32 Depth=1
	mov	w9, w21
	add	x9, x9, w21, uxtw #1
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB209_108
; %bb.88:                               ;   in Loop: Header=BB209_32 Depth=1
	add	x8, x8, x9
	str	x8, [x19, #13368]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #24]
	cmp	w8, w11
	b.hs	LBB209_94
; %bb.89:                               ;   in Loop: Header=BB209_32 Depth=1
	ldr	x9, [x19, #13352]
	mov	w10, w11
	mov	w11, #72                        ; =0x48
	umaddl	x11, w8, w11, x9
	add	x11, x11, #12
	b	LBB209_91
LBB209_90:                              ;   in Loop: Header=BB209_91 Depth=2
	add	x8, x8, #1
	add	x11, x11, #72
	cmp	x8, x10
	b.eq	LBB209_94
LBB209_91:                              ;   Parent Loop BB209_32 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB209_92 Depth 3
	mov	w12, #72                        ; =0x48
	madd	x12, x8, x12, x9
	ldrb	w12, [x12, #32]
	mov	x13, x11
	cbz	x12, LBB209_90
LBB209_92:                              ;   Parent Loop BB209_32 Depth=1
                                        ;     Parent Loop BB209_91 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w14, [x13], #4
	ldrb	w14, [x0, x14]
	cbz	w14, LBB209_101
; %bb.93:                               ;   in Loop: Header=BB209_92 Depth=3
	subs	x12, x12, #1
	b.ne	LBB209_92
	b	LBB209_90
LBB209_94:                              ;   in Loop: Header=BB209_32 Depth=1
	bl	_free
	mov	w11, #33554432                  ; =0x2000000
	add	x27, x27, #1
	ldr	w8, [x19, #272]
	mov	w0, #1                          ; =0x1
	cmp	x27, x8
	b.lo	LBB209_32
	b	LBB209_98
LBB209_95:                              ;   in Loop: Header=BB209_32 Depth=1
	mov	x11, x22
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w21, [x8, #28]
	ldr	x23, [x19, #13360]
	mov	w22, #1                         ; =0x1
	mov	w26, #36                        ; =0x24
	mov	w28, #134217728                 ; =0x8000000
	b	LBB209_85
LBB209_96:
	mov	w0, #0                          ; =0x0
	mov	w8, #3                          ; =0x3
LBB209_97:
	str	w8, [x19, #13376]
LBB209_98:
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
LBB209_99:
	mov	w0, #1                          ; =0x1
	b	LBB209_98
LBB209_100:
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
LBB209_101:
	bl	_free
LBB209_102:
	mov	w0, #0                          ; =0x0
	b	LBB209_98
LBB209_103:
	mov	w8, #4                          ; =0x4
	b	LBB209_24
LBB209_104:
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_free
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #13376]
	b	LBB209_102
LBB209_105:
	mov	w8, #3                          ; =0x3
	b	LBB209_107
LBB209_106:
	mov	w8, #4                          ; =0x4
LBB209_107:
	mov	w0, #0                          ; =0x0
	b	LBB209_97
LBB209_108:
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #13376]
	b	LBB209_101
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rae_equal_bytes
_rae_equal_bytes:                       ; @rae_equal_bytes
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	ldr	x9, [x0, #13360]
	mov	w10, #134217728                 ; =0x8000000
	cmp	x9, x10
	b.hi	LBB210_2
; %bb.1:
	ldr	x9, [x8, #13368]
	mov	w10, #33554432                  ; =0x2000000
	sub	x11, x10, x9
	cmp	x9, x10
	ccmp	x3, x11, #2, ls
	b.ls	LBB210_3
LBB210_2:
	mov	w0, #0                          ; =0x0
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #13376]
	ret
LBB210_3:
	add	x9, x9, x3
	str	x9, [x8, #13368]
	cbz	x3, LBB210_8
; %bb.4:
	mov	w0, #0                          ; =0x0
	cbz	x1, LBB210_7
; %bb.5:
	cbz	x2, LBB210_7
; %bb.6:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB210_7:
	ret
LBB210_8:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufe_recipe
_ufe_recipe:                            ; @ufe_recipe
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cmp	w0, #162
	b.gt	LBB211_4
; %bb.1:
	sub	w8, w0, #96
	cmp	w8, #4
	b.lo	LBB211_5
; %bb.2:
	cmp	w0, #108
	b.ne	LBB211_19
LBB211_3:
	mov	w0, #0                          ; =0x0
	b	LBB211_15
LBB211_4:
	sub	w8, w0, #251
	cmp	w8, #3
	b.hs	LBB211_16
LBB211_5:
	mov	w8, #255                        ; =0xff
	strb	w8, [x1, #31]
	add	x1, x1, #28
LBB211_6:
	mov	w8, #69                         ; =0x45
	strh	w8, [x1]
	cmp	w0, #250
	b.gt	LBB211_10
; %bb.7:
	cmp	w0, #96
	b.eq	LBB211_12
; %bb.8:
	cmp	w0, #99
	b.eq	LBB211_12
LBB211_9:
	mov	w8, #103                        ; =0x67
	b	LBB211_13
LBB211_10:
	cmp	w0, #254
	b.eq	LBB211_14
; %bb.11:
	cmp	w0, #251
	b.ne	LBB211_9
LBB211_12:
	mov	w8, #93                         ; =0x5d
LBB211_13:
	strh	w8, [x1]
LBB211_14:
	mov	w0, #1                          ; =0x1
LBB211_15:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB211_16:
	cmp	w0, #163
	b.eq	LBB211_18
; %bb.17:
	cmp	w0, #254
	b.ne	LBB211_19
LBB211_18:
	mov	w8, #64                         ; =0x40
	strh	w8, [x1, #28]!
	mov	w8, #255                        ; =0xff
	strb	w8, [x1, #3]
	cmp	w0, #163
	b.ne	LBB211_6
	b	LBB211_14
LBB211_19:
	mov	x19, x1
	mov	x20, x0
	bl	_supported
	cbnz	w0, LBB211_22
; %bb.20:
	sub	w8, w20, #96
	cmp	w8, #4
	b.lo	LBB211_22
; %bb.21:
	cmp	w20, #51
	b.ne	LBB211_3
LBB211_22:
	mov	x0, x20
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_rae_recipe
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufe_origins_value
_ufe_origins_value:                     ; @ufe_origins_value
	.cfi_startproc
; %bb.0:
	tst	x2, #0xff0000
	b.ne	LBB212_4
; %bb.1:
	ldr	x8, [x0, #2568]
	ldr	x9, [x0, #2576]
	orr	x8, x9, x8
	ldr	x9, [x0, #2560]
	orr	x10, x9, x8
	bics	xzr, x1, x10
	b.ne	LBB212_4
; %bb.2:
	tst	x9, x1
	cset	w9, ne
	tst	w2, #0x100
	cset	w10, eq
	cmp	w10, w9
	b.eq	LBB212_4
; %bb.3:
	tst	x8, x1
	cset	w8, ne
	tst	w2, #0x400
	cset	w9, eq
	eor	w0, w9, w8
	ret
LBB212_4:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufe_corresponds
_ufe_corresponds:                       ; @ufe_corresponds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x25, [x1, #16]
	tst	x25, #0xff0000
	b.ne	LBB213_10
; %bb.1:
	ldr	x23, [x1, #8]
	ldr	x8, [x5, #2568]
	ldr	x9, [x5, #2576]
	orr	x8, x9, x8
	ldr	x9, [x5, #2560]
	orr	x10, x9, x8
	bics	xzr, x23, x10
	b.ne	LBB213_10
; %bb.2:
	tst	x9, x23
	cset	w11, ne
	tst	w25, #0x100
	cset	w12, eq
	cmp	w12, w11
	b.eq	LBB213_10
; %bb.3:
	tst	w25, #0x400
	cset	w11, eq
	tst	x8, x23
	cset	w12, eq
	eor	w11, w11, w12
	tbnz	w11, #0, LBB213_10
; %bb.4:
	mvn	x10, x10
	ldp	x20, x21, [x1, #24]
	and	x11, x21, #0xff0000
	and	x12, x20, x10
	orr	x11, x11, x12
	cbnz	x11, LBB213_10
; %bb.5:
	tst	x20, x9
	cset	w11, ne
	tst	w21, #0x100
	cset	w12, eq
	cmp	w11, w12
	b.eq	LBB213_10
; %bb.6:
	tst	w21, #0x400
	cset	w11, eq
	tst	x20, x8
	cset	w12, eq
	eor	w11, w12, w11
	tbnz	w11, #0, LBB213_10
; %bb.7:
	ldp	x22, x26, [x1, #40]
	and	x11, x26, #0xff0000
	and	x10, x22, x10
	orr	x10, x11, x10
	cbnz	x10, LBB213_10
; %bb.8:
	tst	x22, x9
	cset	w9, ne
	tst	w26, #0x100
	cset	w10, eq
	cmp	w9, w10
	b.eq	LBB213_10
; %bb.9:
	tst	w26, #0x400
	cset	w9, eq
	tst	x22, x8
	cset	w8, eq
	eor	w8, w8, w9
	tbz	w8, #0, LBB213_12
LBB213_10:
	mov	w0, #0                          ; =0x0
LBB213_11:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB213_12:
	mov	x15, x0
	and	w8, w26, #0xffff
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	ldrb	w28, [x1, #68]
	cmp	w28, #2
	b.ne	LBB213_53
; %bb.13:
	ldrb	w8, [x1, #67]
	cmp	w8, #3
	b.gt	LBB213_29
; %bb.14:
	sub	w9, w8, #1
	cmp	w9, #3
	b.hs	LBB213_53
; %bb.15:
	ldr	w10, [x5, #2584]
	cbz	w10, LBB213_10
; %bb.16:
	mov	x9, x15
	mov	x11, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	ldr	w12, [x1]
	cmp	w8, #3
	csinc	w8, w8, wzr, eq
	and	w13, w21, #0xffff
	add	x14, x5, #16
	mov	w15, #1                         ; =0x1
	b	LBB213_19
LBB213_17:                              ;   in Loop: Header=BB213_19 Depth=1
	lsl	x16, x15, x11
LBB213_18:                              ;   in Loop: Header=BB213_19 Depth=1
	add	x11, x11, #1
	add	x14, x14, #40
	cmp	x10, x11
	b.eq	LBB213_51
LBB213_19:                              ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x14, #-16]
	cmp	w17, w12
	b.ne	LBB213_18
; %bb.20:                               ;   in Loop: Header=BB213_19 Depth=1
	ldur	w17, [x14, #-12]
	ldr	w0, [x1, #4]
	cmp	w17, w0
	b.ne	LBB213_18
; %bb.21:                               ;   in Loop: Header=BB213_19 Depth=1
	cbnz	x16, LBB213_10
; %bb.22:                               ;   in Loop: Header=BB213_19 Depth=1
	ldur	w16, [x14, #-8]
	ldr	w17, [x1, #56]
	cmp	w16, w17
	b.ne	LBB213_10
; %bb.23:                               ;   in Loop: Header=BB213_19 Depth=1
	ldur	w16, [x14, #-4]
	ldr	w17, [x1, #60]
	cmp	w16, w17
	b.ne	LBB213_10
; %bb.24:                               ;   in Loop: Header=BB213_19 Depth=1
	ldrh	w16, [x14, #2]
	ldrh	w17, [x1, #64]
	cmp	w16, w17
	b.ne	LBB213_10
; %bb.25:                               ;   in Loop: Header=BB213_19 Depth=1
	ldrb	w16, [x14, #1]
	ldrb	w17, [x1, #66]
	cmp	w16, w17
	b.ne	LBB213_10
; %bb.26:                               ;   in Loop: Header=BB213_19 Depth=1
	ldrb	w16, [x14]
	cmp	w8, w16
	b.ne	LBB213_10
; %bb.27:                               ;   in Loop: Header=BB213_19 Depth=1
	ldrh	w16, [x14, #16]
	bics	wzr, w13, w16
	b.ne	LBB213_10
; %bb.28:                               ;   in Loop: Header=BB213_19 Depth=1
	ldr	x16, [x14, #8]
	bics	xzr, x20, x16
	b.eq	LBB213_17
	b	LBB213_10
LBB213_29:
	cmp	w8, #4
	b.eq	LBB213_32
; %bb.30:
	cmp	w8, #5
	b.eq	LBB213_44
; %bb.31:
	cmp	w8, #6
	b.ne	LBB213_53
LBB213_32:
	mov	x9, x2
	mov	x11, x3
	mov	x10, x4
	mov	x12, x15
	ldr	w15, [x5, #2584]
	cbz	w15, LBB213_47
; %bb.33:
	mov	x16, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	and	w17, w21, #0xffff
	add	x0, x5, #32
	b	LBB213_37
LBB213_34:                              ;   in Loop: Header=BB213_37 Depth=1
	ldrh	w3, [x0]
LBB213_35:                              ;   in Loop: Header=BB213_37 Depth=1
	orr	x14, x2, x14
	orr	w13, w3, w13
LBB213_36:                              ;   in Loop: Header=BB213_37 Depth=1
	add	x16, x16, #1
	add	x0, x0, #40
	cmp	x15, x16
	b.eq	LBB213_48
LBB213_37:                              ; =>This Inner Loop Header: Depth=1
	lsr	x2, x23, x16
	tbz	w2, #0, LBB213_36
; %bb.38:                               ;   in Loop: Header=BB213_37 Depth=1
	ldurb	w2, [x0, #-16]
	cmp	w2, #1
	b.ne	LBB213_10
; %bb.39:                               ;   in Loop: Header=BB213_37 Depth=1
	ldur	w2, [x0, #-24]
	ldr	w3, [x1, #56]
	cmp	w2, w3
	b.ne	LBB213_10
; %bb.40:                               ;   in Loop: Header=BB213_37 Depth=1
	ldur	w2, [x0, #-20]
	ldr	w3, [x1, #60]
	cmp	w2, w3
	b.ne	LBB213_10
; %bb.41:                               ;   in Loop: Header=BB213_37 Depth=1
	ldur	x2, [x0, #-8]
	cmp	w8, #6
	b.ne	LBB213_34
; %bb.42:                               ;   in Loop: Header=BB213_37 Depth=1
	bics	xzr, x20, x2
	b.ne	LBB213_10
; %bb.43:                               ;   in Loop: Header=BB213_37 Depth=1
	ldrh	w3, [x0]
	bics	wzr, w17, w3
	b.eq	LBB213_35
	b	LBB213_10
LBB213_44:
	mov	w0, #0                          ; =0x0
	ldrb	w8, [x1, #66]
	cmp	x8, #1
	b.hi	LBB213_11
; %bb.45:
	cbz	x23, LBB213_11
; %bb.46:
	add	x9, x5, #2568
	ldr	x8, [x9, x8, lsl #3]
	bics	xzr, x23, x8
	b.ne	LBB213_10
	b	LBB213_53
LBB213_47:
	mov	x14, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
LBB213_48:
	cmp	w8, #4
	mov	x15, x12
	mov	x4, x10
	mov	x3, x11
	mov	x2, x9
	b.ne	LBB213_53
; %bb.49:
	mov	w0, #0                          ; =0x0
	cmp	x14, x22
	b.ne	LBB213_11
; %bb.50:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cmp	w13, w8
	mov	x15, x12
	mov	x4, x10
	mov	x3, x11
	mov	x2, x9
	b.eq	LBB213_53
	b	LBB213_11
LBB213_51:
	mov	w0, #0                          ; =0x0
	cbz	x16, LBB213_11
; %bb.52:
	cmp	x16, x22
	mov	x15, x9
	b.ne	LBB213_11
LBB213_53:
	stp	w2, w3, [sp, #8]                ; 8-byte Folded Spill
	str	x4, [sp]                        ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	str	xzr, [sp, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	mov	x24, x15
	ldrb	w19, [x15, #30]
	add	x1, sp, #96
	mov	x0, x19
	bl	_ufe_recipe
	cbz	w0, LBB213_11
; %bb.54:
	ldrb	w27, [sp, #127]
	ldrb	w9, [x24, #31]
	cmp	w27, w9
	b.ne	LBB213_10
; %bb.55:
	mov	x8, x24
	ldrh	w9, [sp, #124]
	ldrh	w10, [x24, #28]
	cmp	w9, w10
	b.ne	LBB213_10
; %bb.56:
	ldr	w9, [x8]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w9, w8
	b.ne	LBB213_10
; %bb.57:
	ldr	w9, [x24, #4]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #4]
	cmp	w9, w8
	b.ne	LBB213_10
; %bb.58:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #69]
	cbnz	w8, LBB213_10
; %bb.59:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #70]
	cbnz	w8, LBB213_10
; %bb.60:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #71]
	cbnz	w8, LBB213_10
; %bb.61:
	mov	x0, x19
	bl	_uf_sensitive
	cbz	w0, LBB213_66
; %bb.62:
	cmp	w27, #255
	b.ne	LBB213_10
; %bb.63:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	strb	w19, [sp, #32]
	ldr	x27, [x24, #40]
	strb	w27, [sp, #40]
	add	x0, sp, #32
	bl	_uf_site_operation
	mov	x8, x0
	cmp	w28, #2
	b.eq	LBB213_76
; %bb.64:
	cmp	w28, #1
	b.ne	LBB213_10
; %bb.65:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #67]
	cmp	w9, w8
	b.ne	LBB213_10
	b	LBB213_68
LBB213_66:
	cbnz	w28, LBB213_10
; %bb.67:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #67]
	cbnz	w8, LBB213_10
LBB213_68:
	and	x8, x25, #0xffff
	orr	x8, x8, x23
	cbnz	x8, LBB213_10
; %bb.69:
	and	x8, x21, #0xffff
	orr	x8, x8, x20
	cbnz	x8, LBB213_10
; %bb.70:
	and	x8, x26, #0xffff
	orr	x8, x8, x22
	cbnz	x8, LBB213_10
; %bb.71:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #56]
	cmn	w8, #1
	b.ne	LBB213_10
; %bb.72:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #60]
	cmn	w8, #1
	b.ne	LBB213_10
; %bb.73:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrsh	w8, [x8, #64]
	cmn	w8, #1
	b.ne	LBB213_10
; %bb.74:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #66]
	cmp	w8, #255
LBB213_75:
	cset	w0, eq
	b	LBB213_11
LBB213_76:
	cmp	w19, #163
	b.ne	LBB213_81
; %bb.77:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #67]
	cmp	w8, #8
	b.ne	LBB213_10
; %bb.78:
	ldrb	w8, [x24, #32]
	cbnz	w8, LBB213_10
; %bb.79:
	ldrh	w8, [x24, #24]
	cbnz	w8, LBB213_10
; %bb.80:
	ldrh	w8, [x24, #26]
	cbnz	w8, LBB213_10
	b	LBB213_68
LBB213_81:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w9, [x9, #56]
	cbnz	w9, LBB213_10
; %bb.82:
	mov	w0, #0                          ; =0x0
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #67]
	cmp	w9, #3
	b.le	LBB213_94
; %bb.83:
	and	w8, w25, #0xffff
	cmp	w9, #5
	b.gt	LBB213_105
; %bb.84:
	cmp	w9, #4
	b.eq	LBB213_116
; %bb.85:
	cmp	w9, #5
	b.ne	LBB213_11
; %bb.86:
	ldrh	w9, [x24, #24]
	cmp	w9, #1
	b.ne	LBB213_10
; %bb.87:
	mov	w0, #0                          ; =0x0
	cmp	w19, #252
	b.ne	LBB213_11
; %bb.88:
	ldrh	w9, [x24, #26]
	cmp	w9, #1
	b.ne	LBB213_11
; %bb.89:
	cbnz	x27, LBB213_11
; %bb.90:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w9, [x9, #64]
	cbnz	w9, LBB213_10
; %bb.91:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [x9, #60]
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB213_10
; %bb.92:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #66]
	cmp	x9, #1
	b.hi	LBB213_10
; %bb.93:
	mov	w11, #12                        ; =0xc
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	umaddl	x9, w9, w11, x10
	ldrh	w9, [x9, #10]
	cmp	w9, #1
	b.ne	LBB213_10
	b	LBB213_113
LBB213_94:
	sub	w10, w9, #1
	cmp	w10, #3
	b.hs	LBB213_11
; %bb.95:
	cmp	w9, w8
	b.ne	LBB213_10
; %bb.96:
	and	x8, x25, #0xffff
	orr	x8, x8, x23
	cbnz	x8, LBB213_10
; %bb.97:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w11, [x8, #60]
	cmp	w9, #3
	ldp	w10, w8, [sp, #8]               ; 8-byte Folded Reload
	csel	w8, w8, w10, eq
	cmp	w11, w8
	b.ne	LBB213_10
; %bb.98:
	mov	w0, #0                          ; =0x0
	mov	w8, #256                        ; =0x100
	mov	w10, #1024                      ; =0x400
	cmp	w9, #3
	csel	w8, w10, w8, eq
	cmp	w8, w26, uxth
	b.ne	LBB213_11
; %bb.99:
	cbz	x22, LBB213_11
; %bb.100:
	cmp	w19, #251
	b.ne	LBB213_136
; %bb.101:
	cmp	w9, #3
	cset	w8, eq
	cmp	x27, x8
	b.ne	LBB213_10
; %bb.102:
	ldr	x8, [x24, #48]
	cbnz	x8, LBB213_10
; %bb.103:
	ldr	x8, [x24, #56]
	cmp	w9, #3
	b.ne	LBB213_139
; %bb.104:
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldrb	w10, [x10, #66]
	b	LBB213_140
LBB213_105:
	cmp	w9, #6
	b.eq	LBB213_127
; %bb.106:
	cmp	w9, #7
	b.ne	LBB213_11
; %bb.107:
	ldrh	w9, [x24, #24]
	cmp	w9, #1
	b.ne	LBB213_10
; %bb.108:
	mov	w0, #0                          ; =0x0
	cmp	w19, #254
	b.ne	LBB213_11
; %bb.109:
	ldrh	w9, [x24, #26]
	cmp	w9, #1
	b.ne	LBB213_11
; %bb.110:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [x9, #60]
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB213_10
; %bb.111:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #66]
	cmp	w9, #255
	b.ne	LBB213_10
; %bb.112:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrsh	w9, [x9, #64]
	cmn	w9, #1
	b.ne	LBB213_10
LBB213_113:
	mov	w0, #0                          ; =0x0
	cmp	w8, #1024
	b.ne	LBB213_11
; %bb.114:
	cbz	x23, LBB213_11
; %bb.115:
	and	x8, x21, #0xffff
	orr	x8, x8, x20
	cmp	x8, #0
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ccmp	w8, #2, #0, eq
	ccmp	x22, #0, #0, eq
	b	LBB213_75
LBB213_116:
	ldrh	w9, [x24, #24]
	cmp	w9, #1
	b.ne	LBB213_10
; %bb.117:
	ldrh	w9, [x24, #26]
	cmp	w9, #1
	b.ne	LBB213_10
; %bb.118:
	cmp	w19, #252
	b.eq	LBB213_120
; %bb.119:
	cmp	w19, #97
	b.ne	LBB213_10
LBB213_120:
	cbnz	x27, LBB213_10
; %bb.121:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w9, [x9, #64]
	cbnz	w9, LBB213_10
; %bb.122:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [x9, #60]
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB213_10
; %bb.123:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #66]
	cmp	w9, #255
	b.ne	LBB213_10
; %bb.124:
	mov	w0, #0                          ; =0x0
	cmp	w8, #256
	b.ne	LBB213_11
; %bb.125:
	cbz	x23, LBB213_11
; %bb.126:
	and	x8, x21, #0xffff
	orr	x8, x8, x20
	cmp	x8, #0
	mov	w8, #1024                       ; =0x400
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	ccmp	w9, w8, #0, eq
	ccmp	x22, #0, #4, eq
	cset	w0, ne
	b	LBB213_11
LBB213_127:
	ldrh	w9, [x24, #24]
	cmp	w9, #2
	b.ne	LBB213_10
; %bb.128:
	ldrh	w9, [x24, #26]
	cmp	w9, #1
	b.ne	LBB213_10
; %bb.129:
	cmp	w19, #253
	b.eq	LBB213_131
; %bb.130:
	cmp	w19, #98
	b.ne	LBB213_10
LBB213_131:
	cbnz	x27, LBB213_10
; %bb.132:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w9, [x9, #64]
	cbnz	w9, LBB213_10
; %bb.133:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w10, [x9, #60]
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB213_10
; %bb.134:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, #66]
	cmp	w9, #255
	b.ne	LBB213_10
; %bb.135:
	cmp	w8, #256
	and	x8, x21, #0xffff
	mov	w9, #1024                       ; =0x400
	ccmp	x8, x9, #0, eq
	ccmp	x23, #0, #4, eq
	ccmp	x20, #0, #4, ne
	mov	w8, #256                        ; =0x100
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	ccmp	w9, w8, #0, ne
	ccmp	x22, x23, #0, eq
	b	LBB213_75
LBB213_136:
	cbnz	x27, LBB213_10
; %bb.137:
	cmp	w19, #99
	b.ne	LBB213_143
; %bb.138:
	ldr	x10, [x24, #48]
	b	LBB213_142
LBB213_139:
	mov	x10, #0                         ; =0x0
LBB213_140:
	cmp	x8, x10
	b.ne	LBB213_10
; %bb.141:
	ldr	x10, [x24, #64]
LBB213_142:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #64]
	cmp	x10, x8
	b.ne	LBB213_10
LBB213_143:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #66]
	cmp	w9, #3
	b.ne	LBB213_146
; %bb.144:
	cmp	w8, #1
	b.hi	LBB213_10
; %bb.145:
	mov	w11, #12                        ; =0xc
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	umaddl	x8, w8, w11, x10
	ldrh	w8, [x8, #10]
	b	LBB213_148
LBB213_146:
	cmp	w8, #255
	b.ne	LBB213_10
; %bb.147:
	mov	w8, #1                          ; =0x1
LBB213_148:
	ldrh	w10, [x24, #26]
	cmp	w10, #1
	b.ne	LBB213_10
; %bb.149:
	ldrh	w10, [x24, #24]
	cmp	w19, #96
	csel	w11, wzr, w8, eq
	cmp	w11, w10
	b.ne	LBB213_10
; %bb.150:
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldrh	w10, [x10, #64]
	cmp	w8, w10
	b.ne	LBB213_10
; %bb.151:
	cbz	w8, LBB213_155
; %bb.152:
	mov	w8, #1024                       ; =0x400
	mov	w10, #2                         ; =0x2
	cmp	w9, #3
	csel	w8, w10, w8, eq
	cmp	w8, w21, uxth
	b.ne	LBB213_10
; %bb.153:
	cmp	w9, #3
	b.ne	LBB213_156
; %bb.154:
	cmp	x20, #0
	b	LBB213_75
LBB213_155:
	and	x8, x21, #0xffff
	orr	x8, x8, x20
	cmp	x8, #0
	b	LBB213_75
LBB213_156:
	cmp	x20, #0
	cset	w0, ne
	b	LBB213_11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_map_copy_term
_nvm_map_copy_term:                     ; @nvm_map_copy_term
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0, #16]
	tbnz	w8, #0, LBB214_2
; %bb.1:
	ldp	x8, x9, [x0]
	subs	x9, x9, x8
	ccmp	x9, #3, #0, hs
	b.hi	LBB214_3
LBB214_2:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #16]
	mov	w0, #2                          ; =0x2
	ret
LBB214_3:
	add	x8, x8, #4
	str	x8, [x0]
	cmp	x1, #0
	cset	w8, ne
	cmp	x2, #0
	cset	w9, eq
	cmp	w8, w9
	b.eq	LBB214_6
; %bb.4:
	mul	x8, x3, x2
	ldr	x9, [x4]
	cmn	x9, x8
	b.lo	LBB214_7
; %bb.5:
	mov	w0, #2                          ; =0x2
	ret
LBB214_6:
	mov	w0, #1                          ; =0x1
	ret
LBB214_7:
	mov	w0, #0                          ; =0x0
	add	x8, x9, x8
	str	x8, [x4]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufe_proof_retained_cost
_ufe_proof_retained_cost:               ; @ufe_proof_retained_cost
	.cfi_startproc
; %bb.0:
	subs	x8, x1, x2
	cmp	x8, #7
	cset	w8, hi
	sub	x9, x2, x1
	cmp	x9, #23
	cset	w9, hi
	cmp	x1, x2
	csel	w8, w8, w9, hi
	cmp	w8, #1
	b.ne	LBB215_9
; %bb.1:
	ldrb	w8, [x1, #16]
	tbnz	w8, #0, LBB215_3
; %bb.2:
	ldp	x9, x10, [x1]
	subs	x8, x10, x9
	ccmp	x8, #15, #0, hs
	b.hi	LBB215_4
LBB215_3:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
	mov	w0, #2                          ; =0x2
	ret
LBB215_4:
	add	x11, x9, #16
	str	x11, [x1]
	cbz	x0, LBB215_9
; %bb.5:
	ldr	x8, [x0]
	cbz	x8, LBB215_9
; %bb.6:
	ldr	w8, [x0, #40]
	cmp	w8, #64
	b.hi	LBB215_9
; %bb.7:
	ldr	w12, [x0, #44]
	cmp	w12, #256
	b.hi	LBB215_9
; %bb.8:
	ldr	w12, [x0, #48]
	sub	w12, w12, #257
	cmn	w12, #256
	b.hs	LBB215_10
LBB215_9:
	mov	w0, #1                          ; =0x1
	ret
LBB215_10:
	subs	x10, x10, x11
	b.lo	LBB215_3
; %bb.11:
	cmp	x10, #3
	b.ls	LBB215_3
; %bb.12:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	add	x9, x9, #20
	str	x9, [x1]
	mov	w9, #72                         ; =0x48
	str	x9, [sp, #8]
	mov	x21, x0
	ldr	x9, [x0, #8]
	add	x4, sp, #8
	mov	x19, x1
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #40                         ; =0x28
	bl	_nvm_map_copy_term
	cbnz	w0, LBB215_20
; %bb.13:
	ldr	x1, [x21, #16]
	ldr	w2, [x21, #44]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #16                         ; =0x10
	bl	_nvm_map_copy_term
	cbnz	w0, LBB215_20
; %bb.14:
	ldr	x1, [x21, #24]
	ldr	w2, [x21, #48]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #16                         ; =0x10
	bl	_nvm_map_copy_term
	cbnz	w0, LBB215_20
; %bb.15:
	ldr	x1, [x21, #32]
	ldr	w2, [x21, #48]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #2                          ; =0x2
	bl	_nvm_map_copy_term
	cbnz	w0, LBB215_20
; %bb.16:
	ldr	x0, [x21]
	mov	x2, sp
	mov	x1, x19
	bl	_nvm_union_declarations_retained_cost
	cbnz	w0, LBB215_20
; %bb.17:
	ldp	x8, x9, [sp]
	cmn	x9, x8
	b.lo	LBB215_19
; %bb.18:
	mov	w0, #2                          ; =0x2
	b	LBB215_20
LBB215_19:
	mov	w0, #0                          ; =0x0
	add	x8, x9, x8
	str	x8, [x20]
LBB215_20:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ufi_rows_same
_ufi_rows_same:                         ; @ufi_rows_same
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.1:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.2:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.3:
	ldr	w8, [x0, #20]
	ldr	w9, [x1, #20]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.4:
	ldrh	w8, [x0, #24]
	ldrh	w9, [x1, #24]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.5:
	ldrh	w8, [x0, #26]
	ldrh	w9, [x1, #26]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.6:
	ldrh	w8, [x0, #28]
	ldrh	w9, [x1, #28]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.7:
	ldrb	w8, [x0, #30]
	ldrb	w9, [x1, #30]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.8:
	ldrb	w8, [x0, #31]
	ldrb	w9, [x1, #31]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.9:
	ldrb	w8, [x0, #32]
	ldrb	w9, [x1, #32]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.10:
	ldrb	w8, [x0, #33]
	ldrb	w9, [x1, #33]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.11:
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.12:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.13:
	ldrb	w8, [x0, #34]
	ldrb	w9, [x1, #34]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.14:
	ldr	x8, [x0, #40]
	ldr	x9, [x1, #40]
	cmp	x8, x9
	b.ne	LBB216_35
; %bb.15:
	ldrb	w8, [x0, #35]
	ldrb	w9, [x1, #35]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.16:
	ldr	x8, [x0, #48]
	ldr	x9, [x1, #48]
	cmp	x8, x9
	b.ne	LBB216_35
; %bb.17:
	ldrb	w8, [x0, #36]
	ldrb	w9, [x1, #36]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.18:
	ldr	x8, [x0, #56]
	ldr	x9, [x1, #56]
	cmp	x8, x9
	b.ne	LBB216_35
; %bb.19:
	ldrb	w8, [x0, #37]
	ldrb	w9, [x1, #37]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.20:
	ldr	x8, [x0, #64]
	ldr	x9, [x1, #64]
	cmp	x8, x9
	b.ne	LBB216_35
; %bb.21:
	ldr	w8, [x0, #72]
	ldr	w9, [x1, #72]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.22:
	ldr	w8, [x0, #76]
	ldr	w9, [x1, #76]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.23:
	ldr	w8, [x0, #128]
	ldr	w9, [x1, #128]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.24:
	ldr	w8, [x0, #132]
	ldr	w9, [x1, #132]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.25:
	ldrh	w8, [x0, #136]
	ldrh	w9, [x1, #136]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.26:
	ldrb	w8, [x0, #138]
	ldrb	w9, [x1, #138]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.27:
	ldrb	w8, [x0, #139]
	ldrb	w9, [x1, #139]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.28:
	ldrb	w8, [x0, #140]
	ldrb	w9, [x1, #140]
	cmp	w8, w9
	b.ne	LBB216_35
; %bb.29:
	ldrb	w8, [x0, #141]
	cbnz	w8, LBB216_35
; %bb.30:
	ldrb	w8, [x1, #141]
	cbnz	w8, LBB216_35
; %bb.31:
	ldrb	w8, [x0, #142]
	cbnz	w8, LBB216_35
; %bb.32:
	ldrb	w8, [x1, #142]
	cbnz	w8, LBB216_35
; %bb.33:
	ldrb	w8, [x0, #143]
	cbnz	w8, LBB216_35
; %bb.34:
	ldrb	w8, [x1, #143]
	cbz	w8, LBB216_37
LBB216_35:
	mov	w8, #0                          ; =0x0
LBB216_36:
	mov	x0, x8
	ret
LBB216_37:
	ldr	w9, [x0, #88]
	ldr	w10, [x1, #88]
	eor	w9, w10, w9
	tst	x9, #0xffffff
	b.ne	LBB216_36
; %bb.38:
	ldr	x9, [x0, #80]
	ldr	x10, [x1, #80]
	cmp	x9, x10
	b.ne	LBB216_36
; %bb.39:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x0, #104]
	ldr	w10, [x1, #104]
	eor	w9, w10, w9
	tst	x9, #0xffffff
	b.ne	LBB216_36
; %bb.40:
	ldr	x9, [x0, #96]
	ldr	x10, [x1, #96]
	cmp	x9, x10
	b.ne	LBB216_36
; %bb.41:
	mov	w8, #0                          ; =0x0
	ldr	x9, [x0, #120]
	ldr	x10, [x1, #120]
	eor	x9, x10, x9
	tst	x9, #0xffff
	b.ne	LBB216_36
; %bb.42:
	ldr	x10, [x0, #112]
	ldr	x11, [x1, #112]
	cmp	x10, x11
	b.ne	LBB216_36
; %bb.43:
	tst	x9, #0xff0000
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rme_prepare_boundary
_rme_prepare_boundary:                  ; @rme_prepare_boundary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
Lloh816:
	adrp	x8, l___const.rme_prepare_boundary.result@PAGE
Lloh817:
	add	x8, x8, l___const.rme_prepare_boundary.result@PAGEOFF
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x19, #160]
	ldur	q0, [x8, #188]
	stur	q0, [x19, #188]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x19, #96]
	ldp	q1, q0, [x8, #128]
	stp	q1, q0, [x19, #128]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x19, #32]
	ldp	q1, q0, [x8, #64]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x19]
	cbz	x0, LBB217_50
; %bb.1:
	cbz	x1, LBB217_50
; %bb.2:
	mov	w8, #52128                      ; =0xcba0
	movk	w8, #1022, lsl #16
	cmp	x2, x8
	b.hi	LBB217_16
; %bb.3:
	mov	w8, #52129                      ; =0xcba1
	movk	w8, #254, lsl #16
	cmp	x3, x8
	b.hs	LBB217_16
; %bb.4:
	mov	x21, x4
	mov	x25, x2
	mov	x24, x3
	mov	x23, x0
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #24                         ; =0x18
	bl	_calloc
	cbz	x0, LBB217_17
; %bb.5:
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #13384                      ; =0x3448
	bl	_calloc
	str	x0, [x20]
	cbz	x0, LBB217_18
; %bb.6:
	mov	x22, x0
	mov	w8, #13408                      ; =0x3460
	movk	w8, #1025, lsl #16
	add	x8, x25, x8
	mov	w9, #13408                      ; =0x3460
	movk	w9, #257, lsl #16
	stp	xzr, xzr, [x29, #-104]
	add	x9, x24, x9
	str	x8, [x0, #13360]
	str	x9, [x0, #13368]
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #13376]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x0, #500]
	mov	x1, x23
	bl	_rae_snapshot
	cbz	w0, LBB217_49
; %bb.7:
	ldr	w24, [x22, #272]
	cbz	w24, LBB217_14
; %bb.8:
	ldr	x25, [x22, #256]
	ldr	w27, [x22, #248]
	mov	w28, #134217728                 ; =0x8000000
	mov	w26, #33554432                  ; =0x2000000
LBB217_9:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x25], #24
	cmp	w8, w27
	b.hs	LBB217_49
; %bb.10:                               ;   in Loop: Header=BB217_9 Depth=1
	ldr	x9, [x22, #13360]
	cmp	x9, x28
	b.hi	LBB217_28
; %bb.11:                               ;   in Loop: Header=BB217_9 Depth=1
	ldr	x9, [x22, #240]
	ldr	w2, [x9, x8, lsl #2]
	ldr	x9, [x22, #13368]
	sub	x10, x26, x9
	cmp	x9, x26
	ccmp	x10, x2, #0, ls
	b.ls	LBB217_28
; %bb.12:                               ;   in Loop: Header=BB217_9 Depth=1
	add	x10, x2, #1
	add	x9, x10, x9
	str	x9, [x22, #13368]
	ldr	x9, [x22, #232]
	ldr	x0, [x9, x8, lsl #3]
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbnz	x0, LBB217_47
; %bb.13:                               ;   in Loop: Header=BB217_9 Depth=1
	subs	x24, x24, #1
	b.ne	LBB217_9
LBB217_14:
	sturb	wzr, [x29, #-105]
	mov	w8, #9768                       ; =0x2628
	sub	x9, x29, #104
	cmp	x21, #0
	csel	x9, xzr, x9, eq
	stp	xzr, xzr, [sp, #16]
	sub	x10, x29, #105
	stp	x9, x10, [sp]
	add	x5, x22, x8
	add	x7, x20, #8
	mov	x8, x19
	mov	x0, x22
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	mov	w6, #0                          ; =0x0
	bl	_analyze_context_sites
	ldr	w8, [x19]
	cbz	w8, LBB217_19
; %bb.15:
	ldur	x0, [x29, #-104]
	bl	_free
	mov	x0, x20
	bl	_nvm_record_map_execution_free
	b	LBB217_50
LBB217_16:
	mov	w8, #3                          ; =0x3
	str	w8, [x19]
	b	LBB217_50
LBB217_17:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	b	LBB217_50
LBB217_18:
	mov	w8, #4                          ; =0x4
	str	w8, [x19]
	bl	_nvm_record_array_execution_free
	mov	x0, #0                          ; =0x0
	bl	_nvm_record_map_frozen_free
	mov	x0, x20
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	b	_free
LBB217_19:
	cbz	x21, LBB217_25
; %bb.20:
	ldr	x8, [x22, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB217_28
; %bb.21:
	ldr	x9, [x22, #13368]
	mov	w10, #33554432                  ; =0x2000000
	cmp	x9, x10
	b.hi	LBB217_28
; %bb.22:
	ldur	w12, [x29, #-96]
	lsl	x11, x12, #4
	mov	w13, #134217728                 ; =0x8000000
	sub	x13, x13, x8
	cmp	x11, x13
	b.hi	LBB217_28
; %bb.23:
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #3
	sub	x10, x10, x9
	cmp	x12, x10
	b.hi	LBB217_28
; %bb.24:
	add	x8, x11, x8
	str	x8, [x22, #13360]
	add	x9, x9, x12
	str	x9, [x22, #13368]
	b	LBB217_26
LBB217_25:
	ldr	x8, [x22, #13360]
LBB217_26:
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB217_28
; %bb.27:
	ldr	x8, [x22, #13368]
	mov	w9, #65281                      ; =0xff01
	movk	w9, #511, lsl #16
	cmp	x8, x9
	b.lo	LBB217_29
LBB217_28:
	mov	w8, #3                          ; =0x3
	b	LBB217_48
LBB217_29:
	mov	w24, #0                         ; =0x0
	add	x8, x8, #256
	str	x8, [x22, #13368]
	mov	w25, #1                         ; =0x1
	mov	w27, #15                        ; =0xf
	movk	w27, #40704, lsl #16
LBB217_30:                              ; =>This Inner Loop Header: Depth=1
	cmp	w24, #108
	b.ne	LBB217_32
LBB217_31:                              ;   in Loop: Header=BB217_30 Depth=1
	mov	w26, #0                         ; =0x0
	b	LBB217_37
LBB217_32:                              ;   in Loop: Header=BB217_30 Depth=1
	mov	x0, x24
	bl	_supported
	mov	w26, #1                         ; =0x1
	cbnz	w0, LBB217_37
; %bb.33:                               ;   in Loop: Header=BB217_30 Depth=1
	sub	w8, w24, #96
	cmp	w8, #31
	b.hi	LBB217_35
; %bb.34:                               ;   in Loop: Header=BB217_30 Depth=1
	lsl	w8, w25, w8
	tst	w8, w27
	b.ne	LBB217_37
LBB217_35:                              ;   in Loop: Header=BB217_30 Depth=1
	sub	w8, w24, #251
	cmp	w8, #3
	b.lo	LBB217_37
; %bb.36:                               ;   in Loop: Header=BB217_30 Depth=1
	cmp	w24, #51
	b.ne	LBB217_31
LBB217_37:                              ;   in Loop: Header=BB217_30 Depth=1
	add	x1, sp, #72
	mov	x0, x24
	bl	_rme_recipe
	cmp	w26, w0
	b.ne	LBB217_47
; %bb.38:                               ;   in Loop: Header=BB217_30 Depth=1
	add	w24, w24, #1
	cmp	w24, #256
	b.ne	LBB217_30
; %bb.39:
	ldur	x25, [x20, #8]
	ldr	x8, [x25]
	cbz	x8, LBB217_49
; %bb.40:
	ldr	x0, [x8]
	add	x1, sp, #52
	bl	_nvm_ownership_declarations_counts
	cbz	w0, LBB217_49
; %bb.41:
	ldr	w8, [sp, #52]
	cmp	w8, #256
	b.hi	LBB217_49
; %bb.42:
	ldr	x9, [x22, #13360]
	mov	w10, #134217728                 ; =0x8000000
	cmp	x9, x10
	b.hi	LBB217_28
; %bb.43:
	ldr	x9, [x22, #13368]
	mov	w10, #33554432                  ; =0x2000000
	cmp	x9, x10
	b.hi	LBB217_28
; %bb.44:
	lsl	x11, x8, #2
	sub	x10, x10, x9
	cmp	x10, x11
	b.lo	LBB217_28
; %bb.45:
	add	x9, x9, x11
	str	x9, [x22, #13368]
	cbz	w8, LBB217_56
; %bb.46:
	mov	w24, #0                         ; =0x0
	mov	w8, #10280                      ; =0x2828
	add	x26, x22, x8
	mov	w27, #12                        ; =0xc
	b	LBB217_52
LBB217_47:
	mov	w8, #1                          ; =0x1
LBB217_48:
	str	w8, [x22, #13376]
LBB217_49:
	ldr	w8, [x22, #13376]
	str	w8, [x19]
Lloh818:
	adrp	x8, l_.str.180@PAGE
Lloh819:
	add	x8, x8, l_.str.180@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldr	q0, [x8, #32]
	stur	q0, [x19, #44]
	ldur	x8, [x8, #46]
	stur	x8, [x19, #58]
	ldur	x0, [x29, #-104]
	bl	_free
	ldr	x0, [x20]
	bl	_nvm_record_array_execution_free
	ldr	x0, [x20, #8]
	bl	_nvm_record_map_frozen_free
	ldr	x0, [x20, #16]
	bl	_free
	mov	x0, x20
	bl	_free
LBB217_50:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB217_51:                              ;   in Loop: Header=BB217_52 Depth=1
	add	w24, w24, #1
	ldr	w8, [sp, #52]
	cmp	w24, w8
	b.hs	LBB217_56
LBB217_52:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x25]
	cbz	x8, LBB217_49
; %bb.53:                               ;   in Loop: Header=BB217_52 Depth=1
	ldr	x0, [x8]
	add	x2, sp, #72
	mov	x1, x24
	bl	_nvm_ownership_declarations_layout
	cbz	w0, LBB217_49
; %bb.54:                               ;   in Loop: Header=BB217_52 Depth=1
	ldrb	w8, [sp, #72]
	cbnz	w8, LBB217_51
; %bb.55:                               ;   in Loop: Header=BB217_52 Depth=1
	ldr	w8, [x22, #528]
	add	w9, w8, #1
	str	w9, [x22, #528]
	umaddl	x9, w8, w27, x26
	ldrh	w10, [sp, #74]
	stp	w8, w24, [x9]
	strh	w10, [x9, #8]
	strh	wzr, [x9, #10]
	b	LBB217_51
LBB217_56:
	ldr	w8, [x22, #528]
	ldr	w9, [x22, #468]
	cmp	w8, w9
	b.ne	LBB217_49
; %bb.57:
Lloh820:
	adrp	x1, _rme_recipe@PAGE
Lloh821:
	add	x1, x1, _rme_recipe@PAGEOFF
	mov	x0, x22
	mov	w2, #0                          ; =0x0
	bl	_rae_instructions_policy
	cbz	w0, LBB217_49
; %bb.58:
	ldr	w1, [x22, #492]
	mov	x0, x22
	mov	w2, #80                         ; =0x50
	bl	_rae_zero
	mov	x24, x0
	str	x0, [x20, #16]
	ldr	w27, [x22, #492]
	cbnz	x0, LBB217_60
; %bb.59:
	cbnz	w27, LBB217_49
LBB217_60:
	ldr	x8, [x22, #13360]
	mov	w9, #134217728                  ; =0x8000000
	cmp	x8, x9
	b.hi	LBB217_28
; %bb.61:
	ldr	x8, [x22, #13368]
	mov	w9, #33554432                   ; =0x2000000
	cmp	x8, x9
	b.hi	LBB217_28
; %bb.62:
	lsl	x10, x27, #2
	sub	x9, x9, x8
	cmp	x10, x9
	b.hi	LBB217_28
; %bb.63:
	add	x8, x8, x10
	str	x8, [x22, #13368]
	cbz	w27, LBB217_66
; %bb.64:
	mov	x26, #0                         ; =0x0
	ldurb	w25, [x29, #-105]
	ldr	x28, [x22, #13352]
LBB217_65:                              ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x28]
	str	q0, [x24]
	ldp	q0, q1, [x28, #16]
	ldr	q2, [x28, #48]
	ldr	x8, [x28, #64]
	str	x8, [x24, #64]
	stp	q1, q2, [x24, #32]
	str	q0, [x24, #16]
	mov	x0, x24
	mov	x1, x25
	bl	_rme_tags
	add	x26, x26, #1
	add	x24, x24, #80
	add	x28, x28, #72
	cmp	x26, x27
	b.lo	LBB217_65
LBB217_66:
	mov	x0, x22
	mov	x1, x23
	bl	_rae_same
	cbz	w0, LBB217_49
; %bb.67:
	cbz	x21, LBB217_69
; %bb.68:
	ldur	w8, [x29, #-96]
	ldr	w9, [x22, #496]
	cmp	w8, w9
	b.ne	LBB217_49
LBB217_69:
	ldr	w8, [x22, #248]
	str	w8, [x22, #512]
	ldr	w8, [x22, #224]
	str	w8, [x22, #516]
	ldr	w8, [x22, #368]
	str	w8, [x22, #520]
	ldr	w8, [x22, #384]
	str	w8, [x22, #524]
	ldr	w8, [x22, #272]
	str	w8, [x22, #488]
	ldr	w8, [x22, #12]
	str	w8, [x22, #504]
	mov	w8, #1024                       ; =0x400
	str	w8, [x22, #508]
	add	x8, x22, #536
	ldr	q0, [x22, #13360]
	str	q0, [x8]
	cbz	x21, LBB217_71
; %bb.70:
	ldur	q0, [x29, #-104]
	str	q0, [x21]
LBB217_71:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x20, [x8]
	str	wzr, [x19]
	mov	w8, #28271                      ; =0x6e6f
	movk	w8, #46, lsl #16
	stur	w8, [x19, #75]
Lloh822:
	adrp	x8, l_.str.179@PAGE
Lloh823:
	add	x8, x8, l_.str.179@PAGEOFF
	ldp	q0, q1, [x8]
	stur	q0, [x19, #12]
	stur	q1, [x19, #28]
	ldp	q0, q1, [x8, #32]
	stur	q0, [x19, #44]
	stur	q1, [x19, #60]
	b	LBB217_50
	.loh AdrpAdd	Lloh816, Lloh817
	.loh AdrpAdd	Lloh818, Lloh819
	.loh AdrpAdd	Lloh820, Lloh821
	.loh AdrpAdd	Lloh822, Lloh823
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rme_tags
_rme_tags:                              ; @rme_tags
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0, #31]
	cmp	w8, #255
	b.eq	LBB218_2
LBB218_1:
	ret
LBB218_2:
	mov	w8, #32                         ; =0x20
	strh	w8, [x0, #72]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w1
	strh	w9, [x0, #74]
	ldrb	w8, [x0, #30]
	cmp	w8, #122
	b.gt	LBB218_7
; %bb.3:
	cmp	w8, #120
	b.eq	LBB218_11
; %bb.4:
	cmp	w8, #121
	b.eq	LBB218_13
; %bb.5:
	cmp	w8, #122
	b.ne	LBB218_1
; %bb.6:
	mov	w8, #2                          ; =0x2
	b	LBB218_15
LBB218_7:
	cmp	w8, #123
	b.eq	LBB218_12
; %bb.8:
	cmp	w8, #124
	b.eq	LBB218_14
; %bb.9:
	cmp	w8, #127
	b.ne	LBB218_1
; %bb.10:
	mov	w8, #5                          ; =0x5
	strb	w8, [x0, #78]
	mov	w8, #2                          ; =0x2
	strh	w8, [x0, #76]
	ret
LBB218_11:
	mov	w8, #1                          ; =0x1
	b	LBB218_15
LBB218_12:
	mov	w8, #4                          ; =0x4
	strb	w8, [x0, #78]
	mov	w8, #16                         ; =0x10
	strh	w8, [x0, #76]
	ret
LBB218_13:
	mov	w8, #3                          ; =0x3
	strb	w8, [x0, #78]
	orr	w8, w9, #0x1
	strh	w8, [x0, #76]
	ret
LBB218_14:
	mov	w8, #6                          ; =0x6
LBB218_15:
	strb	w8, [x0, #78]
	mov	w8, #8192                       ; =0x2000
	strh	w8, [x0, #76]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function rme_frozen_retained_cost
_rme_frozen_retained_cost:              ; @rme_frozen_retained_cost
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x1, #16]
	tbnz	w8, #0, LBB219_2
; %bb.1:
	ldp	x9, x10, [x1]
	subs	x8, x10, x9
	ccmp	x8, #15, #0, hs
	b.hi	LBB219_3
LBB219_2:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
	mov	w0, #2                          ; =0x2
	ret
LBB219_3:
	add	x11, x9, #16
	str	x11, [x1]
	cbz	x0, LBB219_18
; %bb.4:
	ldr	x8, [x0]
	cbz	x8, LBB219_18
; %bb.5:
	ldr	x12, [x8, #8]
	cbz	x12, LBB219_18
; %bb.6:
	ldr	x8, [x8]
	cbz	x8, LBB219_18
; %bb.7:
	ldr	x8, [x0, #8]
	cbz	x8, LBB219_18
; %bb.8:
	ldr	w13, [x0, #24]
	cmp	w13, #64
	b.hi	LBB219_18
; %bb.9:
	ldr	w8, [x0, #28]
	cmp	w8, w13
	b.hi	LBB219_18
; %bb.10:
	ldr	w14, [x0, #32]
	cmp	w14, #16, lsl #12               ; =65536
	b.hi	LBB219_18
; %bb.11:
	ldr	w15, [x12]
	cmp	w15, w13
	b.ne	LBB219_18
; %bb.12:
	ldr	w12, [x12, #4]
	cmp	w12, w14
	b.ne	LBB219_18
; %bb.13:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	subs	x10, x10, x11
	b.lo	LBB219_19
; %bb.14:
	cmp	x10, #3
	b.ls	LBB219_19
; %bb.15:
	mov	x20, x2
	add	x9, x9, #20
	str	x9, [x1]
	mov	w9, #56                         ; =0x38
	str	x9, [sp, #8]
	mov	x21, x0
	ldr	x9, [x0, #16]
	add	x4, sp, #8
	mov	x19, x1
	mov	x0, x1
	mov	x1, x9
	mov	x2, x8
	mov	w3, #8                          ; =0x8
	bl	_nvm_map_copy_term
	cbnz	w0, LBB219_21
; %bb.16:
	mov	x9, x19
	ldrb	w8, [x19, #16]
	tbz	w8, #0, LBB219_22
LBB219_17:
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #16]
	b	LBB219_20
LBB219_18:
	mov	w0, #1                          ; =0x1
	ret
LBB219_19:
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #16]
LBB219_20:
	mov	w0, #2                          ; =0x2
LBB219_21:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB219_22:
	ldp	x8, x10, [x9]
	subs	x11, x10, x8
	b.lo	LBB219_17
; %bb.23:
	cmp	x11, #3
	b.ls	LBB219_17
; %bb.24:
	ldr	x11, [x21]
	add	x12, x8, #4
	str	x12, [x9]
	cbz	x11, LBB219_36
; %bb.25:
	ldr	x9, [sp, #8]
	cmn	x9, #185
	b.hi	LBB219_20
; %bb.26:
	subs	x10, x10, x12
	b.lo	LBB219_37
; %bb.27:
	cmp	x10, #3
	b.ls	LBB219_37
; %bb.28:
	ldr	x10, [x11, #8]
	add	x8, x8, #8
	str	x8, [x19]
	cbz	x10, LBB219_36
; %bb.29:
	cmn	x9, #3289
	b.hi	LBB219_20
; %bb.30:
	add	x8, x9, #3288
	str	x8, [sp, #8]
	ldr	x1, [x10, #3096]
	ldr	w2, [x21, #32]
	add	x4, sp, #8
	mov	x0, x19
	mov	w3, #16                         ; =0x10
	bl	_nvm_map_copy_term
	cbnz	w0, LBB219_21
; %bb.31:
	ldr	x8, [x21]
	ldr	x0, [x8]
	mov	x2, sp
	mov	x1, x19
	bl	_nvm_ownership_declarations_retained_cost
	cbnz	w0, LBB219_21
; %bb.32:
	ldp	x22, x23, [sp]
	cmn	x23, x22
	b.hs	LBB219_20
; %bb.33:
	ldr	x0, [x21, #8]
	mov	x2, sp
	mov	x1, x19
	bl	_nvm_map_declarations_retained_cost
	cbnz	w0, LBB219_21
; %bb.34:
	ldr	x8, [sp]
	add	x9, x23, x22
	cmn	x9, x8
	b.hs	LBB219_20
; %bb.35:
	mov	w0, #0                          ; =0x0
	add	x8, x9, x8
	str	x8, [x20]
	b	LBB219_21
LBB219_36:
	mov	w0, #1                          ; =0x1
	b	LBB219_21
LBB219_37:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #16]
	b	LBB219_20
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an array-mode output."

l_.str.1:                               ; @.str.1
	.asciz	"I require a module and heap-plan output."

l_.str.2:                               ; @.str.2
	.asciz	"%s"

l_.str.3:                               ; @.str.3
	.asciz	"I require checked ordinary record authority."

l_.str.4:                               ; @.str.4
	.asciz	"I could not publish my managed heap plan."

l_.str.5:                               ; @.str.5
	.asciz	"I require a stable original module and plan output."

l_.str.6:                               ; @.str.6
	.asciz	"I copied complete execution facts; I grant no executable admission."

l_.str.7:                               ; @.str.7
	.asciz	"I could not prepare bounded exact mixed execution facts."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.nvm_record_array_image_copy.result
l___const.nvm_record_array_image_copy.result:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require a copied plan and image output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.8:                               ; @.str.8
	.asciz	"I copied an exact private image without executable admission."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.nvm_union_field_image_copy_reserved.result
l___const.nvm_union_field_image_copy_reserved.result:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require an immutable union plan and image output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.9:                               ; @.str.9
	.asciz	"I require source union facts to match independent reconstruction."

l_.str.10:                              ; @.str.10
	.asciz	"I independently copied descriptive union facts without execution authority."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.nvm_record_array_admit.result
l___const.nvm_record_array_admit.result:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require a complete ordinary array-field candidate.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.11:                              ; @.str.11
	.asciz	"I require a standalone integer-result record-array entry."

l_.str.12:                              ; @.str.12
	.asciz	"I require aggregate record opcodes shared by both public runtimes."

l_.str.13:                              ; @.str.13
	.asciz	"I require an identity record-layout projection for public execution."

l_.str.14:                              ; @.str.14
	.asciz	"I require a scalar initializer for record-array execution."

	.section	__TEXT,__const
l_.str.15:                              ; @.str.15
	.asciz	"I require a map proof output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.p2align	2, 0x0                          ; @__const.nvm_record_map_admit.r
l___const.nvm_record_map_admit.r:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require complete ordinary map-field authority.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.16:                              ; @.str.16
	.asciz	"I require a zero-argument INT map entry and VOID/INT initializer."

l_.str.17:                              ; @.str.17
	.asciz	"I require a closed copied native map module."

l_.str.18:                              ; @.str.18
	.asciz	"I require a capture-free zero-argument INT native map entry."

l_.str.19:                              ; @.str.19
	.asciz	"I require a zero-argument VOID/INT native map initializer."

l_.str.20:                              ; @.str.20
	.asciz	"I require identical native record ordinal and layout identities."

l_.str.21:                              ; @.str.21
	.asciz	"I have not qualified this native map string producer or STRUCT transport."

l_.str.22:                              ; @.str.22
	.asciz	"I require NUL-free executable native map string literals."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.nvm_record_map_publication.result
l___const.nvm_record_map_publication.result:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require established map publication eligibility.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.p2align	2, 0x0                          ; @__const.analyze_context_sites.early
l___const.analyze_context_sites.early:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require a module and report output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.23:                              ; @.str.23
	.asciz	"I could not allocate array analysis state."

l_.str.24:                              ; @.str.24
	.asciz	"I could not allocate union proof state."

l_.str.25:                              ; @.str.25
	.asciz	"I could not allocate map proof state."

l_.str.26:                              ; @.str.26
	.asciz	"I reached my array analysis function limit."

l_.str.27:                              ; @.str.27
	.asciz	"I require a closed zero-argument entry without nominal, ownership or host contracts."

l_.str.28:                              ; @.str.28
	.asciz	"I require exact portable file-read imports."

l_.str.29:                              ; @.str.29
	.asciz	"I reached my array analysis local limit."

l_.str.30:                              ; @.str.30
	.asciz	"I require no captures and at most one result."

l_.str.31:                              ; @.str.31
	.asciz	"__init__"

l_.str.32:                              ; @.str.32
	.asciz	"I require a zero-argument initializer."

l_.str.33:                              ; @.str.33
	.asciz	"I require decodable instructions."

l_.str.34:                              ; @.str.34
	.asciz	"I reached my decoded instruction limit."

l_.str.35:                              ; @.str.35
	.asciz	"I have no proved transfer for this instruction."

l_.str.36:                              ; @.str.36
	.asciz	"I reached my array analysis global limit."

l_.str.37:                              ; @.str.37
	.asciz	"I reached my array analysis stack limit."

l_.str.38:                              ; @.str.38
	.asciz	"I reached my stored abstract-state cell limit."

l_.str.39:                              ; @.str.39
	.asciz	"I could not allocate my bounded function analysis."

l_.str.40:                              ; @.str.40
	.asciz	"I require map creation to match the exact copied STRING-keyed pair."

l_.str.41:                              ; @.str.41
	.asciz	"I reached my shared origin limit."

l_.str.42:                              ; @.str.42
	.asciz	"I have not qualified this declared array shape."

l_.str.43:                              ; @.str.43
	.asciz	"I reached my allocation-site origin limit."

l_.str.44:                              ; @.str.44
	.asciz	"I could not allocate my record field summaries."

l_.str.45:                              ; @.str.45
	.asciz	"I could not copy historical global obligations."

l_.str.46:                              ; @.str.46
	.asciz	"I require exact historical global obligations."

l_.str.47:                              ; @.str.47
	.asciz	"I could not publish my graph analysis report."

l_.str.48:                              ; @.str.48
	.asciz	"I could not publish my array analysis report."

l_.str.49:                              ; @.str.49
	.asciz	"I established copied union-field origin obligations, not execution admission."

l_.str.50:                              ; @.str.50
	.asciz	"I established copied exact map origin obligations, not execution admission."

l_.str.51:                              ; @.str.51
	.asciz	"I established only the bounded portable array-shape obligations."

l_.str.52:                              ; @.str.52
	.asciz	"%.*s"

l_.str.53:                              ; @.str.53
	.asciz	"I require copied map counts."

l_.str.54:                              ; @.str.54
	.asciz	"I require one exact STRING-keyed declaration pair."

l_.str.55:                              ; @.str.55
	.asciz	"I require exact map pair referents."

l_.str.56:                              ; @.str.56
	.asciz	"I prove only exact STRING-to-INT or STRING-to-STRING maps."

l_.str.57:                              ; @.str.57
	.asciz	"allocat"

l_.str.58:                              ; @.str.58
	.asciz	"memory"

l_.str.59:                              ; @.str.59
	.asciz	"file_read"

l_.str.60:                              ; @.str.60
	.asciz	"vm_file_read"

l_.str.61:                              ; @.str.61
	.asciz	"nl_os_file_read"

l_.str.62:                              ; @.str.62
	.asciz	"_bytes"

l_.str.63:                              ; @.str.63
	.asciz	"I could not copy union record mappings."

l_.str.64:                              ; @.str.64
	.asciz	"I could not copy union layout mappings."

l_.str.65:                              ; @.str.65
	.asciz	"I require an exact copied record nominal."

l_.str.66:                              ; @.str.66
	.asciz	"I require the exact union-field layout rows."

l_.str.67:                              ; @.str.67
	.asciz	"I could not copy a union layout field."

l_.str.68:                              ; @.str.68
	.asciz	"I require a copied union field."

l_.str.69:                              ; @.str.69
	.asciz	"I require explicit ordinary record authority."

l_.str.70:                              ; @.str.70
	.asciz	"I require ordinary declarations without affine/reference execution."

l_.str.71:                              ; @.str.71
	.asciz	"I require the bounded scalar/string/acyclic-record field schema."

l_.str.72:                              ; @.str.72
	.asciz	"I require complete declaration counts."

l_.str.73:                              ; @.str.73
	.asciz	"I could not allocate copied record maps."

l_.str.74:                              ; @.str.74
	.asciz	"I could not allocate copied layout maps."

l_.str.75:                              ; @.str.75
	.asciz	"I require a copied declaration row."

l_.str.76:                              ; @.str.76
	.asciz	"I reached my copied field bound."

l_.str.77:                              ; @.str.77
	.asciz	"I require complete ordinary records."

l_.str.78:                              ; @.str.78
	.asciz	"I require validated ordinary records and scalar union declarations."

l_.str.79:                              ; @.str.79
	.asciz	"I could not copy declaration fields."

l_.str.80:                              ; @.str.80
	.asciz	"I require each copied field fact."

l_.str.81:                              ; @.str.81
	.asciz	"I require the original nominal record count."

l_.str.82:                              ; @.str.82
	.asciz	"I could not copy field element constraints."

l_.str.83:                              ; @.str.83
	.asciz	"I require exact copied array bindings."

l_.str.84:                              ; @.str.84
	.asciz	"I require exact nested primitive element authority."

l_.str.85:                              ; @.str.85
	.asciz	"I require exact depth-three primitive authority."

l_.str.86:                              ; @.str.86
	.asciz	"I could not copy nested STRING field constraints."

l_.str.87:                              ; @.str.87
	.asciz	"I require exact bounded field element tags."

l_.str.88:                              ; @.str.88
	.asciz	"I require every array field binding."

l_.str.89:                              ; @.str.89
	.asciz	"I require the bounded ordinary record field schema."

l_.str.90:                              ; @.str.90
	.asciz	"I could not allocate private global flow."

l_.str.91:                              ; @.str.91
	.asciz	"I reached my global flow slot bound."

l_.str.92:                              ; @.str.92
	.asciz	"I reached my global exit cell bound."

l_.str.93:                              ; @.str.93
	.asciz	"I could not allocate global exits."

l_.str.94:                              ; @.str.94
	.asciz	"I reached my global scratch peak bound."

l_.str.95:                              ; @.str.95
	.asciz	"I require a closed global-flow call."

l_.str.96:                              ; @.str.96
	.asciz	"I could not allocate my tail call graph."

l_.str.97:                              ; @.str.97
	.asciz	"I require a closed direct tail graph."

l_.str.98:                              ; @.str.98
	.asciz	"I require a singleton self-tail component."

l_.str.99:                              ; @.str.99
	.asciz	"I refuse ordinary self CALL in a self-tail component."

l_.str.100:                             ; @.str.100
	.asciz	"I require an acyclic direct tail edge."

l_.str.101:                             ; @.str.101
	.asciz	"I reached my record-array work bound."

l_.str.102:                             ; @.str.102
	.asciz	"I require an exact nominal variant construction."

l_.str.103:                             ; @.str.103
	.asciz	"I reached my shared union origin bound."

l_.str.104:                             ; @.str.104
	.asciz	"I require neutral-variant record construction."

l_.str.105:                             ; @.str.105
	.asciz	"I require an authoritative record ordinal."

l_.str.106:                             ; @.str.106
	.asciz	"I require the actual constructed field count to match its record."

l_.str.107:                             ; @.str.107
	.asciz	"I reached my record origin or field-summary limit."

l_.str.108:                             ; @.str.108
	.asciz	"I require bounded abstract stack successors."

l_.str.109:                             ; @.str.109
	.asciz	"I require equal stack heights at joins."

l_.str.110:                             ; @.str.110
	.asciz	"I require the declared result depth at an implicit return."

l_.str.111:                             ; @.str.111
	.asciz	"I require the declared result depth at an explicit return."

l_.str.112:                             ; @.str.112
	.asciz	"I require exactly the direct tail arguments."

l_.str.113:                             ; @.str.113
	.asciz	"I require a verified bounded instruction stack effect."

l_.str.114:                             ; @.str.114
	.asciz	"I require portable import authority."

l_.str.115:                             ; @.str.115
	.asciz	"I require map proof context."

l_.str.116:                             ; @.str.116
	.asciz	"I require exact known union-field value tags."

l_.str.117:                             ; @.str.117
	.asciz	"I refuse scalar heap origins."

l_.str.118:                             ; @.str.118
	.asciz	"I require exact union-field nominal origins."

l_.str.119:                             ; @.str.119
	.asciz	"I require complete union-field origins."

l_.str.120:                             ; @.str.120
	.asciz	"I cannot resolve this reachable union-field receiver."

l_.str.121:                             ; @.str.121
	.asciz	"I require the exact containing record field."

l_.str.122:                             ; @.str.122
	.asciz	"I cannot resolve this historical union write."

l_.str.123:                             ; @.str.123
	.asciz	"I have not qualified union payload mutation."

l_.str.124:                             ; @.str.124
	.asciz	"I require the sole INT payload field."

l_.str.125:                             ; @.str.125
	.asciz	"I refuse an empty variant at payload access."

l_.str.126:                             ; @.str.126
	.asciz	"I cannot resolve this reachable union-field result."

l_.str.127:                             ; @.str.127
	.asciz	"I reached my derived array origin limit."

l_.str.128:                             ; @.str.128
	.asciz	"I cannot resolve an escaped global value."

l_.str.129:                             ; @.str.129
	.asciz	"I require exact ordinary result tags."

l_.str.130:                             ; @.str.130
	.asciz	"I cannot resolve this function result or return path."

l_.str.131:                             ; @.str.131
	.asciz	"I cannot resolve this reachable direct-call return."

l_.str.132:                             ; @.str.132
	.asciz	"I require exact known direct-call parameter tags."

l_.str.133:                             ; @.str.133
	.asciz	"I require authoritative array origins."

l_.str.134:                             ; @.str.134
	.asciz	"I cannot resolve the array index tags."

l_.str.135:                             ; @.str.135
	.asciz	"I require the verified map stack effect."

l_.str.136:                             ; @.str.136
	.asciz	"I require exact known map origins."

l_.str.137:                             ; @.str.137
	.asciz	"I refuse non-map receiver origins."

l_.str.138:                             ; @.str.138
	.asciz	"I refuse unknown map origin bits."

l_.str.139:                             ; @.str.139
	.asciz	"I require exact map key/value scalar tags."

l_.str.140:                             ; @.str.140
	.asciz	"I require exact known field-write tags."

l_.str.141:                             ; @.str.141
	.asciz	"I require complete field array origins and element identity."

l_.str.142:                             ; @.str.142
	.asciz	"I require the exact field element contract."

l_.str.143:                             ; @.str.143
	.asciz	"I refuse conflicting field element constraints."

l_.str.144:                             ; @.str.144
	.asciz	"I require authoritative nested record origins."

l_.str.145:                             ; @.str.145
	.asciz	"I require the exact nested nominal identity for every field write."

l_.str.146:                             ; @.str.146
	.asciz	"I require authoritative record receiver origins."

l_.str.147:                             ; @.str.147
	.asciz	"I require a valid field in every possible record receiver."

l_.str.148:                             ; @.str.148
	.asciz	"I require proved scalar/string/array graph writes."

l_.str.149:                             ; @.str.149
	.asciz	"I require proved scalar/string leaf writes."

l_.str.150:                             ; @.str.150
	.asciz	"I require authoritative child array origins."

l_.str.151:                             ; @.str.151
	.asciz	"I cannot prove a portable packed write for every possible tag."

l_.str.152:                             ; @.str.152
	.asciz	"I reached the union site count bound."

l_.str.153:                             ; @.str.153
	.asciz	"I could not copy final union sites."

l_.str.154:                             ; @.str.154
	.asciz	"I require exact final union site correspondence."

l_.str.155:                             ; @.str.155
	.asciz	"I require complete bounded historical union summaries."

l_.str.156:                             ; @.str.156
	.asciz	"I require matching historical union origin kinds."

l_.str.157:                             ; @.str.157
	.asciz	"I require every historical heap tag to have exact origins."

l_.str.158:                             ; @.str.158
	.asciz	"I have not qualified other heap origins with union fields."

l_.str.159:                             ; @.str.159
	.asciz	"I could not allocate copied union proof."

l_.str.160:                             ; @.str.160
	.asciz	"I could not allocate copied union rows."

l_.str.161:                             ; @.str.161
	.asciz	"I require copied nominal identity during union freeze."

l_.str.162:                             ; @.str.162
	.asciz	"I require proved nested array children."

l_.str.163:                             ; @.str.163
	.asciz	"I require each nested child to preserve its exact primitive leaf."

l_.str.164:                             ; @.str.164
	.asciz	"I require exact flat or bounded depth-two array content."

l_.str.165:                             ; @.str.165
	.asciz	"I require every aliased array write to preserve its exact field element type."

l_.str.166:                             ; @.str.166
	.asciz	"I could not allocate bounded depth-three shape domains."

l_.str.167:                             ; @.str.167
	.asciz	"I reached my depth-three closure bound."

l_.str.168:                             ; @.str.168
	.asciz	"I require acyclic exact depth-three primitive origins and every historical write."

l_.str.169:                             ; @.str.169
	.asciz	"I keep standalone map globals outside this field profile."

l_.str.170:                             ; @.str.170
	.asciz	"I require every historical map write to preserve its exact pair."

l_.str.171:                             ; @.str.171
	.asciz	"I could not allocate frozen map facts."

l_.str.172:                             ; @.str.172
	.asciz	"I could not copy map origin rows."

l_.str.173:                             ; @.str.173
	.asciz	"I could not allocate the origin report."

l_.str.174:                             ; @.str.174
	.asciz	"I could not publish my record analysis report."

l_.str.175:                             ; @.str.175
	.asciz	"I could not publish my record field summaries."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.ufe_prepare_reserved.result
l___const.ufe_prepare_reserved.result:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require a module and copied union recipe output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.176:                             ; @.str.176
	.asciz	"I copied union recipes without executable admission."

l_.str.177:                             ; @.str.177
	.asciz	"I could not copy exact bounded union recipes."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.rme_prepare_boundary.result
l___const.rme_prepare_boundary.result:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require an original module and copied map plan output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.179:                             ; @.str.179
	.asciz	"I copied exact map execution recipes without executable admission."

l_.str.180:                             ; @.str.180
	.asciz	"I could not copy bounded exact map execution recipes."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.rmb_prepare_reserved.r
l___const.rmb_prepare_reserved.r:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require an original module and boundary output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_.str.181:                             ; @.str.181
	.asciz	"I could not allocate my copied boundary owner."

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @__const.rme_image_copy_reserved.result
l___const.rme_image_copy_reserved.result:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.asciz	"I require a copied map plan and image output.\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

	.p2align	3, 0x0                          ; @__const.rme_image_copy_reserved.w
l___const.rme_image_copy_reserved.w:
	.quad	0                               ; 0x0
	.quad	33554432                        ; 0x2000000
	.byte	0                               ; 0x0
	.space	7

	.section	__TEXT,__cstring,cstring_literals
l_.str.182:                             ; @.str.182
	.asciz	"I independently copied map image facts without executable admission."

.subsections_via_symbols
