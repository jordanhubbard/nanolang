	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nl_utf8_validate       ; -- Begin function nl_utf8_validate
	.globl	_nl_utf8_validate
	.p2align	2
_nl_utf8_validate:                      ; @nl_utf8_validate
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB0_2
; %bb.1:
	str	xzr, [x2]
LBB0_2:
	cbz	x1, LBB0_32
; %bb.3:
	cbz	x0, LBB0_35
; %bb.4:
	mov	x8, #0                          ; =0x0
	b	LBB0_7
LBB0_5:                                 ;   in Loop: Header=BB0_7 Depth=1
	add	x14, x8, #1
LBB0_6:                                 ;   in Loop: Header=BB0_7 Depth=1
	mov	x8, x14
	cmp	x14, x1
	b.hs	LBB0_32
LBB0_7:                                 ; =>This Inner Loop Header: Depth=1
	add	x9, x0, x8
	ldrsb	w10, [x9]
	tbz	w10, #31, LBB0_5
; %bb.8:                                ;   in Loop: Header=BB0_7 Depth=1
	and	w11, w10, #0xff
	sub	w10, w11, #224
	cmn	w10, #31
	b.hi	LBB0_11
; %bb.9:                                ;   in Loop: Header=BB0_7 Depth=1
	cmp	w11, #224
	b.ne	LBB0_12
; %bb.10:                               ;   in Loop: Header=BB0_7 Depth=1
	mov	w11, #191                       ; =0xbf
	mov	w13, #160                       ; =0xa0
	b	LBB0_17
LBB0_11:                                ;   in Loop: Header=BB0_7 Depth=1
	mov	w11, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	mov	w12, #1                         ; =0x1
	mov	w14, #2                         ; =0x2
	b	LBB0_18
LBB0_12:                                ;   in Loop: Header=BB0_7 Depth=1
	sub	w12, w11, #225
	cmp	w12, #12
	b.hs	LBB0_14
LBB0_13:                                ;   in Loop: Header=BB0_7 Depth=1
	mov	w11, #191                       ; =0xbf
	b	LBB0_16
LBB0_14:                                ;   in Loop: Header=BB0_7 Depth=1
	cmp	w11, #237
	b.ne	LBB0_24
; %bb.15:                               ;   in Loop: Header=BB0_7 Depth=1
	mov	w11, #159                       ; =0x9f
LBB0_16:                                ;   in Loop: Header=BB0_7 Depth=1
	mov	w13, #128                       ; =0x80
LBB0_17:                                ;   in Loop: Header=BB0_7 Depth=1
	mov	w12, #1                         ; =0x1
	mov	w14, #3                         ; =0x3
LBB0_18:                                ;   in Loop: Header=BB0_7 Depth=1
	add	x14, x14, x8
	cmp	x14, x1
	b.hi	LBB0_33
; %bb.19:                               ;   in Loop: Header=BB0_7 Depth=1
	ldrb	w15, [x9, #1]
	cmp	w13, w15
	ccmp	w11, w15, #0, ls
	b.lo	LBB0_33
; %bb.20:                               ;   in Loop: Header=BB0_7 Depth=1
	cmn	w10, #30
	b.hs	LBB0_6
; %bb.21:                               ;   in Loop: Header=BB0_7 Depth=1
	ldrsb	w10, [x9, #2]
	cmn	w10, #64
	b.ge	LBB0_33
; %bb.22:                               ;   in Loop: Header=BB0_7 Depth=1
	tbnz	w12, #0, LBB0_6
; %bb.23:                               ;   in Loop: Header=BB0_7 Depth=1
	ldrsb	w9, [x9, #3]
	cmn	w9, #64
	b.lt	LBB0_6
	b	LBB0_33
LBB0_24:                                ;   in Loop: Header=BB0_7 Depth=1
	and	w12, w11, #0xfe
	cmp	w12, #238
	b.eq	LBB0_13
; %bb.25:                               ;   in Loop: Header=BB0_7 Depth=1
	cmp	w11, #240
	b.ne	LBB0_27
; %bb.26:                               ;   in Loop: Header=BB0_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #191                       ; =0xbf
	mov	w13, #144                       ; =0x90
	mov	w14, #4                         ; =0x4
	b	LBB0_18
LBB0_27:                                ;   in Loop: Header=BB0_7 Depth=1
	sub	w12, w11, #241
	cmp	w12, #3
	b.hs	LBB0_29
; %bb.28:                               ;   in Loop: Header=BB0_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #191                       ; =0xbf
	b	LBB0_31
LBB0_29:                                ;   in Loop: Header=BB0_7 Depth=1
	cmp	w11, #244
	b.ne	LBB0_33
; %bb.30:                               ;   in Loop: Header=BB0_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #143                       ; =0x8f
LBB0_31:                                ;   in Loop: Header=BB0_7 Depth=1
	mov	w13, #128                       ; =0x80
	mov	w14, #4                         ; =0x4
	b	LBB0_18
LBB0_32:
	mov	w0, #1                          ; =0x1
	ret
LBB0_33:
	cbz	x2, LBB0_36
; %bb.34:
	mov	w0, #0                          ; =0x0
	str	x8, [x2]
LBB0_35:
	ret
LBB0_36:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_utf8_ok_cstr        ; -- Begin function nl_utf8_ok_cstr
	.globl	_nl_utf8_ok_cstr
	.p2align	2
_nl_utf8_ok_cstr:                       ; @nl_utf8_ok_cstr
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_32
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_strlen
	cbz	x0, LBB1_31
; %bb.2:
	mov	x9, #0                          ; =0x0
	b	LBB1_5
LBB1_3:                                 ;   in Loop: Header=BB1_5 Depth=1
	add	x9, x9, #1
LBB1_4:                                 ;   in Loop: Header=BB1_5 Depth=1
	cmp	x9, x0
	b.hs	LBB1_31
LBB1_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x9
	ldrsb	w8, [x10]
	tbz	w8, #31, LBB1_3
; %bb.6:                                ;   in Loop: Header=BB1_5 Depth=1
	and	w12, w8, #0xff
	sub	w11, w12, #224
	cmn	w11, #31
	b.hi	LBB1_9
; %bb.7:                                ;   in Loop: Header=BB1_5 Depth=1
	cmp	w12, #224
	b.ne	LBB1_10
; %bb.8:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w12, #191                       ; =0xbf
	mov	w13, #160                       ; =0xa0
	b	LBB1_15
LBB1_9:                                 ;   in Loop: Header=BB1_5 Depth=1
	mov	w12, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	mov	w8, #1                          ; =0x1
	mov	w14, #2                         ; =0x2
	b	LBB1_16
LBB1_10:                                ;   in Loop: Header=BB1_5 Depth=1
	sub	w8, w12, #225
	cmp	w8, #12
	b.hs	LBB1_12
LBB1_11:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w12, #191                       ; =0xbf
	b	LBB1_14
LBB1_12:                                ;   in Loop: Header=BB1_5 Depth=1
	cmp	w12, #237
	b.ne	LBB1_22
; %bb.13:                               ;   in Loop: Header=BB1_5 Depth=1
	mov	w12, #159                       ; =0x9f
LBB1_14:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w13, #128                       ; =0x80
LBB1_15:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w8, #1                          ; =0x1
	mov	w14, #3                         ; =0x3
LBB1_16:                                ;   in Loop: Header=BB1_5 Depth=1
	add	x9, x14, x9
	cmp	x9, x0
	b.hi	LBB1_33
; %bb.17:                               ;   in Loop: Header=BB1_5 Depth=1
	ldrb	w14, [x10, #1]
	cmp	w13, w14
	ccmp	w12, w14, #0, ls
	b.lo	LBB1_33
; %bb.18:                               ;   in Loop: Header=BB1_5 Depth=1
	cmn	w11, #30
	b.hs	LBB1_4
; %bb.19:                               ;   in Loop: Header=BB1_5 Depth=1
	ldrsb	w11, [x10, #2]
	cmn	w11, #64
	b.ge	LBB1_33
; %bb.20:                               ;   in Loop: Header=BB1_5 Depth=1
	tbnz	w8, #0, LBB1_4
; %bb.21:                               ;   in Loop: Header=BB1_5 Depth=1
	ldrsb	w8, [x10, #3]
	cmn	w8, #64
	b.lt	LBB1_4
	b	LBB1_33
LBB1_22:                                ;   in Loop: Header=BB1_5 Depth=1
	and	w8, w12, #0xfe
	cmp	w8, #238
	b.eq	LBB1_11
; %bb.23:                               ;   in Loop: Header=BB1_5 Depth=1
	cmp	w12, #240
	b.ne	LBB1_25
; %bb.24:                               ;   in Loop: Header=BB1_5 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w12, #191                       ; =0xbf
	mov	w13, #144                       ; =0x90
	b	LBB1_30
LBB1_25:                                ;   in Loop: Header=BB1_5 Depth=1
	sub	w8, w12, #241
	cmp	w8, #3
	b.hs	LBB1_27
; %bb.26:                               ;   in Loop: Header=BB1_5 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w12, #191                       ; =0xbf
	b	LBB1_29
LBB1_27:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w8, #0                          ; =0x0
	cmp	w12, #244
	b.ne	LBB1_34
; %bb.28:                               ;   in Loop: Header=BB1_5 Depth=1
	mov	w12, #143                       ; =0x8f
LBB1_29:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w13, #128                       ; =0x80
LBB1_30:                                ;   in Loop: Header=BB1_5 Depth=1
	mov	w14, #4                         ; =0x4
	b	LBB1_16
LBB1_31:
	mov	w8, #1                          ; =0x1
	b	LBB1_34
LBB1_32:
	mov	w0, #0                          ; =0x0
	ret
LBB1_33:
	mov	w8, #0                          ; =0x0
LBB1_34:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_utf8_cstr_or_marker ; -- Begin function nl_utf8_cstr_or_marker
	.globl	_nl_utf8_cstr_or_marker
	.p2align	2
_nl_utf8_cstr_or_marker:                ; @nl_utf8_cstr_or_marker
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_34
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_strlen
	cbz	x0, LBB2_32
; %bb.2:
	mov	x8, x0
	mov	x9, #0                          ; =0x0
Lloh0:
	adrp	x0, l_.str.1@PAGE
Lloh1:
	add	x0, x0, l_.str.1@PAGEOFF
	b	LBB2_5
LBB2_3:                                 ;   in Loop: Header=BB2_5 Depth=1
	add	x9, x9, #1
LBB2_4:                                 ;   in Loop: Header=BB2_5 Depth=1
	cmp	x9, x8
	b.hs	LBB2_32
LBB2_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x9
	ldrsb	w11, [x10]
	tbz	w11, #31, LBB2_3
; %bb.6:                                ;   in Loop: Header=BB2_5 Depth=1
	and	w12, w11, #0xff
	sub	w11, w12, #224
	cmn	w11, #31
	b.hi	LBB2_9
; %bb.7:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w12, #224
	b.ne	LBB2_10
; %bb.8:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w12, #191                       ; =0xbf
	mov	w14, #160                       ; =0xa0
	b	LBB2_15
LBB2_9:                                 ;   in Loop: Header=BB2_5 Depth=1
	mov	w12, #191                       ; =0xbf
	mov	w14, #128                       ; =0x80
	mov	w13, #1                         ; =0x1
	mov	w15, #2                         ; =0x2
	b	LBB2_16
LBB2_10:                                ;   in Loop: Header=BB2_5 Depth=1
	sub	w13, w12, #225
	cmp	w13, #12
	b.hs	LBB2_12
LBB2_11:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w12, #191                       ; =0xbf
	b	LBB2_14
LBB2_12:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w12, #237
	b.ne	LBB2_23
; %bb.13:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	w12, #159                       ; =0x9f
LBB2_14:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w14, #128                       ; =0x80
LBB2_15:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w13, #1                         ; =0x1
	mov	w15, #3                         ; =0x3
LBB2_16:                                ;   in Loop: Header=BB2_5 Depth=1
	add	x9, x15, x9
	cmp	x9, x8
	b.hi	LBB2_33
; %bb.17:                               ;   in Loop: Header=BB2_5 Depth=1
	ldrb	w15, [x10, #1]
	cmp	w14, w15
	b.hi	LBB2_33
; %bb.18:                               ;   in Loop: Header=BB2_5 Depth=1
	cmp	w12, w15
	b.lo	LBB2_33
; %bb.19:                               ;   in Loop: Header=BB2_5 Depth=1
	cmn	w11, #30
	b.hs	LBB2_4
; %bb.20:                               ;   in Loop: Header=BB2_5 Depth=1
	ldrsb	w11, [x10, #2]
	cmn	w11, #64
	b.ge	LBB2_33
; %bb.21:                               ;   in Loop: Header=BB2_5 Depth=1
	tbnz	w13, #0, LBB2_4
; %bb.22:                               ;   in Loop: Header=BB2_5 Depth=1
	ldrsb	w10, [x10, #3]
	cmn	w10, #64
	b.lt	LBB2_4
	b	LBB2_33
LBB2_23:                                ;   in Loop: Header=BB2_5 Depth=1
	and	w13, w12, #0xfe
	cmp	w13, #238
	b.eq	LBB2_11
; %bb.24:                               ;   in Loop: Header=BB2_5 Depth=1
	cmp	w12, #240
	b.ne	LBB2_26
; %bb.25:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w12, #191                       ; =0xbf
	mov	w14, #144                       ; =0x90
	b	LBB2_31
LBB2_26:                                ;   in Loop: Header=BB2_5 Depth=1
	sub	w13, w12, #241
	cmp	w13, #3
	b.hs	LBB2_28
; %bb.27:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w12, #191                       ; =0xbf
	b	LBB2_30
LBB2_28:                                ;   in Loop: Header=BB2_5 Depth=1
	cmp	w12, #244
	b.ne	LBB2_33
; %bb.29:                               ;   in Loop: Header=BB2_5 Depth=1
	mov	w13, #0                         ; =0x0
	mov	w12, #143                       ; =0x8f
LBB2_30:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w14, #128                       ; =0x80
LBB2_31:                                ;   in Loop: Header=BB2_5 Depth=1
	mov	w15, #4                         ; =0x4
	b	LBB2_16
LBB2_32:
	mov	x0, x19
LBB2_33:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB2_34:
Lloh2:
	adrp	x0, l_.str@PAGE
Lloh3:
	add	x0, x0, l_.str@PAGEOFF
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isspace       ; -- Begin function nl_ascii_isspace
	.globl	_nl_ascii_isspace
	.p2align	2
_nl_ascii_isspace:                      ; @nl_ascii_isspace
	.cfi_startproc
; %bb.0:
	and	w8, w0, #0xff
	sub	w9, w8, #9
	cmp	w8, #32
	ccmp	w9, #5, #0, ne
	cset	w8, lo
	tst	w0, #0x80000000
	csel	w0, wzr, w8, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isdigit       ; -- Begin function nl_ascii_isdigit
	.globl	_nl_ascii_isdigit
	.p2align	2
_nl_ascii_isdigit:                      ; @nl_ascii_isdigit
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #48
	cmp	w8, #10
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isalpha       ; -- Begin function nl_ascii_isalpha
	.globl	_nl_ascii_isalpha
	.p2align	2
_nl_ascii_isalpha:                      ; @nl_ascii_isalpha
	.cfi_startproc
; %bb.0:
	and	w8, w0, #0xffffffdf
	sub	w8, w8, #65
	cmp	w8, #26
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isalnum       ; -- Begin function nl_ascii_isalnum
	.globl	_nl_ascii_isalnum
	.p2align	2
_nl_ascii_isalnum:                      ; @nl_ascii_isalnum
	.cfi_startproc
; %bb.0:
	and	w8, w0, #0xffffffdf
	sub	w8, w8, #65
	sub	w9, w0, #48
	cmp	w9, #10
	ccmp	w8, #26, #0, hs
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isupper       ; -- Begin function nl_ascii_isupper
	.globl	_nl_ascii_isupper
	.p2align	2
_nl_ascii_isupper:                      ; @nl_ascii_isupper
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #65
	cmp	w8, #26
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_islower       ; -- Begin function nl_ascii_islower
	.globl	_nl_ascii_islower
	.p2align	2
_nl_ascii_islower:                      ; @nl_ascii_islower
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #97
	cmp	w8, #26
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_isprint       ; -- Begin function nl_ascii_isprint
	.globl	_nl_ascii_isprint
	.p2align	2
_nl_ascii_isprint:                      ; @nl_ascii_isprint
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #32
	cmp	w8, #95
	cset	w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_toupper       ; -- Begin function nl_ascii_toupper
	.globl	_nl_ascii_toupper
	.p2align	2
_nl_ascii_toupper:                      ; @nl_ascii_toupper
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #97
	sub	w9, w0, #32
	cmp	w8, #26
	csel	w0, w9, w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_ascii_tolower       ; -- Begin function nl_ascii_tolower
	.globl	_nl_ascii_tolower
	.p2align	2
_nl_ascii_tolower:                      ; @nl_ascii_tolower
	.cfi_startproc
; %bb.0:
	sub	w8, w0, #65
	orr	w9, w0, #0x20
	cmp	w8, #26
	csel	w0, w9, w0, lo
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_utf8_sanitize_log   ; -- Begin function nl_utf8_sanitize_log
	.globl	_nl_utf8_sanitize_log
	.p2align	2
_nl_utf8_sanitize_log:                  ; @nl_utf8_sanitize_log
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB12_79
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x2
	cbz	x2, LBB12_78
; %bb.2:
	mov	x19, x1
	mov	x21, x0
	strb	wzr, [x1]
	cbz	x0, LBB12_78
; %bb.3:
	mov	x0, x21
	bl	_strlen
	cbz	x0, LBB12_33
; %bb.4:
	mov	x8, #0                          ; =0x0
	b	LBB12_7
LBB12_5:                                ;   in Loop: Header=BB12_7 Depth=1
	add	x8, x8, #1
LBB12_6:                                ;   in Loop: Header=BB12_7 Depth=1
	cmp	x8, x0
	b.hs	LBB12_33
LBB12_7:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x21, x8
	ldrsb	w10, [x9]
	tbz	w10, #31, LBB12_5
; %bb.8:                                ;   in Loop: Header=BB12_7 Depth=1
	and	w11, w10, #0xff
	sub	w10, w11, #224
	cmn	w10, #31
	b.hi	LBB12_11
; %bb.9:                                ;   in Loop: Header=BB12_7 Depth=1
	cmp	w11, #224
	b.ne	LBB12_12
; %bb.10:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w11, #191                       ; =0xbf
	mov	w13, #160                       ; =0xa0
	b	LBB12_17
LBB12_11:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w11, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	mov	w12, #1                         ; =0x1
	mov	w14, #2                         ; =0x2
	b	LBB12_18
LBB12_12:                               ;   in Loop: Header=BB12_7 Depth=1
	sub	w12, w11, #225
	cmp	w12, #12
	b.hs	LBB12_14
LBB12_13:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w11, #191                       ; =0xbf
	b	LBB12_16
LBB12_14:                               ;   in Loop: Header=BB12_7 Depth=1
	cmp	w11, #237
	b.ne	LBB12_24
; %bb.15:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w11, #159                       ; =0x9f
LBB12_16:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w13, #128                       ; =0x80
LBB12_17:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w12, #1                         ; =0x1
	mov	w14, #3                         ; =0x3
LBB12_18:                               ;   in Loop: Header=BB12_7 Depth=1
	add	x8, x14, x8
	cmp	x8, x0
	b.hi	LBB12_76
; %bb.19:                               ;   in Loop: Header=BB12_7 Depth=1
	ldrb	w14, [x9, #1]
	cmp	w13, w14
	ccmp	w11, w14, #0, ls
	b.lo	LBB12_76
; %bb.20:                               ;   in Loop: Header=BB12_7 Depth=1
	cmn	w10, #30
	b.hs	LBB12_6
; %bb.21:                               ;   in Loop: Header=BB12_7 Depth=1
	ldrsb	w10, [x9, #2]
	cmn	w10, #64
	b.ge	LBB12_76
; %bb.22:                               ;   in Loop: Header=BB12_7 Depth=1
	tbnz	w12, #0, LBB12_6
; %bb.23:                               ;   in Loop: Header=BB12_7 Depth=1
	ldrsb	w9, [x9, #3]
	cmn	w9, #64
	b.lt	LBB12_6
	b	LBB12_76
LBB12_24:                               ;   in Loop: Header=BB12_7 Depth=1
	and	w12, w11, #0xfe
	cmp	w12, #238
	b.eq	LBB12_13
; %bb.25:                               ;   in Loop: Header=BB12_7 Depth=1
	cmp	w11, #240
	b.ne	LBB12_27
; %bb.26:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #191                       ; =0xbf
	mov	w13, #144                       ; =0x90
	b	LBB12_32
LBB12_27:                               ;   in Loop: Header=BB12_7 Depth=1
	sub	w12, w11, #241
	cmp	w12, #3
	b.hs	LBB12_29
; %bb.28:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #191                       ; =0xbf
	b	LBB12_31
LBB12_29:                               ;   in Loop: Header=BB12_7 Depth=1
	cmp	w11, #244
	b.ne	LBB12_76
; %bb.30:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w12, #0                         ; =0x0
	mov	w11, #143                       ; =0x8f
LBB12_31:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w13, #128                       ; =0x80
LBB12_32:                               ;   in Loop: Header=BB12_7 Depth=1
	mov	w14, #4                         ; =0x4
	b	LBB12_18
LBB12_33:
	mov	x0, x21
	bl	_strlen
	mov	x22, #0                         ; =0x0
	cbz	x0, LBB12_77
; %bb.34:
	cmp	x20, #2
	b.lo	LBB12_77
; %bb.35:
	mov	x22, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	add	x24, x21, #3
	mov	w25, #1                         ; =0x1
	mov	w11, #-8234                     ; =0xffffdfd6
	mov	w12, #-8206                     ; =0xffffdff2
	mov	w13, #9728                      ; =0x2600
LBB12_36:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_41 Depth 2
                                        ;     Child Loop BB12_56 Depth 2
	add	x1, x21, x28
	ldrb	w8, [x1]
	cmp	w8, #27
	b.ne	LBB12_44
; %bb.37:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x8, x28, #1
	cmp	x8, x0
	b.hs	LBB12_46
; %bb.38:                               ;   in Loop: Header=BB12_36 Depth=1
	ldrb	w9, [x21, x8]
	cmp	w9, #93
	b.eq	LBB12_51
; %bb.39:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	w9, #91
	b.ne	LBB12_46
; %bb.40:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x8, x28, #2
	cmp	x8, x0
	b.hs	LBB12_74
LBB12_41:                               ;   Parent Loop BB12_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x21, x8]
	sub	w9, w9, #127
	cmn	w9, #64
	b.hi	LBB12_75
; %bb.42:                               ;   in Loop: Header=BB12_41 Depth=2
	add	x8, x8, #1
	cmp	x0, x8
	b.ne	LBB12_41
; %bb.43:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x28, xzr, x0
	b	LBB12_66
LBB12_44:                               ;   in Loop: Header=BB12_36 Depth=1
	tbnz	w8, #7, LBB12_47
; %bb.45:                               ;   in Loop: Header=BB12_36 Depth=1
	mov	w23, #1                         ; =0x1
	b	LBB12_64
LBB12_46:                               ;   in Loop: Header=BB12_36 Depth=1
	mov	x28, x8
	b	LBB12_66
LBB12_47:                               ;   in Loop: Header=BB12_36 Depth=1
	sub	w9, w8, #194
	cmp	w9, #29
	add	x9, x28, #1
	ccmp	x9, x0, #2, ls
	b.lo	LBB12_62
; %bb.48:                               ;   in Loop: Header=BB12_36 Depth=1
	and	w9, w8, #0xf0
	cmp	w9, #224
	b.ne	LBB12_60
; %bb.49:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x9, x28, #2
	cmp	x9, x0
	b.hs	LBB12_77
; %bb.50:                               ;   in Loop: Header=BB12_36 Depth=1
	ubfiz	w8, w8, #12, #4
	ldrb	w10, [x1, #1]
	bfi	w8, w10, #6, #6
	mov	w23, #3                         ; =0x3
	b	LBB12_63
LBB12_51:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x28, x28, #2
	cmp	x28, x0
	b.lo	LBB12_56
LBB12_52:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	x28, x0
	b.hs	LBB12_66
; %bb.53:                               ;   in Loop: Header=BB12_36 Depth=1
	ldrb	w8, [x21, x28]
	cmp	w8, #7
	cinc	x28, x28, eq
	b	LBB12_66
LBB12_54:                               ;   in Loop: Header=BB12_56 Depth=2
	cmp	w8, #7
	b.eq	LBB12_52
LBB12_55:                               ;   in Loop: Header=BB12_56 Depth=2
	add	x28, x28, #1
	cmp	x0, x28
	b.eq	LBB12_77
LBB12_56:                               ;   Parent Loop BB12_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x24, x28
	ldurb	w8, [x8, #-3]
	cmp	w8, #27
	b.ne	LBB12_54
; %bb.57:                               ;   in Loop: Header=BB12_56 Depth=2
	add	x8, x28, #1
	cmp	x8, x0
	b.hs	LBB12_55
; %bb.58:                               ;   in Loop: Header=BB12_56 Depth=2
	add	x8, x24, x28
	ldurb	w8, [x8, #-2]
	cmp	w8, #92
	b.ne	LBB12_55
; %bb.59:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x28, x28, #2
	b	LBB12_52
LBB12_60:                               ;   in Loop: Header=BB12_36 Depth=1
	sub	w9, w8, #240
	cmp	w9, #4
	add	x9, x28, #3
	ccmp	x9, x0, #2, ls
	b.hs	LBB12_77
; %bb.61:                               ;   in Loop: Header=BB12_36 Depth=1
	ubfiz	w8, w8, #18, #3
	ldrb	w10, [x1, #1]
	bfi	w8, w10, #12, #6
	ldrb	w10, [x1, #2]
	bfi	w8, w10, #6, #6
	mov	w23, #4                         ; =0x4
	b	LBB12_63
LBB12_62:                               ;   in Loop: Header=BB12_36 Depth=1
	ubfiz	w8, w8, #6, #5
	mov	w23, #2                         ; =0x2
LBB12_63:                               ;   in Loop: Header=BB12_36 Depth=1
	ldrb	w9, [x21, x9]
	and	w9, w9, #0x3f
	orr	w8, w8, w9
LBB12_64:                               ;   in Loop: Header=BB12_36 Depth=1
	add	w9, w8, w11
	cmp	w9, #63
	lsl	x9, x25, x9
	and	x9, x9, #0xf00000000000001f
	ccmp	x9, #0, #4, ls
	add	w9, w8, w12
	ccmp	w9, #2, #0, eq
	b.hs	LBB12_68
LBB12_65:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x28, x23, x28
LBB12_66:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	x28, x0
	b.hs	LBB12_77
; %bb.67:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x8, x22, #1
	cmp	x8, x20
	b.lo	LBB12_36
	b	LBB12_77
LBB12_68:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	w8, #1564
	b.eq	LBB12_65
; %bb.69:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	w8, #31
	b.hi	LBB12_72
; %bb.70:                               ;   in Loop: Header=BB12_36 Depth=1
	cmp	w8, #13
	b.hi	LBB12_65
; %bb.71:                               ;   in Loop: Header=BB12_36 Depth=1
	lsl	w8, w25, w8
	tst	w8, w13
	b.eq	LBB12_65
LBB12_72:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x26, x23, x22
	cmp	x26, x20
	b.hs	LBB12_77
; %bb.73:                               ;   in Loop: Header=BB12_36 Depth=1
	mov	x27, x0
	add	x0, x19, x22
	mov	x2, x23
	bl	_memcpy
	mov	w13, #9728                      ; =0x2600
	mov	w12, #-8206                     ; =0xffffdff2
	mov	w11, #-8234                     ; =0xffffdfd6
	mov	x0, x27
	add	x28, x23, x28
	mov	x22, x26
	b	LBB12_66
LBB12_74:                               ;   in Loop: Header=BB12_36 Depth=1
	add	x28, xzr, x8
	b	LBB12_66
LBB12_75:                               ;   in Loop: Header=BB12_36 Depth=1
	mov	w9, #1                          ; =0x1
	add	x28, x9, x8
	b	LBB12_66
LBB12_76:
	sub	x22, x20, #1
Lloh4:
	adrp	x1, l_.str.1@PAGE
Lloh5:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x19
	mov	x2, x22
	bl	_strncpy
LBB12_77:
	strb	wzr, [x19, x22]
LBB12_78:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
LBB12_79:
	ret
	.loh AdrpAdd	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

l_.str.1:                               ; @.str.1
	.asciz	"<invalid UTF-8>"

.subsections_via_symbols
