	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_layouts_decode  ; -- Begin function nvm_v2_layouts_decode
	.globl	_nvm_v2_layouts_decode
	.p2align	2
_nvm_v2_layouts_decode:                 ; @nvm_v2_layouts_decode
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	b	_layouts_decode_profile
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function layouts_decode_profile
_layouts_decode_profile:                ; @layouts_decode_profile
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x6
	mov	x22, x5
	mov	x23, x4
	mov	x24, x3
	mov	x20, x2
	mov	x25, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #56
	mov	x2, x25
	bl	_nvm_v2_cursor_init
	add	x0, sp, #56
	add	x1, sp, #52
	bl	_nvm_v2_u32
	cbz	w0, LBB1_2
LBB1_1:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB1_2:
	ldr	w0, [sp, #52]
	cbz	w0, LBB1_1
; %bb.3:
	ldr	x8, [sp, #72]
	sub	x8, x25, x8
	cmp	x0, x8, lsr #3
	b.ls	LBB1_5
; %bb.4:
	mov	w0, #1                          ; =0x1
	b	LBB1_1
LBB1_5:
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB1_36
; %bb.6:
	mov	x28, x0
	mov	x27, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	str	wzr, [sp, #28]                  ; 4-byte Folded Spill
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
LBB1_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_17 Depth 2
	add	x0, sp, #56
	add	x1, sp, #51
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_47
; %bb.8:                                ;   in Loop: Header=BB1_7 Depth=1
	add	x0, sp, #56
	add	x1, sp, #50
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_47
; %bb.9:                                ;   in Loop: Header=BB1_7 Depth=1
	ldrb	w8, [sp, #50]
	cbnz	w8, LBB1_45
; %bb.10:                               ;   in Loop: Header=BB1_7 Depth=1
	ldrb	w8, [sp, #51]
	cmp	w8, #3
	b.hi	LBB1_46
; %bb.11:                               ;   in Loop: Header=BB1_7 Depth=1
	add	x0, sp, #56
	add	x1, sp, #48
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_47
; %bb.12:                               ;   in Loop: Header=BB1_7 Depth=1
	add	x0, sp, #56
	add	x1, sp, #44
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_47
; %bb.13:                               ;   in Loop: Header=BB1_7 Depth=1
	ldrb	w8, [sp, #51]
	add	x19, x28, x27, lsl #4
	strb	w8, [x19]
	ldrh	w0, [sp, #48]
	strh	w0, [x19, #2]
	ldr	w8, [sp, #44]
	str	w8, [x19, #4]
	str	xzr, [x19, #8]
	add	x8, x27, #1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	cbz	x0, LBB1_32
; %bb.14:                               ;   in Loop: Header=BB1_7 Depth=1
	ldr	x8, [sp, #72]
	sub	x8, x25, x8
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43691
	umulh	x8, x8, x9
	cmp	x0, x8, lsr #3
	b.hi	LBB1_48
; %bb.15:                               ;   in Loop: Header=BB1_7 Depth=1
	mov	w1, #12                         ; =0xc
	bl	_calloc
	cbz	x0, LBB1_49
; %bb.16:                               ;   in Loop: Header=BB1_7 Depth=1
	mov	x28, #0                         ; =0x0
	str	x0, [x19, #8]
	add	x19, x0, #8
LBB1_17:                                ;   Parent Loop BB1_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #56
	add	x1, sp, #43
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_39
; %bb.18:                               ;   in Loop: Header=BB1_17 Depth=2
	add	x0, sp, #56
	add	x1, sp, #42
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_39
; %bb.19:                               ;   in Loop: Header=BB1_17 Depth=2
	add	x0, sp, #56
	add	x1, sp, #41
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_39
; %bb.20:                               ;   in Loop: Header=BB1_17 Depth=2
	add	x0, sp, #56
	add	x1, sp, #40
	bl	_nvm_v2_u8
	cbnz	w0, LBB1_39
; %bb.21:                               ;   in Loop: Header=BB1_17 Depth=2
	ldrb	w8, [sp, #42]
	mov	w0, #7                          ; =0x7
	cbnz	w8, LBB1_39
; %bb.22:                               ;   in Loop: Header=BB1_17 Depth=2
	ldrb	w8, [sp, #41]
	cbnz	w8, LBB1_39
; %bb.23:                               ;   in Loop: Header=BB1_17 Depth=2
	ldrb	w8, [sp, #40]
	cbnz	w8, LBB1_39
; %bb.24:                               ;   in Loop: Header=BB1_17 Depth=2
	ldrb	w8, [sp, #43]
	cmp	w8, #15
	b.hi	LBB1_38
; %bb.25:                               ;   in Loop: Header=BB1_17 Depth=2
	add	x0, sp, #56
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_39
; %bb.26:                               ;   in Loop: Header=BB1_17 Depth=2
	add	x0, sp, #56
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_39
; %bb.27:                               ;   in Loop: Header=BB1_17 Depth=2
	ldr	w8, [sp, #36]
	cmn	w8, #1
	b.eq	LBB1_31
; %bb.28:                               ;   in Loop: Header=BB1_17 Depth=2
	mov	w0, #13                         ; =0xd
	cmp	x27, x8
	b.eq	LBB1_39
; %bb.29:                               ;   in Loop: Header=BB1_17 Depth=2
	ldr	w9, [sp, #52]
	cmp	w8, w9
	b.hs	LBB1_39
; %bb.30:                               ;   in Loop: Header=BB1_17 Depth=2
	cmp	x27, x8
	cset	w9, lo
	ldr	w10, [sp, #28]                  ; 4-byte Folded Reload
	orr	w10, w9, w10
	str	w10, [sp, #28]                  ; 4-byte Folded Spill
LBB1_31:                                ;   in Loop: Header=BB1_17 Depth=2
	ldrb	w9, [sp, #43]
	sturb	w9, [x19, #-8]
	ldr	w9, [sp, #32]
	stp	w8, w9, [x19, #-4]
	add	x28, x28, #1
	ldrh	w8, [sp, #48]
	add	x19, x19, #12
	cmp	x28, x8
	b.lo	LBB1_17
LBB1_32:                                ;   in Loop: Header=BB1_7 Depth=1
	add	w26, w26, #1
	ldr	w1, [sp, #52]
	ldp	x28, x19, [sp, #8]              ; 16-byte Folded Reload
	mov	x27, x19
	cmp	x19, x1
	b.lo	LBB1_7
; %bb.33:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB1_52
; %bb.34:
	mov	x0, x28
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, x24
	mov	x3, x23
	mov	x4, x22
	mov	x5, x21
	bl	_forward_record_graph
	cbz	w0, LBB1_51
; %bb.35:
	mov	x8, x19
	mov	x19, x0
	b	LBB1_41
LBB1_36:
	mov	w0, #1                          ; =0x1
	cbz	x21, LBB1_1
; %bb.37:
	strb	w0, [x21]
	b	LBB1_1
LBB1_38:
	mov	w0, #8                          ; =0x8
LBB1_39:
	ldr	x28, [sp, #8]                   ; 8-byte Folded Reload
LBB1_40:
	mov	x19, x0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
LBB1_41:
	mov	x26, x8
LBB1_42:
	mov	w20, w26
	add	x21, x28, #8
LBB1_43:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21], #16
	bl	_free
	subs	x20, x20, #1
	b.ne	LBB1_43
LBB1_44:
	mov	x0, x28
	bl	_free
	mov	x0, x19
	b	LBB1_1
LBB1_45:
	mov	w0, #7                          ; =0x7
	b	LBB1_47
LBB1_46:
	mov	w0, #8                          ; =0x8
LBB1_47:
	mov	x19, x0
	cbnz	w26, LBB1_42
	b	LBB1_44
LBB1_48:
	mov	w0, #1                          ; =0x1
	b	LBB1_40
LBB1_49:
	mov	w0, #1                          ; =0x1
	cbz	x21, LBB1_40
; %bb.50:
	strb	w0, [x21]
	b	LBB1_40
LBB1_51:
	ldr	w1, [sp, #52]
LBB1_52:
	mov	w0, #0                          ; =0x0
	str	x28, [x20]
	str	w1, [x20, #8]
	b	LBB1_1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_layouts_private_decode ; -- Begin function nvm_ownership_layouts_private_decode
	.globl	_nvm_ownership_layouts_private_decode
	.p2align	2
_nvm_ownership_layouts_private_decode:  ; @nvm_ownership_layouts_private_decode
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	mov	w4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	b	_ownership_layouts_private_decode
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ownership_layouts_private_decode
_ownership_layouts_private_decode:      ; @ownership_layouts_private_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x1
	mov	x20, x0
	cbz	x5, LBB3_2
; %bb.1:
	strb	wzr, [x5]
LBB3_2:
	mov	w0, #9                          ; =0x9
	cbz	x19, LBB3_8
; %bb.3:
	cbz	x20, LBB3_8
; %bb.4:
	cbz	x2, LBB3_8
; %bb.5:
	mov	w8, #16777216                   ; =0x1000000
	cmp	x19, x8
	b.ls	LBB3_7
LBB3_6:
	mov	w0, #13                         ; =0xd
	b	LBB3_8
LBB3_7:
	mov	x23, x3
	mov	x22, x4
	mov	x21, x5
	mov	x24, x2
	add	x0, sp, #40
	mov	x1, x20
	mov	x2, x19
	bl	_nvm_v2_cursor_init
	add	x0, sp, #40
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbz	w0, LBB3_9
LBB3_8:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB3_9:
	ldr	w8, [sp, #36]
	cmp	w8, #256
	b.hi	LBB3_6
; %bb.10:
	cbz	w8, LBB3_16
; %bb.11:
	mov	w25, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	mov	w27, #65536                     ; =0x10000
LBB3_12:                                ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #40
	add	x2, sp, #8
	mov	w1, #8                          ; =0x8
	bl	_nvm_v2_take
	cbnz	w0, LBB3_8
; %bb.13:                               ;   in Loop: Header=BB3_12 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w28, [x8, #2]
	sub	w8, w27, w26
	cmp	w8, w28
	b.lo	LBB3_6
; %bb.14:                               ;   in Loop: Header=BB3_12 Depth=1
	mov	w8, #12                         ; =0xc
	umull	x1, w28, w8
	add	x0, sp, #40
	add	x2, sp, #24
	bl	_nvm_v2_take
	cbnz	w0, LBB3_8
; %bb.15:                               ;   in Loop: Header=BB3_12 Depth=1
	add	w26, w26, w28
	add	w25, w25, #1
	ldr	w8, [sp, #36]
	cmp	w25, w8
	b.lo	LBB3_12
LBB3_16:
	ldp	x9, x8, [sp, #48]
	cmp	x8, x9
	b.ne	LBB3_19
; %bb.17:
	str	xzr, [sp, #16]
	add	x2, sp, #8
	mov	x0, x20
	mov	x1, x19
	mov	w3, #1                          ; =0x1
	mov	x4, x23
	mov	x5, x22
	mov	x6, x21
	bl	_layouts_decode_profile
	cbnz	w0, LBB3_8
; %bb.18:
	ldur	q0, [sp, #8]
	str	q0, [x24]
	b	LBB3_8
LBB3_19:
	mov	w0, #9                          ; =0x9
	b	LBB3_8
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_mixed_layouts_private_decode ; -- Begin function nvm_ownership_mixed_layouts_private_decode
	.globl	_nvm_ownership_mixed_layouts_private_decode
	.p2align	2
_nvm_ownership_mixed_layouts_private_decode: ; @nvm_ownership_mixed_layouts_private_decode
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	mov	w4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	b	_ownership_layouts_private_decode
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_mixed_layouts_private_decode_detailed ; -- Begin function nvm_ownership_mixed_layouts_private_decode_detailed
	.globl	_nvm_ownership_mixed_layouts_private_decode_detailed
	.p2align	2
_nvm_ownership_mixed_layouts_private_decode_detailed: ; @nvm_ownership_mixed_layouts_private_decode_detailed
	.cfi_startproc
; %bb.0:
	mov	x5, x3
	mov	w3, #1                          ; =0x1
	mov	w4, #0                          ; =0x0
	b	_ownership_layouts_private_decode
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_ownership_map_layouts_private_decode_detailed ; -- Begin function nvm_ownership_map_layouts_private_decode_detailed
	.globl	_nvm_ownership_map_layouts_private_decode_detailed
	.p2align	2
_nvm_ownership_map_layouts_private_decode_detailed: ; @nvm_ownership_map_layouts_private_decode_detailed
	.cfi_startproc
; %bb.0:
	mov	x5, x3
	mov	w3, #1                          ; =0x1
	mov	w4, #1                          ; =0x1
	b	_ownership_layouts_private_decode
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_layouts_free    ; -- Begin function nvm_v2_layouts_free
	.globl	_nvm_v2_layouts_free
	.p2align	2
_nvm_v2_layouts_free:                   ; @nvm_v2_layouts_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x0, [x0]
	cbz	x0, LBB7_7
; %bb.2:
	ldr	w20, [x19, #8]
	cbz	w20, LBB7_6
; %bb.3:
	add	x21, x0, #8
LBB7_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21], #16
	bl	_free
	subs	x20, x20, #1
	b.ne	LBB7_4
; %bb.5:
	ldr	x0, [x19]
LBB7_6:
	bl	_free
	str	xzr, [x19]
LBB7_7:
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB7_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_v2_layouts_encoded_size
lCPI8_0:
	.quad	4                               ; 0x4
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_layouts_encoded_size
	.globl	_nvm_v2_layouts_encoded_size
	.p2align	2
_nvm_v2_layouts_encoded_size:           ; @nvm_v2_layouts_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	cbz	w8, LBB8_3
; %bb.1:
	stp	d11, d10, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	.cfi_offset b10, -72
	.cfi_offset b11, -80
	ldr	x9, [x0]
	cmp	w8, #8
	b.hi	LBB8_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w0, #4                          ; =0x4
	b	LBB8_12
LBB8_3:
	mov	w0, #4                          ; =0x4
	ret
LBB8_4:
	cmp	w8, #33
	b.hs	LBB8_6
; %bb.5:
	mov	x10, #0                         ; =0x0
	mov	w0, #4                          ; =0x4
	b	LBB8_9
LBB8_6:
	ands	x10, x8, #0x1f
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #12
	movi.2s	v2, #12
	mov	w11, #8                         ; =0x8
	dup.2d	v3, x11
	mov	w11, #32                        ; =0x20
	movi.2d	v4, #0000000000000000
	csel	x11, x11, x10, eq
	movi.2d	v5, #0000000000000000
	sub	x10, x8, x11
	movi.2d	v6, #0000000000000000
	movi.2d	v16, #0000000000000000
Lloh0:
	adrp	x12, lCPI8_0@PAGE
Lloh1:
	ldr	q7, [x12, lCPI8_0@PAGEOFF]
	movi.2d	v17, #0000000000000000
	add	x12, x9, #258
	movi.2d	v22, #0000000000000000
	mov	x13, x8
	movi.2d	v20, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB8_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #176
	ldur	h27, [x12, #-192]
	ld1.h	{ v27 }[1], [x14]
	sub	x14, x12, #160
	ld1.h	{ v27 }[2], [x14]
	sub	x14, x12, #144
	ld1.h	{ v27 }[3], [x14]
	sub	x14, x12, #240
	ldur	h28, [x12, #-256]
	ld1.h	{ v28 }[1], [x14]
	sub	x0, x12, #224
	sub	x2, x12, #208
	sub	x7, x12, #112
	sub	x19, x12, #96
	sub	x20, x12, #80
	sub	x21, x12, #48
	sub	x22, x12, #32
	sub	x23, x12, #16
	add	x3, x12, #16
	add	x1, x12, #32
	add	x17, x12, #48
	add	x24, x12, #80
	add	x6, x12, #96
	add	x5, x12, #112
	add	x16, x12, #144
	add	x15, x12, #160
	add	x14, x12, #176
	ld1.h	{ v28 }[2], [x0]
	ushll.4s	v27, v27, #0
	ld1.h	{ v28 }[3], [x2]
	add	x4, x12, #208
	add	x2, x12, #224
	add	x0, x12, #240
	ushll.4s	v28, v28, #0
	ldur	h29, [x12, #-64]
	ld1.h	{ v29 }[1], [x21]
	ld1.h	{ v29 }[2], [x22]
	ld1.h	{ v29 }[3], [x23]
	ushll.4s	v29, v29, #0
	ldur	h30, [x12, #-128]
	ld1.h	{ v30 }[1], [x7]
	ld1.h	{ v30 }[2], [x19]
	ld1.h	{ v30 }[3], [x20]
	ushll.4s	v30, v30, #0
	ldr	h31, [x12, #64]
	ld1.h	{ v31 }[1], [x24]
	ld1.h	{ v31 }[2], [x6]
	ld1.h	{ v31 }[3], [x5]
	ushll.4s	v31, v31, #0
	ldr	h8, [x12]
	ld1.h	{ v8 }[1], [x3]
	ld1.h	{ v8 }[2], [x1]
	ld1.h	{ v8 }[3], [x17]
	ushll.4s	v8, v8, #0
	ldr	h9, [x12, #192]
	ld1.h	{ v9 }[1], [x4]
	ld1.h	{ v9 }[2], [x2]
	ld1.h	{ v9 }[3], [x0]
	ushll.4s	v9, v9, #0
	ldr	h10, [x12, #128]
	ld1.h	{ v10 }[1], [x16]
	ld1.h	{ v10 }[2], [x15]
	ld1.h	{ v10 }[3], [x14]
	ushll.4s	v10, v10, #0
	umlal.2d	v7, v28, v2
	umlal.2d	v4, v27, v2
	umlal2.2d	v0, v28, v1
	umlal2.2d	v5, v27, v1
	umlal.2d	v6, v30, v2
	umlal.2d	v17, v29, v2
	umlal2.2d	v16, v30, v1
	umlal2.2d	v22, v29, v1
	umlal.2d	v20, v8, v2
	umlal.2d	v25, v31, v2
	umlal2.2d	v18, v8, v1
	umlal2.2d	v23, v31, v1
	umlal.2d	v19, v10, v2
	umlal.2d	v21, v9, v2
	umlal2.2d	v24, v10, v1
	umlal2.2d	v26, v9, v1
	add.2d	v5, v5, v3
	add.2d	v0, v0, v3
	add.2d	v4, v4, v3
	add.2d	v7, v7, v3
	add.2d	v22, v22, v3
	add.2d	v16, v16, v3
	add.2d	v17, v17, v3
	add.2d	v6, v6, v3
	add.2d	v23, v23, v3
	add.2d	v18, v18, v3
	add.2d	v25, v25, v3
	add.2d	v20, v20, v3
	add.2d	v26, v26, v3
	add.2d	v24, v24, v3
	sub	x13, x13, #32
	add.2d	v21, v21, v3
	add	x12, x12, #512
	add.2d	v19, v19, v3
	cmp	x11, x13
	b.ne	LBB8_7
; %bb.8:
	add.2d	v0, v16, v0
	add.2d	v1, v22, v5
	add.2d	v2, v6, v7
	add.2d	v3, v17, v4
	add.2d	v3, v25, v3
	add.2d	v2, v20, v2
	add.2d	v1, v23, v1
	add.2d	v0, v18, v0
	add.2d	v0, v24, v0
	add.2d	v1, v26, v1
	add.2d	v2, v19, v2
	add.2d	v3, v21, v3
	add.2d	v2, v2, v3
	add.2d	v0, v0, v1
	add.2d	v0, v2, v0
	addp.2d	d0, v0
	fmov	x0, d0
	cmp	x11, #9
	b.lo	LBB8_12
LBB8_9:
	mov	x13, x10
	ands	x10, x8, #0x7
	mov	w11, #8                         ; =0x8
	csel	x14, x11, x10, eq
	movi.2d	v0, #0000000000000000
	mov.d	v0[0], x0
	add	x12, x9, x13, lsl #4
	sub	x10, x8, x14
	movi.2d	v1, #0000000000000000
	add	x12, x12, #66
	add	x13, x14, x13
	sub	x13, x13, x8
	movi.4s	v2, #12
	movi.2s	v3, #12
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB8_10:                                ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #48
	sub	x15, x12, #32
	sub	x16, x12, #16
	add	x17, x12, #16
	add	x0, x12, #32
	ldr	h6, [x12]
	ld1.h	{ v6 }[1], [x17]
	ld1.h	{ v6 }[2], [x0]
	add	x17, x12, #48
	ld1.h	{ v6 }[3], [x17]
	ldur	h7, [x12, #-64]
	ld1.h	{ v7 }[1], [x14]
	ushll.4s	v6, v6, #0
	ld1.h	{ v7 }[2], [x15]
	ld1.h	{ v7 }[3], [x16]
	ushll.4s	v7, v7, #0
	umlal.2d	v0, v7, v3
	umlal.2d	v4, v6, v3
	umlal2.2d	v1, v7, v2
	umlal2.2d	v5, v6, v2
	dup.2d	v6, x11
	add.2d	v5, v5, v6
	add.2d	v1, v1, v6
	add.2d	v4, v4, v6
	add.2d	v0, v0, v6
	add	x12, x12, #128
	adds	x13, x13, #8
	b.ne	LBB8_10
; %bb.11:
	add.2d	v0, v0, v4
	add.2d	v1, v1, v5
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x0, d0
LBB8_12:
	add	x9, x9, x10, lsl #4
	add	x9, x9, #2
	sub	x8, x8, x10
	mov	w10, #12                        ; =0xc
LBB8_13:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w11, [x9], #16
	umaddl	x11, w11, w10, x0
	add	x0, x11, #8
	subs	x8, x8, #1
	b.ne	LBB8_13
; %bb.14:
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #80             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_v2_layouts_encode
lCPI9_0:
	.quad	4                               ; 0x4
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_layouts_encode
	.globl	_nvm_v2_layouts_encode
	.p2align	2
_nvm_v2_layouts_encode:                 ; @nvm_v2_layouts_encode
	.cfi_startproc
; %bb.0:
	stp	d11, d10, [sp, #-128]!          ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	mov	x19, x1
	mov	x20, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB9_3
; %bb.1:
	ldr	x9, [x20]
	cmp	w8, #9
	b.hs	LBB9_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w1, #4                          ; =0x4
	b	LBB9_12
LBB9_3:
	mov	w1, #4                          ; =0x4
	b	LBB9_14
LBB9_4:
	cmp	w8, #33
	b.hs	LBB9_6
; %bb.5:
	mov	x10, #0                         ; =0x0
	mov	w1, #4                          ; =0x4
	b	LBB9_9
LBB9_6:
	ands	x10, x8, #0x1f
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #12
	movi.2s	v2, #12
	mov	w11, #8                         ; =0x8
	dup.2d	v3, x11
	mov	w11, #32                        ; =0x20
	movi.2d	v4, #0000000000000000
	csel	x11, x11, x10, eq
	movi.2d	v5, #0000000000000000
	sub	x10, x8, x11
	movi.2d	v6, #0000000000000000
	movi.2d	v16, #0000000000000000
Lloh2:
	adrp	x12, lCPI9_0@PAGE
Lloh3:
	ldr	q7, [x12, lCPI9_0@PAGEOFF]
	movi.2d	v17, #0000000000000000
	add	x12, x9, #258
	movi.2d	v22, #0000000000000000
	mov	x13, x8
	movi.2d	v20, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB9_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #176
	ldur	h27, [x12, #-192]
	ld1.h	{ v27 }[1], [x14]
	sub	x14, x12, #160
	ld1.h	{ v27 }[2], [x14]
	sub	x14, x12, #144
	ld1.h	{ v27 }[3], [x14]
	sub	x14, x12, #240
	ldur	h28, [x12, #-256]
	ld1.h	{ v28 }[1], [x14]
	sub	x0, x12, #224
	sub	x3, x12, #208
	sub	x21, x12, #112
	sub	x22, x12, #96
	sub	x23, x12, #80
	sub	x24, x12, #48
	sub	x25, x12, #32
	sub	x26, x12, #16
	add	x4, x12, #16
	add	x1, x12, #32
	add	x17, x12, #48
	add	x27, x12, #80
	add	x7, x12, #96
	add	x6, x12, #112
	add	x16, x12, #144
	add	x15, x12, #160
	add	x14, x12, #176
	ld1.h	{ v28 }[2], [x0]
	ushll.4s	v27, v27, #0
	ld1.h	{ v28 }[3], [x3]
	add	x5, x12, #208
	add	x3, x12, #224
	add	x0, x12, #240
	ushll.4s	v28, v28, #0
	ldur	h29, [x12, #-64]
	ld1.h	{ v29 }[1], [x24]
	ld1.h	{ v29 }[2], [x25]
	ld1.h	{ v29 }[3], [x26]
	ushll.4s	v29, v29, #0
	ldur	h30, [x12, #-128]
	ld1.h	{ v30 }[1], [x21]
	ld1.h	{ v30 }[2], [x22]
	ld1.h	{ v30 }[3], [x23]
	ushll.4s	v30, v30, #0
	ldr	h31, [x12, #64]
	ld1.h	{ v31 }[1], [x27]
	ld1.h	{ v31 }[2], [x7]
	ld1.h	{ v31 }[3], [x6]
	ushll.4s	v31, v31, #0
	ldr	h8, [x12]
	ld1.h	{ v8 }[1], [x4]
	ld1.h	{ v8 }[2], [x1]
	ld1.h	{ v8 }[3], [x17]
	ushll.4s	v8, v8, #0
	ldr	h9, [x12, #192]
	ld1.h	{ v9 }[1], [x5]
	ld1.h	{ v9 }[2], [x3]
	ld1.h	{ v9 }[3], [x0]
	ushll.4s	v9, v9, #0
	ldr	h10, [x12, #128]
	ld1.h	{ v10 }[1], [x16]
	ld1.h	{ v10 }[2], [x15]
	ld1.h	{ v10 }[3], [x14]
	ushll.4s	v10, v10, #0
	umlal.2d	v7, v28, v2
	umlal.2d	v4, v27, v2
	umlal2.2d	v0, v28, v1
	umlal2.2d	v5, v27, v1
	umlal.2d	v6, v30, v2
	umlal.2d	v17, v29, v2
	umlal2.2d	v16, v30, v1
	umlal2.2d	v22, v29, v1
	umlal.2d	v20, v8, v2
	umlal.2d	v25, v31, v2
	umlal2.2d	v18, v8, v1
	umlal2.2d	v23, v31, v1
	umlal.2d	v19, v10, v2
	umlal.2d	v21, v9, v2
	umlal2.2d	v24, v10, v1
	umlal2.2d	v26, v9, v1
	add.2d	v5, v5, v3
	add.2d	v0, v0, v3
	add.2d	v4, v4, v3
	add.2d	v7, v7, v3
	add.2d	v22, v22, v3
	add.2d	v16, v16, v3
	add.2d	v17, v17, v3
	add.2d	v6, v6, v3
	add.2d	v23, v23, v3
	add.2d	v18, v18, v3
	add.2d	v25, v25, v3
	add.2d	v20, v20, v3
	add.2d	v26, v26, v3
	add.2d	v24, v24, v3
	sub	x13, x13, #32
	add.2d	v21, v21, v3
	add	x12, x12, #512
	add.2d	v19, v19, v3
	cmp	x11, x13
	b.ne	LBB9_7
; %bb.8:
	add.2d	v0, v16, v0
	add.2d	v1, v22, v5
	add.2d	v2, v6, v7
	add.2d	v3, v17, v4
	add.2d	v3, v25, v3
	add.2d	v2, v20, v2
	add.2d	v1, v23, v1
	add.2d	v0, v18, v0
	add.2d	v0, v24, v0
	add.2d	v1, v26, v1
	add.2d	v2, v19, v2
	add.2d	v3, v21, v3
	add.2d	v2, v2, v3
	add.2d	v0, v0, v1
	add.2d	v0, v2, v0
	addp.2d	d0, v0
	fmov	x1, d0
	cmp	x11, #9
	b.lo	LBB9_12
LBB9_9:
	mov	x13, x10
	ands	x10, x8, #0x7
	mov	w11, #8                         ; =0x8
	csel	x14, x11, x10, eq
	movi.2d	v0, #0000000000000000
	mov.d	v0[0], x1
	add	x12, x9, x13, lsl #4
	sub	x10, x8, x14
	movi.2d	v1, #0000000000000000
	add	x12, x12, #66
	add	x13, x14, x13
	sub	x13, x13, x8
	movi.4s	v2, #12
	movi.2s	v3, #12
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB9_10:                                ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #48
	sub	x15, x12, #32
	sub	x16, x12, #16
	add	x17, x12, #16
	add	x0, x12, #32
	ldr	h6, [x12]
	ld1.h	{ v6 }[1], [x17]
	ld1.h	{ v6 }[2], [x0]
	add	x17, x12, #48
	ld1.h	{ v6 }[3], [x17]
	ldur	h7, [x12, #-64]
	ld1.h	{ v7 }[1], [x14]
	ushll.4s	v6, v6, #0
	ld1.h	{ v7 }[2], [x15]
	ld1.h	{ v7 }[3], [x16]
	ushll.4s	v7, v7, #0
	umlal.2d	v0, v7, v3
	umlal.2d	v4, v6, v3
	umlal2.2d	v1, v7, v2
	umlal2.2d	v5, v6, v2
	dup.2d	v6, x11
	add.2d	v5, v5, v6
	add.2d	v1, v1, v6
	add.2d	v4, v4, v6
	add.2d	v0, v0, v6
	add	x12, x12, #128
	adds	x13, x13, #8
	b.ne	LBB9_10
; %bb.11:
	add.2d	v0, v0, v4
	add.2d	v1, v1, v5
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x1, d0
LBB9_12:
	sub	x8, x8, x10
	add	x9, x9, x10, lsl #4
	add	x9, x9, #2
	mov	w10, #12                        ; =0xc
LBB9_13:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w11, [x9], #16
	umaddl	x11, w11, w10, x1
	add	x1, x11, #8
	subs	x8, x8, #1
	b.ne	LBB9_13
LBB9_14:
	cmp	x2, x1
	b.hs	LBB9_16
; %bb.15:
	mov	w0, #1                          ; =0x1
	b	LBB9_24
LBB9_16:
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	str	w8, [x19]
	ldr	w8, [x20, #8]
	cbz	w8, LBB9_23
; %bb.17:
	mov	x8, #0                          ; =0x0
	mov	w9, #4                          ; =0x4
	b	LBB9_19
LBB9_18:                                ;   in Loop: Header=BB9_19 Depth=1
	add	x9, x9, #8
	add	x8, x8, #1
	ldr	w10, [x20, #8]
	cmp	x8, x10
	b.hs	LBB9_23
LBB9_19:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB9_21 Depth 2
	ldr	x10, [x20]
	add	x10, x10, x8, lsl #4
	ldrb	w12, [x10]
	add	x11, x19, x9
	strb	w12, [x11]
	ldrb	w12, [x10, #2]
	strb	w12, [x11, #2]
	ldrb	w12, [x10, #3]
	strb	w12, [x11, #3]
	ldr	w12, [x10, #4]
	str	w12, [x11, #4]
	ldrh	w12, [x10, #2]
	cbz	w12, LBB9_18
; %bb.20:                               ;   in Loop: Header=BB9_19 Depth=1
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
LBB9_21:                                ;   Parent Loop BB9_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x14, [x10, #8]
	ldrb	w14, [x14, x12]
	add	x15, x11, x12
	strb	w14, [x15, #8]
	ldr	x14, [x10, #8]
	add	x14, x14, x12
	ldr	w14, [x14, #4]
	str	w14, [x15, #12]
	ldr	x14, [x10, #8]
	add	x14, x14, x12
	ldr	w14, [x14, #8]
	str	w14, [x15, #16]
	add	x13, x13, #1
	ldrh	w14, [x10, #2]
	add	x12, x12, #12
	cmp	x13, x14
	b.lo	LBB9_21
; %bb.22:                               ;   in Loop: Header=BB9_19 Depth=1
	add	x9, x9, x12
	b	LBB9_18
LBB9_23:
	mov	w0, #0                          ; =0x0
LBB9_24:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #128            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function forward_record_graph
_forward_record_graph:                  ; @forward_record_graph
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w19, w1
	cbz	w1, LBB10_19
; %bb.1:
	mov	x8, #0                          ; =0x0
	eor	w9, w3, #0x1
	b	LBB10_3
LBB10_2:                                ;   in Loop: Header=BB10_3 Depth=1
	add	x8, x8, #1
	cmp	x8, x19
	b.eq	LBB10_19
LBB10_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_9 Depth 2
	add	x12, x0, x8, lsl #4
	ldrb	w10, [x12]
	cmp	w10, #2
	csel	w11, wzr, w3, ne
	cmp	w10, #0
	ccmp	w11, #0, #0, ne
	b.eq	LBB10_18
; %bb.4:                                ;   in Loop: Header=BB10_3 Depth=1
	ldrh	w11, [x12, #2]
	cbz	x11, LBB10_2
; %bb.5:                                ;   in Loop: Header=BB10_3 Depth=1
	cmp	w10, #0
	ldr	x12, [x12, #8]
	csinc	w13, w9, wzr, ne
	and	w13, w2, w13
	add	x12, x12, #4
	eor	w13, w13, #0x1
	b	LBB10_9
LBB10_6:                                ;   in Loop: Header=BB10_9 Depth=2
	cmp	w14, #7
	csinc	w14, w13, wzr, eq
	tbnz	w14, #0, LBB10_18
LBB10_7:                                ;   in Loop: Header=BB10_9 Depth=2
	ldr	w14, [x12]
	cmn	w14, #1
	b.ne	LBB10_18
LBB10_8:                                ;   in Loop: Header=BB10_9 Depth=2
	add	x12, x12, #12
	subs	x11, x11, #1
	b.eq	LBB10_2
LBB10_9:                                ;   Parent Loop BB10_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w14, [x12, #-4]
	sub	w15, w14, #1
	cmp	w15, #5
	b.lo	LBB10_7
; %bb.10:                               ;   in Loop: Header=BB10_9 Depth=2
	cmp	w14, #8
	b.ne	LBB10_15
; %bb.11:                               ;   in Loop: Header=BB10_9 Depth=2
	ldr	w14, [x12]
	cmp	x14, x19
	b.hs	LBB10_18
; %bb.12:                               ;   in Loop: Header=BB10_9 Depth=2
	cbz	w3, LBB10_8
; %bb.13:                               ;   in Loop: Header=BB10_9 Depth=2
	cbnz	w10, LBB10_18
; %bb.14:                               ;   in Loop: Header=BB10_9 Depth=2
	lsl	x14, x14, #4
	ldrb	w14, [x0, x14]
	cbz	w14, LBB10_8
	b	LBB10_18
LBB10_15:                               ;   in Loop: Header=BB10_9 Depth=2
	cbz	w4, LBB10_6
; %bb.16:                               ;   in Loop: Header=BB10_9 Depth=2
	cmp	w14, #13
	b.ne	LBB10_6
; %bb.17:                               ;   in Loop: Header=BB10_9 Depth=2
	cbz	w10, LBB10_7
LBB10_18:
	mov	w19, #13                        ; =0xd
	b	LBB10_38
LBB10_19:
	mov	x23, x5
	mov	x22, x0
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x21, x0
	mov	x0, x19
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x20, x0
	cbz	x21, LBB10_33
; %bb.20:
	cbz	x20, LBB10_33
; %bb.21:
	cbz	x19, LBB10_37
; %bb.22:
	mov	x8, #0                          ; =0x0
	mov	w9, #2                          ; =0x2
	mov	w10, #12                        ; =0xc
	mov	w11, #1                         ; =0x1
	mov	x12, x22
	b	LBB10_24
LBB10_23:                               ;   in Loop: Header=BB10_24 Depth=1
	add	x8, x8, #1
	cmp	x8, x19
	b.eq	LBB10_36
LBB10_24:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_28 Depth 2
	ldrb	w13, [x21, x8]
	cbnz	w13, LBB10_23
; %bb.25:                               ;   in Loop: Header=BB10_24 Depth=1
	stp	w8, wzr, [x20]
	mov	w13, #1                         ; =0x1
	strb	w13, [x21, x8]
	b	LBB10_28
LBB10_26:                               ;   in Loop: Header=BB10_28 Depth=2
	strb	w9, [x21, x17]
	mov	x13, x15
LBB10_27:                               ;   in Loop: Header=BB10_28 Depth=2
	cbz	w13, LBB10_23
LBB10_28:                               ;   Parent Loop BB10_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	w15, w13, #1
	add	x14, x20, w15, uxtw #3
	ldp	w17, w16, [x14]
	add	x1, x12, x17, lsl #4
	ldrh	w2, [x1, #2]
	cmp	w16, w2
	b.eq	LBB10_26
; %bb.29:                               ;   in Loop: Header=BB10_28 Depth=2
	ldr	x15, [x1, #8]
	add	w17, w16, #1
	str	w17, [x14, #4]
	umaddl	x14, w16, w10, x15
	ldr	w14, [x14, #4]
	cmn	w14, #1
	b.eq	LBB10_27
; %bb.30:                               ;   in Loop: Header=BB10_28 Depth=2
	ldrb	w15, [x21, w14, uxtw]
	cmp	w15, #2
	b.eq	LBB10_27
; %bb.31:                               ;   in Loop: Header=BB10_28 Depth=2
	cmp	w15, #1
	b.eq	LBB10_35
; %bb.32:                               ;   in Loop: Header=BB10_28 Depth=2
	strb	w11, [x21, w14, uxtw]
	add	x15, x20, w13, uxtw #3
	add	w13, w13, #1
	stp	w14, wzr, [x15]
	b	LBB10_27
LBB10_33:
	mov	w19, #1                         ; =0x1
	cbz	x23, LBB10_37
; %bb.34:
	strb	w19, [x23]
	b	LBB10_37
LBB10_35:
	mov	w19, #13                        ; =0xd
	b	LBB10_37
LBB10_36:
	mov	w19, #0                         ; =0x0
LBB10_37:
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_free
LBB10_38:
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
