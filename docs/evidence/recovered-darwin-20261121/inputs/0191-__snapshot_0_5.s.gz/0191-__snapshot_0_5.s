	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm2c_emit_file_cyclic_bytes   ; -- Begin function nvm2c_emit_file_cyclic_bytes
	.p2align	2
_nvm2c_emit_file_cyclic_bytes:          ; @nvm2c_emit_file_cyclic_bytes
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1184
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x5
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	bl	_nvm_file_host_enter_query
	mov	x25, x0
	cmp	w0, #1
	b.le	LBB0_5
; %bb.1:
	cmp	w25, #5
	b.eq	LBB0_8
; %bb.2:
	cmp	w25, #3
	b.eq	LBB0_9
; %bb.3:
	cmp	w25, #2
	b.ne	LBB0_7
; %bb.4:
	mov	w25, #4                         ; =0x4
	b	LBB0_122
LBB0_5:
	cbz	w25, LBB0_10
; %bb.6:
	cmp	w25, #1
	b.eq	LBB0_122
LBB0_7:
	mov	w25, #2                         ; =0x2
	b	LBB0_122
LBB0_8:
	mov	w25, #11                        ; =0xb
	b	LBB0_122
LBB0_9:
	mov	w25, #5                         ; =0x5
	b	LBB0_122
LBB0_10:
	cbz	x23, LBB0_117
; %bb.11:
	cbz	x24, LBB0_117
; %bb.12:
	cbz	x21, LBB0_117
; %bb.13:
	cbnz	x20, LBB0_15
; %bb.14:
	cbnz	x19, LBB0_120
LBB0_15:
	cbz	x22, LBB0_117
; %bb.16:
	ldrb	w8, [x22]
	cbz	w8, LBB0_117
; %bb.17:
	and	w8, w8, #0xffffffdf
	sub	w8, w8, #65
	cmp	w8, #25
	b.hi	LBB0_117
; %bb.18:
	ldrb	w12, [x22, #1]
	cbz	w12, LBB0_24
; %bb.19:
	mov	w8, #1                          ; =0x1
	mov	w9, #2                          ; =0x2
	mov	w10, #223                       ; =0xdf
	mov	w11, #95                        ; =0x5f
LBB0_20:                                ; =>This Inner Loop Header: Depth=1
	and	w13, w12, w10
	sub	w13, w13, #65
	cmp	w13, #26
	b.lo	LBB0_22
; %bb.21:                               ;   in Loop: Header=BB0_20 Depth=1
	sub	w13, w12, #58
	cmn	w13, #10
	ccmp	w12, w11, #4, lo
	b.ne	LBB0_117
LBB0_22:                                ;   in Loop: Header=BB0_20 Depth=1
	cmp	x9, #64
	b.eq	LBB0_117
; %bb.23:                               ;   in Loop: Header=BB0_20 Depth=1
	add	x8, x8, #1
	ldrb	w12, [x22, x9]
	add	x9, x9, #1
	cbnz	w12, LBB0_20
LBB0_24:
	str	xzr, [sp, #168]
	add	x2, sp, #168
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_file_cyclic_hosted_prepare
	mov	x25, x0
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB0_124
; %bb.25:
	cbnz	w25, LBB0_123
; %bb.26:
	ldr	x0, [sp, #168]
	add	x1, sp, #72
	bl	_nvm_file_cyclic_hosted_startup
	cbz	w0, LBB0_127
; %bb.27:
	ldr	x25, [sp, #168]
	add	x1, sp, #464
	mov	x0, x25
	bl	_nvm_file_cyclic_hosted_startup
	cbz	w0, LBB0_127
; %bb.28:
	ldrb	w8, [sp, #552]
	tbnz	w8, #0, LBB0_127
; %bb.29:
	ldr	w8, [sp, #476]
	cbz	w8, LBB0_110
; %bb.30:
	mov	w26, #0                         ; =0x0
LBB0_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_35 Depth 2
                                        ;       Child Loop BB0_43 Depth 3
	add	x2, sp, #376
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB0_127
; %bb.32:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrb	w8, [sp, #456]
	cbnz	w8, LBB0_127
; %bb.33:                               ;   in Loop: Header=BB0_31 Depth=1
	ldrh	w8, [sp, #384]
	cbz	w8, LBB0_109
; %bb.34:                               ;   in Loop: Header=BB0_31 Depth=1
	mov	w28, #0                         ; =0x0
LBB0_35:                                ;   Parent Loop BB0_31 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_43 Depth 3
	and	w2, w28, #0xffff
	add	x3, sp, #560
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_instruction
	cbz	w0, LBB0_127
; %bb.36:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w0, [sp, #568]
	bl	_fcd_supported
	ldrb	w8, [sp, #636]
	cmp	w0, #0
	ccmp	w8, #2, #2, ne
	b.hi	LBB0_127
; %bb.37:                               ;   in Loop: Header=BB0_35 Depth=2
	and	w2, w28, #0xffff
	add	x3, sp, #375
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_127
; %bb.38:                               ;   in Loop: Header=BB0_35 Depth=2
	ldrb	w8, [sp, #375]
	cmp	w8, #16
	b.hi	LBB0_127
; %bb.39:                               ;   in Loop: Header=BB0_35 Depth=2
	tst	w28, #0xffff
	b.ne	LBB0_41
; %bb.40:                               ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_127
LBB0_41:                                ;   in Loop: Header=BB0_35 Depth=2
	cbz	w8, LBB0_108
; %bb.42:                               ;   in Loop: Header=BB0_35 Depth=2
	mov	w9, #0                          ; =0x0
LBB0_43:                                ;   Parent Loop BB0_31 Depth=1
                                        ;     Parent Loop BB0_35 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w2, w28, #0xffff
	str	w9, [sp, #68]                   ; 4-byte Folded Spill
	and	w3, w9, #0xff
	add	x4, sp, #264
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_variant
	cbz	w0, LBB0_127
; %bb.44:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #284]
	tbz	w8, #0, LBB0_127
; %bb.45:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w27, [sp, #568]
	mov	x0, x27
	bl	_fcd_supported
	cbz	w0, LBB0_127
; %bb.46:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	cmp	w27, #147
	b.gt	LBB0_50
; %bb.47:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #60
	b.gt	LBB0_54
; %bb.48:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #15
	b.eq	LBB0_60
; %bb.49:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #59
	b.eq	LBB0_60
	b	LBB0_63
LBB0_50:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #150
	b.gt	LBB0_57
; %bb.51:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #148
	b.eq	LBB0_61
; %bb.52:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #149
	b.ne	LBB0_63
; %bb.53:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #2                          ; =0x2
	b	LBB0_63
LBB0_54:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #61
	b.eq	LBB0_62
; %bb.55:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	b.ne	LBB0_63
; %bb.56:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #6                          ; =0x6
	b	LBB0_63
LBB0_57:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #151
	b.eq	LBB0_60
; %bb.58:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #161
	b.ne	LBB0_63
; %bb.59:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #3                          ; =0x3
	b	LBB0_63
LBB0_60:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #5                          ; =0x5
	b	LBB0_63
LBB0_61:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_63
LBB0_62:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #4                          ; =0x4
LBB0_63:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #296]
	cmp	w9, w8
	b.ne	LBB0_127
; %bb.64:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #286]
	cmp	w27, #146
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.65:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #285]
	cmp	w27, #61
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.66:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #59
	b.ne	LBB0_68
; %bb.67:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #1                          ; =0x1
	b	LBB0_69
LBB0_68:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #15
	mov	w8, #151                        ; =0x97
	ccmp	w27, w8, #4, ne
	cset	w8, eq
LBB0_69:                                ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	ldrb	w9, [sp, #287]
	csinc	w8, w8, wzr, ne
	cmp	w9, w8
	b.ne	LBB0_127
; %bb.70:                               ;   in Loop: Header=BB0_43 Depth=3
	cbz	w8, LBB0_81
; %bb.71:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #312]
	ldr	w9, [sp, #560]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.72:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #316]
	ldr	w9, [sp, #576]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.73:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	cset	w8, ne
	ldr	w9, [sp, #308]
	cmp	w9, w8
	b.ne	LBB0_127
; %bb.74:                               ;   in Loop: Header=BB0_43 Depth=3
	cmp	w27, #145
	b.ne	LBB0_82
; %bb.75:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w27, [sp, #1152]
	add	x2, sp, #176
	mov	x0, x25
	mov	x1, x27
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB0_127
; %bb.76:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #176]
	ldr	w9, [sp, #316]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.77:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	x0, x27
	bl	_nl_file_catalog_method
	cbz	x0, LBB0_127
; %bb.78:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #324]
	ldr	w9, [x0, #36]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.79:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w8, [sp, #328]
	ldr	w9, [x0, #40]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.80:                               ;   in Loop: Header=BB0_43 Depth=3
	mov	w8, #0                          ; =0x0
	subs	w9, w27, #1
	cmp	w9, #3
	mov	w9, #399                        ; =0x18f
	mov	w10, #415                       ; =0x19f
	csel	w9, w10, w9, lo
	orr	w10, w9, #0x20
	cmp	w27, #1
	csel	w9, w10, w9, eq
	b	LBB0_83
LBB0_81:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #128                        ; =0x80
	b	LBB0_84
LBB0_82:                                ;   in Loop: Header=BB0_43 Depth=3
	mov	w9, #448                        ; =0x1c0
	mov	w8, #64                         ; =0x40
LBB0_83:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #320]
	cmp	w10, w9
	b.ne	LBB0_127
LBB0_84:                                ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #300]
	cmp	w10, w8
	b.ne	LBB0_127
; %bb.85:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w10, [sp, #304]
	bic	w8, w9, w8
	cmp	w10, w8
	b.ne	LBB0_127
; %bb.86:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #288]
	ldrh	w9, [sp, #266]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.87:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w8, [sp, #290]
	ldrh	w9, [sp, #276]
	cmp	w8, w9
	b.ne	LBB0_127
; %bb.88:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #364]
	ldrb	w9, [sp, #636]
	lsr	w10, w8, w9
	cbnz	w10, LBB0_127
; %bb.89:                               ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #0, LBB0_91
; %bb.90:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w9, [sp, #365]
	cmp	w9, #255
	b.eq	LBB0_96
	b	LBB0_127
LBB0_91:                                ;   in Loop: Header=BB0_43 Depth=3
	cbz	w9, LBB0_127
; %bb.92:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #632]
	ldrh	w8, [sp, #384]
	cmp	w2, w8
	b.hs	LBB0_127
; %bb.93:                               ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #176
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_127
; %bb.94:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #365]
	ldrb	w9, [sp, #176]
	cmp	w8, w9
	b.hs	LBB0_127
; %bb.95:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #364]
LBB0_96:                                ;   in Loop: Header=BB0_43 Depth=3
	tbnz	w8, #1, LBB0_98
; %bb.97:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #366]
	cmp	w8, #255
	b.eq	LBB0_102
	b	LBB0_127
LBB0_98:                                ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #636]
	cmp	w8, #2
	b.lo	LBB0_127
; %bb.99:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrh	w2, [sp, #634]
	ldrh	w8, [sp, #384]
	cmp	w2, w8
	b.hs	LBB0_127
; %bb.100:                              ;   in Loop: Header=BB0_43 Depth=3
	add	x3, sp, #176
	mov	x0, x25
	mov	x1, x26
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_127
; %bb.101:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #366]
	ldrb	w9, [sp, #176]
	cmp	w8, w9
	b.hs	LBB0_127
LBB0_102:                               ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #568]
	cmp	w8, #15
	b.eq	LBB0_105
; %bb.103:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #151
	b.eq	LBB0_105
; %bb.104:                              ;   in Loop: Header=BB0_43 Depth=3
	cmp	w8, #59
	b.ne	LBB0_107
LBB0_105:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w1, [sp, #576]
	add	x2, sp, #176
	mov	x0, x25
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB0_127
; %bb.106:                              ;   in Loop: Header=BB0_43 Depth=3
	ldrb	w8, [sp, #256]
	cbnz	w8, LBB0_127
LBB0_107:                               ;   in Loop: Header=BB0_43 Depth=3
	ldr	w9, [sp, #68]                   ; 4-byte Folded Reload
	add	w9, w9, #1
	ldrb	w8, [sp, #375]
	cmp	w8, w9, uxtb
	b.hi	LBB0_43
LBB0_108:                               ;   in Loop: Header=BB0_35 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #384]
	cmp	w8, w28, uxth
	b.hi	LBB0_35
LBB0_109:                               ;   in Loop: Header=BB0_31 Depth=1
	add	w26, w26, #1
	ldr	w8, [sp, #476]
	cmp	w26, w8
	b.lo	LBB0_31
LBB0_110:
	add	x8, sp, #464
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	add	x0, sp, #464
	bl	_fn_preamble
Lloh0:
	adrp	x1, l_.str.5@PAGE
Lloh1:
	add	x1, x1, l_.str.5@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
	mov	x27, #0                         ; =0x0
	mov	w28, #23                        ; =0x17
Lloh2:
	adrp	x26, l_.str.3@PAGE
Lloh3:
	add	x26, x26, l_.str.3@PAGEOFF
Lloh4:
	adrp	x25, l_.str.6@PAGE
Lloh5:
	add	x25, x25, l_.str.6@PAGEOFF
LBB0_111:                               ; =>This Inner Loop Header: Depth=1
	mov	x8, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x8, #43691
	umulh	x8, x27, x8
	lsr	x8, x8, #4
	mov	w9, #24                         ; =0x18
	madd	x8, x8, x9, x28
	ldrb	w9, [x24], #1
	cmp	x8, #0
Lloh6:
	adrp	x8, l_.str.7@PAGE
Lloh7:
	add	x8, x8, l_.str.7@PAGEOFF
	csel	x8, x8, x26, eq
	stp	x9, x8, [sp]
	add	x0, sp, #464
	mov	x1, x25
	bl	_fn_text
	add	x27, x27, #1
	sub	x28, x28, #1
	sub	x23, x23, #1
	cbnz	x23, LBB0_111
; %bb.112:
Lloh8:
	adrp	x1, l_.str.8@PAGE
Lloh9:
	add	x1, x1, l_.str.8@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
	ldr	x1, [sp, #168]
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #120]
	add	x8, sp, #464
	stp	q0, q1, [x8, #128]
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	stp	q0, q1, [x8, #160]
	ldur	q0, [sp, #72]
	ldur	q1, [sp, #88]
	stp	q0, q1, [x8, #96]
	add	x0, sp, #464
	add	x2, sp, #560
	bl	_fn_agreement
	ldr	w8, [sp, #84]
	cbz	w8, LBB0_226
; %bb.113:
	mov	w24, #0                         ; =0x0
Lloh10:
	adrp	x23, l_.str.9@PAGE
Lloh11:
	add	x23, x23, l_.str.9@PAGEOFF
LBB0_114:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #464
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #84]
	cmp	w24, w8
	b.lo	LBB0_114
; %bb.115:
	cbz	w8, LBB0_226
; %bb.116:
	mov	w23, #0                         ; =0x0
Lloh12:
	adrp	x25, l_.str.162@PAGE
Lloh13:
	add	x25, x25, l_.str.162@PAGEOFF
	b	LBB0_131
LBB0_117:
	mov	w25, #1                         ; =0x1
	cbz	x20, LBB0_121
; %bb.118:
	cbz	x19, LBB0_121
; %bb.119:
Lloh14:
	adrp	x2, l_.str@PAGE
Lloh15:
	add	x2, x2, l_.str@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
LBB0_120:
	mov	w25, #1                         ; =0x1
LBB0_121:
	bl	_nvm_file_host_leave
LBB0_122:
	mov	x0, x25
	add	sp, sp, #1184
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_123:
	cmp	w25, #2
	mov	w8, #1                          ; =0x1
	cinc	w25, w8, eq
LBB0_124:
	cbz	x19, LBB0_121
; %bb.125:
	mov	x8, x25
Lloh16:
	adrp	x9, l_.str.3@PAGE
Lloh17:
	add	x9, x9, l_.str.3@PAGEOFF
	stp	x9, x8, [sp]
Lloh18:
	adrp	x2, l_.str.1@PAGE
Lloh19:
	add	x2, x2, l_.str.1@PAGEOFF
LBB0_126:
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
	b	LBB0_121
LBB0_127:
	ldr	x0, [sp, #168]
	bl	_nvm_file_cyclic_hosted_free
	cbz	x19, LBB0_225
; %bb.128:
Lloh20:
	adrp	x8, l_.str.3@PAGE
Lloh21:
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [sp]
Lloh22:
	adrp	x2, l_.str.4@PAGE
Lloh23:
	add	x2, x2, l_.str.4@PAGEOFF
	mov	x0, x20
	mov	x1, x19
	bl	_snprintf
	mov	w25, #2                         ; =0x2
	b	LBB0_121
LBB0_129:                               ;   in Loop: Header=BB0_131 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #488]
LBB0_130:                               ;   in Loop: Header=BB0_131 Depth=1
	add	w23, w23, #1
	ldr	w8, [sp, #84]
	cmp	w23, w8
	b.hs	LBB0_226
LBB0_131:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_134 Depth 2
                                        ;     Child Loop BB0_140 Depth 2
	ldr	x24, [sp, #168]
	add	x2, sp, #264
	mov	x0, x24
	mov	x1, x23
	bl	_nvm_file_cyclic_hosted_function
	tbz	w0, #0, LBB0_129
; %bb.132:                              ;   in Loop: Header=BB0_131 Depth=1
	mov	x8, x23
	str	x8, [sp]
	add	x0, sp, #464
Lloh24:
	adrp	x1, l_.str.161@PAGE
Lloh25:
	add	x1, x1, l_.str.161@PAGEOFF
	bl	_fn_text
	ldrh	w8, [sp, #272]
	cbz	w8, LBB0_135
; %bb.133:                              ;   in Loop: Header=BB0_131 Depth=1
	mov	w26, #0                         ; =0x0
LBB0_134:                               ;   Parent Loop BB0_131 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	x26, [sp]
	add	x0, sp, #464
	mov	x1, x25
	bl	_fn_text
	add	w26, w26, #1
	ldrh	w8, [sp, #272]
	cmp	w26, w8
	b.lo	LBB0_134
LBB0_135:                               ;   in Loop: Header=BB0_131 Depth=1
	add	x0, sp, #464
Lloh26:
	adrp	x1, l_.str.163@PAGE
Lloh27:
	add	x1, x1, l_.str.163@PAGEOFF
	bl	_fn_text
	ldrh	w8, [sp, #272]
	cbz	w8, LBB0_224
; %bb.136:                              ;   in Loop: Header=BB0_131 Depth=1
	mov	w28, #0                         ; =0x0
	b	LBB0_140
LBB0_137:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh28:
	adrp	x1, l_.str.165@PAGE
Lloh29:
	add	x1, x1, l_.str.165@PAGEOFF
LBB0_138:                               ;   in Loop: Header=BB0_140 Depth=2
	bl	_fn_text
LBB0_139:                               ;   in Loop: Header=BB0_140 Depth=2
	add	w28, w28, #1
	ldrh	w8, [sp, #272]
	cmp	w28, w8
	b.hs	LBB0_224
LBB0_140:                               ;   Parent Loop BB0_131 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #560
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_file_cyclic_hosted_instruction
	cbz	w0, LBB0_129
; %bb.141:                              ;   in Loop: Header=BB0_140 Depth=2
	add	x3, sp, #376
	mov	x0, x24
	mov	x1, x23
	mov	x2, x28
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB0_129
; %bb.142:                              ;   in Loop: Header=BB0_140 Depth=2
	str	x28, [sp]
	add	x0, sp, #464
Lloh30:
	adrp	x1, l_.str.164@PAGE
Lloh31:
	add	x1, x1, l_.str.164@PAGEOFF
	bl	_fn_text
	ldrb	w8, [sp, #376]
	cbz	w8, LBB0_137
; %bb.143:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	x8, x28
	stp	x23, x8, [sp, #16]
	add	x0, sp, #464
	stp	x23, x8, [sp]
Lloh32:
	adrp	x1, l_.str.166@PAGE
Lloh33:
	add	x1, x1, l_.str.166@PAGEOFF
	bl	_fn_text
	ldrb	w26, [sp, #568]
	cmp	w26, #255
	b.eq	LBB0_190
; %bb.144:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w27, #1                         ; =0x1
Lloh34:
	adrp	x10, lJTI0_0@PAGE
Lloh35:
	add	x10, x10, lJTI0_0@PAGEOFF
	adr	x8, LBB0_145
	ldrh	w9, [x10, x26, lsl #1]
	add	x8, x8, x9, lsl #2
	br	x8
LBB0_145:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh36:
	adrp	x1, l_.str.184@PAGE
Lloh37:
	add	x1, x1, l_.str.184@PAGEOFF
	bl	_fn_text
	cmp	w26, #252
	b.eq	LBB0_147
; %bb.146:                              ;   in Loop: Header=BB0_140 Depth=2
	cmp	w26, #106
	b.ne	LBB0_173
LBB0_147:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #576]
	str	x8, [sp]
	add	x0, sp, #464
Lloh38:
	adrp	x1, l_.str.195@PAGE
Lloh39:
	add	x1, x1, l_.str.195@PAGEOFF
	b	LBB0_219
LBB0_148:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrb	w8, [sp, #636]
	cmp	w8, #1
	b.ne	LBB0_222
; %bb.149:                              ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #632]
	ldr	w9, [sp, #576]
	stp	x9, x8, [sp]
	add	x0, sp, #464
Lloh40:
	adrp	x1, l_.str.197@PAGE
Lloh41:
	add	x1, x1, l_.str.197@PAGEOFF
	b	LBB0_138
LBB0_150:                               ;   in Loop: Header=BB0_140 Depth=2
	cmp	w26, #3
	mov	w8, #4                          ; =0x4
	csel	w8, w8, wzr, eq
	cmp	w26, #1
	csinc	w8, w8, wzr, ne
	b.ne	LBB0_170
; %bb.151:                              ;   in Loop: Header=BB0_140 Depth=2
	ldr	x9, [sp, #576]
	b	LBB0_195
LBB0_152:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh42:
	adrp	x1, l_.str.187@PAGE
Lloh43:
	add	x1, x1, l_.str.187@PAGEOFF
	bl	_fn_text
	cmp	w26, #161
	b.ne	LBB0_172
; %bb.153:                              ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh44:
	adrp	x1, l_.str.188@PAGE
Lloh45:
	add	x1, x1, l_.str.188@PAGEOFF
	b	LBB0_219
LBB0_154:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #592]
	ldrh	w9, [sp, #584]
	cmp	w26, #251
	csel	w26, w8, w9, eq
	ldrh	w9, [sp, #600]
	csel	w8, w9, w8, eq
	and	w27, w8, #0xffff
	cmp	w27, #8
	b.hs	LBB0_222
; %bb.155:                              ;   in Loop: Header=BB0_140 Depth=2
	cbz	w27, LBB0_196
; %bb.156:                              ;   in Loop: Header=BB0_140 Depth=2
	str	x27, [sp]
	add	x0, sp, #464
Lloh46:
	adrp	x1, l_.str.190@PAGE
Lloh47:
	add	x1, x1, l_.str.190@PAGEOFF
	bl	_fn_text
	stp	x27, xzr, [sp]
	add	x0, sp, #464
Lloh48:
	adrp	x1, l_.str.191@PAGE
Lloh49:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #1
	b.eq	LBB0_163
; %bb.157:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #1                          ; =0x1
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh50:
	adrp	x1, l_.str.191@PAGE
Lloh51:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #2
	b.eq	LBB0_163
; %bb.158:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #2                          ; =0x2
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh52:
	adrp	x1, l_.str.191@PAGE
Lloh53:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #3
	b.eq	LBB0_163
; %bb.159:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #3                          ; =0x3
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh54:
	adrp	x1, l_.str.191@PAGE
Lloh55:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #4
	b.eq	LBB0_163
; %bb.160:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #4                          ; =0x4
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh56:
	adrp	x1, l_.str.191@PAGE
Lloh57:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #5
	b.eq	LBB0_163
; %bb.161:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #5                          ; =0x5
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh58:
	adrp	x1, l_.str.191@PAGE
Lloh59:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
	subs	w8, w27, #6
	b.eq	LBB0_163
; %bb.162:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w9, #6                          ; =0x6
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh60:
	adrp	x1, l_.str.191@PAGE
Lloh61:
	add	x1, x1, l_.str.191@PAGEOFF
	bl	_fn_text
LBB0_163:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh62:
	adrp	x1, l_.str.192@PAGE
Lloh63:
	add	x1, x1, l_.str.192@PAGEOFF
	b	LBB0_197
LBB0_164:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh64:
	adrp	x1, l_.str.175@PAGE
Lloh65:
	add	x1, x1, l_.str.175@PAGEOFF
	b	LBB0_219
LBB0_165:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh66:
	adrp	x1, l_.str.178@PAGE
Lloh67:
	add	x1, x1, l_.str.178@PAGEOFF
	b	LBB0_219
LBB0_166:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #576]
	cmp	w26, #11
	cset	w9, eq
Lloh68:
	adrp	x10, l_.str.174@PAGE
Lloh69:
	add	x10, x10, l_.str.174@PAGEOFF
Lloh70:
	adrp	x11, l_.str.173@PAGE
Lloh71:
	add	x11, x11, l_.str.173@PAGEOFF
	csel	x10, x11, x10, eq
	stp	x9, x10, [sp, #8]
	add	x0, sp, #464
	str	x8, [sp]
Lloh72:
	adrp	x1, l_.str.172@PAGE
Lloh73:
	add	x1, x1, l_.str.172@PAGEOFF
	b	LBB0_219
LBB0_167:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh74:
	adrp	x1, l_.str.169@PAGE
Lloh75:
	add	x1, x1, l_.str.169@PAGEOFF
	bl	_fn_text
	cmp	w26, #8
	b.ne	LBB0_169
; %bb.168:                              ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh76:
	adrp	x1, l_.str.170@PAGE
Lloh77:
	add	x1, x1, l_.str.170@PAGEOFF
	bl	_fn_text
LBB0_169:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh78:
	adrp	x1, l_.str.171@PAGE
Lloh79:
	add	x1, x1, l_.str.171@PAGEOFF
	b	LBB0_219
LBB0_170:                               ;   in Loop: Header=BB0_140 Depth=2
	cmp	w26, #3
	b.ne	LBB0_194
; %bb.171:                              ;   in Loop: Header=BB0_140 Depth=2
	ldrb	w9, [sp, #576]
	b	LBB0_195
LBB0_172:                               ;   in Loop: Header=BB0_140 Depth=2
	cmp	w26, #57
	cset	w8, eq
	str	x8, [sp]
	add	x0, sp, #464
Lloh80:
	adrp	x1, l_.str.189@PAGE
Lloh81:
	add	x1, x1, l_.str.189@PAGEOFF
	b	LBB0_187
LBB0_173:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh82:
	adrp	x1, l_.str.196@PAGE
Lloh83:
	add	x1, x1, l_.str.196@PAGEOFF
	b	LBB0_219
LBB0_174:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh84:
	adrp	x1, l_.str.177@PAGE
Lloh85:
	add	x1, x1, l_.str.177@PAGEOFF
	b	LBB0_219
LBB0_175:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #576]
	str	x8, [sp]
	add	x0, sp, #464
Lloh86:
	adrp	x1, l_.str.180@PAGE
Lloh87:
	add	x1, x1, l_.str.180@PAGEOFF
	b	LBB0_219
LBB0_176:                               ;   in Loop: Header=BB0_140 Depth=2
	ldr	w26, [sp, #1152]
	subs	w8, w26, #1
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	cset	w27, eq
	add	x0, sp, #464
Lloh88:
	adrp	x1, l_.str.183@PAGE
Lloh89:
	add	x1, x1, l_.str.183@PAGEOFF
	bl	_fn_text
	cmp	w26, #4
	csinc	w27, w27, wzr, ne
	b.eq	LBB0_178
; %bb.177:                              ;   in Loop: Header=BB0_140 Depth=2
	cmp	w26, #1
	b.ne	LBB0_179
LBB0_178:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh90:
	adrp	x1, l_.str.184@PAGE
Lloh91:
	add	x1, x1, l_.str.184@PAGEOFF
	bl	_fn_text
LBB0_179:                               ;   in Loop: Header=BB0_140 Depth=2
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #2
	b.hi	LBB0_181
; %bb.180:                              ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #584]
	str	x8, [sp]
	add	x0, sp, #464
Lloh92:
	adrp	x1, l_.str.185@PAGE
Lloh93:
	add	x1, x1, l_.str.185@PAGEOFF
	bl	_fn_text
LBB0_181:                               ;   in Loop: Header=BB0_140 Depth=2
	ldr	w8, [sp, #576]
	stp	x8, x27, [sp]
	add	x0, sp, #464
Lloh94:
	adrp	x1, l_.str.186@PAGE
Lloh95:
	add	x1, x1, l_.str.186@PAGEOFF
	b	LBB0_219
LBB0_182:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh96:
	adrp	x1, l_.str.168@PAGE
Lloh97:
	add	x1, x1, l_.str.168@PAGEOFF
	b	LBB0_219
LBB0_183:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh98:
	adrp	x1, l_.str.179@PAGE
Lloh99:
	add	x1, x1, l_.str.179@PAGEOFF
	b	LBB0_219
LBB0_184:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh100:
	adrp	x1, l_.str.176@PAGE
Lloh101:
	add	x1, x1, l_.str.176@PAGEOFF
	b	LBB0_219
LBB0_185:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh102:
	adrp	x1, l_.str.198@PAGE
Lloh103:
	add	x1, x1, l_.str.198@PAGEOFF
	b	LBB0_138
LBB0_186:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #576]
	str	x8, [sp]
	add	x0, sp, #464
Lloh104:
	adrp	x1, l_.str.181@PAGE
Lloh105:
	add	x1, x1, l_.str.181@PAGEOFF
LBB0_187:                               ;   in Loop: Header=BB0_140 Depth=2
	bl	_fn_text
	ldrb	w8, [sp, #636]
	cmp	w8, #2
	b.ne	LBB0_222
; %bb.188:                              ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #634]
	ldrh	w9, [sp, #632]
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh106:
	adrp	x1, l_.str.199@PAGE
Lloh107:
	add	x1, x1, l_.str.199@PAGEOFF
	b	LBB0_138
LBB0_189:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #576]
	ldrb	w9, [sp, #584]
	cmp	w9, #0
	mov	w9, #2                          ; =0x2
	cinc	x9, x9, ne
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh108:
	adrp	x1, l_.str.182@PAGE
Lloh109:
	add	x1, x1, l_.str.182@PAGEOFF
	b	LBB0_219
LBB0_190:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w27, #0                         ; =0x0
LBB0_191:                               ;   in Loop: Header=BB0_140 Depth=2
	and	w8, w26, #0xfe
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	cmp	w8, #48
	mov	w8, #50                         ; =0x32
	ccmp	w26, w8, #4, ne
	mov	w8, #4                          ; =0x4
	csinc	w8, w8, wzr, eq
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	sub	w8, w26, #32
	cmp	w8, #181
	b.hi	LBB0_223
; %bb.192:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh110:
	adrp	x11, lJTI0_1@PAGE
Lloh111:
	add	x11, x11, lJTI0_1@PAGEOFF
	adr	x9, LBB0_193
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
Lloh112:
	adrp	x8, l_.str.201@PAGE
Lloh113:
	add	x8, x8, l_.str.201@PAGEOFF
	br	x9
LBB0_193:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh114:
	adrp	x8, l_.str.202@PAGE
Lloh115:
	add	x8, x8, l_.str.202@PAGEOFF
	b	LBB0_211
LBB0_194:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	x9, #0                          ; =0x0
LBB0_195:                               ;   in Loop: Header=BB0_140 Depth=2
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh116:
	adrp	x1, l_.str.167@PAGE
Lloh117:
	add	x1, x1, l_.str.167@PAGEOFF
	b	LBB0_219
LBB0_196:                               ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh118:
	adrp	x1, l_.str.193@PAGE
Lloh119:
	add	x1, x1, l_.str.193@PAGEOFF
LBB0_197:                               ;   in Loop: Header=BB0_140 Depth=2
	bl	_fn_text
	ldr	w8, [sp, #1152]
	and	x9, x26, #0xffff
	stp	x9, x27, [sp, #8]
	str	x8, [sp]
	add	x0, sp, #464
Lloh120:
	adrp	x1, l_.str.194@PAGE
Lloh121:
	add	x1, x1, l_.str.194@PAGEOFF
	b	LBB0_219
LBB0_198:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh122:
	adrp	x8, l_.str.212@PAGE
Lloh123:
	add	x8, x8, l_.str.212@PAGEOFF
	b	LBB0_211
LBB0_199:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh124:
	adrp	x8, l_.str.205@PAGE
Lloh125:
	add	x8, x8, l_.str.205@PAGEOFF
	b	LBB0_211
LBB0_200:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh126:
	adrp	x8, l_.str.206@PAGE
Lloh127:
	add	x8, x8, l_.str.206@PAGEOFF
	b	LBB0_211
LBB0_201:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh128:
	adrp	x8, l_.str.210@PAGE
Lloh129:
	add	x8, x8, l_.str.210@PAGEOFF
	b	LBB0_211
LBB0_202:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh130:
	adrp	x8, l_.str.203@PAGE
Lloh131:
	add	x8, x8, l_.str.203@PAGEOFF
	b	LBB0_211
LBB0_203:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh132:
	adrp	x8, l_.str.207@PAGE
Lloh133:
	add	x8, x8, l_.str.207@PAGEOFF
	b	LBB0_211
LBB0_204:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #1                         ; =0x1
Lloh134:
	adrp	x8, l_.str.204@PAGE
Lloh135:
	add	x8, x8, l_.str.204@PAGEOFF
	b	LBB0_211
LBB0_205:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh136:
	adrp	x8, l_.str.208@PAGE
Lloh137:
	add	x8, x8, l_.str.208@PAGEOFF
	b	LBB0_211
LBB0_206:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh138:
	adrp	x8, l_.str.209@PAGE
Lloh139:
	add	x8, x8, l_.str.209@PAGEOFF
	b	LBB0_211
LBB0_207:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh140:
	adrp	x8, l_.str.211@PAGE
Lloh141:
	add	x8, x8, l_.str.211@PAGEOFF
	b	LBB0_211
LBB0_208:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh142:
	adrp	x8, l_.str.213@PAGE
Lloh143:
	add	x8, x8, l_.str.213@PAGEOFF
	b	LBB0_211
LBB0_209:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh144:
	adrp	x8, l_.str.215@PAGE
Lloh145:
	add	x8, x8, l_.str.215@PAGEOFF
	b	LBB0_211
LBB0_210:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w12, #4                         ; =0x4
Lloh146:
	adrp	x8, l_.str.214@PAGE
Lloh147:
	add	x8, x8, l_.str.214@PAGEOFF
LBB0_211:                               ;   in Loop: Header=BB0_140 Depth=2
	stp	x8, x12, [sp, #40]              ; 16-byte Folded Spill
	cmp	w27, #0
	mov	w8, #1                          ; =0x1
	cinc	x26, x8, eq
	str	x26, [sp]
	add	x0, sp, #464
Lloh148:
	adrp	x1, l_.str.190@PAGE
Lloh149:
	add	x1, x1, l_.str.190@PAGEOFF
	bl	_fn_text
	stp	xzr, xzr, [sp, #16]
	add	x0, sp, #464
	stp	x26, xzr, [sp]
Lloh150:
	adrp	x1, l_.str.216@PAGE
Lloh151:
	add	x1, x1, l_.str.216@PAGEOFF
	bl	_fn_text
	tbnz	w27, #0, LBB0_213
; %bb.212:                              ;   in Loop: Header=BB0_140 Depth=2
	mov	w8, #1                          ; =0x1
	stp	x8, x8, [sp, #16]
	add	x0, sp, #464
	stp	x8, x8, [sp]
Lloh152:
	adrp	x1, l_.str.216@PAGE
Lloh153:
	add	x1, x1, l_.str.216@PAGEOFF
	bl	_fn_text
LBB0_213:                               ;   in Loop: Header=BB0_140 Depth=2
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #464
Lloh154:
	adrp	x1, l_.str.217@PAGE
Lloh155:
	add	x1, x1, l_.str.217@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #40
Lloh156:
	adrp	x26, l_.str.219@PAGE
Lloh157:
	add	x26, x26, l_.str.219@PAGEOFF
	b.ne	LBB0_215
; %bb.214:                              ;   in Loop: Header=BB0_140 Depth=2
	add	x0, sp, #464
Lloh158:
	adrp	x1, l_.str.218@PAGE
Lloh159:
	add	x1, x1, l_.str.218@PAGEOFF
	bl	_fn_text
LBB0_215:                               ;   in Loop: Header=BB0_140 Depth=2
	str	xzr, [sp]
	add	x0, sp, #464
	mov	x1, x26
	bl	_fn_text
	tbz	w27, #0, LBB0_217
; %bb.216:                              ;   in Loop: Header=BB0_140 Depth=2
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
Lloh160:
	adrp	x8, l_.str.221@PAGE
Lloh161:
	add	x8, x8, l_.str.221@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh162:
	adrp	x1, l_.str.220@PAGE
Lloh163:
	add	x1, x1, l_.str.220@PAGEOFF
	bl	_fn_text
	mov	w8, #0                          ; =0x0
Lloh164:
	adrp	x27, l_.str.223@PAGE
Lloh165:
	add	x27, x27, l_.str.223@PAGEOFF
	b	LBB0_218
LBB0_217:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	x1, x26
	mov	w26, #1                         ; =0x1
	str	x26, [sp]
	add	x0, sp, #464
	bl	_fn_text
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
Lloh166:
	adrp	x8, l_.str.222@PAGE
Lloh167:
	add	x8, x8, l_.str.222@PAGEOFF
	stp	x8, x9, [sp]
	add	x0, sp, #464
Lloh168:
	adrp	x1, l_.str.220@PAGE
Lloh169:
	add	x1, x1, l_.str.220@PAGEOFF
	bl	_fn_text
	str	xzr, [sp]
	add	x0, sp, #464
Lloh170:
	adrp	x27, l_.str.223@PAGE
Lloh171:
	add	x27, x27, l_.str.223@PAGEOFF
	mov	x1, x27
	bl	_fn_text
	mov	x8, x26
LBB0_218:                               ;   in Loop: Header=BB0_140 Depth=2
	str	x8, [sp]
	add	x0, sp, #464
	mov	x1, x27
	bl	_fn_text
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp]
	add	x0, sp, #464
Lloh172:
	adrp	x1, l_.str.224@PAGE
Lloh173:
	add	x1, x1, l_.str.224@PAGEOFF
LBB0_219:                               ;   in Loop: Header=BB0_140 Depth=2
	bl	_fn_text
LBB0_220:                               ;   in Loop: Header=BB0_140 Depth=2
	ldrb	w8, [sp, #636]
	cmp	w8, #1
	b.ne	LBB0_222
; %bb.221:                              ;   in Loop: Header=BB0_140 Depth=2
	ldrh	w8, [sp, #632]
	str	x8, [sp]
	add	x0, sp, #464
Lloh174:
	adrp	x1, l_.str.200@PAGE
Lloh175:
	add	x1, x1, l_.str.200@PAGEOFF
	b	LBB0_138
LBB0_222:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #488]
	b	LBB0_139
LBB0_223:                               ;   in Loop: Header=BB0_140 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #488]
	b	LBB0_220
LBB0_224:                               ;   in Loop: Header=BB0_131 Depth=1
	add	x0, sp, #464
Lloh176:
	adrp	x1, l_.str.31@PAGE
Lloh177:
	add	x1, x1, l_.str.31@PAGEOFF
	bl	_fn_text
	b	LBB0_130
LBB0_225:
	mov	w25, #2                         ; =0x2
	b	LBB0_121
LBB0_226:
Lloh178:
	adrp	x8, l_.str.11@PAGE
Lloh179:
	add	x8, x8, l_.str.11@PAGEOFF
	str	x8, [sp]
Lloh180:
	adrp	x1, l_.str.10@PAGE
Lloh181:
	add	x1, x1, l_.str.10@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
Lloh182:
	adrp	x1, l_.str.13@PAGE
Lloh183:
	add	x1, x1, l_.str.13@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
	ldr	w8, [sp, #84]
	cbz	w8, LBB0_229
; %bb.227:
	mov	w24, #0                         ; =0x0
Lloh184:
	adrp	x23, l_.str.14@PAGE
Lloh185:
	add	x23, x23, l_.str.14@PAGEOFF
LBB0_228:                               ; =>This Inner Loop Header: Depth=1
	str	x24, [sp]
	add	x0, sp, #464
	mov	x1, x23
	bl	_fn_text
	add	w24, w24, #1
	ldr	w8, [sp, #84]
	cmp	w24, w8
	b.lo	LBB0_228
LBB0_229:
	ldr	w8, [sp, #80]
	cmn	w8, #1
	b.eq	LBB0_231
; %bb.230:
	str	x8, [sp]
Lloh186:
	adrp	x1, l_.str.15@PAGE
Lloh187:
	add	x1, x1, l_.str.15@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
LBB0_231:
	ldr	w8, [sp, #76]
	stp	x8, x8, [sp]
Lloh188:
	adrp	x1, l_.str.16@PAGE
Lloh189:
	add	x1, x1, l_.str.16@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
	str	x22, [sp]
Lloh190:
	adrp	x1, l_.str.17@PAGE
Lloh191:
	add	x1, x1, l_.str.17@PAGEOFF
	add	x0, sp, #464
	bl	_fn_text
	ldr	x0, [sp, #168]
	bl	_nvm_file_cyclic_hosted_free
	ldr	w25, [sp, #488]
	ldr	x0, [sp, #464]
	cbz	w25, LBB0_234
; %bb.232:
	bl	_free
	cbz	x19, LBB0_121
; %bb.233:
Lloh192:
	adrp	x8, l_.str.3@PAGE
Lloh193:
	add	x8, x8, l_.str.3@PAGEOFF
	stp	x8, x25, [sp]
Lloh194:
	adrp	x2, l_.str.18@PAGE
Lloh195:
	add	x2, x2, l_.str.18@PAGEOFF
	b	LBB0_126
LBB0_234:
	str	x0, [x21]
	cbz	x19, LBB0_121
; %bb.235:
	strb	wzr, [x20]
	b	LBB0_121
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh108, Lloh109
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh110, Lloh111
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh182, Lloh183
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh184, Lloh185
	.loh AdrpAdd	Lloh186, Lloh187
	.loh AdrpAdd	Lloh190, Lloh191
	.loh AdrpAdd	Lloh188, Lloh189
	.loh AdrpAdd	Lloh194, Lloh195
	.loh AdrpAdd	Lloh192, Lloh193
	.cfi_endproc
	.section	__TEXT,__const
	.p2align	1, 0x0
lJTI0_0:
	.short	(LBB0_220-LBB0_145)>>2
	.short	(LBB0_150-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_150-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_150-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_182-LBB0_145)>>2
	.short	(LBB0_167-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_166-LBB0_145)>>2
	.short	(LBB0_164-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_148-LBB0_145)>>2
	.short	(LBB0_166-LBB0_145)>>2
	.short	(LBB0_164-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_184-LBB0_145)>>2
	.short	(LBB0_174-LBB0_145)>>2
	.short	(LBB0_165-LBB0_145)>>2
	.short	(LBB0_165-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_191-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_191-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_220-LBB0_145)>>2
	.short	(LBB0_152-LBB0_145)>>2
	.short	(LBB0_152-LBB0_145)>>2
	.short	(LBB0_148-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_185-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_154-LBB0_145)>>2
	.short	(LBB0_145-LBB0_145)>>2
	.short	(LBB0_145-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_176-LBB0_145)>>2
	.short	(LBB0_186-LBB0_145)>>2
	.short	(LBB0_189-LBB0_145)>>2
	.short	(LBB0_175-LBB0_145)>>2
	.short	(LBB0_167-LBB0_145)>>2
	.short	(LBB0_183-LBB0_145)>>2
	.short	(LBB0_148-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_152-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_191-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_154-LBB0_145)>>2
	.short	(LBB0_145-LBB0_145)>>2
	.short	(LBB0_190-LBB0_145)>>2
	.short	(LBB0_145-LBB0_145)>>2
lJTI0_1:
	.byte	(LBB0_211-LBB0_193)>>2
	.byte	(LBB0_193-LBB0_193)>>2
	.byte	(LBB0_202-LBB0_193)>>2
	.byte	(LBB0_204-LBB0_193)>>2
	.byte	(LBB0_199-LBB0_193)>>2
	.byte	(LBB0_200-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_203-LBB0_193)>>2
	.byte	(LBB0_205-LBB0_193)>>2
	.byte	(LBB0_206-LBB0_193)>>2
	.byte	(LBB0_201-LBB0_193)>>2
	.byte	(LBB0_207-LBB0_193)>>2
	.byte	(LBB0_198-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_208-LBB0_193)>>2
	.byte	(LBB0_210-LBB0_193)>>2
	.byte	(LBB0_209-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_211-LBB0_193)>>2
	.byte	(LBB0_193-LBB0_193)>>2
	.byte	(LBB0_202-LBB0_193)>>2
	.byte	(LBB0_204-LBB0_193)>>2
	.byte	(LBB0_199-LBB0_193)>>2
	.byte	(LBB0_200-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_223-LBB0_193)>>2
	.byte	(LBB0_203-LBB0_193)>>2
	.byte	(LBB0_205-LBB0_193)>>2
	.byte	(LBB0_206-LBB0_193)>>2
	.byte	(LBB0_201-LBB0_193)>>2
	.byte	(LBB0_207-LBB0_193)>>2
	.byte	(LBB0_198-LBB0_193)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fn_preamble
_fn_preamble:                           ; @fn_preamble
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh196:
	adrp	x8, l_.str.19@PAGE
Lloh197:
	add	x8, x8, l_.str.19@PAGEOFF
	str	x8, [sp]
Lloh198:
	adrp	x20, l_.str.10@PAGE
Lloh199:
	add	x20, x20, l_.str.10@PAGEOFF
	mov	x1, x20
	bl	_fn_text
Lloh200:
	adrp	x8, l_.str.20@PAGE
Lloh201:
	add	x8, x8, l_.str.20@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh202:
	adrp	x8, l_.str.23@PAGE
Lloh203:
	add	x8, x8, l_.str.23@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh204:
	adrp	x8, l_.str.24@PAGE
Lloh205:
	add	x8, x8, l_.str.24@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh206:
	adrp	x8, l_.str.25@PAGE
Lloh207:
	add	x8, x8, l_.str.25@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh208:
	adrp	x8, l_.str.26@PAGE
Lloh209:
	add	x8, x8, l_.str.26@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh210:
	adrp	x8, l_.str.27@PAGE
Lloh211:
	add	x8, x8, l_.str.27@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh212:
	adrp	x8, l_.str.28@PAGE
Lloh213:
	add	x8, x8, l_.str.28@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh214:
	adrp	x8, l_.str.29@PAGE
Lloh215:
	add	x8, x8, l_.str.29@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh216:
	adrp	x8, l_.str.30@PAGE
Lloh217:
	add	x8, x8, l_.str.30@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh218:
	adrp	x8, l_.str.31@PAGE
Lloh219:
	add	x8, x8, l_.str.31@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh220:
	adrp	x8, l_.str.32@PAGE
Lloh221:
	add	x8, x8, l_.str.32@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh220, Lloh221
	.loh AdrpAdd	Lloh218, Lloh219
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpAdd	Lloh214, Lloh215
	.loh AdrpAdd	Lloh212, Lloh213
	.loh AdrpAdd	Lloh210, Lloh211
	.loh AdrpAdd	Lloh208, Lloh209
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpAdd	Lloh204, Lloh205
	.loh AdrpAdd	Lloh202, Lloh203
	.loh AdrpAdd	Lloh200, Lloh201
	.loh AdrpAdd	Lloh198, Lloh199
	.loh AdrpAdd	Lloh196, Lloh197
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_text
_fn_text:                               ; @fn_text
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cbz	w8, LBB2_2
; %bb.1:
	ret
LBB2_2:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	add	x8, x29, #16
	stp	x8, x8, [sp]
	add	x3, x29, #16
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, x20
	bl	_vsnprintf
	tbnz	w0, #31, LBB2_17
; %bb.3:
	lsr	w8, w0, #27
	cbnz	w8, LBB2_5
; %bb.4:
	mov	w22, w0
	ldr	x8, [x19, #8]
	mov	w9, #134217727                  ; =0x7ffffff
	sub	x9, x9, x22
	cmp	x8, x9
	b.ls	LBB2_6
LBB2_5:
	mov	w8, #3                          ; =0x3
	b	LBB2_18
LBB2_6:
	ldr	x21, [x19, #16]
	add	x9, x8, x22
	cmp	x9, x21
	b.hs	LBB2_8
; %bb.7:
	mov	x23, x0
	ldr	x0, [x19]
	b	LBB2_15
LBB2_8:
	mov	w8, #4096                       ; =0x1000
	cmp	x21, #0
	csel	x21, x8, x21, eq
	cmp	x21, x9
	b.hi	LBB2_13
; %bb.9:
	mov	w8, #67108864                   ; =0x4000000
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	cmp	x21, x8
	b.hi	LBB2_12
; %bb.11:                               ;   in Loop: Header=BB2_10 Depth=1
	lsl	x21, x21, #1
	cmp	x21, x9
	b.ls	LBB2_10
	b	LBB2_13
LBB2_12:
	mov	w21, #134217728                 ; =0x8000000
LBB2_13:
	mov	x23, x0
	ldr	x0, [x19]
	mov	x1, x21
	bl	_realloc
	cbz	x0, LBB2_20
; %bb.14:
	str	x0, [x19]
	str	x21, [x19, #16]
	ldr	x8, [x19, #8]
LBB2_15:
	sub	x1, x21, x8
	ldr	x3, [sp, #8]
	add	x0, x0, x8
	mov	x2, x20
	bl	_vsnprintf
	cmp	w0, w23
	b.ne	LBB2_17
; %bb.16:
	ldr	x8, [x19, #8]
	add	x8, x8, x22
	str	x8, [x19, #8]
	b	LBB2_19
LBB2_17:
	mov	w8, #1                          ; =0x1
LBB2_18:
	str	w8, [x19, #24]
LBB2_19:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB2_20:
	mov	w8, #4                          ; =0x4
	b	LBB2_18
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fn_agreement
_fn_agreement:                          ; @fn_agreement
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1040
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	str	x2, [sp, #64]                   ; 8-byte Folded Spill
	ldr	w8, [x2, #12]
	str	x1, [sp, #152]                  ; 8-byte Folded Spill
	cbz	w8, LBB3_70
; %bb.1:
	mov	x21, x1
	mov	w22, #0                         ; =0x0
	add	x8, sp, #288
	add	x23, x8, #72
	add	x27, x8, #48
	add	x9, x8, #16
	stp	x23, x9, [sp, #72]              ; 16-byte Folded Spill
Lloh222:
	adrp	x25, l_.str.154@PAGE
Lloh223:
	add	x25, x25, l_.str.154@PAGEOFF
	add	x26, x8, #78
	str	x27, [sp, #120]                 ; 8-byte Folded Spill
	str	x26, [sp, #88]                  ; 8-byte Folded Spill
	b	LBB3_3
LBB3_2:                                 ;   in Loop: Header=BB3_3 Depth=1
	add	w22, w22, #1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w22, w8
	b.hs	LBB3_70
LBB3_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_6 Depth 2
                                        ;       Child Loop BB3_11 Depth 3
                                        ;       Child Loop BB3_16 Depth 3
                                        ;       Child Loop BB3_32 Depth 3
                                        ;       Child Loop BB3_37 Depth 3
                                        ;         Child Loop BB3_42 Depth 4
                                        ;         Child Loop BB3_46 Depth 4
                                        ;         Child Loop BB3_51 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
	add	x2, sp, #192
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB3_91
; %bb.4:                                ;   in Loop: Header=BB3_3 Depth=1
	ldrh	w8, [sp, #200]
	cbz	w8, LBB3_2
; %bb.5:                                ;   in Loop: Header=BB3_3 Depth=1
	mov	w24, #0                         ; =0x0
	mov	x8, x22
	stp	x8, x8, [sp, #96]               ; 16-byte Folded Spill
	stp	x8, x8, [sp, #128]              ; 16-byte Folded Spill
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
LBB3_6:                                 ;   Parent Loop BB3_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_11 Depth 3
                                        ;       Child Loop BB3_16 Depth 3
                                        ;       Child Loop BB3_32 Depth 3
                                        ;       Child Loop BB3_37 Depth 3
                                        ;         Child Loop BB3_42 Depth 4
                                        ;         Child Loop BB3_46 Depth 4
                                        ;         Child Loop BB3_51 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
	mov	x8, x24
	stp	x22, x8, [sp]
	mov	x0, x19
Lloh224:
	adrp	x1, l_.str.83@PAGE
Lloh225:
	add	x1, x1, l_.str.83@PAGEOFF
	bl	_fn_text
	add	x3, sp, #288
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	bl	_nvm_file_cyclic_hosted_instruction
	cbz	w0, LBB3_68
; %bb.7:                                ;   in Loop: Header=BB3_6 Depth=2
	add	x3, sp, #287
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	bl	_nvm_file_cyclic_hosted_variant_count
	cbz	w0, LBB3_68
; %bb.8:                                ;   in Loop: Header=BB3_6 Depth=2
	add	x3, sp, #284
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	bl	_nvm_file_cyclic_hosted_component
	tbz	w0, #0, LBB3_68
; %bb.9:                                ;   in Loop: Header=BB3_6 Depth=2
	ldrb	w8, [sp, #287]
	ldrh	w9, [sp, #284]
	mov	x10, x24
	stp	x10, x9, [sp, #48]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	stp	x8, x9, [sp, #32]
	stp	x9, x10, [sp, #16]
	stp	x9, x10, [sp]
	mov	x0, x19
Lloh226:
	adrp	x1, l_.str.84@PAGE
Lloh227:
	add	x1, x1, l_.str.84@PAGEOFF
	bl	_fn_text
	ldr	w8, [sp, #288]
	str	x8, [sp, #8]
Lloh228:
	adrp	x8, l_.str.85@PAGE
Lloh229:
	add	x8, x8, l_.str.85@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #296]
	str	x8, [sp, #8]
Lloh230:
	adrp	x8, l_.str.86@PAGE
Lloh231:
	add	x8, x8, l_.str.86@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #297]
	str	x8, [sp, #8]
Lloh232:
	adrp	x8, l_.str.87@PAGE
Lloh233:
	add	x8, x8, l_.str.87@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #352]
	str	x8, [sp, #8]
Lloh234:
	adrp	x8, l_.str.88@PAGE
Lloh235:
	add	x8, x8, l_.str.88@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #364]
	str	x8, [sp, #8]
Lloh236:
	adrp	x8, l_.str.89@PAGE
Lloh237:
	add	x8, x8, l_.str.89@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldr	w8, [sp, #880]
	str	x8, [sp, #8]
Lloh238:
	adrp	x8, l_.str.90@PAGE
Lloh239:
	add	x8, x8, l_.str.90@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldrb	w8, [sp, #364]
Lloh240:
	adrp	x26, l_.str.91@PAGE
Lloh241:
	add	x26, x26, l_.str.91@PAGEOFF
	cbz	w8, LBB3_12
; %bb.10:                               ;   in Loop: Header=BB3_6 Depth=2
	mov	x20, #0                         ; =0x0
LBB3_11:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x23, x20, lsl #1]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x26
	bl	_fn_text
	add	x20, x20, #1
	ldrb	w8, [sp, #364]
	cmp	x20, x8
	b.lo	LBB3_11
LBB3_12:                                ;   in Loop: Header=BB3_6 Depth=2
	ldrb	w8, [sp, #297]
	cbz	w8, LBB3_26
; %bb.13:                               ;   in Loop: Header=BB3_6 Depth=2
	mov	x20, #0                         ; =0x0
	ldr	x26, [sp, #80]                  ; 8-byte Folded Reload
	b	LBB3_16
LBB3_14:                                ;   in Loop: Header=BB3_16 Depth=3
	ldrsw	x9, [x26]
Lloh242:
	adrp	x10, l_.str.95@PAGE
Lloh243:
	add	x10, x10, l_.str.95@PAGEOFF
LBB3_15:                                ;   in Loop: Header=BB3_16 Depth=3
	stp	x10, x9, [sp, #24]
	stp	x8, x20, [sp, #8]
	str	x20, [sp]
	mov	x0, x19
Lloh244:
	adrp	x1, l_.str.97@PAGE
Lloh245:
	add	x1, x1, l_.str.97@PAGEOFF
	bl	_fn_text
	add	x20, x20, #1
	ldrb	w8, [sp, #297]
	add	x26, x26, #8
	cmp	x20, x8
	b.hs	LBB3_26
LBB3_16:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x27, x20, lsl #2]
	cmp	w8, #2
	b.le	LBB3_21
; %bb.17:                               ;   in Loop: Header=BB3_16 Depth=3
	cmp	w8, #3
	b.eq	LBB3_25
; %bb.18:                               ;   in Loop: Header=BB3_16 Depth=3
	cmp	w8, #4
	b.eq	LBB3_14
; %bb.19:                               ;   in Loop: Header=BB3_16 Depth=3
	cmp	w8, #5
	b.ne	LBB3_68
; %bb.20:                               ;   in Loop: Header=BB3_16 Depth=3
	ldr	x9, [x26]
Lloh246:
	adrp	x10, l_.str.96@PAGE
Lloh247:
	add	x10, x10, l_.str.96@PAGEOFF
	b	LBB3_15
LBB3_21:                                ;   in Loop: Header=BB3_16 Depth=3
	cmp	w8, #1
	b.eq	LBB3_24
; %bb.22:                               ;   in Loop: Header=BB3_16 Depth=3
	cmp	w8, #2
	b.ne	LBB3_68
; %bb.23:                               ;   in Loop: Header=BB3_16 Depth=3
	ldrh	w9, [x26]
Lloh248:
	adrp	x10, l_.str.93@PAGE
Lloh249:
	add	x10, x10, l_.str.93@PAGEOFF
	b	LBB3_15
LBB3_24:                                ;   in Loop: Header=BB3_16 Depth=3
	ldrb	w9, [x26]
Lloh250:
	adrp	x10, l_.str.92@PAGE
Lloh251:
	add	x10, x10, l_.str.92@PAGEOFF
	b	LBB3_15
LBB3_25:                                ;   in Loop: Header=BB3_16 Depth=3
	ldr	w9, [x26]
Lloh252:
	adrp	x10, l_.str.94@PAGE
Lloh253:
	add	x10, x10, l_.str.94@PAGEOFF
	b	LBB3_15
LBB3_26:                                ;   in Loop: Header=BB3_6 Depth=2
	ldrb	w8, [sp, #296]
	cmp	w8, #15
	ldr	x26, [sp, #88]                  ; 8-byte Folded Reload
	b.eq	LBB3_29
; %bb.27:                               ;   in Loop: Header=BB3_6 Depth=2
	cmp	w8, #151
	b.eq	LBB3_29
; %bb.28:                               ;   in Loop: Header=BB3_6 Depth=2
	cmp	w8, #59
	b.ne	LBB3_33
LBB3_29:                                ;   in Loop: Header=BB3_6 Depth=2
	ldr	w1, [sp, #304]
	sub	x2, x29, #192
	mov	x0, x21
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB3_68
; %bb.30:                               ;   in Loop: Header=BB3_6 Depth=2
	ldurh	w8, [x29, #-180]
Lloh254:
	adrp	x28, l_.str.98@PAGE
Lloh255:
	add	x28, x28, l_.str.98@PAGEOFF
	cbz	w8, LBB3_33
; %bb.31:                               ;   in Loop: Header=BB3_6 Depth=2
	mov	x20, #0                         ; =0x0
LBB3_32:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrh	w8, [x26, x20, lsl #1]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x28
	bl	_fn_text
	add	x20, x20, #1
	ldurh	w8, [x29, #-180]
	cmp	x20, x8
	b.lo	LBB3_32
LBB3_33:                                ;   in Loop: Header=BB3_6 Depth=2
	ldrb	w8, [sp, #287]
	cbz	w8, LBB3_64
; %bb.34:                               ;   in Loop: Header=BB3_6 Depth=2
	mov	w23, #0                         ; =0x0
	mov	x8, x24
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	b	LBB3_37
LBB3_35:                                ;   in Loop: Header=BB3_37 Depth=3
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
LBB3_36:                                ;   in Loop: Header=BB3_37 Depth=3
	add	w23, w23, #1
	ldrb	w8, [sp, #287]
	cmp	w23, w8
	b.hs	LBB3_64
LBB3_37:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB3_42 Depth 4
                                        ;         Child Loop BB3_46 Depth 4
                                        ;         Child Loop BB3_51 Depth 4
                                        ;         Child Loop BB3_62 Depth 4
	sub	x4, x29, #192
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	mov	x3, x23
	bl	_nvm_file_cyclic_hosted_variant
	tbz	w0, #0, LBB3_35
; %bb.38:                               ;   in Loop: Header=BB3_37 Depth=3
	mov	x8, x23
	stp	x24, x8, [sp, #8]
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	str	x8, [sp]
	mov	x0, x19
Lloh256:
	adrp	x1, l_.str.99@PAGE
Lloh257:
	add	x1, x1, l_.str.99@PAGEOFF
	bl	_fn_text
	ldurh	w8, [x29, #-192]
	str	x8, [sp, #8]
Lloh258:
	adrp	x8, l_.str.100@PAGE
Lloh259:
	add	x8, x8, l_.str.100@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-190]
	str	x8, [sp, #8]
Lloh260:
	adrp	x8, l_.str.101@PAGE
Lloh261:
	add	x8, x8, l_.str.101@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-188]
	str	x8, [sp, #8]
Lloh262:
	adrp	x8, l_.str.102@PAGE
Lloh263:
	add	x8, x8, l_.str.102@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-186]
	str	x8, [sp, #8]
Lloh264:
	adrp	x8, l_.str.103@PAGE
Lloh265:
	add	x8, x8, l_.str.103@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-184]
	str	x8, [sp, #8]
Lloh266:
	adrp	x8, l_.str.104@PAGE
Lloh267:
	add	x8, x8, l_.str.104@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-182]
	str	x8, [sp, #8]
Lloh268:
	adrp	x8, l_.str.105@PAGE
Lloh269:
	add	x8, x8, l_.str.105@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-180]
	str	x8, [sp, #8]
Lloh270:
	adrp	x8, l_.str.106@PAGE
Lloh271:
	add	x8, x8, l_.str.106@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-178]
	str	x8, [sp, #8]
Lloh272:
	adrp	x8, l_.str.107@PAGE
Lloh273:
	add	x8, x8, l_.str.107@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-176]
	str	x8, [sp, #8]
Lloh274:
	adrp	x8, l_.str.108@PAGE
Lloh275:
	add	x8, x8, l_.str.108@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-174]
	str	x8, [sp, #8]
Lloh276:
	adrp	x8, l_.str.109@PAGE
Lloh277:
	add	x8, x8, l_.str.109@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-92]
	str	x8, [sp, #8]
Lloh278:
	adrp	x8, l_.str.110@PAGE
Lloh279:
	add	x8, x8, l_.str.110@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-91]
	str	x8, [sp, #8]
Lloh280:
	adrp	x8, l_.str.111@PAGE
Lloh281:
	add	x8, x8, l_.str.111@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-90]
	str	x8, [sp, #8]
Lloh282:
	adrp	x8, l_.str.112@PAGE
Lloh283:
	add	x8, x8, l_.str.112@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-172]
	str	x8, [sp, #8]
Lloh284:
	adrp	x8, l_.str.113@PAGE
Lloh285:
	add	x8, x8, l_.str.113@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-171]
	str	x8, [sp, #8]
Lloh286:
	adrp	x8, l_.str.114@PAGE
Lloh287:
	add	x8, x8, l_.str.114@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-170]
	str	x8, [sp, #8]
Lloh288:
	adrp	x8, l_.str.115@PAGE
Lloh289:
	add	x8, x8, l_.str.115@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-169]
	str	x8, [sp, #8]
Lloh290:
	adrp	x8, l_.str.116@PAGE
Lloh291:
	add	x8, x8, l_.str.116@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-168]
	str	x8, [sp, #8]
Lloh292:
	adrp	x8, l_.str.117@PAGE
Lloh293:
	add	x8, x8, l_.str.117@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-166]
	str	x8, [sp, #8]
Lloh294:
	adrp	x8, l_.str.118@PAGE
Lloh295:
	add	x8, x8, l_.str.118@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-164]
	str	x8, [sp, #8]
Lloh296:
	adrp	x8, l_.str.119@PAGE
Lloh297:
	add	x8, x8, l_.str.119@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-160]
	str	x8, [sp, #8]
Lloh298:
	adrp	x8, l_.str.120@PAGE
Lloh299:
	add	x8, x8, l_.str.120@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-156]
	str	x8, [sp, #8]
Lloh300:
	adrp	x8, l_.str.121@PAGE
Lloh301:
	add	x8, x8, l_.str.121@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-152]
	str	x8, [sp, #8]
Lloh302:
	adrp	x8, l_.str.122@PAGE
Lloh303:
	add	x8, x8, l_.str.122@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-169]
	cmp	w8, #1
	b.ne	LBB3_40
; %bb.39:                               ;   in Loop: Header=BB3_37 Depth=3
	ldur	w8, [x29, #-148]
	str	x8, [sp, #8]
Lloh304:
	adrp	x8, l_.str.123@PAGE
Lloh305:
	add	x8, x8, l_.str.123@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-144]
	str	x8, [sp, #8]
Lloh306:
	adrp	x8, l_.str.124@PAGE
Lloh307:
	add	x8, x8, l_.str.124@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-140]
	str	x8, [sp, #8]
Lloh308:
	adrp	x8, l_.str.125@PAGE
Lloh309:
	add	x8, x8, l_.str.125@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-136]
	str	x8, [sp, #8]
Lloh310:
	adrp	x8, l_.str.126@PAGE
Lloh311:
	add	x8, x8, l_.str.126@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-132]
	str	x8, [sp, #8]
Lloh312:
	adrp	x8, l_.str.127@PAGE
Lloh313:
	add	x8, x8, l_.str.127@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-128]
	str	x8, [sp, #8]
Lloh314:
	adrp	x8, l_.str.128@PAGE
Lloh315:
	add	x8, x8, l_.str.128@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-124]
	str	x8, [sp, #8]
Lloh316:
	adrp	x8, l_.str.129@PAGE
Lloh317:
	add	x8, x8, l_.str.129@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-122]
	str	x8, [sp, #8]
Lloh318:
	adrp	x8, l_.str.130@PAGE
Lloh319:
	add	x8, x8, l_.str.130@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-120]
	str	x8, [sp, #8]
Lloh320:
	adrp	x8, l_.str.131@PAGE
Lloh321:
	add	x8, x8, l_.str.131@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-118]
	str	x8, [sp, #8]
Lloh322:
	adrp	x8, l_.str.132@PAGE
Lloh323:
	add	x8, x8, l_.str.132@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-100]
	str	x8, [sp, #8]
Lloh324:
	adrp	x8, l_.str.133@PAGE
Lloh325:
	add	x8, x8, l_.str.133@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	w8, [x29, #-96]
	str	x8, [sp, #8]
Lloh326:
	adrp	x8, l_.str.134@PAGE
Lloh327:
	add	x8, x8, l_.str.134@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	sub	x8, x29, #192
	ldur	x2, [x8, #76]
	ldur	x3, [x8, #84]
	mov	x0, x19
Lloh328:
	adrp	x1, l_.str.135@PAGE
Lloh329:
	add	x1, x1, l_.str.135@PAGEOFF
	bl	_fn_declaration
LBB3_40:                                ;   in Loop: Header=BB3_37 Depth=3
	ldurh	w8, [x29, #-192]
	cbz	w8, LBB3_44
; %bb.41:                               ;   in Loop: Header=BB3_37 Depth=3
	mov	w20, #0                         ; =0x0
LBB3_42:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ;       Parent Loop BB3_37 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	sub	x5, x29, #232
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	mov	x3, x23
	mov	x4, x20
	bl	_nvm_file_cyclic_hosted_input_local
	cbz	w0, LBB3_59
; %bb.43:                               ;   in Loop: Header=BB3_42 Depth=4
	stp	x23, x20, [sp, #16]
	ldp	x8, x9, [sp, #176]              ; 16-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh330:
	adrp	x1, l_.str.136@PAGE
Lloh331:
	add	x1, x1, l_.str.136@PAGEOFF
	bl	_fn_text
	ldp	x2, x3, [x29, #-232]
	ldurb	w28, [x29, #-216]
	ldur	x27, [x29, #-208]
	ldur	w26, [x29, #-200]
	mov	x0, x19
Lloh332:
	adrp	x1, l_.str.150@PAGE
Lloh333:
	add	x1, x1, l_.str.150@PAGEOFF
	bl	_fn_declaration
Lloh334:
	adrp	x8, l_.str.151@PAGE
Lloh335:
	add	x8, x8, l_.str.151@PAGEOFF
	stp	x8, x28, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh336:
	adrp	x8, l_.str.152@PAGE
Lloh337:
	add	x8, x8, l_.str.152@PAGEOFF
	stp	x8, x27, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh338:
	adrp	x8, l_.str.153@PAGE
Lloh339:
	add	x8, x8, l_.str.153@PAGEOFF
	stp	x8, x26, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-192]
	cmp	w20, w8
	b.lo	LBB3_42
LBB3_44:                                ;   in Loop: Header=BB3_37 Depth=3
	ldurh	w8, [x29, #-190]
	cbz	w8, LBB3_48
; %bb.45:                               ;   in Loop: Header=BB3_37 Depth=3
	mov	w20, #0                         ; =0x0
	mov	x28, x23
LBB3_46:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ;       Parent Loop BB3_37 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	sub	x5, x29, #232
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	mov	x3, x23
	mov	x4, x20
	bl	_nvm_file_cyclic_hosted_input_stack
	cbz	w0, LBB3_59
; %bb.47:                               ;   in Loop: Header=BB3_46 Depth=4
	stp	x28, x20, [sp, #16]
	ldp	x8, x9, [sp, #160]              ; 16-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh340:
	adrp	x1, l_.str.137@PAGE
Lloh341:
	add	x1, x1, l_.str.137@PAGEOFF
	bl	_fn_text
	ldp	x2, x3, [x29, #-232]
	ldurb	w26, [x29, #-216]
	ldur	x27, [x29, #-208]
	ldur	w21, [x29, #-200]
	mov	x0, x19
Lloh342:
	adrp	x1, l_.str.150@PAGE
Lloh343:
	add	x1, x1, l_.str.150@PAGEOFF
	bl	_fn_declaration
Lloh344:
	adrp	x8, l_.str.151@PAGE
Lloh345:
	add	x8, x8, l_.str.151@PAGEOFF
	stp	x8, x26, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
Lloh346:
	adrp	x8, l_.str.152@PAGE
Lloh347:
	add	x8, x8, l_.str.152@PAGEOFF
	stp	x8, x27, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	str	x21, [sp, #8]
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
Lloh348:
	adrp	x8, l_.str.153@PAGE
Lloh349:
	add	x8, x8, l_.str.153@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-190]
	cmp	w20, w8
	b.lo	LBB3_46
LBB3_48:                                ;   in Loop: Header=BB3_37 Depth=3
	mov	x8, x23
	str	x8, [sp, #16]
	ldp	x8, x9, [sp, #104]              ; 16-byte Folded Reload
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh350:
	adrp	x1, l_.str.138@PAGE
Lloh351:
	add	x1, x1, l_.str.138@PAGEOFF
	bl	_fn_text
	mov	w20, #0                         ; =0x0
	ldr	x27, [sp, #120]                 ; 8-byte Folded Reload
Lloh352:
	adrp	x28, l_.str.139@PAGE
Lloh353:
	add	x28, x28, l_.str.139@PAGEOFF
	b	LBB3_51
LBB3_49:                                ;   in Loop: Header=BB3_51 Depth=4
	str	x20, [sp]
	mov	x0, x19
	mov	x1, x28
	bl	_fn_text
	ldurb	w8, [x29, #-232]
	str	x8, [sp, #8]
Lloh354:
	adrp	x8, l_.str.140@PAGE
Lloh355:
	add	x8, x8, l_.str.140@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-231]
	str	x8, [sp, #8]
Lloh356:
	adrp	x8, l_.str.141@PAGE
Lloh357:
	add	x8, x8, l_.str.141@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurh	w8, [x29, #-230]
	str	x8, [sp, #8]
Lloh358:
	adrp	x8, l_.str.142@PAGE
Lloh359:
	add	x8, x8, l_.str.142@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	x9, [x29, #-224]
Lloh360:
	adrp	x8, l_.str.143@PAGE
Lloh361:
	add	x8, x8, l_.str.143@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	x9, [x29, #-216]
Lloh362:
	adrp	x8, l_.str.144@PAGE
Lloh363:
	add	x8, x8, l_.str.144@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldur	x9, [x29, #-208]
Lloh364:
	adrp	x8, l_.str.145@PAGE
Lloh365:
	add	x8, x8, l_.str.145@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	ldurb	w8, [x29, #-200]
	str	x8, [sp, #8]
Lloh366:
	adrp	x8, l_.str.146@PAGE
Lloh367:
	add	x8, x8, l_.str.146@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_text
	mov	x0, x19
Lloh368:
	adrp	x1, l_.str.147@PAGE
Lloh369:
	add	x1, x1, l_.str.147@PAGEOFF
	bl	_fn_text
LBB3_50:                                ;   in Loop: Header=BB3_51 Depth=4
	add	w20, w20, #1
	cmp	w20, #256
	b.eq	LBB3_60
LBB3_51:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ;       Parent Loop BB3_37 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	sub	x5, x29, #232
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	mov	x3, x23
	mov	x4, x20
	bl	_nvm_file_cyclic_hosted_input_reference
	cbz	w0, LBB3_35
; %bb.52:                               ;   in Loop: Header=BB3_51 Depth=4
	ldurb	w8, [x29, #-232]
	tbnz	w8, #0, LBB3_49
; %bb.53:                               ;   in Loop: Header=BB3_51 Depth=4
	ldurb	w8, [x29, #-231]
	tbnz	w8, #0, LBB3_35
; %bb.54:                               ;   in Loop: Header=BB3_51 Depth=4
	ldurh	w8, [x29, #-230]
	cbnz	w8, LBB3_35
; %bb.55:                               ;   in Loop: Header=BB3_51 Depth=4
	ldur	x8, [x29, #-224]
	cbnz	x8, LBB3_35
; %bb.56:                               ;   in Loop: Header=BB3_51 Depth=4
	ldur	x8, [x29, #-216]
	cbnz	x8, LBB3_35
; %bb.57:                               ;   in Loop: Header=BB3_51 Depth=4
	ldur	x8, [x29, #-208]
	cbnz	x8, LBB3_35
; %bb.58:                               ;   in Loop: Header=BB3_51 Depth=4
	ldurb	w8, [x29, #-200]
	tbz	w8, #0, LBB3_50
	b	LBB3_35
LBB3_59:                                ;   in Loop: Header=BB3_37 Depth=3
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
	ldr	x27, [sp, #120]                 ; 8-byte Folded Reload
	b	LBB3_36
LBB3_60:                                ;   in Loop: Header=BB3_37 Depth=3
	mov	x0, x19
Lloh370:
	adrp	x1, l_.str.148@PAGE
Lloh371:
	add	x1, x1, l_.str.148@PAGEOFF
	bl	_fn_text
	ldurh	w8, [x29, #-188]
	cbz	w8, LBB3_36
; %bb.61:                               ;   in Loop: Header=BB3_37 Depth=3
	mov	w20, #0                         ; =0x0
	mov	x28, x23
LBB3_62:                                ;   Parent Loop BB3_3 Depth=1
                                        ;     Parent Loop BB3_6 Depth=2
                                        ;       Parent Loop BB3_37 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	sub	x5, x29, #232
	mov	x0, x21
	mov	x1, x22
	mov	x2, x24
	mov	x3, x23
	mov	x4, x20
	bl	_nvm_file_cyclic_hosted_input_region
	tbz	w0, #0, LBB3_35
; %bb.63:                               ;   in Loop: Header=BB3_62 Depth=4
	ldur	x8, [x29, #-232]
	stp	x20, x8, [sp, #24]
	ldp	x8, x9, [sp, #136]              ; 16-byte Folded Reload
	stp	x9, x28, [sp, #8]
	str	x8, [sp]
	mov	x0, x19
Lloh372:
	adrp	x1, l_.str.149@PAGE
Lloh373:
	add	x1, x1, l_.str.149@PAGEOFF
	bl	_fn_text
	add	w20, w20, #1
	ldurh	w8, [x29, #-188]
	cmp	w20, w8
	b.lo	LBB3_62
	b	LBB3_36
LBB3_64:                                ;   in Loop: Header=BB3_6 Depth=2
	ldrb	w8, [sp, #296]
	cmp	w8, #145
	ldr	x23, [sp, #72]                  ; 8-byte Folded Reload
	b.ne	LBB3_67
; %bb.65:                               ;   in Loop: Header=BB3_6 Depth=2
	ldr	w1, [sp, #880]
	sub	x2, x29, #192
	mov	x0, x21
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB3_68
; %bb.66:                               ;   in Loop: Header=BB3_6 Depth=2
	ldr	w8, [sp, #880]
	ldur	w9, [x29, #-192]
	stp	x8, x9, [sp]
	mov	x0, x19
Lloh374:
	adrp	x1, l_.str.57@PAGE
Lloh375:
	add	x1, x1, l_.str.57@PAGEOFF
	bl	_fn_text
LBB3_67:                                ;   in Loop: Header=BB3_6 Depth=2
	mov	x0, x19
Lloh376:
	adrp	x1, l_.str.82@PAGE
Lloh377:
	add	x1, x1, l_.str.82@PAGEOFF
	bl	_fn_text
	b	LBB3_69
LBB3_68:                                ;   in Loop: Header=BB3_6 Depth=2
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
LBB3_69:                                ;   in Loop: Header=BB3_6 Depth=2
	add	w24, w24, #1
	ldrh	w8, [sp, #200]
	cmp	w24, w8
	b.lo	LBB3_6
	b	LBB3_2
LBB3_70:
Lloh378:
	adrp	x1, l_.str.33@PAGE
Lloh379:
	add	x1, x1, l_.str.33@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	ldr	x21, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w8, [x21]
Lloh380:
	adrp	x9, l_.str.34@PAGE
Lloh381:
	add	x9, x9, l_.str.34@PAGEOFF
	stp	x9, x8, [sp]
Lloh382:
	adrp	x20, l_.str.154@PAGE
Lloh383:
	add	x20, x20, l_.str.154@PAGEOFF
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #4]
Lloh384:
	adrp	x9, l_.str.35@PAGE
Lloh385:
	add	x9, x9, l_.str.35@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #8]
Lloh386:
	adrp	x9, l_.str.36@PAGE
Lloh387:
	add	x9, x9, l_.str.36@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #12]
Lloh388:
	adrp	x9, l_.str.37@PAGE
Lloh389:
	add	x9, x9, l_.str.37@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #16]
Lloh390:
	adrp	x9, l_.str.38@PAGE
Lloh391:
	add	x9, x9, l_.str.38@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #24]
Lloh392:
	adrp	x9, l_.str.39@PAGE
Lloh393:
	add	x9, x9, l_.str.39@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #32]
Lloh394:
	adrp	x9, l_.str.40@PAGE
Lloh395:
	add	x9, x9, l_.str.40@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrh	w8, [x21, #40]
Lloh396:
	adrp	x9, l_.str.41@PAGE
Lloh397:
	add	x9, x9, l_.str.41@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #44]
Lloh398:
	adrp	x9, l_.str.42@PAGE
Lloh399:
	add	x9, x9, l_.str.42@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [x21, #48]
Lloh400:
	adrp	x9, l_.str.43@PAGE
Lloh401:
	add	x9, x9, l_.str.43@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #56]
Lloh402:
	adrp	x9, l_.str.44@PAGE
Lloh403:
	add	x9, x9, l_.str.44@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #64]
Lloh404:
	adrp	x9, l_.str.45@PAGE
Lloh405:
	add	x9, x9, l_.str.45@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #72]
Lloh406:
	adrp	x9, l_.str.46@PAGE
Lloh407:
	add	x9, x9, l_.str.46@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	x8, [x21, #80]
Lloh408:
	adrp	x9, l_.str.47@PAGE
Lloh409:
	add	x9, x9, l_.str.47@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [x21, #88]
	ldr	x21, [sp, #152]                 ; 8-byte Folded Reload
Lloh410:
	adrp	x9, l_.str.48@PAGE
Lloh411:
	add	x9, x9, l_.str.48@PAGEOFF
	stp	x9, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
Lloh412:
	adrp	x1, l_.str.49@PAGE
Lloh413:
	add	x1, x1, l_.str.49@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	mov	w22, #0                         ; =0x0
Lloh414:
	adrp	x23, l_.str.50@PAGE
Lloh415:
	add	x23, x23, l_.str.50@PAGEOFF
Lloh416:
	adrp	x25, l_.str.52@PAGE
Lloh417:
	add	x25, x25, l_.str.52@PAGEOFF
Lloh418:
	adrp	x26, l_.str.53@PAGE
Lloh419:
	add	x26, x26, l_.str.53@PAGEOFF
Lloh420:
	adrp	x27, l_.str.54@PAGE
Lloh421:
	add	x27, x27, l_.str.54@PAGEOFF
Lloh422:
	adrp	x28, l_.str.55@PAGE
Lloh423:
	add	x28, x28, l_.str.55@PAGEOFF
Lloh424:
	adrp	x24, l_.str.56@PAGE
Lloh425:
	add	x24, x24, l_.str.56@PAGEOFF
LBB3_71:                                ; =>This Inner Loop Header: Depth=1
	add	x2, sp, #288
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_type
	tbz	w0, #0, LBB3_91
; %bb.72:                               ;   in Loop: Header=BB3_71 Depth=1
	str	x22, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #288]
	str	x8, [sp, #8]
Lloh426:
	adrp	x8, l_.str.51@PAGE
Lloh427:
	add	x8, x8, l_.str.51@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #292]
	stp	x25, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #296]
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [sp, #300]
	stp	x27, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldrb	w8, [sp, #301]
	stp	x28, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldr	w8, [sp, #304]
	stp	x24, x8, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	add	w22, w22, #1
	cmp	w22, #8
	b.ne	LBB3_71
; %bb.73:
	add	x2, sp, #288
	mov	x0, x21
	mov	w1, #0                          ; =0x0
	bl	_nvm_file_cyclic_hosted_import
	tbz	w0, #0, LBB3_91
; %bb.74:
	ldr	w8, [sp, #288]
	stp	xzr, x8, [sp]
Lloh428:
	adrp	x1, l_.str.57@PAGE
Lloh429:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	add	x2, sp, #288
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB3_91
; %bb.75:
	ldr	w8, [sp, #288]
	mov	w9, #1                          ; =0x1
	stp	x9, x8, [sp]
Lloh430:
	adrp	x1, l_.str.57@PAGE
Lloh431:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	add	x2, sp, #288
	mov	x0, x21
	mov	w1, #2                          ; =0x2
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB3_91
; %bb.76:
	ldr	w8, [sp, #288]
	mov	w9, #2                          ; =0x2
	stp	x9, x8, [sp]
Lloh432:
	adrp	x1, l_.str.57@PAGE
Lloh433:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	add	x2, sp, #288
	mov	x0, x21
	mov	w1, #3                          ; =0x3
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB3_91
; %bb.77:
	ldr	w8, [sp, #288]
	mov	w9, #3                          ; =0x3
	stp	x9, x8, [sp]
Lloh434:
	adrp	x1, l_.str.57@PAGE
Lloh435:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	add	x2, sp, #288
	mov	x0, x21
	mov	w1, #4                          ; =0x4
	bl	_nvm_file_cyclic_hosted_import
	cbz	w0, LBB3_91
; %bb.78:
	ldr	w8, [sp, #288]
	mov	w9, #4                          ; =0x4
	stp	x9, x8, [sp]
Lloh436:
	adrp	x1, l_.str.57@PAGE
Lloh437:
	add	x1, x1, l_.str.57@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cbz	w8, LBB3_90
; %bb.79:
	mov	w22, #0                         ; =0x0
Lloh438:
	adrp	x28, l_.str.58@PAGE
Lloh439:
	add	x28, x28, l_.str.58@PAGEOFF
Lloh440:
	adrp	x24, l_.str.59@PAGE
Lloh441:
	add	x24, x24, l_.str.59@PAGEOFF
Lloh442:
	adrp	x23, l_.str.154@PAGE
Lloh443:
	add	x23, x23, l_.str.154@PAGEOFF
Lloh444:
	adrp	x26, l_.str.60@PAGE
Lloh445:
	add	x26, x26, l_.str.60@PAGEOFF
Lloh446:
	adrp	x20, l_.str.61@PAGE
Lloh447:
	add	x20, x20, l_.str.61@PAGEOFF
Lloh448:
	adrp	x25, l_.str.62@PAGE
Lloh449:
	add	x25, x25, l_.str.62@PAGEOFF
LBB3_80:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_84 Depth 2
                                        ;     Child Loop BB3_88 Depth 2
	add	x2, sp, #288
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_function
	cbz	w0, LBB3_91
; %bb.81:                               ;   in Loop: Header=BB3_80 Depth=1
	add	x2, sp, #192
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_file_cyclic_hosted_function_order
	tbz	w0, #0, LBB3_91
; %bb.82:                               ;   in Loop: Header=BB3_80 Depth=1
	mov	x8, x22
	ldr	w9, [sp, #192]
	stp	x9, x8, [sp, #8]
	str	x8, [sp]
	mov	x0, x19
	mov	x27, x28
	mov	x1, x28
	bl	_fn_text
	ldr	w8, [sp, #288]
	stp	x24, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #292]
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #296]
	stp	x20, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #300]
	stp	x25, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #302]
	str	x8, [sp, #8]
Lloh450:
	adrp	x8, l_.str.63@PAGE
Lloh451:
	add	x8, x8, l_.str.63@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrb	w8, [sp, #304]
	str	x8, [sp, #8]
Lloh452:
	adrp	x8, l_.str.64@PAGE
Lloh453:
	add	x8, x8, l_.str.64@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	add	x8, sp, #53
	ldur	x2, [x8, #255]
	add	x8, sp, #61
	ldur	x3, [x8, #255]
	mov	x0, x19
Lloh454:
	adrp	x1, l_.str.65@PAGE
Lloh455:
	add	x1, x1, l_.str.65@PAGEOFF
	bl	_fn_declaration
	ldrh	w8, [sp, #324]
	str	x8, [sp, #8]
Lloh456:
	adrp	x8, l_.str.66@PAGE
Lloh457:
	add	x8, x8, l_.str.66@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #326]
	str	x8, [sp, #8]
Lloh458:
	adrp	x8, l_.str.67@PAGE
Lloh459:
	add	x8, x8, l_.str.67@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #328]
	str	x8, [sp, #8]
Lloh460:
	adrp	x8, l_.str.68@PAGE
Lloh461:
	add	x8, x8, l_.str.68@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #330]
	str	x8, [sp, #8]
Lloh462:
	adrp	x8, l_.str.69@PAGE
Lloh463:
	add	x8, x8, l_.str.69@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #332]
	str	x8, [sp, #8]
Lloh464:
	adrp	x8, l_.str.70@PAGE
Lloh465:
	add	x8, x8, l_.str.70@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #334]
	str	x8, [sp, #8]
Lloh466:
	adrp	x8, l_.str.71@PAGE
Lloh467:
	add	x8, x8, l_.str.71@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #336]
	str	x8, [sp, #8]
Lloh468:
	adrp	x8, l_.str.72@PAGE
Lloh469:
	add	x8, x8, l_.str.72@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #338]
	str	x8, [sp, #8]
Lloh470:
	adrp	x8, l_.str.73@PAGE
Lloh471:
	add	x8, x8, l_.str.73@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #340]
	str	x8, [sp, #8]
Lloh472:
	adrp	x8, l_.str.74@PAGE
Lloh473:
	add	x8, x8, l_.str.74@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	w8, [sp, #344]
	str	x8, [sp, #8]
Lloh474:
	adrp	x8, l_.str.75@PAGE
Lloh475:
	add	x8, x8, l_.str.75@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	x9, [sp, #352]
Lloh476:
	adrp	x8, l_.str.76@PAGE
Lloh477:
	add	x8, x8, l_.str.76@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldr	x9, [sp, #360]
Lloh478:
	adrp	x8, l_.str.77@PAGE
Lloh479:
	add	x8, x8, l_.str.77@PAGEOFF
	stp	x8, x9, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrb	w8, [sp, #368]
	str	x8, [sp, #8]
Lloh480:
	adrp	x8, l_.str.78@PAGE
Lloh481:
	add	x8, x8, l_.str.78@PAGEOFF
	str	x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldrh	w8, [sp, #328]
Lloh482:
	adrp	x20, l_.str.79@PAGE
Lloh483:
	add	x20, x20, l_.str.79@PAGEOFF
Lloh484:
	adrp	x25, l_.str.80@PAGE
Lloh485:
	add	x25, x25, l_.str.80@PAGEOFF
	cbz	w8, LBB3_86
; %bb.83:                               ;   in Loop: Header=BB3_80 Depth=1
	mov	w28, #0                         ; =0x0
LBB3_84:                                ;   Parent Loop BB3_80 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x3, x29, #192
	mov	x0, x21
	mov	x1, x22
	mov	x2, x28
	bl	_nvm_file_cyclic_hosted_local
	tbz	w0, #0, LBB3_91
; %bb.85:                               ;   in Loop: Header=BB3_84 Depth=2
	stp	x22, x28, [sp]
	mov	x0, x19
	mov	x1, x20
	bl	_fn_text
	ldp	x2, x3, [x29, #-192]
	mov	x0, x19
	mov	x1, x25
	bl	_fn_declaration
	add	w28, w28, #1
	ldrh	w8, [sp, #328]
	cmp	w28, w8
	b.lo	LBB3_84
LBB3_86:                                ;   in Loop: Header=BB3_80 Depth=1
	mov	x25, x26
	mov	x26, x24
	mov	x24, x27
	ldrh	w8, [sp, #296]
Lloh486:
	adrp	x27, l_.str.81@PAGE
Lloh487:
	add	x27, x27, l_.str.81@PAGEOFF
	cbz	w8, LBB3_89
; %bb.87:                               ;   in Loop: Header=BB3_80 Depth=1
	mov	w28, #0                         ; =0x0
	mov	x20, x22
LBB3_88:                                ;   Parent Loop BB3_80 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	stp	x20, x28, [sp]
	mov	x0, x19
	mov	x1, x27
	bl	_fn_text
	add	w28, w28, #1
	ldrh	w8, [sp, #296]
	cmp	w28, w8
	b.lo	LBB3_88
LBB3_89:                                ;   in Loop: Header=BB3_80 Depth=1
	add	w22, w22, #1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w22, w8
	mov	x28, x24
	mov	x24, x26
	mov	x26, x25
Lloh488:
	adrp	x20, l_.str.61@PAGE
Lloh489:
	add	x20, x20, l_.str.61@PAGEOFF
Lloh490:
	adrp	x25, l_.str.62@PAGE
Lloh491:
	add	x25, x25, l_.str.62@PAGEOFF
	b.lo	LBB3_80
LBB3_90:
Lloh492:
	adrp	x1, l_.str.82@PAGE
Lloh493:
	add	x1, x1, l_.str.82@PAGEOFF
	mov	x0, x19
	bl	_fn_text
	b	LBB3_92
LBB3_91:
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #24]
LBB3_92:
	add	sp, sp, #1040
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh222, Lloh223
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpAdd	Lloh240, Lloh241
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpAdd	Lloh236, Lloh237
	.loh AdrpAdd	Lloh234, Lloh235
	.loh AdrpAdd	Lloh232, Lloh233
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpAdd	Lloh228, Lloh229
	.loh AdrpAdd	Lloh226, Lloh227
	.loh AdrpAdd	Lloh242, Lloh243
	.loh AdrpAdd	Lloh244, Lloh245
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpAdd	Lloh248, Lloh249
	.loh AdrpAdd	Lloh250, Lloh251
	.loh AdrpAdd	Lloh252, Lloh253
	.loh AdrpAdd	Lloh254, Lloh255
	.loh AdrpAdd	Lloh302, Lloh303
	.loh AdrpAdd	Lloh300, Lloh301
	.loh AdrpAdd	Lloh298, Lloh299
	.loh AdrpAdd	Lloh296, Lloh297
	.loh AdrpAdd	Lloh294, Lloh295
	.loh AdrpAdd	Lloh292, Lloh293
	.loh AdrpAdd	Lloh290, Lloh291
	.loh AdrpAdd	Lloh288, Lloh289
	.loh AdrpAdd	Lloh286, Lloh287
	.loh AdrpAdd	Lloh284, Lloh285
	.loh AdrpAdd	Lloh282, Lloh283
	.loh AdrpAdd	Lloh280, Lloh281
	.loh AdrpAdd	Lloh278, Lloh279
	.loh AdrpAdd	Lloh276, Lloh277
	.loh AdrpAdd	Lloh274, Lloh275
	.loh AdrpAdd	Lloh272, Lloh273
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpAdd	Lloh268, Lloh269
	.loh AdrpAdd	Lloh266, Lloh267
	.loh AdrpAdd	Lloh264, Lloh265
	.loh AdrpAdd	Lloh262, Lloh263
	.loh AdrpAdd	Lloh260, Lloh261
	.loh AdrpAdd	Lloh258, Lloh259
	.loh AdrpAdd	Lloh256, Lloh257
	.loh AdrpAdd	Lloh328, Lloh329
	.loh AdrpAdd	Lloh326, Lloh327
	.loh AdrpAdd	Lloh324, Lloh325
	.loh AdrpAdd	Lloh322, Lloh323
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh316, Lloh317
	.loh AdrpAdd	Lloh314, Lloh315
	.loh AdrpAdd	Lloh312, Lloh313
	.loh AdrpAdd	Lloh310, Lloh311
	.loh AdrpAdd	Lloh308, Lloh309
	.loh AdrpAdd	Lloh306, Lloh307
	.loh AdrpAdd	Lloh304, Lloh305
	.loh AdrpAdd	Lloh338, Lloh339
	.loh AdrpAdd	Lloh336, Lloh337
	.loh AdrpAdd	Lloh334, Lloh335
	.loh AdrpAdd	Lloh332, Lloh333
	.loh AdrpAdd	Lloh330, Lloh331
	.loh AdrpAdd	Lloh348, Lloh349
	.loh AdrpAdd	Lloh346, Lloh347
	.loh AdrpAdd	Lloh344, Lloh345
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh352, Lloh353
	.loh AdrpAdd	Lloh350, Lloh351
	.loh AdrpAdd	Lloh368, Lloh369
	.loh AdrpAdd	Lloh366, Lloh367
	.loh AdrpAdd	Lloh364, Lloh365
	.loh AdrpAdd	Lloh362, Lloh363
	.loh AdrpAdd	Lloh360, Lloh361
	.loh AdrpAdd	Lloh358, Lloh359
	.loh AdrpAdd	Lloh356, Lloh357
	.loh AdrpAdd	Lloh354, Lloh355
	.loh AdrpAdd	Lloh370, Lloh371
	.loh AdrpAdd	Lloh372, Lloh373
	.loh AdrpAdd	Lloh374, Lloh375
	.loh AdrpAdd	Lloh376, Lloh377
	.loh AdrpAdd	Lloh424, Lloh425
	.loh AdrpAdd	Lloh422, Lloh423
	.loh AdrpAdd	Lloh420, Lloh421
	.loh AdrpAdd	Lloh418, Lloh419
	.loh AdrpAdd	Lloh416, Lloh417
	.loh AdrpAdd	Lloh414, Lloh415
	.loh AdrpAdd	Lloh412, Lloh413
	.loh AdrpAdd	Lloh410, Lloh411
	.loh AdrpAdd	Lloh408, Lloh409
	.loh AdrpAdd	Lloh406, Lloh407
	.loh AdrpAdd	Lloh404, Lloh405
	.loh AdrpAdd	Lloh402, Lloh403
	.loh AdrpAdd	Lloh400, Lloh401
	.loh AdrpAdd	Lloh398, Lloh399
	.loh AdrpAdd	Lloh396, Lloh397
	.loh AdrpAdd	Lloh394, Lloh395
	.loh AdrpAdd	Lloh392, Lloh393
	.loh AdrpAdd	Lloh390, Lloh391
	.loh AdrpAdd	Lloh388, Lloh389
	.loh AdrpAdd	Lloh386, Lloh387
	.loh AdrpAdd	Lloh384, Lloh385
	.loh AdrpAdd	Lloh382, Lloh383
	.loh AdrpAdd	Lloh380, Lloh381
	.loh AdrpAdd	Lloh378, Lloh379
	.loh AdrpAdd	Lloh426, Lloh427
	.loh AdrpAdd	Lloh428, Lloh429
	.loh AdrpAdd	Lloh430, Lloh431
	.loh AdrpAdd	Lloh432, Lloh433
	.loh AdrpAdd	Lloh434, Lloh435
	.loh AdrpAdd	Lloh436, Lloh437
	.loh AdrpAdd	Lloh448, Lloh449
	.loh AdrpAdd	Lloh446, Lloh447
	.loh AdrpAdd	Lloh444, Lloh445
	.loh AdrpAdd	Lloh442, Lloh443
	.loh AdrpAdd	Lloh440, Lloh441
	.loh AdrpAdd	Lloh438, Lloh439
	.loh AdrpAdd	Lloh484, Lloh485
	.loh AdrpAdd	Lloh482, Lloh483
	.loh AdrpAdd	Lloh480, Lloh481
	.loh AdrpAdd	Lloh478, Lloh479
	.loh AdrpAdd	Lloh476, Lloh477
	.loh AdrpAdd	Lloh474, Lloh475
	.loh AdrpAdd	Lloh472, Lloh473
	.loh AdrpAdd	Lloh470, Lloh471
	.loh AdrpAdd	Lloh468, Lloh469
	.loh AdrpAdd	Lloh466, Lloh467
	.loh AdrpAdd	Lloh464, Lloh465
	.loh AdrpAdd	Lloh462, Lloh463
	.loh AdrpAdd	Lloh460, Lloh461
	.loh AdrpAdd	Lloh458, Lloh459
	.loh AdrpAdd	Lloh456, Lloh457
	.loh AdrpAdd	Lloh454, Lloh455
	.loh AdrpAdd	Lloh452, Lloh453
	.loh AdrpAdd	Lloh450, Lloh451
	.loh AdrpAdd	Lloh486, Lloh487
	.loh AdrpAdd	Lloh490, Lloh491
	.loh AdrpAdd	Lloh488, Lloh489
	.loh AdrpAdd	Lloh492, Lloh493
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fcd_supported
_fcd_supported:                         ; @fcd_supported
	.cfi_startproc
; %bb.0:
	cmp	w0, #254
	b.hi	LBB4_3
; %bb.1:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	mov	w8, w8
Lloh494:
	adrp	x9, lJTI4_0@PAGE
Lloh495:
	add	x9, x9, lJTI4_0@PAGEOFF
	adr	x10, LBB4_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB4_2:
	ret
LBB4_3:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh494, Lloh495
	.cfi_endproc
	.section	__TEXT,__const
lJTI4_0:
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
	.byte	(LBB4_3-LBB4_2)>>2
	.byte	(LBB4_2-LBB4_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function fn_declaration
_fn_declaration:                        ; @fn_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x3
	mov	x24, x2
	mov	x20, x1
	mov	x19, x0
Lloh496:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh497:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh498:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	lsr	x27, x2, #32
	lsr	x25, x3, #32
Lloh499:
	adrp	x8, l_.str.156@PAGE
Lloh500:
	add	x8, x8, l_.str.156@PAGEOFF
	stp	x1, x8, [sp]
Lloh501:
	adrp	x21, l_.str.155@PAGE
Lloh502:
	add	x21, x21, l_.str.155@PAGEOFF
	add	x26, sp, #24
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	and	x8, x24, #0xff
	stp	x26, x8, [sp]
Lloh503:
	adrp	x23, l_.str.154@PAGE
Lloh504:
	add	x23, x23, l_.str.154@PAGEOFF
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh505:
	adrp	x8, l_.str.157@PAGE
Lloh506:
	add	x8, x8, l_.str.157@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	ubfx	x8, x24, #8, #8
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh507:
	adrp	x8, l_.str.158@PAGE
Lloh508:
	add	x8, x8, l_.str.158@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x27, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh509:
	adrp	x8, l_.str.159@PAGE
Lloh510:
	add	x8, x8, l_.str.159@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	mov	w8, w22
	stp	x26, x8, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
Lloh511:
	adrp	x8, l_.str.160@PAGE
Lloh512:
	add	x8, x8, l_.str.160@PAGEOFF
	stp	x20, x8, [sp]
	add	x0, sp, #24
	mov	w1, #96                         ; =0x60
	mov	x2, x21
	bl	_snprintf
	stp	x26, x25, [sp]
	mov	x0, x19
	mov	x1, x23
	bl	_fn_text
	ldur	x8, [x29, #-88]
Lloh513:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh514:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh515:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB5_2
; %bb.1:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB5_2:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh513, Lloh514, Lloh515
	.loh AdrpAdd	Lloh511, Lloh512
	.loh AdrpAdd	Lloh509, Lloh510
	.loh AdrpAdd	Lloh507, Lloh508
	.loh AdrpAdd	Lloh505, Lloh506
	.loh AdrpAdd	Lloh503, Lloh504
	.loh AdrpAdd	Lloh501, Lloh502
	.loh AdrpAdd	Lloh499, Lloh500
	.loh AdrpLdrGotLdr	Lloh496, Lloh497, Lloh498
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require exact File bytes and a valid entry identifier"

l_.str.1:                               ; @.str.1
	.asciz	"I refuse %scyclic File preparation (%u)"

l_.str.3:                               ; @.str.3
	.space	1

l_.str.4:                               ; @.str.4
	.asciz	"I lack complete %scyclic File instruction coverage"

l_.str.5:                               ; @.str.5
	.asciz	"static const uint8_t nf_module[]={\n"

l_.str.6:                               ; @.str.6
	.asciz	"%u,%s"

l_.str.7:                               ; @.str.7
	.asciz	"\n"

l_.str.8:                               ; @.str.8
	.asciz	"\n};\n"

l_.str.9:                               ; @.str.9
	.asciz	"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *);\n"

l_.str.10:                              ; @.str.10
	.asciz	"%s"

l_.str.11:                              ; @.str.11
	.asciz	"static NvmFileCyclicExecutionReport nf_execute(const NvmFileCyclicOptions *options,NvmFileRuntimeView *out){\n"

l_.str.13:                              ; @.str.13
	.asciz	"if(!out || !options || options->revision!=NVM_FILE_CYCLIC_RUNTIME_REVISION || options->instruction_limit>NVM_FILE_CYCLIC_FUEL_MAX)return nf_refused(NVM_FILE_RUNTIME_INVALID,options);\nif(!nvm_file_runtime_cyclic_native_abi(1u,sizeof(NvmFileCyclicOptions),sizeof(NvmFileCyclicExecutionReport),sizeof(NvmFileCyclicFrameView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)))return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);\nNvmFileRuntime *c=NULL;uint32_t root;\nNvmFileRuntimeStatus status=nvm_file_runtime_cyclic_create(nf_module,sizeof nf_module,NVM_FILE_RUNTIME_NATIVE,options,&c);\nif(status!=NVM_FILE_RUNTIME_OK)return nf_refused(status,options);\nif(!nf_agrees(nvm_file_runtime_cyclic_plan(c))){(void)nvm_file_runtime_cyclic_destroy(&c,NULL);return nf_refused(NVM_FILE_RUNTIME_UNRESOLVED,options);}\nstatus=nvm_file_runtime_begin(c);\n(void)nf_bits;(void)nf_scalar;\n"

l_.str.14:                              ; @.str.14
	.asciz	"(void)nf_function_%u;\n"

l_.str.15:                              ; @.str.15
	.asciz	"if(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c);\n"

l_.str.16:                              ; @.str.16
	.asciz	"if(status==NVM_FILE_RUNTIME_OK && (!nvm_file_runtime_current_root(c,&root) || root!=%u))status=nf_bad(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nvm_file_runtime_frame_start(c);\nif(status==NVM_FILE_RUNTIME_OK)status=nf_function_%u(c);\nif(status==NVM_FILE_RUNTIME_OK && nvm_file_runtime_current_root(c,&root))status=nf_bad(c);\nif(status!=NVM_FILE_RUNTIME_OK)(void)nvm_file_runtime_fail(c,status);\nreturn nvm_file_runtime_cyclic_destroy(&c,out);\n}\n#undef NF_TRY\n"

l_.str.17:                              ; @.str.17
	.asciz	"NvmFileCyclicExecutionReport nvm_file_cyclic_program_%s(NvmFileHostGrant *grant,const NvmFileCyclicOptions *options,NvmFileScalar *out){\nNvmFileHostStatus entered=nvm_file_host_enter(grant,NVM_FILE_HOST_ABI,NVM_FILE_HOST_CATALOG);\nif(entered!=NVM_FILE_HOST_OK)return nvm_file_cyclic_public_refused(nvm_file_public_grant_status(entered),entered==NVM_FILE_HOST_BUSY?NULL:options);\nNvmFileCyclicExecutionReport report;\nif(!nvm_file_cyclic_public_options(options) || !out)report=nvm_file_cyclic_public_refused(NVM_FILE_RUNTIME_INVALID,options);\nelse {NvmFileCyclicOptions copied=*options;NvmFileRuntimeView view={0};\nif(!nvm_file_runtime_cyclic_public_abi(1u,sizeof copied,sizeof report,sizeof *out))report=nvm_file_cyclic_public_refused(NVM_FILE_RUNTIME_UNRESOLVED,&copied);\nelse {report=nf_execute(&copied,&view);report.runtime=nvm_file_public_publish(report.runtime,&view,out);}}\nnvm_file_host_leave();return report;}\n"

l_.str.18:                              ; @.str.18
	.asciz	"I refuse %scyclic File emission (%u)"

l_.str.19:                              ; @.str.19
	.asciz	"#include <nanolang/file/nanoisa/file_cyclic_native_public.h>\n#include <limits.h>\n#include <string.h>\n"

l_.str.20:                              ; @.str.20
	.asciz	"#if NVM_FILE_CYCLIC_PUBLIC_ABI != 1u || NVM_FILE_CYCLIC_NATIVE_ABI != 1u\n#error I require cyclic public and native ABI revision 1\n#endif\n"

l_.str.23:                              ; @.str.23
	.asciz	"#define NF_TRY(expr) do { NvmFileRuntimeStatus nf_status_=(expr); if(nf_status_!=NVM_FILE_RUNTIME_OK)return nf_status_; } while(0)\n"

l_.str.24:                              ; @.str.24
	.asciz	"static NvmFileRuntimeStatus nf_bad(NvmFileRuntime *c){return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_STATE);}\n"

l_.str.25:                              ; @.str.25
	.asciz	"static int64_t nf_bits(uint64_t x){int64_t y;memcpy(&y,&x,sizeof y);return y;}\n"

l_.str.26:                              ; @.str.26
	.asciz	"static bool nf_scalar(const NvmFileRuntimeView *v,uint8_t tag){\n"

l_.str.27:                              ; @.str.27
	.asciz	" return v->initialized && !v->owning && !v->formal && !v->type.mode &&\n"

l_.str.28:                              ; @.str.28
	.asciz	" v->type.category==NVM_FILE_CATEGORY_UNKNOWN && v->type.tag==tag &&\n"

l_.str.29:                              ; @.str.29
	.asciz	" v->type.global_index==NVM_V2_NO_INDEX && v->type.catalog_ordinal==NVM_V2_NO_INDEX &&\n"

l_.str.30:                              ; @.str.30
	.asciz	" v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);\n"

l_.str.31:                              ; @.str.31
	.asciz	"}\n"

l_.str.32:                              ; @.str.32
	.asciz	"static NvmFileCyclicExecutionReport nf_refused(NvmFileRuntimeStatus status,const NvmFileCyclicOptions *options){\nNvmFileCyclicExecutionReport r={0};r.revision=1u;r.instruction_limit=options?options->instruction_limit:0;\nr.runtime.status=status;r.runtime.function=r.runtime.instruction=NVM_V2_NO_INDEX;return r;}\n"

l_.str.33:                              ; @.str.33
	.asciz	"static bool nf_agrees(const NvmFileCyclicHostedPlan *p){\nNvmFileCyclicHostedStartup s;NvmFileCyclicHostedFunction f;NvmFileFlowDeclaration l;\nNvmFileNominalLayout t;uint32_t ordinal;uint8_t byte;\n(void)l;\nif(!nvm_file_cyclic_hosted_startup(p,&s))return false;\n"

l_.str.34:                              ; @.str.34
	.asciz	"s.revision"

l_.str.35:                              ; @.str.35
	.asciz	"s.entry"

l_.str.36:                              ; @.str.36
	.asciz	"s.initializer"

l_.str.37:                              ; @.str.37
	.asciz	"s.functions"

l_.str.38:                              ; @.str.38
	.asciz	"s.features"

l_.str.39:                              ; @.str.39
	.asciz	"s.vm_value_slots"

l_.str.40:                              ; @.str.40
	.asciz	"s.native_value_slots"

l_.str.41:                              ; @.str.41
	.asciz	"s.frames"

l_.str.42:                              ; @.str.42
	.asciz	"s.reference_slots"

l_.str.43:                              ; @.str.43
	.asciz	"s.region_slots"

l_.str.44:                              ; @.str.44
	.asciz	"s.input_bytes"

l_.str.45:                              ; @.str.45
	.asciz	"s.allocation_bound"

l_.str.46:                              ; @.str.46
	.asciz	"s.query_storage_peak"

l_.str.47:                              ; @.str.47
	.asciz	"s.retained_bound"

l_.str.48:                              ; @.str.48
	.asciz	"s.runtime_admitted"

l_.str.49:                              ; @.str.49
	.asciz	"if(s.input_bytes!=sizeof nf_module)return false;\nfor(size_t n=0;n<sizeof nf_module;n++)if(!nvm_file_cyclic_hosted_bytes(p,n,&byte,1) || byte!=nf_module[n])return false;\n"

l_.str.50:                              ; @.str.50
	.asciz	"if(!nvm_file_cyclic_hosted_type(p,%u,&t))return false;\n"

l_.str.51:                              ; @.str.51
	.asciz	"t.global_index"

l_.str.52:                              ; @.str.52
	.asciz	"t.catalog_ordinal"

l_.str.53:                              ; @.str.53
	.asciz	"t.source_ordinal"

l_.str.54:                              ; @.str.54
	.asciz	"t.layout_kind"

l_.str.55:                              ; @.str.55
	.asciz	"t.ownership_flags"

l_.str.56:                              ; @.str.56
	.asciz	"t.category"

l_.str.57:                              ; @.str.57
	.asciz	"if(!nvm_file_cyclic_hosted_import(p,%u,&ordinal) || ordinal!=%u)return false;\n"

l_.str.58:                              ; @.str.58
	.asciz	"if(!nvm_file_cyclic_hosted_function_order(p,%u,&ordinal) || ordinal!=%u || !nvm_file_cyclic_hosted_function(p,%u,&f))return false;\n"

l_.str.59:                              ; @.str.59
	.asciz	"f.code.code_offset"

l_.str.60:                              ; @.str.60
	.asciz	"f.code.code_length"

l_.str.61:                              ; @.str.61
	.asciz	"f.code.instruction_count"

l_.str.62:                              ; @.str.62
	.asciz	"f.code.declaration.parameters"

l_.str.63:                              ; @.str.63
	.asciz	"f.code.declaration.locals"

l_.str.64:                              ; @.str.64
	.asciz	"f.code.declaration.result_count"

l_.str.65:                              ; @.str.65
	.asciz	"f.code.declaration.result."

l_.str.66:                              ; @.str.66
	.asciz	"f.declared_stack"

l_.str.67:                              ; @.str.67
	.asciz	"f.operand_peak"

l_.str.68:                              ; @.str.68
	.asciz	"f.locals"

l_.str.69:                              ; @.str.69
	.asciz	"f.staging_slots"

l_.str.70:                              ; @.str.70
	.asciz	"f.frames"

l_.str.71:                              ; @.str.71
	.asciz	"f.frame_owner_peak"

l_.str.72:                              ; @.str.72
	.asciz	"f.frame_reference_peak"

l_.str.73:                              ; @.str.73
	.asciz	"f.frame_region_peak"

l_.str.74:                              ; @.str.74
	.asciz	"f.reference_slots"

l_.str.75:                              ; @.str.75
	.asciz	"f.region_slots"

l_.str.76:                              ; @.str.76
	.asciz	"f.vm_value_slots"

l_.str.77:                              ; @.str.77
	.asciz	"f.native_value_slots"

l_.str.78:                              ; @.str.78
	.asciz	"f.entry_variant"

l_.str.79:                              ; @.str.79
	.asciz	"if(!nvm_file_cyclic_hosted_local(p,%u,%u,&l))return false;\n"

l_.str.80:                              ; @.str.80
	.asciz	"l."

l_.str.81:                              ; @.str.81
	.asciz	"if(!nf_agrees_%u_%u(p))return false;\n"

l_.str.82:                              ; @.str.82
	.asciz	"return true;}\n"

l_.str.83:                              ; @.str.83
	.asciz	"static bool nf_agrees_%u_%u(const NvmFileCyclicHostedPlan *p){\nNvmFileCodeInstruction in;NvmFileCyclicVariant variant;\nNvmFileFlowValue value;NvmFileFlowReference reference;\nuint32_t ordinal;uint16_t component;uint8_t count;uint64_t region;\n(void)variant;(void)value;(void)reference;(void)ordinal;(void)region;\n"

l_.str.84:                              ; @.str.84
	.asciz	"if(!nvm_file_cyclic_hosted_instruction(p,%u,%u,&in) || !nvm_file_cyclic_hosted_variant_count(p,%u,%u,&count) || count!=%u || !nvm_file_cyclic_hosted_component(p,%u,%u,&component) || component!=%u)return false;\n"

l_.str.85:                              ; @.str.85
	.asciz	"in.byte_offset"

l_.str.86:                              ; @.str.86
	.asciz	"in.decoded.opcode"

l_.str.87:                              ; @.str.87
	.asciz	"in.decoded.operand_count"

l_.str.88:                              ; @.str.88
	.asciz	"in.decoded.byte_length"

l_.str.89:                              ; @.str.89
	.asciz	"in.successor_count"

l_.str.90:                              ; @.str.90
	.asciz	"in.catalog_ordinal"

l_.str.91:                              ; @.str.91
	.asciz	"if(in.successors[%u]!=%u)return false;\n"

l_.str.92:                              ; @.str.92
	.asciz	"u8"

l_.str.93:                              ; @.str.93
	.asciz	"u16"

l_.str.94:                              ; @.str.94
	.asciz	"u32"

l_.str.95:                              ; @.str.95
	.asciz	"i32"

l_.str.96:                              ; @.str.96
	.asciz	"i64"

l_.str.97:                              ; @.str.97
	.asciz	"if(in.decoded.operand_types[%u]!=%u || (uint64_t)in.decoded.operands[%u].%s!=UINT64_C(%llu))return false;\n"

l_.str.98:                              ; @.str.98
	.asciz	"if(in.call_references[%u]!=%u)return false;\n"

l_.str.99:                              ; @.str.99
	.asciz	"if(!nvm_file_cyclic_hosted_variant(p,%u,%u,%u,&variant))return false;\n"

l_.str.100:                             ; @.str.100
	.asciz	"variant.input.locals"

l_.str.101:                             ; @.str.101
	.asciz	"variant.input.stack"

l_.str.102:                             ; @.str.102
	.asciz	"variant.input.regions"

l_.str.103:                             ; @.str.103
	.asciz	"variant.input.owners"

l_.str.104:                             ; @.str.104
	.asciz	"variant.input.references"

l_.str.105:                             ; @.str.105
	.asciz	"variant.output.locals"

l_.str.106:                             ; @.str.106
	.asciz	"variant.output.stack"

l_.str.107:                             ; @.str.107
	.asciz	"variant.output.regions"

l_.str.108:                             ; @.str.108
	.asciz	"variant.output.owners"

l_.str.109:                             ; @.str.109
	.asciz	"variant.output.references"

l_.str.110:                             ; @.str.110
	.asciz	"variant.edge_mask"

l_.str.111:                             ; @.str.111
	.asciz	"variant.edge_variants[0]"

l_.str.112:                             ; @.str.112
	.asciz	"variant.edge_variants[1]"

l_.str.113:                             ; @.str.113
	.asciz	"variant.body.reachable"

l_.str.114:                             ; @.str.114
	.asciz	"variant.body.exit_checked"

l_.str.115:                             ; @.str.115
	.asciz	"variant.body.refinement"

l_.str.116:                             ; @.str.116
	.asciz	"variant.body.has_obligation"

l_.str.117:                             ; @.str.117
	.asciz	"variant.body.input_stack"

l_.str.118:                             ; @.str.118
	.asciz	"variant.body.output_stack"

l_.str.119:                             ; @.str.119
	.asciz	"variant.body.cleanup_local"

l_.str.120:                             ; @.str.120
	.asciz	"variant.body.cleanup"

l_.str.121:                             ; @.str.121
	.asciz	"variant.body.discharged_checks"

l_.str.122:                             ; @.str.122
	.asciz	"variant.body.pending_checks"

l_.str.123:                             ; @.str.123
	.asciz	"variant.body.obligation.kind"

l_.str.124:                             ; @.str.124
	.asciz	"variant.body.obligation.site"

l_.str.125:                             ; @.str.125
	.asciz	"variant.body.obligation.target"

l_.str.126:                             ; @.str.126
	.asciz	"variant.body.obligation.checks"

l_.str.127:                             ; @.str.127
	.asciz	"variant.body.obligation.required_rights"

l_.str.128:                             ; @.str.128
	.asciz	"variant.body.obligation.acquired_rights"

l_.str.129:                             ; @.str.129
	.asciz	"variant.body.obligation.parameters"

l_.str.130:                             ; @.str.130
	.asciz	"variant.body.obligation.owned_inputs"

l_.str.131:                             ; @.str.131
	.asciz	"variant.body.obligation.borrowed_inputs"

l_.str.132:                             ; @.str.132
	.asciz	"variant.body.obligation.result_count"

l_.str.133:                             ; @.str.133
	.asciz	"variant.body.obligation.outcomes[0]"

l_.str.134:                             ; @.str.134
	.asciz	"variant.body.obligation.outcomes[1]"

l_.str.135:                             ; @.str.135
	.asciz	"variant.body.obligation.result."

l_.str.136:                             ; @.str.136
	.asciz	"if(!nvm_file_cyclic_hosted_input_local(p,%u,%u,%u,%u,&value))return false;\n"

l_.str.137:                             ; @.str.137
	.asciz	"if(!nvm_file_cyclic_hosted_input_stack(p,%u,%u,%u,%u,&value))return false;\n"

l_.str.138:                             ; @.str.138
	.asciz	"for(uint16_t n=0;n<NVM_FILE_FLOW_REFERENCES;n++){\nif(!nvm_file_cyclic_hosted_input_reference(p,%u,%u,%u,n,&reference))return false;\nswitch(n){\n"

l_.str.139:                             ; @.str.139
	.asciz	"case %u:\n"

l_.str.140:                             ; @.str.140
	.asciz	"reference.live"

l_.str.141:                             ; @.str.141
	.asciz	"reference.formal"

l_.str.142:                             ; @.str.142
	.asciz	"reference.local"

l_.str.143:                             ; @.str.143
	.asciz	"reference.owner"

l_.str.144:                             ; @.str.144
	.asciz	"reference.identity"

l_.str.145:                             ; @.str.145
	.asciz	"reference.region"

l_.str.146:                             ; @.str.146
	.asciz	"reference.shared"

l_.str.147:                             ; @.str.147
	.asciz	"break;\n"

l_.str.148:                             ; @.str.148
	.asciz	"default:if(reference.live || reference.formal || reference.local || reference.owner || reference.identity || reference.region || reference.shared)return false;break;}}\n"

l_.str.149:                             ; @.str.149
	.asciz	"if(!nvm_file_cyclic_hosted_input_region(p,%u,%u,%u,%u,&region) || region!=UINT64_C(%llu))return false;\n"

l_.str.150:                             ; @.str.150
	.asciz	"value.type."

l_.str.151:                             ; @.str.151
	.asciz	"value.initialized"

l_.str.152:                             ; @.str.152
	.asciz	"value.owner"

l_.str.153:                             ; @.str.153
	.asciz	"value.arm"

l_.str.154:                             ; @.str.154
	.asciz	"if((uint64_t)(%s)!=UINT64_C(%llu))return false;\n"

l_.str.155:                             ; @.str.155
	.asciz	"%s%s"

l_.str.156:                             ; @.str.156
	.asciz	"tag"

l_.str.157:                             ; @.str.157
	.asciz	"mode"

l_.str.158:                             ; @.str.158
	.asciz	"global_index"

l_.str.159:                             ; @.str.159
	.asciz	"catalog_ordinal"

l_.str.160:                             ; @.str.160
	.asciz	"category"

l_.str.161:                             ; @.str.161
	.asciz	"static NvmFileRuntimeStatus nf_function_%u(NvmFileRuntime *c){\nNvmFileCyclicFrameView current;NvmFileCyclicVariant variant;NvmFileRuntimeFrameView f;\nNvmFileRuntimeView value,values[2];NvmFileFlowArm arm;\nuint32_t src=0,dst=0,output=0,reference=0,roots[2],inputs[NVM_FILE_RUNTIME_FIELDS];\nuint8_t edge=0,tag=0;int64_t a=0,z=0,r=0;\n(void)value;(void)values;(void)arm;(void)src;(void)dst;(void)output;(void)reference;\n(void)roots;(void)inputs;(void)edge;(void)tag;(void)a;(void)z;(void)r;\n"

l_.str.162:                             ; @.str.162
	.asciz	"if(0)goto nf_label_%u;\n"

l_.str.163:                             ; @.str.163
	.asciz	"goto nf_label_0;\n"

l_.str.164:                             ; @.str.164
	.asciz	"nf_label_%u:\n"

l_.str.165:                             ; @.str.165
	.asciz	"return nf_bad(c);\n"

l_.str.166:                             ; @.str.166
	.asciz	"if(!nvm_file_runtime_cyclic_frame_view(c,&current) || current.instruction_open || current.frame.mode!=NVM_FILE_RUNTIME_NATIVE || current.frame.function!=%u || current.frame.instruction!=%u || !nvm_file_cyclic_hosted_variant(nvm_file_runtime_cyclic_plan(c),%u,%u,current.variant,&variant) || !variant.body.reachable || variant.input.stack!=current.frame.stack_count)return nf_bad(c);\nf=current.frame;(void)f;NF_TRY(nvm_file_runtime_cyclic_enter(c));\n"

l_.str.167:                             ; @.str.167
	.asciz	"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_scalar(c,dst,%u,nf_bits(UINT64_C(%llu))));\n"

l_.str.168:                             ; @.str.168
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_copy(c,src,dst));\n"

l_.str.169:                             ; @.str.169
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\n"

l_.str.170:                             ; @.str.170
	.asciz	"if(value.owning || value.formal)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"

l_.str.171:                             ; @.str.171
	.asciz	"NF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.172:                             ; @.str.172
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(!value.initialized || value.formal || value.owning!=%u)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_%s(c,src,dst));\n"

l_.str.173:                             ; @.str.173
	.asciz	"move"

l_.str.174:                             ; @.str.174
	.asciz	"copy"

l_.str.175:                             ; @.str.175
	.asciz	"NF_TRY(nvm_file_runtime_frame_store(c));\n"

l_.str.176:                             ; @.str.176
	.asciz	"NF_TRY(nvm_file_runtime_frame_region_begin(c));\n"

l_.str.177:                             ; @.str.177
	.asciz	"NF_TRY(nvm_file_runtime_frame_region_end(c));\n"

l_.str.178:                             ; @.str.178
	.asciz	"NF_TRY(nvm_file_runtime_frame_borrow(c));\n"

l_.str.179:                             ; @.str.179
	.asciz	"NF_TRY(nvm_file_runtime_frame_end_reference(c));\n"

l_.str.180:                             ; @.str.180
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.181:                             ; @.str.181
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src))return nf_bad(c);\nNF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nedge=arm==NVM_FILE_FLOW_ARM_ERROR;\n"

l_.str.182:                             ; @.str.182
	.asciz	"if(!nvm_file_runtime_frame_local(c,%u,&src) || !nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\nNF_TRY(nvm_file_runtime_take(c,src,%u,dst));\n"

l_.str.183:                             ; @.str.183
	.asciz	"src=reference=NVM_FILE_RUNTIME_NO_SLOT;\nif(!nvm_file_runtime_frame_scratch(c,&dst))return nf_bad(c);\n"

l_.str.184:                             ; @.str.184
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return nf_bad(c);\n"

l_.str.185:                             ; @.str.185
	.asciz	"if(!nvm_file_runtime_frame_reference(c,%u,&reference))return nf_bad(c);\n"

l_.str.186:                             ; @.str.186
	.asciz	"NF_TRY(nvm_file_runtime_service(c,%u,reference,src,dst));\nif(!nvm_file_runtime_frame_reserve(c,(uint16_t)(f.stack_count-%u),&output))return nf_bad(c);\nNF_TRY(nvm_file_runtime_move(c,dst,output));\n"

l_.str.187:                             ; @.str.187
	.asciz	"if(!f.stack_count || !nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) || !nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(!nf_scalar(&value,TAG_BOOL))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_drop(c,src));\n"

l_.str.188:                             ; @.str.188
	.asciz	"if(!value.values[0])return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_ASSERT);\n"

l_.str.189:                             ; @.str.189
	.asciz	"edge=(value.values[0]!=0)==%u;\n"

l_.str.190:                             ; @.str.190
	.asciz	"if(f.stack_count<%u)return nf_bad(c);\n"

l_.str.191:                             ; @.str.191
	.asciz	"if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&inputs[%u]))return nf_bad(c);\n"

l_.str.192:                             ; @.str.192
	.asciz	"dst=inputs[0];\n"

l_.str.193:                             ; @.str.193
	.asciz	"if(!nvm_file_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return nf_bad(c);\n"

l_.str.194:                             ; @.str.194
	.asciz	"NF_TRY(nvm_file_runtime_construct(c,%u,%u,inputs,%u,dst));\n"

l_.str.195:                             ; @.str.195
	.asciz	"NF_TRY(nvm_file_runtime_project(c,src,%u,src));\n"

l_.str.196:                             ; @.str.196
	.asciz	"if(!nvm_file_runtime_view(c,src,&value))return nf_bad(c);\nif(value.owning || value.formal || value.type.category!=NVM_FILE_CATEGORY_SCALAR_RESULT)return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\nNF_TRY(nvm_file_runtime_result_arm(c,src,&arm));\nNF_TRY(nvm_file_runtime_drop(c,src));\nNF_TRY(nvm_file_runtime_scalar(c,src,TAG_INT,arm==NVM_FILE_FLOW_ARM_ERROR));\n"

l_.str.197:                             ; @.str.197
	.asciz	"NF_TRY(nvm_file_runtime_frame_call(c));\nNF_TRY(nf_function_%u(c));\ngoto nf_label_%u;\n"

l_.str.198:                             ; @.str.198
	.asciz	"return nvm_file_runtime_frame_return(c);\n"

l_.str.199:                             ; @.str.199
	.asciz	"NF_TRY(nvm_file_runtime_frame_next(c,edge));\nif(edge)goto nf_label_%u;\ngoto nf_label_%u;\n"

l_.str.200:                             ; @.str.200
	.asciz	"NF_TRY(nvm_file_runtime_frame_next(c,0));\ngoto nf_label_%u;\n"

l_.str.201:                             ; @.str.201
	.asciz	"nf_bits((uint64_t)a+(uint64_t)z)"

l_.str.202:                             ; @.str.202
	.asciz	"nf_bits((uint64_t)a-(uint64_t)z)"

l_.str.203:                             ; @.str.203
	.asciz	"nf_bits((uint64_t)a*(uint64_t)z)"

l_.str.204:                             ; @.str.204
	.asciz	"!z?0:a==INT64_MIN&&z==-1?INT64_MIN:a/z"

l_.str.205:                             ; @.str.205
	.asciz	"!z||(a==INT64_MIN&&z==-1)?0:a%z"

l_.str.206:                             ; @.str.206
	.asciz	"nf_bits(UINT64_C(0)-(uint64_t)a)"

l_.str.207:                             ; @.str.207
	.asciz	"a==z"

l_.str.208:                             ; @.str.208
	.asciz	"a!=z"

l_.str.209:                             ; @.str.209
	.asciz	"a<z"

l_.str.210:                             ; @.str.210
	.asciz	"a<=z"

l_.str.211:                             ; @.str.211
	.asciz	"a>z"

l_.str.212:                             ; @.str.212
	.asciz	"a>=z"

l_.str.213:                             ; @.str.213
	.asciz	"a&&z"

l_.str.214:                             ; @.str.214
	.asciz	"a||z"

l_.str.215:                             ; @.str.215
	.asciz	"!a"

l_.str.216:                             ; @.str.216
	.asciz	"if(!nvm_file_runtime_frame_operand(c,(uint16_t)(f.stack_count-%u),&roots[%u]) || !nvm_file_runtime_view(c,roots[%u],&values[%u]))return nf_bad(c);\n"

l_.str.217:                             ; @.str.217
	.asciz	"tag=%u;\n"

l_.str.218:                             ; @.str.218
	.asciz	"if(values[0].type.tag==TAG_BOOL)tag=TAG_BOOL;\n"

l_.str.219:                             ; @.str.219
	.asciz	"if(!nf_scalar(&values[%u],tag))return nvm_file_runtime_fail(c,NVM_FILE_RUNTIME_TYPE);\n"

l_.str.220:                             ; @.str.220
	.asciz	"a=values[0].values[0];z=%s;r=(%s);\n"

l_.str.221:                             ; @.str.221
	.asciz	"0"

l_.str.222:                             ; @.str.222
	.asciz	"values[1].values[0]"

l_.str.223:                             ; @.str.223
	.asciz	"NF_TRY(nvm_file_runtime_drop(c,roots[%u]));\n"

l_.str.224:                             ; @.str.224
	.asciz	"NF_TRY(nvm_file_runtime_scalar(c,roots[0],%u,r));\n"

.subsections_via_symbols
