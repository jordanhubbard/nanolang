	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_cursor_init     ; -- Begin function nvm_v2_cursor_init
	.globl	_nvm_v2_cursor_init
	.p2align	2
_nvm_v2_cursor_init:                    ; @nvm_v2_cursor_init
	.cfi_startproc
; %bb.0:
	stp	x1, x2, [x0]
	str	xzr, [x0, #16]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_cursor_exhausted ; -- Begin function nvm_v2_cursor_exhausted
	.globl	_nvm_v2_cursor_exhausted
	.p2align	2
_nvm_v2_cursor_exhausted:               ; @nvm_v2_cursor_exhausted
	.cfi_startproc
; %bb.0:
	ldp	x9, x8, [x0, #8]
	cmp	x8, x9
	cset	w0, hs
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_take            ; -- Begin function nvm_v2_take
	.globl	_nvm_v2_take
	.p2align	2
_nvm_v2_take:                           ; @nvm_v2_take
	.cfi_startproc
; %bb.0:
	ldp	x8, x9, [x0, #8]
	sub	x8, x8, x9
	cmp	x1, x8
	b.ls	LBB2_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB2_2:
	cbz	x2, LBB2_4
; %bb.3:
	ldr	x8, [x0]
	add	x8, x8, x9
	str	x8, [x2]
LBB2_4:
	add	x9, x9, x1
	str	x9, [x0, #16]
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_u8              ; -- Begin function nvm_v2_u8
	.globl	_nvm_v2_u8
	.p2align	2
_nvm_v2_u8:                             ; @nvm_v2_u8
	.cfi_startproc
; %bb.0:
	ldp	x10, x9, [x0, #8]
	cmp	x10, x9
	b.ne	LBB3_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB3_2:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8]
	add	x11, x9, #1
	str	x11, [x8, #16]
	ldrb	w8, [x10, x9]
	strb	w8, [x1]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_u16             ; -- Begin function nvm_v2_u16
	.globl	_nvm_v2_u16
	.p2align	2
_nvm_v2_u16:                            ; @nvm_v2_u16
	.cfi_startproc
; %bb.0:
	ldp	x10, x9, [x0, #8]
	sub	x10, x10, x9
	cmp	x10, #2
	b.hs	LBB4_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB4_2:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8]
	add	x11, x9, #2
	str	x11, [x8, #16]
	ldrh	w8, [x10, x9]
	strh	w8, [x1]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_u32             ; -- Begin function nvm_v2_u32
	.globl	_nvm_v2_u32
	.p2align	2
_nvm_v2_u32:                            ; @nvm_v2_u32
	.cfi_startproc
; %bb.0:
	ldp	x10, x9, [x0, #8]
	sub	x10, x10, x9
	cmp	x10, #4
	b.hs	LBB5_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB5_2:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8]
	add	x11, x9, #4
	str	x11, [x8, #16]
	ldr	w8, [x10, x9]
	str	w8, [x1]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_u64             ; -- Begin function nvm_v2_u64
	.globl	_nvm_v2_u64
	.p2align	2
_nvm_v2_u64:                            ; @nvm_v2_u64
	.cfi_startproc
; %bb.0:
	ldp	x10, x9, [x0, #8]
	sub	x10, x10, x9
	cmp	x10, #8
	b.hs	LBB6_2
; %bb.1:
	mov	w0, #1                          ; =0x1
	ret
LBB6_2:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x10, [x8]
	add	x11, x9, #8
	str	x11, [x8, #16]
	ldr	x8, [x10, x9]
	str	x8, [x1]
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_align4          ; -- Begin function nvm_v2_align4
	.globl	_nvm_v2_align4
	.p2align	2
_nvm_v2_align4:                         ; @nvm_v2_align4
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #16]
	tst	x8, #0x3
	b.eq	LBB7_18
; %bb.1:
	ldr	x9, [x0, #8]
	cmp	x9, x8
	b.ne	LBB7_3
; %bb.2:
	mov	w0, #1                          ; =0x1
	ret
LBB7_3:
	ldr	x10, [x0]
	add	x9, x8, #1
	str	x9, [x0, #16]
	ldrb	w10, [x10, x8]
	cbz	w10, LBB7_5
; %bb.4:
	mov	w0, #9                          ; =0x9
	ret
LBB7_5:
	tst	x9, #0x3
	b.eq	LBB7_18
; %bb.6:
	ldr	x10, [x0, #8]
	cmp	x10, x9
	b.ne	LBB7_8
; %bb.7:
	mov	w0, #1                          ; =0x1
	ret
LBB7_8:
	ldr	x11, [x0]
	add	x10, x8, #2
	str	x10, [x0, #16]
	ldrb	w9, [x11, x9]
	cbz	w9, LBB7_10
; %bb.9:
	mov	w0, #9                          ; =0x9
	ret
LBB7_10:
	tst	x10, #0x3
	b.eq	LBB7_18
; %bb.11:
	ldr	x9, [x0, #8]
	cmp	x9, x10
	b.ne	LBB7_13
; %bb.12:
	mov	w0, #1                          ; =0x1
	ret
LBB7_13:
	ldr	x11, [x0]
	add	x9, x8, #3
	str	x9, [x0, #16]
	ldrb	w10, [x11, x10]
	cbz	w10, LBB7_15
; %bb.14:
	mov	w0, #9                          ; =0x9
	ret
LBB7_15:
	tst	x9, #0x3
	b.eq	LBB7_18
; %bb.16:
	ldr	x10, [x0, #8]
	cmp	x10, x9
	b.ne	LBB7_19
; %bb.17:
	mov	w0, #1                          ; =0x1
	ret
LBB7_18:
	mov	w0, #0                          ; =0x0
	ret
LBB7_19:
	ldr	x10, [x0]
	add	x8, x8, #4
	str	x8, [x0, #16]
	ldrb	w8, [x10, x9]
	mov	w9, #9                          ; =0x9
	cmp	w8, #0
	csel	w0, wzr, w9, eq
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
