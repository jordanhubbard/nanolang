	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nl_websocket_plan_build ; -- Begin function nl_websocket_plan_build
	.globl	_nl_websocket_plan_build
	.p2align	2
_nl_websocket_plan_build:               ; @nl_websocket_plan_build
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x0, [sp, #16]
	adrp	x1, _catalog@PAGE
	add	x1, x1, _catalog@PAGEOFF
	bl	_nl_service_catalog_document_equal
	tbnz	w0, #0, LBB0_3
	b	LBB0_2
LBB0_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_3:
	mov	x0, #8                          ; =0x8
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB0_5
	b	LBB0_4
LBB0_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB0_6
LBB0_5:
	ldr	x9, [sp]
	adrp	x8, _catalog@PAGE
	add	x8, x8, _catalog@PAGEOFF
	str	x8, [x9]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB0_6
LBB0_6:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_document_equal
_nl_service_catalog_document_equal:     ; @nl_service_catalog_document_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB1_12
	b	LBB1_1
LBB1_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	cbnz	w8, LBB1_12
	b	LBB1_2
LBB1_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_12
	b	LBB1_3
LBB1_3:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_12
	b	LBB1_4
LBB1_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_5
LBB1_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_6
LBB1_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #64]
	subs	x8, x8, #1
	b.ne	LBB1_12
	b	LBB1_7
LBB1_7:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #80]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.ne	LBB1_12
	b	LBB1_8
LBB1_8:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_12
	b	LBB1_9
LBB1_9:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	cbz	x8, LBB1_12
	b	LBB1_10
LBB1_10:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	cbz	x8, LBB1_12
	b	LBB1_11
LBB1_11:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	cbnz	x8, LBB1_13
	b	LBB1_12
LBB1_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_13:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_16
	b	LBB1_14
LBB1_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #24]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_16
	b	LBB1_15
LBB1_15:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #56]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	ldr	x1, [x8, #32]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_17
	b	LBB1_16
LBB1_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_17:
	stur	xzr, [x29, #-32]
	b	LBB1_18
LBB1_18:                                ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB1_24
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x0, [x8, x9]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	lsl	x9, x9, #4
	ldr	x1, [x8, x9]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_21
	b	LBB1_20
LBB1_20:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #40]
	ldur	x9, [x29, #-32]
	add	x8, x8, x9, lsl #4
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_22
	b	LBB1_21
LBB1_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_22:                                ;   in Loop: Header=BB1_18 Depth=1
	b	LBB1_23
LBB1_23:                                ;   in Loop: Header=BB1_18 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1
	stur	x8, [x29, #-32]
	b	LBB1_18
LBB1_24:
	stur	xzr, [x29, #-40]
	b	LBB1_25
LBB1_25:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_33 Depth 2
	ldur	x8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB1_48
	b	LBB1_26
LBB1_26:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-40]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-40]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-48]
	ldr	x0, [x8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_31
	b	LBB1_27
LBB1_27:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-56]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_31
	b	LBB1_28
LBB1_28:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	cbnz	w8, LBB1_31
	b	LBB1_29
LBB1_29:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ne	LBB1_31
	b	LBB1_30
LBB1_30:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB1_32
	b	LBB1_31
LBB1_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_32:                                ;   in Loop: Header=BB1_25 Depth=1
	str	xzr, [sp, #64]
	b	LBB1_33
LBB1_33:                                ;   Parent Loop BB1_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-56]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB1_46
	b	LBB1_34
LBB1_34:                                ;   in Loop: Header=BB1_33 Depth=2
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #64]
	mov	x10, #48                        ; =0x30
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #56]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #64]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #56]
	ldr	x0, [x8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_35
LBB1_35:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_36
LBB1_36:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	x0, [x8, #16]
	ldr	x8, [sp, #48]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_43
	b	LBB1_37
LBB1_37:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_38
LBB1_38:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #28]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_39
LBB1_39:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #32]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_40
LBB1_40:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #36]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #36]
	subs	w8, w8, w9
	b.ne	LBB1_43
	b	LBB1_41
LBB1_41:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #40]
	cbnz	w8, LBB1_43
	b	LBB1_42
LBB1_42:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #44]
	cbz	w8, LBB1_44
	b	LBB1_43
LBB1_43:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_44:                                ;   in Loop: Header=BB1_33 Depth=2
	b	LBB1_45
LBB1_45:                                ;   in Loop: Header=BB1_33 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #1
	str	x8, [sp, #64]
	b	LBB1_33
LBB1_46:                                ;   in Loop: Header=BB1_25 Depth=1
	b	LBB1_47
LBB1_47:                                ;   in Loop: Header=BB1_25 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #1
	stur	x8, [x29, #-40]
	b	LBB1_25
LBB1_48:
	str	xzr, [sp, #40]
	b	LBB1_49
LBB1_49:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_63 Depth 2
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB1_72
	b	LBB1_50
LBB1_50:                                ;   in Loop: Header=BB1_49 Depth=1
	ldur	x8, [x29, #-16]
	mov	x10, #40                        ; =0x28
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #40]
	add	x8, x8, x9, lsl #6
	str	x8, [sp, #32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #40]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x0, [x8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_61
	b	LBB1_51
LBB1_51:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #24]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_61
	b	LBB1_52
LBB1_52:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #16]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB1_61
	b	LBB1_53
LBB1_53:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #32]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB1_61
	b	LBB1_54
LBB1_54:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #40]
	cbnz	x8, LBB1_61
	b	LBB1_55
LBB1_55:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #48]
	cbnz	x8, LBB1_61
	b	LBB1_56
LBB1_56:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB1_61
	b	LBB1_57
LBB1_57:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbz	x8, LBB1_59
	b	LBB1_58
LBB1_58:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_61
	b	LBB1_59
LBB1_59:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB1_62
	b	LBB1_60
LBB1_60:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #24]
	cbz	x8, LBB1_62
	b	LBB1_61
LBB1_61:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_62:                                ;   in Loop: Header=BB1_49 Depth=1
	str	xzr, [sp, #16]
	b	LBB1_63
LBB1_63:                                ;   Parent Loop BB1_49 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB1_70
	b	LBB1_64
LBB1_64:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #32]
	mov	x10, #24                        ; =0x18
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8, #24]
	ldr	x9, [sp, #16]
	add	x8, x8, x9, lsl #5
	str	x8, [sp]
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	ldr	x8, [sp]
	ldr	x1, [x8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_67
	b	LBB1_65
LBB1_65:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	ldr	x8, [sp]
	ldr	x1, [x8, #8]
	bl	_nl_service_catalog_text_equal
	tbz	w0, #0, LBB1_67
	b	LBB1_66
LBB1_66:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	ldr	x8, [sp]
	ldr	x1, [x8, #16]
	bl	_nl_service_catalog_text_equal
	tbnz	w0, #0, LBB1_68
	b	LBB1_67
LBB1_67:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_68:                                ;   in Loop: Header=BB1_63 Depth=2
	b	LBB1_69
LBB1_69:                                ;   in Loop: Header=BB1_63 Depth=2
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB1_63
LBB1_70:                                ;   in Loop: Header=BB1_49 Depth=1
	b	LBB1_71
LBB1_71:                                ;   in Loop: Header=BB1_49 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #1
	str	x8, [sp, #40]
	b	LBB1_49
LBB1_72:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB1_73
LBB1_73:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_free ; -- Begin function nl_websocket_plan_free
	.globl	_nl_websocket_plan_free
	.p2align	2
_nl_websocket_plan_free:                ; @nl_websocket_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_free
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_storage_size ; -- Begin function nl_websocket_plan_storage_size
	.globl	_nl_websocket_plan_storage_size
	.p2align	2
_nl_websocket_plan_storage_size:        ; @nl_websocket_plan_storage_size
	.cfi_startproc
; %bb.0:
	mov	x0, #8                          ; =0x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_interface ; -- Begin function nl_websocket_plan_interface
	.globl	_nl_websocket_plan_interface
	.p2align	2
_nl_websocket_plan_interface:           ; @nl_websocket_plan_interface
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB4_3
LBB4_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB4_3
LBB4_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_method_count ; -- Begin function nl_websocket_plan_method_count
	.globl	_nl_websocket_plan_method_count
	.p2align	2
_nl_websocket_plan_method_count:        ; @nl_websocket_plan_method_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #64]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_3
LBB5_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_type_count ; -- Begin function nl_websocket_plan_type_count
	.globl	_nl_websocket_plan_type_count
	.p2align	2
_nl_websocket_plan_type_count:          ; @nl_websocket_plan_type_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #80]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB6_3
LBB6_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_capability_count ; -- Begin function nl_websocket_plan_capability_count
	.globl	_nl_websocket_plan_capability_count
	.p2align	2
_nl_websocket_plan_capability_count:    ; @nl_websocket_plan_capability_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_3
LBB7_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB7_3
LBB7_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_method ; -- Begin function nl_websocket_plan_method
	.globl	_nl_websocket_plan_method
	.p2align	2
_nl_websocket_plan_method:              ; @nl_websocket_plan_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB8_3
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.hs	LBB8_3
	b	LBB8_2
LBB8_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #56]
	ldr	x9, [sp, #16]
	mov	x10, #96                        ; =0x60
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB8_4
LBB8_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_type ; -- Begin function nl_websocket_plan_type
	.globl	_nl_websocket_plan_type
	.p2align	2
_nl_websocket_plan_type:                ; @nl_websocket_plan_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB9_3
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #80]
	subs	x8, x8, x9
	b.hs	LBB9_3
	b	LBB9_2
LBB9_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #72]
	ldr	x9, [sp, #16]
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB9_4
LBB9_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB9_4
LBB9_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_plan_capability ; -- Begin function nl_websocket_plan_capability
	.globl	_nl_websocket_plan_capability
	.p2align	2
_nl_websocket_plan_capability:          ; @nl_websocket_plan_capability
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB10_3
	b	LBB10_1
LBB10_1:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.hs	LBB10_3
	b	LBB10_2
LBB10_2:
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #16]
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB10_4
LBB10_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB10_4
LBB10_4:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_interface ; -- Begin function nl_websocket_catalog_interface
	.globl	_nl_websocket_catalog_interface
	.p2align	2
_nl_websocket_catalog_interface:        ; @nl_websocket_catalog_interface
	.cfi_startproc
; %bb.0:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_method ; -- Begin function nl_websocket_catalog_method
	.globl	_nl_websocket_catalog_method
	.p2align	2
_nl_websocket_catalog_method:           ; @nl_websocket_catalog_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #4
	b.hs	LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #8]
	mov	x9, #96                         ; =0x60
	mul	x9, x8, x9
	adrp	x8, _methods@PAGE
	add	x8, x8, _methods@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB12_3
LBB12_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB12_3
LBB12_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_type ; -- Begin function nl_websocket_catalog_type
	.globl	_nl_websocket_catalog_type
	.p2align	2
_nl_websocket_catalog_type:             ; @nl_websocket_catalog_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #7
	b.hs	LBB13_2
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #8]
	mov	x9, #40                         ; =0x28
	mul	x9, x8, x9
	adrp	x8, _types@PAGE
	add	x8, x8, _types@PAGEOFF
	add	x8, x8, x9
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB13_3
LBB13_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB13_3
LBB13_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nl_websocket_catalog_capability ; -- Begin function nl_websocket_catalog_capability
	.globl	_nl_websocket_catalog_capability
	.p2align	2
_nl_websocket_catalog_capability:       ; @nl_websocket_catalog_capability
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	subs	x8, x8, #2
	b.hs	LBB14_2
	b	LBB14_1
LBB14_1:
	ldr	x9, [sp, #8]
	adrp	x8, _capabilities@PAGE
	add	x8, x8, _capabilities@PAGEOFF
	add	x8, x8, x9, lsl #4
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB14_3
LBB14_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB14_3
LBB14_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nl_service_catalog_text_equal
_nl_service_catalog_text_equal:         ; @nl_service_catalog_text_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
	ldur	x8, [x29, #-8]
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB15_4
LBB15_3:
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB15_4
LBB15_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w0, ne
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__const
	.p2align	3, 0x0                          ; @catalog
_catalog:
	.quad	l_.str
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	_capabilities
	.quad	2                               ; 0x2
	.quad	_methods
	.quad	4                               ; 0x4
	.quad	_types
	.quad	7                               ; 0x7

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:nanolang/websocket"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @capabilities
_capabilities:
	.quad	l_.str.100
	.quad	l_.str.6
	.quad	l_.str.101
	.quad	l_.str.102

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.asciz	"websocket"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:nanolang/websocket#io"

l_.str.3:                               ; @.str.3
	.asciz	"io"

l_.str.4:                               ; @.str.4
	.asciz	"1"

l_.str.5:                               ; @.str.5
	.asciz	"nsi:nanolang/websocket#connect"

l_.str.6:                               ; @.str.6
	.asciz	"connect"

l_.str.7:                               ; @.str.7
	.asciz	"nsi_nanolang_websocket_connect"

l_.str.8:                               ; @.str.8
	.asciz	"nsi.websocket.v1.connect"

l_.str.9:                               ; @.str.9
	.asciz	"nsi:nanolang/websocket#Connection"

l_.str.10:                              ; @.str.10
	.asciz	"nsi:nanolang/websocket#send"

l_.str.11:                              ; @.str.11
	.asciz	"send"

l_.str.12:                              ; @.str.12
	.asciz	"nsi_nanolang_websocket_send"

l_.str.13:                              ; @.str.13
	.asciz	"nsi.websocket.v1.send"

l_.str.14:                              ; @.str.14
	.asciz	"nsi:nanolang/websocket#receive"

l_.str.15:                              ; @.str.15
	.asciz	"receive"

l_.str.16:                              ; @.str.16
	.asciz	"nsi_nanolang_websocket_receive"

l_.str.17:                              ; @.str.17
	.asciz	"nsi.websocket.v1.receive"

l_.str.18:                              ; @.str.18
	.asciz	"nsi:nanolang/websocket#close"

l_.str.19:                              ; @.str.19
	.asciz	"close"

l_.str.20:                              ; @.str.20
	.asciz	"nsi_nanolang_websocket_close"

l_.str.21:                              ; @.str.21
	.asciz	"nsi.websocket.v1.close"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @methods
_methods:
	.quad	l_.str.5
	.quad	l_.str.6
	.quad	l_.str.7
	.quad	l_.str.8
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	19                              ; 0x13
	.long	0                               ; 0x0
	.quad	_connect_params
	.quad	3                               ; 0x3
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.9
	.space	16
	.quad	l_.str.10
	.quad	l_.str.11
	.quad	l_.str.12
	.quad	l_.str.13
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_send_params
	.quad	4                               ; 0x4
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.14
	.quad	l_.str.15
	.quad	l_.str.16
	.quad	l_.str.17
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.quad	_receive_params
	.quad	3                               ; 0x3
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.long	1                               ; 0x1
	.space	4
	.quad	0
	.quad	l_.str.18
	.quad	l_.str.19
	.quad	l_.str.20
	.quad	l_.str.21
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.quad	_close_params
	.quad	3                               ; 0x3
	.long	2                               ; 0x2
	.space	4
	.quad	0
	.long	2                               ; 0x2
	.space	4
	.quad	0

	.section	__TEXT,__cstring,cstring_literals
l_.str.23:                              ; @.str.23
	.asciz	"nsi:nanolang/websocket#connect.url"

l_.str.24:                              ; @.str.24
	.asciz	"url"

l_.str.25:                              ; @.str.25
	.asciz	"nsi:core/string"

l_.str.26:                              ; @.str.26
	.asciz	"nsi:nanolang/websocket#connect.timeout_ms"

l_.str.27:                              ; @.str.27
	.asciz	"timeout_ms"

l_.str.28:                              ; @.str.28
	.asciz	"nsi:core/int"

l_.str.29:                              ; @.str.29
	.asciz	"nsi:nanolang/websocket#connect.result"

l_.str.30:                              ; @.str.30
	.asciz	"result"

l_.str.31:                              ; @.str.31
	.asciz	"nsi:nanolang/websocket#ConnectResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @connect_params
_connect_params:
	.quad	l_.str.23
	.quad	l_.str.24
	.quad	l_.str.25
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.26
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.29
	.quad	l_.str.30
	.quad	l_.str.31
	.long	3                               ; 0x3
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.33:                              ; @.str.33
	.asciz	"nsi:nanolang/websocket#send.connection"

l_.str.34:                              ; @.str.34
	.asciz	"connection"

l_.str.35:                              ; @.str.35
	.asciz	"nsi:nanolang/websocket#send.message"

l_.str.36:                              ; @.str.36
	.asciz	"message"

l_.str.37:                              ; @.str.37
	.asciz	"nsi:nanolang/websocket#Message"

l_.str.38:                              ; @.str.38
	.asciz	"nsi:nanolang/websocket#send.timeout_ms"

l_.str.39:                              ; @.str.39
	.asciz	"nsi:nanolang/websocket#send.result"

l_.str.40:                              ; @.str.40
	.asciz	"nsi:nanolang/websocket#SendResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @send_params
_send_params:
	.quad	l_.str.33
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.35
	.quad	l_.str.36
	.quad	l_.str.37
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.38
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.39
	.quad	l_.str.30
	.quad	l_.str.40
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.42:                              ; @.str.42
	.asciz	"nsi:nanolang/websocket#receive.connection"

l_.str.43:                              ; @.str.43
	.asciz	"nsi:nanolang/websocket#receive.timeout_ms"

l_.str.44:                              ; @.str.44
	.asciz	"nsi:nanolang/websocket#receive.result"

l_.str.45:                              ; @.str.45
	.asciz	"nsi:nanolang/websocket#ReceiveResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @receive_params
_receive_params:
	.quad	l_.str.42
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.43
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.44
	.quad	l_.str.30
	.quad	l_.str.45
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.47:                              ; @.str.47
	.asciz	"nsi:nanolang/websocket#close.connection"

l_.str.48:                              ; @.str.48
	.asciz	"nsi:nanolang/websocket#close.timeout_ms"

l_.str.49:                              ; @.str.49
	.asciz	"nsi:nanolang/websocket#close.result"

l_.str.50:                              ; @.str.50
	.asciz	"nsi:nanolang/websocket#CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @close_params
_close_params:
	.quad	l_.str.47
	.quad	l_.str.34
	.quad	l_.str.9
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.48
	.quad	l_.str.27
	.quad	l_.str.28
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	5                               ; 0x5
	.space	4
	.quad	l_.str.49
	.quad	l_.str.30
	.quad	l_.str.50
	.long	3                               ; 0x3
	.long	2                               ; 0x2
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.52:                              ; @.str.52
	.asciz	"Connection"

l_.str.53:                              ; @.str.53
	.asciz	"nsi:nanolang/websocket#WebSocketError"

l_.str.54:                              ; @.str.54
	.asciz	"WebSocketError"

l_.str.55:                              ; @.str.55
	.asciz	"Message"

l_.str.56:                              ; @.str.56
	.asciz	"ConnectResult"

l_.str.57:                              ; @.str.57
	.asciz	"SendResult"

l_.str.58:                              ; @.str.58
	.asciz	"ReceiveResult"

l_.str.59:                              ; @.str.59
	.asciz	"CloseResult"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @types
_types:
	.quad	l_.str.9
	.quad	l_.str.52
	.long	6                               ; 0x6
	.space	4
	.quad	0
	.quad	0                               ; 0x0
	.quad	l_.str.53
	.quad	l_.str.54
	.long	1                               ; 0x1
	.space	4
	.quad	_error_fields
	.quad	9                               ; 0x9
	.quad	l_.str.37
	.quad	l_.str.55
	.long	1                               ; 0x1
	.space	4
	.quad	_message_fields
	.quad	2                               ; 0x2
	.quad	l_.str.31
	.quad	l_.str.56
	.long	2                               ; 0x2
	.space	4
	.quad	_ConnectResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.40
	.quad	l_.str.57
	.long	2                               ; 0x2
	.space	4
	.quad	_SendResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.45
	.quad	l_.str.58
	.long	2                               ; 0x2
	.space	4
	.quad	_ReceiveResult_cases
	.quad	2                               ; 0x2
	.quad	l_.str.50
	.quad	l_.str.59
	.long	2                               ; 0x2
	.space	4
	.quad	_CloseResult_cases
	.quad	2                               ; 0x2

	.section	__TEXT,__cstring,cstring_literals
l_.str.61:                              ; @.str.61
	.asciz	"nsi:nanolang/websocket#WebSocketError.status"

l_.str.62:                              ; @.str.62
	.asciz	"status"

l_.str.63:                              ; @.str.63
	.asciz	"nsi:nanolang/websocket#WebSocketError.host_errno"

l_.str.64:                              ; @.str.64
	.asciz	"host_errno"

l_.str.65:                              ; @.str.65
	.asciz	"nsi:nanolang/websocket#WebSocketError.resolver_error"

l_.str.66:                              ; @.str.66
	.asciz	"resolver_error"

l_.str.67:                              ; @.str.67
	.asciz	"nsi:nanolang/websocket#WebSocketError.supervisor_status"

l_.str.68:                              ; @.str.68
	.asciz	"supervisor_status"

l_.str.69:                              ; @.str.69
	.asciz	"nsi:nanolang/websocket#WebSocketError.close_code"

l_.str.70:                              ; @.str.70
	.asciz	"close_code"

l_.str.71:                              ; @.str.71
	.asciz	"nsi:nanolang/websocket#WebSocketError.cleanup_errno"

l_.str.72:                              ; @.str.72
	.asciz	"cleanup_errno"

l_.str.73:                              ; @.str.73
	.asciz	"nsi:nanolang/websocket#WebSocketError.cleanup_failed"

l_.str.74:                              ; @.str.74
	.asciz	"cleanup_failed"

l_.str.75:                              ; @.str.75
	.asciz	"nsi:core/bool"

l_.str.76:                              ; @.str.76
	.asciz	"nsi:nanolang/websocket#WebSocketError.closure_unknown"

l_.str.77:                              ; @.str.77
	.asciz	"closure_unknown"

l_.str.78:                              ; @.str.78
	.asciz	"nsi:nanolang/websocket#WebSocketError.terminal"

l_.str.79:                              ; @.str.79
	.asciz	"terminal"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @error_fields
_error_fields:
	.quad	l_.str.61
	.quad	l_.str.62
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.63
	.quad	l_.str.64
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.65
	.quad	l_.str.66
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.67
	.quad	l_.str.68
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.69
	.quad	l_.str.70
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.71
	.quad	l_.str.72
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.73
	.quad	l_.str.74
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.76
	.quad	l_.str.77
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.78
	.quad	l_.str.79
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.81:                              ; @.str.81
	.asciz	"nsi:nanolang/websocket#Message.binary"

l_.str.82:                              ; @.str.82
	.asciz	"binary"

l_.str.83:                              ; @.str.83
	.asciz	"nsi:nanolang/websocket#Message.data"

l_.str.84:                              ; @.str.84
	.asciz	"data"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @message_fields
_message_fields:
	.quad	l_.str.81
	.quad	l_.str.82
	.quad	l_.str.75
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.83
	.quad	l_.str.84
	.quad	l_.str.25
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.86:                              ; @.str.86
	.asciz	"nsi:nanolang/websocket#ConnectResult.Ok"

l_.str.87:                              ; @.str.87
	.asciz	"Ok"

l_.str.88:                              ; @.str.88
	.asciz	"nsi:nanolang/websocket#ConnectResult.Error"

l_.str.89:                              ; @.str.89
	.asciz	"Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ConnectResult_cases
_ConnectResult_cases:
	.quad	l_.str.86
	.quad	l_.str.87
	.quad	l_.str.9
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.88
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.91:                              ; @.str.91
	.asciz	"nsi:nanolang/websocket#SendResult.Ok"

l_.str.92:                              ; @.str.92
	.asciz	"nsi:nanolang/websocket#SendResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @SendResult_cases
_SendResult_cases:
	.quad	l_.str.91
	.quad	l_.str.87
	.quad	l_.str.28
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.92
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.94:                              ; @.str.94
	.asciz	"nsi:nanolang/websocket#ReceiveResult.Ok"

l_.str.95:                              ; @.str.95
	.asciz	"nsi:nanolang/websocket#ReceiveResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @ReceiveResult_cases
_ReceiveResult_cases:
	.quad	l_.str.94
	.quad	l_.str.87
	.quad	l_.str.37
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.95
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.97:                              ; @.str.97
	.asciz	"nsi:nanolang/websocket#CloseResult.Ok"

l_.str.98:                              ; @.str.98
	.asciz	"nsi:nanolang/websocket#CloseResult.Error"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @CloseResult_cases
_CloseResult_cases:
	.quad	l_.str.97
	.quad	l_.str.87
	.quad	0
	.long	0                               ; 0x0
	.space	4
	.quad	l_.str.98
	.quad	l_.str.89
	.quad	l_.str.53
	.long	0                               ; 0x0
	.space	4

	.section	__TEXT,__cstring,cstring_literals
l_.str.100:                             ; @.str.100
	.asciz	"cap:nanolang/websocket.connect"

l_.str.101:                             ; @.str.101
	.asciz	"cap:nanolang/net.lookup"

l_.str.102:                             ; @.str.102
	.asciz	"lookup"

.subsections_via_symbols
