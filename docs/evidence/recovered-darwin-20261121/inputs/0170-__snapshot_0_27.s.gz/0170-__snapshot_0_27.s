	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_cyclic_create ; -- Begin function nvm_services_runtime_cyclic_create
	.p2align	2
_nvm_services_runtime_cyclic_create:    ; @nvm_services_runtime_cyclic_create
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x8, x0
Lloh0:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh1:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh2:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB0_27
; %bb.1:
	cbz	x4, LBB0_27
; %bb.2:
	ldr	w9, [x3]
	cmp	w9, #1
	b.ne	LBB0_27
; %bb.3:
	cmp	w2, #1
	b.hi	LBB0_27
; %bb.4:
	ldr	x9, [x3, #8]
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	cmp	x9, x10
	b.hi	LBB0_27
; %bb.5:
	mov	x24, x2
	mov	x23, x3
	mov	x26, x4
	str	xzr, [sp, #128]
	add	x2, sp, #128
	mov	x0, x8
	bl	_nvm_services_cyclic_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB0_27
; %bb.6:
	cbz	w0, LBB0_9
; %bb.7:
	cmp	w0, #1
	b.eq	LBB0_27
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB0_27
LBB0_9:
	ldr	x0, [sp, #128]
	add	x1, sp, #32
	bl	_nvm_services_cyclic_hosted_startup
	cbz	w0, LBB0_26
; %bb.10:
	mov	w21, #0                         ; =0x0
	ldr	x19, [sp, #128]
	mov	w20, #7                         ; =0x7
LBB0_11:                                ; =>This Inner Loop Header: Depth=1
	sub	w1, w20, #7
	add	x2, sp, #140
	mov	x0, x19
	bl	_nvm_services_cyclic_hosted_type
	cbz	w0, LBB0_13
; %bb.12:                               ;   in Loop: Header=BB0_11 Depth=1
	add	x2, sp, #140
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_services_cyclic_hosted_type
	eor	w8, w0, #0x1
	orr	w21, w8, w21
	add	w20, w20, #9
	cmp	w20, #583
	b.ne	LBB0_11
LBB0_13:
Lloh3:
	adrp	x1, l_.memset_pattern.3@PAGE
Lloh4:
	add	x1, x1, l_.memset_pattern.3@PAGEOFF
	add	x0, sp, #176
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #176
	add	x2, sp, #168
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	cbz	w0, LBB0_26
; %bb.14:
Lloh5:
	adrp	x1, l_.memset_pattern@PAGE
Lloh6:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	add	x0, sp, #176
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #176
	add	x2, sp, #160
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	tbz	w0, #0, LBB0_26
; %bb.15:
	ldp	x9, x8, [sp, #160]
	cmp	x8, x9
	csel	x8, x8, x9, hi
	tst	w21, #0x1
	mov	w9, #33554432                   ; =0x2000000
	csel	x9, x9, xzr, ne
	ldp	x20, x25, [sp, #56]
	cmp	w24, #0
	csel	x21, x20, x25, eq
	mov	x10, #-4294967296               ; =0xffffffff00000000
	mov	x11, #-4294967295               ; =0xffffffff00000001
	add	x10, x21, x10
	cmp	x10, x11
	b.lo	LBB0_25
; %bb.16:
	ldrh	w22, [sp, #72]
	cbz	w22, LBB0_25
; %bb.17:
	ldr	w10, [sp, #76]
	cbz	w10, LBB0_25
; %bb.18:
	ldr	w11, [sp, #80]
	cbz	w11, LBB0_25
; %bb.19:
	mov	w13, #4408                      ; =0x1138
	movk	w13, #1019, lsl #16
	ldr	x12, [sp, #112]
	subs	x13, x13, x12
	b.lo	LBB0_25
; %bb.20:
	mov	w14, #176                       ; =0xb0
	mul	x14, x21, x14
	cmp	x14, x13
	b.hi	LBB0_25
; %bb.21:
	lsl	x13, x10, #6
	mov	w15, #4408                      ; =0x1138
	movk	w15, #1019, lsl #16
	add	x12, x12, x14
	sub	x14, x15, x12
	cmp	x13, x14
	b.hi	LBB0_25
; %bb.22:
	add	x12, x12, #78, lsl #12          ; =319488
	add	x14, x12, #3784
	lsl	x12, x11, #3
	mov	w15, #67108864                  ; =0x4000000
	add	x14, x13, x14
	sub	x13, x15, x14
	cmp	x12, x13
	b.hi	LBB0_25
; %bb.23:
	add	x13, x22, x22, lsl #2
	lsl	x13, x13, #3
	mov	w15, #67108864                  ; =0x4000000
	add	x12, x14, x12
	sub	x14, x15, x12
	cmp	x13, x14
	b.hi	LBB0_25
; %bb.24:
	mov	w14, #67108864                  ; =0x4000000
	add	x28, x12, x13
	sub	x12, x14, x28
	add	x27, x8, x9
	cmp	x27, x12
	b.ls	LBB0_29
LBB0_25:
	ldr	x0, [sp, #128]
	bl	_nvm_services_cyclic_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB0_27
LBB0_26:
	ldr	x0, [sp, #128]
	bl	_nvm_services_cyclic_hosted_free
	mov	w0, #1                          ; =0x1
LBB0_27:
	ldur	x8, [x29, #-96]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_51
; %bb.28:
	add	sp, sp, #448
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_29:
	stp	x10, x11, [sp, #16]             ; 16-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #51912                      ; =0xcac8
	movk	w1, #4, lsl #16
	bl	_calloc
	cbz	x0, LBB0_48
; %bb.30:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	mov	w12, #1                         ; =0x1
	str	w12, [x0, #24]
	add	x11, x8, #2732
	add	x8, x28, x27
	ldr	x9, [sp, #128]
	add	x10, x0, #74, lsl #12           ; =303104
	add	x27, x10, #4064
	str	x9, [x0, #8]
	str	w24, [x11]
	str	x11, [sp, #8]                   ; 8-byte Folded Spill
	stur	x12, [x11, #20]
	ldr	x9, [x23, #8]
	str	x9, [x0, #40]
	ldr	x9, [sp, #96]
	ldur	q0, [sp, #36]
	str	q0, [x0, #64]
	stp	x20, x25, [x0, #80]
	strh	w22, [x0, #96]
	ldp	x24, x25, [sp, #16]             ; 16-byte Folded Reload
	stp	w24, w25, [x0, #100]
	stp	x9, x8, [x0, #112]
	stp	w21, w24, [x0, #128]
	str	w25, [x0, #136]
	strh	w22, [x0, #140]
	mov	w0, #1                          ; =0x1
	mov	w1, #9216                       ; =0x2400
	bl	_calloc
	mov	x20, x0
	str	x0, [x19, #32]
	mov	x0, x21
	mov	w1, #176                        ; =0xb0
	bl	_calloc
	mov	x23, x0
	str	x0, [x27]
	mov	x0, x24
	mov	w1, #64                         ; =0x40
	bl	_calloc
	mov	x21, x0
	str	x0, [x27, #8]
	mov	x0, x25
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x24, x0
	str	x0, [x27, #16]
	mov	x0, x22
	mov	w1, #40                         ; =0x28
	bl	_calloc
	mov	x22, x0
	str	x0, [x27, #24]
	mov	w25, #4                         ; =0x4
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	cbz	x20, LBB0_50
; %bb.31:
	cbz	x23, LBB0_50
; %bb.32:
	cbz	x21, LBB0_50
; %bb.33:
	cbz	x24, LBB0_50
; %bb.34:
	cbz	x22, LBB0_50
; %bb.35:
	mov	x25, #0                         ; =0x0
	str	xzr, [sp, #16]                  ; 8-byte Folded Spill
	mov	w8, #9360                       ; =0x2490
	add	x28, x19, x8
	add	x8, x19, #144
	str	x8, [sp]                        ; 8-byte Folded Spill
LBB0_36:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_42 Depth 2
	add	x23, x25, x25, lsl #3
	ldr	x0, [sp, #128]
	add	x2, sp, #176
	mov	x1, x23
	bl	_nvm_services_cyclic_hosted_type
	cbz	w0, LBB0_46
; %bb.37:                               ;   in Loop: Header=BB0_36 Depth=1
	ldr	x0, [sp, #128]
	add	w1, w23, #6
	add	x2, sp, #176
	bl	_nvm_services_cyclic_hosted_type
	cbz	w0, LBB0_49
; %bb.38:                               ;   in Loop: Header=BB0_36 Depth=1
	ldr	x0, [sp, #128]
	add	w1, w23, #8
	add	x2, sp, #176
	bl	_nvm_services_cyclic_hosted_type
	tbz	w0, #0, LBB0_40
; %bb.39:                               ;   in Loop: Header=BB0_36 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB0_41
LBB0_40:                                ;   in Loop: Header=BB0_36 Depth=1
	ldr	x0, [sp, #128]
	add	w1, w23, #7
	add	x2, sp, #176
	bl	_nvm_services_cyclic_hosted_type
	cmp	w0, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
LBB0_41:                                ;   in Loop: Header=BB0_36 Depth=1
	str	w8, [x28, x25, lsl #2]
	ldr	w8, [x19, #9616]
	add	w8, w8, #1
	str	w8, [x19, #9616]
	ldr	x20, [sp]                       ; 8-byte Folded Reload
	ldr	x24, [sp, #16]                  ; 8-byte Folded Reload
LBB0_42:                                ;   Parent Loop BB0_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [sp, #128]
	add	x2, sp, #176
	mov	x1, x24
	bl	_nvm_services_cyclic_hosted_type
	cbz	w0, LBB0_49
; %bb.43:                               ;   in Loop: Header=BB0_42 Depth=2
	ldr	w8, [sp, #180]
	cmp	x24, x8
	b.ne	LBB0_49
; %bb.44:                               ;   in Loop: Header=BB0_42 Depth=2
	ldrb	w9, [sp, #188]
	cmp	w9, #0
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	csel	w9, w10, w9, eq
	ldr	w10, [sp, #176]
	ldr	w11, [sp, #192]
	strb	w9, [x20]
	strb	wzr, [x20, #1]
	strh	wzr, [x20, #2]
	stp	w10, w8, [x20, #4]
	str	w11, [x20, #12]
	add	x24, x24, #1
	ldr	w8, [x28, x25, lsl #2]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	x9, x9, ne
	cmp	w8, #2
	mov	w8, #9                          ; =0x9
	csel	x8, x8, x9, eq
	add	x20, x20, #16
	add	x8, x8, x23
	cmp	x24, x8
	b.lo	LBB0_42
; %bb.45:                               ;   in Loop: Header=BB0_36 Depth=1
	add	x25, x25, #1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, #9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	add	x8, x8, #144
	str	x8, [sp]                        ; 8-byte Folded Spill
	cmp	x25, #64
	b.ne	LBB0_36
LBB0_46:
	ldr	w8, [x19, #9616]
	cbz	w8, LBB0_49
; %bb.47:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x27, #52]
	ldp	w9, w8, [sp, #36]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	w8, [x9, #12]
	str	x19, [x26]
	b	LBB0_27
LBB0_48:
	ldr	x0, [sp, #128]
	bl	_nvm_services_cyclic_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB0_27
LBB0_49:
	mov	w25, #1                         ; =0x1
LBB0_50:
	mov	x0, x22
	bl	_free
	ldr	x0, [x27, #16]
	bl	_free
	mov	x0, x21
	bl	_free
	ldr	x0, [x27]
	bl	_free
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #128]
	bl	_nvm_services_cyclic_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x25
	b	LBB0_27
LBB0_51:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAdd	Lloh3, Lloh4
	.loh AdrpAdd	Lloh5, Lloh6
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_indirect_create ; -- Begin function nvm_services_runtime_indirect_create
	.p2align	2
_nvm_services_runtime_indirect_create:  ; @nvm_services_runtime_indirect_create
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #464
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x8, x0
Lloh10:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh11:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh12:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB1_27
; %bb.1:
	cbz	x4, LBB1_27
; %bb.2:
	ldr	w9, [x3]
	cmp	w9, #1
	b.ne	LBB1_27
; %bb.3:
	cmp	w2, #1
	b.hi	LBB1_27
; %bb.4:
	ldr	x9, [x3, #8]
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	cmp	x9, x10
	b.hi	LBB1_27
; %bb.5:
	mov	x24, x2
	mov	x23, x3
	mov	x26, x4
	str	xzr, [sp, #144]
	add	x2, sp, #144
	mov	x0, x8
	bl	_nvm_services_indirect_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB1_27
; %bb.6:
	cbz	w0, LBB1_9
; %bb.7:
	cmp	w0, #1
	b.eq	LBB1_27
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB1_27
LBB1_9:
	ldr	x0, [sp, #144]
	add	x1, sp, #48
	bl	_nvm_services_indirect_hosted_startup
	cbz	w0, LBB1_26
; %bb.10:
	mov	w21, #0                         ; =0x0
	ldr	x19, [sp, #144]
	mov	w20, #7                         ; =0x7
LBB1_11:                                ; =>This Inner Loop Header: Depth=1
	sub	w1, w20, #7
	add	x2, sp, #156
	mov	x0, x19
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB1_13
; %bb.12:                               ;   in Loop: Header=BB1_11 Depth=1
	add	x2, sp, #156
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_services_indirect_hosted_type
	eor	w8, w0, #0x1
	orr	w21, w8, w21
	add	w20, w20, #9
	cmp	w20, #583
	b.ne	LBB1_11
LBB1_13:
Lloh13:
	adrp	x1, l_.memset_pattern.3@PAGE
Lloh14:
	add	x1, x1, l_.memset_pattern.3@PAGEOFF
	add	x0, sp, #192
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #192
	add	x2, sp, #184
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	cbz	w0, LBB1_26
; %bb.14:
Lloh15:
	adrp	x1, l_.memset_pattern@PAGE
Lloh16:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	add	x0, sp, #192
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #192
	add	x2, sp, #176
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	tbz	w0, #0, LBB1_26
; %bb.15:
	ldp	x9, x8, [sp, #176]
	cmp	x8, x9
	csel	x8, x8, x9, hi
	tst	w21, #0x1
	mov	w9, #33554432                   ; =0x2000000
	csel	x9, x9, xzr, ne
	ldp	x20, x25, [sp, #72]
	cmp	w24, #0
	csel	x21, x20, x25, eq
	mov	x10, #-4294967296               ; =0xffffffff00000000
	mov	x11, #-4294967295               ; =0xffffffff00000001
	add	x10, x21, x10
	cmp	x10, x11
	b.lo	LBB1_25
; %bb.16:
	ldrh	w22, [sp, #88]
	cbz	w22, LBB1_25
; %bb.17:
	ldr	w10, [sp, #92]
	cbz	w10, LBB1_25
; %bb.18:
	ldr	w11, [sp, #96]
	cbz	w11, LBB1_25
; %bb.19:
	mov	w13, #4408                      ; =0x1138
	movk	w13, #1019, lsl #16
	ldr	x12, [sp, #128]
	subs	x13, x13, x12
	b.lo	LBB1_25
; %bb.20:
	mov	w14, #176                       ; =0xb0
	mul	x14, x21, x14
	cmp	x14, x13
	b.hi	LBB1_25
; %bb.21:
	lsl	x13, x10, #6
	mov	w15, #4408                      ; =0x1138
	movk	w15, #1019, lsl #16
	add	x12, x12, x14
	sub	x14, x15, x12
	cmp	x13, x14
	b.hi	LBB1_25
; %bb.22:
	add	x12, x12, #78, lsl #12          ; =319488
	add	x14, x12, #3784
	lsl	x12, x11, #3
	mov	w15, #67108864                  ; =0x4000000
	add	x14, x13, x14
	sub	x13, x15, x14
	cmp	x12, x13
	b.hi	LBB1_25
; %bb.23:
	add	x13, x22, x22, lsl #2
	lsl	x13, x13, #3
	mov	w15, #67108864                  ; =0x4000000
	add	x12, x14, x12
	sub	x14, x15, x12
	cmp	x13, x14
	b.hi	LBB1_25
; %bb.24:
	mov	w14, #67108864                  ; =0x4000000
	add	x28, x12, x13
	sub	x12, x14, x28
	add	x27, x8, x9
	cmp	x27, x12
	b.ls	LBB1_29
LBB1_25:
	ldr	x0, [sp, #144]
	bl	_nvm_services_indirect_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB1_27
LBB1_26:
	ldr	x0, [sp, #144]
	bl	_nvm_services_indirect_hosted_free
	mov	w0, #1                          ; =0x1
LBB1_27:
	ldur	x8, [x29, #-96]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_51
; %bb.28:
	add	sp, sp, #464
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_29:
	stp	x10, x11, [sp, #32]             ; 16-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #51912                      ; =0xcac8
	movk	w1, #4, lsl #16
	bl	_calloc
	cbz	x0, LBB1_48
; %bb.30:
	mov	x19, x0
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #24]
	add	x8, x0, #76, lsl #12            ; =311296
	add	x10, x8, #2732
	ldr	x8, [sp, #144]
	str	x8, [x0, #16]
	add	x8, x0, #74, lsl #12            ; =303104
	add	x8, x8, #4064
	stp	x10, x8, [sp, #16]              ; 16-byte Folded Spill
	add	x8, x28, x27
	str	w24, [x10]
	mov	w9, #1                          ; =0x1
	stur	x9, [x10, #20]
	ldr	x9, [x23, #8]
	str	x9, [x0, #40]
	ldr	x9, [sp, #112]
	ldur	q0, [sp, #52]
	str	q0, [x0, #64]
	stp	x20, x25, [x0, #80]
	strh	w22, [x0, #96]
	ldp	x24, x25, [sp, #32]             ; 16-byte Folded Reload
	stp	w24, w25, [x0, #100]
	stp	x9, x8, [x0, #112]
	stp	w21, w24, [x0, #128]
	str	w25, [x0, #136]
	strh	w22, [x0, #140]
	mov	w0, #1                          ; =0x1
	mov	w1, #9216                       ; =0x2400
	bl	_calloc
	mov	x20, x0
	str	x0, [x19, #32]
	mov	x0, x21
	mov	w1, #176                        ; =0xb0
	bl	_calloc
	mov	x23, x0
	ldr	x27, [sp, #24]                  ; 8-byte Folded Reload
	str	x0, [x27]
	mov	x0, x24
	mov	w1, #64                         ; =0x40
	bl	_calloc
	mov	x21, x0
	str	x0, [x27, #8]
	mov	x0, x25
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x24, x0
	str	x0, [x27, #16]
	mov	x0, x22
	mov	w1, #40                         ; =0x28
	bl	_calloc
	mov	x22, x0
	str	x0, [x27, #24]
	mov	w25, #4                         ; =0x4
	str	x20, [sp, #40]                  ; 8-byte Folded Spill
	cbz	x20, LBB1_50
; %bb.31:
	cbz	x23, LBB1_50
; %bb.32:
	cbz	x21, LBB1_50
; %bb.33:
	cbz	x24, LBB1_50
; %bb.34:
	cbz	x22, LBB1_50
; %bb.35:
	mov	x25, #0                         ; =0x0
	str	xzr, [sp, #32]                  ; 8-byte Folded Spill
	mov	w8, #9360                       ; =0x2490
	add	x28, x19, x8
	add	x8, x19, #144
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB1_36:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_42 Depth 2
	add	x23, x25, x25, lsl #3
	ldr	x0, [sp, #144]
	add	x2, sp, #192
	mov	x1, x23
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB1_46
; %bb.37:                               ;   in Loop: Header=BB1_36 Depth=1
	ldr	x0, [sp, #144]
	add	w1, w23, #6
	add	x2, sp, #192
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB1_49
; %bb.38:                               ;   in Loop: Header=BB1_36 Depth=1
	ldr	x0, [sp, #144]
	add	w1, w23, #8
	add	x2, sp, #192
	bl	_nvm_services_indirect_hosted_type
	tbz	w0, #0, LBB1_40
; %bb.39:                               ;   in Loop: Header=BB1_36 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB1_41
LBB1_40:                                ;   in Loop: Header=BB1_36 Depth=1
	ldr	x0, [sp, #144]
	add	w1, w23, #7
	add	x2, sp, #192
	bl	_nvm_services_indirect_hosted_type
	cmp	w0, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
LBB1_41:                                ;   in Loop: Header=BB1_36 Depth=1
	str	w8, [x28, x25, lsl #2]
	ldr	w8, [x19, #9616]
	add	w8, w8, #1
	str	w8, [x19, #9616]
	ldr	x20, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x24, [sp, #32]                  ; 8-byte Folded Reload
LBB1_42:                                ;   Parent Loop BB1_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [sp, #144]
	add	x2, sp, #192
	mov	x1, x24
	bl	_nvm_services_indirect_hosted_type
	cbz	w0, LBB1_49
; %bb.43:                               ;   in Loop: Header=BB1_42 Depth=2
	ldr	w8, [sp, #196]
	cmp	x24, x8
	b.ne	LBB1_49
; %bb.44:                               ;   in Loop: Header=BB1_42 Depth=2
	ldrb	w9, [sp, #204]
	cmp	w9, #0
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	csel	w9, w10, w9, eq
	ldr	w10, [sp, #192]
	ldr	w11, [sp, #208]
	strb	w9, [x20]
	strb	wzr, [x20, #1]
	strh	wzr, [x20, #2]
	stp	w10, w8, [x20, #4]
	str	w11, [x20, #12]
	add	x24, x24, #1
	ldr	w8, [x28, x25, lsl #2]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	x9, x9, ne
	cmp	w8, #2
	mov	w8, #9                          ; =0x9
	csel	x8, x8, x9, eq
	add	x20, x20, #16
	add	x8, x8, x23
	cmp	x24, x8
	b.lo	LBB1_42
; %bb.45:                               ;   in Loop: Header=BB1_36 Depth=1
	add	x25, x25, #1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, x8, #9
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x8, #144
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	cmp	x25, #64
	b.ne	LBB1_36
LBB1_46:
	ldr	w8, [x19, #9616]
	cbz	w8, LBB1_49
; %bb.47:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x27, #52]
	ldp	w9, w8, [sp, #52]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	w8, [x9, #12]
	str	x19, [x26]
	b	LBB1_27
LBB1_48:
	ldr	x0, [sp, #144]
	bl	_nvm_services_indirect_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB1_27
LBB1_49:
	mov	w25, #1                         ; =0x1
LBB1_50:
	mov	x0, x22
	bl	_free
	ldr	x0, [x27, #16]
	bl	_free
	mov	x0, x21
	bl	_free
	ldr	x0, [x27]
	bl	_free
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #144]
	bl	_nvm_services_indirect_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x25
	b	LBB1_27
LBB1_51:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh10, Lloh11, Lloh12
	.loh AdrpAdd	Lloh13, Lloh14
	.loh AdrpAdd	Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_create    ; -- Begin function nvm_services_runtime_create
	.p2align	2
_nvm_services_runtime_create:           ; @nvm_services_runtime_create
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x8, x0
Lloh20:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh21:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh22:
	ldr	x9, [x9]
	stur	x9, [x29, #-96]
	mov	w0, #1                          ; =0x1
	cmp	w2, #1
	b.hi	LBB2_23
; %bb.1:
	cbz	x3, LBB2_23
; %bb.2:
	mov	x23, x2
	mov	x24, x3
	str	xzr, [sp, #96]
	add	x2, sp, #96
	mov	x0, x8
	bl	_nvm_services_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB2_23
; %bb.3:
	cbz	w0, LBB2_5
; %bb.4:
	mov	w8, #2                          ; =0x2
	cmp	w0, #1
	csel	w0, w0, w8, eq
	b	LBB2_23
LBB2_5:
	ldr	x0, [sp, #96]
	add	x1, sp, #40
	bl	_nvm_services_hosted_startup
	cbz	w0, LBB2_22
; %bb.6:
	mov	w21, #0                         ; =0x0
	ldr	x19, [sp, #96]
	mov	w20, #7                         ; =0x7
LBB2_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	w1, w20, #7
	add	x2, sp, #108
	mov	x0, x19
	bl	_nvm_services_hosted_type
	cbz	w0, LBB2_9
; %bb.8:                                ;   in Loop: Header=BB2_7 Depth=1
	add	x2, sp, #108
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_services_hosted_type
	eor	w8, w0, #0x1
	orr	w21, w8, w21
	add	w20, w20, #9
	cmp	w20, #583
	b.ne	LBB2_7
LBB2_9:
Lloh23:
	adrp	x1, l_.memset_pattern.3@PAGE
Lloh24:
	add	x1, x1, l_.memset_pattern.3@PAGEOFF
	add	x0, sp, #144
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #144
	add	x2, sp, #136
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	cbz	w0, LBB2_22
; %bb.10:
Lloh25:
	adrp	x1, l_.memset_pattern@PAGE
Lloh26:
	add	x1, x1, l_.memset_pattern@PAGEOFF
	add	x0, sp, #144
	mov	w2, #256                        ; =0x100
	bl	_memset_pattern16
	add	x0, sp, #144
	add	x2, sp, #128
	mov	w1, #64                         ; =0x40
	bl	_nl_services_values_storage_bound
	tbz	w0, #0, LBB2_22
; %bb.11:
	ldp	x9, x8, [sp, #128]
	cmp	x8, x9
	csel	x8, x8, x9, hi
	tst	w21, #0x1
	mov	w9, #33554432                   ; =0x2000000
	csel	x9, x9, xzr, ne
	add	x10, sp, #40
	add	x11, x10, #16
	add	x10, x10, #24
	cmp	w23, #0
	csel	x10, x11, x10, eq
	ldr	x20, [x10]
	mov	x10, #-4294967296               ; =0xffffffff00000000
	mov	x11, #-4294967295               ; =0xffffffff00000001
	add	x10, x20, x10
	cmp	x10, x11
	b.lo	LBB2_21
; %bb.12:
	ldrh	w25, [sp, #72]
	cbz	w25, LBB2_21
; %bb.13:
	ldr	w22, [sp, #76]
	cbz	w22, LBB2_21
; %bb.14:
	ldr	w21, [sp, #80]
	cbz	w21, LBB2_21
; %bb.15:
	mov	w11, #13624                     ; =0x3538
	movk	w11, #1019, lsl #16
	ldr	x10, [sp, #88]
	subs	x12, x11, x10
	b.lo	LBB2_21
; %bb.16:
	mov	w11, #176                       ; =0xb0
	mul	x11, x20, x11
	cmp	x11, x12
	b.hi	LBB2_21
; %bb.17:
	mov	w12, #51912                     ; =0xcac8
	movk	w12, #4, lsl #16
	add	x10, x10, x11
	add	x10, x10, x12
	lsl	x12, x22, #6
	mov	w11, #67108864                  ; =0x4000000
	sub	x11, x11, x10
	cmp	x12, x11
	b.hi	LBB2_21
; %bb.18:
	lsl	x11, x21, #3
	mov	w13, #67108864                  ; =0x4000000
	add	x12, x12, x10
	sub	x10, x13, x12
	cmp	x11, x10
	b.hi	LBB2_21
; %bb.19:
	add	x10, x25, x25, lsl #2
	lsl	x10, x10, #3
	mov	w13, #67108864                  ; =0x4000000
	add	x11, x12, x11
	sub	x12, x13, x11
	cmp	x10, x12
	b.hi	LBB2_21
; %bb.20:
	mov	w12, #67108864                  ; =0x4000000
	add	x26, x11, x10
	sub	x10, x12, x26
	add	x27, x8, x9
	cmp	x27, x10
	b.ls	LBB2_25
LBB2_21:
	ldr	x0, [sp, #96]
	bl	_nvm_services_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB2_23
LBB2_22:
	ldr	x0, [sp, #96]
	bl	_nvm_services_hosted_free
	mov	w0, #1                          ; =0x1
LBB2_23:
	ldur	x8, [x29, #-96]
Lloh27:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh28:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh29:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB2_46
; %bb.24:
	add	sp, sp, #416
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB2_25:
	mov	w0, #1                          ; =0x1
	mov	w1, #51912                      ; =0xcac8
	movk	w1, #4, lsl #16
	bl	_calloc
	cbz	x0, LBB2_43
; %bb.26:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	ldr	x9, [sp, #96]
	add	x10, x8, #2732
	str	x9, [x0]
	add	x8, x0, #74, lsl #12            ; =303104
	add	x28, x8, #4064
	add	x8, x26, x27
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #56]
	stp	q0, q1, [x0, #64]
	ldur	q0, [sp, #72]
	str	q0, [x0, #96]
	mov	w9, #1                          ; =0x1
	stur	x9, [x10, #20]
	ldr	x9, [sp, #88]
	str	x10, [sp, #32]                  ; 8-byte Folded Spill
	str	w23, [x10]
	stp	x9, x8, [x0, #112]
	stp	w20, w22, [x0, #128]
	str	w21, [x0, #136]
	strh	w25, [x0, #140]
	mov	x0, x20
	mov	w1, #176                        ; =0xb0
	bl	_calloc
	mov	x23, x0
	str	x0, [x28]
	mov	x0, x22
	mov	w1, #64                         ; =0x40
	bl	_calloc
	mov	x20, x0
	str	x0, [x28, #8]
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x21, x0
	str	x0, [x28, #16]
	mov	x0, x25
	mov	x25, x28
	mov	w1, #40                         ; =0x28
	bl	_calloc
	str	x0, [x28, #24]
	mov	w22, #4                         ; =0x4
	cbz	x23, LBB2_45
; %bb.27:
	cbz	x20, LBB2_45
; %bb.28:
	cbz	x21, LBB2_45
; %bb.29:
	cbz	x0, LBB2_45
; %bb.30:
	stp	x0, x25, [sp]                   ; 16-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	w8, #9360                       ; =0x2490
	add	x28, x19, x8
	add	x8, x19, #144
	stp	x8, xzr, [sp, #16]              ; 16-byte Folded Spill
	mov	w27, #7                         ; =0x7
	mov	w25, #9                         ; =0x9
LBB2_31:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_37 Depth 2
	add	x21, x26, x26, lsl #3
	ldr	x0, [sp, #96]
	add	x2, sp, #144
	mov	x1, x21
	bl	_nvm_services_hosted_type
	cbz	w0, LBB2_41
; %bb.32:                               ;   in Loop: Header=BB2_31 Depth=1
	ldr	x0, [sp, #96]
	add	w1, w21, #6
	add	x2, sp, #144
	bl	_nvm_services_hosted_type
	cbz	w0, LBB2_44
; %bb.33:                               ;   in Loop: Header=BB2_31 Depth=1
	ldr	x0, [sp, #96]
	add	w1, w21, #8
	add	x2, sp, #144
	bl	_nvm_services_hosted_type
	tbz	w0, #0, LBB2_35
; %bb.34:                               ;   in Loop: Header=BB2_31 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB2_36
LBB2_35:                                ;   in Loop: Header=BB2_31 Depth=1
	ldr	x0, [sp, #96]
	add	w1, w21, #7
	add	x2, sp, #144
	bl	_nvm_services_hosted_type
	cmp	w0, #0
	mov	w8, #3                          ; =0x3
	csinc	w8, w8, wzr, eq
LBB2_36:                                ;   in Loop: Header=BB2_31 Depth=1
	str	w8, [x28, x26, lsl #2]
	ldr	w8, [x19, #9616]
	add	w8, w8, #1
	str	w8, [x19, #9616]
	ldp	x23, x22, [sp, #16]             ; 16-byte Folded Reload
LBB2_37:                                ;   Parent Loop BB2_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x0, [sp, #96]
	add	x2, sp, #144
	mov	x1, x22
	bl	_nvm_services_hosted_type
	cbz	w0, LBB2_44
; %bb.38:                               ;   in Loop: Header=BB2_37 Depth=2
	ldr	w8, [sp, #148]
	cmp	x22, x8
	b.ne	LBB2_44
; %bb.39:                               ;   in Loop: Header=BB2_37 Depth=2
	ldrb	w9, [sp, #156]
	cmp	w9, #0
	mov	w9, #10                         ; =0xa
	mov	w10, #8                         ; =0x8
	csel	w9, w10, w9, eq
	ldr	w10, [sp, #144]
	ldr	w11, [sp, #160]
	strb	w9, [x23]
	strb	wzr, [x23, #1]
	strh	wzr, [x23, #2]
	stp	w10, w8, [x23, #4]
	str	w11, [x23, #12]
	add	x22, x22, #1
	ldr	w8, [x28, x26, lsl #2]
	cmp	w8, #3
	cinc	x9, x27, ne
	cmp	w8, #2
	csel	x8, x25, x9, eq
	add	x23, x23, #16
	add	x8, x8, x21
	cmp	x22, x8
	b.lo	LBB2_37
; %bb.40:                               ;   in Loop: Header=BB2_31 Depth=1
	add	x26, x26, #1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x9, x8, #9
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, #144
	stp	x8, x9, [sp, #16]               ; 16-byte Folded Spill
	cmp	x26, #64
	b.ne	LBB2_31
LBB2_41:
	ldr	w8, [x19, #9616]
	cbz	w8, LBB2_44
; %bb.42:
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0xffffffffffffffff
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stur	d0, [x8, #52]
	ldp	w9, w8, [sp, #40]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #12]
	str	x19, [x24]
	b	LBB2_23
LBB2_43:
	ldr	x0, [sp, #96]
	bl	_nvm_services_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB2_23
LBB2_44:
	mov	w22, #1                         ; =0x1
	ldp	x0, x25, [sp]                   ; 16-byte Folded Reload
LBB2_45:
	bl	_free
	ldr	x0, [x25, #16]
	bl	_free
	mov	x0, x20
	bl	_free
	ldr	x0, [x25]
	bl	_free
	ldr	x0, [sp, #96]
	bl	_nvm_services_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x22
	b	LBB2_23
LBB2_46:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh20, Lloh21, Lloh22
	.loh AdrpAdd	Lloh23, Lloh24
	.loh AdrpAdd	Lloh25, Lloh26
	.loh AdrpLdrGotLdr	Lloh27, Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_storage   ; -- Begin function nvm_services_runtime_storage
	.p2align	2
_nvm_services_runtime_storage:          ; @nvm_services_runtime_storage
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB3_2
; %bb.1:
	ldur	q0, [x8, #120]
	ldr	x8, [x8, #136]
	str	x8, [x1, #16]
	str	q0, [x1]
LBB3_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_plan      ; -- Begin function nvm_services_runtime_plan
	.p2align	2
_nvm_services_runtime_plan:             ; @nvm_services_runtime_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_2
; %bb.1:
	ldr	x0, [x0]
LBB4_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_begin     ; -- Begin function nvm_services_runtime_begin
	.p2align	2
_nvm_services_runtime_begin:            ; @nvm_services_runtime_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB5_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB5_59
LBB5_3:
	mov	w0, #1                          ; =0x1
	ret
LBB5_4:
	ldr	w8, [x20]
	cbz	w8, LBB5_6
; %bb.5:
	mov	w9, #11                         ; =0xb
	mov	w10, #5                         ; =0x5
	cmp	w8, #1
	csel	w0, w9, w10, eq
	b	LBB5_59
LBB5_6:
	add	x8, x0, #75, lsl #12            ; =307200
	add	x19, x8, #8
	mov	w21, #1                         ; =0x1
	strb	w21, [x20, #10]
	ldr	w1, [x0, #9616]
	cbz	w1, LBB5_39
; %bb.7:
	mov	w8, #0                          ; =0x0
	mov	w9, #12184                      ; =0x2f98
	add	x9, x0, x9
	mov	w10, #9360                      ; =0x2490
	add	x10, x0, x10
	mov	x11, x1
	b	LBB5_9
LBB5_8:                                 ;   in Loop: Header=BB5_9 Depth=1
	add	x9, x9, #1
	subs	x11, x11, #1
	b.eq	LBB5_12
LBB5_9:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x10], #4
	cmp	w12, #3
	b.ne	LBB5_8
; %bb.10:                               ;   in Loop: Header=BB5_9 Depth=1
	ldrb	w12, [x9]
	tbz	w12, #0, LBB5_14
; %bb.11:                               ;   in Loop: Header=BB5_9 Depth=1
	add	w8, w8, #1
	b	LBB5_8
LBB5_12:
	and	x9, x1, #0x7
	cmp	w1, #8
	b.hs	LBB5_15
; %bb.13:
	mov	x11, #0                         ; =0x0
	b	LBB5_34
LBB5_14:
	strb	wzr, [x20, #10]
	mov	w0, #1                          ; =0x1
	str	w0, [x20]
	mov	w8, #1                          ; =0x1
	b	LBB5_56
LBB5_15:
	mov	x10, #0                         ; =0x0
	mov	w11, #9624                      ; =0x2598
	add	x11, x0, x11
	and	x12, x1, #0xfffffff8
	neg	x12, x12
	mov	w13, #9388                      ; =0x24ac
	add	x13, x0, x13
	mov	w14, #33554432                  ; =0x2000000
	udiv	w14, w14, w8
	b	LBB5_17
LBB5_16:                                ;   in Loop: Header=BB5_17 Depth=1
	add	x13, x13, #32
	sub	x10, x10, #8
	add	x11, x11, #320
	cmp	x12, x10
	b.eq	LBB5_33
LBB5_17:                                ; =>This Inner Loop Header: Depth=1
	ldur	w15, [x13, #-28]
	str	w15, [x11]
	cmp	w15, #3
	b.ne	LBB5_19
; %bb.18:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #32]
LBB5_19:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-24]
	str	w15, [x11, #40]
	cmp	w15, #3
	b.ne	LBB5_21
; %bb.20:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #72]
LBB5_21:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-20]
	str	w15, [x11, #80]
	cmp	w15, #3
	b.ne	LBB5_23
; %bb.22:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #112]
LBB5_23:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-16]
	str	w15, [x11, #120]
	cmp	w15, #3
	b.ne	LBB5_25
; %bb.24:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #152]
LBB5_25:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-12]
	str	w15, [x11, #160]
	cmp	w15, #3
	b.ne	LBB5_27
; %bb.26:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #192]
LBB5_27:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-8]
	str	w15, [x11, #200]
	cmp	w15, #3
	b.ne	LBB5_29
; %bb.28:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #232]
LBB5_29:                                ;   in Loop: Header=BB5_17 Depth=1
	ldur	w15, [x13, #-4]
	str	w15, [x11, #240]
	cmp	w15, #3
	b.ne	LBB5_31
; %bb.30:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #272]
LBB5_31:                                ;   in Loop: Header=BB5_17 Depth=1
	ldr	w15, [x13]
	str	w15, [x11, #280]
	cmp	w15, #3
	b.ne	LBB5_16
; %bb.32:                               ;   in Loop: Header=BB5_17 Depth=1
	str	x14, [x11, #312]
	b	LBB5_16
LBB5_33:
	neg	x11, x10
LBB5_34:
	cbz	x9, LBB5_39
; %bb.35:
	mov	w10, #40                        ; =0x28
	madd	x10, x11, x10, x0
	mov	w12, #9656                      ; =0x25b8
	add	x10, x10, x12
	add	x11, x0, x11, lsl #2
	mov	w12, #9360                      ; =0x2490
	add	x11, x11, x12
	mov	w12, #33554432                  ; =0x2000000
	udiv	w8, w12, w8
	b	LBB5_37
LBB5_36:                                ;   in Loop: Header=BB5_37 Depth=1
	add	x10, x10, #40
	subs	x9, x9, #1
	b.eq	LBB5_39
LBB5_37:                                ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x11], #4
	stur	w12, [x10, #-32]
	cmp	w12, #3
	b.ne	LBB5_36
; %bb.38:                               ;   in Loop: Header=BB5_37 Depth=1
	str	x8, [x10]
	b	LBB5_36
LBB5_39:
	mov	w8, #9624                       ; =0x2598
	mov	x9, x0
	add	x0, x0, x8
	add	x2, x9, #75, lsl #12            ; =307200
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nl_services_values_create_config
	strb	wzr, [x20, #10]
	str	w21, [x20]
	cmp	w0, #2
	b.le	LBB5_44
; %bb.40:
	cmp	w0, #4
	b.gt	LBB5_48
; %bb.41:
	cmp	w0, #3
	b.eq	LBB5_53
; %bb.42:
	cmp	w0, #4
	b.ne	LBB5_52
; %bb.43:
	mov	w8, #8                          ; =0x8
	b	LBB5_56
LBB5_44:
	cbz	w0, LBB5_51
; %bb.45:
	cmp	w0, #1
	b.eq	LBB5_55
; %bb.46:
	cmp	w0, #2
	b.ne	LBB5_52
; %bb.47:
	mov	w8, #7                          ; =0x7
	b	LBB5_56
LBB5_48:
	cmp	w0, #5
	b.eq	LBB5_54
; %bb.49:
	cmp	w0, #6
	b.ne	LBB5_52
; %bb.50:
	mov	w8, #4                          ; =0x4
	b	LBB5_56
LBB5_51:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #11]
	strb	w8, [x19, #4]
	b	LBB5_59
LBB5_52:
	mov	w8, #5                          ; =0x5
	b	LBB5_56
LBB5_53:
	mov	w8, #6                          ; =0x6
	b	LBB5_56
LBB5_54:
	mov	w8, #3                          ; =0x3
	b	LBB5_56
LBB5_55:
	mov	x8, x0
LBB5_56:
	ldr	w9, [x19]
	cbnz	w9, LBB5_58
; %bb.57:
	str	w8, [x19]
	str	w0, [x19, #8]
LBB5_58:
	mov	x0, x8
LBB5_59:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_core
_fr_core:                               ; @fr_core
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	w1, #6
	b.hi	LBB6_3
; %bb.1:
	sub	w9, w1, #1
Lloh30:
	adrp	x10, l_switch.table.fr_core@PAGE
Lloh31:
	add	x10, x10, l_switch.table.fr_core@PAGEOFF
	ldr	w0, [x10, w9, uxtw #2]
	cbnz	x8, LBB6_4
LBB6_2:
	ret
LBB6_3:
	mov	w0, #5                          ; =0x5
	cbz	x8, LBB6_2
LBB6_4:
	add	x9, x8, #76, lsl #12            ; =311296
	ldr	w9, [x9, #2728]
	cmp	w9, #2
	b.eq	LBB6_2
; %bb.5:
	add	x8, x8, #75, lsl #12            ; =307200
	ldr	w9, [x8, #8]!
	cbnz	w9, LBB6_2
; %bb.6:
	str	w0, [x8]
	str	w1, [x8, #8]
	ret
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_site      ; -- Begin function nvm_services_runtime_site
	.p2align	2
_nvm_services_runtime_site:             ; @nvm_services_runtime_site
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_3
; %bb.1:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #688
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB7_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB7_9
LBB7_3:
	mov	w0, #1                          ; =0x1
	ret
LBB7_4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB7_8
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x19, x8, #4088
	ldr	w8, [x19, #16]
	cbnz	w8, LBB7_9
; %bb.6:
	ldrb	w8, [x20, #12]
	cmp	w8, #1
	b.ne	LBB7_10
; %bb.7:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #16]
	mov	w9, #8                          ; =0x8
	str	w9, [x19, #24]
	b	LBB7_9
LBB7_8:
	mov	w8, #5                          ; =0x5
LBB7_9:
	add	sp, sp, #688
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB7_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB7_16
; %bb.11:
	ldrh	w8, [x20, #8]
	cbz	x8, LBB7_15
; %bb.12:
	ldr	x9, [x19]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldr	w9, [x8]
	cmp	w9, w1
	b.ne	LBB7_15
; %bb.13:
	ldr	w9, [x8, #4]
	cmp	w9, w2
	b.ne	LBB7_15
; %bb.14:
	ldrb	w3, [x8, #34]
	b	LBB7_17
LBB7_15:
	mov	w9, #45072                      ; =0xb010
	movk	w9, #4, lsl #16
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #16]
	mov	w10, #8                         ; =0x8
	b	LBB7_21
LBB7_16:
	mov	w3, #0                          ; =0x0
LBB7_17:
	add	x4, sp, #88
	add	x5, sp, #8
	mov	x21, x0
	mov	x22, x1
	bl	_fr_instruction
	cbz	w0, LBB7_22
; %bb.18:
	ldrb	w8, [sp, #8]
	tbz	w8, #0, LBB7_22
; %bb.19:
	mov	w8, #0                          ; =0x0
	str	w22, [x19, #28]
	ldr	w10, [sp, #88]
	mov	w9, #45072                      ; =0xb010
	movk	w9, #4, lsl #16
	orr	x9, x9, #0x8
LBB7_20:
	mov	x0, x21
LBB7_21:
	str	w10, [x0, x9]
	b	LBB7_9
LBB7_22:
	ldr	w8, [x20]
	cmp	w8, #2
	b.ne	LBB7_24
; %bb.23:
	mov	w8, #1                          ; =0x1
	b	LBB7_9
LBB7_24:
	ldr	w9, [x19, #16]
	mov	w8, #1                          ; =0x1
	cbnz	w9, LBB7_9
; %bb.25:
	mov	w9, #45072                      ; =0xb010
	movk	w9, #4, lsl #16
	str	w8, [x19, #16]
	mov	w10, #1                         ; =0x1
	b	LBB7_20
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_instruction
_fr_instruction:                        ; @fr_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x5
	mov	x23, x0
	ldr	w8, [x0, #24]
	cbz	w8, LBB8_3
; %bb.1:
	mov	x20, x3
	cmp	w8, #2
	b.ne	LBB8_4
; %bb.2:
	ldr	x0, [x23, #16]
	mov	x22, x1
	mov	x21, x2
	mov	x3, x4
	bl	_nvm_services_indirect_hosted_instruction
	tbnz	w0, #0, LBB8_5
	b	LBB8_7
LBB8_3:
	ldr	x0, [x23]
	mov	x3, x4
	mov	x4, x19
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	b	_nvm_services_hosted_instruction
LBB8_4:
	ldr	x0, [x23, #8]
	mov	x22, x1
	mov	x21, x2
	mov	x3, x4
	bl	_nvm_services_cyclic_hosted_instruction
	cbz	w0, LBB8_10
LBB8_5:
	ldr	w8, [x23, #24]
	cmp	w8, #2
	b.ne	LBB8_8
; %bb.6:
	ldr	x0, [x23, #16]
	add	x4, sp, #8
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_nvm_services_indirect_hosted_variant
	tbnz	w0, #0, LBB8_9
LBB8_7:
	mov	w0, #0                          ; =0x0
	b	LBB8_10
LBB8_8:
	ldr	x0, [x23, #8]
	add	x4, sp, #8
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_nvm_services_cyclic_hosted_variant
	cbz	w0, LBB8_10
LBB8_9:
	ldur	q0, [sp, #44]
	ldur	q1, [sp, #60]
	ldur	q2, [sp, #76]
	stp	q1, q2, [x19, #32]
	ldur	q1, [sp, #92]
	str	q1, [x19, #64]
	ldur	q1, [sp, #28]
	stp	q1, q0, [x19]
	mov	w0, #1                          ; =0x1
LBB8_10:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_fail      ; -- Begin function nvm_services_runtime_fail
	.p2align	2
_nvm_services_runtime_fail:             ; @nvm_services_runtime_fail
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x9, x8, #2728
	ldrb	w8, [x9, #10]
	tbz	w8, #0, LBB9_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB9_3:
	mov	w0, #1                          ; =0x1
	ret
LBB9_4:
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB9_7
; %bb.5:
	add	x8, x0, #75, lsl #12            ; =307200
	ldr	w0, [x8, #8]!
	cbz	w0, LBB9_8
; %bb.6:
	ret
LBB9_7:
	mov	w0, #5                          ; =0x5
	ret
LBB9_8:
	ldrb	w9, [x9, #12]
	cmp	w9, #1
	b.ne	LBB9_10
; %bb.9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #8]
	ret
LBB9_10:
	sub	w9, w1, #11
	cmn	w9, #11
	b.hi	LBB9_12
; %bb.11:
	mov	w0, #1                          ; =0x1
	str	w0, [x8]
	str	w0, [x8, #8]
	ret
LBB9_12:
	str	w1, [x8]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #8]
	mov	x0, x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_current_root ; -- Begin function nvm_services_runtime_current_root
	.p2align	2
_nvm_services_runtime_current_root:     ; @nvm_services_runtime_current_root
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB10_7
; %bb.1:
	cbz	x1, LBB10_7
; %bb.2:
	add	x8, x8, #76, lsl #12            ; =311296
	ldr	w9, [x8, #2728]
	cmp	w9, #1
	b.ne	LBB10_5
; %bb.3:
	ldrb	w9, [x8, #2740]
	tbnz	w9, #0, LBB10_5
; %bb.4:
	ldrb	w9, [x8, #2738]
	tbz	w9, #0, LBB10_6
LBB10_5:
	mov	w0, #0                          ; =0x0
	ret
LBB10_6:
	ldr	w8, [x8, #2744]
	str	w8, [x1]
	mov	w0, #1                          ; =0x1
LBB10_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_view      ; -- Begin function nvm_services_runtime_view
	.p2align	2
_nvm_services_runtime_view:             ; @nvm_services_runtime_view
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB11_5
; %bb.1:
	cbz	x2, LBB11_5
; %bb.2:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB11_4
; %bb.3:
	add	x8, x0, #76, lsl #12            ; =311296
	ldrb	w8, [x8, #2738]
	tbz	w8, #0, LBB11_6
LBB11_4:
	mov	w8, #0                          ; =0x0
LBB11_5:
	mov	x0, x8
	ret
LBB11_6:
	add	x8, x0, #72, lsl #12            ; =294912
	ldr	x8, [x8, #12256]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x2, #32]
	stp	q0, q1, [x2]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x2, #112]
	stp	q1, q2, [x2, #80]
	str	q0, [x2, #64]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_scalar    ; -- Begin function nvm_services_runtime_scalar
	.p2align	2
_nvm_services_runtime_scalar:           ; @nvm_services_runtime_scalar
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w2 killed $w2 def $x2
	cbz	x0, LBB12_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x10, x8, #2728
	ldrb	w8, [x10, #10]
	tbz	w8, #0, LBB12_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB12_3:
	mov	w0, #1                          ; =0x1
	ret
LBB12_4:
	ldr	w8, [x10]
	cmp	w8, #1
	b.ne	LBB12_7
; %bb.5:
	mov	x9, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x8, x8, #4064
	ldr	w0, [x8, #40]
	cbz	w0, LBB12_8
; %bb.6:
	ret
LBB12_7:
	mov	w0, #5                          ; =0x5
	ret
LBB12_8:
	ldrb	w11, [x10, #12]
	tbz	w11, #0, LBB12_10
LBB12_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #48]
	ret
LBB12_10:
	ldr	w11, [x9, #24]
	cbz	w11, LBB12_12
; %bb.11:
	ldrb	w11, [x9, #57]
	tbz	w11, #0, LBB12_21
LBB12_12:
	ldr	w9, [x9, #128]
	cmp	w1, w9
	b.hs	LBB12_20
; %bb.13:
	ldr	x9, [x8]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	tbnz	w10, #0, LBB12_20
; %bb.14:
	cmp	w2, #4
	b.hi	LBB12_20
; %bb.15:
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w2
	mov	w11, #19                        ; =0x13
	tst	w10, w11
	b.eq	LBB12_20
; %bb.16:
	cmp	w2, #4
	b.ne	LBB12_18
; %bb.17:
	cmp	x3, #1
	b.hi	LBB12_20
LBB12_18:
	cbnz	w2, LBB12_24
; %bb.19:
	cbz	x3, LBB12_24
LBB12_20:
	mov	w0, #6                          ; =0x6
	str	w0, [x8, #40]
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #48]
	ret
LBB12_21:
	ldrh	w10, [x10, #8]
	cbz	x10, LBB12_9
; %bb.22:
	ldr	x11, [x8, #24]
	sub	w10, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldrb	w11, [x10, #32]
	tbnz	w11, #0, LBB12_9
; %bb.23:
	ldrb	w10, [x10, #33]
	tbz	w10, #0, LBB12_9
	b	LBB12_12
LBB12_24:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	orr	x8, x2, #0xffffffff00000000
	stur	x8, [x9, #4]
	cmp	w2, #0
	mov	w8, #-1                         ; =0xffffffff
	stur	x8, [x9, #12]
	cset	w8, ne
	str	wzr, [x9, #20]
	strb	w8, [x9, #24]
	stur	wzr, [x9, #25]
	str	wzr, [x9, #28]
	str	x3, [x9, #32]
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #40]
	stur	q0, [x9, #56]
	stur	q0, [x9, #72]
	stur	q0, [x9, #88]
	stur	q0, [x9, #104]
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_services_runtime_string
lCPI13_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_string
	.p2align	2
_nvm_services_runtime_string:           ; @nvm_services_runtime_string
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x9, x8, #2728
	ldrb	w8, [x9, #10]
	tbz	w8, #0, LBB13_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB13_3:
	mov	w0, #1                          ; =0x1
	ret
LBB13_4:
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB13_8
; %bb.5:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x8, x0, #74, lsl #12            ; =303104
	add	x22, x8, #4056
	ldr	w8, [x22, #48]
	cbnz	w8, LBB13_17
; %bb.6:
	ldrb	w8, [x9, #12]
	tbz	w8, #0, LBB13_9
LBB13_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x22, #48]
	mov	w9, #8                          ; =0x8
	b	LBB13_16
LBB13_8:
	mov	w0, #5                          ; =0x5
	ret
LBB13_9:
	ldr	w8, [x0, #24]
	cbz	w8, LBB13_11
; %bb.10:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB13_18
LBB13_11:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB13_15
; %bb.12:
	ldr	x8, [x22, #8]
	mov	w9, #176                        ; =0xb0
	umaddl	x23, w1, w9, x8
	ldrb	w8, [x23]
	tbnz	w8, #0, LBB13_15
; %bb.13:
	cbnz	x2, LBB13_21
; %bb.14:
	cbz	x3, LBB13_21
LBB13_15:
	mov	w8, #6                          ; =0x6
	str	w8, [x22, #48]
	mov	w9, #3                          ; =0x3
LBB13_16:
	str	w9, [x22, #56]
LBB13_17:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB13_18:
	ldrh	w8, [x9, #8]
	cbz	x8, LBB13_7
; %bb.19:
	ldr	x9, [x22, #32]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB13_7
; %bb.20:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB13_7
	b	LBB13_11
LBB13_21:
	cmp	x3, #256, lsl #12               ; =1048576
	b.hi	LBB13_36
; %bb.22:
	ldr	w24, [x22]
	mov	x25, x0
	cbz	w24, LBB13_29
; %bb.23:
	add	x8, x0, #66, lsl #12            ; =270336
	add	x19, x8, #4056
	mov	x20, x24
	b	LBB13_25
LBB13_24:                               ;   in Loop: Header=BB13_25 Depth=1
	subs	x20, x20, #1
	b.eq	LBB13_29
LBB13_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	x21, [x19], #8
	ldr	x8, [x21, #8]
	cmp	x8, x3
	b.ne	LBB13_24
; %bb.26:                               ;   in Loop: Header=BB13_25 Depth=1
	cbz	x3, LBB13_28
; %bb.27:                               ;   in Loop: Header=BB13_25 Depth=1
	add	x0, x21, #16
	mov	x1, x2
	mov	x26, x2
	mov	x2, x3
	mov	x27, x3
	bl	_memcmp
	mov	x2, x26
	mov	x3, x27
	mov	x8, x0
	mov	x0, x25
	cbnz	w8, LBB13_24
LBB13_28:
	ldr	w21, [x21]
	b	LBB13_35
LBB13_29:
	cmp	w24, #4095
	b.hi	LBB13_36
; %bb.30:
	ldr	x26, [x0, #120]
	mov	w8, #67108848                   ; =0x3fffff0
	sub	x8, x8, x26
	mov	w9, #67108848                   ; =0x3fffff0
	cmp	x26, x9
	ccmp	x3, x8, #2, ls
	b.hi	LBB13_36
; %bb.31:
	mov	x20, x2
	mov	x27, x3
	add	x21, x3, #16
	mov	w0, #1                          ; =0x1
	mov	x1, x21
	bl	_calloc
	cbz	x0, LBB13_37
; %bb.32:
	mov	x19, x0
	add	w8, w24, #1
	str	w8, [x22]
	add	x22, x21, x26
	mov	x21, x8
	str	w8, [x0]
	str	x27, [x0, #8]
	cbz	x27, LBB13_34
; %bb.33:
	mov	x2, x27
	add	x0, x19, #16
	mov	x1, x20
	bl	_memcpy
LBB13_34:
	add	x8, x25, x24, lsl #3
	mov	w9, #12248                      ; =0x2fd8
	movk	w9, #4, lsl #16
	str	x19, [x8, x9]
	str	x22, [x25, #120]
LBB13_35:
	mov	w8, #0                          ; =0x0
Lloh32:
	adrp	x9, lCPI13_0@PAGE
Lloh33:
	ldr	q0, [x9, lCPI13_0@PAGEOFF]
	mov	w9, #1                          ; =0x1
	str	w9, [x23]
	mov	w10, w21
	stur	q0, [x23, #4]
	str	wzr, [x23, #20]
	strb	w9, [x23, #24]
	stur	wzr, [x23, #25]
	str	wzr, [x23, #28]
	str	x10, [x23, #32]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	b	LBB13_17
LBB13_36:
	mov	w8, #3                          ; =0x3
	str	w8, [x22, #48]
	mov	w9, #5                          ; =0x5
	b	LBB13_16
LBB13_37:
	mov	w8, #4                          ; =0x4
	str	w8, [x22, #48]
	mov	w9, #6                          ; =0x6
	b	LBB13_16
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_string_read ; -- Begin function nvm_services_runtime_string_read
	.p2align	2
_nvm_services_runtime_string_read:      ; @nvm_services_runtime_string_read
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB14_21
; %bb.1:
	cbz	x4, LBB14_21
; %bb.2:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x8, x8, #2728
	ldrb	w9, [x8, #10]
	tbnz	w9, #0, LBB14_20
; %bb.3:
	ldr	w8, [x8]
	cmp	w8, #1
	b.ne	LBB14_20
; %bb.4:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x8, x8, #4056
	ldr	w9, [x8, #48]
	cbnz	w9, LBB14_20
; %bb.5:
	ldr	w9, [x0, #128]
	cmp	w1, w9
	b.hs	LBB14_20
; %bb.6:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x9, [x8, #8]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB14_18
; %bb.7:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB14_18
; %bb.8:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB14_18
; %bb.9:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB14_18
; %bb.10:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB14_18
; %bb.11:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB14_18
; %bb.12:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB14_18
; %bb.13:
	ldr	w8, [x8]
	cmp	x9, x8
	b.hi	LBB14_18
; %bb.14:
	str	x4, [sp, #8]                    ; 8-byte Folded Spill
	add	x8, x0, x9, lsl #3
	add	x9, x8, #64, lsl #12            ; =262144
	ldr	x8, [x9, #12240]
	cbz	x8, LBB14_19
; %bb.15:
	mov	x9, x8
	ldr	x8, [x8, #8]
	cmp	x3, x8
	b.lo	LBB14_18
; %bb.16:
	cbnz	x2, LBB14_22
; %bb.17:
	cbz	x8, LBB14_22
LBB14_18:
	mov	w8, #0                          ; =0x0
LBB14_19:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	mov	x0, x8
	ret
LBB14_20:
	mov	w8, #0                          ; =0x0
LBB14_21:
	mov	x0, x8
	ret
LBB14_22:
	cbz	x8, LBB14_24
; %bb.23:
	mov	x19, x9
	add	x1, x9, #16
	mov	x0, x2
	mov	x2, x8
	bl	_memcpy
	ldr	x8, [x19, #8]
LBB14_24:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	b	LBB14_19
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_string
_fr_string:                             ; @fr_string
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB15_9
; %bb.1:
	add	x8, x0, #74, lsl #12            ; =303104
	ldr	x9, [x8, #4064]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB15_9
; %bb.2:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB15_9
; %bb.3:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB15_9
; %bb.4:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB15_9
; %bb.5:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB15_9
; %bb.6:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB15_9
; %bb.7:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB15_9
; %bb.8:
	ldr	w8, [x8, #4056]
	cmp	x9, x8
	b.ls	LBB15_10
LBB15_9:
	mov	x0, #0                          ; =0x0
	ret
LBB15_10:
	add	x8, x0, x9, lsl #3
	add	x9, x8, #64, lsl #12            ; =262144
	ldr	x0, [x9, #12240]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_string_literal ; -- Begin function nvm_services_runtime_string_literal
	.p2align	2
_nvm_services_runtime_string_literal:   ; @nvm_services_runtime_string_literal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_3
; %bb.1:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	ldrb	w8, [x22, #10]
	tbz	w8, #0, LBB16_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB16_20
LBB16_3:
	mov	w0, #1                          ; =0x1
	ret
LBB16_4:
	ldr	w8, [x22]
	cmp	w8, #1
	b.ne	LBB16_14
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x21, x8, #4088
	ldr	w8, [x21, #16]
	cbnz	w8, LBB16_20
; %bb.6:
	ldrb	w8, [x22, #12]
	tbnz	w8, #0, LBB16_18
; %bb.7:
	ldr	w8, [x0, #24]
	cbz	w8, LBB16_18
; %bb.8:
	ldrb	w9, [x0, #57]
	tbz	w9, #0, LBB16_15
LBB16_9:
	cmp	w8, #2
	b.ne	LBB16_18
; %bb.10:
	ldrh	w8, [x22, #8]
	cbz	x8, LBB16_18
; %bb.11:
	mov	x19, x1
	ldr	x9, [x21]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldr	w1, [x8]
	ldrh	w2, [x8, #4]
	ldrb	w3, [x8, #34]
	add	x4, sp, #104
	add	x5, sp, #24
	mov	x20, x0
	bl	_fr_instruction
	ldrb	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, #4, #0, ne
	b.ne	LBB16_21
; %bb.12:
	ldr	x0, [x20, #16]
	ldr	w1, [sp, #120]
	add	x2, sp, #16
	add	x3, sp, #8
	bl	_nvm_services_indirect_hosted_string
	tbz	w0, #0, LBB16_21
; %bb.13:
	ldp	x3, x2, [sp, #8]
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_services_runtime_string
	mov	x8, x0
	b	LBB16_20
LBB16_14:
	mov	w8, #5                          ; =0x5
	b	LBB16_20
LBB16_15:
	ldrh	w9, [x22, #8]
	cbz	x9, LBB16_18
; %bb.16:
	ldr	x10, [x21]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB16_18
; %bb.17:
	ldrb	w9, [x9, #33]
	tbnz	w9, #0, LBB16_9
LBB16_18:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #16]
	mov	w9, #8                          ; =0x8
LBB16_19:
	str	w9, [x21, #24]
LBB16_20:
	add	sp, sp, #704
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB16_21:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB16_23
; %bb.22:
	mov	w8, #6                          ; =0x6
	b	LBB16_20
LBB16_23:
	ldr	w9, [x21, #16]
	mov	w8, #6                          ; =0x6
	cbnz	w9, LBB16_20
; %bb.24:
	str	w8, [x21, #16]
	mov	w9, #3                          ; =0x3
	b	LBB16_19
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_string_operation ; -- Begin function nvm_services_runtime_string_operation
	.p2align	2
_nvm_services_runtime_string_operation: ; @nvm_services_runtime_string_operation
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB17_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x9, x8, #2728
	ldrb	w8, [x9, #10]
	tbz	w8, #0, LBB17_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB17_51
LBB17_3:
	mov	w8, #1                          ; =0x1
	b	LBB17_51
LBB17_4:
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB17_8
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x19, x8, #4056
	ldr	w8, [x19, #48]
	cbnz	w8, LBB17_51
; %bb.6:
	ldrb	w8, [x9, #12]
	tbz	w8, #0, LBB17_9
LBB17_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #48]
	mov	w9, #8                          ; =0x8
	b	LBB17_50
LBB17_8:
	mov	w8, #5                          ; =0x5
	b	LBB17_51
LBB17_9:
	ldr	w8, [x0, #24]
	cbz	w8, LBB17_11
; %bb.10:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB17_31
LBB17_11:
	ldr	w8, [x0, #128]
	cmp	w2, w8
	b.hs	LBB17_20
; %bb.12:
	ldr	x9, [x19, #8]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w2, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB17_20
; %bb.13:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB17_20
; %bb.14:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB17_20
; %bb.15:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB17_20
; %bb.16:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB17_20
; %bb.17:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB17_20
; %bb.18:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB17_20
; %bb.19:
	ldr	w10, [x19]
	cmp	x9, x10
	b.ls	LBB17_39
LBB17_20:
	mov	x9, #0                          ; =0x0
	cmp	w1, #68
	b.ne	LBB17_40
LBB17_21:
	cmp	w3, w8
	b.hs	LBB17_27
; %bb.22:
	ldr	x10, [x19, #8]
	mov	w11, #176                       ; =0xb0
	umaddl	x11, w3, w11, x10
	ldrb	w10, [x11]
	cmp	w10, #1
	b.ne	LBB17_27
; %bb.23:
	ldrb	w10, [x11, #1]
	tbnz	w10, #0, LBB17_27
; %bb.24:
	ldrb	w10, [x11, #2]
	tbnz	w10, #0, LBB17_27
; %bb.25:
	ldrb	w10, [x11, #24]
	cmp	w10, #1
	b.ne	LBB17_27
; %bb.26:
	ldur	x10, [x11, #4]
	mov	x12, #-65531                    ; =0xffffffffffff0005
	movk	x12, #0, lsl #16
	eor	x12, x10, x12
	tst	x12, #0xff
	b.eq	LBB17_34
LBB17_27:
	mov	x10, #0                         ; =0x0
LBB17_28:
	cbz	x9, LBB17_49
; %bb.29:
	cmp	w2, w3
	b.eq	LBB17_49
; %bb.30:
	cbnz	x10, LBB17_43
	b	LBB17_49
LBB17_31:
	ldrh	w8, [x9, #8]
	cbz	x8, LBB17_7
; %bb.32:
	ldr	x9, [x19, #32]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB17_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB17_7
	b	LBB17_11
LBB17_34:
	mov	x10, #0                         ; =0x0
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	tst	x12, x13
	b.ne	LBB17_28
; %bb.35:
	ldur	x12, [x11, #12]
	mov	w13, #-1                        ; =0xffffffff
	cmp	x12, x13
	b.ne	LBB17_28
; %bb.36:
	ldr	x10, [x11, #32]
	cmp	x10, #1
	b.lt	LBB17_27
; %bb.37:
	ldr	w11, [x19]
	cmp	x10, x11
	b.hi	LBB17_27
; %bb.38:
	add	x10, x0, x10, lsl #3
	add	x11, x10, #64, lsl #12          ; =262144
	ldr	x10, [x11, #12240]
	b	LBB17_28
LBB17_39:
	add	x9, x0, x9, lsl #3
	add	x10, x9, #64, lsl #12           ; =262144
	ldr	x9, [x10, #12240]
	cmp	w1, #68
	b.eq	LBB17_21
LBB17_40:
	and	w10, w1, #0xfffffffb
	cmp	w10, #64
	b.ne	LBB17_49
; %bb.41:
	cbz	x9, LBB17_49
; %bb.42:
	mov	x10, #0                         ; =0x0
LBB17_43:
	cmp	w4, w2
	b.eq	LBB17_47
; %bb.44:
	cmp	w4, w3
	b.eq	LBB17_47
; %bb.45:
	cmp	w4, w8
	b.hs	LBB17_49
; %bb.46:
	ldr	x11, [x19, #8]
	mov	w12, #176                       ; =0xb0
	umull	x12, w4, w12
	ldrb	w11, [x11, x12]
	tbnz	w11, #0, LBB17_49
LBB17_47:
	cmp	w1, #64
	b.ne	LBB17_52
; %bb.48:
	cmn	w3, #1
	b.eq	LBB17_56
LBB17_49:
	mov	w8, #6                          ; =0x6
	str	w8, [x19, #48]
	mov	w9, #3                          ; =0x3
LBB17_50:
	str	w9, [x19, #56]
LBB17_51:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB17_52:
	ldr	x8, [x9, #8]
	ldr	x11, [x10, #8]
	cmp	x8, x11
	b.ne	LBB17_55
; %bb.53:
	cbz	x8, LBB17_59
; %bb.54:
	mov	x20, x0
	add	x0, x9, #16
	mov	x21, x1
	add	x1, x10, #16
	mov	x22, x2
	mov	x2, x8
	mov	x23, x4
	mov	x24, x3
	bl	_memcmp
	mov	x1, x21
	mov	x3, x24
	mov	x2, x22
	mov	x4, x23
	mov	x8, x0
	mov	x0, x20
	cmp	w8, #0
	cset	w8, eq
	b	LBB17_60
LBB17_55:
	mov	x8, #0                          ; =0x0
	b	LBB17_60
LBB17_56:
	cmp	w4, w2
	b.ne	LBB17_65
; %bb.57:
	ldr	x10, [x19, #8]
LBB17_58:
	ldr	x8, [x9, #8]
	mov	w9, #1                          ; =0x1
	b	LBB17_62
LBB17_59:
	mov	w8, #1                          ; =0x1
LBB17_60:
	ldr	x9, [x19, #8]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w2, w10, x9
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #144]
	stp	q0, q0, [x9, #112]
	stp	q0, q0, [x9, #80]
	stp	q0, q0, [x9, #48]
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	cmp	w1, #68
	b.ne	LBB17_63
; %bb.61:
	ldr	x10, [x19, #8]
	mov	w9, #4                          ; =0x4
	mov	x2, x3
LBB17_62:
	mov	w11, #176                       ; =0xb0
	umaddl	x10, w2, w11, x10
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #144]
	stp	q0, q0, [x10, #112]
	stp	q0, q0, [x10, #80]
	stp	q0, q0, [x10, #48]
	stp	q0, q0, [x10, #16]
	str	q0, [x10]
	b	LBB17_64
LBB17_63:
	mov	w9, #4                          ; =0x4
LBB17_64:
	mov	x1, x4
	mov	x2, x9
	mov	x3, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	b	_nvm_services_runtime_scalar
LBB17_65:
	cmp	w4, w8
	b.hs	LBB17_49
; %bb.66:
	ldr	x10, [x19, #8]
	mov	w8, #176                        ; =0xb0
	umull	x8, w4, w8
	ldrb	w8, [x10, x8]
	cmp	w8, #1
	b.eq	LBB17_49
	b	LBB17_58
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_copy      ; -- Begin function nvm_services_runtime_copy
	.p2align	2
_nvm_services_runtime_copy:             ; @nvm_services_runtime_copy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x10, x8, #2728
	ldrb	w8, [x10, #10]
	tbz	w8, #0, LBB18_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB18_3:
	mov	w0, #1                          ; =0x1
	ret
LBB18_4:
	ldr	w8, [x10]
	cmp	w8, #1
	b.ne	LBB18_7
; %bb.5:
	mov	x9, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x8, x8, #4064
	ldr	w0, [x8, #40]
	cbz	w0, LBB18_8
; %bb.6:
	ret
LBB18_7:
	mov	w0, #5                          ; =0x5
	ret
LBB18_8:
	ldrb	w11, [x10, #12]
	tbz	w11, #0, LBB18_10
LBB18_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #48]
	ret
LBB18_10:
	ldr	w11, [x9, #24]
	cbz	w11, LBB18_12
; %bb.11:
	ldrb	w11, [x9, #57]
	tbz	w11, #0, LBB18_19
LBB18_12:
	ldr	w9, [x9, #128]
	cmp	w1, w9
	b.hs	LBB18_18
; %bb.13:
	cmp	w2, w9
	b.hs	LBB18_18
; %bb.14:
	ldr	x10, [x8]
	mov	w9, #176                        ; =0xb0
	umaddl	x9, w1, w9, x10
	ldrb	w11, [x9]
	tbz	w11, #0, LBB18_18
; %bb.15:
	mov	w11, #176                       ; =0xb0
	umaddl	x10, w2, w11, x10
	ldrb	w11, [x10]
	tbnz	w11, #0, LBB18_18
; %bb.16:
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB18_18
; %bb.17:
	ldrb	w11, [x9, #2]
	cmp	w11, #1
	b.ne	LBB18_22
LBB18_18:
	mov	w0, #6                          ; =0x6
	str	w0, [x8, #40]
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #48]
	ret
LBB18_19:
	ldrh	w10, [x10, #8]
	cbz	x10, LBB18_9
; %bb.20:
	ldr	x11, [x8, #24]
	sub	w10, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldrb	w11, [x10, #32]
	tbnz	w11, #0, LBB18_9
; %bb.21:
	ldrb	w10, [x10, #33]
	tbz	w10, #0, LBB18_9
	b	LBB18_12
LBB18_22:
	mov	w0, #0                          ; =0x0
	ldp	q0, q1, [x9]
	ldr	q2, [x9, #32]
	stp	q1, q2, [x10, #16]
	str	q0, [x10]
	ldp	q0, q1, [x9, #48]
	ldp	q2, q3, [x9, #80]
	stp	q2, q3, [x10, #80]
	stp	q0, q1, [x10, #48]
	ldp	q0, q1, [x9, #112]
	ldp	q2, q3, [x9, #144]
	stp	q2, q3, [x10, #144]
	stp	q0, q1, [x10, #112]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_move      ; -- Begin function nvm_services_runtime_move
	.p2align	2
_nvm_services_runtime_move:             ; @nvm_services_runtime_move
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB19_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB19_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB19_9
LBB19_3:
	mov	w8, #1                          ; =0x1
	b	LBB19_9
LBB19_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB19_8
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4064
	ldr	w8, [x20, #40]
	cbnz	w8, LBB19_9
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB19_10
LBB19_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x20, #48]
	b	LBB19_9
LBB19_8:
	mov	w8, #5                          ; =0x5
LBB19_9:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB19_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB19_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB19_18
LBB19_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB19_17
; %bb.13:
	cmp	w2, w8
	b.hs	LBB19_17
; %bb.14:
	ldr	x9, [x20]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x9
	ldrb	w10, [x8]
	tbz	w10, #0, LBB19_17
; %bb.15:
	mov	w10, #176                       ; =0xb0
	umull	x10, w2, w10
	ldrb	w10, [x9, x10]
	tbnz	w10, #0, LBB19_17
; %bb.16:
	ldrb	w10, [x8, #2]
	cmp	w10, #1
	b.ne	LBB19_21
LBB19_17:
	mov	w8, #6                          ; =0x6
	str	w8, [x20, #40]
	mov	w9, #3                          ; =0x3
	str	w9, [x20, #48]
	b	LBB19_9
LBB19_18:
	ldrh	w8, [x21, #8]
	cbz	x8, LBB19_7
; %bb.19:
	ldr	x9, [x20, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB19_7
; %bb.20:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB19_7
	b	LBB19_12
LBB19_21:
	mov	w22, w1
	mov	w23, w2
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB19_25
; %bb.22:
	mov	x19, x0
	strb	w8, [x21, #10]
	ldr	x0, [x20, #32]
	mov	w8, #176                        ; =0xb0
	umaddl	x10, w22, w8, x9
	umaddl	x8, w23, w8, x9
	add	x1, x10, #120
	add	x2, x8, #120
	bl	_nl_services_value_move
	strb	wzr, [x21, #10]
	cbz	w0, LBB19_24
; %bb.23:
	mov	x1, x0
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	b	_fr_core
LBB19_24:
	ldr	x9, [x20]
LBB19_25:
	mov	w8, #0                          ; =0x0
	mov	w10, #176                       ; =0xb0
	umaddl	x11, w23, w10, x9
	umaddl	x9, w22, w10, x9
	ldp	q0, q1, [x9]
	ldp	q2, q3, [x9, #32]
	stp	q2, q3, [x11, #32]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x9, #64]
	ldr	q2, [x9, #96]
	ldr	x9, [x9, #112]
	str	x9, [x11, #112]
	stp	q1, q2, [x11, #80]
	str	q0, [x11, #64]
	ldr	x9, [x20]
	umaddl	x11, w22, w10, x9
	ldr	x12, [x11, #160]
	umaddl	x9, w23, w10, x9
	str	x12, [x9, #160]
	ldr	w10, [x11, #168]
	str	w10, [x9, #168]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x11, #96]
	stp	q0, q0, [x11, #64]
	stp	q0, q0, [x11, #32]
	stp	q0, q0, [x11]
	stp	q0, q0, [x11, #128]
	str	q0, [x11, #160]
	b	LBB19_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_drop      ; -- Begin function nvm_services_runtime_drop
	.p2align	2
_nvm_services_runtime_drop:             ; @nvm_services_runtime_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB20_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB20_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB20_9
LBB20_3:
	mov	w0, #1                          ; =0x1
	ret
LBB20_4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB20_8
; %bb.5:
	mov	x8, x0
	add	x9, x0, #74, lsl #12            ; =303104
	add	x19, x9, #4064
	ldr	w0, [x19, #40]
	cbnz	w0, LBB20_9
; %bb.6:
	ldrb	w9, [x20, #12]
	tbz	w9, #0, LBB20_10
LBB20_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x19, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x19, #48]
	b	LBB20_9
LBB20_8:
	mov	w0, #5                          ; =0x5
LBB20_9:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB20_10:
	ldr	w9, [x8, #24]
	cbz	w9, LBB20_12
; %bb.11:
	ldrb	w9, [x8, #57]
	tbz	w9, #0, LBB20_16
LBB20_12:
	ldr	w8, [x8, #128]
	cmp	w1, w8
	b.hs	LBB20_15
; %bb.13:
	ldr	x8, [x19]
	mov	w9, #176                        ; =0xb0
	umaddl	x9, w1, w9, x8
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB20_15
; %bb.14:
	ldrb	w10, [x9, #2]
	cmp	w10, #1
	b.ne	LBB20_19
LBB20_15:
	mov	w0, #6                          ; =0x6
	str	w0, [x19, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #48]
	b	LBB20_9
LBB20_16:
	ldrh	w9, [x20, #8]
	cbz	x9, LBB20_7
; %bb.17:
	ldr	x10, [x19, #24]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB20_7
; %bb.18:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB20_7
	b	LBB20_12
LBB20_19:
	mov	w21, w1
	ldrb	w9, [x9, #1]
	cmp	w9, #1
	b.ne	LBB20_33
; %bb.20:
	strb	w9, [x20, #10]
	ldr	x0, [x19, #32]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w21, w9, x8
	add	x1, x8, #120
	bl	_nl_services_value_drop
	mov	x8, x0
	strb	wzr, [x20, #10]
	cmp	w0, #2
	b.le	LBB20_25
; %bb.21:
	cmp	w8, #4
	b.gt	LBB20_29
; %bb.22:
	cmp	w8, #3
	b.eq	LBB20_35
; %bb.23:
	cmp	w8, #4
	b.ne	LBB20_34
; %bb.24:
	mov	w0, #8                          ; =0x8
	b	LBB20_37
LBB20_25:
	cbz	w8, LBB20_32
; %bb.26:
	mov	x0, x8
	cmp	w8, #1
	b.eq	LBB20_37
; %bb.27:
	cmp	w8, #2
	b.ne	LBB20_34
; %bb.28:
	mov	w0, #7                          ; =0x7
	b	LBB20_37
LBB20_29:
	cmp	w8, #5
	b.eq	LBB20_36
; %bb.30:
	cmp	w8, #6
	b.ne	LBB20_34
; %bb.31:
	mov	w0, #4                          ; =0x4
	b	LBB20_37
LBB20_32:
	ldr	x8, [x19]
LBB20_33:
	mov	w0, #0                          ; =0x0
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w21, w9, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	b	LBB20_9
LBB20_34:
	mov	w0, #5                          ; =0x5
	b	LBB20_37
LBB20_35:
	mov	w0, #6                          ; =0x6
	b	LBB20_37
LBB20_36:
	mov	w0, #3                          ; =0x3
LBB20_37:
	ldr	w9, [x20]
	cmp	w9, #2
	b.eq	LBB20_9
; %bb.38:
	ldr	w9, [x19, #40]
	cbnz	w9, LBB20_9
; %bb.39:
	str	w0, [x19, #40]
	str	w8, [x19, #48]
	b	LBB20_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_construct ; -- Begin function nvm_services_runtime_construct
	.p2align	2
_nvm_services_runtime_construct:        ; @nvm_services_runtime_construct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #304]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #320]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #336]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh34:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh35:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh36:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB21_66
; %bb.1:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	ldrb	w8, [x22, #10]
	tbz	w8, #0, LBB21_3
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB21_67
LBB21_3:
	ldr	w8, [x22]
	cmp	w8, #1
	b.ne	LBB21_7
; %bb.4:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x21, x8, #4064
	ldr	w0, [x21, #40]
	cbnz	w0, LBB21_67
; %bb.5:
	ldrb	w8, [x22, #12]
	tbz	w8, #0, LBB21_8
LBB21_6:
	mov	w0, #5                          ; =0x5
	str	w0, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
	b	LBB21_67
LBB21_7:
	mov	w0, #5                          ; =0x5
	b	LBB21_67
LBB21_8:
	ldr	w8, [x19, #24]
	cbz	w8, LBB21_10
; %bb.9:
	ldrb	w8, [x19, #57]
	tbz	w8, #0, LBB21_18
LBB21_10:
	ldr	w8, [x19, #9616]
	add	w8, w8, w8, lsl #3
	cmp	w1, w8
	b.hs	LBB21_16
; %bb.11:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x8, x8, #33
	add	w9, w8, w8, lsl #3
	sub	w0, w1, w9
	add	x8, x19, x8, lsl #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	w9, w9, ne
	cmp	w8, #2
	ccmp	w9, w0, #2, ne
	b.ls	LBB21_16
; %bb.12:
	cmp	x4, #11
	b.hi	LBB21_16
; %bb.13:
	ldr	w9, [x19, #128]
	cmp	w5, w9
	b.hs	LBB21_16
; %bb.14:
	cbnz	x3, LBB21_21
; %bb.15:
	cbz	x4, LBB21_21
LBB21_16:
	mov	w0, #1                          ; =0x1
LBB21_17:
	str	w0, [x21, #40]
	str	w0, [x21, #48]
	b	LBB21_67
LBB21_18:
	ldrh	w8, [x22, #8]
	cbz	x8, LBB21_6
; %bb.19:
	ldr	x9, [x21, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB21_6
; %bb.20:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB21_6
	b	LBB21_10
LBB21_21:
	add	x9, x19, w1, uxtw #4
	ldp	x27, x28, [x9, #144]
	cmp	w8, #3
	mov	x25, x4
	mov	x24, x3
	str	w5, [sp, #44]                   ; 4-byte Folded Spill
	mov	x23, x2
	mov	x20, x1
	b.eq	LBB21_24
; %bb.22:
	cmp	w8, #2
	b.ne	LBB21_25
; %bb.23:
	bl	_nl_socket_catalog_type
	b	LBB21_26
LBB21_24:
	bl	_nl_websocket_catalog_type
	b	LBB21_26
LBB21_25:
	bl	_nl_file_catalog_type
LBB21_26:
	cbz	x0, LBB21_61
; %bb.27:
	lsr	x26, x28, #32
	sub	x10, x26, #5
	cmn	x10, #2
	b.lo	LBB21_61
; %bb.28:
	mov	x9, x25
	mov	x8, x23
	cmp	x26, #4
	b.ne	LBB21_31
; %bb.29:
	cbnz	w8, LBB21_61
; %bb.30:
	ldr	x10, [x0, #32]
	b	LBB21_33
LBB21_31:
	ldr	x10, [x0, #32]
	cmp	x10, w8, uxtw
	b.ls	LBB21_61
; %bb.32:
	mov	w10, #1                         ; =0x1
LBB21_33:
	cmp	x9, x10
	b.ne	LBB21_61
; %bb.34:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	str	xzr, [sp, #176]
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #112]
	str	q0, [sp, #96]
	mov	w10, #1                         ; =0x1
	strb	w10, [sp, #64]
	stur	x27, [sp, #68]
	stur	x28, [sp, #76]
	cmp	x26, #4
	b.eq	LBB21_36
; %bb.35:
	cmp	w8, #0
	mov	w10, #2                         ; =0x2
	cinc	w10, w10, ne
	str	w10, [sp, #84]
LBB21_36:
	cbz	x9, LBB21_59
; %bb.37:
	mov	w9, #0                          ; =0x0
	mov	x27, #0                         ; =0x0
	add	x10, sp, #64
	add	x10, x10, #32
	str	x10, [sp]                       ; 8-byte Folded Spill
	mov	w8, w8
	stp	x8, x0, [sp, #8]                ; 16-byte Folded Spill
	mov	x10, x24
LBB21_38:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB21_40 Depth 2
	str	w9, [sp, #40]                   ; 4-byte Folded Spill
	cbz	x27, LBB21_42
; %bb.39:                               ;   in Loop: Header=BB21_38 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	w8, [x10, x27, lsl #2]
LBB21_40:                               ;   Parent Loop BB21_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w11, [x10, x9, lsl #2]
	cmp	x11, x8
	b.eq	LBB21_65
; %bb.41:                               ;   in Loop: Header=BB21_40 Depth=2
	add	x9, x9, #1
	cmp	x27, x9
	b.ne	LBB21_40
	b	LBB21_43
LBB21_42:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	w8, [x10]
LBB21_43:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	w9, [x19, #128]
	cmp	x8, x9
	b.hs	LBB21_61
; %bb.44:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	x9, [x21]
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8]
	tbz	w9, #0, LBB21_61
; %bb.45:                               ;   in Loop: Header=BB21_38 Depth=1
	ldrb	w9, [x8, #1]
	ldur	x23, [x8, #4]
	ldur	x28, [x8, #12]
	ldrb	w10, [x8, #24]
	str	w10, [sp, #36]                  ; 4-byte Folded Spill
	ldr	x10, [x8, #32]
	str	x10, [sp, #24]                  ; 8-byte Folded Spill
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [x29, #-144]
	ldur	q1, [x8, #104]
	stur	q1, [x29, #-112]
	ldur	q1, [x8, #40]
	stp	q1, q0, [x29, #-176]
	tbnz	w9, #0, LBB21_70
; %bb.46:                               ;   in Loop: Header=BB21_38 Depth=1
	ldrb	w8, [x8, #2]
	tbnz	w8, #0, LBB21_70
; %bb.47:                               ;   in Loop: Header=BB21_38 Depth=1
	ldp	x9, x8, [sp, #8]                ; 16-byte Folded Reload
	ldr	x8, [x8, #24]
	cmp	x26, #4
	csel	x9, x27, x9, eq
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #48
	mov	x0, x19
	mov	x1, x20
	bl	_fr_member
	cbz	w0, LBB21_70
; %bb.48:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	x8, [sp, #48]
	eor	x8, x8, x23
	tst	x8, #0xff
	b.ne	LBB21_70
; %bb.49:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	x9, [sp, #56]
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	and	x8, x8, x10
	cmp	x8, #0
	ccmp	x28, x9, #0, eq
	b.ne	LBB21_70
; %bb.50:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	w1, [x24, x27, lsl #2]
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	cmp	w1, w8
	cset	w28, eq
	cmp	x26, #4
	b.ne	LBB21_56
; %bb.51:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB21_70
; %bb.52:                               ;   in Loop: Header=BB21_38 Depth=1
	and	w8, w23, #0xff
	mov	w9, #251                        ; =0xfb
	and	w9, w23, w9
	cmp	w9, #1
	ccmp	w8, #4, #4, ne
	b.ne	LBB21_70
; %bb.53:                               ;   in Loop: Header=BB21_38 Depth=1
	cmp	w8, #5
	b.ne	LBB21_55
; %bb.54:                               ;   in Loop: Header=BB21_38 Depth=1
	mov	x0, x19
	bl	_fr_string
	cbz	x0, LBB21_70
LBB21_55:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	str	x9, [x8, x27, lsl #3]
	mov	x8, x25
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB21_57
LBB21_56:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #96]
	ldp	q1, q0, [x29, #-176]
	add	x8, sp, #64
	stur	q0, [x8, #56]
	ldp	q0, q2, [x29, #-144]
	stur	q0, [x8, #72]
	stur	q2, [x8, #88]
	ldur	q0, [x29, #-112]
	stur	q0, [x8, #104]
	stur	q1, [x8, #40]
	mov	x8, x25
LBB21_57:                               ;   in Loop: Header=BB21_38 Depth=1
	ldr	w9, [sp, #40]                   ; 4-byte Folded Reload
	orr	w9, w9, w28
	add	x27, x27, #1
	cmp	x27, x8
	mov	x10, x24
	b.ne	LBB21_38
; %bb.58:
	ldr	w10, [sp, #36]                  ; 4-byte Folded Reload
	strb	w10, [sp, #88]
	tbnz	w9, #0, LBB21_74
LBB21_59:
	ldr	w9, [x19, #128]
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	cmp	w8, w9
	b.hs	LBB21_61
; %bb.60:
	ldr	x9, [x21]
	mov	w10, #176                       ; =0xb0
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	cmp	w8, #1
	b.ne	LBB21_73
LBB21_61:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB21_63
LBB21_62:
	mov	w0, #6                          ; =0x6
	b	LBB21_67
LBB21_63:
	ldr	w8, [x21, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB21_67
; %bb.64:
	str	w0, [x21, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #48]
	b	LBB21_67
LBB21_65:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB21_69
LBB21_66:
	mov	w0, #1                          ; =0x1
LBB21_67:
	ldur	x8, [x29, #-96]
Lloh37:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh38:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh39:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB21_76
; %bb.68:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #352]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #336]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #320]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
LBB21_69:
	ldr	w8, [x21, #40]
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB21_67
	b	LBB21_17
LBB21_70:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB21_62
; %bb.71:
	ldr	w8, [x21, #40]
	cbnz	w8, LBB21_62
; %bb.72:
	mov	w8, #6                          ; =0x6
	str	w8, [x21, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #48]
	b	LBB21_62
LBB21_73:
	mov	x8, x25
	cbz	x25, LBB21_75
LBB21_74:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x24], #4
	ldr	x10, [x21]
	mov	w11, #176                       ; =0xb0
	umaddl	x9, w9, w11, x10
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #144]
	stp	q0, q0, [x9, #112]
	stp	q0, q0, [x9, #80]
	stp	q0, q0, [x9, #48]
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	subs	x8, x8, #1
	b.ne	LBB21_74
LBB21_75:
	mov	w0, #0                          ; =0x0
	ldr	x9, [x21]
	mov	w10, #176                       ; =0xb0
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	umaddl	x8, w8, w10, x9
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #160]
	str	q0, [x8, #96]
	ldr	x9, [sp, #176]
	str	x9, [x8, #112]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x8]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x8, #32]
	b	LBB21_67
LBB21_76:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh34, Lloh35, Lloh36
	.loh AdrpLdrGotLdr	Lloh37, Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function fr_member
lCPI22_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
lCPI22_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI22_2:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI22_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_fr_member:                             ; @fr_member
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x3
	cbz	x2, LBB22_16
; %bb.1:
	mov	x20, x2
	mov	x22, x1
	mov	x21, x0
Lloh40:
	adrp	x1, l_.str@PAGE
Lloh41:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x2
	bl	_strcmp
	cbz	w0, LBB22_17
; %bb.2:
Lloh42:
	adrp	x1, l_.str.1@PAGE
Lloh43:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB22_18
; %bb.3:
Lloh44:
	adrp	x1, l_.str.2@PAGE
Lloh45:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x20
	bl	_strcmp
	cbz	w0, LBB22_20
; %bb.4:
	mov	w23, #36409                     ; =0x8e39
	movk	w23, #14563, lsl #16
	umull	x8, w22, w23
	lsr	x22, x8, #33
	add	w24, w22, w22, lsl #3
	mov	w8, #9360                       ; =0x2490
	add	x25, x21, x8
	ldr	w8, [x25, x22, lsl #2]
	cmp	w8, #3
	mov	w26, #7                         ; =0x7
	cinc	w9, w26, ne
	mov	w27, #9                         ; =0x9
	cmp	w8, #2
	csel	w8, w27, w9, eq
	add	w8, w8, w24
	cmp	w24, w8
	b.hs	LBB22_19
; %bb.5:
	mov	x28, x24
	b	LBB22_7
LBB22_6:                                ;   in Loop: Header=BB22_7 Depth=1
	add	w28, w28, #1
	ldr	w8, [x25, x22, lsl #2]
	cmp	w8, #3
	cinc	w9, w26, ne
	cmp	w8, #2
	csel	w8, w27, w9, eq
	add	w8, w8, w24
	cmp	w28, w8
	b.hs	LBB22_19
LBB22_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #9616]
	add	w8, w8, w8, lsl #3
	cmp	w28, w8
	b.hs	LBB22_6
; %bb.8:                                ;   in Loop: Header=BB22_7 Depth=1
	umull	x8, w28, w23
	lsr	x8, x8, #33
	add	w9, w8, w8, lsl #3
	neg	w9, w9
	add	w0, w28, w9
	ldr	w8, [x25, x8, lsl #2]
	cmp	w8, #3
	cinc	w9, w26, ne
	cmp	w8, #2
	ccmp	w9, w0, #2, ne
	b.ls	LBB22_6
; %bb.9:                                ;   in Loop: Header=BB22_7 Depth=1
	cmp	w8, #3
	b.eq	LBB22_12
; %bb.10:                               ;   in Loop: Header=BB22_7 Depth=1
	cmp	w8, #2
	b.ne	LBB22_13
; %bb.11:                               ;   in Loop: Header=BB22_7 Depth=1
	bl	_nl_socket_catalog_type
	cbnz	x0, LBB22_14
	b	LBB22_6
LBB22_12:                               ;   in Loop: Header=BB22_7 Depth=1
	bl	_nl_websocket_catalog_type
	cbnz	x0, LBB22_14
	b	LBB22_6
LBB22_13:                               ;   in Loop: Header=BB22_7 Depth=1
	bl	_nl_file_catalog_type
	cbz	x0, LBB22_6
LBB22_14:                               ;   in Loop: Header=BB22_7 Depth=1
	ldr	x0, [x0]
	mov	x1, x20
	bl	_strcmp
	cbnz	w0, LBB22_6
; %bb.15:
	add	x8, x21, w28, uxtw #4
	ldr	q0, [x8, #144]
	b	LBB22_21
LBB22_16:
Lloh46:
	adrp	x8, lCPI22_3@PAGE
Lloh47:
	ldr	q0, [x8, lCPI22_3@PAGEOFF]
	b	LBB22_21
LBB22_17:
Lloh48:
	adrp	x8, lCPI22_2@PAGE
Lloh49:
	ldr	q0, [x8, lCPI22_2@PAGEOFF]
	b	LBB22_21
LBB22_18:
Lloh50:
	adrp	x8, lCPI22_1@PAGE
Lloh51:
	ldr	q0, [x8, lCPI22_1@PAGEOFF]
	b	LBB22_21
LBB22_19:
	mov	w0, #0                          ; =0x0
	b	LBB22_22
LBB22_20:
Lloh52:
	adrp	x8, lCPI22_0@PAGE
Lloh53:
	ldr	q0, [x8, lCPI22_0@PAGEOFF]
LBB22_21:
	str	q0, [x19]
	mov	w0, #1                          ; =0x1
LBB22_22:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_project   ; -- Begin function nvm_services_runtime_project
	.p2align	2
_nvm_services_runtime_project:          ; @nvm_services_runtime_project
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x26, x25, [sp, #240]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #256]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh54:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh55:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh56:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	cbz	x0, LBB23_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	ldrb	w8, [x22, #10]
	tbz	w8, #0, LBB23_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB23_9
LBB23_3:
	mov	w0, #1                          ; =0x1
	b	LBB23_9
LBB23_4:
	ldr	w8, [x22]
	cmp	w8, #1
	b.ne	LBB23_8
; %bb.5:
	mov	x20, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x21, x8, #4064
	ldr	w0, [x21, #40]
	cbnz	w0, LBB23_9
; %bb.6:
	ldrb	w8, [x22, #12]
	tbz	w8, #0, LBB23_11
LBB23_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
	b	LBB23_9
LBB23_8:
	mov	w0, #5                          ; =0x5
LBB23_9:
	ldur	x8, [x29, #-72]
Lloh57:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh58:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh59:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB23_47
; %bb.10:
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #272]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #256]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
LBB23_11:
	ldr	w8, [x20, #24]
	cbz	w8, LBB23_13
; %bb.12:
	ldrb	w8, [x20, #57]
	tbz	w8, #0, LBB23_23
LBB23_13:
	ldr	w10, [x20, #128]
	cmp	w1, w10
	b.hs	LBB23_28
; %bb.14:
	ldr	x9, [x21]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x9
	ldrb	w11, [x8]
	cmp	w11, #1
	b.ne	LBB23_28
; %bb.15:
	cmp	w1, w3
	b.ne	LBB23_26
LBB23_16:
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [sp, #80]
	ldr	q0, [x8, #96]
	str	q0, [sp, #112]
	ldr	x9, [x8, #112]
	str	x9, [sp, #128]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [sp, #48]
	ldrb	w8, [sp, #17]
	tbnz	w8, #0, LBB23_28
; %bb.17:
	ldrb	w8, [sp, #18]
	tbnz	w8, #0, LBB23_28
; %bb.18:
	ldr	w19, [sp, #28]
	ldr	w8, [x20, #9616]
	add	w8, w8, w8, lsl #3
	cmp	w19, w8
	b.hs	LBB23_28
; %bb.19:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w19, w8
	lsr	x8, x8, #33
	add	w9, w8, w8, lsl #3
	sub	w0, w19, w9
	add	x8, x20, x8, lsl #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	w9, w9, ne
	cmp	w8, #2
	ccmp	w9, w0, #2, ne
	b.ls	LBB23_28
; %bb.20:
	mov	x25, x2
	mov	x24, x1
	mov	x23, x3
	cmp	w8, #3
	b.eq	LBB23_30
; %bb.21:
	cmp	w8, #2
	b.ne	LBB23_31
; %bb.22:
	bl	_nl_socket_catalog_type
	b	LBB23_32
LBB23_23:
	ldrh	w8, [x22, #8]
	cbz	x8, LBB23_7
; %bb.24:
	ldr	x9, [x21, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB23_7
; %bb.25:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB23_7
	b	LBB23_13
LBB23_26:
	cmp	w3, w10
	b.hs	LBB23_28
; %bb.27:
	mov	w10, #176                       ; =0xb0
	umull	x10, w3, w10
	ldrb	w9, [x9, x10]
	cmp	w9, #1
	b.ne	LBB23_16
LBB23_28:
	mov	w0, #6                          ; =0x6
LBB23_29:
	str	w0, [x21, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #48]
	b	LBB23_9
LBB23_30:
	bl	_nl_websocket_catalog_type
	b	LBB23_32
LBB23_31:
	bl	_nl_file_catalog_type
LBB23_32:
	ldr	w8, [sp, #32]
	cmp	w8, #4
	b.ne	LBB23_37
; %bb.33:
	cbz	x0, LBB23_44
; %bb.34:
	mov	w8, w25
	ldr	x9, [x0, #32]
	ldrb	w10, [sp, #40]
	cmp	x9, x8
	ccmp	w25, w10, #2, hi
	b.hs	LBB23_44
; %bb.35:
	ldr	x9, [x0, #24]
	add	x9, x9, x8, lsl #5
	ldr	x2, [x9, #16]
	mov	x3, sp
	mov	x0, x20
	mov	x1, x19
	mov	x19, x8
	bl	_fr_member
	tbz	w0, #0, LBB23_44
; %bb.36:
	ldp	x8, x9, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #176]
	str	q0, [sp, #208]
	add	x11, sp, #16
	add	x10, x11, x19, lsl #3
	ldr	x10, [x10, #32]
	mov	w11, #1                         ; =0x1
	b	LBB23_43
LBB23_37:
	cbnz	w25, LBB23_44
; %bb.38:
	cmp	w8, #3
	b.ne	LBB23_44
; %bb.39:
	ldr	w8, [sp, #36]
	and	w9, w8, #0xfffffffe
	cmp	w9, #2
	b.ne	LBB23_44
; %bb.40:
	cbz	x0, LBB23_44
; %bb.41:
	cmp	w8, #3
	cset	w8, eq
	ldr	x9, [x0, #24]
	add	x8, x9, x8, lsl #5
	ldr	x2, [x8, #16]
	mov	x3, sp
	mov	x0, x20
	mov	x1, x19
	bl	_fr_member
	tbz	w0, #0, LBB23_44
; %bb.42:
	ldp	x8, x9, [sp]
	ldrb	w11, [sp, #40]
	ldr	x10, [sp, #48]
	ldur	q0, [sp, #72]
	ldur	q1, [sp, #88]
	ldur	q2, [sp, #104]
	stp	q1, q2, [sp, #176]
	ldur	q1, [sp, #120]
	str	q1, [sp, #208]
	ldur	q1, [sp, #56]
	stp	q1, q0, [sp, #144]
LBB23_43:
	mov	w0, #0                          ; =0x0
	ldr	x12, [x21]
	mov	w13, w24
	mov	w14, #176                       ; =0xb0
	umaddl	x12, w13, w14, x12
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x12, #144]
	stp	q0, q0, [x12, #112]
	stp	q0, q0, [x12, #80]
	stp	q0, q0, [x12, #48]
	stp	q0, q0, [x12, #16]
	str	q0, [x12]
	ldr	x12, [x21]
	umaddl	x12, w23, w14, x12
	ldp	q1, q0, [sp, #144]
	stur	q0, [x12, #56]
	ldp	q0, q2, [sp, #176]
	stur	q0, [x12, #72]
	stur	q2, [x12, #88]
	ldr	q0, [sp, #208]
	stur	q0, [x12, #104]
	lsr	x13, x9, #32
	sub	x13, x13, #1
	cmp	x13, #2
	cset	w13, lo
	mov	w14, #1                         ; =0x1
	strb	w14, [x12]
	strb	w13, [x12, #1]
	strh	wzr, [x12, #2]
	stur	x8, [x12, #4]
	stur	x9, [x12, #12]
	str	wzr, [x12, #20]
	strb	w11, [x12, #24]
	strb	wzr, [x12, #31]
	sturh	wzr, [x12, #29]
	stur	wzr, [x12, #25]
	str	x10, [x12, #32]
	stur	q1, [x12, #40]
	b	LBB23_9
LBB23_44:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB23_46
; %bb.45:
	mov	w0, #6                          ; =0x6
	b	LBB23_9
LBB23_46:
	ldr	w8, [x21, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB23_9
	b	LBB23_29
LBB23_47:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh54, Lloh55, Lloh56
	.loh AdrpLdrGotLdr	Lloh57, Lloh58, Lloh59
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_result_arm ; -- Begin function nvm_services_runtime_result_arm
	.p2align	2
_nvm_services_runtime_result_arm:       ; @nvm_services_runtime_result_arm
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_3
; %bb.1:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB24_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB24_25
LBB24_3:
	mov	w0, #1                          ; =0x1
	ret
LBB24_4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB24_24
; %bb.5:
	mov	x8, x0
	add	x9, x0, #74, lsl #12            ; =303104
	add	x19, x9, #4064
	ldr	w0, [x19, #40]
	cbnz	w0, LBB24_25
; %bb.6:
	ldrb	w9, [x20, #12]
	cmp	w9, #1
	b.ne	LBB24_10
; %bb.7:
	mov	w0, #5                          ; =0x5
LBB24_8:
	str	w0, [x19, #40]
	mov	w8, #8                          ; =0x8
LBB24_9:
	str	w8, [x19, #48]
	b	LBB24_25
LBB24_10:
	cbz	x2, LBB24_20
; %bb.11:
	ldr	w8, [x8, #128]
	cmp	w1, w8
	b.hs	LBB24_20
; %bb.12:
	ldr	x8, [x19]
	mov	w9, #176                        ; =0xb0
	umaddl	x9, w1, w9, x8
	ldrb	w10, [x9]
	tbz	w10, #0, LBB24_20
; %bb.13:
	ldr	w10, [x9, #16]
	cmp	w10, #3
	b.eq	LBB24_21
; %bb.14:
	cmp	w10, #2
	b.ne	LBB24_26
; %bb.15:
	mov	x21, x2
	mov	w9, w1
	mov	w10, #1                         ; =0x1
	strb	w10, [x20, #10]
	ldr	x0, [x19, #32]
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w9, w10, x8
	add	x1, x8, #120
	mov	x2, sp
	bl	_nl_services_value_view
	mov	x8, x0
	strb	wzr, [x20, #10]
	cmp	w0, #2
	b.le	LBB24_28
; %bb.16:
	cmp	w8, #4
	b.gt	LBB24_32
; %bb.17:
	cmp	w8, #3
	b.eq	LBB24_38
; %bb.18:
	cmp	w8, #4
	b.ne	LBB24_37
; %bb.19:
	mov	w0, #8                          ; =0x8
	b	LBB24_40
LBB24_20:
	mov	w0, #1                          ; =0x1
	str	w0, [x19, #40]
	str	w0, [x19, #48]
	b	LBB24_25
LBB24_21:
	ldr	w8, [x9, #20]
LBB24_22:
	sub	w9, w8, #4
	cmn	w9, #3
	b.hi	LBB24_27
; %bb.23:
	ldr	w8, [x20]
	cmp	w8, #2
	b.ne	LBB24_35
LBB24_24:
	mov	w0, #5                          ; =0x5
LBB24_25:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB24_26:
	mov	w0, #6                          ; =0x6
	str	w0, [x19, #40]
	mov	w8, #3                          ; =0x3
	b	LBB24_9
LBB24_27:
	mov	w0, #0                          ; =0x0
	str	w8, [x2]
	b	LBB24_25
LBB24_28:
	cbz	w8, LBB24_36
; %bb.29:
	mov	x0, x8
	cmp	w8, #1
	b.eq	LBB24_40
; %bb.30:
	cmp	w8, #2
	b.ne	LBB24_37
; %bb.31:
	mov	w0, #7                          ; =0x7
	b	LBB24_40
LBB24_32:
	cmp	w8, #5
	b.eq	LBB24_39
; %bb.33:
	cmp	w8, #6
	b.ne	LBB24_37
; %bb.34:
	mov	w0, #4                          ; =0x4
	b	LBB24_40
LBB24_35:
	ldr	w8, [x19, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB24_25
	b	LBB24_8
LBB24_36:
	mov	x2, x21
	ldrb	w8, [sp, #4]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, eq
	b	LBB24_22
LBB24_37:
	mov	w0, #5                          ; =0x5
	b	LBB24_40
LBB24_38:
	mov	w0, #6                          ; =0x6
	b	LBB24_40
LBB24_39:
	mov	w0, #3                          ; =0x3
LBB24_40:
	ldr	w9, [x20]
	cmp	w9, #2
	b.eq	LBB24_25
; %bb.41:
	ldr	w9, [x19, #40]
	cbnz	w9, LBB24_25
; %bb.42:
	str	w0, [x19, #40]
	b	LBB24_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_take      ; -- Begin function nvm_services_runtime_take
	.p2align	2
_nvm_services_runtime_take:             ; @nvm_services_runtime_take
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x26, x25, [sp, #352]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #368]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #384]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh60:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh61:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh62:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	cbz	x0, LBB25_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB25_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB25_9
LBB25_3:
	mov	w0, #1                          ; =0x1
	b	LBB25_9
LBB25_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB25_8
; %bb.5:
	mov	x8, x0
	add	x9, x0, #74, lsl #12            ; =303104
	add	x20, x9, #4064
	ldr	w0, [x20, #40]
	cbnz	w0, LBB25_9
; %bb.6:
	ldrb	w9, [x21, #12]
	tbz	w9, #0, LBB25_11
LBB25_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x20, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #48]
	b	LBB25_9
LBB25_8:
	mov	w0, #5                          ; =0x5
LBB25_9:
	ldur	x8, [x29, #-72]
Lloh63:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh64:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh65:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB25_54
; %bb.10:
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #400]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #384]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #368]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
LBB25_11:
	mov	x0, x8
	ldr	w8, [x8, #24]
	cbz	w8, LBB25_13
; %bb.12:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB25_25
LBB25_13:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB25_23
; %bb.14:
	cmp	w3, w8
	b.hs	LBB25_23
; %bb.15:
	ldr	x8, [x20]
	mov	w9, #176                        ; =0xb0
	umull	x9, w1, w9
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB25_23
; %bb.16:
	sub	w9, w2, #4
	cmn	w9, #2
	b.lo	LBB25_23
; %bb.17:
	mov	w9, #176                        ; =0xb0
	umull	x9, w3, w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB25_23
; %bb.18:
	mov	x22, x3
	mov	x24, x2
	sub	x2, x29, #180
	mov	x19, x0
	mov	x23, x1
	bl	_nvm_services_runtime_result_arm
	cbnz	w0, LBB25_9
; %bb.19:
	ldur	w8, [x29, #-180]
	cmp	w8, w24
	b.ne	LBB25_28
; %bb.20:
	add	x9, sp, #112
	mov	w23, w23
	ldr	x8, [x20]
	mov	w10, #176                       ; =0xb0
	umaddl	x13, w23, w10, x8
	ldp	w10, w15, [x13, #12]
	ldrb	w12, [x13, #24]
	mov	w22, w22
	ldur	q0, [x13, #57]
	ldur	q1, [x13, #73]
	stp	q0, q1, [x29, #-144]
	ldur	q0, [x13, #89]
	stur	q0, [x29, #-112]
	ldur	q0, [x13, #104]
	stur	q0, [x9, #207]
	ldur	q0, [x13, #25]
	ldur	q1, [x13, #41]
	stp	q0, q1, [x29, #-176]
	str	xzr, [sp, #224]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	str	q0, [sp, #112]
	mov	w13, #36409                     ; =0x8e39
	movk	w13, #14563, lsl #16
	umull	x13, w10, w13
	lsr	x13, x13, #33
	add	w14, w13, w13, lsl #3
	cmp	w15, #2
	b.ne	LBB25_30
; %bb.21:
	cmp	w24, #2
	b.ne	LBB25_35
; %bb.22:
	add	x10, x19, w14, uxtw #4
	str	wzr, [sp, #228]
	stur	q0, [x9, #100]
	stur	q0, [x9, #84]
	stur	q0, [x9, #68]
	stur	q0, [x9, #52]
	stur	q0, [x9, #36]
	stur	q0, [sp, #132]
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #112]
	strh	wzr, [sp, #114]
	ldr	w11, [x10, #156]
	ldr	q0, [x10, #144]
	sub	x10, x11, #1
	cmp	x10, #2
	cset	w10, lo
	strb	w10, [sp, #113]
	stur	q0, [sp, #116]
	strb	w9, [x21, #10]
	ldr	x0, [x20, #32]
	mov	w9, #176                        ; =0xb0
	umaddl	x10, w23, w9, x8
	umaddl	x8, w22, w9, x8
	add	x1, x10, #120
	add	x2, x8, #120
	bl	_nl_services_value_take_ok
	mov	x1, x0
	strb	wzr, [x21, #10]
	cbnz	w1, LBB25_37
	b	LBB25_47
LBB25_23:
	mov	w0, #6                          ; =0x6
LBB25_24:
	str	w0, [x20, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #48]
	b	LBB25_9
LBB25_25:
	ldrh	w8, [x21, #8]
	cbz	x8, LBB25_7
; %bb.26:
	ldr	x9, [x20, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB25_7
; %bb.27:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB25_7
	b	LBB25_13
LBB25_28:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB25_51
; %bb.29:
	ldr	w8, [x20, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB25_9
	b	LBB25_24
LBB25_30:
	ldr	w9, [x19, #9616]
	add	w9, w9, w9, lsl #3
	cmp	w10, w9
	b.hs	LBB25_48
; %bb.31:
	sub	w0, w10, w14
	add	x8, x19, w13, uxtw #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	w9, w9, ne
	cmp	w8, #2
	ccmp	w9, w0, #2, ne
	b.ls	LBB25_48
; %bb.32:
	stp	w12, w10, [sp, #4]              ; 8-byte Folded Spill
	cmp	w8, #3
	b.eq	LBB25_42
; %bb.33:
	cmp	w8, #2
	b.ne	LBB25_43
; %bb.34:
	bl	_nl_socket_catalog_type
	b	LBB25_44
LBB25_35:
	str	x22, [sp, #8]                   ; 8-byte Folded Spill
	mov	x22, x14
	mov	x24, x13
	mov	w25, #1                         ; =0x1
	strb	w25, [x21, #10]
	ldr	x0, [x20, #32]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w23, w9, x8
	add	x1, x8, #120
	add	x2, sp, #64
	bl	_nl_services_value_view
	strb	wzr, [x21, #10]
	cbz	w0, LBB25_38
; %bb.36:
	mov	x1, x0
LBB25_37:
	mov	x0, x19
	bl	_fr_core
	b	LBB25_9
LBB25_38:
	add	w8, w22, #1
	add	x8, x19, w8, uxtw #4
	movi.2d	v0, #0000000000000000
	stur	q0, [sp, #132]
	str	wzr, [sp, #228]
	add	x10, sp, #112
	stur	q0, [x10, #100]
	stur	q0, [x10, #84]
	stur	q0, [x10, #68]
	stur	q0, [x10, #52]
	stur	q0, [x10, #36]
	strb	w25, [sp, #112]
	strh	wzr, [sp, #114]
	ldr	w10, [x8, #156]
	ldr	q0, [x8, #144]
	sub	x8, x10, #1
	cmp	x8, #2
	cset	w8, lo
	strb	w8, [sp, #113]
	stur	q0, [sp, #116]
	add	x8, x19, w24, uxtw #2
	ldr	w8, [x8, #9360]
	mov	w9, #7                          ; =0x7
	mov	w10, #9                         ; =0x9
	cmp	w8, #3
	csel	w9, w10, w9, eq
	mov	w10, #11                        ; =0xb
	cmp	w8, #2
	csel	w8, w10, w9, eq
	strb	w8, [sp, #136]
	add	x8, sp, #112
	add	x0, sp, #64
	add	x1, x8, #32
	bl	_fr_error_payload
	tbz	w0, #0, LBB25_40
; %bb.39:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #10]
	ldr	x0, [x20, #32]
	ldr	x8, [x20]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w23, w9, x8
	add	x1, x8, #120
	add	x2, sp, #16
	bl	_nl_services_value_take_error
	mov	x1, x0
	strb	wzr, [x21, #10]
	ldr	x22, [sp, #8]                   ; 8-byte Folded Reload
	cbnz	w1, LBB25_37
	b	LBB25_47
LBB25_40:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB25_52
; %bb.41:
	mov	w0, #3                          ; =0x3
	b	LBB25_9
LBB25_42:
	bl	_nl_websocket_catalog_type
	b	LBB25_44
LBB25_43:
	bl	_nl_file_catalog_type
LBB25_44:
	cbz	x0, LBB25_48
; %bb.45:
	ldr	x8, [x0, #24]
	cmp	w24, #3
	cset	w9, eq
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #64
	mov	x0, x19
	ldr	w1, [sp, #8]                    ; 4-byte Folded Reload
	bl	_fr_member
	tbz	w0, #0, LBB25_48
; %bb.46:
	stur	xzr, [sp, #132]
	str	wzr, [sp, #140]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #112]
	strh	wzr, [sp, #114]
	ldr	w8, [sp, #76]
	ldr	q0, [sp, #64]
	sub	x8, x8, #1
	cmp	x8, #2
	cset	w8, lo
	strb	w8, [sp, #113]
	stur	q0, [sp, #116]
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	strb	w8, [sp, #136]
	add	x8, sp, #112
	ldur	q0, [x8, #167]
	ldur	q1, [x8, #183]
	stp	q0, q1, [sp, #176]
	ldur	q0, [x8, #199]
	str	q0, [sp, #208]
	ldur	x9, [x8, #215]
	str	x9, [sp, #224]
	ldur	q0, [x8, #135]
	ldur	q1, [x8, #151]
	stp	q0, q1, [sp, #144]
LBB25_47:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w23, w9, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	ldr	x8, [x20]
	umaddl	x8, w22, w9, x8
	ldp	q0, q1, [sp, #176]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #208]
	str	q0, [x8, #96]
	ldr	x9, [sp, #224]
	str	x9, [x8, #112]
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [x8]
	ldp	q0, q1, [sp, #144]
	stp	q0, q1, [x8, #32]
	b	LBB25_9
LBB25_48:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB25_51
; %bb.49:
	ldr	w8, [x20, #40]
	cbnz	w8, LBB25_51
; %bb.50:
	mov	w8, #6                          ; =0x6
	str	w8, [x20, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #48]
LBB25_51:
	mov	w0, #6                          ; =0x6
	b	LBB25_9
LBB25_52:
	ldr	w8, [x20, #40]
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB25_9
; %bb.53:
	str	w0, [x20, #40]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #48]
	b	LBB25_9
LBB25_54:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh60, Lloh61, Lloh62
	.loh AdrpLdrGotLdr	Lloh63, Lloh64, Lloh65
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_error_payload
_fr_error_payload:                      ; @fr_error_payload
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	cmp	w8, #3
	b.eq	LBB26_8
; %bb.1:
	cmp	w8, #2
	b.eq	LBB26_5
; %bb.2:
	cmp	w8, #1
	b.ne	LBB26_7
; %bb.3:
	ldr	x11, [x0, #24]
	tbnz	x11, #63, LBB26_7
; %bb.4:
	ldrb	w8, [x0, #34]
	ldrb	w9, [x0, #33]
	ldrb	w10, [x0, #32]
	ldr	w12, [x0, #8]
	str	x12, [x1]
	ldur	d0, [x0, #12]
	sshll.2d	v0, v0, #0
	stur	q0, [x1, #8]
	mov	w12, #48                        ; =0x30
	mov	w13, #40                        ; =0x28
	mov	w14, #32                        ; =0x20
	mov	w15, #24                        ; =0x18
	b	LBB26_9
LBB26_5:
	ldr	x11, [x0, #24]
	tbnz	x11, #63, LBB26_7
; %bb.6:
	ldrb	w8, [x0, #44]
	ldrb	w9, [x0, #43]
	ldrb	w10, [x0, #42]
	ldrb	w12, [x0, #41]
	ldrb	w13, [x0, #40]
	ldr	w14, [x0, #8]
	str	x14, [x1]
	ldur	d0, [x0, #12]
	sshll.2d	v0, v0, #0
	stur	q0, [x1, #8]
	str	x11, [x1, #24]
	ldr	d0, [x0, #32]
	ushll.2d	v0, v0, #0
	and	x13, x13, #0x1
	and	x11, x12, #0x1
	str	q0, [x1, #32]
	str	x13, [x1, #48]
	mov	w12, #80                        ; =0x50
	mov	w13, #72                        ; =0x48
	mov	w14, #64                        ; =0x40
	mov	w15, #56                        ; =0x38
	b	LBB26_9
LBB26_7:
	mov	w0, #0                          ; =0x0
	ret
LBB26_8:
	ldr	w12, [x0, #8]
	ldrsw	x11, [x0, #28]
	ldrb	w10, [x0, #32]
	ldrb	w9, [x0, #33]
	ldrb	w8, [x0, #34]
	str	x12, [x1]
	ldur	d0, [x0, #12]
	sshll.2d	v0, v0, #0
	stur	q0, [x1, #8]
	ldur	d0, [x0, #20]
	sshll.2d	v0, v0, #0
	stur	q0, [x1, #24]
	mov	w12, #64                        ; =0x40
	mov	w13, #56                        ; =0x38
	mov	w14, #48                        ; =0x30
	mov	w15, #40                        ; =0x28
LBB26_9:
	str	x11, [x1, x15]
	and	x10, x10, #0x1
	str	x10, [x1, x14]
	and	x9, x9, #0x1
	str	x9, [x1, x13]
	and	x8, x8, #0x1
	str	x8, [x1, x12]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_region_begin ; -- Begin function nvm_services_runtime_region_begin
	.p2align	2
_nvm_services_runtime_region_begin:     ; @nvm_services_runtime_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB27_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x9, x8, #2728
	ldrb	w8, [x9, #10]
	tbz	w8, #0, LBB27_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB27_3:
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	ret
LBB27_4:
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB27_7
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x10, x8, #4080
	ldr	w8, [x10, #24]
	cbz	w8, LBB27_8
; %bb.6:
	mov	x0, x8
	ret
LBB27_7:
	mov	w0, #5                          ; =0x5
	ret
LBB27_8:
	ldrb	w8, [x9, #12]
	tbz	w8, #0, LBB27_10
LBB27_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x10, #24]
	mov	w9, #8                          ; =0x8
	str	w9, [x10, #32]
	ret
LBB27_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB27_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB27_16
LBB27_12:
	ldr	w11, [x9, #20]
	ldr	w8, [x0, #136]
	cmp	w11, w8
	b.eq	LBB27_15
; %bb.13:
	ldr	x12, [x9, #24]
	cmn	x12, #1
	b.eq	LBB27_15
; %bb.14:
	add	x13, x12, #1
	str	x13, [x9, #24]
	ldr	x10, [x10]
	add	w13, w11, #1
	str	w13, [x9, #20]
	str	x12, [x10, x11, lsl #3]
	mov	w0, #0                          ; =0x0
	ret
LBB27_15:
	mov	w0, #3                          ; =0x3
	str	w0, [x10, #24]
	mov	w9, #5                          ; =0x5
	str	w9, [x10, #32]
	ret
LBB27_16:
	ldrh	w8, [x9, #8]
	cbz	x8, LBB27_9
; %bb.17:
	ldr	x11, [x10, #8]
	sub	w8, w8, #1
	mov	w12, #40                        ; =0x28
	umaddl	x8, w8, w12, x11
	ldrb	w11, [x8, #32]
	tbnz	w11, #0, LBB27_9
; %bb.18:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB27_9
	b	LBB27_12
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_borrow    ; -- Begin function nvm_services_runtime_borrow
	.p2align	2
_nvm_services_runtime_borrow:           ; @nvm_services_runtime_borrow
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_file_runtime_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_runtime_borrow_mode
_file_runtime_borrow_mode:              ; @file_runtime_borrow_mode
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB29_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x9, x8, #2728
	ldrb	w8, [x9, #10]
	tbz	w8, #0, LBB29_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB29_3:
	mov	w0, #1                          ; =0x1
	ret
LBB29_4:
	ldr	w8, [x9]
	cmp	w8, #1
	b.ne	LBB29_7
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x10, x8, #4064
	ldr	w8, [x10, #40]
	cbz	w8, LBB29_8
; %bb.6:
	mov	x0, x8
	ret
LBB29_7:
	mov	w0, #5                          ; =0x5
	ret
LBB29_8:
	ldrb	w8, [x9, #12]
	tbz	w8, #0, LBB29_10
LBB29_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x10, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x10, #48]
	ret
LBB29_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB29_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB29_20
LBB29_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB29_19
; %bb.13:
	ldr	x11, [x10]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x11
	ldrb	w12, [x8]
	cmp	w12, #1
	b.ne	LBB29_19
; %bb.14:
	ldr	w12, [x8, #16]
	cmp	w12, #1
	b.ne	LBB29_19
; %bb.15:
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB29_19
; %bb.16:
	ldr	w8, [x9, #20]
	cbz	w8, LBB29_19
; %bb.17:
	ldr	w12, [x0, #132]
	cmp	w2, w12
	b.hs	LBB29_19
; %bb.18:
	ldr	x13, [x10, #8]
	mov	w14, w2
	add	x15, x13, x14, lsl #6
	ldrb	w16, [x15]
	cmp	w16, #1
	b.ne	LBB29_23
LBB29_19:
	mov	w0, #8                          ; =0x8
	str	w0, [x10, #40]
	mov	w9, #4                          ; =0x4
	str	w9, [x10, #48]
	ret
LBB29_20:
	ldrh	w8, [x9, #8]
	cbz	x8, LBB29_9
; %bb.21:
	ldr	x11, [x10, #24]
	sub	w8, w8, #1
	mov	w12, #40                        ; =0x28
	umaddl	x8, w8, w12, x11
	ldrb	w11, [x8, #32]
	tbnz	w11, #0, LBB29_9
; %bb.22:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB29_9
	b	LBB29_12
LBB29_23:
	sub	sp, sp, #128
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	stp	w1, w2, [sp, #20]
	mov	w16, #-1                        ; =0xffffffff
	str	w16, [sp, #28]
	ldr	x16, [x10, #16]
	sub	w8, w8, #1
	ldr	x8, [x16, w8, uxtw #3]
	str	x8, [sp, #32]
	strb	w3, [sp, #18]
	cbz	w3, LBB29_31
; %bb.24:
	mov	x8, #0                          ; =0x0
	b	LBB29_26
LBB29_25:                               ;   in Loop: Header=BB29_26 Depth=1
	add	x8, x8, #1
	add	x13, x13, #64
	cmp	x12, x8
	b.eq	LBB29_31
LBB29_26:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w16, [x13]
	cmp	w16, #1
	b.ne	LBB29_25
; %bb.27:                               ;   in Loop: Header=BB29_26 Depth=1
	ldr	w16, [x13, #4]
	cmp	w16, w1
	b.ne	LBB29_25
; %bb.28:
	str	x15, [sp, #8]                   ; 8-byte Folded Spill
	mov	x19, x10
	ldrb	w9, [x13, #2]
	cmp	w9, #1
	b.ne	LBB29_35
; %bb.29:
	mov	x20, x13
	mov	x1, x8
	bl	_fr_reference
	tbz	w0, #0, LBB29_35
; %bb.30:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x20, #8]
	str	w9, [sp, #24]
	ldur	q0, [x20, #40]
	ldur	q1, [x20, #24]
	ldr	x9, [x20, #56]
	stur	q1, [sp, #40]
	stur	q0, [sp, #56]
	str	x9, [sp, #72]
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #16]
	ldp	q0, q1, [sp, #16]
	ldp	q2, q3, [sp, #48]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	b	LBB29_34
LBB29_31:
	stp	x14, x0, [sp]                   ; 16-byte Folded Spill
	mov	w8, w1
	mov	w20, #1                         ; =0x1
	strb	w20, [x9, #10]
	mov	x19, x10
	ldr	x0, [x10, #32]
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w8, w10, x11
	add	x10, sp, #16
	add	x1, x8, #120
	add	x2, x10, #24
	mov	x21, x9
	bl	_nl_services_value_borrow
	strb	wzr, [x21, #10]
	cbz	w0, LBB29_33
; %bb.32:
	mov	x1, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_fr_core
	mov	x8, x0
	b	LBB29_36
LBB29_33:
	mov	w8, #0                          ; =0x0
	strb	w20, [sp, #16]
	ldr	x10, [x19, #8]
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	add	x9, x10, x9, lsl #6
	ldp	q0, q1, [sp, #16]
	ldp	q2, q3, [sp, #48]
LBB29_34:
	stp	q2, q3, [x9, #32]
	stp	q0, q1, [x9]
	b	LBB29_36
LBB29_35:
	mov	w8, #8                          ; =0x8
	str	w8, [x19, #40]
	mov	w9, #4                          ; =0x4
	str	w9, [x19, #48]
LBB29_36:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #128
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_borrow_shared ; -- Begin function nvm_services_runtime_borrow_shared
	.p2align	2
_nvm_services_runtime_borrow_shared:    ; @nvm_services_runtime_borrow_shared
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_file_runtime_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_bind_formal ; -- Begin function nvm_services_runtime_bind_formal
	.p2align	2
_nvm_services_runtime_bind_formal:      ; @nvm_services_runtime_bind_formal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB31_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x10, x8, #2728
	ldrb	w8, [x10, #10]
	tbz	w8, #0, LBB31_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB31_3:
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	ret
LBB31_4:
	ldr	w8, [x10]
	cmp	w8, #1
	b.ne	LBB31_7
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x9, x8, #4064
	ldr	w8, [x9, #40]
	cbz	w8, LBB31_8
; %bb.6:
	mov	x0, x8
	ret
LBB31_7:
	mov	w0, #5                          ; =0x5
	ret
LBB31_8:
	ldrb	w8, [x10, #12]
	tbz	w8, #0, LBB31_10
LBB31_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x9, #40]
	mov	w10, #8                         ; =0x8
	str	w10, [x9, #48]
	ret
LBB31_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB31_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB31_26
LBB31_12:
	ldr	w13, [x0, #132]
	cmp	w1, w13
	b.hs	LBB31_25
; %bb.13:
	ldr	x8, [x9, #8]
	mov	w10, w1
	add	x10, x8, x10, lsl #6
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB31_25
; %bb.14:
	ldr	w11, [x10, #8]
	cmp	w11, w13
	b.hs	LBB31_25
; %bb.15:
	add	x14, x8, x11, lsl #6
	ldrb	w12, [x14]
	cmp	w12, #1
	b.ne	LBB31_25
; %bb.16:
	ldrb	w12, [x14, #1]
	tbnz	w12, #0, LBB31_25
; %bb.17:
	ldr	w12, [x14, #8]
	cmp	w12, w11
	b.ne	LBB31_25
; %bb.18:
	ldrb	w12, [x14, #2]
	ldrb	w15, [x10, #2]
	cmp	w12, w15
	b.ne	LBB31_25
; %bb.19:
	ldr	x15, [x14, #56]
	ldr	x16, [x10, #56]
	cmp	x15, x16
	b.ne	LBB31_25
; %bb.20:
	ldr	w14, [x14, #4]
	ldr	w15, [x10, #4]
	cmp	w14, w15
	b.ne	LBB31_25
; %bb.21:
	ldr	w16, [x0, #128]
	cmp	w14, w16
	b.hs	LBB31_25
; %bb.22:
	ldr	x15, [x9]
	mov	w17, #176                       ; =0xb0
	umaddl	x17, w14, w17, x15
	ldrb	w0, [x17]
	cmp	w0, #1
	b.ne	LBB31_25
; %bb.23:
	ldrb	w0, [x17, #1]
	cmp	w0, #1
	b.ne	LBB31_25
; %bb.24:
	ldr	w17, [x17, #16]
	cmp	w17, #1
	ccmp	w2, w16, #2, eq
	b.lo	LBB31_29
LBB31_25:
	mov	w0, #8                          ; =0x8
	str	w0, [x9, #40]
	mov	w10, #4                         ; =0x4
	str	w10, [x9, #48]
	ret
LBB31_26:
	ldrh	w8, [x10, #8]
	cbz	x8, LBB31_9
; %bb.27:
	ldr	x10, [x9, #24]
	sub	w8, w8, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w8, w11, x10
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB31_9
; %bb.28:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB31_9
	b	LBB31_12
LBB31_29:
	cmp	w3, w13
	b.hs	LBB31_25
; %bb.30:
	mov	w13, #176                       ; =0xb0
	umull	x13, w2, w13
	ldrb	w13, [x15, x13]
	tbnz	w13, #0, LBB31_25
; %bb.31:
	mov	w13, w3
	add	x13, x8, x13, lsl #6
	ldrb	w8, [x13]
	cmp	w8, #1
	b.eq	LBB31_25
; %bb.32:
	mov	w16, w2
	ldrb	w17, [x10, #3]
	mov	w0, #176                        ; =0xb0
	umaddl	x15, w14, w0, x15
	ldur	x1, [x15, #4]
	ldur	x15, [x15, #12]
	mov	w4, #257                        ; =0x101
	strh	w4, [x13]
	mov	w4, #2                          ; =0x2
	sub	x4, x4, x12
	strb	w12, [x13, #2]
	strb	w17, [x13, #3]
	stp	w14, w11, [x13, #4]
	str	w2, [x13, #12]
	str	xzr, [x13, #16]
	ldr	x11, [x10, #56]
	ldur	q0, [x10, #40]
	ldur	q1, [x10, #24]
	stur	q1, [x13, #24]
	stur	q0, [x13, #40]
	str	x11, [x13, #56]
	ldr	x10, [x9]
	umaddl	x10, w16, w0, x10
	movi.4h	v0, #1
	str	s0, [x10]
	and	x11, x1, #0xffffffffffff00ff
	orr	x11, x11, x4, lsl #8
	stur	x11, [x10, #4]
	stur	x15, [x10, #12]
	str	wzr, [x10, #116]
	movi.2d	v0, #0000000000000000
	stur	q0, [x10, #100]
	stur	q0, [x10, #84]
	stur	q0, [x10, #68]
	stur	q0, [x10, #52]
	stur	q0, [x10, #36]
	stur	q0, [x10, #20]
	ldr	x9, [x9]
	umaddl	x9, w16, w0, x9
	str	w3, [x9, #152]
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_reference
_fr_reference:                          ; @fr_reference
	.cfi_startproc
; %bb.0:
	ldr	w10, [x0, #132]
	cmp	w1, w10
	b.hs	LBB32_13
; %bb.1:
	add	x8, x0, #74, lsl #12            ; =303104
	ldr	x12, [x8, #4072]
	mov	w9, w1
	add	x9, x12, x9, lsl #6
	ldrb	w11, [x9]
	cmp	w11, #1
	b.ne	LBB32_13
; %bb.2:
	ldr	w11, [x9, #8]
	cmp	w11, w10
	b.hs	LBB32_13
; %bb.3:
	add	x10, x12, x11, lsl #6
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB32_13
; %bb.4:
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB32_13
; %bb.5:
	ldr	w12, [x10, #8]
	cmp	w12, w11
	b.ne	LBB32_13
; %bb.6:
	ldrb	w11, [x10, #2]
	ldrb	w12, [x9, #2]
	cmp	w11, w12
	b.ne	LBB32_13
; %bb.7:
	ldr	x11, [x10, #56]
	ldr	x12, [x9, #56]
	cmp	x11, x12
	b.ne	LBB32_13
; %bb.8:
	ldr	w10, [x10, #4]
	ldr	w9, [x9, #4]
	cmp	w10, w9
	b.ne	LBB32_13
; %bb.9:
	ldr	w9, [x0, #128]
	cmp	w10, w9
	b.hs	LBB32_13
; %bb.10:
	ldr	x8, [x8, #4064]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w10, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB32_13
; %bb.11:
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB32_13
; %bb.12:
	ldr	w8, [x8, #16]
	cmp	w8, #1
	cset	w0, eq
	ret
LBB32_13:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_end_reference ; -- Begin function nvm_services_runtime_end_reference
	.p2align	2
_nvm_services_runtime_end_reference:    ; @nvm_services_runtime_end_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB33_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x13, x8, #2728
	ldrb	w8, [x13, #10]
	tbz	w8, #0, LBB33_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB33_9
LBB33_3:
	mov	w8, #1                          ; =0x1
	b	LBB33_9
LBB33_4:
	ldr	w8, [x13]
	cmp	w8, #1
	b.ne	LBB33_8
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x9, x8, #4064
	ldr	w8, [x9, #40]
	cbnz	w8, LBB33_9
; %bb.6:
	ldrb	w8, [x13, #12]
	tbz	w8, #0, LBB33_10
LBB33_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x9, #40]
	mov	w10, #8                         ; =0x8
	str	w10, [x9, #48]
	b	LBB33_9
LBB33_8:
	mov	w8, #5                          ; =0x5
LBB33_9:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB33_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB33_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB33_31
LBB33_12:
	ldr	w8, [x0, #132]
	cmp	w1, w8
	b.hs	LBB33_48
; %bb.13:
	mov	w11, w1
	ldr	x10, [x9, #8]
	add	x14, x10, x11, lsl #6
	ldrb	w12, [x14]
	cmp	w12, #1
	b.ne	LBB33_48
; %bb.14:
	ldr	w12, [x14, #8]
	cmp	w12, w8
	b.hs	LBB33_48
; %bb.15:
	add	x16, x10, x12, lsl #6
	ldrb	w15, [x16]
	cmp	w15, #1
	b.ne	LBB33_48
; %bb.16:
	ldrb	w15, [x16, #1]
	tbnz	w15, #0, LBB33_48
; %bb.17:
	ldr	w15, [x16, #8]
	cmp	w15, w12
	b.ne	LBB33_48
; %bb.18:
	ldrb	w15, [x16, #2]
	ldrb	w17, [x14, #2]
	cmp	w15, w17
	b.ne	LBB33_48
; %bb.19:
	ldr	x17, [x16, #56]
	ldr	x2, [x14, #56]
	cmp	x17, x2
	b.ne	LBB33_48
; %bb.20:
	ldr	w2, [x16, #4]
	ldr	w16, [x14, #4]
	cmp	w2, w16
	b.ne	LBB33_48
; %bb.21:
	ldr	w17, [x0, #128]
	cmp	w2, w17
	b.hs	LBB33_48
; %bb.22:
	ldr	x16, [x9]
	mov	w3, #176                        ; =0xb0
	umaddl	x2, w2, w3, x16
	ldrb	w3, [x2]
	cmp	w3, #1
	b.ne	LBB33_48
; %bb.23:
	ldrb	w3, [x2, #1]
	cmp	w3, #1
	b.ne	LBB33_48
; %bb.24:
	ldr	w2, [x2, #16]
	cmp	w2, #1
	b.ne	LBB33_48
; %bb.25:
	stp	x0, x14, [sp]                   ; 16-byte Folded Spill
	ldrb	w14, [x14, #1]
	cmp	w14, #1
	b.ne	LBB33_34
; %bb.26:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w8, w17
	b.hs	LBB33_7
; %bb.27:
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w8, w10, x16
	ldrb	w10, [x8]
	cmp	w10, #1
	b.ne	LBB33_7
; %bb.28:
	ldrb	w10, [x8, #2]
	cmp	w10, #1
	b.ne	LBB33_7
; %bb.29:
	ldr	w10, [x8, #152]
	cmp	w10, w1
	b.ne	LBB33_7
; %bb.30:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	b	LBB33_55
LBB33_31:
	ldrh	w8, [x13, #8]
	cbz	x8, LBB33_7
; %bb.32:
	ldr	x10, [x9, #24]
	sub	w8, w8, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w8, w11, x10
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB33_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB33_7
	b	LBB33_12
LBB33_34:
	cbz	w15, LBB33_45
; %bb.35:
	mov	x14, #0                         ; =0x0
	mov	x15, x10
	b	LBB33_37
LBB33_36:                               ;   in Loop: Header=BB33_37 Depth=1
	add	x14, x14, #1
	add	x15, x15, #64
	cmp	x8, x14
	b.eq	LBB33_45
LBB33_37:                               ; =>This Inner Loop Header: Depth=1
	cmp	x11, x14
	b.eq	LBB33_36
; %bb.38:                               ;   in Loop: Header=BB33_37 Depth=1
	ldrb	w16, [x15]
	cmp	w16, #1
	b.ne	LBB33_36
; %bb.39:                               ;   in Loop: Header=BB33_37 Depth=1
	ldrb	w16, [x15, #1]
	tbnz	w16, #0, LBB33_36
; %bb.40:                               ;   in Loop: Header=BB33_37 Depth=1
	ldrb	w16, [x15, #2]
	cmp	w16, #1
	b.ne	LBB33_36
; %bb.41:                               ;   in Loop: Header=BB33_37 Depth=1
	ldr	w16, [x15, #8]
	cmp	w16, w12
	b.ne	LBB33_36
; %bb.42:
	cmp	w12, w1
	b.ne	LBB33_55
; %bb.43:
	add	x9, x10, #8
	b	LBB33_52
LBB33_44:                               ;   in Loop: Header=BB33_45 Depth=1
	add	x10, x10, #64
	subs	x8, x8, #1
	b.eq	LBB33_49
LBB33_45:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB33_44
; %bb.46:                               ;   in Loop: Header=BB33_45 Depth=1
	ldrb	w11, [x10, #1]
	cmp	w11, #1
	b.ne	LBB33_44
; %bb.47:                               ;   in Loop: Header=BB33_45 Depth=1
	ldr	w11, [x10, #8]
	cmp	w11, w12
	b.ne	LBB33_44
LBB33_48:
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #40]
	mov	w10, #4                         ; =0x4
	str	w10, [x9, #48]
	b	LBB33_9
LBB33_49:
	mov	w8, #1                          ; =0x1
	mov	x19, x13
	strb	w8, [x13, #10]
	ldr	x0, [x9, #32]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, x8, #24
	bl	_nl_services_value_end_borrow
	strb	wzr, [x19, #10]
	cbz	w0, LBB33_55
; %bb.50:
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	b	_fr_core
LBB33_51:                               ;   in Loop: Header=BB33_52 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB33_55
LBB33_52:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-8]
	cmp	w10, #1
	b.ne	LBB33_51
; %bb.53:                               ;   in Loop: Header=BB33_52 Depth=1
	ldr	w10, [x9]
	cmp	w10, w11
	b.ne	LBB33_51
; %bb.54:                               ;   in Loop: Header=BB33_52 Depth=1
	str	w14, [x9]
	b	LBB33_51
LBB33_55:
	mov	w8, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9]
	b	LBB33_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_region_end ; -- Begin function nvm_services_runtime_region_end
	.p2align	2
_nvm_services_runtime_region_end:       ; @nvm_services_runtime_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB34_3
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB34_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB34_28
LBB34_3:
	mov	w0, #1                          ; =0x1
	ret
LBB34_4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB34_12
; %bb.5:
	add	x8, x0, #74, lsl #12            ; =303104
	add	x21, x8, #4072
	ldr	w8, [x21, #32]
	cbnz	w8, LBB34_28
; %bb.6:
	ldrb	w8, [x20, #12]
	tbnz	w8, #0, LBB34_26
; %bb.7:
	ldr	w8, [x0, #24]
	cbz	w8, LBB34_9
; %bb.8:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB34_23
LBB34_9:
	ldr	w8, [x20, #20]
	cbz	w8, LBB34_26
; %bb.10:
	ldr	x10, [x21, #8]
	sub	w11, w8, #1
	ldr	w8, [x0, #132]
	cbz	w8, LBB34_37
; %bb.11:
	mov	x9, #0                          ; =0x0
	ldr	x22, [x10, w11, uxtw #3]
	ldr	x10, [x21]
	b	LBB34_14
LBB34_12:
	mov	w8, #5                          ; =0x5
	b	LBB34_28
LBB34_13:                               ;   in Loop: Header=BB34_14 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB34_29
LBB34_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB34_19 Depth 2
	add	x11, x10, x9, lsl #6
	ldrb	w12, [x11]
	cmp	w12, #1
	b.ne	LBB34_13
; %bb.15:                               ;   in Loop: Header=BB34_14 Depth=1
	ldrb	w12, [x11, #1]
	tbnz	w12, #0, LBB34_13
; %bb.16:                               ;   in Loop: Header=BB34_14 Depth=1
	ldr	x11, [x11, #16]
	cmp	x11, x22
	b.ne	LBB34_13
; %bb.17:                               ;   in Loop: Header=BB34_14 Depth=1
	mov	x11, x10
	mov	x12, x8
	b	LBB34_19
LBB34_18:                               ;   in Loop: Header=BB34_19 Depth=2
	add	x11, x11, #64
	subs	x12, x12, #1
	b.eq	LBB34_13
LBB34_19:                               ;   Parent Loop BB34_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w13, [x11]
	cmp	w13, #1
	b.ne	LBB34_18
; %bb.20:                               ;   in Loop: Header=BB34_19 Depth=2
	ldrb	w13, [x11, #1]
	cmp	w13, #1
	b.ne	LBB34_18
; %bb.21:                               ;   in Loop: Header=BB34_19 Depth=2
	ldr	w13, [x11, #8]
	cmp	x9, x13
	b.ne	LBB34_18
; %bb.22:
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #32]
	mov	w9, #4                          ; =0x4
	b	LBB34_27
LBB34_23:
	ldrh	w8, [x20, #8]
	cbz	x8, LBB34_26
; %bb.24:
	ldr	x9, [x21, #16]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB34_26
; %bb.25:
	ldrb	w8, [x8, #33]
	tbnz	w8, #0, LBB34_9
LBB34_26:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #32]
	mov	w9, #8                          ; =0x8
LBB34_27:
	str	w9, [x21, #40]
LBB34_28:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB34_29:
	mov	x23, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB34_31
LBB34_30:                               ;   in Loop: Header=BB34_31 Depth=1
	add	x19, x19, #1
	add	x23, x23, #64
	cmp	x19, x8
	b.hs	LBB34_36
LBB34_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x21]
	ldrb	w10, [x9, x23]
	cmp	w10, #1
	b.ne	LBB34_30
; %bb.32:                               ;   in Loop: Header=BB34_31 Depth=1
	add	x9, x9, x23
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB34_30
; %bb.33:                               ;   in Loop: Header=BB34_31 Depth=1
	ldr	x9, [x9, #16]
	cmp	x9, x22
	b.ne	LBB34_30
; %bb.34:                               ;   in Loop: Header=BB34_31 Depth=1
	mov	x24, x0
	mov	x1, x19
	bl	_nvm_services_runtime_end_reference
	cbnz	w0, LBB34_38
; %bb.35:                               ;   in Loop: Header=BB34_31 Depth=1
	mov	x0, x24
	ldr	w8, [x24, #132]
	b	LBB34_30
LBB34_36:
	ldr	x10, [x21, #8]
	ldr	w8, [x20, #20]
	sub	w11, w8, #1
LBB34_37:
	mov	w8, #0                          ; =0x0
	str	w11, [x20, #20]
	str	xzr, [x10, x11, lsl #3]
	b	LBB34_28
LBB34_38:
	mov	x8, x0
	b	LBB34_28
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_service   ; -- Begin function nvm_services_runtime_service
	.p2align	2
_nvm_services_runtime_service:          ; @nvm_services_runtime_service
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB35_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x25, x8, #2728
	ldrb	w8, [x25, #10]
	tbz	w8, #0, LBB35_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB35_84
LBB35_3:
	mov	w0, #1                          ; =0x1
	ret
LBB35_4:
	ldr	w8, [x25]
	cmp	w8, #1
	b.ne	LBB35_83
; %bb.5:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x24, x8, #4064
	ldr	w0, [x24, #40]
	cbnz	w0, LBB35_84
; %bb.6:
	ldrb	w8, [x25, #12]
	tbz	w8, #0, LBB35_9
LBB35_7:
	mov	w0, #5                          ; =0x5
LBB35_8:
	str	w0, [x24, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #48]
	b	LBB35_84
LBB35_9:
	ldr	w8, [x19, #24]
	cbz	w8, LBB35_11
; %bb.10:
	ldrb	w8, [x19, #57]
	tbz	w8, #0, LBB35_25
LBB35_11:
	ldr	w8, [x19, #128]
	cmp	w4, w8
	b.hs	LBB35_66
; %bb.12:
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umull	x9, w4, w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB35_66
; %bb.13:
	mov	x22, x2
	sub	x2, x29, #92
	mov	x0, x19
	mov	x23, x1
	mov	x26, x3
	mov	x21, x4
	bl	_fr_import
	cbz	w0, LBB35_66
; %bb.14:
	mov	x8, x19
	ldur	w20, [x29, #-92]
	ldr	w9, [x19, #9616]
	add	w9, w9, w9, lsl #2
	cmp	w20, w9
	b.hs	LBB35_66
; %bb.15:
	mov	x1, x22
	ldr	w9, [x8, #24]
	cbz	w9, LBB35_21
; %bb.16:
	ldr	x9, [x24, #24]
	ldrh	w10, [x25, #8]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldur	w1, [x9, #-40]
	ldurh	w2, [x9, #-36]
	ldurb	w3, [x9, #-6]
	add	x4, sp, #88
	mov	x5, sp
	mov	x0, x8
	bl	_fr_instruction
	cbz	w0, LBB35_40
; %bb.17:
	ldrb	w8, [sp, #96]
	cmp	w8, #145
	b.ne	LBB35_40
; %bb.18:
	ldr	w8, [sp, #104]
	cmp	w8, w23
	b.ne	LBB35_40
; %bb.19:
	ldr	w8, [sp, #680]
	cmp	w8, w20
	b.ne	LBB35_40
; %bb.20:
	mov	x8, x19
	mov	x1, x22
LBB35_21:
	mov	w9, #52429                      ; =0xcccd
	movk	w9, #52428, lsl #16
	umull	x9, w20, w9
	lsr	x9, x9, #34
	add	x10, x8, x9, lsl #2
	ldr	w28, [x10, #9360]
	cmp	w28, #3
	b.ne	LBB35_28
LBB35_22:
	ldr	w8, [x25]
	cmp	w8, #2
	b.eq	LBB35_43
; %bb.23:
	ldr	w8, [x24, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB35_84
; %bb.24:
	str	w0, [x24, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x24, #48]
	b	LBB35_84
LBB35_25:
	ldrh	w8, [x25, #8]
	cbz	x8, LBB35_7
; %bb.26:
	ldr	x9, [x24, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB35_7
; %bb.27:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB35_7
	b	LBB35_11
LBB35_28:
	add	w10, w9, w9, lsl #2
	sub	w23, w20, w10
	add	w27, w9, w9, lsl #3
	sub	w9, w23, #4
	cmn	w9, #3
	b.hs	LBB35_44
; %bb.29:
	cmn	w1, #1
	b.ne	LBB35_46
; %bb.30:
	cbnz	w23, LBB35_52
; %bb.31:
	cmp	w28, #2
	b.ne	LBB35_52
; %bb.32:
	ldr	w8, [x19, #128]
	cmp	w26, w8
	b.hs	LBB35_22
; %bb.33:
	mov	x3, x26
	ldr	x9, [x24]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w26, w8, x9
	ldrb	w10, [x8]
	cmp	w10, #1
	b.ne	LBB35_22
; %bb.34:
	mov	w10, w3
	mov	w11, #176                       ; =0xb0
	umaddl	x9, w10, w11, x9
	ldr	x11, [x9, #4]!
	add	w10, w27, #8
	add	x10, x19, w10, uxtw #4
	ldr	x12, [x10, #144]!
	eor	x11, x12, x11
	tst	x11, #0xff
	b.ne	LBB35_22
; %bb.35:
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	tst	x11, x12
	b.ne	LBB35_22
; %bb.36:
	ldr	x10, [x10, #8]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB35_22
; %bb.37:
	ldrb	w9, [x8, #1]
	tbnz	w9, #0, LBB35_22
; %bb.38:
	ldrb	w9, [x8, #2]
	tbnz	w9, #0, LBB35_22
; %bb.39:
	ldrb	w8, [x8, #24]
	cmp	w8, #7
	b.ne	LBB35_22
	b	LBB35_70
LBB35_40:
	ldr	w8, [x25]
	cmp	w8, #2
	b.eq	LBB35_43
; %bb.41:
	ldr	w8, [x24, #40]
	cbnz	w8, LBB35_43
; %bb.42:
	mov	w8, #6                          ; =0x6
	str	w8, [x24, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x24, #48]
LBB35_43:
	mov	w0, #6                          ; =0x6
	b	LBB35_84
LBB35_44:
	mov	x0, x8
	bl	_fr_reference
	cbz	w0, LBB35_46
; %bb.45:
	ldr	x9, [x24, #8]
	mov	w8, w22
	add	x8, x9, x8, lsl #6
	ldrb	w9, [x8, #2]
	tbz	w9, #0, LBB35_50
LBB35_46:
	ldr	w8, [x25]
	cmp	w8, #2
	b.ne	LBB35_48
; %bb.47:
	mov	w0, #8                          ; =0x8
	b	LBB35_84
LBB35_48:
	ldr	w8, [x24, #40]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB35_84
; %bb.49:
	str	w0, [x24, #40]
	mov	w8, #4                          ; =0x4
	str	w8, [x24, #48]
	b	LBB35_84
LBB35_50:
	ldr	x9, [x24]
	ldr	w8, [x8, #4]
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w8, w10, x9
	ldr	x10, [x8, #4]!
	add	x9, x19, w27, uxtw #4
	ldr	x11, [x9, #144]!
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB35_22
; %bb.51:
	ldr	x9, [x9, #8]
	ldr	x8, [x8, #8]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	ccmp	x8, x9, #0, eq
	b.ne	LBB35_22
LBB35_52:
	cmp	w23, #4
	b.eq	LBB35_59
; %bb.53:
	cmp	w23, #1
	b.ne	LBB35_65
; %bb.54:
	ldr	w8, [x19, #128]
	cmp	w26, w8
	b.hs	LBB35_22
; %bb.55:
	mov	x3, x26
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umull	x9, w26, w9
	ldrb	w9, [x8, x9]
	cmp	w9, #1
	b.ne	LBB35_22
; %bb.56:
	mov	w9, w3
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w9, w10, x8
	ldr	x9, [x8, #4]!
	eor	x9, x9, #0xffffffff00000001
	tst	x9, #0xff
	b.ne	LBB35_22
; %bb.57:
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	tst	x9, x10
	b.ne	LBB35_22
; %bb.58:
	ldr	x8, [x8, #8]
	mov	w9, #-1                         ; =0xffffffff
	cmp	x8, x9
	b.eq	LBB35_70
	b	LBB35_22
LBB35_59:
	ldr	w8, [x19, #128]
	cmp	w26, w8
	b.hs	LBB35_22
; %bb.60:
	mov	x3, x26
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w26, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB35_22
; %bb.61:
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB35_22
; %bb.62:
	add	x9, x19, w27, uxtw #4
	ldr	x10, [x9, #144]!
	ldur	x11, [x8, #4]
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB35_22
; %bb.63:
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB35_22
; %bb.64:
	ldr	x9, [x9, #8]
	ldur	x8, [x8, #12]
	cmp	x8, x9
	b.eq	LBB35_70
	b	LBB35_22
LBB35_65:
	mov	x3, x26
	cmn	w26, #1
	b.eq	LBB35_70
LBB35_66:
	ldr	w8, [x25]
	cmp	w8, #2
	b.ne	LBB35_68
; %bb.67:
	mov	w0, #1                          ; =0x1
	b	LBB35_84
LBB35_68:
	ldr	w8, [x24, #40]
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB35_84
; %bb.69:
	str	w0, [x24, #40]
	str	w0, [x24, #48]
	b	LBB35_84
LBB35_70:
	mov	w8, #1                          ; =0x1
	strb	w8, [x25, #10]
	str	xzr, [sp, #64]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	mov	x5, sp
	mov	x0, x19
	mov	x1, x20
	mov	x2, x22
	mov	x4, x21
	bl	_fr_mixed_service
	strb	wzr, [x25, #10]
	cbz	w0, LBB35_72
; %bb.71:
	mov	x1, x0
	mov	x0, x19
	bl	_fr_core
	b	LBB35_84
LBB35_72:
	mov	w21, w21
	cmp	w23, #4
	b.eq	LBB35_77
; %bb.73:
	cbnz	w23, LBB35_78
; %bb.74:
	cmp	w28, #2
	b.ne	LBB35_76
; %bb.75:
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w26, w9, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB35_76:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x24]
	add	w9, w27, #3
	add	x9, x19, w9, uxtw #4
	mov	w10, #176                       ; =0xb0
	ldr	q0, [x9, #144]
	ldr	w9, [x9, #156]
	umaddl	x8, w21, w10, x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x8]
	sub	x9, x9, #1
	cmp	x9, #2
	cset	w9, lo
	strb	w9, [x8, #1]
	strh	wzr, [x8, #2]
	stur	q0, [x8, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #20]
	stur	q0, [x8, #36]
	stur	q0, [x8, #52]
	stur	q0, [x8, #68]
	stur	q0, [x8, #84]
	stur	q0, [x8, #100]
	str	wzr, [x8, #116]
	b	LBB35_84
LBB35_77:
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w26, w9, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB35_78:
	mov	x2, sp
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x20
	bl	_fr_scalar_result
	tbz	w0, #0, LBB35_82
; %bb.79:
	cmp	w23, #1
	b.ne	LBB35_81
; %bb.80:
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w26, w9, x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB35_81:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w21, w9, x8
	ldur	q0, [sp, #152]
	str	q0, [x8, #64]
	ldur	q0, [sp, #168]
	str	q0, [x8, #80]
	ldur	q0, [sp, #184]
	str	q0, [x8, #96]
	ldr	x9, [sp, #200]
	str	x9, [x8, #112]
	ldur	q0, [sp, #88]
	str	q0, [x8]
	ldur	q0, [sp, #104]
	str	q0, [x8, #16]
	ldur	q0, [sp, #120]
	str	q0, [x8, #32]
	ldur	q0, [sp, #136]
	str	q0, [x8, #48]
	b	LBB35_84
LBB35_82:
	ldr	w8, [x25]
	cmp	w8, #2
	b.ne	LBB35_85
LBB35_83:
	mov	w0, #5                          ; =0x5
LBB35_84:
	add	sp, sp, #704
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB35_85:
	ldr	w8, [x24, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB35_84
	b	LBB35_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_import
_fr_import:                             ; @fr_import
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #9616]
	cbz	w8, LBB36_11
; %bb.1:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	mov	w8, #9360                       ; =0x2490
	add	x23, x0, x8
	mov	w24, #52429                     ; =0xcccd
	movk	w24, #52428, lsl #16
	b	LBB36_4
LBB36_2:                                ;   in Loop: Header=BB36_4 Depth=1
	ldr	w8, [sp, #12]
	cmp	w8, w20
	b.eq	LBB36_13
LBB36_3:                                ;   in Loop: Header=BB36_4 Depth=1
	add	w22, w22, #1
	ldr	w8, [x21, #9616]
	add	w8, w8, w8, lsl #2
	cmp	w22, w8
	b.hs	LBB36_12
LBB36_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #24]
	cmp	w8, #2
	b.eq	LBB36_7
; %bb.5:                                ;   in Loop: Header=BB36_4 Depth=1
	cbnz	w8, LBB36_8
; %bb.6:                                ;   in Loop: Header=BB36_4 Depth=1
	ldr	x0, [x21]
	add	x2, sp, #12
	mov	x1, x22
	bl	_nvm_services_hosted_import
	tbnz	w0, #0, LBB36_2
	b	LBB36_9
LBB36_7:                                ;   in Loop: Header=BB36_4 Depth=1
	ldr	x0, [x21, #16]
	add	x2, sp, #12
	mov	x1, x22
	bl	_nvm_services_indirect_hosted_import
	tbz	w0, #0, LBB36_9
	b	LBB36_2
LBB36_8:                                ;   in Loop: Header=BB36_4 Depth=1
	ldr	x0, [x21, #8]
	add	x2, sp, #12
	mov	x1, x22
	bl	_nvm_services_cyclic_hosted_import
	tbnz	w0, #0, LBB36_2
LBB36_9:                                ;   in Loop: Header=BB36_4 Depth=1
	umull	x8, w22, w24
	lsr	x8, x8, #34
	add	w9, w8, w8, lsl #2
	add	w9, w9, #4
	ldr	w8, [x23, x8, lsl #2]
	cmp	w9, w22
	ccmp	w8, #3, #0, eq
	b.eq	LBB36_3
; %bb.10:
	mov	w8, #0                          ; =0x0
	b	LBB36_14
LBB36_11:
                                        ; implicit-def: $w8
	and	w0, wzr, w8
	ret
LBB36_12:
	mov	w9, #0                          ; =0x0
                                        ; implicit-def: $w8
	b	LBB36_15
LBB36_13:
	str	w22, [x19]
	mov	w8, #1                          ; =0x1
LBB36_14:
	mov	w9, #1                          ; =0x1
LBB36_15:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	and	w0, w9, w8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_mixed_service
_fr_mixed_service:                      ; @fr_mixed_service
	.cfi_startproc
; %bb.0:
	mov	x8, x2
	mov	x9, x1
	add	x10, x0, #74, lsl #12           ; =303104
	add	x10, x10, #4064
	mov	w11, #52429                     ; =0xcccd
	movk	w11, #52428, lsl #16
	umull	x11, w1, w11
	lsr	x1, x11, #34
	add	w11, w1, w1, lsl #2
	sub	w2, w9, w11
	cmp	w2, #4
	b.eq	LBB37_5
; %bb.1:
	cbnz	w2, LBB37_6
; %bb.2:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x2, #0                          ; =0x0
	str	xzr, [sp, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	str	q0, [sp]
	add	x8, x0, w1, uxtw #2
	ldr	w9, [x8, #9360]
	ldr	x8, [x10]
	cmp	w9, #2
	b.ne	LBB37_4
; %bb.3:
	mov	w9, #176                        ; =0xb0
	umaddl	x9, w3, w9, x8
	ldr	x11, [x9, #80]
	ldp	q0, q1, [x9, #32]
	ldr	q2, [x9, #64]
	stp	q0, q1, [sp]
	str	q2, [sp, #32]
	str	x11, [sp, #48]
	mov	x2, sp
LBB37_4:
	ldr	x0, [x10, #32]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w4, w9, x8
	add	x3, x8, #120
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nl_services_values_acquire
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB37_5:
	ldr	x0, [x10, #32]
	ldr	x8, [x10]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w3, w9, x8
	add	x2, x8, #120
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x3, x5
	b	_nl_services_value_close
LBB37_6:
	ldr	x0, [x10, #32]
	ldr	x9, [x10, #8]
	mov	w8, w8
	add	x8, x9, x8, lsl #6
	cmp	w2, #1
	b.ne	LBB37_8
; %bb.7:
	ldr	x9, [x10]
	mov	w10, #176                       ; =0xb0
	umaddl	x9, w3, w10, x9
	ldr	x4, [x9, #32]
	add	x3, x8, #24
                                        ; kill: def $w1 killed $w1 killed $x1
	b	_nl_services_value_call
LBB37_8:
	mov	x4, #0                          ; =0x0
	add	x3, x8, #24
                                        ; kill: def $w1 killed $w1 killed $x1
	b	_nl_services_value_call
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_scalar_result
_fr_scalar_result:                      ; @fr_scalar_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w1, w8
	lsr	x4, x8, #34
	add	w8, w4, w4, lsl #2
	sub	w15, w1, w8
	ldr	w8, [x0, #9616]
	cmp	w15, #0
	ccmp	w4, w8, #2, ne
	b.hs	LBB38_25
; %bb.1:
	ldr	w14, [x2]
	mov	w8, #9360                       ; =0x2490
	add	x16, x0, x8
	ldr	w8, [x16, w4, uxtw #2]
	cmp	w14, w8
	b.ne	LBB38_25
; %bb.2:
	ldr	w9, [x2, #8]
	cmp	w14, #1
	b.ne	LBB38_6
; %bb.3:
	mov	w8, #0                          ; =0x0
	ldr	w13, [x2, #16]
	sub	w11, w15, #1
	cmp	w13, #0
	cset	w10, ne
	cmp	w9, w11
	b.ne	LBB38_26
; %bb.4:
	ldrb	w7, [x2, #12]
	eor	w9, w10, w7
	tbz	w9, #0, LBB38_26
; %bb.5:
	mov	w8, #0                          ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w12, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	ldr	x19, [x2, #48]
	ldp	w11, w5, [x2, #40]
	ldr	x10, [x2, #32]
	ldr	d0, [x2, #24]
	ldr	w17, [x2, #20]
	ldrb	w2, [x2, #56]
	b	LBB38_9
LBB38_6:
Lloh66:
	adrp	x8, _fr_scalar_result.kinds@PAGE
Lloh67:
	add	x8, x8, _fr_scalar_result.kinds@PAGEOFF
	ldr	w8, [x8, w15, uxtw #2]
	cmp	w9, w8
	b.ne	LBB38_25
; %bb.7:
	ldr	w13, [x2, #16]
	ldrb	w7, [x2, #12]
	and	w8, w7, #0x1
	cmp	w15, #3
	ccmp	w13, #1, #0, eq
	ccmp	w13, #0, #4, ne
	cset	w9, ne
	cmp	w9, w8
	b.eq	LBB38_25
; %bb.8:
	ldr	w17, [x2, #20]
	ldr	d0, [x2, #24]
	ldr	x10, [x2, #32]
	ldp	w11, w5, [x2, #40]
	ldrb	w1, [x2, #48]
	ldrb	w20, [x2, #49]
	ldrb	w12, [x2, #50]
	ldrb	w9, [x2, #51]
	ldrb	w8, [x2, #52]
	ldr	x19, [x2, #56]
	and	x6, x1, #0x1
	and	x1, x20, #0x1
	ldrb	w2, [x2, #64]
LBB38_9:
	add	w4, w4, w4, lsl #3
	add	w20, w15, w4
	add	w20, w20, #3
	add	x0, x0, w20, uxtw #4
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp]
	str	xzr, [sp, #112]
	stp	q1, q1, [sp, #80]
	stp	q1, q1, [sp, #48]
	str	q1, [sp, #32]
	mov	w20, #1                         ; =0x1
	strb	w20, [sp]
	ldr	w20, [x0, #156]
	ldr	q1, [x0, #144]
	stur	q1, [sp, #4]
	sub	x0, x20, #1
	cmp	x0, #2
	cset	w0, lo
	strb	w0, [sp, #1]
	ands	w0, w7, #0x1
	mov	w7, #2                          ; =0x2
	cinc	w7, w7, eq
	str	w7, [sp, #20]
	cbz	w0, LBB38_14
; %bb.10:
	cmp	w15, #3
	b.eq	LBB38_19
; %bb.11:
	cmp	w15, #1
	b.ne	LBB38_22
; %bb.12:
	cmp	x19, #1
	b.hi	LBB38_25
; %bb.13:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #24]
	str	x19, [sp, #32]
	b	LBB38_29
LBB38_14:
	mov	w15, #36409                     ; =0x8e39
	movk	w15, #14563, lsl #16
	umull	x15, w4, w15
	lsr	x15, x15, #33
	ldr	w15, [x16, x15, lsl #2]
	mov	w16, #7                         ; =0x7
	mov	w0, #9                          ; =0x9
	cmp	w15, #3
	csel	w16, w0, w16, eq
	mov	w0, #11                         ; =0xb
	cmp	w15, #2
	csel	w15, w0, w16, eq
	strb	w15, [sp, #24]
	cmp	w14, #3
	b.eq	LBB38_27
; %bb.15:
	cmp	w14, #2
	b.eq	LBB38_23
; %bb.16:
	cmp	w14, #1
	b.ne	LBB38_25
; %bb.17:
	tbnz	x10, #63, LBB38_25
; %bb.18:
	lsr	w8, w11, #16
	lsr	w9, w11, #8
	mov	w12, w13
	sxtw	x14, w17
	smov.s	x15, v0[0]
	mov	w13, #48                        ; =0x30
	stp	x12, x14, [sp, #32]
	str	x15, [sp, #48]
	mov	w14, #40                        ; =0x28
	mov	w15, #32                        ; =0x20
	mov	w16, #24                        ; =0x18
	mov	x12, x11
	b	LBB38_28
LBB38_19:
	mov	w8, #0                          ; =0x0
	cmp	x19, #0
	cset	w9, ne
	cmp	x19, #255
	b.hi	LBB38_26
; %bb.20:
	and	w9, w2, w9
	tbnz	w9, #0, LBB38_26
; %bb.21:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #24]
	and	x8, x2, #0x1
	stp	x19, x8, [sp, #32]
	b	LBB38_29
LBB38_22:
	cmp	x19, #0
	cset	w8, ne
	orr	w8, w8, w2
	tbnz	w8, #0, LBB38_25
	b	LBB38_29
LBB38_23:
	tbnz	x10, #63, LBB38_25
; %bb.24:
	mov	w13, w13
	str	x13, [sp, #32]
	dup.2s	v0, v0[0]
	mov.s	v0[0], w17
	sshll.2d	v0, v0, #0
	stur	q0, [sp, #40]
	mov	w11, w11
	stp	x10, x11, [sp, #56]
	mov	w10, w5
	mov	w13, #80                        ; =0x50
	stp	x10, x6, [sp, #72]
	mov	w14, #72                        ; =0x48
	mov	w15, #64                        ; =0x40
	mov	w16, #56                        ; =0x38
	mov	x10, x1
	b	LBB38_28
LBB38_25:
	mov	w8, #0                          ; =0x0
LBB38_26:
	mov	x0, x8
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB38_27:
	lsr	w8, w11, #16
	lsr	w9, w11, #8
                                        ; kill: def $w17 killed $w17 killed $x17 def $x17
	sxtw	x12, w17
	mov	w13, w13
	stp	x13, x12, [sp, #32]
	sshll.2d	v0, v0, #0
	sxtw	x12, w10
	mov	w13, #64                        ; =0x40
	mov	w14, #56                        ; =0x38
	str	q0, [sp, #48]
	str	x12, [sp, #64]
	mov	w15, #48                        ; =0x30
	mov	w16, #40                        ; =0x28
	mov	x12, x11
	asr	x10, x10, #32
LBB38_28:
	mov	x11, sp
	add	x11, x11, #32
	str	x10, [x11, x16]
	and	x10, x12, #0x1
	str	x10, [x11, x15]
	and	x9, x9, #0x1
	str	x9, [x11, x14]
	and	x8, x8, #0x1
	str	x8, [x11, x13]
LBB38_29:
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x3, #64]
	ldr	q0, [sp, #96]
	str	q0, [x3, #96]
	ldr	x8, [sp, #112]
	str	x8, [x3, #112]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x3]
	ldp	q0, q1, [sp, #32]
	mov	w8, #1                          ; =0x1
	stp	q0, q1, [x3, #32]
	b	LBB38_26
	.loh AdrpAdd	Lloh66, Lloh67
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_complete_root ; -- Begin function nvm_services_runtime_complete_root
	.p2align	2
_nvm_services_runtime_complete_root:    ; @nvm_services_runtime_complete_root
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB39_3
; %bb.1:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	stp	x9, x10, [sp, #-16]!
	stp	x11, x12, [sp, #-16]!
	mov	w9, #6752                       ; =0x1a60
Lloh68:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh69:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	ldp	x11, x12, [sp], #16
	ldp	x9, x10, [sp], #16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2656
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB39_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB39_53
LBB39_3:
	mov	w0, #1                          ; =0x1
	ret
LBB39_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB39_52
; %bb.5:
	mov	x8, x0
	add	x9, x0, #74, lsl #12            ; =303104
	add	x20, x9, #4064
	ldr	w0, [x20, #40]
	cbnz	w0, LBB39_53
; %bb.6:
	ldrb	w9, [x21, #12]
	tbz	w9, #0, LBB39_9
LBB39_7:
	mov	w0, #5                          ; =0x5
LBB39_8:
	str	w0, [x20, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #48]
	b	LBB39_53
LBB39_9:
	sub	x24, x29, #144
	mov	x0, x8
	ldr	w9, [x8, #24]
	cbz	w9, LBB39_16
; %bb.10:
	ldrb	w9, [x0, #57]
	tbz	w9, #0, LBB39_23
LBB39_11:
	ldrh	w9, [x21, #8]
	cmp	w9, #1
	b.ne	LBB39_37
; %bb.12:
	mov	x19, x1
	ldr	x9, [x20, #24]
	ldr	w1, [x9]
	ldrh	w2, [x9, #4]
	ldrb	w3, [x9, #34]
	mov	x4, sp
	sub	x5, x29, #144
	mov	x0, x8
	mov	x22, x8
	bl	_fr_instruction
	cbz	w0, LBB39_36
; %bb.13:
	ldrb	w8, [sp, #8]
	cmp	w8, #61
	b.ne	LBB39_36
; %bb.14:
	ldrb	w8, [x24, #1]
	tbz	w8, #0, LBB39_36
; %bb.15:
	mov	x0, x22
	mov	x1, x19
LBB39_16:
	mov	x25, x1
	ldr	w19, [x21, #16]
	ldr	w22, [x0, #68]
	sub	x2, x29, #144
	mov	x23, x0
	mov	x1, x19
	bl	_fr_function
	tbz	w0, #0, LBB39_51
; %bb.17:
	cmp	w19, w22
	b.ne	LBB39_26
; %bb.18:
	cmn	w25, #1
	b.ne	LBB39_34
; %bb.19:
	mov	x8, x25
	mov	x9, x23
	ldrb	w10, [x24, #16]
	cbnz	w10, LBB39_34
LBB39_20:
	ldr	w10, [x21, #20]
	cbz	w10, LBB39_41
LBB39_21:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB39_55
; %bb.22:
	mov	w0, #8                          ; =0x8
	b	LBB39_53
LBB39_23:
	ldrh	w9, [x21, #8]
	cbz	x9, LBB39_7
; %bb.24:
	ldr	x10, [x20, #24]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB39_7
; %bb.25:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB39_7
	b	LBB39_11
LBB39_26:
	ldr	w10, [x23, #128]
	cmp	w25, w10
	b.hs	LBB39_34
; %bb.27:
	mov	x8, x25
	ldr	x11, [x20]
	mov	w10, #176                       ; =0xb0
	umaddl	x10, w25, w10, x11
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB39_34
; %bb.28:
	mov	w12, w8
	mov	w13, #176                       ; =0xb0
	umaddl	x12, w12, w13, x11
	ldr	x11, [x12, #4]!
	ldur	x13, [x24, #20]
	eor	x13, x13, x11
	tst	x13, #0xff
	b.ne	LBB39_34
; %bb.29:
	ldur	x14, [x24, #28]
	ldr	x12, [x12, #8]
	and	x13, x13, #0xffffffffffffff00
	and	x13, x13, #0xffffffff0000ffff
	cmp	x13, #0
	ccmp	x12, x14, #0, eq
	b.ne	LBB39_34
; %bb.30:
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB39_34
; %bb.31:
	ldrb	w10, [x10, #2]
	tbnz	w10, #0, LBB39_34
; %bb.32:
	mov	x9, x23
	and	w10, w11, #0xff
	cmp	w10, #1
	b.eq	LBB39_20
; %bb.33:
	cmp	w10, #4
	b.eq	LBB39_20
LBB39_34:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB39_39
; %bb.35:
	mov	w0, #6                          ; =0x6
	b	LBB39_53
LBB39_36:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB39_52
LBB39_37:
	ldr	w8, [x20, #40]
	cbnz	w8, LBB39_52
; %bb.38:
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #48]
	b	LBB39_52
LBB39_39:
	ldr	w8, [x20, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB39_53
; %bb.40:
	str	w0, [x20, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #48]
	b	LBB39_53
LBB39_41:
	ldr	w10, [x9, #132]
	cbz	w10, LBB39_45
; %bb.42:
	ldr	x11, [x20, #8]
LBB39_43:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #64
	cmp	w12, #1
	b.eq	LBB39_21
; %bb.44:                               ;   in Loop: Header=BB39_43 Depth=1
	subs	x10, x10, #1
	b.ne	LBB39_43
LBB39_45:
	ldr	w10, [x9, #128]
	cbz	w10, LBB39_57
; %bb.46:
	ldr	x11, [x20]
	add	x11, x11, #2
	mov	x12, x10
	b	LBB39_48
LBB39_47:                               ;   in Loop: Header=BB39_48 Depth=1
	add	x11, x11, #176
	subs	x12, x12, #1
	b.eq	LBB39_57
LBB39_48:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-2]
	cmp	w13, #1
	b.ne	LBB39_47
; %bb.49:                               ;   in Loop: Header=BB39_48 Depth=1
	ldurb	w13, [x11, #-1]
	tbnz	w13, #0, LBB39_51
; %bb.50:                               ;   in Loop: Header=BB39_48 Depth=1
	ldrb	w13, [x11]
	cmp	w13, #1
	b.ne	LBB39_47
LBB39_51:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB39_54
LBB39_52:
	mov	w0, #5                          ; =0x5
LBB39_53:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2656
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB39_54:
	ldr	w8, [x20, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB39_53
	b	LBB39_8
LBB39_55:
	ldr	w8, [x20, #40]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB39_53
; %bb.56:
	str	w0, [x20, #40]
	mov	w8, #4                          ; =0x4
	str	w8, [x20, #48]
	b	LBB39_53
LBB39_57:
	cmp	w19, w22
	b.ne	LBB39_62
; %bb.58:
	ldr	x0, [x20, #32]
	mov	x1, sp
	bl	_nl_services_values_report
	tbz	w0, #0, LBB39_66
; %bb.59:
	ldr	w8, [sp]
	cbnz	w8, LBB39_69
; %bb.60:
	ldr	x9, [sp, #8]
	cbnz	x9, LBB39_69
; %bb.61:
	ldr	x0, [x20]
	ldr	w10, [x23, #128]
	b	LBB39_63
LBB39_62:
	add	x9, x9, #76, lsl #12            ; =311296
	add	x9, x9, #2608
	ldr	x0, [x20]
	mov	w11, #176                       ; =0xb0
	umaddl	x8, w8, w11, x0
	ldp	q0, q1, [x8, #32]
	ldp	q3, q2, [x8]
	stp	q0, q1, [x9, #32]
	stp	q3, q2, [x9]
	ldp	q1, q0, [x8, #80]
	ldr	x11, [x8, #112]
	ldr	q2, [x8, #64]
	str	x11, [x9, #112]
	stp	q1, q0, [x9, #80]
	str	q2, [x9, #64]
LBB39_63:
	mov	w8, #176                        ; =0xb0
	umull	x1, w10, w8
	bl	_bzero
	ldr	x0, [x20, #24]
	ldrh	w8, [x23, #140]
	add	x8, x8, x8, lsl #2
	lsl	x1, x8, #3
	bl	_bzero
	strh	wzr, [x21, #8]
	cmp	w19, w22
	b.ne	LBB39_65
; %bb.64:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x23, #64]
	str	w8, [x21, #16]
	b	LBB39_53
LBB39_65:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #12]
	b	LBB39_53
LBB39_66:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB39_52
; %bb.67:
	ldr	w8, [x20, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB39_53
; %bb.68:
	mov	w8, #8                          ; =0x8
	b	LBB39_72
LBB39_69:
	ldr	w9, [x21]
	cmp	w9, #2
	b.ne	LBB39_71
; %bb.70:
	mov	w0, #10                         ; =0xa
	b	LBB39_53
LBB39_71:
	ldr	w9, [x20, #40]
	mov	w0, #10                         ; =0xa
	cbnz	w9, LBB39_53
LBB39_72:
	str	w0, [x20, #40]
	str	w8, [x20, #48]
	b	LBB39_53
	.loh AdrpLdrGot	Lloh68, Lloh69
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_function
_fr_function:                           ; @fr_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.eq	LBB40_3
; %bb.1:
	cbnz	w8, LBB40_4
; %bb.2:
	ldr	x0, [x0]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	b	_nvm_services_hosted_function
LBB40_3:
	mov	x19, x2
	ldr	x0, [x0, #16]
	add	x2, sp, #8
	bl	_nvm_services_indirect_hosted_function
	b	LBB40_5
LBB40_4:
	mov	x19, x2
	ldr	x0, [x0, #8]
	add	x2, sp, #8
	bl	_nvm_services_cyclic_hosted_function
LBB40_5:
	ldrb	w8, [sp, #88]
	tst	w8, #0xff
	csel	w0, wzr, w0, ne
	cmp	w0, #1
	b.ne	LBB40_7
; %bb.6:
	ldrh	w8, [sp, #52]
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldr	w9, [sp, #40]
	str	w9, [x19, #32]
	ldur	d0, [sp, #44]
	stur	d0, [x19, #36]
	strh	w8, [x19, #44]
	strh	wzr, [x19, #46]
	ldur	d0, [sp, #60]
	str	d0, [x19, #48]
	ldur	q0, [sp, #72]
	stur	q0, [x19, #56]
LBB40_7:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_finish    ; -- Begin function nvm_services_runtime_finish
	.p2align	2
_nvm_services_runtime_finish:           ; @nvm_services_runtime_finish
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB41_3
; %bb.1:
	ldr	w9, [x0, #24]
	cbz	w9, LBB41_3
; %bb.2:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x0, x8
	mov	w1, #6696                       ; =0x1a28
	mov	x19, x8
	bl	_bzero
	mov	w8, #5                          ; =0x5
	str	w8, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB41_3:
	b	_fr_finish
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_finish
_fr_finish:                             ; @fr_finish
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	mov	w9, #6688                       ; =0x1a20
Lloh70:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh71:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2592
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x8
	cbz	x0, LBB42_3
; %bb.1:
	mov	x22, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x24, x8, #2728
	ldrb	w8, [x24, #10]
	cmp	w8, #1
	b.ne	LBB42_6
; %bb.2:
	mov	x0, x19
	mov	w1, #6696                       ; =0x1a28
	bl	_bzero
	mov	w8, #11                         ; =0xb
	b	LBB42_4
LBB42_3:
	mov	x0, x19
	mov	w1, #6696                       ; =0x1a28
	bl	_bzero
	mov	w8, #1                          ; =0x1
LBB42_4:
	str	w8, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
LBB42_5:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2592
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB42_6:
	mov	x20, x1
	add	x8, x22, #74, lsl #12           ; =303104
	add	x21, x8, #4056
	ldr	w8, [x24]
	cmp	w8, #2
	b.ne	LBB42_11
; %bb.7:
	ldr	w8, [x21, #48]!
	cbz	x20, LBB42_10
; %bb.8:
	cbnz	w8, LBB42_10
; %bb.9:
	add	x8, x22, #76, lsl #12           ; =311296
	add	x8, x8, #2608
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x20, #32]
	stp	q0, q1, [x20]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x20, #112]
	stp	q1, q2, [x20, #80]
	str	q0, [x20, #64]
LBB42_10:
	mov	x0, x19
	mov	x1, x21
	mov	w2, #6696                       ; =0x1a28
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2592
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_memcpy
LBB42_11:
	ldrb	w8, [x24, #12]
	tbnz	w8, #0, LBB42_14
; %bb.12:
	ldr	w8, [x21, #48]
	cbnz	w8, LBB42_14
; %bb.13:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #48]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #56]
LBB42_14:
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #10]
	ldr	w13, [x22, #132]
	cbz	w13, LBB42_53
; %bb.15:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w10, #176                       ; =0xb0
	movi.2d	v0, #0000000000000000
	mov	w11, #5                         ; =0x5
	mov	w12, #8                         ; =0x8
	b	LBB42_19
LBB42_16:                               ;   in Loop: Header=BB42_19 Depth=1
	stp	q0, q0, [x13, #144]
	stp	q0, q0, [x13, #112]
	stp	q0, q0, [x13, #80]
	stp	q0, q0, [x13, #48]
	stp	q0, q0, [x13, #16]
	str	q0, [x13]
	ldr	x14, [x21, #16]
LBB42_17:                               ;   in Loop: Header=BB42_19 Depth=1
	add	x13, x14, x8
	stp	q0, q0, [x13, #32]
	stp	q0, q0, [x13]
	ldr	w13, [x22, #132]
LBB42_18:                               ;   in Loop: Header=BB42_19 Depth=1
	add	x9, x9, #1
	add	x8, x8, #64
	cmp	x9, x13
	b.hs	LBB42_27
LBB42_19:                               ; =>This Inner Loop Header: Depth=1
	ldr	x14, [x21, #16]
	ldrb	w15, [x14, x8]
	cmp	w15, #1
	b.ne	LBB42_18
; %bb.20:                               ;   in Loop: Header=BB42_19 Depth=1
	add	x15, x14, x8
	ldrb	w16, [x15, #1]
	cmp	w16, #1
	b.ne	LBB42_18
; %bb.21:                               ;   in Loop: Header=BB42_19 Depth=1
	ldr	w13, [x15, #12]
	ldr	w15, [x22, #128]
	cmp	w13, w15
	b.hs	LBB42_24
; %bb.22:                               ;   in Loop: Header=BB42_19 Depth=1
	ldr	x15, [x21, #8]
	umaddl	x13, w13, w10, x15
	ldrb	w15, [x13, #2]
	cmp	w15, #1
	b.ne	LBB42_24
; %bb.23:                               ;   in Loop: Header=BB42_19 Depth=1
	ldr	w15, [x13, #152]
	cmp	x9, x15
	b.eq	LBB42_16
LBB42_24:                               ;   in Loop: Header=BB42_19 Depth=1
	ldr	w13, [x24]
	cmp	w13, #2
	b.eq	LBB42_17
; %bb.25:                               ;   in Loop: Header=BB42_19 Depth=1
	ldr	w13, [x21, #48]
	cbnz	w13, LBB42_17
; %bb.26:                               ;   in Loop: Header=BB42_19 Depth=1
	str	w11, [x21, #48]
	str	w12, [x21, #56]
	b	LBB42_17
LBB42_27:
	ldrb	w8, [x24, #11]
	tbz	w8, #0, LBB42_77
; %bb.28:
	cbz	x13, LBB42_54
; %bb.29:
	mov	x23, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	b	LBB42_32
LBB42_30:                               ;   in Loop: Header=BB42_32 Depth=1
	ldr	x8, [x21, #16]
	add	x8, x8, x23
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	ldr	w13, [x22, #132]
LBB42_31:                               ;   in Loop: Header=BB42_32 Depth=1
	add	x25, x25, #1
	add	x23, x23, #64
	cmp	x25, x13
	b.hs	LBB42_54
LBB42_32:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21, #16]
	ldrb	w9, [x8, x23]
	cmp	w9, #1
	b.ne	LBB42_31
; %bb.33:                               ;   in Loop: Header=BB42_32 Depth=1
	add	x8, x8, x23
	ldrb	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB42_35
; %bb.34:                               ;   in Loop: Header=BB42_32 Depth=1
	ldr	w9, [x8, #8]
	cmp	x25, x9
	b.ne	LBB42_30
LBB42_35:                               ;   in Loop: Header=BB42_32 Depth=1
	ldr	x0, [x21, #40]
	add	x1, x8, #24
	bl	_nl_services_value_end_borrow
	cmp	w0, #2
	b.le	LBB42_40
; %bb.36:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #4
	b.gt	LBB42_44
; %bb.37:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #3
	b.eq	LBB42_48
; %bb.38:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #4
	b.ne	LBB42_47
; %bb.39:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB42_50
LBB42_40:                               ;   in Loop: Header=BB42_32 Depth=1
	cbz	w0, LBB42_30
; %bb.41:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB42_50
; %bb.42:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #2
	b.ne	LBB42_47
; %bb.43:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB42_50
LBB42_44:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #5
	b.eq	LBB42_49
; %bb.45:                               ;   in Loop: Header=BB42_32 Depth=1
	cmp	w0, #6
	b.ne	LBB42_47
; %bb.46:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB42_50
LBB42_47:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB42_50
LBB42_48:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #6                          ; =0x6
	b	LBB42_50
LBB42_49:                               ;   in Loop: Header=BB42_32 Depth=1
	mov	w8, #3                          ; =0x3
LBB42_50:                               ;   in Loop: Header=BB42_32 Depth=1
	ldr	w9, [x24]
	cmp	w9, #2
	b.eq	LBB42_30
; %bb.51:                               ;   in Loop: Header=BB42_32 Depth=1
	ldr	w9, [x21, #48]
	cbnz	w9, LBB42_30
; %bb.52:                               ;   in Loop: Header=BB42_32 Depth=1
	str	w8, [x21, #48]
	str	w0, [x21, #56]
	b	LBB42_30
LBB42_53:
	ldrb	w8, [x24, #11]
	tbz	w8, #0, LBB42_77
LBB42_54:
	ldr	w8, [x22, #128]
	cbz	w8, LBB42_79
; %bb.55:
	mov	x23, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	b	LBB42_57
LBB42_56:                               ;   in Loop: Header=BB42_57 Depth=1
	ldr	x8, [x21, #8]
	add	x8, x8, x23
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	add	x25, x25, #1
	ldr	w8, [x22, #128]
	add	x23, x23, #176
	cmp	x25, x8
	b.hs	LBB42_79
LBB42_57:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21, #8]
	ldrb	w9, [x8, x23]
	cmp	w9, #1
	b.ne	LBB42_56
; %bb.58:                               ;   in Loop: Header=BB42_57 Depth=1
	add	x8, x8, x23
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB42_56
; %bb.59:                               ;   in Loop: Header=BB42_57 Depth=1
	ldr	x0, [x21, #40]
	add	x1, x8, #120
	bl	_nl_services_value_drop
	cmp	w0, #2
	b.le	LBB42_64
; %bb.60:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #4
	b.gt	LBB42_68
; %bb.61:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #3
	movi.2d	v0, #0000000000000000
	b.eq	LBB42_72
; %bb.62:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #4
	b.ne	LBB42_71
; %bb.63:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB42_74
LBB42_64:                               ;   in Loop: Header=BB42_57 Depth=1
	movi.2d	v0, #0000000000000000
	cbz	w0, LBB42_56
; %bb.65:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB42_74
; %bb.66:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #2
	b.ne	LBB42_71
; %bb.67:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB42_74
LBB42_68:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #5
	movi.2d	v0, #0000000000000000
	b.eq	LBB42_73
; %bb.69:                               ;   in Loop: Header=BB42_57 Depth=1
	cmp	w0, #6
	b.ne	LBB42_71
; %bb.70:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB42_74
LBB42_71:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB42_74
LBB42_72:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #6                          ; =0x6
	b	LBB42_74
LBB42_73:                               ;   in Loop: Header=BB42_57 Depth=1
	mov	w8, #3                          ; =0x3
LBB42_74:                               ;   in Loop: Header=BB42_57 Depth=1
	ldr	w9, [x24]
	cmp	w9, #2
	b.eq	LBB42_56
; %bb.75:                               ;   in Loop: Header=BB42_57 Depth=1
	ldr	w9, [x21, #48]
	cbnz	w9, LBB42_56
; %bb.76:                               ;   in Loop: Header=BB42_57 Depth=1
	str	w8, [x21, #48]
	str	w0, [x21, #56]
	b	LBB42_56
LBB42_77:
	ldr	w8, [x21, #56]
	mov	w9, #45072                      ; =0xb010
	movk	w9, #4, lsl #16
	add	x9, x9, #16
LBB42_78:
	str	w8, [x22, x9]
	b	LBB42_88
LBB42_79:
	ldr	w8, [x21, #48]
	cbz	w8, LBB42_81
; %bb.80:
	ldr	w8, [x21, #56]
	mov	w9, #8                          ; =0x8
	cmp	w8, #0
	csel	w23, w9, w8, eq
	b	LBB42_82
LBB42_81:
	mov	w23, #0                         ; =0x0
LBB42_82:
	ldr	x8, [x21, #40]
	stur	x8, [x29, #-72]
	add	x0, sp, #8
	mov	w1, #6672                       ; =0x1a10
	bl	_bzero
	sub	x0, x29, #72
	add	x2, sp, #8
	mov	x1, x23
	bl	_nl_services_values_destroy
	cbz	w0, LBB42_84
; %bb.83:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #8]
LBB42_84:
	add	x0, x21, #72
	add	x1, sp, #8
	mov	w2, #6672                       ; =0x1a10
	bl	_memcpy
	str	xzr, [x21, #40]
	ldr	w8, [x21, #48]
	cbnz	w8, LBB42_88
; %bb.85:
	ldur	w8, [x21, #72]
	cbnz	w8, LBB42_87
; %bb.86:
	ldr	x9, [x21, #80]
	cbz	x9, LBB42_88
LBB42_87:
	ldr	w9, [x24]
	cmp	w9, #2
	b.ne	LBB42_95
LBB42_88:
	ldr	x0, [x21, #24]
	ldr	w8, [x22, #136]
	lsl	x1, x8, #3
	bl	_bzero
	str	wzr, [x24, #20]
	ldr	w8, [x21]
	cbz	w8, LBB42_91
; %bb.89:
	mov	x23, #0                         ; =0x0
	add	x8, x22, #66, lsl #12           ; =270336
	add	x25, x8, #4056
LBB42_90:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x25, x23, lsl #3]
	bl	_free
	str	xzr, [x25, x23, lsl #3]
	add	x23, x23, #1
	ldr	w8, [x21]
	cmp	x23, x8
	b.lo	LBB42_90
LBB42_91:
	str	wzr, [x21]
	strh	wzr, [x24, #8]
	strb	wzr, [x24, #10]
	mov	w8, #2                          ; =0x2
	str	w8, [x24]
	ldr	w8, [x21, #48]!
	cbz	x20, LBB42_94
; %bb.92:
	cbnz	w8, LBB42_94
; %bb.93:
	add	x8, x22, #76, lsl #12           ; =311296
	add	x8, x8, #2608
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x20, #32]
	stp	q0, q1, [x20]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x20, #112]
	stp	q1, q2, [x20, #80]
	str	q0, [x20, #64]
LBB42_94:
	mov	x0, x19
	mov	x1, x21
	mov	w2, #6696                       ; =0x1a28
	bl	_memcpy
	b	LBB42_5
LBB42_95:
	mov	w9, #45072                      ; =0xb010
	movk	w9, #4, lsl #16
	mov	w10, #10                        ; =0xa
	str	w10, [x21, #48]
	b	LBB42_78
	.loh AdrpLdrGot	Lloh70, Lloh71
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_destroy   ; -- Begin function nvm_services_runtime_destroy
	.p2align	2
_nvm_services_runtime_destroy:          ; @nvm_services_runtime_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB43_4
; %bb.1:
	ldr	x20, [x0]
	cbz	x20, LBB43_4
; %bb.2:
	ldr	w8, [x20, #24]
	cbz	w8, LBB43_7
; %bb.3:
	mov	x0, x19
	mov	w1, #6696                       ; =0x1a28
	bl	_bzero
	mov	w8, #5                          ; =0x5
	b	LBB43_5
LBB43_4:
	mov	x0, x19
	mov	w1, #6696                       ; =0x1a28
	bl	_bzero
	mov	w8, #1                          ; =0x1
LBB43_5:
	str	w8, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
LBB43_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB43_7:
	add	x8, x20, #76, lsl #12           ; =311296
	ldrb	w8, [x8, #2738]
	cmp	w8, #1
	b.ne	LBB43_9
; %bb.8:
	mov	x0, x19
	mov	w1, #6696                       ; =0x1a28
	bl	_bzero
	mov	w8, #11                         ; =0xb
	b	LBB43_5
LBB43_9:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x21, x8, #4064
	mov	x8, x19
	mov	x19, x0
	mov	x0, x20
	bl	_fr_finish
	ldr	x0, [x21, #24]
	bl	_free
	ldr	x0, [x21, #16]
	bl	_free
	ldr	x0, [x21, #8]
	bl	_free
	ldr	x0, [x21]
	bl	_free
	ldr	x0, [x20]
	bl	_nvm_services_hosted_free
	mov	x0, x20
	bl	_free
	str	xzr, [x19]
	b	LBB43_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_start ; -- Begin function nvm_services_runtime_frame_start
	.p2align	2
_nvm_services_runtime_frame_start:      ; @nvm_services_runtime_frame_start
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB44_3
; %bb.1:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #800
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x20, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	ldrb	w8, [x22, #10]
	tbz	w8, #0, LBB44_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB44_14
LBB44_3:
	mov	w0, #1                          ; =0x1
	ret
LBB44_4:
	ldr	w8, [x22]
	cmp	w8, #1
	b.ne	LBB44_13
; %bb.5:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x21, x8, #4064
	ldr	w0, [x21, #40]
	cbnz	w0, LBB44_14
; %bb.6:
	ldrb	w8, [x22, #12]
	cmp	w8, #1
	b.ne	LBB44_9
; %bb.7:
	mov	w0, #5                          ; =0x5
LBB44_8:
	str	w0, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
	b	LBB44_14
LBB44_9:
	ldrb	w8, [x22, #11]
	cmp	w8, #1
	b.ne	LBB44_12
; %bb.10:
	ldrh	w8, [x22, #8]
	cbnz	w8, LBB44_12
; %bb.11:
	ldr	w8, [x22, #20]
	cbz	w8, LBB44_16
LBB44_12:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB44_15
LBB44_13:
	mov	w0, #5                          ; =0x5
LBB44_14:
	add	sp, sp, #800
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB44_15:
	ldr	w8, [x21, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB44_14
	b	LBB44_8
LBB44_16:
	ldrh	w8, [x20, #140]
	cbz	w8, LBB44_12
; %bb.17:
	ldr	w19, [x22, #16]
	add	x2, sp, #8
	mov	x0, x20
	mov	x1, x19
	bl	_fr_function
	cbz	w0, LBB44_12
; %bb.18:
	ldrh	w10, [sp, #50]
	cbz	x10, LBB44_12
; %bb.19:
	ldrh	w9, [sp, #48]
	ldrh	w11, [sp, #22]
	cmp	w9, w11
	b.ne	LBB44_12
; %bb.20:
	mov	x8, x20
	ldr	w11, [x22, #4]
	cmp	w11, #0
	mov	w11, #64                        ; =0x40
	mov	w12, #56                        ; =0x38
	csel	x11, x12, x11, eq
	add	x12, sp, #8
	ldr	x12, [x12, x11]
	ldr	w11, [x20, #128]
	cmp	x12, x11
	b.hi	LBB44_12
; %bb.21:
	add	x10, x9, x10
	subs	x11, x11, x10
	b.lo	LBB44_12
; %bb.22:
	ldrh	w12, [sp, #46]
	cmp	x11, x12
	b.lo	LBB44_12
; %bb.23:
	ldr	w11, [x8, #132]
	cmp	w11, #256
	b.lo	LBB44_12
; %bb.24:
	ldrh	w11, [sp, #52]
	ldrh	w12, [x8, #140]
	cmp	w12, w11
	b.lo	LBB44_12
; %bb.25:
	ldr	w11, [x22, #20]
	stp	w19, wzr, [sp, #80]
	stp	wzr, w10, [sp, #88]
	stp	wzr, w9, [sp, #96]
	stp	wzr, w11, [sp, #104]
	str	xzr, [sp, #112]
	ldrh	w9, [sp, #20]
	cbnz	w9, LBB44_12
; %bb.26:
	ldr	w1, [x22, #16]
	add	x4, sp, #200
	add	x5, sp, #120
	mov	x0, x8
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_fr_instruction
	cbz	w0, LBB44_12
; %bb.27:
	ldrb	w8, [sp, #120]
	tbz	w8, #0, LBB44_12
; %bb.28:
	ldrh	w9, [sp, #124]
	cbnz	w9, LBB44_12
; %bb.29:
	ldr	w8, [x20, #128]
	cbz	w8, LBB44_33
; %bb.30:
	ldr	x9, [x21]
LBB44_31:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #176
	tbnz	w10, #0, LBB44_12
; %bb.32:                               ;   in Loop: Header=BB44_31 Depth=1
	subs	x8, x8, #1
	b.ne	LBB44_31
LBB44_33:
	ldr	w8, [x20, #132]
	cbz	w8, LBB44_37
; %bb.34:
	ldr	x9, [x21, #8]
LBB44_35:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #64
	cmp	w10, #1
	b.eq	LBB44_12
; %bb.36:                               ;   in Loop: Header=BB44_35 Depth=1
	subs	x8, x8, #1
	b.ne	LBB44_35
LBB44_37:
	ldr	x8, [x21, #24]
	ldp	q0, q1, [sp, #80]
	stp	q0, q1, [x8]
	ldr	x9, [sp, #112]
	str	x9, [x8, #32]
	mov	w8, #1                          ; =0x1
	strh	w8, [x22, #8]
	ldr	w8, [x20, #24]
	cbz	w8, LBB44_40
; %bb.38:
	add	x1, sp, #80
	mov	x0, x20
	bl	_frc_validate
	cbz	w0, LBB44_40
; %bb.39:
	ldr	w0, [x21, #40]
	b	LBB44_14
LBB44_40:
	mov	x0, x20
	mov	x1, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_services_runtime_site
	b	LBB44_14
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_layout
_frf_layout:                            ; @frf_layout
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x0, #140]
	cmp	w3, w8
	b.hs	LBB45_9
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x5
	mov	x20, x3
	mov	x23, x2
	mov	x21, x4
	mov	x24, x0
	mov	x22, x1
	mov	x2, x5
	bl	_fr_function
	cbz	w0, LBB45_8
; %bb.2:
	ldrh	w12, [x19, #42]
	cbz	x12, LBB45_7
; %bb.3:
	ldrh	w11, [x19, #40]
	ldrh	w8, [x19, #14]
	cmp	w11, w8
	b.ne	LBB45_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	add	x8, x24, #76, lsl #12           ; =311296
	ldr	w9, [x8, #2732]
	cmp	w9, #0
	mov	w9, #64                         ; =0x40
	mov	w13, #56                        ; =0x38
	csel	x14, x13, x9, eq
	ldr	w13, [x24, #128]
	subs	x15, x13, x23
	b.lo	LBB45_8
; %bb.5:
	mov	x9, x23
	ldr	x14, [x19, x14]
	add	x11, x23, x11
	add	x12, x11, x12
	cmp	x14, x15
	ccmp	x13, x12, #0, ls
	b.lo	LBB45_8
; %bb.6:
	ldrh	w14, [x19, #38]
	sub	x13, x13, x12
	cmp	x13, x14
	b.hs	LBB45_10
LBB45_7:
	mov	w0, #0                          ; =0x0
LBB45_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB45_9:
	mov	w0, #0                          ; =0x0
	ret
LBB45_10:
	mov	x10, x24
	mov	w0, #0                          ; =0x0
	ubfiz	x13, x20, #8, #32
	ldr	w14, [x24, #132]
	subs	x14, x14, x13
	b.lo	LBB45_8
; %bb.11:
	cmp	x14, #256
	b.lo	LBB45_8
; %bb.12:
	ldrh	w14, [x19, #44]
	ldrh	w10, [x10, #140]
	sub	w10, w10, w20
	cmp	w10, w14
	b.lt	LBB45_7
; %bb.13:
	ldr	w8, [x8, #2748]
	stp	w22, wzr, [x21]
	stp	w9, w12, [x21, #8]
	stp	wzr, w11, [x21, #16]
	stp	w13, w8, [x21, #24]
	str	xzr, [x21, #32]
	mov	w0, #1                          ; =0x1
	b	LBB45_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_empty_range
_frf_empty_range:                       ; @frf_empty_range
	.cfi_startproc
; %bb.0:
	mov	w11, w1
	mov	w8, w2
	ldr	w9, [x0, #128]
	sub	x10, x9, x11
	subs	w9, w9, w1
	ccmp	x10, x8, #0, hs
	b.hs	LBB46_2
LBB46_1:
	mov	w0, #0                          ; =0x0
	ret
LBB46_2:
	cbz	w2, LBB46_7
; %bb.3:
	mov	w10, #45024                     ; =0xafe0
	movk	w10, #4, lsl #16
	mov	w12, #176                       ; =0xb0
	umull	x11, w11, w12
LBB46_4:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB46_1
; %bb.5:                                ;   in Loop: Header=BB46_4 Depth=1
	ldr	x12, [x0, x10]
	ldrb	w12, [x12, x11]
	cmp	w12, #1
	b.eq	LBB46_1
; %bb.6:                                ;   in Loop: Header=BB46_4 Depth=1
	add	x11, x11, #176
	sub	x9, x9, #1
	subs	x8, x8, #1
	b.ne	LBB46_4
LBB46_7:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_validate
_frc_validate:                          ; @frc_validate
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1776
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh72:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh73:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh74:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	add	x8, x0, #74, lsl #12            ; =303104
	add	x21, x8, #4064
	ldr	w8, [x0, #24]
	cbz	w8, LBB47_9
; %bb.1:
	ldr	x8, [x0, #32]
	cbz	x8, LBB47_9
; %bb.2:
	ldrh	w8, [x22, #8]
	cbz	w8, LBB47_9
; %bb.3:
	ldrh	w9, [x0, #140]
	cmp	w8, w9
	b.hi	LBB47_9
; %bb.4:
	mov	x23, x22
	ldr	w8, [x23, #20]!
	ldr	w9, [x0, #136]
	cmp	w8, w9
	b.hi	LBB47_9
; %bb.5:
	ldrb	w8, [x22, #11]
	cmp	w8, #1
	b.ne	LBB47_9
; %bb.6:
	ldr	x8, [x21, #32]
	cbz	x8, LBB47_9
; %bb.7:
	str	x1, [sp]                        ; 8-byte Folded Spill
	add	x8, sp, #720
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #992]
	stp	q0, q0, [x8, #960]
	stp	q0, q0, [x8, #928]
	stp	q0, q0, [x8, #896]
	stp	q0, q0, [x8, #864]
	stp	q0, q0, [x8, #832]
	stp	q0, q0, [x8, #800]
	stp	q0, q0, [x8, #768]
	stp	q0, q0, [x8, #736]
	stp	q0, q0, [x8, #704]
	stp	q0, q0, [x8, #672]
	stp	q0, q0, [x8, #640]
	stp	q0, q0, [x8, #608]
	stp	q0, q0, [x8, #576]
	stp	q0, q0, [x8, #544]
	stp	q0, q0, [x8, #512]
	stp	q0, q0, [x8, #480]
	stp	q0, q0, [x8, #448]
	stp	q0, q0, [x8, #416]
	stp	q0, q0, [x8, #384]
	stp	q0, q0, [x8, #352]
	stp	q0, q0, [x8, #320]
	stp	q0, q0, [x8, #288]
	stp	q0, q0, [x8, #256]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	ldr	w8, [x0, #128]
	mov	x19, x0
	cbz	w8, LBB47_39
; %bb.8:
	mov	x25, #0                         ; =0x0
	mov	w28, #176                       ; =0xb0
	b	LBB47_17
LBB47_9:
	ldr	w8, [x22]
	cmp	w8, #2
	b.ne	LBB47_11
; %bb.10:
	mov	w0, #5                          ; =0x5
	b	LBB47_13
LBB47_11:
	ldr	w8, [x21, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB47_13
; %bb.12:
	str	w0, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
LBB47_13:
	ldur	x8, [x29, #-104]
Lloh75:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh76:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh77:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB47_121
; %bb.14:
	add	sp, sp, #1776
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB47_15:                               ;   in Loop: Header=BB47_17 Depth=1
	orr	x8, x26, x27
	add	x9, sp, #1232
	str	x8, [x9, w24, uxtw #3]
	mov	x0, x19
LBB47_16:                               ;   in Loop: Header=BB47_17 Depth=1
	add	x25, x25, #1
	ldr	w8, [x0, #128]
	cmp	x25, x8
	b.hs	LBB47_39
LBB47_17:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB47_21 Depth 2
                                        ;       Child Loop BB47_23 Depth 3
	ldr	x8, [x21]
	madd	x20, x25, x28, x8
	mov	x1, x20
	bl	_frc_payload
	tbz	w0, #0, LBB47_68
; %bb.18:                               ;   in Loop: Header=BB47_17 Depth=1
	ldrb	w8, [x20]
	cmp	w8, #1
	mov	x0, x19
	b.ne	LBB47_16
; %bb.19:                               ;   in Loop: Header=BB47_17 Depth=1
	ldrh	w8, [x22, #8]
	ldr	x24, [sp]                       ; 8-byte Folded Reload
	cbz	w8, LBB47_68
; %bb.20:                               ;   in Loop: Header=BB47_17 Depth=1
	mov	x27, #0                         ; =0x0
	mov	w28, #0                         ; =0x0
LBB47_21:                               ;   Parent Loop BB47_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB47_23 Depth 3
	add	x9, x27, x27, lsl #2
	add	x27, x27, #1
	lsl	x26, x9, #3
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB47_23
LBB47_22:                               ;   in Loop: Header=BB47_23 Depth=3
	ldrh	w8, [x22, #8]
	add	x26, x26, #40
	cmp	x27, x8
	add	x27, x27, #1
	mov	x0, x19
	ldr	x24, [sp]                       ; 8-byte Folded Reload
	b.hs	LBB47_31
LBB47_23:                               ;   Parent Loop BB47_17 Depth=1
                                        ;     Parent Loop BB47_21 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	w27, w8, uxth
	b.eq	LBB47_25
; %bb.24:                               ;   in Loop: Header=BB47_23 Depth=3
	ldr	x8, [x21, #24]
	add	x24, x8, x26
LBB47_25:                               ;   in Loop: Header=BB47_23 Depth=3
	ldr	w1, [x24]
	add	x2, sp, #8
	bl	_fr_function
	tbz	w0, #0, LBB47_111
; %bb.26:                               ;   in Loop: Header=BB47_23 Depth=3
	ldr	w8, [x24, #8]
	cmp	x25, x8
	b.lo	LBB47_28
; %bb.27:                               ;   in Loop: Header=BB47_23 Depth=3
	ldrh	w9, [sp, #48]
	sub	w8, w25, w8
	cmp	w8, w9
	b.lo	LBB47_30
LBB47_28:                               ;   in Loop: Header=BB47_23 Depth=3
	ldr	w8, [x24, #12]
	cmp	x25, x8
	b.lo	LBB47_22
; %bb.29:                               ;   in Loop: Header=BB47_23 Depth=3
	ldr	w9, [x24, #16]
	sub	w8, w25, w8
	cmp	w8, w9
	b.hs	LBB47_22
LBB47_30:                               ;   in Loop: Header=BB47_21 Depth=2
	ldrh	w8, [x22, #8]
	mov	w28, #1                         ; =0x1
	cmp	x27, x8
	mov	x0, x19
	ldr	x24, [sp]                       ; 8-byte Folded Reload
	b.lo	LBB47_21
	b	LBB47_32
LBB47_31:                               ;   in Loop: Header=BB47_17 Depth=1
	tbz	w28, #0, LBB47_68
LBB47_32:                               ;   in Loop: Header=BB47_17 Depth=1
	ldrb	w8, [x20]
	cmp	w8, #1
	mov	w28, #176                       ; =0xb0
	b.ne	LBB47_16
; %bb.33:                               ;   in Loop: Header=BB47_17 Depth=1
	ldrb	w8, [x20, #1]
	cmp	w8, #1
	b.ne	LBB47_16
; %bb.34:                               ;   in Loop: Header=BB47_17 Depth=1
	mov	x1, x20
	ldr	w8, [x1, #120]!
	sub	w24, w8, #1
	ldr	w8, [x0, #9616]
	cmp	w24, w8
	b.hs	LBB47_68
; %bb.35:                               ;   in Loop: Header=BB47_17 Depth=1
	ldr	w8, [x1, #24]
	cmp	w8, #63
	b.hi	LBB47_68
; %bb.36:                               ;   in Loop: Header=BB47_17 Depth=1
	add	x9, sp, #1232
	ldr	x26, [x9, w24, uxtw #3]
	mov	w9, #1                          ; =0x1
	lsl	x27, x9, x8
	tst	x26, x27
	b.ne	LBB47_68
; %bb.37:                               ;   in Loop: Header=BB47_17 Depth=1
	ldr	x0, [x21, #32]
	ldr	w8, [x20, #16]
	cmp	w8, #2
	cset	w2, eq
	bl	_nl_services_value_validate
	cbz	w0, LBB47_15
LBB47_38:
	mov	x1, x0
	mov	x0, x19
	bl	_fr_core
	mov	x8, x0
	b	LBB47_115
LBB47_39:
	ldr	w8, [x23]
	cbz	w8, LBB47_46
; %bb.40:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x21, #16]
	b	LBB47_42
LBB47_41:                               ;   in Loop: Header=BB47_42 Depth=1
	add	x9, x9, #1
	cmp	w9, w8
	b.eq	LBB47_46
LBB47_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB47_44 Depth 2
	ldr	x11, [x10, w9, uxtw #3]
	cbz	x11, LBB47_68
; %bb.43:                               ;   in Loop: Header=BB47_42 Depth=1
	mov	x12, x9
	mov	x13, x10
	cbz	w9, LBB47_41
LBB47_44:                               ;   Parent Loop BB47_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x14, [x13], #8
	cmp	x14, x11
	b.eq	LBB47_67
; %bb.45:                               ;   in Loop: Header=BB47_44 Depth=2
	subs	x12, x12, #1
	b.ne	LBB47_44
	b	LBB47_41
LBB47_46:
	ldr	w10, [x0, #136]
	cmp	w8, w10
	b.hs	LBB47_50
; %bb.47:
	ldr	x9, [x21, #16]
	add	x9, x9, x8, lsl #3
	sub	x8, x10, x8
LBB47_48:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9], #8
	cbnz	x10, LBB47_68
; %bb.49:                               ;   in Loop: Header=BB47_48 Depth=1
	subs	x8, x8, #1
	b.ne	LBB47_48
LBB47_50:
	ldrh	w9, [x22, #8]
	ldr	w8, [x0, #132]
	cmp	w8, w9, lsl #8
	ldr	x20, [sp]                       ; 8-byte Folded Reload
	b.ls	LBB47_65
; %bb.51:
	ldr	x11, [x21, #8]
	sub	x10, x8, x9, lsl #8
	add	x11, x11, x9, lsl #14
	add	x11, x11, #28
LBB47_52:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w12, [x11, #-28]
	tbnz	w12, #0, LBB47_68
; %bb.53:                               ;   in Loop: Header=BB47_52 Depth=1
	ldurb	w12, [x11, #-27]
	tbnz	w12, #0, LBB47_68
; %bb.54:                               ;   in Loop: Header=BB47_52 Depth=1
	ldurb	w12, [x11, #-26]
	tbnz	w12, #0, LBB47_68
; %bb.55:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	w12, [x11, #-24]
	cbnz	w12, LBB47_68
; %bb.56:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	w12, [x11, #-20]
	cbnz	w12, LBB47_68
; %bb.57:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	w12, [x11, #-16]
	cbnz	w12, LBB47_68
; %bb.58:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	x12, [x11, #-12]
	cbnz	x12, LBB47_68
; %bb.59:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	x12, [x11, #28]
	cbnz	x12, LBB47_68
; %bb.60:                               ;   in Loop: Header=BB47_52 Depth=1
	ldp	w13, w12, [x11, #-4]
	orr	w12, w13, w12
	cbnz	w12, LBB47_67
; %bb.61:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	x12, [x11, #4]
	cbnz	x12, LBB47_67
; %bb.62:                               ;   in Loop: Header=BB47_52 Depth=1
	ldur	x12, [x11, #12]
	cbnz	x12, LBB47_67
; %bb.63:                               ;   in Loop: Header=BB47_52 Depth=1
	ldr	w12, [x11, #20]
	cbnz	w12, LBB47_67
; %bb.64:                               ;   in Loop: Header=BB47_52 Depth=1
	add	x11, x11, #64
	subs	x10, x10, #1
	b.ne	LBB47_52
LBB47_65:
	cbz	w8, LBB47_79
; %bb.66:
	mov	x10, #0                         ; =0x0
	ldr	x11, [x21, #8]
	add	x12, sp, #720
	mov	w13, #1                         ; =0x1
	b	LBB47_73
LBB47_67:
	cbz	x0, LBB47_114
LBB47_68:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB47_114
; %bb.69:
	ldr	w9, [x21, #40]
	mov	w8, #5                          ; =0x5
	cbnz	w9, LBB47_115
; %bb.70:
	str	w8, [x21, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x21, #48]
	b	LBB47_115
LBB47_71:                               ;   in Loop: Header=BB47_73 Depth=1
	orr	x15, x16, x15
	str	x15, [x12, w14, uxtw #3]
LBB47_72:                               ;   in Loop: Header=BB47_73 Depth=1
	add	x10, x10, #1
	add	x11, x11, #64
	cmp	x8, x10
	b.eq	LBB47_79
LBB47_73:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w14, [x11]
	cmp	w14, #1
	b.ne	LBB47_72
; %bb.74:                               ;   in Loop: Header=BB47_73 Depth=1
	ldrb	w14, [x11, #1]
	tbnz	w14, #0, LBB47_72
; %bb.75:                               ;   in Loop: Header=BB47_73 Depth=1
	ldr	w14, [x11, #8]
	cmp	x10, x14
	b.ne	LBB47_72
; %bb.76:                               ;   in Loop: Header=BB47_73 Depth=1
	ldr	w14, [x11, #24]
	sub	w14, w14, #1
	ldr	w15, [x0, #9616]
	cmp	w14, w15
	b.hs	LBB47_68
; %bb.77:                               ;   in Loop: Header=BB47_73 Depth=1
	ldr	w15, [x11, #48]
	cmp	w15, #63
	b.hi	LBB47_68
; %bb.78:                               ;   in Loop: Header=BB47_73 Depth=1
	ldr	x16, [x12, w14, uxtw #3]
	lsl	x15, x13, x15
	tst	x16, x15
	b.eq	LBB47_71
	b	LBB47_68
LBB47_79:
	ldr	w8, [x0, #9616]
	cbz	w8, LBB47_86
; %bb.80:
	mov	x20, #0                         ; =0x0
	add	x24, sp, #1232
	add	x25, sp, #720
LBB47_81:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21, #32]
	add	x2, sp, #8
	add	x3, sp, #608
	mov	x1, x20
	bl	_nl_services_values_live_slots
	cbnz	w0, LBB47_38
; %bb.82:                               ;   in Loop: Header=BB47_81 Depth=1
	ldr	x8, [x24, x20, lsl #3]
	ldr	x9, [sp, #8]
	cmp	x8, x9
	b.ne	LBB47_116
; %bb.83:                               ;   in Loop: Header=BB47_81 Depth=1
	ldr	x8, [x25, x20, lsl #3]
	ldr	x9, [sp, #608]
	cmp	x8, x9
	b.ne	LBB47_116
; %bb.84:                               ;   in Loop: Header=BB47_81 Depth=1
	mov	x0, x19
	add	x20, x20, #1
	ldr	w8, [x19, #9616]
	cmp	x20, x8
	b.lo	LBB47_81
; %bb.85:
	ldrh	w9, [x22, #8]
	ldr	x20, [sp]                       ; 8-byte Folded Reload
LBB47_86:
	cbz	w9, LBB47_120
; %bb.87:
	mov	w25, #0                         ; =0x0
	mov	x2, #0                          ; =0x0
	mov	w24, #40                        ; =0x28
LBB47_88:                               ; =>This Inner Loop Header: Depth=1
	and	w3, w25, #0xffff
	add	w27, w3, #1
	cmp	w27, w9, uxth
	b.eq	LBB47_90
; %bb.89:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	x8, [x21, #24]
	and	x9, x25, #0xffff
	umaddl	x20, w9, w24, x8
LBB47_90:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w1, [x20]
	add	x4, sp, #680
	add	x5, sp, #608
	bl	_frf_layout
	cbz	w0, LBB47_111
; %bb.91:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x20, #8]
	ldr	w9, [sp, #688]
	cmp	w8, w9
	b.ne	LBB47_111
; %bb.92:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w28, [x20, #12]
	ldr	w8, [sp, #692]
	cmp	x28, x8
	b.ne	LBB47_111
; %bb.93:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x20, #20]
	ldr	w9, [sp, #700]
	cmp	w8, w9
	b.ne	LBB47_111
; %bb.94:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x20, #24]
	ldr	w9, [sp, #704]
	cmp	w8, w9
	b.ne	LBB47_111
; %bb.95:                               ;   in Loop: Header=BB47_88 Depth=1
	tst	w25, #0xffff
	b.ne	LBB47_97
; %bb.96:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x20, #28]
	cbnz	w8, LBB47_111
LBB47_97:                               ;   in Loop: Header=BB47_88 Depth=1
	ldrh	w8, [x22, #8]
	cmp	w27, w8
	b.hs	LBB47_102
; %bb.98:                               ;   in Loop: Header=BB47_88 Depth=1
	mov	x0, x19
	ldr	w1, [x20]
	ldrh	w2, [x20, #4]
	add	x3, sp, #8
	bl	_fr_code
	cbz	w0, LBB47_111
; %bb.99:                               ;   in Loop: Header=BB47_88 Depth=1
	ldr	x8, [x21, #24]
	umull	x9, w27, w24
	ldr	w3, [x8, x9]
	add	x2, sp, #8
	mov	x0, x19
	mov	x1, x20
	bl	_fr_call_target
	cbz	w0, LBB47_111
; %bb.100:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x20, #36]
	ldr	x9, [x21, #24]
	umull	x10, w27, w24
	ldr	w9, [x9, x10]
	cmp	w8, w9
	b.ne	LBB47_111
; %bb.101:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	w28, [x20, #12]
LBB47_102:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	w8, [x22, #4]
	cbz	w8, LBB47_104
; %bb.103:                              ;   in Loop: Header=BB47_88 Depth=1
	ldrh	w26, [sp, #646]
	b	LBB47_105
LBB47_104:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	w26, [x20, #16]
LBB47_105:                              ;   in Loop: Header=BB47_88 Depth=1
	ldrh	w8, [x22, #8]
	mov	x9, x23
	cmp	w27, w8
	b.eq	LBB47_107
; %bb.106:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	x9, [x21, #24]
	umaddl	x9, w27, w24, x9
	add	x9, x9, #28
LBB47_107:                              ;   in Loop: Header=BB47_88 Depth=1
	ldr	w2, [x9]
	cmp	w27, w8
	b.hs	LBB47_109
; %bb.108:                              ;   in Loop: Header=BB47_88 Depth=1
	ldrb	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB47_111
LBB47_109:                              ;   in Loop: Header=BB47_88 Depth=1
	mov	x0, x19
	mov	x1, x20
	bl	_frc_frame
	tbz	w0, #0, LBB47_111
; %bb.110:                              ;   in Loop: Header=BB47_88 Depth=1
	mov	x0, x19
	mov	w8, #0                          ; =0x0
	add	x2, x26, x28
	add	w25, w25, #1
	ldrh	w9, [x22, #8]
	cmp	w9, w25, uxth
	ldr	x20, [sp]                       ; 8-byte Folded Reload
	b.hi	LBB47_88
	b	LBB47_115
LBB47_111:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB47_114
; %bb.112:
	ldr	w8, [x21, #40]
	cbnz	w8, LBB47_114
; %bb.113:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
LBB47_114:
	mov	w8, #5                          ; =0x5
LBB47_115:
	mov	x0, x8
	b	LBB47_13
LBB47_116:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB47_114
; %bb.117:
	ldr	w8, [x21, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB47_119
; %bb.118:
	str	w0, [x21, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #48]
LBB47_119:
	mov	x8, x0
	b	LBB47_115
LBB47_120:
	mov	w8, #0                          ; =0x0
	b	LBB47_115
LBB47_121:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh72, Lloh73, Lloh74
	.loh AdrpLdrGotLdr	Lloh75, Lloh76, Lloh77
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_services_runtime_frame_view
lCPI48_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_frame_view
	.p2align	2
_nvm_services_runtime_frame_view:       ; @nvm_services_runtime_frame_view
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB48_4
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x1
	mov	x20, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	cbz	w0, LBB48_3
; %bb.2:
	add	x8, x20, #76, lsl #12           ; =311296
	add	x8, x8, #2732
	add	x9, x20, #72, lsl #12           ; =294912
	ldr	x9, [x9, #12280]
	ldrh	w10, [x8, #4]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldr	w8, [x8]
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	strh	w10, [x19, #16]
	stur	w12, [x19, #18]
	strh	w13, [x19, #22]
	ldur	q1, [x9, #-32]
Lloh78:
	adrp	x10, lCPI48_0@PAGE
Lloh79:
	ldr	q2, [x10, lCPI48_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	str	w8, [x19]
	stur	d0, [x19, #4]
	str	w11, [x19, #12]
	stur	q1, [x19, #24]
	str	d2, [x19, #40]
	mov	w0, #1                          ; =0x1
LBB48_3:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB48_4:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpLdr	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_current
_frf_current:                           ; @frf_current
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB49_7
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	add	x8, x8, #2728
	ldrb	w9, [x8, #10]
	tbnz	w9, #0, LBB49_6
; %bb.2:
	ldr	w9, [x8]
	cmp	w9, #1
	b.ne	LBB49_6
; %bb.3:
	ldrb	w9, [x8, #11]
	cmp	w9, #1
	b.ne	LBB49_6
; %bb.4:
	ldrb	w9, [x8, #12]
	tbnz	w9, #0, LBB49_6
; %bb.5:
	add	x9, x0, #74, lsl #12            ; =303104
	add	x9, x9, #4088
	ldr	w10, [x9, #16]
	cbz	w10, LBB49_8
LBB49_6:
	mov	w0, #0                          ; =0x0
LBB49_7:
	ret
LBB49_8:
	ldrh	w8, [x8, #8]
	cbz	w8, LBB49_6
; %bb.9:
	ldrh	w10, [x0, #140]
	cmp	w8, w10
	b.hi	LBB49_6
; %bb.10:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x9, [x9]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x22, w8, w10, x9
	ldrb	w8, [x22, #32]
	tbz	w8, #0, LBB49_12
LBB49_11:
	mov	w0, #0                          ; =0x0
	b	LBB49_17
LBB49_12:
	mov	x20, x2
	mov	x19, x3
	ldr	w8, [x22]
	mov	x21, x0
	mov	x2, x1
	mov	x1, x8
	bl	_fr_function
	cbz	w0, LBB49_17
; %bb.13:
	ldr	w2, [x22, #4]
	lsr	w8, w2, #16
	cbnz	w8, LBB49_11
; %bb.14:
	ldr	w1, [x22]
	ldrb	w3, [x22, #34]
	mov	x0, x21
	mov	x4, x20
	mov	x5, x19
	bl	_fr_instruction
	cbz	w0, LBB49_17
; %bb.15:
	ldrb	w8, [x19]
	cmp	w8, #1
	b.ne	LBB49_11
; %bb.16:
	ldr	w8, [x22, #16]
	ldrh	w9, [x19, #4]
	cmp	w8, w9
	cset	w0, eq
LBB49_17:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_local ; -- Begin function nvm_services_runtime_frame_local
	.p2align	2
_nvm_services_runtime_frame_local:      ; @nvm_services_runtime_frame_local
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB50_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB50_4
; %bb.2:
	ldurh	w8, [x29, #-64]
	cmp	w20, w8
	b.hs	LBB50_4
; %bb.3:
	add	x9, x21, #72, lsl #12           ; =294912
	ldr	x9, [x9, #12280]
	add	x8, x21, #76, lsl #12           ; =311296
	ldrh	w8, [x8, #2736]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldur	w8, [x8, #-32]
	add	w8, w8, w20
	str	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB50_5
LBB50_4:
	mov	w0, #0                          ; =0x0
LBB50_5:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB50_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_operand ; -- Begin function nvm_services_runtime_frame_operand
	.p2align	2
_nvm_services_runtime_frame_operand:    ; @nvm_services_runtime_frame_operand
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB51_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, x2
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB51_6
; %bb.2:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x8, x8, #4064
	ldr	x10, [x8, #24]
	add	x9, x20, #76, lsl #12           ; =311296
	ldrh	w9, [x9, #2736]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldur	w10, [x9, #-24]
	cmp	w10, w19
	b.ls	LBB51_6
; %bb.3:
	ldur	w9, [x9, #-28]
	ldr	w10, [x20, #128]
	add	w9, w9, w19
	cmp	w9, w10
	b.hs	LBB51_6
; %bb.4:
	ldr	x8, [x8]
	mov	w10, #176                       ; =0xb0
	umull	x10, w9, w10
	ldrb	w8, [x8, x10]
	cmp	w8, #1
	b.ne	LBB51_6
; %bb.5:
	str	w9, [x21]
	mov	w0, #1                          ; =0x1
	b	LBB51_7
LBB51_6:
	mov	w0, #0                          ; =0x0
LBB51_7:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB51_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_reserve ; -- Begin function nvm_services_runtime_frame_reserve
	.p2align	2
_nvm_services_runtime_frame_reserve:    ; @nvm_services_runtime_frame_reserve
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB52_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, x2
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB52_5
; %bb.2:
	ldurh	w8, [x29, #-66]
	cmp	w19, w8
	b.hs	LBB52_5
; %bb.3:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x8, x8, #4064
	ldr	x10, [x8, #24]
	add	x9, x20, #76, lsl #12           ; =311296
	ldrh	w9, [x9, #2736]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldur	w9, [x9, #-28]
	ldr	w10, [x20, #128]
	add	w9, w9, w19
	cmp	w9, w10
	b.hs	LBB52_5
; %bb.4:
	ldr	x8, [x8]
	mov	w10, #176                       ; =0xb0
	umull	x10, w9, w10
	ldrb	w8, [x8, x10]
	tbz	w8, #0, LBB52_8
LBB52_5:
	mov	w0, #0                          ; =0x0
LBB52_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB52_7:
	mov	w0, #0                          ; =0x0
	ret
LBB52_8:
	str	w9, [x21]
	mov	w0, #1                          ; =0x1
	b	LBB52_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_scratch ; -- Begin function nvm_services_runtime_frame_scratch
	.p2align	2
_nvm_services_runtime_frame_scratch:    ; @nvm_services_runtime_frame_scratch
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB53_7
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x0
	mov	x20, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB53_5
; %bb.2:
	ldurh	w9, [x29, #-62]
	cbz	x9, LBB53_5
; %bb.3:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x8, x8, #4064
	ldr	x11, [x8, #24]
	add	x10, x19, #76, lsl #12          ; =311296
	ldrh	w10, [x10, #2736]
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldur	w10, [x10, #-20]
	add	x9, x9, x10
	sub	x9, x9, #1
	ldr	w10, [x19, #128]
	cmp	x9, x10
	b.hs	LBB53_5
; %bb.4:
	ldr	x8, [x8]
	mov	w10, #176                       ; =0xb0
	mul	x10, x9, x10
	ldrb	w8, [x8, x10]
	tbz	w8, #0, LBB53_8
LBB53_5:
	mov	w0, #0                          ; =0x0
LBB53_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB53_7:
	mov	w0, #0                          ; =0x0
	ret
LBB53_8:
	str	w9, [x20]
	mov	w0, #1                          ; =0x1
	b	LBB53_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_reference ; -- Begin function nvm_services_runtime_frame_reference
	.p2align	2
_nvm_services_runtime_frame_reference:  ; @nvm_services_runtime_frame_reference
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB54_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB54_4
; %bb.2:
	cmp	w20, #255
	b.hi	LBB54_4
; %bb.3:
	add	x9, x21, #72, lsl #12           ; =294912
	ldr	x9, [x9, #12280]
	add	x8, x21, #76, lsl #12           ; =311296
	ldrh	w8, [x8, #2736]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldur	w8, [x8, #-16]
	add	w8, w8, w20
	str	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB54_5
LBB54_4:
	mov	w0, #0                          ; =0x0
LBB54_5:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB54_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_store ; -- Begin function nvm_services_runtime_frame_store
	.p2align	2
_nvm_services_runtime_frame_store:      ; @nvm_services_runtime_frame_store
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB55_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #912
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x20, x8, #2728
	ldrb	w8, [x20, #10]
	tbz	w8, #0, LBB55_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB55_23
LBB55_3:
	mov	w0, #1                          ; =0x1
	ret
LBB55_4:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB55_22
; %bb.5:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x24, x8, #4064
	ldr	w0, [x24, #40]
	cbnz	w0, LBB55_23
; %bb.6:
	ldrb	w8, [x20, #12]
	tbz	w8, #0, LBB55_9
LBB55_7:
	mov	w0, #5                          ; =0x5
LBB55_8:
	str	w0, [x24, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x24, #48]
	b	LBB55_23
LBB55_9:
	sub	x1, x29, #160
	add	x2, sp, #232
	add	x3, sp, #152
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB55_20
; %bb.10:
	mov	x12, x19
	ldr	w8, [x19, #24]
	ldr	x9, [x24, #24]
	ldrh	w10, [x20, #8]
	cbz	w8, LBB55_12
; %bb.11:
	mov	w11, #40                        ; =0x28
	umaddl	x11, w10, w11, x9
	ldurb	w11, [x11, #-7]
	tbz	w11, #0, LBB55_20
LBB55_12:
	mov	w11, #40                        ; =0x28
	umaddl	x25, w10, w11, x9
	ldur	w9, [x25, #-40]
	ldr	w10, [sp, #232]
	stp	w9, w10, [x24, #52]
	ldrb	w26, [sp, #240]
	cmp	w26, #17
	cset	w9, ne
	cmp	w26, #12
	cset	w10, eq
	eor	w9, w10, w9
	tbnz	w9, #0, LBB55_18
; %bb.13:
	ldur	w9, [x25, #-24]
	cbz	w9, LBB55_18
; %bb.14:
	ldrh	w21, [sp, #248]
	ldurh	w10, [x29, #-120]
	cmp	w21, w10
	b.hs	LBB55_18
; %bb.15:
	ldurh	w10, [x29, #-122]
	cmp	w9, w10
	b.hi	LBB55_18
; %bb.16:
	ldur	w11, [x25, #-28]
	ldr	w12, [x12, #128]
	sub	x13, x12, x11
	cmp	w11, w12
	ccmp	x13, x10, #0, ls
	b.lo	LBB55_18
; %bb.17:
	ldur	w15, [x25, #-20]
	ldurh	w13, [x29, #-118]
	sub	x14, x12, x15
	cmp	w15, w12
	ccmp	x14, x13, #0, ls
	b.hs	LBB55_24
LBB55_18:
	ldr	w8, [x20]
	cmp	w8, #2
	b.eq	LBB55_22
; %bb.19:
	ldr	w8, [x24, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB55_23
	b	LBB55_8
LBB55_20:
	ldr	w8, [x20]
	cmp	w8, #2
	b.eq	LBB55_22
; %bb.21:
	ldr	w8, [x24, #40]
	cbz	w8, LBB55_7
LBB55_22:
	mov	w0, #5                          ; =0x5
LBB55_23:
	add	sp, sp, #912
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB55_24:
	cbz	w13, LBB55_29
; %bb.25:
	sub	w14, w12, w15
	mov	w12, #176                       ; =0xb0
	umull	x15, w15, w12
LBB55_26:                               ; =>This Inner Loop Header: Depth=1
	cbz	x14, LBB55_18
; %bb.27:                               ;   in Loop: Header=BB55_26 Depth=1
	ldr	x12, [x24]
	ldrb	w16, [x12, x15]
	tbnz	w16, #0, LBB55_18
; %bb.28:                               ;   in Loop: Header=BB55_26 Depth=1
	add	x15, x15, #176
	sub	x14, x14, #1
	sub	x13, x13, #1
	cbnz	x13, LBB55_26
	b	LBB55_30
LBB55_29:
	ldr	x12, [x24]
LBB55_30:
	mov	x13, #0                         ; =0x0
	mov	w14, #176                       ; =0xb0
	b	LBB55_33
LBB55_31:                               ;   in Loop: Header=BB55_33 Depth=1
	tbnz	w16, #0, LBB55_18
LBB55_32:                               ;   in Loop: Header=BB55_33 Depth=1
	add	x13, x13, #1
	cmp	x10, x13
	b.eq	LBB55_36
LBB55_33:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w11, w13
	umaddl	x15, w15, w14, x12
	ldrb	w16, [x15]
	cmp	x13, x9
	b.hs	LBB55_31
; %bb.34:                               ;   in Loop: Header=BB55_33 Depth=1
	cbz	w16, LBB55_18
; %bb.35:                               ;   in Loop: Header=BB55_33 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB55_32
	b	LBB55_18
LBB55_36:
	mov	x23, x20
	mov	x22, x24
	ldur	w1, [x25, #-40]
	cbz	w8, LBB55_39
; %bb.37:
	cmp	w8, #2
	b.ne	LBB55_40
; %bb.38:
	ldr	x0, [x19, #16]
	add	x3, sp, #136
	mov	x2, x21
	bl	_nvm_services_indirect_hosted_local
	b	LBB55_41
LBB55_39:
	ldr	x0, [x19]
	add	x3, sp, #136
	mov	x2, x21
	bl	_nvm_services_hosted_local
	b	LBB55_41
LBB55_40:
	ldr	x0, [x19, #8]
	add	x3, sp, #136
	mov	x2, x21
	bl	_nvm_services_cyclic_hosted_local
LBB55_41:
	mov	x24, x22
	mov	x20, x23
	mov	x14, x26
	tbz	w0, #0, LBB55_18
; %bb.42:
	ldp	w9, w8, [x25, #-28]
	ldur	w10, [x25, #-32]
	add	w8, w9, w8
	sub	w20, w8, #1
	add	w21, w10, w21
	ldr	x27, [x24]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w20, w8, x27
	ldr	s0, [x8]
	ldrb	w28, [x8, #1]
	ldrb	w12, [x8, #4]
	ldrb	w9, [x8, #5]
	ldrh	w10, [x8, #6]
	ldr	w11, [x8, #8]
	ldrb	w13, [sp, #137]
	cmp	w14, #12
	b.eq	LBB55_51
; %bb.43:
	ldrb	w14, [x8]
	tbz	w14, #0, LBB55_51
; %bb.44:
	tbnz	w28, #0, LBB55_51
; %bb.45:
	ldrb	w14, [x8, #2]
	tbnz	w14, #0, LBB55_51
; %bb.46:
	ldrb	w14, [sp, #136]
	ldr	w15, [sp, #148]
	sub	w15, w15, #3
	cmp	w12, #0
	ccmp	w9, #0, #0, eq
	ccmn	w11, #1, #0, eq
	ccmp	w14, #0, #4, eq
	ccmp	w13, #0, #0, ne
	ccmn	w15, #3, #2, eq
	b.hi	LBB55_51
; %bb.47:
	ldr	w8, [x19, #128]
	cmp	w21, w8
	b.hs	LBB55_50
; %bb.48:
	mov	w8, #176                        ; =0xb0
	umaddl	x0, w21, w8, x27
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB55_50
; %bb.49:
	ldp	x1, x2, [sp, #136]
	bl	_frf_matches
	tbz	w0, #0, LBB55_52
LBB55_50:
	mov	w0, #0                          ; =0x0
	mov	w8, #176                        ; =0xb0
	umaddl	x9, w21, w8, x27
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #144]
	stp	q0, q0, [x9, #112]
	stp	q0, q0, [x9, #80]
	stp	q0, q0, [x9, #48]
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	ldr	x9, [x22]
	umaddl	x8, w20, w8, x9
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	b	LBB55_23
LBB55_51:
	cbz	w13, LBB55_56
LBB55_52:
	ldr	w8, [x23]
	cmp	w8, #2
	b.ne	LBB55_54
; %bb.53:
	mov	w0, #6                          ; =0x6
	b	LBB55_23
LBB55_54:
	ldr	w8, [x22, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB55_23
; %bb.55:
	str	w0, [x22, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x22, #48]
	b	LBB55_23
LBB55_56:
	ushll.8h	v0, v0, #0
	uzp1.8b	v0, v0, v0
	str	s0, [sp, #16]
	cmp	w26, #12
	strb	w12, [sp, #20]
	cset	w24, eq
	strb	w9, [sp, #21]
	strh	w10, [sp, #22]
	str	w11, [sp, #24]
	ldur	q0, [x8, #60]
	stur	q0, [sp, #76]
	ldur	q0, [x8, #76]
	stur	q0, [sp, #92]
	ldur	q0, [x8, #92]
	stur	q0, [sp, #108]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #12]
	stur	q0, [sp, #28]
	ldur	q0, [x8, #28]
	stur	q0, [sp, #44]
	ldur	q0, [x8, #44]
	stur	q0, [sp, #60]
	ldp	x1, x25, [sp, #136]
	add	x0, sp, #16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, x25
	bl	_frf_matches
	cbz	w0, LBB55_52
; %bb.57:
	eor	w8, w24, w28
	tbnz	w8, #0, LBB55_52
; %bb.58:
	ldr	w8, [x19, #128]
	cmp	w26, #12
	b.ne	LBB55_66
; %bb.59:
	cmp	w21, w8
	b.hs	LBB55_52
; %bb.60:
	mov	w8, #176                        ; =0xb0
	umull	x8, w21, w8
	ldrb	w8, [x27, x8]
	tbnz	w8, #0, LBB55_52
; %bb.61:
	ldr	w8, [x19, #132]
	cbz	w8, LBB55_70
; %bb.62:
	ldr	x9, [x22, #8]
	add	x9, x9, #4
	b	LBB55_64
LBB55_63:                               ;   in Loop: Header=BB55_64 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB55_70
LBB55_64:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB55_63
; %bb.65:                               ;   in Loop: Header=BB55_64 Depth=1
	ldr	w10, [x9]
	cmp	w10, w20
	b.ne	LBB55_63
	b	LBB55_52
LBB55_66:
	cmp	w21, w8
	b.hs	LBB55_69
; %bb.67:
	mov	w8, #176                        ; =0xb0
	umaddl	x0, w21, w8, x27
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB55_69
; %bb.68:
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, x25
	bl	_frf_matches
	tbz	w0, #0, LBB55_52
LBB55_69:
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w21, w8, x27
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB55_70:
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	bl	_nvm_services_runtime_move
	b	LBB55_23
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_stack
_frf_stack:                             ; @frf_stack
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x2, #38]
	cmp	w3, w8
	b.hi	LBB56_3
; %bb.1:
	ldr	w9, [x1, #12]
	ldr	w12, [x0, #128]
	sub	x10, x12, x9
	cmp	w9, w12
	ccmp	x10, x8, #0, ls
	b.lo	LBB56_3
; %bb.2:
	ldr	w13, [x1, #20]
	ldrh	w10, [x2, #42]
	sub	x11, x12, x13
	cmp	w13, w12
	ccmp	x11, x10, #0, ls
	b.hs	LBB56_5
LBB56_3:
	mov	w0, #0                          ; =0x0
LBB56_4:
	ret
LBB56_5:
	cbz	w10, LBB56_10
; %bb.6:
	mov	w11, #45024                     ; =0xafe0
	movk	w11, #4, lsl #16
	sub	w12, w12, w13
	mov	w14, #176                       ; =0xb0
	umull	x13, w13, w14
LBB56_7:                                ; =>This Inner Loop Header: Depth=1
	cbz	x12, LBB56_3
; %bb.8:                                ;   in Loop: Header=BB56_7 Depth=1
	ldr	x14, [x0, x11]
	ldrb	w14, [x14, x13]
	tbnz	w14, #0, LBB56_3
; %bb.9:                                ;   in Loop: Header=BB56_7 Depth=1
	add	x13, x13, #176
	sub	x12, x12, #1
	sub	x10, x10, #1
	cbnz	x10, LBB56_7
LBB56_10:
	cbz	w8, LBB56_17
; %bb.11:
	mov	x10, #0                         ; =0x0
	add	x11, x0, #72, lsl #12           ; =294912
	ldr	x11, [x11, #12256]
	mov	w12, w3
	mov	w13, #176                       ; =0xb0
	mov	w0, #1                          ; =0x1
	b	LBB56_14
LBB56_12:                               ;   in Loop: Header=BB56_14 Depth=1
	tbnz	w15, #0, LBB56_3
LBB56_13:                               ;   in Loop: Header=BB56_14 Depth=1
	add	x10, x10, #1
	cmp	x8, x10
	b.eq	LBB56_4
LBB56_14:                               ; =>This Inner Loop Header: Depth=1
	add	w14, w9, w10
	umaddl	x14, w14, w13, x11
	ldrb	w15, [x14]
	cmp	x10, x12
	b.hs	LBB56_12
; %bb.15:                               ;   in Loop: Header=BB56_14 Depth=1
	cbz	w15, LBB56_3
; %bb.16:                               ;   in Loop: Header=BB56_14 Depth=1
	ldrb	w14, [x14, #2]
	tbz	w14, #0, LBB56_13
	b	LBB56_3
LBB56_17:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_local
_fr_local:                              ; @fr_local
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cbz	w8, LBB57_3
; %bb.1:
	cmp	w8, #2
	b.ne	LBB57_4
; %bb.2:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_local
LBB57_3:
	ldr	x0, [x0]
	b	_nvm_services_hosted_local
LBB57_4:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_local
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_matches
_frf_matches:                           ; @frf_matches
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB58_5
; %bb.1:
	ldur	x8, [x0, #4]
	eor	x8, x8, x1
	tst	x8, #0xff
	b.ne	LBB58_5
; %bb.2:
	ldur	x9, [x0, #12]
	and	x8, x8, #0xffffffffffffff00
	and	x8, x8, #0xffffffff0000ffff
	cmp	x8, #0
	ccmp	x9, x2, #0, eq
	b.ne	LBB58_5
; %bb.3:
	ldrb	w9, [x0, #2]
	ands	x8, x1, #0xff00
	cset	w10, ne
	cmp	w9, w10
	b.ne	LBB58_5
; %bb.4:
	lsr	x9, x2, #32
	sub	x9, x9, #1
	ldrb	w10, [x0, #1]
	cmp	x8, #0
	ccmp	x9, #2, #2, eq
	cset	w8, lo
	cmp	w10, w8
	cset	w0, eq
	ret
LBB58_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_next ; -- Begin function nvm_services_runtime_frame_next
	.p2align	2
_nvm_services_runtime_frame_next:       ; @nvm_services_runtime_frame_next
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB59_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1440
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x24, x8, #2728
	ldrb	w8, [x24, #10]
	tbz	w8, #0, LBB59_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB59_36
LBB59_3:
	mov	w0, #1                          ; =0x1
	ret
LBB59_4:
	ldr	w8, [x24]
	cmp	w8, #1
	b.ne	LBB59_35
; %bb.5:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x23, x8, #4088
	ldr	w0, [x23, #16]
	cbnz	w0, LBB59_36
; %bb.6:
	ldrb	w8, [x24, #12]
	tbz	w8, #0, LBB59_9
LBB59_7:
	mov	w0, #5                          ; =0x5
LBB59_8:
	str	w0, [x23, #16]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #24]
	b	LBB59_36
LBB59_9:
	mov	x26, x1
	add	x1, sp, #680
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB59_16
; %bb.10:
	mov	x8, x19
	ldr	w9, [x19, #24]
	ldr	x10, [x23]
	ldrh	w11, [x24, #8]
	cbz	w9, LBB59_12
; %bb.11:
	mov	w12, #40                        ; =0x28
	umaddl	x12, w11, w12, x10
	ldurb	w12, [x12, #-7]
	tbz	w12, #0, LBB59_16
LBB59_12:
	mov	w12, #40                        ; =0x28
	umaddl	x25, w11, w12, x10
	mov	x20, x25
	ldr	w10, [x20, #-40]!
	ldr	w11, [sp, #80]
	stp	w10, w11, [x23, #28]
	cbz	w9, LBB59_18
; %bb.13:
	cmp	w26, #1
	b.hi	LBB59_34
; %bb.14:
	ldp	w1, w10, [x25, #-40]
	ldurb	w3, [x25, #-6]
	cmp	w9, #2
	b.ne	LBB59_31
; %bb.15:
	ldr	x0, [x8, #16]
	and	w2, w10, #0xffff
	add	x4, sp, #832
	bl	_nvm_services_indirect_hosted_variant
	mov	x8, x26
	tbnz	w0, #0, LBB59_32
	b	LBB59_34
LBB59_16:
	ldr	w8, [x24]
	cmp	w8, #2
	b.eq	LBB59_35
; %bb.17:
	ldr	w8, [x23, #16]
	cbnz	w8, LBB59_35
	b	LBB59_7
LBB59_18:
	mov	w21, #0                         ; =0x0
	mov	x8, x26
LBB59_19:
	ldrb	w9, [sp, #88]
	cmp	w9, #152
	mov	w10, #60                        ; =0x3c
	ccmp	w9, w10, #4, ne
	b.eq	LBB59_34
; %bb.20:
	cmp	w9, #61
	b.hi	LBB59_22
; %bb.21:
	mov	w10, #1                         ; =0x1
	lsl	x10, x10, x9
	mov	x11, #32768                     ; =0x8000
	movk	x11, #10240, lsl #48
	tst	x10, x11
	b.ne	LBB59_34
LBB59_22:
	cmp	w9, #151
	b.eq	LBB59_34
; %bb.23:
	ldrb	w9, [sp, #156]
	cmp	w8, w9
	b.hs	LBB59_34
; %bb.24:
	ldrh	w22, [sp, #6]
	add	x2, sp, #680
	mov	x0, x19
	mov	x1, x20
	mov	x3, x22
	bl	_frf_stack
	cbz	w0, LBB59_34
; %bb.25:
	ldr	w1, [x20]
	add	x10, sp, #80
	add	x27, x10, #72
	ldrh	w2, [x27, w26, uxtw #1]
	add	x4, sp, #832
	add	x5, sp, #752
	mov	x0, x19
	mov	x3, x21
	bl	_fr_instruction
	cbz	w0, LBB59_34
; %bb.26:
	ldrb	w8, [sp, #752]
	tbz	w8, #0, LBB59_34
; %bb.27:
	ldrh	w8, [sp, #756]
	cmp	w22, w8
	b.ne	LBB59_34
; %bb.28:
	ldr	q0, [x20, #16]
	str	q0, [sp, #848]
	ldr	q0, [x20]
	str	q0, [sp, #832]
	ldr	x9, [x20, #32]
	str	x9, [sp, #864]
	ldrh	w9, [x27, w26, uxtw #1]
	ldrh	w10, [sp, #6]
	str	w10, [sp, #848]
	str	w9, [sp, #836]
	strb	w21, [sp, #866]
	strb	wzr, [sp, #865]
	ldr	w8, [x19, #24]
	cbz	w8, LBB59_38
; %bb.29:
	add	x1, sp, #832
	mov	x0, x19
	bl	_frc_validate
	cbz	w0, LBB59_38
; %bb.30:
	ldr	w0, [x23, #16]
	b	LBB59_36
LBB59_31:
	ldr	x0, [x8, #8]
	and	w2, w10, #0xffff
	add	x4, sp, #832
	bl	_nvm_services_cyclic_hosted_variant
	mov	x8, x26
	cbz	w0, LBB59_34
LBB59_32:
	ldrb	w9, [sp, #932]
	lsr	w9, w9, w8
	tbz	w9, #0, LBB59_34
; %bb.33:
	add	x9, sp, #832
	add	x9, x9, w8, uxtw
	ldrb	w21, [x9, #101]
	cmp	w21, #255
	b.ne	LBB59_19
LBB59_34:
	ldr	w8, [x24]
	cmp	w8, #2
	b.ne	LBB59_37
LBB59_35:
	mov	w0, #5                          ; =0x5
LBB59_36:
	add	sp, sp, #1440
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB59_37:
	ldr	w8, [x23, #16]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB59_36
	b	LBB59_8
LBB59_38:
	ldr	q0, [sp, #832]
	str	q0, [x20]
	ldr	q0, [sp, #848]
	str	q0, [x20, #16]
	ldr	x8, [sp, #864]
	str	x8, [x20, #32]
	ldur	w1, [x25, #-40]
	ldurh	w2, [x25, #-36]
	mov	x0, x19
	bl	_nvm_services_runtime_site
	b	LBB59_36
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_edge
_frc_edge:                              ; @frc_edge
	.cfi_startproc
; %bb.0:
	ldr	w9, [x0, #24]
	cbz	w9, LBB60_3
; %bb.1:
	cmp	w2, #1
	b.ls	LBB60_4
; %bb.2:
	mov	w0, #0                          ; =0x0
	ret
LBB60_3:
	strb	wzr, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB60_4:
	sub	sp, sp, #144
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x2
	mov	x19, x3
	mov	x10, x1
	ldr	w1, [x1]
	ldr	w8, [x10, #4]
	ldrb	w3, [x10, #34]
	cmp	w9, #2
	b.ne	LBB60_6
; %bb.5:
	ldr	x0, [x0, #16]
	and	w2, w8, #0xffff
	add	x4, sp, #8
	bl	_nvm_services_indirect_hosted_variant
	tbnz	w0, #0, LBB60_7
	b	LBB60_10
LBB60_6:
	ldr	x0, [x0, #8]
	and	w2, w8, #0xffff
	add	x4, sp, #8
	bl	_nvm_services_cyclic_hosted_variant
	cbz	w0, LBB60_11
LBB60_7:
	ldrb	w8, [sp, #108]
	lsr	w8, w8, w20
	tbz	w8, #0, LBB60_10
; %bb.8:
	add	x8, sp, #8
	add	x8, x8, w20, uxtw
	ldrb	w8, [x8, #101]
	cmp	w8, #255
	b.eq	LBB60_10
; %bb.9:
	strb	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB60_11
LBB60_10:
	mov	w0, #0                          ; =0x0
LBB60_11:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_call ; -- Begin function nvm_services_runtime_frame_call
	.p2align	2
_nvm_services_runtime_frame_call:       ; @nvm_services_runtime_frame_call
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2640
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh80:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh81:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh82:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB61_3
; %bb.1:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB61_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB61_37
LBB61_3:
	mov	w0, #1                          ; =0x1
	b	LBB61_37
LBB61_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB61_36
; %bb.5:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x20, x8, #4064
	ldr	w0, [x20, #40]
	cbnz	w0, LBB61_37
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB61_9
LBB61_7:
	mov	w0, #5                          ; =0x5
LBB61_8:
	str	w0, [x20, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #48]
	b	LBB61_37
LBB61_9:
	add	x1, sp, #848
	add	x2, sp, #176
	add	x3, sp, #96
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB61_24
; %bb.10:
	mov	x9, x19
	ldr	w8, [x19, #24]
	ldr	x10, [x20, #24]
	ldrh	w11, [x21, #8]
	cbz	w8, LBB61_12
; %bb.11:
	mov	w12, #40                        ; =0x28
	umaddl	x12, w11, w12, x10
	ldurb	w12, [x12, #-7]
	tbz	w12, #0, LBB61_24
LBB61_12:
	add	x23, sp, #176
	mov	w12, #40                        ; =0x28
	umaddl	x22, w11, w12, x10
	mov	x1, x22
	ldr	w10, [x1, #-40]!
	ldr	w11, [sp, #176]
	stp	w10, w11, [x20, #52]
	ldrb	w24, [sp, #184]
	cmp	w24, #60
	cset	w10, eq
	cmp	w24, #152
	csinc	w25, w10, wzr, ne
	b.eq	LBB61_14
; %bb.13:
	cmp	w24, #60
	b.ne	LBB61_26
LBB61_14:
	cmp	w8, #2
	b.ne	LBB61_35
; %bb.15:
	ldur	w8, [x22, #-24]
	cbz	w8, LBB61_35
; %bb.16:
	ldur	w10, [x22, #-28]
	add	w8, w8, w10
	sub	w8, w8, #1
	ldr	w10, [x9, #128]
	cmp	w8, w10
	b.hs	LBB61_35
; %bb.17:
	ldr	x10, [x20]
	mov	w11, #176                       ; =0xb0
	umaddl	x10, w8, w11, x10
	ldrb	w11, [x10]
	tbz	w11, #0, LBB61_35
; %bb.18:
	ldur	x11, [x10, #4]
	mov	x12, #-65525                    ; =0xffffffffffff000b
	movk	x12, #0, lsl #16
	eor	x11, x11, x12
	tst	x11, #0xff
	b.ne	LBB61_35
; %bb.19:
	ldur	x12, [x10, #12]
	ldrb	w13, [x10, #2]
	ldrb	w14, [x10, #1]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x11, #0
	mov	w11, #-1                        ; =0xffffffff
	ccmp	x12, x11, #0, eq
	ccmp	w13, #0, #0, eq
	ccmp	w14, #0, #0, eq
	b.ne	LBB61_35
; %bb.20:
	ldrb	w11, [x10, #24]
	cbnz	w11, LBB61_35
; %bb.21:
	ldr	x11, [x10, #160]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.ne	LBB61_35
; %bb.22:
	mov	x26, x8
	ldr	w3, [x10, #168]
	add	x2, sp, #176
	mov	x0, x9
	mov	x23, x1
	mov	x27, x3
	bl	_fr_call_target
	cbz	w0, LBB61_35
; %bb.23:
	ldrb	w11, [sp, #184]
	mov	w10, #-1                        ; =0xffffffff
	mov	x9, x19
	mov	x8, x27
	mov	x1, x23
	add	x23, sp, #176
	b	LBB61_27
LBB61_24:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB61_36
; %bb.25:
	ldr	w8, [x20, #40]
	cbnz	w8, LBB61_36
	b	LBB61_7
LBB61_26:
	ldr	w10, [x23, #16]
	mov	w26, #-1                        ; =0xffffffff
	mov	x11, x24
	mov	x8, x10
LBB61_27:
	cmp	w11, #59
	ccmp	w11, #15, #4, ne
	mov	w12, #151                       ; =0x97
	ccmp	w11, w12, #4, ne
	cset	w11, eq
	orr	w11, w25, w11
	tbz	w11, #0, LBB61_35
; %bb.28:
	ldrb	w11, [sp, #252]
	cmp	w11, #1
	b.ne	LBB61_35
; %bb.29:
	ldrb	w11, [sp, #99]
	tbz	w11, #0, LBB61_35
; %bb.30:
	ldr	w11, [sp, #120]
	cmp	w11, #1
	b.ne	LBB61_35
; %bb.31:
	ldr	w11, [sp, #128]
	cmp	w11, w10
	b.ne	LBB61_35
; %bb.32:
	ldr	w10, [sp, #124]
	ldr	w11, [sp, #176]
	cmp	w10, w11
	b.ne	LBB61_35
; %bb.33:
	ldrb	w10, [sp, #112]
	tbz	w10, #6, LBB61_35
; %bb.34:
	add	x14, sp, #776
	ldur	w10, [x22, #-24]
	ldrh	w11, [x14, #110]
	cmp	w10, w11
	b.ls	LBB61_40
LBB61_35:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB61_39
LBB61_36:
	mov	w0, #5                          ; =0x5
LBB61_37:
	ldur	x8, [x29, #-96]
Lloh83:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh84:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh85:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB61_121
; %bb.38:
	add	sp, sp, #2640
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB61_39:
	ldr	w8, [x20, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB61_37
	b	LBB61_8
LBB61_40:
	ldur	w12, [x22, #-28]
	ldr	w13, [x9, #128]
	cmp	w12, w13
	b.hi	LBB61_35
; %bb.41:
	sub	x9, x13, x12
	cmp	x9, x11
	b.lo	LBB61_35
; %bb.42:
	ldur	w15, [x22, #-20]
	cmp	w15, w13
	b.hi	LBB61_35
; %bb.43:
	ldrh	w9, [x14, #114]
	sub	x14, x13, x15
	cmp	x14, x9
	b.lo	LBB61_35
; %bb.44:
	cbz	w9, LBB61_49
; %bb.45:
	sub	w13, w13, w15
	mov	w14, #176                       ; =0xb0
	umull	x14, w15, w14
LBB61_46:                               ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB61_35
; %bb.47:                               ;   in Loop: Header=BB61_46 Depth=1
	ldr	x15, [x20]
	ldrb	w15, [x15, x14]
	tbnz	w15, #0, LBB61_35
; %bb.48:                               ;   in Loop: Header=BB61_46 Depth=1
	add	x14, x14, #176
	sub	x13, x13, #1
	sub	x9, x9, #1
	cbnz	x9, LBB61_46
LBB61_49:
	cbz	w11, LBB61_56
; %bb.50:
	mov	x9, #0                          ; =0x0
	ldr	x13, [x20]
	mov	w14, #176                       ; =0xb0
	b	LBB61_53
LBB61_51:                               ;   in Loop: Header=BB61_53 Depth=1
	tbnz	w16, #0, LBB61_35
LBB61_52:                               ;   in Loop: Header=BB61_53 Depth=1
	add	x9, x9, #1
	cmp	x11, x9
	b.eq	LBB61_56
LBB61_53:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w12, w9
	umaddl	x15, w15, w14, x13
	ldrb	w16, [x15]
	cmp	x9, x10
	b.hs	LBB61_51
; %bb.54:                               ;   in Loop: Header=BB61_53 Depth=1
	cbz	w16, LBB61_35
; %bb.55:                               ;   in Loop: Header=BB61_53 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB61_52
	b	LBB61_35
LBB61_56:
	add	x2, sp, #776
	mov	x0, x19
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	str	x1, [sp, #32]                   ; 8-byte Folded Spill
	mov	w1, w8
	bl	_fr_function
	tbz	w0, #0, LBB61_35
; %bb.57:
	str	x26, [sp]                       ; 8-byte Folded Spill
	str	w24, [sp, #12]                  ; 4-byte Folded Spill
	stp	x21, x22, [sp, #16]             ; 16-byte Folded Spill
	str	x20, [sp, #40]                  ; 8-byte Folded Spill
	ldrh	w22, [x23, #612]
	add	x27, sp, #1600
	add	x0, sp, #1600
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	cbz	w22, LBB61_91
; %bb.58:
	mov	x28, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	add	x8, sp, #176
	add	x23, x8, #78
LBB61_59:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB61_79 Depth 2
	ldr	w8, [x19, #24]
	cbz	w8, LBB61_62
; %bb.60:                               ;   in Loop: Header=BB61_59 Depth=1
	cmp	w8, #2
	b.ne	LBB61_63
; %bb.61:                               ;   in Loop: Header=BB61_59 Depth=1
	ldr	x0, [x19, #16]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_services_indirect_hosted_local
	tbnz	w0, #0, LBB61_64
	b	LBB61_88
LBB61_62:                               ;   in Loop: Header=BB61_59 Depth=1
	ldr	x0, [x19]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_services_hosted_local
	tbnz	w0, #0, LBB61_64
	b	LBB61_88
LBB61_63:                               ;   in Loop: Header=BB61_59 Depth=1
	ldr	x0, [x19, #8]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_services_cyclic_hosted_local
	tbz	w0, #0, LBB61_88
LBB61_64:                               ;   in Loop: Header=BB61_59 Depth=1
	ldrb	w21, [sp, #1001]
	ldrb	w8, [sp, #184]
	and	w8, w8, #0xff
	cmp	w8, #152
	csel	w9, wzr, w25, eq
	cbz	w21, LBB61_83
; %bb.65:                               ;   in Loop: Header=BB61_59 Depth=1
	sub	w10, w21, #3
	cmn	w10, #2
	csinc	w9, w9, wzr, hs
	tbnz	w9, #0, LBB61_88
; %bb.66:                               ;   in Loop: Header=BB61_59 Depth=1
	cmp	w26, #255
	b.hi	LBB61_88
; %bb.67:                               ;   in Loop: Header=BB61_59 Depth=1
	sub	w9, w8, #151
	cmp	w9, #2
	b.lo	LBB61_69
; %bb.68:                               ;   in Loop: Header=BB61_59 Depth=1
	cmp	w8, #15
	b.ne	LBB61_88
LBB61_69:                               ;   in Loop: Header=BB61_59 Depth=1
	ldrh	w9, [x23, x28, lsl #1]
	cmp	w9, #255
	b.hi	LBB61_88
; %bb.70:                               ;   in Loop: Header=BB61_59 Depth=1
	cmp	w8, #15
	b.ne	LBB61_72
; %bb.71:                               ;   in Loop: Header=BB61_59 Depth=1
	add	x8, sp, #176
	ldrh	w8, [x8, #24]
	cmp	w9, w8
	b.ne	LBB61_88
LBB61_72:                               ;   in Loop: Header=BB61_59 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-16]
	add	w20, w8, w9
	str	w20, [x27, x28, lsl #2]
	mov	x0, x19
	mov	x1, x20
	bl	_fr_reference
	tbz	w0, #0, LBB61_119
; %bb.73:                               ;   in Loop: Header=BB61_59 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldp	x9, x8, [x8]
	add	x8, x8, x20, lsl #6
	ldr	w10, [x8, #4]
	mov	w11, #176                       ; =0xb0
	umaddl	x9, w10, w11, x9
	ldr	x11, [x9, #4]!
	add	x10, sp, #776
	ldr	x10, [x10, #224]
	bfi	x11, x21, #8, #8
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB61_119
; %bb.74:                               ;   in Loop: Header=BB61_59 Depth=1
	add	x11, sp, #776
	ldr	x11, [x11, #232]
	ldr	x9, [x9, #8]
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	and	x10, x10, x12
	cmp	x10, #0
	ccmp	x11, x9, #0, eq
	b.ne	LBB61_119
; %bb.75:                               ;   in Loop: Header=BB61_59 Depth=1
	ldrb	w8, [x8, #2]
	cmp	w21, #1
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB61_119
; %bb.76:                               ;   in Loop: Header=BB61_59 Depth=1
	add	w26, w26, #1
	cbz	x28, LBB61_86
; %bb.77:                               ;   in Loop: Header=BB61_59 Depth=1
	mov	x21, #0                         ; =0x0
	b	LBB61_79
LBB61_78:                               ;   in Loop: Header=BB61_79 Depth=2
	add	x21, x21, #1
	cmp	x28, x21
	b.eq	LBB61_86
LBB61_79:                               ;   Parent Loop BB61_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x21
	bl	_fr_local
	tbz	w0, #0, LBB61_88
; %bb.80:                               ;   in Loop: Header=BB61_79 Depth=2
	ldrb	w8, [sp, #921]
	cbz	w8, LBB61_78
; %bb.81:                               ;   in Loop: Header=BB61_79 Depth=2
	ldrb	w9, [sp, #1001]
	cmp	w8, #1
	ccmp	w9, #1, #0, eq
	b.eq	LBB61_78
; %bb.82:                               ;   in Loop: Header=BB61_79 Depth=2
	ldr	w9, [x27, x21, lsl #2]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	add	x9, x8, x9, lsl #6
	ldr	w9, [x9, #4]
	add	x8, x8, x20, lsl #6
	ldr	w8, [x8, #4]
	cmp	w9, w8
	b.ne	LBB61_78
	b	LBB61_119
LBB61_83:                               ;   in Loop: Header=BB61_59 Depth=1
	tbnz	w9, #0, LBB61_85
; %bb.84:                               ;   in Loop: Header=BB61_59 Depth=1
	ldrsh	w8, [x23, x28, lsl #1]
	cmn	w8, #1
	b.ne	LBB61_88
LBB61_85:                               ;   in Loop: Header=BB61_59 Depth=1
	add	w24, w24, #1
LBB61_86:                               ;   in Loop: Header=BB61_59 Depth=1
	add	x28, x28, #1
	cmp	x28, x22
	b.ne	LBB61_59
; %bb.87:
	and	w8, w24, #0xffff
	b	LBB61_92
LBB61_88:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB61_36
; %bb.89:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB61_37
; %bb.90:
	mov	w8, #8                          ; =0x8
	b	LBB61_124
LBB61_91:
	mov	w8, #0                          ; =0x0
	mov	w26, #0                         ; =0x0
LBB61_92:
	ldrb	w9, [sp, #184]
	cmp	w9, #15
	b.ne	LBB61_97
; %bb.93:
	cmp	w26, #1
	b.eq	LBB61_97
LBB61_94:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB61_36
; %bb.95:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB61_37
; %bb.96:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	w0, [x8, #40]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #48]
	b	LBB61_37
LBB61_97:
	sub	w9, w9, #153
	cmp	w26, #0
	ccmn	w9, #2, #0, eq
	b.hs	LBB61_94
; %bb.98:
	ldrh	w9, [sp, #144]
	cmp	w22, w9
	b.ne	LBB61_94
; %bb.99:
	ldrh	w9, [sp, #148]
	cmp	w26, w9
	b.ne	LBB61_94
; %bb.100:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w9, [x9, #-24]
	add	w8, w8, w25
	subs	w26, w9, w8
	b.lo	LBB61_94
; %bb.101:
	add	x8, sp, #776
	ldrh	w8, [x8, #114]
	cmp	w25, #0
	mov	w9, #1                          ; =0x1
	cinc	w9, w9, ne
	add	w9, w9, w22
	cmp	w9, w8
	b.hi	LBB61_94
; %bb.102:
	ldrb	w8, [sp, #792]
	ldrb	w9, [sp, #150]
	cmp	w8, w9
	b.ne	LBB61_94
; %bb.103:
	cbz	w8, LBB61_107
; %bb.104:
	add	x8, sp, #776
	ldur	x8, [x8, #20]
	ldr	x9, [sp, #152]
	eor	x8, x9, x8
	tst	x8, #0xff
	b.ne	LBB61_94
; %bb.105:
	mov	x9, #-256                       ; =0xffffffffffffff00
	movk	x9, #0, lsl #16
	tst	x8, x9
	b.ne	LBB61_94
; %bb.106:
	ldr	x9, [sp, #160]
	add	x8, sp, #776
	ldur	x8, [x8, #28]
	cmp	x8, x9
	b.ne	LBB61_94
LBB61_107:
	add	x3, sp, #55
	mov	x0, x19
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	mov	w2, #0                          ; =0x0
	bl	_frc_edge
	tbz	w0, #0, LBB61_94
; %bb.108:
	ldrb	w8, [sp, #792]
	ldrh	w20, [sp, #102]
	add	w8, w26, w8
	cmp	w8, w20
	b.ne	LBB61_94
; %bb.109:
	add	x8, sp, #776
	ldrh	w8, [x8, #110]
	cmp	w20, w8
	b.hi	LBB61_94
; %bb.110:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w1, [x8]
	add	x8, sp, #176
	ldrh	w2, [x8, #72]
	ldrb	w3, [sp, #55]
	add	x4, sp, #1000
	add	x5, sp, #920
	mov	x0, x19
	bl	_fr_instruction
	cbz	w0, LBB61_94
; %bb.111:
	ldrb	w8, [sp, #920]
	tbz	w8, #0, LBB61_94
; %bb.112:
	add	x8, sp, #776
	ldrh	w8, [x8, #148]
	cmp	w20, w8
	b.ne	LBB61_94
; %bb.113:
	ldp	x10, x8, [sp, #16]              ; 16-byte Folded Reload
	ldur	w9, [x8, #-28]
	ldr	w11, [x10, #4]
	add	x8, sp, #776
	ldrh	w8, [x8, #110]
	cmp	w11, #0
	csel	w8, w26, w8, eq
	ldrh	w3, [x10, #8]
	add	x2, x8, x9
	add	x4, sp, #56
	add	x5, sp, #776
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_frf_layout
	cbz	w0, LBB61_94
; %bb.114:
	add	x4, sp, #1000
	add	x5, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_fr_instruction
	cbz	w0, LBB61_94
; %bb.115:
	ldrb	w8, [sp, #920]
	tbz	w8, #0, LBB61_94
; %bb.116:
	add	x8, sp, #776
	ldrh	w8, [x8, #148]
	cbnz	w8, LBB61_94
; %bb.117:
	add	x8, sp, #776
	ldrh	w8, [x8, #38]
	ldp	w23, w9, [sp, #64]
	add	w11, w9, w8
	cmp	w23, w11
	b.hs	LBB61_130
; %bb.118:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w9, w8, w26
	mov	w10, #176                       ; =0xb0
	umull	x10, w23, w10
	sub	w11, w11, w23
	mov	x12, x23
	b	LBB61_126
LBB61_119:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.ne	LBB61_122
; %bb.120:
	mov	w0, #8                          ; =0x8
	b	LBB61_37
LBB61_121:
	bl	___stack_chk_fail
LBB61_122:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB61_37
; %bb.123:
	mov	w8, #4                          ; =0x4
LBB61_124:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w0, [x9, #40]
	str	w8, [x9, #48]
	b	LBB61_37
LBB61_125:                              ;   in Loop: Header=BB61_126 Depth=1
	add	x12, x12, #1
	add	x10, x10, #176
	subs	w11, w11, #1
	b.eq	LBB61_130
LBB61_126:                              ; =>This Inner Loop Header: Depth=1
	cmp	x12, x9
	b.lo	LBB61_128
; %bb.127:                              ;   in Loop: Header=BB61_126 Depth=1
	ldr	x13, [sp, #24]                  ; 8-byte Folded Reload
	ldur	w13, [x13, #-24]
	add	w13, w13, w8
	cmp	x12, x13
	b.lo	LBB61_125
LBB61_128:                              ;   in Loop: Header=BB61_126 Depth=1
	ldr	w13, [x19, #128]
	cmp	x12, x13
	b.hs	LBB61_94
; %bb.129:                              ;   in Loop: Header=BB61_126 Depth=1
	ldr	x13, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x13, [x13]
	ldrb	w13, [x13, x10]
	cmp	w13, #1
	b.ne	LBB61_125
	b	LBB61_94
LBB61_130:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w10, [sp, #80]
	mov	w9, #256                        ; =0x100
	str	x10, [sp, #32]                  ; 8-byte Folded Spill
                                        ; kill: def $w10 killed $w10 killed $x10 def $x10
LBB61_131:                              ; =>This Inner Loop Header: Depth=1
	ubfiz	x11, x10, #6, #32
	ldrb	w11, [x8, x11]
	cmp	w11, #1
	b.eq	LBB61_94
; %bb.132:                              ;   in Loop: Header=BB61_131 Depth=1
	add	w10, w10, #1
	subs	x9, x9, #1
	b.ne	LBB61_131
; %bb.133:
	cbz	w22, LBB61_151
; %bb.134:
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w25, w8, w26
	add	x8, sp, #1000
	orr	x27, x8, #0x3
	b	LBB61_137
LBB61_135:                              ;   in Loop: Header=BB61_137 Depth=1
	and	w8, w28, #0x1
	add	w20, w20, w8
	add	w25, w25, #1
LBB61_136:                              ;   in Loop: Header=BB61_137 Depth=1
	add	w21, w21, #1
	cmp	w22, w21, uxth
	b.ls	LBB61_152
LBB61_137:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB61_145 Depth 2
	and	w2, w21, #0xffff
	add	x3, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_fr_local
	tbz	w0, #0, LBB61_169
; %bb.138:                              ;   in Loop: Header=BB61_137 Depth=1
	ldrb	w8, [sp, #921]
	cbnz	w8, LBB61_136
; %bb.139:                              ;   in Loop: Header=BB61_137 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w25, w9, x8
	ldrb	w9, [x8]
	ldrb	w28, [x8, #1]
	ldrb	w24, [x8, #2]
	ldur	q0, [x8, #67]
	str	q0, [x27, #64]
	ldur	q0, [x8, #83]
	str	q0, [x27, #80]
	ldur	q0, [x8, #99]
	str	q0, [x27, #96]
	ldr	x10, [x8, #112]
	stur	x10, [x27, #109]
	ldur	q0, [x8, #3]
	str	q0, [x27]
	ldur	q0, [x8, #19]
	str	q0, [x27, #16]
	ldur	q0, [x8, #35]
	str	q0, [x27, #32]
	ldur	q0, [x8, #51]
	str	q0, [x27, #48]
	strb	w9, [sp, #1000]
	strb	w28, [sp, #1001]
	strb	w24, [sp, #1002]
	add	x8, sp, #776
	ldp	x1, x2, [x8, #144]
	add	x0, sp, #1000
	bl	_frf_matches
	cbz	w0, LBB61_147
; %bb.140:                              ;   in Loop: Header=BB61_137 Depth=1
	tbnz	w24, #0, LBB61_147
; %bb.141:                              ;   in Loop: Header=BB61_137 Depth=1
	tbz	w28, #0, LBB61_135
; %bb.142:                              ;   in Loop: Header=BB61_137 Depth=1
	ldr	w8, [x19, #132]
	cbz	w8, LBB61_135
; %bb.143:                              ;   in Loop: Header=BB61_137 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	add	x9, x9, #4
	b	LBB61_145
LBB61_144:                              ;   in Loop: Header=BB61_145 Depth=2
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB61_135
LBB61_145:                              ;   Parent Loop BB61_137 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB61_144
; %bb.146:                              ;   in Loop: Header=BB61_145 Depth=2
	ldr	w10, [x9]
	cmp	w10, w25
	b.ne	LBB61_144
LBB61_147:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB61_150
; %bb.148:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	cbnz	w8, LBB61_150
; %bb.149:
	mov	w8, #6                          ; =0x6
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w8, [x9, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #48]
LBB61_150:
	mov	w0, #6                          ; =0x6
	b	LBB61_37
LBB61_151:
	mov	w20, #0                         ; =0x0
LBB61_152:
	ldrh	w8, [sp, #146]
	cmp	w8, w20, uxth
	b.ne	LBB61_94
; %bb.153:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w8, #152
	b.eq	LBB61_155
; %bb.154:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w8, #60
	b.ne	LBB61_156
LBB61_155:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	mov	w10, #176                       ; =0xb0
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	umaddl	x8, w8, w10, x9
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB61_156:
	cbz	w22, LBB61_172
; %bb.157:
	mov	w20, #0                         ; =0x0
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w21, w8, w26
	b	LBB61_159
LBB61_158:                              ;   in Loop: Header=BB61_159 Depth=1
	add	w20, w20, #1
	cmp	w22, w20
	b.eq	LBB61_163
LBB61_159:                              ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #1000
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x20
	bl	_fr_local
	tbz	w0, #0, LBB61_94
; %bb.160:                              ;   in Loop: Header=BB61_159 Depth=1
	ldrb	w8, [sp, #1001]
	cbnz	w8, LBB61_158
; %bb.161:                              ;   in Loop: Header=BB61_159 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-20]
	add	w2, w20, w8
	mov	x0, x19
	mov	x1, x21
	bl	_nvm_services_runtime_move
	cbnz	w0, LBB61_37
; %bb.162:                              ;   in Loop: Header=BB61_159 Depth=1
	add	w21, w21, #1
	b	LBB61_158
LBB61_163:
	mov	x20, #0                         ; =0x0
	add	x21, sp, #1600
	b	LBB61_166
LBB61_164:                              ;   in Loop: Header=BB61_166 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-20]
	add	w1, w20, w8
	mov	x0, x19
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_services_runtime_move
	cbnz	w0, LBB61_37
LBB61_165:                              ;   in Loop: Header=BB61_166 Depth=1
	add	x20, x20, #1
	cmp	x22, x20
	b.eq	LBB61_172
LBB61_166:                              ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #1000
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x20
	bl	_fr_local
	tbz	w0, #0, LBB61_169
; %bb.167:                              ;   in Loop: Header=BB61_166 Depth=1
	ldrb	w8, [sp, #1001]
	add	x2, x23, x20
	cbz	w8, LBB61_164
; %bb.168:                              ;   in Loop: Header=BB61_166 Depth=1
	ldr	w1, [x21, x20, lsl #2]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	w3, w8, w20
	mov	x0, x19
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_services_runtime_bind_formal
	cbz	w0, LBB61_165
	b	LBB61_37
LBB61_169:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB61_36
; %bb.170:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	cbnz	w8, LBB61_36
; %bb.171:
	mov	w8, #5                          ; =0x5
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w8, [x9, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #48]
	b	LBB61_36
LBB61_172:
	ldp	x9, x10, [sp, #16]              ; 16-byte Folded Reload
	stur	w26, [x10, #-24]
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	stur	w8, [x10, #-4]
	mov	w8, #1                          ; =0x1
	sturh	w8, [x10, #-8]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldrh	w10, [x9, #8]
	add	w11, w10, #1
	strh	w11, [x9, #8]
	mov	w9, #40                         ; =0x28
	umaddl	x8, w10, w9, x8
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [x8]
	ldr	x9, [sp, #88]
	str	x9, [x8, #32]
	ldr	w8, [x19, #24]
	cbz	w8, LBB61_175
; %bb.173:
	add	x1, sp, #56
	mov	x0, x19
	bl	_frc_validate
	cbz	w0, LBB61_175
; %bb.174:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w0, [x8, #40]
	b	LBB61_37
LBB61_175:
	ldr	w1, [sp, #56]
	mov	x0, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_services_runtime_site
	b	LBB61_37
	.loh AdrpLdrGotLdr	Lloh80, Lloh81, Lloh82
	.loh AdrpLdrGotLdr	Lloh83, Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_call_target
_fr_call_target:                        ; @fr_call_target
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x3
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2, #8]
	cmp	w9, #59
	b.le	LBB62_4
; %bb.1:
	cmp	w9, #60
	b.eq	LBB62_9
; %bb.2:
	cmp	w9, #152
	b.eq	LBB62_9
; %bb.3:
	cmp	w9, #151
	b.eq	LBB62_6
	b	LBB62_8
LBB62_4:
	cmp	w9, #15
	b.eq	LBB62_6
; %bb.5:
	cmp	w9, #59
	b.ne	LBB62_8
LBB62_6:
	ldr	w8, [x2, #16]
	cmp	w8, w19
LBB62_7:
	cset	w0, eq
LBB62_8:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB62_9:
	mov	w0, #0                          ; =0x0
	cmp	w19, #63
	b.hi	LBB62_8
; %bb.10:
	ldr	w9, [x8, #24]
	cmp	w9, #2
	b.ne	LBB62_8
; %bb.11:
	ldr	x0, [x8, #16]
	ldr	w8, [x1]
	ldrh	w2, [x1, #4]
	ldrb	w3, [x1, #34]
	mov	x4, sp
	mov	x1, x8
	bl	_nvm_services_indirect_hosted_call
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB62_8
; %bb.12:
	ldr	x8, [sp, #8]
	cbz	x8, LBB62_8
; %bb.13:
	ldr	x9, [sp, #16]
	cmp	x8, x9
	b.ne	LBB62_8
; %bb.14:
	lsr	x8, x8, x19
	tbz	w8, #0, LBB62_16
; %bb.15:
	ldr	w8, [sp, #32]
	cmn	w8, #1
	b	LBB62_7
LBB62_16:
	mov	w0, #0                          ; =0x0
	b	LBB62_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_return ; -- Begin function nvm_services_runtime_frame_return
	.p2align	2
_nvm_services_runtime_frame_return:     ; @nvm_services_runtime_frame_return
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh86:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh87:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh88:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	cbz	x0, LBB63_3
; %bb.1:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x22, x8, #2728
	ldrb	w8, [x22, #10]
	tbz	w8, #0, LBB63_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB63_23
LBB63_3:
	mov	w0, #1                          ; =0x1
	b	LBB63_23
LBB63_4:
	ldr	w8, [x22]
	cmp	w8, #1
	b.ne	LBB63_22
; %bb.5:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x23, x8, #4064
	ldr	w0, [x23, #40]
	cbnz	w0, LBB63_23
; %bb.6:
	ldrb	w8, [x22, #12]
	tbz	w8, #0, LBB63_9
LBB63_7:
	mov	w0, #5                          ; =0x5
LBB63_8:
	str	w0, [x23, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #48]
	b	LBB63_23
LBB63_9:
	add	x1, sp, #896
	add	x2, sp, #296
	add	x3, sp, #216
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB63_20
; %bb.10:
	mov	x12, x19
	ldr	w10, [x19, #24]
	ldr	x8, [x23, #24]
	ldrh	w9, [x22, #8]
	cbz	w10, LBB63_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB63_20
LBB63_12:
	mov	w10, #40                        ; =0x28
	umaddl	x24, w9, w10, x8
	mov	x8, x24
	ldr	w9, [x8, #-40]!
	ldr	w10, [sp, #296]
	stp	w9, w10, [x23, #52]
	ldrb	w9, [sp, #304]
	cmp	w9, #61
	b.ne	LBB63_18
; %bb.13:
	ldrb	w9, [sp, #217]
	tbz	w9, #0, LBB63_18
; %bb.14:
	ldrb	w9, [sp, #372]
	cbnz	w9, LBB63_18
; %bb.15:
	ldrb	w9, [sp, #912]
	ldur	w27, [x24, #-24]
	cmp	w27, w9
	b.ne	LBB63_18
; %bb.16:
	ldrh	w11, [sp, #934]
	cmp	w11, w9
	b.lo	LBB63_18
; %bb.17:
	ldur	w10, [x24, #-28]
	ldr	w13, [x12, #128]
	sub	x12, x13, x10
	cmp	w10, w13
	ccmp	x12, x11, #0, ls
	b.hs	LBB63_25
LBB63_18:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB63_22
LBB63_19:
	ldr	w8, [x23, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB63_23
	b	LBB63_8
LBB63_20:
	ldr	w8, [x22]
	cmp	w8, #2
	b.eq	LBB63_22
; %bb.21:
	ldr	w8, [x23, #40]
	cbz	w8, LBB63_7
LBB63_22:
	mov	w0, #5                          ; =0x5
LBB63_23:
	ldur	x8, [x29, #-104]
Lloh89:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh90:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh91:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB63_120
; %bb.24:
	add	sp, sp, #2272
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB63_25:
	ldur	w14, [x24, #-20]
	cmp	w14, w13
	b.hi	LBB63_18
; %bb.26:
	ldrh	w12, [sp, #938]
	sub	x15, x13, x14
	cmp	x15, x12
	b.lo	LBB63_18
; %bb.27:
	cbz	w12, LBB63_32
; %bb.28:
	sub	w13, w13, w14
	mov	w15, #176                       ; =0xb0
	umull	x14, w14, w15
LBB63_29:                               ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB63_18
; %bb.30:                               ;   in Loop: Header=BB63_29 Depth=1
	ldr	x15, [x23]
	ldrb	w15, [x15, x14]
	tbnz	w15, #0, LBB63_18
; %bb.31:                               ;   in Loop: Header=BB63_29 Depth=1
	add	x14, x14, #176
	sub	x13, x13, #1
	sub	x12, x12, #1
	cbnz	x12, LBB63_29
LBB63_32:
	cbz	w11, LBB63_39
; %bb.33:
	mov	x12, #0                         ; =0x0
	ldr	x13, [x23]
	mov	w14, #176                       ; =0xb0
	b	LBB63_36
LBB63_34:                               ;   in Loop: Header=BB63_36 Depth=1
	tbnz	w16, #0, LBB63_18
LBB63_35:                               ;   in Loop: Header=BB63_36 Depth=1
	add	x12, x12, #1
	cmp	x11, x12
	b.eq	LBB63_39
LBB63_36:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w10, w12
	umaddl	x15, w15, w14, x13
	ldrb	w16, [x15]
	cmp	x12, x9
	b.hs	LBB63_34
; %bb.37:                               ;   in Loop: Header=BB63_36 Depth=1
	cbz	w16, LBB63_18
; %bb.38:                               ;   in Loop: Header=BB63_36 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB63_35
	b	LBB63_18
LBB63_39:
	ldr	w11, [x22, #20]
	ldur	w12, [x24, #-12]
	cmp	w11, w12
	b.ne	LBB63_18
; %bb.40:
	stp	x9, x8, [sp]                    ; 16-byte Folded Spill
	stp	x22, x10, [sp, #32]             ; 16-byte Folded Spill
	cbz	w9, LBB63_45
; %bb.41:
	ldr	x20, [x23]
	mov	w9, #176                        ; =0xb0
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	umaddl	x0, w8, w9, x20
	add	x8, sp, #896
	ldur	x1, [x8, #20]
	ldur	x2, [x8, #28]
	bl	_frf_matches
	cbz	w0, LBB63_43
; %bb.42:
	mov	w9, #176                        ; =0xb0
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	umaddl	x8, w8, w9, x20
	ldrb	w8, [x8, #2]
	tbz	w8, #0, LBB63_82
LBB63_43:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.ne	LBB63_71
; %bb.44:
	mov	w0, #6                          ; =0x6
	b	LBB63_23
LBB63_45:
	mov	w8, #-1                         ; =0xffffffff
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
LBB63_46:
	ldrh	w8, [sp, #936]
	cbz	w8, LBB63_73
; %bb.47:
	mov	w20, #0                         ; =0x0
	b	LBB63_49
LBB63_48:                               ;   in Loop: Header=BB63_49 Depth=1
	add	w20, w20, #1
	ldrh	w8, [sp, #936]
	cmp	w20, w8
	b.hs	LBB63_73
LBB63_49:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23]
	ldur	w9, [x24, #-32]
	add	w9, w20, w9
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w9, w10, x8
	ldr	s0, [x8]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	ldrb	w22, [x8, #2]
	ldrb	w28, [x8, #1]
	ldrb	w25, [x8]
	ldur	x21, [x8, #4]
	ldur	x26, [x8, #12]
	ldur	q0, [x8, #68]
	str	q0, [sp, #1696]
	ldur	q0, [x8, #84]
	str	q0, [sp, #1712]
	ldur	q0, [x8, #100]
	str	q0, [sp, #1728]
	ldr	w9, [x8, #116]
	str	w9, [sp, #1744]
	ldur	q0, [x8, #20]
	str	q0, [sp, #1648]
	ldur	q0, [x8, #36]
	str	q0, [sp, #1664]
	ldur	q0, [x8, #52]
	str	q0, [sp, #1680]
	ldur	w1, [x24, #-40]
	ldr	w8, [x19, #24]
	cbz	w8, LBB63_52
; %bb.50:                               ;   in Loop: Header=BB63_49 Depth=1
	cmp	w8, #2
	b.ne	LBB63_53
; %bb.51:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x0, [x19, #16]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_services_indirect_hosted_local
	b	LBB63_54
LBB63_52:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x0, [x19]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_services_hosted_local
	b	LBB63_54
LBB63_53:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x0, [x19, #8]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_services_cyclic_hosted_local
LBB63_54:                               ;   in Loop: Header=BB63_49 Depth=1
	cbz	w0, LBB63_68
; %bb.55:                               ;   in Loop: Header=BB63_49 Depth=1
	and	w8, w25, w28
	tbnz	w8, #0, LBB63_68
; %bb.56:                               ;   in Loop: Header=BB63_49 Depth=1
	ldrb	w8, [sp, #969]
	cbz	w8, LBB63_61
; %bb.57:                               ;   in Loop: Header=BB63_49 Depth=1
	tbz	w25, #0, LBB63_68
; %bb.58:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x9, [sp, #968]
	ldr	x8, [sp, #976]
	eor	x10, x9, x21
	and	x11, x10, #0xff
	cmp	x11, #0
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	and	x10, x10, x11
	ccmp	x10, #0, #0, eq
	ccmp	x26, x8, #0, eq
	b.ne	LBB63_68
; %bb.59:                               ;   in Loop: Header=BB63_49 Depth=1
	ands	x9, x9, #0xff00
	cset	w10, ne
	cmp	w22, w10
	b.ne	LBB63_68
; %bb.60:                               ;   in Loop: Header=BB63_49 Depth=1
	lsr	x8, x8, #32
	sub	x8, x8, #1
	cmp	x9, #0
	ccmp	x8, #2, #2, eq
	cset	w8, lo
	cmp	w28, w8
	b.ne	LBB63_68
LBB63_61:                               ;   in Loop: Header=BB63_49 Depth=1
	tbz	w22, #0, LBB63_48
; %bb.62:                               ;   in Loop: Header=BB63_49 Depth=1
	ldrh	w8, [sp, #908]
	cmp	w20, w8
	b.hs	LBB63_68
; %bb.63:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	ushll.8h	v0, v0, #0
	ldur	w22, [x24, #-16]
	uzp1.8b	v0, v0, v0
	str	s0, [sp, #1048]
	ldr	q0, [sp, #1696]
	ldr	q1, [sp, #1680]
	add	x9, sp, #1048
	stur	q0, [x9, #68]
	ldr	q0, [sp, #1712]
	ldr	q2, [sp, #1728]
	stur	q0, [x9, #84]
	stur	q2, [x9, #100]
	ldr	q0, [sp, #1648]
	ldr	q2, [sp, #1664]
	stur	q0, [x9, #20]
	stur	q2, [x9, #36]
	add	x8, sp, #896
	stur	x21, [x8, #156]
	stur	x26, [x8, #164]
	ldr	w8, [sp, #1744]
	stur	w8, [x9, #116]
	stur	q1, [x9, #52]
	ldr	x1, [sp, #968]
	ldr	x2, [sp, #976]
	add	x0, sp, #1048
	bl	_frf_matches
	cbz	w0, LBB63_68
; %bb.64:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x8, [x23]
	ldur	w9, [x24, #-32]
	add	w25, w20, w9
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w25, w9, x8
	ldr	w8, [x8, #152]
	add	w21, w20, w22
	cmp	w21, w8
	b.ne	LBB63_68
; %bb.65:                               ;   in Loop: Header=BB63_49 Depth=1
	mov	x0, x19
	mov	x1, x21
	bl	_fr_reference
	cbz	w0, LBB63_68
; %bb.66:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	x8, [x23, #8]
	add	x8, x8, x21, lsl #6
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB63_68
; %bb.67:                               ;   in Loop: Header=BB63_49 Depth=1
	ldr	w8, [x8, #12]
	cmp	w25, w8
	b.eq	LBB63_48
LBB63_68:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB63_22
; %bb.69:
	ldr	w8, [x23, #40]
	cbnz	w8, LBB63_22
; %bb.70:
	mov	w8, #5                          ; =0x5
	str	w8, [x23, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #48]
	b	LBB63_22
LBB63_71:
	ldr	w8, [x23, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB63_23
; %bb.72:
	str	w0, [x23, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x23, #48]
	b	LBB63_23
LBB63_73:
	mov	x20, #0                         ; =0x0
	ldr	x21, [x23, #8]
	ldur	w22, [x24, #-16]
	mov	w25, #176                       ; =0xb0
	ldrh	w26, [sp, #908]
	b	LBB63_75
LBB63_74:                               ;   in Loop: Header=BB63_75 Depth=1
	add	x20, x20, #1
	cmp	x20, #256
	b.eq	LBB63_87
LBB63_75:                               ; =>This Inner Loop Header: Depth=1
	add	x1, x22, x20
	mov	w8, w1
	add	x8, x21, x8, lsl #6
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB63_74
; %bb.76:                               ;   in Loop: Header=BB63_75 Depth=1
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	ccmp	x20, x26, #2, eq
	b.hs	LBB63_127
; %bb.77:                               ;   in Loop: Header=BB63_75 Depth=1
	ldur	w9, [x24, #-32]
	ldr	w10, [x19, #128]
	add	x9, x20, x9
	cmp	w9, w10
	b.hs	LBB63_127
; %bb.78:                               ;   in Loop: Header=BB63_75 Depth=1
	ldr	x10, [x23]
	mov	w11, w9
	umull	x12, w11, w25
	ldrb	w12, [x10, x12]
	cmp	w12, #1
	b.ne	LBB63_127
; %bb.79:                               ;   in Loop: Header=BB63_75 Depth=1
	umaddl	x10, w11, w25, x10
	ldrb	w10, [x10, #2]
	cmp	w10, #1
	b.ne	LBB63_127
; %bb.80:                               ;   in Loop: Header=BB63_75 Depth=1
	ldr	w8, [x8, #12]
	cmp	w9, w8
	b.ne	LBB63_127
; %bb.81:                               ;   in Loop: Header=BB63_75 Depth=1
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_fr_reference
	tbnz	w0, #0, LBB63_74
	b	LBB63_127
LBB63_82:
	ldr	w8, [x19, #132]
	cbz	w8, LBB63_46
; %bb.83:
	ldr	x9, [x23, #8]
	add	x9, x9, #4
	b	LBB63_85
LBB63_84:                               ;   in Loop: Header=BB63_85 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB63_46
LBB63_85:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB63_84
; %bb.86:                               ;   in Loop: Header=BB63_85 Depth=1
	ldr	w11, [x9]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	cmp	w11, w10
	b.ne	LBB63_84
	b	LBB63_43
LBB63_87:
	strb	wzr, [sp, #215]
	str	xzr, [sp, #192]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	add	x0, sp, #1648
	mov	w1, #600                        ; =0x258
	bl	_bzero
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	str	q0, [sp, #48]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #8]
	cmp	x8, #2
	b.lo	LBB63_108
; %bb.88:
	ldr	x9, [x23, #24]
	sub	w8, w8, #2
	mov	w10, #40                        ; =0x28
	umaddl	x20, w8, w10, x9
	ldrb	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB63_127
; %bb.89:
	ldr	w1, [x20]
	add	x2, sp, #128
	mov	x0, x19
	bl	_fr_function
	cbz	w0, LBB63_127
; %bb.90:
	ldr	w1, [x20]
	ldrh	w2, [x20, #4]
	ldrb	w3, [x20, #34]
	add	x4, sp, #1648
	add	x5, sp, #48
	mov	x0, x19
	bl	_fr_instruction
	ldrb	w8, [sp, #1724]
	cmp	w0, #0
	ccmp	w8, #1, #0, ne
	b.ne	LBB63_127
; %bb.91:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w3, [x8]
	add	x2, sp, #1648
	mov	x0, x19
	mov	x1, x20
	bl	_fr_call_target
	cbz	w0, LBB63_127
; %bb.92:
	ldr	w9, [x20, #36]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w9, w8
	b.ne	LBB63_127
; %bb.93:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB63_127
; %bb.94:
	ldr	w1, [x20, #20]
	ldrh	w2, [sp, #170]
	mov	x0, x19
	bl	_frf_empty_range
	cbz	w0, LBB63_127
; %bb.95:
	ldrh	w8, [sp, #54]
	ldr	w9, [x20, #16]
	add	w9, w9, w27
	cmp	w9, w8
	b.ne	LBB63_127
; %bb.96:
	add	x3, sp, #215
	mov	x0, x19
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_frc_edge
	cbz	w0, LBB63_127
; %bb.97:
	ldr	w1, [x20]
	ldrh	w2, [sp, #1720]
	ldrb	w21, [sp, #215]
	ldrh	w22, [sp, #54]
	add	x4, sp, #1048
	add	x5, sp, #968
	mov	x0, x19
	mov	x3, x21
	bl	_fr_instruction
	cbz	w0, LBB63_127
; %bb.98:
	ldrb	w8, [sp, #968]
	tbz	w8, #0, LBB63_127
; %bb.99:
	ldrh	w8, [sp, #972]
	cmp	w22, w8
	b.ne	LBB63_127
; %bb.100:
	ldr	w8, [x20, #16]
	cbz	w8, LBB63_106
; %bb.101:
	ldr	w10, [x20, #12]
	ldr	w9, [x19, #128]
	subs	w9, w9, w10
	csel	w9, wzr, w9, lo
	mov	w11, #176                       ; =0xb0
	umull	x10, w10, w11
LBB63_102:                              ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB63_127
; %bb.103:                              ;   in Loop: Header=BB63_102 Depth=1
	ldr	x11, [x23]
	ldrb	w12, [x11, x10]
	cmp	w12, #1
	b.ne	LBB63_127
; %bb.104:                              ;   in Loop: Header=BB63_102 Depth=1
	add	x11, x11, x10
	ldrb	w11, [x11, #2]
	cmp	w11, #1
	b.eq	LBB63_127
; %bb.105:                              ;   in Loop: Header=BB63_102 Depth=1
	sub	x9, x9, #1
	add	x10, x10, #176
	subs	x8, x8, #1
	b.ne	LBB63_102
LBB63_106:
	ldr	w8, [x20, #20]
	ldrh	w9, [sp, #170]
	add	w8, w8, w9
	sub	w27, w8, #1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	cbz	w8, LBB63_109
; %bb.107:
	mov	x0, x19
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, x27
	bl	_nvm_services_runtime_move
	cbnz	w0, LBB63_23
	b	LBB63_109
LBB63_108:
	mov	w21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w27, #-1                        ; =0xffffffff
LBB63_109:
	mov	w22, #0                         ; =0x0
	b	LBB63_111
LBB63_110:                              ;   in Loop: Header=BB63_111 Depth=1
	add	w22, w22, #1
	cmp	w22, #256
	b.eq	LBB63_113
LBB63_111:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #8]
	ldur	w9, [x24, #-16]
	add	w1, w22, w9
	ubfiz	x9, x1, #6, #32
	ldrb	w8, [x8, x9]
	cmp	w8, #1
	b.ne	LBB63_110
; %bb.112:                              ;   in Loop: Header=BB63_111 Depth=1
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_services_runtime_end_reference
	cbz	w0, LBB63_110
	b	LBB63_23
LBB63_113:
	cbz	x20, LBB63_125
; %bb.114:
	ldrh	w8, [sp, #934]
	ldp	w9, w10, [x24, #-32]
	add	w10, w10, w8
	cmp	w9, w10
	b.hs	LBB63_117
; %bb.115:
	mov	w8, #176                        ; =0xb0
	umull	x8, w9, w8
	sub	x9, x10, x9
	movi.2d	v0, #0000000000000000
LBB63_116:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x23]
	add	x10, x10, x8
	stp	q0, q0, [x10, #144]
	stp	q0, q0, [x10, #112]
	stp	q0, q0, [x10, #80]
	stp	q0, q0, [x10, #48]
	stp	q0, q0, [x10, #16]
	str	q0, [x10]
	add	x8, x8, #176
	subs	x9, x9, #1
	b.ne	LBB63_116
LBB63_117:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w9, [x8, #8]
	sub	w9, w9, #1
	strh	w9, [x8, #8]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #57]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	cbz	w8, LBB63_121
; %bb.118:
	ldp	w8, w9, [x20, #12]
	add	w2, w9, w8
	mov	x0, x19
	mov	x1, x27
	bl	_nvm_services_runtime_move
	cbz	w0, LBB63_121
; %bb.119:
	strb	wzr, [x19, #57]
	b	LBB63_23
LBB63_120:
	bl	___stack_chk_fail
LBB63_121:
	mov	x0, x19
	strb	wzr, [x19, #57]
	ldrh	w24, [sp, #54]
	add	x2, sp, #128
	mov	x1, x20
	mov	x3, x24
	bl	_frf_stack
	tbz	w0, #0, LBB63_127
; %bb.122:
	str	w24, [x20, #16]
	strh	wzr, [x20, #32]
	ldrh	w8, [sp, #1720]
	str	w8, [x20, #4]
	strb	w21, [x20, #34]
	str	wzr, [x20, #36]
	ldr	w9, [x19, #24]
	cbz	w9, LBB63_129
; %bb.123:
	mov	x0, x19
	mov	x1, x20
	bl	_frc_validate
	cbz	w0, LBB63_128
; %bb.124:
	ldr	w0, [x23, #40]
	b	LBB63_23
LBB63_125:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x8]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #16]
	cmp	w9, w8
	b.ne	LBB63_127
; %bb.126:
	mov	x0, x19
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_services_runtime_complete_root
	b	LBB63_23
LBB63_127:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB63_22
	b	LBB63_19
LBB63_128:
	ldr	w8, [x20, #4]
LBB63_129:
	ldr	w1, [x20]
	and	w2, w8, #0xffff
	mov	x0, x19
	bl	_nvm_services_runtime_site
	b	LBB63_23
	.loh AdrpLdrGotLdr	Lloh86, Lloh87, Lloh88
	.loh AdrpLdrGotLdr	Lloh89, Lloh90, Lloh91
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_region_begin ; -- Begin function nvm_services_runtime_frame_region_begin
	.p2align	2
_nvm_services_runtime_frame_region_begin: ; @nvm_services_runtime_frame_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB64_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB64_4
LBB64_2:
	mov	w0, #11                         ; =0xb
	b	LBB64_28
LBB64_3:
	mov	w0, #1                          ; =0x1
	ret
LBB64_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB64_27
; %bb.5:
	mov	x19, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4080
	ldr	w0, [x20, #24]
	cbnz	w0, LBB64_28
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB64_9
LBB64_7:
	mov	w0, #5                          ; =0x5
LBB64_8:
	str	w0, [x20, #24]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #32]
	b	LBB64_28
LBB64_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB64_24
; %bb.10:
	ldr	w11, [x19, #24]
	ldr	x8, [x20, #8]
	ldrh	w10, [x21, #8]
	cbz	w11, LBB64_12
; %bb.11:
	mov	w9, #40                         ; =0x28
	umaddl	x9, w10, w9, x8
	ldurb	w9, [x9, #-7]
	tbz	w9, #0, LBB64_24
LBB64_12:
	mov	w9, #40                         ; =0x28
	umaddl	x12, w10, w9, x8
	ldur	w9, [x12, #-40]
	ldr	w13, [sp, #80]
	stp	w9, w13, [x20, #36]
	ldrb	w9, [sp, #88]
	cmp	w9, #22
	b.ne	LBB64_26
; %bb.13:
	ldr	w9, [x21, #20]
	ldur	w12, [x12, #-12]
	subs	w12, w9, w12
	b.lo	LBB64_26
; %bb.14:
	cmp	w12, #256
	b.hs	LBB64_26
; %bb.15:
	ldrb	w12, [x21, #10]
	tbnz	w12, #0, LBB64_2
; %bb.16:
	ldr	w12, [x21]
	cmp	w12, #1
	b.ne	LBB64_27
; %bb.17:
	ldr	w0, [x20, #24]
	cbnz	w0, LBB64_28
; %bb.18:
	ldrb	w12, [x21, #12]
	tbnz	w12, #0, LBB64_7
; %bb.19:
	cbz	w11, LBB64_21
; %bb.20:
	ldrb	w11, [x19, #57]
	tbz	w11, #0, LBB64_31
LBB64_21:
	ldr	w8, [x19, #136]
	cmp	w9, w8
	b.eq	LBB64_30
; %bb.22:
	ldr	x8, [x21, #24]
	cmn	x8, #1
	b.eq	LBB64_30
; %bb.23:
	mov	w0, #0                          ; =0x0
	add	x10, x8, #1
	str	x10, [x21, #24]
	ldr	x10, [x20]
	add	w11, w9, #1
	str	w11, [x21, #20]
	str	x8, [x10, x9, lsl #3]
	b	LBB64_28
LBB64_24:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB64_27
; %bb.25:
	ldr	w8, [x20, #24]
	cbnz	w8, LBB64_27
	b	LBB64_7
LBB64_26:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB64_29
LBB64_27:
	mov	w0, #5                          ; =0x5
LBB64_28:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB64_29:
	ldr	w8, [x20, #24]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB64_28
	b	LBB64_8
LBB64_30:
	mov	w0, #3                          ; =0x3
	str	w0, [x20, #24]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #32]
	b	LBB64_28
LBB64_31:
	cbz	w10, LBB64_7
; %bb.32:
	sub	w10, w10, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w10, w11, x8
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB64_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB64_7
	b	LBB64_21
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_region_end ; -- Begin function nvm_services_runtime_frame_region_end
	.p2align	2
_nvm_services_runtime_frame_region_end: ; @nvm_services_runtime_frame_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB65_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB65_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB65_19
LBB65_3:
	mov	w0, #1                          ; =0x1
	ret
LBB65_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB65_18
; %bb.5:
	mov	x19, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4088
	ldr	w0, [x20, #16]
	cbnz	w0, LBB65_19
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB65_9
LBB65_7:
	mov	w0, #5                          ; =0x5
LBB65_8:
	str	w0, [x20, #16]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #24]
	b	LBB65_19
LBB65_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB65_15
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20]
	ldrh	w9, [x21, #8]
	cbz	w10, LBB65_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB65_15
LBB65_12:
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	ldur	w9, [x8, #-40]
	ldr	w10, [sp, #80]
	stp	w9, w10, [x20, #28]
	ldrb	w9, [sp, #88]
	cmp	w9, #23
	b.ne	LBB65_17
; %bb.13:
	ldr	w9, [x21, #20]
	ldur	w8, [x8, #-12]
	cmp	w9, w8
	b.ls	LBB65_17
; %bb.14:
	mov	x0, x19
	bl	_nvm_services_runtime_region_end
	b	LBB65_19
LBB65_15:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB65_18
; %bb.16:
	ldr	w8, [x20, #16]
	cbnz	w8, LBB65_18
	b	LBB65_7
LBB65_17:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB65_20
LBB65_18:
	mov	w0, #5                          ; =0x5
LBB65_19:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB65_20:
	ldr	w8, [x20, #16]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB65_19
	b	LBB65_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_borrow ; -- Begin function nvm_services_runtime_frame_borrow
	.p2align	2
_nvm_services_runtime_frame_borrow:     ; @nvm_services_runtime_frame_borrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB66_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB66_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB66_22
LBB66_3:
	mov	w0, #1                          ; =0x1
	ret
LBB66_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB66_21
; %bb.5:
	mov	x19, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4088
	ldr	w0, [x20, #16]
	cbnz	w0, LBB66_22
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB66_9
LBB66_7:
	mov	w0, #5                          ; =0x5
LBB66_8:
	str	w0, [x20, #16]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #24]
	b	LBB66_22
LBB66_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB66_18
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20]
	ldrh	w9, [x21, #8]
	cbz	w10, LBB66_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB66_18
LBB66_12:
	mov	w10, #40                        ; =0x28
	umaddl	x9, w9, w10, x8
	ldur	w8, [x9, #-40]
	ldr	w10, [sp, #80]
	stp	w8, w10, [x20, #28]
	ldrb	w10, [sp, #88]
	sub	w8, w10, #26
	cmn	w8, #2
	b.lo	LBB66_20
; %bb.13:
	ldrh	w8, [sp, #96]
	cmp	w8, #255
	b.hi	LBB66_20
; %bb.14:
	ldrh	w11, [sp, #104]
	ldurh	w12, [x29, #-64]
	cmp	w11, w12
	b.hs	LBB66_20
; %bb.15:
	ldr	w12, [x21, #20]
	ldur	w13, [x9, #-12]
	cmp	w12, w13
	b.ls	LBB66_20
; %bb.16:
	ldur	w12, [x9, #-32]
	ldur	w9, [x9, #-16]
	add	w1, w12, w11
	add	w2, w9, w8
	mov	x0, x19
	cmp	w10, #24
	b.ne	LBB66_24
; %bb.17:
	mov	w3, #1                          ; =0x1
	b	LBB66_25
LBB66_18:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB66_21
; %bb.19:
	ldr	w8, [x20, #16]
	cbnz	w8, LBB66_21
	b	LBB66_7
LBB66_20:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB66_23
LBB66_21:
	mov	w0, #5                          ; =0x5
LBB66_22:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB66_23:
	ldr	w8, [x20, #16]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB66_22
	b	LBB66_8
LBB66_24:
	mov	w3, #0                          ; =0x0
LBB66_25:
	bl	_file_runtime_borrow_mode
	b	LBB66_22
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_frame_end_reference ; -- Begin function nvm_services_runtime_frame_end_reference
	.p2align	2
_nvm_services_runtime_frame_end_reference: ; @nvm_services_runtime_frame_end_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB67_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB67_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB67_33
LBB67_3:
	mov	w0, #1                          ; =0x1
	ret
LBB67_4:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB67_32
; %bb.5:
	mov	x19, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4064
	ldr	w0, [x20, #40]
	cbnz	w0, LBB67_33
; %bb.6:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB67_9
LBB67_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x20, #40]
	mov	w8, #8                          ; =0x8
LBB67_8:
	str	w8, [x20, #48]
	b	LBB67_33
LBB67_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB67_30
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #24]
	ldrh	w9, [x21, #8]
	cbz	w10, LBB67_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB67_30
LBB67_12:
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	ldur	w9, [x8, #-40]
	ldr	w10, [sp, #80]
	stp	w9, w10, [x20, #52]
	ldrb	w9, [sp, #88]
	cmp	w9, #150
	b.ne	LBB67_28
; %bb.13:
	ldrh	w10, [sp, #96]
	cmp	w10, #255
	b.hi	LBB67_28
; %bb.14:
	ldur	w8, [x8, #-16]
	ldr	w9, [x19, #132]
	add	w1, w8, w10
	cmp	w1, w9
	b.hs	LBB67_28
; %bb.15:
	ldr	x11, [x20, #8]
	add	x8, x11, x1, lsl #6
	ldrb	w10, [x8]
	cmp	w10, #1
	b.ne	LBB67_28
; %bb.16:
	ldr	w10, [x8, #8]
	cmp	w10, w9
	b.hs	LBB67_28
; %bb.17:
	add	x9, x11, x10, lsl #6
	ldrb	w11, [x9]
	cmp	w11, #1
	b.ne	LBB67_28
; %bb.18:
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB67_28
; %bb.19:
	ldr	w11, [x9, #8]
	cmp	w11, w10
	b.ne	LBB67_28
; %bb.20:
	ldrb	w10, [x9, #2]
	ldrb	w11, [x8, #2]
	cmp	w10, w11
	b.ne	LBB67_28
; %bb.21:
	ldr	x10, [x9, #56]
	ldr	x11, [x8, #56]
	cmp	x10, x11
	b.ne	LBB67_28
; %bb.22:
	ldr	w9, [x9, #4]
	ldr	w10, [x8, #4]
	cmp	w9, w10
	b.ne	LBB67_28
; %bb.23:
	ldr	w10, [x19, #128]
	cmp	w9, w10
	b.hs	LBB67_28
; %bb.24:
	ldr	x10, [x20]
	mov	w11, #176                       ; =0xb0
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB67_28
; %bb.25:
	ldrb	w10, [x9, #1]
	cmp	w10, #1
	b.ne	LBB67_28
; %bb.26:
	ldr	w9, [x9, #16]
	cmp	w9, #1
	b.ne	LBB67_28
; %bb.27:
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB67_36
LBB67_28:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB67_34
; %bb.29:
	mov	w0, #8                          ; =0x8
	b	LBB67_33
LBB67_30:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB67_32
; %bb.31:
	ldr	w8, [x20, #40]
	cbz	w8, LBB67_7
LBB67_32:
	mov	w0, #5                          ; =0x5
LBB67_33:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB67_34:
	ldr	w8, [x20, #40]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB67_33
; %bb.35:
	str	w0, [x20, #40]
	mov	w8, #4                          ; =0x4
	b	LBB67_8
LBB67_36:
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_services_runtime_end_reference
	b	LBB67_33
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_cyclic_plan ; -- Begin function nvm_services_runtime_cyclic_plan
	.p2align	2
_nvm_services_runtime_cyclic_plan:      ; @nvm_services_runtime_cyclic_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB68_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB68_4
; %bb.2:
	ldr	x0, [x0, #8]
LBB68_3:
	ret
LBB68_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_services_runtime_cyclic_frame_view
lCPI69_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_cyclic_frame_view
	.p2align	2
_nvm_services_runtime_cyclic_frame_view: ; @nvm_services_runtime_cyclic_frame_view
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB69_6
; %bb.1:
	cbz	x1, LBB69_6
; %bb.2:
	ldr	w9, [x8, #24]
	cmp	w9, #1
	b.ne	LBB69_5
; %bb.3:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x20, x8
	mov	x0, x8
	bl	_frf_current
	tbz	w0, #0, LBB69_7
; %bb.4:
	add	x8, x20, #76, lsl #12           ; =311296
	add	x8, x8, #2732
	add	x9, x20, #72, lsl #12           ; =294912
	ldr	x9, [x9, #12280]
	ldrh	w10, [x8, #4]
	mov	w11, #40                        ; =0x28
	ldr	w8, [x8]
	umaddl	x9, w10, w11, x9
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	ldur	q1, [x9, #-32]
Lloh92:
	adrp	x14, lCPI69_0@PAGE
Lloh93:
	ldr	q2, [x14, lCPI69_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	ldurb	w14, [x9, #-6]
	ldurb	w9, [x9, #-7]
	mov	w0, #1                          ; =0x1
	stp	w0, w8, [x19]
	str	d0, [x19, #8]
	str	w11, [x19, #16]
	strh	w10, [x19, #20]
	stur	w12, [x19, #22]
	strh	w13, [x19, #26]
	stur	q1, [x19, #28]
	stur	d2, [x19, #44]
	strb	w14, [x19, #52]
	strb	w9, [x19, #53]
	strh	wzr, [x19, #54]
	b	LBB69_8
LBB69_5:
	mov	w0, #0                          ; =0x0
LBB69_6:
	ret
LBB69_7:
	mov	w0, #0                          ; =0x0
LBB69_8:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh92, Lloh93
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_cyclic_enter ; -- Begin function nvm_services_runtime_cyclic_enter
	.p2align	2
_nvm_services_runtime_cyclic_enter:     ; @nvm_services_runtime_cyclic_enter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB70_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB70_3
; %bb.2:
	b	_frc_enter
LBB70_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_enter
_frc_enter:                             ; @frc_enter
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	add	x8, x0, #76, lsl #12            ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB71_2
; %bb.1:
	mov	w0, #11                         ; =0xb
	b	LBB71_11
LBB71_2:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB71_10
; %bb.3:
	mov	x19, x0
	add	x8, x0, #74, lsl #12            ; =303104
	add	x20, x8, #4088
	ldr	w0, [x20, #16]
	cbnz	w0, LBB71_11
; %bb.4:
	ldrb	w8, [x21, #12]
	cmp	w8, #1
	b.ne	LBB71_7
; %bb.5:
	mov	w0, #5                          ; =0x5
LBB71_6:
	str	w0, [x20, #16]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #24]
	b	LBB71_11
LBB71_7:
	sub	x1, x29, #120
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	tbz	w0, #0, LBB71_9
; %bb.8:
	ldr	x8, [x20]
	ldrh	w9, [x21, #8]
	mov	w10, #40                        ; =0x28
	umaddl	x22, w9, w10, x8
	ldurb	w8, [x22, #-7]
	cmp	w8, #1
	b.ne	LBB71_13
LBB71_9:
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB71_12
LBB71_10:
	mov	w0, #5                          ; =0x5
LBB71_11:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB71_12:
	ldr	w8, [x20, #16]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB71_11
	b	LBB71_6
LBB71_13:
	mov	x1, x22
	ldr	w8, [x1, #-40]!
	ldr	w9, [sp, #80]
	stp	w8, w9, [x20, #28]
	mov	x0, x19
	bl	_frc_validate
	cbnz	w0, LBB71_11
; %bb.14:
	ldp	x9, x8, [x19, #40]
	cmp	x8, x9
	b.hi	LBB71_9
; %bb.15:
	b.ne	LBB71_18
; %bb.16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #56]
	ldr	w8, [x21]
	cmp	w8, #2
	b.ne	LBB71_19
; %bb.17:
	mov	w0, #3                          ; =0x3
	b	LBB71_11
LBB71_18:
	mov	w0, #0                          ; =0x0
	add	x8, x8, #1
	str	x8, [x19, #48]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x22, #-7]
	b	LBB71_11
LBB71_19:
	ldr	w8, [x20, #16]
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB71_11
; %bb.20:
	str	w0, [x20, #16]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #24]
	b	LBB71_11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_runtime_cyclic_report
lCPI72_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_cyclic_report
	.p2align	2
_nvm_services_runtime_cyclic_report:    ; @nvm_services_runtime_cyclic_report
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB72_6
; %bb.1:
	cbz	x1, LBB72_6
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB72_4
; %bb.3:
	add	x8, x0, #76, lsl #12            ; =311296
	ldrb	w8, [x8, #2738]
	tbz	w8, #0, LBB72_5
LBB72_4:
	mov	w0, #0                          ; =0x0
	ret
LBB72_5:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	stp	x9, x10, [sp, #-16]!
	stp	x11, x12, [sp, #-16]!
	mov	w9, #6720                       ; =0x1a40
Lloh94:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh95:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	ldp	x11, x12, [sp], #16
	ldp	x9, x10, [sp], #16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	add	x0, sp, #24
	add	x8, x19, #75, lsl #12           ; =307200
	mov	x20, x1
	add	x1, x8, #8
	mov	w2, #6696                       ; =0x1a28
	bl	_memcpy
	ldrb	w21, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [sp]                        ; 16-byte Folded Spill
Lloh96:
	adrp	x8, lCPI72_0@PAGE
Lloh97:
	ldr	d0, [x8, lCPI72_0@PAGEOFF]
	str	d0, [x20]
	add	x0, x20, #8
	add	x1, sp, #24
	mov	w2, #6696                       ; =0x1a28
	bl	_memcpy
	mov	w8, #6720                       ; =0x1a40
	strb	w21, [x20, x8]
	ldr	q0, [sp]                        ; 16-byte Folded Reload
	str	q0, [x20, #6704]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x20, x8]
	str	wzr, [x20, #6724]
	mov	w8, #1                          ; =0x1
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2624
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB72_6:
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdrGot	Lloh94, Lloh95
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_runtime_cyclic_finish
lCPI73_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_cyclic_finish
	.p2align	2
_nvm_services_runtime_cyclic_finish:    ; @nvm_services_runtime_cyclic_finish
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x8
	cbz	x0, LBB73_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB73_3
; %bb.2:
	add	x8, x19, #8
	mov	x20, x0
	bl	_fr_finish
Lloh98:
	adrp	x8, lCPI73_0@PAGE
Lloh99:
	ldr	d0, [x8, lCPI73_0@PAGEOFF]
	str	d0, [x19]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	str	q0, [x19, #6704]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	b	LBB73_4
LBB73_3:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh100:
	adrp	x8, lCPI73_0@PAGE
Lloh101:
	ldr	d0, [x8, lCPI73_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	str	xzr, [x19, #6704]
	str	xzr, [x19, #6720]
	str	xzr, [x19, #6712]
LBB73_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh100, Lloh101
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_runtime_cyclic_destroy
lCPI74_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_cyclic_destroy
	.p2align	2
_nvm_services_runtime_cyclic_destroy:   ; @nvm_services_runtime_cyclic_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB74_5
; %bb.1:
	ldr	x20, [x0]
	cbz	x20, LBB74_5
; %bb.2:
	ldr	w8, [x20, #24]
	cmp	w8, #1
	b.ne	LBB74_5
; %bb.3:
	add	x8, x20, #76, lsl #12           ; =311296
	ldrb	w8, [x8, #2738]
	cmp	w8, #1
	b.ne	LBB74_7
; %bb.4:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh102:
	adrp	x8, lCPI74_0@PAGE
Lloh103:
	ldr	d0, [x8, lCPI74_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #11                         ; =0xb
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	str	q0, [x19, #6704]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	b	LBB74_6
LBB74_5:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh104:
	adrp	x8, lCPI74_0@PAGE
Lloh105:
	ldr	d0, [x8, lCPI74_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	str	xzr, [x19, #6704]
	str	xzr, [x19, #6720]
	str	xzr, [x19, #6712]
LBB74_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB74_7:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x21, x8, #4064
	add	x8, x19, #8
	mov	x22, x0
	mov	x0, x20
	bl	_fr_finish
Lloh106:
	adrp	x8, lCPI74_0@PAGE
Lloh107:
	ldr	d0, [x8, lCPI74_0@PAGEOFF]
	str	d0, [x19]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	str	q0, [x19, #6704]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	ldr	x0, [x21, #24]
	bl	_free
	ldr	x0, [x21, #16]
	bl	_free
	ldr	x0, [x21, #8]
	bl	_free
	ldr	x0, [x21]
	bl	_free
	ldr	x0, [x20, #32]
	bl	_free
	ldr	x0, [x20, #8]
	bl	_nvm_services_cyclic_hosted_free
	mov	x0, x20
	bl	_free
	str	xzr, [x22]
	b	LBB74_6
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh106, Lloh107
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_cyclic_abi ; -- Begin function nvm_services_runtime_cyclic_abi
	.p2align	2
_nvm_services_runtime_cyclic_abi:       ; @nvm_services_runtime_cyclic_abi
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	ccmp	x1, #16, #0, eq
	mov	w8, #6728                       ; =0x1a48
	ccmp	x2, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x3, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x4, x8, #0, eq
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_cyclic_native_abi ; -- Begin function nvm_services_runtime_cyclic_native_abi
	.p2align	2
_nvm_services_runtime_cyclic_native_abi: ; @nvm_services_runtime_cyclic_native_abi
	.cfi_startproc
; %bb.0:
	cmp	x1, #16
	mov	w8, #6728                       ; =0x1a48
	ccmp	x2, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x5, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x3, x8, #0, eq
	cset	w8, eq
	cmp	x4, #48
	csel	w8, wzr, w8, ne
	cmp	w0, #1
	csel	w0, wzr, w8, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_indirect_plan ; -- Begin function nvm_services_runtime_indirect_plan
	.p2align	2
_nvm_services_runtime_indirect_plan:    ; @nvm_services_runtime_indirect_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB77_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB77_4
; %bb.2:
	ldr	x0, [x0, #16]
LBB77_3:
	ret
LBB77_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_services_runtime_indirect_frame_view
lCPI78_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_indirect_frame_view
	.p2align	2
_nvm_services_runtime_indirect_frame_view: ; @nvm_services_runtime_indirect_frame_view
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB78_6
; %bb.1:
	cbz	x1, LBB78_6
; %bb.2:
	ldr	w9, [x8, #24]
	cmp	w9, #2
	b.ne	LBB78_5
; %bb.3:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x20, x8
	mov	x0, x8
	bl	_frf_current
	tbz	w0, #0, LBB78_7
; %bb.4:
	add	x8, x20, #76, lsl #12           ; =311296
	add	x8, x8, #2732
	add	x9, x20, #72, lsl #12           ; =294912
	ldr	x9, [x9, #12280]
	ldrh	w10, [x8, #4]
	mov	w11, #40                        ; =0x28
	ldr	w8, [x8]
	umaddl	x9, w10, w11, x9
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	ldur	q1, [x9, #-32]
Lloh108:
	adrp	x14, lCPI78_0@PAGE
Lloh109:
	ldr	q2, [x14, lCPI78_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	ldurb	w14, [x9, #-6]
	ldurb	w9, [x9, #-7]
	mov	w0, #1                          ; =0x1
	stp	w0, w8, [x19]
	str	d0, [x19, #8]
	str	w11, [x19, #16]
	strh	w10, [x19, #20]
	stur	w12, [x19, #22]
	strh	w13, [x19, #26]
	stur	q1, [x19, #28]
	stur	d2, [x19, #44]
	strb	w14, [x19, #52]
	strb	w9, [x19, #53]
	strh	wzr, [x19, #54]
	b	LBB78_8
LBB78_5:
	mov	w0, #0                          ; =0x0
LBB78_6:
	ret
LBB78_7:
	mov	w0, #0                          ; =0x0
LBB78_8:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_indirect_enter ; -- Begin function nvm_services_runtime_indirect_enter
	.p2align	2
_nvm_services_runtime_indirect_enter:   ; @nvm_services_runtime_indirect_enter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB79_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB79_3
; %bb.2:
	b	_frc_enter
LBB79_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_services_runtime_indirect_funcref
lCPI80_0:
	.quad	-4294967285                     ; 0xffffffff0000000b
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_indirect_funcref
	.p2align	2
_nvm_services_runtime_indirect_funcref: ; @nvm_services_runtime_indirect_funcref
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB80_4
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #832
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB80_5
; %bb.2:
	add	x8, x19, #76, lsl #12           ; =311296
	add	x21, x8, #2728
	ldrb	w8, [x21, #10]
	tbz	w8, #0, LBB80_6
; %bb.3:
	mov	w0, #11                         ; =0xb
	b	LBB80_25
LBB80_4:
	mov	w0, #1                          ; =0x1
	ret
LBB80_5:
	mov	w0, #1                          ; =0x1
	b	LBB80_25
LBB80_6:
	ldr	w8, [x21]
	cmp	w8, #1
	b.ne	LBB80_24
; %bb.7:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x20, x8, #4064
	ldr	w0, [x20, #40]
	cbnz	w0, LBB80_25
; %bb.8:
	ldrb	w8, [x21, #12]
	tbz	w8, #0, LBB80_11
LBB80_9:
	mov	w0, #5                          ; =0x5
LBB80_10:
	str	w0, [x20, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #48]
	b	LBB80_25
LBB80_11:
	mov	x22, x1
	sub	x1, x29, #120
	add	x2, sp, #88
	add	x3, sp, #8
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB80_22
; %bb.12:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #24]
	ldrh	w9, [x21, #8]
	cbz	w10, LBB80_14
; %bb.13:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB80_22
LBB80_14:
	mov	w10, #40                        ; =0x28
	umaddl	x23, w9, w10, x8
	ldur	w8, [x23, #-40]
	ldr	w9, [sp, #88]
	stp	w8, w9, [x20, #52]
	ldrb	w8, [sp, #96]
	cmp	w8, #250
	b.ne	LBB80_20
; %bb.15:
	ldr	w1, [sp, #104]
	sub	x2, x29, #192
	mov	x0, x19
	bl	_fr_function
	cbz	w0, LBB80_20
; %bb.16:
	ldur	w8, [x23, #-24]
	ldurh	w9, [x29, #-82]
	cmp	w8, w9
	b.hs	LBB80_20
; %bb.17:
	ldur	w9, [x23, #-28]
	add	w8, w9, w8
	cmp	w22, w8
	b.ne	LBB80_20
; %bb.18:
	ldr	w8, [x19, #128]
	cmp	w22, w8
	b.hs	LBB80_20
; %bb.19:
	ldr	x8, [x20]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w22, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB80_26
LBB80_20:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB80_24
; %bb.21:
	ldr	w8, [x20, #40]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB80_25
	b	LBB80_10
LBB80_22:
	ldr	w8, [x21]
	cmp	w8, #2
	b.eq	LBB80_24
; %bb.23:
	ldr	w8, [x20, #40]
	cbz	w8, LBB80_9
LBB80_24:
	mov	w0, #5                          ; =0x5
LBB80_25:
	add	sp, sp, #832
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB80_26:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
Lloh110:
	adrp	x9, lCPI80_0@PAGE
Lloh111:
	ldr	q0, [x9, lCPI80_0@PAGEOFF]
	mov	w9, w22
	stur	q0, [x8, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #20]
	stur	q0, [x8, #36]
	stur	q0, [x8, #52]
	stur	q0, [x8, #68]
	stur	q0, [x8, #84]
	stur	q0, [x8, #100]
	str	wzr, [x8, #116]
	ldr	x8, [x19, #16]
	ldr	x10, [x20]
	mov	w11, #176                       ; =0xb0
	umaddl	x9, w9, w11, x10
	str	x8, [x9, #160]
	ldr	w8, [sp, #104]
	str	w8, [x9, #168]
	b	LBB80_25
	.loh AdrpLdr	Lloh110, Lloh111
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_runtime_indirect_finish
lCPI81_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_indirect_finish
	.p2align	2
_nvm_services_runtime_indirect_finish:  ; @nvm_services_runtime_indirect_finish
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x8
	cbz	x0, LBB81_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB81_3
; %bb.2:
	add	x8, x19, #8
	mov	x20, x0
	bl	_fr_finish
Lloh112:
	adrp	x8, lCPI81_0@PAGE
Lloh113:
	ldr	d0, [x8, lCPI81_0@PAGEOFF]
	str	d0, [x19]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	str	q0, [x19, #6704]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	b	LBB81_4
LBB81_3:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh114:
	adrp	x8, lCPI81_0@PAGE
Lloh115:
	ldr	d0, [x8, lCPI81_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	str	xzr, [x19, #6704]
	str	xzr, [x19, #6720]
	str	xzr, [x19, #6712]
LBB81_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh114, Lloh115
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_services_runtime_indirect_destroy
lCPI82_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_runtime_indirect_destroy
	.p2align	2
_nvm_services_runtime_indirect_destroy: ; @nvm_services_runtime_indirect_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB82_5
; %bb.1:
	ldr	x20, [x0]
	cbz	x20, LBB82_5
; %bb.2:
	ldr	w8, [x20, #24]
	cmp	w8, #2
	b.ne	LBB82_5
; %bb.3:
	add	x8, x20, #76, lsl #12           ; =311296
	ldrb	w8, [x8, #2738]
	cmp	w8, #1
	b.ne	LBB82_7
; %bb.4:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh116:
	adrp	x8, lCPI82_0@PAGE
Lloh117:
	ldr	d0, [x8, lCPI82_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #11                         ; =0xb
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	str	q0, [x19, #6704]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	b	LBB82_6
LBB82_5:
	add	x0, x19, #28
	mov	w1, #6676                       ; =0x1a14
	bl	_bzero
Lloh118:
	adrp	x8, lCPI82_0@PAGE
Lloh119:
	ldr	d0, [x8, lCPI82_0@PAGEOFF]
	str	d0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #8]
	stur	xzr, [x19, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #20]
	str	xzr, [x19, #6704]
	str	xzr, [x19, #6720]
	str	xzr, [x19, #6712]
LBB82_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB82_7:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x21, x8, #4064
	add	x8, x19, #8
	mov	x22, x0
	mov	x0, x20
	bl	_fr_finish
Lloh120:
	adrp	x8, lCPI82_0@PAGE
Lloh121:
	ldr	d0, [x8, lCPI82_0@PAGEOFF]
	str	d0, [x19]
	ldrb	w8, [x20, #56]
	ldur	q0, [x20, #40]
	mov	w9, #6720                       ; =0x1a40
	strb	w8, [x19, x9]
	str	q0, [x19, #6704]
	mov	w8, #6721                       ; =0x1a41
	str	wzr, [x19, x8]
	str	wzr, [x19, #6724]
	ldr	x0, [x21, #24]
	bl	_free
	ldr	x0, [x21, #16]
	bl	_free
	ldr	x0, [x21, #8]
	bl	_free
	ldr	x0, [x21]
	bl	_free
	ldr	x0, [x20, #32]
	bl	_free
	ldr	x0, [x20, #16]
	bl	_nvm_services_indirect_hosted_free
	mov	x0, x20
	bl	_free
	str	xzr, [x22]
	b	LBB82_6
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh120, Lloh121
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_indirect_native_abi ; -- Begin function nvm_services_runtime_indirect_native_abi
	.p2align	2
_nvm_services_runtime_indirect_native_abi: ; @nvm_services_runtime_indirect_native_abi
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	ccmp	x1, #16, #0, eq
	mov	w8, #6728                       ; =0x1a48
	ccmp	x2, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x3, x8, #0, eq
	mov	w8, #48                         ; =0x30
	ccmp	x4, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x5, x8, #0, eq
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_service_args ; -- Begin function nvm_services_runtime_service_args
	.p2align	2
_nvm_services_runtime_service_args:     ; @nvm_services_runtime_service_args
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #864
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh122:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh123:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh124:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	cbz	x0, LBB84_44
; %bb.1:
	mov	x19, x0
	add	x8, x0, #76, lsl #12            ; =311296
	add	x26, x8, #2728
	ldrb	w8, [x26, #10]
	tbz	w8, #0, LBB84_3
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB84_45
LBB84_3:
	ldr	w8, [x26]
	cmp	w8, #1
	b.ne	LBB84_7
; %bb.4:
	add	x8, x19, #74, lsl #12           ; =303104
	add	x25, x8, #4064
	ldr	w0, [x25, #40]
	cbnz	w0, LBB84_45
; %bb.5:
	ldrb	w8, [x26, #12]
	tbz	w8, #0, LBB84_8
LBB84_6:
	mov	w0, #5                          ; =0x5
	str	w0, [x25, #40]
	mov	w8, #8                          ; =0x8
	str	w8, [x25, #48]
	b	LBB84_45
LBB84_7:
	mov	w0, #5                          ; =0x5
	b	LBB84_45
LBB84_8:
	ldr	w8, [x19, #24]
	cbz	w8, LBB84_10
; %bb.9:
	ldrb	w8, [x19, #57]
	tbz	w8, #0, LBB84_17
LBB84_10:
	ldr	w8, [x19, #128]
	cmp	w5, w8
	b.hs	LBB84_43
; %bb.11:
	ldr	x8, [x25]
	mov	w9, #176                        ; =0xb0
	umull	x9, w5, w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB84_43
; %bb.12:
	mov	x23, x2
	sub	x2, x29, #148
	mov	x0, x19
	mov	x22, x1
	mov	x20, x5
	mov	x27, x3
	mov	x28, x4
	bl	_fr_import
	cbz	w0, LBB84_43
; %bb.13:
	mov	x8, x19
	ldur	w21, [x29, #-148]
	ldr	w9, [x19, #9616]
	add	w9, w9, w9, lsl #2
	cmp	w21, w9
	b.hs	LBB84_43
; %bb.14:
	mov	w9, #52429                      ; =0xcccd
	movk	w9, #52428, lsl #16
	umull	x9, w21, w9
	lsr	x24, x9, #34
	add	w9, w24, w24, lsl #2
	sub	w0, w21, w9
	add	x9, x8, x24, lsl #2
	ldr	w9, [x9, #9360]
	cmp	w9, #3
	b.eq	LBB84_20
; %bb.15:
	cmp	w9, #2
	b.ne	LBB84_37
; %bb.16:
	bl	_nl_socket_catalog_method
	b	LBB84_38
LBB84_17:
	ldrh	w8, [x26, #8]
	cbz	x8, LBB84_6
; %bb.18:
	ldr	x9, [x25, #24]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB84_6
; %bb.19:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB84_6
	b	LBB84_10
LBB84_20:
	ldr	w9, [x8, #24]
	cbz	w9, LBB84_26
; %bb.21:
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x9, [x25, #24]
	ldrh	w10, [x26, #8]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldur	w1, [x9, #-40]
	ldurh	w2, [x9, #-36]
	ldurb	w3, [x9, #-6]
	add	x4, sp, #192
	add	x5, sp, #112
	mov	x0, x8
	bl	_fr_instruction
	cbz	w0, LBB84_49
; %bb.22:
	ldrb	w8, [sp, #200]
	cmp	w8, #145
	b.ne	LBB84_49
; %bb.23:
	ldr	w8, [sp, #208]
	cmp	w8, w22
	b.ne	LBB84_49
; %bb.24:
	ldr	w8, [sp, #784]
	cmp	w8, w21
	b.ne	LBB84_49
; %bb.25:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
LBB84_26:
	mov	x21, x0
	bl	_nl_websocket_catalog_method
	cbz	x0, LBB84_43
; %bb.27:
	ldr	w22, [x0, #44]
	cmp	w22, #1
	cset	w10, eq
	ldr	x8, [x0, #56]
	mvn	x9, x10
	add	x9, x8, x9
	cmp	x28, x9
	b.ne	LBB84_43
; %bb.28:
	cbnz	x27, LBB84_30
; %bb.29:
	cbnz	x28, LBB84_43
LBB84_30:
	stp	x10, x26, [sp, #16]             ; 16-byte Folded Spill
	str	x25, [sp, #32]                  ; 8-byte Folded Spill
	mov	x25, x0
	str	x24, [sp, #8]                   ; 8-byte Folded Spill
	add	w24, w24, w24, lsl #3
	cmp	w22, #1
	b.ne	LBB84_57
; %bb.31:
	mov	x0, x19
	mov	x1, x23
	bl	_fr_reference
	cbz	w0, LBB84_58
; %bb.32:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	w9, w23
	add	x8, x8, x9, lsl #6
	ldrb	w9, [x8, #2]
	cmp	w9, #1
	b.eq	LBB84_58
; %bb.33:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	ldr	w8, [x8, #4]
	mov	w10, #176                       ; =0xb0
	umaddl	x8, w8, w10, x9
	ldr	x10, [x8, #4]!
	add	x9, x19, w24, uxtw #4
	ldr	x11, [x9, #144]!
	eor	x10, x11, x10
	tst	x10, #0xff
	b.eq	LBB84_62
LBB84_34:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB84_52
; %bb.35:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #40]
	mov	w0, #6                          ; =0x6
	cbnz	w9, LBB84_45
; %bb.36:
	str	w0, [x8, #40]
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #48]
	b	LBB84_45
LBB84_37:
	bl	_nl_file_catalog_method
LBB84_38:
	cbz	x0, LBB84_43
; %bb.39:
	ldr	w8, [x0, #44]
	cmp	w8, #1
	cset	w8, eq
	cmp	x28, #1
	b.hi	LBB84_43
; %bb.40:
	ldr	x9, [x0, #56]
	mvn	x8, x8
	add	x8, x8, x9
	cmp	x28, x8
	b.ne	LBB84_43
; %bb.41:
	cbnz	x27, LBB84_53
; %bb.42:
	cbz	x28, LBB84_53
LBB84_43:
	ldr	w8, [x26]
	cmp	w8, #2
	b.ne	LBB84_47
LBB84_44:
	mov	w0, #1                          ; =0x1
LBB84_45:
	ldur	x8, [x29, #-104]
Lloh125:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh126:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh127:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB84_103
; %bb.46:
	add	sp, sp, #864
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB84_47:
	ldr	w8, [x25, #40]
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB84_45
; %bb.48:
	str	w0, [x25, #40]
	str	w0, [x25, #48]
	b	LBB84_45
LBB84_49:
	ldr	w8, [x26]
	cmp	w8, #2
	b.eq	LBB84_52
; %bb.50:
	ldr	w8, [x25, #40]
	cbnz	w8, LBB84_52
; %bb.51:
	mov	w8, #6                          ; =0x6
	str	w8, [x25, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x25, #48]
LBB84_52:
	mov	w0, #6                          ; =0x6
	b	LBB84_45
LBB84_53:
	cbz	x28, LBB84_55
; %bb.54:
	ldr	w3, [x27]
	b	LBB84_56
LBB84_55:
	mov	w3, #-1                         ; =0xffffffff
LBB84_56:
	mov	x0, x19
	mov	x1, x22
	mov	x2, x23
	mov	x4, x20
	bl	_nvm_services_runtime_service
	b	LBB84_45
LBB84_57:
	cmn	w23, #1
	b.eq	LBB84_64
LBB84_58:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.ne	LBB84_60
; %bb.59:
	mov	w0, #8                          ; =0x8
	b	LBB84_45
LBB84_60:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #40]
	mov	w0, #8                          ; =0x8
	cbnz	w9, LBB84_45
; %bb.61:
	str	w0, [x8, #40]
	mov	w9, #4                          ; =0x4
	str	w9, [x8, #48]
	b	LBB84_45
LBB84_62:
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB84_34
; %bb.63:
	ldr	x9, [x9, #8]
	ldr	x8, [x8, #8]
	cmp	x8, x9
	b.ne	LBB84_34
LBB84_64:
	cbz	x28, LBB84_87
; %bb.65:
	mov	x26, #0                         ; =0x0
	b	LBB84_67
LBB84_66:                               ;   in Loop: Header=BB84_67 Depth=1
	add	x26, x26, #1
	cmp	x26, x28
	b.eq	LBB84_87
LBB84_67:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB84_69 Depth 2
	cbz	x26, LBB84_71
; %bb.68:                               ;   in Loop: Header=BB84_67 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, x27
	ldr	w8, [x27, x26, lsl #2]
LBB84_69:                               ;   Parent Loop BB84_67 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w11, [x10, x9, lsl #2]
	cmp	x8, x11
	b.eq	LBB84_84
; %bb.70:                               ;   in Loop: Header=BB84_69 Depth=2
	add	x9, x9, #1
	cmp	x26, x9
	b.ne	LBB84_69
	b	LBB84_72
LBB84_71:                               ;   in Loop: Header=BB84_67 Depth=1
	ldr	w8, [x27]
LBB84_72:                               ;   in Loop: Header=BB84_67 Depth=1
	ldr	w9, [x19, #128]
	cmp	x8, x9
	b.hs	LBB84_81
; %bb.73:                               ;   in Loop: Header=BB84_67 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	mov	w10, #176                       ; =0xb0
	umull	x8, w8, w10
	ldrb	w8, [x9, x8]
	cmp	w8, #1
	b.ne	LBB84_81
; %bb.74:                               ;   in Loop: Header=BB84_67 Depth=1
	ldr	x8, [x25, #48]
	mov	w10, #48                        ; =0x30
	madd	x8, x26, x10, x8
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	umaddl	x8, w9, w10, x8
	ldr	x2, [x8, #16]
	add	x3, sp, #192
	mov	x0, x19
	mov	x1, x24
	bl	_fr_member
	tbz	w0, #0, LBB84_81
; %bb.75:                               ;   in Loop: Header=BB84_67 Depth=1
	cmp	w22, #2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	w9, [x27, x26, lsl #2]
	mov	w10, #176                       ; =0xb0
	umaddl	x1, w9, w10, x8
	ccmp	x26, #0, #0, eq
	cset	w8, eq
	ldur	x9, [x1, #4]
	ldr	x10, [sp, #192]
	eor	x9, x10, x9
	tst	x9, #0xff
	b.ne	LBB84_81
; %bb.76:                               ;   in Loop: Header=BB84_67 Depth=1
	ldr	x10, [sp, #200]
	ldur	x11, [x1, #12]
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	and	x9, x9, x12
	cmp	x9, #0
	ccmp	x11, x10, #0, eq
	b.ne	LBB84_81
; %bb.77:                               ;   in Loop: Header=BB84_67 Depth=1
	ldrb	w9, [x1, #2]
	tbnz	w9, #0, LBB84_81
; %bb.78:                               ;   in Loop: Header=BB84_67 Depth=1
	ldrb	w9, [x1, #1]
	cmp	w9, w8
	b.ne	LBB84_81
; %bb.79:                               ;   in Loop: Header=BB84_67 Depth=1
	tbnz	w8, #0, LBB84_66
; %bb.80:                               ;   in Loop: Header=BB84_67 Depth=1
	mov	x0, x19
	bl	_fr_mixed_ws_payload
	tbnz	w0, #0, LBB84_66
LBB84_81:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB84_52
; %bb.82:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	cbnz	w8, LBB84_52
; %bb.83:
	mov	w8, #6                          ; =0x6
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w8, [x9, #40]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #48]
	b	LBB84_52
LBB84_84:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.eq	LBB84_44
; %bb.85:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [x8, #40]
	mov	w0, #1                          ; =0x1
	cbnz	w9, LBB84_45
; %bb.86:
	str	w0, [x8, #40]
	str	w0, [x8, #48]
	b	LBB84_45
LBB84_87:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x22, [x8]
	add	x8, x27, x28, lsl #2
	ldur	w8, [x8, #-4]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w8, w9, x22
	ldr	x26, [x8, #32]
	str	xzr, [sp, #96]
	mov	w25, w20
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	xzr, xzr, [sp, #40]
	str	xzr, [sp, #56]
	mov	w9, #1                          ; =0x1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	strb	w9, [x8, #10]
	cmp	w21, #2
	b.eq	LBB84_92
; %bb.88:
	cmp	w21, #1
	b.eq	LBB84_91
; %bb.89:
	cbnz	w21, LBB84_93
; %bb.90:
	ldr	w1, [x27]
	mov	x0, x19
	bl	_fr_string
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	ldr	x3, [x0, #8]
	mov	w9, #176                        ; =0xb0
	umaddl	x9, w25, w9, x22
	add	x2, x0, #16
	add	x5, x9, #120
	mov	x0, x8
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x4, x26
	bl	_nl_services_values_websocket_connect
	b	LBB84_94
LBB84_91:
	ldr	w8, [x27]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w8, w9, x22
	ldp	x8, x9, [x8, #32]
	add	x9, x19, x9, lsl #3
	add	x10, x9, #64, lsl #12           ; =262144
	ldr	x9, [x10, #12240]
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x0, [x10, #32]
	ldr	x10, [x10, #8]
	mov	w11, w23
	add	x10, x10, x11, lsl #6
	cmp	x8, #0
	cset	w3, ne
	ldr	x5, [x9, #8]
	add	x2, x10, #24
	add	x4, x9, #16
	add	x7, sp, #64
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x6, x26
	bl	_nl_services_value_websocket_send
	b	LBB84_94
LBB84_92:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldr	x8, [x8, #8]
	mov	w9, w23
	add	x8, x8, x9, lsl #6
	add	x2, x8, #24
	add	x4, sp, #40
	add	x5, sp, #64
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x3, x26
	bl	_nl_services_value_websocket_receive
	b	LBB84_94
LBB84_93:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #32]
	ldr	w8, [x27]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w8, w9, x22
	add	x2, x8, #120
	add	x4, sp, #64
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x3, x26
	bl	_nl_services_value_websocket_close
LBB84_94:
	mov	x22, x0
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	strb	wzr, [x8, #10]
	cbz	w0, LBB84_96
; %bb.95:
	add	x0, sp, #40
	bl	_nl_ws_message_free
	mov	x0, x19
	mov	x1, x22
	bl	_fr_core
	b	LBB84_45
LBB84_96:
	cbz	x28, LBB84_99
; %bb.97:
	mov	w8, #176                        ; =0xb0
	movi.2d	v0, #0000000000000000
LBB84_98:                               ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x27], #4
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x9, [x9]
	umaddl	x9, w10, w8, x9
	stp	q0, q0, [x9, #144]
	stp	q0, q0, [x9, #112]
	stp	q0, q0, [x9, #80]
	stp	q0, q0, [x9, #48]
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	subs	x28, x28, #1
	b.ne	LBB84_98
LBB84_99:
	cbz	w21, LBB84_104
; %bb.100:
	add	x22, sp, #192
	add	w8, w24, w21
	add	w8, w8, #3
	add	x8, x19, w8, uxtw #4
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22]
	str	xzr, [sp, #304]
	stp	q0, q0, [x22, #80]
	stp	q0, q0, [x22, #48]
	str	q0, [x22, #32]
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #192]
	ldr	w9, [x8, #156]
	ldr	q0, [x8, #144]
	stur	q0, [x22, #4]
	sub	x8, x9, #1
	cmp	x8, #2
	cset	w8, lo
	strb	w8, [sp, #193]
	ldr	w8, [sp, #64]
	cmp	w8, #0
	mov	w9, #2                          ; =0x2
	cinc	w9, w9, ne
	str	w9, [sp, #212]
	cbz	w8, LBB84_105
; %bb.101:
	mov	w8, #9                          ; =0x9
	strb	w8, [sp, #216]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x22, #608]
	ldr	x8, [sp, #96]
	stur	x8, [x29, #-112]
	add	x9, sp, #192
	mov	w10, #3                         ; =0x3
	str	x10, [sp, #112]
	stur	q0, [sp, #120]
	stur	q1, [sp, #136]
	str	x8, [sp, #152]
	add	x0, sp, #112
	add	x1, x9, #32
	bl	_fr_error_payload
LBB84_102:
	add	x0, sp, #40
	bl	_nl_ws_message_free
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w25, w9, x8
	ldr	q0, [x22, #64]
	str	q0, [x8, #64]
	ldr	q0, [x22, #80]
	str	q0, [x8, #80]
	ldr	q0, [x22, #96]
	str	q0, [x8, #96]
	ldr	x9, [sp, #304]
	str	x9, [x8, #112]
	ldr	q0, [x22]
	str	q0, [x8]
	ldr	q0, [x22, #16]
	str	q0, [x8, #16]
	ldr	q0, [x22, #32]
	str	q0, [x8, #32]
	ldr	q0, [x22, #48]
	str	q0, [x8, #48]
	b	LBB84_45
LBB84_103:
	bl	___stack_chk_fail
LBB84_104:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	w9, w24, #3
	add	x9, x19, w9, uxtw #4
	mov	w10, #176                       ; =0xb0
	ldr	q0, [x9, #144]
	ldr	w9, [x9, #156]
	umaddl	x8, w25, w10, x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x8]
	sub	x9, x9, #1
	cmp	x9, #2
	cset	w9, lo
	strb	w9, [x8, #1]
	strh	wzr, [x8, #2]
	stur	q0, [x8, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #20]
	stur	q0, [x8, #36]
	stur	q0, [x8, #52]
	stur	q0, [x8, #68]
	stur	q0, [x8, #84]
	stur	q0, [x8, #100]
	str	wzr, [x8, #116]
	b	LBB84_45
LBB84_105:
	cmp	w21, #2
	b.eq	LBB84_109
; %bb.106:
	cmp	w21, #1
	b.ne	LBB84_102
; %bb.107:
	ldr	x8, [sp, #96]
	tbnz	x8, #63, LBB84_111
; %bb.108:
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #216]
	str	x8, [sp, #224]
	b	LBB84_102
LBB84_109:
	ldp	x2, x3, [sp, #48]
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_services_runtime_string
	mov	x19, x0
	ldrb	w20, [sp, #40]
	add	x0, sp, #40
	bl	_nl_ws_message_free
	mov	x0, x19
	cbnz	w19, LBB84_45
; %bb.110:
	mov	w8, #2                          ; =0x2
	strb	w8, [sp, #216]
	str	x20, [sp, #224]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	w9, #176                        ; =0xb0
	umaddl	x8, w25, w9, x8
	ldr	x8, [x8, #32]
	str	x8, [sp, #232]
	b	LBB84_102
LBB84_111:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w8, #2
	b.ne	LBB84_113
; %bb.112:
	mov	w0, #3                          ; =0x3
	b	LBB84_45
LBB84_113:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #40]
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB84_45
; %bb.114:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	w0, [x8, #40]
	mov	w9, #5                          ; =0x5
	str	w9, [x8, #48]
	b	LBB84_45
	.loh AdrpLdrGotLdr	Lloh122, Lloh123, Lloh124
	.loh AdrpLdrGotLdr	Lloh125, Lloh126, Lloh127
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_mixed_ws_payload
_fr_mixed_ws_payload:                   ; @fr_mixed_ws_payload
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldrb	w8, [x1]
	cmp	w8, #1
	b.ne	LBB85_4
; %bb.1:
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB85_4
; %bb.2:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB85_4
; %bb.3:
	ldrb	w8, [x1, #5]
	cbz	w8, LBB85_6
LBB85_4:
	mov	w2, #0                          ; =0x0
LBB85_5:
	mov	x0, x2
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB85_6:
	ldr	w8, [x1, #16]
	cmp	w8, #3
	b.ne	LBB85_12
; %bb.7:
	ldr	w8, [x1, #12]
	ldr	w9, [x0, #9616]
	add	w9, w9, w9, lsl #3
	cmp	w8, w9
	b.hs	LBB85_4
; %bb.8:
	mov	w9, #36409                      ; =0x8e39
	movk	w9, #14563, lsl #16
	umull	x9, w8, w9
	lsr	x9, x9, #33
	add	w10, w9, w9, lsl #3
	sub	w8, w8, w10
	add	x9, x0, x9, lsl #2
	ldr	w9, [x9, #9360]
	cmp	w9, #3
	mov	w10, #7                         ; =0x7
	cinc	w10, w10, ne
	cmp	w9, #2
	ccmp	w10, w8, #2, ne
	b.ls	LBB85_4
; %bb.9:
	cmp	w9, #3
	mov	x19, x0
	mov	x20, x1
	mov	x0, x8
	b.eq	LBB85_14
; %bb.10:
	cmp	w9, #2
	b.ne	LBB85_15
; %bb.11:
	bl	_nl_socket_catalog_type
	b	LBB85_16
LBB85_12:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB85_4
; %bb.13:
	ldrb	w4, [x1, #24]
	ldur	x8, [x1, #4]
	ldur	x2, [x1, #12]
	add	x3, x1, #32
	mov	x1, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	b	_fr_mixed_ws_fields
LBB85_14:
	bl	_nl_websocket_catalog_type
	b	LBB85_16
LBB85_15:
	bl	_nl_file_catalog_type
LBB85_16:
	cbz	x0, LBB85_4
; %bb.17:
	mov	x8, x19
	mov	x9, x20
	ldr	w10, [x20, #12]
	add	x10, x19, x10, lsl #4
	ldr	x11, [x10, #144]!
	ldur	x12, [x20, #4]
	eor	x11, x11, x12
	tst	x11, #0xff
	b.ne	LBB85_4
; %bb.18:
	mov	w2, #0                          ; =0x0
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	tst	x11, x12
	b.ne	LBB85_5
; %bb.19:
	ldr	x10, [x10, #8]
	ldur	x1, [x9, #12]
	cmp	x1, x10
	b.ne	LBB85_5
; %bb.20:
	ldr	w9, [x9, #20]
	and	w10, w9, #0xfffffffe
	cmp	w10, #2
	b.ne	LBB85_4
; %bb.21:
	ldr	x10, [x0, #24]
	cmp	w9, #3
	cset	w9, eq
	add	x9, x10, x9, lsl #5
	ldr	x2, [x9, #16]
	mov	x3, sp
	mov	x0, x8
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_fr_member
	cbz	w0, LBB85_4
; %bb.22:
	ldrb	w4, [x20, #24]
	ldp	x1, x2, [sp]
	add	x3, x20, #32
	mov	x0, x19
	bl	_fr_mixed_ws_fields
	mov	x2, x0
	b	LBB85_5
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_runtime_websocket_policy ; -- Begin function nvm_services_runtime_websocket_policy
	.p2align	2
_nvm_services_runtime_websocket_policy: ; @nvm_services_runtime_websocket_policy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB86_3
; %bb.1:
	add	x8, x0, #76, lsl #12            ; =311296
	ldrb	w9, [x8, #2738]
	tbz	w9, #0, LBB86_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB86_3:
	mov	w0, #1                          ; =0x1
	ret
LBB86_4:
	ldr	w8, [x8, #2728]
	cbz	w8, LBB86_6
; %bb.5:
	mov	w0, #5                          ; =0x5
	ret
LBB86_6:
	ldr	w8, [x0, #9616]
	cmp	w1, w8
	b.hs	LBB86_10
; %bb.7:
	add	x8, x0, w1, uxtw #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	b.ne	LBB86_10
; %bb.8:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w20, w1
	mov	w8, #12184                      ; =0x2f98
	add	x21, x0, x8
	ldrb	w8, [x21, x20]
	tbz	w8, #0, LBB86_11
; %bb.9:
	mov	w0, #5                          ; =0x5
	b	LBB86_19
LBB86_10:
	mov	w0, #6                          ; =0x6
	ret
LBB86_11:
	cbz	x2, LBB86_18
; %bb.12:
	ldr	w8, [x2, #16]
	mov	w9, #60000                      ; =0xea60
	cmp	w8, w9
	b.hi	LBB86_18
; %bb.13:
	ldrb	w8, [x2, #1]
	ldr	x19, [x2, #8]
	cmp	w8, #1
	b.ne	LBB86_15
; %bb.14:
	cbnz	x19, LBB86_16
	b	LBB86_18
LBB86_15:
	cbz	x19, LBB86_20
LBB86_16:
	mov	x22, x2
	mov	x23, x0
	mov	x0, x19
	mov	w1, #4096                       ; =0x1000
	bl	_strnlen
	sub	x9, x0, #1, lsl #12             ; =4096
	cmn	x9, #4095
	b.lo	LBB86_18
; %bb.17:
	mov	x8, x0
	ldrb	w9, [x19]
	cmp	w9, #47
	mov	x0, x23
	mov	x2, x22
	b.eq	LBB86_21
LBB86_18:
	mov	w0, #1                          ; =0x1
LBB86_19:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB86_20:
	mov	x8, #0                          ; =0x0
LBB86_21:
	mov	w9, #40                         ; =0x28
	umaddl	x9, w20, w9, x0
	ldr	q0, [x2]
	ldr	x10, [x2, #16]
	str	x10, [x9, #9648]
	str	q0, [x9, #9632]
	ldr	x1, [x2, #8]
	cbz	x1, LBB86_23
; %bb.22:
	mov	w10, #9632                      ; =0x25a0
	add	x22, x9, x10
	add	x9, x0, x20, lsl #12
	mov	w10, #12248                     ; =0x2fd8
	add	x19, x9, x10
	add	x2, x8, #1
	mov	x0, x19
	bl	_memcpy
	str	x19, [x22, #8]
LBB86_23:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, x20]
	b	LBB86_19
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_code
_fr_code:                               ; @fr_code
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB87_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_instruction
LBB87_2:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_instruction
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_payload
_frc_payload:                           ; @frc_payload
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldrb	w8, [x1]
	cmp	w8, #1
	b.ne	LBB88_18
; %bb.1:
	ldrb	w9, [x1, #4]
	cmp	w9, #11
	b.ne	LBB88_18
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB88_20
; %bb.3:
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB88_20
; %bb.4:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB88_20
; %bb.5:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB88_20
; %bb.6:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB88_20
; %bb.7:
	ldur	x8, [x1, #4]
	mov	x9, #-65531                     ; =0xffffffffffff0005
	movk	x9, #0, lsl #16
	add	x9, x9, #6
	eor	x9, x8, x9
	tst	x9, #0xff
	b.ne	LBB88_20
; %bb.8:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	tst	x9, x10
	b.ne	LBB88_21
; %bb.9:
	ldur	x9, [x1, #12]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB88_21
; %bb.10:
	ldr	w9, [x1, #152]
	cbnz	w9, LBB88_20
; %bb.11:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x1, #120]
	cbnz	w9, LBB88_21
; %bb.12:
	ldr	w9, [x1, #124]
	cbnz	w9, LBB88_21
; %bb.13:
	ldr	x9, [x1, #128]
	cbnz	x9, LBB88_21
; %bb.14:
	ldr	x9, [x1, #136]
	cbnz	x9, LBB88_21
; %bb.15:
	ldr	w9, [x1, #144]
	cbnz	w9, LBB88_21
; %bb.16:
	ldr	x9, [x1, #160]
	ldr	x10, [x8, #16]
	cmp	x9, x10
	b.ne	LBB88_20
; %bb.17:
	ldr	w9, [x1, #168]
	ldr	w8, [x8, #72]
	cmp	w9, w8
	b	LBB88_92
LBB88_18:
	ldr	x9, [x1, #160]
	cbnz	x9, LBB88_20
; %bb.19:
	ldr	w9, [x1, #168]
	cbz	w9, LBB88_22
LBB88_20:
	mov	w0, #0                          ; =0x0
LBB88_21:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB88_22:
	tbz	w8, #0, LBB88_30
; %bb.23:
	ldrb	w8, [x1, #1]
	ldr	w9, [x1, #120]
	cmp	w8, #1
	b.ne	LBB88_56
; %bb.24:
	ldr	w8, [x1, #12]
	mov	w10, #36409                     ; =0x8e39
	movk	w10, #14563, lsl #16
	umull	x8, w8, w10
	lsr	x8, x8, #33
	add	w8, w8, #1
	cmp	w9, w8
	b.ne	LBB88_20
; %bb.25:
	ldr	w8, [x0, #9616]
	cmp	w9, w8
	b.hi	LBB88_20
; %bb.26:
	ldr	w8, [x1, #124]
	sub	w9, w9, #1
	add	x9, x0, w9, uxtw #2
	ldr	w9, [x9, #9360]
	cmp	w8, w9
	b.ne	LBB88_20
; %bb.27:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB88_20
; %bb.28:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB88_20
; %bb.29:
	ldr	w8, [x1, #152]
	b	LBB88_64
LBB88_30:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x1, #120]
	cbnz	w8, LBB88_21
; %bb.31:
	ldr	w8, [x1, #124]
	cbnz	w8, LBB88_21
; %bb.32:
	ldr	x8, [x1, #128]
	cbnz	x8, LBB88_21
; %bb.33:
	ldr	x8, [x1, #136]
	cbnz	x8, LBB88_21
; %bb.34:
	ldr	w8, [x1, #144]
	cbnz	w8, LBB88_21
; %bb.35:
	ldr	w8, [x1, #152]
	cbnz	w8, LBB88_20
; %bb.36:
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB88_20
; %bb.37:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB88_20
; %bb.38:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB88_20
; %bb.39:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB88_20
; %bb.40:
	ldrb	w8, [x1, #4]
	cbnz	w8, LBB88_20
; %bb.41:
	ldrb	w8, [x1, #5]
	cbnz	w8, LBB88_20
; %bb.42:
	ldr	w9, [x1, #8]
	cbnz	w9, LBB88_20
; %bb.43:
	mov	x8, x1
	ldr	w9, [x1, #12]
	cbnz	w9, LBB88_20
; %bb.44:
	ldr	w9, [x8, #16]
	cbnz	w9, LBB88_20
; %bb.45:
	ldr	x9, [x8, #32]
	cbnz	x9, LBB88_20
; %bb.46:
	ldr	x9, [x8, #40]
	cbnz	x9, LBB88_20
; %bb.47:
	ldr	x9, [x8, #48]
	cbnz	x9, LBB88_20
; %bb.48:
	ldr	x9, [x8, #56]
	cbnz	x9, LBB88_20
; %bb.49:
	ldr	x9, [x8, #64]
	cbnz	x9, LBB88_20
; %bb.50:
	ldr	x9, [x8, #72]
	cbnz	x9, LBB88_20
; %bb.51:
	ldr	x9, [x8, #80]
	cbnz	x9, LBB88_20
; %bb.52:
	ldr	x9, [x8, #88]
	cbnz	x9, LBB88_20
; %bb.53:
	ldr	x9, [x8, #96]
	cbnz	x9, LBB88_20
; %bb.54:
	ldr	x9, [x8, #104]
	cbnz	x9, LBB88_20
; %bb.55:
	ldr	x8, [x8, #112]
	cmp	x8, #0
	cset	w0, eq
	b	LBB88_21
LBB88_56:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w9, LBB88_21
; %bb.57:
	ldr	w9, [x1, #124]
	cbnz	w9, LBB88_21
; %bb.58:
	ldr	x9, [x1, #128]
	cbnz	x9, LBB88_21
; %bb.59:
	ldr	x9, [x1, #136]
	cbnz	x9, LBB88_21
; %bb.60:
	ldr	w9, [x1, #144]
	cbnz	w9, LBB88_21
; %bb.61:
	ldrb	w9, [x1, #2]
	cmp	w9, #1
	b.ne	LBB88_65
; %bb.62:
	ldrb	w8, [x1, #5]
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB88_20
; %bb.63:
	ldrb	w8, [x1, #24]
LBB88_64:
	cmp	w8, #0
	cset	w0, eq
	b	LBB88_21
LBB88_65:
	ldr	w9, [x1, #152]
	cbnz	w9, LBB88_20
; %bb.66:
	ldrb	w9, [x1, #5]
	cbnz	w9, LBB88_20
; %bb.67:
	ldrb	w9, [x1, #4]
	cmp	w9, #3
	b.gt	LBB88_71
; %bb.68:
	cbz	w9, LBB88_87
; %bb.69:
	cmp	w9, #1
	b.ne	LBB88_81
; %bb.70:
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB88_20
	b	LBB88_88
LBB88_71:
	cmp	w9, #4
	b.eq	LBB88_89
; %bb.72:
	cmp	w9, #5
	b.ne	LBB88_81
; %bb.73:
	ldrb	w9, [x1, #24]
	cmp	w9, #1
	b.ne	LBB88_20
; %bb.74:
	ldr	w9, [x1, #20]
	cbnz	w9, LBB88_20
; %bb.75:
	ldur	x10, [x1, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB88_20
; %bb.76:
	mov	w0, #0                          ; =0x0
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB88_21
; %bb.77:
	mov	x9, x1
	ldur	x10, [x1, #12]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB88_21
; %bb.78:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB88_20
; %bb.79:
	add	x10, x8, #72, lsl #12           ; =294912
	ldr	w10, [x10, #12248]
	cmp	x9, x10
	b.hi	LBB88_20
; %bb.80:
	add	x8, x8, x9, lsl #3
	add	x9, x8, #64, lsl #12            ; =262144
	ldr	x8, [x9, #12240]
	cmp	x8, #0
	cset	w0, ne
	b	LBB88_21
LBB88_81:
	ldr	w9, [x1, #12]
	ldr	w10, [x8, #9616]
	add	w10, w10, w10, lsl #3
	cmp	w9, w10
	b.hs	LBB88_20
; %bb.82:
	stp	x8, x1, [sp]                    ; 16-byte Folded Spill
	mov	w10, #36409                     ; =0x8e39
	movk	w10, #14563, lsl #16
	umull	x10, w9, w10
	lsr	x10, x10, #33
	add	w11, w10, w10, lsl #3
	sub	w0, w9, w11
	add	x8, x8, x10, lsl #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	mov	w9, #7                          ; =0x7
	cinc	w9, w9, ne
	cmp	w8, #2
	b.eq	LBB88_84
; %bb.83:
	cmp	w9, w0
	b.ls	LBB88_20
LBB88_84:
	cmp	w8, #3
	b.eq	LBB88_93
; %bb.85:
	cmp	w8, #2
	b.ne	LBB88_94
; %bb.86:
	bl	_nl_socket_catalog_type
	b	LBB88_95
LBB88_87:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB88_20
LBB88_88:
	ldr	w8, [x1, #20]
	b	LBB88_64
LBB88_89:
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB88_20
; %bb.90:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB88_20
; %bb.91:
	ldr	x8, [x1, #32]
	cmp	x8, #2
LBB88_92:
	cset	w0, lo
	b	LBB88_21
LBB88_93:
	bl	_nl_websocket_catalog_type
	b	LBB88_95
LBB88_94:
	bl	_nl_file_catalog_type
LBB88_95:
	mov	x8, x0
	cbz	x0, LBB88_20
; %bb.96:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #16]
	cmp	w9, #3
	b.eq	LBB88_103
; %bb.97:
	cmp	w9, #4
	b.ne	LBB88_20
; %bb.98:
	mov	w0, #0                          ; =0x0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w23, [x9, #24]
	cmp	w23, #11
	b.hi	LBB88_21
; %bb.99:
	ldr	x9, [x8, #32]
	cmp	x9, x23
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	b.ne	LBB88_21
; %bb.100:
	ldr	w9, [x9, #20]
	cbnz	w9, LBB88_20
; %bb.101:
	cbz	w23, LBB88_114
; %bb.102:
	ldp	x9, x10, [sp]                   ; 16-byte Folded Reload
	add	x24, x10, #32
	mov	w25, #45016                     ; =0xafd8
	movk	w25, #4, lsl #16
	add	x9, x9, #66, lsl #12            ; =270336
	add	x26, x9, #4056
	ldr	x8, [x8, #24]
	add	x27, x8, #16
Lloh128:
	adrp	x19, l_.str.1@PAGE
Lloh129:
	add	x19, x19, l_.str.1@PAGEOFF
Lloh130:
	adrp	x20, l_.str.2@PAGE
Lloh131:
	add	x20, x20, l_.str.2@PAGEOFF
Lloh132:
	adrp	x21, l_.str@PAGE
Lloh133:
	add	x21, x21, l_.str@PAGEOFF
	b	LBB88_107
LBB88_103:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #20]
	and	w8, w8, #0xfffffffe
	cmp	w8, #2
	b.ne	LBB88_20
; %bb.104:
	ldp	x0, x1, [sp]                    ; 16-byte Folded Reload
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_fr_mixed_payload
LBB88_105:                              ;   in Loop: Header=BB88_107 Depth=1
	ldr	x8, [x24]
	cmp	x8, #2
	b.hs	LBB88_20
LBB88_106:                              ;   in Loop: Header=BB88_107 Depth=1
	add	x24, x24, #8
	mov	w0, #1                          ; =0x1
	subs	x23, x23, #1
	b.eq	LBB88_21
LBB88_107:                              ; =>This Inner Loop Header: Depth=1
	ldr	x22, [x27], #32
	cbz	x22, LBB88_20
; %bb.108:                              ;   in Loop: Header=BB88_107 Depth=1
	mov	x0, x22
	mov	x1, x19
	bl	_strcmp
	cbz	w0, LBB88_105
; %bb.109:                              ;   in Loop: Header=BB88_107 Depth=1
	mov	x0, x22
	mov	x1, x20
	bl	_strcmp
	cbz	w0, LBB88_111
; %bb.110:                              ;   in Loop: Header=BB88_107 Depth=1
	mov	x0, x22
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB88_106
	b	LBB88_20
LBB88_111:                              ;   in Loop: Header=BB88_107 Depth=1
	ldr	x8, [x24]
	cmp	x8, #1
	b.lt	LBB88_20
; %bb.112:                              ;   in Loop: Header=BB88_107 Depth=1
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	w9, [x9, x25]
	cmp	x8, x9
	b.hi	LBB88_20
; %bb.113:                              ;   in Loop: Header=BB88_107 Depth=1
	add	x8, x26, x8, lsl #3
	ldur	x8, [x8, #-8]
	cbnz	x8, LBB88_106
	b	LBB88_20
LBB88_114:
	mov	w0, #1                          ; =0x1
	b	LBB88_21
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh128, Lloh129
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_reference_empty
_frc_reference_empty:                   ; @frc_reference_empty
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	tbz	w8, #0, LBB89_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	ret
LBB89_2:
	ldrb	w8, [x0, #1]
	tbz	w8, #0, LBB89_4
; %bb.3:
	mov	w0, #0                          ; =0x0
	ret
LBB89_4:
	ldrb	w8, [x0, #2]
	tbz	w8, #0, LBB89_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	ret
LBB89_6:
	ldr	w8, [x0, #4]
	cbz	w8, LBB89_8
; %bb.7:
	mov	w0, #0                          ; =0x0
	ret
LBB89_8:
	ldr	w8, [x0, #8]
	cbz	w8, LBB89_10
; %bb.9:
	mov	w0, #0                          ; =0x0
	ret
LBB89_10:
	ldr	w8, [x0, #12]
	cbz	w8, LBB89_12
; %bb.11:
	mov	w0, #0                          ; =0x0
	ret
LBB89_12:
	ldr	x8, [x0, #16]
	cbz	x8, LBB89_14
; %bb.13:
	mov	w0, #0                          ; =0x0
	ret
LBB89_14:
	ldr	x8, [x0, #56]
	cbz	x8, LBB89_16
; %bb.15:
	mov	w0, #0                          ; =0x0
	ret
LBB89_16:
	ldp	w10, w9, [x0, #24]
	orr	w9, w10, w9
	cbnz	w9, LBB89_20
; %bb.17:
	ldr	x9, [x0, #32]
	cbnz	x9, LBB89_20
; %bb.18:
	ldr	x9, [x0, #40]
	cbnz	x9, LBB89_20
; %bb.19:
	ldr	w8, [x0, #48]
	cmp	w8, #0
	cset	w8, eq
LBB89_20:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_frame
_frc_frame:                             ; @frc_frame
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #832
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x21, x2
	mov	x19, x1
	mov	x20, x0
	ldr	w1, [x1]
	sub	x2, x29, #240
	bl	_fr_function
	cbz	w0, LBB90_3
; %bb.1:
	ldr	w2, [x19, #4]
	lsr	w8, w2, #16
	cbz	w8, LBB90_4
LBB90_2:
	mov	w0, #0                          ; =0x0
LBB90_3:
	add	sp, sp, #832
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB90_4:
	ldr	w1, [x19]
	ldrb	w3, [x19, #34]
	ldr	w8, [x20, #24]
	cmp	w8, #2
	b.ne	LBB90_6
; %bb.5:
	ldr	x0, [x20, #16]
	sub	x4, x29, #168
	bl	_nvm_services_indirect_hosted_variant
	b	LBB90_7
LBB90_6:
	ldr	x0, [x20, #8]
	sub	x4, x29, #168
	bl	_nvm_services_cyclic_hosted_variant
LBB90_7:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB90_3
; %bb.8:
	ldurb	w8, [x29, #-148]
	tbz	w8, #0, LBB90_3
; %bb.9:
	ldurh	w9, [x29, #-168]
	ldurh	w8, [x29, #-200]
	cmp	w9, w8
	b.ne	LBB90_2
; %bb.10:
	ldr	w8, [x19, #16]
	ldurh	w10, [x29, #-202]
	cmp	w8, w10
	b.hi	LBB90_2
; %bb.11:
	ldrb	w22, [x19, #32]
	ldurh	w10, [x29, #-166]
	cmp	w8, w10
	cset	w10, ne
	cset	w11, hi
	cmp	w22, #0
	mov	w0, #0                          ; =0x0
	csel	w10, w11, w10, ne
	tbnz	w10, #0, LBB90_3
; %bb.12:
	ldr	w11, [x19, #8]
	ldr	w10, [x20, #128]
	cmp	w11, w10
	b.hi	LBB90_3
; %bb.13:
	sub	x11, x10, x11
	cmp	x11, x9
	b.lo	LBB90_3
; %bb.14:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x19, #12]
	cmp	w9, w10
	b.hi	LBB90_3
; %bb.15:
	sub	x9, x10, x9
	cmp	x9, x8
	b.lo	LBB90_3
; %bb.16:
	ldr	w1, [x19, #20]
	ldurh	w2, [x29, #-198]
	mov	x0, x20
	bl	_frf_empty_range
	cbz	w0, LBB90_3
; %bb.17:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x19, #24]
	ldr	w9, [x20, #132]
	subs	w8, w9, w8
	b.lo	LBB90_3
; %bb.18:
	cmp	w8, #256
	b.lo	LBB90_3
; %bb.19:
	ldr	w8, [x19, #28]
	subs	w8, w21, w8
	b.lo	LBB90_2
; %bb.20:
	add	x9, x20, #76, lsl #12           ; =311296
	ldr	w9, [x9, #2748]
	cmp	w21, w9
	b.hi	LBB90_2
; %bb.21:
	ldurh	w9, [x29, #-164]
	cmp	w8, w9
	b.ne	LBB90_2
; %bb.22:
	cbz	w22, LBB90_27
; %bb.23:
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	add	x3, sp, #56
	mov	x0, x20
	bl	_fr_code
	cbz	w0, LBB90_2
; %bb.24:
	ldr	w3, [x19, #36]
	add	x2, sp, #56
	mov	x0, x20
	mov	x1, x19
	bl	_fr_call_target
	cbz	w0, LBB90_2
; %bb.25:
	ldurb	w8, [x29, #-145]
	tbz	w8, #0, LBB90_2
; %bb.26:
	ldr	w8, [x19, #16]
	ldurh	w9, [x29, #-100]
	ldurh	w10, [x29, #-96]
	add	w8, w8, w9
	sub	w8, w8, w10
	ldrb	w9, [sp, #64]
	cmp	w9, #60
	mov	w10, #152                       ; =0x98
	ccmp	w9, w10, #4, ne
	cinc	w8, w8, eq
	ldurh	w9, [x29, #-166]
	cmp	w8, w9
	b.ne	LBB90_2
LBB90_27:
	ldr	x0, [x20, #32]
	mov	w1, #9216                       ; =0x2400
	bl	_bzero
	ldurh	w8, [x29, #-200]
	cbz	w8, LBB90_32
; %bb.28:
	mov	w21, #0                         ; =0x0
LBB90_29:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_local
	cbz	w0, LBB90_2
; %bb.30:                               ;   in Loop: Header=BB90_29 Depth=1
	ldr	w8, [x19, #8]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [sp, #16]
	ldr	x9, [sp, #88]
	str	x9, [sp, #48]
	add	w1, w21, w8
	add	x2, sp, #16
	mov	x0, x20
	bl	_frc_value
	cbz	w0, LBB90_2
; %bb.31:                               ;   in Loop: Header=BB90_29 Depth=1
	add	w21, w21, #1
	ldurh	w8, [x29, #-200]
	cmp	w21, w8
	b.lo	LBB90_29
LBB90_32:
	ldr	w8, [x19, #16]
	cbz	w8, LBB90_37
; %bb.33:
	mov	w22, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
LBB90_34:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	and	w4, w21, #0xffff
	add	x5, sp, #56
	mov	x0, x20
	bl	_fr_input_stack
	cbz	w0, LBB90_2
; %bb.35:                               ;   in Loop: Header=BB90_34 Depth=1
	ldr	w8, [x19, #12]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [sp, #16]
	ldr	x9, [sp, #88]
	str	x9, [sp, #48]
	add	w1, w8, w22
	add	x2, sp, #16
	mov	x0, x20
	bl	_frc_value
	cbz	w0, LBB90_2
; %bb.36:                               ;   in Loop: Header=BB90_34 Depth=1
	add	w21, w21, #1
	and	w22, w21, #0xffff
	ldr	w8, [x19, #16]
	cmp	w8, w22
	b.hi	LBB90_34
LBB90_37:
	add	x8, x20, #74, lsl #12           ; =303104
	add	x22, x8, #4064
	ldurh	w8, [x29, #-164]
	cbz	w8, LBB90_43
; %bb.38:
	mov	x21, #0                         ; =0x0
LBB90_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_region
	cbz	w0, LBB90_2
; %bb.40:                               ;   in Loop: Header=BB90_39 Depth=1
	ldr	x8, [sp, #56]
	add	x9, x21, #513
	cmp	x9, x8
	b.ne	LBB90_2
; %bb.41:                               ;   in Loop: Header=BB90_39 Depth=1
	ldr	x8, [x22, #16]
	ldr	w9, [x19, #28]
	add	w9, w21, w9
	ldr	x8, [x8, w9, uxtw #3]
	cbz	x8, LBB90_2
; %bb.42:                               ;   in Loop: Header=BB90_39 Depth=1
	add	x21, x21, #1
	ldurh	w8, [x29, #-164]
	cmp	x21, x8
	b.lo	LBB90_39
LBB90_43:
	mov	x21, #0                         ; =0x0
	mov	w23, #176                       ; =0xb0
LBB90_44:                               ; =>This Inner Loop Header: Depth=1
	ldr	x24, [x22, #8]
	ldr	w25, [x19, #24]
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_reference
	cbz	w0, LBB90_2
; %bb.45:                               ;   in Loop: Header=BB90_44 Depth=1
	add	w8, w21, w25
	add	x8, x24, x8, lsl #6
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldrb	w8, [sp, #56]
	tbz	w8, #0, LBB90_67
; %bb.46:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB90_2
; %bb.47:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrb	w9, [sp, #57]
	ldrb	w10, [x8, #1]
	cmp	w9, w10
	b.ne	LBB90_2
; %bb.48:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrb	w9, [sp, #88]
	ldrb	w8, [x8, #2]
	cmp	w9, w8
	b.ne	LBB90_2
; %bb.49:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w8, [x19, #24]
	add	w1, w21, w8
	mov	x0, x20
	bl	_fr_reference
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	w0, LBB90_2
; %bb.50:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x0, [x22, #32]
	add	x1, x8, #24
	bl	_nl_services_borrow_validate
	ldr	x16, [sp, #8]                   ; 8-byte Folded Reload
	cbnz	w0, LBB90_2
; %bb.51:                               ;   in Loop: Header=BB90_44 Depth=1
	ldp	w10, w8, [x16, #24]
	ldr	x15, [x22]
	ldr	w14, [x16, #4]
	umaddl	x12, w14, w23, x15
	ldp	w9, w11, [x12, #120]!
	cmp	w10, w9
	ccmp	w8, w11, #0, eq
	b.ne	LBB90_2
; %bb.52:                               ;   in Loop: Header=BB90_44 Depth=1
	ldp	x13, x11, [x16, #32]
	ldr	w9, [x16, #48]
	ldr	w17, [x12, #24]
	ldp	x12, x0, [x12, #8]
	cmp	x13, x12
	ccmp	x11, x0, #0, eq
	ccmp	w9, w17, #0, eq
	b.ne	LBB90_2
; %bb.53:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x17, [x22, #8]
	ldr	w12, [x16, #8]
	add	x17, x17, x12, lsl #6
	ldp	w0, w1, [x17, #24]!
	cmp	w0, w10
	ccmp	w1, w8, #0, eq
	b.ne	LBB90_2
; %bb.54:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w0, [x17, #24]
	ldp	x2, x1, [x17, #8]
	cmp	x2, x13
	ccmp	x1, x11, #0, eq
	ccmp	w0, w9, #0, eq
	b.ne	LBB90_2
; %bb.55:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x17, [x17, #32]
	ldr	x16, [x16, #56]
	cmp	x17, x16
	b.ne	LBB90_2
; %bb.56:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrb	w16, [sp, #57]
	cmp	w16, #1
	b.ne	LBB90_68
; %bb.57:                               ;   in Loop: Header=BB90_44 Depth=1
	ldurh	w8, [x29, #-228]
	cmp	x21, x8
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	b.hs	LBB90_2
; %bb.58:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrh	w9, [sp, #58]
	cmp	x21, x9
	b.ne	LBB90_2
; %bb.59:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x9, [sp, #64]
	add	x10, x21, #257
	cmp	x10, x9
	b.ne	LBB90_2
; %bb.60:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x10, [sp, #72]
	cmp	x10, x9
	b.ne	LBB90_2
; %bb.61:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x9, [sp, #80]
	cbnz	x9, LBB90_2
; %bb.62:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x9, [x8, #16]
	cbnz	x9, LBB90_2
; %bb.63:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w8, [x8, #12]
	ldr	w9, [x19, #8]
	add	w9, w21, w9
	cmp	w9, w8
	b.ne	LBB90_2
; %bb.64:                               ;   in Loop: Header=BB90_44 Depth=1
	umaddl	x8, w8, w23, x15
	ldrb	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB90_2
; %bb.65:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w9, [x19, #24]
	cmp	w12, w9
	b.hs	LBB90_2
; %bb.66:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w8, [x8, #152]
	add	w9, w21, w9
	cmp	w9, w8
	b.eq	LBB90_84
	b	LBB90_2
LBB90_67:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_frc_reference_empty
	tbnz	w0, #0, LBB90_84
	b	LBB90_2
LBB90_68:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x17, [sp, #64]
	sub	x15, x17, #257
	cmn	x15, #256
	ldr	x15, [sp, #8]                   ; 8-byte Folded Reload
	b.lo	LBB90_2
; %bb.69:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrh	w0, [sp, #58]
	ldurh	w16, [x29, #-200]
	cmp	w0, w16
	b.hs	LBB90_2
; %bb.70:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x16, [sp, #72]
	add	x1, x21, #769
	cmp	x1, x16
	b.ne	LBB90_2
; %bb.71:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x16, [sp, #80]
	subs	x1, x16, #513
	b.lo	LBB90_2
; %bb.72:                               ;   in Loop: Header=BB90_44 Depth=1
	ldurh	w2, [x29, #-164]
	cmp	x1, x2
	b.hs	LBB90_2
; %bb.73:                               ;   in Loop: Header=BB90_44 Depth=1
	ldrb	w1, [x15, #2]
	tbnz	w1, #0, LBB90_75
; %bb.74:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w1, [x19, #24]
	add	w1, w21, w1
	cmp	w1, w12
	b.ne	LBB90_2
LBB90_75:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w12, [x15, #12]
	cmn	w12, #1
	b.ne	LBB90_2
; %bb.76:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w12, [x19, #8]
	add	w12, w12, w0
	cmp	w14, w12
	b.ne	LBB90_2
; %bb.77:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x12, [x20, #32]
	sub	x17, x17, #1
	add	x0, x12, x17, lsl #2
	ldr	w0, [x0, #8192]
	cmp	w0, w14
	b.ne	LBB90_2
; %bb.78:                               ;   in Loop: Header=BB90_44 Depth=1
	add	x12, x12, x17, lsl #5
	ldr	w14, [x12]
	cmp	w14, w10
	b.ne	LBB90_2
; %bb.79:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w10, [x12, #4]
	cmp	w10, w8
	b.ne	LBB90_2
; %bb.80:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x8, [x12, #8]
	cmp	x8, x13
	b.ne	LBB90_2
; %bb.81:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x8, [x12, #16]
	cmp	x8, x11
	b.ne	LBB90_2
; %bb.82:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	w8, [x12, #24]
	cmp	w8, w9
	b.ne	LBB90_2
; %bb.83:                               ;   in Loop: Header=BB90_44 Depth=1
	ldr	x8, [x15, #16]
	ldr	x9, [x22, #16]
	ldr	w10, [x19, #28]
	add	w10, w16, w10
	sub	w10, w10, #513
	ldr	x9, [x9, w10, uxtw #3]
	cmp	x8, x9
	b.ne	LBB90_2
LBB90_84:                               ;   in Loop: Header=BB90_44 Depth=1
	add	x21, x21, #1
	mov	w0, #1                          ; =0x1
	cmp	x21, #256
	b.ne	LBB90_44
	b	LBB90_3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_mixed_payload
_fr_mixed_payload:                      ; @fr_mixed_payload
	.cfi_startproc
; %bb.0:
	ldr	w8, [x1, #12]
	ldr	w9, [x0, #9616]
	add	w9, w9, w9, lsl #3
	cmp	w8, w9
	b.hs	LBB91_19
; %bb.1:
	mov	w9, #36409                      ; =0x8e39
	movk	w9, #14563, lsl #16
	umull	x9, w8, w9
	lsr	x10, x9, #33
	add	w9, w10, w10, lsl #3
	sub	w9, w8, w9
	add	x8, x0, x10, lsl #2
	ldr	w8, [x8, #9360]
	cmp	w8, #3
	mov	w10, #7                         ; =0x7
	cinc	w10, w10, ne
	cmp	w8, #2
	ccmp	w10, w9, #2, ne
	b.ls	LBB91_19
; %bb.2:
	cmp	w8, #3
	b.ne	LBB91_4
; %bb.3:
	b	_fr_mixed_ws_payload
LBB91_4:
	ldr	w10, [x1, #20]
	cmp	w10, #3
	b.ne	LBB91_10
; %bb.5:
	ldrb	w9, [x1, #24]
	mov	w10, #7                         ; =0x7
	mov	w11, #11                        ; =0xb
	cmp	w8, #2
	csel	w10, w11, w10, eq
	cmp	w10, w9
	b.ne	LBB91_19
; %bb.6:
	mov	w10, #4                         ; =0x4
	mov	w11, #6                         ; =0x6
	cmp	w8, #2
	csel	w10, w11, w10, eq
	cmp	w10, w9
	b.hs	LBB91_20
; %bb.7:
	mvn	x8, x10
	add	x8, x8, x9
	add	x9, x1, w10, uxtw #3
	add	x9, x9, #32
LBB91_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9], #8
	cmp	x11, #2
	cset	w0, lo
	subs	x8, x8, #1
	cset	w10, hs
	cmp	x11, #1
	b.hi	LBB91_18
; %bb.9:                                ;   in Loop: Header=BB91_8 Depth=1
	tbnz	w10, #0, LBB91_8
	b	LBB91_18
LBB91_10:
	cmp	w9, #6
	b.eq	LBB91_13
; %bb.11:
	cmp	w9, #4
	b.ne	LBB91_15
; %bb.12:
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b	LBB91_17
LBB91_13:
	ldrb	w8, [x1, #24]
	cmp	w8, #2
	b.ne	LBB91_19
; %bb.14:
	ldr	x8, [x1, #40]
	cmp	x8, #2
	cset	w0, lo
	ret
LBB91_15:
	mov	w8, #13                         ; =0xd
	and	w8, w9, w8
	cmp	w8, #5
	b.ne	LBB91_19
; %bb.16:
	ldrb	w8, [x1, #24]
	cmp	w8, #0
LBB91_17:
	cset	w0, eq
LBB91_18:
	ret
LBB91_19:
	mov	w0, #0                          ; =0x0
	ret
LBB91_20:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_local
_fr_input_local:                        ; @fr_input_local
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB92_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_input_local
LBB92_2:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_input_local
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_value
_frc_value:                             ; @frc_value
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB93_19
; %bb.1:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	add	x8, x0, #74, lsl #12            ; =303104
	add	x24, x8, #4064
	ldr	x8, [x24]
	mov	w9, #176                        ; =0xb0
	mov	x21, x1
	umaddl	x20, w1, w9, x8
	mov	x23, x0
	mov	x1, x20
	bl	_frc_payload
	cbz	w0, LBB93_27
; %bb.2:
	ldrb	w8, [x20]
	ldrb	w9, [x19, #16]
	cmp	w8, w9
	b.ne	LBB93_26
; %bb.3:
	tbz	w8, #0, LBB93_20
; %bb.4:
	ldr	x9, [x19]
	ldur	x8, [x20, #4]
	eor	x11, x8, x9
	tst	x11, #0xff
	b.ne	LBB93_26
; %bb.5:
	ldur	x8, [x20, #12]
	ldr	x10, [x19, #8]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x11, #0
	ccmp	x8, x10, #0, eq
	b.ne	LBB93_26
; %bb.6:
	ldrb	w12, [x20, #2]
	ands	x11, x9, #0xff00
	cset	w9, ne
	cmp	w12, w9
	b.ne	LBB93_26
; %bb.7:
	ldrb	w9, [x20, #1]
	lsr	x10, x10, #32
	sub	x10, x10, #1
	cmp	x11, #0
	ccmp	x10, #2, #2, eq
	cset	w10, lo
	cmp	w9, w10
	b.ne	LBB93_26
; %bb.8:
	ldr	w22, [x20, #20]
	tbz	w9, #0, LBB93_25
; %bb.9:
	and	x25, x8, #0xffffffff00000000
	mov	x26, #8589934592                ; =0x200000000
	cmp	x25, x26
	cset	w2, eq
	ldr	x0, [x24, #32]
	add	x1, x20, #120
	bl	_nl_services_value_validate
	cbnz	w0, LBB93_26
; %bb.10:
	cmp	x25, x26
	b.ne	LBB93_12
; %bb.11:
	ldr	x0, [x24, #32]
	add	x1, x20, #120
	mov	x2, sp
	bl	_nl_services_value_view
	ldrb	w8, [sp, #4]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w22, w8, eq
	cbnz	w0, LBB93_26
LBB93_12:
	ldr	x8, [x19, #24]
	sub	x9, x8, #257
	cmn	x9, #256
	b.lo	LBB93_26
; %bb.13:
	mov	w0, #0                          ; =0x0
	sub	w8, w8, #1
	ldr	x10, [x23, #32]
	add	x9, x10, x8, lsl #5
	ldr	w11, [x9]
	cbnz	w11, LBB93_27
; %bb.14:
	ldr	w11, [x9, #4]
	cbnz	w11, LBB93_27
; %bb.15:
	ldr	x11, [x9, #8]
	cbnz	x11, LBB93_27
; %bb.16:
	ldr	x11, [x9, #16]
	cbnz	x11, LBB93_27
; %bb.17:
	ldr	w11, [x9, #24]
	cbnz	w11, LBB93_27
; %bb.18:
	add	x10, x10, #16
	mov	w11, #256                       ; =0x100
	b	LBB93_22
LBB93_19:
	mov	w0, #0                          ; =0x0
	ret
LBB93_20:
	ldr	x8, [x19, #24]
	cmp	x8, #0
	cset	w0, eq
	b	LBB93_27
LBB93_21:                               ;   in Loop: Header=BB93_22 Depth=1
	add	x10, x10, #32
	subs	x11, x11, #1
	b.eq	LBB93_28
LBB93_22:                               ; =>This Inner Loop Header: Depth=1
	ldp	w15, w16, [x10, #-16]
	ldp	x12, x13, [x10, #-8]
	ldr	w14, [x10, #8]
	cmp	w15, #0
	ccmp	w16, #0, #0, eq
	ccmp	x12, #0, #0, eq
	ccmp	x13, #0, #0, eq
	ccmp	w14, #0, #0, eq
	b.eq	LBB93_21
; %bb.23:                               ;   in Loop: Header=BB93_22 Depth=1
	ldp	w17, w0, [x20, #120]
	cmp	w15, w17
	ccmp	w16, w0, #0, eq
	b.ne	LBB93_21
; %bb.24:                               ;   in Loop: Header=BB93_22 Depth=1
	ldr	w15, [x20, #144]
	ldp	x17, x16, [x20, #128]
	cmp	x12, x17
	ccmp	x13, x16, #0, eq
	ccmp	w14, w15, #0, eq
	b.ne	LBB93_21
	b	LBB93_26
LBB93_25:
	ldr	x8, [x19, #24]
	cbz	x8, LBB93_29
LBB93_26:
	mov	w0, #0                          ; =0x0
LBB93_27:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB93_28:
	ldur	q0, [x20, #120]
	ldur	q1, [x20, #136]
	stp	q0, q1, [x9]
	ldr	x9, [x23, #32]
	add	x8, x9, x8, lsl #2
	str	w21, [x8, #8192]
LBB93_29:
	ldr	w8, [x19, #32]
	and	w9, w22, #0xfffffffe
	cmp	w9, #2
	cset	w9, eq
	cmp	w22, w8
	cset	w10, eq
	cmp	w8, #1
	csel	w0, w9, w10, eq
	b	LBB93_27
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_stack
_fr_input_stack:                        ; @fr_input_stack
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB94_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_input_stack
LBB94_2:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_input_stack
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_region
_fr_input_region:                       ; @fr_input_region
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB95_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_input_region
LBB95_2:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_input_region
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_reference
_fr_input_reference:                    ; @fr_input_reference
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB96_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_services_indirect_hosted_input_reference
LBB96_2:
	ldr	x0, [x0, #8]
	b	_nvm_services_cyclic_hosted_input_reference
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_mixed_ws_fields
_fr_mixed_ws_fields:                    ; @fr_mixed_ws_fields
	.cfi_startproc
; %bb.0:
	and	w8, w1, #0xff
	cmp	w8, #3
	b.gt	LBB97_4
; %bb.1:
	cbz	w8, LBB97_20
; %bb.2:
	cmp	w8, #1
	b.ne	LBB97_10
; %bb.3:
	cmp	w4, #1
	b	LBB97_21
LBB97_4:
	cmp	w8, #4
	b.eq	LBB97_23
; %bb.5:
	cmp	w8, #5
	b.ne	LBB97_10
; %bb.6:
	cmp	w4, #1
	b.ne	LBB97_25
; %bb.7:
	ldr	x8, [x3]
	cmp	x8, #1
	b.lt	LBB97_25
; %bb.8:
	add	x9, x0, #72, lsl #12            ; =294912
	ldr	w9, [x9, #12248]
	cmp	x8, x9
	b.ls	LBB97_26
; %bb.9:
	mov	w0, #0                          ; =0x0
	ret
LBB97_10:
	lsr	x8, x2, #32
	cmp	x8, #4
	b.ne	LBB97_25
; %bb.11:
	ldr	w8, [x0, #9616]
	add	w8, w8, w8, lsl #3
	cmp	w8, w2
	b.ls	LBB97_25
; %bb.12:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w2, w8
	lsr	x8, x8, #33
	add	w9, w8, w8, lsl #3
	sub	w9, w2, w9
	add	x8, x0, x8, lsl #2
	ldr	w10, [x8, #9360]
	cmp	w10, #3
	mov	w8, #7                          ; =0x7
	cinc	w8, w8, ne
	cmp	w10, #2
	ccmp	w8, w9, #2, ne
	b.ls	LBB97_25
; %bb.13:
	add	x11, x0, w2, uxtw #4
	ldr	x8, [x11, #144]!
	eor	x12, x8, x1
	tst	x12, #0xff
	b.ne	LBB97_25
; %bb.14:
	mov	w8, #0                          ; =0x0
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	tst	x12, x13
	b.ne	LBB97_22
; %bb.15:
	ldr	x11, [x11, #8]
	cmp	w2, w11
	b.ne	LBB97_22
; %bb.16:
	eor	x11, x11, x2
	lsr	x11, x11, #32
	cbnz	x11, LBB97_22
; %bb.17:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cmp	w10, #3
	mov	x19, x0
	mov	x22, x2
	mov	x23, x4
	mov	x21, x3
	mov	x0, x9
	b.eq	LBB97_27
; %bb.18:
	cmp	w10, #2
	b.ne	LBB97_28
; %bb.19:
	bl	_nl_socket_catalog_type
	b	LBB97_29
LBB97_20:
	cmp	w4, #0
LBB97_21:
	cset	w8, eq
LBB97_22:
	mov	x0, x8
	ret
LBB97_23:
	cmp	w4, #1
	b.ne	LBB97_25
; %bb.24:
	ldr	x8, [x3]
	cmp	x8, #2
	cset	w0, lo
	ret
LBB97_25:
	mov	w0, #0                          ; =0x0
	ret
LBB97_26:
	add	x8, x0, x8, lsl #3
	add	x9, x8, #64, lsl #12            ; =262144
	ldr	x8, [x9, #12240]
	cmp	x8, #0
	cset	w0, ne
	ret
LBB97_27:
	bl	_nl_websocket_catalog_type
	b	LBB97_29
LBB97_28:
	bl	_nl_file_catalog_type
LBB97_29:
	mov	x20, x0
	cbz	x0, LBB97_38
; %bb.30:
	mov	x9, x23
	mov	w8, #0                          ; =0x0
	cmp	w23, #11
	b.hi	LBB97_39
; %bb.31:
	mov	w23, w9
	ldr	x10, [x20, #32]
	cmp	x10, x23
	b.ne	LBB97_39
; %bb.32:
	mov	w24, #1                         ; =0x1
	cbz	w9, LBB97_40
; %bb.33:
	mov	x0, x19
	mov	x1, x22
	mov	w25, #16                        ; =0x10
	mov	w26, #50                        ; =0x32
LBB97_34:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20, #24]
	ldr	x2, [x8, x25]
	mov	x3, sp
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_fr_member
	cbz	w0, LBB97_38
; %bb.35:                               ;   in Loop: Header=BB97_34 Depth=1
	ldrb	w8, [sp]
	cmp	w8, #5
	lsl	w8, w24, w8
	and	w8, w8, w26
	ccmp	w8, #0, #4, ls
	b.eq	LBB97_38
; %bb.36:                               ;   in Loop: Header=BB97_34 Depth=1
	ldp	x1, x2, [sp]
	mov	x0, x19
	mov	x3, x21
	mov	w4, #1                          ; =0x1
	bl	_fr_mixed_ws_fields
	cbz	w0, LBB97_38
; %bb.37:                               ;   in Loop: Header=BB97_34 Depth=1
	add	x21, x21, #8
	add	x25, x25, #32
	mov	w8, #1                          ; =0x1
	subs	x23, x23, #1
	mov	x0, x19
	mov	x1, x22
	b.ne	LBB97_34
	b	LBB97_39
LBB97_38:
	mov	w8, #0                          ; =0x0
LBB97_39:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	mov	x0, x8
	ret
LBB97_40:
	mov	w8, #1                          ; =0x1
	b	LBB97_39
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @fr_scalar_result.kinds
_fr_scalar_result.kinds:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	3                               ; 0x3

	.p2align	2, 0x0                          ; @switch.table.fr_core
l_switch.table.fr_core:
	.long	1                               ; 0x1
	.long	7                               ; 0x7
	.long	6                               ; 0x6
	.long	8                               ; 0x8
	.long	3                               ; 0x3
	.long	4                               ; 0x4

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; @.memset_pattern
l_.memset_pattern:
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	2                               ; 0x2
	.long	2                               ; 0x2

	.p2align	4, 0x0                          ; @.memset_pattern.3
l_.memset_pattern.3:
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	1                               ; 0x1
	.long	1                               ; 0x1

.subsections_via_symbols
