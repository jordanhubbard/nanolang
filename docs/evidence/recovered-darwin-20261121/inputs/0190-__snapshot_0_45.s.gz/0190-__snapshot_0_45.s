	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_ws_decoder_storage_bound    ; -- Begin function nl_ws_decoder_storage_bound
	.p2align	2
_nl_ws_decoder_storage_bound:           ; @nl_ws_decoder_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_2
; %bb.1:
	mov	w8, #200                        ; =0xc8
	movk	w8, #32, lsl #16
	str	x8, [x0]
LBB0_2:
	cmp	x0, #0
	cset	w0, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_decoder_create           ; -- Begin function nl_ws_decoder_create
	.p2align	2
_nl_ws_decoder_create:                  ; @nl_ws_decoder_create
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	ldr	x8, [x0]
	cbz	x8, LBB1_3
LBB1_2:
	mov	w0, #3                          ; =0x3
	ret
LBB1_3:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #200                        ; =0xc8
	bl	_calloc
	cbz	x0, LBB1_5
; %bb.4:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	w9, #2                          ; =0x2
	str	w9, [x8, #180]
	str	x8, [x19]
	b	LBB1_6
LBB1_5:
	mov	w0, #6                          ; =0x6
LBB1_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_decoder_destroy          ; -- Begin function nl_ws_decoder_destroy
	.p2align	2
_nl_ws_decoder_destroy:                 ; @nl_ws_decoder_destroy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #136]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB2_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_ws_decoder_feed
lCPI3_0:
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_ws_decoder_feed
	.p2align	2
_nl_ws_decoder_feed:                    ; @nl_ws_decoder_feed
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB3_10
; %bb.1:
	cbz	x3, LBB3_10
; %bb.2:
	cbz	x4, LBB3_10
; %bb.3:
	cmp	x1, #0
	ccmp	x2, #0, #4, eq
	cset	w9, ne
	cmp	x2, #16, lsl #12                ; =65536
	b.hi	LBB3_10
; %bb.4:
	tbnz	w9, #0, LBB3_10
; %bb.5:
	cbz	x2, LBB3_8
; %bb.6:
	sub	x8, x3, x1
	cmp	x8, x2
	cset	w8, lo
	subs	x9, x1, x3
	cmp	x9, #8
	cset	w9, lo
	cmp	x1, x3
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB3_9
; %bb.7:
	sub	x8, x4, x1
	cmp	x8, x2
	cset	w8, lo
	subs	x9, x1, x4
	cmp	x9, #24
	cset	w9, lo
	cmp	x1, x4
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB3_9
LBB3_8:
	sub	x8, x4, x3
	cmp	x8, #8
	cset	w8, lo
	sub	x9, x3, x4
	cmp	x9, #24
	cset	w9, lo
	cmp	x3, x4
	csel	w8, w9, w8, hi
	tbz	w8, #0, LBB3_11
LBB3_9:
	mov	w8, #3                          ; =0x3
LBB3_10:
	mov	x0, x8
	ret
LBB3_11:
	str	xzr, [x3]
	ldr	w8, [x0, #192]
	cbnz	w8, LBB3_10
; %bb.12:
	ldrb	w8, [x0, #188]
	cmp	w8, #1
	b.ne	LBB3_14
; %bb.13:
	str	xzr, [x0, #152]
	strb	wzr, [x0, #188]
	ldr	x9, [x3]
	b	LBB3_15
LBB3_14:
	mov	x9, #0                          ; =0x0
LBB3_15:
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	w23, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
	cmp	x9, x2
	b.hs	LBB3_76
; %bb.16:
	add	x20, x0, #10
Lloh0:
	adrp	x8, lCPI3_0@PAGE
Lloh1:
	ldr	d8, [x8, lCPI3_0@PAGEOFF]
	mov	x22, x0
	mov	x21, x4
	mov	x28, x3
	mov	x27, x1
	b	LBB3_19
LBB3_17:                                ;   in Loop: Header=BB3_19 Depth=1
	ldr	x9, [x3]
LBB3_18:                                ;   in Loop: Header=BB3_19 Depth=1
	mov	w8, #1                          ; =0x1
	cmp	x9, x2
	b.hs	LBB3_76
LBB3_19:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_51 Depth 2
	ldp	w8, w10, [x0, #176]
	cmp	w8, w10
	b.hs	LBB3_28
; %bb.20:                               ;   in Loop: Header=BB3_19 Depth=1
	add	x10, x9, #1
	str	x10, [x3]
	ldrb	w9, [x1, x9]
	add	w10, w8, #1
	str	w10, [x0, #176]
	strb	w9, [x0, x8]
	ldr	w8, [x0, #176]
	cmp	w8, #2
	b.ne	LBB3_29
; %bb.21:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w9, [x0]
	tst	w9, #0x70
	b.ne	LBB3_74
; %bb.22:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrsb	w10, [x0, #1]
	tbnz	w10, #31, LBB3_74
; %bb.23:                               ;   in Loop: Header=BB3_19 Depth=1
	and	w11, w9, #0x7
	cmp	w11, #2
	b.hi	LBB3_74
; %bb.24:                               ;   in Loop: Header=BB3_19 Depth=1
	and	w10, w10, #0x7f
	tbz	w9, #3, LBB3_27
; %bb.25:                               ;   in Loop: Header=BB3_19 Depth=1
	tbz	w9, #7, LBB3_74
; %bb.26:                               ;   in Loop: Header=BB3_19 Depth=1
	cmp	w10, #125
	b.hi	LBB3_74
LBB3_27:                                ;   in Loop: Header=BB3_19 Depth=1
	cmp	w10, #127
	mov	w9, #2                          ; =0x2
	mov	w11, #10                        ; =0xa
	csel	w9, w11, w9, eq
	cmp	w10, #126
	mov	w10, #4                         ; =0x4
	csel	w9, w10, w9, eq
	str	w9, [x0, #180]
	b	LBB3_30
LBB3_28:                                ;   in Loop: Header=BB3_19 Depth=1
	ldp	x24, x8, [x0, #160]
	b	LBB3_55
LBB3_29:                                ;   in Loop: Header=BB3_19 Depth=1
	ldr	w9, [x0, #180]
LBB3_30:                                ;   in Loop: Header=BB3_19 Depth=1
	cmp	w8, w9
	b.lo	LBB3_17
; %bb.31:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w25, [x0]
	tst	w25, #0x70
	b.ne	LBB3_74
; %bb.32:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrsb	w9, [x0, #1]
	mov	w8, #4                          ; =0x4
	tbnz	w9, #31, LBB3_75
; %bb.33:                               ;   in Loop: Header=BB3_19 Depth=1
	and	w10, w25, #0x7
	cmp	w10, #2
	b.hi	LBB3_75
; %bb.34:                               ;   in Loop: Header=BB3_19 Depth=1
	and	w26, w25, #0xf
	and	x24, x9, #0xff
	and	w9, w9, #0xff
	cmp	w26, #8
	b.hs	LBB3_37
; %bb.35:                               ;   in Loop: Header=BB3_19 Depth=1
	cmp	w9, #126
	b.ne	LBB3_39
; %bb.36:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrh	w8, [x0, #2]
	rev16	w24, w8
	cmp	w24, #126
	b.hs	LBB3_43
	b	LBB3_74
LBB3_37:                                ;   in Loop: Header=BB3_19 Depth=1
	tbz	w25, #7, LBB3_75
; %bb.38:                               ;   in Loop: Header=BB3_19 Depth=1
	cmp	w9, #125
	b.ls	LBB3_54
	b	LBB3_75
LBB3_39:                                ;   in Loop: Header=BB3_19 Depth=1
	cmp	w9, #127
	b.ne	LBB3_43
; %bb.40:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrsb	x8, [x0, #2]
	tbnz	x8, #63, LBB3_74
; %bb.41:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w9, [x0, #3]
	lsl	w8, w8, #16
	orr	w8, w8, w9, lsl #8
	ldrb	w9, [x0, #4]
	orr	w8, w8, w9
	ldrb	w9, [x0, #5]
	ldrb	w10, [x0, #6]
	ldrb	w11, [x0, #7]
	lsl	x10, x10, #16
	orr	x9, x10, x9, lsl #24
	orr	x8, x9, x8, lsl #32
	orr	x8, x8, x11, lsl #8
	cbz	x8, LBB3_74
; %bb.42:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w9, [x0, #8]
	orr	x8, x8, x9
	ldrb	w9, [x0, #9]
	orr	x24, x9, x8, lsl #8
	cmp	x24, #256, lsl #12              ; =1048576
	b.hi	LBB3_77
LBB3_43:                                ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w8, [x0, #187]
	cbz	w26, LBB3_46
; %bb.44:                               ;   in Loop: Header=BB3_19 Depth=1
	tbnz	w8, #0, LBB3_74
; %bb.45:                               ;   in Loop: Header=BB3_19 Depth=1
	mov	x8, #0                          ; =0x0
	strb	w26, [x0, #185]
	str	xzr, [x0, #152]
	b	LBB3_48
LBB3_46:                                ;   in Loop: Header=BB3_19 Depth=1
	cbz	w8, LBB3_74
; %bb.47:                               ;   in Loop: Header=BB3_19 Depth=1
	ldr	x8, [x0, #152]
LBB3_48:                                ;   in Loop: Header=BB3_19 Depth=1
	mov	w9, #1048576                    ; =0x100000
	sub	x9, x9, x8
	cmp	x24, x9
	b.hi	LBB3_77
; %bb.49:                               ;   in Loop: Header=BB3_19 Depth=1
	ldr	x9, [x0, #144]
	add	x8, x8, x24
	cmp	x8, x9
	b.ls	LBB3_54
; %bb.50:                               ;   in Loop: Header=BB3_19 Depth=1
	mov	x23, x2
	cmp	x9, #0
	mov	w10, #256                       ; =0x100
	csel	x9, x10, x9, eq
LBB3_51:                                ;   Parent Loop BB3_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	x19, x9
	lsl	x9, x9, #1
	cmp	x19, x8
	b.lo	LBB3_51
; %bb.52:                               ;   in Loop: Header=BB3_19 Depth=1
	ldr	x0, [x0, #136]
	mov	x1, x19
	bl	_realloc
	cbz	x0, LBB3_81
; %bb.53:                               ;   in Loop: Header=BB3_19 Depth=1
	mov	x8, x0
	mov	x0, x22
	stp	x8, x19, [x22, #136]
	mov	x4, x21
	mov	x3, x28
	mov	x2, x23
	mov	x1, x27
	mov	w23, #1                         ; =0x1
LBB3_54:                                ;   in Loop: Header=BB3_19 Depth=1
	mov	x8, #0                          ; =0x0
	strb	w26, [x0, #184]
	lsr	w9, w25, #7
	strb	w9, [x0, #186]
	stp	x24, xzr, [x0, #160]
	ldr	x9, [x3]
LBB3_55:                                ;   in Loop: Header=BB3_19 Depth=1
	sub	x10, x24, x8
	sub	x11, x2, x9
	cmp	x10, x11
	csel	x19, x10, x11, lo
	cbz	x19, LBB3_60
; %bb.56:                               ;   in Loop: Header=BB3_19 Depth=1
	mov	x25, x2
	ldrb	w10, [x0, #184]
	tbnz	w10, #3, LBB3_58
; %bb.57:                               ;   in Loop: Header=BB3_19 Depth=1
	ldr	x8, [x0, #136]
	ldr	x10, [x0, #152]
	add	x0, x8, x10
	add	x1, x1, x9
	mov	x2, x19
	bl	_memcpy
	mov	x0, x22
	ldr	x8, [x22, #152]
	add	x8, x8, x19
	str	x8, [x22, #152]
	b	LBB3_59
LBB3_58:                                ;   in Loop: Header=BB3_19 Depth=1
	add	x0, x20, x8
	add	x1, x1, x9
	mov	x2, x19
	bl	_memcpy
	mov	x0, x22
LBB3_59:                                ;   in Loop: Header=BB3_19 Depth=1
	ldr	x8, [x0, #168]
	add	x8, x8, x19
	str	x8, [x0, #168]
	mov	x3, x28
	ldr	x8, [x28]
	add	x9, x8, x19
	str	x9, [x28]
	ldp	x24, x8, [x0, #160]
	mov	x4, x21
	mov	x2, x25
	mov	x1, x27
LBB3_60:                                ;   in Loop: Header=BB3_19 Depth=1
	cmp	x8, x24
	b.ne	LBB3_18
; %bb.61:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w8, [x0, #184]
	str	d8, [x0, #176]
	tbnz	w8, #3, LBB3_67
; %bb.62:                               ;   in Loop: Header=BB3_19 Depth=1
	ldrb	w8, [x0, #186]
	mvn	w10, w8
	bic	w8, w23, w8
	strb	w8, [x0, #187]
	tbnz	w10, #0, LBB3_18
; %bb.63:
	ldrb	w9, [x0, #185]
	ldr	x8, [x0, #136]
	ldr	x1, [x0, #152]
	cmp	w9, #1
	b.ne	LBB3_66
; %bb.64:
	mov	x0, x8
	mov	x2, #0                          ; =0x0
	bl	_nl_utf8_validate
	mov	x8, x0
	mov	x0, x22
	cbz	w8, LBB3_74
; %bb.65:
	ldrb	w9, [x0, #185]
	ldr	x8, [x0, #136]
	ldr	x1, [x0, #152]
	mov	x4, x21
LBB3_66:
	stp	w9, wzr, [x4]
	stp	x8, x1, [x4, #8]
	mov	w9, #1                          ; =0x1
	mov	w8, #2                          ; =0x2
	strb	w9, [x0, #188]
	b	LBB3_76
LBB3_67:
	cmp	w8, #8
	b.ne	LBB3_80
; %bb.68:
	cbz	x24, LBB3_78
; %bb.69:
	cmp	x24, #1
	b.eq	LBB3_74
; %bb.70:
	ldrh	w8, [x0, #10]
	rev16	w8, w8
	sub	w9, w8, #1000
	sub	w10, w8, #1007
	cmn	w10, #3
	ccmp	w9, #15, #2, lo
	b.lo	LBB3_72
; %bb.71:
	sub	w8, w8, #3000
	cmp	w8, #1999
	b.hi	LBB3_74
LBB3_72:
	sub	x1, x24, #2
	add	x0, x22, #12
	mov	x2, #0                          ; =0x0
	bl	_nl_utf8_validate
	mov	x8, x0
	mov	x0, x22
	cbz	w8, LBB3_74
; %bb.73:
	ldrb	w8, [x0, #184]
	ldr	x24, [x0, #160]
	mov	x4, x21
	b	LBB3_79
LBB3_74:
	mov	w8, #4                          ; =0x4
LBB3_75:
	str	w8, [x0, #192]
LBB3_76:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB3_77:
	mov	w8, #5                          ; =0x5
	b	LBB3_75
LBB3_78:
	mov	w8, #8                          ; =0x8
LBB3_79:
	mov	w9, #7                          ; =0x7
	str	w9, [x0, #192]
LBB3_80:
	stp	w8, wzr, [x4]
	mov	w8, #2                          ; =0x2
	stp	x20, x24, [x4, #8]
	b	LBB3_76
LBB3_81:
	mov	w8, #6                          ; =0x6
	mov	x0, x22
	b	LBB3_75
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_decoder_eof              ; -- Begin function nl_ws_decoder_eof
	.p2align	2
_nl_ws_decoder_eof:                     ; @nl_ws_decoder_eof
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_3
; %bb.1:
	mov	x8, x0
	ldr	w0, [x0, #192]
	cbz	w0, LBB4_4
; %bb.2:
	ret
LBB4_3:
	mov	w0, #3                          ; =0x3
	ret
LBB4_4:
	mov	w0, #4                          ; =0x4
	str	w0, [x8, #192]
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nl_ws_client_frame
lCPI5_0:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI5_1:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_ws_client_frame
	.p2align	2
_nl_ws_client_frame:                    ; @nl_ws_client_frame
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x3, LBB5_5
; %bb.1:
	cbz	x4, LBB5_5
; %bb.2:
	cbz	x6, LBB5_5
; %bb.3:
	cbnz	x1, LBB5_6
; %bb.4:
	cbz	x2, LBB5_6
LBB5_5:
	mov	x0, x8
	ret
LBB5_6:
	cmp	w0, #10
	b.hi	LBB5_5
; %bb.7:
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w0
	mov	w10, #1798                      ; =0x706
	tst	w9, w10
	b.eq	LBB5_5
; %bb.8:
	cmp	x2, #256, lsl #12               ; =1048576
	b.ls	LBB5_10
; %bb.9:
	mov	w8, #5                          ; =0x5
	mov	x0, x8
	ret
LBB5_10:
	cmp	w0, #8
	b.lo	LBB5_13
; %bb.11:
	cmp	x2, #125
	b.ls	LBB5_13
; %bb.12:
	mov	w0, #4                          ; =0x4
	ret
LBB5_13:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cmp	w0, #1
	b.eq	LBB5_18
; %bb.14:
	cmp	w0, #8
	b.ne	LBB5_16
; %bb.15:
	mov	x19, x0
	mov	x0, x1
	mov	x20, x1
	mov	x1, x2
	mov	x21, x6
	mov	x25, x3
	mov	x22, x2
	mov	x24, x4
	mov	x23, x5
	bl	_ws_close_valid
	mov	x5, x23
	mov	x4, x24
	mov	x1, x20
	mov	x2, x22
	mov	x3, x25
	mov	x6, x21
	mov	x8, x0
	mov	x0, x19
	tbz	w8, #0, LBB5_19
LBB5_16:
	mov	w8, #10                         ; =0xa
	mov	w9, #4                          ; =0x4
	cmp	x2, #16, lsl #12                ; =65536
	csel	x10, x9, x8, lo
	add	x8, x10, #4
	mov	w9, #6                          ; =0x6
	cmp	x2, #125
	csel	x8, x8, x9, hi
	add	x9, x8, x2
	cmp	x5, x9
	b.hs	LBB5_20
; %bb.17:
	mov	w8, #5                          ; =0x5
	b	LBB5_28
LBB5_18:
	mov	x19, x0
	mov	x0, x1
	mov	x20, x1
	mov	x1, x2
	mov	x21, x2
	mov	x2, #0                          ; =0x0
	mov	x22, x6
	mov	x24, x3
	mov	x23, x4
	mov	x25, x5
	bl	_nl_utf8_validate
	mov	x5, x25
	mov	x4, x23
	mov	x1, x20
	mov	x2, x21
	mov	x3, x24
	mov	x6, x22
	mov	x8, x0
	mov	x0, x19
	cbnz	w8, LBB5_16
LBB5_19:
	mov	w8, #4                          ; =0x4
	b	LBB5_28
LBB5_20:
	cbz	x2, LBB5_22
; %bb.21:
	sub	x11, x4, x1
	cmp	x11, x2
	cset	w11, lo
	subs	x12, x1, x4
	cmp	x12, x9
	cset	w12, lo
	cmp	x1, x4
	csel	w11, w12, w11, hi
	tbnz	w11, #0, LBB5_27
LBB5_22:
	sub	x11, x4, x3
	cmp	x11, #4
	cset	w11, lo
	sub	x12, x3, x4
	cmp	x12, x9
	cset	w12, lo
	cmp	x3, x4
	csel	w11, w12, w11, hi
	tbnz	w11, #0, LBB5_27
; %bb.23:
	sub	x11, x4, x6
	cmp	x11, #8
	cset	w11, lo
	sub	x12, x6, x4
	cmp	x12, x9
	cset	w12, lo
	cmp	x6, x4
	csel	w11, w12, w11, hi
	tbnz	w11, #0, LBB5_27
; %bb.24:
	cbz	x2, LBB5_26
; %bb.25:
	sub	x11, x1, x6
	cmp	x11, #8
	cset	w11, lo
	subs	x12, x6, x1
	cmp	x12, x2
	cset	w12, lo
	cmp	x6, x1
	csel	w11, w12, w11, hi
	tbnz	w11, #0, LBB5_27
LBB5_26:
	sub	x11, x3, x6
	cmp	x11, #8
	cset	w11, lo
	subs	x12, x6, x3
	cmp	x12, #4
	cset	w12, lo
	cmp	x6, x3
	csel	w11, w12, w11, hi
	tbz	w11, #0, LBB5_29
LBB5_27:
	mov	w8, #3                          ; =0x3
LBB5_28:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB5_29:
	orr	w11, w0, #0x80
	strb	w11, [x4]
	cmp	x2, #16, lsl #12                ; =65536
	mov	w11, #126                       ; =0x7e
	cinc	w11, w11, hs
	cmp	x2, #125
	csel	w11, w11, w2, hi
	orr	w11, w11, #0x80
	strb	w11, [x4, #1]
	cmp	x2, #126
	b.lo	LBB5_32
; %bb.30:
	cmp	x2, #16, lsl #12                ; =65536
	b.hs	LBB5_33
; %bb.31:
	mov	w11, #2                         ; =0x2
	b	LBB5_36
LBB5_32:
	ldr	w10, [x3]
	stur	w10, [x4, #2]
	cbnz	x2, LBB5_39
	b	LBB5_41
LBB5_33:
	sub	x12, x10, #2
	and	x13, x12, #0xfffffffffffffffc
	dup.2d	v0, x10
	orr	x11, x12, #0x2
	dup.2d	v1, x2
Lloh2:
	adrp	x14, lCPI5_0@PAGE
Lloh3:
	ldr	q2, [x14, lCPI5_0@PAGEOFF]
Lloh4:
	adrp	x14, lCPI5_1@PAGE
Lloh5:
	ldr	q3, [x14, lCPI5_1@PAGEOFF]
	add	x14, x4, #2
	mov	w15, #4                         ; =0x4
	dup.2d	v4, x15
	mov	x15, x13
LBB5_34:                                ; =>This Inner Loop Header: Depth=1
	mvn.16b	v5, v2
	mvn.16b	v6, v3
	add.2d	v6, v0, v6
	add.2d	v5, v0, v5
	shl.2d	v6, v6, #3
	shl.2d	v5, v5, #3
	neg.2d	v6, v6
	ushl.2d	v6, v1, v6
	neg.2d	v5, v5
	ushl.2d	v5, v1, v5
	xtn.2s	v6, v6
	xtn.2s	v5, v5
	mov.s	w16, v6[1]
	mov.h	v6[1], w16
	mov.s	w16, v5[1]
	mov.h	v6[2], v5[0]
	mov.h	v6[3], w16
	xtn.8b	v6, v6
	st1.s	{ v6 }[0], [x14], #4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	subs	x15, x15, #4
	b.ne	LBB5_34
; %bb.35:
	cmp	x12, x13
	b.eq	LBB5_38
LBB5_36:
	sub	x12, x10, x11
	add	x11, x4, x11
	lsl	x13, x12, #3
	sub	x13, x13, #8
LBB5_37:                                ; =>This Inner Loop Header: Depth=1
	lsr	x14, x2, x13
	strb	w14, [x11], #1
	sub	x13, x13, #8
	sub	x12, x12, #1
	cbnz	x12, LBB5_37
LBB5_38:
	ldr	w11, [x3]
	str	w11, [x4, x10]
LBB5_39:
	mov	x10, #0                         ; =0x0
	add	x8, x4, x8
LBB5_40:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x1, x10]
	and	x12, x10, #0x3
	ldrb	w12, [x3, x12]
	eor	w11, w12, w11
	strb	w11, [x8, x10]
	add	x10, x10, #1
	cmp	x2, x10
	b.ne	LBB5_40
LBB5_41:
	mov	w8, #0                          ; =0x0
	str	x9, [x6]
	b	LBB5_28
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_close_valid
_ws_close_valid:                        ; @ws_close_valid
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB6_5
; %bb.1:
	cmp	x1, #1
	b.eq	LBB6_4
; %bb.2:
	ldrh	w8, [x0]
	rev16	w8, w8
	sub	w9, w8, #1000
	sub	w10, w8, #1007
	cmn	w10, #3
	ccmp	w9, #15, #2, lo
	b.lo	LBB6_6
; %bb.3:
	sub	w8, w8, #3000
	cmp	w8, #1999
	b.ls	LBB6_6
LBB6_4:
	mov	w0, #0                          ; =0x0
	ret
LBB6_5:
	mov	w0, #1                          ; =0x1
	ret
LBB6_6:
	sub	x1, x1, #2
	add	x0, x0, #2
	mov	x2, #0                          ; =0x0
	b	_nl_utf8_validate
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_handshake_key            ; -- Begin function nl_ws_handshake_key
	.p2align	2
_nl_ws_handshake_key:                   ; @nl_ws_handshake_key
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh6:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB7_7
; %bb.1:
	cbz	x1, LBB7_7
; %bb.2:
	cbz	x2, LBB7_7
; %bb.3:
	sub	x8, x1, x0
	cmp	x8, #16
	cset	w8, lo
	subs	x9, x0, x1
	cmp	x9, #25
	cset	w9, lo
	cmp	x0, x1
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB7_6
; %bb.4:
	sub	x8, x2, x0
	cmp	x8, #16
	cset	w8, lo
	subs	x9, x0, x2
	cmp	x9, #29
	cset	w9, lo
	cmp	x0, x2
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB7_6
; %bb.5:
	sub	x8, x2, x1
	cmp	x8, #25
	cset	w8, lo
	subs	x9, x1, x2
	cmp	x9, #29
	cset	w9, lo
	cmp	x1, x2
	csel	w8, w9, w8, hi
	tbz	w8, #0, LBB7_9
LBB7_6:
	mov	w8, #3                          ; =0x3
LBB7_7:
	ldur	x9, [x29, #-96]
Lloh9:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh10:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh11:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB7_12
; %bb.8:
	mov	x0, x8
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB7_9:
	stp	x1, x2, [sp, #8]                ; 16-byte Folded Spill
Lloh12:
	adrp	x8, l_.str@PAGE
Lloh13:
	add	x8, x8, l_.str@PAGEOFF
	ldp	q1, q0, [x8]
	stur	q1, [sp, #123]
	str	wzr, [sp, #28]
	ldrb	w8, [x0, #1]
	ldrb	w9, [x0, #2]
	and	x10, x9, #0x3f
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	bfi	w9, w8, #8, #8
	ldrb	w11, [x0]
	lsl	w12, w11, #16
	orr	w8, w12, w8, lsl #8
	ubfx	x11, x11, #2, #6
Lloh14:
	adrp	x21, _ws_base64.alphabet@PAGE
Lloh15:
	add	x21, x21, _ws_base64.alphabet@PAGEOFF
	ldrb	w11, [x21, x11]
	strb	w11, [sp, #99]
	ubfx	x8, x8, #12, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #100]
	ubfx	x8, x9, #6, #6
	ldrb	w8, [x21, x8]
	ldrb	w9, [x21, x10]
	strb	w8, [sp, #101]
	strb	w9, [sp, #102]
	ldrb	w8, [x0, #4]
	ldrb	w9, [x0, #5]
	and	x10, x9, #0x3f
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	bfi	w9, w8, #8, #8
	ldrb	w11, [x0, #3]
	lsl	w12, w11, #16
	ubfx	x11, x11, #2, #6
	ldrb	w11, [x21, x11]
	orr	w8, w12, w8, lsl #8
	strb	w11, [sp, #103]
	ubfx	x8, x8, #12, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #104]
	ubfx	x8, x9, #6, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #105]
	ldrb	w8, [x21, x10]
	strb	w8, [sp, #106]
	ldrb	w8, [x0, #7]
	ldrb	w9, [x0, #8]
	and	x10, x9, #0x3f
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	bfi	w9, w8, #8, #8
	ldrb	w11, [x0, #6]
	lsl	w12, w11, #16
	orr	w8, w12, w8, lsl #8
	ubfx	x11, x11, #2, #6
	ldrb	w11, [x21, x11]
	strb	w11, [sp, #107]
	ubfx	x8, x8, #12, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #108]
	ubfx	x8, x9, #6, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #109]
	ldrb	w8, [x21, x10]
	strb	w8, [sp, #110]
	ldrb	w8, [x0, #10]
	ldrb	w9, [x0, #11]
	and	x10, x9, #0x3f
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	bfi	w9, w8, #8, #8
	ldrb	w11, [x0, #9]
	lsl	w12, w11, #16
	orr	w8, w12, w8, lsl #8
	ubfx	x11, x11, #2, #6
	ldrb	w11, [x21, x11]
	strb	w11, [sp, #111]
	ubfx	x8, x8, #12, #6
	ldrb	w8, [x21, x8]
	ubfx	x9, x9, #6, #6
	ldrb	w9, [x21, x9]
	strb	w8, [sp, #112]
	strb	w9, [sp, #113]
	ldrb	w8, [x21, x10]
	strb	w8, [sp, #114]
	ldrb	w8, [x0, #13]
	ldrb	w9, [x0, #14]
	and	x10, x9, #0x3f
                                        ; kill: def $w9 killed $w9 killed $x9 def $x9
	bfi	w9, w8, #8, #8
	ldrb	w11, [x0, #12]
	lsl	w12, w11, #16
	orr	w8, w12, w8, lsl #8
	ubfx	x11, x11, #2, #6
	ldrb	w11, [x21, x11]
	strb	w11, [sp, #115]
	ubfx	x8, x8, #12, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #116]
	ubfx	x8, x9, #6, #6
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #117]
	ldrb	w8, [x21, x10]
	strb	w8, [sp, #118]
	ldrb	w8, [x0, #15]
	lsr	x9, x8, #2
	ldrb	w9, [x21, x9]
	strb	w9, [sp, #119]
	ubfiz	x8, x8, #4, #2
	ldrb	w8, [x21, x8]
	strb	w8, [sp, #120]
	mov	w8, #15677                      ; =0x3d3d
	sturh	w8, [sp, #121]
	mov	w8, #16949                      ; =0x4235
	movk	w8, #12593, lsl #16
	stur	w8, [sp, #155]
	stur	q0, [sp, #139]
	bl	_EVP_sha1
	mov	x4, x0
	add	x0, sp, #99
	add	x2, sp, #35
	add	x3, sp, #28
	mov	w1, #60                         ; =0x3c
	mov	x5, #0                          ; =0x0
	bl	_EVP_Digest
	mov	w8, #8                          ; =0x8
	cbz	w0, LBB7_7
; %bb.10:
	ldr	w9, [sp, #28]
	cmp	w9, #20
	b.ne	LBB7_7
; %bb.11:
	mov	w8, #0                          ; =0x0
	ldrb	w9, [sp, #36]
	ldrb	w10, [sp, #35]
	lsl	w10, w10, #16
	ldrb	w11, [sp, #37]
	orr	w10, w10, w9, lsl #8
	orr	w12, w10, w11
	lsr	x9, x12, #18
	ldrb	w9, [x21, x9]
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	ubfx	x10, x10, #12, #6
	ldrb	w10, [x21, x10]
	ubfx	x11, x12, #6, #6
	ldrb	w11, [x21, x11]
	and	x12, x12, #0x3f
	ldrb	w12, [x21, x12]
	ldrb	w13, [sp, #39]
	ldrb	w14, [sp, #38]
	ldrb	w15, [sp, #40]
	lsl	w14, w14, #16
	orr	w14, w14, w13, lsl #8
	orr	w16, w14, w15
	lsr	x13, x16, #18
	ldrb	w13, [x21, x13]
	ubfx	x14, x14, #12, #6
	ldrb	w14, [x21, x14]
	ubfx	x15, x16, #6, #6
	ldrb	w15, [x21, x15]
	and	x16, x16, #0x3f
	ldrb	w16, [x21, x16]
	ldrb	w17, [sp, #42]
	ldrb	w0, [sp, #41]
	ldrb	w1, [sp, #43]
	ldrb	w3, [sp, #45]
	ldrb	w4, [sp, #44]
	ldrb	w5, [sp, #46]
	ldrb	w6, [sp, #48]
	lsl	w0, w0, #16
	ldrb	w7, [sp, #47]
	ldrb	w22, [sp, #49]
	orr	w0, w0, w17, lsl #8
	orr	w2, w0, w1
	ldrb	w23, [sp, #51]
	lsr	x17, x2, #18
	ldrb	w17, [x21, x17]
	ldrb	w24, [sp, #50]
	ubfx	x0, x0, #12, #6
	ldrb	w0, [x21, x0]
	ldrb	w25, [sp, #52]
	ubfx	x1, x2, #6, #6
	ldrb	w1, [x21, x1]
	and	x2, x2, #0x3f
	ldrb	w2, [x21, x2]
	ldrb	w26, [sp, #53]
	lsl	w4, w4, #16
	ldrb	w27, [sp, #54]
	orr	w4, w4, w3, lsl #8
	orr	w28, w4, w5
	lsr	x3, x28, #18
	ldrb	w3, [x21, x3]
	ubfx	x4, x4, #12, #6
	ldrb	w4, [x21, x4]
	ubfx	x5, x28, #6, #6
	ldrb	w5, [x21, x5]
	and	x28, x28, #0x3f
	ldrb	w28, [x21, x28]
	lsl	w7, w7, #16
	orr	w6, w7, w6, lsl #8
	orr	w7, w6, w22
	lsr	x22, x7, #18
	ldrb	w22, [x21, x22]
	ubfx	x6, x6, #12, #6
	ldrb	w6, [x21, x6]
	ubfx	x30, x7, #6, #6
	ldrb	w30, [x21, x30]
	and	x7, x7, #0x3f
	ldrb	w7, [x21, x7]
	lsl	w24, w24, #16
	orr	w23, w24, w23, lsl #8
	orr	w24, w23, w25
	lsr	x25, x24, #18
	ldrb	w25, [x21, x25]
	ubfx	x23, x23, #12, #6
	ldrb	w23, [x21, x23]
	ubfx	x19, x24, #6, #6
	ldrb	w19, [x21, x19]
	and	x24, x24, #0x3f
	ldrb	w24, [x21, x24]
	lsl	w20, w27, #8
	and	w20, w20, #0xf000
	orr	w20, w20, w26, lsl #16
	ubfx	x26, x26, #2, #6
	ldrb	w26, [x21, x26]
	ubfx	x20, x20, #12, #6
	ldrb	w20, [x21, x20]
	ubfiz	x27, x27, #2, #4
	ldrb	w21, [x21, x27]
	ldur	x27, [sp, #115]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	x27, [x9, #16]
	ldur	q0, [sp, #99]
	str	q0, [x9]
	strb	wzr, [x9, #24]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w27, [sp, #4]                   ; 4-byte Folded Reload
	strb	w27, [x9]
	strb	w10, [x9, #1]
	strb	w11, [x9, #2]
	strb	w12, [x9, #3]
	strb	w13, [x9, #4]
	strb	w14, [x9, #5]
	strb	w15, [x9, #6]
	strb	w16, [x9, #7]
	strb	w17, [x9, #8]
	strb	w0, [x9, #9]
	strb	w1, [x9, #10]
	strb	w2, [x9, #11]
	strb	w3, [x9, #12]
	strb	w4, [x9, #13]
	strb	w5, [x9, #14]
	strb	w28, [x9, #15]
	strb	w22, [x9, #16]
	strb	w6, [x9, #17]
	strb	w30, [x9, #18]
	strb	w7, [x9, #19]
	strb	w25, [x9, #20]
	strb	w23, [x9, #21]
	strb	w19, [x9, #22]
	strb	w24, [x9, #23]
	strb	w26, [x9, #24]
	strb	w20, [x9, #25]
	strb	w21, [x9, #26]
	mov	w10, #61                        ; =0x3d
	sturh	w10, [x9, #27]
	b	LBB7_7
LBB7_12:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpLdrGotLdr	Lloh9, Lloh10, Lloh11
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_upgrade_validate         ; -- Begin function nl_ws_upgrade_validate
	.p2align	2
_nl_ws_upgrade_validate:                ; @nl_ws_upgrade_validate
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB8_13
; %bb.1:
	cbz	x2, LBB8_13
; %bb.2:
	cbz	x3, LBB8_13
; %bb.3:
	cbz	x1, LBB8_5
; %bb.4:
	sub	x8, x3, x0
	cmp	x8, x1
	cset	w8, lo
	subs	x9, x0, x3
	cmp	x9, #8
	cset	w9, lo
	cmp	x0, x3
	csel	w8, w9, w8, hi
	tbnz	w8, #0, LBB8_6
LBB8_5:
	sub	x8, x3, x2
	cmp	x8, #29
	cset	w8, lo
	sub	x9, x2, x3
	cmp	x9, #8
	cset	w9, lo
	cmp	x2, x3
	csel	w8, w9, w8, hi
	tbz	w8, #0, LBB8_7
LBB8_6:
	mov	w0, #3                          ; =0x3
	ret
LBB8_7:
	mov	w8, #8192                       ; =0x2000
	cmp	x1, #2, lsl #12                 ; =8192
	csel	x9, x1, x8, lo
	cbz	x1, LBB8_12
; %bb.8:
	ldrb	w10, [x0]
	cbz	w10, LBB8_28
; %bb.9:
	sub	w8, w10, #11
	cmp	w10, #32
	ccmn	w8, #2, #2, lo
	ccmp	w10, #13, #4, lo
	cset	w11, ne
	mov	w8, #4                          ; =0x4
	cmp	w10, #127
	b.eq	LBB8_13
; %bb.10:
	tbnz	w11, #0, LBB8_13
; %bb.11:
	cmp	x1, #1
	b.ne	LBB8_14
LBB8_12:
	lsr	x8, x1, #13
	cmp	x8, #0
	mov	w8, #5                          ; =0x5
	csinc	w8, w8, wzr, ne
LBB8_13:
	mov	x0, x8
	ret
LBB8_14:
	ldrb	w10, [x0, #1]
	cbz	w10, LBB8_13
; %bb.15:
	sub	w8, w10, #11
	cmp	w10, #32
	ccmn	w8, #2, #2, lo
	ccmp	w10, #13, #4, lo
	cset	w11, ne
	mov	w8, #4                          ; =0x4
	cmp	w10, #127
	b.eq	LBB8_13
; %bb.16:
	tbnz	w11, #0, LBB8_13
; %bb.17:
	cmp	x1, #2
	b.eq	LBB8_12
; %bb.18:
	ldrb	w10, [x0, #2]
	cbz	w10, LBB8_13
; %bb.19:
	sub	w8, w10, #11
	cmp	w10, #32
	ccmn	w8, #2, #2, lo
	ccmp	w10, #13, #4, lo
	cset	w11, ne
	mov	w8, #4                          ; =0x4
	cmp	w10, #127
	b.eq	LBB8_13
; %bb.20:
	tbnz	w11, #0, LBB8_13
; %bb.21:
	cmp	x1, #3
	b.eq	LBB8_12
; %bb.22:
	mov	w8, #3                          ; =0x3
	sub	x10, x8, x9
	mov	w9, #2                          ; =0x2
	mov	w11, #2573                      ; =0xa0d
	movk	w11, #2573, lsl #16
LBB8_23:                                ; =>This Inner Loop Header: Depth=1
	add	x8, x0, x9
	ldrb	w12, [x8, #1]
	cbz	w12, LBB8_28
; %bb.24:                               ;   in Loop: Header=BB8_23 Depth=1
	sub	w8, w12, #11
	cmp	w12, #32
	ccmn	w8, #2, #2, lo
	ccmp	w12, #13, #4, lo
	cset	w13, ne
	mov	w8, #4                          ; =0x4
	cmp	w12, #127
	b.eq	LBB8_13
; %bb.25:                               ;   in Loop: Header=BB8_23 Depth=1
	tbnz	w13, #0, LBB8_13
; %bb.26:                               ;   in Loop: Header=BB8_23 Depth=1
	add	x8, x0, x9
	ldur	w8, [x8, #-2]
	cmp	w8, w11
	b.eq	LBB8_29
; %bb.27:                               ;   in Loop: Header=BB8_23 Depth=1
	add	x9, x9, #1
	add	x8, x10, x9
	cmp	x8, #2
	b.ne	LBB8_23
	b	LBB8_12
LBB8_28:
	mov	w0, #4                          ; =0x4
	ret
LBB8_29:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x25, x2
	mov	x8, #0                          ; =0x0
	add	x23, x9, #1
	mov	x21, x9
	add	x9, x9, #2
	stp	x9, x3, [sp, #24]               ; 16-byte Folded Spill
	mov	x22, x0
	b	LBB8_31
LBB8_30:                                ;   in Loop: Header=BB8_31 Depth=1
	add	x8, x8, #1
	cmp	x23, x8
	b.eq	LBB8_33
LBB8_31:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x0, x8]
	cmp	w9, #13
	b.ne	LBB8_30
; %bb.32:                               ;   in Loop: Header=BB8_31 Depth=1
	add	x9, x0, x8
	ldrb	w9, [x9, #1]
	cmp	w9, #10
	b.ne	LBB8_30
	b	LBB8_34
LBB8_33:
	mov	x8, x23
LBB8_34:
	cmp	x8, #13
	b.lo	LBB8_36
; %bb.35:
	ldr	x10, [x22]
	ldur	x9, [x22, #5]
	mov	x11, #21576                     ; =0x5448
	movk	x11, #20564, lsl #16
	movk	x11, #12591, lsl #32
	movk	x11, #12590, lsl #48
	cmp	x10, x11
	mov	x10, #11825                     ; =0x2e31
	movk	x10, #8241, lsl #16
	movk	x10, #12337, lsl #32
	movk	x10, #8241, lsl #48
	ccmp	x9, x10, #0, eq
	b.eq	LBB8_38
LBB8_36:
	mov	w8, #4                          ; =0x4
LBB8_37:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	mov	x0, x8
	ret
LBB8_38:
	subs	x9, x8, #13
	b.eq	LBB8_42
; %bb.39:
	add	x10, x22, #13
LBB8_40:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #1
	cmp	w11, #10
	ccmp	w11, #13, #4, ne
	b.eq	LBB8_36
; %bb.41:                               ;   in Loop: Header=BB8_40 Depth=1
	subs	x9, x9, #1
	b.ne	LBB8_40
LBB8_42:
	strb	wzr, [sp, #47]
	add	x20, x8, #2
	cmp	x20, x21
	b.hs	LBB8_36
; %bb.43:
	sub	x8, x22, #1
	stp	xzr, x8, [sp, #8]               ; 16-byte Folded Spill
LBB8_44:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB8_47 Depth 2
                                        ;     Child Loop BB8_53 Depth 2
                                        ;     Child Loop BB8_59 Depth 2
                                        ;     Child Loop BB8_64 Depth 2
                                        ;     Child Loop BB8_69 Depth 2
	mov	x27, x20
	cmp	x20, x23
	b.hs	LBB8_50
; %bb.45:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	x27, x20
	mov	x8, x22
	b	LBB8_47
LBB8_46:                                ;   in Loop: Header=BB8_47 Depth=2
	add	x27, x27, #1
	cmp	x23, x27
	b.eq	LBB8_49
LBB8_47:                                ;   Parent Loop BB8_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x8, x27]
	cmp	w9, #13
	b.ne	LBB8_46
; %bb.48:                               ;   in Loop: Header=BB8_47 Depth=2
	add	x9, x8, x27
	ldrb	w9, [x9, #1]
	cmp	w9, #10
	b.ne	LBB8_46
	b	LBB8_50
LBB8_49:                                ;   in Loop: Header=BB8_44 Depth=1
	mov	x27, x23
LBB8_50:                                ;   in Loop: Header=BB8_44 Depth=1
	subs	x28, x20, x27
	b.hs	LBB8_36
; %bb.51:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	x19, #0                         ; =0x0
	add	x24, x22, x20
	b	LBB8_53
LBB8_52:                                ;   in Loop: Header=BB8_53 Depth=2
	sub	x19, x19, #1
	cmp	x28, x19
	b.eq	LBB8_36
LBB8_53:                                ;   Parent Loop BB8_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w26, [x24], #1
	and	w8, w26, #0xffffffdf
	sub	w8, w8, #65
	sub	w9, w26, #48
	cmp	w9, #10
	ccmp	w8, #26, #0, hs
	b.lo	LBB8_52
; %bb.54:                               ;   in Loop: Header=BB8_53 Depth=2
	cbz	w26, LBB8_36
; %bb.55:                               ;   in Loop: Header=BB8_53 Depth=2
Lloh16:
	adrp	x0, l_.str.9@PAGE
Lloh17:
	add	x0, x0, l_.str.9@PAGEOFF
	mov	x1, x26
	mov	w2, #16                         ; =0x10
	bl	_memchr
	cbnz	x0, LBB8_52
; %bb.56:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	w8, #4                          ; =0x4
	cbz	x19, LBB8_37
; %bb.57:                               ;   in Loop: Header=BB8_44 Depth=1
	cmp	w26, #58
	b.ne	LBB8_37
; %bb.58:                               ;   in Loop: Header=BB8_44 Depth=1
	sub	x8, x20, x19
	add	x26, x8, #1
	cmp	x26, x27
	b.hs	LBB8_62
LBB8_59:                                ;   Parent Loop BB8_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [x22, x26]
	cmp	w8, #32
	ccmp	w8, #9, #4, ne
	b.ne	LBB8_62
; %bb.60:                               ;   in Loop: Header=BB8_59 Depth=2
	add	x26, x26, #1
	cmp	x27, x26
	b.ne	LBB8_59
; %bb.61:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	x26, x27
LBB8_62:                                ;   in Loop: Header=BB8_44 Depth=1
	mov	x8, x27
	cmp	x27, x26
	b.ls	LBB8_67
; %bb.63:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	x8, x27
LBB8_64:                                ;   Parent Loop BB8_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w9, [x9, x8]
	cmp	w9, #32
	ccmp	w9, #9, #4, ne
	b.ne	LBB8_67
; %bb.65:                               ;   in Loop: Header=BB8_64 Depth=2
	sub	x8, x8, #1
	cmp	x8, x26
	b.hi	LBB8_64
; %bb.66:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	x8, x26
LBB8_67:                                ;   in Loop: Header=BB8_44 Depth=1
	subs	x24, x8, x26
	b.ls	LBB8_71
; %bb.68:                               ;   in Loop: Header=BB8_44 Depth=1
	add	x8, x22, x26
	mov	x9, x24
LBB8_69:                                ;   Parent Loop BB8_44 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w10, [x8], #1
	cmp	w10, #10
	ccmp	w10, #13, #4, ne
	b.eq	LBB8_36
; %bb.70:                               ;   in Loop: Header=BB8_69 Depth=2
	subs	x9, x9, #1
	b.ne	LBB8_69
LBB8_71:                                ;   in Loop: Header=BB8_44 Depth=1
	neg	x19, x19
	add	x0, x22, x20
	mov	x1, x19
Lloh18:
	adrp	x2, l_.str.3@PAGE
Lloh19:
	add	x2, x2, l_.str.3@PAGEOFF
	bl	_ws_case_equal
	cbz	w0, LBB8_75
; %bb.72:                               ;   in Loop: Header=BB8_44 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbnz	w8, #0, LBB8_36
; %bb.73:                               ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x26
	mov	x1, x24
Lloh20:
	adrp	x2, l_.str.4@PAGE
Lloh21:
	add	x2, x2, l_.str.4@PAGEOFF
	bl	_ws_case_equal
	tbz	w0, #0, LBB8_36
; %bb.74:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB8_84
LBB8_75:                                ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x20
	mov	x1, x19
Lloh22:
	adrp	x2, l_.str.5@PAGE
Lloh23:
	add	x2, x2, l_.str.5@PAGEOFF
	bl	_ws_case_equal
	cbz	w0, LBB8_77
; %bb.76:                               ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x26
	add	x2, sp, #47
	mov	x1, x24
	bl	_ws_connection_tokens
	tbnz	w0, #0, LBB8_84
	b	LBB8_36
LBB8_77:                                ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x20
	mov	x1, x19
Lloh24:
	adrp	x2, l_.str.6@PAGE
Lloh25:
	add	x2, x2, l_.str.6@PAGEOFF
	bl	_ws_case_equal
	cbz	w0, LBB8_82
; %bb.78:                               ;   in Loop: Header=BB8_44 Depth=1
	cmp	x24, #28
	cset	w8, ne
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	orr	w8, w9, w8
	tbnz	w8, #0, LBB8_36
; %bb.79:                               ;   in Loop: Header=BB8_44 Depth=1
	add	x8, x22, x26
	ldp	x9, x10, [x8]
	ldp	x12, x13, [x25]
	ldr	x14, [x8, #16]
	ldr	x15, [x25, #16]
	ldr	w8, [x8, #24]
	ldr	w11, [x25, #24]
	cmp	x9, x12
	ccmp	x10, x13, #0, eq
	ccmp	x14, x15, #0, eq
	ccmp	x8, x11, #0, eq
	b.ne	LBB8_36
; %bb.80:                               ;   in Loop: Header=BB8_44 Depth=1
	ldrb	w8, [x25, #28]
	cbnz	w8, LBB8_36
; %bb.81:                               ;   in Loop: Header=BB8_44 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB8_84
LBB8_82:                                ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x20
	mov	x1, x19
Lloh26:
	adrp	x2, l_.str.7@PAGE
Lloh27:
	add	x2, x2, l_.str.7@PAGEOFF
	bl	_ws_case_equal
	tbnz	w0, #0, LBB8_36
; %bb.83:                               ;   in Loop: Header=BB8_44 Depth=1
	add	x0, x22, x20
	mov	x1, x19
Lloh28:
	adrp	x2, l_.str.8@PAGE
Lloh29:
	add	x2, x2, l_.str.8@PAGEOFF
	bl	_ws_case_equal
	tbnz	w0, #0, LBB8_36
LBB8_84:                                ;   in Loop: Header=BB8_44 Depth=1
	add	x20, x27, #2
	cmp	x20, x21
	b.lo	LBB8_44
; %bb.85:
	ldrb	w8, [sp, #47]
	ldp	w10, w9, [sp, #8]               ; 8-byte Folded Reload
	and	w9, w9, w10
	and	w8, w9, w8
	tbz	w8, #0, LBB8_36
; %bb.86:
	mov	w8, #0                          ; =0x0
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	str	x10, [x9]
	b	LBB8_37
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_case_equal
_ws_case_equal:                         ; @ws_case_equal
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	mov	x0, x2
	bl	_strlen
	cmp	x0, x21
	b.ne	LBB9_5
; %bb.1:
	cbz	x21, LBB9_6
; %bb.2:
	sub	x8, x21, #1
LBB9_3:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x20], #1
	sub	w10, w9, #65
	orr	w11, w9, #0x20
	cmp	w10, #26
	csel	w10, w11, w9, lo
	ldrb	w11, [x19], #1
	subs	x8, x8, #1
	cset	w9, hs
	cmp	w10, w11
	cset	w0, eq
	b.ne	LBB9_7
; %bb.4:                                ;   in Loop: Header=BB9_3 Depth=1
	tbnz	w9, #0, LBB9_3
	b	LBB9_7
LBB9_5:
	mov	w0, #0                          ; =0x0
	b	LBB9_7
LBB9_6:
	mov	w0, #1                          ; =0x1
LBB9_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_connection_tokens
_ws_connection_tokens:                  ; @ws_connection_tokens
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB10_29
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x27, #0                         ; =0x0
	sub	x23, x1, #1
	mov	w24, #1                         ; =0x1
Lloh30:
	adrp	x22, l_.str.9@PAGE
Lloh31:
	add	x22, x22, l_.str.9@PAGEOFF
	b	LBB10_3
LBB10_2:                                ;   in Loop: Header=BB10_3 Depth=1
	add	x27, x27, #1
	cmp	x27, x20
	b.hs	LBB10_30
LBB10_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_7 Depth 2
                                        ;     Child Loop BB10_22 Depth 2
	add	x26, x21, x27
	ldrb	w8, [x26]
	cmp	w8, #32
	ccmp	w8, #9, #4, ne
	b.eq	LBB10_2
; %bb.4:                                ;   in Loop: Header=BB10_3 Depth=1
	cmp	x27, x20
	b.hs	LBB10_30
; %bb.5:                                ;   in Loop: Header=BB10_3 Depth=1
	mov	x25, x27
	b	LBB10_7
LBB10_6:                                ;   in Loop: Header=BB10_7 Depth=2
	add	x25, x25, #1
	cmp	x20, x25
	b.eq	LBB10_10
LBB10_7:                                ;   Parent Loop BB10_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w1, [x21, x25]
	and	w8, w1, #0xffffffdf
	sub	w8, w8, #65
	sub	w9, w1, #48
	cmp	w9, #10
	ccmp	w8, #26, #0, hs
	b.lo	LBB10_6
; %bb.8:                                ;   in Loop: Header=BB10_7 Depth=2
	cbz	w1, LBB10_11
; %bb.9:                                ;   in Loop: Header=BB10_7 Depth=2
	mov	x0, x22
	mov	w2, #16                         ; =0x10
	bl	_memchr
	cbnz	x0, LBB10_6
	b	LBB10_11
LBB10_10:                               ;   in Loop: Header=BB10_3 Depth=1
	mov	x25, x20
LBB10_11:                               ;   in Loop: Header=BB10_3 Depth=1
	subs	x8, x25, x27
	b.eq	LBB10_30
; %bb.12:                               ;   in Loop: Header=BB10_3 Depth=1
	cmp	x8, #7
	b.ne	LBB10_21
; %bb.13:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #117
	b.ne	LBB10_21
; %bb.14:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #1]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #112
	b.ne	LBB10_21
; %bb.15:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #2]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #103
	b.ne	LBB10_21
; %bb.16:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #3]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #114
	b.ne	LBB10_21
; %bb.17:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #4]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #97
	b.ne	LBB10_21
; %bb.18:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #5]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #100
	b.ne	LBB10_21
; %bb.19:                               ;   in Loop: Header=BB10_3 Depth=1
	ldrb	w8, [x26, #6]
	sub	w9, w8, #65
	orr	w10, w8, #0x20
	cmp	w9, #26
	csel	w8, w10, w8, lo
	cmp	w8, #101
	b.ne	LBB10_21
; %bb.20:                               ;   in Loop: Header=BB10_3 Depth=1
	strb	w24, [x19]
LBB10_21:                               ;   in Loop: Header=BB10_3 Depth=1
	cmp	x25, x20
	b.hs	LBB10_27
LBB10_22:                               ;   Parent Loop BB10_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [x21, x25]
	cmp	w8, #32
	ccmp	w8, #9, #4, ne
	b.ne	LBB10_24
; %bb.23:                               ;   in Loop: Header=BB10_22 Depth=2
	add	x25, x25, #1
	cmp	x20, x25
	b.ne	LBB10_22
	b	LBB10_28
LBB10_24:                               ;   in Loop: Header=BB10_3 Depth=1
	mov	w0, #0                          ; =0x0
	cmp	x23, x25
	b.eq	LBB10_31
; %bb.25:                               ;   in Loop: Header=BB10_3 Depth=1
	cmp	w8, #44
	b.ne	LBB10_31
; %bb.26:                               ;   in Loop: Header=BB10_3 Depth=1
	add	x25, x25, #1
LBB10_27:                               ;   in Loop: Header=BB10_3 Depth=1
	mov	x27, x25
	cmp	x25, x20
	b.lo	LBB10_3
LBB10_28:
	mov	w0, #1                          ; =0x1
	b	LBB10_31
LBB10_29:
	mov	w0, #0                          ; =0x0
	ret
LBB10_30:
	mov	w0, #0                          ; =0x0
LBB10_31:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

l_.str.1:                               ; @.str.1
	.asciz	"\r\n\r\n"

l_.str.2:                               ; @.str.2
	.asciz	"HTTP/1.1 101 "

l_.str.3:                               ; @.str.3
	.asciz	"upgrade"

l_.str.4:                               ; @.str.4
	.asciz	"websocket"

l_.str.5:                               ; @.str.5
	.asciz	"connection"

l_.str.6:                               ; @.str.6
	.asciz	"sec-websocket-accept"

l_.str.7:                               ; @.str.7
	.asciz	"sec-websocket-extensions"

l_.str.8:                               ; @.str.8
	.asciz	"sec-websocket-protocol"

_ws_base64.alphabet:                    ; @ws_base64.alphabet
	.asciz	"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

l_.str.9:                               ; @.str.9
	.asciz	"!#$%&'*+-.^_`|~"

.subsections_via_symbols
