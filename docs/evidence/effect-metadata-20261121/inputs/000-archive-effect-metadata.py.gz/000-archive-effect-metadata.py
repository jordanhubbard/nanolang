from pathlib import Path
import json,gzip,hashlib
base=Path('.test_output');dest=Path('docs/evidence/effect-metadata-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True);paths={Path(__file__)}
for name in ['effect-metadata-baseline','effect-metadata-restored-baseline','effect-metadata-ready-baseline','effect-metadata-owned-repair','effect-metadata-ordinary']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['run-effect-baseline.py','run-effect-restored-baseline.py','run-effect-ready-baseline.py','run-effect-owned-repair.py','run-effect-ordinary.py','retain-effect-ordinary-driver.py']:
 paths.add(base/name)
for name in ['src/env.c','src/nanolang.h','src/typechecker.c','tests/test_eval.c','tests/test_eval_effect_metadata_ownership.c','tests/test_interpreter_ffi_native.c','Makefile.gnu']:
 paths.add(Path(name))
a=json.loads((base/'effect-metadata-ready-baseline/manifest.json').read_text());b=json.loads((base/'effect-metadata-owned-repair/manifest.json').read_text())
for n in ['tests/test_eval.c','tests/test_eval_effect_metadata_ownership.c','src/typechecker.c']:assert a['source_sha256'][n]==b['source_sha256'][n]
for folder,expected in [('effect-metadata-ready-baseline','29765 byte(s) leaked in 583'),('effect-metadata-owned-repair','13352 byte(s) leaked in 384')]:assert expected in (base/folder/'complete-original.stderr').read_text()
for n in ['effect-controls','complete-original']:assert ' in env_define_effect ' not in (base/'effect-metadata-owned-repair'/(n+'.stderr')).read_text()
assert all(x['returncode']==0 for x in json.loads((base/'effect-metadata-ordinary/manifest.json').read_text())['steps']);assert all(x['returncode']==0 for x in json.loads((base/'effect-metadata-ordinary/retained-driver.json').read_text())['steps'])
sha=lambda b:hashlib.sha256(b).hexdigest();provider_files={}
for root in [Path('obj'),base/'obj-effect-owned-repair',base/'obj-effect-ordinary']:
 for p in root.rglob('*.o'):provider_files[str(p)]=sha(p.read_bytes())
(base/'effect-metadata-provider-identities.json').write_text(json.dumps(dict(observed_after_runs=True,files=provider_files),indent=2)+'\n');paths.add(base/'effect-metadata-provider-identities.json')
entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,limits=['I retain complete failing sanitizer outcomes. My successful ordinary Make recipe removes its executable; the separately derived and executed retained driver has its own command/hash/terminal. Provider hashes are observed after these runs.']),indent=2)+'\n')
for x in entries:
 raw=(dest/x['artifact']).read_bytes();assert sha(raw)==x['compressed_sha256'] and sha(gzip.decompress(raw))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(x.stat().st_size for x in seen.values()))
