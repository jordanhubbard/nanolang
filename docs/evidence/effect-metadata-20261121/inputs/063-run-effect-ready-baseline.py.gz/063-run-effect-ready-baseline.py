from pathlib import Path
import json,subprocess,os,time,hashlib
root=Path.cwd();out=root/'.test_output/effect-metadata-ready-baseline';out.mkdir(exist_ok=False);m=json.loads((root/'.test_output/effect-metadata-baseline/manifest.json').read_text());env=dict(os.environ,**m['environment']);record=dict(base_pin=m['pin'],source_sha256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['src/env.c','src/typechecker.c','tests/test_eval.c','tests/test_eval_effect_metadata_ownership.c']},steps=[])
for label,target in [('effect-controls','test-eval-effect-metadata-ownership'),('complete-original','test-eval')]:
 args=m['argv'][:-1]+[target];start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(args,env=env,stdout=a,stderr=b,timeout=300)
 record['steps'].append(dict(label=label,argv=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print([(x['label'],x['returncode']) for x in record['steps']])
