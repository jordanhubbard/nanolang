from pathlib import Path
import os,sys,json,subprocess,time
root=Path.cwd();products=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
record=dict(status='running',steps=[],environment={k:os.environ.get(k) for k in ['CC','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']},limits=['I instrument all actual reference-place code and the oracle/original C unit. I compare all retained C reports. This does not instrument every language provider or establish Darwin LeakSanitizer support.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,args):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,timeout=600);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);record['steps'].append(dict(name=name,argv=list(map(str,args)),returncode=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,(name,p.returncode,p.stderr[-1000:]);return p.stdout.decode().splitlines()
flags=['/usr/bin/cc','-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer','-Isrc/nanoisa']
for name,source in [('reference','tests/nvm2c_reference_places_reference.c'),('original','tests/nanoisa/test_reference_places.c')]:run('build-'+name,[*flags,source,'src/nanoisa/reference_places.c','-o',out/name])
record['original_reports']=run('original',[out/'original']);m=json.loads((products/'manifest.json').read_text());paths=[products/e['file'] for e in m['inputs']];reports=[]
for offset in range(0,len(paths),32):reports+=run(f'cases-{offset:05d}',[out/'reference',*paths[offset:offset+32]])
assert reports==(products/'actual-c.reports').read_text().splitlines();record.update(status='passed',cases=len(reports));save();print(json.dumps(dict(status=record['status'],cases=len(reports),original_reports=record['original_reports'])))
