#define _POSIX_C_SOURCE 200809L  /* For mkdtemp */
#include "nanolang.h"
#include "module_builder.h"
#include "runtime/module_build_dir.h"
#include "shell_path.h"
#include "stdlib_runtime.h"
#include "utf8.h"
#include "nanoisa/file_source_snapshot.h"
#include "service_namespace.h"
#include "service_bodies.h"
#include "service_ownership.h"
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <libgen.h>
#include <stdio.h>

/* mkdtemp declaration (if not available via headers) */
#ifndef _DARWIN_C_SOURCE
char *mkdtemp(char *template);
#endif

/* Weak default so binaries that don't define get_project_root() still link */
__attribute__((weak)) const char *get_project_root(void) {
    return ".";
}

/* Module cache to prevent duplicate imports and preserve ASTs */
typedef struct {
    char **loaded_paths;
    ASTNode **loaded_asts;  /* Corresponding ASTs for each path */
    int count;
    int capacity;
} ModuleCache;

static ModuleCache *module_cache = NULL;

static void init_module_cache(void) {
    if (!module_cache) {
        module_cache = malloc(sizeof(ModuleCache));
        module_cache->count = 0;
        module_cache->capacity = 16;
        module_cache->loaded_paths = malloc(sizeof(char*) * module_cache->capacity);
        module_cache->loaded_asts = malloc(sizeof(ASTNode*) * module_cache->capacity);
    }
}

static int cached_module_index(const char *module_path) {
    if (!module_cache || !module_path) return -1;
    for (int i = 0; i < module_cache->count; i++) {
        if (strcmp(module_cache->loaded_paths[i], module_path) == 0) {
            return i;
        }
    }
    char *canonical = realpath(module_path, NULL);
    if (!canonical) return -1;
    int found = -1;
    for (int i = 0; i < module_cache->count; i++) {
        if (strcmp(module_cache->loaded_paths[i], canonical) == 0) {
            found = i;
            break;
        }
    }
    free(canonical);
    return found;
}

static bool is_module_cached(const char *module_path) {
    return cached_module_index(module_path) >= 0;
}

ASTNode *get_cached_module_ast(const char *module_path) {
    int index = cached_module_index(module_path);
    return index < 0 ? NULL : module_cache->loaded_asts[index];
}

static void cache_module(const char *module_path) {
    init_module_cache();
    if (is_module_cached(module_path)) return;
    
    if (module_cache->count >= module_cache->capacity) {
        module_cache->capacity *= 2;
        module_cache->loaded_paths = realloc(module_cache->loaded_paths, 
                                             sizeof(char*) * module_cache->capacity);
        module_cache->loaded_asts = realloc(module_cache->loaded_asts,
                                            sizeof(ASTNode*) * module_cache->capacity);
    }
    char *key = realpath(module_path, NULL);
    module_cache->loaded_paths[module_cache->count] = key ? key : strdup(module_path);
    module_cache->loaded_asts[module_cache->count] = NULL;  /* Set later */
    module_cache->count++;
}

static void cache_module_with_ast(const char *module_path, ASTNode *ast) {
    init_module_cache();
    
    /* Check if already cached - if so, update AST */
    int index = cached_module_index(module_path);
    if (index >= 0) {
        module_cache->loaded_asts[index] = ast;
        return;
    }
    
    /* Not cached yet - add new entry */
    if (module_cache->count >= module_cache->capacity) {
        module_cache->capacity *= 2;
        module_cache->loaded_paths = realloc(module_cache->loaded_paths,
                                             sizeof(char*) * module_cache->capacity);
        module_cache->loaded_asts = realloc(module_cache->loaded_asts,
                                            sizeof(ASTNode*) * module_cache->capacity);
    }
    char *key = realpath(module_path, NULL);
    module_cache->loaded_paths[module_cache->count] = key ? key : strdup(module_path);
    module_cache->loaded_asts[module_cache->count] = ast;
    module_cache->count++;
}

void clear_module_cache(void) {
    if (module_cache) {
        for (int i = 0; i < module_cache->count; i++) {
            free(module_cache->loaded_paths[i]);
            /* Free ASTs - they were allocated during module loading and are no longer needed */
            if (module_cache->loaded_asts[i]) {
                free_ast(module_cache->loaded_asts[i]);
            }
        }
        free(module_cache->loaded_paths);
        free(module_cache->loaded_asts);
        free(module_cache);
        module_cache = NULL;
    }
}

/* Create a new module list */
ModuleList *create_module_list(void) {
    ModuleList *list = malloc(sizeof(ModuleList));
    list->count = 0;
    list->capacity = 8;
    list->module_paths = malloc(sizeof(char*) * list->capacity);
    return list;
}

/* Free a module list */
void free_module_list(ModuleList *list) {
    if (!list) return;
    for (int i = 0; i < list->count; i++) {
        free(list->module_paths[i]);
    }
    free(list->module_paths);
    free(list);
}

/* Add a module path to the list */
void module_list_add(ModuleList *list, const char *module_path) {
    if (!list || !module_path) return;
    
    /* Check if already in list */
    for (int i = 0; i < list->count; i++) {
        if (strcmp(list->module_paths[i], module_path) == 0) {
            return;  /* Already added */
        }
    }
    
    if (list->count >= list->capacity) {
        list->capacity = list->capacity > 0 ? list->capacity * 2 : 8;
        char **new_paths = realloc(list->module_paths, sizeof(char*) * list->capacity);
        if (!new_paths) return;
        list->module_paths = new_paths;
    }

    list->module_paths[list->count++] = strdup(module_path);
}

/* Get module search paths from NANO_MODULE_PATH environment variable */
static char **get_module_search_paths(int *count_out) {
    *count_out = 0;
    char **paths = NULL;
    int capacity = 4;
    paths = malloc(sizeof(char*) * capacity);
    
    /* Get NANO_MODULE_PATH environment variable */
    const char *module_path_env = getenv("NANO_MODULE_PATH");
    
    /* If NANO_MODULE_PATH is not set, use default module directory */
    if (!module_path_env || safe_strlen(module_path_env) == 0) {
        /* Default to "modules" directory in current working directory */
        *count_out = 1;
        free(paths);  /* Free the initial allocation */
        paths = malloc(sizeof(char*));
        paths[0] = strdup("modules");
        return paths;
    }
    
    if (module_path_env && safe_strlen(module_path_env) > 0) {
        /* Split by colon (Unix) or semicolon (Windows) */
        char *path_copy = strdup(module_path_env);
        char *token = strtok(path_copy, ":;");
        
        while (token) {
            /* Skip empty tokens */
            assert(token != NULL);
            if (safe_strlen(token) > 0) {
                if (*count_out >= capacity) {
                    capacity *= 2;
                    paths = realloc(paths, sizeof(char*) * capacity);
                }
                paths[*count_out] = strdup(token);
                (*count_out)++;
            }
            token = strtok(NULL, ":;");
        }
        
        free(path_copy);
    }
    
    /* Add default path: ~/.nanolang/modules */
    const char *home = getenv("HOME");
    if (home) {
        char default_path[512];
        snprintf(default_path, sizeof(default_path), "%s/.nanolang/modules", home);
        
        if (*count_out >= capacity) {
            capacity *= 2;
            paths = realloc(paths, sizeof(char*) * capacity);
        }
        paths[*count_out] = strdup(default_path);
        (*count_out)++;
    }
    
    return paths;
}

/* Free module search paths array */
static void free_module_search_paths(char **paths, int count) {
    if (!paths) return;
    for (int i = 0; i < count; i++) {
        free(paths[i]);
    }
    free(paths);
}

/* Find a module in NANO_MODULE_PATH directories
 * Returns path to module package (.nano.tar.zst) or NULL if not found
 */
char *find_module_in_paths(const char *module_name) {
    if (!module_name) return NULL;
    
    int path_count = 0;
    char **search_paths = get_module_search_paths(&path_count);
    
    char package_name[512];
    snprintf(package_name, sizeof(package_name), "%s.nano.tar.zst", module_name);
    
    for (int i = 0; i < path_count; i++) {
        char package_path[1024];
        snprintf(package_path, sizeof(package_path), "%s/%s", search_paths[i], package_name);
        
        FILE *test = fopen(package_path, "r");
        if (test) {
            fclose(test);
            char *result = strdup(package_path);
            free_module_search_paths(search_paths, path_count);
            return result;
        }
    }
    
    free_module_search_paths(search_paths, path_count);
    return NULL;
}

/* Unpack a module package to a temporary directory
 * Returns allocated string with temp directory path, or NULL on error
 * temp_dir_out must be at least 512 bytes (output parameter)
 */
char *unpack_module_package(const char *package_path, char *temp_dir_out, size_t temp_dir_size) {
    if (!package_path || !temp_dir_out || temp_dir_size < 512) {
        return NULL;
    }
    
    /* Create temporary directory (TMPDIR-aware) */
    const char *tmpdir = getenv("TMPDIR");
    if (!tmpdir || tmpdir[0] == '\0') tmpdir = "/tmp";
    char temp_template[512];
    snprintf(temp_template, sizeof(temp_template), "%s/nanolang_module_XXXXXX", tmpdir);
    char *temp_dir = mkdtemp(temp_template);
    if (temp_dir == NULL || temp_dir != temp_template) {
        fprintf(stderr, "Error: Failed to create temporary directory\n");
        return NULL;
    }
    
    /* Extract package using tar with zstd */
    char extract_cmd[2048];
    snprintf(extract_cmd, sizeof(extract_cmd),
            "tar -I zstd -xf '%s' -C '%s' 2>/dev/null",
            package_path, temp_dir);
    
    int result = system(extract_cmd);
    if (result != 0) {
        fprintf(stderr, "Error: Failed to extract module package '%s'\n", package_path);
        rmdir(temp_dir);
        return NULL;
    }
    
    /* Copy temp directory path to output */
    strncpy(temp_dir_out, temp_dir, temp_dir_size - 1);
    temp_dir_out[temp_dir_size - 1] = '\0';
    
    return strdup(temp_dir);
}

/* Resolve module path relative to current file or in module search paths
 * Returns a malloc'd string that caller must free
 * Note: Returns const char* to match NanoLang's string type mapping
 */
const char *resolve_module_path(const char *module_path, const char *current_file) {
    if (!module_path) return NULL;
    
    /* I resolve explicit relative paths from the importing file, like bare paths. */
    if (module_path[0] == '/') {
        return strdup(module_path);
    }
    
    /* Check if this is a project-relative path (common prefixes like std/, stdlib/, examples/, src/) */
    if (strncmp(module_path, "examples/", 9) == 0 ||
        strncmp(module_path, "modules/", 8) == 0 ||
        strncmp(module_path, "src/", 4) == 0 ||
        strncmp(module_path, "src_nano/", 9) == 0 ||
        strncmp(module_path, "std/", 4) == 0 ||
        strncmp(module_path, "stdlib/", 7) == 0) {
        /* Try to find project root by walking up from current_file */
        if (current_file) {
            char current_dir[1024];
            strncpy(current_dir, current_file, sizeof(current_dir) - 1);
            current_dir[sizeof(current_dir) - 1] = '\0';
            
            /* Remove filename to get directory */
            char *last_slash = strrchr(current_dir, '/');
            if (last_slash) {
                *last_slash = '\0';
                
                /* Walk up to find project root (directory containing "modules/" or "examples/") */
                char test_path[2048];  /* Increased to handle long paths */
                for (int depth = 0; depth < 10; depth++) {
                    /* Check if this directory has modules/ or examples/ subdirectory */
                    snprintf(test_path, sizeof(test_path), "%s/modules", current_dir);
                    DIR *dir = opendir(test_path);
                    if (dir) {
                        closedir(dir);
                        /* Found project root - resolve path from here */
                        /* Prefer canonical stdlib/modules over legacy root-level paths */
                        const char *prefixes[] = {"stdlib/", "modules/", "", NULL};
                        for (int p = 0; prefixes[p] != NULL; p++) {
                            snprintf(test_path, sizeof(test_path), "%s/%s%s", current_dir, prefixes[p], module_path);
                            FILE *test = fopen(test_path, "r");
                            if (test) {
                                fclose(test);
                                return strdup(test_path);
                            }
                        }
                        break;
                    }
                    
                    /* Try examples/ directory */
                    snprintf(test_path, sizeof(test_path), "%s/examples", current_dir);
                    dir = opendir(test_path);
                    if (dir) {
                        closedir(dir);
                        /* Found project root - resolve path from here */
                        /* Prefer canonical stdlib/modules over legacy root-level paths */
                        const char *prefixes[] = {"stdlib/", "modules/", "", NULL};
                        for (int p = 0; prefixes[p] != NULL; p++) {
                            snprintf(test_path, sizeof(test_path), "%s/%s%s", current_dir, prefixes[p], module_path);
                            FILE *test = fopen(test_path, "r");
                            if (test) {
                                fclose(test);
                                return strdup(test_path);
                            }
                        }
                        break;
                    }
                    
                    /* Move up one directory */
                    last_slash = strrchr(current_dir, '/');
                    if (!last_slash) break;
                    *last_slash = '\0';
                }
            }
        }

        /* Fallback: try CWD-relative parent directories as project root.
         * Handles the case where current_file is a shallow relative path
         * (e.g. "language/foo.nano") and the walk-up from the file path
         * runs out of parent directories before finding the project root. */
        {
            char test_path[2048];
            const char *parents[] = {".", "..", "../..", NULL};
            for (int d = 0; parents[d] != NULL; d++) {
                char marker[2048];
                snprintf(marker, sizeof(marker), "%s/modules", parents[d]);
                DIR *dir = opendir(marker);
                if (!dir) {
                    snprintf(marker, sizeof(marker), "%s/examples", parents[d]);
                    dir = opendir(marker);
                }
                if (dir) {
                    closedir(dir);
                    const char *prefixes[] = {"stdlib/", "modules/", "", NULL};
                    for (int p = 0; prefixes[p] != NULL; p++) {
                        snprintf(test_path, sizeof(test_path), "%s/%s%s", parents[d], prefixes[p], module_path);
                        FILE *test = fopen(test_path, "r");
                        if (test) {
                            fclose(test);
                            return strdup(test_path);
                        }
                    }
                    break;
                }
            }
        }

        /* Use NANO_MODULE_PATH to derive project root: if set to .../repo/modules,
         * try .../repo/<module_path> so examples/ and std/ resolve when cwd is not repo. */
        {
            int path_count = 0;
            char **search_paths = get_module_search_paths(&path_count);
            for (int i = 0; i < path_count; i++) {
                const char *base = search_paths[i];
                const char *last = strrchr(base, '/');
                if (!last) continue;
                char project_root[2048];
                size_t root_len = (size_t)(last - base);
                if (root_len >= sizeof(project_root)) continue;
                memcpy(project_root, base, root_len);
                project_root[root_len] = '\0';
                const char *prefixes[] = {"stdlib/", "modules/", "", NULL};
                for (int p = 0; prefixes[p] != NULL; p++) {
                    char test_path[4096];
                    snprintf(test_path, sizeof(test_path), "%s/%s%s", project_root, prefixes[p], module_path);
                    FILE *test = fopen(test_path, "r");
                    if (test) {
                        fclose(test);
                        free_module_search_paths(search_paths, path_count);
                        return strdup(test_path);
                    }
                }
            }
            free_module_search_paths(search_paths, path_count);
        }
    }
    
    /* First, try relative to current file */
    char *resolved = NULL;
    if (current_file) {
        /* Find last '/' in current_file */
        const char *last_slash = strrchr(current_file, '/');
        if (last_slash) {
            int dir_len = last_slash - current_file + 1;
            assert(module_path != NULL);
            resolved = malloc(dir_len + safe_strlen(module_path) + 1);
            strncpy(resolved, current_file, dir_len);
            safe_strncpy(resolved + dir_len, module_path, safe_strlen(module_path) + 1);
            
            /* Check if file exists */
            FILE *test = fopen(resolved, "r");
            if (test) {
                fclose(test);
                return resolved;
            }
            free((char*)resolved);
            resolved = NULL;
        }
    }

    /* Next, try common project-relative locations from current working directory.
     * This enables imports like "std/math/vector2d.nano" to resolve to
     * "stdlib/std/math/vector2d.nano" during tests (where current_file is often relative). */
    {
        /* Prefer canonical stdlib/modules over legacy root-level paths */
        const char *prefixes[] = {"stdlib/", "modules/", "", NULL};
        char test_path[2048];
        for (int p = 0; prefixes[p] != NULL; p++) {
            snprintf(test_path, sizeof(test_path), "%s%s", prefixes[p], module_path);
            FILE *test = fopen(test_path, "r");
            if (test) {
                fclose(test);
                return strdup(test_path);
            }
        }
    }

    /* Try NANO_MODULE_PATH directories directly with the module path.
     * This handles imports like "std/math/vector2d.nano" when building from
     * a subdirectory (e.g., examples/) where NANO_MODULE_PATH=../modules
     * resolves to the correct location. */
    {
        int path_count = 0;
        char **search_paths = get_module_search_paths(&path_count);
        for (int i = 0; i < path_count; i++) {
            char test_path[2048];
            snprintf(test_path, sizeof(test_path), "%s/%s", search_paths[i], module_path);
            FILE *test = fopen(test_path, "r");
            if (test) {
                fclose(test);
                free_module_search_paths(search_paths, path_count);
                return strdup(test_path);
            }
        }
        free_module_search_paths(search_paths, path_count);
    }
    
    /* If import path starts with "modules/", try NANO_MODULE_PATH with prefix stripped */
    if (strncmp(module_path, "modules/", 8) == 0) {
        const char *stripped = module_path + 8;  /* skip "modules/" */
        int path_count = 0;
        char **search_paths = get_module_search_paths(&path_count);
        for (int i = 0; i < path_count; i++) {
            char test_path[2048];
            snprintf(test_path, sizeof(test_path), "%s/%s", search_paths[i], stripped);
            FILE *test = fopen(test_path, "r");
            if (test) {
                fclose(test);
                free_module_search_paths(search_paths, path_count);
                return strdup(test_path);
            }
        }
        free_module_search_paths(search_paths, path_count);
    }

    /* If not found relative to current file, try module search paths */
    /* Extract module name (remove .nano extension if present) */
    char module_name[256];
    strncpy(module_name, module_path, sizeof(module_name) - 1);
    module_name[sizeof(module_name) - 1] = '\0';
    
    char *dot = strrchr(module_name, '.');
    if (dot && strcmp(dot, ".nano") == 0) {
        *dot = '\0';
    }
    
    /* Look for package in module paths */
    char *package_path = find_module_in_paths(module_name);
    if (package_path) {
        /* Found package - will be unpacked by caller */
        return package_path;
    }
    
    /* Fallback: return module_path as-is (will fail if not found) */
    return strdup(module_path);
}

static char *module_name_from_path(const char *module_path) {
    if (!module_path) {
        return NULL;
    }
    const char *last_slash = strrchr(module_path, '/');
    const char *last_dot = strrchr(module_path, '.');
    if (last_slash && last_dot && last_dot > last_slash) {
        size_t name_len = last_dot - (last_slash + 1);
        return strndup(last_slash + 1, name_len);
    }
    if (last_slash) {
        return strdup(last_slash + 1);
    }
    if (last_dot) {
        size_t name_len = last_dot - module_path;
        return strndup(module_path, name_len);
    }
    return strdup(module_path);
}

/* I return an owned module name for checking or emitting one imported program. */
char *module_program_name(ASTNode *program, const char *module_path) {
    if (!program || program->type != AST_PROGRAM) return NULL;
    for (int i = 0; i < program->as.program.count; i++) {
        ASTNode *item = program->as.program.items[i];
        if (item->type == AST_MODULE_DECL) return strdup(item->as.module_decl.name);
    }
    return module_name_from_path(module_path);
}

static Function *find_module_function(Environment *env, const char *module_name, const char *func_name) {
    if (!env || !func_name) {
        return NULL;
    }
    for (int i = 0; i < env->function_count; i++) {
        if (safe_strcmp(env->functions[i].name, func_name) == 0) {
            if (!module_name || !env->functions[i].module_name ||
                strcmp(env->functions[i].module_name, module_name) == 0) {
                return &env->functions[i];
            }
        }
    }
    return NULL;
}

/* Load and parse a module file */
static ASTNode *load_module_internal(const char *module_path, Environment *env, bool use_cache, ModuleList *modules_to_track) {
    if (!module_path) return NULL;
    
    /* Check if module is already loaded (only if using cache) */
    if (use_cache) {
        if (is_module_cached(module_path)) {
            ASTNode *cached_ast = get_cached_module_ast(module_path);
            if (cached_ast) {
                /* Module fully loaded - return cached AST */
                /* This allows compile_module_to_object to reuse the AST */
                /* without triggering a second parse (fixes nanolang-6h9) */
                return cached_ast;
            }
            /* Module is in cache with NULL AST: it is currently being loaded.
             * This means we have a circular import dependency. */
            fprintf(stderr, "Error: Circular import dependency detected for module '%s'\n", module_path);
            fprintf(stderr, "  Hint: Modules cannot import each other directly or transitively.\n");
            fprintf(stderr, "  Hint: Consider restructuring shared code into a third module.\n");
            return NULL;
        }

        /* Mark module as loading to prevent circular imports */
        cache_module(module_path);
    }
    
    /* Read source file */
    FILE *file = fopen(module_path, "r");
    if (!file) {
        fprintf(stderr, "Error: Could not open module file '%s'\n", module_path);
        return NULL;
    }
    
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    char *source = malloc(size + 1);
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-result"
    fread(source, 1, size, file);
#pragma GCC diagnostic pop
    source[size] = '\0';
    fclose(file);
    
    /* Tokenize */
    int token_count = 0;
    Token *tokens = tokenize(source, &token_count);
    if (!tokens) {
        fprintf(stderr, "Error: Failed to tokenize module '%s'\n", module_path);
        free(source);
        return NULL;
    }
    
    /* Parse */
    ASTNode *module_ast = parse_program(tokens, token_count);
    if (!module_ast) {
        fprintf(stderr, "Error: Failed to parse module '%s'\n", module_path);
        free_tokens(tokens, token_count);
        free(source);
        return NULL;
    }
    
    /* I register aliases in their importer's context, before checking its body. */
    char *saved_current_module = env->current_module;
    char *module_name = module_name_from_path(module_path);
    env->current_module = module_name;

    /* Process imports first - modules may depend on symbols from imported modules */
    if (!process_imports(module_ast, env, modules_to_track, module_path)) {
        fprintf(stderr, "Error: Failed to process imports for module '%s'\n", module_path);
        env->current_module = saved_current_module;
        free(module_name);
        free_ast(module_ast);
        free_tokens(tokens, token_count);
        free(source);
        return NULL;
    }
    
    /* I retain the whole service graph before checking any service identities.
     * Ordinary modules loaded before its first service keep their existing path. */
    if (env->service_origin_count > 0) {
        env->current_module = saved_current_module;
        free(module_name);
        free_tokens(tokens, token_count);
        free(source);
        if (use_cache) cache_module_with_ast(module_path, module_ast);
        return module_ast;
    }

    /* Type check module (without requiring main) */
    /* I must not merge distinct files into one public introspection identity.
     * Imports are resolved first so this also catches a parent/child clash. */
    char *identity = module_program_name(module_ast, module_path);
    for (int i = 0; identity && module_cache && i < module_cache->count; i++) {
        if (!module_cache->loaded_asts[i] ||
            strcmp(module_cache->loaded_paths[i], module_path) == 0) continue;
        char *other = module_program_name(module_cache->loaded_asts[i],
                                          module_cache->loaded_paths[i]);
        bool duplicate = other && strcmp(identity, other) == 0;
        free(other);
        if (duplicate) {
            fprintf(stderr, "Error: I reject ambiguous module introspection identity: %s\n", identity);
            free(identity);
            env->current_module = saved_current_module;
            free(module_name);
            free_ast(module_ast);
            free_tokens(tokens, token_count);
            free(source);
            return NULL;
        }
    }
    /* I retain the same physical source under its declared introspection name. */
    if (identity && strcmp(identity, module_name) != 0)
        env_register_module(env, identity, module_path, false);
    free(identity);
    /* Register module for introspection BEFORE type checking so functions can be tracked */
    env_register_module(env, module_name, module_path, false);  /* is_unsafe will be updated later */
    
    bool saved_suppress_shadow_warnings = env->suppress_shadow_warnings;
    env->suppress_shadow_warnings = true;
    const char *saved_source_file = env_current_file(env);
    /* I borrow the same cache-owned identity as the retained module AST. */
    int source_index = cached_module_index(module_path);
    ModuleInfo *source_owner = env_get_module(env, module_name);
    const char *module_source = source_index >= 0 ? module_cache->loaded_paths[source_index] :
                                (source_owner ? source_owner->path : NULL);
    env_set_current_file(env, module_source);
    bool module_typecheck_ok = type_check_module(module_ast, env);
    env_set_current_file(env, saved_source_file);
    env->suppress_shadow_warnings = saved_suppress_shadow_warnings;
    if (!module_typecheck_ok) {
        fprintf(stderr, "Error: Type checking failed for module '%s'\n", module_path);
        /* NOTE: module_name may have been freed/overwritten by the module's own
         * `module <name>` declaration handler in the typechecker, so we must not
         * free it here.
         */
        env->current_module = saved_current_module;  /* Restore context */
        free_ast(module_ast);
        free_tokens(tokens, token_count);
        free(source);
        return NULL;
    }
    
    /* Restore original module context */
    /* NOTE: We intentionally DON'T free module_name here because:
     * 1. Functions registered during type_check have module_name pointers that reference it
     * 2. Those pointers are just shallow copies from the struct assignment
     * 3. Freeing would create dangling pointers
     * 4. This is a short-lived compiler process, so the memory leak is acceptable
     */
    env->current_module = saved_current_module;
    
    /* Load constants from C headers if module has module.json */
    char *module_dir_copy = strdup(module_path);
    char *dir_result = dirname(module_dir_copy);
    ModuleBuildMetadata *meta = module_load_metadata(dir_result);
    if (meta && meta->headers_count > 0) {
        /* Try to find and parse C headers for constants */
        for (size_t i = 0; i < meta->headers_count; i++) {
            char *header_path = module_find_header(meta->headers[i]);
            if (header_path) {
                int const_count = 0;
                ConstantDef *constants = parse_c_header_constants(header_path, &const_count);
                free(header_path);
                
                if (constants && const_count > 0) {
                    /* Add constants to environment as immutable symbols */
                    for (int j = 0; j < const_count; j++) {
                        /* I keep this module's explicit functions authoritative
                         * over constants discovered implicitly in its headers. */
                        bool exists = false;
                        for (int k = 0; k < module_ast->as.program.count; k++) {
                            ASTNode *declaration = module_ast->as.program.items[k];
                            if (declaration->type == AST_FUNCTION &&
                                strcmp(declaration->as.function.name, constants[j].name) == 0) {
                                exists = true;
                                break;
                            }
                        }
                        for (int k = 0; k < env->symbol_count; k++) {
                            if (strcmp(env->symbols[k].name, constants[j].name) == 0) {
                                exists = true;
                                break;
                            }
                        }
                        
                        if (!exists) {
                            /* Add as new symbol */
                            if (env->symbol_count >= env->symbol_capacity) {
                                env->symbol_capacity = env->symbol_capacity == 0 ? 16 : env->symbol_capacity * 2;
                                env->symbols = realloc(env->symbols, sizeof(Symbol) * env->symbol_capacity);
                            }
                            
                            /* I bypass normal insertion for header constants. */
                            env_symbol_index_invalidate(env);
                            Symbol *sym = &env->symbols[env->symbol_count++];
                            memset(sym, 0, sizeof(*sym));
                            sym->is_global = true;
                            sym->name = strdup(constants[j].name);
                            sym->type = constants[j].type;
                            sym->struct_type_name = NULL;
                            sym->element_type = TYPE_UNKNOWN;
                            sym->type_info = NULL;
                            sym->is_mut = false;  /* Constants are immutable */
                            sym->is_used = true;   /* Assume used (from header) */
                            sym->from_c_header = true;  /* Mark as from C header */
                            sym->def_line = 0;
                            sym->def_column = 0;
                            
                            /* Set value */
                            if (constants[j].type == TYPE_INT) {
                                sym->value.type = VAL_INT;
                                sym->value.as.int_val = constants[j].value;
                            } else if (constants[j].type == TYPE_FLOAT) {
                                sym->value.type = VAL_FLOAT;
                                union { double d; int64_t i; } u;
                                u.i = constants[j].value;
                                sym->value.as.float_val = u.d;
                            }
                        }
                    }
                    
                    /* Free constants array */
                    for (int j = 0; j < const_count; j++) {
                        free(constants[j].name);
                    }
                    free(constants);
                }
            }
        }
    }
    if (meta) {
        module_metadata_free(meta);
    }
    free(module_dir_copy);
    
    free_tokens(tokens, token_count);
    free(source);
    
    /* Cache the AST with the module path for reuse (fixes nanolang-6h9) */
    if (use_cache) {
        cache_module_with_ast(module_path, module_ast);
    }
    
    return module_ast;
}

/* Public wrapper for load_module that uses cache */
ASTNode *load_module(const char *module_path, Environment *env) {
    if (!module_path) return NULL;
    char *canonical = realpath(module_path, NULL);
    ASTNode *program = load_module_internal(canonical ? canonical : module_path, env, true, NULL);
    free(canonical);
    return program;
}

/* Load module from a package file */
ASTNode *load_module_from_package(const char *package_path, Environment *env, char *temp_dir_out, size_t temp_dir_size) {
    if (!package_path || !env) return NULL;
    
    /* Unpack package to temporary directory */
    char temp_dir[512];
    char *unpacked_dir = unpack_module_package(package_path, temp_dir, sizeof(temp_dir));
    if (!unpacked_dir) {
        return NULL;
    }
    
    /* Copy temp directory to output if provided */
    if (temp_dir_out && temp_dir_size > 0) {
        strncpy(temp_dir_out, unpacked_dir, temp_dir_size - 1);
        temp_dir_out[temp_dir_size - 1] = '\0';
    }
    
    /* Find module.nano file in unpacked directory */
    char module_nano_path[1024];
    snprintf(module_nano_path, sizeof(module_nano_path), "%s/module.nano", unpacked_dir);
    
    /* Try alternative: look for any .nano file */
    FILE *test = fopen(module_nano_path, "r");
    if (!test) {
        /* Try to find any .nano file */
        DIR *dir = opendir(unpacked_dir);
        if (dir) {
            struct dirent *entry;
            while ((entry = readdir(dir)) != NULL) {
                if (strstr(entry->d_name, ".nano") != NULL) {
                    /* Skip a name that would not fit rather than opening a
                     * silently truncated path. */
                    int written = snprintf(module_nano_path, sizeof(module_nano_path),
                                           "%s/%s", unpacked_dir, entry->d_name);
                    if (written < 0 || (size_t)written >= sizeof(module_nano_path))
                        continue;
                    break;
                }
            }
            closedir(dir);
        }
    } else {
        fclose(test);
    }
    
    /* Load the module */
    ASTNode *module_ast = load_module(module_nano_path, env);
    
    /* Note: We don't free unpacked_dir here - caller is responsible for cleanup */
    /* The temp directory will be cleaned up by the caller */
    
    return module_ast;
}

static bool process_imports_owned(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file);

/* I bind the parser's own source before import aliases or module declarations
 * can change visible names. Failure leaves both the AST and origin table intact. */
bool bind_service_origin(ASTNode *program, Environment *env, const char *source_file) {
    if (!program || program->type != AST_PROGRAM || !env) return false;
    if (!ast_has_service_declaration(program)) return true;
    int declarations = 0;
    for (int i = 0; i < program->as.program.count; ++i)
        if (program->as.program.items[i]->type == AST_SERVICE_DECL) ++declarations;
    if (declarations != 1) return false;
    if (!source_file || !source_file[0]) return false;
    char *canonical = realpath(source_file, NULL);
    if (!canonical) return false;
    size_t size = strlen(canonical);
    if (!size || size > 4096 || canonical[0] != '/' || !nl_utf8_validate(canonical, size, NULL)) {
        free(canonical);
        return false;
    }
    int index = 0;
    while (index < env->service_origin_count &&
           strcmp(env->service_origins[index], canonical)) ++index;
    if (index == 16) { free(canonical); return false; }
    for (int i = 0; i < program->as.program.count; ++i) {
        ASTNode *node = program->as.program.items[i];
        if (node->type != AST_SERVICE_DECL) continue;
        if (node->as.service_decl.origin_index != -1 &&
            node->as.service_decl.origin_index != index) { free(canonical); return false; }
    }
    if (index == env->service_origin_count) {
        env->service_origins[env->service_origin_count++] = canonical;
    } else free(canonical);
    for (int i = 0; i < program->as.program.count; ++i) {
        ASTNode *node = program->as.program.items[i];
        if (node->type == AST_SERVICE_DECL) node->as.service_decl.origin_index = index;
    }
    return true;
}

/* I acquire data under the original source identity. Repeated import aliases
 * retain the first immutable bytes rather than reopening a changed document. */
bool acquire_service_input(ASTNode *program, Environment *env) {
    if (!program || program->type != AST_PROGRAM || !env) return false;
    ASTNode *service = NULL;
    for (int i = 0; i < program->as.program.count; ++i) {
        ASTNode *node = program->as.program.items[i];
        if (node->type != AST_SERVICE_DECL) continue;
        if (service) return false;
        service = node;
    }
    if (!service) return true;
    int64_t owner = service->as.service_decl.origin_index;
    const char *interface_id = service->as.service_decl.interface_id;
    const char *relative = service->as.service_decl.document_path;
    if (owner < 0 || owner >= env->service_origin_count || owner >= 16 ||
        service->as.service_decl.catalog_version != 1 || !interface_id || !relative ||
        !nl_service_source_catalog_id(interface_id) ||
        service->as.service_decl.interface_bytes != (int64_t)strlen(interface_id) ||
        service->as.service_decl.path_bytes <= 0 ||
        service->as.service_decl.path_bytes > NL_FILE_BINDING_MAX_BYTES ||
        (uint64_t)service->as.service_decl.path_bytes != strlen(relative)) return false;
    const char *origin = env->service_origins[owner];
    if (!origin) return false;
    if (env->service_snapshot_bound[owner]) {
        size_t size = 0, parent = strlen(origin), count = strlen(relative);
        const unsigned char *path = nl_file_source_snapshot_bytes(env->service_inputs,
            env->service_snapshot_indices[owner], 0, &size);
        while (parent && origin[parent - 1] != '/') --parent;
        return nl_service_source_snapshot_catalog(env->service_inputs, env->service_snapshot_indices[owner]) ==
            nl_service_source_catalog_id(interface_id) && path && parent <= size && count == size - parent &&
            !memcmp(path, origin, parent) && !memcmp(path + parent, relative, count);
    }
    if (!env->service_inputs &&
        nl_file_source_snapshots_new(&env->service_inputs) != NL_FILE_BINDING_OK) return false;
    size_t index;
    if (nl_service_source_snapshot_open(env->service_inputs, nl_service_source_catalog_id(interface_id), origin, strlen(origin),
            relative, service->as.service_decl.path_bytes, &index) != NL_FILE_BINDING_OK) return false;
    env->service_snapshot_indices[owner] = index;
    env->service_snapshot_bound[owner] = true;
    return true;
}

/* I apply an explicit module declaration before registering its import aliases. */
static bool process_imports_consumer(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file, bool service_consumer) {
    if (!program || program->type != AST_PROGRAM || !env) return false;
    if (env->service_import_depth == 0) {
        nl_service_ownership_free(env->service_ownership);
        env->service_ownership = NULL;
        nl_service_body_check_free(env->service_bodies);
        env->service_bodies = NULL;
        nl_service_namespace_free(env->service_namespace);
        env->service_namespace = NULL;
    }
    if (!bind_service_origin(program, env, current_file)) {
        fprintf(stderr, "I cannot retain the original source of this File service declaration.\n");
        return false;
    }
    if (!acquire_service_input(program, env)) {
        fprintf(stderr, "I cannot acquire the immutable companion of this File service declaration.\n");
        return false;
    }
    char *saved_owner = env->current_module;
    for (int i = 0; i < program->as.program.count; i++) {
        ASTNode *item = program->as.program.items[i];
        if (item->type == AST_MODULE_DECL) {
            env->current_module = item->as.module_decl.name;
            break;
        }
    }
    bool root = env->service_import_depth++ == 0;
    bool own_modules = root && !modules;
    if (own_modules) modules = create_module_list();
    bool ok = process_imports_owned(program, env, modules, current_file);
    --env->service_import_depth;
    env->current_module = saved_owner;
    if (root && ok && env->service_origin_count > 0) {
        NlServiceNamespace *space = NULL;
        NlFileSourceStatus status = nl_service_namespace_build(program, env, modules, current_file, &space);
        if (status != NL_FILE_SOURCE_OK) {
            fprintf(stderr, "I cannot resolve the complete File service namespace (status %d).\n", status);
        } else {
            nl_service_namespace_free(env->service_namespace);
            env->service_namespace = space;
            uint32_t module = 0;
            while (nl_service_namespace_program(space, module)) {
                if (!bind_service_annotations(nl_service_namespace_program(space, module), env,
                        nl_service_namespace_module(space, module))) {
                    fprintf(stderr, "I cannot retain nominal File type annotations.\n");
                    nl_service_namespace_free(space);
                    env->service_namespace = NULL;
                    break;
                }
                ++module;
            }
            if (env->service_namespace) {
                env->service_bodies = nl_service_check_bodies(space);
                if (!env->service_bodies || env->service_bodies->status == 1 || env->service_bodies->status == 3)
                    fprintf(stderr, "I cannot type-check File service bodies: %s\n",
                            env->service_bodies ? env->service_bodies->diagnostic : "I cannot allocate body facts.");
                if (env->service_bodies && env->service_bodies->status == 0) {
                    env->service_ownership = nl_service_check_ownership(space, env->service_bodies);
                    if (!env->service_ownership || env->service_ownership->status == 1 || env->service_ownership->status == 3)
                        fprintf(stderr, "I cannot verify File service ownership: %s\n",
                                env->service_ownership ? env->service_ownership->diagnostic : "I cannot allocate ownership facts.");
                }
            }
        }
        ok = service_consumer && env->service_namespace && env->service_bodies &&
            env->service_bodies->status == 0 && env->service_ownership &&
            env->service_ownership->status == 0;
        if(!ok)fprintf(stderr, "I have not resolved File service declarations for this consumer.\n");
    }
    if (own_modules) free_module_list(modules);
    return ok;
}

bool process_imports(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file) {
    return process_imports_consumer(program,env,modules,current_file,false);
}

bool process_imports_for_service(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file) {
    /* I retain the complete graph through lowering; the caller owns modules. */
    if(!modules)return false;
    return process_imports_consumer(program,env,modules,current_file,true);
}

/* Process imports in a program */
static bool process_imports_owned(ASTNode *program, Environment *env, ModuleList *modules, const char *current_file) {
    if (!program || program->type != AST_PROGRAM) {
        return false;
    }
    
    /* Track unpacked package directories for cleanup */
    char **unpacked_dirs = NULL;
    int unpacked_count = 0;
    int unpacked_capacity = 4;
    unpacked_dirs = malloc(sizeof(char*) * unpacked_capacity);
    
    /* First pass: collect all imports and resolve paths */
    for (int i = 0; i < program->as.program.count; i++) {
        ASTNode *item = program->as.program.items[i];
        
        if (item->type == AST_IMPORT) {
            char *module_path = (char*)resolve_module_path(item->as.import_stmt.module_path, current_file);
            char *module_alias = item->as.import_stmt.module_alias;  /* NULL if no alias */
            
            if (!module_path) {
                fprintf(stderr, "Error at line %d, column %d: Failed to resolve module path '%s'\n",
                        item->line, item->column, item->as.import_stmt.module_path);
                /* Cleanup unpacked directories */
                for (int j = 0; j < unpacked_count; j++) {
                    free(unpacked_dirs[j]);
                }
                free(unpacked_dirs);
                return false;
            }

            /* I identify an existing imported file once, independent of spelling.
             * Dependencies of a symlinked file belong to its target directory. */
            char *canonical_path = realpath(module_path, NULL);
            if (canonical_path) {
                free(module_path);
                module_path = canonical_path;
            }
            
            ASTNode *module_ast = NULL;
            char temp_dir[512] = {0};
            
            /* Check if this is a package file (.nano.tar.zst) */
            if (strstr(module_path, ".nano.tar.zst") != NULL) {
                /* Load from package */
                module_ast = load_module_from_package(module_path, env, temp_dir, sizeof(temp_dir));
                
                /* Track unpacked directory for cleanup */
                if (temp_dir[0] != '\0') {
                    if (unpacked_count >= unpacked_capacity) {
                        unpacked_capacity *= 2;
                        unpacked_dirs = realloc(unpacked_dirs, sizeof(char*) * unpacked_capacity);
                    }
                    unpacked_dirs[unpacked_count++] = strdup(temp_dir);
                }
                
                /* Use the unpacked .nano file path for module list */
                if (temp_dir[0] != '\0') {
                    char unpacked_nano[1024];
                    snprintf(unpacked_nano, sizeof(unpacked_nano), "%s/module.nano", temp_dir);
                    free(module_path);
                    module_path = strdup(unpacked_nano);
                }
            } else {
                /* Regular .nano file */
                FILE *test = fopen(module_path, "r");
                if (!test) {
                    fprintf(stderr, "Error at line %d, column %d: Module file '%s' not found\n",
                            item->line, item->column, module_path);
                    free(module_path);
                    /* Cleanup unpacked directories */
                    for (int j = 0; j < unpacked_count; j++) {
                        free(unpacked_dirs[j]);
                    }
                    free(unpacked_dirs);
                    return false;
                }
                fclose(test);

                /* Load module and track transitive imports for compilation */
                module_ast = load_module_internal(module_path, env, true, modules);
            }
            
            /* I return an AST for a completed cached load. A NULL AST is a
             * failure, even when a loading marker remains in the cache. */
            if (module_ast == NULL) {
                fprintf(stderr, "Error at line %d, column %d: Failed to load module '%s'\n",
                        item->line, item->column, module_path);
                free(module_path);
                /* Cleanup unpacked directories */
                for (int j = 0; j < unpacked_count; j++) {
                    free(unpacked_dirs[j]);
                }
                free(unpacked_dirs);
                return false;
            }
            
            /* Add to module list (even if already cached) */
            if (modules) {
                module_list_add(modules, module_path);
            }

            if (env->service_origin_count > 0) {
                free(module_path);
                continue;
            }

            /* If module was already cached and returned NULL, try to grab cached AST for alias handling */
            if (module_ast == NULL) {
                module_ast = get_cached_module_ast(module_path);
                if (!module_ast) {
                    free(module_path);
                    continue;
                }
            }
            
            char *orig_module_name = NULL;
            for (int j = 0; j < module_ast->as.program.count; j++) {
                ASTNode *node = module_ast->as.program.items[j];
                if (node->type == AST_MODULE_DECL && !orig_module_name) {
                    orig_module_name = node->as.module_decl.name;
                }
            }
            
            /* Register namespace if module has an alias */
            if (module_alias) {
                /* Extract function names, struct names, enum names, union names from module */
                /* Count them first */
                int func_count = 0, struct_count = 0, enum_count = 0, union_count = 0;
                for (int j = 0; j < module_ast->as.program.count; j++) {
                    ASTNode *node = module_ast->as.program.items[j];
                    if (node->type == AST_FUNCTION) func_count++;
                    else if (node->type == AST_STRUCT_DEF) struct_count++;
                    else if (node->type == AST_ENUM_DEF) enum_count++;
                    else if (node->type == AST_UNION_DEF) union_count++;
                }
                
                /* Allocate arrays */
                char **func_names = malloc(sizeof(char*) * (func_count > 0 ? func_count : 1));
                char **struct_names = malloc(sizeof(char*) * (struct_count > 0 ? struct_count : 1));
                char **enum_names = malloc(sizeof(char*) * (enum_count > 0 ? enum_count : 1));
                char **union_names = malloc(sizeof(char*) * (union_count > 0 ? union_count : 1));
                
                /* Fill arrays */
                int f_idx = 0, s_idx = 0, e_idx = 0, u_idx = 0;
                for (int j = 0; j < module_ast->as.program.count; j++) {
                    ASTNode *node = module_ast->as.program.items[j];
                    if (node->type == AST_FUNCTION) {
                        func_names[f_idx++] = strdup(node->as.function.name);
                    } else if (node->type == AST_STRUCT_DEF) {
                        struct_names[s_idx++] = strdup(node->as.struct_def.original_name ? node->as.struct_def.original_name : node->as.struct_def.name);
                    } else if (node->type == AST_ENUM_DEF) {
                        enum_names[e_idx++] = strdup(node->as.enum_def.original_name ? node->as.enum_def.original_name : node->as.enum_def.name);
                    } else if (node->type == AST_UNION_DEF) {
                        union_names[u_idx++] = strdup(node->as.union_def.original_name ? node->as.union_def.original_name : node->as.union_def.name);
                    }
                }
                
                /* Register the namespace */
                char *inferred_name = orig_module_name ? NULL : module_name_from_path(module_path);
                env_register_namespace(env, module_alias, orig_module_name ? orig_module_name : inferred_name,
                                      func_names, func_count,
                                      struct_names, struct_count,
                                      enum_names, enum_count,
                                      union_names, union_count);
                free(inferred_name);
            }

            /* I bind effects only into the importing module's namespace. */
            char *effect_owner = orig_module_name ? strdup(orig_module_name) : module_name_from_path(module_path);
            for (int e = 0; e < module_ast->as.program.count; ++e) {
                ASTNode *declaration = module_ast->as.program.items[e];
                if (declaration->type != AST_EFFECT_DECL) continue;
                const char *name = declaration->as.effect_decl.effect_name;
                EffectDef *target = env_get_effect_owned(env, name, effect_owner);
                if (!target) continue;
                if (item->as.import_stmt.is_selective && !item->as.import_stmt.is_wildcard) {
                    for (int selected = 0; selected < item->as.import_stmt.import_symbol_count; ++selected) {
                        if (strcmp(item->as.import_stmt.import_symbols[selected], name)) continue;
                        const char *alias = item->as.import_stmt.import_aliases ? item->as.import_stmt.import_aliases[selected] : NULL;
                        if (!env_import_effect(env, alias && *alias ? alias : name, target)) {
                            fprintf(stderr, "I cannot bind a private or conflicting effect import: %s\n", name);
                            free(effect_owner); free(module_path); return false;
                        }
                    }
                } else if (target->is_pub) {
                    size_t length = (module_alias ? strlen(module_alias) + 1 : 0) + strlen(name) + 1;
                    char *qualified = malloc(length);
                    if (!qualified) { free(effect_owner); free(module_path); return false; }
                    snprintf(qualified, length, "%s%s%s", module_alias ? module_alias : "", module_alias ? "." : "", name);
                    bool bound = env_import_effect(env, qualified, target);
                    free(qualified);
                    if (!bound) {
                        fprintf(stderr, "I cannot bind a conflicting effect import: %s\n", name);
                        free(effect_owner); free(module_path); return false;
                    }
                }
            }
            free(effect_owner);

            /* I retain public imports and the legacy plain-import immutable constant contract. */
            for (int g = 0; g < module_ast->as.program.count; ++g) {
                ASTNode *global = module_ast->as.program.items[g];
                if (global->type != AST_LET) continue;
                bool legacy_constant = !module_alias && !item->as.import_stmt.is_selective && !global->as.let.is_mut;
                if (!global->as.let.is_pub && !legacy_constant) continue;
                const char *name = global->as.let.name;
                if (item->as.import_stmt.is_selective && !item->as.import_stmt.is_wildcard) {
                    for (int selected = 0; selected < item->as.import_stmt.import_symbol_count; ++selected) {
                        if (strcmp(item->as.import_stmt.import_symbols[selected], name)) continue;
                        const char *alias = item->as.import_stmt.import_aliases ? item->as.import_stmt.import_aliases[selected] : NULL;
                        if (!env_import_global(env, current_file, alias && *alias ? alias : name, global)) {
                            fprintf(stderr, "I cannot bind a conflicting public global import.\n");
                            free(module_path);
                            return false;
                        }
                    }
                } else {
                    size_t length = (module_alias ? strlen(module_alias) + 1 : 0) + strlen(name) + 1;
                    char *qualified = malloc(length);
                    if (!qualified) { free(module_path); return false; }
                    snprintf(qualified, length, "%s%s%s", module_alias ? module_alias : "", module_alias ? "." : "", name);
                    bool bound = env_import_global(env, current_file, qualified, global);
                    /* I preserve legacy literal folding without copying the binding into another scope. */
                    Symbol *constant = bound && legacy_constant ? env_global_import_symbol_at(env, current_file, qualified) : NULL;
                    ASTNode *value = global->as.let.value;
                    if (constant && constant->value.type == VAL_VOID && value) {
                        if (value->type == AST_NUMBER) constant->value = create_int(value->as.number);
                        else if (value->type == AST_FLOAT) constant->value = create_float(value->as.float_val);
                        else if (value->type == AST_BOOL) constant->value = create_bool(value->as.bool_val);
                        else if (value->type == AST_STRING) constant->value = create_string(value->as.string_val);
                    }
                    free(qualified);
                    if (!bound) { fprintf(stderr, "I cannot bind a conflicting public global import.\n"); free(module_path); return false; }
                }
            }

            /* Apply import aliases for selective imports: from "module" import foo as bar */
            if (item->as.import_stmt.is_selective &&
                item->as.import_stmt.import_symbols &&
                item->as.import_stmt.import_symbol_count > 0) {
                char *module_name_for_alias = NULL;
                if (orig_module_name) {
                    module_name_for_alias = strdup(orig_module_name);
                } else {
                    module_name_for_alias = module_name_from_path(module_path);
                }
                
                for (int j = 0; j < item->as.import_stmt.import_symbol_count; j++) {
                    const char *symbol = item->as.import_stmt.import_symbols[j];
                    const char *alias = item->as.import_stmt.import_aliases
                        ? item->as.import_stmt.import_aliases[j]
                        : NULL;
                    
                    if (!alias || alias[0] == '\0' || strcmp(alias, symbol) == 0) {
                        continue;
                    }
                    
                    EffectDef *effect_alias = env_get_effect_owned(env, symbol, module_name_for_alias);
                    if (effect_alias && effect_alias->is_pub) continue;

                    if (env_get_function(env, alias)) {
                        fprintf(stderr, "Error at line %d, column %d: Import alias '%s' conflicts with existing function\n",
                                item->line, item->column, alias);
                        free(module_name_for_alias);
                        free(module_path);
                        for (int k = 0; k < unpacked_count; k++) {
                            free(unpacked_dirs[k]);
                        }
                        free(unpacked_dirs);
                        return false;
                    }
                    
                    bool enum_alias = false;
                    for (int e = 0; e < env->enum_count; ++e) {
                        EnumDef *definition = &env->enums[e];
                        const char *source_name = definition->original_name ? definition->original_name : definition->name;
                        if (!definition->is_pub || !definition->module_name ||
                            strcmp(definition->module_name, module_name_for_alias) || strcmp(source_name, symbol)) continue;
                        if (!env_import_enum(env, alias, definition)) {
                            fprintf(stderr, "I cannot bind conflicting enum import alias: %s\n", alias);
                            free(module_name_for_alias); free(module_path);
                            for (int k = 0; k < unpacked_count; ++k) free(unpacked_dirs[k]);
                            free(unpacked_dirs); return false;
                        }
                        enum_alias = true; break;
                    }
                    if (enum_alias) continue;

                    Function *func = find_module_function(env, module_name_for_alias, symbol);
                    if (!func && env_lookup_global_import_at(env, current_file, alias)) continue;
                    if (!func) {
                        fprintf(stderr, "Error at line %d, column %d: Symbol '%s' not found in module for alias '%s'\n",
                                item->line, item->column, symbol, alias);
                        free(module_name_for_alias);
                        free(module_path);
                        for (int k = 0; k < unpacked_count; k++) {
                            free(unpacked_dirs[k]);
                        }
                        free(unpacked_dirs);
                        return false;
                    }
                    
                    Function alias_func = *func;
                    alias_func.name = strdup(alias);
                    const char *orig_name = func->alias_of ? func->alias_of : func->name;
                    alias_func.alias_of = orig_name ? strdup(orig_name) : NULL;
                    env_define_function(env, alias_func);
                }
                
                if (module_name_for_alias) {
                    free(module_name_for_alias);
                }
            }
            
            /* Execute module definitions (functions, structs, etc.) */
            /* This makes module symbols available in the current environment */
            for (int j = 0; j < module_ast->as.program.count; j++) {
                ASTNode *module_item = module_ast->as.program.items[j];
                
                /* Skip imports, shadows, and executable statements in modules */
                if (module_item->type == AST_IMPORT || 
                    module_item->type == AST_SHADOW ||
                    module_item->type == AST_LET ||
                    module_item->type == AST_SET ||
                    module_item->type == AST_IF ||
                    module_item->type == AST_WHILE ||
                    module_item->type == AST_FOR ||
                    module_item->type == AST_RETURN ||
                    module_item->type == AST_PRINT ||
                    module_item->type == AST_ASSERT) {
                    continue;
                }
                
                /* Functions, structs, enums, unions are already registered during type_check */
            }
            
            free(module_path);
            /* Note: We don't free module_ast here - it's kept in memory for interpreter */
            /* For compiler, we'll track modules separately */
        }
    }
    
    /* Note: Unpacked directories are tracked but not cleaned up here */
    /* They will be cleaned up when the program exits or by the caller */
    /* For interpreter: cleaned up at end of session */
    /* For compiler: cleaned up after compilation */
    free(unpacked_dirs);
    
    return true;
}

/* Compile a single module to an object file */

static bool compile_module_object(const char *module_path,
                              const char *output_obj,
                              Environment *env,
                              bool verbose,
                              char **extra_compile_flags,
                              size_t extra_compile_flags_count,
                              ModuleBuildInfo **dependencies, size_t dependency_count) {
    if (!module_path || !output_obj) return false;

    /* env is intentionally unused: module compilation is done in an isolated environment */
    (void)env;

    /* Module loading uses a global cache. Compile module objects with a fresh
     * cache, but restore the caller's cache afterward (needed for transpilation
     * and forward declarations in the main compilation).
     */
    ModuleCache *saved_cache = module_cache;
    module_cache = NULL;

    /*
     * IMPORTANT:
     * Module objects must be compiled in an isolated environment so that the
     * generated C does not accidentally include types/externs from the top-level
     * program (e.g. SDL externs leaking into stdlib objects).
     */
    Environment *module_env = create_environment();
    if (!module_env) {
        fprintf(stderr, "Error: Failed to create environment for module compilation\n");
        module_cache = saved_cache;
        return false;
    }
    module_env->emit_module_metadata = false;
    module_env->emit_c_main = false;

    /* Use a fresh module cache per module compilation to avoid cross-env AST reuse */

    ASTNode *module_ast = load_module_internal(module_path, module_env, true, NULL);
    if (!module_ast) {
        fprintf(stderr, "Error: Failed to load module '%s' for compilation\n", module_path);
        clear_module_cache();
        module_cache = saved_cache;
        free_environment(module_env);
        return false;
    }
    
    /* Extract module metadata before transpiling */
    const char *last_slash = strrchr(module_path, '/');
    const char *base_name = last_slash ? last_slash + 1 : module_path;
    char module_name[256];
    snprintf(module_name, sizeof(module_name), "%s", base_name);
    char *dot = strrchr(module_name, '.');
    if (dot) *dot = '\0';
    
    /* Extract module metadata from the isolated module environment. */
    ModuleMetadata *meta = extract_module_metadata(module_env, module_name);
    
    /*
     * Transpile module to C.
     *
     * IMPORTANT: We reuse the shared Environment to avoid module reload/AST corruption,
     * but that environment may contain a program-level `main` from the top-level compile.
     * When generating a module object, we must NOT emit a C main() wrapper.
     */
    Function *saved_main = env_get_function(module_env, "main");
    bool saved_main_is_extern = false;
    if (saved_main) {
        saved_main_is_extern = saved_main->is_extern;
        saved_main->is_extern = true;
    }

    char *saved_module_context = module_env->current_module;
    module_env->current_module = module_name;
    for (int i = 0; i < module_ast->as.program.count; i++) {
        ASTNode *item = module_ast->as.program.items[i];
        if (item->type == AST_MODULE_DECL && item->as.module_decl.name)
            module_env->current_module = item->as.module_decl.name;
    }
    const char *saved_source_file = env_current_file(module_env);
    env_set_current_file(module_env, module_path);
    char *c_code = transpile_to_c(module_ast, module_env, module_path);
    env_set_current_file(module_env, saved_source_file);
    module_env->current_module = saved_module_context;

    if (saved_main) {
        saved_main->is_extern = saved_main_is_extern;
    }
    if (!c_code) {
        fprintf(stderr, "Error: Failed to transpile module '%s'\n", module_path);
        if (meta) free_module_metadata(meta);
        clear_module_cache();
        module_cache = saved_cache;
        free_environment(module_env);
        return false;
    }
    
    /* I keep source identity separate from the module's reported public name. */
    if (meta) {
        size_t code_size = safe_strlen(c_code);
        bool embedded = false;
        char *metadata_c = serialize_module_metadata_for_source(meta, module_path);
        if (metadata_c) {
            size_t metadata_size = safe_strlen(metadata_c);
            if (code_size <= SIZE_MAX - metadata_size - 1) {
                char *combined = realloc(c_code, code_size + metadata_size + 1);
                if (combined) {
                    c_code = combined;
                    memcpy(c_code + code_size, metadata_c, metadata_size + 1);
                    embedded = true;
                }
            }
            free(metadata_c);
        }
        if (!embedded) {
            fprintf(stderr, "I cannot retain source-identified module metadata\n");
            free(c_code); free_module_metadata(meta);
            clear_module_cache(); module_cache = saved_cache;
            free_environment(module_env);
            return false;
        }
    }
    if (meta) {
        free_module_metadata(meta);
    }
    
    /* Private siblings keep concurrent builds separate and rename on the same
     * filesystem. A failed compiler must not truncate a published object. */
    char build_dir[1024];
    /* I keep user-controlled basenames out of the compiler's __FILE__ path.
     * Quotes and control characters are valid source filename bytes, but GCC
     * can mis-expand them when an assert references generated source. Only
     * the private stem changes: publication still renames beside output_obj. */
    const char *output_slash = strrchr(output_obj, '/');
    size_t parent_length = output_slash ? (size_t)(output_slash - output_obj) + 1 : 0;
    int path_length = parent_length < sizeof(build_dir)
        ? snprintf(build_dir, sizeof(build_dir), "%.*s.nano-module-XXXXXX",
                   (int)parent_length, output_obj) : -1;
    bool have_build_dir = path_length >= 0 && (size_t)path_length < sizeof(build_dir) &&
                          mkdtemp(build_dir) != NULL;
    char temp_c_file[1040] = "";
    char temp_obj_file[1040] = "";
    if (have_build_dir) {
        snprintf(temp_c_file, sizeof(temp_c_file), "%s/source.c", build_dir);
        snprintf(temp_obj_file, sizeof(temp_obj_file), "%s/object.o", build_dir);
    }
    FILE *c_file = have_build_dir ? fopen(temp_c_file, "w") : NULL;
    if (!c_file) {
        fprintf(stderr, "I could not create private module source for '%s'.\n", output_obj);
        if (have_build_dir) rmdir(build_dir);
        free(c_code);
        /* Don't free AST - it's owned by the cache */
        clear_module_cache();
        module_cache = saved_cache;
        free_environment(module_env);
        return false;
    }
    
    bool source_written = fputs(c_code, c_file) >= 0;
    if (fclose(c_file) != 0) source_written = false;
    if (!source_written) {
        fprintf(stderr, "I could not finish writing module source '%s'.\n", temp_c_file);
        remove(temp_c_file);
        rmdir(build_dir);
        free(c_code);
        clear_module_cache();
        module_cache = saved_cache;
        free_environment(module_env);
        return false;
    }
    
    if (verbose) {
        printf("✓ Generated module C code: %s\n", temp_c_file);
    }

    /* Ensure any generic list headers needed by this module exist before compilation.
     * (The top-level compilation generates list runtimes later, but module objects
     * must be able to include the headers during their own cc -c step.)
     */
    {
        const char *scan_ptr = c_code;
        char detected_types[64][64];
        int detected_count = 0;

        while ((scan_ptr = strstr(scan_ptr, "List_")) != NULL) {
            scan_ptr += 5;
            const char *end_ptr = scan_ptr;

            while ((*end_ptr >= 'A' && *end_ptr <= 'Z') ||
                   (*end_ptr >= 'a' && *end_ptr <= 'z') ||
                   (*end_ptr >= '0' && *end_ptr <= '9') ||
                   *end_ptr == '_') {
                end_ptr++;
            }

            if (*end_ptr == '*' || *end_ptr == ' ' || *end_ptr == '\n') {
                int len = (int)(end_ptr - scan_ptr);
                if (len <= 0 || len >= 63) continue;

                char type_name[64];
                strncpy(type_name, scan_ptr, (size_t)len);
                type_name[len] = '\0';

                if (strcmp(type_name, "int") == 0 ||
                    strcmp(type_name, "string") == 0 ||
                    strcmp(type_name, "token") == 0) {
                    continue;
                }

                bool already_detected = false;
                for (int i = 0; i < detected_count; i++) {
                    if (strcmp(detected_types[i], type_name) == 0) {
                        already_detected = true;
                        break;
                    }
                }

                if (!already_detected && detected_count < 64) {
                    snprintf(detected_types[detected_count], 64, "%s", type_name);
                    detected_count++;

                    const char *c_type = type_name;
                    if (strcmp(type_name, "LexerToken") == 0) c_type = "Token";
                    else if (strcmp(type_name, "NSType") == 0) c_type = "NSType";

                    char gen_cmd[512];
                    snprintf(gen_cmd, sizeof(gen_cmd),
                             "./scripts/generate_list.sh %s /tmp %s > /dev/null 2>&1",
                             type_name, c_type);
                    if (verbose) {
                        printf("[Modules] Generating List<%s> runtime...\n", type_name);
                    }
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-result"
                    system(gen_cmd);
#pragma GCC diagnostic pop
                }
            }
        }
    }

    /* Compile C code to object file */
    /* Note: Runtime files are linked separately, not compiled into module objects */
    /* Add SDL flags if SDL modules are used */
    char sdl_flags[256] = "";
    FILE *sdl_check = popen("sdl2-config --cflags 2>/dev/null", "r");
    if (sdl_check) {
        if (!fgets(sdl_flags, sizeof(sdl_flags), sdl_check)) sdl_flags[0] = '\0';
        pclose(sdl_check);
        /* Remove trailing newline */
        char *newline = strchr(sdl_flags, '\n');
        if (newline) *newline = '\0';
    }
    
    const char *cc = getenv("NANO_CC");
    if (!cc) cc = getenv("CC");
    if (!cc) cc = "cc";

    char compile_cmd[4096];
    char inherited_flags[2048] = "";
    bool arguments_valid = true;
    const char *root = get_project_root();

    /* I inherit flags only from this isolated module's actual import closure. */
    ModuleBuildInfo **selected = dependency_count ? calloc(dependency_count, sizeof *selected) : NULL;
    size_t selected_count = 0, import_flag_count = 0;
    if (dependency_count && !selected) arguments_valid = false;
    for (size_t i = 0; selected && i < dependency_count; ++i) {
        const char *directory = dependencies[i]->module_dir;
        if (!directory) continue;
        for (int j = 0; module_cache && j < module_cache->count; ++j) {
            const char *path = module_cache->loaded_paths[j];
            const char *slash = strrchr(path, '/');
            if (slash && strlen(directory) == (size_t)(slash - path) &&
                !strncmp(path, directory, (size_t)(slash - path))) {
                selected[selected_count++] = dependencies[i];
                break;
            }
        }
    }
    char **import_flags = module_get_compile_flags(selected, selected_count, &import_flag_count);
    if (!import_flags)
        for (size_t i = 0; i < selected_count; ++i)
            if (selected[i]->compile_flags_count) arguments_valid = false;
    free(selected);
    for (int group = 0; group < 2; ++group) {
        char **flags = group ? import_flags : extra_compile_flags;
        size_t count = group ? import_flag_count : extra_compile_flags_count;
        for (size_t i = 0; i < count; ++i) {
            if (!flags || !flags[i] || !flags[i][0]) continue;
            if (strlen(inherited_flags) + strlen(flags[i]) + 2 < sizeof inherited_flags) {
                if (inherited_flags[0]) strcat(inherited_flags, " ");
                strcat(inherited_flags, flags[i]);
            } else arguments_valid = false;
        }
    }
    for (size_t i = 0; i < import_flag_count; ++i) free(import_flags[i]);
    free(import_flags);

    /* Extract the module's own directory for -I path (so it can find its own headers) */
    char module_dir[512] = "";
    {
        /* Use realpath to resolve relative paths (e.g. ../modules/examples/runner.nano
         * invoked from a subdirectory) to an absolute directory. Fallback to the
         * root-relative heuristic if realpath fails (e.g. file not yet on disk). */
        char abs_module_path[4096];
        const char *resolved = realpath(module_path, abs_module_path);
        const char *path_to_use = resolved ? abs_module_path : module_path;
        char *mp_copy = strdup(path_to_use);
        if (!mp_copy) arguments_valid = false;
        char *last_slash = mp_copy ? strrchr(mp_copy, '/') : NULL;
        if (last_slash) {
            *last_slash = '\0';
            int written = mp_copy[0] == '/' ?
                snprintf(module_dir, sizeof(module_dir), "-I%s", mp_copy) :
                snprintf(module_dir, sizeof(module_dir), "-I%s/%s", root, mp_copy);
            if (written < 0 || (size_t)written >= sizeof(module_dir)) arguments_valid = false;
        }
        free(mp_copy);
    }

    char *quoted_root = module_quote_path(root);
    char *quoted_module = module_dir[0] ? module_quote_path(module_dir) : strdup("");
    char *quoted_object = module_quote_path(temp_obj_file);
    char *quoted_source = module_quote_path(temp_c_file);
    arguments_valid = arguments_valid && quoted_root && quoted_module && quoted_object && quoted_source;
    compile_cmd[0] = '\0';
    int command_length = arguments_valid ? snprintf(compile_cmd, sizeof(compile_cmd),
            "%s -std=c99 -I%s/src -I%s/modules/std -I%s/modules/std/collections -I%s/modules/std/json -I%s/modules/std/io -I%s/modules/std/math -I%s/modules/std/peg -I%s/modules/std/string -I%s/modules/sdl_helpers %s %s %s -c -o %s %s",
            cc, quoted_root, quoted_root, quoted_root, quoted_root, quoted_root,
            quoted_root, quoted_root, quoted_root, quoted_root,
            quoted_module, sdl_flags, inherited_flags, quoted_object, quoted_source) : -1;
    free(quoted_root);
    free(quoted_module);
    free(quoted_object);
    free(quoted_source);
    
    if (verbose) {
        printf("Compiling module: %s\n", compile_cmd);
    }
    
    /* Compile and capture errors */
    char error_cmd[sizeof(compile_cmd) + sizeof(" 2>&1")];
    snprintf(error_cmd, sizeof(error_cmd), "%s 2>&1", compile_cmd);
    FILE *pipe = command_length >= 0 && (size_t)command_length < sizeof(compile_cmd) ?
                 popen(error_cmd, "r") : NULL;
    char error_output[4096] = {0};
    if (command_length < 0 || (size_t)command_length >= sizeof(compile_cmd))
        snprintf(error_output, sizeof(error_output), "I could not represent all module compiler arguments.");
    int result = -1;
    if (pipe) {
        /* I retain a bounded diagnostic prefix but drain the entire pipe so
         * a verbose child cannot block while I wait for its exit status. */
        char chunk[4096];
        size_t retained = 0;
        size_t bytes_read;
        while ((bytes_read = fread(chunk, 1, sizeof(chunk), pipe)) > 0) {
            size_t available = sizeof(error_output) - 1 - retained;
            size_t copied = bytes_read < available ? bytes_read : available;
            memcpy(error_output + retained, chunk, copied);
            retained += copied;
        }
        error_output[retained] = '\0';
        bool read_failed = ferror(pipe) != 0;
        result = pclose(pipe);
        if (read_failed) result = -1;
    }
    if (result == 0 && rename(temp_obj_file, output_obj) != 0) {
        snprintf(error_output, sizeof(error_output),
                 "I could not publish the module object: %s", strerror(errno));
        result = -1;
    }
    
    if (result != 0) {
        remove(temp_obj_file);
        fprintf(stderr, "Error: Failed to compile module '%s' to object file\n", module_path);
        assert(error_output != NULL);
        if (safe_strlen(error_output) > 0) {
            fprintf(stderr, "Compilation errors:\n%s\n", error_output);
        }
        /* Keep C file for debugging */
        fprintf(stderr, "C file kept at: %s\n", temp_c_file);
        free(c_code);
        clear_module_cache();
        module_cache = saved_cache;
        /* Don't free AST or environment - they're owned by the cache/caller */
        free_environment(module_env);
        return false;
    }
    
    /* Clean up temporary C file */
    if (!verbose) {
        remove(temp_c_file);
        rmdir(build_dir);
    } else {
        printf("✓ Compiled module to object file: %s\n", output_obj);
        printf("  C source kept at: %s\n", temp_c_file);
    }
    
    free(c_code);
    clear_module_cache();
    module_cache = saved_cache;
    /* Don't free AST or environment - they're owned by the cache/caller */
    free_environment(module_env);
    return true;
}

bool compile_module_to_object(const char *module_path, const char *output_obj,
                              Environment *env, bool verbose,
                              char **extra_compile_flags, size_t extra_compile_flags_count) {
    return compile_module_object(module_path, output_obj, env, verbose,
                                 extra_compile_flags, extra_compile_flags_count, NULL, 0);
}

/* Check if a module is FFI-only (only extern declarations, no implementation) */
/* I share parsed source facts with native initialization; globals require storage. */
bool module_is_ffi_only(const char *module_path) {
    ASTNode *program = get_cached_module_ast(module_path);
    if (!program || program->type != AST_PROGRAM) return false;
    bool has_extern = false;
    for (int i = 0; i < program->as.program.count; ++i) {
        ASTNode *item = program->as.program.items[i];
        if (item->type == AST_FUNCTION && item->as.function.is_extern) {
            has_extern = true;
        } else if (item->type != AST_MODULE_DECL && item->type != AST_OPAQUE_TYPE) {
            return false;
        }
    }
    return has_extern;
}

/* Helper: Extract module directory from module path */
static char* get_module_dir(const char *module_path) {
    char *dir = strdup(module_path);
    char *last_slash = strrchr(dir, '/');
    if (last_slash) {
        *last_slash = '\0';
    } else {
        free(dir);
        dir = strdup(".");
    }
    return dir;
}

/* I keep equal basenames in different canonical module-directory namespaces. */
static bool native_module_object_path(const char *module_dir, const char *base,
                                      char *destination, size_t size) {
    char directory[256];
    if (!nano_module_build_dir_at(module_dir, "obj/nano_modules", directory, sizeof directory) ||
        (mkdir("obj", 0777) != 0 && errno != EEXIST) ||
        (mkdir("obj/nano_modules", 0777) != 0 && errno != EEXIST) ||
        (mkdir(directory, 0777) != 0 && errno != EEXIST)) {
        fprintf(stderr, "I cannot prepare the native module object directory\n");
        return false;
    }
    int length = snprintf(destination, size, "%s/nanolang_%s.o", directory, base);
    if (length < 0 || (size_t)length >= size) {
        fprintf(stderr, "I cannot represent the native module object path\n");
        return false;
    }
    return true;
}

/* Compile all modules in the list to object files using the module builder */
bool compile_modules(ModuleList *modules, Environment *env, char **module_objs_buffer, char *compile_flags_buffer, size_t compile_flags_buffer_size, bool verbose) {
    if (!modules || !module_objs_buffer) {
        return false;
    }
    
    /* Initialize buffers */
    *module_objs_buffer = NULL;
    if (compile_flags_buffer && compile_flags_buffer_size > 0) {
        compile_flags_buffer[0] = '\0';
    }
    
    if (modules->count == 0) {
        return true;  /* No modules to compile */
    }
    
    /* Check for verbose build flag */
    if (getenv("NANO_VERBOSE_BUILD")) {
        verbose = true;
        module_builder_verbose = true;
    }
    
    if (verbose) {
        printf("[Modules] Processing %d module(s)...\n", modules->count);
    }
    
    /* Create module builder */
    const char *module_path_env = getenv("NANO_MODULE_PATH");
    ModuleBuilder *builder = module_builder_new(module_path_env);
    if (!builder) {
        fprintf(stderr, "Error: Failed to create module builder\n");
        return false;
    }
    
    /* Track all build info for cleanup */
    ModuleBuildInfo **build_infos = calloc(modules->count, sizeof(ModuleBuildInfo*));
    int build_info_count = 0;
    
    int nanolang_compiled = 0;
    int c_modules_built = 0;
    int ffi_only = 0;
    
    for (int i = 0; i < modules->count; i++) {
        const char *module_path = modules->module_paths[i];
        
        /* Get module directory */
        char *module_dir = get_module_dir(module_path);
        
        /* Check if module has module.json (C sources) */
        ModuleBuildMetadata *meta = module_load_metadata(module_dir);
        
        if (meta) {
            /* Module has C sources - use module builder */
            if (verbose) {
                printf("[Modules] Building C module '%s' (%s)\n", meta->name, module_dir);
            }
            
            /* I pin one generation per physical foreign module for this link.
             * Different .nano files in that directory still compile separately. */
            ModuleBuildInfo *info = NULL;
            char *physical_dir = realpath(meta->module_dir, NULL);
            for (int j = 0; physical_dir && j < build_info_count; j++) {
                if (build_infos[j]->module_dir &&
                    strcmp(build_infos[j]->module_dir, physical_dir) == 0) {
                    info = build_infos[j];
                    break;
                }
            }
            free(physical_dir);
            if (!info) {
                info = module_build_native(builder, meta);
                if (info) {
                    build_infos[build_info_count++] = info;
                    c_modules_built++;
                }
            }
            if (!info) {
                fprintf(stderr, "Error: Failed to build module '%s'\n", meta->name);
                module_metadata_free(meta);
                free(module_dir);
                module_builder_free(builder);
                for (int j = 0; j < build_info_count; j++) {
                    module_build_info_free(build_infos[j]);
                }
                free(build_infos);
                return false;
            }
            
            /* 
             * IMPORTANT: If the module ALSO has a .nano file with implementations 
             * (not just externs), we must compile it too!
             */
            if (!module_is_ffi_only(module_path)) {
                if (verbose) {
                    printf("[Modules] Also compiling nanolang parts of C module '%s'\n", meta->name);
                }

                /*
                 * IMPORTANT:
                 * A single C-backed module directory (e.g. modules/std/) can contain multiple
                 * NanoLang source files that may be imported independently (env.nano, fs.nano,
                 * binary.nano, etc).
                 *
                 * If we always emit to obj/nano_modules/<module>_nano.o, later imports overwrite
                 * earlier ones and we end up linking only the last compiled Nano object, causing
                 * undefined references on strict linkers (Linux CI).
                 */

                const char *last_slash = strrchr(module_path, '/');
                const char *base_name = last_slash ? last_slash + 1 : module_path;

                char base_without_ext[256];
                snprintf(base_without_ext, sizeof(base_without_ext), "%s", base_name);
                char *dot = strrchr(base_without_ext, '.');
                if (dot && strcmp(dot, ".nano") == 0) {
                    *dot = '\0';
                }

                char nano_obj[2048];
                
                if (!native_module_object_path(module_dir, base_without_ext, nano_obj, sizeof nano_obj) ||
                    !compile_module_object(module_path, nano_obj, env, verbose, info->compile_flags, info->compile_flags_count, build_infos, (size_t)build_info_count)) {
                    fprintf(stderr, "Error: Failed to compile nanolang parts of module '%s'\n", meta->name);
                    module_metadata_free(meta);
                    free(module_dir);
                    module_builder_free(builder);
                    for (int j = 0; j < build_info_count; j++) {
                        module_build_info_free(build_infos[j]);
                    }
                    free(build_infos);
                    return false;
                }
                
                if (!module_append_unique_object(module_objs_buffer, nano_obj)) {
                    fprintf(stderr, "I could not represent all module object paths.\n");
                    module_metadata_free(meta);
                    free(module_dir);
                    module_builder_free(builder);
                    for (int j = 0; j < build_info_count; j++) module_build_info_free(build_infos[j]);
                    free(build_infos);
                    return false;
                }
            }
            
            module_metadata_free(meta);
        } else {
            /* No module.json - check if it's FFI-only (just extern declarations) */
            if (module_is_ffi_only(module_path)) {
                if (verbose) {
                    printf("[Modules] Skipping FFI-only module '%s'\n", module_path);
                }
                ffi_only++;
                free(module_dir);
                continue;
            }
            
            /* Pure nanolang module - compile using existing method */
            if (verbose) {
                printf("[Modules] Compiling nanolang module '%s'\n", module_path);
            }
            
            /* Generate object file name from module path */
            char obj_file[2048];
            const char *last_slash = strrchr(module_path, '/');
            const char *base_name = last_slash ? last_slash + 1 : module_path;
            
            /* Remove .nano extension */
            char base_without_ext[256];
            snprintf(base_without_ext, sizeof(base_without_ext), "%s", base_name);
            char *dot = strrchr(base_without_ext, '.');
            if (dot && strcmp(dot, ".nano") == 0) {
                *dot = '\0';
            }
            
            /*
             * IMPORTANT:
             * Keep NanoLang-compiled module objects separate from C-compiled objects.
             * The C reference compiler builds src/lexer.c -> obj/lexer.o, etc.
             * If we also emit modules to obj/<name>.o (e.g. lexer.nano -> obj/lexer.o),
             * we can clobber C objects and break linking.
             */



            /* Compile module to object file */
            if (!native_module_object_path(module_dir, base_without_ext, obj_file, sizeof obj_file) ||
                !compile_module_object(module_path, obj_file, env, verbose, NULL, 0, build_infos, (size_t)build_info_count)) {
                fprintf(stderr, "Error: Failed to compile module '%s'\n", module_path);
                free(module_dir);
                module_builder_free(builder);
                for (int j = 0; j < build_info_count; j++) {
                    module_build_info_free(build_infos[j]);
                }
                free(build_infos);
                return false;
            }
            
            nanolang_compiled++;
            
            if (!module_append_unique_object(module_objs_buffer, obj_file)) {
                fprintf(stderr, "I could not represent all module object paths.\n");
                free(module_dir);
                module_builder_free(builder);
                for (int j = 0; j < build_info_count; j++) module_build_info_free(build_infos[j]);
                free(build_infos);
                return false;
            }
        }
        
        free(module_dir);
    }
    
    /* Get all link flags from C modules */
    size_t link_flags_count = 0;
    char **link_flags = module_get_link_flags(build_infos, build_info_count, &link_flags_count);
    
    /* Add link flags to buffer */
    if (link_flags) {
        for (size_t i = 0; i < link_flags_count; i++) {
            // Skip NULL or empty flags
            if (!link_flags[i] || link_flags[i][0] == '\0') {
                free(link_flags[i]);
                continue;
            }

            // Skip direct .tbd inputs (macOS text stubs) to avoid linker warnings
            size_t flag_len = strlen(link_flags[i]);
            if (flag_len > 4 && strcmp(link_flags[i] + flag_len - 4, ".tbd") == 0) {
                if (verbose) {
                    fprintf(stderr, "[Modules] Warning: Skipping direct .tbd link input %s\n", link_flags[i]);
                }
                free(link_flags[i]);
                continue;
            }
            
            // Validate flag is printable ASCII (no UTF-8 or binary garbage)
            bool valid = true;
            for (const char *p = link_flags[i]; *p; p++) {
                if ((unsigned char)*p < 32 || (unsigned char)*p > 126) {
                    // Non-printable or non-ASCII character found
                    if (verbose) {
                        fprintf(stderr, "[Modules] Warning: Skipping invalid link flag with non-ASCII character (byte 0x%02x)\n", (unsigned char)*p);
                    }
                    valid = false;
                    break;
                }
            }
            
            if (!valid) {
                free(link_flags[i]);
                continue;
            }

            /* The driver always links libm. Do not repeat it when a module also
             * declares the standard math library. */
            if (strcmp(link_flags[i], "-lm") == 0) {
                free(link_flags[i]);
                continue;
            }
            
            if (!module_append_fragment(module_objs_buffer, link_flags[i])) {
                fprintf(stderr, "I could not allocate the complete module link closure.\n");
                for (size_t k = i; k < link_flags_count; k++) free(link_flags[k]);
                free(link_flags);
                for (int j = 0; j < build_info_count; j++) module_build_info_free(build_infos[j]);
                free(build_infos);
                module_builder_free(builder);
                return false;
            }
            free(link_flags[i]);
        }
        free(link_flags);
    }
    
    /* Get all compile flags from C modules */
    if (compile_flags_buffer && compile_flags_buffer_size > 0) {
        size_t compile_flags_count = 0;
        char **compile_flags = module_get_compile_flags(build_infos, build_info_count, &compile_flags_count);
        
        /* Add compile flags to buffer */
        if (compile_flags) {
            for (size_t i = 0; i < compile_flags_count; i++) {
                // Skip NULL or empty flags
                if (!compile_flags[i] || compile_flags[i][0] == '\0') {
                    free(compile_flags[i]);
                    continue;
                }
                
                // Validate flag is printable ASCII (no UTF-8 or binary garbage)
                bool valid = true;
                for (const char *p = compile_flags[i]; *p; p++) {
                    if ((unsigned char)*p < 32 || (unsigned char)*p > 126) {
                        // Non-printable or non-ASCII character found
                        if (verbose) {
                            fprintf(stderr, "[Modules] Warning: Skipping invalid compile flag with non-ASCII character (byte 0x%02x)\n", (unsigned char)*p);
                        }
                        valid = false;
                        break;
                    }
                }
                
                if (!valid) {
                    free(compile_flags[i]);
                    continue;
                }
                
                if (strlen(compile_flags_buffer) + strlen(compile_flags[i]) + 2 < compile_flags_buffer_size) {
                    if (compile_flags_buffer[0] != '\0') {
                        strcat(compile_flags_buffer, " ");
                    }
                    strcat(compile_flags_buffer, compile_flags[i]);
                } else {
                    fprintf(stderr, "I could not represent all module compile flags.\n");
                    for (size_t k = i; k < compile_flags_count; k++) free(compile_flags[k]);
                    free(compile_flags);
                    for (int j = 0; j < build_info_count; j++) module_build_info_free(build_infos[j]);
                    free(build_infos);
                    module_builder_free(builder);
                    return false;
                }
                free(compile_flags[i]);
            }
            free(compile_flags);
        }
    }
    
    /* Cleanup */
    for (int j = 0; j < build_info_count; j++) {
        module_build_info_free(build_infos[j]);
    }
    free(build_infos);
    module_builder_free(builder);
    
    if (verbose) {
        printf("[Modules] ✓ Complete: %d nanolang, %d C, %d FFI-only\n", 
               nanolang_compiled, c_modules_built, ffi_only);
    }
    
    return true;
}


/* Extract module metadata from environment */
ModuleMetadata *extract_module_metadata(Environment *env, const char *module_name) {
    if (!env) return NULL;
    
    ModuleMetadata *meta = malloc(sizeof(ModuleMetadata));
    meta->module_name = module_name ? strdup(module_name) : strdup("unknown");
    
    /* Extract functions */
    meta->function_count = env->function_count;
    if (meta->function_count > 0) {
        meta->functions = malloc(sizeof(Function) * meta->function_count);
        for (int i = 0; i < meta->function_count; i++) {
            /* Copy function - note: we copy pointers, not deep copy */
            meta->functions[i] = env->functions[i];
            /* I retain owned annotation copies; executable AST and environment
             * pointers remain outside compiled module metadata. */
            meta->functions[i].body = NULL;
            meta->functions[i].shadow_test = NULL;
            meta->functions[i].module_name = NULL;
            meta->functions[i].source_file = NULL;
            meta->functions[i].alias_of = NULL;
            meta->functions[i].cleanup_function = NULL;
            meta->functions[i].effect_names = NULL;
            meta->functions[i].effect_count = 0;
            meta->functions[i].return_fn_sig = copy_function_signature(env->functions[i].return_fn_sig);
            meta->functions[i].return_type_info = copy_payload_type_info(env->functions[i].return_type_info);
            meta->functions[i].params = NULL;
            /* Keep params and param_count consistent: only restore the count
             * once the parameter array has actually been deep copied below.
             * Some environment functions carry a non-zero param_count with a
             * NULL params pointer; copying that verbatim made the serializer
             * dereference NULL (the reported bus error). */
            meta->functions[i].param_count = 0;
            /* Deep copy name and params */
            if (env->functions[i].name) {
                meta->functions[i].name = strdup(env->functions[i].name);
            }
            if (env->functions[i].param_count > 0 && env->functions[i].params) {
                meta->functions[i].params = malloc(sizeof(Parameter) * env->functions[i].param_count);
                meta->functions[i].param_count = env->functions[i].param_count;
                for (int j = 0; j < env->functions[i].param_count; j++) {
                    meta->functions[i].params[j] = env->functions[i].params[j];
                    meta->functions[i].params[j].fn_sig = copy_function_signature(env->functions[i].params[j].fn_sig);
                    meta->functions[i].params[j].type_info = copy_payload_type_info(env->functions[i].params[j].type_info);
                    meta->functions[i].params[j].name = NULL;
                    meta->functions[i].params[j].struct_type_name = NULL;
                    if (env->functions[i].params[j].name) {
                        meta->functions[i].params[j].name = strdup(env->functions[i].params[j].name);
                    }
                    if (env->functions[i].params[j].struct_type_name) {
                        meta->functions[i].params[j].struct_type_name = strdup(env->functions[i].params[j].struct_type_name);
                    }
                }
            }
            if (env->functions[i].return_struct_type_name) {
                meta->functions[i].return_struct_type_name = strdup(env->functions[i].return_struct_type_name);
            }

            /* Auto-generate memory semantics annotations based on return type */
            if (env->functions[i].return_type == TYPE_STRING) {
                /* String return types are GC-managed */
                meta->functions[i].returns_gc_managed = true;
                meta->functions[i].requires_manual_free = false;
                meta->functions[i].cleanup_function = NULL;
            } else if (env->functions[i].return_type == TYPE_OPAQUE) {
                /* Opaque types typically require manual free */
                meta->functions[i].returns_gc_managed = false;
                meta->functions[i].requires_manual_free = true;

                /* Infer cleanup function name from function name convention */
                /* Pattern: <type>_<action> -> <type>_free (e.g., regex_compile -> regex_free) */
                if (env->functions[i].name) {
                    const char *name = env->functions[i].name;
                    /* Find last underscore to extract type prefix */
                    const char *last_underscore = strrchr(name, '_');
                    if (last_underscore && last_underscore > name) {
                        /* Extract prefix (type name) */
                        size_t prefix_len = last_underscore - name;
                        char *cleanup_name = malloc(prefix_len + 6); /* prefix + "_free" + \0 */
                        if (cleanup_name) {
                            memcpy(cleanup_name, name, prefix_len);
                            cleanup_name[prefix_len] = '\0';
                            strcat(cleanup_name, "_free");
                            meta->functions[i].cleanup_function = cleanup_name;
                        } else {
                            meta->functions[i].cleanup_function = NULL;
                        }
                    } else {
                        meta->functions[i].cleanup_function = NULL;
                    }
                } else {
                    meta->functions[i].cleanup_function = NULL;
                }

                /* Detect borrowed reference returns (accessors vs constructors) */
                /* Pattern: functions with "get" in the name return borrowed refs */
                /* Constructors (parse, new_, compile) return owned refs */
                meta->functions[i].returns_borrowed = false;
                if (env->functions[i].name) {
                    const char *name = env->functions[i].name;
                    /* Check if it's an accessor function (gets existing data) */
                    if (strstr(name, "get") != NULL ||
                        strstr(name, "Get") != NULL ||
                        strstr(name, "as_") != NULL) {  /* as_string, as_bool, etc. also borrowed */
                        meta->functions[i].returns_borrowed = true;
                        /* Borrowed refs don't need cleanup */
                        meta->functions[i].requires_manual_free = false;
                        if (meta->functions[i].cleanup_function) {
                            free(meta->functions[i].cleanup_function);
                            meta->functions[i].cleanup_function = NULL;
                        }
                    }
                }
            } else {
                /* Other types don't require special memory management */
                meta->functions[i].returns_gc_managed = false;
                meta->functions[i].requires_manual_free = false;
                meta->functions[i].returns_borrowed = false;
                meta->functions[i].cleanup_function = NULL;
            }

            /* Clear body and shadow_test - not needed in metadata */
            meta->functions[i].body = NULL;
            meta->functions[i].shadow_test = NULL;
        }
    } else {
        meta->functions = NULL;
    }
    
    /* Extract structs */
    meta->struct_count = env->struct_count;
    if (meta->struct_count > 0) {
        meta->structs = malloc(sizeof(StructDef) * meta->struct_count);
        for (int i = 0; i < meta->struct_count; i++) {
            meta->structs[i] = env->structs[i];
            if (env->structs[i].name) {
                meta->structs[i].name = strdup(env->structs[i].name);
            }
            if (env->structs[i].field_count > 0) {
                meta->structs[i].field_names = malloc(sizeof(char*) * env->structs[i].field_count);
                meta->structs[i].field_types = malloc(sizeof(Type) * env->structs[i].field_count);
                for (int j = 0; j < env->structs[i].field_count; j++) {
                    if (env->structs[i].field_names[j]) {
                        meta->structs[i].field_names[j] = strdup(env->structs[i].field_names[j]);
                    }
                    meta->structs[i].field_types[j] = env->structs[i].field_types[j];
                }
            }
        }
    } else {
        meta->structs = NULL;
    }
    
    /* Extract enums */
    meta->enum_count = env->enum_count;
    if (meta->enum_count > 0) {
        meta->enums = malloc(sizeof(EnumDef) * meta->enum_count);
        for (int i = 0; i < meta->enum_count; i++) {
            meta->enums[i] = env->enums[i];
            meta->enums[i].original_name = env->enums[i].original_name ? strdup(env->enums[i].original_name) : NULL;
            if (env->enums[i].name) {
                meta->enums[i].name = strdup(env->enums[i].name);
            }
            if (env->enums[i].variant_count > 0) {
                meta->enums[i].variant_names = malloc(sizeof(char*) * env->enums[i].variant_count);
                meta->enums[i].variant_values = malloc(sizeof(int) * env->enums[i].variant_count);
                for (int j = 0; j < env->enums[i].variant_count; j++) {
                    if (env->enums[i].variant_names[j]) {
                        meta->enums[i].variant_names[j] = strdup(env->enums[i].variant_names[j]);
                    }
                    meta->enums[i].variant_values[j] = env->enums[i].variant_values[j];
                }
            }
        }
    } else {
        meta->enums = NULL;
    }
    
    /* Extract unions */
    meta->union_count = env->union_count;
    if (meta->union_count > 0) {
        meta->unions = malloc(sizeof(UnionDef) * meta->union_count);
        for (int i = 0; i < meta->union_count; i++) {
            meta->unions[i] = env->unions[i];
            meta->unions[i].original_name = env->unions[i].original_name ? strdup(env->unions[i].original_name) : NULL;
            meta->unions[i].variant_names = NULL;
            meta->unions[i].variant_field_counts = NULL;
            meta->unions[i].variant_field_names = NULL;
            meta->unions[i].variant_field_types = NULL;
            /* I own these copies independently of the registering environment. */
            meta->unions[i].module_name = env->unions[i].module_name ? strdup(env->unions[i].module_name) : NULL;
            meta->unions[i].generic_params = NULL;
            if (env->unions[i].generic_param_count > 0) {
                meta->unions[i].generic_params = calloc((size_t)env->unions[i].generic_param_count, sizeof(char *));
                for (int j = 0; j < env->unions[i].generic_param_count; j++)
                    if (env->unions[i].generic_params[j])
                        meta->unions[i].generic_params[j] = strdup(env->unions[i].generic_params[j]);
            }
            meta->unions[i].variant_field_type_names = NULL;
            if (env->unions[i].variant_field_type_names) {
                meta->unions[i].variant_field_type_names = calloc((size_t)env->unions[i].variant_count, sizeof(char **));
                for (int j = 0; j < env->unions[i].variant_count; j++) {
                    if (!env->unions[i].variant_field_type_names[j]) continue;
                    int fields = env->unions[i].variant_field_counts[j];
                    meta->unions[i].variant_field_type_names[j] = calloc((size_t)fields, sizeof(char *));
                    for (int k = 0; k < fields; k++)
                        if (env->unions[i].variant_field_type_names[j][k])
                            meta->unions[i].variant_field_type_names[j][k] = strdup(env->unions[i].variant_field_type_names[j][k]);
                }
            }
            meta->unions[i].variant_field_type_info = calloc((size_t)env->unions[i].variant_count, sizeof(TypeInfo **));
            for (int j = 0; j < env->unions[i].variant_count; ++j) {
                int fields = env->unions[i].variant_field_counts[j];
                meta->unions[i].variant_field_type_info[j] = calloc((size_t)fields, sizeof(TypeInfo *));
                for (int k = 0; k < fields; ++k)
                    if (env->unions[i].variant_field_type_info && env->unions[i].variant_field_type_info[j])
                        meta->unions[i].variant_field_type_info[j][k] = copy_payload_type_info(env->unions[i].variant_field_type_info[j][k]);
            }
            if (env->unions[i].name) {
                meta->unions[i].name = strdup(env->unions[i].name);
            }
            if (env->unions[i].variant_count > 0) {
                meta->unions[i].variant_names = calloc(env->unions[i].variant_count, sizeof(char*));
                meta->unions[i].variant_field_counts = malloc(sizeof(int) * env->unions[i].variant_count);
                meta->unions[i].variant_field_names = calloc(env->unions[i].variant_count, sizeof(char**));
                meta->unions[i].variant_field_types = calloc(env->unions[i].variant_count, sizeof(Type*));
                for (int j = 0; j < env->unions[i].variant_count; j++) {
                    if (env->unions[i].variant_names[j]) {
                        meta->unions[i].variant_names[j] = strdup(env->unions[i].variant_names[j]);
                    }
                    meta->unions[i].variant_field_counts[j] = env->unions[i].variant_field_counts[j];
                    if (env->unions[i].variant_field_counts[j] > 0) {
                        meta->unions[i].variant_field_names[j] = calloc(env->unions[i].variant_field_counts[j], sizeof(char*));
                        meta->unions[i].variant_field_types[j] = malloc(sizeof(Type) * env->unions[i].variant_field_counts[j]);
                        for (int k = 0; k < env->unions[i].variant_field_counts[j]; k++) {
                            if (env->unions[i].variant_field_names[j][k]) {
                                meta->unions[i].variant_field_names[j][k] = strdup(env->unions[i].variant_field_names[j][k]);
                            }
                            meta->unions[i].variant_field_types[j][k] = env->unions[i].variant_field_types[j][k];
                        }
                    }
                }
            }
        }
    } else {
        meta->unions = NULL;
    }
    
    /* Extract constants from symbols (global let statements with constant values) */
    meta->constant_count = 0;
    meta->constants = NULL;
    
    /* Count global constants (immutable symbols with constant values at file scope) */
    int const_count = 0;
    for (int i = 0; i < env->symbol_count; i++) {
        Symbol *sym = &env->symbols[i];
        /* Only extract immutable int/float constants */
        if (!sym->is_mut && (sym->type == TYPE_INT || sym->type == TYPE_FLOAT)) {
            const_count++;
        }
    }
    
    if (const_count > 0) {
        meta->constants = malloc(sizeof(ConstantDef) * const_count);
        int const_idx = 0;
        for (int i = 0; i < env->symbol_count; i++) {
            Symbol *sym = &env->symbols[i];
            if (!sym->is_mut && (sym->type == TYPE_INT || sym->type == TYPE_FLOAT)) {
                /* Deduplicate by name: the environment can hold several
                 * immutable symbols that share a name (e.g. block-scoped
                 * bindings that leaked into the flat symbol table). Emitting
                 * each one produced duplicate `static const` C definitions and
                 * a redefinition compile error, so only keep the first. */
                if (sym->name) {
                    bool already_present = false;
                    for (int k = 0; k < const_idx; k++) {
                        if (meta->constants[k].name &&
                            strcmp(meta->constants[k].name, sym->name) == 0) {
                            already_present = true;
                            break;
                        }
                    }
                    if (already_present) continue;
                }
                meta->constants[const_idx].name = sym->name ? strdup(sym->name) : NULL;
                meta->constants[const_idx].type = sym->type;
                if (sym->type == TYPE_INT) {
                    meta->constants[const_idx].value = sym->value.as.int_val;
                } else if (sym->type == TYPE_FLOAT) {
                    /* Store float as int64 bit pattern - will need special handling */
                    union { double d; int64_t i; } u;
                    u.d = sym->value.as.float_val;
                    meta->constants[const_idx].value = u.i;
                }
                const_idx++;
            }
        }
        meta->constant_count = const_idx;
    }
    
    return meta;
}

/* Free module metadata */
/* Get number of imports in a cached module
 * Returns -1 if module not found
 * Note: Returns int64_t to match NanoLang's int type mapping
 */
int64_t module_get_import_count(const char *module_path) {
    if (!module_path) return -1;
    
    ASTNode *module_ast = get_cached_module_ast(module_path);
    if (!module_ast || module_ast->type != AST_PROGRAM) {
        return -1;
    }
    
    int64_t count = 0;
    for (int i = 0; i < module_ast->as.program.count; i++) {
        ASTNode *item = module_ast->as.program.items[i];
        if (item && item->type == AST_IMPORT) {
            count++;
        }
    }
    
    return count;
}

/* Get the path of the nth import in a cached module
 * Returns a malloc'd string that caller must free, or NULL on error
 * Note: Returns const char* to match NanoLang's string type mapping
 * Note: index is int64_t to match NanoLang's int type mapping
 */
const char *module_get_import_path(const char *module_path, int64_t index) {
    if (!module_path || index < 0) return NULL;
    
    ASTNode *module_ast = get_cached_module_ast(module_path);
    if (!module_ast || module_ast->type != AST_PROGRAM) {
        return NULL;
    }
    
    int count = 0;
    for (int i = 0; i < module_ast->as.program.count; i++) {
        ASTNode *item = module_ast->as.program.items[i];
        if (item && item->type == AST_IMPORT) {
            if (count == index) {
                /* Resolve the import path */
                const char *resolved = resolve_module_path(
                    item->as.import_stmt.module_path, 
                    module_path
                );
                return resolved;
            }
            count++;
        }
    }
    
    return NULL;
}

/* Generate forward declarations for a module's public functions
 * Returns a malloc'd string with C forward declarations, or NULL on error
 * Caller must free the returned string
 * Note: Returns const char* to match NanoLang's string type mapping
 */
const char *module_generate_forward_declarations(const char *module_path) {
    if (!module_path) return NULL;
    
    ASTNode *module_ast = get_cached_module_ast(module_path);
    if (!module_ast || module_ast->type != AST_PROGRAM) {
        return NULL;
    }
    
    /* Find module name */
    const char *module_name = NULL;
    for (int i = 0; i < module_ast->as.program.count; i++) {
        ASTNode *item = module_ast->as.program.items[i];
        if (item && item->type == AST_MODULE_DECL && item->as.module_decl.name) {
            module_name = item->as.module_decl.name;
            break;
        }
    }
    
    /* Build forward declarations string */
    StringBuilder *sb = sb_create();
    if (!sb) return NULL;
    
    sb_append(sb, "/* Forward declarations from ");
    sb_append(sb, module_path);
    sb_append(sb, " */\n");
    
    /* Track emitted function names to avoid duplicates */
    int emitted_count = 0;
    int emitted_capacity = 64;
    char **emitted = malloc(sizeof(char*) * emitted_capacity);
    if (!emitted) {
        free(sb->buffer);
        free(sb);
        return NULL;
    }
    
    /* Iterate through functions in module */
    for (int i = 0; i < module_ast->as.program.count; i++) {
        ASTNode *item = module_ast->as.program.items[i];
        if (!item || item->type != AST_FUNCTION) continue;
        if (!item->as.function.is_pub) continue;  /* Only public functions */
        if (item->as.function.is_extern) continue;  /* Skip extern functions */
        if (strcmp(item->as.function.name, "main") == 0) continue;  /* Skip main */
        
        /* Build C function name with module prefix */
        char c_name_buf[512];
        const char *c_name = NULL;
        if (module_name) {
            snprintf(c_name_buf, sizeof(c_name_buf), "%s__%s", module_name, item->as.function.name);
            c_name = c_name_buf;
        } else {
            snprintf(c_name_buf, sizeof(c_name_buf), "nl_%s", item->as.function.name);
            c_name = c_name_buf;
        }
        
        /* Check if already emitted */
        bool seen = false;
        for (int j = 0; j < emitted_count; j++) {
            if (strcmp(emitted[j], c_name) == 0) {
                seen = true;
                break;
            }
        }
        if (seen) continue;
        
        /* Add to emitted list */
        if (emitted_count >= emitted_capacity) {
            emitted_capacity *= 2;
            char **new_emitted = realloc(emitted, sizeof(char*) * emitted_capacity);
            if (!new_emitted) {
                for (int j = 0; j < emitted_count; j++) free(emitted[j]);
                free(emitted);
                free(sb->buffer);
                free(sb);
                return NULL;
            }
            emitted = new_emitted;
        }
        emitted[emitted_count++] = strdup(c_name);
        
        /* Generate forward declaration */
        sb_append(sb, "extern ");
        
        /* Return type - simplified version */
        Type ret_type = item->as.function.return_type;
        if (ret_type == TYPE_INT) {
            sb_append(sb, "int64_t");
        } else if (ret_type == TYPE_FLOAT) {
            sb_append(sb, "double");
        } else if (ret_type == TYPE_BOOL) {
            sb_append(sb, "int");
        } else if (ret_type == TYPE_STRING) {
            sb_append(sb, "const char*");
        } else if (ret_type == TYPE_VOID) {
            sb_append(sb, "void");
        } else if (ret_type == TYPE_STRUCT && item->as.function.return_struct_type_name) {
            char buf[256];
            snprintf(buf, sizeof(buf), "nl_%s", item->as.function.return_struct_type_name);
            sb_append(sb, buf);
        } else if (ret_type == TYPE_UNION && item->as.function.return_struct_type_name) {
            char buf[256];
            snprintf(buf, sizeof(buf), "nl_%s", item->as.function.return_struct_type_name);
            sb_append(sb, buf);
        } else if (ret_type == TYPE_LIST_GENERIC && item->as.function.return_struct_type_name) {
            char buf[256];
            snprintf(buf, sizeof(buf), "List_%s*", item->as.function.return_struct_type_name);
            sb_append(sb, buf);
        } else {
            sb_append(sb, "void");  /* Fallback */
        }
        
        char name_buf[1024];
        snprintf(name_buf, sizeof(name_buf), " %s(", c_name);
        sb_append(sb, name_buf);
        
        /* Parameters */
        for (int p = 0; p < item->as.function.param_count; p++) {
            if (p > 0) sb_append(sb, ", ");
            Parameter *param = &item->as.function.params[p];
            char param_buf[256];
            
            if (param->type == TYPE_INT) {
                sb_append(sb, "int64_t");
            } else if (param->type == TYPE_FLOAT) {
                sb_append(sb, "double");
            } else if (param->type == TYPE_BOOL) {
                sb_append(sb, "int");
            } else if (param->type == TYPE_STRING) {
                sb_append(sb, "const char*");
            } else if (param->type == TYPE_STRUCT && param->struct_type_name) {
                snprintf(param_buf, sizeof(param_buf), "nl_%s", param->struct_type_name);
                sb_append(sb, param_buf);
            } else if (param->type == TYPE_UNION && param->struct_type_name) {
                snprintf(param_buf, sizeof(param_buf), "nl_%s", param->struct_type_name);
                sb_append(sb, param_buf);
            } else if (param->type == TYPE_LIST_GENERIC && param->struct_type_name) {
                snprintf(param_buf, sizeof(param_buf), "List_%s*", param->struct_type_name);
                sb_append(sb, param_buf);
            } else {
                sb_append(sb, "void");  /* Fallback */
            }
            
            if (param->name) {
                snprintf(param_buf, sizeof(param_buf), " %s", param->name);
                sb_append(sb, param_buf);
            } else {
                snprintf(param_buf, sizeof(param_buf), " param%d", p);
                sb_append(sb, param_buf);
            }
        }
        
        sb_append(sb, ");\n");
    }
    
    /* Cleanup */
    for (int i = 0; i < emitted_count; i++) {
        free(emitted[i]);
    }
    free(emitted);
    
    sb_append(sb, "\n");
    
    /* Return the string (caller must free) */
    char *result = strdup(sb->buffer);
    free(sb->buffer);
    free(sb);
    return result;
}

void free_module_metadata(ModuleMetadata *meta) {
    if (!meta) return;
    
    if (meta->module_name) free(meta->module_name);
    
    /* Free functions */
    if (meta->functions) {
        for (int i = 0; i < meta->function_count; i++) {
            if (meta->functions[i].name) free(meta->functions[i].name);
            if (meta->functions[i].params) {
                for (int j = 0; j < meta->functions[i].param_count; j++) {
                    free_function_signature(meta->functions[i].params[j].fn_sig);
                    free_payload_type_info(meta->functions[i].params[j].type_info);
                    if (meta->functions[i].params[j].name) free(meta->functions[i].params[j].name);
                    if (meta->functions[i].params[j].struct_type_name) free(meta->functions[i].params[j].struct_type_name);
                }
                free(meta->functions[i].params);
            }
            free_function_signature(meta->functions[i].return_fn_sig);
            free_payload_type_info(meta->functions[i].return_type_info);
            if (meta->functions[i].return_struct_type_name) free(meta->functions[i].return_struct_type_name);
        }
        free(meta->functions);
    }
    
    /* Free structs */
    if (meta->structs) {
        for (int i = 0; i < meta->struct_count; i++) {
            if (meta->structs[i].name) free(meta->structs[i].name);
            if (meta->structs[i].field_names) {
                for (int j = 0; j < meta->structs[i].field_count; j++) {
                    if (meta->structs[i].field_names[j]) free(meta->structs[i].field_names[j]);
                }
                free(meta->structs[i].field_names);
            }
            if (meta->structs[i].field_types) free(meta->structs[i].field_types);
        }
        free(meta->structs);
    }
    
    /* Free enums */
    if (meta->enums) {
        for (int i = 0; i < meta->enum_count; i++) {
            if (meta->enums[i].name) free(meta->enums[i].name);
            free(meta->enums[i].original_name);
            if (meta->enums[i].variant_names) {
                for (int j = 0; j < meta->enums[i].variant_count; j++) {
                    if (meta->enums[i].variant_names[j]) free(meta->enums[i].variant_names[j]);
                }
                free(meta->enums[i].variant_names);
            }
            if (meta->enums[i].variant_values) free(meta->enums[i].variant_values);
        }
        free(meta->enums);
    }
    
    /* Free unions */
    if (meta->unions) {
        for (int i = 0; i < meta->union_count; i++) {
            if (meta->unions[i].name) free(meta->unions[i].name);
            free(meta->unions[i].original_name);
            if (meta->unions[i].variant_names) {
                for (int j = 0; j < meta->unions[i].variant_count; j++) {
                    if (meta->unions[i].variant_names[j]) free(meta->unions[i].variant_names[j]);
                    if (meta->unions[i].variant_field_type_info && meta->unions[i].variant_field_type_info[j]) {
                        for (int k = 0; k < meta->unions[i].variant_field_counts[j]; ++k)
                            free_payload_type_info(meta->unions[i].variant_field_type_info[j][k]);
                        free(meta->unions[i].variant_field_type_info[j]);
                    }
                    if (meta->unions[i].variant_field_names && meta->unions[i].variant_field_names[j]) {
                        for (int k = 0; k < meta->unions[i].variant_field_counts[j]; k++) {
                            if (meta->unions[i].variant_field_names[j][k]) free(meta->unions[i].variant_field_names[j][k]);
                        }
                        free(meta->unions[i].variant_field_names[j]);
                    }
                    if (meta->unions[i].variant_field_types && meta->unions[i].variant_field_types[j]) {
                        free(meta->unions[i].variant_field_types[j]);
                    }
                    if (meta->unions[i].variant_field_type_names && meta->unions[i].variant_field_type_names[j]) {
                        for (int k = 0; k < meta->unions[i].variant_field_counts[j]; k++)
                            free(meta->unions[i].variant_field_type_names[j][k]);
                        free(meta->unions[i].variant_field_type_names[j]);
                    }
                }
                free(meta->unions[i].variant_names);
                free(meta->unions[i].variant_field_counts);
                free(meta->unions[i].variant_field_names);
                free(meta->unions[i].variant_field_types);
            }
            free(meta->unions[i].variant_field_type_info);
            free(meta->unions[i].variant_field_type_names);
            for (int j = 0; j < meta->unions[i].generic_param_count; j++)
                free(meta->unions[i].generic_params[j]);
            free(meta->unions[i].generic_params);
            free(meta->unions[i].module_name);
        }
        free(meta->unions);
    }
    
    /* Free constants */
    if (meta->constants) {
        for (int i = 0; i < meta->constant_count; i++) {
            if (meta->constants[i].name) free(meta->constants[i].name);
        }
        free(meta->constants);
    }
    
    free(meta);
}
