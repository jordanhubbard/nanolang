from pathlib import Path
import os,sys,json,subprocess,hashlib,gzip,stat,shutil
root=Path.cwd();work=root/'.test_output/reference-places-20261122';state=json.loads((work/'linux/manifest.json').read_text());san=json.loads((work/'linux/reference-sanitizers/manifest.json').read_text());products=json.loads((work/'linux/products/manifest.json').read_text());assert state['status']==san['status']=='passed' and state['final_guards_unchanged']
sha=lambda raw:hashlib.sha256(raw).hexdigest();expected=state['source_hashes'];assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert pin==state['base'];out=root/'docs/evidence/reference-places-linux-20261122';(out/'inputs').mkdir(parents=True,exist_ok=False)
for name in ['reference-places-preflight.stdout','reference-places-preflight.stderr']:
 p=root/'.test_output'/name
 if p.is_file():shutil.copyfile(p,work/name)
paths={p for p in work.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(work).parts};paths.update(root/n for n in expected)
for name in [*state['tools'],'obj/fixture_identifier_lexer','docs/ROADMAP.md','docs/NANOLANG_NANOISA_C_TRANSLATOR.md']:
 p=root/name
 if p.is_file():paths.add(p)
frozen=Path('/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121');sys.path.insert(0,str(frozen));from scripts.bootstrap_nanoisa import Bootstrap
b=Bootstrap(frozen,1800,30);b.env.pop('NANO_BUILD_CACHE',None);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']))
for name in ['nanoc_stage1','nanoc_stage1.nvm','nanoc_bootstrap.json']:paths.add(frozen/'bin'/name)
paths.update(Path(n) for n in b.manifest['hosts']);files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw)
 if digest not in seen:
  artifact=f'inputs/{i:05d}-{p.name}.gz';(out/artifact).write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[digest]=artifact
 packed=(out/seen[digest]).read_bytes();files.append(dict(path=str(p),artifact=seen[digest],bytes=len(raw),sha256=digest,mode=stat.S_IMODE(p.stat().st_mode),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
record=dict(implementation=pin,source_hashes=expected,verification=products,sanitizers=san,provider=state['provider'],files=files,issue=1142,limits=['I qualify only the complete shared reference-place API dependency through five Linux routes and all75 original C checks, not affine state/bytecode, private-profile or executable admission. I retain1629 actual-C reports including487 independent expectations, malformed/pointer/authority/sibling/path/prefix/unsigned identity, randomized and deep/shared DAG controls. Harness D refuses only unrepresentable/truncated carriers. All3571 source/test/spec/Make inputs, tools and frozen qualified bdffa4ccc development producer guards hold; no raw bootstrap executes. Original shadows10s and native/guest600s remain unchanged. Actual reference-place implementation/oracle/original-unit sanitizers pass all cases with no environment overrides; emitted-product sanitizers do not instrument every provider. I retain the raw-library preflight missing-main refusal separately from successful actual driver compilation and all product gates. Build caches are omitted.'])
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(sha((root/n).read_bytes())==v for n,v in expected.items());assert all(sha((root/n).read_bytes())==v for n,v in state['tools'].items());print(json.dumps(dict(files=len(files),unique_artifacts=len(seen),raw_bytes=sum(e['bytes'] for e in files),compressed_bytes=sum((out/n).stat().st_size for n in seen.values()),source_files=len(expected))))
