from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('docs/evidence/nanolang-routing-20261121');inputs=root/'inputs';inputs.mkdir(exist_ok=True)
records=[]
def retain(name,data):
    packed=gzip.compress(data,mtime=0);(inputs/(name+'.gz')).write_bytes(packed)
    records.append(dict(path='inputs/'+name+'.gz',uncompressed_bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),compressed_sha256=hashlib.sha256(packed).hexdigest()))
for p in sorted(Path('.test_output').glob('routes-*.log')):retain('linux-'+p.name,p.read_bytes())
for p in sorted(Path('.test_output/routes-darwin').glob('*.log')):retain('darwin-'+p.name,p.read_bytes())
for name in ['routes-corpus.json','routes-products.json','routes-linux-manifest.json','routes-collect.py','routes-pack.py','declarations-collect.py','routes-reference-first.c','routes-first-candidate.nano','routes-first-tests.py','routes-launch-results.json']:
    retain(name,Path('.test_output',name).read_bytes())
for name in ['routes-darwin-manifest.json','routes-products.json']:
    p=Path('.test_output/routes-darwin',name)
    data=p.read_bytes() if p.exists() else gzip.decompress(p.with_suffix('.json.gz').read_bytes())
    retain('darwin-'+name,data)
a=json.loads(Path('.test_output/routes-linux-manifest.json').read_text())
b=json.loads(Path('.test_output/routes-darwin/routes-darwin-manifest.json').read_text())
assert a['source_sha256']==b['source_sha256']
for name,sha in a['source_sha256'].items():
    data=subprocess.check_output(['git','show','156917fba:'+name]);assert hashlib.sha256(data).hexdigest()==sha,name
    retain('source-'+name.replace('/','_'),data)
assert Path('.test_output/routes-corpus.json').read_bytes()==gzip.decompress(Path('.test_output/routes-darwin/routes-corpus.json.gz').read_bytes())
(root/'retained-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:
    packed=(root/r['path']).read_bytes();data=gzip.decompress(packed)
    assert len(data)==r['uncompressed_bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
    assert hashlib.sha256(packed).hexdigest()==r['compressed_sha256']
print('I retained and verified',len(records),'inputs; paired synthetic bytes/reports and source hashes match.')
