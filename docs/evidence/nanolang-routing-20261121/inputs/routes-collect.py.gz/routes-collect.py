from pathlib import Path
import gzip,hashlib,json,os,platform,re,runpy,subprocess,sys,tempfile
from tests.test_nanolang_translator_routes import corpus
from tests.nanolang_translator_routes import checked

if sys.argv[1]=='--corpus':
    cases=corpus()
    with tempfile.TemporaryDirectory(prefix='route-corpus-') as d:
        paths=[]
        for i,(_,data,_) in enumerate(cases):
            p=Path(d)/str(i);p.write_bytes(data);paths.append(p)
        values=[]
        for i in range(0,len(paths),32):values+=checked(['obj/nvm2c_declaration_reference','0',*paths[i:i+32]],timeout=600).splitlines()
    assert len(values)==len(cases)
    records=[]
    for (name,data,expected),value in zip(cases,values):
        if expected is not None:assert value==expected,(name,value,expected)
        records.append(dict(name=name,bytes_hex=data.hex(),sha256=hashlib.sha256(data).hexdigest(),explicit_report=expected,actual_c_report=value))
    Path('.test_output/routes-corpus.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
    print('I retained',len(records),'synthetic routing inputs and five-selector reports;',sum(e is not None for _,_,e in cases),'explicit controls.')
elif sys.argv[1]=='--products':
    log=Path(sys.argv[2]).read_text();match=re.search(r'I retain actual producer modules/models at (.+)',log);assert match
    root=Path(match[1]);items=json.loads((root/'records.json').read_text());assert len(items)==14
    result=[]
    for r in items:
        module=(root/r['module']).read_bytes();model=(root/r['model']).read_bytes()
        assert model[:16]==bytes(16),'I require a separate routing carrier for nonzero foreign context.'
        assert hashlib.sha256(module).hexdigest()==r['module_sha256']
        assert hashlib.sha256(model).hexdigest()==r['model_sha256']
        assert hashlib.sha256(Path(r['source']).read_bytes()).hexdigest()==r['source_sha256']
        value=checked(['obj/nvm2c_declaration_reference','0',root/r['model']],timeout=120).strip()
        result.append(dict(**r,module_bytes_hex=module.hex(),model_bytes_hex=model.hex(),actual_c_route_report=value))
    Path('.test_output/routes-products.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print('I retained',len(result),'actual producer modules/models, exact VM results and routing reports; all foreign prefixes are zero.')
else:
    destination=sys.argv[1];runpy.run_path('.test_output/declarations-collect.py',run_name='__main__')
    record=json.loads(Path(destination).read_text())
    extra=['src_nano/nvm2c/routes.nano','src_nano/nvm2c/module.nano','tests/test_nanolang_translator_routes.py','tests/test_nanolang_translator_module.py','tests/test_nanolang_translator_instructions.py']
    extra+=['src/nanoisa/'+s for s in ['record_map_route.inc','record_map_admission.h','record_array_admission.inc','record_array_admission.h','mixed_samples_prepare.inc','owned_array_admit.inc','owned_array_admission.h','service_bindings_module.c','service_bindings_module.h','service_classification_private.h','nvm_format.c','verifier.c','managed_array_shapes.c']]
    record['source_sha256'].update({s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in extra})
    record['limits']+=['My routing model includes explicit empty-pointer presence and abstract service-import presence; actual producer foreign prefixes are verified zero.', 'My C routing oracle calls actual selectors; only the existing declaration-provider regression uses a full owning/provider sanitizer image, not every C routing TU.', 'Routing never grants admission; selected/invalid routes cannot fall back, and DEFER still requires full validation.']
    Path(destination).write_text(json.dumps(record,indent=2)+'\n')
