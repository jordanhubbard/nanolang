## Finding

My retained complete evaluator sanitizer failure under #1149 includes directly leaked AST_FUNCTION nodes from test_eval_handler_return_async_calls. My parser allocates an AST_ASYNC_FN wrapper owning the parsed function child, and AST_AWAIT owns its parsed expression child. My free_ast switch currently has neither ownership case. I will first isolate parser-only async/await trees and the unchanged original async handler method under matching ASan/UBSan/leak instrumentation before a repair.

## Ownership

I resume this bounded work on feat/5.1-service-module-integration / draft #1168 in /home/jkh/.worktrees/nanolang/service-module-integration. I own src/parser.c, focused parser/evaluator ownership controls and their Make enrollment. My current bdffa4ccc Linux/Darwin bootstrap checkouts stay immutable. #1149/#1140/#1116 retain broader evaluator and callable/record ownership scope.

## Acceptance

- [ ] I retain matching baseline sanitizer failures and exact real providers for parser-only async/await trees and the original async-handler method.
- [ ] I reclaim the children owned by async/await syntax without changing evaluation, scheduling or AST ownership elsewhere.
- [ ] I pass the bounded controls, original complete ordinary parser/evaluator suites and relevant original async/effect controls with unchanged assertions/deadlines.
- [ ] I retain complete sanitizer results, distinguish any remaining leaks, link pushed commits and record platform limits before closure.
