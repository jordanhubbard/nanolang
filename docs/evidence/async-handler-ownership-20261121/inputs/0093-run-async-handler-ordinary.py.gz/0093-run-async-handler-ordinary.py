from pathlib import Path
import os,subprocess,time,json,shutil,hashlib,signal
root=Path.cwd();out=root/'.test_output/async-handler-ordinary';out.mkdir(exist_ok=False);env=dict(os.environ,PATH='/usr/bin:/bin:/home/jkh/.cargo/bin',CC='/usr/bin/cc',NANO_AS_CAPTURE_HELPER=str(root/'bin/nano_as_capture.so'),NANO_BUILD_CACHE=str(out/'module-cache'),NANOLANG_EFFECT_COMPILERS=str(root/'bin/nano_virt'),NANOLANG_IMPORTED_EFFECT_COMPILERS=str(root/'bin/nano_virt'),NANOLANG_EFFECT_TARGETS='vm,native')
for name in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_TRANSLATOR_SOURCE_COMPILER','NANOLANG_TRANSLATOR_SOURCE_MODULE']:env.pop(name,None)
record={'steps':[],'sources':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['src/parser.c','src/typechecker.c','tests/test_parser.c','tests/test_eval.c','Makefile.gnu']},'limits':['I build original source C/VM/translator providers and complete ordinary parser/evaluator/typechecker/effect controls using a fresh ordinary object root. I rebuild the actual default-path native fixture with matching ordinary flags. I retain all original assertions and test methods, original source async/refusal and effect product cases, ordinary shadow deadlines and the separately failed complete sanitizer result. I make no self-hosted, Darwin or full-release claim.']}
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,timeout=1800):
 t=time.monotonic();s={'label':label,'argv':args};record['steps'].append(s);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);s['pid']=p.pid;save()
  try:s['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:s['driver_timeout']=True;os.killpg(p.pid,signal.SIGKILL);s['returncode']=p.wait()
 s['elapsed_seconds']=time.monotonic()-t;save();assert s['returncode']==0,s
run('matching-default-native-fixture',['make','-f','Makefile.gnu','-B','CC=/usr/bin/cc','obj/test_interpreter_ffi_native.so'])
common=['make','-f','Makefile.gnu','-j4','CC=/usr/bin/cc','OBJ_DIR=.test_output/obj-async-handler-ordinary']
run('original-source-product-tools',common+['bin/nanoc_c','nano_virt','nano_vm','nanoisa_dump','nvm2c','nvm2c-runtime','bin/nano_as_capture.so'])
run('original-complete-ordinary',common+['test-parser','test-eval','test-typechecker','test-effects','test-parser-async-ownership','test-eval-async-ownership','test-eval-effect-metadata-ownership'])
run('original-cseed-async-and-effect-products',['/usr/bin/python3','-m','unittest','-v','tests.test_async_source_contracts.CSeedAsyncContracts','tests.test_imported_effect_identity','tests.test_selfhost_effects','tests.test_effect_execution','tests.test_native_effect_execution','tests.test_native_effects'])
record['tools']={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['bin/nanoc_c','bin/nano_virt','bin/nano_vm','bin/nvm2c','bin/nano_aot_runtime.o','bin/nano_as_capture.so']};save();print(json.dumps(record))
