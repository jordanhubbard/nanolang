from pathlib import Path
import json,gzip,hashlib,subprocess,shlex
root=Path.cwd();out=root/'.test_output/async-handler-ordinary';m=json.loads((out/'manifest.json').read_text());assert all(s.get('returncode')==0 for s in m['steps']);assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==h for name,h in m['sources'].items());paths={Path(__file__).resolve(),root/'.test_output/archive-async-handler-ownership-v1.py',root/'.test_output/archive-async-handler-ownership.log'};dest=root/'docs/evidence/async-handler-ownership-20261121';(dest/'inputs').mkdir(parents=True,exist_ok=True)
for name in ['async-ast-baseline','async-ast-baseline-v2','async-ast-repaired','handler-symbol-baseline','handler-symbol-repaired','handler-full-sanitizers','async-handler-ordinary']:
 directory=root/'.test_output'/name
 paths.update(p for p in directory.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(directory).parts)
for pattern in ['run-async-ast*.py','run-async-ast*.log','run-handler-*.py','run-handler-*.log','run-async-handler*.py','run-async-handler*.log','*ast-issue*.md','handler-symbol-issue.md']:
 paths.update((root/'.test_output').glob(pattern))
# I snapshot the linked tools after all complete gates have stopped.
for name,h in m['tools'].items():
 p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;paths.add(p)
for name in ['src/parser.c','src/typechecker.c','src/env.c','src/nanolang.h','tests/test_parser.c','tests/test_eval.c','tests/test_parser_async_ownership.c','tests/test_eval_async_ownership.c','tests/test_eval_effect_metadata_ownership.c','Makefile.gnu']:
 paths.add(root/name)
(out/'working-source.diff').write_bytes(subprocess.check_output(['git','diff','--','src/parser.c','src/typechecker.c','tests/test_parser.c','Makefile.gnu']));paths.add(out/'working-source.diff')
providers={};unparsed=[]
for directory in [root/'.test_output/handler-symbol-repaired',root/'.test_output/handler-full-sanitizers',out]:
 for log in directory.glob('*.stdout'):
  for line in log.read_text(errors='replace').replace(chr(92)+chr(10),' ').splitlines():
   if ' -o ' not in line or not line.startswith('/usr/bin/cc '):continue
   try:words=shlex.split(line)
   except ValueError as error:unparsed.append(dict(log=str(log),line=line,error=repr(error)));continue
   for name in words:
    p=root/name
    if p.suffix in ('.o','.a') and p.is_file():providers[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'post-gate-provider-identities.json').write_text(json.dumps(dict(providers=providers,unparsed=unparsed,limits=['I collect these provider bytes after the gates. My exact baseline/repaired images retain their actual linked code. I do not describe a later rebuilt global archive as the unchanged earlier archive or claim uniform instrumentation beyond the explicitly built parser/checker/evaluator and recorded flags.']),indent=2)+'\n');paths.add(out/'post-gate-provider-identities.json')
sha=lambda b:hashlib.sha256(b).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);artifact=seen.get(h,dest/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:artifact.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 packed=artifact.read_bytes();entries.append(dict(path=str(p),artifact=str(artifact.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries,base_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),ordinary_sources_unchanged=True),indent=2)+'\n')
for e in entries:
 packed=(dest/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum(p.stat().st_size for p in seen.values()))))
