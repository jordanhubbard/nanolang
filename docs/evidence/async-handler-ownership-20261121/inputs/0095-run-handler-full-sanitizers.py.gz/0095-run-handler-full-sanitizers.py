from pathlib import Path
import os,subprocess,time,json,shutil,hashlib
root=Path.cwd();out=root/'.test_output/handler-full-sanitizers';out.mkdir(exist_ok=False);baseline=json.loads((root/'.test_output/enum-ownership-baseline/manifest.json').read_text());env=dict(os.environ,**baseline['environment']);record={'steps':[],'limits':['I retain every original complete evaluator assertion and matching ASan/UBSan/leak flags after the async-child/handler-name fixes. I deliberately rebuild the hardcoded default-path native test fixture with matching flags while all evaluator providers use the explicit sanitizer object root. Remaining original leaks stay failures under #1149; I do not claim all134 sanitizer methods complete after a child/process refusal.']}
for name in ['src/parser.c','src/typechecker.c','tests/test_eval.c']:
 p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
for label,args in [('matching-default-native-fixture',baseline['argv'][:-2]+['-B','obj/test_interpreter_ffi_native.so']),('complete-original',baseline['argv'][:-1]+['test-eval'])]:
 t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(args,cwd=root,env=env,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-t));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 if label=='matching-default-native-fixture':assert r.returncode==0
for name in ['tests/test_eval','obj/test_interpreter_ffi_native.so']:
 p=root/name
 if p.exists():shutil.copy2(p,out/p.name)
print(json.dumps(record))
