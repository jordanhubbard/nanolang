from pathlib import Path
import subprocess,os,time,json,shutil,hashlib
root=Path.cwd();out=root/'.test_output/async-ast-baseline';out.mkdir(exist_ok=False);m=json.loads((root/'.test_output/enum-ownership-baseline/manifest.json').read_text());prefix=m['argv'][:-2];env=dict(os.environ,**m['environment']);record={'steps':[],'environment':m['environment'],'limits':['I retain complete ASan/UBSan/leak instrumentation with the existing matching object closure. I run new parser-only async/await ownership controls and the unchanged original async-handler method separately, before changing free_ast. My source/provider snapshots distinguish setup refusals from completed leak checks.']}
for source in ['src/parser.c','tests/test_parser.c','tests/test_parser_async_ownership.c','tests/test_eval_async_ownership.c','Makefile.gnu']:
 dest=out/'source'/source;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/source,dest)
for label,target in [('parser','test-parser-async-ownership'),('evaluator','test-eval-async-ownership')]:
 args=prefix+[target];t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(args,cwd=root,env=env,stdout=a,stderr=b,timeout=600)
 entry={'label':label,'argv':args,'returncode':r.returncode,'elapsed_seconds':time.monotonic()-t};record['steps'].append(entry)
 name='test_parser_async_ownership' if label=='parser' else 'test_eval_async_ownership';image=root/'.test_output/obj-enum-baseline'/name
 if image.is_file():shutil.copy2(image,out/(name+'-baseline'));entry['image_sha256']=hashlib.sha256(image.read_bytes()).hexdigest()
 (out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
