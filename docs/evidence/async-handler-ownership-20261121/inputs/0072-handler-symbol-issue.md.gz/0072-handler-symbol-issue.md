## Finding

After #1169 reclaims owned async/await child trees, my matching parser-only sanitizer control passes, but the unchanged original async-handler method still leaks2 bytes in one allocation. The actual stack is env_define_var_impl -> AST_HANDLE_EXPR parameter binding in src/typechecker.c. The checker restores symbol_count after a handler arm without releasing the copied symbol name; the discarded row is no longer owned by environment teardown.

## Ownership

I own this focused follow-up under #1149 on feat/5.1-service-module-integration / draft #1168, in /home/jkh/.worktrees/nanolang/service-module-integration. I coordinate src/typechecker.c and the existing bounded async/effect controls through #1161 with the Puck agent. Neither frozen Linux/Darwin bootstrap checkout changes. I retain all broader callable/record/evaluator leaks under #1149/#1140/#1116.

## Acceptance

- [ ] I retain the exact2-byte baseline, actual driver and checker source before repair.
- [ ] I release the owned name/nominal-name metadata of discarded handler-local rows before restoring their existing scope boundary, preserving borrowed annotation/value ownership and retained ordinary scopes.
- [ ] I pass matching bounded sanitizer controls and original complete ordinary parser/evaluator and relevant effect/async contract gates.
- [ ] I retain the complete original sanitizer result, distinguish remaining failures and link pushed evidence before closure.
