.types 0 0 0
.entry 0

.import "/home/jkh/nanolang-qualification/compiler-support-cda-linux/ordinary/source/obj/module_cache/v2-312225affe226495823bcde3b3a69fc73abee12680e7ccfcf66c8cd356715d48/.nano-gen-PCl8H2/libcompiler_support.so" "nlc_runtime_root" string
.import_kind 0 artifact
.import "/home/jkh/nanolang-qualification/compiler-support-cda-linux/ordinary/source/obj/module_cache/v2-312225affe226495823bcde3b3a69fc73abee12680e7ccfcf66c8cd356715d48/.nano-gen-PCl8H2/libcompiler_support.so" "nlc_native_array_abi" int
.import_kind 1 artifact
.string s0 "/home/jkh/nanolang-qualification/compiler-support-cda-linux/ordinary/source"

.function main 0 2 0 int 1
  CALL_EXTERN 0
  STORE_LOCAL 0
.local_begin 0 "first"
  CALL_EXTERN 0
  STORE_LOCAL 1
.local_begin 1 "second"
  LOAD_LOCAL 0
  PUSH_STR s0
  EQ
  ASSERT
  LOAD_LOCAL 0
  LOAD_LOCAL 1
  EQ
  ASSERT
  CALL_EXTERN 1
  PRINTLN
  PUSH_I64 0
  RET
.local_end 0
.local_end 1
.end

