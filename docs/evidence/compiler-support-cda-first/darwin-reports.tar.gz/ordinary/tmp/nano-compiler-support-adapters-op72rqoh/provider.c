#include <stdint.h>
#include <stdio.h>
int64_t nlc_native_array_abi(void) { return 47; }
const char *nlc_runtime_root(void) { static char text[32]; static int calls; snprintf(text, sizeof text, "root-%d", ++calls); return text; }
