#include <assert.h>
#include <dlfcn.h>
#include <inttypes.h>
#include <stdio.h>
int main(int argc, char **argv) { assert(argc == 2); void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL); assert(library); int64_t (*abi)(void) = (int64_t (*)(void))dlsym(library, "nlc_native_array_abi"); const char *(*root)(void) = (const char *(*)(void))dlsym(library, "nlc_runtime_root"); assert(abi && root && dlsym(library, "nlc_module_artifact")); assert(!dlsym(library, "module_builder_verbose")); assert(!dlsym(library, "module_build")); assert(!dlsym(library, "nano_native_sdk_prepare")); printf("%" PRId64 "\n%s\n", abi(), root()); dlclose(library); return 0; }
