.types 0 0 0
.entry 0

.import "/Users/jkh/nanolang-qualification/compiler-support-cda-puck/ordinary/source/obj/module_cache/v2-85850d5762bc642308a387055b9ec92c3a0931254be12cbb4da09a53d63cb9b7/.nano-gen-lRkQts/libcompiler_support.dylib" "nlc_runtime_root" string
.import_kind 0 artifact
.import "/Users/jkh/nanolang-qualification/compiler-support-cda-puck/ordinary/source/obj/module_cache/v2-85850d5762bc642308a387055b9ec92c3a0931254be12cbb4da09a53d63cb9b7/.nano-gen-3NxRa3/libcompiler_support.dylib" "nlc_native_array_abi" int
.import_kind 1 artifact
.string s0 "/Users/jkh/nanolang-qualification/compiler-support-cda-puck/ordinary/source"

.function main 0 2 0 int 1
  CALL_EXTERN 0
  STORE_LOCAL 0
.local_begin 0 "first"
  CALL_EXTERN 0
  STORE_LOCAL 1
.local_begin 1 "second"
  LOAD_LOCAL 0
  PUSH_STR s0
  EQ
  ASSERT
  LOAD_LOCAL 0
  LOAD_LOCAL 1
  EQ
  ASSERT
  CALL_EXTERN 1
  PRINTLN
  PUSH_I64 0
  RET
.local_end 0
.local_end 1
.end

