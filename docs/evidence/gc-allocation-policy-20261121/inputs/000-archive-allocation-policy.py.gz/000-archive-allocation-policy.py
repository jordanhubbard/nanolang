from pathlib import Path
import gzip,hashlib,json
base=Path('.test_output');dest=Path('docs/evidence/gc-allocation-policy-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__)}
for name in ['cycle-allocation-policy-candidate','cycle-allocation-policy-controls','cycle-allocation-policy-sanitizers','cycle-allocation-policy-generation','cycle-inline-generation','cycle-leaf-graph-generation']:
 paths.update(x for x in (base/name).rglob('*') if x.is_file())
for pattern in ['*cycle-allocation-policy*.py','*cycle-allocation-policy*.log','run-cycle-policy-sanitizers.py','*cycle-policy-sanitizers*.log','cycle-test-inputs.log','vm-profile-inputs.log']:
 paths.update(base.glob(pattern))
for name in ['Makefile.gnu']:
 paths.add(Path(name))
sha=lambda x:hashlib.sha256(x).hexdigest();entries=[];seen={}
for i,x in enumerate(sorted(paths)):
 raw=x.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{x.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(x),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
(dest/'manifest.json').write_text(json.dumps(dict(files=entries),indent=2)+'\n')
for x in entries:
 raw=(dest/x['artifact']).read_bytes();assert sha(raw)==x['compressed_sha256'] and sha(gzip.decompress(raw))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries))
