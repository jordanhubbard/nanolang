from pathlib import Path
import hashlib,json,shlex,subprocess,time
base=Path.cwd();old=Path('/home/jkh/Src/nanolang-callable-ownership');out=base/'.test_output/cycle-allocation-policy-candidate';opts={x.partition('=')[0]:x.partition('=')[2] for x in (base/'.test_output/cycle-test-inputs.log').read_text().splitlines() if x.startswith('CYCLE_TEST_')};cc=shlex.split(opts['CYCLE_TEST_CC']);flags=[*shlex.split(opts['CYCLE_TEST_CFLAGS']),'-I'+str(out),'-I'+str(base/'src/nanovm'),'-I'+str(base/'tests/nanovm'),'-include',str(out/'heap.h')];objects=shlex.split(opts['CYCLE_TEST_OBJECTS']);names=['heap','heap_cycles','vm'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();record=dict(sources={n:sha(out/n) for n in ['heap.c','heap_cycles.c','heap.h','vm.c','bstring_intrinsics.inc','test_vm.c']},steps=[],limits=['I preserve heap/VM structure definitions; the private header adds only the pressure helper declaration. I compare the same expanded actual unit driver under the production packed-only providers and private scheduling candidate.'])
def run(argv,label):
 argv=list(map(str,argv));start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:r=subprocess.run(argv,cwd=old,stdout=a,stderr=b,timeout=600)
 record['steps'].append(dict(label=label,argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-start));(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
baseline=[str(base/'.test_output/cycle-packed-leaf-repair/heap_cycles.o') if x=='obj/nanovm/heap_cycles.o' else x for x in objects]
run([*cc,*flags,'-o',out/'baseline-test-vm',out/'test_vm.c',*baseline,*shlex.split(opts['CYCLE_TEST_LDFLAGS'])],'link-baseline-tests');run([out/'baseline-test-vm'],'baseline-expanded-vm-tests')
for n in names:run([*cc,*flags,'-c',out/(n+'.c'),'-o',out/(n+'.o')],'compile-'+n)
for n in names:
 assert objects.count('obj/nanovm/'+n+'.o')==1
 objects=[str(out/(n+'.o')) if x=='obj/nanovm/'+n+'.o' else x for x in objects]
run([*cc,*flags,'-o',out/'test_vm',out/'test_vm.c',*objects,*shlex.split(opts['CYCLE_TEST_LDFLAGS'])],'link-candidate-tests');run([out/'test_vm'],'candidate-expanded-vm-tests');print('I passed all existing assertions and the bounded live-graph/automatic-cycle guard under both actual collector configurations.')
