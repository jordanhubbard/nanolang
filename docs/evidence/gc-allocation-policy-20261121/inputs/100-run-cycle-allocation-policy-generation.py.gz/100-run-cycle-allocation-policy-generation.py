from pathlib import Path
import json,os,shlex,signal,subprocess,sys,time,hashlib
base=Path.cwd();old=Path('/home/jkh/Src/nanolang-callable-ownership');src=base/'.test_output/cycle-allocation-policy-candidate';out=base/'.test_output/cycle-allocation-policy-generation';out.mkdir(exist_ok=False);sys.path.insert(0,str(old));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1.nvm']);opts={l.partition('=')[0]:l.partition('=')[2] for l in (base/'.test_output/vm-profile-inputs.log').read_text().splitlines() if l.startswith('PROFILE_')};tests={l.partition('=')[0]:l.partition('=')[2] for l in (base/'.test_output/cycle-test-inputs.log').read_text().splitlines() if l.startswith('CYCLE_TEST_')};cc=shlex.split(opts['PROFILE_CC']);flags=shlex.split(opts['PROFILE_CFLAGS']);extra=['-I'+str(src),'-I'+str(base/'src/nanovm'),'-I'+str(base/'tests/nanovm'),'-include',str(src/'heap.h')];record=dict(original_pin='74644c29f',base_checkout_pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources={n:digest(src/n) for n in ['heap.c','heap_cycles.c','heap.h','vm.c','bstring_intrinsics.inc','test_vm.c']},steps=[],limits=['I test a genuine private allocation-scheduling VM; source hashes identify its uncommitted delta. Heap/VM layouts, full trial-deletion edges, explicit collection and the4096-root minimum remain. I keep1800/30 budgets and never overwrite canonical products. I retain the initial generic-flags unit control; this VM unit uses the original strict binary64 target flags.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,env=None):
 argv=list(map(str,argv));entry=dict(label=label,argv=argv);record['steps'].append(entry);save();start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as c:
  p=subprocess.Popen(argv,cwd=old,env=env,stdout=a,stderr=c,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=1800)
  except BaseException as e:
   entry['error']=repr(e)
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
   entry['returncode']=p.wait();raise
  finally:entry['elapsed_seconds']=time.monotonic()-start;save()
 if entry['returncode']:raise RuntimeError(entry)
run([*cc,*flags,*extra,'-ffp-contract=off','-fno-fast-math','-c',src/'vm.c','-o',out/'vm-strict.o'],'compile-strict-vm')
replacements={'obj/nanovm/heap.o':src/'heap.o','obj/nanovm/heap_cycles.o':src/'heap_cycles.o','obj/nanovm/vm.o':out/'vm-strict.o'}
def substituted(text):
 objects=shlex.split(text)
 for key in replacements:assert objects.count(key)==1,key
 return [str(replacements.get(x,x)) for x in objects]
run([*cc,*flags,*extra,'-o',out/'test_vm',src/'test_vm.c',*substituted(tests['CYCLE_TEST_OBJECTS']),*shlex.split(tests['CYCLE_TEST_LDFLAGS'])],'link-strict-tests');run([out/'test_vm'],'strict-expanded-vm-tests')
vm=out/'nano_vm';run([*cc,*flags,'-o',vm,*substituted(opts['PROFILE_OBJECTS']),*shlex.split(opts['PROFILE_LDFLAGS'])],'link-candidate-vm');record['candidate_vm_sha256']=digest(vm);save()
env=b.guarded_environment();env.update(NANOLANG_BOOTSTRAP_NO_CC='1',NANO_COMPILER_PHASE_RECORDER=str(old/'.test_output/bootstrap-join-phase-recorder.py'),NANO_BOOTSTRAP_PHASE_FILE=str(out/'phases.jsonl'))
try:
 run([vm,old/'bin/nanoc_stage1.nvm','--','src_nano/nanoc_v06.nano','--emit-nvm','-o',out/'derived-stage2.nvm'],'actual-complete-generation',env)
 run([old/'bin/nano_vm','--verify-only',out/'derived-stage2.nvm'],'verify-complete-generation')
 record['raw_stage1_stage2_equal']=(out/'derived-stage2.nvm').read_bytes()==(old/'bin/nanoc_stage1.nvm').read_bytes();record['derived_module_sha256']=digest(out/'derived-stage2.nvm');record['host_closure_equal']=b.imports(out/'derived-stage2.nvm')==b.manifest['hosts'];save();assert record['raw_stage1_stage2_equal'] and record['host_closure_equal']
finally:
 b.check_inputs();b.check_artifacts(['nanoc_stage1.nvm']);record['unchanged_original_inputs']=True;record['unchanged_private_sources']=all(digest(src/n)==h for n,h in record['sources'].items());record['output_exists']=(out/'derived-stage2.nvm').exists();save();assert record['unchanged_private_sources']
print('I completed actual unchanged-budget raw self-generation, verification and byte equality with my private allocation-scheduling VM; fresh authoritative and paired acceptance remain separate.')
