from pathlib import Path
base=Path.cwd();out=base/'.test_output/cycle-allocation-policy-candidate';out.mkdir(exist_ok=False)
s=(base/'src/nanovm/heap_cycles.c').read_text()
needle='/* ── Suspect buffer ─────────────────────────────────────────────────────── */';assert s.count(needle)==1
insert='''/* I keep scheduling state after the root slots, preserving the heap layout. */
typedef struct {
    size_t allocation_mark;
    size_t allowance;
} CycleSchedule;

static CycleSchedule cycle_schedule(void **items, uint32_t capacity) {
    CycleSchedule result = {0};
    if (items) memcpy(&result, (char *)items + (size_t)capacity * sizeof(*items), sizeof result);
    return result;
}

static void cycle_schedule_store(void **items, uint32_t capacity, CycleSchedule value) {
    memcpy((char *)items + (size_t)capacity * sizeof(*items), &value, sizeof value);
}

void vm_gc_maybe_collect(VmHeap *heap) {
    if (!heap || heap->gc_running || heap->cycle_count < VM_GC_CYCLE_THRESHOLD || !heap->cycle_buf) return;
    CycleSchedule schedule = cycle_schedule(heap->cycle_buf, heap->cycle_capacity);
    size_t allocated = heap->stats.allocated;
    if (allocated < schedule.allocation_mark || allocated - schedule.allocation_mark >= schedule.allowance)
        vm_gc_collect_cycles(heap);
}

'''
s=s.replace(needle,insert+needle)
needle='''        void **grown = realloc(heap->cycle_buf, (size_t)next * sizeof(*grown));''';assert s.count(needle)==1
s=s.replace(needle,'''        size_t root_bytes = (size_t)next * sizeof(void *);
        if (next <= heap->cycle_capacity || root_bytes / sizeof(void *) != next ||
            root_bytes > SIZE_MAX - sizeof(CycleSchedule)) return;
        CycleSchedule schedule = cycle_schedule(heap->cycle_buf, heap->cycle_capacity);
        void **grown = realloc(heap->cycle_buf, (size_t)next * sizeof(*grown) + sizeof(CycleSchedule));''')
needle='        heap->cycle_capacity = next;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        cycle_schedule_store(grown, next, schedule);')
needle='''    if (!heap->gc_running && heap->cycle_count >= VM_GC_CYCLE_THRESHOLD)
        vm_gc_collect_cycles(heap);''';assert s.count(needle)==1;s=s.replace(needle,'    vm_gc_maybe_collect(heap);')
needle='    uint32_t count = heap->cycle_count;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    uint32_t capacity = heap->cycle_capacity;')
needle='''    free(buf);
    heap->cycles_collected += freed;''';assert s.count(needle)==1;s=s.replace(needle,'''    if (!heap->cycle_buf && heap->stats.num_objects) {
        /* I retain a small schedule carrier, never stale root membership. */
        void **trimmed = realloc(buf, 64 * sizeof(*buf) + sizeof(CycleSchedule));
        if (trimmed) { buf = trimmed; capacity = 64; }
        heap->cycle_buf = buf;
        heap->cycle_capacity = capacity;
    } else {
        free(buf);
    }
    if (heap->cycle_buf) {
        size_t retained = heap->stats.allocated >= heap->stats.freed
            ? heap->stats.allocated - heap->stats.freed : 0;
        CycleSchedule schedule = {heap->stats.allocated, retained / 4};
        cycle_schedule_store(heap->cycle_buf, heap->cycle_capacity, schedule);
    }
    heap->cycles_collected += freed;''')
(out/'heap_cycles.c').write_text(s)
s=(base/'src/nanovm/heap.h').read_text();needle='void vm_gc_cycle_buffer_free(VmHeap *heap);';assert s.count(needle)==1;s=s.replace(needle,'void vm_gc_maybe_collect(VmHeap *heap);\n'+needle);(out/'heap.h').write_text(s);assert s.replace('void vm_gc_maybe_collect(VmHeap *heap);\n','')==(base/'src/nanovm/heap.h').read_text()
s=(base/'src/nanovm/heap.c').read_text();needle='    heap->stats.num_objects++;';assert s.count(needle)==8;s=s.replace(needle,needle+'\n    vm_gc_maybe_collect(heap);')
needle='    a->capacity = new_cap;\n    return true;';assert s.count(needle)==1;s=s.replace(needle,'    a->capacity = new_cap;\n    vm_gc_maybe_collect(heap);\n    return true;')
needle='    free(old_entries);\n    return true;';assert s.count(needle)==1;s=s.replace(needle,'    free(old_entries);\n    vm_gc_maybe_collect(heap);\n    return true;');(out/'heap.c').write_text(s)
(out/'vm.c').write_bytes((base/'src/nanovm/vm.c').read_bytes())
s=(base/'src/nanovm/bstring_intrinsics.inc').read_text();needle='        if (values[0]->capacity > before) heap->stats.allocated += values[0]->capacity - before;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        vm_gc_maybe_collect(heap);');(out/'bstring_intrinsics.inc').write_text(s)
s=(base/'tests/nanovm/test_vm.c').read_text();needle='int main(void) {';assert s.count(needle)==1
stress='''static void test_automatic_cycles_with_large_live_graph(void) {
    VmHeap heap = {0};
    vm_heap_init(&heap);
    const uint32_t count = 65536;
    VmArray *graph = vm_array_new(&heap, TAG_STRUCT, count);
    ASSERT(graph, "I allocate my stable record graph");
    NanoValue root = val_array(graph);
    for (uint32_t i = 0; i < count; i++) {
        VmStruct *record = vm_struct_new(&heap, 0, 1);
        ASSERT(record, "I allocate a live record");
        record->fields[0] = val_int(i);
        NanoValue item = val_struct(record);
        ASSERT(vm_array_push(&heap, graph, item), "I retain each stable record");
        vm_release(&heap, item);
    }
    vm_gc_collect_cycles(&heap);
    size_t baseline = heap.stats.num_objects, peak = baseline;
    uint64_t before = heap.cycles_collected;
    for (uint32_t i = 0; i < count; i++) {
        VmArray *cycle = vm_array_new(&heap, TAG_ARRAY, 1);
        ASSERT(cycle, "I allocate an independent garbage cycle");
        NanoValue item = val_array(cycle);
        ASSERT(vm_array_push(&heap, cycle, item), "I close the garbage cycle");
        vm_release(&heap, item);
        vm_retain(&heap, root);
        vm_release(&heap, root);
        if (heap.stats.num_objects > peak) peak = heap.stats.num_objects;
    }
    bool automatic_progress = heap.cycles_collected - before >= count / 2;
    bool live = graph->header.ref_count == 1 && graph->length == count;
    for (uint32_t i = 0; i < count; i++) {
        NanoValue item = vm_array_get(graph, i);
        if (item.tag != TAG_STRUCT || item.as.sval->header.ref_count != 1 ||
            item.as.sval->fields[0].as.i64 != i) live = false;
    }
    vm_gc_collect_cycles(&heap);
    vm_release(&heap, root);
    vm_gc_collect_cycles(&heap);
    bool empty = !heap.stats.num_objects && heap.stats.allocated == heap.stats.freed;
    vm_heap_destroy(&heap);
    ASSERT(automatic_progress, "I reclaim garbage automatically during sustained allocation");
    ASSERT(peak <= baseline * 2 + 4096, "I bound retained objects beside the live graph");
    ASSERT(live, "I preserve every live record and its exact owner count");
    ASSERT(empty, "I reclaim the graph and all independent cycles");
}

'''
s=s.replace(needle,stress+needle+'\n    RUN_TEST(test_automatic_cycles_with_large_live_graph);');(out/'test_vm.c').write_text(s)
print(out)
