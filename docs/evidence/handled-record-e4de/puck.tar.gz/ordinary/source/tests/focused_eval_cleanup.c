#define main retained_full_eval_main
#include "test_eval.c"
#undef main
int main(void) {
 TEST(eval_handler_return_async_calls);
 TEST(eval_callable_projection_lifetimes);
 TEST(eval_struct_creation_and_access);
 TEST(eval_tuple_types);
 TEST(eval_effect_argument_lists);
 TEST(eval_handled_record_identity);
 puts("I completed the bounded evaluator cleanup controls.");
 return 0;
}
