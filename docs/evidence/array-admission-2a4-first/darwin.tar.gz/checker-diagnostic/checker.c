#include "nanolang.h"
#include <stdio.h>
int g_argc=0;char **g_argv=NULL;char g_project_root[4096]=".";const char *get_project_root(void){return g_project_root;}
int main(void){int n=0;Token *t=tokenize("fn probe(xs:array<int>)->void{(- xs) (% xs 2) (+ xs 1)} fn main()->int{return 0}",&n);if(!t)return 3;ASTNode *p=parse_program(t,n);if(!p){free_tokens(t,n);return 4;}Environment *e=create_environment();typecheck_set_current_file("exact-discarded-positive.nano");bool ok=type_check(p,e);fprintf(stderr,"CHECKER_RESULT=%d\n",ok);free_environment(e);free_ast(p);free_tokens(t,n);return ok?0:1;}
