$(info PROFILE_CC=$(CC))
$(info PROFILE_CFLAGS=$(CFLAGS))
$(info PROFILE_LDFLAGS=$(LDFLAGS) $(EXPORT_DYNAMIC_LDFLAGS))
$(info PROFILE_OBJECTS=$(NANOVM_OBJECTS) $(NANOISA_OBJECTS) $(COMMON_OBJECTS) $(RUNTIME_OBJECTS) $(OBJ_DIR)/nanovm/vmd_protocol.o $(OBJ_DIR)/nanovm/vmd_client.o $(OBJ_DIR)/nanovm/main.o $(FILE_CLI_OBJECT) $(FILE_PUBLIC_LIBRARY) lib/libnano_socket_runtime.a lib/libnano_services_runtime.a lib/libnano_websocket_runtime.a)
.PHONY: print-vm-profile-inputs
print-vm-profile-inputs:
	@:
