#include <time.h>
#include <stdlib.h>
#include <stdio.h>
volatile unsigned long sink;
int main(int argc,char **argv){struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);double limit=argc>1?atof(argv[1]):0.5;puts("I started my diagnostic CPU control.");fflush(stdout);do{for(unsigned i=0;i<10000;i++)sink+=i;clock_gettime(CLOCK_MONOTONIC,&now);}while(limit<0 || (now.tv_sec-start.tv_sec)+(now.tv_nsec-start.tv_nsec)*1e-9<limit);return 0;}
