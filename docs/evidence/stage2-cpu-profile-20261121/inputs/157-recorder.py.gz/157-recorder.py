#!/usr/bin/python3
import fcntl,json,os,sys,time
from pathlib import Path
phase=sys.argv[1]
with open(os.environ['NANO_BOOTSTRAP_PHASE_FILE'],'a') as f:
 fcntl.flock(f,fcntl.LOCK_EX);f.write(json.dumps(dict(phase=phase,mono_ns=time.monotonic_ns(),pid=os.getpid(),parent=os.getppid()))+'\n')
if phase=='typecheck-start':Path(os.environ['NANO_DIAGNOSTIC_TYPECHECK_MARKER']).touch()
