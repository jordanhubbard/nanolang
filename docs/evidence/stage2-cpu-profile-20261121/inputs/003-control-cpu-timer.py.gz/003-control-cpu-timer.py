from pathlib import Path
import json,os,signal,struct,subprocess,time
out=Path('.test_output/cpu-timer-control').resolve();out.mkdir(exist_ok=False);source=Path('.test_output/cpu-timer-sampler.c').resolve();helper=out/'sampler.so';subprocess.run(['cc','-Wall','-Wextra','-Werror','-std=c11','-O2','-g','-shared','-fPIC',str(source),'-o',str(helper),'-lrt'],check=True,timeout=60);binary=Path('.test_output/gprofng-control/spin').resolve();results=[]
for label,seconds in [('finite','0.5'),('terminated','-1')]:
 data=out/(label+'.bin');status=out/(label+'.json');env=dict(os.environ,LD_PRELOAD=str(helper),NANO_CPU_PROFILE_TARGET=str(binary),NANO_CPU_PROFILE_OUTPUT=str(data),NANO_CPU_PROFILE_STATUS=str(status));t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen([binary,seconds],env=env,stdout=a,stderr=b,start_new_session=True)
  try:code=p.wait(timeout=5 if label=='finite' else 0.8)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);code=p.wait(timeout=10)
 raw=data.read_bytes();assert len(raw)%32==0;rows=list(struct.iter_unpack('<QQQQ',raw));state=json.loads(status.read_text());assert state['enabled'] and all(r[2]==p.pid and r[3]==p.pid and r[1]>0 for r in rows);record=dict(label=label,pid=p.pid,elapsed_seconds=time.monotonic()-t,returncode=code,samples=len(rows),status=state);results.append(record);(out/'manifest.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True);assert len(rows)>=(35 if label=='finite' else 50)
