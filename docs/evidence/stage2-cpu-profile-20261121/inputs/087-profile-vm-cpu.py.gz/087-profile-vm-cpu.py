from pathlib import Path
import hashlib,json,os,queue,shutil,signal,struct,subprocess,sys,threading,time
old=Path('/home/jkh/Src/nanolang-callable-ownership');base=Path.cwd();out=(base/'.test_output/stage2-vm-cpu-profile').resolve();out.mkdir(exist_ok=False);sys.path.insert(0,str(old));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1.nvm']);vm=(old/'bin/nano_vm').resolve();helper=out/'sampler.so';shutil.copy2(base/'.test_output/cpu-timer-control/sampler.so',helper);shutil.copy2(base/'.test_output/cpu-timer-sampler.c',out/'sampler.c');record=dict(source_pin='74644c29f',vm_sha256=digest(vm),module_sha256=digest(old/'bin/nanoc_stage1.nvm'),helper_sha256=digest(helper),sample_format='four native little-endian uint64:monotonic_ns,pc,pid,main_tid',interval_ns=10000000,steps=[],limits=['I retain the original VM executable and add private preload signal instrumentation. I sample only its main thread CPU PCs; I change no opcode/authority code or system settings. I retain maps and sampling controls, stop30 wall-clock seconds after the actual typecheck marker and keep authoritative Stage2 acceptance separate.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def environment(data,status):
 env=b.guarded_environment();prior=env.get('LD_PRELOAD');env.update(NANOLANG_BOOTSTRAP_NO_CC='1',LD_PRELOAD=str(helper)+(':'+prior if prior else ''),NANO_CPU_PROFILE_TARGET=str(vm),NANO_CPU_PROFILE_OUTPUT=str(data),NANO_CPU_PROFILE_STATUS=str(status));return env
# I validate a new completion-file observer before the compiler workload.
ready=out/'observer-control.json';thread=threading.Timer(0.1,lambda:ready.write_text('{"ready":true}\n'));thread.start();expr='(wait-for (quote (exists "observer-control.json")) (quote ((timeout-ms 2000))))';r=subprocess.run(['toolscheme','--root',str(out),'-e',expr],cwd=out,capture_output=True,timeout=3);thread.join();(out/'observer-control.stdout').write_bytes(r.stdout);(out/'observer-control.stderr').write_bytes(r.stderr);assert r.returncode==0 and b'(satisfied #t)' in r.stdout;record['observer_control_passed']=True;save()
# I reuse the actual retained production-VM hello control, with exact tools pinned.
prior=json.loads((base/'.test_output/stage2-vm-function-profile/manifest.json').read_text());assert prior['base_vm_sha256']==digest(vm) and prior['compiler_module_sha256']==digest(old/'bin/nanoc_stage1.nvm')
env=environment(out/'control.bin',out/'control-status.json');env.pop('NANO_COMPILER_PHASE_RECORDER',None);env.pop('NANO_BOOTSTRAP_PHASE_FILE',None);argv=list(map(str,[vm,old/'bin/nanoc_stage1.nvm','--','examples/language/nl_hello.nano','--emit-nvm','-o',out/'control.nvm']));t=time.monotonic();r=subprocess.run(argv,cwd=old,env=env,capture_output=True,timeout=60);(out/'control.stdout').write_bytes(r.stdout);(out/'control.stderr').write_bytes(r.stderr);assert r.returncode==0;actual=(out/'control.nvm').read_bytes();reference=base/'.test_output/stage2-vm-function-profile/production.nvm';assert actual==reference.read_bytes();raw=(out/'control.bin').read_bytes();assert len(raw)%32==0 and len(raw)>=32;record['control']=dict(argv=argv,returncode=r.returncode,elapsed_seconds=time.monotonic()-t,raw_equal=True,reference=str(reference),sha256=digest(reference),samples=len(raw)//32,status=json.loads((out/'control-status.json').read_text()));save();b.check_inputs()
timer=out/'complete-window.py';timer.write_text('''import json,sys,time
from pathlib import Path
start=int(sys.argv[1]);pid=int(sys.argv[2]);target=Path(sys.argv[3]);time.sleep(max(0,(start+30000000000-time.monotonic_ns())/1e9));temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(dict(start_ns=start,end_ns=time.monotonic_ns(),pid=pid))+'\\n');temporary.replace(target)
''')
recorder=out/'recorder.py';recorder.write_text('''#!/usr/bin/python3
import fcntl,json,os,subprocess,sys,time
from pathlib import Path
phase=sys.argv[1];now=time.monotonic_ns();root=Path(os.environ['NANO_CPU_EXPERIMENT']);pid=int((root/'target.pid').read_text());assert Path('/proc/'+str(pid)+'/exe').resolve()==Path(os.environ['NANO_CPU_PROFILE_TARGET'])
with (root/'phases.jsonl').open('a') as f:
 fcntl.flock(f,fcntl.LOCK_EX);f.write(json.dumps(dict(phase=phase,mono_ns=now,pid=os.getpid(),target_pid=pid))+'\\n')
if phase=='typecheck-start':
 (root/'typecheck-start.maps').write_text(Path('/proc/'+str(pid)+'/maps').read_text())
 subprocess.Popen([sys.executable,str(root/'complete-window.py'),str(now),str(pid),str(root/'window-complete.json')],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
''');recorder.chmod(0o700)
env=environment(out/'samples.bin',out/'status.json');env.update(NANO_COMPILER_PHASE_RECORDER=str(recorder),NANO_CPU_EXPERIMENT=str(out));argv=list(map(str,[vm,old/'bin/nanoc_stage1.nvm','--','src_nano/nanoc_v06.nano','--emit-nvm','-o',out/'unqualified-output.nvm']));entry=dict(label='original-vm-private-cpu-observation',argv=argv);record['steps'].append(entry);save();started=time.monotonic()
with (out/'compile.stdout').open('wb') as a,(out/'compile.stderr').open('wb') as c,(out/'wait.stdout').open('wb') as wo,(out/'wait.stderr').open('wb') as we:
 p=subprocess.Popen(argv,cwd=old,env=env,stdout=a,stderr=c,start_new_session=True);entry['pid']=p.pid;(out/'target.pid').write_text(str(p.pid));save()
 expr='(wait-for (quote (exists "window-complete.json")) (quote ((timeout-ms 1800000))))';observer=subprocess.Popen(['toolscheme','--root',str(out),'-e',expr],cwd=out,stdout=wo,stderr=we,start_new_session=True);events=queue.Queue()
 def await_target():
  try:events.put(('target',p.wait(timeout=1800)))
  except subprocess.TimeoutExpired:events.put(('target-timeout',None))
 def await_observer():events.put(('observer',observer.wait()))
 left=threading.Thread(target=await_target,daemon=True);right=threading.Thread(target=await_observer,daemon=True);left.start();right.start();which,status=events.get(timeout=1805);entry['first_event']=[which,status]
 if which=='observer' and status==0 and '(satisfied #t)' in (out/'wait.stdout').read_text():
  event=json.loads((out/'window-complete.json').read_text());assert event['pid']==p.pid;entry['intentional_completed_window_stop']=True;entry['window']=event
 if p.poll() is None:
  (out/'stop.maps').write_text(Path(f'/proc/{p.pid}/maps').read_text());os.killpg(p.pid,signal.SIGTERM)
 try:entry['returncode']=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);entry['returncode']=p.wait()
 if observer.poll() is None:os.killpg(observer.pid,signal.SIGTERM)
 observer.wait();left.join(timeout=1);right.join(timeout=1);entry['elapsed_seconds']=time.monotonic()-started;save()
b.check_inputs();record['unchanged_authoritative_inputs']=True;save();print('I retained a bounded main-thread CPU observation with a completed-file observer and raw-equal original-VM control.')
