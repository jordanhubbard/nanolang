$(info CYCLE_TEST_CC=$(CC))
$(info CYCLE_TEST_CFLAGS=$(CFLAGS))
$(info CYCLE_TEST_LDFLAGS=$(LDFLAGS))
$(info CYCLE_TEST_OBJECTS=$(NANOVM_OBJECTS) $(NANOISA_OBJECTS) $(COMMON_OBJECTS) $(RUNTIME_OBJECTS))
.PHONY: print-cycle-test-inputs
print-cycle-test-inputs:
	@:
