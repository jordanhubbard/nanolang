from pathlib import Path
import hashlib,json,os,subprocess,sys,time,signal
old=Path('/home/jkh/Src/nanolang-callable-ownership');out=Path('.test_output/stage2-native-profile').resolve();out.mkdir(exist_ok=False)
sys.path.insert(0,str(old))
from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1','nanoc_stage1.nvm']);manifest=json.loads((b.work/'manifest.json').read_text());(out/'failed-bootstrap-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ('bootstrap-join-phases-linux.jsonl','bootstrap-join-phase-linux.log','bootstrap-join-phase-stage2-linux.log','bootstrap-phase-perf-control.stderr'):
 p=old/'.test_output'/name
 if p.exists():(out/name).write_bytes(p.read_bytes())
record=dict(source_pin='74644c29f',source_inputs=b.manifest['sources'],tools=b.manifest['tools'],hosts=b.manifest['hosts'],original_stage1_sha256=digest(old/'bin/nanoc_stage1'),steps=[],limits=['I profile an instrumented actual native Stage1 translation. I do not execute the timed-out NanoVM process, qualify Stage2 or change its budgets. Only generated compiler C is instrumented; runtime/shared providers retain their actual original bytes.'])
def run(argv,label,env=None):
 argv=list(map(str,argv));r=dict(label=label,argv=argv);record['steps'].append(r);(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');t=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(argv,cwd=old,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:r['returncode']=p.wait(timeout=1800)
  except BaseException as e:
   os.killpg(p.pid,signal.SIGKILL);p.wait();r['error']=repr(e);raise
  finally:
   r['elapsed_seconds']=time.monotonic()-t;(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 if r['returncode']:raise RuntimeError(r)
args=next(s['argv'] for s in manifest['steps'] if s['label']=='stage1-native').copy();binary=out/'nanoc-stage1-gprof';args[args.index('-o')+1]=str(binary);args.insert(1,'-pg');args.insert(2,'-g');record['generated_c_sha256']=digest(b.work/'stage1.c');run(args,'build-profile');record['profile_binary_sha256']=digest(binary)
env=b.guarded_environment();env.update(NANOLANG_BOOTSTRAP_NO_CC='1',GMON_OUT_PREFIX=str(out/'gmon'),NANO_COMPILER_PHASE_RECORDER=str(old/'.test_output/bootstrap-join-phase-recorder.py'),NANO_BOOTSTRAP_PHASE_FILE=str(out/'phases.jsonl'))
run([binary,'src_nano/nanoc_v06.nano','--emit-nvm','-o',out/'profile-product.nvm'],'profile-compiler',env)
b.check_inputs();run([old/'bin/nano_vm','--verify-only',out/'profile-product.nvm'],'verify-profile-product')
run(['gprof','-b',binary,*sorted(out.glob('gmon.*'))],'gprof')
record['raw_equals_stage1']=(out/'profile-product.nvm').read_bytes()==(old/'bin/nanoc_stage1.nvm').read_bytes();record['profile_product_sha256']=digest(out/'profile-product.nvm');(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('I retained a bounded actual instrumented native compiler profile; authoritative NanoVM Stage2 acceptance remains open.')
