from pathlib import Path
import json,os,signal,subprocess,time
out=Path('.test_output/gprofng-control').resolve();out.mkdir(exist_ok=False);source=out/'spin.c';source.write_text('''#include <time.h>
#include <stdlib.h>
#include <stdio.h>
volatile unsigned long sink;
int main(int argc,char **argv){struct timespec start,now;clock_gettime(CLOCK_MONOTONIC,&start);double limit=argc>1?atof(argv[1]):0.5;puts("I started my diagnostic CPU control.");fflush(stdout);do{for(unsigned i=0;i<10000;i++)sink+=i;clock_gettime(CLOCK_MONOTONIC,&now);}while(limit<0 || (now.tv_sec-start.tv_sec)+(now.tv_nsec-start.tv_nsec)*1e-9<limit);return 0;}
''');binary=out/'spin';subprocess.run(['cc','-O1','-g',str(source),'-o',str(binary)],check=True,timeout=60);records=[]
for label,seconds in [('finite','0.5'),('terminated','-1')]:
 exp=out/(label+'.er');argv=['gprofng','collect','app','-p','hi','-F','off','-a','usedldobjects','-o',str(exp),str(binary),seconds];r=dict(label=label,argv=argv);records.append(r);t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(argv,stdout=a,stderr=b,start_new_session=True)
  try:r['returncode']=p.wait(timeout=10 if label=='finite' else 0.8)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM);r['intentional_control_stop']=True;r['returncode']=p.wait(timeout=10)
  r['elapsed_seconds']=time.monotonic()-t
 command=['gprofng','display','text','-functions',str(exp)];d=subprocess.run(command,capture_output=True,timeout=60);(out/(label+'-functions.stdout')).write_bytes(d.stdout);(out/(label+'-functions.stderr')).write_bytes(d.stderr);r['display_returncode']=d.returncode;r['experiment_exists']=exp.is_dir();r['display_bytes']=len(d.stdout)
 (out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
 print(r,flush=True)
