from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('.test_output'); dest=Path('docs/evidence/stage2-cpu-profile-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
paths={Path(__file__)}
for name in ['stage2-vm-function-profile','stage2-vm-cpu-profile','stage2-native-profile','stage2-native-profile-control','cpu-timer-control','gprofng-control','cycle-packed-leaf-baseline','cycle-packed-leaf-repair','cycle-packed-leaf-sanitizers']:
 paths.update(p for p in (base/name).rglob('*') if p.is_file())
for name in ['profile-native-stage1.py','control-native-gprof.py','vm-function-sampler.c','profile-vm-functions.py','vm-profile-inputs.mk','vm-profile-inputs.log','analyze-vm-functions.py','gprofng-control.py','gprofng-help.log','cpu-timer-sampler.c','control-cpu-timer.py','profile-vm-cpu.py','analyze-vm-cpu.py','run-cycle-regression-repair.py','run-cycle-sanitizers.py','cycle-test-inputs.mk','cycle-test-inputs.log','vm-log-condition-control.log']:
 p=base/name
 if p.exists():paths.add(p)
paths.update([Path('src/nanovm/heap_cycles.c'),Path('tests/nanovm/test_vm.c')])
a=json.loads((base/'stage2-vm-cpu-profile/analysis.json').read_text());assert a['samples']==2997 and a['intentional_completed_window_stop']
assert '299243 passed, 0 failed' in (base/'cycle-packed-leaf-sanitizers/full-vm-tests.stdout').read_text()
sha=lambda b:hashlib.sha256(b).hexdigest(); entries=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);out=seen.get(h,dest/'inputs'/f'{i:03d}-{p.name}.gz')
 if h not in seen:out.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=out
 packed=out.read_bytes();entries.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
manifest=dict(original_pin='74644c29f',repair_pin='208441b46',retention_pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=entries,limits=['I preserve all failed observation controls and the dispatch observer overrun. The valid CPU result describes only the first30 seconds of typechecking. Full generation is a separate gate.'])
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in entries:
 b=(dest/x['artifact']).read_bytes();assert sha(b)==x['compressed_sha256'] and sha(gzip.decompress(b))==x['sha256']
print(len(entries),sum(x['bytes'] for x in entries),sum(p.stat().st_size for p in seen.values()))
