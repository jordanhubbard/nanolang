from pathlib import Path
import hashlib,json,os,queue,shlex,signal,subprocess,sys,threading,time
old=Path('/home/jkh/Src/nanolang-callable-ownership');base=Path.cwd();out=(base/'.test_output/stage2-vm-function-profile').resolve();out.mkdir(exist_ok=False);sys.path.insert(0,str(old))
from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(old,1800,30);b.load();b.check_artifacts(['nanoc_stage1.nvm']);record=dict(source_pin='74644c29f',steps=[],limits=['I use an explicitly instrumented private VM, not the authoritative VM. I sample at private deterministic pseudorandom dispatch intervals4096..12287, retain at most the last64 frames, and intentionally stop30 observed seconds after typecheck begins. I change no opcode/authority checks. Small-output equality is a control, not full interpreter equivalence or Stage2 acceptance.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(argv,label,env=None,timeout=600):
 argv=list(map(str,argv));entry=dict(label=label,argv=argv);record['steps'].append(entry);save();t=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.Popen(argv,cwd=old,env=env,stdout=stdout,stderr=stderr,start_new_session=True);entry['pid']=p.pid;save()
  try:entry['returncode']=p.wait(timeout=timeout)
  except BaseException as error:
   os.killpg(p.pid,signal.SIGKILL);p.wait();entry['error']=repr(error);raise
  finally:entry['elapsed_seconds']=time.monotonic()-t;save()
 if entry['returncode']:raise RuntimeError(entry)
opts={line.partition('=')[0]:line.partition('=')[2] for line in (base/'.test_output/vm-profile-inputs.log').read_text().splitlines() if line.startswith('PROFILE_')}
source=old/'src/nanovm/vm.c';text=source.read_text();needle='static VmResult vm_error(VmState *vm, VmResult err, const char *fmt, ...) {';assert text.count(needle)==1;text=text.replace(needle,(base/'.test_output/vm-function-sampler.c').read_text()+'\n'+needle)
needle='        frame->instruction_ip = vm->ip;\n        VmReferenceActivation *reference_context=';assert text.count(needle)==1;text=text.replace(needle,'        nano_diagnostic_sample(vm);\n'+needle);private_source=out/'vm.c';private_source.write_text(text)
record['source_sha256']=digest(source);record['instrumented_source_sha256']=digest(private_source);record['base_vm_sha256']=digest(old/'bin/nano_vm');record['compiler_module_sha256']=digest(old/'bin/nanoc_stage1.nvm');record['compiler_options']=opts
object_file=out/'vm.o';compiler=shlex.split(opts['PROFILE_CC']);flags=shlex.split(opts['PROFILE_CFLAGS']);flags += ['-ffp-contract=off','-fno-fast-math','-I'+str(old/'src/nanovm')]
run([*compiler,*flags,'-c',private_source,'-o',object_file],'build-instrumented-vm-object')
objects=shlex.split(opts['PROFILE_OBJECTS']);assert objects.count('obj/nanovm/vm.o')==1;record['link_input_sha256']={p:digest(old/p) for p in objects};objects=[str(object_file) if p=='obj/nanovm/vm.o' else p for p in objects];vm=out/'nano_vm';run([*compiler,*flags,'-o',vm,*objects,*shlex.split(opts['PROFILE_LDFLAGS'])],'link-instrumented-vm');record['instrumented_vm_sha256']=digest(vm);save()
recorder=out/'recorder.py';recorder.write_text('''#!/usr/bin/python3
import fcntl,json,os,sys,time
from pathlib import Path
phase=sys.argv[1]
with open(os.environ['NANO_BOOTSTRAP_PHASE_FILE'],'a') as f:
 fcntl.flock(f,fcntl.LOCK_EX);f.write(json.dumps(dict(phase=phase,mono_ns=time.monotonic_ns(),pid=os.getpid(),parent=os.getppid()))+'\\n')
if phase=='typecheck-start':Path(os.environ['NANO_DIAGNOSTIC_TYPECHECK_MARKER']).touch()
''');recorder.chmod(0o700)
for label,tool in [('production',old/'bin/nano_vm'),('instrumented',vm)]:
 env=b.guarded_environment();env.update(NANOLANG_BOOTSTRAP_NO_CC='1');env.pop('NANO_COMPILER_PHASE_RECORDER',None);env.pop('NANO_BOOTSTRAP_PHASE_FILE',None)
 if label=='instrumented':env['NANO_DIAGNOSTIC_SAMPLE_PATH']=str(out/'control-samples.jsonl')
 run([tool,old/'bin/nanoc_stage1.nvm','--','examples/language/nl_hello.nano','--emit-nvm','-o',out/(label+'.nvm')],label+'-control',env,60)
assert (out/'production.nvm').read_bytes()==(out/'instrumented.nvm').read_bytes();assert (out/'control-samples.jsonl').stat().st_size>0;record['control_raw_equal']=True;save();b.check_inputs()
run([old/'bin/nano_vm','--verify-only',out/'instrumented.nvm'],'verify-control',timeout=60)
run([old/'bin/nanoisa','dump',old/'bin/nanoc_stage1.nvm'],'actual-module-dump',timeout=60)
env=b.guarded_environment();env.update(NANOLANG_BOOTSTRAP_NO_CC='1',NANO_COMPILER_PHASE_RECORDER=str(recorder),NANO_BOOTSTRAP_PHASE_FILE=str(out/'phases.jsonl'),NANO_DIAGNOSTIC_SAMPLE_PATH=str(out/'samples.jsonl'),NANO_DIAGNOSTIC_TYPECHECK_MARKER=str(out/'typecheck-started'))
argv=list(map(str,[vm,old/'bin/nanoc_stage1.nvm','--','src_nano/nanoc_v06.nano','--emit-nvm','-o',out/'unqualified-output.nvm']));entry=dict(label='sample-actual-stage1-vm-compiler',argv=argv);record['steps'].append(entry);save();started=time.monotonic()
with (out/'sample.stdout').open('wb') as stdout,(out/'sample.stderr').open('wb') as stderr,(out/'wait.stdout').open('wb') as waitout,(out/'wait.stderr').open('wb') as waiterr:
 p=subprocess.Popen(argv,cwd=old,env=env,stdout=stdout,stderr=stderr,start_new_session=True);entry['pid']=p.pid;save()
 expr='(wait-for (quote (matches "samples.jsonl" "diagnostic_window_complete")) (quote ((timeout-ms 1800000))))'
 observer=subprocess.Popen(['toolscheme','--root',str(out),'-e',expr],cwd=out,stdout=waitout,stderr=waiterr,start_new_session=True)
 events=queue.Queue()
 def await_process():
  try:events.put(('process',p.wait(timeout=1800)))
  except subprocess.TimeoutExpired:events.put(('process-timeout',None))
 def await_observer():events.put(('observer',observer.wait()))
 a=threading.Thread(target=await_process,daemon=True);c=threading.Thread(target=await_observer,daemon=True);a.start();c.start();which,status=events.get(timeout=1805);entry['first_event']=[which,status]
 if which=='observer' and status==0 and '(satisfied #t)' in (out/'wait.stdout').read_text():entry['intentional_diagnostic_stop']=True
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
 try:entry['returncode']=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);entry['returncode']=p.wait()
 if observer.poll() is None:os.killpg(observer.pid,signal.SIGTERM)
 observer.wait();a.join(timeout=1);c.join(timeout=1);entry['elapsed_seconds']=time.monotonic()-started;save()
b.check_inputs();record['unchanged_authoritative_inputs']=True;save();print('I retained a bounded private VM sample and its raw-equal actual production-VM control.')
