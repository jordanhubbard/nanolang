/* I collect diagnostic samples only; I do not change opcode or authority work. */
#include <unistd.h>
static void nano_diagnostic_sample(VmState *vm) {
    static unsigned remaining = 8192, rng = 0x9e3779b9u;
    static int initialized;
    static FILE *output;
    static const char *marker;
    static uint64_t observed, phase_start;
    static int completed;
    if (!initialized) {
        const char *path = getenv("NANO_DIAGNOSTIC_SAMPLE_PATH");
        marker = getenv("NANO_DIAGNOSTIC_TYPECHECK_MARKER");
        if (path && *path) output = fopen(path, "a");
        initialized = 1;
    }
    if (!output || --remaining) return;
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    remaining = 4096 + (rng & 8191);
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now)) return;
    uint64_t ns = (uint64_t)now.tv_sec * 1000000000u + (uint64_t)now.tv_nsec;
    if (!phase_start && marker && access(marker, F_OK) == 0) phase_start = ns;
    fprintf(output, "{\"pid\":%ld,\"mono_ns\":%llu,\"fn\":%u,\"ip\":%u,\"module\":\"%p\",\"depth\":%u,\"frames\":[",
        (long)getpid(), (unsigned long long)ns, vm->current_fn, vm->ip,
        (const void *)vm->module, vm->frame_count);
    uint32_t begin = vm->frame_count > 64 ? vm->frame_count - 64 : 0;
    for (uint32_t i = begin; i < vm->frame_count; i++) {
        const VmCallFrame *frame = &vm->frames[i];
        fprintf(output, "%s[%u,%u,\"%p\"]", i == begin ? "" : ",",
            frame->fn_idx, frame->instruction_ip, (const void *)frame->module);
    }
    fputs("]}\n", output);
    if (phase_start && ns - phase_start >= UINT64_C(30000000000) && !completed) {
        fprintf(output, "{\"diagnostic_window_complete\":true,\"pid\":%ld,\"mono_ns\":%llu}\n",
            (long)getpid(), (unsigned long long)ns);
        completed = 1;
        fflush(output);
    }
    if ((++observed & 127u) == 1) fflush(output);
}
