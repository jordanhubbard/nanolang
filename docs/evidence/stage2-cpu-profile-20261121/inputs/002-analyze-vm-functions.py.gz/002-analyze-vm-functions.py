from pathlib import Path
import collections,json,shlex
p=Path('.test_output/stage2-vm-function-profile');meta=json.loads((p/'manifest.json').read_text());pid=meta['steps'][-1]['pid'];names=[shlex.split(line)[1] for line in (p/'actual-module-dump.stdout').read_text().splitlines() if line.startswith('.function ')]
phases=[json.loads(l) for l in (p/'phases.jsonl').read_text().splitlines()];start=next(r['mono_ns'] for r in phases if r['phase']=='typecheck-start');end=start+30_000_000_000;raw=p/'samples.jsonl';times=[];exclusive=collections.Counter();inclusive=collections.Counter();buckets={};total=0;tail=0;completion=None
with raw.open('rb') as f:
 while True:
  line=f.readline()
  if not line:break
  try:r=json.loads(line)
  except json.JSONDecodeError:
   assert not line.endswith(b'\n') and f.tell()==raw.stat().st_size;tail+=1;continue
  if r.get('diagnostic_window_complete'):completion=r;continue
  assert r['pid']==pid;total+=1
  if not start<=r['mono_ns']<=end:continue
  assert 0<=r['fn']<len(names);times.append(r['mono_ns']);exclusive[r['fn']]+=1
  for fn in {frame[0] for frame in r['frames'] if frame[2]==r['module']}:inclusive[fn]+=1
  buckets[(r['mono_ns']-start)//10_000_000]=r
assert completion and len(times)>100
# I use the last observed checkpoint in each occupied10ms bin, not elapsed-time attribution.
be=collections.Counter(r['fn'] for r in buckets.values());bi=collections.Counter()
for r in buckets.values():
 for fn in {frame[0] for frame in r['frames'] if frame[2]==r['module']}:bi[fn]+=1
rank=lambda c:[dict(fn=fn,name=names[fn],count=count) for fn,count in c.most_common(35)]
seq=[start,*times,end];report=dict(pid=pid,window_start_ns=start,window_end_ns=end,window_seconds=30,total_complete_sample_records=total,window_samples=len(times),occupied_10ms_bins=len(buckets),possible_10ms_bins=3000,max_checkpoint_gap_ms=max(b-a for a,b in zip(seq,seq[1:]))/1e6,trailing_incomplete_records=tail,completion=completion,exclusive_dispatch_checkpoints=rank(exclusive),inclusive_dispatch_checkpoints=rank(inclusive),exclusive_observed_bins=rank(be),inclusive_observed_bins=rank(bi),limits=['I sample dispatch checkpoints, not asynchronous CPU time. Occupied time bins retain observed checkpoints only; gaps are not attributed. Frame inclusion deduplicates recursive function IDs and retains at most64 deepest frames. Extra data after30 seconds is retained but excluded after an observer overrun.'])
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('exclusive_dispatch_checkpoints','inclusive_dispatch_checkpoints')},indent=2)[:9500])
