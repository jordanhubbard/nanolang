import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve()
PROVIDERS = Path(sys.argv[2]).resolve()
OUT = Path(sys.argv[3]).resolve()
OUT.mkdir(exist_ok=False)

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def digest(path):
    data = Path(path).read_bytes()
    return dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

runner = load('retained_runner', HERE / 'runner.py')
fixture = load('retained_effect_fixture', HERE / 'fixture.py')
fixture.ROOT = ROOT
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == 'a2ef6eaddc3613151ef72ede0ecb391703f74122'
sources = json.loads((PROVIDERS / 'source-initial.json').read_text())
tools = json.loads((PROVIDERS / 'tools-initial.json').read_text())

def verify(mapping):
    actual = {name: digest(name) for name in mapping}
    assert all(actual[name] == {key: row[key] for key in ('sha256', 'bytes')}
               for name, row in mapping.items())
    return actual

save('sources-before.json', verify(sources))
save('tools-before.json', verify(tools))
products = {str(p): digest(p) for folder in ('bin', 'obj', 'lib')
            for p in (ROOT / folder).rglob('*') if p.is_file()}
save('providers-before.json', products)
save('scope.json', dict(production='a2ef6eaddc3613151ef72ede0ecb391703f74122',
    fixture='a522b2fd8', runner='99a055f5d:tests/native_sdk_runner.py',
    scope='All four actual effect methods, Cseed native and C-producer NanoVM. Existing fixture assertions and 60s/10s command deadlines retained; only temporary-directory retention and bounded command supervision are adapted.',
    inputs={str(p): digest(p) for p in HERE.glob('*.py')}))

class RetainedDirectory:
    def __init__(self, prefix):
        self.name = tempfile.mkdtemp(prefix=prefix, dir=OUT)
    def __enter__(self):
        return self.name
    def __exit__(self, *args):
        return False

serial = 0
def command(argv, cwd, capture_output, timeout):
    global serial
    assert capture_output and timeout in (10, 60)
    serial += 1
    out, err, status = runner.run(OUT, f'command-{serial:03}', argv, cwd,
        extra={'NANO_SDK_MIN_FREE_BYTES': str(2 * 1024**3),
               'NANOLANG_SDK_ROOT': str(ROOT), 'NANO_MODULE_PATH': str(ROOT / 'modules'),
               'NANO_BUILD_CACHE': str(ROOT / 'obj/module_cache')},
        timeout=timeout, track_descendants=True)
    return subprocess.CompletedProcess(argv, status['returncode'], out, err)

fixture.tempfile = types.SimpleNamespace(TemporaryDirectory=RetainedDirectory)
fixture.subprocess = types.SimpleNamespace(run=command)
suite = unittest.defaultTestLoader.loadTestsFromModule(fixture)
assert suite.countTestCases() == 4
result = unittest.TextTestRunner(verbosity=2, failfast=True).run(suite)
save('sources-after.json', verify(sources))
save('tools-after.json', verify(tools))
after = {name: digest(name) for name in products}
save('providers-after.json', after)
assert after == products
save('artifacts.json', {str(p.relative_to(OUT)): digest(p) for p in OUT.rglob('*') if p.is_file()})
save('terminal.json', dict(passed=result.wasSuccessful(), tests=result.testsRun,
    commands=serial, errors=len(result.errors), failures=len(result.failures)))
sys.exit(0 if result.wasSuccessful() else 1)
