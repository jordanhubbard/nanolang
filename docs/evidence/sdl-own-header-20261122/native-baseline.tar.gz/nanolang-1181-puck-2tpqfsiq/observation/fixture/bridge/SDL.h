#ifndef NANO_OWN_HEADER_SDL_H
#define NANO_OWN_HEADER_SDL_H
typedef unsigned int Uint32;
Uint32 SDL_GetTicks(void);
#endif
