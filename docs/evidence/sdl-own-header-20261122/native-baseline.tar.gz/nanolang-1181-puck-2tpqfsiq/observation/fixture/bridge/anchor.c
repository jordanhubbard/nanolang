#include "SDL.h"
Uint32 SDL_GetTicks(void) { return 42; }
