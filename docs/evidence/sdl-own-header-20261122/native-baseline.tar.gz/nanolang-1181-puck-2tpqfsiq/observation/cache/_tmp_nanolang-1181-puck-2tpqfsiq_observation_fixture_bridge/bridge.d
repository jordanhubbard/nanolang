/tmp/nanolang-1181-puck-2tpqfsiq/observation/cache/_tmp_nanolang-1181-puck-2tpqfsiq_observation_fixture_bridge/bridge.o: \
 /tmp/nanolang-1181-puck-2tpqfsiq/observation/fixture/bridge/anchor.c \
 /tmp/nanolang-1181-puck-2tpqfsiq/observation/fixture/bridge/SDL.h
