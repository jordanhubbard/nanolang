"""I observe a native C-backed module's own declared header without SDL installation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
compiler=Path(sys.argv[1]).resolve(strict=True);root=Path(sys.argv[2]).resolve(strict=True);out=Path(sys.argv[3]).resolve();out.mkdir(parents=True,exist_ok=False)
work=out/'fixture';work.mkdir();module=work/'bridge';module.mkdir()
(module/'SDL.h').write_text('#ifndef NANO_OWN_HEADER_SDL_H\n#define NANO_OWN_HEADER_SDL_H\ntypedef unsigned int Uint32;\nUint32 SDL_GetTicks(void);\n#endif\n')
(module/'anchor.c').write_text('#include "SDL.h"\nUint32 SDL_GetTicks(void) { return 42; }\n')
(module/'bridge.nano').write_text('module bridge\nextern fn SDL_GetTicks() -> int\npub fn answer()->int{return 42}\nshadow answer{assert (== (answer) 42)}\n')
(module/'module.json').write_text(json.dumps({'name':'bridge','headers':['SDL.h'],'c_sources':['anchor.c'],'include_dirs':['.']}))
source=work/'main.nano';source.write_text('module "bridge/bridge.nano" as bridge\nfn main()->int{assert (== (bridge.answer) 42) return 0}\nshadow main{assert (== (main) 0)}\n')
cmd=[str(compiler),str(source),'--keep-c','-o',str(work/'program')];env=dict(os.environ,NANO_BUILD_CACHE=str(out/'cache'))
r=subprocess.run(cmd,cwd=work,env=env,capture_output=True,timeout=60)
(out/'compile.stdout').write_bytes(r.stdout);(out/'compile.stderr').write_bytes(r.stderr)
report={'compiler':str(compiler),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'argv':cmd,'cwd':str(work),'returncode':r.returncode,'scope':'I observe this exact native image; this diagnostic alone establishes no source pin or release acceptance.'}
if r.returncode==0:
 run=subprocess.run([str(work/'program')],cwd=work,capture_output=True,timeout=10);report['execution_returncode']=run.returncode;(out/'run.stdout').write_bytes(run.stdout);(out/'run.stderr').write_bytes(run.stderr)
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
