
#include "nanoisa/socket_indirect_public.h"
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>
extern NvmSocketIndirectExecutionReport nvm_socket_indirect_program_source(NvmSocketHostGrant *,const NvmSocketIndirectOptions *,NvmSocketScalar *);
int main(void) {
    NvmSocketHostGrant *grant=NULL;
    assert(nvm_socket_host_grant_create_tcp_connections(&grant)==NVM_SOCKET_HOST_OK);
    NvmSocketIndirectOptions options={1,100000};NvmSocketScalar scalar={0};
    unsigned before=0,after=0;
    for(int i=0;i<1024;i++)before+=fcntl(i,F_GETFD)!=-1;
    NvmSocketIndirectExecutionReport denied=nvm_socket_indirect_program_source(NULL,&options,&scalar);
    assert(denied.runtime.status==NVM_SOCKET_RUNTIME_INVALID && !denied.runtime.acquired);
    NvmSocketIndirectExecutionReport report=nvm_socket_indirect_program_source(grant,&options,&scalar);
    for(int i=0;i<1024;i++)after+=fcntl(i,F_GETFD)!=-1;
    assert(before==after);
    printf("EXEC %u VALUE %lld\n",report.runtime.status,(long long)scalar.value);
    assert(!report.runtime.cleanup.cleanup_failures);
    assert(nvm_socket_host_grant_destroy(&grant)==NVM_SOCKET_HOST_OK);
    return 0;
}
