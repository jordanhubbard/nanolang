
#include "nanoisa/file_cyclic_public.h"
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>
extern NvmFileCyclicExecutionReport nvm_file_cyclic_program_source(NvmFileHostGrant *,const NvmFileCyclicOptions *,NvmFileScalar *);
int main(void) {
    NvmFileHostGrant *grant=NULL;
    assert(nvm_file_host_grant_create_temporary_files(&grant)==NVM_FILE_HOST_OK);
    NvmFileCyclicOptions options={1,100000};NvmFileScalar scalar={0};
    unsigned before=0,after=0;
    for(int i=0;i<1024;i++)before+=fcntl(i,F_GETFD)!=-1;
    NvmFileCyclicExecutionReport denied=nvm_file_cyclic_program_source(NULL,&options,&scalar);
    assert(denied.runtime.status==NVM_FILE_RUNTIME_INVALID && !denied.runtime.acquired);
    NvmFileCyclicExecutionReport report=nvm_file_cyclic_program_source(grant,&options,&scalar);
    for(int i=0;i<1024;i++)after+=fcntl(i,F_GETFD)!=-1;
    assert(before==after);
    printf("EXEC %u VALUE %lld\n",report.runtime.status,(long long)scalar.value);
    assert(!report.runtime.cleanup.cleanup_failures);
    assert(nvm_file_host_grant_destroy(&grant)==NVM_FILE_HOST_OK);
    return 0;
}
