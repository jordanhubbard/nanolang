# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h" 2


# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h"
typedef struct {
    uint32_t revision;
    
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h"
        allow_connections,allow_lookup;
    uint32_t max_timeout_ms;
    const char *resolver_helper;
} NvmWebSocketHostPolicy;

typedef struct NvmWebSocketHostGrant NvmWebSocketHostGrant;
typedef enum {
    NVM_WEBSOCKET_HOST_OK = 0,
    NVM_WEBSOCKET_HOST_INVALID = 1,
    NVM_WEBSOCKET_HOST_MEMORY = 2,
    NVM_WEBSOCKET_HOST_STATE = 3,
    NVM_WEBSOCKET_HOST_UNRESOLVED = 4,
    NVM_WEBSOCKET_HOST_BUSY = 5
} NvmWebSocketHostStatus;
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant.h"
NvmWebSocketHostStatus nvm_websocket_host_grant_create(const NvmWebSocketHostPolicy *,NvmWebSocketHostGrant **out);

NvmWebSocketHostStatus nvm_websocket_host_grant_revoke(NvmWebSocketHostGrant *grant);


NvmWebSocketHostStatus nvm_websocket_host_grant_destroy(NvmWebSocketHostGrant **inout);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
typedef struct {
    uint32_t imports[4u];
    uint32_t layouts[7u];
} NvmWebSocketNominalBindings;
NvmServiceResult nvm_websocket_nominal_check(const NvmWebSocketNominalBindings *);

NvmServiceResult nvm_websocket_nominal_decode(const uint8_t *,size_t,NvmWebSocketNominalBindings *);


NvmServiceResult nvm_websocket_nominal_encode(const NvmWebSocketNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_WEBSOCKET_NOMINAL_DESCRIBED, NVM_WEBSOCKET_NOMINAL_INVALID,
    NVM_WEBSOCKET_NOMINAL_LIMIT, NVM_WEBSOCKET_NOMINAL_MEMORY
} NvmWebSocketNominalStatus;
typedef enum {
    NVM_WEBSOCKET_CATEGORY_UNKNOWN, NVM_WEBSOCKET_CATEGORY_CONN,
    NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT, NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT,
    NVM_WEBSOCKET_CATEGORY_RECORD
} NvmWebSocketCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmWebSocketCategory category;
} NvmWebSocketNominalLayout;
typedef struct NvmWebSocketNominalPlan NvmWebSocketNominalPlan;




NvmWebSocketNominalStatus nvm_websocket_nominal_plan(const NvmModule *,NvmWebSocketNominalPlan **);
void nvm_websocket_nominal_plan_free(NvmWebSocketNominalPlan *);



# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_websocket_nominal_layout_count(const NvmWebSocketNominalPlan *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_layout(const NvmWebSocketNominalPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_type(const NvmWebSocketNominalPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_source(const NvmWebSocketNominalPlan *,uint8_t,uint32_t,NvmWebSocketNominalLayout *);

# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_import(const NvmWebSocketNominalPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 2
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
typedef enum {
    NVM_WEBSOCKET_FLOW_OK, NVM_WEBSOCKET_FLOW_INVALID, NVM_WEBSOCKET_FLOW_UNRESOLVED,
    NVM_WEBSOCKET_FLOW_LIMIT, NVM_WEBSOCKET_FLOW_MEMORY
} NvmWebSocketFlowStatus;
typedef struct NvmWebSocketFlowDeclarations NvmWebSocketFlowDeclarations;
typedef struct NvmWebSocketFlowState NvmWebSocketFlowState;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_index, catalog_ordinal;
    NvmWebSocketCategory category;
} NvmWebSocketFlowDeclaration;
typedef struct {
    uint16_t parameters, locals;
    uint8_t result_count;
    NvmWebSocketFlowDeclaration result;
} NvmWebSocketFlowFunction;
typedef enum {
    NVM_WEBSOCKET_FLOW_ARM_NONE, NVM_WEBSOCKET_FLOW_ARM_UNKNOWN,
    NVM_WEBSOCKET_FLOW_ARM_OK, NVM_WEBSOCKET_FLOW_ARM_ERROR
} NvmWebSocketFlowArm;
typedef struct {
    NvmWebSocketFlowDeclaration type;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
        initialized;
    uint64_t owner;
    NvmWebSocketFlowArm arm;
} NvmWebSocketFlowValue;
typedef struct {
    
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
        live, formal;
    uint16_t local;
    uint64_t owner, identity, region;
    
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
   _Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
        shared;
} NvmWebSocketFlowReference;
typedef struct {
    uint16_t stack, regions, owners, references;
    uint64_t cleanup_obligations;
    uint16_t obligations;
    
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
   _Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
        reachable;
} NvmWebSocketFlowCounts;



typedef enum { NVM_WEBSOCKET_FLOW_SERVICE, NVM_WEBSOCKET_FLOW_CALL } NvmWebSocketFlowObligationKind;
typedef enum { NVM_WEBSOCKET_FLOW_INPUT_NONE, NVM_WEBSOCKET_FLOW_INPUT_PRESERVED,
               NVM_WEBSOCKET_FLOW_INPUT_CONSUMED } NvmWebSocketFlowInputState;
enum {
    NVM_WEBSOCKET_FLOW_CHECK_BINDING=1u, NVM_WEBSOCKET_FLOW_CHECK_INVOCATION=2u,
    NVM_WEBSOCKET_FLOW_CHECK_LIVENESS=4u, NVM_WEBSOCKET_FLOW_CHECK_RIGHTS=8u,
    NVM_WEBSOCKET_FLOW_CHECK_BORROW=16u, NVM_WEBSOCKET_FLOW_CHECK_BYTE=32u,
    NVM_WEBSOCKET_FLOW_CHECK_CALLEE=64u, NVM_WEBSOCKET_FLOW_CHECK_CLEANUP=128u,
    NVM_WEBSOCKET_FLOW_CHECK_RESULT=256u, NVM_WEBSOCKET_FLOW_CHECK_TIMEOUT=1024u
};
typedef struct {
    NvmWebSocketFlowObligationKind kind;
    uint32_t site, target, checks, required_rights, acquired_rights;
    uint16_t parameters, owned_inputs, borrowed_inputs;
    uint8_t result_count;
    NvmWebSocketFlowDeclaration result;
    NvmWebSocketFlowInputState outcomes[2];
} NvmWebSocketFlowObligation;




NvmWebSocketFlowStatus nvm_websocket_flow_declarations(const NvmModule *, NvmWebSocketFlowDeclarations **out);
void nvm_websocket_flow_declarations_free(NvmWebSocketFlowDeclarations *);

# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_function(const NvmWebSocketFlowDeclarations *, uint32_t, NvmWebSocketFlowFunction *);

# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_declaration(const NvmWebSocketFlowDeclarations *, uint32_t, uint16_t,
                             NvmWebSocketFlowDeclaration *);


NvmWebSocketFlowStatus nvm_websocket_flow_state(NvmWebSocketFlowDeclarations *, uint32_t, NvmWebSocketFlowState **out);
void nvm_websocket_flow_state_free(NvmWebSocketFlowState *);

# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_local(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowValue *);

# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_stack(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowValue *);

# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_reference(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowReference *);

# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_counts(const NvmWebSocketFlowState *, NvmWebSocketFlowCounts *);

# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
_Bool 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
    nvm_websocket_flow_obligation(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowObligation *);
NvmWebSocketFlowStatus nvm_websocket_flow_clone(const NvmWebSocketFlowState *, NvmWebSocketFlowState **out);

NvmWebSocketFlowStatus nvm_websocket_flow_refine(const NvmWebSocketFlowState *, uint16_t local,
                                     NvmWebSocketFlowState **ok, NvmWebSocketFlowState **error);
NvmWebSocketFlowStatus nvm_websocket_flow_join(NvmWebSocketFlowState *, const NvmWebSocketFlowState *, 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h" 3 4
                                                                                                      _Bool 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow.h"
                                                                                                           *changed);



NvmWebSocketFlowStatus nvm_websocket_flow_push_scalar(NvmWebSocketFlowState *, uint8_t);
NvmWebSocketFlowStatus nvm_websocket_flow_load(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_store(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_dup(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_pop(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_clear_copy(NvmWebSocketFlowState *, uint16_t);


NvmWebSocketFlowStatus nvm_websocket_flow_construct(NvmWebSocketFlowState *, uint32_t catalog, uint16_t variant);
NvmWebSocketFlowStatus nvm_websocket_flow_field(NvmWebSocketFlowState *, uint16_t field);
NvmWebSocketFlowStatus nvm_websocket_flow_take_result(NvmWebSocketFlowState *, uint16_t local, NvmWebSocketFlowArm);



NvmWebSocketFlowStatus nvm_websocket_flow_service(NvmWebSocketFlowState *, uint32_t site, uint32_t import,
                                      uint16_t reference);




NvmWebSocketFlowStatus nvm_websocket_flow_call(NvmWebSocketFlowState *, uint32_t site, uint32_t function,
                                   const uint16_t *references, uint16_t count);
NvmWebSocketFlowStatus nvm_websocket_flow_move(NvmWebSocketFlowState *, uint16_t from, uint16_t to);
NvmWebSocketFlowStatus nvm_websocket_flow_take(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_put(NvmWebSocketFlowState *, uint16_t);

NvmWebSocketFlowStatus nvm_websocket_flow_drop_local(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_drop_stack(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_region_begin(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_region_end(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_borrow(NvmWebSocketFlowState *, uint16_t local, uint16_t reference);
NvmWebSocketFlowStatus nvm_websocket_flow_borrow_shared(NvmWebSocketFlowState *,uint16_t local,uint16_t reference);
NvmWebSocketFlowStatus nvm_websocket_flow_end_borrow(NvmWebSocketFlowState *, uint16_t reference);



NvmWebSocketFlowStatus nvm_websocket_flow_can_exit(const NvmWebSocketFlowState *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
typedef struct NvmWebSocketCodePlan NvmWebSocketCodePlan;
typedef struct {
    uint32_t byte_offset;
    DecodedInstruction decoded;
    uint16_t successors[2];
    uint8_t successor_count;
    uint16_t call_references[256u];
    uint32_t catalog_ordinal;
} NvmWebSocketCodeInstruction;
typedef struct {
    uint32_t code_offset, code_length;
    uint16_t instruction_count;
    NvmWebSocketFlowFunction declaration;
} NvmWebSocketCodeFunction;
NvmWebSocketFlowStatus nvm_websocket_code_prepare(const NvmModule *, NvmWebSocketCodePlan **out);
void nvm_websocket_code_free(NvmWebSocketCodePlan *);
uint32_t nvm_websocket_code_function_count(const NvmWebSocketCodePlan *);


# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
    nvm_websocket_code_function(const NvmWebSocketCodePlan *, uint32_t, NvmWebSocketCodeFunction *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
    nvm_websocket_code_local(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                         NvmWebSocketFlowDeclaration *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
    nvm_websocket_code_instruction(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                               NvmWebSocketCodeInstruction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
    nvm_websocket_code_instruction_order(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                                     uint16_t *);


# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_code.h"
    nvm_websocket_code_function_order(const NvmWebSocketCodePlan *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 2




typedef struct NvmWebSocketBodyReport NvmWebSocketBodyReport;
typedef enum {
    NVM_WEBSOCKET_BODY_CLEANUP_NORMAL, NVM_WEBSOCKET_BODY_CLEANUP_DROP_LOCAL,
    NVM_WEBSOCKET_BODY_CLEANUP_DROP_STACK, NVM_WEBSOCKET_BODY_CLEANUP_ASSERT,
    NVM_WEBSOCKET_BODY_CLEANUP_RETURN, NVM_WEBSOCKET_BODY_CLEANUP_CALL,
    NVM_WEBSOCKET_BODY_CLEANUP_SERVICE
} NvmWebSocketBodyCleanup;
typedef struct {
    
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h"
        reachable, exit_checked, refinement, has_obligation;
    uint16_t input_stack, output_stack, cleanup_local;
    NvmWebSocketBodyCleanup cleanup;
    uint32_t discharged_checks, pending_checks;
    NvmWebSocketFlowObligation obligation;
} NvmWebSocketBodyInstruction;
NvmWebSocketFlowStatus nvm_websocket_body_analyze(const NvmModule *, NvmWebSocketBodyReport **out);
void nvm_websocket_body_free(NvmWebSocketBodyReport *);
uint32_t nvm_websocket_body_function_count(const NvmWebSocketBodyReport *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h"
    nvm_websocket_body_function(const NvmWebSocketBodyReport *, uint32_t, NvmWebSocketCodeFunction *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h"
    nvm_websocket_body_local(const NvmWebSocketBodyReport *, uint32_t, uint16_t, NvmWebSocketFlowDeclaration *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_body.h"
    nvm_websocket_body_instruction(const NvmWebSocketBodyReport *, uint32_t, uint16_t,
                              NvmWebSocketCodeInstruction *, NvmWebSocketBodyInstruction *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 2


typedef struct NvmWebSocketHostedPlan NvmWebSocketHostedPlan;
typedef struct {
    uint32_t entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t allocation_bound;
} NvmWebSocketHostedStartup;
typedef struct {
    NvmWebSocketCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
} NvmWebSocketHostedFunction;






NvmWebSocketFlowStatus nvm_websocket_hosted_prepare(const uint8_t *,size_t,NvmWebSocketHostedPlan **);
void nvm_websocket_hosted_free(NvmWebSocketHostedPlan *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_startup(const NvmWebSocketHostedPlan *,NvmWebSocketHostedStartup *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_function(const NvmWebSocketHostedPlan *,uint32_t,NvmWebSocketHostedFunction *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_local(const NvmWebSocketHostedPlan *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_instruction(const NvmWebSocketHostedPlan *,uint32_t,uint16_t,
                                NvmWebSocketCodeInstruction *,NvmWebSocketBodyInstruction *);


# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_type(const NvmWebSocketHostedPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_import(const NvmWebSocketHostedPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 2


typedef struct NlWsTransport NlWsTransport;
typedef enum {
    NL_WS_TRANSPORT_OK, NL_WS_TRANSPORT_ARGUMENT, NL_WS_TRANSPORT_RIGHTS,
    NL_WS_TRANSPORT_MEMORY, NL_WS_TRANSPORT_LIMIT, NL_WS_TRANSPORT_TIMEOUT,
    NL_WS_TRANSPORT_IO, NL_WS_TRANSPORT_PROTOCOL, NL_WS_TRANSPORT_CRYPTO,
    NL_WS_TRANSPORT_CLOSED
} NlWsTransportStatus;
typedef struct {
    NlWsTransportStatus status;
    int host_errno,resolver_error,supervisor_status,close_code,cleanup_errno;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
        cleanup_failed,closure_unknown,terminal;
    size_t bytes;
} NlWsTransportResult;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
        allow_network,allow_lookup;
    const char *resolver_helper;
    unsigned max_timeout_ms;
} NlWsTransportPolicy;
typedef struct { 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
                _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
                     binary; unsigned char *bytes; size_t length; } NlWsMessage;
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_storage_bound(size_t *out);
NlWsTransportResult nl_ws_transport_connect(const void *url,size_t length,
    const NlWsTransportPolicy *,unsigned timeout_ms,NlWsTransport **out);
NlWsTransportResult nl_ws_transport_send(NlWsTransport *,
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
                                                        _Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
                                                             binary,
    const void *bytes,size_t length,unsigned timeout_ms);


NlWsTransportResult nl_ws_transport_receive(NlWsTransport *,unsigned timeout_ms,NlWsMessage *out);
void nl_ws_message_free(NlWsMessage *);


NlWsTransportResult nl_ws_transport_close(NlWsTransport *,unsigned timeout_ms);

NlWsTransportResult nl_ws_transport_abort(NlWsTransport *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_connected(const NlWsTransport *);
const char *nl_ws_transport_error(const NlWsTransport *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 2





typedef struct NlWsValues NlWsValues;
typedef enum {
    NL_WS_VALUE_OK, NL_WS_VALUE_ARGUMENT, NL_WS_VALUE_STALE, NL_WS_VALUE_TYPE,
    NL_WS_VALUE_BORROWED, NL_WS_VALUE_LIMIT, NL_WS_VALUE_MEMORY,
    NL_WS_VALUE_DISPOSED, NL_WS_VALUE_STATE, NL_WS_VALUE_STATUS_COUNT
} NlWsValueStatus;
typedef struct { uint64_t invocation,generation; uint32_t slot; } NlWsValue;
typedef struct { NlWsValue value; uint64_t epoch; } NlWsValueBorrow;
typedef struct { 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 3 4
                _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
                     ok; NlWsTransportResult error; } NlWsConnectView;
typedef struct {
    NlWsValueStatus execution;
    uint64_t cleanup_failures;
    NlWsTransportResult first_cleanup,next_cleanup;
} NlWsValuesFinish;
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
NlWsValueStatus nl_ws_values_create_bounded(const NlWsTransportPolicy *,size_t,NlWsValues **out);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
    nl_ws_values_minimum_storage(size_t *out);
NlWsValueStatus nl_ws_values_create(const NlWsTransportPolicy *,NlWsValues **out);
NlWsValueStatus nl_ws_values_connect(NlWsValues *,const void *,size_t,int64_t,NlWsValue *out);
NlWsValueStatus nl_ws_connect_view(NlWsValues *,const NlWsValue *,NlWsConnectView *out);
NlWsValueStatus nl_ws_connect_take_ok(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_connect_take_error(NlWsValues *,NlWsValue *,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_move(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_value_borrow(NlWsValues *,const NlWsValue *,NlWsValueBorrow *out);
NlWsValueStatus nl_ws_value_end_borrow(NlWsValues *,NlWsValueBorrow *);
NlWsValueStatus nl_ws_value_send(NlWsValues *,const NlWsValueBorrow *,
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 3 4
                                                                     _Bool
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
                                                                         ,
    const void *,size_t,int64_t,NlWsTransportResult *out);


NlWsValueStatus nl_ws_value_receive(NlWsValues *,const NlWsValueBorrow *,int64_t,
    NlWsMessage *message,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_close(NlWsValues *,NlWsValue *,int64_t,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_drop(NlWsValues *,NlWsValue *);
NlWsValueStatus nl_ws_value_validate(NlWsValues *,const NlWsValue *,
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 3 4
                                                                   _Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
                                                                        connect_result);
NlWsValueStatus nl_ws_value_borrow_validate(NlWsValues *,const NlWsValueBorrow *);
NlWsValueStatus nl_ws_values_live_slots(NlWsValues *,uint64_t *owners,uint64_t *borrowed);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_values.h"
    nl_ws_values_report(const NlWsValues *,NlWsValuesFinish *out);



NlWsValuesFinish nl_ws_values_finish(NlWsValues *,NlWsValueStatus);
NlWsValuesFinish nl_ws_values_destroy(NlWsValues *,NlWsValueStatus);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
typedef enum { NVM_WEBSOCKET_RUNTIME_VM, NVM_WEBSOCKET_RUNTIME_NATIVE } NvmWebSocketRuntimeMode;
typedef enum {
    NVM_WEBSOCKET_RUNTIME_OK, NVM_WEBSOCKET_RUNTIME_INVALID, NVM_WEBSOCKET_RUNTIME_UNRESOLVED,
    NVM_WEBSOCKET_RUNTIME_LIMIT, NVM_WEBSOCKET_RUNTIME_MEMORY, NVM_WEBSOCKET_RUNTIME_STATE,
    NVM_WEBSOCKET_RUNTIME_TYPE, NVM_WEBSOCKET_RUNTIME_STALE, NVM_WEBSOCKET_RUNTIME_BORROWED,
    NVM_WEBSOCKET_RUNTIME_ASSERT, NVM_WEBSOCKET_RUNTIME_CLEANUP, NVM_WEBSOCKET_RUNTIME_BUSY
} NvmWebSocketRuntimeStatus;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
        initialized, owning, formal;
    NvmWebSocketFlowDeclaration type;
    NvmWebSocketFlowArm arm;
    uint8_t fields;
    int64_t values[9u];
} NvmWebSocketRuntimeView;
typedef struct {
    NvmWebSocketRuntimeStatus status;
    
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
   _Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
        acquired;
    NlWsValueStatus core_status;
    uint32_t function, instruction;
    NlWsValuesFinish cleanup;
} NvmWebSocketRuntimeReport;
typedef struct {
    size_t allocation_bound;
    uint32_t values, references, regions;
    uint16_t frames;
} NvmWebSocketRuntimeStorage;
typedef struct NvmWebSocketRuntime NvmWebSocketRuntime;


NvmWebSocketRuntimeStatus nvm_websocket_runtime_create(const uint8_t *,size_t,NvmWebSocketRuntimeMode,NvmWebSocketRuntime **out);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_storage(const NvmWebSocketRuntime *,NvmWebSocketRuntimeStorage *);
const NvmWebSocketHostedPlan *nvm_websocket_runtime_plan(const NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_begin(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_site(NvmWebSocketRuntime *,uint32_t function,uint16_t instruction);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_fail(NvmWebSocketRuntime *,NvmWebSocketRuntimeStatus);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_current_root(const NvmWebSocketRuntime *,uint32_t *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_view(const NvmWebSocketRuntime *,uint32_t,NvmWebSocketRuntimeView *);

NvmWebSocketRuntimeStatus nvm_websocket_runtime_scalar(NvmWebSocketRuntime *,uint32_t,uint8_t,int64_t);




NvmWebSocketRuntimeStatus nvm_websocket_runtime_string(NvmWebSocketRuntime *,uint32_t,const void *,size_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_literal(NvmWebSocketRuntime *,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_operation(NvmWebSocketRuntime *,uint8_t,uint32_t,uint32_t,uint32_t);

# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_string_read(const NvmWebSocketRuntime *,uint32_t,void *,size_t,size_t *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_copy(NvmWebSocketRuntime *,uint32_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_move(NvmWebSocketRuntime *,uint32_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_drop(NvmWebSocketRuntime *,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_construct(NvmWebSocketRuntime *,uint32_t ordinal,uint16_t variant,const uint32_t *,size_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_project(NvmWebSocketRuntime *,uint32_t,uint16_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_result_arm(NvmWebSocketRuntime *,uint32_t,NvmWebSocketFlowArm *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_take(NvmWebSocketRuntime *,uint32_t,NvmWebSocketFlowArm,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_begin(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_end(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow(NvmWebSocketRuntime *,uint32_t owner,uint32_t reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow_shared(NvmWebSocketRuntime *,uint32_t owner,uint32_t reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_bind_formal(NvmWebSocketRuntime *,uint32_t source_reference,uint32_t formal_root,uint32_t formal_reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_end_reference(NvmWebSocketRuntime *,uint32_t);

NvmWebSocketRuntimeStatus nvm_websocket_runtime_policy(NvmWebSocketRuntime *,const NlWsTransportPolicy *);



NvmWebSocketRuntimeStatus nvm_websocket_runtime_service(NvmWebSocketRuntime *,uint32_t import,uint32_t reference,const uint32_t *inputs,size_t count,uint32_t output);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_complete_root(NvmWebSocketRuntime *,uint32_t result);



NvmWebSocketRuntimeReport nvm_websocket_runtime_finish(NvmWebSocketRuntime *,NvmWebSocketRuntimeView *);
NvmWebSocketRuntimeReport nvm_websocket_runtime_destroy(NvmWebSocketRuntime **,NvmWebSocketRuntimeView *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public.h" 2


typedef struct { uint8_t tag; int64_t value; } NvmWebSocketScalar;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_report.h" 1






typedef struct { uint32_t revision; uint64_t instruction_limit; } NvmWebSocketIndirectOptions;
typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeReport runtime;
    uint64_t instruction_limit, instructions_started;
    
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_report.h" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_report.h"
        fuel_exhausted;
} NvmWebSocketIndirectExecutionReport;
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public.h" 2






NvmWebSocketIndirectExecutionReport nvm_websocket_execute_indirect_bytes(NvmWebSocketHostGrant *,
    const uint8_t *, size_t, const NvmWebSocketIndirectOptions *, NvmWebSocketScalar *);



NvmWebSocketRuntimeStatus nvm2c_emit_websocket_indirect_bytes(const uint8_t *, size_t,
    const char *entry_identifier, char **out, char *diagnostic, size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public_internal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_transport.h" 1
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant_internal.h" 2
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_host_grant_internal.h"
NvmWebSocketHostStatus nvm_websocket_host_enter_query(void);
NvmWebSocketHostStatus nvm_websocket_host_enter(const NvmWebSocketHostGrant *grant,
                                    unsigned abi, unsigned catalog);

NvmWebSocketHostStatus nvm_websocket_host_policy(const NvmWebSocketHostGrant *,NlWsTransportPolicy *);
void nvm_websocket_host_leave(void);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public_internal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_public_internal.h" 2


static inline NvmWebSocketRuntimeStatus nvm_websocket_public_grant_status(NvmWebSocketHostStatus s) {
    switch (s) {
    case NVM_WEBSOCKET_HOST_OK: return NVM_WEBSOCKET_RUNTIME_OK;
    case NVM_WEBSOCKET_HOST_INVALID: return NVM_WEBSOCKET_RUNTIME_INVALID;
    case NVM_WEBSOCKET_HOST_MEMORY: return NVM_WEBSOCKET_RUNTIME_MEMORY;
    case NVM_WEBSOCKET_HOST_STATE: return NVM_WEBSOCKET_RUNTIME_STATE;
    case NVM_WEBSOCKET_HOST_BUSY: return NVM_WEBSOCKET_RUNTIME_BUSY;
    default: return NVM_WEBSOCKET_RUNTIME_UNRESOLVED;
    }
}
static inline NvmWebSocketRuntimeReport nvm_websocket_public_refused(NvmWebSocketRuntimeStatus s) {
    NvmWebSocketRuntimeReport r = {0};
    r.status = s;
    r.function = r.instruction = 0xFFFFFFFFu;
    return r;
}


static inline NvmWebSocketRuntimeReport nvm_websocket_public_publish(NvmWebSocketRuntimeReport r,
    const NvmWebSocketRuntimeView *view, NvmWebSocketScalar *out) {
    if (r.status != NVM_WEBSOCKET_RUNTIME_OK) return r;
    if (!r.acquired) { r.status = NVM_WEBSOCKET_RUNTIME_STATE; return r; }
    if (r.core_status != NL_WS_VALUE_OK || r.cleanup.execution != NL_WS_VALUE_OK ||
        r.cleanup.cleanup_failures) { r.status = NVM_WEBSOCKET_RUNTIME_CLEANUP; return r; }
    if (!out || !view->initialized || view->owning || view->formal ||
        view->type.mode || view->type.category != NVM_WEBSOCKET_CATEGORY_UNKNOWN ||
        view->type.global_index != 0xFFFFFFFFu ||
        view->type.catalog_ordinal != 0xFFFFFFFFu || view->fields != 1 ||
        (view->type.tag != TAG_INT && view->type.tag != TAG_BOOL) ||
        (view->type.tag == TAG_BOOL && view->values[0] != 0 && view->values[0] != 1)) {
        r.status = NVM_WEBSOCKET_RUNTIME_TYPE;
        return r;
    }
    NvmWebSocketScalar scalar = {view->type.tag, view->values[0]};
    *out = scalar;
    return r;
}
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public_internal.h" 2

static inline NvmWebSocketIndirectExecutionReport nvm_websocket_indirect_public_refused(
    NvmWebSocketRuntimeStatus status, const NvmWebSocketIndirectOptions *options) {
    NvmWebSocketIndirectExecutionReport report = {0};
    report.revision = 1u;
    report.instruction_limit = options ? options->instruction_limit : 0;
    report.runtime = nvm_websocket_public_refused(status);
    return report;
}
static inline 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public_internal.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_public_internal.h"
                  nvm_websocket_indirect_public_options(const NvmWebSocketIndirectOptions *options) {
    return options && options->revision == 1u &&
        options->instruction_limit <= 1000000UL;
}
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_dispatch_config.h" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow_config.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal_config.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/../nsi_websocket_plan.h" 2



typedef struct NlWebSocketPlan NlWebSocketPlan;
typedef enum { NL_WEBSOCKET_PLAN_OK, NL_WEBSOCKET_PLAN_INVALID, NL_WEBSOCKET_PLAN_MEMORY } NlWebSocketPlanStatus;



NlWebSocketPlanStatus nl_websocket_plan_build(const NlNsi *,NlWebSocketPlan **out);
void nl_websocket_plan_free(NlWebSocketPlan *);
size_t nl_websocket_plan_storage_size(void);
const char *nl_websocket_plan_interface(const NlWebSocketPlan *);
size_t nl_websocket_plan_method_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_type_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_capability_count(const NlWebSocketPlan *);
const NlServicePlanMethod *nl_websocket_plan_method(const NlWebSocketPlan *,size_t);
const NlServicePlanType *nl_websocket_plan_type(const NlWebSocketPlan *,size_t);
const NlServicePlanCapability *nl_websocket_plan_capability(const NlWebSocketPlan *,size_t);
const char *nl_websocket_catalog_interface(void);
const NlServicePlanMethod *nl_websocket_catalog_method(size_t);
const NlServicePlanType *nl_websocket_catalog_type(size_t);
const NlServicePlanCapability *nl_websocket_catalog_capability(size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_websocket_nominal_config.h" 2
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_flow_config.h" 2
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_dispatch_config.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
typedef struct NvmWebSocketCyclicReport NvmWebSocketCyclicReport;
typedef struct {
    uint32_t revision, functions, instructions, variants, transfers, edges;
    size_t storage_peak;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
        runtime_admitted;
} NvmWebSocketCyclicSummary;
typedef struct {
    uint16_t locals, stack, regions, owners, references;
} NvmWebSocketCyclicStateInfo;
typedef struct {
    NvmWebSocketCyclicStateInfo input, output;
    NvmWebSocketBodyInstruction body;
    uint8_t edge_mask, edge_variants[2];


} NvmWebSocketCyclicVariant;
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
NvmWebSocketFlowStatus nvm_websocket_cyclic_analyze(const NvmModule *, NvmWebSocketCyclicReport **);
void nvm_websocket_cyclic_free(NvmWebSocketCyclicReport *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_summary(const NvmWebSocketCyclicReport *, NvmWebSocketCyclicSummary *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_function(const NvmWebSocketCyclicReport *, uint32_t, NvmWebSocketCodeFunction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_local(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, NvmWebSocketFlowDeclaration *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_instruction(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, NvmWebSocketCodeInstruction *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_component(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint16_t *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_variant_count(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_variant(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, NvmWebSocketCyclicVariant *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_local(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowValue *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_stack(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowValue *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_reference(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowReference *);

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_region(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, uint64_t *);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_type(const NvmWebSocketCyclicReport *, uint32_t, NvmWebSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_import(const NvmWebSocketCyclicReport *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h" 1





typedef struct NvmWebSocketIndirectTargets NvmWebSocketIndirectTargets;
typedef enum { NVM_WEBSOCKET_INDIRECT_DESCRIBED, NVM_WEBSOCKET_INDIRECT_INVALID,
 NVM_WEBSOCKET_INDIRECT_UNRESOLVED, NVM_WEBSOCKET_INDIRECT_LIMIT,
 NVM_WEBSOCKET_INDIRECT_MEMORY } NvmWebSocketIndirectStatus;
typedef struct {
 NvmWebSocketIndirectStatus status;
 uint32_t function,pc;
 const char *message;
} NvmWebSocketIndirectResult;
typedef struct {
 uint32_t functions,instructions,calls,visits;
 size_t storage_bound;
} NvmWebSocketIndirectSummary;
typedef struct {
 uint32_t function,pc;
 uint16_t instruction,parameters;
 uint64_t candidates;
 uint8_t result_count;
 NvmWebSocketFlowDeclaration result;
} NvmWebSocketIndirectCall;





NvmWebSocketIndirectResult nvm_websocket_indirect_targets(const NvmModule *,NvmWebSocketIndirectTargets **);
void nvm_websocket_indirect_targets_free(NvmWebSocketIndirectTargets *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_summary(const NvmWebSocketIndirectTargets *,NvmWebSocketIndirectSummary *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_call(const NvmWebSocketIndirectTargets *,uint32_t,NvmWebSocketIndirectCall *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_parameter(const NvmWebSocketIndirectTargets *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 2


typedef struct NvmWebSocketIndirectFlow NvmWebSocketIndirectFlow;
typedef struct {
 NvmWebSocketIndirectSummary targets;
 NvmWebSocketCyclicSummary ownership;
 uint32_t candidate_applications;
 size_t storage_bound;
 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
     runtime_admitted;
} NvmWebSocketIndirectFlowSummary;
typedef struct {
 uint32_t function,pc;
 uint64_t candidates,checked_candidates;
 NvmWebSocketFlowObligation common;
} NvmWebSocketIndirectFlowCall;





NvmWebSocketFlowStatus nvm_websocket_indirect_flow_analyze(const NvmModule *,NvmWebSocketIndirectFlow **);
void nvm_websocket_indirect_flow_free(NvmWebSocketIndirectFlow *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_summary(const NvmWebSocketIndirectFlow *,NvmWebSocketIndirectFlowSummary *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_function(const NvmWebSocketIndirectFlow *,uint32_t,NvmWebSocketCodeFunction *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_local(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_instruction(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,NvmWebSocketCodeInstruction *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_variant_count(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_variant(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmWebSocketCyclicVariant *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_local(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_stack(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_reference(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowReference *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_region(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_call(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmWebSocketIndirectFlowCall *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_component(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint16_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_type(const NvmWebSocketIndirectFlow *,uint32_t,NvmWebSocketNominalLayout *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_import(const NvmWebSocketIndirectFlow *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 2
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
typedef struct NvmWebSocketIndirectHostedPlan NvmWebSocketIndirectHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
        runtime_admitted;
} NvmWebSocketIndirectHostedStartup;
typedef struct {
    NvmWebSocketCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmWebSocketIndirectHostedFunction;




NvmWebSocketFlowStatus nvm_websocket_indirect_hosted_prepare(const uint8_t *,size_t,NvmWebSocketIndirectHostedPlan **);
void nvm_websocket_indirect_hosted_free(NvmWebSocketIndirectHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_query_summary(const NvmWebSocketIndirectHostedPlan *,NvmWebSocketIndirectFlowSummary *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_startup(const NvmWebSocketIndirectHostedPlan *,NvmWebSocketIndirectHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_function(const NvmWebSocketIndirectHostedPlan *,uint32_t,NvmWebSocketIndirectHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_function_order(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_local(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_instruction(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,NvmWebSocketCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_component(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_variant_count(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_variant(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmWebSocketCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_local(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_stack(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_reference(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_region(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_type(const NvmWebSocketIndirectHostedPlan *,uint32_t,NvmWebSocketNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_import(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_bytes(const NvmWebSocketIndirectHostedPlan *,size_t,void *,size_t);

# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_call(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmWebSocketIndirectFlowCall *);


# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_string(const NvmWebSocketIndirectHostedPlan *,uint32_t,const uint8_t **,size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
typedef struct {
    NvmWebSocketRuntimeMode mode;
    uint32_t function, instruction, byte_offset;
    uint16_t depth, locals, staging_slots, operand_peak;
    uint32_t locals_base, staging_base, stack_base, stack_count;
    uint32_t reference_base, region_floor;
} NvmWebSocketRuntimeFrameView;

NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_start(NvmWebSocketRuntime *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_view(const NvmWebSocketRuntime *,NvmWebSocketRuntimeFrameView *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_local(const NvmWebSocketRuntime *,uint16_t,uint32_t *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_operand(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_reserve(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_scratch(const NvmWebSocketRuntime *,uint32_t *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_reference(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_store(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_next(NvmWebSocketRuntime *,uint8_t successor);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_call(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_return(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_begin(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_end(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_borrow(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_end_reference(NvmWebSocketRuntime *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 2

typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeFrameView frame;
    uint8_t variant;
    
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h"
        instruction_open;
} NvmWebSocketIndirectFrameView;
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_create(const uint8_t *,size_t,
    NvmWebSocketRuntimeMode,const NvmWebSocketIndirectOptions *,NvmWebSocketRuntime **);
const NvmWebSocketIndirectHostedPlan *nvm_websocket_runtime_indirect_plan(const NvmWebSocketRuntime *);

# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h"
    nvm_websocket_runtime_indirect_frame_view(const NvmWebSocketRuntime *,NvmWebSocketIndirectFrameView *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_enter(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_funcref(NvmWebSocketRuntime *,uint32_t dst);
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_finish(NvmWebSocketRuntime *,NvmWebSocketRuntimeView *);
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_destroy(NvmWebSocketRuntime **,NvmWebSocketRuntimeView *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_indirect_runtime.h"
    nvm_websocket_runtime_indirect_native_abi(uint32_t,size_t,size_t,size_t,size_t,size_t);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/websocket_dispatch_config.h" 2
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 1




# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_dispatch_catalog.inc" 1
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 2


static 
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
      _Bool 
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
           fcd_supported(uint8_t op) {
    switch(op) {
    case OP_PUSH_STR: case OP_STR_EQ: case OP_STR_LEN:
    case OP_FUNCREF: case OP_FILE_CALL_INDIRECT_REFS:case OP_CALL_INDIRECT:
    case OP_NOP: case OP_PUSH_I64: case OP_PUSH_BOOL: case OP_PUSH_VOID:
    case OP_DUP: case OP_POP: case OP_LOAD_LOCAL: case OP_STORE_LOCAL:
    case OP_OWN_MOVE_LOCAL: case OP_OWN_STORE_LOCAL:
    case OP_REGION_BEGIN: case OP_REGION_END: case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:
    case OP_FILE_SERVICE: case OP_FILE_RESULT_BRANCH: case OP_FILE_RESULT_TAKE:
    case OP_FILE_DROP_LOCAL: case OP_FILE_DROP_STACK: case OP_FILE_END_BORROW:
    case OP_CALL: case OP_CALL_REF:case OP_FILE_CALL_REFS: case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE:
    case OP_RET: case OP_ASSERT:
    case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: case OP_NEG:
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
    case OP_I64_REM_S: case OP_I64_NEG:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S:
    case OP_I64_GT_S: case OP_I64_GE_S: case OP_AND: case OP_OR: case OP_NOT:
    case OP_AGG_PACK: case OP_UNION_CONSTRUCT: case OP_AGG_GET: case OP_UNION_FIELD:
    case OP_AGG_TAG: case OP_UNION_TAG:return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                             1
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                 ;
    default:return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                  0
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                       ;
    }
}
static 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
      _Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
           fcd_fact(const NvmWebSocketIndirectHostedPlan *p,const NvmWebSocketCodeInstruction *in,
                     const NvmWebSocketBodyInstruction *fact) {
    uint8_t op=in->decoded.opcode;
    if(!fcd_supported(op))return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                0
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                     ;
    if(!fact->reachable)return 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                              1
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                  ;
    NvmWebSocketBodyCleanup cleanup=NVM_WEBSOCKET_BODY_CLEANUP_NORMAL;
    switch(op) {
    case OP_FILE_DROP_LOCAL:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_DROP_LOCAL;break;
    case OP_FILE_DROP_STACK:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_DROP_STACK;break;
    case OP_ASSERT:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_ASSERT;break;
    case OP_RET:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_RETURN;break;
    case OP_FILE_CALL_INDIRECT_REFS:case OP_CALL_INDIRECT:case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_CALL;break;
    case OP_FILE_SERVICE:cleanup=NVM_WEBSOCKET_BODY_CLEANUP_SERVICE;break;
    default:break;
    }
    if(fact->cleanup!=cleanup || fact->refinement!=(op==OP_FILE_RESULT_BRANCH) ||
       fact->exit_checked!=(op==OP_RET))return 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                              0
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                   ;
    uint32_t checks=NVM_WEBSOCKET_FLOW_CHECK_CLEANUP,discharged=0;
    
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
        service=op==OP_FILE_SERVICE,call=isa_is_file_indirect_call(op) || op==OP_CALL || (op==OP_CALL_REF || op==OP_FILE_CALL_REFS);
    if(fact->has_obligation!=(service || call))return 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                     0
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                          ;
    if(service || call) {
        const NvmWebSocketFlowObligation *o=&fact->obligation;
        if(o->site!=in->byte_offset || o->target!=(isa_is_file_indirect_call(op)?0xFFFFFFFFu:in->decoded.operands[0].u32) ||
           o->kind!=(service?NVM_WEBSOCKET_FLOW_SERVICE:NVM_WEBSOCKET_FLOW_CALL))return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                         0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                              ;
        checks|=NVM_WEBSOCKET_FLOW_CHECK_RESULT;
        if(service) {
            uint32_t original,ordinal=in->catalog_ordinal;
            if(!nvm_websocket_indirect_hosted_import(p,ordinal,&original) || original!=o->target)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                                     0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                                          ;
            const NlServicePlanMethod *method=nl_websocket_catalog_method(ordinal);
            if(!method || o->required_rights!=method->required_rights ||
               o->acquired_rights!=method->acquired_rights)return 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                 0
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                      ;
            checks|=NVM_WEBSOCKET_FLOW_CHECK_BINDING|NVM_WEBSOCKET_FLOW_CHECK_INVOCATION|
                    NVM_WEBSOCKET_FLOW_CHECK_LIVENESS|NVM_WEBSOCKET_FLOW_CHECK_RIGHTS;
            if(method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE)checks|=NVM_WEBSOCKET_FLOW_CHECK_BORROW;
            for(size_t i=0;i+1<method->param_count;i++) {
                if(method->params[i].domain==NL_SERVICE_DOMAIN_BYTE_INT)checks|=NVM_WEBSOCKET_FLOW_CHECK_BYTE;
                if(method->params[i].domain==NL_SERVICE_DOMAIN_TIMEOUT_MS)checks|=NVM_WEBSOCKET_FLOW_CHECK_TIMEOUT;
            }
            if(0 && (ordinal)==0)checks|=0u;
        } else { checks|=NVM_WEBSOCKET_FLOW_CHECK_CALLEE;discharged=NVM_WEBSOCKET_FLOW_CHECK_CALLEE; }
        if(o->checks!=checks)return 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                   0
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                        ;
    }
    return fact->discharged_checks==discharged && fact->pending_checks==(checks&~discharged);
}
static 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
      _Bool 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
           fcd_coverage(const NvmWebSocketIndirectHostedPlan *p) {
    NvmWebSocketIndirectHostedStartup start;
    if(!nvm_websocket_indirect_hosted_startup(p,&start) || start.runtime_admitted)return 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                      0
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                           ;
    for(uint32_t f=0;f<start.functions;f++) {
        NvmWebSocketIndirectHostedFunction fn;
        if(!nvm_websocket_indirect_hosted_function(p,f,&fn) || fn.entry_variant!=0)return 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                       0
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                            ;
        for(uint16_t i=0;i<fn.code.instruction_count;i++) {
            NvmWebSocketCodeInstruction in;uint8_t count;
            if(!nvm_websocket_indirect_hosted_instruction(p,f,i,&in) || !fcd_supported(in.decoded.opcode) || in.successor_count>2 ||
               !nvm_websocket_indirect_hosted_variant_count(p,f,i,&count) ||
               count>16u || (!i && !count))return 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                0
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                     ;
            for(uint8_t v=0;v<count;v++) {
                NvmWebSocketCyclicVariant fact;
                if(!nvm_websocket_indirect_hosted_variant(p,f,i,v,&fact) || !fact.body.reachable ||
                   !fcd_fact(p,&in,&fact.body) || fact.body.input_stack!=fact.input.stack ||
                   fact.body.output_stack!=fact.output.stack ||
                   (fact.edge_mask & ~((1u<<in.successor_count)-1u)))return 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                           0
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                ;
                for(uint8_t e=0;e<2;e++) {
                    if(!(fact.edge_mask&(1u<<e))) {
                        if(fact.edge_variants[e]!=
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                 (255)
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                 )return 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                         0
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                              ;
                    } else {
                        uint8_t destination_count;
                        if(e>=in.successor_count || in.successors[e]>=fn.code.instruction_count ||
                           !nvm_websocket_indirect_hosted_variant_count(p,f,in.successors[e],&destination_count) ||
                           fact.edge_variants[e]>=destination_count)return 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                          0
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                               ;
                    }
                }
                if(isa_is_file_indirect_call(in.decoded.opcode)) {
                    NvmWebSocketIndirectFlowCall call;
                    if(!nvm_websocket_indirect_hosted_call(p,f,i,v,&call) || !call.candidates ||
                       call.candidates!=call.checked_candidates || call.function!=f || call.pc!=in.byte_offset ||
                       call.common.target!=0xFFFFFFFFu)return 
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                 0
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                      ;
                    for(uint32_t target=0;target<64u;target++)if(call.candidates&(1UL<<target)) {
                        NvmWebSocketIndirectHostedFunction callee;
                        if(!nvm_websocket_indirect_hosted_function(p,target,&callee) || callee.entry_variant!=0 ||
                           callee.code.declaration.parameters!=call.common.parameters ||
                           callee.code.declaration.result_count!=call.common.result_count)return 
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                                                                0
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                                                                     ;
                    }
                }
                if(in.decoded.opcode==OP_CALL || (in.decoded.opcode==OP_CALL_REF || in.decoded.opcode==OP_FILE_CALL_REFS)) {
                    NvmWebSocketIndirectHostedFunction callee;
                    if(!nvm_websocket_indirect_hosted_function(p,in.decoded.operands[0].u32,&callee) ||
                       callee.entry_variant!=0)return 
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
                                                     0
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
                                                          ;
                }
            }
        }
    }
    return 
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc" 3 4
          1
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/../nanoisa/service_indirect_dispatch.inc"
              ;
}
static inline NvmWebSocketIndirectExecutionReport fcd_refused(NvmWebSocketRuntimeStatus status,
                                               const NvmWebSocketIndirectOptions *options) {
    NvmWebSocketIndirectExecutionReport report={0};
    report.revision=1u;
    report.instruction_limit=options?options->instruction_limit:0;
    report.runtime.status=status;
    report.runtime.function=report.runtime.instruction=0xFFFFFFFFu;
    return report;
}
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 1 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 205 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4


# 24 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 82 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 1 3 4
# 64 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uio_lim.h" 1 3 4
# 65 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 2 3 4
# 204 "/usr/include/limits.h" 2 3 4
# 206 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 2 3 4
# 35 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 2

# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
static NvmWebSocketRuntimeStatus fvm_bad(NvmWebSocketRuntime *c) {
    return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_STATE);
}
static 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
      _Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
           fvm_scalar(const NvmWebSocketRuntimeView *v,uint8_t tag) {
    return v->initialized && !v->owning && !v->formal && !v->type.mode &&
        v->type.category==NVM_WEBSOCKET_CATEGORY_UNKNOWN && v->type.tag==tag &&
        v->type.global_index==0xFFFFFFFFu && v->type.catalog_ordinal==0xFFFFFFFFu &&
        v->fields==(tag==TAG_VOID?0:1) && (tag!=TAG_BOOL || v->values[0]==0 || v->values[0]==1);
}
static int64_t fvm_bits(uint64_t bits) { int64_t result;memcpy(&result,&bits,sizeof result);return result; }

static NvmWebSocketRuntimeStatus fvm_numeric(NvmWebSocketRuntime *c,const NvmWebSocketRuntimeFrameView *f,uint8_t op) {
    
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
   _Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
        unary=op==OP_NEG || op==OP_I64_NEG || op==OP_NOT;
    uint16_t count=unary?1:2;uint32_t roots[2];NvmWebSocketRuntimeView values[2];
    if(f->stack_count<count)return fvm_bad(c);
    for(uint16_t i=0;i<count;i++)
        if(!nvm_websocket_runtime_frame_operand(c,(uint16_t)(f->stack_count-count+i),&roots[i]) ||
           !nvm_websocket_runtime_view(c,roots[i],&values[i]))return fvm_bad(c);
    
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
   _Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
        logic=op==OP_AND || op==OP_OR || op==OP_NOT;
    uint8_t input=logic?TAG_BOOL:TAG_INT;
    if((op==OP_EQ || op==OP_NE) && values[0].type.tag==TAG_BOOL)input=TAG_BOOL;
    for(uint16_t i=0;i<count;i++)if(!fvm_scalar(&values[i],input))
        return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_TYPE);
    int64_t a=values[0].values[0],b=unary?0:values[1].values[0],result=0;uint8_t tag=TAG_INT;
    switch(op) {
    case OP_ADD:case OP_I64_ADD:result=fvm_bits((uint64_t)a+(uint64_t)b);break;
    case OP_SUB:case OP_I64_SUB:result=fvm_bits((uint64_t)a-(uint64_t)b);break;
    case OP_MUL:case OP_I64_MUL:result=fvm_bits((uint64_t)a*(uint64_t)b);break;
    case OP_DIV:case OP_I64_DIV_S:result=!b?0:a==
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                (-9223372036854775807L -1)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                         &&b==-1?
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                                 (-9223372036854775807L -1)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                                          :a/b;break;
    case OP_MOD:case OP_I64_REM_S:result=!b || (a==
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                  (-9223372036854775807L -1)
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                           &&b==-1)?0:a%b;break;
    case OP_NEG:case OP_I64_NEG:result=fvm_bits(0UL -(uint64_t)a);break;
    case OP_EQ:case OP_I64_EQ:result=a==b;tag=TAG_BOOL;break;
    case OP_NE:case OP_I64_NE:result=a!=b;tag=TAG_BOOL;break;
    case OP_LT:case OP_I64_LT_S:result=a<b;tag=TAG_BOOL;break;
    case OP_LE:case OP_I64_LE_S:result=a<=b;tag=TAG_BOOL;break;
    case OP_GT:case OP_I64_GT_S:result=a>b;tag=TAG_BOOL;break;
    case OP_GE:case OP_I64_GE_S:result=a>=b;tag=TAG_BOOL;break;
    case OP_AND:result=a&&b;tag=TAG_BOOL;break;
    case OP_OR:result=a||b;tag=TAG_BOOL;break;
    case OP_NOT:result=!a;tag=TAG_BOOL;break;
    default:return fvm_bad(c);
    }
    for(uint16_t i=0;i<count;i++)do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_drop(c,roots[i])); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
    do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_scalar(c,roots[0],tag,result)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
    return nvm_websocket_runtime_frame_next(c,0);
}
static NvmWebSocketRuntimeStatus fvm_step(NvmWebSocketRuntime *c,NvmWebSocketRuntimeFrameView f,
                                     const NvmWebSocketCodeInstruction *in) {
    const DecodedInstruction *d=&in->decoded;uint8_t op=d->opcode,edge=0;
    uint32_t src=
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                (4294967295U)
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                              ,dst=
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                   (4294967295U)
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                                                 ;
    NvmWebSocketRuntimeView value;
    switch(op) {
    case OP_NOP:case OP_JMP:break;
    case OP_PUSH_STR:
        if(!nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_string_literal(c,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_STR_EQ:case OP_STR_LEN: {
        uint16_t count=op==OP_STR_EQ?2:1;uint32_t other=
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                       (4294967295U)
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                                                     ;
        if(f.stack_count<count || !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-count),&src) ||
           (count==2 && !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&other)))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_string_operation(c,op,src,other,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    }
    case OP_PUSH_I64:case OP_PUSH_BOOL:case OP_PUSH_VOID:
        if(!nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_scalar(c,dst,op==OP_PUSH_I64?TAG_INT:op==OP_PUSH_BOOL?TAG_BOOL:TAG_VOID, op==OP_PUSH_I64?d->operands[0].i64:op==OP_PUSH_BOOL?d->operands[0].u8:0)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0)
                                                                                     ;break;
    case OP_FUNCREF:
        if(!nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_indirect_funcref(c,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_DUP:
        if(!f.stack_count || !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) ||
           !nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_copy(c,src,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_POP:case OP_FILE_DROP_STACK:
        if(!f.stack_count || !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) ||
           !nvm_websocket_runtime_view(c,src,&value))return fvm_bad(c);
        if(op==OP_POP && (value.owning || value.formal))return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_TYPE);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_drop(c,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_LOAD_LOCAL:case OP_OWN_MOVE_LOCAL:
        if(!nvm_websocket_runtime_frame_local(c,d->operands[0].u16,&src) ||
           !nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst) ||
           !nvm_websocket_runtime_view(c,src,&value))return fvm_bad(c);
        if(!value.initialized || value.formal || value.owning!=(op==OP_OWN_MOVE_LOCAL))
            return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_TYPE);
        do { NvmWebSocketRuntimeStatus status_=(op==OP_LOAD_LOCAL?nvm_websocket_runtime_copy(c,src,dst):nvm_websocket_runtime_move(c,src,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_STORE_LOCAL:case OP_OWN_STORE_LOCAL:do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_frame_store(c)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_REGION_BEGIN:do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_frame_region_begin(c)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_REGION_END:do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_frame_region_end(c)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_BORROW_LOCAL_SHARED: case OP_BORROW_LOCAL_EXCLUSIVE:do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_frame_borrow(c)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_FILE_END_BORROW:do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_frame_end_reference(c)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_FILE_DROP_LOCAL:
        if(!nvm_websocket_runtime_frame_local(c,d->operands[0].u16,&src))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_drop(c,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_FILE_RESULT_BRANCH: {
        NvmWebSocketFlowArm arm;
        if(!nvm_websocket_runtime_frame_local(c,d->operands[0].u16,&src))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_result_arm(c,src,&arm)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);edge=arm==NVM_WEBSOCKET_FLOW_ARM_ERROR;break;
    }
    case OP_FILE_RESULT_TAKE:
        if(!nvm_websocket_runtime_frame_local(c,d->operands[0].u16,&src) ||
           !nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_take(c,src,d->operands[1].u8?NVM_WEBSOCKET_FLOW_ARM_ERROR:NVM_WEBSOCKET_FLOW_ARM_OK,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    case OP_FILE_SERVICE: {
        uint32_t ordinal=in->catalog_ordinal,original,reference=
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                               (4294967295U)
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                                                             ;
        if(!nvm_websocket_indirect_hosted_import(nvm_websocket_runtime_indirect_plan(c),ordinal,&original) ||
           original!=d->operands[0].u32 || !nvm_websocket_runtime_frame_scratch(c,&dst))return fvm_bad(c);

        const NlServicePlanMethod *method=nl_websocket_catalog_method(ordinal);
        if(!method || !method->param_count)return fvm_bad(c);
        
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
       _Bool 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
            borrowed=method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE;
        size_t count=method->param_count-1-(borrowed?1:0);uint32_t inputs[2],output;
        if(count>2 || count>f.stack_count)return fvm_bad(c);
        for(size_t i=0;i<count;i++)
            if(!nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-count+i),&inputs[i]))return fvm_bad(c);
        if(borrowed && !nvm_websocket_runtime_frame_reference(c,d->operands[1].u16,&reference))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_service(c,d->operands[0].u32,reference,inputs,count,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
        if(!nvm_websocket_runtime_frame_reserve(c,(uint16_t)(f.stack_count-count),&output))return fvm_bad(c);
# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_move(c,dst,output)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    }
    case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_ASSERT:
        if(!f.stack_count || !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src) ||
           !nvm_websocket_runtime_view(c,src,&value))return fvm_bad(c);
        if(!fvm_scalar(&value,TAG_BOOL))return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_TYPE);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_drop(c,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
        if(op==OP_ASSERT) { if(!value.values[0])return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_ASSERT); }
        else edge=(value.values[0]!=0)==(op==OP_JMP_TRUE);
        break;
    case OP_AGG_PACK:case OP_UNION_CONSTRUCT: {
        uint16_t variant=d->operands[op==OP_AGG_PACK?2:1].u16;
        uint16_t count=d->operands[op==OP_AGG_PACK?3:2].u16;
        uint32_t inputs[9u];
        if(count>9u || count>f.stack_count)return fvm_bad(c);
        for(uint16_t i=0;i<count;i++)
            if(!nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-count+i),&inputs[i]))return fvm_bad(c);
        if(count)dst=inputs[0];else if(!nvm_websocket_runtime_frame_reserve(c,(uint16_t)f.stack_count,&dst))return fvm_bad(c);
        do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_construct(c,in->catalog_ordinal,variant,inputs,count,dst)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);break;
    }
    case OP_AGG_GET:case OP_UNION_FIELD:case OP_AGG_TAG:case OP_UNION_TAG:
        if(!f.stack_count || !nvm_websocket_runtime_frame_operand(c,(uint16_t)(f.stack_count-1),&src))return fvm_bad(c);
        if(op==OP_AGG_GET || op==OP_UNION_FIELD)do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_project(c,src,d->operands[0].u16,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
        else {
            NvmWebSocketFlowArm arm;
            if(!nvm_websocket_runtime_view(c,src,&value))return fvm_bad(c);
            if(value.owning || value.formal || value.type.category!=NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT)
                return nvm_websocket_runtime_fail(c,NVM_WEBSOCKET_RUNTIME_TYPE);
            do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_result_arm(c,src,&arm)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_drop(c,src)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
            do { NvmWebSocketRuntimeStatus status_=(nvm_websocket_runtime_scalar(c,src,TAG_INT,arm==NVM_WEBSOCKET_FLOW_ARM_ERROR)); if(status_!=NVM_WEBSOCKET_RUNTIME_OK)return status_; } while(0);
        }break;
    case OP_FILE_CALL_INDIRECT_REFS:case OP_CALL_INDIRECT:case OP_CALL:case OP_CALL_REF:case OP_FILE_CALL_REFS:return nvm_websocket_runtime_frame_call(c);
    case OP_RET:return nvm_websocket_runtime_frame_return(c);
    default:return fvm_numeric(c,&f,op);
    }
    return nvm_websocket_runtime_frame_next(c,edge);
}

static NvmWebSocketIndirectExecutionReport file_vm_indirect_execute_serialized(const uint8_t *bytes,size_t size,
    const NvmWebSocketIndirectOptions *options,NvmWebSocketRuntimeView *out ,const NlWsTransportPolicy *policy) {
    if(!out)return fcd_refused(NVM_WEBSOCKET_RUNTIME_INVALID,options);
    NvmWebSocketRuntime *c=
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                            ((void *)0)
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                ;
    NvmWebSocketRuntimeStatus status=nvm_websocket_runtime_indirect_create(bytes,size,NVM_WEBSOCKET_RUNTIME_VM,options,&c);
    if(status!=NVM_WEBSOCKET_RUNTIME_OK)return fcd_refused(status,options);
    const NvmWebSocketIndirectHostedPlan *plan=nvm_websocket_runtime_indirect_plan(c);
    if(!fcd_coverage(plan)) {
        (void)nvm_websocket_runtime_indirect_destroy(&c,
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                     ((void *)0)
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                         );
        return fcd_refused(NVM_WEBSOCKET_RUNTIME_UNRESOLVED,options);
    }
    status=nvm_websocket_runtime_policy(c,policy);
    if(status!=NVM_WEBSOCKET_RUNTIME_OK) {
        (void)nvm_websocket_runtime_indirect_destroy(&c,
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc" 3 4
                                                     ((void *)0)
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/service_vm_indirect_engine.inc"
                                                         );
        return fcd_refused(status,options);
    }
    status=nvm_websocket_runtime_begin(c);
    if(status==NVM_WEBSOCKET_RUNTIME_OK)status=nvm_websocket_runtime_frame_start(c);
    while(status==NVM_WEBSOCKET_RUNTIME_OK) {
        NvmWebSocketIndirectFrameView current;NvmWebSocketCodeInstruction in;NvmWebSocketCyclicVariant variant;
        if(!nvm_websocket_runtime_indirect_frame_view(c,&current) || current.instruction_open ||
           current.frame.mode!=NVM_WEBSOCKET_RUNTIME_VM ||
           !nvm_websocket_indirect_hosted_instruction(plan,current.frame.function,(uint16_t)current.frame.instruction,&in) ||
           !nvm_websocket_indirect_hosted_variant(plan,current.frame.function,(uint16_t)current.frame.instruction,current.variant,&variant) ||
           !variant.body.reachable || variant.input.stack!=current.frame.stack_count) {
            status=fvm_bad(c);break;
        }
        status=nvm_websocket_runtime_indirect_enter(c);
        if(status!=NVM_WEBSOCKET_RUNTIME_OK)break;
        status=fvm_step(c,current.frame,&in);
        if(status!=NVM_WEBSOCKET_RUNTIME_OK)break;
        if(in.decoded.opcode==OP_RET && current.frame.depth==1) {
            uint32_t root;
            if(!nvm_websocket_runtime_current_root(c,&root))break;
            status=nvm_websocket_runtime_frame_start(c);
        }
    }
    if(status!=NVM_WEBSOCKET_RUNTIME_OK)(void)nvm_websocket_runtime_fail(c,status);
    return nvm_websocket_runtime_indirect_destroy(&c,out);
}
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c" 2
NvmWebSocketIndirectExecutionReport nvm_websocket_execute_indirect_bytes(NvmWebSocketHostGrant *grant,
    const uint8_t *bytes,size_t size,const NvmWebSocketIndirectOptions *options,NvmWebSocketScalar *out) {
    NvmWebSocketHostStatus entered=nvm_websocket_host_enter(grant,1u,3u);
    if(entered!=NVM_WEBSOCKET_HOST_OK)return nvm_websocket_indirect_public_refused(
        nvm_websocket_public_grant_status(entered),entered==NVM_WEBSOCKET_HOST_BUSY?
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c" 3 4
                                                                                   ((void *)0)
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanovm/websocket_indirect_public_vm.c"
                                                                                       :options);
    NvmWebSocketIndirectExecutionReport report;
    if(!nvm_websocket_indirect_public_options(options) || !out)
        report=nvm_websocket_indirect_public_refused(NVM_WEBSOCKET_RUNTIME_INVALID,options);
    else {
        NvmWebSocketIndirectOptions copied=*options;NvmWebSocketRuntimeView view={0};NlWsTransportPolicy policy;
        NvmWebSocketHostStatus status=nvm_websocket_host_policy(grant,&policy);
        if(status!=NVM_WEBSOCKET_HOST_OK)report=nvm_websocket_indirect_public_refused(nvm_websocket_public_grant_status(status),&copied);
        else {report=file_vm_indirect_execute_serialized(bytes,size,&copied,&view,&policy);
            report.runtime=nvm_websocket_public_publish(report.runtime,&view,out);}
    }
    nvm_websocket_host_leave();return report;
}
