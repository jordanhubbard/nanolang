# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi.h" 2








# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog.h" 2



# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog.h"
typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.h" 2



typedef struct NlWebSocketPlan NlWebSocketPlan;
typedef enum { NL_WEBSOCKET_PLAN_OK, NL_WEBSOCKET_PLAN_INVALID, NL_WEBSOCKET_PLAN_MEMORY } NlWebSocketPlanStatus;



NlWebSocketPlanStatus nl_websocket_plan_build(const NlNsi *,NlWebSocketPlan **out);
void nl_websocket_plan_free(NlWebSocketPlan *);
size_t nl_websocket_plan_storage_size(void);
const char *nl_websocket_plan_interface(const NlWebSocketPlan *);
size_t nl_websocket_plan_method_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_type_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_capability_count(const NlWebSocketPlan *);
const NlServicePlanMethod *nl_websocket_plan_method(const NlWebSocketPlan *,size_t);
const NlServicePlanType *nl_websocket_plan_type(const NlWebSocketPlan *,size_t);
const NlServicePlanCapability *nl_websocket_plan_capability(const NlWebSocketPlan *,size_t);
const char *nl_websocket_catalog_interface(void);
const NlServicePlanMethod *nl_websocket_catalog_method(size_t);
const NlServicePlanType *nl_websocket_catalog_type(size_t);
const NlServicePlanCapability *nl_websocket_catalog_capability(size_t);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 1



# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4

# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 2




# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
typedef struct {
    const char *interface_id, *interface_name;
    const char *error_id, *error_name, *error_version;
    const NlServicePlanCapability *capabilities;
    size_t capability_count;
    const NlServicePlanMethod *methods;
    size_t method_count;
    const NlServicePlanType *types;
    size_t type_count;
} NlServiceCatalog;
static inline 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
             _Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                  nl_service_catalog_text_equal(const char *a, const char *b) {
    return (!a || !b) ? a == b : strcmp(a, b) == 0;
}
static inline 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
             _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                  nl_service_catalog_document_equal(const NlNsi *n, const NlServiceCatalog *c) {
    if (!n || n->version != 0 ||
        !nl_service_catalog_text_equal(n->iface.id, c->interface_id) ||
        !nl_service_catalog_text_equal(n->iface.name, c->interface_name) ||
        n->method_count != c->method_count || n->type_count != c->type_count ||
        n->error_count != 1 || n->capability_count != c->capability_count ||
        !n->methods || !n->types || !n->errors || !n->capabilities) return 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                          0
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                               ;
    if (!nl_service_catalog_text_equal(n->errors[0].id, c->error_id) ||
        !nl_service_catalog_text_equal(n->errors[0].name, c->error_name) ||
        !nl_service_catalog_text_equal(n->errors[0].version, c->error_version)) return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                                      0
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                                           ;
    for(size_t i=0;i<c->capability_count;i++) {
        if(!nl_service_catalog_text_equal(n->capabilities[i].id,c->capabilities[i].id) ||
           !nl_service_catalog_text_equal(n->capabilities[i].name,c->capabilities[i].name))return 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                                                 0
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                                                      ;
    }
    for (size_t i = 0; i < c->method_count; i++) {
        const NlNsiMethod *a = &n->methods[i];
        const NlServicePlanMethod *b = &c->methods[i];
        if (!nl_service_catalog_text_equal(a->id, b->id) ||
            !nl_service_catalog_text_equal(a->name, b->name) || a->idempotent != 0 ||
            a->param_count != b->param_count || !a->params) return 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                  0
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                       ;
        for (size_t j = 0; j < b->param_count; j++) {
            const NlNsiParam *x = &a->params[j];
            const NlServicePlanParam *y = &b->params[j];
            if (!nl_service_catalog_text_equal(x->id, y->id) ||
                !nl_service_catalog_text_equal(x->name, y->name) ||
                !nl_service_catalog_text_equal(x->type_id, y->type_id) ||
                x->direction != y->direction || x->ownership != y->ownership ||
                x->lifetime != y->lifetime || x->mutability != y->mutability ||
                x->optional != 0 || x->streaming != NL_NSI_STREAM_NONE) return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                              0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                                   ;
        }
    }
    for (size_t i = 0; i < c->type_count; i++) {
        const NlNsiType *a = &n->types[i];
        const NlServicePlanType *b = &c->types[i];
        if (!nl_service_catalog_text_equal(a->id, b->id) ||
            !nl_service_catalog_text_equal(a->name, b->name) || a->kind != b->kind ||
            a->member_count != b->member_count || a->element_id || a->method_id || a->result_id ||
            (b->member_count && !a->members) || (!b->member_count && a->members)) return 
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                                        0
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                                             ;
        for (size_t j = 0; j < b->member_count; j++) {
            const NlNsiMember *x = &a->members[j];
            const NlServicePlanMember *y = &b->members[j];
            if (!nl_service_catalog_text_equal(x->id, y->id) ||
                !nl_service_catalog_text_equal(x->name, y->name) ||
                !nl_service_catalog_text_equal(x->type_id, y->type_id)) return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
                                                                              0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
                                                                                   ;
        }
    }
    return 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h" 3 4
          1
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_service_catalog_internal.h"
              ;
}
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_cap.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_cap.h" 2
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_cap.h"
typedef enum {
    NL_CAP_AUDIT_CREATE = 0,
    NL_CAP_AUDIT_DELEGATE,
    NL_CAP_AUDIT_USE,
    NL_CAP_AUDIT_REVOKE,
    NL_CAP_AUDIT_FAIL,
    NL_CAP_AUDIT_TRANSFER,
    NL_CAP_AUDIT_RESTART
} NlCapAuditKind;

typedef struct {
    uint64_t secret;
    uint32_t slot;
    uint32_t generation;
} NlCap;

typedef struct NlCapTable NlCapTable;

NlCapTable *nl_cap_table_create(void);
void nl_cap_table_destroy(NlCapTable *t);

int nl_cap_mint(NlCapTable *t, const char *type_id, const char *service_id,
                uint32_t rights, int transferable, const char *scope, NlCap *out);
int nl_cap_check(NlCapTable *t, const NlCap *c, uint32_t need);
int nl_cap_attenuate(NlCapTable *t, const NlCap *parent, uint32_t rights, NlCap *out);
int nl_cap_transfer(NlCapTable *t, const NlCap *src, NlCap *out);
int nl_cap_revoke(NlCapTable *t, const NlCap *c);
int nl_cap_restart(NlCapTable *t);
int nl_cap_invalidate_service(NlCapTable *t, const char *service_id);

int nl_cap_from_integer(NlCapTable *t, uint64_t n, NlCap *out);
int nl_cap_from_pointer(NlCapTable *t, void *p, NlCap *out);

int nl_cap_resource_own(NlCapTable *t, const char *nsi_type_id,
                        const char *service_id, uint32_t rights, NlCap *out);
int nl_cap_resource_consume(NlCapTable *t, const NlCap *c);

int nl_cap_forth_bind(NlCapTable *t, const NlCap *c, uint64_t *cell);
int nl_cap_forth_lookup(NlCapTable *t, uint64_t cell, NlCap *out);

uint32_t nl_cap_rights(NlCapTable *t, const NlCap *c);
uint32_t nl_cap_generation(NlCapTable *t, const NlCap *c);
const char *nl_cap_type_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_service_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_scope(NlCapTable *t, const NlCap *c);
int nl_cap_revoked(NlCapTable *t, const NlCap *c);
int nl_cap_transferable(NlCapTable *t, const NlCap *c);

int nl_cap_audit_count(const NlCapTable *t);
int nl_cap_audit_kind(const NlCapTable *t, int i);
const char *nl_cap_audit_id(const NlCapTable *t, int i);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
static const NlServicePlanMember error_fields[]={
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "status","status","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "host_errno","host_errno","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "resolver_error","resolver_error","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "supervisor_status","supervisor_status","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "close_code","close_code","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "cleanup_errno","cleanup_errno","nsi:core/int",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "cleanup_failed","cleanup_failed","nsi:core/bool",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "closure_unknown","closure_unknown","nsi:core/bool",NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "WebSocketError" "." "terminal","terminal","nsi:core/bool",NL_SERVICE_DOMAIN_NONE}
};
static const NlServicePlanMember message_fields[]={
    {"nsi:nanolang/websocket" "#" "Message" "." "binary","binary","nsi:core/bool",NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "Message" "." "data","data","nsi:core/string",NL_SERVICE_DOMAIN_NONE}
};


static const NlServicePlanMember ConnectResult_cases[]={ {"nsi:nanolang/websocket" "#" "ConnectResult" "." "Ok","Ok","nsi:nanolang/websocket" "#" "Connection",NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "ConnectResult" "." "Error","Error","nsi:nanolang/websocket" "#" "WebSocketError",NL_SERVICE_DOMAIN_NONE} };
static const NlServicePlanMember SendResult_cases[]={ {"nsi:nanolang/websocket" "#" "SendResult" "." "Ok","Ok","nsi:core/int",NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "SendResult" "." "Error","Error","nsi:nanolang/websocket" "#" "WebSocketError",NL_SERVICE_DOMAIN_NONE} };
static const NlServicePlanMember ReceiveResult_cases[]={ {"nsi:nanolang/websocket" "#" "ReceiveResult" "." "Ok","Ok","nsi:nanolang/websocket" "#" "Message",NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "ReceiveResult" "." "Error","Error","nsi:nanolang/websocket" "#" "WebSocketError",NL_SERVICE_DOMAIN_NONE} };
static const NlServicePlanMember CloseResult_cases[]={ {"nsi:nanolang/websocket" "#" "CloseResult" "." "Ok","Ok",
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
((void *)0)
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
,NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "CloseResult" "." "Error","Error","nsi:nanolang/websocket" "#" "WebSocketError",NL_SERVICE_DOMAIN_NONE} };

static const NlServicePlanType types[]={
    {"nsi:nanolang/websocket" "#" "Connection","Connection",NL_NSI_TYPE_RESOURCE,
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                       ((void *)0)
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                           ,0},
    {"nsi:nanolang/websocket" "#" "WebSocketError","WebSocketError",NL_NSI_TYPE_RECORD,error_fields,(sizeof(error_fields)/sizeof((error_fields)[0]))},
    {"nsi:nanolang/websocket" "#" "Message","Message",NL_NSI_TYPE_RECORD,message_fields,(sizeof(message_fields)/sizeof((message_fields)[0]))},
    {"nsi:nanolang/websocket" "#" "ConnectResult","ConnectResult",NL_NSI_TYPE_VARIANT,ConnectResult_cases,(sizeof(ConnectResult_cases)/sizeof((ConnectResult_cases)[0]))},
    {"nsi:nanolang/websocket" "#" "SendResult","SendResult",NL_NSI_TYPE_VARIANT,SendResult_cases,(sizeof(SendResult_cases)/sizeof((SendResult_cases)[0]))},
    {"nsi:nanolang/websocket" "#" "ReceiveResult","ReceiveResult",NL_NSI_TYPE_VARIANT,ReceiveResult_cases,(sizeof(ReceiveResult_cases)/sizeof((ReceiveResult_cases)[0]))},
    {"nsi:nanolang/websocket" "#" "CloseResult","CloseResult",NL_NSI_TYPE_VARIANT,CloseResult_cases,(sizeof(CloseResult_cases)/sizeof((CloseResult_cases)[0]))}
};





static const NlServicePlanParam connect_params[]={
    {"nsi:nanolang/websocket" "#" "connect" "." "url","url","nsi:core/string",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "connect" "." "timeout_ms","timeout_ms","nsi:core/int",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_TIMEOUT_MS},
    {"nsi:nanolang/websocket" "#" "connect" "." "result","result","nsi:nanolang/websocket" "#" "ConnectResult",NL_NSI_DIR_RETURN,NL_NSI_OWN_TRANSFER,NL_NSI_LIFE_RESOURCE,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE}
};
static const NlServicePlanParam send_params[]={{"nsi:nanolang/websocket" "#" "send" "." "connection","connection","nsi:nanolang/websocket" "#" "Connection",NL_NSI_DIR_IN,NL_NSI_OWN_BORROW,NL_NSI_LIFE_CALL,NL_NSI_MUT_MUTABLE,NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "send" "." "message","message","nsi:nanolang/websocket" "#" "Message",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "send" "." "timeout_ms","timeout_ms","nsi:core/int",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_TIMEOUT_MS},{"nsi:nanolang/websocket" "#" "send" "." "result","result","nsi:nanolang/websocket" "#" "SendResult",NL_NSI_DIR_RETURN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALLER,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE}};
static const NlServicePlanParam receive_params[]={{"nsi:nanolang/websocket" "#" "receive" "." "connection","connection","nsi:nanolang/websocket" "#" "Connection",NL_NSI_DIR_IN,NL_NSI_OWN_BORROW,NL_NSI_LIFE_CALL,NL_NSI_MUT_MUTABLE,NL_SERVICE_DOMAIN_NONE},{"nsi:nanolang/websocket" "#" "receive" "." "timeout_ms","timeout_ms","nsi:core/int",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_TIMEOUT_MS},{"nsi:nanolang/websocket" "#" "receive" "." "result","result","nsi:nanolang/websocket" "#" "ReceiveResult",NL_NSI_DIR_RETURN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALLER,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE}};
static const NlServicePlanParam close_params[]={
    {"nsi:nanolang/websocket" "#" "close" "." "connection","connection","nsi:nanolang/websocket" "#" "Connection",NL_NSI_DIR_IN,NL_NSI_OWN_TRANSFER,NL_NSI_LIFE_CALLEE,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE},
    {"nsi:nanolang/websocket" "#" "close" "." "timeout_ms","timeout_ms","nsi:core/int",NL_NSI_DIR_IN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALL,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_TIMEOUT_MS},{"nsi:nanolang/websocket" "#" "close" "." "result","result","nsi:nanolang/websocket" "#" "CloseResult",NL_NSI_DIR_RETURN,NL_NSI_OWN_COPY,NL_NSI_LIFE_CALLER,NL_NSI_MUT_IMMUTABLE,NL_SERVICE_DOMAIN_NONE}
};


static const NlServicePlanMethod methods[]={
    {"nsi:nanolang/websocket" "#" "connect","connect","nsi_nanolang_websocket_" "connect","nsi.websocket.v1." "connect",1,0,1u|2u|16u,NL_SERVICE_INPUT_NONE,connect_params,(sizeof(connect_params)/sizeof((connect_params)[0])),{{NL_SERVICE_OWNER_NONE,"nsi:nanolang/websocket" "#" "Connection"},{NL_SERVICE_OWNER_NONE,
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   }}},
    {"nsi:nanolang/websocket" "#" "send","send","nsi_nanolang_websocket_" "send","nsi.websocket.v1." "send",1,2u,0,NL_SERVICE_INPUT_EXCLUSIVE,send_params,(sizeof(send_params)/sizeof((send_params)[0])),{{NL_SERVICE_OWNER_PRESERVED,
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   },{NL_SERVICE_OWNER_PRESERVED,
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   }}},
    {"nsi:nanolang/websocket" "#" "receive","receive","nsi_nanolang_websocket_" "receive","nsi.websocket.v1." "receive",1,1u,0,NL_SERVICE_INPUT_EXCLUSIVE,receive_params,(sizeof(receive_params)/sizeof((receive_params)[0])),{{NL_SERVICE_OWNER_PRESERVED,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   },{NL_SERVICE_OWNER_PRESERVED,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   }}},
    {"nsi:nanolang/websocket" "#" "close","close","nsi_nanolang_websocket_" "close","nsi.websocket.v1." "close",1,0,0,NL_SERVICE_INPUT_CONSUME,close_params,(sizeof(close_params)/sizeof((close_params)[0])),{{NL_SERVICE_OWNER_CONSUMED,
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   },{NL_SERVICE_OWNER_CONSUMED,
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
   ((void *)0)
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
   }}}
};
static const NlServicePlanCapability capabilities[]={
    {"cap:nanolang/websocket.connect","connect"},
    {"cap:nanolang/net.lookup","lookup"}
};
_Static_assert((sizeof(types)/sizeof((types)[0]))==7u,"I retain all WebSocket types");
_Static_assert((sizeof(methods)/sizeof((methods)[0]))==4u,"I retain all WebSocket methods");
_Static_assert((sizeof(capabilities)/sizeof((capabilities)[0]))==2u,"I separate network and DNS authority");
static const NlServiceCatalog catalog={"nsi:nanolang/websocket","websocket","nsi:nanolang/websocket" "#" "io","io","1",capabilities,(sizeof(capabilities)/sizeof((capabilities)[0])),methods,(sizeof(methods)/sizeof((methods)[0])),types,(sizeof(types)/sizeof((types)[0]))};
struct NlWebSocketPlan { const NlServiceCatalog *catalog; };
NlWebSocketPlanStatus nl_websocket_plan_build(const NlNsi *n,NlWebSocketPlan **out) {
    if(!out || !nl_service_catalog_document_equal(n,&catalog))return NL_WEBSOCKET_PLAN_INVALID;
    NlWebSocketPlan *p=malloc(sizeof *p);if(!p)return NL_WEBSOCKET_PLAN_MEMORY;
    p->catalog=&catalog;*out=p;return NL_WEBSOCKET_PLAN_OK;
}
void nl_websocket_plan_free(NlWebSocketPlan *p) { free(p); }
size_t nl_websocket_plan_storage_size(void) { return sizeof(NlWebSocketPlan); }
const char *nl_websocket_plan_interface(const NlWebSocketPlan *p) { return p?p->catalog->interface_id:
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                     ((void *)0)
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                         ; }
size_t nl_websocket_plan_method_count(const NlWebSocketPlan *p) { return p?p->catalog->method_count:0; }
size_t nl_websocket_plan_type_count(const NlWebSocketPlan *p) { return p?p->catalog->type_count:0; }
size_t nl_websocket_plan_capability_count(const NlWebSocketPlan *p) { return p?p->catalog->capability_count:0; }
const NlServicePlanMethod *nl_websocket_plan_method(const NlWebSocketPlan *p,size_t i) { return p && i<p->catalog->method_count?&p->catalog->methods[i]:
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                                                                       ((void *)0)
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                                                                           ; }
const NlServicePlanType *nl_websocket_plan_type(const NlWebSocketPlan *p,size_t i) { return p && i<p->catalog->type_count?&p->catalog->types[i]:
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                                                               ((void *)0)
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                                                                   ; }
const NlServicePlanCapability *nl_websocket_plan_capability(const NlWebSocketPlan *p,size_t i) { return p && i<p->catalog->capability_count?&p->catalog->capabilities[i]:
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                                                                                        ((void *)0)
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                                                                                            ; }
const char *nl_websocket_catalog_interface(void) { return "nsi:nanolang/websocket"; }
const NlServicePlanMethod *nl_websocket_catalog_method(size_t i) { return i<(sizeof(methods)/sizeof((methods)[0]))?&methods[i]:
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                      ((void *)0)
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                          ; }
const NlServicePlanType *nl_websocket_catalog_type(size_t i) { return i<(sizeof(types)/sizeof((types)[0]))?&types[i]:
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                              ((void *)0)
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                  ; }
const NlServicePlanCapability *nl_websocket_catalog_capability(size_t i) { return i<(sizeof(capabilities)/sizeof((capabilities)[0]))?&capabilities[i]:
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c" 3 4
                                                                                                                        ((void *)0)
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nsi_websocket_plan.c"
                                                                                                                            ; }
