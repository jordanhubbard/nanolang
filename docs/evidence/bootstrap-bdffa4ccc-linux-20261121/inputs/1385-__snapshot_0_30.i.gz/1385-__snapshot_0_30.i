# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_abi.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_abi.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_public.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_abi.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 2
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
typedef struct {
    uint32_t catalog;
    uint32_t imports[5], layouts[9];
} NvmServiceInstance;
typedef struct {
    uint32_t count;
    NvmServiceInstance instances[64u];
} NvmMultiNominalBindings;






uint32_t nvm_multi_nominal_catalog_types(uint32_t catalog);
uint32_t nvm_multi_nominal_catalog_methods(uint32_t catalog);
NvmServiceResult nvm_multi_nominal_check(const NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_decode(const uint8_t *,size_t,NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_encode(const NvmMultiNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum { NVM_MULTI_NOMINAL_DESCRIBED, NVM_MULTI_NOMINAL_INVALID,
    NVM_MULTI_NOMINAL_LIMIT, NVM_MULTI_NOMINAL_MEMORY } NvmMultiNominalStatus;
typedef struct {
    uint32_t global_index, instance, catalog, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
} NvmMultiNominalLayout;
typedef struct NvmMultiNominalPlan NvmMultiNominalPlan;


NvmMultiNominalStatus nvm_multi_nominal_plan(const NvmModule *,NvmMultiNominalPlan **);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_storage_bound(uint32_t,size_t *);
uint32_t nvm_multi_nominal_layout_count(const NvmMultiNominalPlan *);
void nvm_multi_nominal_plan_free(NvmMultiNominalPlan *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_layout(const NvmMultiNominalPlan *,uint32_t,NvmMultiNominalLayout *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_type(const NvmMultiNominalPlan *,uint32_t,uint32_t,NvmMultiNominalLayout *);

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_import(const NvmMultiNominalPlan *,uint32_t,uint32_t,uint32_t *);
uint32_t nvm_multi_nominal_instance_count(const NvmMultiNominalPlan *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 2



typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h" 2


const char *nl_file_catalog_interface(void);
const NlFilePlanMethod *nl_file_catalog_method(size_t);
const NlFilePlanType *nl_file_catalog_type(size_t);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 1







typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_socket_plan_free(NlSocketPlan *);
size_t nl_socket_plan_storage_size(void);
const char *nl_socket_plan_interface(const NlSocketPlan *);
size_t nl_socket_plan_method_count(const NlSocketPlan *);
size_t nl_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_socket_catalog_interface(void);
const NlServicePlanMethod *nl_socket_catalog_method(size_t);
const NlServicePlanType *nl_socket_catalog_type(size_t);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 2



typedef enum {
 NVM_SERVICES_CATEGORY_UNKNOWN, NVM_SERVICES_CATEGORY_OWNER,
 NVM_SERVICES_CATEGORY_OWNER_RESULT, NVM_SERVICES_CATEGORY_SCALAR_RESULT,
 NVM_SERVICES_CATEGORY_RECORD
} NvmServicesCategory;
typedef struct {
 uint32_t global_index,catalog_ordinal,source_ordinal;
 uint8_t layout_kind,ownership_flags;
 NvmServicesCategory category;
} NvmServicesNominalLayout;
typedef NvmMultiNominalPlan NvmServicesNominalPlan;
typedef NvmMultiNominalBindings NvmServicesNominalBindings;




NvmMultiNominalStatus nvm_services_nominal_plan(const NvmModule *,NvmServicesNominalPlan **);





# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h"
    nvm_services_nominal_layout(const NvmServicesNominalPlan *,uint32_t,NvmServicesNominalLayout *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h"
    nvm_services_nominal_type(const NvmServicesNominalPlan *,uint32_t,NvmServicesNominalLayout *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h"
    nvm_services_nominal_source(const NvmServicesNominalPlan *,uint8_t,uint32_t,NvmServicesNominalLayout *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h"
    nvm_services_nominal_import(const NvmServicesNominalPlan *,uint32_t,uint32_t *);
const NlServicePlanType *nvm_services_catalog_type(const NvmServicesNominalPlan *,uint32_t);
const NlServicePlanMethod *nvm_services_catalog_method(const NvmServicesNominalPlan *,uint32_t);
uint32_t nvm_services_catalog_types(const NvmServicesNominalPlan *,uint32_t);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_nominal.h"
    nvm_services_catalog_endpoint(const NvmServicesNominalPlan *,uint32_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 2
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
typedef enum {
    NVM_SERVICES_FLOW_OK, NVM_SERVICES_FLOW_INVALID, NVM_SERVICES_FLOW_UNRESOLVED,
    NVM_SERVICES_FLOW_LIMIT, NVM_SERVICES_FLOW_MEMORY
} NvmServicesFlowStatus;
typedef struct NvmServicesFlowDeclarations NvmServicesFlowDeclarations;
typedef struct NvmServicesFlowState NvmServicesFlowState;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_index, catalog_ordinal;
    NvmServicesCategory category;
} NvmServicesFlowDeclaration;
typedef struct {
    uint16_t parameters, locals;
    uint8_t result_count;
    NvmServicesFlowDeclaration result;
} NvmServicesFlowFunction;
typedef enum {
    NVM_SERVICES_FLOW_ARM_NONE, NVM_SERVICES_FLOW_ARM_UNKNOWN,
    NVM_SERVICES_FLOW_ARM_OK, NVM_SERVICES_FLOW_ARM_ERROR
} NvmServicesFlowArm;
typedef struct {
    NvmServicesFlowDeclaration type;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
        initialized;
    uint64_t owner;
    NvmServicesFlowArm arm;
} NvmServicesFlowValue;
typedef struct {
    
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
        live, formal;
    uint16_t local;
    uint64_t owner, identity, region;
    
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
   _Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
        shared;
} NvmServicesFlowReference;
typedef struct {
    uint16_t stack, regions, owners, references;
    uint64_t cleanup_obligations;
    uint16_t obligations;
    
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
   _Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
        reachable;
} NvmServicesFlowCounts;



typedef enum { NVM_SERVICES_FLOW_SERVICE, NVM_SERVICES_FLOW_CALL } NvmServicesFlowObligationKind;
typedef enum { NVM_SERVICES_FLOW_INPUT_NONE, NVM_SERVICES_FLOW_INPUT_PRESERVED,
               NVM_SERVICES_FLOW_INPUT_CONSUMED } NvmServicesFlowInputState;
enum {
    NVM_SERVICES_FLOW_CHECK_BINDING=1u, NVM_SERVICES_FLOW_CHECK_INVOCATION=2u,
    NVM_SERVICES_FLOW_CHECK_LIVENESS=4u, NVM_SERVICES_FLOW_CHECK_RIGHTS=8u,
    NVM_SERVICES_FLOW_CHECK_BORROW=16u, NVM_SERVICES_FLOW_CHECK_BYTE=32u,
    NVM_SERVICES_FLOW_CHECK_CALLEE=64u, NVM_SERVICES_FLOW_CHECK_CLEANUP=128u,
    NVM_SERVICES_FLOW_CHECK_RESULT=256u, NVM_SERVICES_FLOW_CHECK_ENDPOINT=512u,
    NVM_SERVICES_FLOW_CHECK_TIMEOUT=1024u
};
typedef struct {
    NvmServicesFlowObligationKind kind;
    uint32_t site, target, checks, required_rights, acquired_rights;
    uint16_t parameters, owned_inputs, borrowed_inputs;
    uint8_t result_count;
    NvmServicesFlowDeclaration result;
    NvmServicesFlowInputState outcomes[2];
} NvmServicesFlowObligation;




NvmServicesFlowStatus nvm_services_flow_declarations(const NvmModule *, NvmServicesFlowDeclarations **out);
void nvm_services_flow_declarations_free(NvmServicesFlowDeclarations *);

# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_function(const NvmServicesFlowDeclarations *, uint32_t, NvmServicesFlowFunction *);

# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_declaration(const NvmServicesFlowDeclarations *, uint32_t, uint16_t,
                             NvmServicesFlowDeclaration *);


NvmServicesFlowStatus nvm_services_flow_state(NvmServicesFlowDeclarations *, uint32_t, NvmServicesFlowState **out);
void nvm_services_flow_state_free(NvmServicesFlowState *);

# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_local(const NvmServicesFlowState *, uint16_t, NvmServicesFlowValue *);

# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_stack(const NvmServicesFlowState *, uint16_t, NvmServicesFlowValue *);

# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_reference(const NvmServicesFlowState *, uint16_t, NvmServicesFlowReference *);

# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_counts(const NvmServicesFlowState *, NvmServicesFlowCounts *);

# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
_Bool 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
    nvm_services_flow_obligation(const NvmServicesFlowState *, uint16_t, NvmServicesFlowObligation *);
NvmServicesFlowStatus nvm_services_flow_clone(const NvmServicesFlowState *, NvmServicesFlowState **out);

NvmServicesFlowStatus nvm_services_flow_refine(const NvmServicesFlowState *, uint16_t local,
                                     NvmServicesFlowState **ok, NvmServicesFlowState **error);
NvmServicesFlowStatus nvm_services_flow_join(NvmServicesFlowState *, const NvmServicesFlowState *, 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h" 3 4
                                                                                                  _Bool 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
                                                                                                       *changed);



NvmServicesFlowStatus nvm_services_flow_push_scalar(NvmServicesFlowState *, uint8_t);
NvmServicesFlowStatus nvm_services_flow_load(NvmServicesFlowState *, uint16_t);
NvmServicesFlowStatus nvm_services_flow_store(NvmServicesFlowState *, uint16_t);
NvmServicesFlowStatus nvm_services_flow_dup(NvmServicesFlowState *);
NvmServicesFlowStatus nvm_services_flow_pop(NvmServicesFlowState *);
NvmServicesFlowStatus nvm_services_flow_clear_copy(NvmServicesFlowState *, uint16_t);


NvmServicesFlowStatus nvm_services_flow_construct(NvmServicesFlowState *, uint32_t type_id, uint16_t variant);
NvmServicesFlowStatus nvm_services_flow_field(NvmServicesFlowState *, uint16_t field);
NvmServicesFlowStatus nvm_services_flow_take_result(NvmServicesFlowState *, uint16_t local, NvmServicesFlowArm);
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_flow.h"
NvmServicesFlowStatus nvm_services_flow_service(NvmServicesFlowState *, uint32_t site, uint32_t import,
                                      uint16_t reference);




NvmServicesFlowStatus nvm_services_flow_call(NvmServicesFlowState *, uint32_t site, uint32_t function,
                                   const uint16_t *references, uint16_t count);
NvmServicesFlowStatus nvm_services_flow_move(NvmServicesFlowState *, uint16_t from, uint16_t to);
NvmServicesFlowStatus nvm_services_flow_take(NvmServicesFlowState *, uint16_t);
NvmServicesFlowStatus nvm_services_flow_put(NvmServicesFlowState *, uint16_t);

NvmServicesFlowStatus nvm_services_flow_drop_local(NvmServicesFlowState *, uint16_t);
NvmServicesFlowStatus nvm_services_flow_drop_stack(NvmServicesFlowState *);
NvmServicesFlowStatus nvm_services_flow_region_begin(NvmServicesFlowState *);
NvmServicesFlowStatus nvm_services_flow_region_end(NvmServicesFlowState *);
NvmServicesFlowStatus nvm_services_flow_borrow(NvmServicesFlowState *, uint16_t local, uint16_t reference);
NvmServicesFlowStatus nvm_services_flow_borrow_shared(NvmServicesFlowState *,uint16_t local,uint16_t reference);
NvmServicesFlowStatus nvm_services_flow_end_borrow(NvmServicesFlowState *, uint16_t reference);



NvmServicesFlowStatus nvm_services_flow_can_exit(const NvmServicesFlowState *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
typedef struct NvmServicesCodePlan NvmServicesCodePlan;
typedef struct {
    uint32_t byte_offset;
    DecodedInstruction decoded;
    uint16_t successors[2];
    uint8_t successor_count;
    uint16_t call_references[256u];
    uint32_t catalog_ordinal;
} NvmServicesCodeInstruction;
typedef struct {
    uint32_t code_offset, code_length;
    uint16_t instruction_count;
    NvmServicesFlowFunction declaration;
} NvmServicesCodeFunction;
NvmServicesFlowStatus nvm_services_code_prepare(const NvmModule *, NvmServicesCodePlan **out);
void nvm_services_code_free(NvmServicesCodePlan *);
uint32_t nvm_services_code_function_count(const NvmServicesCodePlan *);


# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
    nvm_services_code_function(const NvmServicesCodePlan *, uint32_t, NvmServicesCodeFunction *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
    nvm_services_code_local(const NvmServicesCodePlan *, uint32_t, uint16_t,
                         NvmServicesFlowDeclaration *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
    nvm_services_code_instruction(const NvmServicesCodePlan *, uint32_t, uint16_t,
                               NvmServicesCodeInstruction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
    nvm_services_code_instruction_order(const NvmServicesCodePlan *, uint32_t, uint16_t,
                                     uint16_t *);


# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_code.h"
    nvm_services_code_function_order(const NvmServicesCodePlan *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 2




typedef struct NvmServicesBodyReport NvmServicesBodyReport;
typedef enum {
    NVM_SERVICES_BODY_CLEANUP_NORMAL, NVM_SERVICES_BODY_CLEANUP_DROP_LOCAL,
    NVM_SERVICES_BODY_CLEANUP_DROP_STACK, NVM_SERVICES_BODY_CLEANUP_ASSERT,
    NVM_SERVICES_BODY_CLEANUP_RETURN, NVM_SERVICES_BODY_CLEANUP_CALL,
    NVM_SERVICES_BODY_CLEANUP_SERVICE
} NvmServicesBodyCleanup;
typedef struct {
    
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h"
        reachable, exit_checked, refinement, has_obligation;
    uint16_t input_stack, output_stack, cleanup_local;
    NvmServicesBodyCleanup cleanup;
    uint32_t discharged_checks, pending_checks;
    NvmServicesFlowObligation obligation;
} NvmServicesBodyInstruction;
NvmServicesFlowStatus nvm_services_body_analyze(const NvmModule *, NvmServicesBodyReport **out);
void nvm_services_body_free(NvmServicesBodyReport *);
uint32_t nvm_services_body_function_count(const NvmServicesBodyReport *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h"
    nvm_services_body_function(const NvmServicesBodyReport *, uint32_t, NvmServicesCodeFunction *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h"
    nvm_services_body_local(const NvmServicesBodyReport *, uint32_t, uint16_t, NvmServicesFlowDeclaration *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_body.h"
    nvm_services_body_instruction(const NvmServicesBodyReport *, uint32_t, uint16_t,
                              NvmServicesCodeInstruction *, NvmServicesBodyInstruction *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
typedef struct NvmServicesCyclicReport NvmServicesCyclicReport;
typedef struct {
    uint32_t revision, functions, instructions, variants, transfers, edges;
    size_t storage_peak;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
        runtime_admitted;
} NvmServicesCyclicSummary;
typedef struct {
    uint16_t locals, stack, regions, owners, references;
} NvmServicesCyclicStateInfo;
typedef struct {
    NvmServicesCyclicStateInfo input, output;
    NvmServicesBodyInstruction body;
    uint8_t edge_mask, edge_variants[2];


} NvmServicesCyclicVariant;
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
NvmServicesFlowStatus nvm_services_cyclic_analyze(const NvmModule *, NvmServicesCyclicReport **);
void nvm_services_cyclic_free(NvmServicesCyclicReport *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_summary(const NvmServicesCyclicReport *, NvmServicesCyclicSummary *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_function(const NvmServicesCyclicReport *, uint32_t, NvmServicesCodeFunction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_local(const NvmServicesCyclicReport *, uint32_t, uint16_t, NvmServicesFlowDeclaration *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_instruction(const NvmServicesCyclicReport *, uint32_t, uint16_t, NvmServicesCodeInstruction *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_component(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint16_t *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_variant_count(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_variant(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t, NvmServicesCyclicVariant *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_input_local(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmServicesFlowValue *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_input_stack(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmServicesFlowValue *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_input_reference(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmServicesFlowReference *);

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_input_region(const NvmServicesCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, uint64_t *);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_type(const NvmServicesCyclicReport *, uint32_t, NvmServicesNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_cyclic.h"
    nvm_services_cyclic_import(const NvmServicesCyclicReport *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h" 1





typedef struct NvmServicesIndirectTargets NvmServicesIndirectTargets;
typedef enum { NVM_SERVICES_INDIRECT_DESCRIBED, NVM_SERVICES_INDIRECT_INVALID,
 NVM_SERVICES_INDIRECT_UNRESOLVED, NVM_SERVICES_INDIRECT_LIMIT,
 NVM_SERVICES_INDIRECT_MEMORY } NvmServicesIndirectStatus;
typedef struct {
 NvmServicesIndirectStatus status;
 uint32_t function,pc;
 const char *message;
} NvmServicesIndirectResult;
typedef struct {
 uint32_t functions,instructions,calls,visits;
 size_t storage_bound;
} NvmServicesIndirectSummary;
typedef struct {
 uint32_t function,pc;
 uint16_t instruction,parameters;
 uint64_t candidates;
 uint8_t result_count;
 NvmServicesFlowDeclaration result;
} NvmServicesIndirectCall;





NvmServicesIndirectResult nvm_services_indirect_targets(const NvmModule *,NvmServicesIndirectTargets **);
void nvm_services_indirect_targets_free(NvmServicesIndirectTargets *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h"
    nvm_services_indirect_targets_summary(const NvmServicesIndirectTargets *,NvmServicesIndirectSummary *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h"
    nvm_services_indirect_targets_call(const NvmServicesIndirectTargets *,uint32_t,NvmServicesIndirectCall *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_targets.h"
    nvm_services_indirect_targets_parameter(const NvmServicesIndirectTargets *,uint32_t,uint16_t,NvmServicesFlowDeclaration *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 2


typedef struct NvmServicesIndirectFlow NvmServicesIndirectFlow;
typedef struct {
 NvmServicesIndirectSummary targets;
 NvmServicesCyclicSummary ownership;
 uint32_t candidate_applications;
 size_t storage_bound;
 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
     runtime_admitted;
} NvmServicesIndirectFlowSummary;
typedef struct {
 uint32_t function,pc;
 uint64_t candidates,checked_candidates;
 NvmServicesFlowObligation common;
} NvmServicesIndirectFlowCall;





NvmServicesFlowStatus nvm_services_indirect_flow_analyze(const NvmModule *,NvmServicesIndirectFlow **);
void nvm_services_indirect_flow_free(NvmServicesIndirectFlow *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_summary(const NvmServicesIndirectFlow *,NvmServicesIndirectFlowSummary *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_function(const NvmServicesIndirectFlow *,uint32_t,NvmServicesCodeFunction *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_local(const NvmServicesIndirectFlow *,uint32_t,uint16_t,NvmServicesFlowDeclaration *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_instruction(const NvmServicesIndirectFlow *,uint32_t,uint16_t,NvmServicesCodeInstruction *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_variant_count(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_variant(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmServicesCyclicVariant *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_input_local(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowValue *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_input_stack(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowValue *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_input_reference(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowReference *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_input_region(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_call(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmServicesIndirectFlowCall *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_component(const NvmServicesIndirectFlow *,uint32_t,uint16_t,uint16_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_type(const NvmServicesIndirectFlow *,uint32_t,NvmServicesNominalLayout *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_flow.h"
    nvm_services_indirect_flow_import(const NvmServicesIndirectFlow *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 1





typedef struct NvmServicesHostedPlan NvmServicesHostedPlan;
typedef struct {
    uint32_t entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t allocation_bound;
} NvmServicesHostedStartup;
typedef struct {
    NvmServicesCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
} NvmServicesHostedFunction;






NvmServicesFlowStatus nvm_services_hosted_prepare(const uint8_t *,size_t,NvmServicesHostedPlan **);
void nvm_services_hosted_free(NvmServicesHostedPlan *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_startup(const NvmServicesHostedPlan *,NvmServicesHostedStartup *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_function(const NvmServicesHostedPlan *,uint32_t,NvmServicesHostedFunction *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_local(const NvmServicesHostedPlan *,uint32_t,uint16_t,NvmServicesFlowDeclaration *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_instruction(const NvmServicesHostedPlan *,uint32_t,uint16_t,
                                NvmServicesCodeInstruction *,NvmServicesBodyInstruction *);


# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_type(const NvmServicesHostedPlan *,uint32_t,NvmServicesNominalLayout *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_hosted.h"
    nvm_services_hosted_import(const NvmServicesHostedPlan *,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 2







typedef struct NvmServicesIndirectHostedPlan NvmServicesIndirectHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
        runtime_admitted;
} NvmServicesIndirectHostedStartup;
typedef struct {
    NvmServicesCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmServicesIndirectHostedFunction;




NvmServicesFlowStatus nvm_services_indirect_hosted_prepare(const uint8_t *,size_t,NvmServicesIndirectHostedPlan **);
void nvm_services_indirect_hosted_free(NvmServicesIndirectHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_query_summary(const NvmServicesIndirectHostedPlan *,NvmServicesIndirectFlowSummary *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_startup(const NvmServicesIndirectHostedPlan *,NvmServicesIndirectHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_function(const NvmServicesIndirectHostedPlan *,uint32_t,NvmServicesIndirectHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_function_order(const NvmServicesIndirectHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_local(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,NvmServicesFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_instruction(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,NvmServicesCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_component(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_variant_count(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_variant(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmServicesCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_input_local(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_input_stack(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_input_reference(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmServicesFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_input_region(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_type(const NvmServicesIndirectHostedPlan *,uint32_t,NvmServicesNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_import(const NvmServicesIndirectHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_bytes(const NvmServicesIndirectHostedPlan *,size_t,void *,size_t);

# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_call(const NvmServicesIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmServicesIndirectFlowCall *);


# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h" 3 4
_Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_hosted.h"
    nvm_services_indirect_hosted_string(const NvmServicesIndirectHostedPlan *,uint32_t,const uint8_t **,size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_cap.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_cap.h" 2
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_cap.h"
typedef enum {
    NL_CAP_AUDIT_CREATE = 0,
    NL_CAP_AUDIT_DELEGATE,
    NL_CAP_AUDIT_USE,
    NL_CAP_AUDIT_REVOKE,
    NL_CAP_AUDIT_FAIL,
    NL_CAP_AUDIT_TRANSFER,
    NL_CAP_AUDIT_RESTART
} NlCapAuditKind;

typedef struct {
    uint64_t secret;
    uint32_t slot;
    uint32_t generation;
} NlCap;

typedef struct NlCapTable NlCapTable;

NlCapTable *nl_cap_table_create(void);
void nl_cap_table_destroy(NlCapTable *t);

int nl_cap_mint(NlCapTable *t, const char *type_id, const char *service_id,
                uint32_t rights, int transferable, const char *scope, NlCap *out);
int nl_cap_check(NlCapTable *t, const NlCap *c, uint32_t need);
int nl_cap_attenuate(NlCapTable *t, const NlCap *parent, uint32_t rights, NlCap *out);
int nl_cap_transfer(NlCapTable *t, const NlCap *src, NlCap *out);
int nl_cap_revoke(NlCapTable *t, const NlCap *c);
int nl_cap_restart(NlCapTable *t);
int nl_cap_invalidate_service(NlCapTable *t, const char *service_id);

int nl_cap_from_integer(NlCapTable *t, uint64_t n, NlCap *out);
int nl_cap_from_pointer(NlCapTable *t, void *p, NlCap *out);

int nl_cap_resource_own(NlCapTable *t, const char *nsi_type_id,
                        const char *service_id, uint32_t rights, NlCap *out);
int nl_cap_resource_consume(NlCapTable *t, const NlCap *c);

int nl_cap_forth_bind(NlCapTable *t, const NlCap *c, uint64_t *cell);
int nl_cap_forth_lookup(NlCapTable *t, uint64_t cell, NlCap *out);

uint32_t nl_cap_rights(NlCapTable *t, const NlCap *c);
uint32_t nl_cap_generation(NlCapTable *t, const NlCap *c);
const char *nl_cap_type_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_service_id(NlCapTable *t, const NlCap *c);
const char *nl_cap_scope(NlCapTable *t, const NlCap *c);
int nl_cap_revoked(NlCapTable *t, const NlCap *c);
int nl_cap_transferable(NlCapTable *t, const NlCap *c);

int nl_cap_audit_count(const NlCapTable *t);
int nl_cap_audit_kind(const NlCapTable *t, int i);
const char *nl_cap_audit_id(const NlCapTable *t, int i);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 2

# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 2




typedef struct NlFileService NlFileService;


# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h"
    nl_file_service_storage_bound(size_t *out);

typedef struct {
    uint64_t context_id;
    NlCap cap;
} NlFileToken;

typedef enum {
    NL_FILE_OK = 0,
    NL_FILE_ARGUMENT,
    NL_FILE_DISPOSED,
    NL_FILE_TOKEN,
    NL_FILE_RIGHTS,
    NL_FILE_CAPACITY,
    NL_FILE_LIMIT,
    NL_FILE_MEMORY,
    NL_FILE_IO,
    NL_FILE_DIRECTION
} NlFileStatus;

typedef struct {
    NlFileStatus status;
    int host_errno;
    int cleanup_errno;
    size_t bytes;
    
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h"
        eof;
    
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h"
        consumed;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file.h"
        cleanup_failed;
} NlFileResult;


NlFileResult nl_file_service_create(NlFileService **out);
NlFileResult nl_file_acquire_temp(NlFileService *, uint32_t rights, NlFileToken *out);



NlFileResult nl_file_read(NlFileService *, const NlFileToken *, void *, size_t);
NlFileResult nl_file_write(NlFileService *, const NlFileToken *, const void *, size_t);
NlFileResult nl_file_rewind(NlFileService *, const NlFileToken *);


NlFileResult nl_file_transfer(NlFileService *, const NlFileToken *, NlFileToken *out);

NlFileResult nl_file_consume_close(NlFileService *, const NlFileToken *);



NlFileResult nl_file_service_dispose(NlFileService *);
NlFileResult nl_file_service_destroy(NlFileService *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 2





typedef struct NlFileValues NlFileValues;


# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
_Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
    nl_file_values_storage_bound(size_t *out);



typedef enum {
    NL_FILE_VALUE_OK, NL_FILE_VALUE_ARGUMENT, NL_FILE_VALUE_STALE,
    NL_FILE_VALUE_TYPE, NL_FILE_VALUE_BORROWED, NL_FILE_VALUE_LIMIT,
    NL_FILE_VALUE_MEMORY, NL_FILE_VALUE_DISPOSED, NL_FILE_VALUE_STATE,
    NL_FILE_VALUE_STATUS_COUNT
} NlFileValueStatus;


typedef struct { uint64_t invocation, generation; uint32_t slot; } NlFileValue;
typedef struct { NlFileValue value; uint64_t epoch; } NlFileValueBorrow;
typedef struct { 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
                _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
                     ok; NlFileResult error; } NlFileOpenView;
typedef enum {
    NL_FILE_VALUE_WRITE, NL_FILE_VALUE_POSITION, NL_FILE_VALUE_READ,
    NL_FILE_VALUE_CLOSE
} NlFileScalarKind;
typedef struct {
    NlFileScalarKind kind;
    
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
        ok;
    NlFileResult detail;
    int64_t value;
    
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
   _Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
        eof;
} NlFileScalarResult;
typedef struct {
    NlFileValueStatus execution;
    uint64_t cleanup_failures;
    NlFileResult first_cleanup, next_cleanup;
} NlFileValuesFinish;


NlFileValueStatus nl_file_values_create(NlFileValues **out);


NlFileValueStatus nl_file_values_temp(NlFileValues *, NlFileValue *out);


NlFileValueStatus nl_file_value_move(NlFileValues *, NlFileValue *source, NlFileValue *out);
NlFileValueStatus nl_file_open_view(NlFileValues *, const NlFileValue *, NlFileOpenView *out);
NlFileValueStatus nl_file_open_take_ok(NlFileValues *, NlFileValue *, NlFileValue *out);

NlFileValueStatus nl_file_open_take_error(NlFileValues *, NlFileValue *, NlFileResult *out);
NlFileValueStatus nl_file_value_borrow(NlFileValues *, const NlFileValue *, NlFileValueBorrow *out);
NlFileValueStatus nl_file_value_end_borrow(NlFileValues *, NlFileValueBorrow *);


NlFileValueStatus nl_file_value_write_byte(NlFileValues *, const NlFileValueBorrow *, int64_t, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_rewind(NlFileValues *, const NlFileValueBorrow *, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_read_byte(NlFileValues *, const NlFileValueBorrow *, NlFileScalarResult *out);
NlFileValueStatus nl_file_value_close(NlFileValues *, NlFileValue *, NlFileScalarResult *out);


NlFileValueStatus nl_file_value_drop(NlFileValues *, NlFileValue *);






# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_values.h"
    nl_file_values_report(const NlFileValues *, NlFileValuesFinish *out);
NlFileValuesFinish nl_file_values_finish(NlFileValues *, NlFileValueStatus first_execution_error);
NlFileValuesFinish nl_file_values_destroy(NlFileValues *, NlFileValueStatus first_execution_error);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 1





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 2





typedef struct NlSocketService NlSocketService;
typedef struct { uint64_t context_id; NlCap cap; } NlSocketToken;
typedef struct { NlSocketToken endpoints[2]; } NlSocketPair;
typedef enum { NL_SOCKET_IPV4 = 4, NL_SOCKET_IPV6 = 6 } NlSocketFamily;
typedef struct {
    NlSocketFamily family;
    uint8_t address[16];
    uint16_t port;
    uint32_t scope_id;
} NlSocketAddress;
typedef enum {
    NL_SOCKET_OK = 0, NL_SOCKET_EOF, NL_SOCKET_WOULD_BLOCK,
    NL_SOCKET_INTERRUPTED, NL_SOCKET_ARGUMENT, NL_SOCKET_DISPOSED,
    NL_SOCKET_TOKEN, NL_SOCKET_RIGHTS, NL_SOCKET_CAPACITY, NL_SOCKET_LIMIT,
    NL_SOCKET_MEMORY, NL_SOCKET_IO
} NlSocketStatus;
typedef struct {
    NlSocketStatus status;
    int host_errno, cleanup_errno;
    size_t bytes;
    unsigned close_attempts, closed_count;
    
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 3 4
   _Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h"
        eof, consumed, cleanup_failed, closure_unknown;
    
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 3 4
   _Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h"
        connect_pending;
} NlSocketResult;





NlSocketResult nl_socket_service_create(NlSocketService **out);


# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h"
    nl_socket_service_storage_bound(size_t *out);
NlSocketResult nl_socket_acquire_pair(NlSocketService *, uint32_t left_rights,
                                     uint32_t right_rights, NlSocketPair *out);




NlSocketResult nl_socket_acquire_tcp(NlSocketService *, const NlSocketAddress *,
                                    uint32_t rights, NlSocketToken *out);



NlSocketResult nl_socket_finish_connect(NlSocketService *, const NlSocketToken *);





NlSocketResult nl_socket_send(NlSocketService *, const NlSocketToken *, const void *, size_t);
NlSocketResult nl_socket_receive(NlSocketService *, const NlSocketToken *, void *, size_t);
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h"
typedef struct {
    size_t count;
    NlSocketAddress addresses[16u];
} NlSocketResolution;
typedef struct {
    NlSocketStatus status;
    int resolver_error;
    int host_errno;
} NlSocketResolveResult;
NlSocketResolveResult nl_socket_resolve_tcp(NlSocketService *, const char *host,
    size_t length, uint16_t port, 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h" 3 4
                                 _Bool 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket.h"
                                      allow_lookup, NlSocketResolution *out);

NlSocketResult nl_socket_send_byte(NlSocketService *, const NlSocketToken *, uint8_t);
NlSocketResult nl_socket_receive_byte(NlSocketService *, const NlSocketToken *, uint8_t *out);
NlSocketResult nl_socket_transfer(NlSocketService *, const NlSocketToken *, NlSocketToken *out);


NlSocketResult nl_socket_consume_close(NlSocketService *, const NlSocketToken *);


NlSocketResult nl_socket_service_dispose(NlSocketService *);
NlSocketResult nl_socket_service_destroy(NlSocketService *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 2



typedef struct NlSocketValues NlSocketValues;


typedef struct {
    int64_t family, address0, address1, address2, address3, port, scope_id;
} NlSocketEndpoint;

typedef enum {
    NL_SOCKET_VALUE_OK, NL_SOCKET_VALUE_ARGUMENT, NL_SOCKET_VALUE_STALE,
    NL_SOCKET_VALUE_TYPE, NL_SOCKET_VALUE_BORROWED, NL_SOCKET_VALUE_LIMIT,
    NL_SOCKET_VALUE_MEMORY, NL_SOCKET_VALUE_DISPOSED, NL_SOCKET_VALUE_STATE,
    NL_SOCKET_VALUE_STATUS_COUNT
} NlSocketValueStatus;
typedef struct { uint64_t invocation, generation; uint32_t slot; } NlSocketValue;
typedef struct { NlSocketValue value; uint64_t epoch; } NlSocketValueBorrow;
typedef struct { 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
                _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
                     ok, pending; NlSocketResult error; } NlSocketConnectView;
typedef enum {
    NL_SOCKET_VALUE_CONNECT, NL_SOCKET_VALUE_SEND, NL_SOCKET_VALUE_RECEIVE,
    NL_SOCKET_VALUE_CLOSE
} NlSocketScalarKind;
typedef struct {
    NlSocketScalarKind kind;
    
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
   _Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
        ok;
    NlSocketResult detail;
    int64_t value;
    
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
        eof;
} NlSocketScalarResult;
typedef struct {
    NlSocketValueStatus execution;
    uint64_t cleanup_failures;
    NlSocketResult first_cleanup, next_cleanup;
} NlSocketValuesFinish;




# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
    nl_socket_values_storage_bound(size_t *out);
NlSocketValueStatus nl_socket_values_create(NlSocketValues **out);


NlSocketValueStatus nl_socket_values_connect(NlSocketValues *, const NlSocketAddress *, NlSocketValue *out);



# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
    nl_socket_endpoint_decode(const NlSocketEndpoint *, NlSocketAddress *out);
NlSocketValueStatus nl_socket_values_begin_connect(NlSocketValues *, const NlSocketEndpoint *, NlSocketValue *out);
NlSocketValueStatus nl_socket_connect_view(NlSocketValues *, const NlSocketValue *, NlSocketConnectView *out);


NlSocketValueStatus nl_socket_value_move(NlSocketValues *, NlSocketValue *, NlSocketValue *out);
NlSocketValueStatus nl_socket_connect_take_ok(NlSocketValues *, NlSocketValue *, NlSocketValue *out);
NlSocketValueStatus nl_socket_connect_take_error(NlSocketValues *, NlSocketValue *, NlSocketResult *out);
NlSocketValueStatus nl_socket_value_borrow(NlSocketValues *, const NlSocketValue *, NlSocketValueBorrow *out);
NlSocketValueStatus nl_socket_value_end_borrow(NlSocketValues *, NlSocketValueBorrow *);

NlSocketValueStatus nl_socket_value_finish_connect(NlSocketValues *, const NlSocketValueBorrow *, NlSocketScalarResult *out);
NlSocketValueStatus nl_socket_value_send_byte(NlSocketValues *, const NlSocketValueBorrow *, int64_t, NlSocketScalarResult *out);
NlSocketValueStatus nl_socket_value_receive_byte(NlSocketValues *, const NlSocketValueBorrow *, NlSocketScalarResult *out);
NlSocketValueStatus nl_socket_value_close(NlSocketValues *, NlSocketValue *, NlSocketScalarResult *out);

NlSocketValueStatus nl_socket_value_drop(NlSocketValues *, NlSocketValue *);

NlSocketValueStatus nl_socket_value_validate(NlSocketValues *, const NlSocketValue *, 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
                                                                                     _Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
                                                                                          connect_result);
NlSocketValueStatus nl_socket_value_borrow_validate(NlSocketValues *, const NlSocketValueBorrow *);
NlSocketValueStatus nl_socket_values_live_slots(NlSocketValues *, uint64_t *owners, uint64_t *borrowed);

# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_values.h"
    nl_socket_values_report(const NlSocketValues *, NlSocketValuesFinish *out);



NlSocketValuesFinish nl_socket_values_finish(NlSocketValues *, NlSocketValueStatus);
NlSocketValuesFinish nl_socket_values_destroy(NlSocketValues *, NlSocketValueStatus);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 2


typedef struct NlWsTransport NlWsTransport;
typedef enum {
    NL_WS_TRANSPORT_OK, NL_WS_TRANSPORT_ARGUMENT, NL_WS_TRANSPORT_RIGHTS,
    NL_WS_TRANSPORT_MEMORY, NL_WS_TRANSPORT_LIMIT, NL_WS_TRANSPORT_TIMEOUT,
    NL_WS_TRANSPORT_IO, NL_WS_TRANSPORT_PROTOCOL, NL_WS_TRANSPORT_CRYPTO,
    NL_WS_TRANSPORT_CLOSED
} NlWsTransportStatus;
typedef struct {
    NlWsTransportStatus status;
    int host_errno,resolver_error,supervisor_status,close_code,cleanup_errno;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
        cleanup_failed,closure_unknown,terminal;
    size_t bytes;
} NlWsTransportResult;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
        allow_network,allow_lookup;
    const char *resolver_helper;
    unsigned max_timeout_ms;
} NlWsTransportPolicy;
typedef struct { 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
                _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
                     binary; unsigned char *bytes; size_t length; } NlWsMessage;
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_storage_bound(size_t *out);
NlWsTransportResult nl_ws_transport_connect(const void *url,size_t length,
    const NlWsTransportPolicy *,unsigned timeout_ms,NlWsTransport **out);
NlWsTransportResult nl_ws_transport_send(NlWsTransport *,
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
                                                        _Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
                                                             binary,
    const void *bytes,size_t length,unsigned timeout_ms);


NlWsTransportResult nl_ws_transport_receive(NlWsTransport *,unsigned timeout_ms,NlWsMessage *out);
void nl_ws_message_free(NlWsMessage *);


NlWsTransportResult nl_ws_transport_close(NlWsTransport *,unsigned timeout_ms);

NlWsTransportResult nl_ws_transport_abort(NlWsTransport *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_connected(const NlWsTransport *);
const char *nl_ws_transport_error(const NlWsTransport *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 2





typedef struct NlWsValues NlWsValues;
typedef enum {
    NL_WS_VALUE_OK, NL_WS_VALUE_ARGUMENT, NL_WS_VALUE_STALE, NL_WS_VALUE_TYPE,
    NL_WS_VALUE_BORROWED, NL_WS_VALUE_LIMIT, NL_WS_VALUE_MEMORY,
    NL_WS_VALUE_DISPOSED, NL_WS_VALUE_STATE, NL_WS_VALUE_STATUS_COUNT
} NlWsValueStatus;
typedef struct { uint64_t invocation,generation; uint32_t slot; } NlWsValue;
typedef struct { NlWsValue value; uint64_t epoch; } NlWsValueBorrow;
typedef struct { 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                     ok; NlWsTransportResult error; } NlWsConnectView;
typedef struct {
    NlWsValueStatus execution;
    uint64_t cleanup_failures;
    NlWsTransportResult first_cleanup,next_cleanup;
} NlWsValuesFinish;
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
NlWsValueStatus nl_ws_values_create_bounded(const NlWsTransportPolicy *,size_t,NlWsValues **out);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
    nl_ws_values_minimum_storage(size_t *out);
NlWsValueStatus nl_ws_values_create(const NlWsTransportPolicy *,NlWsValues **out);
NlWsValueStatus nl_ws_values_connect(NlWsValues *,const void *,size_t,int64_t,NlWsValue *out);
NlWsValueStatus nl_ws_connect_view(NlWsValues *,const NlWsValue *,NlWsConnectView *out);
NlWsValueStatus nl_ws_connect_take_ok(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_connect_take_error(NlWsValues *,NlWsValue *,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_move(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_value_borrow(NlWsValues *,const NlWsValue *,NlWsValueBorrow *out);
NlWsValueStatus nl_ws_value_end_borrow(NlWsValues *,NlWsValueBorrow *);
NlWsValueStatus nl_ws_value_send(NlWsValues *,const NlWsValueBorrow *,
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                                                                     _Bool
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                                                                         ,
    const void *,size_t,int64_t,NlWsTransportResult *out);


NlWsValueStatus nl_ws_value_receive(NlWsValues *,const NlWsValueBorrow *,int64_t,
    NlWsMessage *message,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_close(NlWsValues *,NlWsValue *,int64_t,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_drop(NlWsValues *,NlWsValue *);
NlWsValueStatus nl_ws_value_validate(NlWsValues *,const NlWsValue *,
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                                                                   _Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                                                                        connect_result);
NlWsValueStatus nl_ws_value_borrow_validate(NlWsValues *,const NlWsValueBorrow *);
NlWsValueStatus nl_ws_values_live_slots(NlWsValues *,uint64_t *owners,uint64_t *borrowed);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
    nl_ws_values_report(const NlWsValues *,NlWsValuesFinish *out);



NlWsValuesFinish nl_ws_values_finish(NlWsValues *,NlWsValueStatus);
NlWsValuesFinish nl_ws_values_destroy(NlWsValues *,NlWsValueStatus);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 2







typedef enum { NL_SERVICES_FILE=1, NL_SERVICES_TCP=2, NL_SERVICES_WEBSOCKET=3 } NlServicesCatalog;
typedef enum {
    NL_SERVICES_VALUE_OK, NL_SERVICES_VALUE_ARGUMENT, NL_SERVICES_VALUE_STALE,
    NL_SERVICES_VALUE_TYPE, NL_SERVICES_VALUE_BORROWED, NL_SERVICES_VALUE_LIMIT,
    NL_SERVICES_VALUE_MEMORY, NL_SERVICES_VALUE_DISPOSED, NL_SERVICES_VALUE_STATE
} NlServicesValueStatus;
typedef struct NlServicesValues NlServicesValues;
typedef struct {
    uint32_t instance;
    NlServicesCatalog catalog;
    union { NlFileValue file; NlSocketValue tcp; NlWsValue websocket; } value;
} NlServicesValue;
typedef struct {
    uint32_t instance;
    NlServicesCatalog catalog;
    union { NlFileValueBorrow file; NlSocketValueBorrow tcp; NlWsValueBorrow websocket; } borrow;
} NlServicesBorrow;
typedef struct {
    NlServicesCatalog catalog;
    
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
        ok, pending;
    union { NlFileResult file; NlSocketResult tcp; NlWsTransportResult websocket; } error;
} NlServicesOpenView;
typedef struct {
    NlServicesCatalog catalog;
    union { NlFileScalarResult file; NlSocketScalarResult tcp; } result;
} NlServicesScalarResult;
typedef struct {
    NlServicesValueStatus execution;
    uint32_t count;
    uint64_t cleanup_failures;
    struct {
        NlServicesCatalog catalog;
        union { NlFileValuesFinish file; NlSocketValuesFinish tcp; NlWsValuesFinish websocket; } finish;
    } instances[64u];
} NlServicesFinish;




typedef struct {
    NlServicesCatalog catalog;
    NlWsTransportPolicy websocket;
    size_t websocket_storage_limit;
} NlServicesValueConfig;

# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
    nl_services_values_config_storage_bound(const NlServicesValueConfig *,uint32_t,size_t *);
NlServicesValueStatus nl_services_values_create_config(const NlServicesValueConfig *,uint32_t,NlServicesValues **);




NlServicesValueStatus nl_services_values_websocket_connect(NlServicesValues *,uint32_t,const void *,size_t,int64_t,NlServicesValue *);
NlServicesValueStatus nl_services_value_websocket_send(NlServicesValues *,uint32_t,const NlServicesBorrow *,
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
                                                                                                           _Bool
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
                                                                                                               ,const void *,size_t,int64_t,NlWsTransportResult *);
NlServicesValueStatus nl_services_value_websocket_receive(NlServicesValues *,uint32_t,const NlServicesBorrow *,int64_t,NlWsMessage *,NlWsTransportResult *);
NlServicesValueStatus nl_services_value_websocket_close(NlServicesValues *,uint32_t,NlServicesValue *,int64_t,NlWsTransportResult *);




# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
    nl_services_values_storage_bound(const NlServicesCatalog *,uint32_t,size_t *);
NlServicesValueStatus nl_services_values_create(const NlServicesCatalog *,uint32_t,NlServicesValues **);


NlServicesValueStatus nl_services_values_acquire(NlServicesValues *,uint32_t,const NlSocketEndpoint *,NlServicesValue *);
NlServicesValueStatus nl_services_value_move(NlServicesValues *,NlServicesValue *,NlServicesValue *);
NlServicesValueStatus nl_services_value_view(NlServicesValues *,const NlServicesValue *,NlServicesOpenView *);
NlServicesValueStatus nl_services_value_take_ok(NlServicesValues *,NlServicesValue *,NlServicesValue *);
NlServicesValueStatus nl_services_value_take_error(NlServicesValues *,NlServicesValue *,NlServicesOpenView *);
NlServicesValueStatus nl_services_value_borrow(NlServicesValues *,const NlServicesValue *,NlServicesBorrow *);
NlServicesValueStatus nl_services_value_end_borrow(NlServicesValues *,NlServicesBorrow *);



NlServicesValueStatus nl_services_value_call(NlServicesValues *,uint32_t,uint32_t,const NlServicesBorrow *,int64_t,NlServicesScalarResult *);
NlServicesValueStatus nl_services_value_close(NlServicesValues *,uint32_t,NlServicesValue *,NlServicesScalarResult *);


NlServicesValueStatus nl_services_value_validate(NlServicesValues *,const NlServicesValue *,
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
                                                                                           _Bool
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
                                                                                               );
NlServicesValueStatus nl_services_borrow_validate(NlServicesValues *,const NlServicesBorrow *);
NlServicesValueStatus nl_services_values_live_slots(NlServicesValues *,uint32_t,uint64_t *,uint64_t *);
NlServicesValueStatus nl_services_value_drop(NlServicesValues *,NlServicesValue *);




# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h" 3 4
_Bool 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_services_values.h"
    nl_services_values_report(const NlServicesValues *,NlServicesFinish *);
NlServicesValueStatus nl_services_values_finish(NlServicesValues *,NlServicesValueStatus,NlServicesFinish *);
NlServicesValueStatus nl_services_values_destroy(NlServicesValues **,NlServicesValueStatus,NlServicesFinish *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
typedef enum { NVM_SERVICES_RUNTIME_VM, NVM_SERVICES_RUNTIME_NATIVE } NvmServicesRuntimeMode;
typedef enum {
    NVM_SERVICES_RUNTIME_OK, NVM_SERVICES_RUNTIME_INVALID, NVM_SERVICES_RUNTIME_UNRESOLVED,
    NVM_SERVICES_RUNTIME_LIMIT, NVM_SERVICES_RUNTIME_MEMORY, NVM_SERVICES_RUNTIME_STATE,
    NVM_SERVICES_RUNTIME_TYPE, NVM_SERVICES_RUNTIME_STALE, NVM_SERVICES_RUNTIME_BORROWED,
    NVM_SERVICES_RUNTIME_ASSERT, NVM_SERVICES_RUNTIME_CLEANUP, NVM_SERVICES_RUNTIME_BUSY
} NvmServicesRuntimeStatus;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
        initialized, owning, formal;
    NvmServicesFlowDeclaration type;
    NvmServicesFlowArm arm;
    uint8_t fields;
    int64_t values[11u];
} NvmServicesRuntimeView;
typedef struct {
    NvmServicesRuntimeStatus status;
    
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
   _Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
        acquired;
    NlServicesValueStatus core_status;
    uint32_t function, instruction;
    NlServicesFinish cleanup;
} NvmServicesRuntimeReport;
typedef struct {
    size_t allocation_bound;
    uint32_t values, references, regions;
    uint16_t frames;
} NvmServicesRuntimeStorage;
typedef struct NvmServicesRuntime NvmServicesRuntime;


NvmServicesRuntimeStatus nvm_services_runtime_create(const uint8_t *,size_t,NvmServicesRuntimeMode,NvmServicesRuntime **out);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
    nvm_services_runtime_storage(const NvmServicesRuntime *,NvmServicesRuntimeStorage *);
const NvmServicesHostedPlan *nvm_services_runtime_plan(const NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_begin(NvmServicesRuntime *);



NvmServicesRuntimeStatus nvm_services_runtime_websocket_policy(NvmServicesRuntime *,uint32_t,const NlWsTransportPolicy *);


NvmServicesRuntimeStatus nvm_services_runtime_site(NvmServicesRuntime *,uint32_t function,uint16_t instruction);
NvmServicesRuntimeStatus nvm_services_runtime_fail(NvmServicesRuntime *,NvmServicesRuntimeStatus);

# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
_Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
    nvm_services_runtime_current_root(const NvmServicesRuntime *,uint32_t *);

# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
_Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
    nvm_services_runtime_view(const NvmServicesRuntime *,uint32_t,NvmServicesRuntimeView *);

NvmServicesRuntimeStatus nvm_services_runtime_scalar(NvmServicesRuntime *,uint32_t,uint8_t,int64_t);




NvmServicesRuntimeStatus nvm_services_runtime_string(NvmServicesRuntime *,uint32_t,const void *,size_t);
NvmServicesRuntimeStatus nvm_services_runtime_string_literal(NvmServicesRuntime *,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_string_operation(NvmServicesRuntime *,uint8_t,uint32_t,uint32_t,uint32_t);

# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime.h"
    nvm_services_runtime_string_read(const NvmServicesRuntime *,uint32_t,void *,size_t,size_t *);
NvmServicesRuntimeStatus nvm_services_runtime_copy(NvmServicesRuntime *,uint32_t,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_move(NvmServicesRuntime *,uint32_t,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_drop(NvmServicesRuntime *,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_construct(NvmServicesRuntime *,uint32_t ordinal,uint16_t variant,const uint32_t *,size_t,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_project(NvmServicesRuntime *,uint32_t,uint16_t,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_result_arm(NvmServicesRuntime *,uint32_t,NvmServicesFlowArm *);
NvmServicesRuntimeStatus nvm_services_runtime_take(NvmServicesRuntime *,uint32_t,NvmServicesFlowArm,uint32_t);
NvmServicesRuntimeStatus nvm_services_runtime_region_begin(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_region_end(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_borrow(NvmServicesRuntime *,uint32_t owner,uint32_t reference);
NvmServicesRuntimeStatus nvm_services_runtime_borrow_shared(NvmServicesRuntime *,uint32_t owner,uint32_t reference);
NvmServicesRuntimeStatus nvm_services_runtime_bind_formal(NvmServicesRuntime *,uint32_t source_reference,uint32_t formal_root,uint32_t formal_reference);
NvmServicesRuntimeStatus nvm_services_runtime_end_reference(NvmServicesRuntime *,uint32_t);




NvmServicesRuntimeStatus nvm_services_runtime_service(NvmServicesRuntime *,uint32_t import,uint32_t reference,uint32_t input,uint32_t output);



NvmServicesRuntimeStatus nvm_services_runtime_service_args(NvmServicesRuntime *,uint32_t,uint32_t,const uint32_t *,size_t,uint32_t);


NvmServicesRuntimeStatus nvm_services_runtime_complete_root(NvmServicesRuntime *,uint32_t result);



NvmServicesRuntimeReport nvm_services_runtime_finish(NvmServicesRuntime *,NvmServicesRuntimeView *);
NvmServicesRuntimeReport nvm_services_runtime_destroy(NvmServicesRuntime **,NvmServicesRuntimeView *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 2






typedef struct {
    NvmServicesRuntimeMode mode;
    uint32_t function, instruction, byte_offset;
    uint16_t depth, locals, staging_slots, operand_peak;
    uint32_t locals_base, staging_base, stack_base, stack_count;
    uint32_t reference_base, region_floor;
} NvmServicesRuntimeFrameView;

NvmServicesRuntimeStatus nvm_services_runtime_frame_start(NvmServicesRuntime *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_view(const NvmServicesRuntime *,NvmServicesRuntimeFrameView *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_local(const NvmServicesRuntime *,uint16_t,uint32_t *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_operand(const NvmServicesRuntime *,uint16_t,uint32_t *);


# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_reserve(const NvmServicesRuntime *,uint16_t,uint32_t *);


# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_scratch(const NvmServicesRuntime *,uint32_t *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_runtime_frames.h"
    nvm_services_runtime_frame_reference(const NvmServicesRuntime *,uint16_t,uint32_t *);


NvmServicesRuntimeStatus nvm_services_runtime_frame_store(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_frame_next(NvmServicesRuntime *,uint8_t successor);
NvmServicesRuntimeStatus nvm_services_runtime_frame_call(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_frame_return(NvmServicesRuntime *);


NvmServicesRuntimeStatus nvm_services_runtime_frame_region_begin(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_frame_region_end(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_frame_borrow(NvmServicesRuntime *);
NvmServicesRuntimeStatus nvm_services_runtime_frame_end_reference(NvmServicesRuntime *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_report.h" 1






typedef struct { uint32_t revision; uint64_t instruction_limit; } NvmServicesIndirectOptions;
typedef struct {
    uint32_t revision;
    NvmServicesRuntimeReport runtime;
    uint64_t instruction_limit, instructions_started;
    
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_report.h" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_report.h"
        fuel_exhausted;
} NvmServicesIndirectExecutionReport;
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 2
typedef struct {
    uint32_t revision;
    NvmServicesRuntimeFrameView frame;
    uint8_t variant;
    
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h"
        instruction_open;
} NvmServicesIndirectFrameView;
NvmServicesRuntimeStatus nvm_services_runtime_indirect_create(const uint8_t *,size_t,
    NvmServicesRuntimeMode,const NvmServicesIndirectOptions *,NvmServicesRuntime **);
const NvmServicesIndirectHostedPlan *nvm_services_runtime_indirect_plan(const NvmServicesRuntime *);

# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h"
    nvm_services_runtime_indirect_frame_view(const NvmServicesRuntime *,NvmServicesIndirectFrameView *);
NvmServicesRuntimeStatus nvm_services_runtime_indirect_enter(NvmServicesRuntime *);


NvmServicesRuntimeStatus nvm_services_runtime_indirect_funcref(NvmServicesRuntime *,uint32_t dst);
NvmServicesIndirectExecutionReport nvm_services_runtime_indirect_finish(NvmServicesRuntime *,NvmServicesRuntimeView *);
NvmServicesIndirectExecutionReport nvm_services_runtime_indirect_destroy(NvmServicesRuntime **,NvmServicesRuntimeView *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_runtime.h"
    nvm_services_runtime_indirect_native_abi(uint32_t,size_t,size_t,size_t,size_t,size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_abi.h" 2
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_public.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_public.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h" 1
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h" 2


typedef enum { NVM_SERVICES_HOST_FILE=1, NVM_SERVICES_HOST_TCP=2, NVM_SERVICES_HOST_WEBSOCKET=3 } NvmServicesHostCatalog;
typedef struct { NvmServicesHostCatalog catalog; 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h" 3 4
                                                _Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h"
                                                     allowed; } NvmServicesHostPolicy;

typedef struct {
    uint32_t revision;
    NvmServicesHostCatalog catalog;
    
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h" 3 4
   _Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h"
        allowed, allow_lookup;
    uint32_t max_timeout_ms;
    const char *resolver_helper;
} NvmServicesHostConfig;

typedef struct NvmServicesHostGrant NvmServicesHostGrant;
typedef enum {
    NVM_SERVICES_HOST_OK = 0,
    NVM_SERVICES_HOST_INVALID = 1,
    NVM_SERVICES_HOST_MEMORY = 2,
    NVM_SERVICES_HOST_STATE = 3,
    NVM_SERVICES_HOST_UNRESOLVED = 4,
    NVM_SERVICES_HOST_BUSY = 5
} NvmServicesHostStatus;
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant.h"
NvmServicesHostStatus nvm_services_host_grant_create(const NvmServicesHostPolicy *,size_t,NvmServicesHostGrant **out);






NvmServicesHostStatus nvm_services_host_grant_create_config(const NvmServicesHostConfig *,size_t,NvmServicesHostGrant **out);
NvmServicesHostStatus nvm_services_host_grant_revoke_instance(NvmServicesHostGrant *,size_t);



NvmServicesHostStatus nvm_services_host_grant_revoke(NvmServicesHostGrant *grant);


NvmServicesHostStatus nvm_services_host_grant_destroy(NvmServicesHostGrant **inout);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_public.h" 2



typedef struct { uint8_t tag; int64_t value; } NvmServicesScalar;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public.h" 2







NvmServicesIndirectExecutionReport nvm_services_execute_indirect_bytes(NvmServicesHostGrant *,
    const uint8_t *, size_t, const NvmServicesIndirectOptions *, NvmServicesScalar *);



NvmServicesRuntimeStatus nvm2c_emit_services_indirect_bytes(const uint8_t *, size_t,
    const char *entry_identifier, char **out, char *diagnostic, size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_internal.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_public_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant_internal.h" 1




# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 1
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant_internal.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_host_grant_internal.h"
NvmServicesHostStatus nvm_services_host_enter_query(void);
NvmServicesHostStatus nvm_services_host_enter(const NvmServicesHostGrant *grant,
                                    unsigned abi, unsigned catalog);


NvmServicesHostStatus nvm_services_host_authorize(const NvmServicesHostGrant *,const NvmServicesIndirectHostedPlan *);



NvmServicesHostStatus nvm_services_host_websocket_policy(const NvmServicesHostGrant *,size_t,NlWsTransportPolicy *out);
void nvm_services_host_leave(void);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_public_internal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_public_internal.h" 2


static inline NvmServicesRuntimeStatus nvm_services_public_grant_status(NvmServicesHostStatus s) {
    switch (s) {
    case NVM_SERVICES_HOST_OK: return NVM_SERVICES_RUNTIME_OK;
    case NVM_SERVICES_HOST_INVALID: return NVM_SERVICES_RUNTIME_INVALID;
    case NVM_SERVICES_HOST_MEMORY: return NVM_SERVICES_RUNTIME_MEMORY;
    case NVM_SERVICES_HOST_STATE: return NVM_SERVICES_RUNTIME_STATE;
    case NVM_SERVICES_HOST_BUSY: return NVM_SERVICES_RUNTIME_BUSY;
    default: return NVM_SERVICES_RUNTIME_UNRESOLVED;
    }
}
static inline NvmServicesRuntimeReport nvm_services_public_refused(NvmServicesRuntimeStatus s) {
    NvmServicesRuntimeReport r = {0};
    r.status = s;
    r.function = r.instruction = 0xFFFFFFFFu;
    return r;
}


static inline NvmServicesRuntimeReport nvm_services_public_publish(NvmServicesRuntimeReport r,
    const NvmServicesRuntimeView *view, NvmServicesScalar *out) {
    if (r.status != NVM_SERVICES_RUNTIME_OK) return r;
    if (!r.acquired) { r.status = NVM_SERVICES_RUNTIME_STATE; return r; }
    if (r.core_status != NL_SERVICES_VALUE_OK || r.cleanup.execution != NL_SERVICES_VALUE_OK ||
        r.cleanup.cleanup_failures) { r.status = NVM_SERVICES_RUNTIME_CLEANUP; return r; }
    if (!out || !view->initialized || view->owning || view->formal ||
        view->type.mode || view->type.category != NVM_SERVICES_CATEGORY_UNKNOWN ||
        view->type.global_index != 0xFFFFFFFFu ||
        view->type.catalog_ordinal != 0xFFFFFFFFu || view->fields != 1 ||
        (view->type.tag != TAG_INT && view->type.tag != TAG_BOOL) ||
        (view->type.tag == TAG_BOOL && view->values[0] != 0 && view->values[0] != 1)) {
        r.status = NVM_SERVICES_RUNTIME_TYPE;
        return r;
    }
    NvmServicesScalar scalar = {view->type.tag, view->values[0]};
    *out = scalar;
    return r;
}
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_internal.h" 2


static inline NvmServicesRuntimeStatus nvm_services_public_configure(NvmServicesRuntime *c,const NvmServicesHostGrant *grant) {
    const NvmServicesIndirectHostedPlan *plan=nvm_services_runtime_indirect_plan(c);
    NvmServicesRuntimeStatus status=nvm_services_public_grant_status(nvm_services_host_authorize(grant,plan));
    if(status!=NVM_SERVICES_RUNTIME_OK)return status;
    for(uint32_t i=0;i<64u;i++) {
        NvmServicesNominalLayout type;
        if(!nvm_services_indirect_hosted_type(plan,i*9,&type))break;
        if(nvm_services_indirect_hosted_type(plan,i*9+7,&type))continue;
        NlWsTransportPolicy policy;
        status=nvm_services_public_grant_status(nvm_services_host_websocket_policy(grant,i,&policy));
        if(status==NVM_SERVICES_RUNTIME_OK)status=nvm_services_runtime_websocket_policy(c,i,&policy);
        if(status!=NVM_SERVICES_RUNTIME_OK)return status;
    }
    return NVM_SERVICES_RUNTIME_OK;
}

static inline NvmServicesIndirectExecutionReport nvm_services_indirect_public_refused(
    NvmServicesRuntimeStatus status, const NvmServicesIndirectOptions *options) {
    NvmServicesIndirectExecutionReport report = {0};
    report.revision = 1u;
    report.instruction_limit = options ? options->instruction_limit : 0;
    report.runtime = nvm_services_public_refused(status);
    return report;
}
static inline 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_internal.h" 3 4
             _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_internal.h"
                  nvm_services_indirect_public_options(const NvmServicesIndirectOptions *options) {
    return options && options->revision == 1u &&
        options->instruction_limit <= 1000000UL;
}
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_public.h" 2





# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_public.h" 3 4
_Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_native_public.h"
    nvm_services_runtime_indirect_public_abi(uint32_t, size_t, size_t, size_t);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_abi.c" 2

# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_abi.c" 3 4
_Bool 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/services_indirect_public_abi.c"
    nvm_services_runtime_indirect_public_abi(uint32_t revision, size_t options,
    size_t report, size_t scalar) {
    return revision == 1u &&
        options == sizeof(NvmServicesIndirectOptions) &&
        report == sizeof(NvmServicesIndirectExecutionReport) && scalar == sizeof(NvmServicesScalar);
}
