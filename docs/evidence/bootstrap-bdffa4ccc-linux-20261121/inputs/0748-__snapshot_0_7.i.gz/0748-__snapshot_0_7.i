# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 1
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h" 2



# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h"
    nvm_layouts_have_facts(const NvmV2Layouts *layouts);



# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h" 3 4
_Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/retained_layouts.h"
    nvm_retained_layouts_valid(const NvmModule *module);


NvmV2Result nvm_retain_layouts(NvmModule *module, const NvmV2Layouts *layouts);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
typedef enum {
    NVM_REFERENCE_SHARED = 1,
    NVM_REFERENCE_EXCLUSIVE = 2
} NvmReferenceMode;

typedef struct {
    uint64_t invocation;
    uint16_t local;
    uint32_t root_layout;
    const uint16_t *fields;
    uint16_t field_count;
    uint32_t referent_layout;
    NvmReferenceMode mode;
} NvmReferencePlace;






# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
    nvm_reference_place_valid(const NvmV2Layouts *layouts,
                               uint32_t authoritative_root_layout,
                               const NvmReferencePlace *place);





# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
    nvm_reference_places_overlap(const NvmReferencePlace *a,
                                  const NvmReferencePlace *b);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
    nvm_reference_holds_conflict(const NvmReferencePlace *a,
                                 const NvmReferencePlace *b);



# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
    nvm_reference_owner_access_conflicts(const NvmReferencePlace *hold,
                                          const NvmReferencePlace *access,
                                          
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h" 3 4
                                         _Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/reference_places.h"
                                              write_or_move);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
typedef struct NvmMapDeclarationPlan NvmMapDeclarationPlan;
typedef enum { NVM_MAP_ABSENT, NVM_MAP_DESCRIBED, NVM_MAP_INVALID,
               NVM_MAP_LIMIT, NVM_MAP_MEMORY } NvmMapDeclarationStatus;
typedef struct { NvmMapDeclarationStatus status; const char *message; } NvmMapDeclarationResult;
typedef struct { uint32_t scalars,pairs,bindings; } NvmMapDeclarationCounts;
typedef struct { uint32_t key_type,value_type; } NvmMapDeclarationPair;
typedef struct { uint32_t layout; uint16_t field; uint32_t pair; } NvmMapDeclarationBinding;
NvmMapDeclarationResult nvm_prepare_map_declarations(const NvmModule *,NvmMapDeclarationPlan **);
void nvm_map_declarations_free(NvmMapDeclarationPlan *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_counts(const NvmMapDeclarationPlan *,NvmMapDeclarationCounts *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_scalar(const NvmMapDeclarationPlan *,uint32_t,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_pair(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationPair *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_binding(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationBinding *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_field(const NvmMapDeclarationPlan *,uint32_t,uint16_t,NvmMapDeclarationPair *);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_structure_private.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_array_shapes.h" 1






typedef enum {
    NVM_ARRAY_ELIGIBLE, NVM_ARRAY_UNRESOLVED, NVM_ARRAY_INVALID,
    NVM_ARRAY_LIMIT, NVM_ARRAY_MEMORY
} NvmArrayEligibilityStatus;
typedef struct {
    uint32_t function, pc;
    uint16_t child_tags;
    uint8_t declared_tag, packed;
} NvmArrayOrigin;
typedef struct {
    uint32_t origin_count, checked_writes;

    uint32_t runtime_tag_checks;
    NvmArrayOrigin origins[64];
} NvmArrayEligibilityReport;

typedef struct {
    NvmArrayEligibilityReport arrays;
    uint64_t child_origins[64];
    uint8_t child_unknown[64];
} NvmArrayGraphEligibilityReport;
typedef struct {
    NvmArrayEligibilityStatus status;
    uint32_t function, pc;
    char message[192];
} NvmArrayEligibilityResult;

NvmArrayEligibilityResult nvm_analyze_managed_arrays(
    const NvmModule *module, NvmArrayEligibilityReport **out);
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report);

NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(
    const NvmModule *module, NvmArrayGraphEligibilityReport **out);
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report);



NvmArrayEligibilityResult nvm_select_managed_array_mode(
    const NvmModule *module, int *graph_required);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h" 1






typedef struct NvmOrdinaryArrayAuthority NvmOrdinaryArrayAuthority;
typedef enum { NVM_OAA_DESCRIBED, NVM_OAA_UNKNOWN, NVM_OAA_INVALID,
               NVM_OAA_LIMIT, NVM_OAA_MEMORY } NvmOrdinaryArrayStatus;
typedef struct { NvmOrdinaryArrayStatus status; uint32_t layout, field;
                 const char *message; } NvmOrdinaryArrayResult;
typedef struct { uint32_t layouts, types, bindings; } NvmOrdinaryArrayCounts;
typedef struct { uint8_t tag; uint32_t referent; } NvmOrdinaryArrayType;
typedef struct { uint32_t layout; uint16_t field; uint32_t element_type; } NvmOrdinaryArrayBinding;
NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(const NvmModule *, NvmOrdinaryArrayAuthority **);
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *, NvmOrdinaryArrayCounts *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayType *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayBinding *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 2





typedef struct NvmOwnershipDeclarationPlan NvmOwnershipDeclarationPlan;
typedef enum {
    NVM_DECL_PREPARED, NVM_DECL_UNKNOWN, NVM_DECL_INVALID,
    NVM_DECL_LIMIT, NVM_DECL_MEMORY
} NvmDeclarationStatus;
typedef struct { NvmDeclarationStatus status; const char *message; } NvmDeclarationResult;
typedef struct { uint32_t layouts, types, bindings, unions, variants; } NvmDeclarationCounts;
typedef struct { uint8_t kind, flags; uint16_t fields; uint32_t name; } NvmDeclarationLayout;
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *,NvmOwnershipDeclarationPlan **);
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *,NvmDeclarationCounts *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *,uint32_t,NvmDeclarationLayout *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayType *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h" 1
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h" 2




typedef struct {
    
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
        ok;
    char error_msg[256];
} NvmVerifyResult;
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify(const NvmModule *mod);







typedef enum {
    NVM_PROFILE_GENERAL = 0,
    NVM_PROFILE_CLOSED_SCALAR = 1,
    NVM_PROFILE_CLOSED_LITERAL_STRINGS = 2,
    NVM_PROFILE_CLOSED_MANAGED_STRINGS = 3,


    NVM_PROFILE_PORTABLE_FILE_READ = 5,
    NVM_PROFILE_PORTABLE_READ_TEXT = 4
} NvmVerifyProfile;
NvmVerifyResult nvm_verify_profile(const NvmModule *mod, NvmVerifyProfile profile);



NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod);



# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
    nvm_uses_owned_transfers(const NvmModule *mod);



NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx);


NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx);
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_function_types(const NvmModule *mod, uint32_t fn_idx,
                                          const VmDecodedFunction *decoded,
                                          uint16_t max_depth,
                                          char *error, size_t error_size);

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack);





NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count);
# 131 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 2

# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 2





# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
typedef struct {
    uint64_t bytes, peak, work;
    
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
        limited, memory;
} NvmRecordArrayBudget;
static inline 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_bytes(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->bytes>(64UL*1024*1024) || n>(64UL*1024*1024)-b->bytes){b->limited=
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                   1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                       ;return 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                               0
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                                    ;}
    b->bytes+=n;if(b->peak<b->bytes)b->peak=b->bytes;return 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                           1
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                               ;
}
static inline 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_steps(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->work>16777216UL || n>16777216UL -b->work){b->limited=
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                 1
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                     ;return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                             0
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                                  ;}
    b->work+=n;return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                     1
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                         ;
}
static inline void *nvm_ra_alloc(NvmRecordArrayBudget *b,size_t n,size_t width) {
    if(width && n>
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                 (18446744073709551615UL)
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                         /width){if(b)b->limited=
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                 1
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                     ;return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                             ((void *)0)
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                 ;}
    if(!nvm_ra_bytes(b,(uint64_t)n*width))return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                ((void *)0)
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                    ;
    void *p=calloc(n,width);if(!p && n && width && b)b->memory=
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                              1
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
                                                                  ;return p;
}


typedef struct {
    NvmOwnershipDeclarationPlan *declarations;
    uint32_t functions;
    VmDecodedFunction decoded[256];
    uint16_t stacks[256];
} NvmRecordArrayStructure;

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_array_structure_private.h"
    nvm_record_array_opcode_supported(uint8_t);
NvmArrayEligibilityResult nvm_record_array_structure_prepare(
    const NvmModule *,NvmRecordArrayBudget *,NvmRecordArrayStructure **);
void nvm_record_array_structure_free(NvmRecordArrayStructure *);
NvmVerifyResult nvm_verify_function_types_record_array(
    const NvmModule *,uint32_t,const VmDecodedFunction *,uint16_t,NvmRecordArrayBudget *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_structure_private.h" 2


NvmMapDeclarationResult nvm_prepare_map_declarations_split(const NvmModule *,
    NvmMapDeclarationPlan **,NvmOwnershipDeclarationPlan **);
NvmArrayEligibilityResult nvm_record_map_structure_prepare(const NvmModule *,
    NvmRecordArrayBudget *,NvmRecordArrayStructure **,NvmMapDeclarationPlan **);
static inline 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_structure_private.h" 3 4
             _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_structure_private.h"
                  nvm_record_map_opcode(uint8_t op) {
    return op==OP_HM_NEW || op==OP_HM_SET || op==OP_HM_GET ||
           op==OP_HM_HAS || op==OP_HM_LEN || op==OP_HM_DELETE;
}
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
typedef struct { uint64_t used,limit; 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                                     _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                                          limited; } NvmMapCopyWork;
typedef enum { NVM_MAP_COST_OK, NVM_MAP_COST_INVALID, NVM_MAP_COST_LIMIT } NvmMapCostStatus;
static inline 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
             _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                  nvm_map_copy_charge(NvmMapCopyWork *w,uint64_t amount) {
    if(!w)return 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                0
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                     ;
    if(w->limited || w->used>w->limit || amount>w->limit-w->used){w->limited=
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                                                                            1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                                                                                ;return 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                                                                                        0
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                                                                                             ;}
    w->used+=amount;return 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                          1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                              ;
}
static inline NvmMapCostStatus nvm_map_copy_term(NvmMapCopyWork *w,const void *ptr,
                                                uint64_t count,uint64_t width,uint64_t *sum) {
    if(!nvm_map_copy_charge(w,4))return NVM_MAP_COST_LIMIT;
    if(!!ptr!=!!count || !width)return NVM_MAP_COST_INVALID;
    if(count>
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
            (18446744073709551615UL)
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                      /width || count*width>
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
                                            (18446744073709551615UL)
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                                                      -*sum)return NVM_MAP_COST_LIMIT;
    *sum+=count*width;return NVM_MAP_COST_OK;
}
static inline NvmMapCostStatus nvm_map_copy_sum(uint64_t *sum,uint64_t add) {
    if(add>
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h" 3 4
          (18446744073709551615UL)
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_cost_private.h"
                    -*sum)return NVM_MAP_COST_LIMIT;
    *sum+=add;return NVM_MAP_COST_OK;
}
NvmMapCostStatus nvm_ownership_declarations_retained_cost(const NvmOwnershipDeclarationPlan *,NvmMapCopyWork *,uint64_t *);
NvmMapCostStatus nvm_map_declarations_retained_cost(const NvmMapDeclarationPlan *,NvmMapCopyWork *,uint64_t *);
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2

# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4

# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2


# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
static 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
      _Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
           scalar(uint8_t tag) {
    return tag == TAG_INT || tag == TAG_U8 || tag == TAG_FLOAT || tag == TAG_BOOL;
}

static 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
      _Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
           ownership_version(uint32_t version) {
    return version == 1u ||
           version == 2u ||
           version == 3u;
}

static NvmV2Result check_layouts(const NvmV2Layouts *layouts, const uint8_t *flags,
                                
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                               _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                    *needs, 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                            _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                 array_fields, 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                               _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                    union_fields, 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                  _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                       map_fields) {
    
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        resource_table = 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                         0
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                              ;
    for (uint32_t i = 0; i < layouts->count; i++)
        if (flags[i] & 2u) resource_table = 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                            1
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                ;


    if (resource_table) for (uint32_t i = 0; i < layouts->count; i++)
        for (uint16_t j = 0; j < layouts->items[i].field_count; j++) {
            uint32_t child = layouts->items[i].fields[j].nested_idx;
            if (child != 0xFFFFFFFFu && child >= i) return NVM_V2_ERR_SECTION_TYPE;
        }
    for (uint32_t i = 0; i < layouts->count; i++) {
        unsigned flag = flags[i];
        if (flag & ~(1u | 2u))
            return NVM_V2_ERR_RESERVED_FLAGS;
        if ((flag & 2u) && !(flag & 1u))
            return NVM_V2_ERR_SECTION_TYPE;
        if (!(flag & 1u)) continue;
        const NvmV2Layout *layout = &layouts->items[i];
        if (layout->kind != NVM_V2_LAYOUT_STRUCT &&
            !(union_fields && layout->kind == NVM_V2_LAYOUT_UNION))
            return NVM_V2_ERR_SECTION_TYPE;
        for (uint16_t j = 0; j < layout->field_count; j++) {
            const NvmV2LayoutField *field = &layout->fields[j];
            if (scalar(field->type_tag) || field->type_tag == TAG_STRING) {
                if (field->nested_idx != 0xFFFFFFFFu) return NVM_V2_ERR_SECTION_TYPE;
            } else if (array_fields && field->type_tag == TAG_ARRAY && !(flag & 2u)) {
                if (field->nested_idx != 0xFFFFFFFFu) return NVM_V2_ERR_SECTION_TYPE;
            } else if (map_fields && field->type_tag == TAG_HASHMAP &&
                       layout->kind == NVM_V2_LAYOUT_STRUCT && flag == 1u) {
                if (field->nested_idx != 0xFFFFFFFFu) return NVM_V2_ERR_SECTION_TYPE;
            } else if ((field->type_tag == TAG_STRUCT ||
                        (union_fields && field->type_tag == TAG_UNION)) &&
                       field->nested_idx < layouts->count &&
                       (!resource_table || field->nested_idx < i)) {
                uint16_t kind = field->type_tag == TAG_STRUCT ?
                    NVM_V2_LAYOUT_STRUCT : NVM_V2_LAYOUT_UNION;
                if (layouts->items[field->nested_idx].kind != kind)
                    return NVM_V2_ERR_SECTION_TYPE;
                unsigned nested = flags[field->nested_idx];
                if (!(nested & 1u)) return NVM_V2_ERR_SECTION_TYPE;
                if ((nested & 2u) && !(flag & 2u))
                    return NVM_V2_ERR_SECTION_TYPE;
            } else return NVM_V2_ERR_SECTION_TYPE;
        }


        if (flag & 2u) *needs = 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                1
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                    ;
    }
    return NVM_V2_OK;
}


typedef struct { uint32_t required; 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                   _Bool 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                        untyped; } EffectArrayReferences;
static NvmV2Result descriptor(NvmV2Cursor *cursor, const NvmV2Layouts *layouts,
                               const uint8_t *flags, uint32_t version, 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                      _Bool 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                           parameter,
                               int signature_tag, 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                 _Bool 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                      *needs, 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                              _Bool 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                   *ambiguous,
                               EffectArrayReferences *arrays) {
    uint8_t tag, mode;
    uint16_t reserved;
    uint32_t layout;
    NvmV2Result result;
    if ((result = nvm_v2_u8(cursor, &tag)) != NVM_V2_OK ||
        (result = nvm_v2_u8(cursor, &mode)) != NVM_V2_OK ||
        (result = nvm_v2_u16(cursor, &reserved)) != NVM_V2_OK ||
        (result = nvm_v2_u32(cursor, &layout)) != NVM_V2_OK) return result;
    if (reserved) return NVM_V2_ERR_RESERVED_FLAGS;
    if (tag >= TAG_COUNT || mode > NVM_REFERENCE_EXCLUSIVE ||
        (!parameter && mode) || (signature_tag >= 0 && tag != signature_tag))
        return NVM_V2_ERR_SECTION_TYPE;
    if (tag==TAG_ARRAY && arrays) {
        if (layout==0xFFFFFFFFu) arrays->untyped=
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                    1
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                        ;
        else {
            if (version!=3u || mode)
                return NVM_V2_ERR_SECTION_TYPE;

            if (arrays->required<layout+1) arrays->required=layout+1;
            *needs=
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                  1
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                      ;return NVM_V2_OK;
        }
    }
    if (layout != 0xFFFFFFFFu) {
        if (layout >= layouts->count) return NVM_V2_ERR_INDEX_RANGE;
        
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
       _Bool 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
            record=tag==TAG_STRUCT && (flags[layout]&1u) &&
                    layouts->items[layout].kind==NVM_V2_LAYOUT_STRUCT;
        
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
       _Bool 
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
            union_value=version==3u && tag==TAG_UNION &&
                         (!flags[layout] || (flags[layout]&1u)) &&
                         layouts->items[layout].kind==NVM_V2_LAYOUT_UNION;
        if (!record && !union_value)
            return NVM_V2_ERR_SECTION_TYPE;
        if (union_value) *needs=
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                               1
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                   ;
    }
    if (mode) {
        if (layout == 0xFFFFFFFFu || !(flags[layout] & 2u))
            return NVM_V2_ERR_SECTION_TYPE;
        NvmReferencePlace place = {1, 0, layout, 
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                ((void *)0)
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                    , 0, layout, (NvmReferenceMode)mode};
        if (!nvm_reference_place_valid(layouts, layout, &place)) {
            if (ambiguous) *ambiguous=
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                     1
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                         ;
            return NVM_V2_ERR_SECTION_TYPE;
        }
        *needs = 
# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                1
# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                    ;
    }
    return NVM_V2_OK;
}


static NvmV2Result paths_read(NvmV2Cursor *cursor,uint32_t wanted,
                               uint16_t *fields,uint16_t capacity,uint16_t *length,
                               
# 129 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                              _Bool 
# 129 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                   terminal) {
    uint32_t count;NvmV2Result result;
    uint16_t selected[32u],selected_count=0;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (count>256u) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint16_t n,reserved;
        if ((result=nvm_v2_u16(cursor,&n))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&reserved))!=NVM_V2_OK) return result;
        if (reserved) return NVM_V2_ERR_RESERVED_FLAGS;
        if (!n || n>32u) return NVM_V2_ERR_INDEX_RANGE;
        for (uint16_t j=0;j<n;j++) {
            uint16_t field;
            if ((result=nvm_v2_u16(cursor,&field))!=NVM_V2_OK) return result;
            if (i==wanted) selected[j]=field;
        }
        if (i==wanted) selected_count=n;
        if ((result=nvm_v2_align4(cursor))!=NVM_V2_OK) return result;
    }
    if (terminal && cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (wanted!=0xFFFFFFFFu) {
        if (!selected_count || selected_count>capacity || !fields || !length)
            return NVM_V2_ERR_INDEX_RANGE;
        for (uint16_t i=0;i<selected_count;i++) fields[i]=selected[i];
        *length=selected_count;
    }
    return NVM_V2_OK;
}

typedef struct {
    const uint8_t *data;
    uint32_t size;
    uint16_t revision;
} NvmOwnershipExtensionView;

typedef struct {
    NvmOwnershipExtensionView union_variants;
    NvmOwnershipExtensionView array_fields;
    NvmOwnershipExtensionView globals;
    NvmOwnershipExtensionView effects;
} NvmOwnershipExtensions;



static NvmV2Result extensions_read_map(NvmV2Cursor *cursor,NvmOwnershipExtensions *out,
                                         NvmOwnershipExtensionView *map) {
    uint32_t count;NvmV2Result result;
    NvmOwnershipExtensions found={0};uint16_t prior=0;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (!count || count>4u) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint16_t kind,revision;uint32_t bytes;const uint8_t *payload;
        if ((result=nvm_v2_u16(cursor,&kind))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&revision))!=NVM_V2_OK ||
            (result=nvm_v2_u32(cursor,&bytes))!=NVM_V2_OK ||
            (result=nvm_v2_take(cursor,bytes,&payload))!=NVM_V2_OK ||
            (result=nvm_v2_align4(cursor))!=NVM_V2_OK) return result;
        if (!kind || kind<=prior) return NVM_V2_ERR_SECTION_TYPE;
        if (revision!=1u &&
            !(kind==4u && (revision==2u ||
              revision==3u)))
            return NVM_V2_ERR_FORMAT_VERSION;
        NvmOwnershipExtensionView view={payload,bytes,revision};
        if (kind==1u)
            found.union_variants=view;
        else if (kind==2u)
            found.array_fields=view;
        else if (kind==3u)
            found.globals=view;
        else if (kind==4u)
            found.effects=view;
        else if (kind==5u && map)
            *map=view;
        else return NVM_V2_ERR_FORMAT_VERSION;
        prior=kind;
    }
    if (cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (out) *out=found;
    return NVM_V2_OK;
}



static NvmV2Result extension_suffix_read_map(NvmV2Cursor *cursor,uint32_t wanted,
                                         uint16_t *fields,uint16_t capacity,
                                         uint16_t *length,NvmOwnershipExtensions *extensions,
                                         NvmOwnershipExtensionView *map) {
    uint32_t bytes;const uint8_t *data;NvmV2Result result;
    if ((result=nvm_v2_u32(cursor,&bytes))!=NVM_V2_OK) return result;
    if (bytes<4 || bytes%4) return NVM_V2_ERR_SECTION_RANGE;
    if ((result=nvm_v2_take(cursor,bytes,&data))!=NVM_V2_OK) return result;
    NvmV2Cursor paths;nvm_v2_cursor_init(&paths,data,bytes);
    if ((result=paths_read(&paths,wanted,fields,capacity,length,
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                               1
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                   ))!=NVM_V2_OK)
        return result;
    return extensions_read_map(cursor,extensions,map);
}

static NvmV2Result extension_suffix_read(NvmV2Cursor *cursor,uint32_t wanted,
        uint16_t *fields,uint16_t capacity,uint16_t *length,NvmOwnershipExtensions *extensions) {
    return extension_suffix_read_map(cursor,wanted,fields,capacity,length,extensions,
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                    ((void *)0)
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                        );
}

NvmV2Result nvm_ownership_path(const NvmModule *module,uint32_t index,
                               uint16_t *fields,uint16_t capacity,uint16_t *count) {
    if (!module || !module->ownership_data || index==0xFFFFFFFFu)
        return NVM_V2_ERR_INDEX_RANGE;
    
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs=
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
              0
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                   ;NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,layouts,functions;const uint8_t *ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=2u && version!=3u)
        return NVM_V2_ERR_FORMAT_VERSION;
    if ((result=nvm_v2_u32(&cursor,&layouts))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,layouts,&ignored))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&functions))!=NVM_V2_OK) return result;
    if (functions!=module->function_count) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<functions;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK) return result;
        if (params>locals) return NVM_V2_ERR_INDEX_RANGE;
        if ((result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK) return result;
    }
    uint16_t selected[32u],selected_count=0;
    if (version==2u)
        result=paths_read(&cursor,index,selected,32u,
                          &selected_count,
# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                         1
# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                             );
    else
        result=extension_suffix_read(&cursor,index,selected,32u,
                                     &selected_count,
# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                    ((void *)0)
# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                        );
    if (result!=NVM_V2_OK) return result;
    if (!fields || !count || selected_count>capacity) return NVM_V2_ERR_INDEX_RANGE;
    for (uint16_t i=0;i<selected_count;i++) fields[i]=selected[i];
    *count=selected_count;
    return NVM_V2_OK;
}


typedef struct {
    NvmOwnershipExtensionView view;
    NvmUnionVariantFact *rows;
    uint32_t capacity, count;
    uint32_t *starts;
    uint16_t *variants;
    
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        ambiguous;
} OwnershipProjection;
static NvmV2Result union_facts_read(NvmV2Cursor *cursor,const NvmModule *module,
                                    const NvmV2Layouts *layouts,const uint8_t *flags,
                                    uint32_t wanted_union,uint16_t wanted_variant,
                                    NvmUnionVariantFact *selected, OwnershipProjection *projection) {
    uint32_t count;NvmV2Result result;
    NvmUnionVariantFact found={0};
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                 _Bool 
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                      have=
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                           0
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                ;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (count!=module->union_count || count>256u)
        return NVM_V2_ERR_INDEX_RANGE;
    uint32_t ordinal=0, copied=0;
    for (uint32_t i=0;i<count;i++) {
        uint32_t layout;uint16_t variants,reserved;
        if ((result=nvm_v2_u32(cursor,&layout))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&variants))!=NVM_V2_OK ||
            (result=nvm_v2_u16(cursor,&reserved))!=NVM_V2_OK) return result;
        while (ordinal<layouts->count && layouts->items[ordinal].kind!=NVM_V2_LAYOUT_UNION)
            ordinal++;
        if (reserved || !variants || variants>256u ||
            ordinal>=layouts->count || layout!=ordinal ||
            layouts->items[layout].kind!=NVM_V2_LAYOUT_UNION ||
            layouts->items[layout].name_idx==0xFFFFFFFFu)
            return NVM_V2_ERR_SECTION_TYPE;
        const NvmV2Layout *shape=&layouts->items[layout];
        if (projection && projection->rows) {
            if (copied>projection->capacity || variants>projection->capacity-copied)
                return NVM_V2_ERR_INDEX_RANGE;
            projection->starts[i]=copied;
            projection->variants[i]=variants;
        }
        size_t variants_at=cursor->pos;
        uint32_t next=0;
        for (uint16_t v=0;v<variants;v++) {
            uint32_t name;uint16_t offset,fields;
            if ((result=nvm_v2_u32(cursor,&name))!=NVM_V2_OK ||
                (result=nvm_v2_u16(cursor,&offset))!=NVM_V2_OK ||
                (result=nvm_v2_u16(cursor,&fields))!=NVM_V2_OK) return result;
            if (name>=module->string_count || offset!=next ||
                fields>shape->field_count-offset)
                return NVM_V2_ERR_INDEX_RANGE;
            for (uint16_t prior=0;prior<v;prior++) {
                size_t prior_at=variants_at+(size_t)prior*8;
                if (prior_at>cursor->size || cursor->size-prior_at<4)
                    return NVM_V2_ERR_SECTION_RANGE;
                uint32_t prior_name=(uint32_t)cursor->base[prior_at] |
                    ((uint32_t)cursor->base[prior_at+1]<<8) |
                    ((uint32_t)cursor->base[prior_at+2]<<16) |
                    ((uint32_t)cursor->base[prior_at+3]<<24);
                if (prior_name==name) return NVM_V2_ERR_SECTION_TYPE;
            }
            for (uint16_t f=0;f<fields;f++) {
                const NvmV2LayoutField *field=&shape->fields[offset+f];
                
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
               _Bool 
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                    leaf=(scalar(field->type_tag) || field->type_tag==TAG_STRING) &&
                          field->nested_idx==0xFFFFFFFFu;
                
# 331 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
               _Bool 
# 331 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                    nested=(flags[layout]&1u) &&
                            field->nested_idx<layout &&
                            (flags[field->nested_idx]&1u) &&
                            ((field->type_tag==TAG_STRUCT &&
                              layouts->items[field->nested_idx].kind==NVM_V2_LAYOUT_STRUCT) ||
                             (field->type_tag==TAG_UNION &&
                              layouts->items[field->nested_idx].kind==NVM_V2_LAYOUT_UNION));
                if ((!leaf && !nested) || field->name_idx==0xFFFFFFFFu)
                    return NVM_V2_ERR_SECTION_TYPE;
            }
            if (projection && projection->rows)
                projection->rows[copied]=(NvmUnionVariantFact){layout,name,offset,fields};
            copied++;
            if (i==wanted_union && v==wanted_variant) {
                found=(NvmUnionVariantFact){layout,name,offset,fields};have=
# 345 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                           1
# 345 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                               ;
            }
            next=(uint32_t)offset+fields;
        }
        if (next!=shape->field_count) return NVM_V2_ERR_INDEX_RANGE;
        ordinal++;
    }
    while (ordinal<layouts->count) {
        if (layouts->items[ordinal].kind==NVM_V2_LAYOUT_UNION)
            return NVM_V2_ERR_INDEX_RANGE;
        ordinal++;
    }
    if (cursor->pos!=cursor->size) return NVM_V2_ERR_SECTION_RANGE;
    if (wanted_union!=0xFFFFFFFFu && !have) return NVM_V2_ERR_INDEX_RANGE;
    if (have && selected) *selected=found;
    if (projection) projection->count=copied;
    return NVM_V2_OK;
}




static NvmV2Result globals_read(NvmOwnershipExtensionView view,
        const NvmV2Layouts *layouts,const uint8_t *flags) {
    NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,view.data,view.size);
    uint32_t count;NvmV2Result result;
    if ((result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) return result;
    if (!count || count>256u) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint8_t tag,mutable;uint16_t reserved;uint32_t layout;
        if ((result=nvm_v2_u8(&cursor,&tag))!=NVM_V2_OK ||
            (result=nvm_v2_u8(&cursor,&mutable))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&reserved))!=NVM_V2_OK ||
            (result=nvm_v2_u32(&cursor,&layout))!=NVM_V2_OK) return result;
        if (reserved || mutable>1) return NVM_V2_ERR_RESERVED_FLAGS;
        if (scalar(tag) || tag==TAG_STRING) {
            if (layout!=0xFFFFFFFFu) return NVM_V2_ERR_SECTION_TYPE;
        } else if (tag==TAG_STRUCT || tag==TAG_UNION) {
            if (layout>=layouts->count) return NVM_V2_ERR_INDEX_RANGE;
            uint16_t kind=tag==TAG_STRUCT?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION;
            if (layouts->items[layout].kind!=kind || !(flags[layout]&1u))
                return NVM_V2_ERR_SECTION_TYPE;
        } else return NVM_V2_ERR_SECTION_TYPE;
    }
    return cursor.pos==cursor.size?NVM_V2_OK:NVM_V2_ERR_SECTION_RANGE;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
static NvmV2Result effect_value_read(NvmV2Cursor *cursor,
        const NvmV2Layouts *layouts,const uint8_t *flags,
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                        _Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                             result_value,
        uint32_t earlier_types,
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                              _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                   arrays,
        NvmOwnershipEffectValue *out) {
    uint8_t mode;uint16_t reserved;NvmV2Result result;
    NvmOwnershipEffectValue value={0};
    if ((result=nvm_v2_u8(cursor,&value.tag))!=NVM_V2_OK ||
        (result=nvm_v2_u8(cursor,&mode))!=NVM_V2_OK ||
        (result=nvm_v2_u16(cursor,&reserved))!=NVM_V2_OK ||
        (result=nvm_v2_u32(cursor,&value.layout))!=NVM_V2_OK) return result;
    if (mode || reserved) return NVM_V2_ERR_RESERVED_FLAGS;
    if (scalar(value.tag) || value.tag==TAG_STRING ||
        (result_value && value.tag==TAG_VOID)) {
        if (value.layout!=0xFFFFFFFFu) return NVM_V2_ERR_SECTION_TYPE;
    } else if (value.tag==TAG_STRUCT || value.tag==TAG_UNION) {
        if (value.layout>=layouts->count) return NVM_V2_ERR_INDEX_RANGE;
        uint16_t kind=value.tag==TAG_STRUCT?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION;
        if (layouts->items[value.layout].kind!=kind ||
            !(flags[value.layout]&1u)) return NVM_V2_ERR_SECTION_TYPE;
    } else if (arrays && value.tag==TAG_ARRAY) {
        if (value.layout>=earlier_types) return NVM_V2_ERR_INDEX_RANGE;
    } else return NVM_V2_ERR_SECTION_TYPE;
    *out=value;return NVM_V2_OK;
}

typedef struct { uint32_t function,pc,element; } EffectConstructorQuery;



static NvmV2Result effect_constructors_read(NvmV2Cursor *cursor,const NvmModule *module,
        const NvmOwnershipEffectTypes *types,EffectConstructorQuery *query) {
    uint32_t count,prior_function=
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                 (4294967295U)
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                           ,prior_site=0,pc=0;
    NvmV2Result result;
    if ((result=nvm_v2_u32(cursor,&count))!=NVM_V2_OK) return result;
    if (count>32768u) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        uint32_t function,site,element;
        if ((result=nvm_v2_u32(cursor,&function))!=NVM_V2_OK ||
            (result=nvm_v2_u32(cursor,&site))!=NVM_V2_OK ||
            (result=nvm_v2_u32(cursor,&element))!=NVM_V2_OK) return result;
        if (!module->functions || function>=module->function_count || element>=types->count)
            return NVM_V2_ERR_INDEX_RANGE;
        if (i && (function<prior_function || (function==prior_function && site<=prior_site)))
            return NVM_V2_ERR_SECTION_TYPE;
        const NvmFunctionEntry *fn=&module->functions[function];
        if (!module->code || fn->code_offset>module->code_size ||
            fn->code_length>module->code_size-fn->code_offset || site>=fn->code_length)
            return NVM_V2_ERR_INDEX_RANGE;
        if (function!=prior_function) pc=0;
        DecodedInstruction instruction;uint32_t width;
        while (pc<site) {
            width=isa_decode(module->code+fn->code_offset+pc,fn->code_length-pc,&instruction);
            if (!width) return NVM_V2_ERR_SECTION_TYPE;
            pc+=width;
        }
        if (pc!=site) return NVM_V2_ERR_SECTION_TYPE;
        width=isa_decode(module->code+fn->code_offset+pc,fn->code_length-pc,&instruction);
        if (!width || (instruction.opcode!=OP_ARR_NEW &&
                !(instruction.opcode==OP_ARR_LITERAL && !instruction.operands[1].u16)) ||
            instruction.operands[0].u8!=types->items[element].tag)
            return NVM_V2_ERR_SECTION_TYPE;
        if (query && query->function==function && query->pc==site) query->element=element;
        prior_function=function;prior_site=site;pc+=width;
    }
    return NVM_V2_OK;
}

static NvmV2Result effects_read(NvmOwnershipExtensionView view,
        const NvmModule *module,const NvmV2Layouts *layouts,const uint8_t *flags,
        uint32_t wanted,NvmOwnershipEffect *out,NvmOwnershipEffectTypes *types_out,
        EffectConstructorQuery *constructor) {
    NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,view.data,view.size);
    uint32_t count,keys[256u];NvmV2Result result;
    NvmOwnershipEffect selected={0};
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                   _Bool 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                        found=
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                              0
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                   ;
    NvmOwnershipEffectTypes types={0};
    if (view.revision>=2u) {
        if ((result=nvm_v2_u32(&cursor,&types.count))!=NVM_V2_OK) return result;
        if (!types.count || types.count>256u)
            return NVM_V2_ERR_INDEX_RANGE;
        for (uint32_t i=0;i<types.count;i++)
            if ((result=effect_value_read(&cursor,layouts,flags,
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                               0
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                                    ,i,
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                                       1
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                                           ,&types.items[i]))!=NVM_V2_OK)
                return result;
    }
    EffectConstructorQuery selected_constructor=constructor?*constructor:(EffectConstructorQuery){0};
    selected_constructor.element=0xFFFFFFFFu;
    if (view.revision==3u &&
        (result=effect_constructors_read(&cursor,module,&types,&selected_constructor))!=NVM_V2_OK)
        return result;
    const char *requested=wanted==0xFFFFFFFFu?
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                 ((void *)0)
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                     :nvm_get_string(module,wanted);
    if (wanted!=0xFFFFFFFFu && !requested) return NVM_V2_ERR_INDEX_RANGE;
    if ((result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) return result;
    if (!count || count>256u) return NVM_V2_ERR_INDEX_RANGE;
    for (uint32_t i=0;i<count;i++) {
        NvmOwnershipEffect row={0};uint16_t reserved;
        if ((result=nvm_v2_u32(&cursor,&row.key_idx))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&row.parameter_count))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&reserved))!=NVM_V2_OK) return result;
        if (reserved) return NVM_V2_ERR_RESERVED_FLAGS;
        if (row.parameter_count>256u ||
            row.key_idx>=module->string_count) return NVM_V2_ERR_INDEX_RANGE;
        const char *key=nvm_get_string(module,row.key_idx);
        uint32_t length=nvm_get_string_len(module,row.key_idx);
        if (!key || !length || memchr(key,0,length) || (i && row.key_idx<=keys[i-1]))
            return NVM_V2_ERR_SECTION_TYPE;
        for (uint32_t j=0;j<i;j++)
            if (!strcmp(key,nvm_get_string(module,keys[j]))) return NVM_V2_ERR_SECTION_TYPE;
        keys[i]=row.key_idx;
        if ((result=effect_value_read(&cursor,layouts,flags,
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                           1
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                               ,types.count,view.revision>=2u,&row.result))!=NVM_V2_OK)
            return result;
        for (uint16_t p=0;p<row.parameter_count;p++)
            if ((result=effect_value_read(&cursor,layouts,flags,
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                               0
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                                    ,types.count,view.revision>=2u,&row.parameters[p]))!=NVM_V2_OK)
                return result;
        if (requested && nvm_get_string_len(module,wanted)==length &&
            !memcmp(requested,key,length)) { selected=row;found=
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc" 3 4
                                                               1
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_effects.inc"
                                                                   ; }
    }
    if (cursor.pos!=cursor.size) return NVM_V2_ERR_SECTION_RANGE;
    if (wanted!=0xFFFFFFFFu && !found) return NVM_V2_ERR_INDEX_RANGE;
    if (out && found) *out=selected;
    if (types_out) *types_out=types;
    if (constructor) *constructor=selected_constructor;
    return NVM_V2_OK;
}
# 393 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h"
NvmV2Result nvm_ownership_layouts_private_decode(const uint8_t *,size_t,NvmV2Layouts *);


NvmV2Result nvm_ownership_mixed_layouts_private_decode(const uint8_t *,size_t,NvmV2Layouts *);




NvmV2Result nvm_ownership_mixed_layouts_private_decode_detailed(const uint8_t *,size_t,
                                                             NvmV2Layouts *,
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h" 3 4
                                                                           _Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h"
                                                                                *allocation_failed);

NvmV2Result nvm_ownership_map_layouts_private_decode_detailed(const uint8_t *,size_t,
                                                             NvmV2Layouts *,
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h" 3 4
                                                                           _Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_layouts_private.h"
                                                                                *allocation_failed);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 2




struct NvmOrdinaryArrayAuthority {
    NvmV2Layouts layouts;
    NvmOrdinaryArrayType *types;
    NvmOrdinaryArrayBinding *bindings;
    uint8_t flags[256u];
    uint32_t type_count, binding_count, steps;
    NvmOrdinaryArrayStatus failure;
    
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
   _Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
        unknown;
};
static 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
      _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
           oaa_charge(NvmOrdinaryArrayAuthority *p,uint32_t n) {
    if(n>1048576u -p->steps){p->failure=NVM_OAA_LIMIT;return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
                                                            0
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
                                                                 ;}
    p->steps+=n;return 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
                      1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
                          ;
}
static NvmV2Result oaa_array_fields(NvmOwnershipExtensionView view,
                                   NvmOrdinaryArrayAuthority *p) {
    NvmV2Cursor c;nvm_v2_cursor_init(&c,view.data,view.size);
    uint32_t types,bindings;NvmV2Result r;
    if((r=nvm_v2_u32(&c,&types))!=NVM_V2_OK)return r;
    if(types>4096u){p->failure=NVM_OAA_LIMIT;return NVM_V2_ERR_INDEX_RANGE;}

    const uint8_t *rows;
    if((r=nvm_v2_take(&c,(size_t)types*8,&rows))!=NVM_V2_OK ||
       (r=nvm_v2_u32(&c,&bindings))!=NVM_V2_OK)return r;
    if(bindings>65536u){p->failure=NVM_OAA_LIMIT;return NVM_V2_ERR_INDEX_RANGE;}
    const uint8_t *binding_rows;
    if((r=nvm_v2_take(&c,(size_t)bindings*12,&binding_rows))!=NVM_V2_OK)return r;
    if(c.pos!=c.size)return NVM_V2_ERR_SECTION_RANGE;
    size_t bytes=sizeof *p+(size_t)p->layouts.count*sizeof(NvmV2Layout);
    for(uint32_t i=0;i<p->layouts.count;i++)bytes+=(size_t)p->layouts.items[i].field_count*sizeof(NvmV2LayoutField);

    size_t extra=(size_t)types*sizeof *p->types+(size_t)bindings*sizeof *p->bindings;
    if(bytes>(16u * 1024u * 1024u) || extra>(16u * 1024u * 1024u)-bytes){p->failure=NVM_OAA_LIMIT;return NVM_V2_ERR_INDEX_RANGE;}
    p->type_count=types;p->binding_count=bindings;
    if(types)p->types=calloc(types,sizeof *p->types);
    if(bindings)p->bindings=calloc(bindings,sizeof *p->bindings);
    if((types&&!p->types)||(bindings&&!p->bindings)){p->failure=NVM_OAA_MEMORY;return NVM_V2_ERR_TRUNCATED;}
    NvmV2Cursor t;nvm_v2_cursor_init(&t,rows,(size_t)types*8);
    for(uint32_t i=0;i<types;i++) {
        if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
        uint8_t tag,z;uint16_t zz;uint32_t ref;
        if((r=nvm_v2_u8(&t,&tag))!=NVM_V2_OK || (r=nvm_v2_u8(&t,&z))!=NVM_V2_OK ||
           (r=nvm_v2_u16(&t,&zz))!=NVM_V2_OK || (r=nvm_v2_u32(&t,&ref))!=NVM_V2_OK)return r;
        if(z||zz)return NVM_V2_ERR_RESERVED_FLAGS;
        if(scalar(tag)||tag==TAG_STRING){if(ref!=0xFFFFFFFFu)return NVM_V2_ERR_INDEX_RANGE;}
        else if(tag==TAG_ARRAY){if(ref>=types)return NVM_V2_ERR_INDEX_RANGE;}
        else if(tag==TAG_STRUCT){
            if(ref>=p->layouts.count || p->layouts.items[ref].kind!=NVM_V2_LAYOUT_STRUCT ||
               p->flags[ref]!=1u)return NVM_V2_ERR_SECTION_TYPE;
            p->unknown=
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
                      1
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
                          ;
        } else return NVM_V2_ERR_SECTION_TYPE;
        p->types[i]=(NvmOrdinaryArrayType){tag,ref};
    }


    uint8_t color[4096u]={0},depths[4096u]={0};uint32_t path[64];
    for(uint32_t root=0;root<types;root++) {
        uint32_t at=root,n=0;unsigned depth=0;
        while(!color[at]) {
            if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
            if(n==64){p->failure=NVM_OAA_LIMIT;return NVM_V2_ERR_INDEX_RANGE;}
            color[at]=1;path[n++]=at;
            if(p->types[at].tag!=TAG_ARRAY)break;
            at=p->types[at].referent;
            if(color[at]==1)return NVM_V2_ERR_SECTION_TYPE;
        }
        if(color[at]==2)depth=depths[at];
        while(n){uint32_t item=path[--n];if(++depth>64){p->failure=NVM_OAA_LIMIT;return NVM_V2_ERR_INDEX_RANGE;}color[item]=2;depths[item]=(uint8_t)depth;}
    }


    for(uint32_t i=0;i<types;i++)if(p->types[i].tag==TAG_ARRAY) {
        if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
        NvmOrdinaryArrayType child=p->types[p->types[i].referent];
        if(child.tag==TAG_ARRAY) {
            if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
            child=p->types[child.referent];
        }
        if(child.tag<TAG_INT || child.tag>TAG_STRING || child.referent!=0xFFFFFFFFu)p->unknown=
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc" 3 4
                                                                                                  1
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_array_fields.inc"
                                                                                                      ;
    }
    nvm_v2_cursor_init(&t,binding_rows,(size_t)bindings*12);
    for(uint32_t i=0;i<bindings;i++) {
        if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
        uint32_t layout,element;uint16_t field,z;
        if((r=nvm_v2_u32(&t,&layout))!=NVM_V2_OK || (r=nvm_v2_u16(&t,&field))!=NVM_V2_OK ||
           (r=nvm_v2_u16(&t,&z))!=NVM_V2_OK || (r=nvm_v2_u32(&t,&element))!=NVM_V2_OK)return r;
        if(z)return NVM_V2_ERR_RESERVED_FLAGS;
        if(layout>=p->layouts.count || element>=types || p->flags[layout]!=1u ||
           p->layouts.items[layout].kind!=NVM_V2_LAYOUT_STRUCT || field>=p->layouts.items[layout].field_count ||
           p->layouts.items[layout].fields[field].type_tag!=TAG_ARRAY)return NVM_V2_ERR_SECTION_TYPE;
        if(i && (layout<p->bindings[i-1].layout || (layout==p->bindings[i-1].layout && field<=p->bindings[i-1].field)))return NVM_V2_ERR_SECTION_TYPE;
        p->bindings[i]=(NvmOrdinaryArrayBinding){layout,field,element};
    }
    uint32_t next=0;
    for(uint32_t i=0;i<p->layouts.count;i++)for(uint16_t f=0;f<p->layouts.items[i].field_count;f++) {
        if(!oaa_charge(p,1))return NVM_V2_ERR_INDEX_RANGE;
        if(p->flags[i]==1u && p->layouts.items[i].fields[f].type_tag==TAG_ARRAY) {
            if(next>=bindings || p->bindings[next].layout!=i || p->bindings[next].field!=f)return NVM_V2_ERR_SECTION_TYPE;
            next++;
        }
    }
    return next==bindings?NVM_V2_OK:NVM_V2_ERR_SECTION_TYPE;
}
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
struct NvmMapDeclarationPlan {
    NvmOwnershipDeclarationPlan *base;
    uint8_t *scalars;
    NvmMapDeclarationPair *pairs;
    NvmMapDeclarationBinding *bindings;
    uint32_t *starts;
    NvmMapDeclarationCounts counts;
    uint32_t layouts;
    uint64_t bytes,work;
    NvmMapDeclarationStatus failure;
};
typedef struct {
    uint8_t scalar_used[5],pair_used[25];
    NvmV2Cursor extent,rows;
    NvmMapDeclarationPair previous_pair;
    NvmMapDeclarationBinding previous_binding;
    uint32_t scalars,pairs,bindings,index,layout;
    uint8_t previous_tag;
} MapDeclarationScratch;
static 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
      _Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
           map_charge(NvmMapDeclarationPlan *p,uint64_t bytes,uint64_t work) {
    if(p->bytes>(2u*1024u*1024u) || bytes>(2u*1024u*1024u)-p->bytes ||
       p->work>(4u*1024u*1024u) || work>(4u*1024u*1024u)-p->work) {
        p->failure=NVM_MAP_LIMIT;return 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                       0
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                            ;
    }
    p->bytes+=bytes;p->work+=work;return 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                        1
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                            ;
}
static void *map_alloc(NvmMapDeclarationPlan *p,size_t n,size_t width) {
    if(width && n>
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                 (18446744073709551615UL)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                         /width){p->failure=NVM_MAP_LIMIT;return 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                 ((void *)0)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                     ;}
    if(!map_charge(p,(uint64_t)n*width,0))return 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                ((void *)0)
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                    ;
    void *v=calloc(n,width);if(!v)p->failure=NVM_MAP_MEMORY;return v;
}
static 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
      _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
           map_payload(NvmMapDeclarationPlan *p,NvmOwnershipExtensionView view,
                        const NvmV2Layouts *layouts,const uint8_t *flags) {
    if(!map_charge(p,sizeof(MapDeclarationScratch),(uint64_t)view.size*2u))return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                 0
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                      ;
    MapDeclarationScratch s={0};const uint8_t *scalar_rows,*pair_rows,*binding_rows;
    nvm_v2_cursor_init(&s.extent,view.data,view.size);
    if(view.revision!=1 || nvm_v2_u32(&s.extent,&s.scalars)!=NVM_V2_OK)return 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                             0
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                  ;
    if(!s.scalars || s.scalars>5){p->failure=s.scalars?NVM_MAP_LIMIT:NVM_MAP_INVALID;return 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                           0
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                                ;}
    if(nvm_v2_take(&s.extent,(size_t)s.scalars*8,&scalar_rows)!=NVM_V2_OK ||
       nvm_v2_u32(&s.extent,&s.pairs)!=NVM_V2_OK)return 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                       0
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                            ;
    if(!s.pairs || s.pairs>25){p->failure=s.pairs?NVM_MAP_LIMIT:NVM_MAP_INVALID;return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                      0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                           ;}
    if(nvm_v2_take(&s.extent,(size_t)s.pairs*8,&pair_rows)!=NVM_V2_OK ||
       nvm_v2_u32(&s.extent,&s.bindings)!=NVM_V2_OK)return 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                          0
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                               ;
    if(!s.bindings || s.bindings>65536){p->failure=s.bindings?NVM_MAP_LIMIT:NVM_MAP_INVALID;return 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                                  0
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                                       ;}
    if(nvm_v2_take(&s.extent,(size_t)s.bindings*12,&binding_rows)!=NVM_V2_OK ||
       s.extent.pos!=s.extent.size || layouts->count>256)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                               0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                    ;
    p->counts=(NvmMapDeclarationCounts){s.scalars,s.pairs,s.bindings};p->layouts=layouts->count;
    p->scalars=map_alloc(p,s.scalars,sizeof *p->scalars);
    if(!p->scalars)return 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                         0
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                              ;
    p->pairs=map_alloc(p,s.pairs,sizeof *p->pairs);
    if(!p->pairs)return 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                       0
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                            ;
    p->bindings=map_alloc(p,s.bindings,sizeof *p->bindings);
    if(!p->bindings)return 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                          0
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                               ;
    p->starts=map_alloc(p,257,sizeof *p->starts);
    if(!p->scalars || !p->pairs || !p->bindings || !p->starts)return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                    0
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                         ;
    nvm_v2_cursor_init(&s.rows,scalar_rows,(size_t)s.scalars*8);
    for(s.index=0;s.index<s.scalars;s.index++) {
        uint8_t tag,z;uint16_t zz;uint32_t ref;
        if(!map_charge(p,0,1))return 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                    0
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                         ;
        if(nvm_v2_u8(&s.rows,&tag)!=NVM_V2_OK || nvm_v2_u8(&s.rows,&z)!=NVM_V2_OK ||
           nvm_v2_u16(&s.rows,&zz)!=NVM_V2_OK || nvm_v2_u32(&s.rows,&ref)!=NVM_V2_OK ||
           z || zz || ref!=0xFFFFFFFFu || (!scalar(tag)&&tag!=TAG_STRING) ||
           (s.index && tag<=s.previous_tag))return 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                  0
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                       ;
        p->scalars[s.index]=tag;s.previous_tag=tag;
    }
    nvm_v2_cursor_init(&s.rows,pair_rows,(size_t)s.pairs*8);
    for(s.index=0;s.index<s.pairs;s.index++) {
        NvmMapDeclarationPair row;
        if(!map_charge(p,0,4))return 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                    0
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                         ;
        if(nvm_v2_u32(&s.rows,&row.key_type)!=NVM_V2_OK || nvm_v2_u32(&s.rows,&row.value_type)!=NVM_V2_OK ||
           row.key_type>=s.scalars || row.value_type>=s.scalars || (s.index &&
           (row.key_type<s.previous_pair.key_type || (row.key_type==s.previous_pair.key_type &&
            row.value_type<=s.previous_pair.value_type))))return 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                0
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                     ;
        p->pairs[s.index]=row;s.previous_pair=row;
        s.scalar_used[row.key_type]=1;s.scalar_used[row.value_type]=1;
    }
    nvm_v2_cursor_init(&s.rows,binding_rows,(size_t)s.bindings*12);
    for(s.index=0;s.index<s.bindings;s.index++) {
        NvmMapDeclarationBinding row;uint16_t reserved;
        if(!map_charge(p,0,5))return 
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                    0
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                         ;
        if(nvm_v2_u32(&s.rows,&row.layout)!=NVM_V2_OK || nvm_v2_u16(&s.rows,&row.field)!=NVM_V2_OK ||
           nvm_v2_u16(&s.rows,&reserved)!=NVM_V2_OK || nvm_v2_u32(&s.rows,&row.pair)!=NVM_V2_OK ||
           reserved || row.layout>=layouts->count || row.pair>=s.pairs ||
           row.field>=layouts->items[row.layout].field_count || (s.index &&
           (row.layout<s.previous_binding.layout || (row.layout==s.previous_binding.layout &&
            row.field<=s.previous_binding.field))))return 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                         0
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                              ;
        const NvmV2Layout *l=&layouts->items[row.layout];
        if(l->kind!=NVM_V2_LAYOUT_STRUCT || flags[row.layout]!=1u ||
           l->fields[row.field].type_tag!=TAG_HASHMAP || l->fields[row.field].nested_idx!=0xFFFFFFFFu)return 
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                                                0
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                                                     ;
        p->bindings[s.index]=row;s.previous_binding=row;s.pair_used[row.pair]=1;
    }
    s.index=0;
    for(s.layout=0;s.layout<layouts->count;s.layout++) {
        const NvmV2Layout *l=&layouts->items[s.layout];
        if(!map_charge(p,0,1))return 
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                    0
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                         ;
        p->starts[s.layout]=s.index;
        for(uint16_t f=0;f<l->field_count;f++) {
            if(!map_charge(p,0,2))return 
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                        0
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                             ;
            if(l->fields[f].type_tag!=TAG_HASHMAP)continue;
            if(s.index>=s.bindings || p->bindings[s.index].layout!=s.layout ||
               p->bindings[s.index].field!=f)return 
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                   0
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                        ;
            s.index++;
        }
    }
    p->starts[layouts->count]=s.index;
    if(s.index!=s.bindings)return 
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                 0
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                      ;
    for(uint32_t i=0;i<s.scalars;i++){if(!map_charge(p,0,1)||!s.scalar_used[i])return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                     0
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                          ;}
    for(uint32_t i=0;i<s.pairs;i++){if(!map_charge(p,0,1)||!s.pair_used[i])return 
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
                                                                                 0
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
                                                                                      ;}
    return 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc" 3 4
          1
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_fields.inc"
              ;
}
# 395 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
static NvmV2Result ownership_validate_owned(const NvmModule *module,
        const NvmV2Layouts *layouts,
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                   _Bool 
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                        *requires_verifier,
        NvmOrdinaryArrayAuthority *private_plan, OwnershipProjection *projection,
        NvmMapDeclarationPlan *map) {
    NvmV2Result result;
    
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        ambiguous=
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                  0
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                       ;
    EffectArrayReferences arrays={0};uint32_t effect_type_count=0;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
    uint32_t version, count;
    const uint8_t *flags;
    
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs = 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                0
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                     ;
    if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
        (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK) goto done;
    if (!ownership_version(version)) { result = NVM_V2_ERR_FORMAT_VERSION; goto done; }
    if (count != layouts->count) { result = NVM_V2_ERR_INDEX_RANGE; goto done; }
    if ((result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK ||
        (result = nvm_v2_align4(&cursor)) != NVM_V2_OK ||
        (result = check_layouts(layouts, flags, &needs, private_plan!=
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                     ((void *)0)
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                         ,
                                version==3u && !private_plan,map!=
# 414 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                              ((void *)0)
# 414 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                                  )) != NVM_V2_OK ||
        (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK) goto done;
    if (private_plan) for (uint32_t i=0;i<layouts->count;i++) private_plan->flags[i]=flags[i];
    if (count != module->function_count || (count && !module->functions)) {
        result = NVM_V2_ERR_INDEX_RANGE; goto done;
    }
    for (uint32_t i = 0; i < count; i++) {
        uint16_t locals, params;
        const NvmFunctionEntry *function = &module->functions[i];
        if ((result = nvm_v2_u16(&cursor, &locals)) != NVM_V2_OK ||
            (result = nvm_v2_u16(&cursor, &params)) != NVM_V2_OK) goto done;
        if (locals != function->local_count || params != function->arity || params > locals ||
            function->result_count > 1) { result = NVM_V2_ERR_INDEX_RANGE; goto done; }
        int return_tag = function->result_count ? function->result_tag : TAG_VOID;
        if(map && return_tag==TAG_HASHMAP) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
        ambiguous=
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                 0
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                      ;
        result=descriptor(&cursor,layouts,flags,version,
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                       0
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                            ,return_tag,&needs,private_plan?&ambiguous:
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                                       ((void *)0)
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                                           ,private_plan?
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                                                         ((void *)0)
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                                                             :&arrays);
        if (result!=NVM_V2_OK) {
            if (!projection || !ambiguous) goto done;
            projection->ambiguous=
# 433 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                 1
# 433 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                     ;result=NVM_V2_OK;
        }
        for (uint16_t local = 0; local < locals; local++) {
            int tag = -1;
            if (local < params) tag = module->function_param_types &&
                module->function_param_types[i] ? module->function_param_types[i][local] : TAG_VOID;
            if(map && local<params && tag==TAG_HASHMAP) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
            ambiguous=
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                     0
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                          ;
            result=descriptor(&cursor,layouts,flags,version,local<params,tag,&needs,private_plan?&ambiguous:
# 441 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                                           ((void *)0)
# 441 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                                               ,private_plan?
# 441 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                                                             ((void *)0)
# 441 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                                                                 :&arrays);
            if (result!=NVM_V2_OK) {
                if (!projection || !ambiguous) goto done;
                projection->ambiguous=
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                     1
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                         ;result=NVM_V2_OK;
            }
        }
    }
    NvmOwnershipExtensions extensions={0};NvmOwnershipExtensionView map_view={0};
    if (version==2u) {
        if ((result=paths_read(&cursor,0xFFFFFFFFu,
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                      ((void *)0)
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                          ,0,
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                             ((void *)0)
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                 ,
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                  1
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                      ))!=NVM_V2_OK)
            goto done;
    } else if (version==3u) {
        if ((result=extension_suffix_read_map(&cursor,0xFFFFFFFFu,
# 453 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                     ((void *)0)
# 453 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                         ,0,
# 453 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                            ((void *)0)
# 453 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                ,
                                          &extensions,map?&map_view:
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                   ((void *)0)
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                       ))!=NVM_V2_OK) goto done;
        if (!!extensions.union_variants.data != !!module->union_count) {
            result=NVM_V2_ERR_SECTION_TYPE;goto done;
        }
        if (extensions.union_variants.data) {
            NvmV2Cursor unions;nvm_v2_cursor_init(&unions,extensions.union_variants.data,
                                                  extensions.union_variants.size);
            if ((result=union_facts_read(&unions,module,layouts,flags,0xFFFFFFFFu,0,
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                       ((void *)0)
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                           ,projection))
                !=NVM_V2_OK) goto done;
            if (projection) projection->view=extensions.union_variants;
            needs=
# 464 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                 1
# 464 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                     ;
        }
        if (extensions.globals.data) {


            if (private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            if ((result=globals_read(extensions.globals,layouts,flags))!=NVM_V2_OK) goto done;
            needs=
# 471 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                 1
# 471 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                     ;
        }
        if (extensions.effects.data) {
            if (private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            NvmOwnershipEffectTypes types;
            if ((result=effects_read(extensions.effects,module,layouts,flags,
                                     0xFFFFFFFFu,
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                    ((void *)0)
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                        ,&types,
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                ((void *)0)
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                    ))!=NVM_V2_OK) goto done;
            effect_type_count=types.count;
            needs=
# 479 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                 1
# 479 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                     ;
        }
        if (extensions.array_fields.data) {
            if (!private_plan) { result=NVM_V2_ERR_FORMAT_VERSION;goto done; }
            if ((result=oaa_array_fields(extensions.array_fields,private_plan))!=NVM_V2_OK) goto done;
        }
    }
    if (map && (!map_view.data || !map_payload(map,map_view,layouts,flags))) {
        result=NVM_V2_ERR_SECTION_TYPE;goto done;
    }
    if (arrays.required>effect_type_count) { result=NVM_V2_ERR_INDEX_RANGE;goto done; }
    if (effect_type_count && arrays.untyped) { result=NVM_V2_ERR_SECTION_TYPE;goto done; }
    if (cursor.pos != cursor.size) { result = NVM_V2_ERR_SECTION_RANGE; goto done; }
    *requires_verifier = needs;
done:
    if (private_plan && ambiguous && !projection) private_plan->failure=NVM_OAA_UNKNOWN;
    return result;
}

NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 499 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                           _Bool 
# 499 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                *requires_verifier) {
    if (!module || !requires_verifier) return NVM_V2_ERR_INDEX_RANGE;
    *requires_verifier = 
# 501 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                        0
# 501 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                             ;
    if (!module->ownership_size)
        return module->ownership_data ? NVM_V2_ERR_SECTION_RANGE : NVM_V2_OK;
    if (!module->ownership_data || !module->layout_size ||
        !nvm_retained_layouts_valid(module)) return NVM_V2_ERR_SECTION_TYPE;
    NvmV2Layouts layouts = {0};
    NvmV2Result result = nvm_v2_layouts_decode(module->layout_data,
                                             module->layout_size, &layouts);
    if (result != NVM_V2_OK) return result;
    result=ownership_validate_owned(module,&layouts,requires_verifier,
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                     ((void *)0)
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                         ,
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                          ((void *)0)
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                              ,
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                               ((void *)0)
# 510 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                   );
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_globals(const NvmModule *module,NvmOwnershipGlobal *out,
                                  uint32_t capacity,uint32_t *count) {
    if (!module || !count || (!out && capacity)) return NVM_V2_ERR_INDEX_RANGE;
    
# 518 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 518 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs=
# 518 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
              0
# 518 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                   ;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    if (!module->ownership_size) { *count=0;return NVM_V2_OK; }
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,n;const uint8_t *ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=3u) { *count=0;return NVM_V2_OK; }
    if ((result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,n,&ignored))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK) return result;
    for (uint32_t i=0;i<n;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            return result;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,0xFFFFFFFFu,
# 539 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                             ((void *)0)
# 539 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                 ,0,
# 539 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                    ((void *)0)
# 539 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                        ,&extensions))
        !=NVM_V2_OK) return result;
    if (!extensions.globals.data) { *count=0;return NVM_V2_OK; }
    nvm_v2_cursor_init(&cursor,extensions.globals.data,extensions.globals.size);
    if ((result=nvm_v2_u32(&cursor,&n))!=NVM_V2_OK) return result;
    if (out && capacity<n) return NVM_V2_ERR_INDEX_RANGE;
    NvmOwnershipGlobal rows[256u];
    for (uint32_t i=0;i<n;i++) {
        uint8_t mutable;uint16_t reserved;
        if ((result=nvm_v2_u8(&cursor,&rows[i].tag))!=NVM_V2_OK ||
            (result=nvm_v2_u8(&cursor,&mutable))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&reserved))!=NVM_V2_OK ||
            (result=nvm_v2_u32(&cursor,&rows[i].layout))!=NVM_V2_OK) return result;
        rows[i].mutable=mutable!=0;
    }
    if (out) for (uint32_t i=0;i<n;i++) out[i]=rows[i];
    *count=n;return NVM_V2_OK;
}

static NvmV2Result ownership_effect_query(const NvmModule *module,uint32_t key_idx,
                                 NvmOwnershipEffect *out,NvmOwnershipEffectTypes *types,
                                 EffectConstructorQuery *constructor) {
    if (!module || (!out && !types && !constructor) || (out && key_idx>=module->string_count)) return NVM_V2_ERR_INDEX_RANGE;
    
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs=
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
              0
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                   ;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    if (!module->ownership_size) return NVM_V2_ERR_INDEX_RANGE;
    NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,count;const uint8_t *flags,*ignored;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK) return result;
    if (version!=3u) return NVM_V2_ERR_INDEX_RANGE;
    if ((result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,count,&flags))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) return result;
    for (uint32_t i=0;i<count;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            return result;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,0xFFFFFFFFu,
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                             ((void *)0)
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                 ,0,
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                    ((void *)0)
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                        ,&extensions))!=NVM_V2_OK)
        return result;
    if (!extensions.effects.data) return NVM_V2_ERR_INDEX_RANGE;
    NvmV2Layouts layouts={0};
    result=nvm_v2_layouts_decode(module->layout_data,module->layout_size,&layouts);
    if (result!=NVM_V2_OK) return result;
    result=effects_read(extensions.effects,module,&layouts,flags,key_idx,out,types,constructor);
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_effect(const NvmModule *module,uint32_t key_idx,
                                 NvmOwnershipEffect *out) {
    return ownership_effect_query(module,key_idx,out,
# 595 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                    ((void *)0)
# 595 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                        ,
# 595 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                         ((void *)0)
# 595 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                             );
}
NvmV2Result nvm_ownership_effect_types(const NvmModule *module,NvmOwnershipEffectTypes *out) {
    return ownership_effect_query(module,0xFFFFFFFFu,
# 598 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                        ((void *)0)
# 598 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                            ,out,
# 598 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                 ((void *)0)
# 598 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                     );
}

NvmV2Result nvm_ownership_array_constructor(const NvmModule *module,uint32_t function,
                                            uint32_t byte_offset,uint32_t *out) {
    if (!module || !out || !module->functions || function>=module->function_count ||
        byte_offset>=module->functions[function].code_length) return NVM_V2_ERR_INDEX_RANGE;
    EffectConstructorQuery query={function,byte_offset,0xFFFFFFFFu};
    NvmV2Result result=ownership_effect_query(module,0xFFFFFFFFu,
# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                    ((void *)0)
# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                        ,
# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                         ((void *)0)
# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                             ,&query);
    if (result==NVM_V2_OK) *out=query.element;
    return result;
}

NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out) {
    if (!module || !out || !module->ownership_data || !module->layout_data)
        return NVM_V2_ERR_INDEX_RANGE;
    
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs=
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
              0
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                   ;
    NvmV2Result result=nvm_ownership_contracts_validate(module,&needs);
    if (result!=NVM_V2_OK) return result;
    NvmV2Layouts layouts={0};
    result=nvm_v2_layouts_decode(module->layout_data,module->layout_size,&layouts);
    if (result!=NVM_V2_OK) return result;
    NvmV2Cursor cursor;
    nvm_v2_cursor_init(&cursor,module->ownership_data,module->ownership_size);
    uint32_t version,count;const uint8_t *ignored,*flags;
    if ((result=nvm_v2_u32(&cursor,&version))!=NVM_V2_OK ||
        version!=3u ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK ||
        (result=nvm_v2_take(&cursor,count,&flags))!=NVM_V2_OK ||
        (result=nvm_v2_align4(&cursor))!=NVM_V2_OK ||
        (result=nvm_v2_u32(&cursor,&count))!=NVM_V2_OK) {
        if (result==NVM_V2_OK) result=NVM_V2_ERR_FORMAT_VERSION;
        goto done_query;
    }
    for (uint32_t i=0;i<count;i++) {
        uint16_t locals,params;
        if ((result=nvm_v2_u16(&cursor,&locals))!=NVM_V2_OK ||
            (result=nvm_v2_u16(&cursor,&params))!=NVM_V2_OK ||
            (result=nvm_v2_take(&cursor,((size_t)locals+1)*8,&ignored))!=NVM_V2_OK)
            goto done_query;
    }
    NvmOwnershipExtensions extensions={0};
    if ((result=extension_suffix_read(&cursor,0xFFFFFFFFu,
# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                             ((void *)0)
# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                 ,0,
# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                    ((void *)0)
# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                        ,&extensions))
        !=NVM_V2_OK) goto done_query;
    if (!extensions.union_variants.data) { result=NVM_V2_ERR_FORMAT_VERSION;goto done_query; }
    NvmV2Cursor unions;nvm_v2_cursor_init(&unions,extensions.union_variants.data,
                                          extensions.union_variants.size);
    NvmUnionVariantFact selected;
    result=union_facts_read(&unions,module,&layouts,flags,union_ordinal,variant,&selected,
# 649 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                                                                                         ((void *)0)
# 649 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                                                                                             );
    if (result==NVM_V2_OK) *out=selected;
done_query:
    nvm_v2_layouts_free(&layouts);
    return result;
}

NvmV2Result nvm_ownership_layout_authority(const NvmModule *module, uint32_t layout,
                                          NvmLayoutAuthority *out) {
    if (!module || !out || layout == 0xFFFFFFFFu) return NVM_V2_ERR_INDEX_RANGE;
    
# 659 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 659 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs;
    NvmV2Result result = nvm_ownership_contracts_validate(module, &needs);
    if (result != NVM_V2_OK) return result;
    NvmLayoutAuthority authority = NVM_LAYOUT_AUTHORITY_UNKNOWN;
    if (module->ownership_size) {
        NvmV2Cursor cursor;
        uint32_t version, count;
        const uint8_t *flags;
        nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
        if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
            (result = nvm_v2_u32(&cursor, &count)) != NVM_V2_OK ||
            (result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK) return result;
        if (layout >= count) return NVM_V2_ERR_INDEX_RANGE;
        if (flags[layout] & 1u)
            authority = flags[layout] & 2u ?
                NVM_LAYOUT_AUTHORITY_RESOURCE : NVM_LAYOUT_AUTHORITY_ORDINARY;
    }
    *out = authority;
    return NVM_V2_OK;
}

NvmV2Result nvm_ownership_layout_authorities(const NvmModule *module, uint32_t count,
                                            NvmLayoutAuthority *out) {
    if (!module || (count && !out)) return NVM_V2_ERR_INDEX_RANGE;
    
# 683 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
   _Bool 
# 683 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
        needs;
    NvmV2Result result = nvm_ownership_contracts_validate(module, &needs);
    if (result != NVM_V2_OK) return result;
    const uint8_t *flags = 
# 686 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 3 4
                          ((void *)0)
# 686 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c"
                              ;
    if (module->ownership_size) {
        NvmV2Cursor cursor;
        uint32_t version, declared_count;
        nvm_v2_cursor_init(&cursor, module->ownership_data, module->ownership_size);
        if ((result = nvm_v2_u32(&cursor, &version)) != NVM_V2_OK ||
            (result = nvm_v2_u32(&cursor, &declared_count)) != NVM_V2_OK) return result;
        if (declared_count != count) return NVM_V2_ERR_INDEX_RANGE;
        if ((result = nvm_v2_take(&cursor, count, &flags)) != NVM_V2_OK) return result;
    }
    for (uint32_t i = 0; i < count; i++)
        out[i] = flags && (flags[i] & 1u) ?
            (flags[i] & 2u ? NVM_LAYOUT_AUTHORITY_RESOURCE :
             NVM_LAYOUT_AUTHORITY_ORDINARY) : NVM_LAYOUT_AUTHORITY_UNKNOWN;
    return NVM_V2_OK;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 1

static NvmOrdinaryArrayResult oaa_result(NvmOrdinaryArrayStatus status) {
    const char *message="I could not establish complete ordinary array declarations.";
    if(status==NVM_OAA_DESCRIBED)message="I copied ordinary array declarations without executable admission.";
    else if(status==NVM_OAA_INVALID)message="I require consistent complete declaration bytes.";
    else if(status==NVM_OAA_LIMIT)message="I reached my bounded declaration budget.";
    else if(status==NVM_OAA_MEMORY)message="I could not allocate my declaration report.";
    return (NvmOrdinaryArrayResult){status,0xFFFFFFFFu,0xFFFFFFFFu,message};
}
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *p) {
    if(!p)return;
    nvm_v2_layouts_free(&p->layouts);free(p->types);free(p->bindings);free(p);
}

# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *p,NvmOrdinaryArrayCounts *out) {
    if(!p||!out)return 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                      0
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                           ;
    *out=(NvmOrdinaryArrayCounts){p->layouts.count,p->type_count,p->binding_count};return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                                         1
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                                             ;
}

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *p,uint32_t i,NvmOrdinaryArrayType *out) {
    if(!p||!out||i>=p->type_count)return 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                        0
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                             ;
    *out=p->types[i];return 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                           1
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                               ;
}

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *p,uint32_t i,NvmOrdinaryArrayBinding *out) {
    if(!p||!out||i>=p->binding_count)return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                           0
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                ;
    *out=p->bindings[i];return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                              1
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                  ;
}


static NvmOrdinaryArrayStatus oaa_preflight(const NvmModule *m,uint32_t *work,
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                             _Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                                  mixed) {
    if(m->layout_size>(16u * 1024u * 1024u) || m->ownership_size>(16u * 1024u * 1024u))return NVM_OAA_LIMIT;
    NvmV2Cursor c;nvm_v2_cursor_init(&c,m->layout_data,m->layout_size);
    uint32_t count,total=0;
    if(nvm_v2_u32(&c,&count)!=NVM_V2_OK)return NVM_OAA_INVALID;
    if(count>256u)return NVM_OAA_LIMIT;
    for(uint32_t i=0;i<count;i++) {
        const uint8_t *h,*fields;
        if(nvm_v2_take(&c,8,&h)!=NVM_V2_OK)return NVM_OAA_INVALID;
        uint16_t n=(uint16_t)((uint16_t)h[2]|((uint16_t)h[3]<<8));
        if(n>65536u -total)return NVM_OAA_LIMIT;
        total+=n;
        if(nvm_v2_take(&c,(size_t)n*12,&fields)!=NVM_V2_OK)return NVM_OAA_INVALID;
    }
    if(c.pos!=c.size)return NVM_OAA_INVALID;
    if(m->function_count && !m->functions)return NVM_OAA_INVALID;


    uint32_t used=total*4u+count*4u;
    uint32_t descriptor_cost=total*3u+count+33u;
    if(m->function_count>(1048576u -used)/descriptor_cost)return NVM_OAA_LIMIT;
    for(uint32_t i=0;i<m->function_count;i++) {
        uint32_t descriptors=(uint32_t)m->functions[i].local_count+1u;
        if(descriptors>(1048576u -used)/descriptor_cost)return NVM_OAA_LIMIT;
        uint32_t cost=descriptors*descriptor_cost;
        if(cost>1048576u -used)return NVM_OAA_LIMIT;
        used+=cost;
    }


    uint32_t union_work=mixed?131072u:65536u;
    if(m->union_count>(1048576u -used)/union_work)return NVM_OAA_LIMIT;
    used+=m->union_count*union_work;*work=used;return NVM_OAA_DESCRIBED;
}
static NvmOrdinaryArrayResult oaa_prepare_map(
        const NvmModule *m,NvmOrdinaryArrayAuthority **out,OwnershipProjection *projection,NvmMapDeclarationPlan *map) {
    if(!m||!out||(!m->layout_data != !m->layout_size)||
       (!m->ownership_data != !m->ownership_size))return oaa_result(NVM_OAA_INVALID);
    if(!m->layout_size || !m->ownership_size)return oaa_result(NVM_OAA_UNKNOWN);
    uint32_t work=0;NvmOrdinaryArrayStatus status=oaa_preflight(m,&work,projection!=
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                                   ((void *)0)
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                                       );
    if(status!=NVM_OAA_DESCRIBED)return oaa_result(status);
    NvmOrdinaryArrayAuthority *p=calloc(1,sizeof *p);
    if(!p)return oaa_result(NVM_OAA_MEMORY);
    p->failure=NVM_OAA_INVALID;p->steps=work;
    
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
   _Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
        allocation_failed=
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                          0
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                               ;
    NvmV2Result r=map?
        nvm_ownership_map_layouts_private_decode_detailed(m->layout_data,m->layout_size,&p->layouts,&allocation_failed):projection?
        nvm_ownership_mixed_layouts_private_decode_detailed(m->layout_data,m->layout_size,&p->layouts,&allocation_failed):
        nvm_ownership_layouts_private_decode(m->layout_data,m->layout_size,&p->layouts);
    if(r!=NVM_V2_OK){status=allocation_failed?NVM_OAA_MEMORY:r==NVM_V2_ERR_TRUNCATED?NVM_OAA_UNKNOWN:NVM_OAA_INVALID;goto fail;}
    uint32_t records=0,enums=0,unions=0;
    for(uint32_t i=0;i<p->layouts.count;i++) {
        const NvmV2Layout *row=&p->layouts.items[i];
        if(row->name_idx!=0xFFFFFFFFu && row->name_idx>=m->string_count){status=NVM_OAA_INVALID;goto fail;}
        records+=row->kind==NVM_V2_LAYOUT_STRUCT;enums+=row->kind==NVM_V2_LAYOUT_ENUM;unions+=row->kind==NVM_V2_LAYOUT_UNION;
        if(row->kind!=NVM_V2_LAYOUT_STRUCT && (!projection || row->kind!=NVM_V2_LAYOUT_UNION))p->unknown=
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                                                        1
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                                                            ;
        for(uint16_t f=0;f<row->field_count;f++) {
            const NvmV2LayoutField *field=&row->fields[f];uint32_t ref=field->nested_idx;
            if(field->name_idx!=0xFFFFFFFFu && field->name_idx>=m->string_count){status=NVM_OAA_INVALID;goto fail;}


            if(field->type_tag==TAG_STRUCT) {
                if(ref>=p->layouts.count || p->layouts.items[ref].kind!=NVM_V2_LAYOUT_STRUCT){status=NVM_OAA_INVALID;goto fail;}
            } else if(field->type_tag==TAG_ENUM && ref!=0xFFFFFFFFu) {
                if(ref>=p->layouts.count || p->layouts.items[ref].kind!=NVM_V2_LAYOUT_ENUM){status=NVM_OAA_INVALID;goto fail;}
            } else if(ref!=0xFFFFFFFFu){status=NVM_OAA_INVALID;goto fail;}
            if(!scalar(field->type_tag) && field->type_tag!=TAG_STRING &&
               field->type_tag!=TAG_STRUCT && field->type_tag!=TAG_ARRAY &&
               !(map && field->type_tag==TAG_HASHMAP))p->unknown=
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                1
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                    ;
        }
    }
    if(records!=m->struct_count || enums!=m->enum_count || unions!=m->union_count){status=NVM_OAA_INVALID;goto fail;}
    
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
   _Bool 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
        needs=
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
              0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                   ;
    r=ownership_validate_owned(m,&p->layouts,&needs,p,projection,map);
    if(r!=NVM_V2_OK){status=p->failure;goto fail;}
    if((needs && !projection) || (projection && projection->ambiguous) || m->import_count || m->module_ref_count || m->service_size || m->service_data ||
       m->passive_size || m->passive_data)p->unknown=
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                    1
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                        ;
    uint32_t arrays=0;
    for(uint32_t i=0;i<p->layouts.count;i++) {
        if(p->flags[i]!=(projection && p->layouts.items[i].kind==NVM_V2_LAYOUT_UNION?0:1u))p->unknown=
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                                                                      1
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                                                                          ;
        for(uint16_t f=0;f<p->layouts.items[i].field_count;f++)
            arrays+=p->layouts.items[i].fields[f].type_tag==TAG_ARRAY;
    }
    if(arrays && !p->binding_count)p->unknown=
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                             1
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                 ;
    if(projection && m->union_count && !projection->view.data)p->unknown=
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                                                        1
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                                                            ;
    if(p->unknown){status=NVM_OAA_UNKNOWN;goto fail;}
    *out=p;return oaa_result(NVM_OAA_DESCRIBED);
fail:
    nvm_ordinary_array_authority_free(p);return oaa_result(status);
}

static NvmOrdinaryArrayResult oaa_prepare(const NvmModule *m,NvmOrdinaryArrayAuthority **out,OwnershipProjection *projection) {
    return oaa_prepare_map(m,out,projection,
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                                           ((void *)0)
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                               );
}

NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(
        const NvmModule *m,NvmOrdinaryArrayAuthority **out) {
    return oaa_prepare(m,out,
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc" 3 4
                            ((void *)0)
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ordinary_array_authority.inc"
                                );
}
# 704 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 1

struct NvmOwnershipDeclarationPlan {
    NvmOrdinaryArrayAuthority *ordinary;
    NvmUnionVariantFact *rows;
    uint32_t unions, count;
    uint32_t starts[256u];
    uint16_t variants[256u];
};
static NvmDeclarationResult declaration_result(NvmDeclarationStatus status) {
    const char *message="I could not establish complete mixed declarations.";
    if(status==NVM_DECL_PREPARED)message="I copied complete declarations without execution authority.";
    else if(status==NVM_DECL_INVALID)message="I require consistent complete declaration bytes.";
    else if(status==NVM_DECL_LIMIT)message="I reached my declaration storage or work bound.";
    else if(status==NVM_DECL_MEMORY)message="I could not allocate my declaration projection.";
    return (NvmDeclarationResult){status,message};
}
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *p) {
    if(!p)return;
    nvm_ordinary_array_authority_free(p->ordinary);free(p->rows);free(p);
}
static NvmDeclarationResult prepare_ownership_declarations_map(
        const NvmModule *m,NvmOwnershipDeclarationPlan **out,NvmMapDeclarationPlan *map) {
    if(!out)return declaration_result(NVM_DECL_INVALID);
    OwnershipProjection projection={0};NvmOrdinaryArrayAuthority *ordinary=
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                                          ((void *)0)
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                              ;
    NvmOrdinaryArrayResult prepared=oaa_prepare_map(m,&ordinary,&projection,map);
    if(prepared.status!=NVM_OAA_DESCRIBED) {
        NvmDeclarationStatus status=prepared.status==NVM_OAA_UNKNOWN?NVM_DECL_UNKNOWN:
            prepared.status==NVM_OAA_LIMIT?NVM_DECL_LIMIT:
            prepared.status==NVM_OAA_MEMORY?NVM_DECL_MEMORY:NVM_DECL_INVALID;
        return declaration_result(status);
    }


    size_t used=sizeof *ordinary+(size_t)ordinary->layouts.count*sizeof(NvmV2Layout);
    for(uint32_t i=0;i<ordinary->layouts.count;i++)
        used+=(size_t)ordinary->layouts.items[i].field_count*sizeof(NvmV2LayoutField);
    used+=(size_t)ordinary->type_count*sizeof(NvmOrdinaryArrayType);
    used+=(size_t)ordinary->binding_count*sizeof(NvmOrdinaryArrayBinding);
    size_t rows=(size_t)projection.count*sizeof(NvmUnionVariantFact);
    if(projection.count>65536u || used>(16u * 1024u * 1024u) || sizeof(NvmOwnershipDeclarationPlan)>(16u * 1024u * 1024u)-used ||
       rows>(16u * 1024u * 1024u)-used-sizeof(NvmOwnershipDeclarationPlan)) {
        nvm_ordinary_array_authority_free(ordinary);return declaration_result(NVM_DECL_LIMIT);
    }
    NvmOwnershipDeclarationPlan *p=calloc(1,sizeof *p);
    if(!p){nvm_ordinary_array_authority_free(ordinary);return declaration_result(NVM_DECL_MEMORY);}
    p->ordinary=ordinary;p->unions=m->union_count;p->count=projection.count;
    if(p->count) {
        p->rows=calloc(p->count,sizeof *p->rows);
        if(!p->rows){nvm_ownership_declarations_free(p);return declaration_result(NVM_DECL_MEMORY);}
        projection.rows=p->rows;projection.capacity=p->count;
        projection.starts=p->starts;projection.variants=p->variants;
        NvmV2Cursor cursor;nvm_v2_cursor_init(&cursor,projection.view.data,projection.view.size);
        NvmV2Result result=union_facts_read(&cursor,m,&ordinary->layouts,ordinary->flags,0xFFFFFFFFu,0,
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                                                                          ((void *)0)
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                                                              ,&projection);
        if(result!=NVM_V2_OK || projection.count!=p->count) {
            nvm_ownership_declarations_free(p);return declaration_result(NVM_DECL_INVALID);
        }
    }
    *out=p;return declaration_result(NVM_DECL_PREPARED);
}
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *m,NvmOwnershipDeclarationPlan **out) {
    return prepare_ownership_declarations_map(m,out,
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                   ((void *)0)
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                       );
}

# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *p,NvmDeclarationCounts *out) {
    if(!p||!out)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                      0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                           ;
    *out=(NvmDeclarationCounts){p->ordinary->layouts.count,p->ordinary->type_count,
        p->ordinary->binding_count,p->unions,p->count};return 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                             1
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                 ;
}

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *p,uint32_t i,NvmDeclarationLayout *out) {
    if(!p||!out||i>=p->ordinary->layouts.count)return 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                     0
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                          ;
    const NvmV2Layout *row=&p->ordinary->layouts.items[i];
    *out=(NvmDeclarationLayout){row->kind,p->ordinary->flags[i],row->field_count,row->name_idx};return 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                                                                      1
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                                                          ;
}

# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out) {
    if(!p||!out||i>=p->ordinary->layouts.count||field>=p->ordinary->layouts.items[i].field_count)return 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                                                                       0
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                                                            ;
    *out=p->ordinary->layouts.items[i].fields[field];return 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                           1
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                               ;
}

# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *p,uint32_t i,NvmOrdinaryArrayType *out) {
    return p && nvm_ordinary_array_authority_type(p->ordinary,i,out);
}

# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out) {
    return p && nvm_ordinary_array_authority_binding(p->ordinary,i,out);
}

# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *p,uint32_t ordinal,uint16_t variant,NvmUnionVariantFact *out) {
    if(!p||!out||ordinal>=p->unions||variant>=p->variants[ordinal])return 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                                         0
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                                              ;
    *out=p->rows[p->starts[ordinal]+variant];return 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc" 3 4
                                                   1
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_declaration_projection.inc"
                                                       ;
}

NvmMapCostStatus nvm_ownership_declarations_retained_cost(const NvmOwnershipDeclarationPlan *p,
                                                       NvmMapCopyWork *w,uint64_t *out) {
    if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
    if(!p || !out || !p->ordinary || p->unions>256 || p->count>65536)return NVM_MAP_COST_INVALID;
    const NvmOrdinaryArrayAuthority *a=p->ordinary;
    if(a->layouts.count>256 || a->type_count>4096 || a->binding_count>65536)return NVM_MAP_COST_INVALID;
    uint64_t bytes=0;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(a),(1),sizeof *(a),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(a->layouts.items),(a->layouts.count),sizeof *(a->layouts.items),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(p->rows),(p->count),sizeof *(p->rows),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(a->types),(a->type_count),sizeof *(a->types),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(a->bindings),(a->binding_count),sizeof *(a->bindings),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    uint32_t fields=0;
    for(uint32_t i=0;i<a->layouts.count;i++) {
        if(!nvm_map_copy_charge(w,8))return NVM_MAP_COST_LIMIT;
        const NvmV2Layout *row=&a->layouts.items[i];
        if(row->field_count>65536u-fields)return NVM_MAP_COST_INVALID;
        fields+=row->field_count;do {status=nvm_map_copy_term(w,(row->fields),(row->field_count),sizeof *(row->fields),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    }

    *out=bytes;return NVM_MAP_COST_OK;
}
# 706 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 1

typedef enum { MAP_ROUTE_ABSENT, MAP_ROUTE_PRESENT, MAP_ROUTE_INVALID, MAP_ROUTE_LIMIT } MapRoute;
static MapRoute map_route(const NvmModule *m,uint64_t *work) {
    if(!m || (!m->layout_data != !m->layout_size) || (!m->ownership_data != !m->ownership_size))return MAP_ROUTE_INVALID;
    if(!m->layout_size && !m->ownership_size)return MAP_ROUTE_ABSENT;
    if(!m->layout_size || !m->ownership_size)return MAP_ROUTE_INVALID;
    if(m->layout_size>(16u * 1024u * 1024u) || m->ownership_size>(16u * 1024u * 1024u))return MAP_ROUTE_LIMIT;
    *work=(uint64_t)m->layout_size+m->ownership_size;
    if(*work>(4u*1024u*1024u))return MAP_ROUTE_LIMIT;
    
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
        field_map=
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                  0
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                       ;NvmV2Cursor c;uint32_t count,total=0;const uint8_t *data;
    nvm_v2_cursor_init(&c,m->layout_data,m->layout_size);
    if(nvm_v2_u32(&c,&count)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
    if(count>256)return MAP_ROUTE_LIMIT;
    for(uint32_t i=0;i<count;i++) {
        if(nvm_v2_take(&c,8,&data)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
        uint16_t fields=(uint16_t)((uint16_t)data[2]|((uint16_t)data[3]<<8));
        if(data[1] || data[0]>NVM_V2_LAYOUT_ENUM)return MAP_ROUTE_INVALID;
        if(fields>65536u-total)return MAP_ROUTE_LIMIT;
        total+=fields;
        for(uint16_t f=0;f<fields;f++) {
            if(nvm_v2_take(&c,12,&data)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
            if(data[0]>=TAG_COUNT || data[1] || data[2] || data[3])return MAP_ROUTE_INVALID;
            field_map|=data[0]==TAG_HASHMAP;
        }
    }
    if(c.pos!=c.size)return MAP_ROUTE_INVALID;
    uint32_t version,layouts,functions;
    nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK || !ownership_version(version) ||
       nvm_v2_u32(&c,&layouts)!=NVM_V2_OK || layouts!=count ||
       nvm_v2_take(&c,layouts,&data)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
    for(uint32_t i=0;i<layouts;i++)if(data[i]&~(1u|2u))return MAP_ROUTE_INVALID;
    if(nvm_v2_align4(&c)!=NVM_V2_OK || nvm_v2_u32(&c,&functions)!=NVM_V2_OK ||
       functions!=m->function_count || (functions && !m->functions))return MAP_ROUTE_INVALID;
    for(uint32_t i=0;i<functions;i++) {
        uint16_t locals,params;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK ||
           locals!=m->functions[i].local_count || params!=m->functions[i].arity || params>locals ||
           nvm_v2_take(&c,((size_t)locals+1)*8,&data)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
        for(uint32_t j=0;j<=(uint32_t)locals;j++)if(data[j*8]>=TAG_COUNT ||
            data[j*8+1]>NVM_REFERENCE_EXCLUSIVE || data[j*8+2] || data[j*8+3])return MAP_ROUTE_INVALID;
    }
    if(version==3) {
        NvmV2Cursor bound=c;uint32_t path_bytes,extensions;
        if(nvm_v2_u32(&bound,&path_bytes)!=NVM_V2_OK ||
           nvm_v2_take(&bound,path_bytes,
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                        ((void *)0)
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                            )!=NVM_V2_OK ||
           nvm_v2_u32(&bound,&extensions)!=NVM_V2_OK)return MAP_ROUTE_INVALID;
        if(extensions>4u)return MAP_ROUTE_LIMIT;
        if(*work>(4u*1024u*1024u) || 8u>(4u*1024u*1024u)-*work)return MAP_ROUTE_LIMIT;
        *work+=8;
    }
    NvmOwnershipExtensionView map={0};NvmOwnershipExtensions other={0};
    NvmV2Result r=NVM_V2_OK;
    if(version==2)r=paths_read(&c,0xFFFFFFFFu,
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                 ((void *)0)
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                     ,0,
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                        ((void *)0)
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                            ,
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                             1
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                                 );
    else if(version==3)r=extension_suffix_read_map(&c,0xFFFFFFFFu,
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                                     ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                                         ,0,
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                                            ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                                                ,&other,&map);
    if(r!=NVM_V2_OK || c.pos!=c.size)return MAP_ROUTE_INVALID;

    return field_map || map.data?MAP_ROUTE_PRESENT:MAP_ROUTE_ABSENT;
}
static NvmMapDeclarationResult map_result(NvmMapDeclarationStatus status) {
    const char *s="I require complete exact map declarations.";
    if(status==NVM_MAP_ABSENT)s="I found no map declaration route.";
    else if(status==NVM_MAP_DESCRIBED)s="I copied exact map declarations without execution authority.";
    else if(status==NVM_MAP_LIMIT)s="I reached my map declaration bound.";
    else if(status==NVM_MAP_MEMORY)s="I could not allocate map declarations.";
    return (NvmMapDeclarationResult){status,s};
}
void nvm_map_declarations_free(NvmMapDeclarationPlan *p) {
    if(!p)return;
    free(p->scalars);free(p->pairs);free(p->bindings);free(p->starts);
    nvm_ownership_declarations_free(p->base);free(p);
}
NvmMapDeclarationResult nvm_prepare_map_declarations(const NvmModule *m,NvmMapDeclarationPlan **out) {
    if(!out)return map_result(NVM_MAP_INVALID);
    uint64_t work=0;MapRoute route=map_route(m,&work);
    if(route!=MAP_ROUTE_PRESENT)return map_result(route==MAP_ROUTE_ABSENT?NVM_MAP_ABSENT:
                                                 route==MAP_ROUTE_LIMIT?NVM_MAP_LIMIT:NVM_MAP_INVALID);
    if(sizeof(NvmMapDeclarationPlan)>(2u*1024u*1024u))return map_result(NVM_MAP_LIMIT);
    NvmMapDeclarationPlan *p=calloc(1,sizeof *p);
    if(!p)return map_result(NVM_MAP_MEMORY);
    p->bytes=sizeof *p;p->work=work;p->failure=NVM_MAP_INVALID;
    NvmDeclarationResult base=prepare_ownership_declarations_map(m,&p->base,p);
    if(base.status!=NVM_DECL_PREPARED) {
        NvmMapDeclarationStatus failure=p->failure;
        if(base.status==NVM_DECL_MEMORY)failure=NVM_MAP_MEMORY;
        else if(base.status==NVM_DECL_LIMIT)failure=NVM_MAP_LIMIT;
        nvm_map_declarations_free(p);return map_result(failure);
    }
    *out=p;return map_result(NVM_MAP_DESCRIBED);
}

# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
    nvm_map_declarations_counts(const NvmMapDeclarationPlan *p,NvmMapDeclarationCounts *out) {
    if(!p||!out)return 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                      0
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                           ;
    *out=p->counts;return 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                         1
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                             ;
}

# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
_Bool 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
    nvm_map_declarations_scalar(const NvmMapDeclarationPlan *p,uint32_t index,uint8_t *out) {
    if(!p||!out||index>=p->counts.scalars)return 
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                0
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                     ;
    *out=p->scalars[index];return 
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                 1
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                     ;
}

# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
_Bool 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
    nvm_map_declarations_pair(const NvmMapDeclarationPlan *p,uint32_t index,NvmMapDeclarationPair *out) {
    if(!p||!out||index>=p->counts.pairs)return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                              0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                   ;
    *out=p->pairs[index];return 
# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                               1
# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                   ;
}

# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
_Bool 
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
    nvm_map_declarations_binding(const NvmMapDeclarationPlan *p,uint32_t index,NvmMapDeclarationBinding *out) {
    if(!p||!out||index>=p->counts.bindings)return 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                 0
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                      ;
    *out=p->bindings[index];return 
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                  1
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                      ;
}

# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
_Bool 
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
    nvm_map_declarations_field(const NvmMapDeclarationPlan *p,uint32_t layout,uint16_t field,NvmMapDeclarationPair *out) {
    if(!p||!out||layout>=p->layouts)return 
# 108 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                          0
# 108 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                               ;
    uint32_t low=p->starts[layout],high=p->starts[layout+1];
    while(low<high) {
        uint32_t mid=low+(high-low)/2;const NvmMapDeclarationBinding *b=&p->bindings[mid];
        if(b->field==field){*out=p->pairs[b->pair];return 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                                                         1
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                                             ;}
        if(b->field<field)low=mid+1;else high=mid;
    }
    return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
          0
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
               ;
}


NvmMapDeclarationResult nvm_prepare_map_declarations_split(const NvmModule *m,
        NvmMapDeclarationPlan **out,NvmOwnershipDeclarationPlan **base) {
    if(!out || !base || (void *)out==(void *)base)return map_result(NVM_MAP_INVALID);
    NvmMapDeclarationPlan *p=
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                            ((void *)0)
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                                ;
    NvmMapDeclarationResult r=nvm_prepare_map_declarations(m,&p);
    if(r.status!=NVM_MAP_DESCRIBED)return r;
    *base=p->base;p->base=
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc" 3 4
                         ((void *)0)
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_map_declarations.inc"
                             ;*out=p;return r;
}

NvmMapCostStatus nvm_map_declarations_retained_cost(const NvmMapDeclarationPlan *p,
                                                 NvmMapCopyWork *w,uint64_t *out) {
    if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
    if(!p || !out || p->base || !p->counts.scalars || p->counts.scalars>5 ||
       !p->counts.pairs || p->counts.pairs>25 || !p->counts.bindings ||
       p->counts.bindings>65536 || p->layouts>256)return NVM_MAP_COST_INVALID;
    uint64_t bytes=0;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->scalars),(p->counts.scalars),sizeof *(p->scalars),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->pairs),(p->counts.pairs),sizeof *(p->pairs),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(p->bindings),(p->counts.bindings),sizeof *(p->bindings),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->starts),(257),sizeof *(p->starts),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);

    *out=bytes;return NVM_MAP_COST_OK;
}
# 708 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_shapes.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h"
typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_shapes.h" 2


typedef struct {
    uint64_t origins;
    uint16_t tags;
    uint8_t unknown;
} NvmRecordValueOrigins;
typedef enum { NVM_HEAP_ORIGIN_ARRAY, NVM_HEAP_ORIGIN_RECORD } NvmHeapOriginKind;
typedef struct {
    uint32_t function, pc;
    uint32_t record_ordinal, layout_index, field_start;
    uint16_t field_count;
    uint8_t kind, declared_tag, packed;
    NvmRecordValueOrigins children;
} NvmRecordHeapOrigin;
typedef struct {
    uint32_t origin_count, field_value_count, checked_field_writes;
    uint32_t checked_array_writes, runtime_tag_checks;
    NvmRecordHeapOrigin origins[64];
    NvmRecordValueOrigins *fields;
} NvmRecordEligibilityReport;



NvmArrayEligibilityResult nvm_analyze_managed_records(
    const NvmModule *module, NvmRecordEligibilityReport **out);
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report);


typedef enum { NVM_MANAGED_LEAF, NVM_MANAGED_ARRAY_GRAPH, NVM_MANAGED_RECORD } NvmManagedHeapMode;
typedef struct {
    NvmManagedHeapMode mode;
    NvmRecordPlan *records;
    NvmRecordEligibilityReport *fields;
} NvmManagedHeapPlan;
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *, int mutable_arrays,
                                                 NvmManagedHeapPlan **out);
void nvm_managed_heap_plan_free(NvmManagedHeapPlan *);
NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *, NvmManagedHeapPlan **);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 2



typedef struct NvmRecordArrayOrigins NvmRecordArrayOrigins;
typedef struct {
    uint32_t origins, fields, checked_field_writes, checked_array_writes, runtime_tag_checks;
    uint64_t work_reserved, peak_bytes_reserved;
} NvmRecordArrayOriginCounts;
NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *,NvmRecordArrayOrigins **);
void nvm_record_array_origins_free(NvmRecordArrayOrigins *);

# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *,NvmRecordArrayOriginCounts *);

# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origin(const NvmRecordArrayOrigins *,uint32_t,NvmRecordHeapOrigin *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *,uint32_t,NvmRecordValueOrigins *);
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
static inline uint16_t nvm_record_array_requirement(uint8_t depth,uint8_t leaf) {
    if(leaf<TAG_INT || leaf>TAG_STRING)return 0;
    if(depth==1)return (uint16_t)(1u<<leaf);
    if(depth==2) {
        switch(leaf) {
        case TAG_INT:return ((uint16_t)(1u << TAG_ARRAY));
        case TAG_U8:return ((uint16_t)(1u << 9));
        case TAG_FLOAT:return ((uint16_t)(1u << 10));
        case TAG_BOOL:return ((uint16_t)(1u << 11));
        case TAG_STRING:return ((uint16_t)(1u << 8));
        }
    }
    if(depth==3)return leaf==TAG_STRING?((uint16_t)(1u << 6)):(uint16_t)(1u<<(11u+leaf));
    return 0;
}
static inline uint8_t nvm_record_array_requirement_depth(uint16_t requirement) {
    for(uint8_t depth=1;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(requirement==nvm_record_array_requirement(depth,leaf))return depth;
    return 0;
}

static inline uint8_t nvm_record_array_requirement_leaf(uint16_t requirement) {
    switch(requirement) {
    case ((uint16_t)(1u << 12)):case ((uint16_t)(1u << TAG_ARRAY)):return TAG_INT;
    case ((uint16_t)(1u << 13)):case ((uint16_t)(1u << 9)):return TAG_U8;
    case ((uint16_t)(1u << 14)):case ((uint16_t)(1u << 10)):return TAG_FLOAT;
    case ((uint16_t)(1u << 15)):case ((uint16_t)(1u << 11)):return TAG_BOOL;
    case ((uint16_t)(1u << 6)):case ((uint16_t)(1u << 8)):return TAG_STRING;
    default:return TAG_VOID;
    }
}

# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *,uint32_t,uint16_t *);

# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *,NvmDeclarationCounts *);

# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *,uint32_t,NvmDeclarationLayout *);

# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmV2LayoutField *);

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayType *);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayBinding *);

# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 2





typedef struct NvmRecordArrayExecutionPlan NvmRecordArrayExecutionPlan;
typedef enum {
    NVM_RA_ROOT_SCALAR, NVM_RA_ROOT_CONSTANT, NVM_RA_ROOT_LOAD,
    NVM_RA_ROOT_STORE, NVM_RA_ROOT_DUP, NVM_RA_ROOT_SWAP, NVM_RA_ROOT_DROP,
    NVM_RA_ROOT_BRANCH, NVM_RA_ROOT_CALL, NVM_RA_ROOT_RETURN,
    NVM_RA_ROOT_STRING, NVM_RA_ROOT_CONSTRUCT, NVM_RA_ROOT_GET,
    NVM_RA_ROOT_SET, NVM_RA_ROOT_ARRAY_PUSH, NVM_RA_ROOT_ARRAY_POP,
    NVM_RA_ROOT_ARRAY_COPY, NVM_RA_ROOT_TAIL
} NvmRecordArrayRootRecipe;
enum {

    NVM_RA_CHECK_TAGS=1u, NVM_RA_CHECK_BOUNDS=2u, NVM_RA_CHECK_NOMINAL=4u,
    NVM_RA_SAFEPOINT_BEFORE=8u, NVM_RA_STAGE_OPERANDS=16u,
    NVM_RA_RETAIN_BEFORE_RELEASE=32u, NVM_RA_FIRST_ERROR_CLEANUP=64u
};
typedef struct {
    uint32_t functions, instructions, globals, initializer, entry, frame_limit;
    uint32_t strings, sections, metadata, debug, records;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordArrayExecutionCounts;
typedef struct {
    NvmFunctionEntry signature;
    uint32_t instruction_start, instruction_count;
    uint16_t maximum_stack;
    uint8_t parameter_tags_present;
} NvmRecordArrayExecutionFunction;



typedef struct {
    uint32_t function, pc, next_pc, successors[2], callee;
    uint16_t pops, pushes, obligations;
    uint8_t opcode, recipe, successor_count, operand_count;
    uint8_t operand_types[4];
    uint64_t operand_bits[4];
} NvmRecordArrayExecutionInstruction;
typedef struct {
    uint32_t ordinal, layout;
    uint16_t fields;
} NvmRecordArrayExecutionDescriptor;
typedef enum {
    NVM_RA_SNAPSHOT_CODE, NVM_RA_SNAPSHOT_LAYOUTS, NVM_RA_SNAPSHOT_OWNERSHIP,
    NVM_RA_SNAPSHOT_STRING
} NvmRecordArraySnapshotKind;
NvmArrayEligibilityResult nvm_prepare_record_array_execution(
    const NvmModule *, NvmRecordArrayExecutionPlan **);
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *);

# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionInstruction *);

# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionDescriptor *);

# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *,NvmHeader *);

# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *,uint32_t,NvmSectionEntry *);

# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *,uint32_t,NvmMetadataEntry *);

# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDebugEntry *);

# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayOriginCounts *);

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordHeapOrigin *);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t *);

# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *,NvmDeclarationCounts *);

# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayType *);

# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
typedef struct NvmRecordMapFrozenContext NvmRecordMapFrozenContext;
typedef struct {
    uint32_t origins,map_origins,fields,checked_map_operations;
    uint64_t peak_bytes_reserved,work_reserved;
} NvmRecordMapCounts;
NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *,NvmRecordMapFrozenContext **);
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *,NvmRecordMapCounts *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *,uint32_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordHeapOrigin *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordValueOrigins *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 2


typedef struct NvmRecordMapExecutionPlan NvmRecordMapExecutionPlan;
typedef enum { NVM_RM_NONE, NVM_RM_NEW, NVM_RM_SET, NVM_RM_GET,
               NVM_RM_HAS, NVM_RM_LEN, NVM_RM_DELETE } NvmRecordMapOperation;
typedef struct {
    NvmRecordArrayExecutionCounts carrier;
    NvmRecordMapCounts maps;
} NvmRecordMapExecutionCounts;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    uint16_t key_tags,value_tags,result_tags;
    uint8_t map_operation;
} NvmRecordMapExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *,NvmRecordMapExecutionPlan **);




# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *,uint8_t *);
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *,NvmRecordMapExecutionCounts *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *,uint32_t,NvmRecordMapExecutionInstruction *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *,uint32_t,uint8_t *,uint8_t *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h" 2





typedef enum { NVM_RECORD_MAP_ABSENT, NVM_RECORD_MAP_PRESENT,
    NVM_RECORD_MAP_INVALID, NVM_RECORD_MAP_LIMIT, NVM_RECORD_MAP_DEFER } NvmRecordMapRoute;
NvmRecordMapRoute nvm_record_map_route(const NvmModule *);


# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h"
    nvm_record_map_wire_selected(const NvmV2Module *);
static inline 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_admission.h"
                  nvm_record_map_selected(NvmRecordMapRoute r) {
    return r==NVM_RECORD_MAP_PRESENT || r==NVM_RECORD_MAP_INVALID || r==NVM_RECORD_MAP_LIMIT;
}


NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *,NvmRecordMapExecutionPlan **);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 2



static 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
      _Bool 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
           map_public_layout_scan(const NvmModule *m,
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                     _Bool 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                          *found,uint32_t *layouts) {
    NvmV2Cursor c;const uint8_t *h,*f;uint32_t count;
    if(!m->layout_data)return !m->layout_size;
    size_t size=m->layout_size>(16u * 1024u * 1024u)?(16u * 1024u * 1024u):m->layout_size;
    nvm_v2_cursor_init(&c,m->layout_data,size);
    if(nvm_v2_u32(&c,&count)!=NVM_V2_OK)return 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                              0
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                   ;
    *layouts=count;
    
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        valid=
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
              1
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                  ;
    for(uint32_t i=0;i<count;i++) {
        if(nvm_v2_take(&c,8,&h)!=NVM_V2_OK)return 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                 0
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                      ;
        if(h[1] || h[0]>NVM_V2_LAYOUT_ENUM)valid=
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                    0
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                         ;
        uint16_t fields=(uint16_t)((uint16_t)h[2]|((uint16_t)h[3]<<8));
        for(uint16_t j=0;j<fields;j++) {
            if(nvm_v2_take(&c,12,&f)!=NVM_V2_OK)return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                      0
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                           ;
            if(f[0]==TAG_HASHMAP)*found=
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                       1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                           ;
            if(f[0]>=TAG_COUNT || f[1] || f[2] || f[3])valid=
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                            0
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                 ;
        }
    }
    return valid && c.pos==c.size;
}
static 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
      _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
           map_public_ownership_scan(const NvmModule *m,
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                        _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                             *found,uint32_t layouts) {
    NvmV2Cursor c;uint32_t version,count,functions;const uint8_t *flags;
    if(!m->ownership_data)return !m->ownership_size;
    size_t size=m->ownership_size>(16u * 1024u * 1024u)?(16u * 1024u * 1024u):m->ownership_size;
    nvm_v2_cursor_init(&c,m->ownership_data,size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK || nvm_v2_u32(&c,&count)!=NVM_V2_OK ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK)return 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                     0
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                          ;
    
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        valid=ownership_version(version) && count==layouts;
    for(uint32_t i=0;i<count;i++)if(flags[i]&~(1u|2u))valid=
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                                             0
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                                                  ;
    if(nvm_v2_align4(&c)!=NVM_V2_OK || nvm_v2_u32(&c,&functions)!=NVM_V2_OK)return 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                                  0
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                                       ;
    for(uint32_t i=0;i<functions;i++) {
        uint16_t locals,params;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK ||
           nvm_v2_take(&c,((size_t)locals+1)*8,
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                              ((void *)0)
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                  )!=NVM_V2_OK)return 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                      0
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                           ;
        if(params>locals)valid=
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                              0
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                   ;
    }
    if(version==3) {


        NvmV2Cursor probe=c;uint32_t paths,extensions;
        if(nvm_v2_u32(&probe,&paths)!=NVM_V2_OK || nvm_v2_take(&probe,paths,
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                           ((void *)0)
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                               )!=NVM_V2_OK ||
           nvm_v2_u32(&probe,&extensions)!=NVM_V2_OK)return 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                           0
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                ;
        for(uint32_t i=0;i<extensions;i++) {
            uint16_t kind,revision;uint32_t bytes;
            if(nvm_v2_u16(&probe,&kind)!=NVM_V2_OK)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                         0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                              ;
            if(kind==5u)*found=
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                              1
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                  ;
            if(nvm_v2_u16(&probe,&revision)!=NVM_V2_OK || nvm_v2_u32(&probe,&bytes)!=NVM_V2_OK ||
               nvm_v2_take(&probe,bytes,
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                       ((void *)0)
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                           )!=NVM_V2_OK || nvm_v2_align4(&probe)!=NVM_V2_OK)return 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                                                   0
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                                                        ;
        }
        NvmOwnershipExtensions other={0};NvmOwnershipExtensionView map={0};
        if(extension_suffix_read_map(&c,0xFFFFFFFFu,
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                       ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                           ,0,
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                              ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                  ,&other,&map)!=NVM_V2_OK)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                                                  0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                                                       ;
    } else if(version==2 && paths_read(&c,0xFFFFFFFFu,
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                         ((void *)0)
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                             ,0,
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                ((void *)0)
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                    ,
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                     1
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                         )!=NVM_V2_OK)return 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                                                             0
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                                                                  ;
    return valid && c.pos==c.size;
}
NvmRecordMapRoute nvm_record_map_route(const NvmModule *m) {
    if(!m)return NVM_RECORD_MAP_DEFER;
    if(!m->layout_data && !m->layout_size && !m->ownership_data && !m->ownership_size)return NVM_RECORD_MAP_ABSENT;
    
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        found=
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
              0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                   ;uint32_t layouts=0;
    
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        layout_ok=map_public_layout_scan(m,&found,&layouts);
    
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        ownership_ok=map_public_ownership_scan(m,&found,layouts);
    if(!found)return layout_ok && ownership_ok?NVM_RECORD_MAP_ABSENT:NVM_RECORD_MAP_DEFER;
    if(m->layout_size>(16u * 1024u * 1024u) || m->ownership_size>(16u * 1024u * 1024u))return NVM_RECORD_MAP_LIMIT;
    if(!m->layout_data || !m->layout_size || !m->ownership_data || !m->ownership_size ||
       !layout_ok || !ownership_ok)return NVM_RECORD_MAP_INVALID;
    return NVM_RECORD_MAP_PRESENT;
}


# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
    nvm_record_map_wire_selected(const NvmV2Module *m) {
    if(!m)return 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                0
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                     ;
    NvmModule framed={0};framed.ownership_data=(uint8_t *)m->ownership_data;
    framed.ownership_size=m->ownership_size;
    
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
   _Bool 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
        found=
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
              0
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                   ;
    (void)map_public_ownership_scan(&framed,&found,m->layouts.count);
    if(found)return 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                   1
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                       ;
    if(!m->layouts.items)return 
# 79 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                               0
# 79 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                    ;
    uint64_t work=0;
    for(uint32_t i=0;i<m->layouts.count;i++) {
        if(++work>(16u * 1024u * 1024u))return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                  0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                       ;
        const NvmV2Layout *l=&m->layouts.items[i];
        if(!l->fields && l->field_count)return 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                              0
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                   ;
        for(uint16_t j=0;j<l->field_count;j++) {
            if(++work>(16u * 1024u * 1024u))return 
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                      0
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                           ;
            if(l->fields[j].type_tag==TAG_HASHMAP)return 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
                                                        1
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
                                                            ;
        }
    }
    return 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc" 3 4
          0
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/record_map_route.inc"
               ;
}
# 709 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h" 1
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h"
typedef struct NvmUnionFieldDeclarations NvmUnionFieldDeclarations;
typedef enum { NVM_UFD_PREPARED, NVM_UFD_UNKNOWN, NVM_UFD_INVALID,
               NVM_UFD_LIMIT, NVM_UFD_MEMORY } NvmUnionFieldDeclarationStatus;
typedef struct {
    NvmUnionFieldDeclarationStatus status;
    const char *message;
    uint64_t bytes_reserved, work_reserved;
} NvmUnionFieldDeclarationResult;
NvmUnionFieldDeclarationResult nvm_union_field_declarations_prepare(const NvmModule *,NvmUnionFieldDeclarations **);
void nvm_union_field_declarations_free(NvmUnionFieldDeclarations *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_layout(const NvmUnionFieldDeclarations *,uint32_t,NvmDeclarationLayout *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_field(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmV2LayoutField *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_variant(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_nominal(const NvmUnionFieldDeclarations *,uint8_t,uint32_t,uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 2
struct NvmUnionFieldDeclarations {
    NvmV2Layouts layouts;
    NvmUnionVariantFact variants[2];
    uint8_t flags[2];
    uint16_t record_layout, union_layout, payload_variant, empty_variant;
};
static NvmUnionFieldDeclarationResult ufd_result(NvmUnionFieldDeclarationStatus s,uint64_t b,uint64_t w) {
    const char *message="I require consistent union declaration bytes.";
    if(s==NVM_UFD_PREPARED)message="I copied union declarations without execution authority.";
    else if(s==NVM_UFD_UNKNOWN)message="I could not establish the supported union declarations.";
    else if(s==NVM_UFD_LIMIT)message="I reached the union declaration bound.";
    else if(s==NVM_UFD_MEMORY)message="I could not allocate union declarations.";
    return (NvmUnionFieldDeclarationResult){s,message,b,w};
}
void nvm_union_field_declarations_free(NvmUnionFieldDeclarations *p) {
    if(!p)return;
    nvm_v2_layouts_free(&p->layouts);free(p);
}


static NvmUnionFieldDeclarationResult ufd_prepare_reserved(const NvmModule *m,
        NvmUnionFieldDeclarations **out,uint64_t extra_bytes,uint64_t extra_work) {
    uint64_t work=64,bytes=0;
    if(extra_work>1048576u -work || extra_bytes>(16u * 1024u * 1024u))
        return ufd_result(NVM_UFD_LIMIT,bytes,work);
    work+=extra_work;bytes=extra_bytes;
    if(!m||!out || (!m->layout_data != !m->layout_size) ||
       (!m->ownership_data != !m->ownership_size))return ufd_result(NVM_UFD_INVALID,bytes,work);
    if(!m->layout_size || !m->ownership_size)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    if(m->layout_size>(16u * 1024u * 1024u) || m->ownership_size>(16u * 1024u * 1024u) || m->function_count>256)
        return ufd_result(NVM_UFD_LIMIT,bytes,work);
    if(m->function_count && !m->functions)return ufd_result(NVM_UFD_INVALID,bytes,work);
    uint64_t source=(uint64_t)m->layout_size+m->ownership_size;

    if(source>1048576u -work)return ufd_result(NVM_UFD_LIMIT,bytes,work);
    work+=source;
    NvmV2Cursor c;nvm_v2_cursor_init(&c,m->layout_data,m->layout_size);
    uint32_t n;const uint8_t *row;

    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=2 || m->struct_count!=1 || m->union_count!=1 || m->enum_count)
        return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    for(uint32_t i=0;i<2;i++) {
        do { if((nvm_v2_take(&c,8,&row))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
        uint16_t fields=(uint16_t)(row[2]|((uint16_t)row[3]<<8));
        if(fields!=1)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
        if(row[0]!=(i?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION))
            return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
        do { if((nvm_v2_take(&c,12,&row))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
        uint32_t ref=(uint32_t)row[4]|((uint32_t)row[5]<<8)|((uint32_t)row[6]<<16)|((uint32_t)row[7]<<24);
        if(row[0]!=(i?TAG_UNION:TAG_INT) || ref!=(i?0:0xFFFFFFFFu))
            return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    }
    if(c.pos!=c.size)return ufd_result(NVM_UFD_INVALID,bytes,work);
    nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=3)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=2)return ufd_result(NVM_UFD_INVALID,bytes,work);
    do { if((nvm_v2_take(&c,2,&row))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    uint8_t flags[2]={row[0],row[1]};
    if(flags[0]!=1u || flags[1]!=1u)
        return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_align4(&c))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=m->function_count)return ufd_result(NVM_UFD_INVALID,bytes,work);
    uint64_t descriptors=0;
    for(uint32_t i=0;i<n;i++) {
        uint16_t locals,params;
        do { if((nvm_v2_u16(&c,&locals))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);do { if((nvm_v2_u16(&c,&params))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
        if(locals>256)return ufd_result(NVM_UFD_LIMIT,bytes,work);
        if(locals!=m->functions[i].local_count || params!=m->functions[i].arity || params>locals)
            return ufd_result(NVM_UFD_INVALID,bytes,work);
        descriptors+=(uint32_t)locals+1;
        for(uint32_t d=0;d<=(uint32_t)locals;d++) {
            do { if((nvm_v2_take(&c,8,&row))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
            if(row[1])return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
        }
    }
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=4)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=1)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    uint16_t kind,revision;
    do { if((nvm_v2_u16(&c,&kind))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);do { if((nvm_v2_u16(&c,&revision))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(kind!=1 || revision!=1)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_u32(&c,&n))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(n!=28)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    do { if((nvm_v2_take(&c,28,&row))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(c.pos!=c.size)return ufd_result(NVM_UFD_INVALID,bytes,work);
    NvmV2Cursor u;nvm_v2_cursor_init(&u,row,28);
    uint32_t unions,layout;uint16_t variants,reserved;
    do { if((nvm_v2_u32(&u,&unions))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);do { if((nvm_v2_u32(&u,&layout))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    do { if((nvm_v2_u16(&u,&variants))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);do { if((nvm_v2_u16(&u,&reserved))!=NVM_V2_OK)return ufd_result(NVM_UFD_INVALID,bytes,work); } while(0);
    if(unions!=1 || layout!=0 || variants!=2 || reserved)
        return ufd_result(NVM_UFD_INVALID,bytes,work);

    if(m->import_count || m->module_ref_count || m->service_size || m->service_data ||
       m->passive_size || m->passive_data)return ufd_result(NVM_UFD_UNKNOWN,bytes,work);
    uint64_t more=4*source+32*descriptors+128*2+64*2;
    if(more>1048576u -work)return ufd_result(NVM_UFD_LIMIT,bytes,work);
    work+=more;
    uint64_t payload=sizeof(NvmUnionFieldDeclarations)+2*sizeof(NvmV2Layout)+2*sizeof(NvmV2LayoutField);
    if(payload>(16u * 1024u * 1024u)-bytes)return ufd_result(NVM_UFD_LIMIT,bytes,work);
    bytes+=payload;
    NvmUnionFieldDeclarations *p=calloc(1,sizeof *p);
    if(!p)return ufd_result(NVM_UFD_MEMORY,bytes,work);
    
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
   _Bool 
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
        oom=
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
            0
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                 ;
    NvmV2Result decoded=nvm_ownership_mixed_layouts_private_decode_detailed(
        m->layout_data,m->layout_size,&p->layouts,&oom);
    NvmUnionFieldDeclarationStatus status=NVM_UFD_INVALID;
    if(decoded!=NVM_V2_OK){if(oom)status=NVM_UFD_MEMORY;goto fail;}

    if(p->layouts.count!=2 || p->layouts.items[0].kind!=NVM_V2_LAYOUT_UNION ||
       p->layouts.items[1].kind!=NVM_V2_LAYOUT_STRUCT)goto fail;
    for(uint32_t i=0;i<2;i++) {
        const NvmV2Layout *l=&p->layouts.items[i];
        if(l->field_count!=1 || l->name_idx>=m->string_count || l->fields[0].name_idx>=m->string_count)goto fail;
        const NvmV2LayoutField *f=&l->fields[0];
        if(f->type_tag!=(i?TAG_UNION:TAG_INT) || f->nested_idx!=(i?0:0xFFFFFFFFu))goto fail;
    }
    OwnershipProjection projection={0};
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                      _Bool 
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                           needs=
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                 0
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                      ;
    if(ownership_validate_owned(m,&p->layouts,&needs,
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                    ((void *)0)
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                        ,&projection,
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                                     ((void *)0)
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                                         )!=NVM_V2_OK ||
       projection.ambiguous || projection.count!=2 || !projection.view.data)goto fail;
    uint32_t starts[1]={0};uint16_t counts[1]={0};
    projection.rows=p->variants;projection.capacity=2;projection.starts=starts;projection.variants=counts;
    nvm_v2_cursor_init(&u,projection.view.data,projection.view.size);
    if(union_facts_read(&u,m,&p->layouts,flags,0xFFFFFFFFu,0,
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                                ((void *)0)
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                                    ,&projection)!=NVM_V2_OK ||
       projection.ambiguous || projection.count!=2 || starts[0] || counts[0]!=2)goto fail;
    if(p->variants[0].field_count+p->variants[1].field_count!=1)goto fail;
    p->payload_variant=p->variants[0].field_count?0:1;
    p->empty_variant=(uint16_t)(1-p->payload_variant);
    p->record_layout=1;p->union_layout=0;p->flags[0]=flags[0];p->flags[1]=flags[1];
    *out=p;return ufd_result(NVM_UFD_PREPARED,bytes,work);
fail:
    nvm_union_field_declarations_free(p);return ufd_result(status,bytes,work);
}
NvmUnionFieldDeclarationResult nvm_union_field_declarations_prepare(const NvmModule *m,NvmUnionFieldDeclarations **out) {
    return ufd_prepare_reserved(m,out,0,0);
}

# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
_Bool 
# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
    nvm_union_field_declarations_layout(const NvmUnionFieldDeclarations *p,uint32_t i,NvmDeclarationLayout *out) {
    if(!p||!out||i>=2)return 
# 144 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                            0
# 144 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                 ;
    const NvmV2Layout *l=&p->layouts.items[i];
    *out=(NvmDeclarationLayout){l->kind,p->flags[i],l->field_count,l->name_idx};return 
# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                                                      1
# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                                                          ;
}

# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
_Bool 
# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
    nvm_union_field_declarations_field(const NvmUnionFieldDeclarations *p,uint32_t i,uint16_t f,NvmV2LayoutField *out) {
    if(!p||!out||i>=2||f)return 
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                               0
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                    ;
    *out=p->layouts.items[i].fields[0];return 
# 150 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                             1
# 150 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                 ;
}

# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
_Bool 
# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
    nvm_union_field_declarations_variant(const NvmUnionFieldDeclarations *p,uint32_t ordinal,uint16_t v,NvmUnionVariantFact *out) {
    if(!p||!out||ordinal||v>=2)return 
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                     0
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                          ;
    *out=p->variants[v];return 
# 154 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                              1
# 154 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                  ;
}

# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
_Bool 
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
    nvm_union_field_declarations_nominal(const NvmUnionFieldDeclarations *p,uint8_t tag,uint32_t ordinal,uint32_t *out) {
    if(!p||!out||ordinal||(tag!=TAG_STRUCT&&tag!=TAG_UNION))return 
# 157 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                                  0
# 157 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                                       ;
    *out=tag==TAG_STRUCT?p->record_layout:p->union_layout;return 
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 3 4
                                                                1
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc"
                                                                    ;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h"
static inline 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h" 3 4
             _Bool 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h"
                  ufc_outputs_disjoint(const NvmMapCopyWork *w,const uint64_t *out) {
    if(!w || !out)return 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h" 3 4
                        0
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/union_field_cost_private.h"
                             ;
    uintptr_t a=(uintptr_t)w,b=(uintptr_t)out;
    return a>b ? a-b>=sizeof *out : b-a>=sizeof *w;
}
NvmMapCostStatus nvm_union_declarations_retained_cost(
    const NvmUnionFieldDeclarations *,NvmMapCopyWork *,uint64_t *);
# 162 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_union_fields_private.inc" 2
NvmMapCostStatus nvm_union_declarations_retained_cost(const NvmUnionFieldDeclarations *p,
                                                    NvmMapCopyWork *w,uint64_t *out) {
    if(!ufc_outputs_disjoint(w,out))return NVM_MAP_COST_INVALID;
    if(!nvm_map_copy_charge(w,32))return NVM_MAP_COST_LIMIT;
    if(!p || p->layouts.count!=2 || !p->layouts.items || p->record_layout!=1 || p->union_layout ||
       p->payload_variant>1 || p->empty_variant!=(uint16_t)(1-p->payload_variant) ||
       p->flags[0]!=1u || p->flags[1]!=1u ||
       p->variants[p->payload_variant].field_count!=1 || p->variants[p->empty_variant].field_count ||
       p->variants[0].layout || p->variants[1].layout || p->variants[0].field_offset ||
       p->variants[1].field_offset!=p->variants[0].field_count)
        return NVM_MAP_COST_INVALID;
    uint64_t bytes=0;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->layouts.items),(2),sizeof *(p->layouts.items),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    for(uint32_t i=0;i<2;i++) {
        if(!nvm_map_copy_charge(w,8))return NVM_MAP_COST_LIMIT;
        const NvmV2Layout *l=&p->layouts.items[i];
        if(l->kind!=(i?NVM_V2_LAYOUT_STRUCT:NVM_V2_LAYOUT_UNION) || l->field_count!=1)
            return NVM_MAP_COST_INVALID;
        do {status=nvm_map_copy_term(w,(l->fields),(1),sizeof *(l->fields),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
        if(l->fields[0].type_tag!=(i?TAG_UNION:TAG_INT) ||
           l->fields[0].nested_idx!=(i?0:0xFFFFFFFFu))return NVM_MAP_COST_INVALID;
    }

    *out=bytes;return NVM_MAP_COST_OK;
}
# 711 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.c" 2
