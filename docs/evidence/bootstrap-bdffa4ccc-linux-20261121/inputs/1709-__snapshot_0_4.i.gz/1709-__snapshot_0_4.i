# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding.h"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding.h"
typedef enum {
    NL_BINDING_OK, NL_BINDING_INVALID, NL_BINDING_LIMIT,
    NL_BINDING_MEMORY, NL_BINDING_UNRESOLVED,
    NL_BINDING_IO, NL_BINDING_EXISTS, NL_BINDING_UNSUPPORTED
} NlBindingStatus;
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h" 2

typedef struct NlSocketBindingPlan NlSocketBindingPlan;
typedef NlBindingStatus NlSocketBindingStatus;
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h"
NlSocketBindingStatus nl_socket_binding_prepare(const unsigned char *bytes,
                                          size_t size, NlSocketBindingPlan **out);
void nl_socket_binding_free(NlSocketBindingPlan *plan);

const unsigned char *nl_socket_binding_interface_bytes(const NlSocketBindingPlan *, size_t *size);
const unsigned char *nl_socket_binding_source_bytes(const NlSocketBindingPlan *, size_t *size);
size_t nl_socket_binding_storage_size(const NlSocketBindingPlan *);
size_t nl_socket_binding_peak_bound(const NlSocketBindingPlan *);




# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.h"
    nl_socket_binding_allocation_bound(size_t *out);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_service_catalog.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_service_catalog.h" 2



# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_service_catalog.h"
typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_plan.h" 2




typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_socket_plan_free(NlSocketPlan *);
size_t nl_socket_plan_storage_size(void);
const char *nl_socket_plan_interface(const NlSocketPlan *);
size_t nl_socket_plan_method_count(const NlSocketPlan *);
size_t nl_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_socket_catalog_interface(void);
const NlServicePlanMethod *nl_socket_catalog_method(size_t);
const NlServicePlanType *nl_socket_catalog_type(size_t);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c"
static NlBindingStatus binding_catalog_validate(const NlNsi *nsi) {
    NlSocketPlan *catalog = 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c" 3 4
                           ((void *)0)
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c"
                               ;
    NlSocketPlanStatus status = nl_socket_plan_build(nsi, &catalog);
    nl_socket_plan_free(catalog);
    return status == NL_SOCKET_PLAN_OK ? NL_BINDING_OK :
           status == NL_SOCKET_PLAN_MEMORY ? NL_BINDING_MEMORY : NL_BINDING_INVALID;
}
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 1




# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_internal.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h" 1
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h" 2
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h"
typedef struct cJSON
{

    struct cJSON *next;
    struct cJSON *prev;

    struct cJSON *child;


    int type;


    char *valuestring;

    int valueint;

    double valuedouble;


    char *string;
} cJSON;

typedef struct cJSON_Hooks
{

      void *( *malloc_fn)(size_t sz);
      void ( *free_fn)(void *ptr);
} cJSON_Hooks;

typedef int cJSON_bool;
# 147 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h"
const char* cJSON_Version(void);


void cJSON_InitHooks(cJSON_Hooks* hooks);



cJSON * cJSON_Parse(const char *value);
cJSON * cJSON_ParseWithLength(const char *value, size_t buffer_length);


cJSON * cJSON_ParseWithOpts(const char *value, const char **return_parse_end, cJSON_bool require_null_terminated);
cJSON * cJSON_ParseWithLengthOpts(const char *value, size_t buffer_length, const char **return_parse_end, cJSON_bool require_null_terminated);


char * cJSON_Print(const cJSON *item);

char * cJSON_PrintUnformatted(const cJSON *item);

char * cJSON_PrintBuffered(const cJSON *item, int prebuffer, cJSON_bool fmt);


cJSON_bool cJSON_PrintPreallocated(cJSON *item, char *buffer, const int length, const cJSON_bool format);

void cJSON_Delete(cJSON *item);


int cJSON_GetArraySize(const cJSON *array);

cJSON * cJSON_GetArrayItem(const cJSON *array, int index);

cJSON * cJSON_GetObjectItem(const cJSON * const object, const char * const string);
cJSON * cJSON_GetObjectItemCaseSensitive(const cJSON * const object, const char * const string);
cJSON_bool cJSON_HasObjectItem(const cJSON *object, const char *string);

const char * cJSON_GetErrorPtr(void);


char * cJSON_GetStringValue(const cJSON * const item);
double cJSON_GetNumberValue(const cJSON * const item);


cJSON_bool cJSON_IsInvalid(const cJSON * const item);
cJSON_bool cJSON_IsFalse(const cJSON * const item);
cJSON_bool cJSON_IsTrue(const cJSON * const item);
cJSON_bool cJSON_IsBool(const cJSON * const item);
cJSON_bool cJSON_IsNull(const cJSON * const item);
cJSON_bool cJSON_IsNumber(const cJSON * const item);
cJSON_bool cJSON_IsString(const cJSON * const item);
cJSON_bool cJSON_IsArray(const cJSON * const item);
cJSON_bool cJSON_IsObject(const cJSON * const item);
cJSON_bool cJSON_IsRaw(const cJSON * const item);


cJSON * cJSON_CreateNull(void);
cJSON * cJSON_CreateTrue(void);
cJSON * cJSON_CreateFalse(void);
cJSON * cJSON_CreateBool(cJSON_bool boolean);
cJSON * cJSON_CreateNumber(double num);
cJSON * cJSON_CreateString(const char *string);

cJSON * cJSON_CreateRaw(const char *raw);
cJSON * cJSON_CreateArray(void);
cJSON * cJSON_CreateObject(void);



cJSON * cJSON_CreateStringReference(const char *string);


cJSON * cJSON_CreateObjectReference(const cJSON *child);
cJSON * cJSON_CreateArrayReference(const cJSON *child);



cJSON * cJSON_CreateIntArray(const int *numbers, int count);
cJSON * cJSON_CreateFloatArray(const float *numbers, int count);
cJSON * cJSON_CreateDoubleArray(const double *numbers, int count);
cJSON * cJSON_CreateStringArray(const char *const *strings, int count);


cJSON_bool cJSON_AddItemToArray(cJSON *array, cJSON *item);
cJSON_bool cJSON_AddItemToObject(cJSON *object, const char *string, cJSON *item);



cJSON_bool cJSON_AddItemToObjectCS(cJSON *object, const char *string, cJSON *item);

cJSON_bool cJSON_AddItemReferenceToArray(cJSON *array, cJSON *item);
cJSON_bool cJSON_AddItemReferenceToObject(cJSON *object, const char *string, cJSON *item);


cJSON * cJSON_DetachItemViaPointer(cJSON *parent, cJSON * const item);
cJSON * cJSON_DetachItemFromArray(cJSON *array, int which);
void cJSON_DeleteItemFromArray(cJSON *array, int which);
cJSON * cJSON_DetachItemFromObject(cJSON *object, const char *string);
cJSON * cJSON_DetachItemFromObjectCaseSensitive(cJSON *object, const char *string);
void cJSON_DeleteItemFromObject(cJSON *object, const char *string);
void cJSON_DeleteItemFromObjectCaseSensitive(cJSON *object, const char *string);


cJSON_bool cJSON_InsertItemInArray(cJSON *array, int which, cJSON *newitem);
cJSON_bool cJSON_ReplaceItemViaPointer(cJSON * const parent, cJSON * const item, cJSON * replacement);
cJSON_bool cJSON_ReplaceItemInArray(cJSON *array, int which, cJSON *newitem);
cJSON_bool cJSON_ReplaceItemInObject(cJSON *object,const char *string,cJSON *newitem);
cJSON_bool cJSON_ReplaceItemInObjectCaseSensitive(cJSON *object,const char *string,cJSON *newitem);


cJSON * cJSON_Duplicate(const cJSON *item, cJSON_bool recurse);





cJSON_bool cJSON_Compare(const cJSON * const a, const cJSON * const b, const cJSON_bool case_sensitive);




void cJSON_Minify(char *json);



cJSON* cJSON_AddNullToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddTrueToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddFalseToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddBoolToObject(cJSON * const object, const char * const name, const cJSON_bool boolean);
cJSON* cJSON_AddNumberToObject(cJSON * const object, const char * const name, const double number);
cJSON* cJSON_AddStringToObject(cJSON * const object, const char * const name, const char * const string);
cJSON* cJSON_AddRawToObject(cJSON * const object, const char * const name, const char * const raw);
cJSON* cJSON_AddObjectToObject(cJSON * const object, const char * const name);
cJSON* cJSON_AddArrayToObject(cJSON * const object, const char * const name);




double cJSON_SetNumberHelper(cJSON *object, double number);


char* cJSON_SetValuestring(cJSON *object, const char *valuestring);
# 299 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/cJSON.h"
void * cJSON_malloc(size_t size);
void cJSON_free(void *object);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_internal.h" 2



NlNsi *nl_nsi_decode_object(cJSON *json);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h" 2







# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h" 3 4
_Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h"
    nl_utf8_validate(const char *data, size_t n, size_t *error_offset);



# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/utf8.h"
    nl_utf8_ok_cstr(const char *s);



const char *nl_utf8_cstr_or_marker(const char *s);


int nl_ascii_isspace(int c);
int nl_ascii_isdigit(int c);
int nl_ascii_isalpha(int c);
int nl_ascii_isalnum(int c);
int nl_ascii_isupper(int c);
int nl_ascii_islower(int c);
int nl_ascii_isprint(int c);
int nl_ascii_toupper(int c);
int nl_ascii_tolower(int c);




void nl_utf8_sanitize_log(const char *s, char *out, size_t out_n);
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 2

# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 153 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));



# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 552 "/usr/include/string.h" 3 4

# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 2


# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
struct NlSocketBindingPlan {
    size_t interface_size, source_size, storage_size, peak_bound;
    unsigned char bytes[];
};

typedef struct {
    const unsigned char *bytes;
    size_t size, pos, tokens, objects;
    NlBindingStatus status;
} BindingScan;

static 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_add(size_t *total, size_t n) {
    if (n > 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
           (18446744073709551615UL) 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                    - *total) return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                     0
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                          ;
    *total += n;
    return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          1
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
              ;
}
static 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_product(size_t *total, size_t n, size_t width) {
    return (!n || width <= 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                          (18446744073709551615UL) 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                   / n) && fb_add(total, n * width);
}

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
    nl_socket_binding_allocation_bound(size_t *out) {
    size_t total = sizeof(NlSocketBindingPlan);
    size_t elements = 0;
    if (!out || !fb_add(&elements, sizeof(NlNsiNamed)) ||
        !fb_add(&elements, sizeof(NlNsiParam)) || !fb_add(&elements, sizeof(NlNsiMethod)) ||
        !fb_add(&elements, sizeof(NlNsiMember)) || !fb_add(&elements, sizeof(NlNsiType)) ||
        !fb_add(&elements, sizeof(NlNsiError)) ||
        !fb_product(&total, 2, 1048576u + 1u) ||
        !fb_add(&total, 1048576u + 1u) ||
        !fb_product(&total, 8192u + 1u, sizeof(cJSON)) ||
        !fb_product(&total, 2, 1048576u + 2u * 8192u) ||
        !fb_add(&total, 4096u + 1u) ||
        !fb_add(&total, sizeof(NlNsi)) ||
        !fb_product(&total, 8192u, elements) ||
        !fb_product(&total, 256u + 1u, sizeof(const char *)) ||
        !fb_add(&total, nl_socket_plan_storage_size()) ||
        total > 16777216u) return 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                 0
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                      ;
    *out = total;
    return 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          1
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
              ;
}
static 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_fail(BindingScan *s, NlBindingStatus status) {
    s->status = status;
    return 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          0
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
               ;
}
static 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_space(unsigned char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}
static void fb_skip(BindingScan *s) {
    while (s->pos < s->size && fb_space(s->bytes[s->pos])) s->pos++;
}
static 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_token(BindingScan *s) {
    if (s->tokens == 8192u) return fb_fail(s, NL_BINDING_LIMIT);
    s->tokens++;
    return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          1
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
              ;
}
static int fb_hex(unsigned char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
static 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_hex4(BindingScan *s, unsigned *out) {
    unsigned n = 0;
    if (s->size - s->pos < 4) return fb_fail(s, NL_BINDING_INVALID);
    for (size_t i = 0; i < 4; i++) {
        int v = fb_hex(s->bytes[s->pos++]);
        if (v < 0) return fb_fail(s, NL_BINDING_INVALID);
        n = (n << 4) | (unsigned)v;
    }
    *out = n;
    return 
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          1
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
              ;
}
static 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_string(BindingScan *s) {
    if (!fb_token(s)) return 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                            0
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                 ;
    if (s->pos == s->size || s->bytes[s->pos++] != '"') return fb_fail(s, NL_BINDING_INVALID);
    size_t start = s->pos;
    while (s->pos < s->size) {
        unsigned char c = s->bytes[s->pos++];
        if (c == '"') {
            if (s->pos - start - 1 > 4096u) return fb_fail(s, NL_BINDING_LIMIT);
            return 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                  1
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                      ;
        }
        if (s->pos - start > 4096u) return fb_fail(s, NL_BINDING_LIMIT);
        if (c < 0x20) return fb_fail(s, NL_BINDING_INVALID);
        if (c != '\\') continue;
        if (s->pos == s->size) return fb_fail(s, NL_BINDING_INVALID);
        c = s->bytes[s->pos++];
        if (c == '"' || c == '\\' || c == '/' || c == 'b' || c == 'f' || c == 'n' || c == 'r' || c == 't') continue;
        if (c != 'u') return fb_fail(s, NL_BINDING_INVALID);
        unsigned value;
        if (!fb_hex4(s, &value)) return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                       0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                            ;
        if (!value || (value >= 0xdc00 && value <= 0xdfff)) return fb_fail(s, NL_BINDING_INVALID);
        if (value >= 0xd800 && value <= 0xdbff) {
            if (s->size - s->pos < 2 || s->bytes[s->pos] != '\\' || s->bytes[s->pos + 1] != 'u')
                return fb_fail(s, NL_BINDING_INVALID);
            s->pos += 2;
            if (!fb_hex4(s, &value)) return 
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                           0
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                ;
            if (value < 0xdc00 || value > 0xdfff) return fb_fail(s, NL_BINDING_INVALID);
        }
    }
    return fb_fail(s, NL_BINDING_INVALID);
}
static 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_digit(unsigned char c) { return c >= '0' && c <= '9'; }
static 
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_number(BindingScan *s) {
    size_t start = s->pos;
    if (!fb_token(s)) return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                            0
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                 ;
    if (s->bytes[s->pos] == '-') s->pos++;
    if (s->pos == s->size || !fb_digit(s->bytes[s->pos])) return fb_fail(s, NL_BINDING_INVALID);
    if (s->bytes[s->pos] == '0') s->pos++;
    else while (s->pos < s->size && fb_digit(s->bytes[s->pos])) s->pos++;
    if (s->pos < s->size && s->bytes[s->pos] == '.') {
        s->pos++;
        if (s->pos == s->size || !fb_digit(s->bytes[s->pos])) return fb_fail(s, NL_BINDING_INVALID);
        while (s->pos < s->size && fb_digit(s->bytes[s->pos])) s->pos++;
    }
    if (s->pos < s->size && (s->bytes[s->pos] == 'e' || s->bytes[s->pos] == 'E')) {
        s->pos++;
        if (s->pos < s->size && (s->bytes[s->pos] == '+' || s->bytes[s->pos] == '-')) s->pos++;
        if (s->pos == s->size || !fb_digit(s->bytes[s->pos])) return fb_fail(s, NL_BINDING_INVALID);
        while (s->pos < s->size && fb_digit(s->bytes[s->pos])) s->pos++;
    }
    return s->pos - start <= 4096u || fb_fail(s, NL_BINDING_LIMIT);
}
static 
# 133 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 133 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_value(BindingScan *s, size_t depth) {
    fb_skip(s);
    if (s->pos == s->size) return fb_fail(s, NL_BINDING_INVALID);
    unsigned char c = s->bytes[s->pos];
    if (c == '"') return fb_string(s);
    if (c == '-' || fb_digit(c)) return fb_number(s);
    if (c == '{' || c == '[') {
        
# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
       _Bool 
# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
            object = c == '{';
        unsigned char end = object ? '}' : ']';
        size_t count = 0;
        if (depth == 64u) return fb_fail(s, NL_BINDING_LIMIT);
        if (object && ++s->objects > 256u) return fb_fail(s, NL_BINDING_LIMIT);
        if (!fb_token(s)) return 
# 145 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                0
# 145 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                     ;
        s->pos++;
        fb_skip(s);
        if (s->pos < s->size && s->bytes[s->pos] == end) { s->pos++; return fb_token(s); }
        for (;;) {
            if (++count > (object ? 64u : 256u))
                return fb_fail(s, NL_BINDING_LIMIT);
            if (object) {
                if (!fb_string(s)) return 
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                         0
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                              ;
                fb_skip(s);
                if (s->pos == s->size || s->bytes[s->pos++] != ':') return fb_fail(s, NL_BINDING_INVALID);
                if (!fb_token(s)) return 
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                        0
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                             ;
            }
            if (!fb_value(s, depth + 1)) return 
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                               0
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                    ;
            fb_skip(s);
            if (s->pos == s->size) return fb_fail(s, NL_BINDING_INVALID);
            c = s->bytes[s->pos++];
            if (!fb_token(s)) return 
# 162 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                    0
# 162 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                         ;
            if (c == end) return 
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                1
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                    ;
            if (c != ',') return fb_fail(s, NL_BINDING_INVALID);
            fb_skip(s);
        }
    }
    const char *literal = c == 't' ? "true" : c == 'f' ? "false" : c == 'n' ? "null" : 
# 168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                                                      ((void *)0)
# 168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                                          ;
    if (!literal || s->size - s->pos < strlen(literal) ||
        memcmp(s->bytes + s->pos, literal, strlen(literal))) return fb_fail(s, NL_BINDING_INVALID);
    s->pos += strlen(literal);
    return fb_token(s);
}
static NlBindingStatus fb_preflight(const unsigned char *bytes, size_t size) {
    if (!bytes || !size) return NL_BINDING_INVALID;
    if (size > 1048576u) return NL_BINDING_LIMIT;
    if (memchr(bytes, 0, size) || !nl_utf8_validate((const char *)bytes, size, 
# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                                              ((void *)0)
# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                                  )) return NL_BINDING_INVALID;
    BindingScan s = { bytes, size, 0, 0, 0, NL_BINDING_OK };
    fb_skip(&s);
    if (s.pos == size || bytes[s.pos] != '{') return NL_BINDING_INVALID;
    if (!fb_value(&s, 0)) return s.status;
    fb_skip(&s);
    return s.pos == size ? NL_BINDING_OK : NL_BINDING_INVALID;
}
static 
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
      _Bool 
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
           fb_unique_keys(const cJSON *value, size_t depth) {
    if (depth > 64u) return 
# 186 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                            0
# 186 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                 ;
    if (cJSON_IsObject(value)) {
        for (const cJSON *a = value->child; a; a = a->next) {
            if (!a->string) return 
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                  0
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                       ;
            for (const cJSON *b = a->next; b; b = b->next)
                if (!b->string || strcmp(a->string, b->string) == 0) return 
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                                           0
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                                ;
        }
    }
    for (const cJSON *child = value->child; child; child = child->next)
        if (!fb_unique_keys(child, depth + 1)) return 
# 195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                     0
# 195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                          ;
    return 
# 196 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
          1
# 196 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
              ;
}

static NlBindingStatus fb_decode(const unsigned char *bytes, size_t size, NlNsi **out) {
    NlBindingStatus status = fb_preflight(bytes, size);
    if (status != NL_BINDING_OK) return status;
    char *copy = malloc(size + 1);
    if (!copy) return NL_BINDING_MEMORY;
    memcpy(copy, bytes, size); copy[size] = 0;
    const char *end = 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                     ((void *)0)
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                         ;
    cJSON *json = cJSON_ParseWithLengthOpts(copy, size + 1, &end, 1);
    if (!json) { free(copy); return NL_BINDING_UNRESOLVED; }
    if (end != copy + size || !fb_unique_keys(json, 0)) {
        cJSON_Delete(json); free(copy); return NL_BINDING_INVALID;
    }
    NlNsi *nsi = nl_nsi_decode_object(json);
    cJSON_Delete(json); free(copy);
    if (!nsi) return NL_BINDING_UNRESOLVED;
    NlBindingStatus checked = binding_catalog_validate(nsi);
    if (checked != NL_BINDING_OK) {
        nl_nsi_free(nsi);
        return checked;
    }
    *out = nsi;
    return NL_BINDING_OK;
}

typedef struct { unsigned char *data; size_t size, capacity; 
# 223 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                            _Bool 
# 223 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                 ok; } BindingWriter;
static void fb_write(BindingWriter *w, const char *text) {
    size_t n = strlen(text);
    if (!w->ok || n > 1048576u - w->size) { w->ok = 
# 226 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                               0
# 226 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                    ; return; }
    if (w->data) {
        if (n > w->capacity - w->size) { w->ok = 
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                0
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                     ; return; }
        memcpy(w->data + w->size, text, n);
    }
    w->size += n;
}
static void fb_quote(BindingWriter *w, const char *text) {
    static const char hex[] = "0123456789abcdef";
    fb_write(w, "\"");
    for (const unsigned char *p = (const unsigned char *)text; *p && w->ok; p++) {
        char escaped[7] = {0};
        if (*p == '"' || *p == '\\') { escaped[0] = '\\'; escaped[1] = (char)*p; }
        else if (*p < 0x20) {
            memcpy(escaped, "\\u00", 4); escaped[4] = hex[*p >> 4]; escaped[5] = hex[*p & 15];
        } else escaped[0] = (char)*p;
        fb_write(w, escaped);
    }
    fb_write(w, "\"");
}
static void fb_named(BindingWriter *w, const char *id, const char *name) {
    fb_write(w, "{\"id\":"); fb_quote(w, id);
    fb_write(w, ",\"name\":"); fb_quote(w, name);
}
static void fb_render_interface(BindingWriter *w, const NlNsi *n) {
    static const char *const directions[] = {"in","out","inout","return"};
    static const char *const ownerships[] = {"borrow","transfer","copy"};
    static const char *const lifetimes[] = {"call","caller","callee","resource"};
    static const char *const mutability[] = {"immutable","mutable"};
    fb_write(w, "{\"nsi_version\":0,\"interface\":");
    fb_named(w, n->iface.id, n->iface.name); fb_write(w, "},\"methods\":[");
    for (size_t i = 0; i < n->method_count; i++) {
        const NlNsiMethod *m = &n->methods[i];
        if (i) fb_write(w, ",");
        fb_named(w, m->id, m->name); fb_write(w, ",\"idempotent\":false,\"params\":[");
        for (size_t j = 0; j < m->param_count; j++) {
            const NlNsiParam *p = &m->params[j];
            if (j) fb_write(w, ",");
            fb_named(w, p->id, p->name); fb_write(w, ",\"type\":"); fb_quote(w, p->type_id);
            fb_write(w, ",\"direction\":"); fb_quote(w, directions[p->direction]);
            fb_write(w, ",\"ownership\":"); fb_quote(w, ownerships[p->ownership]);
            fb_write(w, ",\"lifetime\":"); fb_quote(w, lifetimes[p->lifetime]);
            fb_write(w, ",\"mutability\":"); fb_quote(w, mutability[p->mutability]);
            fb_write(w, ",\"optional\":false,\"streaming\":\"none\"}");
        }
        fb_write(w, "]}");
    }
    fb_write(w, "],\"types\":[");
    for (size_t i = 0; i < n->type_count; i++) {
        const NlNsiType *t = &n->types[i];
        if (i) fb_write(w, ",");
        fb_named(w, t->id, t->name); fb_write(w, ",\"kind\":");
        fb_quote(w, t->kind == NL_NSI_TYPE_RECORD ? "record" : t->kind == NL_NSI_TYPE_VARIANT ? "variant" : "resource");
        if (t->kind != NL_NSI_TYPE_RESOURCE) {
            fb_write(w, t->kind == NL_NSI_TYPE_RECORD ? ",\"fields\":[" : ",\"cases\":[");
            for (size_t j = 0; j < t->member_count; j++) {
                const NlNsiMember *m = &t->members[j];
                if (j) fb_write(w, ",");
                fb_named(w, m->id, m->name);
                if (m->type_id) { fb_write(w, ",\"type\":"); fb_quote(w, m->type_id); }
                fb_write(w, "}");
            }
            fb_write(w, "]");
        }
        fb_write(w, "}");
    }
    fb_write(w, "],\"errors\":[");
    fb_named(w, n->errors[0].id, n->errors[0].name);
    fb_write(w, ",\"version\":"); fb_quote(w, n->errors[0].version);
    fb_write(w, "}],\"capabilities\":[");
    for (size_t i = 0; i < n->capability_count; i++) {
        if (i) fb_write(w, ",");
        fb_named(w, n->capabilities[i].id, n->capabilities[i].name);
        fb_write(w, "}");
    }
    fb_write(w, "]}\n");
}
static void fb_render_source(BindingWriter *, const NlNsi *);
NlBindingStatus nl_socket_binding_prepare(const unsigned char *bytes, size_t size,
                                          NlSocketBindingPlan **out) {
    size_t bound;
    if (!out) return NL_BINDING_INVALID;
    if (!nl_socket_binding_allocation_bound(&bound)) return NL_BINDING_LIMIT;
    NlNsi *nsi = 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                ((void *)0)
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                    ;
    NlBindingStatus status = fb_decode(bytes, size, &nsi);
    if (status != NL_BINDING_OK) return status;
    BindingWriter json = {
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                         ((void *)0)
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                             , 0, 0, 
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                     1
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                         }, source = {
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                      ((void *)0)
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                          , 0, 0, 
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                                                                  1
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                                                      };
    fb_render_interface(&json, nsi); fb_render_source(&source, nsi);
    size_t allocation = sizeof(NlSocketBindingPlan);
    if (!json.ok || !source.ok || !fb_add(&allocation, json.size + 1) ||
        !fb_add(&allocation, source.size + 1)) { nl_nsi_free(nsi); return NL_BINDING_LIMIT; }
    NlSocketBindingPlan *plan = malloc(allocation);
    if (!plan) { nl_nsi_free(nsi); return NL_BINDING_MEMORY; }
    plan->interface_size = json.size; plan->source_size = source.size;
    plan->storage_size = allocation; plan->peak_bound = bound;
    json.data = plan->bytes; json.capacity = json.size; json.size = 0;
    source.data = plan->bytes + plan->interface_size + 1;
    source.capacity = source.size; source.size = 0;
    fb_render_interface(&json, nsi); fb_render_source(&source, nsi);
    nl_nsi_free(nsi); nsi = 
# 325 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                           ((void *)0)
# 325 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                               ;
    if (!json.ok || !source.ok || json.size != plan->interface_size || source.size != plan->source_size) {
        free(plan); return NL_BINDING_UNRESOLVED;
    }
    json.data[json.size] = 0; source.data[source.size] = 0;

    status = fb_decode(plan->bytes, plan->interface_size, &nsi);
    nl_nsi_free(nsi);
    if (status != NL_BINDING_OK) { free(plan); return status; }
    *out = plan;
    return NL_BINDING_OK;
}
void nl_socket_binding_free(NlSocketBindingPlan *plan) { free(plan); }
const unsigned char *nl_socket_binding_interface_bytes(const NlSocketBindingPlan *plan, size_t *size) {
    if (!plan || !size) return 
# 339 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                              ((void *)0)
# 339 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                  ;
    *size = plan->interface_size;
    return plan->bytes;
}
const unsigned char *nl_socket_binding_source_bytes(const NlSocketBindingPlan *plan, size_t *size) {
    if (!plan || !size) return 
# 344 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc" 3 4
                              ((void *)0)
# 344 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_binding_impl.inc"
                                  ;
    *size = plan->source_size;
    return plan->bytes + plan->interface_size + 1;
}
size_t nl_socket_binding_storage_size(const NlSocketBindingPlan *plan) { return plan ? plan->storage_size : 0; }
size_t nl_socket_binding_peak_bound(const NlSocketBindingPlan *plan) { return plan ? plan->peak_bound : 0; }
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_source_inputs/../../src/nsi_socket_binding.c" 2



static void fb_render_source(BindingWriter *w, const NlNsi *n) {
    fb_write(w, "# I declare catalog1; this declaration alone grants no host authority.\nservice ");
    fb_quote(w, n->iface.id);
    fb_write(w, " catalog 1 from \"interface.nsi.json\"\n");
}
