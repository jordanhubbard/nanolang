# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_layout_view.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/managed_record_plan.h" 2





typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_layout_view.h" 2


typedef enum {
    NVM_MIXED_UNKNOWN, NVM_MIXED_RESOURCE,
    NVM_MIXED_ORDINARY_STRUCTURAL, NVM_MIXED_PENDING_ARRAY_PROOF
} NvmMixedLayoutClass;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count, managed_count;
    uint32_t source_to_global[256u];
    uint32_t global_to_source[256u];
    uint32_t managed_to_global[256u];
    uint32_t global_to_managed[256u];
    NvmMixedLayoutClass classes[256u];
    uint8_t *ownership;
    uint32_t ownership_size;
} NvmMixedLayoutView;

NvmRecordPlanResult nvm_describe_mixed_layouts(const NvmModule *, NvmMixedLayoutView **);
void nvm_mixed_layout_view_free(NvmMixedLayoutView *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.h" 2




typedef enum {
    NVM_MIXED_SHAPE_PROVED, NVM_MIXED_SHAPE_UNRESOLVED,
    NVM_MIXED_SHAPE_INVALID, NVM_MIXED_SHAPE_LIMIT, NVM_MIXED_SHAPE_MEMORY
} NvmMixedShapeStatus;
typedef struct {
    NvmMixedShapeStatus status;
    uint32_t function, pc;
    const char *message;
} NvmMixedShapeResult;
typedef struct {
    uint16_t tags;
    uint64_t origins;
} NvmMixedFieldFact;
typedef struct {
    uint32_t function, pc, global_layout, source_record, field_start;
    uint16_t field_count;
    uint8_t tag;
} NvmMixedFloatOrigin;
typedef struct {
    uint32_t function, pc;
    uint16_t read_tags;
    uint16_t required_tags, actual_tags;
} NvmMixedScalarObligation;
typedef struct {
    NvmMixedLayoutView *view;
    uint32_t origin_count, field_count, obligation_count, checked_writes;
    
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.h" 3 4
   _Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.h"
        requires_affine_verification;
    NvmMixedFloatOrigin origins[64u];
    NvmMixedFieldFact *fields;
    NvmMixedScalarObligation obligations[4096u];
} NvmMixedFloatProof;


NvmMixedShapeResult nvm_analyze_mixed_float_origins(const NvmModule *, NvmMixedFloatProof **);
void nvm_mixed_float_proof_free(NvmMixedFloatProof *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 1
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 792 "/usr/include/stdlib.h" 3 4
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 948 "/usr/include/stdlib.h" 3 4
typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 2








# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
typedef struct { uint16_t tags; uint64_t origins; uint32_t nominal; uint16_t root; uint8_t kind, unknown; } MFValue;

typedef struct { uint8_t tag; uint32_t layout; } MFType;
typedef struct {
    DecodedInstruction in;
    uint32_t pc, next, target, function;
    int16_t origin;
    int16_t depth;
    MFValue *state;
    
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
   _Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
        queued;
} MFInstruction;
typedef struct {
    uint32_t start, end;
    MFType result, locals[256u];
    uint8_t calls, color;
} MFFunction;
typedef struct {
    const NvmModule *module;
    NvmMixedFloatProof *proof;
    MFFunction functions[8u];
    MFInstruction instructions[4096u];
    uint32_t count, cells, visits;
    
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
   _Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
        checking;
    uint32_t queue[4096u], head, tail, queued;
    NvmMixedShapeResult error;
} MFAnalysis;
static 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_stop(MFAnalysis *a,NvmMixedShapeStatus s,uint32_t f,uint32_t pc,const char *message) {
    a->error=(NvmMixedShapeResult){s,f,pc,message}; return 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                          0
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                               ;
}
static MFValue mf_tag(uint8_t tag) { MFValue v={0};v.tags=((uint16_t)(1u << (tag)));return v; }
static MFValue mf_owner(uint32_t nominal) { MFValue v=mf_tag(TAG_STRUCT);v.kind=1;v.nominal=nominal;return v; }
static 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_exact(MFValue v,uint16_t tags) { return !v.unknown && !v.kind && !v.origins && v.tags==tags; }
static 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_merge(MFValue *to,MFValue from) {
    uint16_t tags=to->tags;uint64_t origins=to->origins;uint8_t unknown=to->unknown;
    to->tags|=from.tags;to->origins|=from.origins;to->unknown|=from.unknown;
    return tags!=to->tags || origins!=to->origins || unknown!=to->unknown;
}
static void mf_enqueue(MFAnalysis *a,uint32_t index) {
    if(a->instructions[index].queued)return;
    a->instructions[index].queued=
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                 1
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                     ;a->queue[a->tail]=index;
    a->tail=(a->tail+1)%4096u;a->queued++;
}
static 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_join(MFAnalysis *a,uint32_t index,const MFValue *state,uint16_t depth) {
    MFInstruction *i=&a->instructions[index];uint32_t locals=a->module->functions[i->function].local_count;
    if(depth>256u)return mf_stop(a,NVM_MIXED_SHAPE_LIMIT,i->function,i->pc,"I reached my shape stack limit.");
    if(i->depth>=0 && i->depth!=depth)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,i->function,i->pc,"I require equal stack heights at shape joins.");
    
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
   _Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
        changed=
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                0
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                     ;
    if(!i->state) {
        uint32_t cells=locals+256u;
        if(cells>1048576u -a->cells)return mf_stop(a,NVM_MIXED_SHAPE_LIMIT,i->function,i->pc,"I reached my shape state budget.");
        i->state=calloc(cells,sizeof *i->state);
        if(!i->state)return mf_stop(a,NVM_MIXED_SHAPE_MEMORY,i->function,i->pc,"I could not allocate shape state.");
        a->cells+=cells;memcpy(i->state,state,(locals+depth)*sizeof *state);i->depth=(int16_t)depth;changed=
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                           1
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                               ;
    } else for(uint32_t n=0;n<locals+depth;n++) {
        MFValue *old=&i->state[n],v=state[n];
        if((old->kind || v.kind) && (old->kind!=v.kind || old->nominal!=v.nominal || old->root!=v.root || old->tags!=v.tags))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,i->function,i->pc,"I retain exact opaque owner states at joins.");
        changed|=mf_merge(old,v);
    }
    if(changed)mf_enqueue(a,index);
    return 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}
static 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_scalar_layout(const NvmMixedLayoutView *v,uint32_t layout) {
    if(layout>=v->layouts.count || v->classes[layout]!=NVM_MIXED_RESOURCE)return 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                0
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                     ;
    const NvmV2Layout *l=&v->layouts.items[layout];
    for(uint16_t i=0;i<l->field_count;i++) {
        uint8_t tag=l->fields[i].type_tag;
        if((tag!=TAG_INT && tag!=TAG_BOOL && tag!=TAG_U8) || l->fields[i].nested_idx!=0xFFFFFFFFu)return 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                            0
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                                 ;
    }
    return 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}
static 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_signature_type(MFAnalysis *a,MFType t) {
    if(t.tag==TAG_STRUCT)return mf_scalar_layout(a->proof->view,t.layout);
    return t.layout==0xFFFFFFFFu && (t.tag==TAG_VOID || t.tag==TAG_INT || t.tag==TAG_BOOL || t.tag==TAG_U8);
}
static 
# 89 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 89 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_descriptors(MFAnalysis *a) {
    NvmV2Cursor c;NvmMixedLayoutView *v=a->proof->view;uint32_t n,version;const uint8_t *unused;
    nvm_v2_cursor_init(&c,v->ownership,v->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK || nvm_v2_u32(&c,&n)!=NVM_V2_OK ||
       nvm_v2_take(&c,n,&unused)!=NVM_V2_OK || nvm_v2_align4(&c)!=NVM_V2_OK ||
       nvm_v2_u32(&c,&n)!=NVM_V2_OK)return 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                          0
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                               ;
    for(uint32_t f=0;f<n;f++) {
        uint16_t locals,params;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK)return 
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                        0
# 97 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                             ;
        for(uint32_t j=0;j<=locals;j++) {
            MFType t;uint8_t mode;uint16_t reserved;
            if(nvm_v2_u8(&c,&t.tag)!=NVM_V2_OK || nvm_v2_u8(&c,&mode)!=NVM_V2_OK ||
               nvm_v2_u16(&c,&reserved)!=NVM_V2_OK || nvm_v2_u32(&c,&t.layout)!=NVM_V2_OK)return 
# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                0
# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                     ;
            if(mode)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I keep reference calls outside my shape proof.");
            if(j>0 && j<=params && t.tag==TAG_VOID)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require concrete parameter tags.");
            if(j==0 || j<=params) {
                if(!mf_signature_type(a,t))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require existing scalar or scalar-leaf owner signatures.");
            }
            if(!j && !f && t.tag!=TAG_INT && t.tag!=TAG_BOOL && t.tag!=TAG_U8)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I retain scalar entry results.");
            if(!j)a->functions[f].result=t;else a->functions[f].locals[j-1]=t;
        }
    }
    return 
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}

static int mf_scalar_op(uint8_t op,uint16_t *required) {
    *required=0;
    switch(op) {
    case OP_PUSH_I64:return TAG_INT;case OP_PUSH_F64:return TAG_FLOAT;
    case OP_PUSH_U8:return TAG_U8;case OP_PUSH_BOOL:return TAG_BOOL;case OP_PUSH_VOID:return TAG_VOID;
    case OP_I64_ADD:case OP_I64_SUB:case OP_I64_MUL:case OP_I64_DIV_S:case OP_I64_REM_S:case OP_I64_NEG:
        *required=((uint16_t)(1u << (TAG_INT)));return TAG_INT;
    case OP_F64_ADD:case OP_F64_SUB:case OP_F64_MUL:case OP_F64_DIV:case OP_F64_NEG:
        *required=((uint16_t)(1u << (TAG_FLOAT)));return TAG_FLOAT;
    case OP_I64_EQ:case OP_I64_NE:case OP_I64_LT_S:case OP_I64_LE_S:case OP_I64_GT_S:case OP_I64_GE_S:
        *required=((uint16_t)(1u << (TAG_INT)));return TAG_BOOL;
    case OP_F64_EQ:case OP_F64_NE:case OP_F64_LT:case OP_F64_LE:case OP_F64_GT:case OP_F64_GE:
        *required=((uint16_t)(1u << (TAG_FLOAT)));return TAG_BOOL;
    case OP_BOOL_AND:case OP_BOOL_OR:case OP_BOOL_NOT:
        *required=((uint16_t)(1u << (TAG_BOOL)));return TAG_BOOL;
    case OP_EQ:case OP_NE:case OP_LT:case OP_LE:case OP_GT:case OP_GE:return TAG_BOOL;
    default:return -1;
    }
}
static 
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_supported(uint8_t op) {
    uint16_t required;if(mf_scalar_op(op,&required)>=0)return 
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                             1
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                 ;
    switch(op) {
    case OP_NOP:case OP_DUP:case OP_POP:case OP_SWAP:case OP_ROT3:
    case OP_LOAD_LOCAL:case OP_STORE_LOCAL:case OP_OWN_MOVE_LOCAL:case OP_OWN_STORE_LOCAL:
    case OP_OWN_PACK:case OP_OWN_UNPACK_LOCAL:case OP_AGG_PACK:case OP_AGG_GET:
    case OP_ARR_NEW:case OP_ARR_LITERAL:case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN:
    case OP_JMP:case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_CALL:case OP_RET:case OP_ASSERT:return 
# 142 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                 1
# 142 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                     ;
    default:return 
# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                  0
# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                       ;
    }
}
static 
# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_graph(MFAnalysis *a,uint32_t f) {
    MFFunction *fn=&a->functions[f];if(fn->color==2)return 
# 147 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                          1
# 147 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                              ;
    if(fn->color==1)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require an acyclic complete call graph.");
    fn->color=1;
    for(uint32_t c=0;c<a->module->function_count;c++)if((fn->calls&(1u<<c)) && !mf_graph(a,c))return 
# 150 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                    0
# 150 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                         ;
    fn->color=2;return 
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                      1
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                          ;
}
static 
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_preflight(MFAnalysis *a) {
    const NvmModule *m=a->module;NvmMixedLayoutView *v=a->proof->view;
    for(uint32_t f=0;f<m->function_count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];MFFunction *af=&a->functions[f];af->start=a->count;
        if(fn->name_idx>=m->string_count || !m->strings || !m->strings[fn->name_idx])
            return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,0,"I require exact function name indices.");
        if(!strcmp(m->strings[fn->name_idx],"__init__"))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I keep initializer execution outside this proof.");
        if(fn->code_offset>m->code_size || fn->code_length>m->code_size-fn->code_offset || !fn->code_length)
            return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,0,"I require complete nonempty code ranges.");
        for(uint32_t earlier=0;earlier<f;earlier++) {
            const NvmFunctionEntry *other=&m->functions[earlier];
            if(fn->code_offset<(uint64_t)other->code_offset+other->code_length &&
               other->code_offset<(uint64_t)fn->code_offset+fn->code_length)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require distinct function code ranges.");
        }
        for(uint32_t pc=0;pc<fn->code_length;) {
            if(a->count==4096u)return mf_stop(a,NVM_MIXED_SHAPE_LIMIT,f,pc,"I reached my decoded instruction limit.");
            MFInstruction *i=&a->instructions[a->count++];i->pc=pc;i->function=f;i->origin=-1;i->depth=-1;
            uint32_t width=isa_decode(m->code+fn->code_offset+pc,fn->code_length-pc,&i->in);
            if(!width)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require complete decoded instructions.");
            uint8_t op=i->in.opcode;
            if(!mf_supported(op))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I have no closed transfer for this opcode.");
            if(op==OP_PUSH_BOOL && i->in.operands[0].u8>1)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require canonical boolean operands.");
            if(op==OP_LOAD_LOCAL || op==OP_STORE_LOCAL || op==OP_OWN_MOVE_LOCAL || op==OP_OWN_STORE_LOCAL || op==OP_OWN_UNPACK_LOCAL) {
                if(i->in.operands[0].u16>=fn->local_count)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require an existing local index.");
            }
            if(op==OP_CALL) {
                uint32_t target=i->in.operands[0].u32;
                if(target>=m->function_count)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require an existing direct callee.");
                if(!target)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I do not call my entry function.");
                af->calls|=(uint8_t)(1u<<target);
            }
            if(op==OP_OWN_PACK || op==OP_OWN_UNPACK_LOCAL) {
                uint32_t layout=op==OP_OWN_PACK?i->in.operands[0].u32:af->locals[i->in.operands[0].u16].layout;
                if(!mf_scalar_layout(v,layout))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require exact scalar-leaf owner effects.");
            }
            if(op==OP_ARR_NEW || op==OP_ARR_LITERAL || op==OP_AGG_PACK) {
                uint32_t layout=0xFFFFFFFFu,source=0xFFFFFFFFu,fields=0;
                if(op==OP_AGG_PACK) {
                    source=i->in.operands[1].u32;
                    if(i->in.operands[0].u8 || i->in.operands[2].u16 || source>=v->record_count)
                        return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require an exact ordinary struct constructor.");
                    layout=v->source_to_global[source];fields=v->layouts.items[layout].field_count;
                    if(fields!=i->in.operands[3].u16)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require the declared constructor field count.");
                    if(v->classes[layout]!=NVM_MIXED_ORDINARY_STRUCTURAL && v->classes[layout]!=NVM_MIXED_PENDING_ARRAY_PROOF)
                        return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require a known nonresource constructor declaration.");
                } else if(i->in.operands[0].u8!=TAG_FLOAT)
                    return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I prove only declared packed FLOAT arrays.");
                if(a->proof->origin_count==64u || fields>65536u -a->proof->field_count)
                    return mf_stop(a,NVM_MIXED_SHAPE_LIMIT,f,pc,"I reached my allocation-origin or field-summary budget.");
                i->origin=(int16_t)a->proof->origin_count++;
                a->proof->origins[i->origin]=(NvmMixedFloatOrigin){f,pc,layout,source,a->proof->field_count,(uint16_t)fields,op==OP_AGG_PACK?TAG_STRUCT:TAG_ARRAY};
                a->proof->field_count+=fields;
            }
            pc+=width;i->next=a->count;i->target=
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                (4294967295U)
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                          ;
        }
        af->end=a->count;
    }
    for(uint32_t f=0;f<m->function_count;f++) {
        MFFunction *fn=&a->functions[f];
        for(uint32_t n=fn->start;n<fn->end;n++) {
            MFInstruction *i=&a->instructions[n];uint8_t op=i->in.opcode;
            if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
                int64_t target=(int64_t)i->pc+i->in.operands[0].i32;
                for(uint32_t j=fn->start;j<fn->end;j++)if(target==a->instructions[j].pc)i->target=j;
                if(target==m->functions[f].code_length)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require explicit terminal instructions, not end-of-code branches.");
                if(i->target==
# 220 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                             (4294967295U)
# 220 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                       )return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require an instruction-boundary branch target.");
            }
            if(i->next==fn->end && op!=OP_JMP && op!=OP_RET)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require explicit terminal control flow.");
        }
        if(!mf_graph(a,f))return 
# 225 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                0
# 225 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                     ;
    }
    return 
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}
static 
# 229 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 229 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_array(MFAnalysis *a,MFValue v) {
    if(v.kind || v.unknown || v.tags!=((uint16_t)(1u << (TAG_ARRAY))) || !v.origins)return 
# 230 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                            0
# 230 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                 ;
    for(uint32_t i=0;i<a->proof->origin_count;i++)if((v.origins&(1UL<<i)) && a->proof->origins[i].tag!=TAG_ARRAY)return 
# 231 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                                                               0
# 231 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                                                                    ;
    return 
# 232 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 232 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}
static 
# 234 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 234 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_field_matches(MFAnalysis *a,MFValue v,const NvmV2LayoutField *field) {
    if(v.kind || v.unknown || v.tags!=((uint16_t)(1u << (field->type_tag))))return 
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                    0
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                         ;
    if(field->type_tag==TAG_ARRAY)return mf_array(a,v);
    if(field->type_tag!=TAG_STRUCT)return !v.origins && (v.tags&(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))))!=0;
    if(!v.origins)return 
# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                        0
# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                             ;
    for(uint32_t i=0;i<a->proof->origin_count;i++)if(v.origins&(1UL<<i)) {
        NvmMixedFloatOrigin *o=&a->proof->origins[i];
        if(o->tag!=TAG_STRUCT || o->global_layout!=field->nested_idx)return 
# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                           0
# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                ;
    }
    return 
# 243 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
          1
# 243 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
              ;
}
static 
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_type_matches(MFValue v,MFType t) {
    if(t.tag==TAG_STRUCT)return v.kind==1 && !v.unknown && !v.origins && v.tags==((uint16_t)(1u << (TAG_STRUCT))) && v.nominal==t.layout;
    return mf_exact(v,((uint16_t)(1u << (t.tag))));
}
static void mf_field_union(MFAnalysis *a,uint32_t origin,uint16_t field,MFValue value) {
    NvmMixedFieldFact *fact=&a->proof->fields[a->proof->origins[origin].field_start+field];
    uint16_t old_tags=fact->tags;uint64_t old_origins=fact->origins;
    fact->tags|=value.tags;fact->origins|=value.origins;
    if(old_tags!=fact->tags || old_origins!=fact->origins)
        for(uint32_t i=0;i<a->count;i++)if(a->instructions[i].state)mf_enqueue(a,i);
}
static 
# 256 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
      _Bool 
# 256 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
           mf_step(MFAnalysis *a,uint32_t index) {
    MFInstruction *i=&a->instructions[index];uint32_t f=i->function;
    const NvmFunctionEntry *fn=&a->module->functions[f];MFFunction *af=&a->functions[f];
    MFValue state[256u*2];memcpy(state,i->state,(fn->local_count+(uint16_t)i->depth)*sizeof *state);
    MFValue *stack=state+fn->local_count;uint16_t depth=(uint16_t)i->depth;
    DecodedInstruction *in=&i->in;uint8_t op=in->opcode;const InstructionInfo *info=isa_get_info(op);
    int pops=info->pop_count,pushes=info->push_count;
    if(op==OP_ARR_LITERAL) {pops=in->operands[1].u16;pushes=1;}
    if(op==OP_AGG_PACK) {pops=in->operands[3].u16;pushes=1;}
    if(op==OP_OWN_PACK)pops=a->proof->view->layouts.items[in->operands[0].u32].field_count;
    if(op==OP_OWN_UNPACK_LOCAL) {pops=0;pushes=a->proof->view->layouts.items[af->locals[in->operands[0].u16].layout].field_count;}
    if(op==OP_CALL) {const NvmFunctionEntry *callee=&a->module->functions[in->operands[0].u32];pops=callee->arity;pushes=callee->result_count;}
    if(op==OP_RET) {
        if(depth!=fn->result_count)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require the exact declared return count.");
        if(a->checking && depth && !mf_type_matches(stack[0],af->result))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact scalar or owned return identity.");
        return 
# 272 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
              1
# 272 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                  ;
    }
    if(pops<0 || pushes<0 || depth<pops)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require complete operand stacks.");
    if((uint32_t)(depth-pops+pushes)>256u)return mf_stop(a,NVM_MIXED_SHAPE_LIMIT,f,i->pc,"I reached my operand stack budget.");
    if(op==OP_OWN_MOVE_LOCAL || op==OP_OWN_UNPACK_LOCAL) {
        uint16_t local=in->operands[0].u16;
        for(uint16_t n=0;n<depth;n++)if(stack[n].kind==2 && stack[n].root==local)
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I cannot consume an observed owner.");
    }
    uint16_t base=(uint16_t)(depth-pops);MFValue result={0};uint16_t required;
    int scalar=mf_scalar_op(op,&required);
    NvmMixedScalarObligation *ob=&a->proof->obligations[index];ob->function=f;ob->pc=i->pc;
    if(scalar>=0) {
        result=mf_tag((uint8_t)scalar);
        for(uint16_t n=base;n<depth;n++) {
            if(stack[n].kind || stack[n].origins || stack[n].unknown || (stack[n].tags&~(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL))))))
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I do not feed managed or opaque values to scalar instructions.");
            if(a->checking && !stack[n].tags)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require known scalar input alternatives.");
            if(required && stack[n].tags!=required) {ob->required_tags|=required;ob->actual_tags|=stack[n].tags;}
        }
        if(!required && pops>0) {
            ob->actual_tags|=stack[base].tags;
            if(pops>1)ob->actual_tags|=stack[base+1].tags;
        }
    } else switch(op) {
    case OP_NOP:case OP_JMP:break;
    case OP_DUP:
        if(stack[depth-1].kind)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I cannot duplicate an opaque owner or observation.");
        stack[depth]=stack[depth-1];depth++;goto successors;
    case OP_SWAP:result=stack[depth-1];stack[depth-1]=stack[depth-2];stack[depth-2]=result;goto successors;
    case OP_ROT3:result=stack[depth-1];stack[depth-1]=stack[depth-2];stack[depth-2]=stack[depth-3];stack[depth-3]=result;goto successors;
    case OP_POP:
        if(stack[base].kind)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require explicit opaque owner consumption.");
        break;
    case OP_LOAD_LOCAL:
        result=state[in->operands[0].u16];
        if(a->checking && (af->locals[in->operands[0].u16].tag==TAG_ARRAY ||
                          af->locals[in->operands[0].u16].tag==TAG_STRUCT) &&
           (result.tags&((uint16_t)(1u << (TAG_VOID)))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require initialized managed or owned local alternatives.");
        if(result.kind==1) {result.kind=2;result.root=in->operands[0].u16;}
        break;
    case OP_STORE_LOCAL: {
        uint16_t local=in->operands[0].u16;MFType t=af->locals[local];result=stack[base];
        if(result.kind || state[local].kind)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I keep opaque ownership out of ordinary stores.");
        if(a->checking) {
            NvmV2LayoutField field={t.tag,t.layout,0xFFFFFFFFu};
            if(!mf_field_matches(a,result,&field))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact initialized local shape.");
        }
        state[local]=result;break;
    }
    case OP_OWN_MOVE_LOCAL: {
        uint16_t local=in->operands[0].u16;result=state[local];
        if(!mf_type_matches(result,af->locals[local]))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an intact exact owner move.");
        if(!result.kind)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an owner for an owner move.");
        state[local]=mf_tag(TAG_VOID);break;
    }
    case OP_OWN_STORE_LOCAL: {
        uint16_t local=in->operands[0].u16;
        if(state[local].kind || !mf_exact(state[local],((uint16_t)(1u << (TAG_VOID)))) || !mf_type_matches(stack[base],af->locals[local]) || stack[base].kind!=1)
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an empty exact owner destination.");
        state[local]=stack[base];break;
    }
    case OP_OWN_PACK: {
        uint32_t layout=in->operands[0].u32;const NvmV2Layout *l=&a->proof->view->layouts.items[layout];
        for(uint16_t n=0;n<l->field_count;n++)if(a->checking && !mf_exact(stack[base+n],((uint16_t)(1u << (l->fields[n].type_tag)))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact scalar owner fields.");
        result=mf_owner(layout);break;
    }
    case OP_OWN_UNPACK_LOCAL: {
        uint16_t local=in->operands[0].u16;MFType t=af->locals[local];
        if(!mf_type_matches(state[local],t))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an intact exact unpack source.");
        const NvmV2Layout *l=&a->proof->view->layouts.items[t.layout];state[local]=mf_tag(TAG_VOID);
        for(uint16_t n=0;n<l->field_count;n++)stack[depth++]=mf_tag(l->fields[n].type_tag);
        goto successors;
    }
    case OP_AGG_PACK: {
        NvmMixedFloatOrigin *o=&a->proof->origins[i->origin];const NvmV2Layout *l=&a->proof->view->layouts.items[o->global_layout];
        for(uint16_t n=0;n<l->field_count;n++) {
            MFValue value=stack[base+n];
            if(value.kind || value.unknown)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I refuse owner or unknown ordinary fields.");
            if(a->checking && !mf_field_matches(a,value,&l->fields[n]))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require every exact nominal field alternative.");
            if(!a->checking)mf_field_union(a,(uint32_t)i->origin,n,value);
        }
        result=mf_tag(TAG_STRUCT);result.origins=1UL<<i->origin;break;
    }
    case OP_AGG_GET: {
        MFValue receiver=stack[base];uint16_t field=in->operands[0].u16;
        if(receiver.kind) {
            if(receiver.kind!=2 || receiver.nominal>=a->proof->view->layouts.count)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an exact owner observation.");
            const NvmV2Layout *l=&a->proof->view->layouts.items[receiver.nominal];
            if(field>=l->field_count)return mf_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require an existing owner field.");
            if(receiver.root>=fn->local_count || state[receiver.root].kind!=1 || state[receiver.root].nominal!=receiver.nominal)
                return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require the observed owner to remain live.");
            result=mf_tag(l->fields[field].type_tag);break;
        }
        if(a->checking && (receiver.unknown || receiver.tags!=((uint16_t)(1u << (TAG_STRUCT))) || !receiver.origins))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact ordinary record receiver origins.");
        for(uint32_t n=0;n<a->proof->origin_count;n++)if(receiver.origins&(1UL<<n)) {
            NvmMixedFloatOrigin *o=&a->proof->origins[n];
            if(o->tag!=TAG_STRUCT || field>=o->field_count)return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require a field on every receiver alternative.");
            NvmMixedFieldFact *fact=&a->proof->fields[o->field_start+field];result.tags|=fact->tags;result.origins|=fact->origins;
        }
        result.unknown=receiver.unknown;break;
    }
    case OP_ARR_NEW:case OP_ARR_LITERAL:
        for(uint16_t n=base;n<depth;n++)if(a->checking && !mf_exact(stack[n],((uint16_t)(1u << (TAG_FLOAT)))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact FLOAT literal elements.");
        result=mf_tag(TAG_ARRAY);result.origins=1UL<<i->origin;break;
    case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN: {
        MFValue receiver=stack[base];
        if(a->checking && !mf_array(a,receiver))return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require positive closed FLOAT-array origins.");
        if((op==OP_ARR_SET || op==OP_ARR_GET) && a->checking && !mf_exact(stack[base+1],((uint16_t)(1u << (TAG_INT)))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact integer array indices.");
        if((op==OP_ARR_PUSH || op==OP_ARR_SET) && a->checking && !mf_exact(stack[depth-1],((uint16_t)(1u << (TAG_FLOAT)))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact FLOAT writes on every array alias.");
        if(op==OP_ARR_GET) {result=mf_tag(TAG_FLOAT);result.tags|=((uint16_t)(1u << (TAG_VOID)));ob->read_tags=result.tags;}
        else if(op==OP_ARR_LEN)result=mf_tag(TAG_INT);
        else {result=receiver;if(a->checking)a->proof->checked_writes++;}
        break;
    }
    case OP_CALL: {
        uint32_t target=in->operands[0].u32;const NvmFunctionEntry *callee=&a->module->functions[target];
        for(uint16_t n=0;n<callee->arity;n++)if(a->checking && !mf_type_matches(stack[base+n],a->functions[target].locals[n]))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require every positional call identity before transfer.");
        MFType t=a->functions[target].result;result=t.tag==TAG_STRUCT?mf_owner(t.layout):mf_tag(t.tag);break;
    }
    case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_ASSERT:
        if(stack[base].kind || stack[base].origins || stack[base].unknown || (stack[base].tags&~(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL))))))
            return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require scalar control operands.");
        if(stack[base].tags!=((uint16_t)(1u << (TAG_BOOL)))) {ob->required_tags|=((uint16_t)(1u << (TAG_BOOL)));ob->actual_tags|=stack[base].tags;}
        break;
    default:return mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an explicit shape transfer.");
    }
    depth=(uint16_t)(base+pushes);if(pushes)stack[base]=result;
successors:
    if(a->checking)return 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                         1
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                             ;
    if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
        if(!mf_join(a,i->target,state,depth))return 
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                   0
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                        ;
        if(op==OP_JMP)return 
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                            1
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                ;
    }
    return mf_join(a,i->next,state,depth);
}
void nvm_mixed_float_proof_free(NvmMixedFloatProof *proof) {
    if(!proof)return;
    nvm_mixed_layout_view_free(proof->view);free(proof->fields);free(proof);
}
NvmMixedShapeResult nvm_analyze_mixed_float_origins(const NvmModule *m,NvmMixedFloatProof **out) {
    NvmMixedShapeResult invalid={NVM_MIXED_SHAPE_INVALID,0,0,"I require a complete immutable module and output."};
    if(!m || !out || !m->functions || !m->code || !m->function_count)return invalid;
    if(m->function_count>8u || m->header.entry_point || m->import_count || m->module_ref_count || m->callback_contract_count || m->passive_size)
        return (NvmMixedShapeResult){NVM_MIXED_SHAPE_UNRESOLVED,0,0,"I require my standalone eight-function closed value graph."};
    for(uint32_t f=0;f<m->function_count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];
        if(fn->local_count>256u || fn->arity>8)return (NvmMixedShapeResult){NVM_MIXED_SHAPE_LIMIT,f,0,"I reached my function slot or argument budget."};
        if(fn->arity>fn->local_count || fn->result_count>1 || fn->upvalue_count || (!f && fn->arity))return invalid;
    }
    NvmMixedLayoutView *view=
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                            ((void *)0)
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                ;NvmRecordPlanResult described=nvm_describe_mixed_layouts(m,&view);
    if(described.status!=NVM_RECORD_DESCRIBED) {
        NvmMixedShapeStatus status=described.status==NVM_RECORD_MEMORY?NVM_MIXED_SHAPE_MEMORY:
            described.status==NVM_RECORD_LIMIT?NVM_MIXED_SHAPE_LIMIT:
            described.status==NVM_RECORD_INVALID?NVM_MIXED_SHAPE_INVALID:NVM_MIXED_SHAPE_UNRESOLVED;
        return (NvmMixedShapeResult){status,0,0,described.message};
    }
    if(!view->ownership_size) {nvm_mixed_layout_view_free(view);return (NvmMixedShapeResult){NVM_MIXED_SHAPE_UNRESOLVED,0,0,"I require explicit mixed declarations."};}
    MFAnalysis *a=calloc(1,sizeof *a);NvmMixedFloatProof *proof=calloc(1,sizeof *proof);
    if(!a || !proof) {free(a);free(proof);nvm_mixed_layout_view_free(view);return (NvmMixedShapeResult){NVM_MIXED_SHAPE_MEMORY,0,0,"I could not allocate my bounded proof."};}
    a->module=m;a->proof=proof;proof->view=view;proof->requires_affine_verification=
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                                                                   1
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                                                                       ;a->error=invalid;
    if(!mf_descriptors(a) || !mf_preflight(a))goto done;
    a->cells=proof->field_count;
    if(proof->field_count) {
        proof->fields=calloc(proof->field_count,sizeof *proof->fields);
        if(!proof->fields) {mf_stop(a,NVM_MIXED_SHAPE_MEMORY,0,0,"I could not allocate field summaries.");goto done;}
    }
    for(uint32_t f=0;f<m->function_count;f++) {
        MFValue seed[256u*2]={0};const NvmFunctionEntry *fn=&m->functions[f];
        for(uint16_t n=0;n<fn->local_count;n++)seed[n]=mf_tag(TAG_VOID);
        for(uint16_t n=0;n<fn->arity;n++) {MFType t=a->functions[f].locals[n];seed[n]=t.tag==TAG_STRUCT?mf_owner(t.layout):mf_tag(t.tag);}
        if(!mf_join(a,a->functions[f].start,seed,0))goto done;
    }
    while(a->queued) {
        if(a->visits++==262144u) {mf_stop(a,NVM_MIXED_SHAPE_LIMIT,0,0,"I reached my shape fixed-point work budget.");goto done;}
        uint32_t index=a->queue[a->head];a->head=(a->head+1)%4096u;a->queued--;
        a->instructions[index].queued=
# 456 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
                                     0
# 456 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                                          ;if(!mf_step(a,index))goto done;
    }
    a->checking=
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c" 3 4
               1
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/nanoisa/../../src/nanoisa/mixed_float_proof.c"
                   ;
    for(uint32_t i=0;i<a->count;i++) {
        if(!a->instructions[i].state) {mf_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,a->instructions[i].function,a->instructions[i].pc,"I require checked state for every declared instruction.");goto done;}
        if(!mf_step(a,i))goto done;
    }
    proof->obligation_count=a->count;
    a->error=(NvmMixedShapeResult){NVM_MIXED_SHAPE_PROVED,0,0,"I proved closed managed shape only; scalar and affine admission remain separate."};
done:
    for(uint32_t i=0;i<a->count;i++)free(a->instructions[i].state);
    NvmMixedShapeResult result=a->error;free(a);
    if(result.status==NVM_MIXED_SHAPE_PROVED)*out=proof;else nvm_mixed_float_proof_free(proof);
    return result;
}
