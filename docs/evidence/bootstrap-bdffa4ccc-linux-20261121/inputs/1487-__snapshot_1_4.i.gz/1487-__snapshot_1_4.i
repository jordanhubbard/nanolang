# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.h" 2



typedef enum {
    NVM_ARRAY_ELIGIBLE, NVM_ARRAY_UNRESOLVED, NVM_ARRAY_INVALID,
    NVM_ARRAY_LIMIT, NVM_ARRAY_MEMORY
} NvmArrayEligibilityStatus;
typedef struct {
    uint32_t function, pc;
    uint16_t child_tags;
    uint8_t declared_tag, packed;
} NvmArrayOrigin;
typedef struct {
    uint32_t origin_count, checked_writes;

    uint32_t runtime_tag_checks;
    NvmArrayOrigin origins[64];
} NvmArrayEligibilityReport;

typedef struct {
    NvmArrayEligibilityReport arrays;
    uint64_t child_origins[64];
    uint8_t child_unknown[64];
} NvmArrayGraphEligibilityReport;
typedef struct {
    NvmArrayEligibilityStatus status;
    uint32_t function, pc;
    char message[192];
} NvmArrayEligibilityResult;

NvmArrayEligibilityResult nvm_analyze_managed_arrays(
    const NvmModule *module, NvmArrayEligibilityReport **out);
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report);

NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(
    const NvmModule *module, NvmArrayGraphEligibilityReport **out);
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report);



NvmArrayEligibilityResult nvm_select_managed_array_mode(
    const NvmModule *module, int *graph_required);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_plan.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_plan.h" 2





typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_shapes.h" 2


typedef struct {
    uint64_t origins;
    uint16_t tags;
    uint8_t unknown;
} NvmRecordValueOrigins;
typedef enum { NVM_HEAP_ORIGIN_ARRAY, NVM_HEAP_ORIGIN_RECORD } NvmHeapOriginKind;
typedef struct {
    uint32_t function, pc;
    uint32_t record_ordinal, layout_index, field_start;
    uint16_t field_count;
    uint8_t kind, declared_tag, packed;
    NvmRecordValueOrigins children;
} NvmRecordHeapOrigin;
typedef struct {
    uint32_t origin_count, field_value_count, checked_field_writes;
    uint32_t checked_array_writes, runtime_tag_checks;
    NvmRecordHeapOrigin origins[64];
    NvmRecordValueOrigins *fields;
} NvmRecordEligibilityReport;



NvmArrayEligibilityResult nvm_analyze_managed_records(
    const NvmModule *module, NvmRecordEligibilityReport **out);
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report);


typedef enum { NVM_MANAGED_LEAF, NVM_MANAGED_ARRAY_GRAPH, NVM_MANAGED_RECORD } NvmManagedHeapMode;
typedef struct {
    NvmManagedHeapMode mode;
    NvmRecordPlan *records;
    NvmRecordEligibilityReport *fields;
} NvmManagedHeapPlan;
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *, int mutable_arrays,
                                                 NvmManagedHeapPlan **out);
void nvm_managed_heap_plan_free(NvmManagedHeapPlan *);
NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *, NvmManagedHeapPlan **);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 1






typedef struct NvmOrdinaryArrayAuthority NvmOrdinaryArrayAuthority;
typedef enum { NVM_OAA_DESCRIBED, NVM_OAA_UNKNOWN, NVM_OAA_INVALID,
               NVM_OAA_LIMIT, NVM_OAA_MEMORY } NvmOrdinaryArrayStatus;
typedef struct { NvmOrdinaryArrayStatus status; uint32_t layout, field;
                 const char *message; } NvmOrdinaryArrayResult;
typedef struct { uint32_t layouts, types, bindings; } NvmOrdinaryArrayCounts;
typedef struct { uint8_t tag; uint32_t referent; } NvmOrdinaryArrayType;
typedef struct { uint32_t layout; uint16_t field; uint32_t element_type; } NvmOrdinaryArrayBinding;
NvmOrdinaryArrayResult nvm_describe_ordinary_array_authority(const NvmModule *, NvmOrdinaryArrayAuthority **);
void nvm_ordinary_array_authority_free(NvmOrdinaryArrayAuthority *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_counts(const NvmOrdinaryArrayAuthority *, NvmOrdinaryArrayCounts *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_type(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayType *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ordinary_array_authority.h"
    nvm_ordinary_array_authority_binding(const NvmOrdinaryArrayAuthority *, uint32_t, NvmOrdinaryArrayBinding *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 2



typedef struct NvmOwnershipDeclarationPlan NvmOwnershipDeclarationPlan;
typedef enum {
    NVM_DECL_PREPARED, NVM_DECL_UNKNOWN, NVM_DECL_INVALID,
    NVM_DECL_LIMIT, NVM_DECL_MEMORY
} NvmDeclarationStatus;
typedef struct { NvmDeclarationStatus status; const char *message; } NvmDeclarationResult;
typedef struct { uint32_t layouts, types, bindings, unions, variants; } NvmDeclarationCounts;
typedef struct { uint8_t kind, flags; uint16_t fields; uint32_t name; } NvmDeclarationLayout;
NvmDeclarationResult nvm_prepare_ownership_declarations(const NvmModule *,NvmOwnershipDeclarationPlan **);
void nvm_ownership_declarations_free(NvmOwnershipDeclarationPlan *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_counts(const NvmOwnershipDeclarationPlan *,NvmDeclarationCounts *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_layout(const NvmOwnershipDeclarationPlan *,uint32_t,NvmDeclarationLayout *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_field(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_type(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayType *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_binding(const NvmOwnershipDeclarationPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_declaration_projection.h"
    nvm_ownership_declarations_variant(const NvmOwnershipDeclarationPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 2


typedef struct NvmRecordArrayOrigins NvmRecordArrayOrigins;
typedef struct {
    uint32_t origins, fields, checked_field_writes, checked_array_writes, runtime_tag_checks;
    uint64_t work_reserved, peak_bytes_reserved;
} NvmRecordArrayOriginCounts;
NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *,NvmRecordArrayOrigins **);
void nvm_record_array_origins_free(NvmRecordArrayOrigins *);

# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *,NvmRecordArrayOriginCounts *);

# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_origin(const NvmRecordArrayOrigins *,uint32_t,NvmRecordHeapOrigin *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *,uint32_t,NvmRecordValueOrigins *);
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
static inline uint16_t nvm_record_array_requirement(uint8_t depth,uint8_t leaf) {
    if(leaf<TAG_INT || leaf>TAG_STRING)return 0;
    if(depth==1)return (uint16_t)(1u<<leaf);
    if(depth==2) {
        switch(leaf) {
        case TAG_INT:return ((uint16_t)(1u << TAG_ARRAY));
        case TAG_U8:return ((uint16_t)(1u << 9));
        case TAG_FLOAT:return ((uint16_t)(1u << 10));
        case TAG_BOOL:return ((uint16_t)(1u << 11));
        case TAG_STRING:return ((uint16_t)(1u << 8));
        }
    }
    if(depth==3)return leaf==TAG_STRING?((uint16_t)(1u << 6)):(uint16_t)(1u<<(11u+leaf));
    return 0;
}
static inline uint8_t nvm_record_array_requirement_depth(uint16_t requirement) {
    for(uint8_t depth=1;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(requirement==nvm_record_array_requirement(depth,leaf))return depth;
    return 0;
}

static inline uint8_t nvm_record_array_requirement_leaf(uint16_t requirement) {
    switch(requirement) {
    case ((uint16_t)(1u << 12)):case ((uint16_t)(1u << TAG_ARRAY)):return TAG_INT;
    case ((uint16_t)(1u << 13)):case ((uint16_t)(1u << 9)):return TAG_U8;
    case ((uint16_t)(1u << 14)):case ((uint16_t)(1u << 10)):return TAG_FLOAT;
    case ((uint16_t)(1u << 15)):case ((uint16_t)(1u << 11)):return TAG_BOOL;
    case ((uint16_t)(1u << 6)):case ((uint16_t)(1u << 8)):return TAG_STRING;
    default:return TAG_VOID;
    }
}

# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *,uint32_t,uint16_t *);

# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *,NvmDeclarationCounts *);

# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *,uint32_t,NvmDeclarationLayout *);

# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmV2LayoutField *);

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayType *);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *,uint32_t,NvmOrdinaryArrayBinding *);

# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_origins.h"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 1




# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h" 1
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/isa.h" 1
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/../nanoisa/nvm_format.h" 1
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
typedef struct {
    const NvmModule *module;
    const NvmFunctionEntry *function;
    uint32_t function_index;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
        resolved;
} VmCallHandle;

typedef struct {
    uint32_t byte_offset;
    uint32_t next_byte_offset;
    uint32_t resolved_target;
    VmCallHandle call_handle;
    DecodedInstruction instruction;
} VmDecodedInstruction;

typedef struct {
    VmDecodedInstruction *instructions;
    uint32_t instruction_count;
    uint32_t code_size;
    uint8_t *boundaries;
    uint32_t *instruction_indices;
} VmDecodedFunction;

typedef struct {
    VmDecodedFunction *functions;
    uint32_t function_count;
} VmDecodedModule;


# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_function(const NvmModule *module, uint32_t function_index,
                        VmDecodedFunction *out, char error[256]);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decode_module(const NvmModule *module, VmDecodedModule *out,
                      char error[256]);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nanovm/vm_decode.h"
    vm_decoded_function_has_boundary(const VmDecodedFunction *function,
                                      uint32_t byte_offset);
const VmDecodedInstruction *vm_decoded_function_at(
    const VmDecodedFunction *function, uint32_t byte_offset);
void vm_decoded_function_free(VmDecodedFunction *function);
void vm_decoded_module_free(VmDecodedModule *module);
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h" 2




typedef struct {
    
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h" 3 4
   _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
        ok;
    char error_msg[256];
} NvmVerifyResult;
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify(const NvmModule *mod);







typedef enum {
    NVM_PROFILE_GENERAL = 0,
    NVM_PROFILE_CLOSED_SCALAR = 1,
    NVM_PROFILE_CLOSED_LITERAL_STRINGS = 2,
    NVM_PROFILE_CLOSED_MANAGED_STRINGS = 3,


    NVM_PROFILE_PORTABLE_FILE_READ = 5,
    NVM_PROFILE_PORTABLE_READ_TEXT = 4
} NvmVerifyProfile;
NvmVerifyResult nvm_verify_profile(const NvmModule *mod, NvmVerifyProfile profile);



NvmVerifyResult nvm_verify_owned_module(const NvmModule *mod);



# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
    nvm_uses_owned_transfers(const NvmModule *mod);



NvmVerifyResult nvm_verify_affine_function(const NvmModule *mod, uint32_t fn_idx);


NvmVerifyResult nvm_verify_function(const NvmModule *mod, uint32_t fn_idx);
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_function_types(const NvmModule *mod, uint32_t fn_idx,
                                          const VmDecodedFunction *decoded,
                                          uint16_t max_depth,
                                          char *error, size_t error_size);

NvmVerifyResult nvm_verify_function_max_stack(const NvmModule *mod,
                                              uint32_t fn_idx,
                                              uint16_t *out_max_stack);





NvmVerifyResult nvm_verify_declared_max_stacks(const NvmModule *mod,
                                              const uint16_t *declared_depths,
                                              uint32_t count);
# 131 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/verifier.h"
NvmVerifyResult nvm_verify_linked(const NvmModule *mod,
                                  const NvmModule *const *linked_modules,
                                  uint32_t linked_count);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 2

# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 2





# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
typedef struct {
    uint64_t bytes, peak, work;
    
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
        limited, memory;
} NvmRecordArrayBudget;
static inline 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_bytes(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->bytes>(64UL*1024*1024) || n>(64UL*1024*1024)-b->bytes){b->limited=
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                   1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                       ;return 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                               0
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                                    ;}
    b->bytes+=n;if(b->peak<b->bytes)b->peak=b->bytes;return 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                           1
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                               ;
}
static inline 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
             _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                  nvm_ra_steps(NvmRecordArrayBudget *b,uint64_t n) {
    if(!b)return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                1
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                    ;
    if(b->limited || b->memory)return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                     0
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                          ;
    if(b->work>16777216UL || n>16777216UL -b->work){b->limited=
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                 1
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                     ;return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                                             0
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                                  ;}
    b->work+=n;return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                     1
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                         ;
}
static inline void *nvm_ra_alloc(NvmRecordArrayBudget *b,size_t n,size_t width) {
    if(width && n>
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                 (18446744073709551615UL)
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                         /width){if(b)b->limited=
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                 1
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                     ;return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                             ((void *)0)
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                 ;}
    if(!nvm_ra_bytes(b,(uint64_t)n*width))return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                ((void *)0)
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                    ;
    void *p=calloc(n,width);if(!p && n && width && b)b->memory=
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
                                                              1
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
                                                                  ;return p;
}


typedef struct {
    NvmOwnershipDeclarationPlan *declarations;
    uint32_t functions;
    VmDecodedFunction decoded[256];
    uint16_t stacks[256];
} NvmRecordArrayStructure;

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_structure_private.h"
    nvm_record_array_opcode_supported(uint8_t);
NvmArrayEligibilityResult nvm_record_array_structure_prepare(
    const NvmModule *,NvmRecordArrayBudget *,NvmRecordArrayStructure **);
void nvm_record_array_structure_free(NvmRecordArrayStructure *);
NvmVerifyResult nvm_verify_function_types_record_array(
    const NvmModule *,uint32_t,const VmDecodedFunction *,uint16_t,NvmRecordArrayBudget *);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
typedef struct NvmMapDeclarationPlan NvmMapDeclarationPlan;
typedef enum { NVM_MAP_ABSENT, NVM_MAP_DESCRIBED, NVM_MAP_INVALID,
               NVM_MAP_LIMIT, NVM_MAP_MEMORY } NvmMapDeclarationStatus;
typedef struct { NvmMapDeclarationStatus status; const char *message; } NvmMapDeclarationResult;
typedef struct { uint32_t scalars,pairs,bindings; } NvmMapDeclarationCounts;
typedef struct { uint32_t key_type,value_type; } NvmMapDeclarationPair;
typedef struct { uint32_t layout; uint16_t field; uint32_t pair; } NvmMapDeclarationBinding;
NvmMapDeclarationResult nvm_prepare_map_declarations(const NvmModule *,NvmMapDeclarationPlan **);
void nvm_map_declarations_free(NvmMapDeclarationPlan *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_counts(const NvmMapDeclarationPlan *,NvmMapDeclarationCounts *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_scalar(const NvmMapDeclarationPlan *,uint32_t,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_pair(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationPair *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_binding(const NvmMapDeclarationPlan *,uint32_t,NvmMapDeclarationBinding *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_map_declarations.h"
    nvm_map_declarations_field(const NvmMapDeclarationPlan *,uint32_t,uint16_t,NvmMapDeclarationPair *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 2

NvmMapDeclarationResult nvm_prepare_map_declarations_split(const NvmModule *,
    NvmMapDeclarationPlan **,NvmOwnershipDeclarationPlan **);
NvmArrayEligibilityResult nvm_record_map_structure_prepare(const NvmModule *,
    NvmRecordArrayBudget *,NvmRecordArrayStructure **,NvmMapDeclarationPlan **);
static inline 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_structure_private.h" 3 4
             _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_structure_private.h"
                  nvm_record_map_opcode(uint8_t op) {
    return op==OP_HM_NEW || op==OP_HM_SET || op==OP_HM_GET ||
           op==OP_HM_HAS || op==OP_HM_LEN || op==OP_HM_DELETE;
}
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_union_structure_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 1
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
typedef struct NvmUnionFieldDeclarations NvmUnionFieldDeclarations;
typedef enum { NVM_UFD_PREPARED, NVM_UFD_UNKNOWN, NVM_UFD_INVALID,
               NVM_UFD_LIMIT, NVM_UFD_MEMORY } NvmUnionFieldDeclarationStatus;
typedef struct {
    NvmUnionFieldDeclarationStatus status;
    const char *message;
    uint64_t bytes_reserved, work_reserved;
} NvmUnionFieldDeclarationResult;
NvmUnionFieldDeclarationResult nvm_union_field_declarations_prepare(const NvmModule *,NvmUnionFieldDeclarations **);
void nvm_union_field_declarations_free(NvmUnionFieldDeclarations *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_layout(const NvmUnionFieldDeclarations *,uint32_t,NvmDeclarationLayout *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_field(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmV2LayoutField *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_variant(const NvmUnionFieldDeclarations *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_union_fields_private.h"
    nvm_union_field_declarations_nominal(const NvmUnionFieldDeclarations *,uint8_t,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_union_structure_private.h" 2







typedef struct {
    NvmRecordArrayStructure *carrier;
    NvmUnionFieldDeclarations *declarations;
} NvmRecordUnionStructure;
NvmArrayEligibilityResult nvm_record_union_structure_prepare(
    const NvmModule *,NvmRecordArrayBudget *,NvmRecordUnionStructure **);
void nvm_record_union_structure_free(NvmRecordUnionStructure *);
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 1
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
typedef struct NvmUnionFieldProof NvmUnionFieldProof;
typedef struct {
    uint32_t function, pc, nominal_ordinal, layout_index;
    uint8_t kind, variant;
    uint16_t member_count;
    NvmRecordValueOrigins member;
} NvmUnionFieldOrigin;
typedef struct {
    uint32_t origins, globals, functions;
    uint64_t bytes_reserved, work_reserved;
} NvmUnionFieldProofCounts;
NvmArrayEligibilityResult nvm_union_field_proof_prepare(const NvmModule *,NvmUnionFieldProof **);
void nvm_union_field_proof_free(NvmUnionFieldProof *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_counts(const NvmUnionFieldProof *,NvmUnionFieldProofCounts *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_origin(const NvmUnionFieldProof *,uint32_t,NvmUnionFieldOrigin *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_global(const NvmUnionFieldProof *,uint32_t,NvmRecordValueOrigins *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_result(const NvmUnionFieldProof *,uint32_t,NvmRecordValueOrigins *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_stack(const NvmUnionFieldProof *,uint32_t,uint16_t *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_layout(const NvmUnionFieldProof *,uint32_t,NvmDeclarationLayout *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_field(const NvmUnionFieldProof *,uint32_t,uint16_t,NvmV2LayoutField *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_variant(const NvmUnionFieldProof *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_proof_private.h"
    nvm_union_field_proof_nominal(const NvmUnionFieldProof *,uint8_t,uint32_t,uint32_t *);
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
typedef struct NvmRecordArrayExecutionPlan NvmRecordArrayExecutionPlan;
typedef enum {
    NVM_RA_ROOT_SCALAR, NVM_RA_ROOT_CONSTANT, NVM_RA_ROOT_LOAD,
    NVM_RA_ROOT_STORE, NVM_RA_ROOT_DUP, NVM_RA_ROOT_SWAP, NVM_RA_ROOT_DROP,
    NVM_RA_ROOT_BRANCH, NVM_RA_ROOT_CALL, NVM_RA_ROOT_RETURN,
    NVM_RA_ROOT_STRING, NVM_RA_ROOT_CONSTRUCT, NVM_RA_ROOT_GET,
    NVM_RA_ROOT_SET, NVM_RA_ROOT_ARRAY_PUSH, NVM_RA_ROOT_ARRAY_POP,
    NVM_RA_ROOT_ARRAY_COPY, NVM_RA_ROOT_TAIL
} NvmRecordArrayRootRecipe;
enum {

    NVM_RA_CHECK_TAGS=1u, NVM_RA_CHECK_BOUNDS=2u, NVM_RA_CHECK_NOMINAL=4u,
    NVM_RA_SAFEPOINT_BEFORE=8u, NVM_RA_STAGE_OPERANDS=16u,
    NVM_RA_RETAIN_BEFORE_RELEASE=32u, NVM_RA_FIRST_ERROR_CLEANUP=64u
};
typedef struct {
    uint32_t functions, instructions, globals, initializer, entry, frame_limit;
    uint32_t strings, sections, metadata, debug, records;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordArrayExecutionCounts;
typedef struct {
    NvmFunctionEntry signature;
    uint32_t instruction_start, instruction_count;
    uint16_t maximum_stack;
    uint8_t parameter_tags_present;
} NvmRecordArrayExecutionFunction;



typedef struct {
    uint32_t function, pc, next_pc, successors[2], callee;
    uint16_t pops, pushes, obligations;
    uint8_t opcode, recipe, successor_count, operand_count;
    uint8_t operand_types[4];
    uint64_t operand_bits[4];
} NvmRecordArrayExecutionInstruction;
typedef struct {
    uint32_t ordinal, layout;
    uint16_t fields;
} NvmRecordArrayExecutionDescriptor;
typedef enum {
    NVM_RA_SNAPSHOT_CODE, NVM_RA_SNAPSHOT_LAYOUTS, NVM_RA_SNAPSHOT_OWNERSHIP,
    NVM_RA_SNAPSHOT_STRING
} NvmRecordArraySnapshotKind;
NvmArrayEligibilityResult nvm_prepare_record_array_execution(
    const NvmModule *, NvmRecordArrayExecutionPlan **);
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *);

# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionInstruction *);

# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordArrayExecutionDescriptor *);

# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *,NvmHeader *);

# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *,uint32_t,NvmSectionEntry *);

# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *,uint32_t,NvmMetadataEntry *);

# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDebugEntry *);

# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *,NvmRecordArrayOriginCounts *);

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordHeapOrigin *);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t *);

# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *,NvmDeclarationCounts *);

# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayType *);

# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *,uint32_t,NvmOrdinaryArrayBinding *);

# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h" 3 4
_Bool 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.h"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 2







enum NvmUnionSiteState { UFS_NOT_REQUIRED, UFS_NOT_ESTABLISHED, UFS_PROVED };
enum NvmUnionSiteOperation {
    UFS_NONE, UFS_RECORD_NEW, UFS_RECORD_PACK, UFS_VARIANT_PACK,
    UFS_RECORD_GET, UFS_PAYLOAD_GET, UFS_RECORD_SET, UFS_TAG, UFS_HALT
};
typedef struct {
    uint32_t function,pc;
    NvmRecordValueOrigins receiver,input,result;
    uint32_t nominal,layout;
    uint16_t member;
    uint8_t variant,operation,state,reserved[3];
} NvmUnionFieldSite;

typedef struct NvmUnionFieldExecutionPlan NvmUnionFieldExecutionPlan;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    NvmUnionFieldSite site;
} NvmUnionFieldExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_union_field_execution(const NvmModule *,NvmUnionFieldExecutionPlan **);
void nvm_union_field_execution_free(NvmUnionFieldExecutionPlan *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_counts(const NvmUnionFieldExecutionPlan *,NvmRecordArrayExecutionCounts *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_instruction(const NvmUnionFieldExecutionPlan *,uint32_t,NvmUnionFieldExecutionInstruction *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_function(const NvmUnionFieldExecutionPlan *,uint32_t,NvmRecordArrayExecutionFunction *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_parameter(const NvmUnionFieldExecutionPlan *,uint32_t,uint16_t,uint8_t *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_header(const NvmUnionFieldExecutionPlan *,NvmHeader *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_size(const NvmUnionFieldExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_bytes(const NvmUnionFieldExecutionPlan *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_proof_counts(const NvmUnionFieldExecutionPlan *,NvmUnionFieldProofCounts *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_origin(const NvmUnionFieldExecutionPlan *,uint32_t,NvmUnionFieldOrigin *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_global(const NvmUnionFieldExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_result(const NvmUnionFieldExecutionPlan *,uint32_t,NvmRecordValueOrigins *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_layout(const NvmUnionFieldExecutionPlan *,uint32_t,NvmDeclarationLayout *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_field(const NvmUnionFieldExecutionPlan *,uint32_t,uint16_t,NvmV2LayoutField *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_variant(const NvmUnionFieldExecutionPlan *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution_private.h"
    nvm_union_field_execution_nominal(const NvmUnionFieldExecutionPlan *,uint8_t,uint32_t,uint32_t *);
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
typedef struct NvmRecordMapFrozenContext NvmRecordMapFrozenContext;
typedef struct {
    uint32_t origins,map_origins,fields,checked_map_operations;
    uint64_t peak_bytes_reserved,work_reserved;
} NvmRecordMapCounts;
NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *,NvmRecordMapFrozenContext **);
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *,NvmRecordMapCounts *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *,uint32_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordHeapOrigin *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_origins.h"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *,uint32_t,NvmRecordValueOrigins *);
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 1




# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4

# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 2




# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
static inline unsigned nvm_portable_file_read_import(const NvmModule *m,uint32_t index) {
    if(!m || index>=m->import_count || !m->imports || !m->import_param_types ||
       !m->strings || !m->string_lengths)return 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                                               0
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                                                    ;
    const NvmImportEntry *imp=&m->imports[index];
    if(imp->module_name_idx>=m->string_count || imp->function_name_idx>=m->string_count ||
       imp->kind!=NVM_IMPORT_FFI || imp->param_count!=1 || (imp->return_type!=TAG_STRING && imp->return_type!=TAG_ARRAY) ||
       !m->import_param_types[index] || m->import_param_types[index][0]!=TAG_STRING ||
       m->string_lengths[imp->module_name_idx])return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                                                     0
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                                                          ;
    const char *name=m->strings[imp->function_name_idx];
    if(!name)return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
                   0
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                        ;
    static const char *const names[]={"file_read","vm_file_read","nl_os_file_read"};
    for(size_t i=0;i<sizeof names/sizeof names[0];i++) {
        size_t n=strlen(names[i]);
        if(imp->return_type==TAG_STRING && m->string_lengths[imp->function_name_idx]==n && !memcmp(name,names[i],n))return 1;
        if(imp->return_type==TAG_ARRAY && m->string_lengths[imp->function_name_idx]==n+6 &&
           !memcmp(name,names[i],n) && !memcmp(name+n,"_bytes",6))return 2;
    }
    return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
          0
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
               ;
}
static inline 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h" 3 4
             _Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/portable_read_catalog.h"
                  nvm_portable_read_import_exact(const NvmModule *m,uint32_t index) {
    return nvm_portable_file_read_import(m,index)==1;
}
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2

# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 85 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) __attribute__ ((__warn_unused_result__));
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) __attribute__ ((__warn_unused_result__));
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) __attribute__ ((__warn_unused_result__));




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) __attribute__ ((__warn_unused_result__));

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));
# 442 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf")

                          __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf")
                         __attribute__ ((__warn_unused_result__));
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) __attribute__ ((__warn_unused_result__));
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
    __attribute__ ((__access__ (__write_only__, 1))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream) __attribute__ ((__warn_unused_result__))
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) __attribute__ ((__warn_unused_result__));






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));





extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern int __sprintf_chk (char *__restrict __s, int __flag, size_t __slen,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));
extern int __vsprintf_chk (char *__restrict __s, int __flag, size_t __slen,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3)));



extern int __snprintf_chk (char *__restrict __s, size_t __n, int __flag,
      size_t __slen, const char *__restrict __format,
      ...) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int __vsnprintf_chk (char *__restrict __s, size_t __n, int __flag,
       size_t __slen, const char *__restrict __format,
       __gnuc_va_list __ap) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 2)));





extern int __fprintf_chk (FILE *__restrict __stream, int __flag,
     const char *__restrict __format, ...)
    __attribute__ ((__nonnull__ (1)));
extern int __printf_chk (int __flag, const char *__restrict __format, ...);
extern int __vfprintf_chk (FILE *__restrict __stream, int __flag,
      const char *__restrict __format,
      __gnuc_va_list __ap) __attribute__ ((__nonnull__ (1)));
extern int __vprintf_chk (int __flag, const char *__restrict __format,
     __gnuc_va_list __ap);


extern int __dprintf_chk (int __fd, int __flag, const char *__restrict __fmt,
     ...) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __vdprintf_chk (int __fd, int __flag,
      const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 3, 0)));




extern int __asprintf_chk (char **__restrict __ptr, int __flag,
      const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4))) __attribute__ ((__warn_unused_result__));
extern int __vasprintf_chk (char **__restrict __ptr, int __flag,
       const char *__restrict __fmt, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0))) __attribute__ ((__warn_unused_result__));
extern int __obstack_printf_chk (struct obstack *__restrict __obstack,
     int __flag, const char *__restrict __format,
     ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int __obstack_vprintf_chk (struct obstack *__restrict __obstack,
      int __flag,
      const char *__restrict __format,
      __gnuc_va_list __args)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 96 "/usr/include/aarch64-linux-gnu/bits/stdio2-decl.h" 3 4
extern char *__fgets_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets called with bigger size than length " "of destination buffer")))
                                 ;

extern char *__fgets_chk (char *__restrict __s, size_t __size, int __n,
     FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));

extern size_t __fread_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread")


            __attribute__ ((__warn_unused_result__));
extern size_t __fread_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread called with bigger size * nmemb than length " "of destination buffer")))
                                 ;

extern size_t __fread_chk (void *__restrict __ptr, size_t __ptrlen,
      size_t __size, size_t __n,
      FILE *__restrict __stream) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));


extern char *__fgets_unlocked_alias (char *__restrict __s, int __n, FILE *__restrict __stream) __asm__ ("" "fgets_unlocked")


    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *__fgets_unlocked_chk_warn (char *__restrict __s, size_t __size, int __n, FILE *__restrict __stream) __asm__ ("" "__fgets_unlocked_chk")


     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fgets_unlocked called with bigger size than length " "of destination buffer")))
                                 ;


extern char *__fgets_unlocked_chk (char *__restrict __s, size_t __size,
       int __n, FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__nonnull__ (4)));




extern size_t __fread_unlocked_alias (void *__restrict __ptr, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "fread_unlocked")


                     __attribute__ ((__warn_unused_result__));
extern size_t __fread_unlocked_chk_warn (void *__restrict __ptr, size_t __ptrlen, size_t __size, size_t __n, FILE *__restrict __stream) __asm__ ("" "__fread_unlocked_chk")




     __attribute__ ((__warn_unused_result__)) __attribute__((__warning__ ("fread_unlocked called with bigger size * nmemb than " "length of destination buffer")))
                                        ;

extern size_t __fread_unlocked_chk (void *__restrict __ptr, size_t __ptrlen,
        size_t __size, size_t __n,
        FILE *__restrict __stream)
    __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (5)));
# 965 "/usr/include/stdio.h" 2 3 4
# 976 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 1 3 4
# 46 "/usr/include/aarch64-linux-gnu/bits/stdio.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
getchar (void)
{
  return getc (stdin);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fgetc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}





extern __inline __attribute__ ((__gnu_inline__)) int
getc_unlocked (FILE *__fp)
{
  return (__builtin_expect (((__fp)->_IO_read_ptr >= (__fp)->_IO_read_end), 0) ? __uflow (__fp) : *(unsigned char *) (__fp)->_IO_read_ptr++);
}


extern __inline __attribute__ ((__gnu_inline__)) int
getchar_unlocked (void)
{
  return (__builtin_expect (((stdin)->_IO_read_ptr >= (stdin)->_IO_read_end), 0) ? __uflow (stdin) : *(unsigned char *) (stdin)->_IO_read_ptr++);
}




extern __inline __attribute__ ((__gnu_inline__)) int
putchar (int __c)
{
  return putc (__c, stdout);
}




extern __inline __attribute__ ((__gnu_inline__)) int
fputc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) int
putc_unlocked (int __c, FILE *__stream)
{
  return (__builtin_expect (((__stream)->_IO_write_ptr >= (__stream)->_IO_write_end), 0) ? __overflow (__stream, (unsigned char) (__c)) : (unsigned char) (*(__stream)->_IO_write_ptr++ = (__c)));
}


extern __inline __attribute__ ((__gnu_inline__)) int
putchar_unlocked (int __c)
{
  return (__builtin_expect (((stdout)->_IO_write_ptr >= (stdout)->_IO_write_end), 0) ? __overflow (stdout, (unsigned char) (__c)) : (unsigned char) (*(stdout)->_IO_write_ptr++ = (__c)));
}





extern __inline __attribute__ ((__gnu_inline__)) __ssize_t
getline (char **__lineptr, size_t *__n, FILE *__stream)
{
  return __getdelim (__lineptr, __n, '\n', __stream);
}





extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) feof_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0010) != 0);
}


extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) ferror_unlocked (FILE *__stream)
{
  return (((__stream)->_flags & 0x0020) != 0);
}
# 977 "/usr/include/stdio.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) sprintf (char *__restrict __s, const char *__restrict __fmt, ...)
{
  return __builtin___sprintf_chk (__s, 3 - 1,
      __builtin_dynamic_object_size (__s, 1), __fmt,
      __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsprintf (char *__restrict __s, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsprintf_chk (__s, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) snprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, ...)

{
  return __builtin___snprintf_chk (__s, __n, 3 - 1,
       __builtin_dynamic_object_size (__s, 1), __fmt,
       __builtin_va_arg_pack ());
}






extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vsnprintf (char *__restrict __s, size_t __n, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __builtin___vsnprintf_chk (__s, __n, 3 - 1,
        __builtin_dynamic_object_size (__s, 1), __fmt, __ap);
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
fprintf (FILE *__restrict __stream, const char *__restrict __fmt, ...)
{
  return __fprintf_chk (__stream, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
printf (const char *__restrict __fmt, ...)
{
  return __printf_chk (3 - 1, __fmt, __builtin_va_arg_pack ());
}







extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vprintf (const char *__restrict __fmt, __gnuc_va_list __ap)
{

  return __vfprintf_chk (stdout, 3 - 1, __fmt, __ap);



}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__nonnull__ (1))) int
vfprintf (FILE *__restrict __stream,
   const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vfprintf_chk (__stream, 3 - 1, __fmt, __ap);
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
dprintf (int __fd, const char *__restrict __fmt, ...)
{
  return __dprintf_chk (__fd, 3 - 1, __fmt,
   __builtin_va_arg_pack ());
}





extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
vdprintf (int __fd, const char *__restrict __fmt, __gnuc_va_list __ap)
{
  return __vdprintf_chk (__fd, 3 - 1, __fmt, __ap);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)
{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) __asprintf (char **__restrict __ptr, const char *__restrict __fmt, ...)

{
  return __asprintf_chk (__ptr, 3 - 1, __fmt,
    __builtin_va_arg_pack ());
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_printf (struct obstack *__restrict __obstack, const char *__restrict __fmt, ...)

{
  return __obstack_printf_chk (__obstack, 3 - 1, __fmt,
          __builtin_va_arg_pack ());
}
# 165 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) vasprintf (char **__restrict __ptr, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __vasprintf_chk (__ptr, 3 - 1, __fmt, __ap);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) obstack_vprintf (struct obstack *__restrict __obstack, const char *__restrict __fmt, __gnuc_va_list __ap)

{
  return __obstack_vprintf_chk (__obstack, 3 - 1, __fmt,
    __ap);
}
# 194 "/usr/include/aarch64-linux-gnu/bits/stdio2.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_chk_warn (__s, sz, __n, __stream);
  return __fgets_chk (__s, sz, __n, __stream);
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread (void *__restrict __ptr, size_t __size, size_t __n,
       FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    return __fread_alias (__ptr, __size, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_chk (__ptr, sz, __size, __n, __stream);
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 1)))
__attribute__ ((__nonnull__ (3))) char *
fgets_unlocked (char *__restrict __s, int __n, FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__s, 1);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char))))) && (((long unsigned int) (__n)) <= ((sz)) / ((sizeof (char)))))))
    return __fgets_unlocked_alias (__s, __n, __stream);
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (__n)) <= (sz) / (sizeof (char)))))
    return __fgets_unlocked_chk_warn (__s, sz, __n, __stream);
  return __fgets_unlocked_chk (__s, sz, __n, __stream);
}




extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__nonnull__ (4))) size_t
fread_unlocked (void *__restrict __ptr, size_t __size, size_t __n,
  FILE *__restrict __stream)
{
  size_t sz = __builtin_dynamic_object_size (__ptr, 0);
  if (((__builtin_constant_p (sz) && (sz) == (long unsigned int) -1) || (((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= ((sz)) / ((__size)))) && (((long unsigned int) (__n)) <= ((sz)) / ((__size))))))
    {

      if (__builtin_constant_p (__size)
   && __builtin_constant_p (__n)
   && (__size | __n) < (((size_t) 1) << (8 * sizeof (size_t) / 2))
   && __size * __n <= 8)
 {
   size_t __cnt = __size * __n;
   char *__cptr = (char *) __ptr;
   if (__cnt == 0)
     return 0;

   for (; __cnt > 0; --__cnt)
     {
       int __c = getc_unlocked (__stream);
       if (__c == (-1))
  break;
       *__cptr++ = __c;
     }
   return (__cptr - (char *) __ptr) / __size;
 }

      return __fread_unlocked_alias (__ptr, __size, __n, __stream);
    }
  if ((((__typeof (__n)) 0 < (__typeof (__n)) -1 || (__builtin_constant_p (__n) && (__n) > 0)) && __builtin_constant_p ((((long unsigned int) (__n)) <= (sz) / (__size))) && !(((long unsigned int) (__n)) <= (sz) / (__size))))
    return __fread_unlocked_chk_warn (__ptr, sz, __size, __n, __stream);
  return __fread_unlocked_chk (__ptr, sz, __size, __n, __stream);

}
# 981 "/usr/include/stdio.h" 2 3 4



# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
typedef struct { uint64_t origins; uint16_t tags; uint8_t unknown,relation_tag; uint16_t relation; } Value;
typedef struct {
    Value *exits;
    uint64_t writes[256u][4];
    uint8_t returned[256u];
} GlobalFlow;
typedef struct {
    VmDecodedFunction decoded;
    Value *states, result;
    uint16_t *depths, stack, locals;
    uint32_t *queue, head, tail, queued_count, stride;
    uint8_t *seen, *queued;
    int16_t *origins;
} Function;
typedef struct {
    const NvmModule *module;
    Function functions[256u];
    Value globals[256u];
    GlobalFlow *global_flow;
    Value children[64u];
    int graph, records, portable_reads;
    NvmRecordPlan *plan;
    Value *fields;
    uint32_t field_count, checked_field_writes;
    uint64_t state_cells;
    uint8_t origin_kind[64u];
    uint32_t record_ordinal[64u], field_start[64u];
    uint16_t record_fields[64u];
    NvmArrayEligibilityReport report;
    NvmArrayEligibilityResult result;
    uint32_t global_count;
    int changed;
    NvmRecordArrayStructure *structure;
    NvmRecordArrayBudget budget;
    uint32_t layout_fields[256];
    uint8_t *field_elements;
    uint8_t *nested_string_fields;
    uint8_t nested_arrays;
    uint16_t required_elements[64u];
    Value all_writes[64u];
} Analysis;

typedef struct {
    NvmMapDeclarationPlan *declarations;
    Value keys[64u],values[64u];
    uint32_t checked;
} NvmRecordMapAnalysisContext;
typedef struct {
    NvmUnionFieldDeclarations *declarations;
    Value payloads[64u];
    uint8_t variant[64u];
} NvmUnionAnalysisContext;
typedef char NvmUnionOriginDistinct[3u!=2u &&
    3u!=NVM_HEAP_ORIGIN_RECORD && 3u!=NVM_HEAP_ORIGIN_ARRAY?1:-1];
typedef char NvmNestedPresenceSizeUnchanged[sizeof(
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                  _Bool
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                      )==sizeof(uint8_t)?1:-1];

enum { FIELD_NESTED_U8=0xf1, FIELD_NESTED_FLOAT=0xf2, FIELD_NESTED_BOOL=0xf3, FIELD_DEPTH3_FIRST=0xf4 };
enum { NESTED_PRESENT=1, NESTED_U8=2, NESTED_FLOAT=4, NESTED_BOOL=8, NESTED_DEPTH3=16, NESTED_DEPTH3_STRING=32 };





static void *allocate(size_t n, size_t width) {
    if (width && n > 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                    (18446744073709551615UL) 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                             / width) return 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                             ((void *)0)
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                 ;




    return calloc(n, width);
}
static void *analysis_alloc(Analysis *a,size_t n,size_t width) {
    if(width && n>
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                 (18446744073709551615UL)
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                         /width){if(a->structure)a->budget.limited=
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                   1
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                       ;return 
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                               ((void *)0)
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                   ;}
    if(a->structure && (!nvm_ra_bytes(&a->budget,(uint64_t)n*width) || !nvm_ra_steps(&a->budget,n)))return 
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                          ((void *)0)
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                              ;
    void *p=allocate(n,width);if(!p && a->structure)a->budget.memory=
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                    1
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                        ;return p;
}
void nvm_record_eligibility_free(NvmRecordEligibilityReport *report) {
    if (report) { free(report->fields); free(report); }
}
void nvm_array_eligibility_free(NvmArrayEligibilityReport *report) { free(report); }
void nvm_array_graph_eligibility_free(NvmArrayGraphEligibilityReport *report) { free(report); }
static Value tag(uint8_t t) { Value v = {.tags=((uint16_t)(1u << (t)))}; return v; }


static int merge(Value *to, const Value *from) {
    Value old = *to;
    to->tags |= from->tags; to->origins |= from->origins; to->unknown |= from->unknown;
    return old.tags != to->tags || old.origins != to->origins || old.unknown != to->unknown;
}
static int stop(Analysis *a, NvmArrayEligibilityStatus status, uint32_t f, uint32_t pc, const char *message) {
    if(a->structure && a->budget.limited)status=NVM_ARRAY_LIMIT;
    a->result.status = status; a->result.function = f; a->result.pc = pc;
    snprintf(a->result.message, sizeof a->result.message, "%.*s", (int)sizeof a->result.message - 1, message);
    return 0;
}
static int analysis_work(Analysis *a,uint64_t n) {
    if(!a->structure || nvm_ra_steps(&a->budget,n))return 1;
    return stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my record-array work bound.");
}
static int verified(Analysis *a, NvmVerifyResult result) {
    if (result.ok) return 1;
    return stop(a, strstr(result.error_msg, "allocat") || strstr(result.error_msg, "memory") ?
                NVM_ARRAY_MEMORY : NVM_ARRAY_INVALID, 0, 0, result.error_msg);
}
static Value global_plain(Value value) { value.relation=0;value.relation_tag=0;return value; }
static int global_merge(Value *to,const Value *from) {
    Value old=*to;
    if(!to->tags && !to->origins && !to->unknown) {
        to->relation=from->relation;to->relation_tag=from->relation_tag;
    } else if((from->tags || from->origins || from->unknown) &&
              (to->relation!=from->relation || to->relation_tag!=from->relation_tag)) {
        to->relation=0;to->relation_tag=0;
    }
    return merge(to,from) || old.relation!=to->relation || old.relation_tag!=to->relation_tag;
}
static Value *global_values(Function *f,Value *state) { return state+f->locals+f->stack; }
static int global_invalidates(Analysis *a,Function *f,Value *state,uint32_t slot) {
    if(!analysis_work(a,f->stride))return 0;
    for(uint32_t i=0;i<f->stride;i++)if(state[i].relation==slot+1 || state[i].relation==256u +slot+1) {
        state[i].relation=0;state[i].relation_tag=0;
    }
    return 1;
}





static int tail_prepare(Analysis *a) {
    if(!a->structure)return 1;
    uint32_t count=a->module->function_count;
    uint64_t (*reach)[4]=analysis_alloc(a,count,sizeof *reach);
    if(!reach)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate my tail call graph.");
    int ok=0;
    for(uint32_t fi=0;fi<count;fi++) {
        const VmDecodedFunction *f=&a->structure->decoded[fi];
        for(uint32_t i=0;i<f->instruction_count;i++) {
            if(!analysis_work(a,1))goto done;
            const DecodedInstruction *in=&f->instructions[i].instruction;
            if(in->opcode!=OP_CALL && in->opcode!=OP_TAIL_CALL)continue;
            uint32_t target=in->operands[0].u32;
            if(target>=count){stop(a,NVM_ARRAY_INVALID,fi,0,"I require a closed direct tail graph.");goto done;}
            reach[fi][target/64]|=1UL<<(target%64);
        }
    }
    for(uint32_t via=0;via<count;via++)for(uint32_t from=0;from<count;from++) {
        if(!analysis_work(a,5))goto done;
        if(reach[from][via/64]&(1UL<<(via%64)))
            for(unsigned word=0;word<4;word++)reach[from][word]|=reach[via][word];
    }
    for(uint32_t fi=0;fi<count;fi++) {
        const VmDecodedFunction *f=&a->structure->decoded[fi];
        for(uint32_t i=0;i<f->instruction_count;i++) {
            if(!analysis_work(a,1))goto done;
            const DecodedInstruction *in=&f->instructions[i].instruction;
            if(in->opcode!=OP_TAIL_CALL)continue;
            uint32_t target=in->operands[0].u32;
            if(target==fi) {


                for(uint32_t other=0;other<count;other++) {
                    if(!analysis_work(a,1))goto done;
                    if(other!=fi && (reach[fi][other/64]&(1UL<<(other%64))) &&
                       (reach[other][fi/64]&(1UL<<(fi%64)))) {
                        stop(a,NVM_ARRAY_UNRESOLVED,fi,f->instructions[i].byte_offset,
                             "I require a singleton self-tail component.");goto done;
                    }
                }
                for(uint32_t j=0;j<f->instruction_count;j++) {
                    if(!analysis_work(a,1))goto done;
                    const DecodedInstruction *call=&f->instructions[j].instruction;
                    if(call->opcode==OP_CALL && call->operands[0].u32==fi) {
                        stop(a,NVM_ARRAY_UNRESOLVED,fi,f->instructions[j].byte_offset,
                             "I refuse ordinary self CALL in a self-tail component.");goto done;
                    }
                }
            } else if(reach[target][fi/64]&(1UL<<(fi%64))) {
                stop(a,NVM_ARRAY_UNRESOLVED,fi,f->instructions[i].byte_offset,
                     "I require an acyclic direct tail edge.");goto done;
            }
        }
    }
    ok=1;
done:
    free(reach);return ok;
}
static int global_prepare(Analysis *a) {
    if(!a->structure)return 1;
    int tails=0;
    if(!analysis_work(a,sizeof *a->global_flow))return 0;
    a->global_flow=analysis_alloc(a,1,sizeof *a->global_flow);
    if(!a->global_flow)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate private global flow.");
    for(uint32_t fi=0;fi<a->module->function_count;fi++) {
        const VmDecodedFunction *f=&a->structure->decoded[fi];
        for(uint32_t i=0;i<f->instruction_count;i++) {
            if(!analysis_work(a,2))return 0;
            const DecodedInstruction *in=&f->instructions[i].instruction;
            tails|=in->opcode==OP_TAIL_CALL;
            if(in->opcode!=OP_LOAD_GLOBAL && in->opcode!=OP_STORE_GLOBAL)continue;
            uint32_t slot=in->operands[0].u32;
            if(slot>=256u)return stop(a,NVM_ARRAY_LIMIT,fi,f->instructions[i].byte_offset,"I reached my global flow slot bound.");
            if(a->global_count<=slot)a->global_count=slot+1;
            if(in->opcode==OP_STORE_GLOBAL)a->global_flow->writes[fi][slot/64]|=1UL<<(slot%64);
        }
    }
    if(tails && !tail_prepare(a))return 0;
    uint64_t cells=(uint64_t)a->global_count*a->module->function_count;
    if(cells>1048576u -a->state_cells)return stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my global exit cell bound.");
    a->state_cells+=cells;
    if(cells) {
        a->global_flow->exits=analysis_alloc(a,(size_t)cells,sizeof(Value));
        if(!a->global_flow->exits)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate global exits.");
    }


    if(!nvm_ra_bytes(&a->budget,3u*256u*3u*sizeof(Value)))
        return stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my global scratch peak bound.");
    int changed;
    do {
        changed=0;
        for(uint32_t fi=0;fi<a->module->function_count;fi++) {
            const VmDecodedFunction *f=&a->structure->decoded[fi];
            for(uint32_t i=0;i<f->instruction_count;i++) {
                if(!analysis_work(a,1))return 0;
                const DecodedInstruction *in=&f->instructions[i].instruction;
                if(in->opcode!=OP_CALL && in->opcode!=OP_TAIL_CALL)continue;
                uint32_t target=in->operands[0].u32;
                if(target>=a->module->function_count)return stop(a,NVM_ARRAY_INVALID,fi,0,"I require a closed global-flow call.");
                if(!analysis_work(a,4))return 0;
                for(unsigned word=0;word<4;word++) {
                    uint64_t old=a->global_flow->writes[fi][word];
                    a->global_flow->writes[fi][word]|=a->global_flow->writes[target][word];
                    changed|=old!=a->global_flow->writes[fi][word];
                }
            }
        }
    } while(changed);
    return 1;
}
static int global_return(Analysis *a,uint32_t fi,Value *state) {
    if(!a->global_flow)return 1;
    if(!analysis_work(a,a->global_count+1))return 0;
    if(!a->global_flow->returned[fi]){a->global_flow->returned[fi]=1;a->changed=1;}
    Value *values=global_values(&a->functions[fi],state);
    for(uint32_t slot=0;slot<a->global_count;slot++)
        a->changed|=merge(&a->global_flow->exits[(size_t)fi*a->global_count+slot],&values[slot]);
    return 1;
}


static int global_refine_context(Analysis *a,Function *f,Value *state,Value condition,int truth,int *reachable,NvmRecordMapAnalysisContext *maps,NvmUnionAnalysisContext *unions) {
    *reachable=1;
    if(!a->global_flow || condition.relation<=256u || condition.relation>256u +a->global_count)return 1;
    uint32_t slot=condition.relation-256u -1;Value *value=&global_values(f,state)[slot];
    if(value->unknown)return 1;
    if(!analysis_work(a,64u +2))return 0;
    if(condition.relation_tag>=16){if(truth)*reachable=0;return 1;}
    uint16_t bit=((uint16_t)(1u << (condition.relation_tag)));
    value->tags=truth?(value->tags&bit):(value->tags&~bit);
    if(!value->tags){*reachable=0;return 1;}
    uint64_t origins=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if((value->origins&(1UL<<i)) &&
        ((a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY && (value->tags&((uint16_t)(1u << (TAG_ARRAY))))) ||
         (a->origin_kind[i]==NVM_HEAP_ORIGIN_RECORD && (value->tags&((uint16_t)(1u << (TAG_STRUCT))))) ||
         (maps && a->origin_kind[i]==2u && (value->tags&((uint16_t)(1u << (TAG_HASHMAP))))) ||
         (unions && a->origin_kind[i]==3u && (value->tags&((uint16_t)(1u << (TAG_UNION)))))))origins|=1UL<<i;
    value->origins=origins;return 1;
}
static int global_refine_map(Analysis *a,Function *f,Value *state,Value condition,int truth,int *reachable,NvmRecordMapAnalysisContext *maps) {
    return global_refine_context(a,f,state,condition,truth,reachable,maps,
# 299 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                         ((void *)0)
# 299 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                             );
}
static int global_refine(Analysis *a,Function *f,Value *state,Value condition,int truth,int *reachable) {
    return global_refine_map(a,f,state,condition,truth,reachable,
# 302 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                ((void *)0)
# 302 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                    );
}
static void enqueue(Function *f, uint32_t pc) {
    if (f->queued[pc]) return;
    uint32_t capacity = f->decoded.instruction_count + 1;
    f->queue[f->tail] = pc; f->tail = (f->tail + 1) % capacity;
    f->queued[pc] = 1; f->queued_count++;
}
static int join(Analysis *a, uint32_t fi, uint32_t pc, Value *state, uint16_t depth) {
    Function *f = &a->functions[fi];
    if(!analysis_work(a,(uint64_t)f->locals+depth+1+(a->global_flow?a->global_count:0)))return 0;
    if (pc > f->decoded.instruction_count || depth > f->stack)
        return stop(a,NVM_ARRAY_INVALID,fi,pc,"I require bounded abstract stack successors.");
    int changed = !f->seen[pc];
    if (f->seen[pc] && f->depths[pc] != depth)
        return stop(a,NVM_ARRAY_INVALID,fi,pc,"I require equal stack heights at joins.");
    f->seen[pc] = 1; f->depths[pc] = depth;
    Value *target = f->states + (size_t)pc * f->stride;
    for (uint32_t i=0;i<(uint32_t)f->locals+depth;i++)
        changed |= a->global_flow?global_merge(&target[i],&state[i]):merge(&target[i],&state[i]);
    if(a->global_flow)for(uint32_t slot=0;slot<a->global_count;slot++)
        changed|=global_merge(&global_values(f,target)[slot],&global_values(f,state)[slot]);
    if (changed) { a->changed = 1; enqueue(f,pc); }
    return 1;
}
static int seed(Analysis *a,uint32_t fi,const Value *args,const Value *globals) {
    Function *f=&a->functions[fi]; Value state[a->global_flow?256u*3:256u*2];memset(state,0,sizeof state);
    if(!analysis_work(a,a->global_flow?256u*3u:256u*2u))return 0;
    if(a->global_flow)for(uint32_t slot=0;slot<a->global_count;slot++)
        global_values(f,state)[slot]=global_plain(globals[slot]);
    for(uint16_t i=0;i<f->locals;i++) state[i]=tag(TAG_VOID);
    for(uint16_t i=0;i<a->module->functions[fi].arity;i++) state[i]=a->global_flow?global_plain(args[i]):args[i];
    return join(a,fi,0,state,0);
}

static int fixed_result(uint8_t op) {
    switch(op) {
    case OP_PUSH_I64: case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL:
    case OP_F64_TO_BITS: case OP_I64_DIV_S: case OP_I64_REM_S: case OP_I64_NEG: case OP_CAST_INT:
    case OP_STR_LEN: case OP_STR_CHAR_AT: case OP_ARR_LEN: return TAG_INT;
    case OP_PUSH_U8: case OP_CAST_U8: return TAG_U8;
    case OP_PUSH_F64: case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL:
    case OP_F64_FROM_BITS: case OP_F64_DIV: case OP_F64_NEG: case OP_CAST_FLOAT: return TAG_FLOAT;
    case OP_PUSH_BOOL: case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S: case OP_I64_GT_S: case OP_I64_GE_S:
    case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
    case OP_BOOL_AND: case OP_BOOL_OR: case OP_BOOL_NOT: case OP_AND: case OP_OR: case OP_NOT:
    case OP_CAST_BOOL: case OP_TYPE_CHECK: case OP_STR_EQ: case OP_STR_CONTAINS:
    case OP_STR_STARTS_WITH: case OP_STR_ENDS_WITH: return TAG_BOOL;
    case OP_PUSH_STR: case OP_CAST_STRING: case OP_STR_CONCAT: case OP_STR_SUBSTR:
    case OP_STR_TRIM: case OP_STR_TO_LOWER: case OP_STR_TO_UPPER: case OP_STR_REPLACE:
    case OP_STR_FROM_INT: case OP_STR_FROM_FLOAT: return TAG_STRING;
    case OP_ENUM_VAL: return TAG_ENUM;
    case OP_PUSH_VOID: return TAG_VOID;
    default: return -1;
    }
}
static int record_operation(uint8_t op) {
    return op == OP_STRUCT_NEW || op == OP_STRUCT_LITERAL || op == OP_STRUCT_GET ||
           op == OP_STRUCT_SET || op == OP_AGG_PACK || op == OP_AGG_GET || op == OP_AGG_SET;
}
static int supported(uint8_t op) {
    if(fixed_result(op)>=0)return 1;
    switch(op) {
    case OP_NOP: case OP_DUP: case OP_POP: case OP_SWAP:
    case OP_LOAD_LOCAL: case OP_STORE_LOCAL: case OP_LOAD_GLOBAL: case OP_STORE_GLOBAL:
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE: case OP_CALL: case OP_RET: case OP_ASSERT:
    case OP_ARR_LITERAL: case OP_ARR_SLICE: case OP_ARR_NEW: case OP_ARR_PUSH: case OP_ARR_SET: case OP_ARR_GET: case OP_ARR_POP: case OP_STR_SPLIT:
        return 1;
    default:return 0;
    }
}

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
    nvm_record_array_opcode_supported(uint8_t op) {
    return op!=OP_ENUM_VAL && (supported(op) || record_operation(op) || op==OP_TAIL_CALL);
}
static uint16_t record_field_element(const Analysis *,uint32_t);
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_analysis.inc" 1

static int map_declarations_exact(Analysis *a,NvmRecordMapAnalysisContext *maps,uint8_t *value_out) {
    NvmMapDeclarationCounts counts;
    if(!analysis_work(a,1u) ||
       !nvm_map_declarations_counts(maps->declarations,&counts))
        return stop(a,NVM_ARRAY_INVALID,0,0,"I require copied map counts.");
    if(counts.pairs!=1)return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require one exact STRING-keyed declaration pair.");
    for(uint32_t i=0;i<counts.pairs;i++) {
        NvmMapDeclarationPair pair;uint8_t key,value;
        if(!analysis_work(a,3u*1u))return 0;
        if(!nvm_map_declarations_pair(maps->declarations,i,&pair) ||
           !nvm_map_declarations_scalar(maps->declarations,pair.key_type,&key) ||
           !nvm_map_declarations_scalar(maps->declarations,pair.value_type,&value))
            return stop(a,NVM_ARRAY_INVALID,0,0,"I require exact map pair referents.");
        if(key!=TAG_STRING || (value!=TAG_INT && value!=TAG_STRING))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I prove only exact STRING-to-INT or STRING-to-STRING maps.");
        *value_out=value;
    }
    return 1;
}
static int map_receiver(Analysis *a,NvmRecordMapAnalysisContext *maps,
                        uint32_t fn,uint32_t pc,Value receiver) {
    if(!maps || receiver.unknown || receiver.tags!=((uint16_t)(1u << (TAG_HASHMAP))) || !receiver.origins)
        return stop(a,NVM_ARRAY_UNRESOLVED,fn,pc,"I require exact known map origins.");
    if(!analysis_work(a,64u))return 0;
    uint64_t known=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(receiver.origins&(1UL<<i)) {
        if(a->origin_kind[i]!=2u)
            return stop(a,NVM_ARRAY_UNRESOLVED,fn,pc,"I refuse non-map receiver origins.");
        known|=1UL<<i;
    }
    if(known!=receiver.origins)return stop(a,NVM_ARRAY_UNRESOLVED,fn,pc,"I refuse unknown map origin bits.");
    return 1;
}
static int map_exact_scalar(Analysis *a,uint32_t fn,uint32_t pc,Value value,uint8_t expected) {
    if(value.unknown || value.origins || value.tags!=((uint16_t)(1u << (expected))))
        return stop(a,NVM_ARRAY_UNRESOLVED,fn,pc,"I require exact map key/value scalar tags.");
    return 1;
}
static int map_operation(Analysis *a,NvmRecordMapAnalysisContext *maps,uint32_t fn,
                         const VmDecodedInstruction *d,const Value *stack,uint16_t depth,uint8_t value_tag) {
    uint8_t op=d->instruction.opcode;
    if(op==OP_HM_NEW)return 1;

    unsigned pops=op==OP_HM_SET?3u:op==OP_HM_LEN?1u:2u;
    if(depth<pops)return stop(a,NVM_ARRAY_INVALID,fn,d->byte_offset,"I require the verified map stack effect.");
    unsigned base=depth-pops;
    if(!map_receiver(a,maps,fn,d->byte_offset,stack[base]))return 0;
    if(op!=OP_HM_LEN && !map_exact_scalar(a,fn,d->byte_offset,stack[base+1],TAG_STRING))return 0;
    if(op==OP_HM_SET && !map_exact_scalar(a,fn,d->byte_offset,stack[base+2],value_tag))return 0;
    maps->checked++;return 1;
}
static int map_final(Analysis *a,NvmRecordMapAnalysisContext *maps,uint8_t value_tag) {
    if(!analysis_work(a,64u*2u+a->global_count))return 0;
    for(uint32_t i=0;i<a->global_count;i++)if(a->globals[i].tags&((uint16_t)(1u << (TAG_HASHMAP))))
        return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I keep standalone map globals outside this field profile.");
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==2u) {
        Value key=maps->keys[i],value=maps->values[i];
        if(key.unknown || value.unknown || key.origins || value.origins ||
           (key.tags&~((uint16_t)(1u << (TAG_STRING)))) || (value.tags&~((uint16_t)(1u << (value_tag)))))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require every historical map write to preserve its exact pair.");
    }
    return 1;
}
# 379 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 1
struct NvmRecordArrayOrigins {
    NvmOwnershipDeclarationPlan *declarations;
    NvmRecordEligibilityReport *origins;
    uint16_t required[64u];
    NvmRecordArrayOriginCounts counts;
};
static int publish_records(Analysis *,NvmRecordEligibilityReport **);
static int ra_prepare_records(Analysis *a,NvmRecordMapAnalysisContext *maps) {
    NvmDeclarationCounts counts;
    if(!nvm_ownership_declarations_counts(a->structure->declarations,&counts) || counts.layouts>256)
        return stop(a,NVM_ARRAY_INVALID,0,0,"I require complete declaration counts.");
    a->plan=analysis_alloc(a,1,sizeof *a->plan);
    if(!a->plan)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate copied record maps.");
    NvmRecordPlan *p=a->plan;
    p->layouts.items=analysis_alloc(a,counts.layouts?counts.layouts:1,sizeof *p->layouts.items);
    p->record_to_layout=analysis_alloc(a,counts.layouts?counts.layouts:1,sizeof *p->record_to_layout);
    p->layout_to_record=analysis_alloc(a,counts.layouts?counts.layouts:1,sizeof *p->layout_to_record);
    if(!p->layouts.items || !p->record_to_layout || !p->layout_to_record)
        return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate copied layout maps.");
    p->layouts.count=counts.layouts;p->authority=NVM_RECORD_AUTHORITY_ORDINARY;
    uint32_t fields=0;
    for(uint32_t i=0;i<counts.layouts;i++) {
        NvmDeclarationLayout row;
        if(!nvm_ownership_declarations_layout(a->structure->declarations,i,&row))
            return stop(a,NVM_ARRAY_INVALID,0,0,"I require a copied declaration row.");
        if(!analysis_work(a,(uint64_t)row.fields*4u+1))return 0;
        a->layout_fields[i]=fields;
        if(row.fields>65536u-fields)return stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my copied field bound.");
        fields+=row.fields;p->layout_to_record[i]=0xFFFFFFFFu;
        if(row.kind==NVM_V2_LAYOUT_STRUCT) {
            p->layout_to_record[i]=p->record_count;p->record_to_layout[p->record_count++]=i;
            if(row.flags!=1u)return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require complete ordinary records.");
        } else if(row.kind!=NVM_V2_LAYOUT_UNION || row.flags)
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require validated ordinary records and scalar union declarations.");
        NvmV2Layout *layout=&p->layouts.items[i];layout->kind=row.kind;layout->name_idx=row.name;
        if(row.fields) {
            layout->fields=analysis_alloc(a,row.fields,sizeof *layout->fields);
            if(!layout->fields)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy declaration fields.");
        }
        layout->field_count=row.fields;
        for(uint16_t j=0;j<row.fields;j++)
            if(!nvm_ownership_declarations_field(a->structure->declarations,i,j,&layout->fields[j]))
                return stop(a,NVM_ARRAY_INVALID,0,0,"I require each copied field fact.");
    }
    if(p->record_count!=a->module->struct_count)
        return stop(a,NVM_ARRAY_INVALID,0,0,"I require the original nominal record count.");
    a->field_elements=analysis_alloc(a,fields?fields:1,sizeof *a->field_elements);
    if(!a->field_elements)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy field element constraints.");
    if(!analysis_work(a,(uint64_t)counts.bindings*4u+fields))return 0;
    for(uint32_t i=0;i<counts.bindings;i++) {
        NvmOrdinaryArrayBinding binding;NvmOrdinaryArrayType element;
        if(!nvm_ownership_declarations_binding(a->structure->declarations,i,&binding) ||
           !nvm_ownership_declarations_type(a->structure->declarations,binding.element_type,&element) ||
           binding.layout>=p->layouts.count || binding.field>=p->layouts.items[binding.layout].field_count)
            return stop(a,NVM_ARRAY_INVALID,0,0,"I require exact copied array bindings.");
        if(element.tag==TAG_ARRAY) {
            NvmOrdinaryArrayType child;
            if(!nvm_ownership_declarations_type(a->structure->declarations,element.referent,&child))
                return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact nested primitive element authority.");
            if(child.tag==TAG_ARRAY) {
                if(!analysis_work(a,1))return 0;
                NvmOrdinaryArrayType leaf;
                if(!nvm_ownership_declarations_type(a->structure->declarations,child.referent,&leaf) ||
                   leaf.tag<TAG_INT || leaf.tag>TAG_STRING || leaf.referent!=0xFFFFFFFFu)
                    return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact depth-three primitive authority.");
                a->nested_arrays|=NESTED_PRESENT|NESTED_DEPTH3;
                if(leaf.tag==TAG_U8)a->nested_arrays|=NESTED_U8;
                if(leaf.tag==TAG_FLOAT)a->nested_arrays|=NESTED_FLOAT;
                if(leaf.tag==TAG_BOOL)a->nested_arrays|=NESTED_BOOL;
                if(leaf.tag==TAG_STRING)a->nested_arrays|=NESTED_DEPTH3_STRING;
                a->field_elements[a->layout_fields[binding.layout]+binding.field]=
                    (uint8_t)(FIELD_DEPTH3_FIRST+leaf.tag-TAG_INT);
                continue;
            }
            if(child.tag<TAG_INT || child.tag>TAG_STRING || child.referent!=0xFFFFFFFFu)
                return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact nested primitive element authority.");
            a->nested_arrays|=NESTED_PRESENT;
            if(child.tag==TAG_U8 || child.tag==TAG_FLOAT || child.tag==TAG_BOOL) {
                uint32_t field=a->layout_fields[binding.layout]+binding.field;
                a->field_elements[field]=child.tag==TAG_U8?FIELD_NESTED_U8:
                    child.tag==TAG_FLOAT?FIELD_NESTED_FLOAT:FIELD_NESTED_BOOL;
                a->nested_arrays|=child.tag==TAG_U8?NESTED_U8:
                    child.tag==TAG_FLOAT?NESTED_FLOAT:NESTED_BOOL;
                continue;
            }
            if(child.tag==TAG_STRING) {
                if(!a->nested_string_fields) {
                    size_t bytes=(fields+7u)/8u;
                    a->nested_string_fields=analysis_alloc(a,bytes,1);
                    if(!a->nested_string_fields)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy nested STRING field constraints.");
                    if(!analysis_work(a,bytes))return 0;
                }
                uint32_t field=a->layout_fields[binding.layout]+binding.field;
                a->nested_string_fields[field/8]|=(uint8_t)(1u<<(field%8));
                continue;
            }
        } else if(element.referent!=0xFFFFFFFFu || !(element.tag==TAG_INT || element.tag==TAG_U8 ||
             element.tag==TAG_FLOAT || element.tag==TAG_BOOL || element.tag==TAG_STRING))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact bounded field element tags.");
        a->field_elements[a->layout_fields[binding.layout]+binding.field]=((uint16_t)(1u << (element.tag)));
    }
    for(uint32_t i=0;i<p->layouts.count;i++) {
        NvmV2Layout *layout=&p->layouts.items[i];
        if(layout->kind!=NVM_V2_LAYOUT_STRUCT)continue;
        for(uint16_t j=0;j<layout->field_count;j++) {
            uint8_t tag=layout->fields[j].type_tag;
            if(tag==TAG_ARRAY) {
                if(!record_field_element(a,a->layout_fields[i]+j))
                    return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require every array field binding.");
            } else if(!(tag==TAG_INT || tag==TAG_U8 || tag==TAG_FLOAT || tag==TAG_BOOL || tag==TAG_STRING || tag==TAG_STRUCT || (maps && tag==TAG_HASHMAP)))
                return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require the bounded ordinary record field schema.");
        }
    }
    return 1;
}

static uint16_t ra_child_domain(uint16_t domain) {
    uint16_t out=0;
    for(uint8_t depth=2;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
        if(domain&nvm_record_array_requirement(depth,leaf))out|=nvm_record_array_requirement((uint8_t)(depth-1),leaf);
    return out;
}
static uint16_t ra_parent_domain(uint16_t parents,uint16_t children) {
    uint16_t out=0;
    for(uint8_t depth=2;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++) {
        uint16_t shape=nvm_record_array_requirement(depth,leaf);
        if((parents&shape) && (children&nvm_record_array_requirement((uint8_t)(depth-1),leaf)))out|=shape;
    }
    return out;
}
static int ra_check_depth_three(Analysis *a) {
    int result=0;uint64_t converted_children=0;
    uint16_t *domains=analysis_alloc(a,64u,sizeof *domains);
    if(!domains)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate bounded depth-three shape domains.");
    if(!analysis_work(a,64u*16u))goto done;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        uint8_t declared=a->report.origins[i].declared_tag;
        Value content=a->children[i];merge(&content,&a->all_writes[i]);
        if(content.unknown)goto invalid;
        if(declared==TAG_ARRAY) {
            if((content.tags&~((uint16_t)(1u << (TAG_ARRAY)))) || (content.tags && !content.origins))goto invalid;
            for(uint8_t depth=2;depth<=3;depth++)for(uint8_t leaf=TAG_INT;leaf<=TAG_STRING;leaf++)
                domains[i]|=nvm_record_array_requirement(depth,leaf);
        } else {
            if(declared<TAG_INT || declared>TAG_STRING || content.origins ||
               (content.tags&~(((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING))))))goto invalid;
            domains[i]=((uint16_t)(1u << (declared)));
        }
        if(a->required_elements[i]) {
            if(!nvm_record_array_requirement_depth(a->required_elements[i]))goto invalid;
            domains[i]&=a->required_elements[i];
        }
        if(!domains[i])goto invalid;
    }


    for(uint32_t round=0;round<=64u*16u;round++) {
        
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
       _Bool 
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
            changed=
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                    0
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                         ;
        for(uint32_t i=0;i<a->report.origin_count;i++) {
            if(!analysis_work(a,1))goto done;
            if(a->origin_kind[i]!=NVM_HEAP_ORIGIN_ARRAY || a->report.origins[i].declared_tag!=TAG_ARRAY)continue;
            Value content=a->children[i];merge(&content,&a->all_writes[i]);
            for(uint32_t j=0;j<a->report.origin_count;j++) {
                if(!analysis_work(a,1))goto done;
                if(!(content.origins&(1UL<<j)))continue;
                if(!analysis_work(a,32))goto done;
                if(a->origin_kind[j]!=NVM_HEAP_ORIGIN_ARRAY)goto invalid;
                uint16_t parent=ra_parent_domain(domains[i],domains[j]);
                uint16_t child=(uint16_t)(domains[j]&ra_child_domain(parent));
                if(!parent || !child)goto invalid;
                if(parent!=domains[i]){domains[i]=parent;changed=
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                                1
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                                    ;}
                if(child!=domains[j]){domains[j]=child;changed=
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                              1
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                                  ;}
                if(a->required_elements[i]) {
                    uint16_t required=ra_child_domain(a->required_elements[i]);
                    if(!nvm_record_array_requirement_depth(required) || !(domains[j]&required) ||
                       (a->required_elements[j] && a->required_elements[j]!=required))goto invalid;
                    if(!a->required_elements[j]){a->required_elements[j]=required;changed=
# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                                                         1
# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                                                             ;}
                    if(domains[j]!=required){domains[j]=required;changed=
# 178 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                                        1
# 178 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                                            ;}
                    if(a->required_elements[i]==((uint16_t)(1u << 9)))converted_children|=1UL<<j;
                }
            }
        }
        if(!changed)break;
        if(round==64u*16u){stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my depth-three closure bound.");goto done;}
    }
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        if(!analysis_work(a,16))goto done;
        uint8_t declared=a->report.origins[i].declared_tag;
        Value writes=a->all_writes[i],children=a->children[i];
        uint16_t allowed=declared==TAG_ARRAY?((uint16_t)(1u << (TAG_ARRAY))):(((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING))));
        if(writes.unknown || children.unknown || (writes.tags&~allowed) ||
           (children.tags&~allowed) || (a->report.origins[i].child_tags&~allowed))goto invalid;
        uint16_t required=a->required_elements[i];
        if(required) {
            uint8_t depth=nvm_record_array_requirement_depth(required);
            if(!depth)goto invalid;
            uint16_t expected=depth>1?((uint16_t)(1u << (TAG_ARRAY))):required;
            uint16_t accepted=(uint16_t)(expected|((converted_children&(1UL<<i))?((uint16_t)(1u << (TAG_INT))):0));
            if(expected!=((uint16_t)(1u << (declared))) || (writes.tags&~accepted))goto invalid;
        }
    }
    result=1;goto done;
invalid:
    stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require acyclic exact depth-three primitive origins and every historical write.");
done:
    free(domains);return result;
}



static int ra_check_constraints(Analysis *a) {
    if(a->nested_arrays&NESTED_DEPTH3)return ra_check_depth_three(a);
    uint64_t converted_children=0;
    if(!analysis_work(a,64u*16u))return 0;
    if(a->nested_arrays && !analysis_work(a,64u*64u*4u))return 0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY &&
        a->report.origins[i].declared_tag==TAG_ARRAY) {
        Value content=a->children[i];merge(&content,&a->all_writes[i]);
        if(content.unknown || (content.tags&~((uint16_t)(1u << (TAG_ARRAY)))) ||
           (content.tags && !content.origins))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require proved nested array children.");
        uint16_t requirement=a->required_elements[i];
        uint8_t leaf=nvm_record_array_requirement_leaf(requirement);
        for(uint32_t j=0;j<a->report.origin_count;j++)if(content.origins&(1UL<<j)) {
            uint8_t child=a->report.origins[j].declared_tag;
            if(a->origin_kind[j]!=NVM_HEAP_ORIGIN_ARRAY ||
               (child!=TAG_INT && !(a->nested_string_fields && child==TAG_STRING) &&
                !(child==TAG_U8 && (a->nested_arrays&NESTED_U8)) &&
                !(child==TAG_FLOAT && (a->nested_arrays&NESTED_FLOAT)) &&
                !(child==TAG_BOOL && (a->nested_arrays&NESTED_BOOL))) ||
               (leaf!=TAG_VOID && child!=leaf))
                return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require each nested child to preserve its exact primitive leaf.");
            if(requirement==((uint16_t)(1u << 9)))
                converted_children|=1UL<<j;
            leaf=child;a->required_elements[j]|=((uint16_t)(1u << (child)));
        }
    }
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        Value writes=a->all_writes[i],children=a->children[i];
        uint8_t declared=a->report.origins[i].declared_tag;
        uint16_t allowed=declared==TAG_ARRAY?((uint16_t)(1u << (TAG_ARRAY))):(((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING))));
        if(!(allowed&((uint16_t)(1u << (declared)))) || writes.unknown || children.unknown ||
           (declared!=TAG_ARRAY && (writes.origins || children.origins)) ||
           (writes.tags&~allowed) || (children.tags&~allowed) ||
           (a->report.origins[i].child_tags&~allowed))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact flat or bounded depth-two array content.");
        uint16_t expected=nvm_record_array_requirement_leaf(a->required_elements[i])!=TAG_VOID?((uint16_t)(1u << (TAG_ARRAY))):a->required_elements[i];

        uint16_t accepted_writes=expected | ((converted_children&(1UL<<i))?((uint16_t)(1u << (TAG_INT))):0);
        if(expected && (expected!=((uint16_t)(1u << (declared))) || (writes.tags&~accepted_writes)))
            return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require every aliased array write to preserve its exact field element type.");
    }
    return 1;
}
static int ra_publish(Analysis *a,NvmRecordArrayOrigins **out) {
    NvmRecordArrayOrigins *p=analysis_alloc(a,1,sizeof *p);
    if(!p)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate the origin report.");
    if(!analysis_work(a,(uint64_t)a->field_count+64u*2u) || !publish_records(a,&p->origins)) {free(p);return 0;}
    memcpy(p->required,a->required_elements,sizeof p->required);
    p->counts=(NvmRecordArrayOriginCounts){p->origins->origin_count,p->origins->field_value_count,
        p->origins->checked_field_writes,p->origins->checked_array_writes,p->origins->runtime_tag_checks,
        a->budget.work,a->budget.peak};
    p->declarations=a->structure->declarations;a->structure->declarations=
# 263 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                                         ((void *)0)
# 263 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                                             ;
    *out=p;return 1;
}
void nvm_record_array_origins_free(NvmRecordArrayOrigins *p) {
    if(!p)return;
    nvm_ownership_declarations_free(p->declarations);nvm_record_eligibility_free(p->origins);free(p);
}

# 270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_origins_counts(const NvmRecordArrayOrigins *p,NvmRecordArrayOriginCounts *out) {
    if(!p||!out)return 
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                      0
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                           ;
    *out=p->counts;return 
# 272 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                         1
# 272 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                             ;
}

# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_origin(const NvmRecordArrayOrigins *p,uint32_t i,NvmRecordHeapOrigin *out) {
    if(!p||!out||i>=p->origins->origin_count)return 
# 275 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                   0
# 275 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                        ;
    *out=p->origins->origins[i];return 
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                      1
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                          ;
}

# 278 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 278 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_field_value(const NvmRecordArrayOrigins *p,uint32_t i,NvmRecordValueOrigins *out) {
    if(!p||!out||i>=p->origins->field_value_count)return 
# 279 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                        0
# 279 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                             ;
    *out=p->origins->fields[i];return 
# 280 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                     1
# 280 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                         ;
}

# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_required_elements(const NvmRecordArrayOrigins *p,uint32_t i,uint16_t *out) {
    if(!p||!out||i>=p->origins->origin_count)return 
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                                                   0
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                                        ;
    *out=p->required[i];return 
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
                              1
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
                                  ;
}

# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_counts(const NvmRecordArrayOrigins *p,NvmDeclarationCounts *out) {
    return p && nvm_ownership_declarations_counts(p->declarations,out);
}

# 289 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 289 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_layout(const NvmRecordArrayOrigins *p,uint32_t i,NvmDeclarationLayout *out) {
    return p && nvm_ownership_declarations_layout(p->declarations,i,out);
}

# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_field(const NvmRecordArrayOrigins *p,uint32_t i,uint16_t f,NvmV2LayoutField *out) {
    return p && nvm_ownership_declarations_field(p->declarations,i,f,out);
}

# 295 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 295 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_type(const NvmRecordArrayOrigins *p,uint32_t i,NvmOrdinaryArrayType *out) {
    return p && nvm_ownership_declarations_type(p->declarations,i,out);
}

# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_binding(const NvmRecordArrayOrigins *p,uint32_t i,NvmOrdinaryArrayBinding *out) {
    return p && nvm_ownership_declarations_binding(p->declarations,i,out);
}

# 301 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc" 3 4
_Bool 
# 301 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_origins.inc"
    nvm_record_array_declaration_variant(const NvmRecordArrayOrigins *p,uint32_t i,uint16_t v,NvmUnionVariantFact *out) {
    return p && nvm_ownership_declarations_variant(p->declarations,i,v,out);
}
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
static int packed(uint8_t t) { return t==TAG_INT || t==TAG_U8 || t==TAG_FLOAT || t==TAG_BOOL; }
static uint16_t writes(uint8_t t) {
    return ((uint16_t)(1u << (t))) | (t==TAG_INT?((uint16_t)(1u << (TAG_U8))):t==TAG_U8 || t==TAG_FLOAT?((uint16_t)(1u << (TAG_INT))):0);
}
static Value read_array(Analysis *a,Value receiver) {
    Value result=tag(TAG_VOID);
    if(!analysis_work(a,64u*4u))return result;
    result.unknown=receiver.unknown || ((receiver.tags&((uint16_t)(1u << (TAG_ARRAY)))) && !receiver.origins);
    for(uint32_t i=0;i<a->report.origin_count;i++) if((receiver.origins&(1UL<<i)) && a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        NvmArrayOrigin *o=&a->report.origins[i];
        result.tags |= o->packed?((uint16_t)(1u << (o->declared_tag))):o->child_tags;
        if(a->graph && !o->packed)merge(&result,&a->children[i]);
    }
    return result;
}
static void write_array(Analysis *a,Value receiver,Value value) {
    if(!analysis_work(a,64u*4u))return;
    for(uint32_t i=0;i<a->report.origin_count;i++) if((receiver.origins&(1UL<<i)) && a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        NvmArrayOrigin *o=&a->report.origins[i];
        if(a->structure)a->changed|=merge(&a->all_writes[i],&value);
        if(!o->packed) {
            uint16_t old=o->child_tags;o->child_tags|=value.tags;
            a->changed |= old!=o->child_tags;
            if(a->graph)a->changed |= merge(&a->children[i],&value);
        }
    }
}

static int slice_origins(Analysis *a,uint32_t fi,uint32_t pc,Value receiver,Value *result) {
    if(!analysis_work(a,64u*(64u +8u)))return 0;
    *result=tag(TAG_ARRAY);
    result->unknown=receiver.unknown || ((receiver.tags&((uint16_t)(1u << (TAG_ARRAY)))) && !receiver.origins);



    if(a->graph && !receiver.origins && !receiver.unknown && !(receiver.tags&((uint16_t)(1u << (TAG_ARRAY)))))
        *result=(Value){0};
    for(uint32_t i=0;i<a->report.origin_count;i++)if((receiver.origins&(1UL<<i)) && a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        NvmArrayOrigin source=a->report.origins[i];
        uint32_t target=0;
        while(target<a->report.origin_count) {
            NvmArrayOrigin *o=&a->report.origins[target];
            if(a->origin_kind[target]==NVM_HEAP_ORIGIN_ARRAY && o->function==fi && o->pc==pc && o->declared_tag==source.declared_tag)break;
            target++;
        }
        if(target==a->report.origin_count) {
            if(target==64u)return stop(a,NVM_ARRAY_LIMIT,fi,pc,"I reached my derived array origin limit.");
            a->report.origin_count++;
            a->report.origins[target]=(NvmArrayOrigin){fi,pc,0,source.declared_tag,source.packed};
            a->changed=1;
        }
        NvmArrayOrigin *o=&a->report.origins[target];
        uint16_t old=o->child_tags;o->child_tags|=source.child_tags;
        a->changed|=old!=o->child_tags;
        if(a->graph && !o->packed)a->changed|=merge(&a->children[target],&a->children[i]);
        result->origins|=1UL<<target;
    }
    return 1;
}
static int check_write(Analysis *a,uint32_t fi,uint32_t pc,Value receiver,Value value) {
    if(!analysis_work(a,64u*4u))return 0;
    a->report.checked_writes++;
    uint16_t allowed=a->structure?((((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING))))|(a->nested_arrays?((uint16_t)(1u << (TAG_ARRAY))):0)):(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING)))|((uint16_t)(1u << (TAG_ENUM))))|(a->graph?((uint16_t)(1u << (TAG_ARRAY))):0);
    if(value.unknown || !value.tags || (value.tags&~allowed))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,a->graph && !a->structure?
            "I require proved scalar/string/array graph writes.":"I require proved scalar/string leaf writes.");
    if(a->graph && (value.tags&((uint16_t)(1u << (TAG_ARRAY)))) && !value.origins)
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require authoritative child array origins.");
    for(uint32_t i=0;i<a->report.origin_count;i++)if((receiver.origins&(1UL<<i)) && a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY) {
        NvmArrayOrigin *o=&a->report.origins[i];
        if(o->packed && (value.tags&~writes(o->declared_tag)))
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I cannot prove a portable packed write for every possible tag.");
    }
    return 1;
}


static int prepare_records(Analysis *a,NvmRecordMapAnalysisContext *maps) {
    if(a->structure)return ra_prepare_records(a,maps);
    NvmRecordPlanResult result=nvm_describe_managed_records(a->module,&a->plan);
    if(result.status!=NVM_RECORD_DESCRIBED) {
        NvmArrayEligibilityStatus status=result.status==NVM_RECORD_MEMORY?NVM_ARRAY_MEMORY:
            result.status==NVM_RECORD_LIMIT?NVM_ARRAY_LIMIT:
            result.status==NVM_RECORD_INVALID?NVM_ARRAY_INVALID:NVM_ARRAY_UNRESOLVED;
        return stop(a,status,0,0,result.message);
    }
    if(a->plan->authority!=NVM_RECORD_AUTHORITY_ORDINARY)
        return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require explicit ordinary record authority.");
    
# 468 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
   _Bool 
# 468 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
        requires_verifier=
# 468 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                          0
# 468 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                               ;
    if(nvm_ownership_contracts_validate(a->module,&requires_verifier)!=NVM_V2_OK || requires_verifier)
        return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require ordinary declarations without affine/reference execution.");
    for(uint32_t i=0;i<a->plan->record_count;i++) {
        const NvmV2Layout *layout=&a->plan->layouts.items[a->plan->record_to_layout[i]];
        for(uint16_t j=0;j<layout->field_count;j++) {
            const NvmV2LayoutField *field=&layout->fields[j];
            if(field->type_tag!=TAG_STRUCT && !((((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING)))|((uint16_t)(1u << (TAG_ENUM))))&((uint16_t)(1u << (field->type_tag)))))
                return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require the bounded scalar/string/acyclic-record field schema.");
        }
    }
    return 1;
}
static int record_site(Analysis *a,uint32_t fi,uint32_t pc) {
    Function *f=&a->functions[fi];VmDecodedInstruction *d=&f->decoded.instructions[pc];
    const DecodedInstruction *in=&d->instruction;uint8_t op=in->opcode;
    if(op==OP_AGG_PACK && (in->operands[0].u8!=AGG_RECORD || in->operands[2].u16))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require neutral-variant record construction.");
    uint32_t record=in->operands[op==OP_AGG_PACK?1:0].u32;
    if(record>=a->plan->record_count)
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require an authoritative record ordinal.");
    const NvmV2Layout *layout=&a->plan->layouts.items[a->plan->record_to_layout[record]];
    uint16_t count=op==OP_STRUCT_NEW?0:in->operands[op==OP_AGG_PACK?3:1].u16;
    if(count!=layout->field_count)
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require the actual constructed field count to match its record.");
    if(a->report.origin_count==64u || count>65536u -a->field_count ||
       a->state_cells+(uint64_t)a->field_count+count>1048576u)
        return stop(a,NVM_ARRAY_LIMIT,fi,d->byte_offset,"I reached my record origin or field-summary limit.");
    uint32_t origin=a->report.origin_count++;f->origins[pc]=(int16_t)origin;
    a->origin_kind[origin]=NVM_HEAP_ORIGIN_RECORD;
    a->record_ordinal[origin]=record;a->record_fields[origin]=count;
    a->field_start[origin]=a->field_count;a->field_count+=count;
    a->report.origins[origin]=(NvmArrayOrigin){fi,d->byte_offset,0,TAG_STRUCT,0};
    return 1;
}
static uint64_t origins_of_kind(const Analysis *a,Value value,uint8_t kind) {
    uint64_t found=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)
        if((value.origins&(1UL<<i)) && a->origin_kind[i]==kind)found|=1UL<<i;
    return found;
}
static void write_record(Analysis *a,Value receiver,uint16_t field,Value value) {
    if(!analysis_work(a,64u*4u))return;
    uint64_t origins=origins_of_kind(a,receiver,NVM_HEAP_ORIGIN_RECORD);
    for(uint32_t i=0;i<a->report.origin_count;i++)if(origins&(1UL<<i)) {

        if(field<a->record_fields[i])a->changed|=merge(&a->fields[a->field_start[i]+field],&value);
    }
}
static Value read_record(Analysis *a,Value receiver,uint16_t field) {
    Value result={0};
    if(!analysis_work(a,64u*4u))return result;
    uint64_t origins=origins_of_kind(a,receiver,NVM_HEAP_ORIGIN_RECORD);
    result.unknown=receiver.unknown || ((receiver.tags&((uint16_t)(1u << (TAG_STRUCT)))) && !origins);
    for(uint32_t i=0;i<a->report.origin_count;i++)if(origins&(1UL<<i))
        if(field<a->record_fields[i])merge(&result,&a->fields[a->field_start[i]+field]);
    return result;
}
static uint16_t record_field_element(const Analysis *a,uint32_t field) {
    if(a->nested_string_fields && (a->nested_string_fields[field/8]&(1u<<(field%8))))
        return ((uint16_t)(1u << 8));
    if(a->field_elements[field]>=FIELD_DEPTH3_FIRST && a->field_elements[field]<FIELD_DEPTH3_FIRST+5)
        return nvm_record_array_requirement(3,(uint8_t)(TAG_INT+a->field_elements[field]-FIELD_DEPTH3_FIRST));
    switch(a->field_elements[field]) {
    case FIELD_NESTED_U8:return ((uint16_t)(1u << 9));
    case FIELD_NESTED_FLOAT:return ((uint16_t)(1u << 10));
    case FIELD_NESTED_BOOL:return ((uint16_t)(1u << 11));
    default:return a->field_elements[field];
    }
}
static int record_value_matches(Analysis *a,uint32_t fi,uint32_t pc,
                                const NvmV2LayoutField *field,Value value,uint16_t element,NvmRecordMapAnalysisContext *maps) {
    if(!analysis_work(a,64u*4u))return 0;
    a->checked_field_writes++;
    if(value.unknown || value.tags!=((uint16_t)(1u << (field->type_tag))))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require exact known field-write tags.");
    if(a->structure && field->type_tag==TAG_ARRAY) {
        uint64_t origins=origins_of_kind(a,value,NVM_HEAP_ORIGIN_ARRAY);
        if(!nvm_record_array_requirement_depth(element) || !origins || origins!=value.origins)
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require complete field array origins and element identity.");
        for(uint32_t i=0;i<a->report.origin_count;i++)if(origins&(1UL<<i)) {
            NvmArrayOrigin *origin=&a->report.origins[i];
            if((nvm_record_array_requirement_leaf(element)!=TAG_VOID ? ((uint16_t)(1u << (TAG_ARRAY))) : element)!=((uint16_t)(1u << (origin->declared_tag))))
                return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require the exact field element contract.");
            a->required_elements[i]|=element;
            if(a->required_elements[i]!=element)
                return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I refuse conflicting field element constraints.");
        }
    }
    if(field->type_tag==TAG_HASHMAP && !map_receiver(a,maps,fi,pc,value))return 0;
    if(field->type_tag==TAG_STRUCT) {
        uint64_t origins=origins_of_kind(a,value,NVM_HEAP_ORIGIN_RECORD);
        if(!origins || origins!=value.origins)
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require authoritative nested record origins.");
        for(uint32_t i=0;i<a->report.origin_count;i++)if(origins&(1UL<<i))
            if(a->plan->record_to_layout[a->record_ordinal[i]]!=field->nested_idx)
                return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require the exact nested nominal identity for every field write.");
    }
    return 1;
}
static int check_record_access(Analysis *a,uint32_t fi,uint32_t pc,
                               Value receiver,uint16_t field,const Value *write,NvmRecordMapAnalysisContext *maps) {
    if(!analysis_work(a,64u*4u))return 0;
    uint64_t origins=origins_of_kind(a,receiver,NVM_HEAP_ORIGIN_RECORD);
    if(receiver.unknown || !receiver.tags || ((receiver.tags&((uint16_t)(1u << (TAG_STRUCT)))) && !origins))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require authoritative record receiver origins.");
    if(receiver.tags!=((uint16_t)(1u << (TAG_STRUCT))))a->report.runtime_tag_checks++;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(origins&(1UL<<i)) {
        if(field>=a->record_fields[i])
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require a valid field in every possible record receiver.");
        const NvmV2Layout *layout=&a->plan->layouts.items[a->plan->record_to_layout[a->record_ordinal[i]]];
        if(write && !record_value_matches(a,fi,pc,&layout->fields[field],*write,
            a->structure?record_field_element(a,a->layout_fields[a->plan->record_to_layout[a->record_ordinal[i]]]+field):0,maps))return 0;
    }
    return 1;
}
static int publish_records(Analysis *a,NvmRecordEligibilityReport **out) {
    NvmRecordEligibilityReport *report=analysis_alloc(a,1,sizeof *report);
    if(!report)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not publish my record analysis report.");
    if(a->field_count) {
        report->fields=analysis_alloc(a,a->field_count,sizeof *report->fields);
        if(!report->fields) {
            nvm_record_eligibility_free(report);
            return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not publish my record field summaries.");
        }
    }
    report->origin_count=a->report.origin_count;report->field_value_count=a->field_count;
    report->checked_field_writes=a->checked_field_writes;
    report->checked_array_writes=a->report.checked_writes;
    report->runtime_tag_checks=a->report.runtime_tag_checks;
    for(uint32_t i=0;i<a->report.origin_count;i++) {
        NvmArrayOrigin *source=&a->report.origins[i];NvmRecordHeapOrigin *origin=&report->origins[i];
        origin->function=source->function;origin->pc=source->pc;origin->kind=a->origin_kind[i];
        origin->record_ordinal=origin->layout_index=0xFFFFFFFFu;
        origin->declared_tag=source->declared_tag;origin->packed=source->packed;
        if(origin->kind==NVM_HEAP_ORIGIN_RECORD) {
            origin->record_ordinal=a->record_ordinal[i];
            origin->layout_index=a->plan->record_to_layout[origin->record_ordinal];
            origin->field_start=a->field_start[i];origin->field_count=a->record_fields[i];
        } else {
            origin->children=(NvmRecordValueOrigins){a->children[i].origins,source->child_tags,a->children[i].unknown};
        }
    }
    for(uint32_t i=0;i<a->field_count;i++)
        report->fields[i]=(NvmRecordValueOrigins){a->fields[i].origins,a->fields[i].tags,a->fields[i].unknown};
    *out=report;return 1;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 1

struct NvmUnionFieldProof {
    NvmUnionFieldDeclarations *declarations;
    NvmUnionFieldOrigin *origins;
    NvmRecordValueOrigins *globals,*results;
    uint16_t *stacks;
    NvmUnionFieldProofCounts counts;
};
void nvm_union_field_proof_free(NvmUnionFieldProof *p) {
    if(!p)return;
    nvm_union_field_declarations_free(p->declarations);
    free(p->origins);free(p->globals);free(p->results);free(p->stacks);free(p);
}

# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
    nvm_union_field_proof_counts(const NvmUnionFieldProof *p,NvmUnionFieldProofCounts *out) {
    if(!p || !out)return 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                        0
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                             ;
    *out=p->counts;return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                         1
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                             ;
}






# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
nvm_union_field_proof_origin(const NvmUnionFieldProof *p,uint32_t i,NvmUnionFieldOrigin *out) { if(!p || !out || i>=p->counts.origins)return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
0
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; *out=p->origins[i];return 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
1
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; }

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
nvm_union_field_proof_global(const NvmUnionFieldProof *p,uint32_t i,NvmRecordValueOrigins *out) { if(!p || !out || i>=p->counts.globals)return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
0
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; *out=p->globals[i];return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
1
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; }

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
nvm_union_field_proof_result(const NvmUnionFieldProof *p,uint32_t i,NvmRecordValueOrigins *out) { if(!p || !out || i>=p->counts.functions)return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
0
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; *out=p->results[i];return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
1
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; }

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
nvm_union_field_proof_stack(const NvmUnionFieldProof *p,uint32_t i,uint16_t *out) { if(!p || !out || i>=p->counts.functions)return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
0
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; *out=p->stacks[i];return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
1
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
; }


# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
    nvm_union_field_proof_layout(const NvmUnionFieldProof *p,uint32_t i,NvmDeclarationLayout *out) {
    return p && nvm_union_field_declarations_layout(p->declarations,i,out);
}

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
    nvm_union_field_proof_field(const NvmUnionFieldProof *p,uint32_t i,uint16_t j,NvmV2LayoutField *out) {
    return p && nvm_union_field_declarations_field(p->declarations,i,j,out);
}

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
    nvm_union_field_proof_variant(const NvmUnionFieldProof *p,uint32_t i,uint16_t j,NvmUnionVariantFact *out) {
    return p && nvm_union_field_declarations_variant(p->declarations,i,j,out);
}

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
    nvm_union_field_proof_nominal(const NvmUnionFieldProof *p,uint8_t tag,uint32_t i,uint32_t *out) {
    return p && nvm_union_field_declarations_nominal(p->declarations,tag,i,out);
}
static int uf_prepare_records(Analysis *a,NvmUnionAnalysisContext *u) {
    a->plan=analysis_alloc(a,1,sizeof *a->plan);
    if(!a->plan)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy union record mappings.");
    NvmRecordPlan *p=a->plan;
    p->layouts.items=analysis_alloc(a,2,sizeof *p->layouts.items);
    p->record_to_layout=analysis_alloc(a,1,sizeof *p->record_to_layout);
    p->layout_to_record=analysis_alloc(a,2,sizeof *p->layout_to_record);
    if(!p->layouts.items || !p->record_to_layout || !p->layout_to_record)
        return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy union layout mappings.");
    p->layouts.count=2;p->record_count=1;p->authority=NVM_RECORD_AUTHORITY_ORDINARY;
    if(!analysis_work(a,4))return 0;
    if(!nvm_union_field_declarations_nominal(u->declarations,TAG_STRUCT,0,&p->record_to_layout[0]))
        return stop(a,NVM_ARRAY_INVALID,0,0,"I require an exact copied record nominal.");
    for(uint32_t i=0;i<2;i++) {
        NvmDeclarationLayout row;
        if(!analysis_work(a,8))return 0;
        if(!nvm_union_field_declarations_layout(u->declarations,i,&row) || row.fields!=1)
            return stop(a,NVM_ARRAY_INVALID,0,0,"I require the exact union-field layout rows.");
        p->layout_to_record[i]=i==p->record_to_layout[0]?0:0xFFFFFFFFu;
        NvmV2Layout *l=&p->layouts.items[i];l->kind=row.kind;l->name_idx=row.name;
        l->fields=analysis_alloc(a,1,sizeof *l->fields);
        if(!l->fields)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy a union layout field.");
        l->field_count=1;
        if(!nvm_union_field_declarations_field(u->declarations,i,0,l->fields))
            return stop(a,NVM_ARRAY_INVALID,0,0,"I require a copied union field.");
    }
    return 1;
}
static int uf_site(Analysis *a,NvmUnionAnalysisContext *u,uint32_t fi,uint32_t pc) {
    Function *f=&a->functions[fi];VmDecodedInstruction *d=&f->decoded.instructions[pc];
    DecodedInstruction *in=&d->instruction;
    if(in->opcode!=OP_AGG_PACK || in->operands[0].u8!=AGG_VARIANT)
        return record_site(a,fi,pc);
    NvmUnionVariantFact v;uint32_t layout;
    if(!analysis_work(a,8))return 0;
    if(!nvm_union_field_declarations_nominal(u->declarations,TAG_UNION,in->operands[1].u32,&layout) ||
       !nvm_union_field_declarations_variant(u->declarations,in->operands[1].u32,in->operands[2].u16,&v) ||
       v.layout!=layout || v.field_count!=in->operands[3].u16)
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require an exact nominal variant construction.");
    if(a->report.origin_count==64u)
        return stop(a,NVM_ARRAY_LIMIT,fi,d->byte_offset,"I reached my shared union origin bound.");
    uint32_t o=a->report.origin_count++;f->origins[pc]=(int16_t)o;
    a->origin_kind[o]=3u;a->record_ordinal[o]=in->operands[1].u32;
    a->record_fields[o]=v.field_count;u->variant[o]=(uint8_t)in->operands[2].u16;
    a->report.origins[o]=(NvmArrayOrigin){fi,d->byte_offset,0,TAG_UNION,0};
    return 1;
}

static int uf_value(Analysis *a,Value v,uint8_t expected,uint32_t fi,uint32_t pc) {
    if(!analysis_work(a,64u +1))return 0;
    if(v.unknown || v.tags!=((uint16_t)(1u << (expected))))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require exact known union-field value tags.");
    if(expected!=TAG_STRUCT && expected!=TAG_UNION) {
        if(v.origins)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I refuse scalar heap origins.");
        return 1;
    }
    uint8_t kind=expected==TAG_STRUCT?NVM_HEAP_ORIGIN_RECORD:3u;
    uint64_t matched=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(v.origins&(1UL<<i)) {
        if(a->origin_kind[i]!=kind || a->record_ordinal[i]!=0)
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require exact union-field nominal origins.");
        matched|=1UL<<i;
    }
    if(!matched || matched!=v.origins)
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require complete union-field origins.");
    return 1;
}


static int uf_access(Analysis *a,NvmUnionAnalysisContext *u,Value receiver,
                     uint16_t field,int writing,Value value,uint32_t fi,uint32_t pc,
                     int final,Value *result) {
    if(receiver.unknown || !receiver.tags || !receiver.origins) {
        if(final)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I cannot resolve this reachable union-field receiver.");
        return 2;
    }
    if(receiver.tags==((uint16_t)(1u << (TAG_STRUCT)))) {
        if(!uf_value(a,receiver,TAG_STRUCT,fi,pc))return 0;
        if(field)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require the exact containing record field.");
        if(writing) {
            if(value.unknown || !value.tags || !value.origins) {
                if(final)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I cannot resolve this historical union write.");
                return 2;
            }
            if(!uf_value(a,value,TAG_UNION,fi,pc))return 0;
            if(!final)write_record(a,receiver,field,value);
            *result=receiver;
        } else *result=read_record(a,receiver,field);
    } else {
        if(!uf_value(a,receiver,TAG_UNION,fi,pc))return 0;
        if(writing)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I have not qualified union payload mutation.");
        if(field)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require the sole INT payload field.");
        if(!analysis_work(a,64u))return 0;
        *result=(Value){0};
        for(uint32_t i=0;i<a->report.origin_count;i++)if(receiver.origins&(1UL<<i)) {
            if(a->record_fields[i]!=1)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I refuse an empty variant at payload access.");
            merge(result,&u->payloads[i]);
        }
    }
    if(result->unknown || !result->tags || (!result->origins && result->tags==((uint16_t)(1u << (TAG_UNION))))) {
        if(final)return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I cannot resolve this reachable union-field result.");
        return 2;
    }
    return !a->budget.limited;
}
static int uf_operation(Analysis *a,NvmUnionAnalysisContext *u,uint32_t fi,uint32_t pc) {
    Function *f=&a->functions[fi];VmDecodedInstruction *d=&f->decoded.instructions[pc];
    DecodedInstruction *in=&d->instruction;uint8_t op=in->opcode;
    Value *stack=f->states+(size_t)pc*f->stride+f->locals;uint16_t depth=f->depths[pc];
    if(op==OP_AGG_TAG)return uf_value(a,stack[depth-1],TAG_UNION,fi,d->byte_offset);
    if(op==OP_STRUCT_NEW || op==OP_STRUCT_LITERAL || op==OP_AGG_PACK) {
        uint32_t o=(uint32_t)f->origins[pc];uint16_t n=a->record_fields[o];
        if(n && !uf_value(a,stack[depth-n],a->origin_kind[o]==3u?TAG_INT:TAG_UNION,fi,d->byte_offset))return 0;
        return 1;
    }
    int writing=op==OP_STRUCT_SET || op==OP_AGG_SET;Value result={0};
    return uf_access(a,u,stack[depth-(writing?2:1)],in->operands[0].u16,writing,
                     writing?stack[depth-1]:(Value){0},fi,d->byte_offset,1,&result)==1;
}
static int uf_summary(Analysis *a,Value v,uint32_t fi,uint32_t pc) {
    if(!analysis_work(a,64u +1))return 0;
    uint16_t allowed=(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING)))|((uint16_t)(1u << (TAG_ENUM))))|((uint16_t)(1u << (TAG_STRUCT)))|((uint16_t)(1u << (TAG_UNION)));
    if(v.unknown || !v.tags || (v.tags&~allowed))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require complete bounded historical union summaries.");
    uint64_t valid=0;uint16_t heap_tags=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(v.origins&(1UL<<i)) {
        uint16_t bit=a->origin_kind[i]==NVM_HEAP_ORIGIN_RECORD?((uint16_t)(1u << (TAG_STRUCT))):
            a->origin_kind[i]==3u?((uint16_t)(1u << (TAG_UNION))):0;
        if(!bit || !(v.tags&bit))return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require matching historical union origin kinds.");
        valid|=1UL<<i;heap_tags|=bit;
    }
    if(valid!=v.origins || heap_tags!=(v.tags&(((uint16_t)(1u << (TAG_STRUCT)))|((uint16_t)(1u << (TAG_UNION))))))
        return stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I require every historical heap tag to have exact origins.");
    return 1;
}
static NvmRecordValueOrigins uf_copy_value(Value v) {
    NvmRecordValueOrigins out={0};out.tags=v.tags;out.origins=v.origins;return out;
}

typedef struct { NvmUnionFieldSite *rows;uint32_t count,reserved; } NvmUnionFieldSiteExport;
static int uf_outputs_overlap(const void *a,size_t an,const void *b,size_t bn) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    return x<=y?y-x<an:x-y<bn;
}
static int uf_sensitive(uint8_t op) { return record_operation(op) || op==OP_AGG_TAG || op==OP_HALT; }
static uint8_t uf_site_operation(const DecodedInstruction *in) {
    switch(in->opcode) {
    case OP_STRUCT_NEW:return UFS_RECORD_NEW;
    case OP_STRUCT_LITERAL:return UFS_RECORD_PACK;
    case OP_AGG_PACK:return in->operands[0].u8==AGG_VARIANT?UFS_VARIANT_PACK:UFS_RECORD_PACK;
    case OP_STRUCT_GET:return UFS_RECORD_GET;
    case OP_STRUCT_SET:case OP_AGG_SET:return UFS_RECORD_SET;
    case OP_AGG_TAG:return UFS_TAG;
    case OP_HALT:return UFS_HALT;
    default:return UFS_NONE;
    }
}
static int uf_export_sites(Analysis *a,NvmUnionAnalysisContext *u,NvmUnionFieldSiteExport *out) {
    uint32_t count=0;
    if(!analysis_work(a,a->module->function_count))return 0;
    for(uint32_t fi=0;fi<a->module->function_count;fi++) {
        uint32_t n=a->functions[fi].decoded.instruction_count;
        if(n>65536u-count)return stop(a,NVM_ARRAY_LIMIT,fi,0,"I reached the union site count bound.");
        count+=n;
    }
    if(!analysis_work(a,(uint64_t)count*512u))return 0;
    NvmUnionFieldSite *rows=count?analysis_alloc(a,count,sizeof *rows):
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                                                      ((void *)0)
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                                          ;
    if(count && !rows)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy final union sites.");
    uint32_t index=0;
    for(uint32_t fi=0;fi<a->module->function_count;fi++) {
        Function *f=&a->functions[fi];
        for(uint32_t pc=0;pc<f->decoded.instruction_count;pc++,index++) {
            VmDecodedInstruction *d=&f->decoded.instructions[pc];DecodedInstruction *in=&d->instruction;
            NvmUnionFieldSite *r=&rows[index];r->function=fi;r->pc=d->byte_offset;
            r->nominal=r->layout=
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                (4294967295U)
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                          ;r->member=
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                                     (65535)
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                               ;r->variant=
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                                                           (255)
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                                                    ;
            if(!uf_sensitive(in->opcode))continue;
            r->state=UFS_NOT_ESTABLISHED;r->operation=uf_site_operation(in);
            if(!f->seen[pc])continue;
            r->state=UFS_PROVED;
            if(in->opcode==OP_HALT)continue;
            Value receiver={0},input={0},result={0};uint16_t depth=f->depths[pc];
            Value *stack=f->states+(size_t)pc*f->stride+f->locals;
            uint8_t nominal_tag=TAG_VOID;
            if(in->opcode==OP_STRUCT_NEW || in->opcode==OP_STRUCT_LITERAL || in->opcode==OP_AGG_PACK) {
                int32_t o=f->origins[pc];
                if(o<0 || (uint32_t)o>=a->report.origin_count)goto invalid;
                r->member=a->record_fields[o];r->nominal=a->record_ordinal[o];
                nominal_tag=a->origin_kind[o]==3u?TAG_UNION:TAG_STRUCT;
                if(r->member>1 || depth<r->member)goto invalid;
                if(r->member)input=stack[depth-r->member];
                result=tag(nominal_tag);result.origins=1UL<<o;
                if(nominal_tag==TAG_UNION)r->variant=u->variant[o];
            } else if(in->opcode==OP_AGG_TAG) {
                if(!depth)goto invalid;
                receiver=stack[depth-1];result=tag(TAG_INT);nominal_tag=TAG_UNION;r->nominal=0;
            } else {
                int writing=in->opcode==OP_STRUCT_SET || in->opcode==OP_AGG_SET;
                if(depth<(writing?2:1))goto invalid;
                receiver=stack[depth-(writing?2:1)];if(writing)input=stack[depth-1];
                if(uf_access(a,u,receiver,in->operands[0].u16,writing,input,fi,d->byte_offset,1,&result)!=1)goto fail;
                r->member=in->operands[0].u16;r->nominal=0;
                nominal_tag=receiver.tags==((uint16_t)(1u << (TAG_STRUCT)))?TAG_STRUCT:TAG_UNION;
                r->operation=writing?UFS_RECORD_SET:nominal_tag==TAG_STRUCT?UFS_RECORD_GET:UFS_PAYLOAD_GET;
                if(nominal_tag==TAG_UNION) {
                    for(uint32_t j=0;j<a->report.origin_count;j++)if(receiver.origins&(1UL<<j)) {
                        if(r->variant!=
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                      (255) 
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                && r->variant!=u->variant[j])goto invalid;
                        r->variant=u->variant[j];
                    }
                }
            }

            if((receiver.tags && !uf_summary(a,receiver,fi,d->byte_offset)) ||
               (input.tags && !uf_summary(a,input,fi,d->byte_offset)) ||
               !uf_summary(a,result,fi,d->byte_offset))goto fail;
            if(!analysis_work(a,4))goto fail;
            if(!nvm_union_field_declarations_nominal(u->declarations,nominal_tag,r->nominal,&r->layout))goto invalid;
            r->receiver=uf_copy_value(receiver);r->input=uf_copy_value(input);r->result=uf_copy_value(result);
        }
    }
    *out=(NvmUnionFieldSiteExport){rows,count,0};return 1;
invalid:
    stop(a,NVM_ARRAY_INVALID,0,0,"I require exact final union site correspondence.");
fail:
    free(rows);return 0;
}
static int uf_freeze(Analysis *a,NvmUnionAnalysisContext *u,NvmUnionFieldProof **out) {
    uint32_t origins=a->report.origin_count,globals=a->global_count,functions=a->module->function_count;
    if(!analysis_work(a,origins+globals+functions))return 0;

    for(uint32_t i=0;i<origins;i++) {
        Value v;
        if(a->origin_kind[i]==NVM_HEAP_ORIGIN_RECORD) {
            v=a->fields[a->field_start[i]];
            if(!uf_value(a,v,TAG_UNION,a->report.origins[i].function,a->report.origins[i].pc))return 0;
        } else if(a->origin_kind[i]==3u) {
            if(a->record_fields[i] && !uf_value(a,u->payloads[i],TAG_INT,a->report.origins[i].function,a->report.origins[i].pc))return 0;
        } else return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I have not qualified other heap origins with union fields.");
    }
    for(uint32_t i=0;i<globals;i++)if(!uf_summary(a,a->globals[i],0,0))return 0;
    for(uint32_t i=0;i<functions;i++)
        if(a->module->functions[i].result_count && !uf_summary(a,a->functions[i].result,i,0))return 0;
    NvmUnionFieldProof *p=analysis_alloc(a,1,sizeof *p);
    if(!p)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate copied union proof.");
    if(origins)p->origins=analysis_alloc(a,origins,sizeof *p->origins);
    if(globals)p->globals=analysis_alloc(a,globals,sizeof *p->globals);
    p->results=analysis_alloc(a,functions,sizeof *p->results);
    p->stacks=analysis_alloc(a,functions,sizeof *p->stacks);
    if((origins && !p->origins) || (globals && !p->globals) || !p->results || !p->stacks) {
        nvm_union_field_proof_free(p);return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate copied union rows.");
    }
    if(!analysis_work(a,(uint64_t)origins*5u+globals+functions)) {
        nvm_union_field_proof_free(p);return 0;
    }
    for(uint32_t i=0;i<origins;i++) {
        NvmUnionFieldOrigin *row=&p->origins[i];
        row->function=a->report.origins[i].function;row->pc=a->report.origins[i].pc;
        row->nominal_ordinal=a->record_ordinal[i];row->kind=a->origin_kind[i];
        row->variant=row->kind==3u?u->variant[i]:
# 297 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                                                    (255)
# 297 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                                             ;
        row->member_count=a->record_fields[i];
        if(!nvm_union_field_declarations_nominal(u->declarations,
            row->kind==3u?TAG_UNION:TAG_STRUCT,row->nominal_ordinal,&row->layout_index)) {
            nvm_union_field_proof_free(p);return stop(a,NVM_ARRAY_INVALID,0,0,"I require copied nominal identity during union freeze.");
        }
        if(row->member_count)row->member=uf_copy_value(row->kind==3u?
            u->payloads[i]:a->fields[a->field_start[i]]);
    }
    for(uint32_t i=0;i<globals;i++)p->globals[i]=uf_copy_value(a->globals[i]);
    for(uint32_t i=0;i<functions;i++) {
        if(a->module->functions[i].result_count)p->results[i]=uf_copy_value(a->functions[i].result);
        p->stacks[i]=a->structure->stacks[i];
    }
    p->counts=(NvmUnionFieldProofCounts){origins,globals,functions,a->budget.peak,a->budget.work};
    p->declarations=u->declarations;u->declarations=
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc" 3 4
                                                   ((void *)0)
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_analysis.inc"
                                                       ;
    *out=p;return 1;
}
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
static int walk_context(Analysis *a,uint32_t fi,NvmRecordMapAnalysisContext *maps,uint8_t value_tag,NvmUnionAnalysisContext *unions) {
    Function *f=&a->functions[fi];const NvmFunctionEntry *entry=&a->module->functions[fi];
    if(!analysis_work(a,(uint64_t)f->decoded.instruction_count+1))return 0;
    for(uint32_t i=0;i<=f->decoded.instruction_count;i++)if(f->seen[i])enqueue(f,i);
    while(f->queued_count) {


        if(!analysis_work(a,a->global_flow?4096:2048))return 0;
        uint32_t index=f->queue[f->head];f->head=(f->head+1)%(f->decoded.instruction_count+1);
        f->queued_count--;f->queued[index]=0;
        Value state[a->global_flow?256u*3:256u*2];memset(state,0,sizeof state);uint16_t depth=f->depths[index];
        memcpy(state,f->states+(size_t)index*f->stride,((size_t)f->locals+depth)*sizeof(Value));
        if(a->global_flow)memcpy(global_values(f,state),
            global_values(f,f->states+(size_t)index*f->stride),a->global_count*sizeof(Value));
        Value *stack=state+f->locals;
        if(index==f->decoded.instruction_count) {
            if(a->structure && depth!=entry->result_count)
                return stop(a,NVM_ARRAY_INVALID,fi,entry->code_length,"I require the declared result depth at an implicit return.");
            if(entry->result_count)a->changed|=merge(&f->result,&stack[depth-1]);
            if(!global_return(a,fi,state))return 0;
            continue;
        }
        VmDecodedInstruction *d=&f->decoded.instructions[index];DecodedInstruction *in=&d->instruction;
        uint8_t op=in->opcode;const InstructionInfo *info=isa_get_info(op);

        if(unions && op==OP_HALT)continue;
        int pops=info->pop_count,pushes=info->push_count;
        if(op==OP_ARR_LITERAL || op==OP_STRUCT_LITERAL){pops=in->operands[1].u16;pushes=1;}
        if(op==OP_AGG_PACK){pops=in->operands[3].u16;pushes=1;}
        if(op==OP_CALL || op==OP_TAIL_CALL){pops=a->module->functions[in->operands[0].u32].arity;pushes=a->module->functions[in->operands[0].u32].result_count;}
        if(op==OP_CALL_EXTERN && a->portable_reads){pops=1;pushes=1;}
        if(op==OP_RET) {
            if(a->structure && depth!=entry->result_count)
                return stop(a,NVM_ARRAY_INVALID,fi,d->byte_offset,"I require the declared result depth at an explicit return.");
            if(entry->result_count)a->changed|=merge(&f->result,&stack[depth-1]);
            if(!global_return(a,fi,state))return 0;
            continue;
        }
        if(op==OP_TAIL_CALL) {
            if(depth!=pops)return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require exactly the direct tail arguments.");
            pushes=0;
        }
        if(pops<0 || pushes<0 || depth<pops || depth-pops+pushes>f->stack)
            return stop(a,NVM_ARRAY_INVALID,fi,d->byte_offset,"I require a verified bounded instruction stack effect.");
        Value result={0};int exact=fixed_result(op);if(exact>=0)result=tag((uint8_t)exact);
        uint32_t base=depth-(uint16_t)pops;
        if(unions) {
            if(op==OP_AGG_PACK && in->operands[0].u8==AGG_VARIANT) {
                uint32_t origin=(uint32_t)f->origins[index];
                if(pops && (stack[base].unknown || !stack[base].tags))continue;
                if(pops && !uf_value(a,stack[base],TAG_INT,fi,d->byte_offset))return 0;
                result=tag(TAG_UNION);result.origins=1UL<<origin;
                if(pops)a->changed|=merge(&unions->payloads[origin],&stack[base]);
                goto transferred;
            }
            if(op==OP_AGG_TAG) {
                if(stack[base].unknown || !stack[base].tags || !stack[base].origins)continue;
                if(!uf_value(a,stack[base],TAG_UNION,fi,d->byte_offset))return 0;
                result=tag(TAG_INT);goto transferred;
            }
            if(op==OP_AGG_GET || op==OP_STRUCT_GET || op==OP_AGG_SET || op==OP_STRUCT_SET) {
                int writing=op==OP_AGG_SET || op==OP_STRUCT_SET;
                int ready=uf_access(a,unions,stack[base],in->operands[0].u16,writing,
                    writing?stack[depth-1]:(Value){0},fi,d->byte_offset,0,&result);
                if(!ready)return 0;
                if(ready==2)continue;
                goto transferred;
            }
        }
        switch(op) {
        case OP_DUP: result=stack[depth-1];stack[depth]=result;depth++;goto successors;
        case OP_SWAP: result=stack[depth-1];stack[depth-1]=stack[depth-2];stack[depth-2]=result;goto successors;
        case OP_LOAD_LOCAL: result=state[in->operands[0].u16];break;
        case OP_STORE_LOCAL: state[in->operands[0].u16]=stack[base];break;
        case OP_LOAD_GLOBAL:
            result=a->global_flow?global_values(f,state)[in->operands[0].u32]:a->globals[in->operands[0].u32];
            if(a->global_flow){result.relation=(uint16_t)(in->operands[0].u32+1);result.relation_tag=0;}
            break;
        case OP_STORE_GLOBAL: {
            uint32_t slot=in->operands[0].u32;Value value=stack[base];
            a->changed|=merge(&a->globals[slot],&value);
            if(a->global_flow) {
                if(!global_invalidates(a,f,state,slot))return 0;
                global_values(f,state)[slot]=global_plain(value);
            }
            break;
        }
        case OP_TYPE_CHECK:
            if(a->global_flow && stack[base].relation && stack[base].relation<=a->global_count) {
                result.relation=(uint16_t)(256u +stack[base].relation);result.relation_tag=in->operands[0].u8;
            }
            break;
        case OP_CALL_EXTERN:
            if(!a->portable_reads)return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require portable import authority.");
            if(nvm_portable_file_read_import(a->module,in->operands[0].u32)==1) {
                result=tag(TAG_STRING);break;
            }
            result=tag(TAG_ARRAY);result.origins=1UL<<f->origins[index];break;
        case OP_HM_NEW:
            result=tag(TAG_HASHMAP);result.origins=1UL<<f->origins[index];break;
        case OP_HM_SET:
            if(!maps)return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require map proof context.");
            if(!analysis_work(a,64u*2u))return 0;
            for(uint32_t i=0;i<a->report.origin_count;i++)if((stack[base].origins&(1UL<<i)) &&
                a->origin_kind[i]==2u) {
                a->changed|=merge(&maps->keys[i],&stack[base+1]);
                a->changed|=merge(&maps->values[i],&stack[base+2]);
            }
            result=stack[base];break;
        case OP_HM_DELETE:
            if(!maps)return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require map proof context.");

            result=stack[base];break;
        case OP_HM_GET: result=tag(value_tag);result.tags|=((uint16_t)(1u << (TAG_VOID)));break;
        case OP_HM_HAS: result=tag(TAG_BOOL);break;
        case OP_HM_LEN: result=tag(TAG_INT);break;
        case OP_ARR_NEW: case OP_STR_SPLIT: case OP_ARR_LITERAL:
            result=tag(TAG_ARRAY);result.origins=1UL<<f->origins[index];
            if(op==OP_ARR_LITERAL)for(uint32_t i=base;i<depth;i++) {
                write_array(a,result,stack[i]);
                if(a->structure && a->budget.limited)return 0;
            }
            break;
        case OP_ARR_SLICE:
            if(!slice_origins(a,fi,d->byte_offset,stack[base],&result))return 0;
            break;
        case OP_ARR_PUSH: case OP_ARR_SET:
            write_array(a,stack[base],stack[depth-1]);result=stack[base];break;
        case OP_ARR_GET: case OP_ARR_POP: result=read_array(a,stack[base]);break;
        case OP_STRUCT_NEW: case OP_STRUCT_LITERAL: case OP_AGG_PACK: {
            int ready=1;
            for(uint32_t i=base;i<depth;i++)if(!stack[i].tags && !stack[i].unknown)ready=0;
            if(ready) {
                result=tag(TAG_STRUCT);result.origins=1UL<<f->origins[index];
                for(uint32_t i=base;i<depth;i++) {
                    write_record(a,result,(uint16_t)(i-base),stack[i]);
                    if(a->structure && a->budget.limited)return 0;
                }
            }
            break;
        }
        case OP_STRUCT_GET: case OP_AGG_GET:
            result=read_record(a,stack[base],in->operands[0].u16);break;
        case OP_STRUCT_SET: case OP_AGG_SET:
            write_record(a,stack[base],in->operands[0].u16,stack[depth-1]);result=stack[base];break;
        case OP_CALL: case OP_TAIL_CALL: {
            uint32_t callee=in->operands[0].u32;
            if(!seed(a,callee,stack+base,a->global_flow?global_values(f,state):
# 764 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                              ((void *)0)
# 764 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                  ))return 0;
            if(a->global_flow) {
                if(!a->global_flow->returned[callee])continue;
                for(uint32_t slot=0;slot<a->global_count;slot++) {
                    if(!analysis_work(a,1))return 0;
                    if(!(a->global_flow->writes[callee][slot/64]&(1UL<<(slot%64))))continue;
                    if(!global_invalidates(a,f,state,slot))return 0;
                    global_values(f,state)[slot]=global_plain(a->global_flow->exits[(size_t)callee*a->global_count+slot]);
                }
            }
            result=a->functions[callee].result;
            if(op==OP_TAIL_CALL) {
                if(entry->result_count)a->changed|=merge(&f->result,&result);
                if(!global_return(a,fi,state))return 0;
                goto next_instruction;
            }
            break;
        }
        default:break;
        }
    transferred:
        if(a->structure && a->budget.limited)return 0;
        depth=(uint16_t)(base+pushes);if(pushes)stack[base]=result;
    successors:
        if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
            uint32_t relative=d->resolved_target-entry->code_offset;
            uint32_t target=relative==f->decoded.code_size?f->decoded.instruction_count:
                f->decoded.instruction_indices[relative]-1;
            if(a->global_flow && op!=OP_JMP) {
                Value branch[256u*3];
                if(!analysis_work(a,256u*3u))return 0;
                memcpy(branch,state,sizeof branch);

                Value condition=stack[depth];int reachable;
                if(!(unions?global_refine_context(a,f,branch,condition,op==OP_JMP_TRUE,&reachable,
# 798 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                 ((void *)0)
# 798 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                     ,unions):maps?global_refine_map(a,f,branch,condition,op==OP_JMP_TRUE,&reachable,maps):
                    global_refine(a,f,branch,condition,op==OP_JMP_TRUE,&reachable)))return 0;
                if(reachable && !join(a,fi,target,branch,depth))return 0;
                if(!(unions?global_refine_context(a,f,state,condition,op==OP_JMP_FALSE,&reachable,
# 801 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                 ((void *)0)
# 801 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                     ,unions):maps?global_refine_map(a,f,state,condition,op==OP_JMP_FALSE,&reachable,maps):
                    global_refine(a,f,state,condition,op==OP_JMP_FALSE,&reachable)))return 0;
                if(!reachable)continue;
            } else if(!join(a,fi,target,state,depth))return 0;
            if(op==OP_JMP)continue;
        }
        if(!join(a,fi,index+1,state,depth))return 0;
    next_instruction:;
    }
    return 1;
}
static int walk_map_pair(Analysis *a,uint32_t fi,NvmRecordMapAnalysisContext *maps,uint8_t value_tag) {
    return walk_context(a,fi,maps,value_tag,
# 813 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                           ((void *)0)
# 813 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                               );
}
static int walk_map(Analysis *a,uint32_t fi,NvmRecordMapAnalysisContext *maps) { return walk_map_pair(a,fi,maps,TAG_INT); }
static int walk(Analysis *a,uint32_t fi) { return walk_map(a,fi,
# 816 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                               ((void *)0)
# 816 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                   ); }
static int final_check_context(Analysis *a,NvmRecordMapAnalysisContext *maps,uint8_t value_tag,NvmUnionAnalysisContext *unions) {
    if(!analysis_work(a,256u +256u))return 0;
    for(uint32_t i=0;i<a->global_count;i++)if(a->globals[i].unknown)
        return stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I cannot resolve an escaped global value.");
    for(uint32_t fi=0;fi<a->module->function_count;fi++) {
        Function *f=&a->functions[fi];
        if(a->structure && a->module->functions[fi].result_count &&
           f->result.tags!=((uint16_t)(1u << (a->module->functions[fi].result_tag))))
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,0,"I require exact ordinary result tags.");
        if(a->module->functions[fi].result_count && (f->result.unknown || !f->result.tags))
            return stop(a,NVM_ARRAY_UNRESOLVED,fi,0,"I cannot resolve this function result or return path.");
        for(uint32_t pc=0;pc<f->decoded.instruction_count;pc++) {
            if(!analysis_work(a,512))return 0;
            if(!f->seen[pc])continue;
            VmDecodedInstruction *d=&f->decoded.instructions[pc];uint8_t op=d->instruction.opcode;
            if(a->structure && (op==OP_CALL || op==OP_TAIL_CALL)) {
                uint32_t target=d->instruction.operands[0].u32;
                if(unions && (!a->global_flow || !a->global_flow->returned[target]))
                    return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I cannot resolve this reachable direct-call return.");
                const NvmFunctionEntry *callee=&a->module->functions[target];
                Value *stack=f->states+(size_t)pc*f->stride+f->locals;
                for(uint16_t i=0;i<callee->arity;i++) {
                    uint8_t tag=a->module->function_param_types && a->module->function_param_types[target]?
                        a->module->function_param_types[target][i]:TAG_VOID;
                    Value argument=stack[f->depths[pc]-callee->arity+i];
                    if(tag!=TAG_VOID && (argument.unknown || argument.tags!=((uint16_t)(1u << (tag)))))
                        return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require exact known direct-call parameter tags.");
                }
            }
            if(maps && nvm_record_map_opcode(op)) {
                Value *stack=f->states+(size_t)pc*f->stride+f->locals;
                if(!map_operation(a,maps,fi,d,stack,f->depths[pc],value_tag))return 0;
                continue;
            }
            if(unions && (record_operation(op) || op==OP_AGG_TAG)) {
                if(!uf_operation(a,unions,fi,pc))return 0;
                continue;
            }
            if(a->records && record_operation(op)) {
                Value *stack=f->states+(size_t)pc*f->stride+f->locals;
                uint16_t depth=f->depths[pc];
                if(op==OP_STRUCT_NEW || op==OP_STRUCT_LITERAL || op==OP_AGG_PACK) {
                    uint32_t origin=(uint32_t)f->origins[pc];
                    uint16_t count=a->record_fields[origin];
                    const NvmV2Layout *layout=&a->plan->layouts.items[a->plan->record_to_layout[a->record_ordinal[origin]]];
                    for(uint16_t i=0;i<count;i++)
                        if(!record_value_matches(a,fi,d->byte_offset,&layout->fields[i],stack[depth-count+i],
                            a->structure?record_field_element(a,a->layout_fields[a->plan->record_to_layout[a->record_ordinal[origin]]]+i):0,maps))return 0;
                } else {
                    int writes=op==OP_STRUCT_SET || op==OP_AGG_SET;
                    Value receiver=stack[depth-(writes?2:1)];
                    if(!check_record_access(a,fi,d->byte_offset,receiver,d->instruction.operands[0].u16,
                                            writes?&stack[depth-1]:
# 869 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                  ((void *)0)
# 869 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                      ,maps))return 0;
                }
                continue;
            }
            if(op==OP_ARR_LITERAL) {
                uint16_t count=d->instruction.operands[1].u16;
                Value receiver=tag(TAG_ARRAY);receiver.origins=1UL<<f->origins[pc];
                Value *stack=f->states+(size_t)pc*f->stride+f->locals;
                for(uint32_t i=f->depths[pc]-count;i<f->depths[pc];i++)
                    if(!check_write(a,fi,d->byte_offset,receiver,stack[i]))return 0;
                continue;
            }
            if(op!=OP_ARR_PUSH && op!=OP_ARR_SET && op!=OP_ARR_GET && op!=OP_ARR_POP && op!=OP_ARR_LEN && op!=OP_ARR_SLICE)continue;
            uint16_t depth=f->depths[pc];int pops=isa_get_info(op)->pop_count;
            Value *stack=f->states+(size_t)pc*f->stride+f->locals;
            Value receiver=stack[depth-pops];
            if(receiver.unknown || !receiver.tags || ((receiver.tags&((uint16_t)(1u << (TAG_ARRAY)))) && !receiver.origins))
                return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require authoritative array origins.");
            if(receiver.tags!=((uint16_t)(1u << (TAG_ARRAY))))a->report.runtime_tag_checks++;
            if(op==OP_ARR_GET || op==OP_ARR_SET) {
                Value index=stack[depth-pops+1];
                if(index.unknown || !index.tags)return stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I cannot resolve the array index tags.");
                if(index.tags!=((uint16_t)(1u << (TAG_INT))))a->report.runtime_tag_checks++;
            }
            if(op!=OP_ARR_PUSH && op!=OP_ARR_SET)continue;
            if(!check_write(a,fi,d->byte_offset,receiver,stack[depth-1]))return 0;
        }
    }
    return 1;
}
static int final_check(Analysis *a,NvmRecordMapAnalysisContext *maps,uint8_t value_tag) {
    return final_check_context(a,maps,value_tag,
# 900 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                               ((void *)0)
# 900 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                   );
}
static void destroy(Analysis *a) {
    for(uint32_t i=0;i<256u;i++) {
        Function *f=&a->functions[i];vm_decoded_function_free(&f->decoded);
        free(f->states);free(f->depths);free(f->queue);free(f->seen);free(f->queued);free(f->origins);
    }
    nvm_record_array_structure_free(a->structure);
    free(a->field_elements);
    free(a->nested_string_fields);
    if(a->global_flow){free(a->global_flow->exits);free(a->global_flow);}
    nvm_record_plan_free(a->plan);
    free(a->fields);
    free(a);
}
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 1
_Static_assert(2u!=NVM_HEAP_ORIGIN_ARRAY && 2u!=NVM_HEAP_ORIGIN_RECORD,"map identity has a distinct private kind");
typedef struct { uint32_t ordinal,pair; } MapFrozenOrigin;
_Static_assert(sizeof(MapFrozenOrigin)==8,"map origin row has an exact copied size");
struct NvmRecordMapFrozenContext {
    NvmRecordArrayOrigins *base;
    NvmMapDeclarationPlan *declarations;
    MapFrozenOrigin *rows;
    NvmRecordMapCounts counts;
};
void nvm_record_map_frozen_free(NvmRecordMapFrozenContext *p) {
    if(!p)return;
    nvm_record_array_origins_free(p->base);nvm_map_declarations_free(p->declarations);
    free(p->rows);free(p);
}
static int map_freeze(Analysis *a,NvmRecordMapAnalysisContext *maps,NvmRecordMapFrozenContext **out) {
    NvmRecordMapFrozenContext *p=analysis_alloc(a,1,sizeof *p);
    if(!p)return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate frozen map facts.");
    uint32_t count=0;
    if(!analysis_work(a,64u*2u)){free(p);return 0;}
    for(uint32_t i=0;i<a->report.origin_count;i++)count+=a->origin_kind[i]==2u;
    if(count) {
        p->rows=analysis_alloc(a,count,sizeof *p->rows);
        if(!p->rows){free(p);return stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy map origin rows.");}
    }
    uint32_t index=0;
    for(uint32_t i=0;i<a->report.origin_count;i++)if(a->origin_kind[i]==2u)
        p->rows[index++]=(MapFrozenOrigin){i,0};
    if(!ra_publish(a,&p->base)){nvm_record_map_frozen_free(p);return 0;}
    p->counts=(NvmRecordMapCounts){a->report.origin_count,count,a->field_count,maps->checked,a->budget.peak,a->budget.work};
    p->declarations=maps->declarations;maps->declarations=
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                                                         ((void *)0)
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                                                             ;
    *out=p;return 1;
}

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
    nvm_record_map_frozen_counts(const NvmRecordMapFrozenContext *p,NvmRecordMapCounts *out) {
    if(!p||!out)return 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                      0
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                           ;
    *out=p->counts;return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                         1
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                             ;
}

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
    nvm_record_map_frozen_origin(const NvmRecordMapFrozenContext *p,uint32_t origin,
                                  uint8_t *key,uint8_t *value) {
    if(!p||!key||!value||key==value)return 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                                          0
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                                               ;
    for(uint32_t i=0;i<p->counts.map_origins;i++)if(p->rows[i].ordinal==origin) {
        NvmMapDeclarationPair pair;uint8_t k,v;
        if(!nvm_map_declarations_pair(p->declarations,p->rows[i].pair,&pair) ||
           !nvm_map_declarations_scalar(p->declarations,pair.key_type,&k) ||
           !nvm_map_declarations_scalar(p->declarations,pair.value_type,&v))return 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                                                                                  0
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                                                                                       ;
        *key=k;*value=v;return 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                              1
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                                  ;
    }
    return 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
          0
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
               ;
}

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
    nvm_record_map_frozen_field(const NvmRecordMapFrozenContext *p,uint32_t layout,uint16_t field,
                                 uint8_t *key,uint8_t *value) {
    NvmMapDeclarationPair pair;uint8_t k,v;
    if(!p||!key||!value||key==value || !nvm_map_declarations_field(p->declarations,layout,field,&pair) ||
       !nvm_map_declarations_scalar(p->declarations,pair.key_type,&k) ||
       !nvm_map_declarations_scalar(p->declarations,pair.value_type,&v))return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                                                                              0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                                                                                   ;
    *key=k;*value=v;return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
                          1
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
                              ;
}

# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
_Bool 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
    nvm_record_map_heap_origin(const NvmRecordMapFrozenContext *p,uint32_t i,NvmRecordHeapOrigin *out) {
    return p && nvm_record_array_origin(p->base,i,out);
}

# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc" 3 4
_Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_frozen.inc"
    nvm_record_map_field_value(const NvmRecordMapFrozenContext *p,uint32_t i,NvmRecordValueOrigins *out) {
    return p && nvm_record_array_field_value(p->base,i,out);
}
# 916 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
typedef struct {
    NvmRecordValueOrigins *rows;
    uint32_t count;
} NvmMapGlobalExport;
static int map_boundary_value_valid(Value value,uint64_t arrays,uint64_t records) {
    const uint16_t scalar=((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_STRING)));
    const uint16_t heap=((uint16_t)(1u << (TAG_ARRAY)))|((uint16_t)(1u << (TAG_STRUCT)));
    if(value.unknown || !value.tags || (value.tags&~(scalar|heap)))return 0;
    uint64_t allowed=0;
    if(value.tags&((uint16_t)(1u << (TAG_ARRAY)))) {if(!(value.origins&arrays))return 0;allowed|=arrays;}
    if(value.tags&((uint16_t)(1u << (TAG_STRUCT)))) {if(!(value.origins&records))return 0;allowed|=records;}
    return !(value.origins&~allowed);
}

static NvmArrayEligibilityResult analyze_context_sites(const NvmModule *m,NvmArrayEligibilityReport **out,
                                          NvmArrayGraphEligibilityReport **graph_out,
                                          NvmRecordEligibilityReport **record_out,NvmRecordArrayOrigins **mixed_out,uint16_t *prepared_stacks, int portable_reads,NvmRecordMapFrozenContext **map_out,NvmMapGlobalExport *globals_out,uint8_t *map_value_out,NvmUnionFieldProof **union_out,NvmUnionFieldSiteExport *sites_out) {
    NvmArrayEligibilityResult early={NVM_ARRAY_INVALID,0,0,"I require a module and report output."};
    if(!m || (!out && !graph_out && !record_out && !mixed_out && !map_out && !union_out) || (globals_out && !map_out) ||
       (union_out && (out || graph_out || record_out || mixed_out || map_out || prepared_stacks || portable_reads || globals_out || map_value_out)))return early;
    if(sites_out && (!union_out || uf_outputs_overlap(union_out,sizeof *union_out,sites_out,sizeof *sites_out)))return early;
    NvmUnionFieldSiteExport sites={0};NvmUnionFieldProof *pending_union=
# 937 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                       ((void *)0)
# 937 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                           ;
    NvmRecordArrayBudget budget={0};NvmRecordArrayStructure *structure=
# 938 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                      ((void *)0)
# 938 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                          ;
    NvmMapDeclarationPlan *map_declarations=
# 939 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                           ((void *)0)
# 939 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                               ;NvmRecordUnionStructure *union_structure=
# 939 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                         ((void *)0)
# 939 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                             ;
    if(mixed_out || map_out || union_out) {
        if(union_out) {
            early=nvm_record_union_structure_prepare(m,&budget,&union_structure);
            if(early.status==NVM_ARRAY_ELIGIBLE) {
                structure=union_structure->carrier;union_structure->carrier=
# 944 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                           ((void *)0)
# 944 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                               ;
            }
        } else early=map_out?nvm_record_map_structure_prepare(m,&budget,&structure,&map_declarations):
            nvm_record_array_structure_prepare(m,&budget,&structure);
        if(early.status!=NVM_ARRAY_ELIGIBLE)return early;
        if(!nvm_ra_bytes(&budget,sizeof(Analysis))) {
            nvm_record_union_structure_free(union_structure);nvm_map_declarations_free(map_declarations);nvm_record_array_structure_free(structure);early.status=NVM_ARRAY_LIMIT;return early;
        }
    }
    Analysis *a=allocate(1,sizeof *a);
    if(!a){nvm_record_union_structure_free(union_structure);nvm_map_declarations_free(map_declarations);nvm_record_array_structure_free(structure);early.status=NVM_ARRAY_MEMORY;snprintf(early.message,sizeof early.message,"I could not allocate array analysis state.");return early;}
    NvmRecordMapAnalysisContext *maps=
# 955 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                     ((void *)0)
# 955 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                         ;NvmUnionAnalysisContext *unions=
# 955 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                          ((void *)0)
# 955 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                              ;uint8_t value_tag=TAG_INT;
    NvmMapGlobalExport globals={0};
    a->module=m;a->structure=structure;a->budget=budget;a->portable_reads=portable_reads;
    if(union_out) {
        unions=analysis_alloc(a,1,sizeof *unions);
        if(!unions){stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate union proof state.");goto done;}
        unions->declarations=union_structure->declarations;union_structure->declarations=
# 961 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                        ((void *)0)
# 961 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                            ;
    }
    if(map_out) {
        maps=analysis_alloc(a,1,sizeof *maps);
        if(!maps){nvm_map_declarations_free(map_declarations);stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate map proof state.");goto done;}
        maps->declarations=map_declarations;
        if(!map_declarations_exact(a,maps,&value_tag))goto done;
    }
    a->records=record_out!=
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                          ((void *)0) 
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                               || mixed_out!=
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                             ((void *)0) 
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  || map_out!=
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                              ((void *)0) 
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                   || union_out!=
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                 ((void *)0)
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                     ;a->graph=graph_out!=
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                          ((void *)0) 
# 969 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                               || a->records;
    if(!a->structure && !verified(a,nvm_verify(m)))goto done;
    if(m->function_count>256u){stop(a,NVM_ARRAY_LIMIT,0,0,"I reached my array analysis function limit.");goto done;}
    if(!(m->header.flags&(1 << 0)) || m->functions[m->header.entry_point].arity ||
       (!portable_reads && m->import_count) || m->module_ref_count || (!a->structure && m->union_count) || m->passive_size ||
       (!a->records && (m->struct_count || m->ownership_size || m->layout_size))) {
        stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require a closed zero-argument entry without nominal, ownership or host contracts.");goto done;
    }
    if(portable_reads)for(uint32_t i=0;i<m->import_count;i++)
        if(!nvm_portable_file_read_import(m,i)) {
            stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact portable file-read imports.");goto done;
        }
    if(a->records && !(unions?uf_prepare_records(a,unions):prepare_records(a,maps)))goto done;
    if(!global_prepare(a))goto done;
    uint32_t instructions=0;int initializer=-1;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        if(!analysis_work(a,(uint64_t)m->functions[fi].code_length*2u+1024u))goto done;
        Function *f=&a->functions[fi];const NvmFunctionEntry *e=&m->functions[fi];
        if(e->local_count>256u){stop(a,NVM_ARRAY_LIMIT,fi,0,"I reached my array analysis local limit.");goto done;}
        if(e->upvalue_count || e->result_count>1){stop(a,NVM_ARRAY_UNRESOLVED,fi,0,"I require no captures and at most one result.");goto done;}
        const char *name=nvm_get_string(m,e->name_idx);
        if(initializer<0 && name && !strcmp(name,"__init__")) {
            if(e->arity){stop(a,NVM_ARRAY_UNRESOLVED,fi,0,"I require a zero-argument initializer.");goto done;}initializer=(int)fi;
        }
        for(uint32_t pc=0;pc<e->code_length;) {
            DecodedInstruction in={0};uint32_t width=isa_decode(m->code+e->code_offset+pc,e->code_length-pc,&in);
            if(!width){stop(a,NVM_ARRAY_INVALID,fi,pc,"I require decodable instructions.");goto done;}
            if(++instructions>65536u){stop(a,NVM_ARRAY_LIMIT,fi,pc,"I reached my decoded instruction limit.");goto done;}
            if(!supported(in.opcode) && !(unions && (in.opcode==OP_AGG_TAG || in.opcode==OP_HALT)) && !(maps && nvm_record_map_opcode(in.opcode)) && !(a->structure && in.opcode==OP_TAIL_CALL) && !(a->records && record_operation(in.opcode)) && !(portable_reads && in.opcode==OP_CALL_EXTERN)){stop(a,NVM_ARRAY_UNRESOLVED,fi,pc,"I have no proved transfer for this instruction.");goto done;}
            if(in.opcode==OP_LOAD_GLOBAL || in.opcode==OP_STORE_GLOBAL) {
                uint32_t global=in.operands[0].u32;
                if(global>=256u){stop(a,NVM_ARRAY_LIMIT,fi,pc,"I reached my array analysis global limit.");goto done;}
                if(global>=a->global_count)a->global_count=global+1;
            }
            pc+=width;
        }
        if(a->structure)f->stack=a->structure->stacks[fi];
        else if(!verified(a,nvm_verify_function_max_stack(m,fi,&f->stack)))goto done;
        if(f->stack>256u){stop(a,NVM_ARRAY_LIMIT,fi,0,"I reached my array analysis stack limit.");goto done;}
        char error[256];
        if(a->structure) {
            f->decoded=a->structure->decoded[fi];memset(&a->structure->decoded[fi],0,sizeof f->decoded);
        } else if(!vm_decode_function(m,fi,&f->decoded,error)){stop(a,NVM_ARRAY_MEMORY,fi,0,error);goto done;}
        f->locals=e->local_count;f->stride=(uint32_t)f->locals+f->stack+(a->global_flow?a->global_count:0);if(!f->stride)f->stride=1;
        uint32_t count=f->decoded.instruction_count+1;
        a->state_cells+=(uint64_t)count*f->stride;
        if(a->state_cells+a->field_count>1048576u){stop(a,NVM_ARRAY_LIMIT,fi,0,"I reached my stored abstract-state cell limit.");goto done;}
        f->states=analysis_alloc(a,(size_t)count*f->stride,sizeof(Value));f->depths=analysis_alloc(a,count,sizeof(uint16_t));
        f->queue=analysis_alloc(a,count,sizeof(uint32_t));f->seen=analysis_alloc(a,count,1);f->queued=analysis_alloc(a,count,1);f->origins=analysis_alloc(a,count,sizeof(int16_t));
        if(!f->states || !f->depths || !f->queue || !f->seen || !f->queued || !f->origins){stop(a,NVM_ARRAY_MEMORY,fi,0,"I could not allocate my bounded function analysis.");goto done;}
        for(uint32_t i=0;i<f->decoded.instruction_count;i++) {
            VmDecodedInstruction *d=&f->decoded.instructions[i];uint8_t op=d->instruction.opcode;
            f->origins[i]=-1;
            if(a->records && (op==OP_STRUCT_NEW || op==OP_STRUCT_LITERAL || op==OP_AGG_PACK)) {
                if(!(unions?uf_site(a,unions,fi,i):record_site(a,fi,i)))goto done;
                continue;
            }
            if(maps && op==OP_HM_NEW) {
                if(d->instruction.operands[0].u8!=TAG_STRING || d->instruction.operands[1].u8!=value_tag) {
                    stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I require map creation to match the exact copied STRING-keyed pair.");goto done;
                }
                if(a->report.origin_count==64u){stop(a,NVM_ARRAY_LIMIT,fi,d->byte_offset,"I reached my shared origin limit.");goto done;}
                uint32_t origin=a->report.origin_count++;f->origins[i]=(int16_t)origin;
                a->origin_kind[origin]=2u;
                a->report.origins[origin]=(NvmArrayOrigin){fi,d->byte_offset,0,TAG_HASHMAP,0};
                continue;
            }
            int bytes=portable_reads && op==OP_CALL_EXTERN &&
                nvm_portable_file_read_import(m,d->instruction.operands[0].u32)==2;
            if(op!=OP_ARR_NEW && op!=OP_STR_SPLIT && op!=OP_ARR_LITERAL && !bytes)continue;
            uint8_t declared=bytes?TAG_U8:op==OP_STR_SPLIT?TAG_STRING:d->instruction.operands[0].u8;
            uint16_t allowed=a->structure?((((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING))))|(a->nested_arrays?((uint16_t)(1u << (TAG_ARRAY))):0)):(((uint16_t)(1u << (TAG_VOID)))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_U8)))|((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_STRING)))|((uint16_t)(1u << (TAG_ENUM))))|(a->graph?((uint16_t)(1u << (TAG_ARRAY))):0);
            if(!(allowed&((uint16_t)(1u << (declared))))){stop(a,NVM_ARRAY_UNRESOLVED,fi,d->byte_offset,"I have not qualified this declared array shape.");goto done;}
            if(a->report.origin_count==64u){stop(a,NVM_ARRAY_LIMIT,fi,d->byte_offset,"I reached my allocation-site origin limit.");goto done;}
            uint32_t origin=a->report.origin_count++;f->origins[i]=(int16_t)origin;
            a->report.origins[origin]=(NvmArrayOrigin){fi,d->byte_offset,bytes?((uint16_t)(1u << (TAG_U8))):op==OP_STR_SPLIT?((uint16_t)(1u << (TAG_STRING))):0,declared,(uint8_t)packed(declared)};
            if(op==OP_STR_SPLIT)a->children[origin]=tag(TAG_STRING);
            if(bytes)a->children[origin]=tag(TAG_U8);
        }
    }
    if(a->field_count) {
        a->fields=analysis_alloc(a,a->field_count,sizeof *a->fields);
        if(!a->fields){stop(a,NVM_ARRAY_MEMORY,0,0,"I could not allocate my record field summaries.");goto done;}
    }
    for(uint32_t i=0;i<a->global_count;i++)a->globals[i]=tag(TAG_VOID);
    if(!a->global_flow) {
        if(initializer>=0 && !seed(a,(uint32_t)initializer,
# 1055 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                          ((void *)0)
# 1055 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                              ,
# 1055 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                               ((void *)0)
# 1055 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                   ))goto done;
        if(!seed(a,m->header.entry_point,
# 1056 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                        ((void *)0)
# 1056 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                            ,
# 1056 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                             ((void *)0)
# 1056 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                 ))goto done;
    }
    int seeded_unused=0;
    do {
        if(!analysis_work(a,(uint64_t)m->function_count*512u+256u))goto done;
        a->changed=0;
        if(a->global_flow) {
            if(initializer>=0) {
                if(!seed(a,(uint32_t)initializer,
# 1064 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                ((void *)0)
# 1064 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                    ,a->globals))goto done;
                if(a->global_flow->returned[initializer] && !seed(a,m->header.entry_point,
# 1065 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                         ((void *)0)
# 1065 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                             ,
                    a->global_count?a->global_flow->exits+(size_t)initializer*a->global_count:a->globals))goto done;
            } else if(!seed(a,m->header.entry_point,
# 1067 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                   ((void *)0)
# 1067 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                       ,a->globals))goto done;
        }
        for(uint32_t fi=0;fi<m->function_count;fi++)if(!(unions?walk_context(a,fi,
# 1069 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                 ((void *)0)
# 1069 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                     ,TAG_VOID,unions):maps?walk_map_pair(a,fi,maps,value_tag):walk(a,fi)))goto done;
        if(!a->changed && !seeded_unused) {
            seeded_unused=1;
            for(uint32_t fi=0;fi<m->function_count;fi++)if(!a->functions[fi].seen[0]) {
                Value args[256u]={{0}};
                for(uint16_t i=0;i<m->functions[fi].arity;i++)args[i].unknown=1;
                if(!seed(a,fi,args,a->global_flow?a->globals:
# 1075 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                            ((void *)0)
# 1075 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                ))goto done;
            }
        }
    } while(a->changed);
    if(!(unions?final_check_context(a,
# 1079 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                     ((void *)0)
# 1079 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                         ,TAG_VOID,unions):final_check(a,maps,value_tag)))goto done;
    if(union_out) {
        if(sites_out) {
            if(!uf_export_sites(a,unions,&sites) || !uf_freeze(a,unions,&pending_union))goto done;
            *union_out=pending_union;pending_union=
# 1083 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                  ((void *)0)
# 1083 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                      ;
            *sites_out=sites;sites.rows=
# 1084 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1084 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ;
        } else if(!uf_freeze(a,unions,union_out))goto done;
    } else if(map_out) {
        if(prepared_stacks && !analysis_work(a,256))goto done;
        if(!ra_check_constraints(a) || !map_final(a,maps,value_tag))goto done;
        if(globals_out) {
            if(a->global_count>256u || a->report.origin_count>64u ||
               !analysis_work(a,128u+(uint64_t)a->global_count*8u))goto done;
            uint64_t arrays=0,records=0;
            for(uint32_t i=0;i<a->report.origin_count;i++) {
                if(a->origin_kind[i]==NVM_HEAP_ORIGIN_ARRAY)arrays|=1UL<<i;
                else if(a->origin_kind[i]==NVM_HEAP_ORIGIN_RECORD)records|=1UL<<i;
            }
            if(a->global_count) {
                globals.rows=analysis_alloc(a,a->global_count,sizeof *globals.rows);
                if(!globals.rows){stop(a,NVM_ARRAY_MEMORY,0,0,"I could not copy historical global obligations.");goto done;}
            }
            globals.count=a->global_count;
            for(uint32_t i=0;i<globals.count;i++) {
                Value value=a->globals[i];
                if(!map_boundary_value_valid(value,arrays,records)) {
                    stop(a,NVM_ARRAY_UNRESOLVED,0,0,"I require exact historical global obligations.");goto done;
                }
                globals.rows[i].origins=value.origins;globals.rows[i].tags=value.tags;

            }
        }
        if(!map_freeze(a,maps,map_out))goto done;
        if(map_value_out)*map_value_out=value_tag;
        if(globals_out){*globals_out=globals;globals.rows=
# 1113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                         ((void *)0)
# 1113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                             ;}
        if(prepared_stacks)memcpy(prepared_stacks,a->structure->stacks,sizeof a->structure->stacks);
    } else if(mixed_out) {
        if(prepared_stacks && !analysis_work(a,256))goto done;
        if(!ra_check_constraints(a) || !ra_publish(a,mixed_out))goto done;
        if(prepared_stacks)memcpy(prepared_stacks,a->structure->stacks,sizeof a->structure->stacks);
    } else if(record_out) {
        if(!publish_records(a,record_out))goto done;
    } else if(graph_out) {
        NvmArrayGraphEligibilityReport *report=analysis_alloc(a,1,sizeof *report);
        if(!report){stop(a,NVM_ARRAY_MEMORY,0,0,"I could not publish my graph analysis report.");goto done;}
        report->arrays=a->report;
        for(uint32_t i=0;i<a->report.origin_count;i++) {
            report->child_origins[i]=a->children[i].origins;
            report->child_unknown[i]=a->children[i].unknown;
        }
        *graph_out=report;
    } else {
        NvmArrayEligibilityReport *report=analysis_alloc(a,1,sizeof *report);
        if(!report){stop(a,NVM_ARRAY_MEMORY,0,0,"I could not publish my array analysis report.");goto done;}
        *report=a->report;*out=report;
    }
    a->result.status=NVM_ARRAY_ELIGIBLE;
    snprintf(a->result.message,sizeof a->result.message,"%s",unions?
        "I established copied union-field origin obligations, not execution admission.":maps?
        "I established copied exact map origin obligations, not execution admission.":
        "I established only the bounded portable array-shape obligations.");
 done:;
    NvmArrayEligibilityResult result=a->result;
    if(maps){nvm_map_declarations_free(maps->declarations);free(maps);}
    if(unions){nvm_union_field_declarations_free(unions->declarations);free(unions);}
    nvm_record_union_structure_free(union_structure);
    free(sites.rows);nvm_union_field_proof_free(pending_union);
    free(globals.rows);destroy(a);return result;
}

static NvmArrayEligibilityResult analyze_context(const NvmModule *m,NvmArrayEligibilityReport **out,
    NvmArrayGraphEligibilityReport **graph_out,NvmRecordEligibilityReport **record_out,
    NvmRecordArrayOrigins **mixed_out,uint16_t *prepared_stacks,int portable_reads,
    NvmRecordMapFrozenContext **map_out,NvmMapGlobalExport *globals_out,uint8_t *map_value_out,NvmUnionFieldProof **union_out) {
    return analyze_context_sites(m,out,graph_out,record_out,mixed_out,prepared_stacks,portable_reads,
                                 map_out,globals_out,map_value_out,union_out,
# 1154 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                            ((void *)0)
# 1154 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                );
}
static NvmArrayEligibilityResult analyze_union_sites(const NvmModule *m,NvmUnionFieldProof **proof,
                                                    NvmUnionFieldSiteExport *sites) {
    if(!proof || !sites)return (NvmArrayEligibilityResult){NVM_ARRAY_INVALID,0,0,"I require disjoint union proof and site outputs."};
    return analyze_context_sites(m,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                  ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                      ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                            ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                 ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                     ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                      ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                          ,0,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                             ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                 ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                  ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                      ,
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                       ((void *)0)
# 1159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                           ,proof,sites);
}
static NvmArrayEligibilityResult analyze_boundary_pair(const NvmModule *m,NvmArrayEligibilityReport **out,
    NvmArrayGraphEligibilityReport **graph_out,NvmRecordEligibilityReport **record_out,
    NvmRecordArrayOrigins **mixed_out,uint16_t *prepared_stacks,int portable_reads,
    NvmRecordMapFrozenContext **map_out,NvmMapGlobalExport *globals_out,uint8_t *map_value_out) {
    return analyze_context(m,out,graph_out,record_out,mixed_out,prepared_stacks,portable_reads,map_out,globals_out,map_value_out,
# 1165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                                                ((void *)0)
# 1165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                                                    );
}
NvmArrayEligibilityResult nvm_union_field_proof_prepare(const NvmModule *m,NvmUnionFieldProof **out) {
    return analyze_context(m,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                            ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                 ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                     ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                      ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                          ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                           ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                               ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                    ,0,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                       ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                           ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                            ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                ,
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                 ((void *)0)
# 1168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                     ,out);
}
static NvmArrayEligibilityResult analyze_boundary(const NvmModule *m,NvmArrayEligibilityReport **out,
    NvmArrayGraphEligibilityReport **graph_out,NvmRecordEligibilityReport **record_out,
    NvmRecordArrayOrigins **mixed_out,uint16_t *prepared_stacks,int portable_reads,
    NvmRecordMapFrozenContext **map_out,NvmMapGlobalExport *globals_out) {
    return analyze_boundary_pair(m,out,graph_out,record_out,mixed_out,prepared_stacks,portable_reads,map_out,globals_out,
# 1174 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                                        ((void *)0)
# 1174 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                                            );
}
static NvmArrayEligibilityResult analyze(const NvmModule *m,NvmArrayEligibilityReport **out,
    NvmArrayGraphEligibilityReport **graph_out,NvmRecordEligibilityReport **record_out,
    NvmRecordArrayOrigins **mixed_out,uint16_t *prepared_stacks,int portable_reads,
    NvmRecordMapFrozenContext **map_out) {
    return analyze_boundary(m,out,graph_out,record_out,mixed_out,prepared_stacks,portable_reads,map_out,
# 1180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                                                                       ((void *)0)
# 1180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                                                                           );
}

NvmArrayEligibilityResult nvm_analyze_managed_arrays(const NvmModule *m,NvmArrayEligibilityReport **out) {
    return analyze(m,out,
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                        ((void *)0)
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                            ,
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                             ((void *)0)
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                 ,
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                  ((void *)0)
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                      ,
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ,0,
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                              ((void *)0)
# 1184 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  );
}
NvmArrayEligibilityResult nvm_analyze_managed_array_graphs(const NvmModule *m,NvmArrayGraphEligibilityReport **out) {
    return analyze(m,
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                    ((void *)0)
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                        ,out,
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                             ((void *)0)
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                 ,
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                  ((void *)0)
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                      ,
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ,0,
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                              ((void *)0)
# 1187 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  );
}

NvmArrayEligibilityResult nvm_analyze_managed_records(const NvmModule *m,NvmRecordEligibilityReport **out) {
    return analyze(m,
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                    ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                        ,
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                         ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                             ,out,
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                  ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                      ,
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ,0,
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                              ((void *)0)
# 1191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  );
}

NvmArrayEligibilityResult nvm_analyze_record_array_origins(const NvmModule *m,NvmRecordArrayOrigins **out) {
    return analyze(m,
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                    ((void *)0)
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                        ,
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                         ((void *)0)
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                             ,
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                              ((void *)0)
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                  ,out,
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                       ((void *)0)
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                           ,0,
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                              ((void *)0)
# 1195 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  );
}

NvmArrayEligibilityResult nvm_select_managed_array_mode(const NvmModule *m,int *graph_required) {
    if(!graph_required) {
        NvmArrayEligibilityResult result={.status=NVM_ARRAY_INVALID};
        snprintf(result.message,sizeof result.message,"I require an array-mode output.");
        return result;
    }
    NvmArrayEligibilityReport *leaf=
# 1204 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                   ((void *)0)
# 1204 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                       ;
    NvmArrayEligibilityResult result=nvm_analyze_managed_arrays(m,&leaf);
    nvm_array_eligibility_free(leaf);
    if(result.status==NVM_ARRAY_ELIGIBLE){*graph_required=0;return result;}
    if(result.status!=NVM_ARRAY_UNRESOLVED)return result;
    NvmArrayGraphEligibilityReport *graph=
# 1209 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                         ((void *)0)
# 1209 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                             ;
    result=nvm_analyze_managed_array_graphs(m,&graph);
    nvm_array_graph_eligibility_free(graph);
    if(result.status==NVM_ARRAY_ELIGIBLE)*graph_required=1;
    return result;
}

void nvm_managed_heap_plan_free(NvmManagedHeapPlan *plan) {
    if(!plan)return;
    nvm_record_plan_free(plan->records);
    nvm_record_eligibility_free(plan->fields);
    free(plan);
}
NvmArrayEligibilityResult nvm_select_managed_heap(const NvmModule *m,int mutable_arrays,
                                                 NvmManagedHeapPlan **out) {
    NvmArrayEligibilityResult result={.status=NVM_ARRAY_INVALID};
    snprintf(result.message,sizeof result.message,"I require a module and heap-plan output.");
    if(!m || !out)return result;
    NvmVerifyResult verified=nvm_verify(m);
    if(!verified.ok)return result;
    NvmManagedHeapPlan staged={0};
    if(m->struct_count || m->layout_size || m->ownership_size) {
        NvmRecordPlanResult described=nvm_describe_managed_records(m,&staged.records);
        if(described.status!=NVM_RECORD_DESCRIBED) {
            result.status=described.status==NVM_RECORD_MEMORY?NVM_ARRAY_MEMORY:
                described.status==NVM_RECORD_LIMIT?NVM_ARRAY_LIMIT:
                described.status==NVM_RECORD_INVALID?NVM_ARRAY_INVALID:NVM_ARRAY_UNRESOLVED;
            snprintf(result.message,sizeof result.message,"%s",described.message);
            return result;
        }
        if(staged.records->authority!=NVM_RECORD_AUTHORITY_ORDINARY) {
            result.status=NVM_ARRAY_UNRESOLVED;
            snprintf(result.message,sizeof result.message,"I require checked ordinary record authority.");
        } else result=nvm_analyze_managed_records(m,&staged.fields);
        staged.mode=NVM_MANAGED_RECORD;
    } else if(mutable_arrays) {
        int graph=0;
        result=nvm_select_managed_array_mode(m,&graph);
        staged.mode=graph?NVM_MANAGED_ARRAY_GRAPH:NVM_MANAGED_LEAF;
    } else result.status=NVM_ARRAY_ELIGIBLE;
    if(result.status==NVM_ARRAY_ELIGIBLE) {
        NvmManagedHeapPlan *plan=allocate(1,sizeof *plan);
        if(plan){*plan=staged;*out=plan;return result;}
        result.status=NVM_ARRAY_MEMORY;
        snprintf(result.message,sizeof result.message,"I could not publish my managed heap plan.");
    }
    nvm_record_plan_free(staged.records);
    nvm_record_eligibility_free(staged.fields);
    return result;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_snapshot_private.h" 1




typedef struct NvmRecordArrayImage NvmRecordArrayImage;
typedef struct { uint64_t bytes_reserved, work_charged; } NvmRecordArrayImageCost;

# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_snapshot_private.h" 3 4
_Bool 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_snapshot_private.h"
    nvm_record_array_image_bound(const NvmRecordArrayExecutionPlan *,NvmRecordArrayImageCost *);
NvmArrayEligibilityResult nvm_record_array_image_copy(
    const NvmRecordArrayExecutionPlan *, NvmRecordArrayImage **);
const NvmModule *nvm_record_array_image_borrow(const NvmRecordArrayImage *);

# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_snapshot_private.h" 3 4
_Bool 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_snapshot_private.h"
    nvm_record_array_image_cost(const NvmRecordArrayImage *, NvmRecordArrayImageCost *);
void nvm_record_array_image_free(NvmRecordArrayImage *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 2
struct NvmRecordArrayExecutionPlan {
    NvmModule snapshot;
    NvmRecordArrayOrigins *origins;
    NvmRecordArrayExecutionCounts counts;
    NvmRecordArrayExecutionFunction functions[256];
    uint16_t maximum_stacks[256];
    NvmRecordArrayExecutionDescriptor descriptors[256];
    NvmRecordArrayExecutionInstruction *instructions;
    uint64_t bytes, work;
    NvmArrayEligibilityStatus failure;
};
static int rae_charge(NvmRecordArrayExecutionPlan *p,uint64_t bytes,uint64_t work) {
    if(p->bytes>(128UL*1024*1024) || p->work>33554432UL ||
       bytes>(128UL*1024*1024)-p->bytes || work>33554432UL -p->work) {
        p->failure=NVM_ARRAY_LIMIT;return 0;
    }
    p->bytes+=bytes;p->work+=work;return 1;
}
static void *rae_copy(NvmRecordArrayExecutionPlan *p,const void *source,size_t n,size_t width) {
    if(width && n>
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                 (18446744073709551615UL)
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                         /width){p->failure=NVM_ARRAY_LIMIT;return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                   ((void *)0)
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                       ;}
    size_t bytes=n*width;
    if(!bytes)return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                    ((void *)0)
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                        ;
    if(!source){p->failure=NVM_ARRAY_INVALID;return 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                   ((void *)0)
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                       ;}
    if(!rae_charge(p,bytes,bytes))return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                        ((void *)0)
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                            ;
    void *copy=malloc(bytes);
    if(!copy){p->failure=NVM_ARRAY_MEMORY;return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                ((void *)0)
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                    ;}
    memcpy(copy,source,bytes);return copy;
}
static void *rae_zero(NvmRecordArrayExecutionPlan *p,size_t n,size_t width) {
    if(width && n>
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                 (18446744073709551615UL)
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                         /width){p->failure=NVM_ARRAY_LIMIT;return 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                   ((void *)0)
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                       ;}
    size_t bytes=n*width;if(!bytes)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                         ((void *)0)
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                             ;
    if(!rae_charge(p,bytes,bytes))return 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                        ((void *)0)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                            ;
    void *v=calloc(n,width);if(!v)p->failure=NVM_ARRAY_MEMORY;return v;
}
static void rae_snapshot_free(NvmModule *m) {
    if(m->strings)for(uint32_t i=0;i<m->string_count;i++)free(m->strings[i]);
    if(m->function_param_types)for(uint32_t i=0;i<m->function_count;i++)free(m->function_param_types[i]);
    free(m->strings);free(m->string_lengths);free(m->functions);free(m->function_param_types);
    free(m->code);free(m->ownership_data);free(m->layout_data);free(m->metadata);free(m->debug_entries);
}
void nvm_record_array_execution_free(NvmRecordArrayExecutionPlan *p) {
    if(!p)return;
    rae_snapshot_free(&p->snapshot);
    nvm_record_array_origins_free(p->origins);free(p->instructions);free(p);
}
static int rae_snapshot(NvmRecordArrayExecutionPlan *p,const NvmModule *m) {

    if(m->service_data || m->service_size || m->passive_data || m->passive_size ||
       m->import_count || m->module_ref_count || m->callback_contract_count ||
       m->call_descriptors || m->call_descriptor_count) {
        p->failure=NVM_ARRAY_UNRESOLVED;return 0;
    }
    if(m->function_count>256 || m->string_count>4096 || m->code_size>16u*1024u*1024u) {
        p->failure=NVM_ARRAY_LIMIT;return 0;
    }
    if(!m->function_count || !m->functions || m->section_count>16 ||
       m->header.section_count>16 ||
       (m->string_count && (!m->strings || !m->string_lengths)))return 0;
    NvmModule *s=&p->snapshot;


    s->header=m->header;memcpy(s->sections,m->sections,sizeof s->sections);
    s->section_count=m->section_count;s->string_count=m->string_count;s->string_capacity=m->string_capacity;
    s->function_count=m->function_count;s->function_capacity=m->function_capacity;
    s->code_size=m->code_size;s->code_capacity=m->code_capacity;
    s->ownership_size=m->ownership_size;s->layout_size=m->layout_size;
    s->metadata_count=m->metadata_count;s->metadata_capacity=m->metadata_capacity;
    s->debug_count=m->debug_count;s->debug_capacity=m->debug_capacity;s->source_file_idx=m->source_file_idx;
    s->import_capacity=m->import_capacity;s->module_ref_capacity=m->module_ref_capacity;
    s->callback_contract_capacity=m->callback_contract_capacity;
    s->struct_count=m->struct_count;s->union_count=m->union_count;s->enum_count=m->enum_count;

    do { s->functions=rae_copy(p,m->functions,(m->function_count),sizeof *s->functions); if((m->function_count) && !s->functions)return 0; } while(0);do { s->code=rae_copy(p,m->code,(m->code_size),sizeof *s->code); if((m->code_size) && !s->code)return 0; } while(0);
    do { s->ownership_data=rae_copy(p,m->ownership_data,(m->ownership_size),sizeof *s->ownership_data); if((m->ownership_size) && !s->ownership_data)return 0; } while(0);do { s->layout_data=rae_copy(p,m->layout_data,(m->layout_size),sizeof *s->layout_data); if((m->layout_size) && !s->layout_data)return 0; } while(0);
    do { s->metadata=rae_copy(p,m->metadata,(m->metadata_count),sizeof *s->metadata); if((m->metadata_count) && !s->metadata)return 0; } while(0);do { s->debug_entries=rae_copy(p,m->debug_entries,(m->debug_count),sizeof *s->debug_entries); if((m->debug_count) && !s->debug_entries)return 0; } while(0);
    do { s->string_lengths=rae_copy(p,m->string_lengths,(m->string_count),sizeof *s->string_lengths); if((m->string_count) && !s->string_lengths)return 0; } while(0);

    s->strings=rae_zero(p,m->string_count,sizeof *s->strings);
    if(m->string_count && !s->strings)return 0;
    for(uint32_t i=0;i<m->string_count;i++) {
        if((uint64_t)m->string_lengths[i]+1>
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                           (18446744073709551615UL)
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                   ){p->failure=NVM_ARRAY_LIMIT;return 0;}
        s->strings[i]=rae_copy(p,m->strings[i],(size_t)m->string_lengths[i]+1,1);
        if(!s->strings[i])return 0;
    }
    if(m->function_param_types) {
        s->function_param_types=rae_zero(p,m->function_count,sizeof *s->function_param_types);
        if(!s->function_param_types)return 0;
    }
    for(uint32_t i=0;i<m->function_count;i++) {
        if(m->functions[i].arity>256 || m->functions[i].local_count>256){p->failure=NVM_ARRAY_LIMIT;return 0;}
        if(m->function_param_types && m->function_param_types[i]) {

            size_t n=m->functions[i].arity;
            s->function_param_types[i]=n?rae_copy(p,m->function_param_types[i],n,1):rae_zero(p,1,1);
            if(!s->function_param_types[i])return 0;
        }
    }
    return 1;
}
static int rae_equal_bytes(NvmRecordArrayExecutionPlan *p,const void *a,const void *b,size_t n) {
    if(!rae_charge(p,0,n))return 0;
    return !n || (a && b && !memcmp(a,b,n));
}
static int rae_same(NvmRecordArrayExecutionPlan *p,const NvmModule *m) {
    const NvmModule *s=&p->snapshot;
    if(!rae_charge(p,0,1024))return 0;

    if(s->header.format_version!=m->header.format_version)return 0;if(s->header.flags!=m->header.flags)return 0;if(s->header.entry_point!=m->header.entry_point)return 0;if(s->header.section_count!=m->header.section_count)return 0;
    if(s->header.string_pool_offset!=m->header.string_pool_offset)return 0;if(s->header.string_pool_length!=m->header.string_pool_length)return 0;if(s->header.checksum!=m->header.checksum)return 0;
    if(s->section_count!=m->section_count)return 0;if(s->string_count!=m->string_count)return 0;if(s->string_capacity!=m->string_capacity)return 0;if(s->function_count!=m->function_count)return 0;if(s->function_capacity!=m->function_capacity)return 0;
    if(s->code_size!=m->code_size)return 0;if(s->code_capacity!=m->code_capacity)return 0;if(s->ownership_size!=m->ownership_size)return 0;if(s->layout_size!=m->layout_size)return 0;if(s->service_size!=m->service_size)return 0;if(s->passive_size!=m->passive_size)return 0;
    if(s->metadata_count!=m->metadata_count)return 0;if(s->metadata_capacity!=m->metadata_capacity)return 0;if(s->debug_count!=m->debug_count)return 0;if(s->debug_capacity!=m->debug_capacity)return 0;if(s->source_file_idx!=m->source_file_idx)return 0;
    if(s->import_count!=m->import_count)return 0;if(s->import_capacity!=m->import_capacity)return 0;if(s->module_ref_count!=m->module_ref_count)return 0;if(s->module_ref_capacity!=m->module_ref_capacity)return 0;
    if(s->callback_contract_count!=m->callback_contract_count)return 0;if(s->callback_contract_capacity!=m->callback_contract_capacity)return 0;if(s->call_descriptor_count!=m->call_descriptor_count)return 0;
    if(s->struct_count!=m->struct_count)return 0;if(s->enum_count!=m->enum_count)return 0;if(s->union_count!=m->union_count)return 0;

    if(m->service_data || m->passive_data || m->call_descriptors ||
       !!s->function_param_types!=!!m->function_param_types)return 0;
    if(!rae_equal_bytes(p,s->header.magic,m->header.magic,4))return 0;
    for(uint32_t i=0;i<s->section_count;i++)
        if(s->sections[i].type!=m->sections[i].type || s->sections[i].offset!=m->sections[i].offset ||
           s->sections[i].size!=m->sections[i].size)return 0;
    for(uint32_t i=0;i<s->function_count;i++) {
        if(!rae_charge(p,0,16))return 0;
        const NvmFunctionEntry *a=&s->functions[i],*b=&m->functions[i];

        if(a->name_idx!=b->name_idx)return 0;if(a->arity!=b->arity)return 0;if(a->code_offset!=b->code_offset)return 0;if(a->code_length!=b->code_length)return 0;if(a->local_count!=b->local_count)return 0;if(a->upvalue_count!=b->upvalue_count)return 0;if(a->result_tag!=b->result_tag)return 0;if(a->result_count!=b->result_count)return 0;

        if(s->function_param_types) {
            if(!!s->function_param_types[i]!=!!m->function_param_types[i])return 0;
            if(s->function_param_types[i] && !rae_equal_bytes(p,s->function_param_types[i],m->function_param_types[i],a->arity))return 0;
        }
    }
    for(uint32_t i=0;i<s->string_count;i++) {
        if(!rae_charge(p,0,1) || s->string_lengths[i]!=m->string_lengths[i] ||
           !rae_equal_bytes(p,s->strings[i],m->strings[i],(size_t)s->string_lengths[i]+1))return 0;
    }
    for(uint32_t i=0;i<s->metadata_count;i++) {
        if(!rae_charge(p,0,2) || s->metadata[i].key_idx!=m->metadata[i].key_idx || s->metadata[i].value_idx!=m->metadata[i].value_idx)return 0;
    }
    for(uint32_t i=0;i<s->debug_count;i++) {
        if(!rae_charge(p,0,3) || s->debug_entries[i].bytecode_offset!=m->debug_entries[i].bytecode_offset ||
           s->debug_entries[i].source_line!=m->debug_entries[i].source_line || s->debug_entries[i].source_col!=m->debug_entries[i].source_col)return 0;
    }
    return rae_equal_bytes(p,s->code,m->code,s->code_size) &&
        rae_equal_bytes(p,s->layout_data,m->layout_data,s->layout_size) &&
        rae_equal_bytes(p,s->ownership_data,m->ownership_data,s->ownership_size);
}


static int rae_recipe(uint8_t op,NvmRecordArrayExecutionInstruction *r) {
    r->obligations=NVM_RA_FIRST_ERROR_CLEANUP|NVM_RA_CHECK_TAGS;
    switch(op) {
    case OP_PUSH_I64: case OP_PUSH_U8: case OP_PUSH_F64: case OP_PUSH_BOOL: case OP_PUSH_VOID:
        r->recipe=NVM_RA_ROOT_CONSTANT;r->obligations=NVM_RA_FIRST_ERROR_CLEANUP;break;
    case OP_PUSH_STR:
        r->recipe=NVM_RA_ROOT_CONSTANT;r->obligations|=NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_NOP:r->recipe=NVM_RA_ROOT_SCALAR;r->obligations=NVM_RA_FIRST_ERROR_CLEANUP;break;
    case OP_I64_ADD: case OP_I64_SUB: case OP_I64_MUL: case OP_I64_DIV_S:
    case OP_I64_REM_S: case OP_I64_NEG: case OP_F64_TO_BITS: case OP_F64_FROM_BITS:
    case OP_F64_ADD: case OP_F64_SUB: case OP_F64_MUL: case OP_F64_DIV: case OP_F64_NEG:
    case OP_CAST_INT: case OP_CAST_FLOAT: case OP_CAST_BOOL: case OP_CAST_U8: case OP_TYPE_CHECK:
    case OP_EQ: case OP_NE: case OP_LT: case OP_LE: case OP_GT: case OP_GE:
    case OP_I64_EQ: case OP_I64_NE: case OP_I64_LT_S: case OP_I64_LE_S: case OP_I64_GT_S: case OP_I64_GE_S:
    case OP_F64_EQ: case OP_F64_NE: case OP_F64_LT: case OP_F64_LE: case OP_F64_GT: case OP_F64_GE:
    case OP_BOOL_AND: case OP_BOOL_OR: case OP_BOOL_NOT: case OP_AND: case OP_OR: case OP_NOT:
    case OP_STR_LEN: case OP_STR_CHAR_AT: case OP_ARR_LEN:
    case OP_STR_EQ: case OP_STR_CONTAINS: case OP_STR_STARTS_WITH: case OP_STR_ENDS_WITH:
        r->recipe=NVM_RA_ROOT_SCALAR;break;
    case OP_CAST_STRING: case OP_STR_CONCAT: case OP_STR_SUBSTR: case OP_STR_TRIM:
    case OP_STR_TO_LOWER: case OP_STR_TO_UPPER: case OP_STR_REPLACE:
    case OP_STR_FROM_INT: case OP_STR_FROM_FLOAT: case OP_STR_SPLIT:
        r->recipe=NVM_RA_ROOT_STRING;
        r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS;break;
    case OP_LOAD_LOCAL: case OP_LOAD_GLOBAL:r->recipe=NVM_RA_ROOT_LOAD;r->obligations|=NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_STORE_LOCAL: case OP_STORE_GLOBAL:r->recipe=NVM_RA_ROOT_STORE;r->obligations|=NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_DUP:r->recipe=NVM_RA_ROOT_DUP;r->obligations|=NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_SWAP:r->recipe=NVM_RA_ROOT_SWAP;break;
    case OP_POP: case OP_ASSERT:r->recipe=NVM_RA_ROOT_DROP;break;
    case OP_JMP: case OP_JMP_TRUE: case OP_JMP_FALSE:r->recipe=NVM_RA_ROOT_BRANCH;break;
    case OP_CALL:r->recipe=NVM_RA_ROOT_CALL;r->obligations|=NVM_RA_STAGE_OPERANDS;break;
    case OP_TAIL_CALL:r->recipe=NVM_RA_ROOT_TAIL;r->obligations|=NVM_RA_STAGE_OPERANDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_RET:r->recipe=NVM_RA_ROOT_RETURN;r->obligations|=NVM_RA_STAGE_OPERANDS;break;
    case OP_STRUCT_NEW: case OP_STRUCT_LITERAL: case OP_AGG_PACK:
        r->recipe=NVM_RA_ROOT_CONSTRUCT;
        r->obligations|=NVM_RA_CHECK_NOMINAL|NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS;break;
    case OP_ARR_NEW: case OP_ARR_LITERAL:
        r->recipe=NVM_RA_ROOT_CONSTRUCT;r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS;break;
    case OP_STRUCT_GET: case OP_AGG_GET:
        r->recipe=NVM_RA_ROOT_GET;r->obligations|=NVM_RA_CHECK_NOMINAL|NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_ARR_GET:r->recipe=NVM_RA_ROOT_GET;r->obligations|=NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_STRUCT_SET: case OP_AGG_SET:
        r->recipe=NVM_RA_ROOT_SET;r->obligations|=NVM_RA_CHECK_NOMINAL|NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_ARR_SET:r->recipe=NVM_RA_ROOT_SET;r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS|NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_ARR_PUSH:r->recipe=NVM_RA_ROOT_ARRAY_PUSH;r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_ARR_POP:r->recipe=NVM_RA_ROOT_ARRAY_POP;r->obligations|=NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;break;
    case OP_ARR_SLICE:r->recipe=NVM_RA_ROOT_ARRAY_COPY;r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS|NVM_RA_CHECK_BOUNDS;break;
    default:return 0;
    }
    return 1;
}
static int rae_instructions_policy(NvmRecordArrayExecutionPlan *p,
        int (*recipe)(uint8_t,NvmRecordArrayExecutionInstruction *),int halt_terminal) {
    const NvmModule *m=&p->snapshot;uint32_t total=0;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        const NvmFunctionEntry *f=&m->functions[fi];
        if(!rae_charge(p,0,(uint64_t)f->code_length+32))return 0;
        NvmRecordArrayExecutionFunction *copy=&p->functions[fi];copy->signature=*f;
        copy->maximum_stack=p->maximum_stacks[fi];copy->instruction_start=total;
        copy->parameter_tags_present=m->function_param_types && m->function_param_types[fi];
        for(uint32_t pc=0;pc<f->code_length;) {
            DecodedInstruction in;uint32_t size=isa_decode(m->code+f->code_offset+pc,f->code_length-pc,&in);
            if(!size || total==65536){p->failure=size?NVM_ARRAY_LIMIT:NVM_ARRAY_INVALID;return 0;}
            total++;copy->instruction_count++;pc+=size;
        }
        uint32_t name=f->name_idx;
        if(!rae_charge(p,0,8))return 0;
        if(p->counts.initializer==
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                 (4294967295U) 
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                            && name<m->string_count && m->string_lengths[name]==8 &&
           !memcmp(m->strings[name],"__init__",8))p->counts.initializer=fi;
    }
    p->counts.instructions=total;
    p->instructions=rae_zero(p,total,sizeof *p->instructions);
    if(total && !p->instructions)return 0;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        const NvmFunctionEntry *f=&m->functions[fi];
        if(!rae_charge(p,0,(uint64_t)f->code_length+p->functions[fi].instruction_count*64u))return 0;
        uint8_t *boundaries=rae_zero(p,(size_t)f->code_length+1,1);
        if(!boundaries)return 0;
        uint32_t index=p->functions[fi].instruction_start;
        for(uint32_t pc=0;pc<f->code_length;) {
            DecodedInstruction in;uint32_t size=isa_decode(m->code+f->code_offset+pc,f->code_length-pc,&in);
            if(!size){free(boundaries);return 0;}
            NvmRecordArrayExecutionInstruction *r=&p->instructions[index++];
            const InstructionInfo *info=isa_get_info(in.opcode);
            if(!info || !recipe(in.opcode,r)) {
                free(boundaries);p->failure=NVM_ARRAY_UNRESOLVED;return 0;
            }
            boundaries[pc]=1;r->function=fi;r->pc=pc;r->next_pc=pc+size;r->opcode=in.opcode;r->callee=
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                                                     (4294967295U)
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                                                               ;
            r->operand_count=info->operand_count;uint32_t offset=1;
            for(uint8_t j=0;j<info->operand_count;j++) {
                uint32_t width=isa_operand_size(info->operands[j]);
                if(width>8 || offset>size || width>size-offset){free(boundaries);return 0;}
                r->operand_types[j]=(uint8_t)info->operands[j];
                for(uint32_t k=0;k<width;k++)r->operand_bits[j]|=(uint64_t)m->code[f->code_offset+pc+offset+k]<<(k*8u);
                offset+=width;
            }
            if(offset!=size){free(boundaries);return 0;}
            int pops=info->pop_count,pushes=info->push_count;
            if(in.opcode==OP_ARR_LITERAL || in.opcode==OP_STRUCT_LITERAL){pops=in.operands[1].u16;pushes=1;}
            if(in.opcode==OP_AGG_PACK){pops=in.operands[3].u16;pushes=1;}
            if(in.opcode==OP_CALL || in.opcode==OP_TAIL_CALL) {
                r->callee=in.operands[0].u32;
                if(r->callee>=m->function_count){free(boundaries);return 0;}
                pops=m->functions[r->callee].arity;pushes=in.opcode==OP_TAIL_CALL?0:m->functions[r->callee].result_count;
            }
            if(in.opcode==OP_RET){pops=f->result_count;pushes=0;}
            if(pops<0 || pushes<0 || pops>256 || pushes>256){free(boundaries);return 0;}
            r->pops=(uint16_t)pops;r->pushes=(uint16_t)pushes;
            if(in.opcode==OP_JMP || in.opcode==OP_JMP_TRUE || in.opcode==OP_JMP_FALSE) {
                int64_t target=(int64_t)pc+in.operands[0].i32;
                if(target<0 || (uint64_t)target>f->code_length){free(boundaries);return 0;}
                r->successors[r->successor_count++]=(uint32_t)target;
            }
            if(in.opcode!=OP_JMP && in.opcode!=OP_RET && in.opcode!=OP_TAIL_CALL && !(halt_terminal && in.opcode==OP_HALT))r->successors[r->successor_count++]=pc+size;
            if(in.opcode==OP_LOAD_GLOBAL || in.opcode==OP_STORE_GLOBAL) {
                uint32_t count=in.operands[0].u32+1;
                if(count>256){free(boundaries);return 0;}
                if(count>p->counts.globals)p->counts.globals=count;
            }
            pc+=size;
        }
        boundaries[f->code_length]=1;

        if(!rae_charge(p,0,(uint64_t)p->functions[fi].instruction_count*3u)){free(boundaries);return 0;}
        for(uint32_t i=p->functions[fi].instruction_start;i<index;i++) {
            NvmRecordArrayExecutionInstruction *r=&p->instructions[i];
            for(uint8_t j=0;j<r->successor_count;j++)if(!boundaries[r->successors[j]]){free(boundaries);return 0;}
        }
        free(boundaries);
    }
    return 1;
}
static int rae_instructions_using(NvmRecordArrayExecutionPlan *p,
        int (*recipe)(uint8_t,NvmRecordArrayExecutionInstruction *)) {
    return rae_instructions_policy(p,recipe,0);
}
static int rae_old_recipe(uint8_t op,NvmRecordArrayExecutionInstruction *r) {
    return nvm_record_array_opcode_supported(op) && rae_recipe(op,r);
}
static int rae_instructions(NvmRecordArrayExecutionPlan *p) {
    return rae_instructions_using(p,rae_old_recipe);
}
NvmArrayEligibilityResult nvm_prepare_record_array_execution(const NvmModule *m,NvmRecordArrayExecutionPlan **out) {
    NvmArrayEligibilityResult r={.status=NVM_ARRAY_INVALID};
    snprintf(r.message,sizeof r.message,"I require a stable original module and plan output.");
    if(!m || !out)return r;
    NvmRecordArrayExecutionPlan *p=calloc(1,sizeof *p);
    if(!p){r.status=NVM_ARRAY_MEMORY;return r;}
    p->failure=NVM_ARRAY_INVALID;p->counts.initializer=
# 303 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                      (4294967295U)
# 303 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                ;


    p->bytes=64UL*1024*1024;p->work=16777216UL;
    if(!rae_charge(p,65536u+sizeof *p,65536u+sizeof *p) || !rae_snapshot(p,m))goto fail;


    for(uint32_t fi=0;fi<p->snapshot.function_count;fi++) {
        uint32_t name=p->snapshot.functions[fi].name_idx;
        if(name>=p->snapshot.string_count)goto fail;
        uint32_t length=p->snapshot.string_lengths[name];
        if(!rae_charge(p,0,(uint64_t)length+1))goto fail;
        if(memchr(p->snapshot.strings[name],0,length)) {
            p->failure=NVM_ARRAY_UNRESOLVED;goto fail;
        }
    }
    r=analyze(&p->snapshot,
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                          ((void *)0)
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                              ,
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                               ((void *)0)
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                   ,
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                    ((void *)0)
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                        ,&p->origins,p->maximum_stacks,0,
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                         ((void *)0)
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                             );
    if(r.status!=NVM_ARRAY_ELIGIBLE){nvm_record_array_execution_free(p);return r;}

    if(!rae_charge(p,0,256))goto fail;
    for(uint32_t op=0;op<256;op++) {
        NvmRecordArrayExecutionInstruction recipe={0};
        if(!!nvm_record_array_opcode_supported((uint8_t)op)!=!!rae_recipe((uint8_t)op,&recipe)) {
            p->failure=NVM_ARRAY_UNRESOLVED;goto fail;
        }
    }
    NvmDeclarationCounts declarations;
    if(!nvm_record_array_declaration_counts(p->origins,&declarations) || declarations.layouts>256)goto fail;
    if(!rae_charge(p,0,(uint64_t)declarations.layouts*4u))goto fail;
    for(uint32_t i=0;i<declarations.layouts;i++) {
        NvmDeclarationLayout row;
        if(!nvm_record_array_declaration_layout(p->origins,i,&row))goto fail;
        if(row.kind==NVM_V2_LAYOUT_STRUCT) {
            uint32_t ordinal=p->counts.records++;
            p->descriptors[ordinal]=(NvmRecordArrayExecutionDescriptor){ordinal,i,row.fields};
        }
    }
    if(p->counts.records!=p->snapshot.struct_count)goto fail;
    if(!rae_instructions(p) || !rae_same(p,m))goto fail;
    p->counts.strings=p->snapshot.string_count;p->counts.sections=p->snapshot.section_count;
    p->counts.metadata=p->snapshot.metadata_count;p->counts.debug=p->snapshot.debug_count;
    p->counts.functions=p->snapshot.function_count;p->counts.entry=p->snapshot.header.entry_point;
    p->counts.frame_limit=1024u;
    p->counts.peak_bytes_reserved=p->bytes;p->counts.work_reserved=p->work;
    *out=p;r.status=NVM_ARRAY_ELIGIBLE;
    snprintf(r.message,sizeof r.message,"I copied complete execution facts; I grant no executable admission.");return r;
fail:
    r.status=p->failure;snprintf(r.message,sizeof r.message,"I could not prepare bounded exact mixed execution facts.");
    nvm_record_array_execution_free(p);return r;
}

# 353 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 353 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_counts(const NvmRecordArrayExecutionPlan *p,NvmRecordArrayExecutionCounts *out) {
    if(!p || !out)return 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                        0
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                             ;
    *out=p->counts;return 
# 355 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                         1
# 355 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                             ;
}

# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_function(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out) {
    if(!p || !out || i>=p->counts.functions)return 
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                  0
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                       ;
    *out=p->functions[i];return 
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                               1
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                   ;
}

# 361 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 361 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_instruction(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionInstruction *out) {
    if(!p || !out || i>=p->counts.instructions)return 
# 362 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                     0
# 362 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                          ;
    *out=p->instructions[i];return 
# 363 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                  1
# 363 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                      ;
}

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_parameter(const NvmRecordArrayExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out) {
    if(!p || !out || fi>=p->counts.functions || !p->functions[fi].parameter_tags_present || i>=p->snapshot.functions[fi].arity)return 
# 366 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                                                                                     0
# 366 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                                                                                          ;
    *out=p->snapshot.function_param_types[fi][i];return 
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                       1
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                           ;
}

# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_bytes(const NvmRecordArrayExecutionPlan *p,NvmRecordArraySnapshotKind kind,
        uint32_t index,uint32_t offset,uint32_t count,void *out) {
    if(!p || !out)return 
# 371 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                        0
# 371 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                             ;
    const void *source=
# 372 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                      ((void *)0)
# 372 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                          ;uint32_t size=0;
    switch(kind) {
    case NVM_RA_SNAPSHOT_CODE:if(index)return 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                             0
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                  ;source=p->snapshot.code;size=p->snapshot.code_size;break;
    case NVM_RA_SNAPSHOT_LAYOUTS:if(index)return 
# 375 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                0
# 375 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                     ;source=p->snapshot.layout_data;size=p->snapshot.layout_size;break;
    case NVM_RA_SNAPSHOT_OWNERSHIP:if(index)return 
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                  0
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                       ;source=p->snapshot.ownership_data;size=p->snapshot.ownership_size;break;
    case NVM_RA_SNAPSHOT_STRING:if(index>=p->snapshot.string_count)return 
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                         0
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                              ;source=p->snapshot.strings[index];size=p->snapshot.string_lengths[index];break;
    default:return 
# 378 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                  0
# 378 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                       ;
    }
    if(offset>size || count>size-offset)return 
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                              0
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                   ;
    if(count)memcpy(out,(const uint8_t *)source+offset,count);
    return 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
          1
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
              ;
}



# 386 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 386 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_origin(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out){return p && nvm_record_array_origin(p->origins,i,out);}

# 387 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 387 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_field_value(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out){return p && nvm_record_array_field_value(p->origins,i,out);}

# 388 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 388 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_required_elements(const NvmRecordArrayExecutionPlan *p,uint32_t i,uint16_t *out){return p && nvm_record_array_required_elements(p->origins,i,out);}

# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_layout(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out){return p && nvm_record_array_declaration_layout(p->origins,i,out);}

# 390 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 390 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_type(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out){return p && nvm_record_array_declaration_type(p->origins,i,out);}

# 391 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 391 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
nvm_record_array_execution_binding(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out){return p && nvm_record_array_declaration_binding(p->origins,i,out);}


# 393 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 393 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_declaration_counts(const NvmRecordArrayExecutionPlan *p,NvmDeclarationCounts *out) {
    return p && nvm_record_array_declaration_counts(p->origins,out);
}

# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_field(const NvmRecordArrayExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out) {
    return p && nvm_record_array_declaration_field(p->origins,i,field,out);
}

# 399 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 399 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_variant(const NvmRecordArrayExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out) {
    return p && nvm_record_array_declaration_variant(p->origins,i,variant,out);
}

# 402 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 402 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_header(const NvmRecordArrayExecutionPlan *p,NvmHeader *out) {
    if(!p || !out)return 
# 403 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                        0
# 403 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                             ;
    *out=p->snapshot.header;return 
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                  1
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                      ;
}

# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_section(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmSectionEntry *out) {
    if(!p || !out || i>=p->snapshot.section_count)return 
# 407 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                        0
# 407 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                             ;
    *out=p->snapshot.sections[i];return 
# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                       1
# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                           ;
}

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_metadata(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmMetadataEntry *out) {
    if(!p || !out || i>=p->snapshot.metadata_count)return 
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                         0
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                              ;
    *out=p->snapshot.metadata[i];return 
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                       1
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                           ;
}

# 414 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 414 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_debug(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmDebugEntry *out) {
    if(!p || !out || i>=p->snapshot.debug_count)return 
# 415 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                      0
# 415 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                           ;
    *out=p->snapshot.debug_entries[i];return 
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                            1
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                ;
}

# 418 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 418 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_size(const NvmRecordArrayExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out) {
    if(!p || !out)return 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                        0
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                             ;
    uint32_t value;
    switch(kind) {
    case NVM_RA_SNAPSHOT_CODE:if(index)return 
# 422 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                             0
# 422 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                  ;value=p->snapshot.code_size;break;
    case NVM_RA_SNAPSHOT_LAYOUTS:if(index)return 
# 423 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                0
# 423 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                     ;value=p->snapshot.layout_size;break;
    case NVM_RA_SNAPSHOT_OWNERSHIP:if(index)return 
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                  0
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                       ;value=p->snapshot.ownership_size;break;
    case NVM_RA_SNAPSHOT_STRING:if(index>=p->snapshot.string_count)return 
# 425 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                         0
# 425 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                              ;value=p->snapshot.string_lengths[index];break;
    default:return 
# 426 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                  0
# 426 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                       ;
    }
    *out=value;return 
# 428 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                     1
# 428 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                         ;
}

# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 430 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_origin_counts(const NvmRecordArrayExecutionPlan *p,NvmRecordArrayOriginCounts *out) {
    return p && nvm_record_array_origins_counts(p->origins,out);
}


# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_execution_descriptor(const NvmRecordArrayExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out) {
    if(!p || !out || i>=p->counts.records)return 
# 435 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                0
# 435 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                     ;
    *out=p->descriptors[i];return 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                 1
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                     ;
}



struct NvmRecordArrayImage { NvmRecordArrayExecutionPlan storage; };



# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_image_bound(const NvmRecordArrayExecutionPlan *plan,
                                 NvmRecordArrayImageCost *out) {
    if(!plan || !out)return 
# 446 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                           0
# 446 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                ;
    const NvmModule *m=&plan->snapshot;
    uint64_t bytes=sizeof(NvmRecordArrayImage),compare=1028;
    bytes+=(uint64_t)m->function_count*sizeof *m->functions+m->code_size+
        (uint64_t)m->ownership_size+m->layout_size+
        (uint64_t)m->metadata_count*sizeof *m->metadata+
        (uint64_t)m->debug_count*sizeof *m->debug_entries+
        (uint64_t)m->string_count*(sizeof *m->strings+sizeof *m->string_lengths);
    compare+=(uint64_t)m->function_count*16+m->code_size+
        (uint64_t)m->ownership_size+m->layout_size+
        (uint64_t)m->metadata_count*2+(uint64_t)m->debug_count*3;
    if(m->function_param_types)bytes+=(uint64_t)m->function_count*sizeof *m->function_param_types;
    for(uint32_t i=0;i<m->function_count;i++)
        if(m->function_param_types && m->function_param_types[i]) {
            bytes+=m->functions[i].arity?m->functions[i].arity:1;
            compare+=m->functions[i].arity;
        }
    for(uint32_t i=0;i<m->string_count;i++) {
        bytes+=(uint64_t)m->string_lengths[i]+1;
        compare+=(uint64_t)m->string_lengths[i]+2;
    }

    uint64_t work=bytes+compare+1024+(uint64_t)m->function_count*8+
        (uint64_t)m->string_count*4;
    if(bytes>(128UL*1024*1024) || work>33554432UL)return 
# 470 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                                             0
# 470 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                                                  ;
    *out=(NvmRecordArrayImageCost){bytes,work};return 
# 471 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                     1
# 471 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                         ;
}
NvmArrayEligibilityResult nvm_record_array_image_copy(
        const NvmRecordArrayExecutionPlan *plan,NvmRecordArrayImage **out) {
    NvmArrayEligibilityResult result={NVM_ARRAY_INVALID,0,0,"I require a copied plan and image output."};
    if(!plan || !out)return result;
    NvmRecordArrayImageCost bound;
    if(!nvm_record_array_image_bound(plan,&bound)){result.status=NVM_ARRAY_LIMIT;return result;}


    if(sizeof(NvmRecordArrayImage)>(128UL*1024*1024) ||
       sizeof(NvmRecordArrayImage)>33554432UL) {
        result.status=NVM_ARRAY_LIMIT;return result;
    }
    NvmRecordArrayImage *image=calloc(1,sizeof *image);
    if(!image){result.status=NVM_ARRAY_MEMORY;return result;}
    NvmRecordArrayExecutionPlan *copy=&image->storage;
    copy->failure=NVM_ARRAY_INVALID;
    copy->bytes=sizeof *image;copy->work=sizeof *image;
    if(!rae_snapshot(copy,&plan->snapshot) ||
       !rae_same(copy,&plan->snapshot)) {
        result.status=copy->failure;nvm_record_array_image_free(image);return result;
    }
    if(copy->bytes>bound.bytes_reserved || copy->work>bound.work_charged) {
        result.status=NVM_ARRAY_LIMIT;nvm_record_array_image_free(image);return result;
    }
    copy->bytes=bound.bytes_reserved;copy->work=bound.work_charged;
    *out=image;result.status=NVM_ARRAY_ELIGIBLE;
    snprintf(result.message,sizeof result.message,"I copied an exact private image without executable admission.");
    return result;
}
const NvmModule *nvm_record_array_image_borrow(const NvmRecordArrayImage *image) {
    return image?&image->storage.snapshot:
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                         ((void *)0)
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                             ;
}

# 505 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
_Bool 
# 505 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
    nvm_record_array_image_cost(const NvmRecordArrayImage *image,NvmRecordArrayImageCost *out) {
    if(!image || !out)return 
# 506 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                            0
# 506 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                 ;
    *out=(NvmRecordArrayImageCost){image->storage.bytes,image->storage.work};return 
# 507 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc" 3 4
                                                                                   1
# 507 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_array_execution.inc"
                                                                                       ;
}
void nvm_record_array_image_free(NvmRecordArrayImage *image) {
    if(!image)return;
    rae_snapshot_free(&image->storage.snapshot);free(image);
}
# 1261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 1

_Static_assert(
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
              (255)
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                        >NVM_RA_ROOT_TAIL,"union sentinel cannot alias an old recipe");
struct NvmUnionFieldExecutionPlan {
    NvmRecordArrayExecutionPlan *carrier;
    NvmUnionFieldProof *proof;
    NvmUnionFieldSite *sites;
    uint32_t site_count,reserved;
};
void nvm_union_field_execution_free(NvmUnionFieldExecutionPlan *p) {
    if(!p)return;
    nvm_record_array_execution_free(p->carrier);
    nvm_union_field_proof_free(p->proof);free(p->sites);free(p);
}
static int ufe_recipe(uint8_t op,NvmRecordArrayExecutionInstruction *r) {
    if(!uf_sensitive(op))return rae_old_recipe(op,r);
    r->recipe=
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
             (255)
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                       ;
    r->obligations=NVM_RA_FIRST_ERROR_CLEANUP;
    if(op==OP_HALT)return 1;
    r->obligations|=NVM_RA_CHECK_TAGS|NVM_RA_CHECK_NOMINAL;
    if(op==OP_STRUCT_NEW || op==OP_STRUCT_LITERAL || op==OP_AGG_PACK)
        r->obligations|=NVM_RA_SAFEPOINT_BEFORE|NVM_RA_STAGE_OPERANDS;
    else if(op!=OP_AGG_TAG)
        r->obligations|=NVM_RA_CHECK_BOUNDS|NVM_RA_RETAIN_BEFORE_RELEASE;
    return 1;
}
static int ufe_empty(NvmRecordValueOrigins v) { return !v.tags && !v.origins && !v.unknown; }
typedef struct {
    NvmUnionFieldOrigin rows[64];
    uint64_t records,variants[2];
    uint32_t count;
} UfeOrigins;
static int ufe_origins_value(const UfeOrigins *o,NvmRecordValueOrigins v) {
    uint64_t unions=o->variants[0]|o->variants[1];
    if(v.unknown || (v.origins&~(o->records|unions)))return 0;
    if(!!(v.tags&((uint16_t)(1u << (TAG_STRUCT))))!=!!(v.origins&o->records) ||
       !!(v.tags&((uint16_t)(1u << (TAG_UNION))))!=!!(v.origins&unions))return 0;
    return 1;
}
static int ufe_origin_correspondence(const UfeOrigins *o,const NvmUnionFieldSite *s) {
    if(!ufe_origins_value(o,s->receiver) || !ufe_origins_value(o,s->input) || !ufe_origins_value(o,s->result))return 0;
    if(s->state!=UFS_PROVED)return 1;
    if(s->operation==UFS_VARIANT_PACK || s->operation==UFS_RECORD_PACK || s->operation==UFS_RECORD_NEW) {
        uint64_t site=0;
        for(uint32_t i=0;i<o->count;i++) {
            const NvmUnionFieldOrigin *r=&o->rows[i];
            if(r->function==s->function && r->pc==s->pc) {
                if(site || r->nominal_ordinal!=s->nominal || r->layout_index!=s->layout ||
                   r->member_count!=s->member || r->variant!=s->variant ||
                   r->kind!=(s->operation==UFS_VARIANT_PACK?3u:NVM_HEAP_ORIGIN_RECORD) ||
                   (s->input.tags&~r->member.tags) || (s->input.origins&~r->member.origins))return 0;
                site=1UL<<i;
            }
        }
        return site && site==s->result.origins;
    }
    if(s->operation==UFS_PAYLOAD_GET)
        return s->variant<2 && s->receiver.origins && !(s->receiver.origins&~o->variants[s->variant]);
    if(s->operation==UFS_RECORD_GET || s->operation==UFS_RECORD_SET) {
        uint64_t children=0;uint16_t tags=0;
        for(uint32_t i=0;i<o->count;i++)if(s->receiver.origins&(1UL<<i)) {
            const NvmUnionFieldOrigin *r=&o->rows[i];
            if(r->kind!=NVM_HEAP_ORIGIN_RECORD || r->nominal_ordinal!=s->nominal || r->layout_index!=s->layout)return 0;
            if(s->operation==UFS_RECORD_SET && ((s->input.origins&~r->member.origins) || (s->input.tags&~r->member.tags)))return 0;
            children|=r->member.origins;tags|=r->member.tags;
        }
        if(s->operation==UFS_RECORD_GET)return children==s->result.origins && tags==s->result.tags;
    }
    return 1;
}


static int ufe_corresponds(const NvmRecordArrayExecutionInstruction *r,const NvmUnionFieldSite *s,
                          uint32_t record_layout,uint32_t union_layout,const NvmUnionVariantFact variants[2],const UfeOrigins *origins) {
    if(!ufe_origin_correspondence(origins,s))return 0;
    NvmRecordArrayExecutionInstruction expected={0};
    if(!ufe_recipe(r->opcode,&expected) || expected.recipe!=r->recipe || expected.obligations!=r->obligations)return 0;
    if(r->function!=s->function || r->pc!=s->pc || s->reserved[0] || s->reserved[1] || s->reserved[2] ||
       s->receiver.unknown || s->input.unknown || s->result.unknown)return 0;
    if(!uf_sensitive(r->opcode))return s->state==UFS_NOT_REQUIRED && s->operation==UFS_NONE &&
        ufe_empty(s->receiver) && ufe_empty(s->input) && ufe_empty(s->result) &&
        s->nominal==
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                   (4294967295U) 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                              && s->layout==
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                            (4294967295U) 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                       && s->member==
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                     (65535) 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                && s->variant==
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                               (255)
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                        ;
    if(r->recipe!=
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                 (255)
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                           )return 0;
    DecodedInstruction in={0};in.opcode=r->opcode;in.operands[0].u8=(uint8_t)r->operand_bits[0];
    uint8_t operation=uf_site_operation(&in);
    if(s->state==UFS_NOT_ESTABLISHED)return s->operation==operation &&
        ufe_empty(s->receiver) && ufe_empty(s->input) && ufe_empty(s->result) &&
        s->nominal==
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                   (4294967295U) 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                              && s->layout==
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                            (4294967295U) 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                       && s->member==
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                     (65535) 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                && s->variant==
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                               (255)
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                        ;
    if(s->state!=UFS_PROVED)return 0;
    if(r->opcode==OP_HALT)return s->operation==UFS_HALT && !r->successor_count && !r->pops && !r->pushes &&
        ufe_empty(s->receiver) && ufe_empty(s->input) && ufe_empty(s->result) &&
        s->nominal==
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                   (4294967295U) 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                              && s->layout==
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                            (4294967295U) 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                       && s->member==
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                     (65535) 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                && s->variant==
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                               (255)
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                        ;
    if(s->nominal!=0)return 0;
    switch(s->operation) {
    case UFS_RECORD_NEW:case UFS_RECORD_PACK:case UFS_VARIANT_PACK: {
        int variant=s->operation==UFS_VARIANT_PACK;
        if(s->operation!=operation || !ufe_empty(s->receiver) || s->layout!=(variant?union_layout:record_layout) ||
           s->result.tags!=((uint16_t)(1u << (variant?TAG_UNION:TAG_STRUCT))) || !s->result.origins)return 0;
        if(r->opcode==OP_AGG_PACK) {
            if(r->operand_bits[0]!=(uint64_t)(variant?AGG_VARIANT:AGG_RECORD) || r->operand_bits[1]!=s->nominal ||
               r->operand_bits[2]!=(variant?s->variant:0) || r->operand_bits[3]!=s->member)return 0;
        } else if(r->operand_bits[0]!=s->nominal || (r->opcode==OP_STRUCT_LITERAL && r->operand_bits[1]!=s->member))return 0;
        uint16_t count=1;
        if(variant) {
            if(s->variant>=2)return 0;
            count=variants[s->variant].field_count;
        } else if(s->variant!=
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                             (255)
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                      )return 0;
        return r->pushes==1 && r->pops==(r->opcode==OP_STRUCT_NEW?0:count) && s->member==count && (count?(s->input.tags==((uint16_t)(1u << (variant?TAG_INT:TAG_UNION))) &&
             (variant?!s->input.origins:!!s->input.origins)):ufe_empty(s->input));
    }
    case UFS_RECORD_GET:
        return r->pops==1 && r->pushes==1 && (r->opcode==OP_STRUCT_GET || r->opcode==OP_AGG_GET) && !r->operand_bits[0] && !s->member &&
            s->layout==record_layout && s->variant==
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                   (255) 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                             && s->receiver.tags==((uint16_t)(1u << (TAG_STRUCT))) &&
            s->receiver.origins && ufe_empty(s->input) && s->result.tags==((uint16_t)(1u << (TAG_UNION))) && s->result.origins;
    case UFS_PAYLOAD_GET:
        return r->pops==1 && r->pushes==1 && r->opcode==OP_AGG_GET && !r->operand_bits[0] && !s->member && s->layout==union_layout &&
            s->variant<2 && variants[s->variant].field_count==1 && s->receiver.tags==((uint16_t)(1u << (TAG_UNION))) &&
            s->receiver.origins && ufe_empty(s->input) && s->result.tags==((uint16_t)(1u << (TAG_INT))) && !s->result.origins;
    case UFS_RECORD_SET:
        return r->pops==2 && r->pushes==1 && (r->opcode==OP_STRUCT_SET || r->opcode==OP_AGG_SET) && !r->operand_bits[0] && !s->member &&
            s->layout==record_layout && s->variant==
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                   (255) 
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                             && s->receiver.tags==((uint16_t)(1u << (TAG_STRUCT))) && s->receiver.origins &&
            s->input.tags==((uint16_t)(1u << (TAG_UNION))) && s->input.origins && s->result.tags==s->receiver.tags && s->result.origins==s->receiver.origins;
    case UFS_TAG:
        return r->pops==1 && r->pushes==1 && r->opcode==OP_AGG_TAG && s->layout==union_layout && s->variant==
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                                            (255) 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                                      && s->member==
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                                                                    (65535) 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                                                               &&
            s->receiver.tags==((uint16_t)(1u << (TAG_UNION))) && s->receiver.origins && ufe_empty(s->input) && s->result.tags==((uint16_t)(1u << (TAG_INT))) && !s->result.origins;
    default:return 0;
    }
}
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
typedef struct { uint64_t used,limit; 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                                     _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                                          limited; } NvmMapCopyWork;
typedef enum { NVM_MAP_COST_OK, NVM_MAP_COST_INVALID, NVM_MAP_COST_LIMIT } NvmMapCostStatus;
static inline 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
             _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                  nvm_map_copy_charge(NvmMapCopyWork *w,uint64_t amount) {
    if(!w)return 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                0
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                     ;
    if(w->limited || w->used>w->limit || amount>w->limit-w->used){w->limited=
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                                                                            1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                                                                                ;return 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                                                                                        0
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                                                                                             ;}
    w->used+=amount;return 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                          1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                              ;
}
static inline NvmMapCostStatus nvm_map_copy_term(NvmMapCopyWork *w,const void *ptr,
                                                uint64_t count,uint64_t width,uint64_t *sum) {
    if(!nvm_map_copy_charge(w,4))return NVM_MAP_COST_LIMIT;
    if(!!ptr!=!!count || !width)return NVM_MAP_COST_INVALID;
    if(count>
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
            (18446744073709551615UL)
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                      /width || count*width>
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
                                            (18446744073709551615UL)
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                                                      -*sum)return NVM_MAP_COST_LIMIT;
    *sum+=count*width;return NVM_MAP_COST_OK;
}
static inline NvmMapCostStatus nvm_map_copy_sum(uint64_t *sum,uint64_t add) {
    if(add>
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h" 3 4
          (18446744073709551615UL)
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_cost_private.h"
                    -*sum)return NVM_MAP_COST_LIMIT;
    *sum+=add;return NVM_MAP_COST_OK;
}
NvmMapCostStatus nvm_ownership_declarations_retained_cost(const NvmOwnershipDeclarationPlan *,NvmMapCopyWork *,uint64_t *);
NvmMapCostStatus nvm_map_declarations_retained_cost(const NvmMapDeclarationPlan *,NvmMapCopyWork *,uint64_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h" 2





static inline 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h" 3 4
             _Bool 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h"
                  ufc_outputs_disjoint(const NvmMapCopyWork *w,const uint64_t *out) {
    if(!w || !out)return 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h" 3 4
                        0
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost_private.h"
                             ;
    uintptr_t a=(uintptr_t)w,b=(uintptr_t)out;
    return a>b ? a-b>=sizeof *out : b-a>=sizeof *w;
}
NvmMapCostStatus nvm_union_declarations_retained_cost(
    const NvmUnionFieldDeclarations *,NvmMapCopyWork *,uint64_t *);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc" 2



static NvmMapCostStatus ufe_proof_retained_cost(const NvmUnionFieldProof *p,
                                              NvmMapCopyWork *w,uint64_t *out) {
    if(!ufc_outputs_disjoint(w,out))return NVM_MAP_COST_INVALID;
    if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
    if(!p || !p->declarations || p->counts.origins>64 || p->counts.globals>256 ||
       !p->counts.functions || p->counts.functions>256)return NVM_MAP_COST_INVALID;
    uint64_t bytes=0,part;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->origins),(p->counts.origins),sizeof *(p->origins),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->globals),(p->counts.globals),sizeof *(p->globals),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(p->results),(p->counts.functions),sizeof *(p->results),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->stacks),(p->counts.functions),sizeof *(p->stacks),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);

    status=nvm_union_declarations_retained_cost(p->declarations,w,&part);
    if(status!=NVM_MAP_COST_OK)return status;
    if(nvm_map_copy_sum(&bytes,part)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;
    *out=bytes;return NVM_MAP_COST_OK;
}
static NvmMapCostStatus ufe_plan_retained_cost(const NvmUnionFieldExecutionPlan *p,
                                             NvmMapCopyWork *w,uint64_t *out) {
    if(!ufc_outputs_disjoint(w,out))return NVM_MAP_COST_INVALID;
    if(!nvm_map_copy_charge(w,32))return NVM_MAP_COST_LIMIT;
    if(!p || !p->carrier || !p->proof || p->reserved || p->carrier->origins)return NVM_MAP_COST_INVALID;
    const NvmRecordArrayExecutionPlan *c=p->carrier;const NvmModule *m=&c->snapshot;
    if(!m->function_count || m->function_count>256 || m->string_count>4096 ||
       m->section_count>16 || m->header.section_count>16 ||
       m->code_size>16u*1024u*1024u || m->layout_size>(128UL*1024*1024) ||
       m->ownership_size>(128UL*1024*1024) ||
       m->metadata_count>(128UL*1024*1024)/sizeof *m->metadata ||
       m->debug_count>(128UL*1024*1024)/sizeof *m->debug_entries ||
       c->counts.functions!=m->function_count || c->counts.strings!=m->string_count ||
       c->counts.sections!=m->section_count || c->counts.metadata!=m->metadata_count ||
       c->counts.debug!=m->debug_count || c->counts.instructions>65536 ||
       p->site_count!=c->counts.instructions || p->proof->counts.functions!=m->function_count ||
       p->proof->counts.globals!=c->counts.globals || m->struct_count!=1 || m->union_count!=1 ||
       m->enum_count || c->counts.records!=1 || m->service_data || m->service_size ||
       m->passive_data || m->passive_size || m->import_count || m->module_ref_count ||
       m->callback_contract_count || m->call_descriptors || m->call_descriptor_count)
        return NVM_MAP_COST_INVALID;
    uint64_t bytes=0,part;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(c),(1),sizeof *(c),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(c->instructions),(c->counts.instructions),sizeof *(c->instructions),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->sites),(p->site_count),sizeof *(p->sites),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->functions),(m->function_count),sizeof *(m->functions),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->code),(m->code_size),sizeof *(m->code),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->layout_data),(m->layout_size),sizeof *(m->layout_data),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->ownership_data),(m->ownership_size),sizeof *(m->ownership_data),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->metadata),(m->metadata_count),sizeof *(m->metadata),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->debug_entries),(m->debug_count),sizeof *(m->debug_entries),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->string_lengths),(m->string_count),sizeof *(m->string_lengths),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->strings),(m->string_count),sizeof *(m->strings),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->function_param_types),(m->function_param_types?m->function_count:0),sizeof *(m->function_param_types),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    uint32_t instructions=0;
    for(uint32_t i=0;i<m->function_count;i++) {
        if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
        const NvmFunctionEntry *f=&m->functions[i];
        const NvmRecordArrayExecutionFunction *copy=&c->functions[i];
        const uint8_t *row=m->function_param_types?m->function_param_types[i]:
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc" 3 4
                                                                             ((void *)0)
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc"
                                                                                 ;
        if(f->arity>256 || f->local_count>256 || copy->signature.arity!=f->arity ||
           copy->signature.local_count!=f->local_count || copy->parameter_tags_present!=!!row ||
           copy->instruction_start!=instructions ||
           copy->instruction_count>c->counts.instructions-instructions)return NVM_MAP_COST_INVALID;
        instructions+=copy->instruction_count;
        do {status=nvm_map_copy_term(w,(row),(row?(f->arity?f->arity:1):0),sizeof *(row),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    }
    if(instructions!=c->counts.instructions)return NVM_MAP_COST_INVALID;
    for(uint32_t i=0;i<m->string_count;i++) {
        if(!nvm_map_copy_charge(w,8))return NVM_MAP_COST_LIMIT;
        uint64_t length=(uint64_t)m->string_lengths[i]+1;
        if(length>
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc" 3 4
                 (18446744073709551615UL)
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_cost.inc"
                         )return NVM_MAP_COST_LIMIT;
        do {status=nvm_map_copy_term(w,(m->strings[i]),(length),sizeof *(m->strings[i]),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    }

    status=ufe_proof_retained_cost(p->proof,w,&part);
    if(status!=NVM_MAP_COST_OK)return status;
    if(nvm_map_copy_sum(&bytes,part)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;
    *out=bytes;return NVM_MAP_COST_OK;
}
# 129 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 2
static NvmArrayEligibilityResult ufe_prepare_reserved(const NvmModule *m,NvmUnionFieldExecutionPlan **out,
                                                     uint64_t extra_bytes,uint64_t extra_work) {
    NvmArrayEligibilityResult result={NVM_ARRAY_INVALID,0,0,"I require a module and copied union recipe output."};
    if(!m || !out)return result;
    uint64_t bytes=64UL*1024*1024+65536u+sizeof(NvmUnionFieldExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    uint64_t work=16777216UL +65536u+sizeof(NvmUnionFieldExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    if(bytes>(128UL*1024*1024) || work>33554432UL ||
       extra_bytes>(128UL*1024*1024)-bytes || extra_work>33554432UL -work) {
        result.status=NVM_ARRAY_LIMIT;return result;
    }
    bytes+=extra_bytes;work+=extra_work;
    NvmUnionFieldExecutionPlan *p=calloc(1,sizeof *p);
    if(!p){result.status=NVM_ARRAY_MEMORY;return result;}
    p->carrier=calloc(1,sizeof *p->carrier);
    if(!p->carrier){result.status=NVM_ARRAY_MEMORY;nvm_union_field_execution_free(p);return result;}
    NvmRecordArrayExecutionPlan *c=p->carrier;
    c->bytes=bytes;c->work=work;c->failure=NVM_ARRAY_INVALID;c->counts.initializer=
# 145 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                  (4294967295U)
# 145 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                            ;
    if(!rae_snapshot(c,m))goto fail;

    for(uint32_t fi=0;fi<c->snapshot.function_count;fi++) {
        uint32_t name=c->snapshot.functions[fi].name_idx;
        if(name>=c->snapshot.string_count)goto fail;
        uint32_t length=c->snapshot.string_lengths[name];
        if(!rae_charge(c,0,(uint64_t)length+1))goto fail;
        if(memchr(c->snapshot.strings[name],0,length)){c->failure=NVM_ARRAY_UNRESOLVED;goto fail;}
    }
    NvmUnionFieldSiteExport sites={0};
    result=analyze_union_sites(&c->snapshot,&p->proof,&sites);
    if(result.status!=NVM_ARRAY_ELIGIBLE){nvm_union_field_execution_free(p);return result;}
    p->sites=sites.rows;p->site_count=sites.count;
    if(p->site_count>65536 || !rae_charge(c,(uint64_t)p->site_count*sizeof *p->sites,0))goto fail;
    if(!rae_charge(c,0,(uint64_t)c->snapshot.function_count*4u))goto fail;
    for(uint32_t i=0;i<c->snapshot.function_count;i++)
        if(!nvm_union_field_proof_stack(p->proof,i,&c->maximum_stacks[i]))goto fail;
    if(!rae_charge(c,0,256))goto fail;
    for(uint32_t op=0;op<256;op++) {
        NvmRecordArrayExecutionInstruction row={0};
        int supported=nvm_record_array_opcode_supported((uint8_t)op) || op==OP_AGG_TAG || op==OP_HALT;
        if(!!supported!=!!ufe_recipe((uint8_t)op,&row))goto fail;
    }
    uint32_t record_layout,union_layout;NvmDeclarationLayout record,uni;
    NvmUnionVariantFact variants[2];NvmV2LayoutField rf,uf;
    if(!rae_charge(c,0,32))goto fail;
    if(!nvm_union_field_proof_nominal(p->proof,TAG_STRUCT,0,&record_layout) ||
       !nvm_union_field_proof_nominal(p->proof,TAG_UNION,0,&union_layout) ||
       !nvm_union_field_proof_layout(p->proof,record_layout,&record) ||
       !nvm_union_field_proof_layout(p->proof,union_layout,&uni) ||
       !nvm_union_field_proof_variant(p->proof,0,0,&variants[0]) ||
       !nvm_union_field_proof_variant(p->proof,0,1,&variants[1]) ||
       !nvm_union_field_proof_field(p->proof,record_layout,0,&rf) ||
       !nvm_union_field_proof_field(p->proof,union_layout,0,&uf))goto fail;
    if(record_layout==union_layout || record.fields!=1 || uni.fields!=1 ||
       c->snapshot.struct_count!=1 || c->snapshot.union_count!=1)goto fail;
    c->counts.records=1;c->descriptors[0]=(NvmRecordArrayExecutionDescriptor){0,record_layout,record.fields};
    UfeOrigins origins={0};NvmUnionFieldProofCounts facts;
    if(!rae_charge(c,0,4) || !nvm_union_field_proof_counts(p->proof,&facts) || facts.origins>64)goto fail;
    origins.count=facts.origins;
    if(!rae_charge(c,0,(uint64_t)origins.count*5u))goto fail;
    for(uint32_t i=0;i<origins.count;i++) {
        NvmUnionFieldOrigin *r=&origins.rows[i];
        if(!nvm_union_field_proof_origin(p->proof,i,r) || r->nominal_ordinal!=0 || r->member.unknown)goto fail;
        if(r->kind==NVM_HEAP_ORIGIN_RECORD) {
            if(r->layout_index!=record_layout || r->variant!=
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                            (255) 
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                      || r->member_count!=1 || r->member.tags!=((uint16_t)(1u << (TAG_UNION))))goto fail;
            origins.records|=1UL<<i;
        } else if(r->kind==3u) {
            if(r->layout_index!=union_layout || r->variant>=2 || r->member_count!=variants[r->variant].field_count ||
               (r->member_count?(r->member.tags!=((uint16_t)(1u << (TAG_INT))) || r->member.origins):!ufe_empty(r->member)))goto fail;
            origins.variants[r->variant]|=1UL<<i;
        } else goto fail;
    }
    if(!rae_charge(c,0,origins.count))goto fail;
    for(uint32_t i=0;i<origins.count;i++)if(!ufe_origins_value(&origins,origins.rows[i].member))goto fail;
    if(!rae_instructions_policy(c,ufe_recipe,1) || c->counts.instructions!=p->site_count)goto fail;

    if(!rae_charge(c,0,(uint64_t)p->site_count*80u))goto fail;
    for(uint32_t i=0;i<p->site_count;i++)
        if(!ufe_corresponds(&c->instructions[i],&p->sites[i],record_layout,union_layout,variants,&origins))goto fail;
    if(!rae_same(c,m))goto fail;
    c->counts.strings=c->snapshot.string_count;c->counts.sections=c->snapshot.section_count;
    c->counts.metadata=c->snapshot.metadata_count;c->counts.debug=c->snapshot.debug_count;
    c->counts.functions=c->snapshot.function_count;c->counts.entry=c->snapshot.header.entry_point;
    c->counts.frame_limit=1024u;
    c->counts.peak_bytes_reserved=c->bytes;c->counts.work_reserved=c->work;
    *out=p;result.status=NVM_ARRAY_ELIGIBLE;
    snprintf(result.message,sizeof result.message,"I copied union recipes without executable admission.");return result;
fail:
    result.status=c->failure;
    snprintf(result.message,sizeof result.message,"I could not copy exact bounded union recipes.");
    nvm_union_field_execution_free(p);return result;
}
NvmArrayEligibilityResult nvm_prepare_union_field_execution(const NvmModule *m,NvmUnionFieldExecutionPlan **out) {
    return ufe_prepare_reserved(m,out,0,0);
}

# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_counts(const NvmUnionFieldExecutionPlan *p,NvmRecordArrayExecutionCounts *out) {
    return p && nvm_record_array_execution_counts(p->carrier,out);
}

# 225 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 225 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_instruction(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmUnionFieldExecutionInstruction *out) {
    if(!p || !out || i>=p->site_count || i>=p->carrier->counts.instructions)return 
# 226 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                  0
# 226 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                       ;
    NvmUnionFieldExecutionInstruction row={p->carrier->instructions[i],p->sites[i]};*out=row;return 
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
                                                                                                   1
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
                                                                                                       ;
}

# 229 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 229 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_function(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out) {
    return p && nvm_record_array_execution_function(p->carrier,i,out);
}

# 232 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 232 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_parameter(const NvmUnionFieldExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out) {
    return p && nvm_record_array_execution_parameter(p->carrier,fi,i,out);
}

# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_header(const NvmUnionFieldExecutionPlan *p,NvmHeader *out) {
    return p && nvm_record_array_execution_header(p->carrier,out);
}

# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_size(const NvmUnionFieldExecutionPlan *p,NvmRecordArraySnapshotKind k,uint32_t i,uint32_t *out) {
    return p && nvm_record_array_execution_size(p->carrier,k,i,out);
}

# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_bytes(const NvmUnionFieldExecutionPlan *p,NvmRecordArraySnapshotKind k,uint32_t i,uint32_t offset,uint32_t count,void *out) {
    return p && nvm_record_array_execution_bytes(p->carrier,k,i,offset,count,out);
}

# 244 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 244 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_proof_counts(const NvmUnionFieldExecutionPlan *p,NvmUnionFieldProofCounts *out) {
    return p && nvm_union_field_proof_counts(p->proof,out);
}




# 250 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 250 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
nvm_union_field_execution_origin(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmUnionFieldOrigin *out) { return p && nvm_union_field_proof_origin(p->proof,i,out); }

# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
nvm_union_field_execution_global(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out) { return p && nvm_union_field_proof_global(p->proof,i,out); }

# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
nvm_union_field_execution_result(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out) { return p && nvm_union_field_proof_result(p->proof,i,out); }

# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
nvm_union_field_execution_layout(const NvmUnionFieldExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out) { return p && nvm_union_field_proof_layout(p->proof,i,out); }


# 255 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 255 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_field(const NvmUnionFieldExecutionPlan *p,uint32_t i,uint16_t j,NvmV2LayoutField *out) {
    return p && nvm_union_field_proof_field(p->proof,i,j,out);
}

# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_variant(const NvmUnionFieldExecutionPlan *p,uint32_t i,uint16_t j,NvmUnionVariantFact *out) {
    return p && nvm_union_field_proof_variant(p->proof,i,j,out);
}

# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc" 3 4
_Bool 
# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_union_field_execution.inc"
    nvm_union_field_execution_nominal(const NvmUnionFieldExecutionPlan *p,uint8_t tag,uint32_t i,uint32_t *out) {
    return p && nvm_union_field_proof_nominal(p->proof,tag,i,out);
}
# 1262 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
typedef struct NvmUnionFieldImage NvmUnionFieldImage;
typedef struct {
    uint64_t source_retained_bytes,preparation_bytes_reserved,preparation_work_reserved;
} NvmUnionFieldImageCost;
NvmArrayEligibilityResult nvm_union_field_image_copy(const NvmUnionFieldExecutionPlan *,NvmUnionFieldImage **);
void nvm_union_field_image_free(NvmUnionFieldImage *);

# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_cost(const NvmUnionFieldImage *,NvmUnionFieldImageCost *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_counts(const NvmUnionFieldImage *,NvmRecordArrayExecutionCounts *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_instruction(const NvmUnionFieldImage *,uint32_t,NvmUnionFieldExecutionInstruction *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_function(const NvmUnionFieldImage *,uint32_t,NvmRecordArrayExecutionFunction *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_parameter(const NvmUnionFieldImage *,uint32_t,uint16_t,uint8_t *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_header(const NvmUnionFieldImage *,NvmHeader *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_size(const NvmUnionFieldImage *,NvmRecordArraySnapshotKind,uint32_t,uint32_t *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_bytes(const NvmUnionFieldImage *,NvmRecordArraySnapshotKind,uint32_t,uint32_t,uint32_t,void *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_proof_counts(const NvmUnionFieldImage *,NvmUnionFieldProofCounts *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_origin(const NvmUnionFieldImage *,uint32_t,NvmUnionFieldOrigin *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_global(const NvmUnionFieldImage *,uint32_t,NvmRecordValueOrigins *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_result(const NvmUnionFieldImage *,uint32_t,NvmRecordValueOrigins *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_layout(const NvmUnionFieldImage *,uint32_t,NvmDeclarationLayout *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_field(const NvmUnionFieldImage *,uint32_t,uint16_t,NvmV2LayoutField *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_variant(const NvmUnionFieldImage *,uint32_t,uint16_t,NvmUnionVariantFact *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot_private.h"
    nvm_union_field_image_nominal(const NvmUnionFieldImage *,uint8_t,uint32_t,uint32_t *);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_vm_image_private.h" 1






NvmArrayEligibilityResult nvm_union_field_image_copy_reserved(
    const NvmUnionFieldExecutionPlan *,uint64_t,uint64_t,NvmUnionFieldImage **);
const NvmModule *nvm_union_field_image_module_internal(const NvmUnionFieldImage *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 2
struct NvmUnionFieldImage { NvmUnionFieldExecutionPlan *plan;NvmUnionFieldImageCost cost; };



static NvmMapCostStatus ufi_comparison_work(const NvmUnionFieldExecutionPlan *p,uint64_t *out) {
    uint64_t work=32+sizeof(NvmRecordArrayExecutionCounts)+sizeof(NvmUnionFieldProofCounts)+sizeof(NvmHeader);
    const NvmRecordArrayExecutionCounts *c=&p->carrier->counts;

    do {uint64_t count=(c->functions),size=(16+sizeof(NvmRecordArrayExecutionFunction));if(size && count>
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    for(uint32_t i=0;i<c->functions;i++)do {uint64_t count=(p->carrier->snapshot.functions[i].arity),size=(9);if(size && count>
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                       (18446744073709551615UL)
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                       /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=(c->instructions),size=(24+sizeof(NvmRecordArrayExecutionInstruction)+sizeof(NvmUnionFieldSite));if(size && count>
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=(p->proof->counts.origins),size=(8+sizeof(NvmUnionFieldOrigin));if(size && count>
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=((uint64_t)p->proof->counts.globals+p->proof->counts.functions),size=(8+sizeof(NvmRecordValueOrigins));if(size && count>
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=(c->functions),size=(10);if(size && count>
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=(2),size=(8+sizeof(uint32_t));if(size && count>
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);do {uint64_t count=(2),size=(8+sizeof(NvmDeclarationLayout));if(size && count>
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                 (18446744073709551615UL)
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                 /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);
    do {uint64_t count=(2),size=(8+sizeof(NvmUnionVariantFact));if(size && count>
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   (18446744073709551615UL)
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);do {uint64_t count=(2),size=(8+sizeof(NvmV2LayoutField));if(size && count>
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                            (18446744073709551615UL)
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                            /size)return NVM_MAP_COST_LIMIT; if(nvm_map_copy_sum(&work,count*size)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;}while(0);

    *out=work;return NVM_MAP_COST_OK;
}
static 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
      _Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
           ufi_value_same(NvmRecordValueOrigins a,NvmRecordValueOrigins b) {
    return a.tags==b.tags && a.origins==b.origins && a.unknown==b.unknown;
}
static 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
      _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
           ufi_rows_same(const NvmUnionFieldExecutionInstruction *x,const NvmUnionFieldExecutionInstruction *y) {
    const NvmRecordArrayExecutionInstruction *a=&x->base,*b=&y->base;

    do {if(a->function!=b->function)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(a->pc!=b->pc)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                    0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                    ;}while(0);do {if(a->next_pc!=b->next_pc)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                               0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                               ;}while(0);do {if(a->callee!=b->callee)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                               0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                               ;}while(0);do {if(a->pops!=b->pops)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                              0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                              ;}while(0);do {if(a->pushes!=b->pushes)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                           0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                           ;}while(0);do {if(a->obligations!=b->obligations)return 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                          0
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                          ;}while(0);
    do {if(a->opcode!=b->opcode)return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(a->recipe!=b->recipe)return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                  0
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                  ;}while(0);do {if(a->successor_count!=b->successor_count)return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                 0
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                 ;}while(0);do {if(a->operand_count!=b->operand_count)return 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                         0
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                         ;}while(0);
    for(unsigned i=0;i<2;i++)do {if(a->successors[i]!=b->successors[i])return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                            0
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                            ;}while(0);
    for(unsigned i=0;i<4;i++){do {if(a->operand_types[i]!=b->operand_types[i])return 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                        0
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                        ;}while(0);do {if(a->operand_bits[i]!=b->operand_bits[i])return 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                 0
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                 ;}while(0);}

    const NvmUnionFieldSite *s=&x->site,*t=&y->site;

    do {if(s->function!=t->function)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(s->pc!=t->pc)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                    0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                    ;}while(0);do {if(s->nominal!=t->nominal)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                               0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                               ;}while(0);do {if(s->layout!=t->layout)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                               0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                               ;}while(0);do {if(s->member!=t->member)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                              0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                              ;}while(0);do {if(s->variant!=t->variant)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                             0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                             ;}while(0);do {if(s->operation!=t->operation)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                             0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                             ;}while(0);do {if(s->state!=t->state)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                               0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                               ;}while(0);

    for(unsigned i=0;i<3;i++)if(s->reserved[i] || t->reserved[i])return 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                       0
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                            ;
    return ufi_value_same(s->receiver,t->receiver)&&ufi_value_same(s->input,t->input)&&ufi_value_same(s->result,t->result);
}



static 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
      _Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
           ufi_same(const NvmUnionFieldExecutionPlan *source,const NvmUnionFieldExecutionPlan *copy) {
    NvmRecordArrayExecutionCounts a,b;NvmUnionFieldProofCounts pa,pb;NvmHeader ha,hb;
    if(!nvm_union_field_execution_counts(source,&a)||!nvm_union_field_execution_counts(copy,&b)||
       !nvm_union_field_execution_proof_counts(source,&pa)||!nvm_union_field_execution_proof_counts(copy,&pb)||
       !nvm_union_field_execution_header(source,&ha)||!nvm_union_field_execution_header(copy,&hb))return 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                        0
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                             ;

    do {if(a.functions!=b.functions)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(a.instructions!=b.instructions)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                     0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                     ;}while(0);do {if(a.globals!=b.globals)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                          0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                          ;}while(0);do {if(a.initializer!=b.initializer)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                          0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                          ;}while(0);do {if(a.entry!=b.entry)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                              0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                              ;}while(0);do {if(a.frame_limit!=b.frame_limit)return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                            0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                            ;}while(0);
    do {if(a.strings!=b.strings)return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(a.sections!=b.sections)return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                   0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                   ;}while(0);do {if(a.metadata!=b.metadata)return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                    0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                    ;}while(0);do {if(a.debug!=b.debug)return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                     0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                     ;}while(0);do {if(a.records!=b.records)return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                   0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                   ;}while(0);

    if(pa.origins!=pb.origins||pa.globals!=pb.globals||pa.functions!=pb.functions)return 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                        0
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                             ;

    do {if(ha.format_version!=hb.format_version)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(ha.flags!=hb.flags)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                          0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                          ;}while(0);do {if(ha.entry_point!=hb.entry_point)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                        0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                        ;}while(0);do {if(ha.section_count!=hb.section_count)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                            0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                            ;}while(0);
    do {if(ha.string_pool_offset!=hb.string_pool_offset)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
   0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
   ;}while(0);do {if(ha.string_pool_length!=hb.string_pool_length)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                              0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                              ;}while(0);do {if(ha.checksum!=hb.checksum)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                         0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                         ;}while(0);
    for(unsigned i=0;i<4;i++)do {if(ha.magic[i]!=hb.magic[i])return 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                            0
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                            ;}while(0);

    for(uint32_t i=0;i<a.functions;i++) {
        NvmRecordArrayExecutionFunction x,y;
        if(!nvm_union_field_execution_function(source,i,&x)||!nvm_union_field_execution_function(copy,i,&y))return 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                  0
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                       ;

        do {if(x.signature.name_idx!=y.signature.name_idx)return 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
       0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
       ;}while(0);do {if(x.signature.arity!=y.signature.arity)return 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                  0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                  ;}while(0);do {if(x.signature.code_offset!=y.signature.code_offset)return 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                          0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                          ;}while(0);do {if(x.signature.code_length!=y.signature.code_length)return 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                        0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                        ;}while(0);
        do {if(x.signature.local_count!=y.signature.local_count)return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
       0
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
       ;}while(0);do {if(x.signature.upvalue_count!=y.signature.upvalue_count)return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                     0
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                     ;}while(0);do {if(x.signature.result_tag!=y.signature.result_tag)return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                     0
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                     ;}while(0);do {if(x.signature.result_count!=y.signature.result_count)return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                  0
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                  ;}while(0);
        do {if(x.instruction_start!=y.instruction_start)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
       0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
       ;}while(0);do {if(x.instruction_count!=y.instruction_count)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                 0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                 ;}while(0);do {if(x.maximum_stack!=y.maximum_stack)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                           0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                           ;}while(0);do {if(x.parameter_tags_present!=y.parameter_tags_present)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                 0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                 ;}while(0);

        if(x.parameter_tags_present)for(uint16_t j=0;j<x.signature.arity;j++) {
            uint8_t u,v;
            if(!nvm_union_field_execution_parameter(source,i,j,&u)||!nvm_union_field_execution_parameter(copy,i,j,&v)||u!=v)return 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                                  0
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                       ;
        }
        uint16_t u,v;
        if(!nvm_union_field_proof_stack(source->proof,i,&u)||!nvm_union_field_proof_stack(copy->proof,i,&v)||u!=v||
           source->carrier->maximum_stacks[i]!=u)return 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                       0
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                            ;
    }
    for(uint32_t i=0;i<a.instructions;i++) {
        NvmUnionFieldExecutionInstruction x,y;
        if(!nvm_union_field_execution_instruction(source,i,&x)||!nvm_union_field_execution_instruction(copy,i,&y)||!ufi_rows_same(&x,&y))return 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                                               0
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                                    ;
    }
    for(uint32_t i=0;i<pa.origins;i++) {
        NvmUnionFieldOrigin x,y;
        if(!nvm_union_field_execution_origin(source,i,&x)||!nvm_union_field_execution_origin(copy,i,&y))return 
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                              0
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                   ;

        do {if(x.function!=y.function)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
       0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
       ;}while(0);do {if(x.pc!=y.pc)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                        0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                        ;}while(0);do {if(x.nominal_ordinal!=y.nominal_ordinal)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                   0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                   ;}while(0);do {if(x.layout_index!=y.layout_index)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                           0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                           ;}while(0);do {if(x.kind!=y.kind)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                ;}while(0);do {if(x.variant!=y.variant)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                             0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                             ;}while(0);do {if(x.member_count!=y.member_count)return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                             0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                             ;}while(0);

        if(!ufi_value_same(x.member,y.member))return 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                    0
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                         ;
    }
    for(uint32_t i=0;i<pa.globals;i++) {
        NvmRecordValueOrigins x,y;
        if(!nvm_union_field_execution_global(source,i,&x)||!nvm_union_field_execution_global(copy,i,&y)||!ufi_value_same(x,y))return 
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                                    0
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                         ;
    }
    for(uint32_t i=0;i<pa.functions;i++) {
        NvmRecordValueOrigins x,y;
        if(!nvm_union_field_execution_result(source,i,&x)||!nvm_union_field_execution_result(copy,i,&y)||!ufi_value_same(x,y))return 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                                    0
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                         ;
    }
    for(uint32_t i=0;i<2;i++) {
        uint32_t u,v;uint8_t tag=i?TAG_UNION:TAG_STRUCT;
        if(!nvm_union_field_execution_nominal(source,tag,0,&u)||!nvm_union_field_execution_nominal(copy,tag,0,&v)||u!=v)return 
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                              0
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                   ;
        NvmDeclarationLayout x,y;
        if(!nvm_union_field_execution_layout(source,i,&x)||!nvm_union_field_execution_layout(copy,i,&y))return 
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                              0
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                   ;

        do {if(x.kind!=y.kind)return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
       0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
       ;}while(0);do {if(x.flags!=y.flags)return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                    0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                    ;}while(0);do {if(x.fields!=y.fields)return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                  0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                  ;}while(0);do {if(x.name!=y.name)return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                 0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                 ;}while(0);

        NvmUnionVariantFact va,vb;
        if(!nvm_union_field_execution_variant(source,0,(uint16_t)i,&va)||!nvm_union_field_execution_variant(copy,0,(uint16_t)i,&vb)||
           va.layout!=vb.layout||va.name_idx!=vb.name_idx||va.field_offset!=vb.field_offset||va.field_count!=vb.field_count)return 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                                                  0
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                                                       ;
        NvmV2LayoutField fa,fb;
        if(!nvm_union_field_execution_field(source,i,0,&fa)||!nvm_union_field_execution_field(copy,i,0,&fb)||
           fa.type_tag!=fb.type_tag||fa.nested_idx!=fb.nested_idx||fa.name_idx!=fb.name_idx)return 
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                                  0
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                                       ;
    }

    return source->carrier->descriptors[0].ordinal==copy->carrier->descriptors[0].ordinal&&
           source->carrier->descriptors[0].layout==copy->carrier->descriptors[0].layout&&
           source->carrier->descriptors[0].fields==copy->carrier->descriptors[0].fields;
}
void nvm_union_field_image_free(NvmUnionFieldImage *p) {
    if(!p)return;
    nvm_union_field_execution_free(p->plan);free(p);
}
NvmArrayEligibilityResult nvm_union_field_image_copy_reserved(const NvmUnionFieldExecutionPlan *source,
        uint64_t extra_bytes,uint64_t extra_work,NvmUnionFieldImage **out) {
    NvmArrayEligibilityResult result={NVM_ARRAY_INVALID,0,0,"I require an immutable union plan and image output."};
    if(!source || !out)return result;
    NvmMapCopyWork cost={0,33554432UL,
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                           0
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                };uint64_t retained,comparison;
    NvmMapCostStatus status=ufe_plan_retained_cost(source,&cost,&retained);
    if(status==NVM_MAP_COST_OK)status=ufi_comparison_work(source,&comparison);
    if(status!=NVM_MAP_COST_OK){result.status=status==NVM_MAP_COST_LIMIT?NVM_ARRAY_LIMIT:NVM_ARRAY_INVALID;return result;}
    uint64_t bytes=retained,work=cost.used;
    uint64_t initial_bytes=64UL*1024*1024+65536u+sizeof(NvmUnionFieldExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    uint64_t initial_work=16777216UL +65536u+sizeof(NvmUnionFieldExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    if(nvm_map_copy_sum(&bytes,extra_bytes)!=NVM_MAP_COST_OK||
       nvm_map_copy_sum(&work,extra_work)!=NVM_MAP_COST_OK||
       nvm_map_copy_sum(&bytes,sizeof(NvmUnionFieldImage))!=NVM_MAP_COST_OK||
       nvm_map_copy_sum(&work,sizeof(NvmUnionFieldImage))!=NVM_MAP_COST_OK||
       nvm_map_copy_sum(&work,comparison)!=NVM_MAP_COST_OK||
       initial_bytes>(128UL*1024*1024)||bytes>(128UL*1024*1024)-initial_bytes||
       initial_work>33554432UL||work>33554432UL -initial_work) {
        result.status=NVM_ARRAY_LIMIT;return result;
    }
    NvmUnionFieldImage *image=calloc(1,sizeof *image);
    if(!image){result.status=NVM_ARRAY_MEMORY;return result;}
    NvmUnionFieldExecutionPlan *staged=
# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                      ((void *)0)
# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                          ;
    result=ufe_prepare_reserved(&source->carrier->snapshot,&staged,bytes,work);
    if(result.status!=NVM_ARRAY_ELIGIBLE){free(image);return result;}
    if(!ufi_same(source,staged)) {
        nvm_union_field_execution_free(staged);free(image);result.status=NVM_ARRAY_INVALID;
        snprintf(result.message,sizeof result.message,"I require source union facts to match independent reconstruction.");return result;
    }
    image->cost=(NvmUnionFieldImageCost){retained,staged->carrier->counts.peak_bytes_reserved,staged->carrier->counts.work_reserved};
    image->plan=staged;staged=
# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                             ((void *)0)
# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                 ;*out=image;
    snprintf(result.message,sizeof result.message,"I independently copied descriptive union facts without execution authority.");return result;
}

NvmArrayEligibilityResult nvm_union_field_image_copy(const NvmUnionFieldExecutionPlan *source,NvmUnionFieldImage **out) {
    return nvm_union_field_image_copy_reserved(source,0,0,out);
}
const NvmModule *nvm_union_field_image_module_internal(const NvmUnionFieldImage *image) {
    return image && image->plan && image->plan->carrier?&image->plan->carrier->snapshot:
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                                                                                       ((void *)0)
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                                                                                           ;
}

# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_cost(const NvmUnionFieldImage *p,NvmUnionFieldImageCost *out) {
    if(!p || !out)return 
# 159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                        0
# 159 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                             ;
    *out=p->cost;return 
# 160 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
                       1
# 160 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
                           ;
}




# 165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_counts(const NvmUnionFieldImage *p,NvmRecordArrayExecutionCounts *out) { return p && nvm_union_field_execution_counts(p->plan,out); }

# 166 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 166 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_header(const NvmUnionFieldImage *p,NvmHeader *out) { return p && nvm_union_field_execution_header(p->plan,out); }

# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_proof_counts(const NvmUnionFieldImage *p,NvmUnionFieldProofCounts *out) { return p && nvm_union_field_execution_proof_counts(p->plan,out); }





# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_instruction(const NvmUnionFieldImage *p,uint32_t i,NvmUnionFieldExecutionInstruction *out) { return p && nvm_union_field_execution_instruction(p->plan,i,out); }

# 173 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 173 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_function(const NvmUnionFieldImage *p,uint32_t i,NvmRecordArrayExecutionFunction *out) { return p && nvm_union_field_execution_function(p->plan,i,out); }

# 174 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 174 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_origin(const NvmUnionFieldImage *p,uint32_t i,NvmUnionFieldOrigin *out) { return p && nvm_union_field_execution_origin(p->plan,i,out); }

# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_global(const NvmUnionFieldImage *p,uint32_t i,NvmRecordValueOrigins *out) { return p && nvm_union_field_execution_global(p->plan,i,out); }

# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_result(const NvmUnionFieldImage *p,uint32_t i,NvmRecordValueOrigins *out) { return p && nvm_union_field_execution_result(p->plan,i,out); }

# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 177 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
nvm_union_field_image_layout(const NvmUnionFieldImage *p,uint32_t i,NvmDeclarationLayout *out) { return p && nvm_union_field_execution_layout(p->plan,i,out); }


# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_parameter(const NvmUnionFieldImage *p,uint32_t i,uint16_t j,uint8_t *out) {
    return p && nvm_union_field_execution_parameter(p->plan,i,j,out);
}

# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_size(const NvmUnionFieldImage *p,NvmRecordArraySnapshotKind k,uint32_t i,uint32_t *out) {
    return p && nvm_union_field_execution_size(p->plan,k,i,out);
}

# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_bytes(const NvmUnionFieldImage *p,NvmRecordArraySnapshotKind k,uint32_t i,uint32_t offset,uint32_t count,void *out) {
    return p && nvm_union_field_execution_bytes(p->plan,k,i,offset,count,out);
}

# 188 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 188 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_field(const NvmUnionFieldImage *p,uint32_t i,uint16_t j,NvmV2LayoutField *out) {
    return p && nvm_union_field_execution_field(p->plan,i,j,out);
}

# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_variant(const NvmUnionFieldImage *p,uint32_t i,uint16_t j,NvmUnionVariantFact *out) {
    return p && nvm_union_field_execution_variant(p->plan,i,j,out);
}

# 194 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc" 3 4
_Bool 
# 194 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/union_field_snapshot.inc"
    nvm_union_field_image_nominal(const NvmUnionFieldImage *p,uint8_t tag,uint32_t i,uint32_t *out) {
    return p && nvm_union_field_execution_nominal(p->plan,tag,i,out);
}
# 1263 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 1






typedef struct NvmRecordMapExecutionPlan NvmRecordMapExecutionPlan;
typedef enum { NVM_RM_NONE, NVM_RM_NEW, NVM_RM_SET, NVM_RM_GET,
               NVM_RM_HAS, NVM_RM_LEN, NVM_RM_DELETE } NvmRecordMapOperation;
typedef struct {
    NvmRecordArrayExecutionCounts carrier;
    NvmRecordMapCounts maps;
} NvmRecordMapExecutionCounts;
typedef struct {
    NvmRecordArrayExecutionInstruction base;
    uint16_t key_tags,value_tags,result_tags;
    uint8_t map_operation;
} NvmRecordMapExecutionInstruction;
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *,NvmRecordMapExecutionPlan **);




# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *,uint8_t *);
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *,NvmRecordMapExecutionCounts *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *,uint32_t,NvmRecordMapExecutionInstruction *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *,uint32_t,uint8_t *,uint8_t *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.h"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 2
_Static_assert(
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
              (255)
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                        >NVM_RA_ROOT_TAIL,"map recipe cannot alias an old root recipe");
struct NvmRecordMapExecutionPlan {
    NvmRecordArrayExecutionPlan *carrier;
    NvmRecordMapFrozenContext *facts;
    NvmRecordMapExecutionInstruction *instructions;
};
void nvm_record_map_execution_free(NvmRecordMapExecutionPlan *p) {
    if(!p)return;

    nvm_record_array_execution_free(p->carrier);
    nvm_record_map_frozen_free(p->facts);free(p->instructions);free(p);
}
static int rme_recipe(uint8_t op,NvmRecordArrayExecutionInstruction *r) {
    if(!nvm_record_map_opcode(op))return rae_old_recipe(op,r);
    r->recipe=
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
             (255)
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                       ;
    r->obligations=NVM_RA_FIRST_ERROR_CLEANUP|NVM_RA_CHECK_TAGS|NVM_RA_STAGE_OPERANDS;
    if(op==OP_HM_NEW || op==OP_HM_SET)r->obligations|=NVM_RA_SAFEPOINT_BEFORE;
    if(op==OP_HM_SET || op==OP_HM_GET)r->obligations|=NVM_RA_RETAIN_BEFORE_RELEASE;
    return 1;
}
static void rme_tags(NvmRecordMapExecutionInstruction *r,uint8_t value_tag) {
    if(r->base.recipe!=
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                      (255)
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                )return;
    r->key_tags=(uint16_t)(1u<<TAG_STRING);r->value_tags=(uint16_t)(1u<<value_tag);
    switch(r->base.opcode) {
    case OP_HM_NEW:r->map_operation=NVM_RM_NEW;r->result_tags=(uint16_t)(1u<<TAG_HASHMAP);break;
    case OP_HM_DELETE:r->map_operation=NVM_RM_DELETE;r->result_tags=(uint16_t)(1u<<TAG_HASHMAP);break;
    case OP_HM_SET:r->map_operation=NVM_RM_SET;r->result_tags=(uint16_t)(1u<<TAG_HASHMAP);break;
    case OP_HM_GET:r->map_operation=NVM_RM_GET;r->result_tags=(uint16_t)((1u<<value_tag)|(1u<<TAG_VOID));break;
    case OP_HM_HAS:r->map_operation=NVM_RM_HAS;r->result_tags=(uint16_t)(1u<<TAG_BOOL);break;
    case OP_HM_LEN:r->map_operation=NVM_RM_LEN;r->result_tags=(uint16_t)(1u<<TAG_INT);break;
    }
}

static NvmArrayEligibilityResult rme_prepare_boundary(const NvmModule *m,NvmRecordMapExecutionPlan **out,
    uint64_t extra_bytes,uint64_t extra_work,NvmMapGlobalExport *globals_out) {
    NvmArrayEligibilityResult result={NVM_ARRAY_INVALID,0,0,"I require an original module and copied map plan output."};
    if(!m || !out)return result;
    uint64_t bytes=64UL*1024*1024+65536u+sizeof(NvmRecordMapExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    uint64_t work=16777216UL +65536u+sizeof(NvmRecordMapExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    if(bytes>(128UL*1024*1024) || work>33554432UL ||
       extra_bytes>(128UL*1024*1024)-bytes || extra_work>33554432UL -work) {
        result.status=NVM_ARRAY_LIMIT;return result;
    }
    bytes+=extra_bytes;work+=extra_work;
    NvmRecordMapExecutionPlan *p=calloc(1,sizeof *p);
    if(!p){result.status=NVM_ARRAY_MEMORY;return result;}
    p->carrier=calloc(1,sizeof *p->carrier);
    if(!p->carrier){result.status=NVM_ARRAY_MEMORY;nvm_record_map_execution_free(p);return result;}
    NvmMapGlobalExport globals={0};
    NvmRecordArrayExecutionPlan *c=p->carrier;
    c->bytes=bytes;c->work=work;c->failure=NVM_ARRAY_INVALID;c->counts.initializer=
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                                                  (4294967295U)
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                                            ;
    if(!rae_snapshot(c,m))goto fail;
    for(uint32_t fi=0;fi<c->snapshot.function_count;fi++) {
        uint32_t name=c->snapshot.functions[fi].name_idx;
        if(name>=c->snapshot.string_count)goto fail;
        uint32_t length=c->snapshot.string_lengths[name];
        if(!rae_charge(c,0,(uint64_t)length+1))goto fail;
        if(memchr(c->snapshot.strings[name],0,length)){c->failure=NVM_ARRAY_UNRESOLVED;goto fail;}
    }

    uint8_t value_tag=TAG_VOID;
    result=analyze_boundary_pair(&c->snapshot,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                             ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                 ,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                  ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                      ,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                       ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                           ,
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                            ((void *)0)
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                ,c->maximum_stacks,0,&p->facts,
        globals_out?&globals:
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                            ((void *)0)
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                ,&value_tag);
    if(result.status!=NVM_ARRAY_ELIGIBLE){free(globals.rows);nvm_record_map_execution_free(p);return result;}


    if(globals_out && !rae_charge(c,(uint64_t)globals.count*sizeof *globals.rows,
                                 (uint64_t)globals.count*(sizeof *globals.rows+8u)))goto fail;
    if(!rae_charge(c,0,256))goto fail;
    for(uint32_t op=0;op<256;op++) {
        NvmRecordArrayExecutionInstruction row={0};
        int supported=nvm_record_array_opcode_supported((uint8_t)op)||nvm_record_map_opcode((uint8_t)op);
        if(!!supported!=!!rme_recipe((uint8_t)op,&row)){c->failure=NVM_ARRAY_UNRESOLVED;goto fail;}
    }
    NvmDeclarationCounts declarations;
    if(!nvm_record_array_declaration_counts(p->facts->base,&declarations) || declarations.layouts>256)goto fail;
    if(!rae_charge(c,0,(uint64_t)declarations.layouts*4u))goto fail;
    for(uint32_t i=0;i<declarations.layouts;i++) {
        NvmDeclarationLayout row;
        if(!nvm_record_array_declaration_layout(p->facts->base,i,&row))goto fail;
        if(row.kind==NVM_V2_LAYOUT_STRUCT) {
            uint32_t ordinal=c->counts.records++;
            c->descriptors[ordinal]=(NvmRecordArrayExecutionDescriptor){ordinal,i,row.fields};
        }
    }
    if(c->counts.records!=c->snapshot.struct_count || !rae_instructions_using(c,rme_recipe))goto fail;
    p->instructions=rae_zero(c,c->counts.instructions,sizeof *p->instructions);
    if(c->counts.instructions && !p->instructions)goto fail;
    if(!rae_charge(c,0,(uint64_t)c->counts.instructions*4u))goto fail;
    for(uint32_t i=0;i<c->counts.instructions;i++) {
        p->instructions[i].base=c->instructions[i];rme_tags(&p->instructions[i],value_tag);
    }
    if(!rae_same(c,m) || (globals_out && globals.count!=c->counts.globals))goto fail;
    c->counts.strings=c->snapshot.string_count;c->counts.sections=c->snapshot.section_count;
    c->counts.metadata=c->snapshot.metadata_count;c->counts.debug=c->snapshot.debug_count;
    c->counts.functions=c->snapshot.function_count;c->counts.entry=c->snapshot.header.entry_point;
    c->counts.frame_limit=1024u;
    c->counts.peak_bytes_reserved=c->bytes;c->counts.work_reserved=c->work;
    if(globals_out){*globals_out=globals;globals.rows=
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                     ((void *)0)
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                         ;}
    *out=p;result.status=NVM_ARRAY_ELIGIBLE;
    snprintf(result.message,sizeof result.message,"I copied exact map execution recipes without executable admission.");return result;
fail:
    result.status=c->failure;
    snprintf(result.message,sizeof result.message,"I could not copy bounded exact map execution recipes.");
    free(globals.rows);nvm_record_map_execution_free(p);return result;
}
static NvmArrayEligibilityResult rme_prepare_reserved(const NvmModule *m,NvmRecordMapExecutionPlan **out,
    uint64_t extra_bytes,uint64_t extra_work) {
    return rme_prepare_boundary(m,out,extra_bytes,extra_work,
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                            ((void *)0)
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                );
}
NvmArrayEligibilityResult nvm_prepare_record_map_execution(const NvmModule *m,NvmRecordMapExecutionPlan **out) {
    return rme_prepare_reserved(m,out,0,0);
}

# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_counts(const NvmRecordMapExecutionPlan *p,NvmRecordMapExecutionCounts *out) {
    if(!p || !out)return 
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                        0
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                             ;
    NvmRecordMapExecutionCounts value;
    if(!nvm_record_array_execution_counts(p->carrier,&value.carrier) || !nvm_record_map_frozen_counts(p->facts,&value.maps))return 
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                                                                                                  0
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                                                                                       ;
    *out=value;return 
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                     1
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                         ;
}

# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_instruction(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordMapExecutionInstruction *out) {
    if(!p || !out || i>=p->carrier->counts.instructions)return 
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                              0
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                   ;
    *out=p->instructions[i];return 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                  1
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                      ;
}

# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_map_field(const NvmRecordMapExecutionPlan *p,uint32_t layout,uint16_t field,uint8_t *key,uint8_t *value) {
    return p && nvm_record_map_frozen_field(p->facts,layout,field,key,value);
}

# 128 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 128 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_map_origin(const NvmRecordMapExecutionPlan *p,uint32_t origin,uint8_t *key,uint8_t *value) {
    return p && nvm_record_map_frozen_origin(p->facts,origin,key,value);
}

# 131 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 131 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_function(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionFunction *out) {
    return p && nvm_record_array_execution_function(p->carrier,i,out);
}

# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_parameter(const NvmRecordMapExecutionPlan *p,uint32_t fi,uint16_t i,uint8_t *out) {
    return p && nvm_record_array_execution_parameter(p->carrier,fi,i,out);
}

# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_bytes(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t offset,uint32_t count,void *out) {
    return p && nvm_record_array_execution_bytes(p->carrier,kind,index,offset,count,out);
}

# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 140 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_size(const NvmRecordMapExecutionPlan *p,NvmRecordArraySnapshotKind kind,uint32_t index,uint32_t *out) {
    return p && nvm_record_array_execution_size(p->carrier,kind,index,out);
}

# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_descriptor(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordArrayExecutionDescriptor *out) {
    return p && nvm_record_array_execution_descriptor(p->carrier,i,out);
}

# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 146 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_header(const NvmRecordMapExecutionPlan *p,NvmHeader *out) {
    return p && nvm_record_array_execution_header(p->carrier,out);
}

# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_section(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmSectionEntry *out) {
    return p && nvm_record_array_execution_section(p->carrier,i,out);
}

# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_metadata(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmMetadataEntry *out) {
    return p && nvm_record_array_execution_metadata(p->carrier,i,out);
}

# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_debug(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDebugEntry *out) {
    return p && nvm_record_array_execution_debug(p->carrier,i,out);
}

# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_origin_counts(const NvmRecordMapExecutionPlan *p,NvmRecordArrayOriginCounts *out) {
    return p && nvm_record_array_origins_counts(p->facts->base,out);
}

# 161 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 161 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_origin(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordHeapOrigin *out) {
    return p && nvm_record_array_origin(p->facts->base,i,out);
}

# 164 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 164 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_field_value(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmRecordValueOrigins *out) {
    return p && nvm_record_array_field_value(p->facts->base,i,out);
}

# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_required_elements(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t *out) {
    return p && nvm_record_array_required_elements(p->facts->base,i,out);
}

# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_declaration_counts(const NvmRecordMapExecutionPlan *p,NvmDeclarationCounts *out) {
    return p && nvm_record_array_declaration_counts(p->facts->base,out);
}

# 173 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 173 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_layout(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmDeclarationLayout *out) {
    return p && nvm_record_array_declaration_layout(p->facts->base,i,out);
}

# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_field(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t field,NvmV2LayoutField *out) {
    return p && nvm_record_array_declaration_field(p->facts->base,i,field,out);
}

# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_type(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayType *out) {
    return p && nvm_record_array_declaration_type(p->facts->base,i,out);
}

# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_binding(const NvmRecordMapExecutionPlan *p,uint32_t i,NvmOrdinaryArrayBinding *out) {
    return p && nvm_record_array_declaration_binding(p->facts->base,i,out);
}

# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_variant(const NvmRecordMapExecutionPlan *p,uint32_t i,uint16_t variant,NvmUnionVariantFact *out) {
    return p && nvm_record_array_declaration_variant(p->facts->base,i,variant,out);
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_boundary_private.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.h" 1







typedef struct NvmRecordMapBoundaryPlan NvmRecordMapBoundaryPlan;
typedef struct {
    uint32_t globals;
    uint64_t peak_bytes_reserved, work_reserved;
} NvmRecordMapBoundaryCounts;
NvmArrayEligibilityResult nvm_prepare_record_map_boundary(
    const NvmModule *, NvmRecordMapBoundaryPlan **);
void nvm_record_map_boundary_free(NvmRecordMapBoundaryPlan *);

# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.h"
    nvm_record_map_boundary_counts(const NvmRecordMapBoundaryPlan *,NvmRecordMapBoundaryCounts *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.h"
    nvm_record_map_boundary_global(const NvmRecordMapBoundaryPlan *,uint32_t,NvmRecordValueOrigins *);
const NvmRecordMapExecutionPlan *nvm_record_map_boundary_execution(const NvmRecordMapBoundaryPlan *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_boundary_private.h" 2


NvmArrayEligibilityResult nvm_prepare_record_map_boundary_reserved_private(
    const NvmModule *,NvmRecordMapBoundaryPlan **,uint64_t,uint64_t);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 2
struct NvmRecordMapBoundaryPlan {
    NvmRecordMapExecutionPlan *execution;
    NvmRecordValueOrigins *globals;
    uint32_t count, reserved;
    uint64_t bytes, work;
};
_Static_assert(sizeof(NvmRecordMapBoundaryPlan)==40,"boundary owner ledger");
_Static_assert(sizeof(NvmRecordValueOrigins)==16,"boundary row ledger");
void nvm_record_map_boundary_free(NvmRecordMapBoundaryPlan *p) {
    if(!p)return;
    nvm_record_map_execution_free(p->execution);free(p->globals);free(p);
}

static NvmArrayEligibilityResult rmb_prepare_reserved(const NvmModule *m,NvmRecordMapBoundaryPlan **out,
    uint64_t extra_bytes,uint64_t extra_work) {
    NvmArrayEligibilityResult r={NVM_ARRAY_INVALID,0,0,"I require an original module and boundary output."};
    if(!m || !out)return r;
    if(extra_bytes>
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                  (18446744073709551615UL)
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                            -sizeof(NvmRecordMapBoundaryPlan) ||
       extra_work>
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                 (18446744073709551615UL)
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                           -sizeof(NvmRecordMapBoundaryPlan)) {r.status=NVM_ARRAY_LIMIT;return r;}


    NvmRecordMapExecutionPlan *execution=
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                                        ((void *)0)
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                                            ;NvmMapGlobalExport globals={0};
    r=rme_prepare_boundary(m,&execution,extra_bytes+sizeof(NvmRecordMapBoundaryPlan),
                          extra_work+sizeof(NvmRecordMapBoundaryPlan),&globals);
    if(r.status!=NVM_ARRAY_ELIGIBLE)return r;
    NvmRecordMapBoundaryPlan *p=calloc(1,sizeof *p);
    if(!p){free(globals.rows);nvm_record_map_execution_free(execution);r.status=NVM_ARRAY_MEMORY;
        snprintf(r.message,sizeof r.message,"I could not allocate my copied boundary owner.");return r;}
    p->execution=execution;p->globals=globals.rows;p->count=globals.count;
    p->bytes=execution->carrier->bytes;p->work=execution->carrier->work;
    *out=p;return r;
}
NvmArrayEligibilityResult nvm_prepare_record_map_boundary_reserved_private(
    const NvmModule *m,NvmRecordMapBoundaryPlan **out,uint64_t bytes,uint64_t work) {
    return rmb_prepare_reserved(m,out,bytes,work);
}
NvmArrayEligibilityResult nvm_prepare_record_map_boundary(const NvmModule *m,NvmRecordMapBoundaryPlan **out) {
    return rmb_prepare_reserved(m,out,0,0);
}

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
    nvm_record_map_boundary_counts(const NvmRecordMapBoundaryPlan *p,NvmRecordMapBoundaryCounts *out) {
    if(!p || !out)return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                        0
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                             ;
    NvmRecordMapBoundaryCounts row={0};row.globals=p->count;
    row.peak_bytes_reserved=p->bytes;row.work_reserved=p->work;*out=row;return 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                                                                              1
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                                                                                  ;
}

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
    nvm_record_map_boundary_global(const NvmRecordMapBoundaryPlan *p,uint32_t i,NvmRecordValueOrigins *out) {
    if(!p || !out || i>=p->count)return 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                                       0
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                                            ;
    *out=p->globals[i];return 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                             1
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                                 ;
}
const NvmRecordMapExecutionPlan *nvm_record_map_boundary_execution(const NvmRecordMapBoundaryPlan *p) {
    return p?p->execution:
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc" 3 4
                         ((void *)0)
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_boundary.inc"
                             ;
}
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 2




# 193 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
_Bool 
# 193 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
    nvm_record_map_execution_uniform_pair(const NvmRecordMapExecutionPlan *p,uint8_t *out) {
    NvmMapDeclarationCounts counts;NvmMapDeclarationPair pair;uint8_t key,value;
    if(!p || !p->facts || !out ||
       !nvm_map_declarations_counts(p->facts->declarations,&counts) || counts.pairs!=1 ||
       !nvm_map_declarations_pair(p->facts->declarations,0,&pair) ||
       !nvm_map_declarations_scalar(p->facts->declarations,pair.key_type,&key) ||
       !nvm_map_declarations_scalar(p->facts->declarations,pair.value_type,&value) ||
       key!=TAG_STRING || (value!=TAG_INT && value!=TAG_STRING))return 
# 200 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                                                                      0
# 200 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                                                                           ;
    *out=value;return 
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc" 3 4
                     1
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_map_execution.inc"
                         ;
}
# 1264 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 1

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 1



typedef struct NvmRecordMapImage NvmRecordMapImage;
typedef struct {
    uint64_t source_retained_bytes,preparation_bytes_reserved,preparation_work_reserved;
} NvmRecordMapImageCost;
NvmArrayEligibilityResult nvm_record_map_image_copy(const NvmRecordMapExecutionPlan *,NvmRecordMapImage **);
NvmArrayEligibilityResult nvm_record_map_image_copy_reserved(const NvmRecordMapExecutionPlan *,
    uint64_t extra_bytes,uint64_t extra_work,NvmRecordMapImage **);
const NvmRecordMapExecutionPlan *nvm_record_map_image_plan(const NvmRecordMapImage *);
void nvm_record_map_image_free(NvmRecordMapImage *);

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h"
    nvm_record_map_image_cost(const NvmRecordMapImage *,NvmRecordMapImageCost *);

const NvmModule *nvm_record_map_image_borrow(const NvmRecordMapImage *);

# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 3 4
_Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h"
    nvm_record_map_image_counts(const NvmRecordMapImage *,NvmRecordMapExecutionCounts *);

# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h"
    nvm_record_map_image_instruction(const NvmRecordMapImage *,uint32_t,NvmRecordMapExecutionInstruction *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h"
    nvm_record_map_image_field(const NvmRecordMapImage *,uint32_t,uint16_t,uint8_t *,uint8_t *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot_private.h"
    nvm_record_map_image_origin(const NvmRecordMapImage *,uint32_t,uint8_t *,uint8_t *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 2

static NvmMapCostStatus rme_frozen_retained_cost(const NvmRecordMapFrozenContext *p,
                                              NvmMapCopyWork *w,uint64_t *out) {
    if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
    if(!p || !out || !p->base || !p->base->origins || !p->base->declarations || !p->declarations ||
       p->counts.origins>64 || p->counts.map_origins>p->counts.origins || p->counts.fields>65536u ||
       p->base->origins->origin_count!=p->counts.origins ||
       p->base->origins->field_value_count!=p->counts.fields)return NVM_MAP_COST_INVALID;
    uint64_t bytes=0,part;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->rows),(p->counts.map_origins),sizeof *(p->rows),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->base),(1),sizeof *(p->base),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(p->base->origins),(1),sizeof *(p->base->origins),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->base->origins->fields),(p->counts.fields),sizeof *(p->base->origins->fields),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);

    status=nvm_ownership_declarations_retained_cost(p->base->declarations,w,&part);
    if(status!=NVM_MAP_COST_OK)return status;
    if(nvm_map_copy_sum(&bytes,part)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;
    status=nvm_map_declarations_retained_cost(p->declarations,w,&part);
    if(status!=NVM_MAP_COST_OK)return status;
    if(nvm_map_copy_sum(&bytes,part)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;
    *out=bytes;return NVM_MAP_COST_OK;
}
static NvmMapCostStatus rme_plan_retained_cost(const NvmRecordMapExecutionPlan *p,
                                            NvmMapCopyWork *w,uint64_t *out) {
    if(!nvm_map_copy_charge(w,16))return NVM_MAP_COST_LIMIT;
    if(!p || !out || !p->carrier || !p->facts || p->carrier->origins)return NVM_MAP_COST_INVALID;
    const NvmRecordArrayExecutionPlan *c=p->carrier;const NvmModule *m=&c->snapshot;
    if(!m->function_count || m->function_count>256 || m->string_count>4096 ||
       c->counts.functions!=m->function_count || c->counts.strings!=m->string_count ||
       c->counts.metadata!=m->metadata_count || c->counts.debug!=m->debug_count ||
       c->counts.sections!=m->section_count || m->section_count>16 ||
       c->counts.instructions>65536 || m->code_size>16u*1024u*1024u)return NVM_MAP_COST_INVALID;
    uint64_t bytes=0,part;NvmMapCostStatus status;

    do {status=nvm_map_copy_term(w,(p),(1),sizeof *(p),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(c),(1),sizeof *(c),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(c->instructions),(c->counts.instructions),sizeof *(c->instructions),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(p->instructions),(c->counts.instructions),sizeof *(p->instructions),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->functions),(m->function_count),sizeof *(m->functions),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->code),(m->code_size),sizeof *(m->code),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->layout_data),(m->layout_size),sizeof *(m->layout_data),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->ownership_data),(m->ownership_size),sizeof *(m->ownership_data),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->metadata),(m->metadata_count),sizeof *(m->metadata),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->debug_entries),(m->debug_count),sizeof *(m->debug_entries),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->string_lengths),(m->string_count),sizeof *(m->string_lengths),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);do {status=nvm_map_copy_term(w,(m->strings),(m->string_count),sizeof *(m->strings),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    do {status=nvm_map_copy_term(w,(m->function_param_types),(m->function_param_types?m->function_count:0),sizeof *(m->function_param_types),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    uint32_t instructions=0;
    for(uint32_t i=0;i<m->function_count;i++) {
        if(!nvm_map_copy_charge(w,8))return NVM_MAP_COST_LIMIT;
        const NvmFunctionEntry *f=&m->functions[i];
        const NvmRecordArrayExecutionFunction *copy=&c->functions[i];
        if(f->arity>256 || f->local_count>256 || copy->signature.arity!=f->arity ||
           copy->signature.local_count!=f->local_count || copy->instruction_start!=instructions ||
           copy->instruction_count>c->counts.instructions-instructions)return NVM_MAP_COST_INVALID;
        instructions+=copy->instruction_count;
        const uint8_t *row=m->function_param_types?m->function_param_types[i]:
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                                                                             ((void *)0)
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                                                                                 ;
        do {status=nvm_map_copy_term(w,(row),(row?(f->arity?f->arity:1):0),sizeof *(row),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    }
    if(instructions!=c->counts.instructions)return NVM_MAP_COST_INVALID;
    for(uint32_t i=0;i<m->string_count;i++) {
        if(!nvm_map_copy_charge(w,8))return NVM_MAP_COST_LIMIT;
        uint64_t length=(uint64_t)m->string_lengths[i]+1;
        if(length>
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                 (18446744073709551615UL)
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                         )return NVM_MAP_COST_LIMIT;
        do {status=nvm_map_copy_term(w,(m->strings[i]),(length),sizeof *(m->strings[i]),&bytes);if(status!=NVM_MAP_COST_OK)return status;}while(0);
    }

    status=rme_frozen_retained_cost(p->facts,w,&part);
    if(status!=NVM_MAP_COST_OK)return status;
    if(nvm_map_copy_sum(&bytes,part)!=NVM_MAP_COST_OK)return NVM_MAP_COST_LIMIT;
    *out=bytes;return NVM_MAP_COST_OK;
}
struct NvmRecordMapImage { NvmRecordMapExecutionPlan *plan;NvmRecordMapImageCost cost; };
void nvm_record_map_image_free(NvmRecordMapImage *p) {
    if(!p)return;
    nvm_record_map_execution_free(p->plan);free(p);
}
static NvmArrayEligibilityResult rme_image_copy_reserved(const NvmRecordMapExecutionPlan *source,
        NvmRecordMapImage **out,uint64_t extra_bytes,uint64_t extra_work) {
    NvmArrayEligibilityResult result={NVM_ARRAY_INVALID,0,0,"I require a copied map plan and image output."};
    if(!source || !out)return result;
    NvmMapCopyWork w={0,33554432UL,
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                                                        0
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                                                             };uint64_t retained;
    NvmMapCostStatus status=rme_plan_retained_cost(source,&w,&retained);
    if(status!=NVM_MAP_COST_OK){result.status=status==NVM_MAP_COST_LIMIT?NVM_ARRAY_LIMIT:NVM_ARRAY_INVALID;return result;}
    uint64_t bytes=retained,work=w.used;


    uint64_t initial_bytes=64UL*1024*1024+65536u+sizeof(NvmRecordMapExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    uint64_t initial_work=16777216UL +65536u+sizeof(NvmRecordMapExecutionPlan)+sizeof(NvmRecordArrayExecutionPlan);
    if(nvm_map_copy_sum(&bytes,sizeof(NvmRecordMapImage))!=NVM_MAP_COST_OK ||
       nvm_map_copy_sum(&work,sizeof(NvmRecordMapImage))!=NVM_MAP_COST_OK ||
       nvm_map_copy_sum(&bytes,extra_bytes)!=NVM_MAP_COST_OK || nvm_map_copy_sum(&work,extra_work)!=NVM_MAP_COST_OK ||
       initial_bytes>(128UL*1024*1024) || bytes>(128UL*1024*1024)-initial_bytes ||
       initial_work>33554432UL || work>33554432UL -initial_work) {
        result.status=NVM_ARRAY_LIMIT;return result;
    }
    NvmRecordMapImage *image=calloc(1,sizeof *image);
    if(!image){result.status=NVM_ARRAY_MEMORY;return result;}


    result=rme_prepare_reserved(&source->carrier->snapshot,&image->plan,bytes,work);
    if(result.status!=NVM_ARRAY_ELIGIBLE){nvm_record_map_image_free(image);return result;}
    image->cost=(NvmRecordMapImageCost){retained,image->plan->carrier->counts.peak_bytes_reserved,
                                              image->plan->carrier->counts.work_reserved};
    *out=image;snprintf(result.message,sizeof result.message,"I independently copied map image facts without executable admission.");return result;
}
NvmArrayEligibilityResult nvm_record_map_image_copy(const NvmRecordMapExecutionPlan *p,NvmRecordMapImage **out) {
    return rme_image_copy_reserved(p,out,0,0);
}

# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
_Bool 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
    nvm_record_map_image_cost(const NvmRecordMapImage *p,NvmRecordMapImageCost *out) {
    if(!p || !out)return 
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                        0
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                             ;
    *out=p->cost;return 
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                       1
# 106 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                           ;
}
const NvmModule *nvm_record_map_image_borrow(const NvmRecordMapImage *p) {
    return p?&p->plan->carrier->snapshot:
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                                        ((void *)0)
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                                            ;
}

# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
_Bool 
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
    nvm_record_map_image_counts(const NvmRecordMapImage *p,NvmRecordMapExecutionCounts *out) {
    return p && nvm_record_map_execution_counts(p->plan,out);
}

# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
_Bool 
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
    nvm_record_map_image_instruction(const NvmRecordMapImage *p,uint32_t i,NvmRecordMapExecutionInstruction *out) {
    return p && nvm_record_map_execution_instruction(p->plan,i,out);
}

# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
_Bool 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
    nvm_record_map_image_field(const NvmRecordMapImage *p,uint32_t i,uint16_t field,uint8_t *key,uint8_t *value) {
    return p && nvm_record_map_execution_map_field(p->plan,i,field,key,value);
}

# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
_Bool 
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
    nvm_record_map_image_origin(const NvmRecordMapImage *p,uint32_t i,uint8_t *key,uint8_t *value) {
    return p && nvm_record_map_execution_map_origin(p->plan,i,key,value);
}

NvmArrayEligibilityResult nvm_record_map_image_copy_reserved(const NvmRecordMapExecutionPlan *p,
        uint64_t bytes,uint64_t work,NvmRecordMapImage **out) {
    return rme_image_copy_reserved(p,out,bytes,work);
}
const NvmRecordMapExecutionPlan *nvm_record_map_image_plan(const NvmRecordMapImage *p) {
    return p?p->plan:
# 129 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc" 3 4
                    ((void *)0)
# 129 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_snapshot.inc"
                        ;
}
# 1265 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.h" 1






# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.h" 3 4
_Bool 
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.h"
    nvm_record_array_candidate(const NvmModule *);


NvmArrayEligibilityResult nvm_record_array_admit(const NvmModule *,NvmRecordArrayExecutionPlan **);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 1
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[8u];
} NvmFileNominalBindings;
NvmServiceResult nvm_file_nominal_check(const NvmFileNominalBindings *);

NvmServiceResult nvm_file_nominal_decode(const uint8_t *,size_t,NvmFileNominalBindings *);


NvmServiceResult nvm_file_nominal_encode(const NvmFileNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_FILE_NOMINAL_DESCRIBED, NVM_FILE_NOMINAL_INVALID,
    NVM_FILE_NOMINAL_LIMIT, NVM_FILE_NOMINAL_MEMORY
} NvmFileNominalStatus;
typedef enum {
    NVM_FILE_CATEGORY_UNKNOWN, NVM_FILE_CATEGORY_FILE,
    NVM_FILE_CATEGORY_OPEN_RESULT, NVM_FILE_CATEGORY_SCALAR_RESULT,
    NVM_FILE_CATEGORY_RECORD
} NvmFileCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmFileCategory category;
} NvmFileNominalLayout;
typedef struct NvmFileNominalPlan NvmFileNominalPlan;




NvmFileNominalStatus nvm_file_nominal_plan(const NvmModule *,NvmFileNominalPlan **);
void nvm_file_nominal_plan_free(NvmFileNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_file_nominal_layout_count(const NvmFileNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_layout(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_type(const NvmFileNominalPlan *,uint32_t,NvmFileNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_source(const NvmFileNominalPlan *,uint8_t,uint32_t,NvmFileNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h"
    nvm_file_nominal_import(const NvmFileNominalPlan *,uint32_t,uint32_t *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 1
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
typedef struct {
    uint32_t imports[5u];
    uint32_t layouts[9u];
} NvmSocketNominalBindings;
NvmServiceResult nvm_socket_nominal_check(const NvmSocketNominalBindings *);

NvmServiceResult nvm_socket_nominal_decode(const uint8_t *,size_t,NvmSocketNominalBindings *);


NvmServiceResult nvm_socket_nominal_encode(const NvmSocketNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_SOCKET_NOMINAL_DESCRIBED, NVM_SOCKET_NOMINAL_INVALID,
    NVM_SOCKET_NOMINAL_LIMIT, NVM_SOCKET_NOMINAL_MEMORY
} NvmSocketNominalStatus;
typedef enum {
    NVM_SOCKET_CATEGORY_UNKNOWN, NVM_SOCKET_CATEGORY_CONN,
    NVM_SOCKET_CATEGORY_CONNECT_RESULT, NVM_SOCKET_CATEGORY_SCALAR_RESULT,
    NVM_SOCKET_CATEGORY_RECORD
} NvmSocketCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmSocketCategory category;
} NvmSocketNominalLayout;
typedef struct NvmSocketNominalPlan NvmSocketNominalPlan;




NvmSocketNominalStatus nvm_socket_nominal_plan(const NvmModule *,NvmSocketNominalPlan **);
void nvm_socket_nominal_plan_free(NvmSocketNominalPlan *);



# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_socket_nominal_layout_count(const NvmSocketNominalPlan *);


# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_layout(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_type(const NvmSocketNominalPlan *,uint32_t,NvmSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_source(const NvmSocketNominalPlan *,uint8_t,uint32_t,NvmSocketNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_socket_nominal.h"
    nvm_socket_nominal_import(const NvmSocketNominalPlan *,uint32_t,uint32_t *);
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
typedef struct {
    uint32_t catalog;
    uint32_t imports[5], layouts[9];
} NvmServiceInstance;
typedef struct {
    uint32_t count;
    NvmServiceInstance instances[64u];
} NvmMultiNominalBindings;






uint32_t nvm_multi_nominal_catalog_types(uint32_t catalog);
uint32_t nvm_multi_nominal_catalog_methods(uint32_t catalog);
NvmServiceResult nvm_multi_nominal_check(const NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_decode(const uint8_t *,size_t,NvmMultiNominalBindings *);
NvmServiceResult nvm_multi_nominal_encode(const NvmMultiNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum { NVM_MULTI_NOMINAL_DESCRIBED, NVM_MULTI_NOMINAL_INVALID,
    NVM_MULTI_NOMINAL_LIMIT, NVM_MULTI_NOMINAL_MEMORY } NvmMultiNominalStatus;
typedef struct {
    uint32_t global_index, instance, catalog, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
} NvmMultiNominalLayout;
typedef struct NvmMultiNominalPlan NvmMultiNominalPlan;


NvmMultiNominalStatus nvm_multi_nominal_plan(const NvmModule *,NvmMultiNominalPlan **);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_storage_bound(uint32_t,size_t *);
uint32_t nvm_multi_nominal_layout_count(const NvmMultiNominalPlan *);
void nvm_multi_nominal_plan_free(NvmMultiNominalPlan *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_layout(const NvmMultiNominalPlan *,uint32_t,NvmMultiNominalLayout *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_type(const NvmMultiNominalPlan *,uint32_t,uint32_t,NvmMultiNominalLayout *);

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_multi_nominal.h"
    nvm_multi_nominal_import(const NvmMultiNominalPlan *,uint32_t,uint32_t,uint32_t *);
uint32_t nvm_multi_nominal_instance_count(const NvmMultiNominalPlan *);
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_socket_plan.h" 2




typedef struct NlSocketPlan NlSocketPlan;
typedef enum { NL_SOCKET_PLAN_OK, NL_SOCKET_PLAN_INVALID, NL_SOCKET_PLAN_MEMORY } NlSocketPlanStatus;



NlSocketPlanStatus nl_socket_plan_build(const NlNsi *, NlSocketPlan **out);
void nl_socket_plan_free(NlSocketPlan *);
size_t nl_socket_plan_storage_size(void);
const char *nl_socket_plan_interface(const NlSocketPlan *);
size_t nl_socket_plan_method_count(const NlSocketPlan *);
size_t nl_socket_plan_type_count(const NlSocketPlan *);
const NlServicePlanMethod *nl_socket_plan_method(const NlSocketPlan *, size_t);
const NlServicePlanType *nl_socket_plan_type(const NlSocketPlan *, size_t);

const char *nl_socket_catalog_interface(void);
const NlServicePlanMethod *nl_socket_catalog_method(size_t);
const NlServicePlanType *nl_socket_catalog_type(size_t);
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h" 1






typedef struct NlFilePlan NlFilePlan;
typedef enum { NL_FILE_PLAN_OK, NL_FILE_PLAN_INVALID, NL_FILE_PLAN_MEMORY } NlFilePlanStatus;

typedef NlServiceInputMode NlFileInputMode;
typedef NlServiceOwnerState NlFileOwnerState;
typedef NlServiceDomain NlFileDomain;
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h"
typedef NlServicePlanParam NlFilePlanParam;
typedef NlServicePlanMember NlFilePlanMember;
typedef NlServicePlanType NlFilePlanType;
typedef NlServicePlanOutcome NlFilePlanOutcome;
typedef NlServicePlanMethod NlFilePlanMethod;






NlFilePlanStatus nl_file_plan_build(const NlNsi *, NlFilePlan **out);
void nl_file_plan_free(NlFilePlan *);

size_t nl_file_plan_storage_size(void);
const char *nl_file_plan_interface(const NlFilePlan *);
size_t nl_file_plan_method_count(const NlFilePlan *);
size_t nl_file_plan_type_count(const NlFilePlan *);
const NlFilePlanMethod *nl_file_plan_method(const NlFilePlan *, size_t);
const NlFilePlanType *nl_file_plan_type(const NlFilePlan *, size_t);
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 2




# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_bindings_present(const NvmModule *);

# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_service_bindings_present(const NvmV2Module *);



# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_file_instructions_present(const NvmModule *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_v2_file_instructions_present(const NvmV2Module *);


# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings_module.h"
    nvm_service_execution_pending(const NvmModule *);


NvmV2Result nvm_service_bindings_validate(const NvmModule *);
NvmV2Result nvm_v2_service_bindings_validate(const NvmV2Module *);



NvmV2Result nvm_service_bindings_attach(NvmModule *, const NlFilePlan *,
                                       const NvmServiceBindings *);


NvmV2Result nvm_file_nominal_attach(NvmModule *,const NlFilePlan *,
                                   const NvmFileNominalBindings *);

NvmV2Result nvm_socket_nominal_attach(NvmModule *,const NlSocketPlan *,const NvmSocketNominalBindings *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 2


# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
_Bool 
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
    nvm_record_array_candidate(const NvmModule *m) {
    if(!m || !m->ownership_data || !m->layout_data)return 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                         0
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                              ;
    NvmV2Cursor c;uint32_t version,count,layouts;const uint8_t *flags;
    nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    if(nvm_v2_u32(&c,&version)!=NVM_V2_OK || version!=3u ||
       nvm_v2_u32(&c,&count)!=NVM_V2_OK || count>256u ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK)return 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                     0
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                          ;
    for(uint32_t i=0;i<count;i++)if(flags[i]&2u)return 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                                       0
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                                            ;
    nvm_v2_cursor_init(&c,m->layout_data,m->layout_size);
    if(nvm_v2_u32(&c,&layouts)!=NVM_V2_OK || layouts!=count)return 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                                  0
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                                       ;
    uint32_t total=0;
    for(uint32_t i=0;i<count;i++) {
        uint8_t kind,reserved;uint16_t fields;uint32_t name;const uint8_t *field;
        if(nvm_v2_u8(&c,&kind)!=NVM_V2_OK || nvm_v2_u8(&c,&reserved)!=NVM_V2_OK ||
           nvm_v2_u16(&c,&fields)!=NVM_V2_OK || nvm_v2_u32(&c,&name)!=NVM_V2_OK ||
           fields>65536u -total)return 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                         0
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                              ;
        total+=fields;
        for(uint16_t j=0;j<fields;j++) {
            if(nvm_v2_take(&c,12,&field)!=NVM_V2_OK)return 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                                          0
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                                               ;
            if(field[0]==TAG_ARRAY)return !nvm_service_execution_pending(m);
        }
    }
    return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
          0
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
               ;
}
NvmArrayEligibilityResult nvm_record_array_admit(const NvmModule *m,NvmRecordArrayExecutionPlan **out) {
    NvmArrayEligibilityResult result={NVM_ARRAY_UNRESOLVED,0,0,"I require a complete ordinary array-field candidate."};
    if(!out){result.status=NVM_ARRAY_INVALID;return result;}
    if(!nvm_record_array_candidate(m))return result;
    NvmRecordArrayExecutionPlan *plan=
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                                     ((void *)0)
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                         ;
    result=nvm_prepare_record_array_execution(m,&plan);
    if(result.status!=NVM_ARRAY_ELIGIBLE)return result;
    NvmRecordArrayExecutionCounts counts;NvmRecordArrayExecutionFunction entry;
    if(!nvm_record_array_execution_counts(plan,&counts) ||
       counts.functions>256u ||
       !nvm_record_array_execution_function(plan,counts.entry,&entry) ||
       entry.signature.arity || entry.signature.result_count!=1 || entry.signature.result_tag!=TAG_INT) {
        nvm_record_array_execution_free(plan);result.status=NVM_ARRAY_UNRESOLVED;
        snprintf(result.message,sizeof result.message,"I require a standalone integer-result record-array entry.");return result;
    }
    for(uint32_t i=0;i<counts.instructions;i++) {
        NvmRecordArrayExecutionInstruction instruction;
        if(!nvm_record_array_execution_instruction(plan,i,&instruction) ||
           instruction.opcode==OP_STRUCT_LITERAL || instruction.opcode==OP_STRUCT_GET || instruction.opcode==OP_STRUCT_SET) {
            nvm_record_array_execution_free(plan);result.status=NVM_ARRAY_UNRESOLVED;
            snprintf(result.message,sizeof result.message,"I require aggregate record opcodes shared by both public runtimes.");return result;
        }
    }
    for(uint32_t i=0;i<counts.records;i++) {
        NvmRecordArrayExecutionDescriptor descriptor;
        if(!nvm_record_array_execution_descriptor(plan,i,&descriptor) || descriptor.ordinal!=descriptor.layout) {
            nvm_record_array_execution_free(plan);result.status=NVM_ARRAY_UNRESOLVED;
            snprintf(result.message,sizeof result.message,"I require an identity record-layout projection for public execution.");return result;
        }
    }
    if(counts.initializer!=
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc" 3 4
                          (4294967295U)
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_array_admission.inc"
                                    ) {
        NvmRecordArrayExecutionFunction initializer;
        if(!nvm_record_array_execution_function(plan,counts.initializer,&initializer) ||
           initializer.signature.arity || (initializer.signature.result_count && initializer.signature.result_tag!=TAG_INT)) {
            nvm_record_array_execution_free(plan);result.status=NVM_ARRAY_UNRESOLVED;
            snprintf(result.message,sizeof result.message,"I require a scalar initializer for record-array execution.");return result;
        }
    }
    *out=plan;return result;
}
# 1266 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2

NvmArrayEligibilityResult nvm_select_portable_read_heap(const NvmModule *m,NvmManagedHeapPlan **out) {
    NvmArrayEligibilityResult result={.status=NVM_ARRAY_INVALID};
    if(!m || !out)return result;
    NvmArrayEligibilityReport *leaf=
# 1270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                   ((void *)0)
# 1270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                       ;
    result=analyze(m,&leaf,
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                          ((void *)0)
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                              ,
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                               ((void *)0)
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                   ,
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                    ((void *)0)
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                        ,
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                         ((void *)0)
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                             ,1,
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                ((void *)0)
# 1271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                    );
    nvm_array_eligibility_free(leaf);
    int graph=0;
    if(result.status==NVM_ARRAY_UNRESOLVED) {
        NvmArrayGraphEligibilityReport *report=
# 1275 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                              ((void *)0)
# 1275 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                  ;
        result=analyze(m,
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                        ((void *)0)
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                            ,&report,
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                     ((void *)0)
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                         ,
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                          ((void *)0)
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                              ,
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                               ((void *)0)
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                   ,1,
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                                      ((void *)0)
# 1276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                                          );
        nvm_array_graph_eligibility_free(report);
        graph=1;
    }
    if(result.status!=NVM_ARRAY_ELIGIBLE)return result;
    NvmManagedHeapPlan *plan=allocate(1,sizeof *plan);
    if(!plan){result.status=NVM_ARRAY_MEMORY;return result;}
    plan->mode=graph?NVM_MANAGED_ARRAY_GRAPH:NVM_MANAGED_LEAF;
    *out=plan;
    return result;
}

NvmArrayEligibilityResult nvm_analyze_record_map_origins(const NvmModule *m,NvmRecordMapFrozenContext **out) {
    if(!out)return (NvmArrayEligibilityResult){NVM_ARRAY_INVALID,0,0,"I require a map proof output."};
    return analyze(m,
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                    ((void *)0)
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                        ,
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                         ((void *)0)
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                             ,
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                              ((void *)0)
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                  ,
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                   ((void *)0)
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                       ,
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 3 4
                                        ((void *)0)
# 1290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c"
                                            ,0,out);
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h"
typedef enum { NVM_RECORD_MAP_ABSENT, NVM_RECORD_MAP_PRESENT,
    NVM_RECORD_MAP_INVALID, NVM_RECORD_MAP_LIMIT, NVM_RECORD_MAP_DEFER } NvmRecordMapRoute;
NvmRecordMapRoute nvm_record_map_route(const NvmModule *);


# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h"
    nvm_record_map_wire_selected(const NvmV2Module *);
static inline 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h" 3 4
             _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.h"
                  nvm_record_map_selected(NvmRecordMapRoute r) {
    return r==NVM_RECORD_MAP_PRESENT || r==NVM_RECORD_MAP_INVALID || r==NVM_RECORD_MAP_LIMIT;
}


NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *,NvmRecordMapExecutionPlan **);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc" 2
NvmArrayEligibilityResult nvm_record_map_admit(const NvmModule *m,NvmRecordMapExecutionPlan **out) {
    NvmArrayEligibilityResult r={NVM_ARRAY_UNRESOLVED,0,0,"I require complete ordinary map-field authority."};
    if(!out){r.status=NVM_ARRAY_INVALID;return r;}
    NvmRecordMapRoute route=nvm_record_map_route(m);
    if(route!=NVM_RECORD_MAP_PRESENT) {
        if(route==NVM_RECORD_MAP_INVALID)r.status=NVM_ARRAY_INVALID;
        if(route==NVM_RECORD_MAP_LIMIT)r.status=NVM_ARRAY_LIMIT;
        return r;
    }
    NvmRecordMapExecutionPlan *p=
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc" 3 4
                                ((void *)0)
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc"
                                    ;r=nvm_prepare_record_map_execution(m,&p);
    if(r.status!=NVM_ARRAY_ELIGIBLE)return r;
    NvmRecordMapExecutionCounts c;NvmRecordArrayExecutionFunction f;
    
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc"
        valid=nvm_record_map_execution_counts(p,&c) && c.carrier.functions<=256 &&
        nvm_record_map_execution_function(p,c.carrier.entry,&f) && !f.signature.arity &&
        !f.signature.upvalue_count && f.signature.result_count==1 && f.signature.result_tag==TAG_INT;
    if(valid && c.carrier.initializer!=
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc" 3 4
                                      (4294967295U)
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_admission.inc"
                                                )
        valid=nvm_record_map_execution_function(p,c.carrier.initializer,&f) && !f.signature.arity &&
            !f.signature.upvalue_count && f.signature.result_count<=1 &&
            ((!f.signature.result_count && f.signature.result_tag==TAG_VOID) ||
             (f.signature.result_count==1 && f.signature.result_tag==TAG_INT));
    if(!valid) {
        nvm_record_map_execution_free(p);r.status=NVM_ARRAY_UNRESOLVED;
        snprintf(r.message,sizeof r.message,"I require a zero-argument INT map entry and VOID/INT initializer.");return r;
    }
    *out=p;return r;
}
# 1294 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target_internal.h" 1





typedef struct {
    NvmArrayEligibilityResult eligibility;
    uint64_t work;
} NvmRecordMapTargetResult;

NvmRecordMapTargetResult nvm_record_map_native_target_pair(const NvmRecordMapImage *,uint64_t allowance,uint8_t *);
NvmRecordMapTargetResult nvm_record_map_native_target(const NvmRecordMapImage *,uint64_t allowance);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 2


_Static_assert(4==4,"I budget four native target operands.");
_Static_assert(32<=1+4*8,"I require a bounded native target instruction.");
NvmRecordMapTargetResult nvm_record_map_native_target_pair(const NvmRecordMapImage *image,uint64_t allowance,uint8_t *value_out) {
    NvmRecordMapTargetResult result={{NVM_ARRAY_INVALID,0,0,{0}},0};
    const char *unsupported=
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 3 4
                           ((void *)0)
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc"
                               ;





    do {uint64_t amount=(uint64_t)(64); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
    const NvmModule *m=nvm_record_map_image_borrow(image);
    const NvmRecordMapExecutionPlan *p=nvm_record_map_image_plan(image);
    NvmRecordMapExecutionCounts counts;
    if(!m || !p || !nvm_record_map_image_counts(image,&counts) ||
       counts.carrier.functions!=m->function_count || counts.carrier.entry>=m->function_count ||
       counts.carrier.records!=m->struct_count || (m->function_count && !m->functions))
        do {snprintf(result.eligibility.message,sizeof result.eligibility.message,"%s",("I require a closed copied native map module."));return result;}while(0);
    if(m->function_count>256u || m->import_count)
        do {if(!unsupported)unsupported=("I require a closed copied native map module.");}while(0);


    uint8_t value_tag=TAG_VOID;
    if(!nvm_record_map_execution_uniform_pair(p,&value_tag))return result;
    const NvmFunctionEntry *entry=&m->functions[counts.carrier.entry];
    if(entry->arity || entry->upvalue_count || entry->result_count!=1 || entry->result_tag!=TAG_INT)
        do {if(!unsupported)unsupported=("I require a capture-free zero-argument INT native map entry.");}while(0);
    if(counts.carrier.initializer!=
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 3 4
                                  (4294967295U)
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc"
                                            ) {
        if(counts.carrier.initializer>=m->function_count)return result;
        const NvmFunctionEntry *init=&m->functions[counts.carrier.initializer];
        if(init->arity || init->upvalue_count || init->result_count>1 ||
           (init->result_count && init->result_tag!=TAG_INT))
            do {if(!unsupported)unsupported=("I require a zero-argument VOID/INT native map initializer.");}while(0);
    }


    for(uint32_t ordinal=0;ordinal<counts.carrier.records;ordinal++) {
        do {uint64_t amount=(uint64_t)(32); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
        NvmRecordArrayExecutionDescriptor descriptor;NvmDeclarationLayout layout;
        if(!nvm_record_map_execution_descriptor(p,ordinal,&descriptor) ||
           descriptor.ordinal!=ordinal ||
           !nvm_record_map_execution_layout(p,descriptor.layout,&layout) ||
           layout.kind!=NVM_V2_LAYOUT_STRUCT || layout.fields!=descriptor.fields)
            do {snprintf(result.eligibility.message,sizeof result.eligibility.message,"%s",("I require identical native record ordinal and layout identities."));return result;}while(0);
        if(descriptor.layout!=ordinal)
            do {if(!unsupported)unsupported=("I require identical native record ordinal and layout identities.");}while(0);
    }
    uint32_t index=0;
    for(uint32_t fi=0;fi<m->function_count;fi++) {
        do {uint64_t amount=(uint64_t)(16); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
        const NvmFunctionEntry *f=&m->functions[fi];
        if((f->code_length && !m->code) || f->code_offset>m->code_size || f->code_length>m->code_size-f->code_offset)return result;
        for(uint32_t pc=0;pc<f->code_length;) {
            do {uint64_t amount=(uint64_t)(128); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
            DecodedInstruction in;NvmRecordMapExecutionInstruction row;
            uint32_t width=isa_decode(m->code+f->code_offset+pc,f->code_length-pc,&in);
            do {uint64_t amount=(uint64_t)(width); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
            const InstructionInfo *info=width?isa_get_info(in.opcode):
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 3 4
                                                                     ((void *)0)
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc"
                                                                         ;
            if(!info || width>32 || info->operand_count>4 || index>=counts.carrier.instructions ||
               !nvm_record_map_image_instruction(image,index++,&row) ||
               row.base.function!=fi || row.base.pc!=pc || row.base.next_pc!=pc+width ||
               row.base.opcode!=in.opcode || row.base.operand_count!=info->operand_count)return result;
            uint32_t offset=1;
            for(uint8_t a=0;a<info->operand_count;a++) {
                uint32_t bytes=isa_operand_size(info->operands[a]);uint64_t bits=0;
                if(bytes>8 || offset>width || bytes>width-offset ||
                   row.base.operand_types[a]!=(uint8_t)info->operands[a])return result;
                for(uint32_t k=0;k<bytes;k++)bits|=(uint64_t)m->code[f->code_offset+pc+offset+k]<<(8u*k);
                if(bits!=row.base.operand_bits[a])return result;
                offset+=bytes;
            }
            if(offset!=width)return result;
            NvmRecordArrayExecutionInstruction expected={0};
            if(!rme_recipe(in.opcode,&expected) || row.base.recipe!=expected.recipe ||
               row.base.obligations!=expected.obligations)return result;


            if((row.base.recipe==NVM_RA_ROOT_STRING && in.opcode!=OP_STR_CONCAT) || in.opcode==OP_CAST_STRING ||
               in.opcode==OP_STRUCT_NEW || in.opcode==OP_STRUCT_LITERAL ||
               in.opcode==OP_STRUCT_GET || in.opcode==OP_STRUCT_SET)
                do {if(!unsupported)unsupported=("I have not qualified this native map string producer or STRUCT transport.");}while(0);
            uint8_t operation=in.opcode==OP_HM_NEW?NVM_RM_NEW:in.opcode==OP_HM_SET?NVM_RM_SET:
                in.opcode==OP_HM_GET?NVM_RM_GET:in.opcode==OP_HM_HAS?NVM_RM_HAS:
                in.opcode==OP_HM_LEN?NVM_RM_LEN:in.opcode==OP_HM_DELETE?NVM_RM_DELETE:NVM_RM_NONE;
            if(row.map_operation!=operation)return result;
            if(operation) {
                uint16_t result_tags=operation==NVM_RM_GET?(1u<<value_tag)|(1u<<TAG_VOID):
                    operation==NVM_RM_HAS?(1u<<TAG_BOOL):operation==NVM_RM_LEN?(1u<<TAG_INT):(1u<<TAG_HASHMAP);
                if(!operation || row.map_operation!=operation || row.base.recipe!=
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 3 4
                                                                                 (255) 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc"
                                                                                                            ||
                   row.key_tags!=(1u<<TAG_STRING) || row.value_tags!=(1u<<value_tag) || row.result_tags!=result_tags)return result;
            } else if(row.base.recipe>NVM_RA_ROOT_TAIL)return result;
            if(in.opcode==OP_HM_NEW && (in.operands[0].u8!=TAG_STRING || in.operands[1].u8!=value_tag))return result;
            if(in.opcode==OP_PUSH_STR) {
                uint32_t at=in.operands[0].u32;
                if(at>=m->string_count || !m->strings || !m->string_lengths || !m->strings[at])
                    do {snprintf(result.eligibility.message,sizeof result.eligibility.message,"%s",("I require NUL-free executable native map string literals."));return result;}while(0);
                do {uint64_t amount=(uint64_t)(m->string_lengths[at]); if(result.work>allowance || amount>allowance-result.work){result.eligibility.status=NVM_ARRAY_LIMIT;return result;} result.work+=amount;}while(0);
                if(memchr(m->strings[at],0,m->string_lengths[at]))
                    do {if(!unsupported)unsupported=("I require NUL-free executable native map string literals.");}while(0);
            }
            if(in.opcode==OP_AGG_PACK) {
                NvmRecordArrayExecutionDescriptor descriptor;NvmDeclarationLayout layout;
                uint32_t ordinal=in.operands[1].u32;
                if(in.operands[0].u8!=AGG_RECORD || in.operands[2].u16 ||
                   !nvm_record_map_execution_descriptor(p,ordinal,&descriptor) || descriptor.ordinal!=ordinal ||
                   descriptor.fields!=in.operands[3].u16 ||
                   !nvm_record_map_execution_layout(p,descriptor.layout,&layout) ||
                   layout.kind!=NVM_V2_LAYOUT_STRUCT || layout.fields!=descriptor.fields)return result;
            }
            pc+=width;
        }
    }
    if(index!=counts.carrier.instructions)return result;
    result.eligibility.status=unsupported?NVM_ARRAY_UNRESOLVED:NVM_ARRAY_ELIGIBLE;
    if(!unsupported && value_out)*value_out=value_tag;
    if(unsupported)snprintf(result.eligibility.message,sizeof result.eligibility.message,"%s",unsupported);



    return result;
}

NvmRecordMapTargetResult nvm_record_map_native_target(const NvmRecordMapImage *image,uint64_t allowance) {
    return nvm_record_map_native_target_pair(image,allowance,
# 127 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc" 3 4
                                                            ((void *)0)
# 127 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_native_target.inc"
                                                                );
}
# 1296 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.h" 1







NvmArrayEligibilityResult nvm_record_map_publication(const NvmModule *);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc" 2
NvmArrayEligibilityResult nvm_record_map_publication(const NvmModule *source) {
    NvmArrayEligibilityResult result={NVM_ARRAY_UNRESOLVED,0,0,"I require established map publication eligibility."};
    if(!source){result.status=NVM_ARRAY_INVALID;return result;}
    NvmRecordMapRoute route=nvm_record_map_route(source);
    if(route!=NVM_RECORD_MAP_PRESENT) {
        if(route==NVM_RECORD_MAP_INVALID)result.status=NVM_ARRAY_INVALID;
        if(route==NVM_RECORD_MAP_LIMIT)result.status=NVM_ARRAY_LIMIT;
        return result;
    }
    NvmRecordMapExecutionPlan *plan=
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc" 3 4
                                   ((void *)0)
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc"
                                       ;NvmRecordMapImage *image=
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc" 3 4
                                                                 ((void *)0)
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/record_map_publication.inc"
                                                                     ;
    result=nvm_record_map_admit(source,&plan);
    if(result.status!=NVM_ARRAY_ELIGIBLE)return result;
    result=nvm_record_map_image_copy(plan,&image);
    nvm_record_map_execution_free(plan);
    if(result.status!=NVM_ARRAY_ELIGIBLE)return result;
    NvmRecordMapTargetResult target=nvm_record_map_native_target(image,33554432UL);
    nvm_record_map_image_free(image);
    return target.eligibility;
}
# 1297 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_array_shapes.c" 2
