	.arch armv8-a
	.file	"nsi_socket_plan.c"
	.text
	.align	2
	.type	nl_service_catalog_text_equal, %function
nl_service_catalog_text_equal:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 0
	beq	.L2
	ldr	x0, [sp, 16]
	cmp	x0, 0
	bne	.L3
.L2:
	ldr	x1, [sp, 24]
	ldr	x0, [sp, 16]
	cmp	x1, x0
	cset	w0, eq
	and	w0, w0, 255
	b	.L4
.L3:
	ldr	x1, [sp, 16]
	ldr	x0, [sp, 24]
	bl	strcmp
	cmp	w0, 0
	cset	w0, eq
	and	w0, w0, 255
.L4:
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	nl_service_catalog_text_equal, .-nl_service_catalog_text_equal
	.align	2
	.type	nl_service_catalog_document_equal, %function
nl_service_catalog_document_equal:
.LFB1:
	.cfi_startproc
	stp	x29, x30, [sp, -144]!
	.cfi_def_cfa_offset 144
	.cfi_offset 29, -144
	.cfi_offset 30, -136
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 24]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	w0, [x0]
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 64]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 48]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 80]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 64]
	cmp	x0, 1
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 80]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 48]
	cmp	x1, x0
	bne	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 40]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	cmp	x0, 0
	beq	.L7
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 72]
	cmp	x0, 0
	bne	.L8
.L7:
	mov	w0, 0
	b	.L9
.L8:
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L10
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 24]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L10
	ldr	x0, [sp, 24]
	ldr	x0, [x0, 56]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 32]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L11
.L10:
	mov	w0, 0
	b	.L9
.L11:
	str	xzr, [sp, 40]
	b	.L12
.L15:
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 72]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x2, [x0]
	ldr	x0, [sp, 16]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L13
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 72]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 16]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 40]
	lsl	x0, x0, 4
	add	x0, x1, x0
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L14
.L13:
	mov	w0, 0
	b	.L9
.L14:
	ldr	x0, [sp, 40]
	add	x0, x0, 1
	str	x0, [sp, 40]
.L12:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 48]
	ldr	x1, [sp, 40]
	cmp	x1, x0
	bcc	.L15
	str	xzr, [sp, 48]
	b	.L16
.L23:
	ldr	x0, [sp, 24]
	ldr	x2, [x0, 24]
	ldr	x1, [sp, 48]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 112]
	ldr	x0, [sp, 16]
	ldr	x2, [x0, 56]
	ldr	x1, [sp, 48]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	add	x0, x2, x0
	str	x0, [sp, 120]
	ldr	x0, [sp, 112]
	ldr	x2, [x0]
	ldr	x0, [sp, 120]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	w0, [x0, 32]
	cmp	w0, 0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 56]
	cmp	x1, x0
	bne	.L17
	ldr	x0, [sp, 112]
	ldr	x0, [x0, 16]
	cmp	x0, 0
	bne	.L18
.L17:
	mov	w0, 0
	b	.L9
.L18:
	str	xzr, [sp, 56]
	b	.L19
.L22:
	ldr	x0, [sp, 112]
	ldr	x2, [x0, 16]
	ldr	x1, [sp, 56]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 128]
	ldr	x0, [sp, 120]
	ldr	x2, [x0, 48]
	ldr	x1, [sp, 56]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 4
	add	x0, x2, x0
	str	x0, [sp, 136]
	ldr	x0, [sp, 128]
	ldr	x2, [x0]
	ldr	x0, [sp, 136]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 136]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 136]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 24]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 24]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 28]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 28]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 32]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 32]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w1, [x0, 36]
	ldr	x0, [sp, 136]
	ldr	w0, [x0, 36]
	cmp	w1, w0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w0, [x0, 40]
	cmp	w0, 0
	bne	.L20
	ldr	x0, [sp, 128]
	ldr	w0, [x0, 44]
	cmp	w0, 0
	beq	.L21
.L20:
	mov	w0, 0
	b	.L9
.L21:
	ldr	x0, [sp, 56]
	add	x0, x0, 1
	str	x0, [sp, 56]
.L19:
	ldr	x0, [sp, 120]
	ldr	x0, [x0, 56]
	ldr	x1, [sp, 56]
	cmp	x1, x0
	bcc	.L22
	ldr	x0, [sp, 48]
	add	x0, x0, 1
	str	x0, [sp, 48]
.L16:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 64]
	ldr	x1, [sp, 48]
	cmp	x1, x0
	bcc	.L23
	str	xzr, [sp, 64]
	b	.L24
.L32:
	ldr	x0, [sp, 24]
	ldr	x1, [x0, 40]
	ldr	x0, [sp, 64]
	lsl	x0, x0, 6
	add	x0, x1, x0
	str	x0, [sp, 80]
	ldr	x0, [sp, 16]
	ldr	x2, [x0, 72]
	ldr	x1, [sp, 64]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 88]
	ldr	x0, [sp, 80]
	ldr	x2, [x0]
	ldr	x0, [sp, 88]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	w1, [x0, 16]
	ldr	x0, [sp, 88]
	ldr	w0, [x0, 16]
	cmp	w1, w0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x1, [x0, 32]
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x1, x0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 40]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 48]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 56]
	cmp	x0, 0
	bne	.L25
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x0, 0
	beq	.L26
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L25
.L26:
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	cmp	x0, 0
	bne	.L27
	ldr	x0, [sp, 80]
	ldr	x0, [x0, 24]
	cmp	x0, 0
	beq	.L27
.L25:
	mov	w0, 0
	b	.L9
.L27:
	str	xzr, [sp, 72]
	b	.L28
.L31:
	ldr	x0, [sp, 80]
	ldr	x2, [x0, 24]
	ldr	x1, [sp, 72]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	str	x0, [sp, 96]
	ldr	x0, [sp, 88]
	ldr	x1, [x0, 24]
	ldr	x0, [sp, 72]
	lsl	x0, x0, 5
	add	x0, x1, x0
	str	x0, [sp, 104]
	ldr	x0, [sp, 96]
	ldr	x2, [x0]
	ldr	x0, [sp, 104]
	ldr	x0, [x0]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L29
	ldr	x0, [sp, 96]
	ldr	x2, [x0, 8]
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 8]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	bne	.L29
	ldr	x0, [sp, 96]
	ldr	x2, [x0, 16]
	ldr	x0, [sp, 104]
	ldr	x0, [x0, 16]
	mov	x1, x0
	mov	x0, x2
	bl	nl_service_catalog_text_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L30
.L29:
	mov	w0, 0
	b	.L9
.L30:
	ldr	x0, [sp, 72]
	add	x0, x0, 1
	str	x0, [sp, 72]
.L28:
	ldr	x0, [sp, 88]
	ldr	x0, [x0, 32]
	ldr	x1, [sp, 72]
	cmp	x1, x0
	bcc	.L31
	ldr	x0, [sp, 64]
	add	x0, x0, 1
	str	x0, [sp, 64]
.L24:
	ldr	x0, [sp, 16]
	ldr	x0, [x0, 80]
	ldr	x1, [sp, 64]
	cmp	x1, x0
	bcc	.L32
	mov	w0, 1
.L9:
	ldp	x29, x30, [sp], 144
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE1:
	.size	nl_service_catalog_document_equal, .-nl_service_catalog_document_equal
	.section	.rodata
	.align	3
.LC0:
	.string	"nsi:nanolang/net#SocketError.status"
	.align	3
.LC1:
	.string	"status"
	.align	3
.LC2:
	.string	"nsi:core/int"
	.align	3
.LC3:
	.string	"nsi:nanolang/net#SocketError.host_errno"
	.align	3
.LC4:
	.string	"host_errno"
	.align	3
.LC5:
	.string	"nsi:nanolang/net#SocketError.cleanup_errno"
	.align	3
.LC6:
	.string	"cleanup_errno"
	.align	3
.LC7:
	.string	"nsi:nanolang/net#SocketError.bytes"
	.align	3
.LC8:
	.string	"bytes"
	.align	3
.LC9:
	.string	"nsi:nanolang/net#SocketError.close_attempts"
	.align	3
.LC10:
	.string	"close_attempts"
	.align	3
.LC11:
	.string	"nsi:nanolang/net#SocketError.closed_count"
	.align	3
.LC12:
	.string	"closed_count"
	.align	3
.LC13:
	.string	"nsi:nanolang/net#SocketError.eof"
	.align	3
.LC14:
	.string	"eof"
	.align	3
.LC15:
	.string	"nsi:core/bool"
	.align	3
.LC16:
	.string	"nsi:nanolang/net#SocketError.consumed"
	.align	3
.LC17:
	.string	"consumed"
	.align	3
.LC18:
	.string	"nsi:nanolang/net#SocketError.cleanup_failed"
	.align	3
.LC19:
	.string	"cleanup_failed"
	.align	3
.LC20:
	.string	"nsi:nanolang/net#SocketError.closure_unknown"
	.align	3
.LC21:
	.string	"closure_unknown"
	.align	3
.LC22:
	.string	"nsi:nanolang/net#SocketError.connect_pending"
	.align	3
.LC23:
	.string	"connect_pending"
	.section	.data.rel.ro.local,"aw"
	.align	3
	.type	error_fields, %object
	.size	error_fields, 352
error_fields:
	.xword	.LC0
	.xword	.LC1
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC3
	.xword	.LC4
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC5
	.xword	.LC6
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC7
	.xword	.LC8
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC9
	.xword	.LC10
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC11
	.xword	.LC12
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC13
	.xword	.LC14
	.xword	.LC15
	.word	0
	.zero	4
	.xword	.LC16
	.xword	.LC17
	.xword	.LC15
	.word	0
	.zero	4
	.xword	.LC18
	.xword	.LC19
	.xword	.LC15
	.word	0
	.zero	4
	.xword	.LC20
	.xword	.LC21
	.xword	.LC15
	.word	0
	.zero	4
	.xword	.LC22
	.xword	.LC23
	.xword	.LC15
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC24:
	.string	"nsi:nanolang/net#ReadByte.value"
	.align	3
.LC25:
	.string	"value"
	.align	3
.LC26:
	.string	"nsi:nanolang/net#ReadByte.eof"
	.section	.data.rel.ro.local
	.align	3
	.type	byte_fields, %object
	.size	byte_fields, 64
byte_fields:
	.xword	.LC24
	.xword	.LC25
	.xword	.LC2
	.word	1
	.zero	4
	.xword	.LC26
	.xword	.LC14
	.xword	.LC15
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC27:
	.string	"nsi:nanolang/net#Endpoint.family"
	.align	3
.LC28:
	.string	"family"
	.align	3
.LC29:
	.string	"nsi:nanolang/net#Endpoint.address0"
	.align	3
.LC30:
	.string	"address0"
	.align	3
.LC31:
	.string	"nsi:nanolang/net#Endpoint.address1"
	.align	3
.LC32:
	.string	"address1"
	.align	3
.LC33:
	.string	"nsi:nanolang/net#Endpoint.address2"
	.align	3
.LC34:
	.string	"address2"
	.align	3
.LC35:
	.string	"nsi:nanolang/net#Endpoint.address3"
	.align	3
.LC36:
	.string	"address3"
	.align	3
.LC37:
	.string	"nsi:nanolang/net#Endpoint.port"
	.align	3
.LC38:
	.string	"port"
	.align	3
.LC39:
	.string	"nsi:nanolang/net#Endpoint.scope_id"
	.align	3
.LC40:
	.string	"scope_id"
	.section	.data.rel.ro.local
	.align	3
	.type	endpoint_fields, %object
	.size	endpoint_fields, 224
endpoint_fields:
	.xword	.LC27
	.xword	.LC28
	.xword	.LC2
	.word	4
	.zero	4
	.xword	.LC29
	.xword	.LC30
	.xword	.LC2
	.word	2
	.zero	4
	.xword	.LC31
	.xword	.LC32
	.xword	.LC2
	.word	2
	.zero	4
	.xword	.LC33
	.xword	.LC34
	.xword	.LC2
	.word	2
	.zero	4
	.xword	.LC35
	.xword	.LC36
	.xword	.LC2
	.word	2
	.zero	4
	.xword	.LC37
	.xword	.LC38
	.xword	.LC2
	.word	3
	.zero	4
	.xword	.LC39
	.xword	.LC40
	.xword	.LC2
	.word	2
	.zero	4
	.section	.rodata
	.align	3
.LC41:
	.string	"nsi:nanolang/net#ConnectResult.Ok"
	.align	3
.LC42:
	.string	"Ok"
	.align	3
.LC43:
	.string	"nsi:nanolang/net#Conn"
	.align	3
.LC44:
	.string	"nsi:nanolang/net#ConnectResult.Error"
	.align	3
.LC45:
	.string	"Error"
	.align	3
.LC46:
	.string	"nsi:nanolang/net#SocketError"
	.section	.data.rel.ro.local
	.align	3
	.type	ConnectResult_cases, %object
	.size	ConnectResult_cases, 64
ConnectResult_cases:
	.xword	.LC41
	.xword	.LC42
	.xword	.LC43
	.word	0
	.zero	4
	.xword	.LC44
	.xword	.LC45
	.xword	.LC46
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC47:
	.string	"nsi:nanolang/net#SendResult.Ok"
	.align	3
.LC48:
	.string	"nsi:nanolang/net#SendResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	SendResult_cases, %object
	.size	SendResult_cases, 64
SendResult_cases:
	.xword	.LC47
	.xword	.LC42
	.xword	.LC2
	.word	0
	.zero	4
	.xword	.LC48
	.xword	.LC45
	.xword	.LC46
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC49:
	.string	"nsi:nanolang/net#ConnectStatus.Ok"
	.align	3
.LC50:
	.string	"nsi:nanolang/net#ConnectStatus.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	ConnectStatus_cases, %object
	.size	ConnectStatus_cases, 64
ConnectStatus_cases:
	.xword	.LC49
	.xword	.LC42
	.xword	0
	.word	0
	.zero	4
	.xword	.LC50
	.xword	.LC45
	.xword	.LC46
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC51:
	.string	"nsi:nanolang/net#ReceiveResult.Ok"
	.align	3
.LC52:
	.string	"nsi:nanolang/net#ReadByte"
	.align	3
.LC53:
	.string	"nsi:nanolang/net#ReceiveResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	ReceiveResult_cases, %object
	.size	ReceiveResult_cases, 64
ReceiveResult_cases:
	.xword	.LC51
	.xword	.LC42
	.xword	.LC52
	.word	0
	.zero	4
	.xword	.LC53
	.xword	.LC45
	.xword	.LC46
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC54:
	.string	"nsi:nanolang/net#CloseResult.Ok"
	.align	3
.LC55:
	.string	"nsi:nanolang/net#CloseResult.Error"
	.section	.data.rel.ro.local
	.align	3
	.type	CloseResult_cases, %object
	.size	CloseResult_cases, 64
CloseResult_cases:
	.xword	.LC54
	.xword	.LC42
	.xword	0
	.word	0
	.zero	4
	.xword	.LC55
	.xword	.LC45
	.xword	.LC46
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC56:
	.string	"Conn"
	.align	3
.LC57:
	.string	"SocketError"
	.align	3
.LC58:
	.string	"ReadByte"
	.align	3
.LC59:
	.string	"nsi:nanolang/net#ConnectResult"
	.align	3
.LC60:
	.string	"ConnectResult"
	.align	3
.LC61:
	.string	"nsi:nanolang/net#SendResult"
	.align	3
.LC62:
	.string	"SendResult"
	.align	3
.LC63:
	.string	"nsi:nanolang/net#ConnectStatus"
	.align	3
.LC64:
	.string	"ConnectStatus"
	.align	3
.LC65:
	.string	"nsi:nanolang/net#ReceiveResult"
	.align	3
.LC66:
	.string	"ReceiveResult"
	.align	3
.LC67:
	.string	"nsi:nanolang/net#CloseResult"
	.align	3
.LC68:
	.string	"CloseResult"
	.align	3
.LC69:
	.string	"nsi:nanolang/net#Endpoint"
	.align	3
.LC70:
	.string	"Endpoint"
	.section	.data.rel.ro.local
	.align	3
	.type	types, %object
	.size	types, 360
types:
	.xword	.LC43
	.xword	.LC56
	.word	6
	.zero	4
	.xword	0
	.xword	0
	.xword	.LC46
	.xword	.LC57
	.word	1
	.zero	4
	.xword	error_fields
	.xword	11
	.xword	.LC52
	.xword	.LC58
	.word	1
	.zero	4
	.xword	byte_fields
	.xword	2
	.xword	.LC59
	.xword	.LC60
	.word	2
	.zero	4
	.xword	ConnectResult_cases
	.xword	2
	.xword	.LC61
	.xword	.LC62
	.word	2
	.zero	4
	.xword	SendResult_cases
	.xword	2
	.xword	.LC63
	.xword	.LC64
	.word	2
	.zero	4
	.xword	ConnectStatus_cases
	.xword	2
	.xword	.LC65
	.xword	.LC66
	.word	2
	.zero	4
	.xword	ReceiveResult_cases
	.xword	2
	.xword	.LC67
	.xword	.LC68
	.word	2
	.zero	4
	.xword	CloseResult_cases
	.xword	2
	.xword	.LC69
	.xword	.LC70
	.word	1
	.zero	4
	.xword	endpoint_fields
	.xword	7
	.section	.rodata
	.align	3
.LC71:
	.string	"nsi:nanolang/net#begin_connect.endpoint"
	.align	3
.LC72:
	.string	"endpoint"
	.align	3
.LC73:
	.string	"nsi:nanolang/net#begin_connect.result"
	.align	3
.LC74:
	.string	"result"
	.section	.data.rel.ro.local
	.align	3
	.type	begin_params, %object
	.size	begin_params, 96
begin_params:
	.xword	.LC71
	.xword	.LC72
	.xword	.LC69
	.word	0
	.word	2
	.word	0
	.word	0
	.word	0
	.zero	4
	.xword	.LC73
	.xword	.LC74
	.xword	.LC59
	.word	3
	.word	1
	.word	3
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC75:
	.string	"nsi:nanolang/net#send_byte.connection"
	.align	3
.LC76:
	.string	"connection"
	.align	3
.LC77:
	.string	"nsi:nanolang/net#send_byte.value"
	.align	3
.LC78:
	.string	"nsi:nanolang/net#send_byte.result"
	.section	.data.rel.ro.local
	.align	3
	.type	send_params, %object
	.size	send_params, 144
send_params:
	.xword	.LC75
	.xword	.LC76
	.xword	.LC43
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC77
	.xword	.LC25
	.xword	.LC2
	.word	0
	.word	2
	.word	0
	.word	0
	.word	1
	.zero	4
	.xword	.LC78
	.xword	.LC74
	.xword	.LC61
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC79:
	.string	"nsi:nanolang/net#finish_connect.connection"
	.align	3
.LC80:
	.string	"nsi:nanolang/net#finish_connect.result"
	.section	.data.rel.ro.local
	.align	3
	.type	finish_params, %object
	.size	finish_params, 96
finish_params:
	.xword	.LC79
	.xword	.LC76
	.xword	.LC43
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC80
	.xword	.LC74
	.xword	.LC63
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC81:
	.string	"nsi:nanolang/net#receive_byte.connection"
	.align	3
.LC82:
	.string	"nsi:nanolang/net#receive_byte.result"
	.section	.data.rel.ro.local
	.align	3
	.type	receive_params, %object
	.size	receive_params, 96
receive_params:
	.xword	.LC81
	.xword	.LC76
	.xword	.LC43
	.word	0
	.word	0
	.word	0
	.word	1
	.word	0
	.zero	4
	.xword	.LC82
	.xword	.LC74
	.xword	.LC65
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC83:
	.string	"nsi:nanolang/net#close.connection"
	.align	3
.LC84:
	.string	"nsi:nanolang/net#close.result"
	.section	.data.rel.ro.local
	.align	3
	.type	close_params, %object
	.size	close_params, 96
close_params:
	.xword	.LC83
	.xword	.LC76
	.xword	.LC43
	.word	0
	.word	1
	.word	2
	.word	0
	.word	0
	.zero	4
	.xword	.LC84
	.xword	.LC74
	.xword	.LC67
	.word	3
	.word	2
	.word	1
	.word	0
	.word	0
	.zero	4
	.section	.rodata
	.align	3
.LC85:
	.string	"nsi:nanolang/net#begin_connect"
	.align	3
.LC86:
	.string	"begin_connect"
	.align	3
.LC87:
	.string	"nsi_nanolang_net_begin_connect"
	.align	3
.LC88:
	.string	"nsi.tcp.v1.begin_connect"
	.align	3
.LC89:
	.string	"nsi:nanolang/net#send_byte"
	.align	3
.LC90:
	.string	"send_byte"
	.align	3
.LC91:
	.string	"nsi_nanolang_net_send_byte"
	.align	3
.LC92:
	.string	"nsi.tcp.v1.send_byte"
	.align	3
.LC93:
	.string	"nsi:nanolang/net#finish_connect"
	.align	3
.LC94:
	.string	"finish_connect"
	.align	3
.LC95:
	.string	"nsi_nanolang_net_finish_connect"
	.align	3
.LC96:
	.string	"nsi.tcp.v1.finish_connect"
	.align	3
.LC97:
	.string	"nsi:nanolang/net#receive_byte"
	.align	3
.LC98:
	.string	"receive_byte"
	.align	3
.LC99:
	.string	"nsi_nanolang_net_receive_byte"
	.align	3
.LC100:
	.string	"nsi.tcp.v1.receive_byte"
	.align	3
.LC101:
	.string	"nsi:nanolang/net#close"
	.align	3
.LC102:
	.string	"close"
	.align	3
.LC103:
	.string	"nsi_nanolang_net_close"
	.align	3
.LC104:
	.string	"nsi.tcp.v1.close"
	.section	.data.rel.ro.local
	.align	3
	.type	methods, %object
	.size	methods, 480
methods:
	.xword	.LC85
	.xword	.LC86
	.xword	.LC87
	.xword	.LC88
	.word	1
	.word	0
	.word	19
	.word	0
	.xword	begin_params
	.xword	2
	.word	0
	.zero	4
	.xword	.LC43
	.word	0
	.zero	4
	.xword	0
	.xword	.LC89
	.xword	.LC90
	.xword	.LC91
	.xword	.LC92
	.word	1
	.word	2
	.word	0
	.word	1
	.xword	send_params
	.xword	3
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC93
	.xword	.LC94
	.xword	.LC95
	.xword	.LC96
	.word	1
	.word	0
	.word	0
	.word	1
	.xword	finish_params
	.xword	2
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC97
	.xword	.LC98
	.xword	.LC99
	.xword	.LC100
	.word	1
	.word	1
	.word	0
	.word	1
	.xword	receive_params
	.xword	2
	.word	1
	.zero	4
	.xword	0
	.word	1
	.zero	4
	.xword	0
	.xword	.LC101
	.xword	.LC102
	.xword	.LC103
	.xword	.LC104
	.word	1
	.word	0
	.word	0
	.word	2
	.xword	close_params
	.xword	2
	.word	2
	.zero	4
	.xword	0
	.word	2
	.zero	4
	.xword	0
	.section	.rodata
	.align	3
.LC105:
	.string	"cap:nanolang/net.connect"
	.align	3
.LC106:
	.string	"connect"
	.section	.data.rel.ro.local
	.align	3
	.type	capabilities, %object
	.size	capabilities, 16
capabilities:
	.xword	.LC105
	.xword	.LC106
	.section	.rodata
	.align	3
.LC107:
	.string	"nsi:nanolang/net"
	.align	3
.LC108:
	.string	"net"
	.align	3
.LC109:
	.string	"nsi:nanolang/net#io"
	.align	3
.LC110:
	.string	"io"
	.align	3
.LC111:
	.string	"1"
	.section	.data.rel.ro.local
	.align	3
	.type	catalog, %object
	.size	catalog, 88
catalog:
	.xword	.LC107
	.xword	.LC108
	.xword	.LC109
	.xword	.LC110
	.xword	.LC111
	.xword	capabilities
	.xword	1
	.xword	methods
	.xword	5
	.xword	types
	.xword	9
	.text
	.align	2
	.global	nl_source_catalog_private_socket_plan_build
	.type	nl_source_catalog_private_socket_plan_build, %function
nl_source_catalog_private_socket_plan_build:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 24]
	str	x1, [sp, 16]
	ldr	x0, [sp, 16]
	cmp	x0, 0
	beq	.L34
	adrp	x0, catalog
	add	x1, x0, :lo12:catalog
	ldr	x0, [sp, 24]
	bl	nl_service_catalog_document_equal
	and	w0, w0, 255
	eor	w0, w0, 1
	and	w0, w0, 255
	and	w0, w0, 1
	cmp	w0, 0
	beq	.L35
.L34:
	mov	w0, 1
	b	.L36
.L35:
	mov	x0, 8
	bl	malloc
	str	x0, [sp, 40]
	ldr	x0, [sp, 40]
	cmp	x0, 0
	bne	.L37
	mov	w0, 2
	b	.L36
.L37:
	ldr	x0, [sp, 40]
	adrp	x1, catalog
	add	x1, x1, :lo12:catalog
	str	x1, [x0]
	ldr	x0, [sp, 16]
	ldr	x1, [sp, 40]
	str	x1, [x0]
	mov	w0, 0
.L36:
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	nl_source_catalog_private_socket_plan_build, .-nl_source_catalog_private_socket_plan_build
	.align	2
	.global	nl_source_catalog_private_socket_plan_free
	.type	nl_source_catalog_private_socket_plan_free, %function
nl_source_catalog_private_socket_plan_free:
.LFB3:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	str	x0, [sp, 24]
	ldr	x0, [sp, 24]
	bl	free
	nop
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE3:
	.size	nl_source_catalog_private_socket_plan_free, .-nl_source_catalog_private_socket_plan_free
	.align	2
	.global	nl_source_catalog_private_socket_plan_storage_size
	.type	nl_source_catalog_private_socket_plan_storage_size, %function
nl_source_catalog_private_socket_plan_storage_size:
.LFB4:
	.cfi_startproc
	mov	x0, 8
	ret
	.cfi_endproc
.LFE4:
	.size	nl_source_catalog_private_socket_plan_storage_size, .-nl_source_catalog_private_socket_plan_storage_size
	.align	2
	.global	nl_source_catalog_private_socket_plan_interface
	.type	nl_source_catalog_private_socket_plan_interface, %function
nl_source_catalog_private_socket_plan_interface:
.LFB5:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L42
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x0, [x0]
	b	.L44
.L42:
	mov	x0, 0
.L44:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE5:
	.size	nl_source_catalog_private_socket_plan_interface, .-nl_source_catalog_private_socket_plan_interface
	.align	2
	.global	nl_source_catalog_private_socket_plan_method_count
	.type	nl_source_catalog_private_socket_plan_method_count, %function
nl_source_catalog_private_socket_plan_method_count:
.LFB6:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L46
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x0, [x0, 64]
	b	.L48
.L46:
	mov	x0, 0
.L48:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE6:
	.size	nl_source_catalog_private_socket_plan_method_count, .-nl_source_catalog_private_socket_plan_method_count
	.align	2
	.global	nl_source_catalog_private_socket_plan_type_count
	.type	nl_source_catalog_private_socket_plan_type_count, %function
nl_source_catalog_private_socket_plan_type_count:
.LFB7:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L50
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x0, [x0, 80]
	b	.L52
.L50:
	mov	x0, 0
.L52:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE7:
	.size	nl_source_catalog_private_socket_plan_type_count, .-nl_source_catalog_private_socket_plan_type_count
	.align	2
	.global	nl_source_catalog_private_socket_plan_method
	.type	nl_source_catalog_private_socket_plan_method, %function
nl_source_catalog_private_socket_plan_method:
.LFB8:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	str	x1, [sp]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L54
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x0, [x0, 64]
	ldr	x1, [sp]
	cmp	x1, x0
	bcs	.L54
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x2, [x0, 56]
	ldr	x1, [sp]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	add	x0, x2, x0
	b	.L56
.L54:
	mov	x0, 0
.L56:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE8:
	.size	nl_source_catalog_private_socket_plan_method, .-nl_source_catalog_private_socket_plan_method
	.align	2
	.global	nl_source_catalog_private_socket_plan_type
	.type	nl_source_catalog_private_socket_plan_type, %function
nl_source_catalog_private_socket_plan_type:
.LFB9:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	str	x1, [sp]
	ldr	x0, [sp, 8]
	cmp	x0, 0
	beq	.L58
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x0, [x0, 80]
	ldr	x1, [sp]
	cmp	x1, x0
	bcs	.L58
	ldr	x0, [sp, 8]
	ldr	x0, [x0]
	ldr	x2, [x0, 72]
	ldr	x1, [sp]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	add	x0, x2, x0
	b	.L60
.L58:
	mov	x0, 0
.L60:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE9:
	.size	nl_source_catalog_private_socket_plan_type, .-nl_source_catalog_private_socket_plan_type
	.align	2
	.global	nl_source_catalog_private_socket_catalog_interface
	.type	nl_source_catalog_private_socket_catalog_interface, %function
nl_source_catalog_private_socket_catalog_interface:
.LFB10:
	.cfi_startproc
	adrp	x0, .LC107
	add	x0, x0, :lo12:.LC107
	ret
	.cfi_endproc
.LFE10:
	.size	nl_source_catalog_private_socket_catalog_interface, .-nl_source_catalog_private_socket_catalog_interface
	.align	2
	.global	nl_source_catalog_private_socket_catalog_method
	.type	nl_source_catalog_private_socket_catalog_method, %function
nl_source_catalog_private_socket_catalog_method:
.LFB11:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 4
	bhi	.L64
	ldr	x1, [sp, 8]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 5
	adrp	x1, methods
	add	x1, x1, :lo12:methods
	add	x0, x0, x1
	b	.L66
.L64:
	mov	x0, 0
.L66:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE11:
	.size	nl_source_catalog_private_socket_catalog_method, .-nl_source_catalog_private_socket_catalog_method
	.align	2
	.global	nl_source_catalog_private_socket_catalog_type
	.type	nl_source_catalog_private_socket_catalog_type, %function
nl_source_catalog_private_socket_catalog_type:
.LFB12:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	cmp	x0, 8
	bhi	.L68
	ldr	x1, [sp, 8]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	lsl	x0, x0, 3
	adrp	x1, types
	add	x1, x1, :lo12:types
	add	x0, x0, x1
	b	.L70
.L68:
	mov	x0, 0
.L70:
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE12:
	.size	nl_source_catalog_private_socket_catalog_type, .-nl_source_catalog_private_socket_catalog_type
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
