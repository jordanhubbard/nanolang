# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h" 1
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h" 2




# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h"
typedef enum {
    GC_TYPE_ARRAY = 1,
    GC_TYPE_STRING = 2,
    GC_TYPE_STRUCT = 3,
    GC_TYPE_CLOSURE = 4,
    GC_TYPE_OPAQUE = 5
} GCObjectType;


typedef void (*GCFinalizer)(void* object);


typedef struct GCHeader {
    uint32_t ref_count;
    uint8_t type;
    uint8_t marked;
    uint16_t flags;
    size_t size;
    struct GCHeader* next;
    struct GCHeader* prev;
    GCFinalizer finalizer;
} GCHeader;


typedef struct {
    size_t total_allocated;
    size_t total_freed;
    size_t current_usage;
    size_t num_objects;
    size_t num_collections;
} GCStats;


void gc_init(void);


void gc_shutdown(void);


void* gc_alloc(size_t size, GCObjectType type);


void gc_retain(void* ptr);


void gc_release(void* ptr);


void gc_collect_cycles(void);


void gc_collect_all(void);


GCStats gc_get_stats(void);


void gc_print_stats(void);


static inline GCHeader* gc_get_header(void* ptr) {
    return (GCHeader*)((char*)ptr - sizeof(GCHeader));
}


static inline void* gc_header_to_ptr(GCHeader* header) {
    return (void*)((char*)header + sizeof(GCHeader));
}



# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h"
    gc_is_managed(void* ptr);


void gc_set_cycle_detection_enabled(
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h" 3 4
                                   _Bool 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/gc.h"
                                        enabled);


void gc_set_threshold(size_t bytes);


char* gc_alloc_string(size_t length);


void* gc_alloc_opaque(size_t size, GCFinalizer finalizer);




void* gc_wrap_external(void* external_ptr, GCFinalizer finalizer);


void* gc_unwrap(void* wrapper_ptr);


void gc_set_finalizer(void* ptr, GCFinalizer finalizer);
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 2
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
typedef enum { ELEM_INT = 1, ELEM_U8 = 8, ELEM_FLOAT = 2, ELEM_STRING = 3, ELEM_BOOL = 4, ELEM_ARRAY = 5, ELEM_STRUCT = 6, ELEM_POINTER = 7 } ElementType; typedef struct { int64_t length; int64_t capacity; ElementType elem_type; uint8_t elem_size; void *data; } DynArray;



static inline 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
             _Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                  dyn_array_has_storage(const DynArray *array, ElementType type,
                                         size_t width, uint64_t bytes) {
    if (!array || !array->data || array->elem_type != type || !width ||
        array->elem_size != width || array->length < 0 || array->capacity < array->length ||
        (uint64_t)array->length > 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                 (18446744073709551615UL) 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                          / width) return 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                                          0
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                               ;
    return bytes <= (uint64_t)array->length * width;
}







DynArray* dyn_array_new(ElementType elem_type);


DynArray* dyn_array_new_with_capacity(ElementType elem_type, int64_t initial_capacity);


DynArray* dyn_array_push_int(DynArray* arr, int64_t value);
DynArray* dyn_array_push_u8(DynArray* arr, uint8_t value);
DynArray* dyn_array_push_float(DynArray* arr, double value);
DynArray* dyn_array_push_bool(DynArray* arr, 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                            _Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                 value);
DynArray* dyn_array_push_string(DynArray* arr, const char* value);
DynArray* dyn_array_push_string_copy(DynArray* arr, const char* value);
DynArray* dyn_array_push_array(DynArray* arr, DynArray* value);


int64_t dyn_array_pop_int(DynArray* arr, 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                        _Bool
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                            * success);
uint8_t dyn_array_pop_u8(DynArray* arr, 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                       _Bool
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                           * success);
double dyn_array_pop_float(DynArray* arr, 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                         _Bool
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                             * success);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
    dyn_array_pop_bool(DynArray* arr, 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                      _Bool
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                          * success);
const char* dyn_array_pop_string(DynArray* arr, 
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                               _Bool
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                   * success);
DynArray* dyn_array_pop_array(DynArray* arr, 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                            _Bool
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                * success);


int64_t dyn_array_get_int(DynArray* arr, int64_t index);
uint8_t dyn_array_get_u8(DynArray* arr, int64_t index);
double dyn_array_get_float(DynArray* arr, int64_t index);

# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
_Bool 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
    dyn_array_get_bool(DynArray* arr, int64_t index);
char* dyn_array_get_string(DynArray* arr, int64_t index);
DynArray* dyn_array_get_array(DynArray* arr, int64_t index);


void dyn_array_set_int(DynArray* arr, int64_t index, int64_t value);
void dyn_array_set_u8(DynArray* arr, int64_t index, uint8_t value);
void dyn_array_set_float(DynArray* arr, int64_t index, double value);
void dyn_array_set_bool(DynArray* arr, int64_t index, 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                                     _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                          value);
void dyn_array_set_string(DynArray* arr, int64_t index, const char* value);
void dyn_array_set_array(DynArray* arr, int64_t index, DynArray* value);


DynArray* dyn_array_remove_at(DynArray* arr, int64_t index);


DynArray* dyn_array_insert_int(DynArray* arr, int64_t index, int64_t value);
DynArray* dyn_array_insert_float(DynArray* arr, int64_t index, double value);
DynArray* dyn_array_insert_bool(DynArray* arr, int64_t index, 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                                             _Bool 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                                  value);
DynArray* dyn_array_insert_string(DynArray* arr, int64_t index, const char* value);


void dyn_array_clear(DynArray* arr);


int64_t dyn_array_length(DynArray* arr);


int64_t dyn_array_capacity(DynArray* arr);


ElementType dyn_array_get_elem_type(DynArray* arr);


void dyn_array_reserve(DynArray* arr, int64_t new_capacity);


DynArray* dyn_array_clone(DynArray* arr);


DynArray* dyn_array_sorted(DynArray* arr);


DynArray* dyn_array_push_struct(DynArray* arr, const void* struct_ptr, size_t struct_size);
void* dyn_array_get_struct(DynArray* arr, int64_t index);
void dyn_array_set_struct(DynArray* arr, int64_t index, const void* struct_ptr, size_t struct_size);
void dyn_array_pop_struct(DynArray* arr, void* out_struct, size_t struct_size, 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 3 4
                                                                              _Bool
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h"
                                                                                  * success);
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 2
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h"
DynArray* fs_walkdir(const char* root);






# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h"
    fs_walkdir_release(DynArray* result);


const char* path_normalize(const char* path);


const char* path_canonical(const char* path);


int64_t file_compare_identity(const char* source, const char* candidate);




int64_t file_compare_destinations(const char* first, const char* second);


const char* path_join(const char* a, const char* b);


const char* path_basename(const char* path);


const char* path_dirname(const char* path);






const char* path_relpath(const char* target, const char* base);




void path_normalize__nano_string_release_v1(const char* result);
void path_canonical__nano_string_release_v1(const char* result);
void path_join__nano_string_release_v1(const char* result);
void path_basename__nano_string_release_v1(const char* result);
void path_dirname__nano_string_release_v1(const char* result);
void path_relpath__nano_string_release_v1(const char* result);


const char* file_read(const char* path);


void file_read__nano_string_release_v1(const char* result);


int64_t file_write(const char* path, const char* content);


int64_t file_append(const char* path, const char* content);



# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h" 3 4
_Bool 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.h"
    file_exists(const char* path);


int64_t file_delete(const char* path);


int64_t fs_mkdir_p(const char* path);


int64_t file_copy(const char* src, const char* dst);


int64_t dir_copy(const char* src, const char* dst);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 1 3 4
# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4

# 40 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h" 3 4
typedef __builtin_va_list __gnuc_va_list;
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4
# 53 "/usr/include/stdio.h" 3 4
typedef __gnuc_va_list va_list;
# 64 "/usr/include/stdio.h" 3 4
typedef __off_t off_t;
# 78 "/usr/include/stdio.h" 3 4
typedef __ssize_t ssize_t;






typedef __fpos_t fpos_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
# 184 "/usr/include/stdio.h" 3 4
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 211 "/usr/include/stdio.h" 3 4
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (__builtin_free, 1)));






extern int fflush (FILE *__stream);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 299 "/usr/include/stdio.h" 3 4
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 314 "/usr/include/stdio.h" 3 4
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 357 "/usr/include/stdio.h" 3 4
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
# 410 "/usr/include/stdio.h" 3 4
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));





# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 438 "/usr/include/stdio.h" 2 3 4
# 463 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf")

                                __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf")
                              ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ , __leaf__))

                      ;
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
# 540 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 635 "/usr/include/stdio.h" 3 4
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
# 654 "/usr/include/stdio.h" 3 4
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 779 "/usr/include/stdio.h" 3 4
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 860 "/usr/include/stdio.h" 3 4
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 878 "/usr/include/stdio.h" 3 4
extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
# 941 "/usr/include/stdio.h" 3 4
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 983 "/usr/include/stdio.h" 3 4

# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 200 "/usr/include/stdlib.h" 3 4
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4

# 47 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __ino_t ino_t;
# 59 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;
# 97 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;
# 121 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 158 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 185 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 227 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 2 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 573 "/usr/include/stdlib.h" 3 4
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 672 "/usr/include/stdlib.h" 3 4
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
# 718 "/usr/include/stdlib.h" 3 4
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 756 "/usr/include/stdlib.h" 3 4
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 786 "/usr/include/stdlib.h" 3 4
extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1062 "/usr/include/stdlib.h" 3 4
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ , __leaf__))

                        __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));
# 478 "/usr/include/string.h" 3 4
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 552 "/usr/include/string.h" 3 4

# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/aarch64-linux-gnu/sys/stat.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 31 "/usr/include/aarch64-linux-gnu/sys/stat.h" 2 3 4
# 99 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stat.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 2 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
struct stat
  {
    __dev_t st_dev;
    __ino_t st_ino;
    __mode_t st_mode;
    __nlink_t st_nlink;
    __uid_t st_uid;
    __gid_t st_gid;
    __dev_t st_rdev;
    __dev_t __pad1;
    __off_t st_size;
    __blksize_t st_blksize;
    int __pad2;
    __blkcnt_t st_blocks;







    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 79 "/usr/include/aarch64-linux-gnu/bits/struct_stat.h" 3 4
    int __glibc_reserved[2];
  };
# 26 "/usr/include/aarch64-linux-gnu/bits/stat.h" 2 3 4
# 102 "/usr/include/aarch64-linux-gnu/sys/stat.h" 2 3 4
# 205 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 264 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 313 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 352 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 365 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ , __leaf__));





extern int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;






extern __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ , __leaf__));
# 389 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






extern int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));





extern int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));






extern int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
# 452 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4
extern int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ , __leaf__));
# 468 "/usr/include/aarch64-linux-gnu/sys/stat.h" 3 4

# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2

# 1 "/usr/include/dirent.h" 1 3 4
# 27 "/usr/include/dirent.h" 3 4

# 61 "/usr/include/dirent.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/dirent.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/dirent.h" 3 4
struct dirent
  {

    __ino_t d_ino;
    __off_t d_off;




    unsigned short int d_reclen;
    unsigned char d_type;
    char d_name[256];
  };
# 62 "/usr/include/dirent.h" 2 3 4
# 127 "/usr/include/dirent.h" 3 4
typedef struct __dirstream DIR;






extern int closedir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));






extern DIR *opendir (const char *__name) __attribute__ ((__nonnull__ (1)))
 __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (closedir, 1)));






extern DIR *fdopendir (int __fd)
 __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (closedir, 1)));
# 164 "/usr/include/dirent.h" 3 4
extern struct dirent *readdir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
# 185 "/usr/include/dirent.h" 3 4
extern int readdir_r (DIR *__restrict __dirp,
        struct dirent *__restrict __entry,
        struct dirent **__restrict __result)
     __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__deprecated__));
# 211 "/usr/include/dirent.h" 3 4
extern void rewinddir (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void seekdir (DIR *__dirp, long int __pos) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int telldir (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int dirfd (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 247 "/usr/include/dirent.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 248 "/usr/include/dirent.h" 2 3 4
# 257 "/usr/include/dirent.h" 3 4
extern int scandir (const char *__restrict __dir,
      struct dirent ***__restrict __namelist,
      int (*__selector) (const struct dirent *),
      int (*__cmp) (const struct dirent **,
      const struct dirent **))
     __attribute__ ((__nonnull__ (1, 2)));
# 327 "/usr/include/dirent.h" 3 4
extern int alphasort (const struct dirent **__e1,
        const struct dirent **__e2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 404 "/usr/include/dirent.h" 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/dirent_ext.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/dirent_ext.h" 3 4

# 33 "/usr/include/aarch64-linux-gnu/bits/dirent_ext.h" 3 4

# 407 "/usr/include/dirent.h" 2 3 4
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/unistd.h" 1 3 4
# 27 "/usr/include/unistd.h" 3 4

# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/environments.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/environments.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/environments.h" 2 3 4
# 207 "/usr/include/unistd.h" 2 3 4
# 226 "/usr/include/unistd.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 274 "/usr/include/unistd.h" 3 4
typedef __socklen_t socklen_t;
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 309 "/usr/include/unistd.h" 3 4
extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));
# 358 "/usr/include/unistd.h" 3 4
extern int close (int __fd);
# 371 "/usr/include/unistd.h" 3 4
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    __attribute__ ((__access__ (__write_only__, 2, 3)));





extern ssize_t write (int __fd, const void *__buf, size_t __n)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
# 389 "/usr/include/unistd.h" 3 4
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
    __attribute__ ((__access__ (__write_only__, 2, 3)));






extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
# 437 "/usr/include/unistd.h" 3 4
extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;



extern int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;



extern int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;
# 552 "/usr/include/unistd.h" 3 4
extern int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;


extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));
# 564 "/usr/include/unistd.h" 3 4
extern char **__environ;







extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));




extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 619 "/usr/include/unistd.h" 3 4
extern int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;




extern void _exit (int __status) __attribute__ ((__noreturn__));





# 1 "/usr/include/aarch64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));


extern long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));



extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 3)));




extern __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));


extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));

extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));






extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));
# 682 "/usr/include/unistd.h" 3 4
extern int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));






extern __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));



extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));



extern __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));


extern __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));




extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 1)));
# 722 "/usr/include/unistd.h" 3 4
extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;




extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;
# 778 "/usr/include/unistd.h" 3 4
extern __pid_t fork (void) __attribute__ ((__nothrow__));
# 799 "/usr/include/unistd.h" 3 4
extern char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));



extern int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));
# 819 "/usr/include/unistd.h" 3 4
extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;




extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;




extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));





extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;


extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)))
     __attribute__ ((__access__ (__write_only__, 3, 4)));



extern int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));






extern char *getlogin (void);







extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
# 903 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4








extern char *optarg;
# 50 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4
extern int optind;




extern int opterr;



extern int optopt;
# 91 "/usr/include/aarch64-linux-gnu/bits/getopt_core.h" 3 4
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));


# 28 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 2 3 4


# 38 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 3 4
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts) __asm__ ("" "__posix_getopt") __attribute__ ((__nothrow__ , __leaf__))

                     ;
# 49 "/usr/include/aarch64-linux-gnu/bits/getopt_posix.h" 3 4

# 904 "/usr/include/unistd.h" 2 3 4







extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
# 989 "/usr/include/unistd.h" 3 4
extern int fsync (int __fd);
# 1002 "/usr/include/unistd.h" 3 4
extern long int gethostid (void);


extern void sync (void) __attribute__ ((__nothrow__ , __leaf__));
# 1026 "/usr/include/unistd.h" 3 4
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1049 "/usr/include/unistd.h" 3 4
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;
# 1114 "/usr/include/unistd.h" 3 4
extern int lockf (int __fd, int __cmd, __off_t __len) ;
# 1150 "/usr/include/unistd.h" 3 4
extern int fdatasync (int __fildes);
# 1171 "/usr/include/unistd.h" 3 4
extern void swab (const void *__restrict __from, void *__restrict __to,
    ssize_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
    __attribute__ ((__access__ (__read_only__, 1, 3)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 1222 "/usr/include/unistd.h" 2 3 4


# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/libgen.h" 1 3 4
# 23 "/usr/include/libgen.h" 3 4



extern char *dirname (char *__path) __attribute__ ((__nothrow__ , __leaf__));







extern char *__xpg_basename (char *__path) __attribute__ ((__nothrow__ , __leaf__));



# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/usr/include/errno.h" 1 3 4
# 28 "/usr/include/errno.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/errno.h" 1 3 4
# 26 "/usr/include/aarch64-linux-gnu/bits/errno.h" 3 4
# 1 "/usr/include/linux/errno.h" 1 3 4
# 1 "/usr/include/aarch64-linux-gnu/asm/errno.h" 1 3 4
# 1 "/usr/include/asm-generic/errno.h" 1 3 4




# 1 "/usr/include/asm-generic/errno-base.h" 1 3 4
# 6 "/usr/include/asm-generic/errno.h" 2 3 4
# 2 "/usr/include/aarch64-linux-gnu/asm/errno.h" 2 3 4
# 2 "/usr/include/linux/errno.h" 2 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/errno.h" 2 3 4
# 29 "/usr/include/errno.h" 2 3 4








extern int *__errno_location (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
# 52 "/usr/include/errno.h" 3 4

# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/dyn_array.h" 1
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 2








# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
typedef struct {
    char *path;
    dev_t device;
    ino_t inode;
    
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
        visited;
} NlWalkDirectory;



static void nl_walk_enqueue(NlWalkDirectory **queue, size_t *count, size_t *capacity, char *path) {
    if (*count == *capacity) {
        if (*capacity > 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                       (18446744073709551615UL) 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                / 2 / sizeof(**queue)) abort();
        size_t next = *capacity ? *capacity * 2 : 16;
        NlWalkDirectory *grown = realloc(*queue, next * sizeof(**queue));
        if (!grown) abort();
        *queue = grown;
        *capacity = next;
    }
    (*queue)[(*count)++] = (NlWalkDirectory){.path = path};
}



static DynArray* nl_fs_walkdir(const char* root) {
    DynArray* result = dyn_array_new_with_capacity(ELEM_STRING, 128);
    if (!result || !root || !root[0]) return result;
    NlWalkDirectory *queue = 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                            ((void *)0)
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                ;
    size_t count = 0, capacity = 0;
    char *initial = strdup(root);
    if (!initial) abort();
    nl_walk_enqueue(&queue, &count, &capacity, initial);
    for (size_t current = 0; current < count; ++current) {
        char *path = queue[current].path;
        DIR *dir = opendir(path);
        struct stat identity;
        
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
       _Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
            seen = 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                   0
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                        ;
        if (dir && fstat(dirfd(dir), &identity) == 0) {
            for (size_t prior = 0; prior < current; ++prior) {
                if (queue[prior].visited && queue[prior].device == identity.st_dev &&
                    queue[prior].inode == identity.st_ino) { seen = 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                                                   1
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                                                       ; break; }
            }
            if (!seen) {
                queue[current].visited = 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                        1
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                            ;
                queue[current].device = identity.st_dev;
                queue[current].inode = identity.st_ino;
                struct dirent *entry;
                while ((entry = readdir(dir)) != 
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                                ((void *)0)
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                                    ) {
                    if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;
                    size_t parent_len = strlen(path), name_len = strlen(entry->d_name);
                    if (parent_len > 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                    (18446744073709551615UL) 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                             - name_len - 2) abort();
                    char *child = malloc(parent_len + name_len + 2);
                    if (!child) abort();
                    memcpy(child, path, parent_len);
                    child[parent_len] = '/';
                    memcpy(child + parent_len + 1, entry->d_name, name_len + 1);
                    struct stat st;
                    if (stat(child, &st) == 0) {
                        if (
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                           ((((
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                           st.st_mode
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                           )) & 0170000) == (0100000))
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                              ) dyn_array_push_string_copy(result, child);
                        else if (
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                ((((
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                st.st_mode
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                )) & 0170000) == (0040000))
# 70 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                                   ) {
                            nl_walk_enqueue(&queue, &count, &capacity, child);
                            child = 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                                   ((void *)0)
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                       ;
                        }
                    }
                    free(child);
                }
            }
        }
        if (dir) closedir(dir);
        free(path);
        queue[current].path = 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h" 3 4
                             ((void *)0)
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/directory_walk.h"
                                 ;
    }
    free(queue);
    return result;
}
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_bytes.h" 1







static inline DynArray *nl_read_byte_stream(FILE *file) {
    DynArray *bytes = dyn_array_new(ELEM_U8);
    if (!bytes || !file) {
        if (file) fclose(file);
        return bytes;
    }
    unsigned char buffer[4096];
    size_t count;
    while ((count = fread(buffer, 1, sizeof(buffer), file)) != 0) {
        for (size_t i = 0; i < count; i++) dyn_array_push_u8(bytes, buffer[i]);
    }
    int failed = ferror(file);
    if (fclose(file) != 0) failed = 1;
    if (failed) bytes->length = 0;
    return bytes;
}

static inline DynArray *nl_read_file_bytes(const char *path) {
    return nl_read_byte_stream(path ? fopen(path, "rb") : 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_bytes.h" 3 4
                                                         ((void *)0)
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_bytes.h"
                                                             );
}
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 2






static inline char *nl_read_text_stream(FILE *file) {
    DynArray *bytes = nl_read_byte_stream(file);
    if (!bytes) return 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 3 4
                      ((void *)0)
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h"
                          ;
    size_t length = (size_t)bytes->length;
    if (length && memchr(bytes->data, 0, length)) length = 0;
    char *text = length < 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 3 4
                         (18446744073709551615UL) 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h"
                                  ? malloc(length + 1) : 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 3 4
                                                         ((void *)0)
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h"
                                                             ;
    if (text) {
        if (length) memcpy(text, bytes->data, length);
        text[length] = '\0';
    }
    gc_release(bytes);
    return text;
}

static inline char *nl_read_file_text(const char *path) {
    return nl_read_text_stream(path ? fopen(path, "rb") : 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h" 3 4
                                                         ((void *)0)
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_text.h"
                                                             );
}
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_write.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/file_write.h"
static inline int64_t nl_write_file_text(const char *path, const char *text,
                                         const char *mode) {
    if (!path || !text) return -1;
    FILE *file = fopen(path, mode);
    if (!file) return -1;
    size_t length = strlen(text);
    size_t written = fwrite(text, 1, length, file);
    int closed = fclose(file);
    return written == length && closed == 0 ? 0 : -1;
}
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
static inline char *nl_normalize_path(const char *path) {
    if (!path) path = "";
    size_t length = strlen(path), slots = length / 2 + 1;
    if (length > 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 3 4
                (18446744073709551615UL) 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
                         - 2 || slots > 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 3 4
                                        (18446744073709551615UL) 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
                                                 / sizeof(size_t)) return 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 3 4
                                                                          ((void *)0)
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
                                                                              ;
    char *out = malloc(length + 2);
    size_t *bases = malloc(slots * sizeof *bases);
    if (!out || !bases) { free(out); free(bases); return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 3 4
                                                        ((void *)0)
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
                                                            ; }
    int absolute = path[0] == '/';
    size_t used = 0, count = 0, cursor = 0;
    if (absolute) out[used++] = '/';
    while (cursor < length) {
        if (path[cursor] == '/') { ++cursor; continue; }
        size_t start = cursor;
        while (cursor < length && path[cursor] != '/') ++cursor;
        size_t size = cursor - start;
        if (size == 1 && path[start] == '.') continue;
        if (size == 2 && path[start] == '.' && path[start + 1] == '.') {
            if (count) {
                size_t previous = bases[count - 1];
                if (out[previous] == '/') ++previous;
                if (!(used - previous == 2 && out[previous] == '.' && out[previous + 1] == '.')) {
                    used = bases[--count]; continue;
                }
            }
            if (absolute) continue;
        }
        if (count >= slots) { free(out); free(bases); return 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h" 3 4
                                                            ((void *)0)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/../../src/runtime/path_normalize.h"
                                                                ; }
        bases[count++] = used;
        if (used && out[used - 1] != '/') out[used++] = '/';
        memcpy(out + used, path + start, size); used += size;
    }
    if (!used) out[used++] = '.';
    out[used] = 0;
    free(bases);
    return out;
}
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 2

__attribute__((visibility("default"))) const uint32_t fs_walkdir__nano_array_abi = 1u;

DynArray* fs_walkdir(const char* root) {
    return nl_fs_walkdir(root);
}


# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
    fs_walkdir_release(DynArray* result) {
    if (!result || !gc_is_managed(result)) return 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                 0
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                      ;
    GCHeader *header = gc_get_header(result);
    if (header->type != GC_TYPE_ARRAY || header->ref_count != 1 ||
        !dyn_array_has_storage(result, ELEM_STRING, sizeof(char*), 0)) return 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                                             0
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                                                  ;
    for (int64_t i = 0; i < result->length; i++) {
        free(((char**)result->data)[i]);
        ((char**)result->data)[i] = 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                   ((void *)0)
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                       ;
    }
    result->length = 0;
    gc_release(result);
    return 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
          1
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
              ;
}



const char* path_canonical(const char* path) {
    if (!path || !path[0]) return strdup("");
    char *resolved = realpath(path, 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                   ((void *)0)
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                       );
    return resolved ? resolved : strdup("");
}




int64_t file_compare_identity(const char* source, const char* candidate) {
    struct stat source_stat, candidate_stat;
    if (!source || !source[0] || !candidate || !candidate[0]) return -1;
    if (stat(source, &source_stat) != 0) return -1;
    if (stat(candidate, &candidate_stat) != 0)
        return 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
              (*__errno_location ()) 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                    == 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                       2 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                              || 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                 (*__errno_location ()) 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                       == 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                          20 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                  ? 0 : -1;
    return source_stat.st_dev == candidate_stat.st_dev &&
           source_stat.st_ino == candidate_stat.st_ino ? 1 : 0;
}


static int destination_stat(const char* path, struct stat* info) {
    if (stat(path, info) == 0) return 1;
    if (
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
       (*__errno_location ()) 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
             != 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                2
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                      ) return -1;
    if (lstat(path, info) == 0 || 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                 (*__errno_location ()) 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                       != 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                          2
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                ) return -1;
    return 0;
}





int64_t file_compare_destinations(const char* first, const char* second) {
    if (!first || !first[0] || !second || !second[0]) return -1;
    struct stat a, b;
    int a_exists = destination_stat(first, &a);
    int b_exists = destination_stat(second, &b);
    if (a_exists < 0 || b_exists < 0) return -1;
    if (a_exists && b_exists)
        return a.st_dev == b.st_dev && a.st_ino == b.st_ino;
    if (a_exists || b_exists) return 0;

    if (mkdir(first, 0700) != 0) return -1;
    int64_t result = -1;
    if (stat(first, &a) == 0) {
        b_exists = destination_stat(second, &b);
        if (b_exists == 0) result = 0;
        else if (b_exists > 0)
            result = a.st_dev == b.st_dev && a.st_ino == b.st_ino;
    }
    if (rmdir(first) != 0) return -1;
    return result;
}



const char* path_normalize(const char* path) {
    return nl_normalize_path(path);
}


const char* path_join(const char* a, const char* b) {
    char result[2048];

    if (!a || a[0] == '\0') {
        snprintf(result, sizeof(result), "%s", b ? b : "");
        return strdup(result);
    }

    if (!b || b[0] == '\0') {
        snprintf(result, sizeof(result), "%s", a);
        return strdup(result);
    }


    size_t a_len = strlen(a);
    if (a[a_len - 1] == '/') {
        snprintf(result, sizeof(result), "%s%s", a, b);
    } else {
        snprintf(result, sizeof(result), "%s/%s", a, b);
    }

    return strdup(result);
}


const char* path_basename(const char* path) {
    if (!path || path[0] == '\0') {
        return strdup(".");
    }


    char* copy = strdup(path);
    if (!copy) {
        return strdup(path);
    }

    char* base = 
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                __xpg_basename
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        (copy);
    const char* result = strdup(base);
    free(copy);

    return result;
}


const char* path_dirname(const char* path) {
    if (!path || path[0] == '\0') {
        return strdup(".");
    }


    char* copy = strdup(path);
    if (!copy) {
        return strdup(path);
    }

    char* dir = dirname(copy);
    const char* result = strdup(dir);
    free(copy);

    return result;
}

static char *relative_path_cwd(void) {
    size_t capacity = 256;
    for (;;) {
        char *cwd = malloc(capacity);
        if (!cwd) return 
# 168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                        ((void *)0)
# 168 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                            ;
        if (getcwd(cwd, capacity)) return cwd;
        int error = 
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                   (*__errno_location ())
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        ;
        free(cwd);
        if (error != 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                    34 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                           || capacity > 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                         (18446744073709551615UL) 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                  / 2) return 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                              ((void *)0)
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                                  ;
        capacity *= 2;
    }
}

static char *relative_path_absolute(const char *path, const char *cwd) {
    if (path[0] == '/') return nl_normalize_path(path);
    size_t prefix = strlen(cwd), suffix = strlen(path);
    if (suffix > 
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                (18446744073709551615UL) 
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                         - 2 || prefix > 
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                         (18446744073709551615UL) 
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                  - suffix - 2) return 
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                                       ((void *)0)
# 180 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                                           ;
    char *joined = malloc(prefix + suffix + 2);
    if (!joined) return 
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                       ((void *)0)
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                           ;
    memcpy(joined, cwd, prefix); joined[prefix] = '/';
    memcpy(joined + prefix + 1, path, suffix + 1);
    char *normalized = nl_normalize_path(joined);
    free(joined);
    return normalized;
}



const char* path_relpath(const char* target, const char* base) {
    if (!target || !base) return strdup(".");
    char *cwd = 
# 194 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
               ((void *)0)
# 194 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                   ;
    if (target[0] != '/' || base[0] != '/') {
        cwd = relative_path_cwd();
        if (!cwd) return 
# 197 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                        ((void *)0)
# 197 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                            ;
    }
    char *target_norm = relative_path_absolute(target, cwd);
    char *base_norm = relative_path_absolute(base, cwd);
    free(cwd);
    if (!target_norm || !base_norm) {
        free(target_norm); free(base_norm); return 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                  ((void *)0)
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                      ;
    }
    size_t target_length = strlen(target_norm), base_length = strlen(base_norm);
    if (target_length > 
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                       (18446744073709551615UL) 
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                - 2 || base_length > (
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                      (18446744073709551615UL) 
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                               - target_length - 2) / 3) {
        free(target_norm); free(base_norm); return 
# 207 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                  ((void *)0)
# 207 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                      ;
    }
    char *result = malloc(target_length + base_length * 3 + 2);
    if (!result) { free(target_norm); free(base_norm); return 
# 210 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                             ((void *)0)
# 210 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                                 ; }
    char *target_save = 
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                       ((void *)0)
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                           , *base_save = 
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                          ((void *)0)
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                              ;
    char *a = strtok_r(target_norm, "/", &target_save);
    char *b = strtok_r(base_norm, "/", &base_save);
    while (a && b && strcmp(a, b) == 0) {
        a = strtok_r(
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                    ((void *)0)
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        , "/", &target_save);
        b = strtok_r(
# 216 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                    ((void *)0)
# 216 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        , "/", &base_save);
    }
    size_t used = 0;
    while (b) {
        if (used) result[used++] = '/';
        result[used++] = '.'; result[used++] = '.';
        b = strtok_r(
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                    ((void *)0)
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        , "/", &base_save);
    }
    while (a) {
        if (used) result[used++] = '/';
        size_t length = strlen(a);
        memcpy(result + used, a, length); used += length;
        a = strtok_r(
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                    ((void *)0)
# 228 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                        , "/", &target_save);
    }
    if (!used) result[used++] = '.';
    result[used] = 0;
    free(target_norm); free(base_norm);
    return result;
}



void path_normalize__nano_string_release_v1(const char *result) {
    free((void *)result);
}

void path_canonical__nano_string_release_v1(const char *result) {
    free((void *)result);
}

void path_join__nano_string_release_v1(const char *result) {
    free((void *)result);
}

void path_basename__nano_string_release_v1(const char *result) {
    free((void *)result);
}

void path_dirname__nano_string_release_v1(const char *result) {
    free((void *)result);
}

void path_relpath__nano_string_release_v1(const char *result) {
    free((void *)result);
}


static const char file_read_empty_result[] = "";
const char* file_read(const char* path) {
    char *text = nl_read_file_text(path);
    return text ? text : file_read_empty_result;
}

void file_read__nano_string_release_v1(const char *result) {
    if (result != file_read_empty_result) free((void *)result);
}


int64_t file_write(const char* path, const char* content) {
    return nl_write_file_text(path, content, "w");
}


int64_t file_append(const char* path, const char* content) {
    return nl_write_file_text(path, content, "a");
}



# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
_Bool 
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
    file_exists(const char* path) {
    return access(path, 
# 285 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                       0
# 285 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                           ) == 0;
}


int64_t file_delete(const char* path) {
    return remove(path);
}


int64_t fs_mkdir_p(const char* path) {
    if (!path || path[0] == '\0') return -1;

    char tmp[2048];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);

    if (len == 0) return -1;
    if (tmp[len - 1] == '/') {
        tmp[len - 1] = '\0';
    }

    for (char* p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                        (*__errno_location ()) 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                              != 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                                 17
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                       ) {
                *p = '/';
                return -1;
            }
            *p = '/';
        }
    }

    if (mkdir(tmp, 0755) != 0 && 
# 317 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                (*__errno_location ()) 
# 317 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                      != 
# 317 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                         17
# 317 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                               ) {
        return -1;
    }
    return 0;
}


int64_t file_copy(const char* src, const char* dst) {
    FILE* in = fopen(src, "rb");
    if (!in) return -1;
    FILE* out = fopen(dst, "wb");
    if (!out) {
        fclose(in);
        return -1;
    }

    char buffer[8192];
    size_t n = 0;
    while ((n = fread(buffer, 1, sizeof(buffer), in)) > 0) {
        if (fwrite(buffer, 1, n, out) != n) {
            fclose(in);
            fclose(out);
            return -1;
        }
    }

    if (ferror(in)) {
        fclose(in);
        fclose(out);
        return -1;
    }

    fclose(in);
    fclose(out);
    return 0;
}


int64_t dir_copy(const char* src, const char* dst) {
    struct stat st;
    if (stat(src, &st) != 0 || !
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                               ((((
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                               st.st_mode
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                               )) & 0170000) == (0040000))
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                                  ) {
        return -1;
    }

    if (fs_mkdir_p(dst) != 0) {
        return -1;
    }

    DIR* dir = opendir(src);
    if (!dir) return -1;

    struct dirent* entry;
    while ((entry = readdir(dir)) != 
# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                                    ((void *)0)
# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                        ) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        char src_path[2048];
        char dst_path[2048];
        snprintf(src_path, sizeof(src_path), "%s/%s", src, entry->d_name);
        snprintf(dst_path, sizeof(dst_path), "%s/%s", dst, entry->d_name);

        if (stat(src_path, &st) != 0) {
            closedir(dir);
            return -1;
        }

        if (
# 384 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
           ((((
# 384 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
           st.st_mode
# 384 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
           )) & 0170000) == (0040000))
# 384 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                              ) {
            if (dir_copy(src_path, dst_path) != 0) {
                closedir(dir);
                return -1;
            }
        } else if (
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                  ((((
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                  st.st_mode
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c" 3 4
                  )) & 0170000) == (0100000))
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/std/fs.c"
                                     ) {
            if (file_copy(src_path, dst_path) != 0) {
                closedir(dir);
                return -1;
            }
        }
    }

    closedir(dir);
    return 0;
}
