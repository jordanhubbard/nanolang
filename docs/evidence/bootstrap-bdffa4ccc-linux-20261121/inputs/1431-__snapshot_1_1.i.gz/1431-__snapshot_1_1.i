# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
typedef struct {
    uint32_t layout;
    uint32_t name_idx;
    uint16_t field_offset;
    uint16_t field_count;
} NvmUnionVariantFact;

typedef struct {
    uint8_t tag;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
        mutable;
    uint32_t layout;
} NvmOwnershipGlobal;

typedef struct { uint8_t tag; uint32_t layout; } NvmOwnershipEffectValue;


typedef struct {
    uint32_t count;
    NvmOwnershipEffectValue items[256u];
} NvmOwnershipEffectTypes;
typedef struct {
    uint32_t key_idx;
    uint16_t parameter_count;
    NvmOwnershipEffectValue result;
    NvmOwnershipEffectValue parameters[256u];
} NvmOwnershipEffect;





NvmV2Result nvm_ownership_effect(const NvmModule *, uint32_t key_idx,
                                 NvmOwnershipEffect *out);


NvmV2Result nvm_ownership_effect_types(const NvmModule *, NvmOwnershipEffectTypes *out);



NvmV2Result nvm_ownership_array_constructor(const NvmModule *, uint32_t function,
                                            uint32_t byte_offset, uint32_t *out);






NvmV2Result nvm_ownership_globals(const NvmModule *, NvmOwnershipGlobal *,
                                  uint32_t capacity, uint32_t *count);




NvmV2Result nvm_ownership_contracts_validate(const NvmModule *module,
                                            
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h" 3 4
                                           _Bool 
# 85 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/ownership_contracts.h"
                                                *requires_verifier);
typedef enum {
    NVM_LAYOUT_AUTHORITY_UNKNOWN, NVM_LAYOUT_AUTHORITY_ORDINARY,
    NVM_LAYOUT_AUTHORITY_RESOURCE
} NvmLayoutAuthority;




NvmV2Result nvm_ownership_layout_authority(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_layout_authorities(const NvmModule *, uint32_t, NvmLayoutAuthority *);




NvmV2Result nvm_ownership_path(const NvmModule *module, uint32_t index,
                               uint16_t *fields, uint16_t capacity, uint16_t *count);







NvmV2Result nvm_ownership_union_variant(const NvmModule *module,
                                        uint32_t union_ordinal,
                                        uint16_t variant,
                                        NvmUnionVariantFact *out);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 2




typedef enum {
    NVM_REFERENCE_SHARED = 1,
    NVM_REFERENCE_EXCLUSIVE = 2
} NvmReferenceMode;

typedef struct {
    uint64_t invocation;
    uint16_t local;
    uint32_t root_layout;
    const uint16_t *fields;
    uint16_t field_count;
    uint32_t referent_layout;
    NvmReferenceMode mode;
} NvmReferencePlace;






# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_place_valid(const NvmV2Layouts *layouts,
                               uint32_t authoritative_root_layout,
                               const NvmReferencePlace *place);





# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_places_overlap(const NvmReferencePlace *a,
                                  const NvmReferencePlace *b);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_holds_conflict(const NvmReferencePlace *a,
                                 const NvmReferencePlace *b);



# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h"
    nvm_reference_owner_access_conflicts(const NvmReferencePlace *hold,
                                          const NvmReferencePlace *access,
                                          
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h" 3 4
                                         _Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/reference_places.h"
                                              write_or_move);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 2







typedef struct NvmAffineState NvmAffineState;
NvmAffineState *nvm_affine_state_create(const NvmModule *module,
                                       uint32_t function, uint32_t references);
NvmAffineState *nvm_affine_state_clone(const NvmAffineState *state);




NvmAffineState *nvm_affine_handler_enter(const NvmAffineState *state,
                                         uint32_t key_idx,uint16_t first);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_suspend(const NvmAffineState *state);
void nvm_affine_state_free(NvmAffineState *state);


# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_complete_unions(const NvmAffineState *state);


# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_has_array_types(const NvmAffineState *state);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_equal(const NvmAffineState *a, const NvmAffineState *b);



# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_state_meet_initialization(NvmAffineState *destination,
                                          const NvmAffineState *incoming,
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                        _Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                             *changed);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_define(NvmAffineState *state, uint16_t local);


# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_define(NvmAffineState *state, uint16_t local);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_string_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_move(NvmAffineState *state, uint16_t source, uint16_t destination);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_pack(NvmAffineState *state, uint16_t destination,
                      const uint16_t *fields, uint16_t count);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_unpack(NvmAffineState *state, uint16_t source,
                        const uint16_t *fields, uint16_t count);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owner_access(const NvmAffineState *state, uint16_t root,
                              const uint16_t *path, uint16_t count, 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                                   _Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
                                                                        write);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_begin(NvmAffineState *state);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_region_end(NvmAffineState *state);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_borrow(NvmAffineState *state, uint32_t reference,
                        uint16_t root, const uint16_t *path, uint16_t count,
                        NvmReferenceMode mode);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reborrow(NvmAffineState *state, uint32_t reference,
                          uint32_t parent, NvmReferenceMode mode);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_access(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write);

# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_reference_field(const NvmAffineState *state, uint32_t reference,
                                  uint16_t field, 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
                                                 _Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
                                                      write, uint8_t *tag);




# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit(const NvmAffineState *state, uint16_t result);



# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_info(const NvmAffineState *state, uint16_t local,
                            uint8_t *tag, uint8_t *mode);

# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_scalar_field(const NvmAffineState *state, uint16_t local,
                              uint16_t field, uint8_t *tag);

# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_scalar(const NvmAffineState *state, uint8_t tag);
typedef struct { uint8_t tag; uint32_t layout; } NvmAffineType;

# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_types_equal(const NvmAffineState *,NvmAffineType,NvmAffineType);

# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_define(NvmAffineState *,uint16_t local,uint32_t element);



# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_element(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_type(const NvmAffineState *,NvmAffineType,NvmAffineType *);

# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_array_tag_type(const NvmAffineState *,uint8_t,NvmAffineType *);

# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 75 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_resume(const NvmAffineState *state,NvmAffineType result);






# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_type_is_owned(const NvmAffineState *state,NvmAffineType type);

# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_is_copyable(const NvmAffineState *state,uint32_t layout);

# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_define(NvmAffineState *state,uint16_t local,uint32_t layout);

# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_local_fields(const NvmAffineState *state,uint16_t local,
    NvmAffineType *fields,uint16_t capacity,uint16_t *count);

# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_take_local(NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 87 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_put_local(NvmAffineState *state, uint16_t local, NvmAffineType type);

# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_local_type(const NvmAffineState *state, uint16_t local, NvmAffineType *type);

# 89 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 89 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_record_fields(const NvmAffineState *state, uint32_t layout,
                               NvmAffineType *fields, uint16_t capacity, uint16_t *count);



# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_define(NvmAffineState *state,uint16_t local,
                              uint32_t layout,uint16_t variant);




# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_pack(NvmAffineState *state,uint16_t destination,uint16_t variant,
                            const uint16_t *fields,uint16_t count);

# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_unpack(NvmAffineState *state,uint16_t source,uint16_t variant,
                              const uint16_t *fields,uint16_t count);

# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_refine(NvmAffineState *state,uint16_t local,uint16_t variant);

# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_variant(const NvmAffineState *state,uint16_t local,
                               uint16_t *variant);

# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_union_fields(const NvmAffineState *state,uint32_t layout,
                              uint16_t variant,NvmAffineType *fields,
                              uint16_t capacity,uint16_t *count);

# 108 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 108 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_can_exit_type(const NvmAffineState *state, NvmAffineType type);






# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_bind_caller(NvmAffineState *callee,const NvmAffineState *caller,
                             uint32_t reference);

# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_at(const NvmAffineState *state,uint16_t parameter,
                               NvmAffineType *type,NvmReferenceMode *mode);
# 126 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"

# 126 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 126 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_result(const NvmAffineState *state,NvmAffineType *type,
                              uint16_t *field_count);



# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_value_parameters(const NvmAffineState *state,
                                  NvmAffineType *types,uint16_t capacity,uint16_t *count);



# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_consuming_parameters(const NvmAffineState *state,
                                      NvmAffineType *types,uint16_t capacity,uint16_t *count);


# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_owned_parameter_type(const NvmAffineState *state,NvmAffineType *type);

# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h" 3 4
_Bool 
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.h"
    nvm_affine_parameter_type(const NvmAffineState *state,NvmAffineType *type,
                                 NvmReferenceMode *mode);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4



# 59 "/usr/include/stdlib.h" 3 4
typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);





  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 1 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 205 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4

extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 82 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 1 3 4
# 64 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uio_lim.h" 1 3 4
# 65 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 2 3 4
# 204 "/usr/include/limits.h" 2 3 4
# 206 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 2 3 4
# 35 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2


# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
typedef struct { uint8_t tag, mode; uint32_t layout; } Slot;
typedef struct {
    uint32_t users;
    NvmV2Layouts layouts;
    uint8_t *flags;
    Slot result, *locals;
    NvmOwnershipEffectTypes *arrays;
    uint16_t count, params;
    const NvmModule *module;
    uint32_t function;
} Facts;
typedef struct {
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        live;
    uint32_t region, parent;
    NvmReferencePlace place;
} Reference;
typedef struct { uint64_t invocation; uint16_t local; uint32_t layout; } CallerOrigin;
struct NvmAffineState {
    Facts *facts;
    
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        *live;
    uint16_t *variants;
    Reference *refs;
    uint32_t ref_count, region;
    
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        caller_bound;
    
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        handler;
    uint16_t handler_first;
    uint32_t handler_key;
    NvmAffineType resume_type;
    uint64_t invocation;
    uint16_t origin_count;
    CallerOrigin origins[8u];
};
static 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           scalar(uint8_t tag) {
    return tag == TAG_INT || tag == TAG_U8 || tag == TAG_FLOAT || tag == TAG_BOOL;
}
static 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           array_leaf(const Facts *f,Slot slot,Slot *leaf) {
    for (uint32_t depth=0;depth<=256u;depth++) {
        if (slot.tag!=TAG_ARRAY) { *leaf=slot;return 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                    1
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                        ; }
        if (slot.mode || !f->arrays || slot.layout>=f->arrays->count) return 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                            0
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
        NvmOwnershipEffectValue value=f->arrays->items[slot.layout];
        slot=(Slot){value.tag,0,value.layout};
    }
    return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
               ;
}
static 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           resource(const Facts *f, Slot slot) {
    if (!array_leaf(f,slot,&slot)) return 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         0
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ;
    return (slot.tag==TAG_STRUCT || slot.tag==TAG_UNION) &&
           slot.layout<f->layouts.count &&
           (f->flags[slot.layout] & 2u);
}
static 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           union_ordinal(const Facts *f,uint32_t layout,uint32_t *ordinal) {
    if (!f || !ordinal || layout>=f->layouts.count ||
        f->layouts.items[layout].kind!=NVM_V2_LAYOUT_UNION) return 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                  0
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                       ;
    uint32_t found=0;
    for (uint32_t i=0;i<layout;i++)
        if (f->layouts.items[i].kind==NVM_V2_LAYOUT_UNION) found++;
    *ordinal=found;return 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                         1
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                             ;
}
static 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           union_value(const Facts *f, Slot slot) {
    uint32_t ordinal;NvmUnionVariantFact fact;
    return slot.tag==TAG_UNION && slot.mode==0 &&
           union_ordinal(f,slot.layout,&ordinal) &&
           nvm_ownership_union_variant(f->module,ordinal,0,&fact)==NVM_V2_OK &&
           fact.layout==slot.layout;
}
static 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 72 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           supported(const Facts *f,Slot slot) {
    return (slot.tag==TAG_ARRAY && !slot.mode && f->arrays && slot.layout<f->arrays->count) ||
           scalar(slot.tag) ||
           (slot.tag == TAG_STRING && slot.layout == 0xFFFFFFFFu) ||
           (slot.tag == TAG_STRUCT && slot.layout != 0xFFFFFFFFu) ||
           union_value(f,slot);
}
static 
# 79 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 79 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           same(const Facts *f,Slot a, Slot b) {
    if (a.mode!=b.mode) return 
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                              0
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                   ;
    for (uint32_t depth=0;depth<=256u;depth++) {
        if (a.tag!=b.tag) return 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                0
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                     ;
        if (a.tag!=TAG_ARRAY) return a.layout==b.layout;
        if (!f->arrays || a.layout>=f->arrays->count || b.layout>=f->arrays->count) return 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                          0
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                               ;
        NvmOwnershipEffectValue x=f->arrays->items[a.layout],y=f->arrays->items[b.layout];
        a=(Slot){x.tag,0,x.layout};b=(Slot){y.tag,0,y.layout};
    }
    return 
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          0
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
               ;
}
static 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           slot_read(NvmV2Cursor *c, Slot *s) {
    uint16_t reserved;
    return nvm_v2_u8(c,&s->tag)==NVM_V2_OK && nvm_v2_u8(c,&s->mode)==NVM_V2_OK &&
           nvm_v2_u16(c,&reserved)==NVM_V2_OK && nvm_v2_u32(c,&s->layout)==NVM_V2_OK;
}
static void facts_free(Facts *f) {
    if (!f || --f->users) return;
    nvm_v2_layouts_free(&f->layouts); free(f->flags); free(f->locals); free(f->arrays); free(f);
}

# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_has_complete_unions(const NvmAffineState *s) {
    if (!s) return 
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  0
# 100 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                       ;
    for (uint32_t i=0;i<s->facts->layouts.count;i++)
        if (s->facts->layouts.items[i].kind==NVM_V2_LAYOUT_UNION &&
            (s->facts->flags[i]&1u)) return 
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                            1
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                ;
    return 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          0
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
               ;
}
void nvm_affine_state_free(NvmAffineState *s) {
    if (!s) return;
    if (s->refs) for (uint32_t i=0;i<s->ref_count;i++) free((void*)s->refs[i].place.fields);
    free(s->refs); free(s->variants); free(s->live); facts_free(s->facts); free(s);
}
NvmAffineState *nvm_affine_state_create(const NvmModule *m, uint32_t function,
                                       uint32_t references) {
    
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 113 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        needs;


    if (!m || !m->ownership_size || function >= m->function_count ||
        nvm_ownership_contracts_validate(m,&needs)!=NVM_V2_OK) return 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                     ((void *)0)
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                         ;
    NvmAffineState *s=calloc(1,sizeof(*s));
    if (!s) return 
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  ((void *)0)
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;
    s->facts=calloc(1,sizeof(*s->facts));
    if (!s->facts) { free(s); return 
# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    ((void *)0)
# 121 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                        ; }
    Facts *f=s->facts; f->users=1; f->module=m; f->function=function;
    s->invocation=1;
    NvmOwnershipEffectTypes arrays;
    NvmV2Result array_status=nvm_ownership_effect_types(m,&arrays);
    if (array_status!=NVM_V2_OK && array_status!=NVM_V2_ERR_INDEX_RANGE) goto fail;
    if (array_status==NVM_V2_OK && arrays.count) {
        f->arrays=malloc(sizeof(*f->arrays));if (!f->arrays) goto fail;
        *f->arrays=arrays;
    }
    if (nvm_v2_layouts_decode(m->layout_data,m->layout_size,&f->layouts)!=NVM_V2_OK) goto fail;
    NvmV2Cursor c; nvm_v2_cursor_init(&c,m->ownership_data,m->ownership_size);
    uint32_t ignored, count; const uint8_t *flags;
    if (nvm_v2_u32(&c,&ignored)!=NVM_V2_OK || nvm_v2_u32(&c,&count)!=NVM_V2_OK ||
        nvm_v2_take(&c,count,&flags)!=NVM_V2_OK) goto fail;
    f->flags=malloc(count ? count : 1);
    if (!f->flags) goto fail;
    memcpy(f->flags,flags,count);
    if (nvm_v2_align4(&c)!=NVM_V2_OK || nvm_v2_u32(&c,&ignored)!=NVM_V2_OK) goto fail;
    uint16_t params=0;
    for (uint32_t i=0;i<=function;i++) {
        uint16_t locals; Slot result;
        if (nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK ||
            !slot_read(&c,&result)) goto fail;
        if (i==function) {
            if (result.tag != TAG_VOID && !supported(f,result)) goto fail;
            f->count=locals; f->params=params; f->result=result;
            f->locals=calloc(locals ? locals : 1,sizeof(*f->locals));
            if (!f->locals) goto fail;
        }
        for (uint16_t j=0;j<locals;j++) {
            Slot slot; if (!slot_read(&c,&slot)) goto fail;
            if (i==function) {

                if (!supported(f,slot)) goto fail;
                f->locals[j]=slot;
            }
        }
    }
    s->ref_count=references;
    s->live=calloc(f->count ? f->count : 1,sizeof(*s->live));
    s->variants=malloc((f->count ? f->count : 1)*sizeof(*s->variants));
    s->refs=calloc(references ? references : 1,sizeof(*s->refs));
    if (!s->live || !s->variants || !s->refs) goto fail;
    for (uint16_t i=0;i<f->count;i++) s->variants[i]=
# 165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                    (65535)
# 165 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                              ;
    for (uint16_t i=0;i<params;i++) {
        Slot slot=f->locals[i]; s->live[i]=
# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          1
# 167 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ;
        if (slot.mode) {
            if (i>=references) goto fail;
            s->refs[i]=(Reference){
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                  1
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                      ,0,
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         (4294967295U)
# 170 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                   ,
                {1,i,slot.layout,
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                ((void *)0)
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                    ,0,slot.layout,(NvmReferenceMode)slot.mode}};
        }
    }
    return s;
fail:
    nvm_affine_state_free(s); return 
# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    ((void *)0)
# 176 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                        ;
}
NvmAffineState *nvm_affine_state_clone(const NvmAffineState *s) {
    if (!s || s->facts->users==
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                              (4294967295U)
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                        ) return 
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                 ((void *)0)
# 179 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                     ;
    NvmAffineState *out=calloc(1,sizeof(*out));
    if (!out) return 
# 181 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                    ((void *)0)
# 181 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                        ;
    out->facts=s->facts; out->facts->users++;
    out->ref_count=s->ref_count; out->region=s->region;
    out->caller_bound=s->caller_bound; out->invocation=s->invocation;
    out->handler=s->handler;out->handler_first=s->handler_first;
    out->handler_key=s->handler_key;out->resume_type=s->resume_type;
    out->origin_count=s->origin_count;
    memcpy(out->origins,s->origins,sizeof(out->origins));
    out->live=malloc((s->facts->count ? s->facts->count : 1)*sizeof(*s->live));
    out->variants=malloc((s->facts->count ? s->facts->count : 1)*sizeof(*s->variants));
    out->refs=calloc(s->ref_count ? s->ref_count : 1,sizeof(*s->refs));
    if (!out->live || !out->variants || !out->refs) goto fail;
    memcpy(out->live,s->live,s->facts->count*sizeof(*s->live));
    memcpy(out->variants,s->variants,s->facts->count*sizeof(*s->variants));
    for (uint32_t i=0;i<s->ref_count;i++) {
        out->refs[i]=s->refs[i]; out->refs[i].place.fields=
# 196 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                          ((void *)0)
# 196 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                              ;
        uint16_t count=s->refs[i].place.field_count;
        if (count) {
            uint16_t *path=malloc(count*sizeof(*path)); if (!path) goto fail;
            memcpy(path,s->refs[i].place.fields,count*sizeof(*path));
            out->refs[i].place.fields=path;
        }
    }
    return out;
fail:
    nvm_affine_state_free(out); return 
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                      ((void *)0)
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
}
NvmAffineState *nvm_affine_handler_enter(const NvmAffineState *s,
                                         uint32_t key_idx,uint16_t first) {
    if (!s || s->region || s->caller_bound || first>s->facts->count ||
        (s->handler && first<s->handler_first)) return 
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      ((void *)0)
# 211 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                          ;
    for (uint32_t i=0;i<s->ref_count;i++) if (s->refs[i].live) return 
# 212 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                     ((void *)0)
# 212 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                         ;
    NvmOwnershipEffect effect;
    if (nvm_ownership_effect(s->facts->module,key_idx,&effect)!=NVM_V2_OK ||
        effect.parameter_count>s->facts->count-first) return 
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                            ((void *)0)
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                ;
    for (uint16_t p=0;p<effect.parameter_count;p++) {
        NvmOwnershipEffectValue value=effect.parameters[p];
        if (!same(s->facts,s->facts->locals[first+p],(Slot){value.tag,0,value.layout})) return 
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                              ((void *)0)
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                  ;
    }
    NvmAffineState *arm=nvm_affine_state_clone(s);
    if (!arm) return 
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                    ((void *)0)
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                        ;
    arm->handler=
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                1
# 222 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                    ;arm->handler_first=first;arm->handler_key=effect.key_idx;
    arm->resume_type=(NvmAffineType){effect.result.tag,effect.result.layout};
    for (uint16_t i=0;i<arm->facts->count;i++) {
        Slot slot=arm->facts->locals[i];
        if (i>=first || slot.mode || resource(arm->facts,slot)) {
            arm->live[i]=
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                        0
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                             ;arm->variants[i]=
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               (65535)
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                         ;
        }
    }
    for (uint16_t p=0;p<effect.parameter_count;p++) arm->live[first+p]=
# 230 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                      1
# 230 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                          ;
    return arm;
}


# 234 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 234 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_can_suspend(const NvmAffineState *s) {
    if (!s || s->region) return 
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                               0
# 235 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                    ;
    for (uint32_t i=0;i<s->ref_count;i++) if (s->refs[i].live) return 
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                     0
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                          ;
    for (uint16_t i=0;i<s->facts->count;i++)
        if (s->live[i] && resource(s->facts,s->facts->locals[i])) return 
# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                        0
# 238 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             ;
    return 
# 239 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 239 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}


# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_can_resume(const NvmAffineState *s,NvmAffineType result) {
    return s && s->handler && same(s->facts,(Slot){s->resume_type.tag,0,s->resume_type.layout},(Slot){result.tag,0,result.layout}) && nvm_affine_can_suspend(s);
}

static 
# 246 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 246 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           state_equal(const NvmAffineState *a, const NvmAffineState *b, 
# 246 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                         _Bool 
# 246 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                              meet_scalars) {
    if (!a || !b || a->facts!=b->facts || a->region!=b->region ||
        a->ref_count!=b->ref_count || a->caller_bound!=b->caller_bound ||
        a->invocation!=b->invocation || a->origin_count!=b->origin_count ||
        a->handler!=b->handler || a->handler_first!=b->handler_first ||
        a->handler_key!=b->handler_key || a->resume_type.tag!=b->resume_type.tag ||
        a->resume_type.layout!=b->resume_type.layout) return 
# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                            0
# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                 ;
    for (uint16_t i=0;i<a->facts->count;i++) {
        Slot slot=a->facts->locals[i];
        if (meet_scalars && !slot.mode &&
            (scalar(slot.tag) || slot.tag==TAG_STRING ||
             ((slot.tag==TAG_UNION || slot.tag==TAG_STRUCT || slot.tag==TAG_ARRAY) && !resource(a->facts,slot)))) continue;
        if (a->live[i]!=b->live[i]) return 
# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          0
# 258 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                               ;
        if (!meet_scalars && slot.tag==TAG_UNION && a->live[i] &&
            a->variants[i]!=b->variants[i]) return 
# 260 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                  0
# 260 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                       ;
    }
    for (uint16_t i=0;i<a->origin_count;i++)
        if(a->origins[i].invocation!=b->origins[i].invocation ||
           a->origins[i].local!=b->origins[i].local ||
           a->origins[i].layout!=b->origins[i].layout) return 
# 265 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                             0
# 265 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                  ;
    for (uint32_t i=0;i<a->ref_count;i++) {
        const Reference *x=&a->refs[i],*y=&b->refs[i];
        if (x->live!=y->live) return 
# 268 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    0
# 268 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                         ;
        if (!x->live) continue;
        const NvmReferencePlace *p=&x->place,*q=&y->place;
        if (x->region!=y->region || x->parent!=y->parent || p->invocation!=q->invocation ||
            p->local!=q->local || p->root_layout!=q->root_layout || p->field_count!=q->field_count ||
            p->referent_layout!=q->referent_layout || p->mode!=q->mode ||
            (p->field_count && memcmp(p->fields,q->fields,p->field_count*sizeof(*p->fields)))) return 
# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                     0
# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                          ;
    }
    return 
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 278 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 278 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_state_equal(const NvmAffineState *a, const NvmAffineState *b) {
    return state_equal(a,b,
# 279 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          0
# 279 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                               );
}

# 281 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 281 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_state_meet_initialization(NvmAffineState *destination,
                                          const NvmAffineState *incoming,
# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                        _Bool 
# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             *changed) {
    if (!changed) return 
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                        0
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                             ;
    *changed=
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
            0
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                 ;

    if (!state_equal(destination,incoming,
# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         1
# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                             )) return 
# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       0
# 286 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                            ;
    for (uint16_t i=0;i<destination->facts->count;i++) {
        Slot slot=destination->facts->locals[i];
        if (!slot.mode && (scalar(slot.tag) || slot.tag==TAG_STRING ||
            ((slot.tag==TAG_UNION || slot.tag==TAG_STRUCT || slot.tag==TAG_ARRAY) && !resource(destination->facts,slot))) && destination->live[i] && !incoming->live[i]) {
            destination->live[i]=
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                0
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                     ;
            if (slot.tag==TAG_UNION) destination->variants[i]=
# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                             (65535)
# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                       ;
            *changed=
# 293 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                    1
# 293 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                        ;
        }
        if (!slot.mode && slot.tag==TAG_UNION && destination->live[i] && incoming->live[i] &&
            destination->variants[i]!=incoming->variants[i] &&
            destination->variants[i]!=
# 297 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                     (65535)
# 297 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                               ) {
            destination->variants[i]=
# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    (65535)
# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                              ;*changed=
# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                        1
# 298 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                            ;
        }
    }
    return 
# 301 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 301 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}
static 
# 303 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 303 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           value_local(const NvmAffineState *s, uint16_t local) {
    return s && local<s->facts->count && !s->facts->locals[local].mode &&
        !(s->handler && local<s->handler_first && resource(s->facts,s->facts->locals[local]));
}
static 
# 307 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 307 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           resolve(const NvmAffineState *s,uint16_t local,const uint16_t *path,
                    uint16_t count,Slot *out) {
    if (!s || local>=s->facts->count || (count && !path)) return 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                0
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                     ;
    Slot slot=s->facts->locals[local];
    for (uint16_t i=0;i<count;i++) {
        if (slot.tag!=TAG_STRUCT || slot.layout>=s->facts->layouts.count) return 
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                0
# 312 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                     ;
        const NvmV2Layout *layout=&s->facts->layouts.items[slot.layout];
        if (layout->kind!=NVM_V2_LAYOUT_STRUCT || path[i]>=layout->field_count) return 
# 314 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                      0
# 314 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                           ;
        NvmV2LayoutField field=layout->fields[path[i]];
        slot=(Slot){field.type_tag,0,field.nested_idx};
    }
    *out=slot; return scalar(slot.tag) ||
        (slot.tag==TAG_STRING && slot.layout==0xFFFFFFFFu) ||
        slot.layout!=0xFFFFFFFFu;
}

# 322 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 322 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_owner_access(const NvmAffineState *s,uint16_t local,
                              const uint16_t *path,uint16_t count,
# 323 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                 _Bool 
# 323 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                      write) {
    Slot slot;
    if (!value_local(s,local) || !s->live[local] || !resolve(s,local,path,count,&slot)) return 
# 325 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                              0
# 325 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                   ;
    NvmReferencePlace place={s->invocation,local,s->facts->locals[local].layout,path,count,
                              slot.layout,NVM_REFERENCE_SHARED};
    for (uint32_t i=0;i<s->ref_count;i++) if (s->refs[i].live &&
        nvm_reference_owner_access_conflicts(&s->refs[i].place,&place,write)) return 
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                    0
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                         ;
    return 
# 330 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 330 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}
static 
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           destination(const NvmAffineState *s,uint16_t local) {
    if (!value_local(s,local)) return 
# 333 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                     0
# 333 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
    if (!s->live[local]) return 
# 334 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                               1
# 334 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                   ;
    if (s->facts->locals[local].tag==TAG_UNION)
        return !resource(s->facts,s->facts->locals[local]);
    return !resource(s->facts,s->facts->locals[local]) &&
           nvm_affine_owner_access(s,local,
# 338 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          ((void *)0)
# 338 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ,0,
# 338 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                 1
# 338 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                     );
}

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_scalar_define(NvmAffineState *s,uint16_t local) {
    if (!destination(s,local) || !scalar(s->facts->locals[local].tag)) return 
# 341 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                             0
# 341 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                  ;
    s->live[local]=
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ; return 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                               1
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                   ;
}

# 344 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 344 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_string_define(NvmAffineState *s,uint16_t local) {
    if (!destination(s,local) || s->facts->locals[local].tag!=TAG_STRING ||
        s->facts->locals[local].layout!=0xFFFFFFFFu) return 
# 346 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                               0
# 346 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                    ;
    s->live[local]=
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;return 
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                              1
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                  ;
}

# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_define(NvmAffineState *s,uint16_t local,uint32_t layout,
                              uint16_t variant) {
    uint32_t ordinal;NvmUnionVariantFact fact;
    if (!destination(s,local) || s->facts->locals[local].layout!=layout ||
        !union_value(s->facts,s->facts->locals[local]) ||
        resource(s->facts,s->facts->locals[local]) ||
        !union_ordinal(s->facts,layout,&ordinal)) return 
# 355 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                        0
# 355 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                             ;
    if (variant!=
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                (65535) 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                           &&
        (nvm_ownership_union_variant(s->facts->module,ordinal,variant,&fact)!=NVM_V2_OK ||
         fact.layout!=layout)) return 
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                     0
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
    s->live[local]=
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;s->variants[local]=variant;return 
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                         1
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                             ;
}

# 361 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 361 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_refine(NvmAffineState *s,uint16_t local,uint16_t variant) {
    uint32_t ordinal;NvmUnionVariantFact fact;
    if (!value_local(s,local) || !s->live[local] ||
        !union_value(s->facts,s->facts->locals[local]) ||
        (s->variants[local]!=
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                            (65535) 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                       &&
         s->variants[local]!=variant) ||
        !union_ordinal(s->facts,s->facts->locals[local].layout,&ordinal) ||
        nvm_ownership_union_variant(s->facts->module,ordinal,variant,&fact)!=NVM_V2_OK)
        return 
# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
              0
# 369 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                   ;
    s->variants[local]=variant;return 
# 370 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                     1
# 370 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                         ;
}

# 372 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 372 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_variant(const NvmAffineState *s,uint16_t local,
                               uint16_t *variant) {
    if (!variant || !value_local(s,local) || !s->live[local] ||
        !union_value(s->facts,s->facts->locals[local]) ||
        s->variants[local]==
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                           (65535)
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                     ) return 
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                              0
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                   ;
    *variant=s->variants[local];return 
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                      1
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
}

# 379 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 379 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_move(NvmAffineState *s,uint16_t from,uint16_t to) {
    if (from==to || !destination(s,to) || !nvm_affine_owner_access(s,from,
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                         ((void *)0)
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             ,0,
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                1
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                    ) ||
        !same(s->facts,s->facts->locals[from],s->facts->locals[to])) return 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                           0
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                ;
    s->live[from]=
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                 0
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ; s->live[to]=
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    1
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                        ;
    if (s->facts->locals[from].tag==TAG_UNION) {
        s->variants[to]=s->variants[from];
        s->variants[from]=
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                         (65535)
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                   ;
    }
    return 
# 387 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 387 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}
static 
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           fields_check(const NvmAffineState *s,uint16_t root,const uint16_t *fields,
                          uint16_t count,
# 390 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                        _Bool 
# 390 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                             unpack) {
    if (!value_local(s,root) || (count && !fields)) return 
# 391 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                          0
# 391 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                               ;
    Slot slot=s->facts->locals[root];
    if (slot.tag!=TAG_STRUCT || slot.layout>=s->facts->layouts.count) return 
# 393 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                            0
# 393 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
    const NvmV2Layout *layout=&s->facts->layouts.items[slot.layout];
    if (layout->kind!=NVM_V2_LAYOUT_STRUCT || count!=layout->field_count) return 
# 395 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                0
# 395 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                     ;
    if (unpack ? !nvm_affine_owner_access(s,root,
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                ((void *)0)
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    ,0,
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       1
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ) : !destination(s,root)) return 
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                            0
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                 ;
    for (uint16_t i=0;i<count;i++) {
        uint16_t local=fields[i]; NvmV2LayoutField field=layout->fields[i];
        if (local==root || !value_local(s,local) ||
            !same(s->facts,s->facts->locals[local],(Slot){field.type_tag,0,field.nested_idx})) return 
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                     0
# 400 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                          ;
        for (uint16_t j=0;j<i;j++) if (fields[j]==local &&
            (unpack || resource(s->facts,s->facts->locals[local]))) return 
# 402 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                          0
# 402 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                               ;
        if (unpack ? !destination(s,local) :
            !nvm_affine_owner_access(s,local,
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                            ((void *)0)
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                ,0,resource(s->facts,s->facts->locals[local]))) return 
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                       0
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                            ;
    }
    return 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_pack(NvmAffineState *s,uint16_t to,const uint16_t *fields,uint16_t count) {
    if (!fields_check(s,to,fields,count,
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                       0
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                            )) return 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      0
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ;
    for (uint16_t i=0;i<count;i++) if (resource(s->facts,s->facts->locals[fields[i]])) {
        s->live[fields[i]]=
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          0
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                               ;s->variants[fields[i]]=
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       (65535)
# 411 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
    }
    s->live[to]=
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
               1
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                   ; return 
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                            1
# 413 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                ;
}

# 415 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 415 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_unpack(NvmAffineState *s,uint16_t from,const uint16_t *fields,uint16_t count) {
    if (!fields_check(s,from,fields,count,
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         1
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                             )) return 
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       0
# 416 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                            ;
    s->live[from]=
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                 0
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;
    for (uint16_t i=0;i<count;i++) {
        s->live[fields[i]]=
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          1
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                              ;s->variants[fields[i]]=
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      (65535)
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                ;
    }
    return 
# 421 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 421 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

static 
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           union_fields_check(const NvmAffineState *s,uint16_t root,uint16_t variant,
                               const uint16_t *fields,uint16_t count,
# 425 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                    _Bool 
# 425 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                         unpack) {
    uint32_t ordinal;NvmUnionVariantFact fact;
    if (!value_local(s,root) || (count && !fields) ||
        !union_value(s->facts,s->facts->locals[root]) ||
        !union_ordinal(s->facts,s->facts->locals[root].layout,&ordinal) ||
        nvm_ownership_union_variant(s->facts->module,ordinal,variant,&fact)!=NVM_V2_OK ||
        fact.field_count!=count) return 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                       0
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                            ;
    if (unpack) {
        if (!s->live[root] || s->variants[root]!=variant ||
            !nvm_affine_owner_access(s,root,
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                           ((void *)0)
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                               ,0,
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                  1
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                      )) return 
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                0
# 434 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                     ;
    } else if (!destination(s,root)) return 
# 435 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                           0
# 435 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                ;
    const NvmV2Layout *layout=&s->facts->layouts.items[fact.layout];
    for (uint16_t i=0;i<count;i++) {
        uint16_t local=fields[i];NvmV2LayoutField field=layout->fields[fact.field_offset+i];
        if (local==root || !value_local(s,local) ||
            !same(s->facts,s->facts->locals[local],(Slot){field.type_tag,0,field.nested_idx})) return 
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                     0
# 440 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                          ;
        for (uint16_t j=0;j<i;j++) if (fields[j]==local &&
            (unpack || resource(s->facts,s->facts->locals[local]))) return 
# 442 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                          0
# 442 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                               ;
        if (unpack ? !destination(s,local) :
            !nvm_affine_owner_access(s,local,
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                            ((void *)0)
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                ,0,resource(s->facts,s->facts->locals[local]))) return 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                       0
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                            ;
    }
    return 
# 446 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 446 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 448 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 448 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_pack(NvmAffineState *s,uint16_t destination,uint16_t variant,
                            const uint16_t *fields,uint16_t count) {
    if (!union_fields_check(s,destination,variant,fields,count,
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                              0
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                   )) return 
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                             0
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                  ;
    for (uint16_t i=0;i<count;i++) if (resource(s->facts,s->facts->locals[fields[i]])) {
        s->live[fields[i]]=
# 452 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          0
# 452 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                               ;s->variants[fields[i]]=
# 452 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       (65535)
# 452 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
    }
    s->live[destination]=
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                        1
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                            ;s->variants[destination]=variant;return 
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                     1
# 454 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                         ;
}

# 456 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 456 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_unpack(NvmAffineState *s,uint16_t source,uint16_t variant,
                              const uint16_t *fields,uint16_t count) {
    if (!union_fields_check(s,source,variant,fields,count,
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                         1
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                             )) return 
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                       0
# 458 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                            ;
    s->live[source]=
# 459 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                   0
# 459 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                        ;s->variants[source]=
# 459 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                             (65535)
# 459 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                       ;
    for (uint16_t i=0;i<count;i++) {
        s->live[fields[i]]=
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          1
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                              ;s->variants[fields[i]]=
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      (65535)
# 461 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                ;
    }
    return 
# 463 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 463 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 465 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 465 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_region_begin(NvmAffineState *s) {
    if (!s || s->region==
# 466 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                        (4294967295U)
# 466 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                  ) return 
# 466 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                           0
# 466 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                ;
    s->region++; return 
# 467 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                       1
# 467 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                           ;
}

# 469 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 469 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_region_end(NvmAffineState *s) {
    if (!s || !s->region) return 
# 470 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                0
# 470 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                     ;
    for (uint32_t i=0;i<s->ref_count;i++) if (s->refs[i].live && s->refs[i].region==s->region) {
        free((void*)s->refs[i].place.fields); memset(&s->refs[i],0,sizeof(s->refs[i]));
    }
    s->region--; return 
# 474 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                       1
# 474 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                           ;
}
static 
# 476 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 476 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           ancestor(const NvmAffineState *s,uint32_t possible,uint32_t child) {
    for (uint32_t n=0;n<s->ref_count && child!=
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                              (4294967295U)
# 477 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                        ;n++) {
        if (child==possible) return 
# 478 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                   1
# 478 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                       ;
        child=s->refs[child].parent;
    }
    return 
# 481 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          0
# 481 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
               ;
}
static uint32_t authoritative_root(const NvmAffineState *s,const NvmReferencePlace *place) {
    if(place->invocation==s->invocation && place->local<s->facts->count)
        return s->facts->locals[place->local].layout;
    for(uint16_t i=0;i<s->origin_count;i++)
        if(s->origins[i].invocation==place->invocation && s->origins[i].local==place->local)
            return s->origins[i].layout;
    return 0xFFFFFFFFu;
}
static 
# 491 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 491 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           borrow_install(NvmAffineState *s,uint32_t id,NvmReferencePlace place,uint32_t parent) {
    if (!s || !s->region || id>=s->ref_count || s->refs[id].live ||
        !nvm_reference_place_valid(&s->facts->layouts,authoritative_root(s,&place),&place) ||
        !resource(s->facts,(Slot){TAG_STRUCT,0,place.referent_layout})) return 
# 494 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                              0
# 494 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                   ;
    for (uint32_t i=0;i<s->ref_count;i++) if (s->refs[i].live &&
        !ancestor(s,i,parent) && nvm_reference_holds_conflict(&s->refs[i].place,&place)) return 
# 496 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                               0
# 496 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                    ;
    uint16_t *path=
# 497 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  ((void *)0)
# 497 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;
    if (place.field_count) {
        path=malloc(place.field_count*sizeof(*path)); if (!path) return 
# 499 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                       0
# 499 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                            ;
        memcpy(path,place.fields,place.field_count*sizeof(*path));
    }
    place.fields=path;
    s->refs[id]=(Reference){
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                           1
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                               ,s->region,parent,place}; return 
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                1
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                    ;
}

# 505 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 505 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_borrow(NvmAffineState *s,uint32_t id,uint16_t root,
                        const uint16_t *path,uint16_t count,NvmReferenceMode mode) {
    Slot slot;
    if (!value_local(s,root) || !s->live[root] || s->facts->locals[root].tag==TAG_ARRAY ||
        !resolve(s,root,path,count,&slot)) return 
# 509 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                 0
# 509 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                      ;
    return borrow_install(s,id,(NvmReferencePlace){s->invocation,root,s->facts->locals[root].layout,
        path,count,slot.layout,mode},
# 511 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                    (4294967295U)
# 511 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              );
}

# 513 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 513 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_reborrow(NvmAffineState *s,uint32_t id,uint32_t parent,NvmReferenceMode mode) {
    if (!s || parent>=s->ref_count || !s->refs[parent].live ||
        s->refs[parent].region>=s->region ||
        (mode==NVM_REFERENCE_EXCLUSIVE && s->refs[parent].place.mode!=NVM_REFERENCE_EXCLUSIVE)) return 
# 516 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                      0
# 516 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                           ;
    NvmReferencePlace place=s->refs[parent].place; place.mode=mode;
    return borrow_install(s,id,place,parent);
}

# 520 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 520 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_reference_access(const NvmAffineState *s,uint32_t id,uint16_t field,
# 520 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                   _Bool 
# 520 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                        write) {
    if (!s || id>=s->ref_count || !s->refs[id].live) return 
# 521 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                           0
# 521 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                ;
    const Reference *ref=&s->refs[id];
    const NvmV2Layout *layout=&s->facts->layouts.items[ref->place.referent_layout];
    if (field>=layout->field_count || !scalar(layout->fields[field].type_tag) ||
        (write && ref->place.mode!=NVM_REFERENCE_EXCLUSIVE)) return 
# 525 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                   0
# 525 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                        ;
    for (uint32_t i=0;i<s->ref_count;i++) if (i!=id && s->refs[i].live &&
        ancestor(s,id,i) && (write || s->refs[i].place.mode==NVM_REFERENCE_EXCLUSIVE)) return 
# 527 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                             0
# 527 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                  ;
    return 
# 528 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 528 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 530 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 530 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_reference_field(const NvmAffineState *s,uint32_t id,uint16_t field,
                                  
# 531 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                 _Bool 
# 531 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                      write,uint8_t *tag) {
    if (!tag || !nvm_affine_reference_access(s,id,field,write)) return 
# 532 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                      0
# 532 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                           ;
    *tag=s->facts->layouts.items[s->refs[id].place.referent_layout].fields[field].type_tag;
    return 
# 534 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 534 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 536 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 536 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_can_exit(const NvmAffineState *s,uint16_t result) {
    if (!s || s->region) return 
# 537 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                               0
# 537 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                    ;
    if (result==
# 538 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
               (65535)
# 538 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                         ) { if (s->facts->result.tag!=TAG_VOID) return 
# 538 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                        0
# 538 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             ; }
    else if (!value_local(s,result) || !s->live[result] ||
             !same(s->facts,s->facts->locals[result],s->facts->result)) return 
# 540 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                              0
# 540 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                   ;
    for (uint16_t i=0;i<s->facts->count;i++) if (i!=result && s->live[i] &&
        !s->facts->locals[i].mode && resource(s->facts,s->facts->locals[i])) return 
# 542 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                   0
# 542 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                        ;
    return 
# 543 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 543 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}


# 546 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 546 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_local_info(const NvmAffineState *s,uint16_t local,
                            uint8_t *tag,uint8_t *mode) {
    if (!s || local>=s->facts->count || !s->live[local] || !tag || !mode) return 
# 548 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                0
# 548 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                     ;
    Slot slot=s->facts->locals[local];
    if (s->caller_bound && slot.mode) return 
# 550 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                            0
# 550 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                 ;
    if (!slot.mode && slot.tag!=TAG_UNION &&
        !nvm_affine_owner_access(s,local,
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                        ((void *)0)
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                            ,0,
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               0
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    )) return 
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                              0
# 552 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                   ;
    *tag=slot.tag; *mode=slot.mode; return 
# 553 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          1
# 553 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ;
}

# 555 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 555 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_scalar_field(const NvmAffineState *s,uint16_t local,
                              uint16_t field,uint8_t *tag) {
    if (!s || local>=s->facts->count || !s->live[local] || !tag) return 
# 557 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                       0
# 557 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                            ;
    Slot root=s->facts->locals[local];
    if (root.tag!=TAG_STRUCT || root.layout>=s->facts->layouts.count) return 
# 559 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                            0
# 559 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
    const NvmV2Layout *layout=&s->facts->layouts.items[root.layout];
    if (field>=layout->field_count || !scalar(layout->fields[field].type_tag)) return 
# 561 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                     0
# 561 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                          ;
    
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        allowed=root.mode ? nvm_affine_reference_access(s,local,field,
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                      0
# 562 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                           )
        : nvm_affine_owner_access(s,local,&field,1,
# 563 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                  0
# 563 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                       );
    if (!allowed) return 
# 564 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                        0
# 564 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                             ;
    *tag=layout->fields[field].type_tag; return 
# 565 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               1
# 565 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                   ;
}

# 567 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 567 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_string_field(const NvmAffineState *s,uint16_t local,
                              uint16_t field,uint8_t *tag) {
    if (!s || local>=s->facts->count || !s->live[local] || !tag) return 
# 569 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                       0
# 569 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                            ;
    Slot root=s->facts->locals[local];
    if (root.mode || root.tag!=TAG_STRUCT || root.layout>=s->facts->layouts.count) return 
# 571 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                         0
# 571 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                              ;
    const NvmV2Layout *layout=&s->facts->layouts.items[root.layout];
    if (field>=layout->field_count || layout->fields[field].type_tag!=TAG_STRING ||
        layout->fields[field].nested_idx!=0xFFFFFFFFu ||
        !nvm_affine_owner_access(s,local,&field,1,
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                 0
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                      )) return 
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                0
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                     ;
    *tag=TAG_STRING;return 
# 576 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                          1
# 576 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                              ;
}

# 578 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 578 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_can_exit_scalar(const NvmAffineState *s,uint8_t tag) {
    if (!s || s->region || (tag!=TAG_VOID && !scalar(tag)) ||
        s->facts->result.tag!=tag) return 
# 580 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         0
# 580 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ;
    for (uint16_t i=0;i<s->facts->count;i++) if (s->live[i] &&
        !s->facts->locals[i].mode && resource(s->facts,s->facts->locals[i])) return 
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                   0
# 582 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                        ;
    return 
# 583 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 583 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}


# 586 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 586 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_local_type(const NvmAffineState *s,uint16_t local,NvmAffineType *type) {
    if (!s || local>=s->facts->count || !type) return 
# 587 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                     0
# 587 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                          ;
    Slot slot=s->facts->locals[local];
    if (slot.mode) return 
# 589 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                         0
# 589 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                              ;
    *type=(NvmAffineType){slot.tag,slot.layout}; return 
# 590 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       1
# 590 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ;
}

# 592 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 592 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_type_is_owned(const NvmAffineState *s,NvmAffineType type) {
    if (s && type.tag==TAG_ARRAY)
        return supported(s->facts,(Slot){type.tag,0,type.layout}) && resource(s->facts,(Slot){type.tag,0,type.layout});
    if (!s || type.layout>=s->facts->layouts.count ||
        !(s->facts->flags[type.layout]&1u)) return 
# 596 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                   0
# 596 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                        ;
    uint8_t kind=s->facts->layouts.items[type.layout].kind;
    return ((type.tag==TAG_STRUCT && kind==NVM_V2_LAYOUT_STRUCT) ||
            (type.tag==TAG_UNION && kind==NVM_V2_LAYOUT_UNION)) &&
         resource(s->facts,(Slot){type.tag,0,type.layout});
}

# 602 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 602 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_has_array_types(const NvmAffineState *s) { return s && s->facts->arrays; }

# 603 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 603 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_types_equal(const NvmAffineState *s,NvmAffineType a,NvmAffineType b) {
    return s && same(s->facts,(Slot){a.tag,0,a.layout},(Slot){b.tag,0,b.layout});
}

# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 606 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_array_define(NvmAffineState *s,uint16_t local,uint32_t element) {
    Slot type={TAG_ARRAY,0,element};
    if (!s || !supported(s->facts,type) || resource(s->facts,type) ||
        !destination(s,local) || !same(s->facts,s->facts->locals[local],type)) return 
# 609 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                     0
# 609 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                          ;
    s->live[local]=
# 610 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 610 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;return 
# 610 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                              1
# 610 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                  ;
}

# 612 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 612 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_array_element(const NvmAffineState *s,NvmAffineType type,NvmAffineType *out) {
    if (!s || !out || type.tag!=TAG_ARRAY || !s->facts->arrays || type.layout>=s->facts->arrays->count) return 
# 613 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                              0
# 613 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                                   ;
    NvmOwnershipEffectValue value=s->facts->arrays->items[type.layout];
    *out=(NvmAffineType){value.tag,value.layout};return 
# 615 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                       1
# 615 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ;
}

# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 617 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_array_type(const NvmAffineState *s,NvmAffineType element,NvmAffineType *out) {
    if (!s || !out || !s->facts->arrays) return 
# 618 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               0
# 618 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    ;
    for (uint32_t i=0;i<s->facts->arrays->count;i++) {
        NvmOwnershipEffectValue row=s->facts->arrays->items[i];
        if (same(s->facts,(Slot){row.tag,0,row.layout},(Slot){element.tag,0,element.layout})) {
            *out=(NvmAffineType){TAG_ARRAY,i};return 
# 622 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                    1
# 622 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                        ;
        }
    }
    return 
# 625 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          0
# 625 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
               ;
}

# 627 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 627 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_array_tag_type(const NvmAffineState *s,uint8_t tag,NvmAffineType *out) {
    if (!s || !out || !s->facts->arrays) return 
# 628 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               0
# 628 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    ;
    uint32_t selected=0xFFFFFFFFu;
    for (uint32_t i=0;i<s->facts->arrays->count;i++) {
        if (s->facts->arrays->items[i].tag!=tag) continue;
        if (selected!=0xFFFFFFFFu && !same(s->facts,(Slot){TAG_ARRAY,0,selected},(Slot){TAG_ARRAY,0,i})) return 
# 632 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                                   0
# 632 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                                        ;
        selected=i;
    }
    if (selected==0xFFFFFFFFu) return 
# 635 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                         0
# 635 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                              ;
    *out=(NvmAffineType){TAG_ARRAY,selected};return 
# 636 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                   1
# 636 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                       ;
}

# 638 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 638 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_record_is_copyable(const NvmAffineState *s,uint32_t layout) {
    return s && layout<s->facts->layouts.count &&
        s->facts->layouts.items[layout].kind==NVM_V2_LAYOUT_STRUCT &&
        (s->facts->flags[layout]&(1u|2u))==1u;
}

# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 643 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_record_define(NvmAffineState *s,uint16_t local,uint32_t layout) {
    if (!nvm_affine_record_is_copyable(s,layout) || !destination(s,local) ||
        s->facts->locals[local].tag!=TAG_STRUCT || s->facts->locals[local].layout!=layout) return 
# 645 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                 0
# 645 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                      ;
    s->live[local]=
# 646 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 646 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;return 
# 646 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                              1
# 646 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                  ;
}

# 648 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 648 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_owned_local_fields(const NvmAffineState *s,uint16_t local,
    NvmAffineType *fields,uint16_t capacity,uint16_t *count) {
    NvmAffineType type;uint16_t variant;
    if (!nvm_affine_local_type(s,local,&type) || !nvm_affine_type_is_owned(s,type)) return 
# 651 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                          0
# 651 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                               ;
    if (type.tag==TAG_UNION)
        return nvm_affine_union_variant(s,local,&variant) &&
            nvm_affine_union_fields(s,type.layout,variant,fields,capacity,count);
    return type.tag==TAG_STRUCT && nvm_affine_record_fields(s,type.layout,fields,capacity,count);
}

# 657 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 657 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_take_local(NvmAffineState *s,uint16_t local,NvmAffineType *type) {
    NvmAffineType found;
    if (!type || !nvm_affine_local_type(s,local,&found) || !nvm_affine_type_is_owned(s,found) ||
        found.layout==0xFFFFFFFFu || !nvm_affine_owner_access(s,local,
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                         ((void *)0)
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             ,0,
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                1
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                    )) return 
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                              0
# 660 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                   ;
    s->live[local]=
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  0
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                       ;s->variants[local]=
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                           (65535)
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                     ; *type=found; return 
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                           1
# 661 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                               ;
}

# 663 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 663 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_put_local(NvmAffineState *s,uint16_t local,NvmAffineType type) {
    NvmAffineType wanted;
    if (!nvm_affine_local_type(s,local,&wanted) || !nvm_affine_type_is_owned(s,type) ||
        type.layout==0xFFFFFFFFu || !same(s->facts,(Slot){wanted.tag,0,wanted.layout},(Slot){type.tag,0,type.layout}) ||
        !destination(s,local)) return 
# 667 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                     0
# 667 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
    s->live[local]=
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  1
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                      ;s->variants[local]=
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          (65535)
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                    ; return 
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                             1
# 668 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                 ;
}

# 670 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 670 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_record_fields(const NvmAffineState *s,uint32_t layout,
                               NvmAffineType *fields,uint16_t capacity,uint16_t *count) {
    if (!s || !count || layout>=s->facts->layouts.count ||
        !(s->facts->flags[layout]&1u)) return 
# 673 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                              0
# 673 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                   ;
    const NvmV2Layout *record=&s->facts->layouts.items[layout];
    if (record->kind!=NVM_V2_LAYOUT_STRUCT || record->field_count>capacity ||
        (record->field_count && !fields)) return 
# 676 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                0
# 676 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                     ;
    for (uint16_t i=0;i<record->field_count;i++)
        fields[i]=(NvmAffineType){record->fields[i].type_tag,record->fields[i].nested_idx};
    *count=record->field_count; return 
# 679 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                      1
# 679 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                          ;
}

# 681 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 681 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_union_fields(const NvmAffineState *s,uint32_t layout,
                              uint16_t variant,NvmAffineType *fields,
                              uint16_t capacity,uint16_t *count) {
    uint32_t ordinal;NvmUnionVariantFact fact;
    if (!s || !count || (capacity && !fields) ||
        !union_ordinal(s->facts,layout,&ordinal) ||
        nvm_ownership_union_variant(s->facts->module,ordinal,variant,&fact)!=NVM_V2_OK ||
        fact.layout!=layout || fact.field_count>capacity) return 
# 688 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                0
# 688 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                     ;
    const NvmV2Layout *shape=&s->facts->layouts.items[layout];
    for (uint16_t i=0;i<fact.field_count;i++) {
        const NvmV2LayoutField *field=&shape->fields[fact.field_offset+i];
        fields[i]=(NvmAffineType){field->type_tag,field->nested_idx};
    }
    *count=fact.field_count;return 
# 694 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                  1
# 694 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                      ;
}

# 696 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 696 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_can_exit_type(const NvmAffineState *s,NvmAffineType type) {
    if (!s || s->region || !same(s->facts,s->facts->result,(Slot){type.tag,0,type.layout})) return 
# 697 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                  0
# 697 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                       ;
    for (uint16_t i=0;i<s->facts->count;i++) if (s->live[i] &&
        !s->facts->locals[i].mode && resource(s->facts,s->facts->locals[i])) return 
# 699 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                   0
# 699 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                        ;
    return 
# 700 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 700 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}




# 705 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 705 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_bind_caller(NvmAffineState *callee,const NvmAffineState *caller,
                             uint32_t reference) {
    if (!callee || !caller || callee->caller_bound || caller->caller_bound ||
        callee->facts->module!=caller->facts->module ||
        caller->facts->function!=0 || callee->facts->function!=1 || callee->region)
        return 
# 710 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
              0
# 710 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                   ;
    uint16_t count=callee->facts->params;
    if(!count || count>8u || count>callee->ref_count ||
       reference>caller->ref_count || count>caller->ref_count-reference) return 
# 713 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                               0
# 713 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                    ;
    for(uint32_t i=count;i<callee->ref_count;i++) if(callee->refs[i].live) return 
# 714 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                 0
# 714 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                      ;
    for(uint16_t i=count;i<callee->facts->count;i++) if(callee->live[i]) return 
# 715 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                               0
# 715 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                    ;
    NvmReferencePlace places[8u];
    for(uint16_t p=0;p<count;p++) {
        uint32_t source=reference+p;Slot param=callee->facts->locals[p];
        if(!caller->refs[source].live) return 
# 719 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                             0
# 719 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                  ;
        NvmReferencePlace place=caller->refs[source].place;
        if(param.tag!=TAG_STRUCT || !param.mode || param.layout!=place.referent_layout ||
           (param.mode==NVM_REFERENCE_EXCLUSIVE && place.mode!=NVM_REFERENCE_EXCLUSIVE)) return 
# 722 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                               0
# 722 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                    ;
        place.mode=(NvmReferenceMode)param.mode;
        for(uint32_t i=0;i<caller->ref_count;i++) if(caller->refs[i].live &&
            !ancestor(caller,i,source) && nvm_reference_holds_conflict(&caller->refs[i].place,&place)) return 
# 725 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                                             0
# 725 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                                  ;
        if(place.invocation!=caller->invocation || place.local>=caller->facts->count ||
           !nvm_reference_place_valid(&caller->facts->layouts,
               caller->facts->locals[place.local].layout,&place)) return 
# 728 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                        0
# 728 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                             ;
        for(uint16_t i=0;i<p;i++) if(nvm_reference_holds_conflict(&places[i],&place)) return 
# 729 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                            0
# 729 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                                 ;
        places[p]=place;
    }
    uint16_t *paths[8u]={0};
    for(uint16_t p=0;p<count;p++) if(places[p].field_count) {
        paths[p]=malloc(places[p].field_count*sizeof(*paths[p]));
        if(!paths[p]) {
            for(uint16_t i=0;i<p;i++) free(paths[i]);
            return 
# 737 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  0
# 737 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                       ;
        }
        memcpy(paths[p],places[p].fields,places[p].field_count*sizeof(*paths[p]));
    }
    for(uint16_t p=0;p<count;p++) {
        free((void*)callee->refs[p].place.fields);places[p].fields=paths[p];
        callee->refs[p]=(Reference){
# 743 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                   1
# 743 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                       ,0,
# 743 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                          (4294967295U)
# 743 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    ,places[p]};
        callee->origins[p]=(CallerOrigin){places[p].invocation,places[p].local,
            caller->facts->locals[places[p].local].layout};
    }
    callee->origin_count=count;callee->caller_bound=
# 747 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                   1
# 747 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                       ;callee->invocation=2;
    return 
# 748 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 748 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 750 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 750 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_parameter_at(const NvmAffineState *s,uint16_t parameter,
                               NvmAffineType *type,NvmReferenceMode *mode) {
    if(!s || !type || !mode || !s->facts->params ||
       s->facts->params>8u || parameter>=s->facts->params ||
       parameter>=s->ref_count || !s->refs[parameter].live ||
       !s->facts->locals[parameter].mode) return 
# 755 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                0
# 755 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                     ;
    Slot param=s->facts->locals[parameter];
    NvmReferencePlace place={1,parameter,param.layout,
# 757 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                     ((void *)0)
# 757 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                         ,0,param.layout,(NvmReferenceMode)param.mode};
    if(!resource(s->facts,param) ||
       !nvm_reference_place_valid(&s->facts->layouts,param.layout,&place)) return 
# 759 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                 0
# 759 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                      ;
    *type=(NvmAffineType){param.tag,param.layout};*mode=(NvmReferenceMode)param.mode;
    return 
# 761 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 761 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}


static 
# 765 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
      _Bool 
# 765 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
           nested_result_tree(const Facts *facts,uint32_t root) {
    uint8_t *depth=calloc((size_t)root+1,sizeof(*depth));
    if (!depth) return 
# 767 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                      0
# 767 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                           ;
    depth[root]=1;
    
# 769 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 769 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        owned=(facts->flags[root]&2u)!=0;
    for (uint32_t next=root+1;next>0;) {
        uint32_t index=--next;
        if (!depth[index]) continue;
        const NvmV2Layout *layout=&facts->layouts.items[index];
        if (!(facts->flags[index]&1u) ||
            ((facts->flags[index]&2u)!=0)!=owned ||
            (layout->kind!=NVM_V2_LAYOUT_STRUCT && layout->kind!=NVM_V2_LAYOUT_UNION) ||
            layout->field_count>256u) goto refused;
        for (uint16_t f=0;f<layout->field_count;f++) {
            const NvmV2LayoutField *field=&layout->fields[f];
            if (field->type_tag==TAG_STRUCT || field->type_tag==TAG_UNION) {
                uint32_t child=field->nested_idx;
                if (child>=index || depth[index]>=32u)
                    goto refused;
                uint8_t child_depth=(uint8_t)(depth[index]+1);
                if (depth[child]<child_depth) depth[child]=child_depth;
            } else if ((field->type_tag!=TAG_INT && field->type_tag!=TAG_BOOL &&
                        field->type_tag!=TAG_U8 && field->type_tag!=TAG_STRING) || field->nested_idx!=0xFFFFFFFFu)
                goto refused;
        }
    }
    free(depth);return 
# 791 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                      1
# 791 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                          ;
refused:
    free(depth);return 
# 793 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                      0
# 793 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                           ;
}

# 795 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 795 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_value_result(const NvmAffineState *s,NvmAffineType *type,
                              uint16_t *field_count) {
    if (!s || !type || !field_count) return 
# 797 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                           0
# 797 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                ;
    Slot result=s->facts->result;
    const NvmFunctionEntry *fn=&s->facts->module->functions[s->facts->function];
    if (result.mode || fn->result_tag!=result.tag ||
        fn->result_count!=(result.tag==TAG_VOID?0:1)) return 
# 801 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                            0
# 801 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                 ;
    uint16_t fields=0;
    if (result.tag==TAG_STRUCT) {
        if (result.layout>=s->facts->layouts.count ||
            !(s->facts->flags[result.layout]&1u)) return 
# 805 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                         0
# 805 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                              ;
        const NvmV2Layout *layout=&s->facts->layouts.items[result.layout];
        if (layout->kind!=NVM_V2_LAYOUT_STRUCT) return 
# 807 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      0
# 807 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ;
        
# 808 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
       _Bool 
# 808 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
            nested=
# 808 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                   0
# 808 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                        ;
        for (uint16_t i=0;i<layout->field_count;i++) {
            const NvmV2LayoutField *field=&layout->fields[i];
            if (field->type_tag==TAG_STRUCT || field->type_tag==TAG_UNION) nested=
# 811 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                 1
# 811 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                     ;
            else if ((field->type_tag!=TAG_INT && field->type_tag!=TAG_BOOL && field->type_tag!=TAG_U8 && field->type_tag!=TAG_STRING) ||
                     field->nested_idx!=0xFFFFFFFFu) return 
# 813 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                               0
# 813 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                    ;
        }

        if (nested && !nested_result_tree(s->facts,result.layout)) return 
# 816 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                         0
# 816 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                              ;
        fields=layout->field_count;
    } else if (result.tag==TAG_UNION) {
        if (!union_value(s->facts,result)) return 
# 819 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                 0
# 819 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                      ;
    } else if (result.tag==TAG_ARRAY) {
        if (!supported(s->facts,result)) return 
# 821 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                               0
# 821 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                    ;
    } else if ((result.tag!=TAG_VOID && result.tag!=TAG_INT &&
                result.tag!=TAG_BOOL && result.tag!=TAG_U8) ||
               result.layout!=0xFFFFFFFFu) return 
# 824 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                     0
# 824 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                          ;
    *type=(NvmAffineType){result.tag,result.layout};*field_count=fields;
    return 
# 826 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 826 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}


# 829 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 829 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_value_parameters(const NvmAffineState *s,NvmAffineType *types,
                                  uint16_t capacity,uint16_t *count) {
    if (!s || !types || !count || s->facts->params>8u ||
        s->facts->params>capacity || s->facts->params>s->facts->count) return 
# 832 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                             0
# 832 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                  ;
    for (uint16_t p=0;p<s->facts->params;p++) {
        Slot parameter=s->facts->locals[p];
        if (parameter.mode) return 
# 835 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                  0
# 835 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                       ;
        if (parameter.tag==TAG_STRUCT) {
            if (parameter.layout>=s->facts->layouts.count ||
                s->facts->layouts.items[parameter.layout].kind!=NVM_V2_LAYOUT_STRUCT ||
                !(s->facts->flags[parameter.layout]&1u)) return 
# 839 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                0
# 839 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                     ;
        } else if (parameter.tag==TAG_STRING) {
            if (parameter.layout!=0xFFFFFFFFu) return 
# 841 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                         0
# 841 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                              ;
        } else if (parameter.tag==TAG_UNION) {
            if (!union_value(s->facts,parameter)) return 
# 843 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                        0
# 843 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                             ;
        } else if (parameter.tag==TAG_ARRAY) {
            if (!supported(s->facts,parameter)) return 
# 845 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                      0
# 845 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                           ;
        } else if (parameter.tag!=TAG_INT && parameter.tag!=TAG_BOOL && parameter.tag!=TAG_U8)
            return 
# 847 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                  0
# 847 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                       ;
    }
    for (uint16_t p=0;p<s->facts->params;p++)
        types[p]=(NvmAffineType){s->facts->locals[p].tag,s->facts->locals[p].layout};
    *count=s->facts->params;
    return 
# 852 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
          1
# 852 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
              ;
}

# 854 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 854 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_consuming_parameters(const NvmAffineState *s,NvmAffineType *types,
                                      uint16_t capacity,uint16_t *count) {
    NvmAffineType checked[8u];uint16_t length=0;
    if (!types || !count || !nvm_affine_value_parameters(s,checked,8u,&length) ||
        length>capacity) return 
# 858 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                               0
# 858 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                    ;
    
# 859 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
   _Bool 
# 859 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
        owned=
# 859 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
              0
# 859 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                   ;
    for (uint16_t p=0;p<length;p++) if (nvm_affine_type_is_owned(s,checked[p])) owned=
# 860 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                     1
# 860 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                         ;
    if (!owned) return 
# 861 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                      0
# 861 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                           ;
    memcpy(types,checked,length*sizeof(*types));*count=length;return 
# 862 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                    1
# 862 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                        ;
}

# 864 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 864 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_owned_parameter_type(const NvmAffineState *s,NvmAffineType *type) {
    if (!s || !type || s->facts->params!=1 || !s->facts->count ||
        s->facts->locals[0].tag!=TAG_STRUCT || s->facts->locals[0].mode || !resource(s->facts,s->facts->locals[0]) ||
        !(s->facts->flags[s->facts->locals[0].layout]&1u)) return 
# 867 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
                                                                                  0
# 867 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
                                                                                       ;
    *type=(NvmAffineType){s->facts->locals[0].tag,s->facts->locals[0].layout};
    return type->tag==TAG_STRUCT;
}

# 871 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 3 4
_Bool 
# 871 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c"
    nvm_affine_parameter_type(const NvmAffineState *s,NvmAffineType *type,
                                 NvmReferenceMode *mode) {
    return s && s->facts->params==1 && nvm_affine_parameter_at(s,0,type,mode);
}


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 1

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_layout_view.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_plan.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/managed_record_plan.h"
typedef enum {
    NVM_RECORD_DESCRIBED, NVM_RECORD_UNRESOLVED, NVM_RECORD_INVALID,
    NVM_RECORD_LIMIT, NVM_RECORD_MEMORY
} NvmRecordPlanStatus;
typedef enum { NVM_RECORD_AUTHORITY_UNKNOWN = 0, NVM_RECORD_AUTHORITY_ORDINARY = 1 } NvmRecordAuthority;
typedef struct {
    NvmRecordPlanStatus status;
    uint32_t layout, field;
    const char *message;
} NvmRecordPlanResult;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count;
    uint32_t *record_to_layout;
    uint32_t *layout_to_record;
    NvmRecordAuthority authority;
} NvmRecordPlan;






NvmRecordPlanResult nvm_describe_managed_records(const NvmModule *, NvmRecordPlan **);
void nvm_record_plan_free(NvmRecordPlan *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_layout_view.h" 2


typedef enum {
    NVM_MIXED_UNKNOWN, NVM_MIXED_RESOURCE,
    NVM_MIXED_ORDINARY_STRUCTURAL, NVM_MIXED_PENDING_ARRAY_PROOF
} NvmMixedLayoutClass;
typedef struct {
    NvmV2Layouts layouts;
    uint32_t record_count, managed_count;
    uint32_t source_to_global[256u];
    uint32_t global_to_source[256u];
    uint32_t managed_to_global[256u];
    uint32_t global_to_managed[256u];
    NvmMixedLayoutClass classes[256u];
    uint8_t *ownership;
    uint32_t ownership_size;
} NvmMixedLayoutView;

NvmRecordPlanResult nvm_describe_mixed_layouts(const NvmModule *, NvmMixedLayoutView **);
void nvm_mixed_layout_view_free(NvmMixedLayoutView *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 2




typedef enum {
    NVM_MIXED_SHAPE_PROVED, NVM_MIXED_SHAPE_UNRESOLVED,
    NVM_MIXED_SHAPE_INVALID, NVM_MIXED_SHAPE_LIMIT, NVM_MIXED_SHAPE_MEMORY
} NvmMixedShapeStatus;
typedef struct {
    NvmMixedShapeStatus status;
    uint32_t function, pc;
    const char *message;
} NvmMixedShapeResult;
typedef struct {
    uint16_t tags;
    uint64_t origins;
} NvmMixedFieldFact;
typedef struct {
    uint32_t function, pc, global_layout, source_record, field_start;
    uint16_t field_count;
    uint8_t tag;
} NvmMixedFloatOrigin;
typedef struct {
    uint32_t function, pc;
    uint16_t read_tags;
    uint16_t required_tags, actual_tags;
} NvmMixedScalarObligation;
typedef struct {
    NvmMixedLayoutView *view;
    uint32_t origin_count, field_count, obligation_count, checked_writes;
    
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_float_proof.h" 3 4
   _Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_float_proof.h"
        requires_affine_verification;
    NvmMixedFloatOrigin origins[64u];
    NvmMixedFieldFact *fields;
    NvmMixedScalarObligation obligations[4096u];
} NvmMixedFloatProof;


NvmMixedShapeResult nvm_analyze_mixed_float_origins(const NvmModule *, NvmMixedFloatProof **);
void nvm_mixed_float_proof_free(NvmMixedFloatProof *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h" 2

typedef enum { NVM_MIXED_CHECK_FLOAT, NVM_MIXED_COMPARE_VALUE } NvmMixedScalarPolicy;
typedef struct {
    uint32_t function, pc;
    uint16_t operand, actual_tags, required_tags;
    NvmMixedScalarPolicy policy;
} NvmMixedScalarCheck;
typedef struct {
    NvmMixedFloatProof *shape;
    uint32_t checked_functions, checked_instructions, visits, check_count;
    uint16_t max_stack[8];
    uint32_t managed_count;
    uint32_t global_to_managed[256u];
    uint32_t managed_to_global[256u];
    NvmMixedScalarCheck checks[(2u * 4096u)];
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h"
        affine_checked;
    
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h" 3 4
   _Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.h"
        runtime_admitted;
} NvmMixedSamplesProof;




NvmMixedShapeResult nvm_analyze_mixed_samples(const NvmModule *, NvmMixedSamplesProof **);
void nvm_mixed_samples_proof_free(NvmMixedSamplesProof *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 2






typedef struct {
    uint16_t tags, root;
    uint64_t origins;
    uint32_t nominal;
    uint8_t kind;
} MCValue;
typedef struct {
    NvmAffineState *owners;
    MCValue *values;
    uint16_t depth;
} MCFrame;
typedef struct {
    DecodedInstruction in;
    uint32_t function, pc, next, target;
    int16_t origin;
    MCFrame *frame;
    
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
   _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
        queued;
} MCInstruction;
typedef struct {
    uint32_t start, end;
    NvmAffineState *seed;
    uint8_t calls, color;
} MCFunction;
typedef struct {
    const NvmModule *module;
    NvmMixedSamplesProof *proof;
    MCFunction functions[8u];
    MCInstruction instructions[4096u];
    uint32_t count, cells, visits;
    uint32_t queue[4096u], head, tail, pending;
    NvmMixedShapeResult error;
} MCAnalysis;
static 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_stop(MCAnalysis *a,NvmMixedShapeStatus status,uint32_t f,uint32_t pc,const char *message) {
    a->error=(NvmMixedShapeResult){status,f,pc,message};return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                              0
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                   ;
}
static MCValue mc_tag(uint8_t tag) { MCValue v={0};v.tags=((uint16_t)(1u << (tag)));return v; }
static MCValue mc_owner(uint32_t layout) { MCValue v=mc_tag(TAG_STRUCT);v.kind=1;v.nominal=layout;return v; }
static 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_exact(MCValue v,uint8_t tag) { return !v.kind && !v.origins && v.tags==((uint16_t)(1u << (tag))); }
static 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_plain(MCValue v) {
    const uint16_t tags=(((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_VOID))))|((uint16_t)(1u << (TAG_INT)))|((uint16_t)(1u << (TAG_BOOL)))|((uint16_t)(1u << (TAG_U8)));
    return !v.kind && !v.origins && v.tags && !(v.tags&~tags);
}
static 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_owned_layout(const MCAnalysis *a,uint32_t layout) {
    const NvmMixedLayoutView *v=a->proof->shape->view;
    if(layout>=v->layouts.count || v->classes[layout]!=NVM_MIXED_RESOURCE)return 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                0
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                     ;
    const NvmV2Layout *l=&v->layouts.items[layout];
    if(l->kind!=NVM_V2_LAYOUT_STRUCT || l->field_count>256u)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                      0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                           ;
    for(uint16_t f=0;f<l->field_count;f++) {
        const NvmV2LayoutField *field=&l->fields[f];
        if((field->type_tag!=TAG_INT && field->type_tag!=TAG_BOOL && field->type_tag!=TAG_U8) ||
           field->nested_idx!=0xFFFFFFFFu)return 
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                    0
# 59 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                         ;
    }
    return 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 63 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_owned_local(const MCAnalysis *a,const NvmAffineState *s,uint16_t local) {
    return local<s->facts->count && !s->facts->locals[local].mode &&
        s->facts->locals[local].tag==TAG_STRUCT && mc_owned_layout(a,s->facts->locals[local].layout);
}
static 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_signature(const MCAnalysis *a,Slot slot,
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                      _Bool 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                           result) {
    if(slot.mode)return 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                       0
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                            ;
    if(slot.tag==TAG_STRUCT)return mc_owned_layout(a,slot.layout);
    return slot.layout==0xFFFFFFFFu && (slot.tag==TAG_INT || slot.tag==TAG_BOOL ||
        slot.tag==TAG_U8 || (result && slot.tag==TAG_VOID));
}


static NvmAffineState *mc_checked_state(MCAnalysis *a,uint32_t function) {
    const NvmMixedLayoutView *v=a->proof->shape->view;
    NvmAffineState *s=calloc(1,sizeof *s);
    if(!s)return 
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                ((void *)0)
# 78 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                    ;
    s->facts=calloc(1,sizeof *s->facts);
    if(!s->facts){free(s);return 
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                ((void *)0)
# 80 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                    ;}
    Facts *f=s->facts;f->users=1;f->module=a->module;f->function=function;s->invocation=1;
    if(nvm_v2_layouts_decode(a->module->layout_data,a->module->layout_size,&f->layouts)!=NVM_V2_OK)goto fail;
    f->flags=malloc(v->layouts.count?v->layouts.count:1);
    if(!f->flags)goto fail;
    memcpy(f->flags,v->ownership+8,v->layouts.count);
    NvmV2Cursor c;uint32_t ignored,count;const uint8_t *flags;
    nvm_v2_cursor_init(&c,v->ownership,v->ownership_size);
    if(nvm_v2_u32(&c,&ignored)!=NVM_V2_OK || nvm_v2_u32(&c,&count)!=NVM_V2_OK ||
       nvm_v2_take(&c,count,&flags)!=NVM_V2_OK || nvm_v2_align4(&c)!=NVM_V2_OK ||
       nvm_v2_u32(&c,&ignored)!=NVM_V2_OK)goto fail;
    for(uint32_t n=0;n<=function;n++) {
        uint16_t locals,params;Slot result;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK || !slot_read(&c,&result))goto fail;
        if(n==function) {
            f->count=locals;f->params=params;f->result=result;
            f->locals=calloc(locals?locals:1,sizeof *f->locals);
            s->live=calloc(locals?locals:1,sizeof *s->live);
            s->variants=malloc((locals?locals:1)*sizeof *s->variants);

            s->refs=calloc(1,sizeof *s->refs);
            if(!f->locals || !s->live || !s->variants || !s->refs)goto fail;
            for(uint16_t local=0;local<locals;local++)s->variants[local]=
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                        (65535)
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                  ;
        }
        for(uint16_t local=0;local<locals;local++) {
            Slot slot;if(!slot_read(&c,&slot))goto fail;
            if(n==function){f->locals[local]=slot;s->live[local]=local<params;}
        }
    }
    return s;
fail:nvm_affine_state_free(s);return 
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                    ((void *)0)
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                        ;
}
static 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_declarations(MCAnalysis *a,uint32_t f) {
    const NvmFunctionEntry *fn=&a->module->functions[f];
    NvmAffineState *s=mc_checked_state(a,f);
    if(!s)return mc_stop(a,NVM_MIXED_SHAPE_MEMORY,f,0,"I could not materialize checked mixed facts.");
    a->functions[f].seed=s;
    if(s->facts->count!=fn->local_count || s->facts->params!=fn->arity ||
       !mc_signature(a,s->facts->result,
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                       1
# 118 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                           ) || s->facts->result.tag!=fn->result_tag ||
       fn->result_count!=(s->facts->result.tag==TAG_VOID?0:1))
        return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require exact mixed value signatures.");
    for(uint16_t n=0;n<fn->local_count;n++) {
        Slot slot=s->facts->locals[n];
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                     _Bool 
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                          valid=
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                0
# 122 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                     ;
        if(n<fn->arity)valid=mc_signature(a,slot,
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                0
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                     );
        else if(!slot.mode) {
            if(slot.tag==TAG_STRUCT) {
                const NvmMixedLayoutView *v=a->proof->shape->view;
                valid=slot.layout<v->layouts.count && (mc_owned_layout(a,slot.layout) ||
                    v->classes[slot.layout]==NVM_MIXED_ORDINARY_STRUCTURAL ||
                    v->classes[slot.layout]==NVM_MIXED_PENDING_ARRAY_PROOF);
            } else valid=slot.layout==0xFFFFFFFFu && (scalar(slot.tag) || slot.tag==TAG_ARRAY);
        }
        if(!valid)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I keep unavailable mixed local categories explicit.");
    }
    return 
# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 134 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static void mc_frame_free(MCFrame *f) { if(f){nvm_affine_state_free(f->owners);free(f->values);free(f);} }
static MCFrame *mc_frame_clone(const MCFrame *f,uint16_t locals) {
    MCFrame *out=calloc(1,sizeof *out);if(!out)return 
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                     ((void *)0)
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                         ;
    out->owners=nvm_affine_state_clone(f->owners);
    out->values=calloc((uint32_t)locals+256u,sizeof *out->values);
    if(!out->owners || !out->values){mc_frame_free(out);return 
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                              ((void *)0)
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                  ;}
    out->depth=f->depth;memcpy(out->values,f->values,((uint32_t)locals+f->depth)*sizeof *out->values);
    return out;
}
static void mc_enqueue(MCAnalysis *a,uint32_t index) {
    MCInstruction *i=&a->instructions[index];if(i->queued)return;
    i->queued=
# 147 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
             1
# 147 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                 ;a->queue[a->tail]=index;a->tail=(a->tail+1)%4096u;a->pending++;
}
static 
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_join(MCAnalysis *a,uint32_t index,const MCFrame *from) {
    MCInstruction *i=&a->instructions[index];uint16_t locals=a->module->functions[i->function].local_count;
    
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
   _Bool 
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
        changed=
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                0
# 151 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                     ;
    if(!i->frame) {
        uint32_t cells=(uint32_t)locals+256u;
        if(cells>1048576u -a->cells)return mc_stop(a,NVM_MIXED_SHAPE_LIMIT,i->function,i->pc,"I reached my composed state budget.");
        i->frame=mc_frame_clone(from,locals);
        if(!i->frame)return mc_stop(a,NVM_MIXED_SHAPE_MEMORY,i->function,i->pc,"I could not allocate a composed edge.");
        a->cells+=cells;changed=
# 157 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                               1
# 157 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                   ;
    } else {
        MCFrame *to=i->frame;
        if(to->depth!=from->depth)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,i->function,i->pc,"I require equal composed stack heights.");

        for(uint32_t n=0;n<(uint32_t)locals+to->depth;n++) {
            MCValue x=to->values[n],y=from->values[n];
            if((x.kind || y.kind) && (x.kind!=y.kind || x.tags!=y.tags || x.nominal!=y.nominal || x.root!=y.root))
                return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,i->function,i->pc,"I require exact owner stack and observation joins.");
        }
        if(!nvm_affine_state_meet_initialization(to->owners,from->owners,&changed))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,i->function,i->pc,"I require exact owner state at composed joins.");
        for(uint32_t n=0;n<(uint32_t)locals+to->depth;n++) {
            MCValue *x=&to->values[n],y=from->values[n];uint16_t tags=x->tags;uint64_t origins=x->origins;
            x->tags|=y.tags;x->origins|=y.origins;changed|=tags!=x->tags || origins!=x->origins;
        }
    }
    if(changed)mc_enqueue(a,index);
    return 
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static int mc_scalar_op(uint8_t op,uint8_t *required) {
    *required=TAG_COUNT;
    switch(op) {
    case OP_PUSH_I64:return TAG_INT;case OP_PUSH_F64:return TAG_FLOAT;
    case OP_PUSH_U8:return TAG_U8;case OP_PUSH_BOOL:return TAG_BOOL;case OP_PUSH_VOID:return TAG_VOID;
    case OP_I64_ADD:case OP_I64_SUB:case OP_I64_MUL:case OP_I64_DIV_S:case OP_I64_REM_S:case OP_I64_NEG:*required=TAG_INT;return TAG_INT;
    case OP_I64_EQ:case OP_I64_NE:case OP_I64_LT_S:case OP_I64_LE_S:case OP_I64_GT_S:case OP_I64_GE_S:*required=TAG_INT;return TAG_BOOL;
    case OP_F64_ADD:case OP_F64_SUB:case OP_F64_MUL:case OP_F64_DIV:case OP_F64_NEG:*required=TAG_FLOAT;return TAG_FLOAT;
    case OP_F64_EQ:case OP_F64_NE:case OP_F64_LT:case OP_F64_LE:case OP_F64_GT:case OP_F64_GE:*required=TAG_FLOAT;return TAG_BOOL;
    case OP_BOOL_AND:case OP_BOOL_OR:case OP_BOOL_NOT:*required=TAG_BOOL;return TAG_BOOL;
    default:return -1;
    }
}
static 
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_supported(uint8_t op) {
    uint8_t required;if(mc_scalar_op(op,&required)>=0)return 
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                            1
# 191 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                ;
    switch(op) {
    case OP_NOP:case OP_DUP:case OP_POP:case OP_SWAP:case OP_ROT3:
    case OP_EQ:case OP_NE:case OP_LT:case OP_LE:case OP_GT:case OP_GE:
    case OP_LOAD_LOCAL:case OP_STORE_LOCAL:case OP_OWN_MOVE_LOCAL:case OP_OWN_STORE_LOCAL:
    case OP_OWN_PACK:case OP_OWN_UNPACK_LOCAL:case OP_AGG_PACK:case OP_AGG_GET:
    case OP_ARR_NEW:case OP_ARR_LITERAL:case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN:
    case OP_JMP:case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_CALL:case OP_RET:case OP_ASSERT:return 
# 198 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                 1
# 198 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                     ;
    default:return 
# 199 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                  0
# 199 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                       ;
    }
}
static 
# 202 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 202 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_graph(MCAnalysis *a,uint32_t f) {
    MCFunction *fn=&a->functions[f];if(fn->color==2)return 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                          1
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                              ;
    if(fn->color==1)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,0,"I require acyclic composed calls.");
    fn->color=1;for(uint32_t n=0;n<a->module->function_count;n++)if((fn->calls&(1u<<n)) && !mc_graph(a,n))return 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                0
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                     ;
    fn->color=2;return 
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                      1
# 206 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                          ;
}
static 
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_preflight(MCAnalysis *a) {
    const NvmModule *m=a->module;const NvmMixedLayoutView *view=a->proof->shape->view;
    for(uint32_t f=0;f<m->function_count;f++) {
        const NvmFunctionEntry *fn=&m->functions[f];MCFunction *af=&a->functions[f];af->start=a->count;
        if(!fn->code_length || fn->code_offset>m->code_size || fn->code_length>m->code_size-fn->code_offset ||
           fn->name_idx>=m->string_count || fn->result_tag>=TAG_COUNT || !mc_declarations(a,f))return 
# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                     0
# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                          ;
        for(uint32_t prior=0;prior<f;prior++) {
            const NvmFunctionEntry *other=&m->functions[prior];
            if(fn->code_offset<(uint64_t)other->code_offset+other->code_length && other->code_offset<(uint64_t)fn->code_offset+fn->code_length)
                return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,0,"I require distinct composed function ranges.");
        }
        for(uint32_t pc=0;pc<fn->code_length;) {
            if(a->count==4096u)return mc_stop(a,NVM_MIXED_SHAPE_LIMIT,f,pc,"I reached my composed instruction bound.");
            MCInstruction *i=&a->instructions[a->count++];i->function=f;i->pc=pc;i->origin=-1;i->target=
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                       (4294967295U)
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                 ;
            uint32_t width=isa_decode(m->code+fn->code_offset+pc,fn->code_length-pc,&i->in);
            if(!width)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require a complete composed instruction.");
            uint8_t op=i->in.opcode;
            if(!mc_supported(op))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require an explicit independent composed transfer.");
            if(op==OP_PUSH_BOOL && i->in.operands[0].u8>1)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require a Boolean literal.");
            if((op==OP_LOAD_LOCAL || op==OP_STORE_LOCAL || op==OP_OWN_MOVE_LOCAL || op==OP_OWN_STORE_LOCAL || op==OP_OWN_UNPACK_LOCAL) &&
               i->in.operands[0].u16>=fn->local_count)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require an existing composed local.");
            if(op==OP_CALL) {
                uint32_t target=i->in.operands[0].u32;
                if(!target || target>=m->function_count)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I require an existing nonentry callee.");
                af->calls|=(uint8_t)(1u<<target);
            }
            if(op==OP_OWN_PACK && !mc_owned_layout(a,i->in.operands[0].u32))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I refuse ordinary or unavailable owner construction.");
            if(op==OP_AGG_PACK || op==OP_ARR_NEW || op==OP_ARR_LITERAL) {
                for(uint32_t n=0;n<a->proof->shape->origin_count;n++) {
                    const NvmMixedFloatOrigin *o=&a->proof->shape->origins[n];
                    if(o->function==f && o->pc==pc)i->origin=(int16_t)n;
                }
                if(i->origin<0)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require this exact closed allocation origin.");
                if(op==OP_AGG_PACK) {
                    uint32_t source=i->in.operands[1].u32;
                    if(i->in.operands[0].u8 || i->in.operands[2].u16 || source>=view->record_count ||
                       view->source_to_global[source]!=a->proof->shape->origins[i->origin].global_layout ||
                       i->in.operands[3].u16!=a->proof->shape->origins[i->origin].field_count)
                        return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,pc,"I preserve constructor source and global identities.");
                } else if(i->in.operands[0].u8!=TAG_FLOAT)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,pc,"I require packed FLOAT array origins.");
            }
            pc+=width;i->next=a->count;
        }
        af->end=a->count;
    }
    for(uint32_t f=0;f<m->function_count;f++) {
        MCFunction *fn=&a->functions[f];
        for(uint32_t n=fn->start;n<fn->end;n++) {
            MCInstruction *i=&a->instructions[n];uint8_t op=i->in.opcode;
            if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
                int64_t target=(int64_t)i->pc+i->in.operands[0].i32;
                for(uint32_t j=fn->start;j<fn->end;j++)if(target==a->instructions[j].pc)i->target=j;
                if(i->target==
# 260 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                             (4294967295U)
# 260 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                       )return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require an explicit instruction-boundary branch.");
            }
            if(i->next==fn->end && op!=OP_RET && op!=OP_JMP)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require explicit composed termination.");
        }
        if(!mc_graph(a,f))return 
# 264 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                0
# 264 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                     ;
    }
    return 
# 266 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 266 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static 
# 268 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 268 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_array(const MCAnalysis *a,MCValue v) {
    if(v.kind || v.tags!=((uint16_t)(1u << (TAG_ARRAY))) || !v.origins)return 
# 269 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                               0
# 269 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                    ;
    for(uint32_t n=0;n<a->proof->shape->origin_count;n++)if((v.origins&(1UL<<n)) && a->proof->shape->origins[n].tag!=TAG_ARRAY)return 
# 270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                                             0
# 270 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                                                  ;
    return 
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static 
# 273 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 273 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_field(const MCAnalysis *a,MCValue v,uint8_t tag,uint32_t layout) {
    if(v.kind || v.tags!=((uint16_t)(1u << (tag))))return 
# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                           0
# 274 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                ;
    if(tag==TAG_ARRAY)return layout==0xFFFFFFFFu && mc_array(a,v);
    if(tag!=TAG_STRUCT)return layout==0xFFFFFFFFu && mc_plain(v);
    if(!v.origins)return 
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                        0
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                             ;
    for(uint32_t n=0;n<a->proof->shape->origin_count;n++)if(v.origins&(1UL<<n)) {
        const NvmMixedFloatOrigin *o=&a->proof->shape->origins[n];
        if(o->tag!=TAG_STRUCT || o->global_layout!=layout)return 
# 280 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                0
# 280 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                     ;
    }
    return 
# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          1
# 282 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
              ;
}
static 
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_type(const MCAnalysis *a,MCValue v,Slot type) {
    if(type.mode)return 
# 285 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                       0
# 285 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                            ;
    if(type.tag==TAG_STRUCT)return mc_owned_layout(a,type.layout) && v.kind==1 &&
        v.tags==((uint16_t)(1u << (TAG_STRUCT))) && !v.origins && v.nominal==type.layout;
    return mc_exact(v,type.tag) && type.layout==0xFFFFFFFFu;
}
static 
# 290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 290 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_observed(const MCFrame *f,uint16_t locals,uint16_t root) {
    for(uint16_t n=0;n<f->depth;n++)if(f->values[locals+n].kind==2 && f->values[locals+n].root==root)return 
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                           1
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                               ;
    return 
# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
          0
# 292 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
               ;
}
static 
# 294 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 294 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_check(MCAnalysis *a,const MCInstruction *i,uint16_t operand,uint16_t actual,uint16_t required,NvmMixedScalarPolicy policy) {
    for(uint32_t n=0;n<a->proof->check_count;n++) {
        NvmMixedScalarCheck *c=&a->proof->checks[n];
        if(c->function==i->function && c->pc==i->pc && c->operand==operand && c->policy==policy) {
            c->actual_tags|=actual;return c->required_tags==required;
        }
    }
    if(a->proof->check_count==(2u * 4096u))return mc_stop(a,NVM_MIXED_SHAPE_LIMIT,i->function,i->pc,"I reached my scalar obligation budget.");
    a->proof->checks[a->proof->check_count++]=(NvmMixedScalarCheck){i->function,i->pc,operand,actual,required,policy};return 
# 302 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                            1
# 302 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                                ;
}
static 
# 304 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
      _Bool 
# 304 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
           mc_transfer(MCAnalysis *a,uint32_t index,MCFrame *frame) {
    MCInstruction *i=&a->instructions[index];uint32_t f=i->function;
    uint16_t locals=a->module->functions[f].local_count;
    NvmAffineState *owners=frame->owners;MCValue *stack=frame->values+locals;
    DecodedInstruction *in=&i->in;uint8_t op=in->opcode;
    const InstructionInfo *info=isa_get_info(op);
    int pops=info->pop_count,pushes=info->push_count;
    NvmAffineType fields[256u];uint16_t fields_count=0,local=in->operands[0].u16;
    if(op==OP_ARR_LITERAL){pops=in->operands[1].u16;pushes=1;}
    if(op==OP_AGG_PACK){pops=in->operands[3].u16;pushes=1;}
    if(op==OP_OWN_PACK || op==OP_OWN_UNPACK_LOCAL) {
        uint32_t layout=op==OP_OWN_PACK?in->operands[0].u32:owners->facts->locals[local].layout;
        if(!mc_owned_layout(a,layout) || !nvm_affine_record_fields(owners,layout,fields,256u,&fields_count))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require RESOURCE authority before owner field transfer.");
        pops=op==OP_OWN_PACK?fields_count:0;pushes=op==OP_OWN_PACK?1:fields_count;
    }
    if(op==OP_CALL) {
        const NvmFunctionEntry *callee=&a->module->functions[in->operands[0].u32];pops=callee->arity;pushes=callee->result_count;
    }
    if(op==OP_RET) {
        Slot result=owners->facts->result;
        if(frame->depth!=a->module->functions[f].result_count ||
           (frame->depth && !mc_type(a,stack[0],result)) ||
           !nvm_affine_can_exit_type(owners,(NvmAffineType){result.tag,result.layout}))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an exact return and complete independent owner consumption.");
        return 
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
              1
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                  ;
    }
    if(pops<0 || pushes<0 || frame->depth<pops)return mc_stop(a,NVM_MIXED_SHAPE_INVALID,f,i->pc,"I require a complete independent operand stack.");
    if((uint32_t)(frame->depth-pops+pushes)>256u)return mc_stop(a,NVM_MIXED_SHAPE_LIMIT,f,i->pc,"I reached my independent operand stack budget.");
    uint16_t base=(uint16_t)(frame->depth-pops);MCValue result={0};uint8_t required;
    int produced=mc_scalar_op(op,&required);
    if(produced>=0) {
        for(uint16_t n=base;n<frame->depth;n++) {
            if(required==TAG_COUNT || !mc_plain(stack[n]))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I refuse heap or owner scalar operands.");
            if(!mc_exact(stack[n],required)) {
                if(required!=TAG_FLOAT || stack[n].tags!=(((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_VOID)))))
                    return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact scalar inputs or an explicit FLOAT-or-VOID check.");
                if(!mc_check(a,i,(uint16_t)(n-base),stack[n].tags,((uint16_t)(1u << (TAG_FLOAT))),NVM_MIXED_CHECK_FLOAT))return 
# 341 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                 0
# 341 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                      ;
            }
        }
        result=mc_tag((uint8_t)produced);
    } else switch(op) {
    case OP_NOP:case OP_JMP:break;
    case OP_EQ:case OP_NE:case OP_LT:case OP_LE:case OP_GT:case OP_GE: {
        MCValue x=stack[base],y=stack[base+1];
# 348 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                             _Bool 
# 348 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                  exact=mc_plain(x) && mc_plain(y) && x.tags==y.tags && !(x.tags&(x.tags-1));
        
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
       _Bool 
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
            optional=(op==OP_EQ || op==OP_NE) && mc_plain(x) && mc_plain(y) && !(x.tags&~(((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_VOID))))) && !(y.tags&~(((uint16_t)(1u << (TAG_FLOAT)))|((uint16_t)(1u << (TAG_VOID)))));
        if(!exact && !optional)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require supported scalar value comparisons, never owner or ordinary heap equality.");
        if(op!=OP_EQ && op!=OP_NE && (x.tags&((uint16_t)(1u << (TAG_VOID)))))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I keep VOID ordering outside my first composition.");
        if(!mc_check(a,i,0,x.tags,0,NVM_MIXED_COMPARE_VALUE) || !mc_check(a,i,1,y.tags,0,NVM_MIXED_COMPARE_VALUE))return 
# 352 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                        0
# 352 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                             ;
        result=mc_tag(TAG_BOOL);break;
    }
    case OP_DUP:
        if(stack[frame->depth-1].kind)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I cannot duplicate an owner or observation.");
        stack[frame->depth]=stack[frame->depth-1];frame->depth++;goto successors;
    case OP_POP:
        if(stack[base].kind)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require explicit owner consumption rather than POP.");
        break;
    case OP_SWAP:
        result=stack[frame->depth-1];stack[frame->depth-1]=stack[frame->depth-2];stack[frame->depth-2]=result;goto successors;
    case OP_ROT3:
        result=stack[frame->depth-1];stack[frame->depth-1]=stack[frame->depth-2];stack[frame->depth-2]=stack[frame->depth-3];stack[frame->depth-3]=result;goto successors;
    case OP_LOAD_LOCAL: {
        Slot slot=owners->facts->locals[local];
        if(mc_owned_local(a,owners,local)) {
            uint8_t tag,mode;
            if(!nvm_affine_local_info(owners,local,&tag,&mode) || tag!=TAG_STRUCT || mode)
                return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require a live exact owner observation.");
            result=mc_owner(slot.layout);result.kind=2;result.root=local;
        } else {
            result=frame->values[local];
            if(!mc_field(a,result,slot.tag,slot.layout))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require initialized exact ordinary local alternatives.");
        }
        break;
    }
    case OP_STORE_LOCAL: {
        Slot slot=owners->facts->locals[local];
        if(mc_owned_local(a,owners,local) || !mc_field(a,stack[base],slot.tag,slot.layout))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I refuse owner or mismatched ordinary local stores.");
        if(scalar(slot.tag) && !nvm_affine_scalar_define(owners,local))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require a checked scalar destination.");

        frame->values[local]=stack[base];break;
    }
    case OP_OWN_MOVE_LOCAL:case OP_OWN_UNPACK_LOCAL: {
        NvmAffineType type;
        if(!mc_owned_local(a,owners,local) || mc_observed(frame,locals,local) || !nvm_affine_take_local(owners,local,&type))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require a live unobserved RESOURCE for move or unpack.");
        if(op==OP_OWN_MOVE_LOCAL)result=mc_owner(type.layout);
        else {
            for(uint16_t n=0;n<fields_count;n++)stack[frame->depth++]=mc_tag(fields[n].tag);
            goto successors;
        }
        break;
    }
    case OP_OWN_STORE_LOCAL:
        if(!mc_owned_local(a,owners,local) || !mc_type(a,stack[base],owners->facts->locals[local]) ||
           !nvm_affine_put_local(owners,local,(NvmAffineType){TAG_STRUCT,stack[base].nominal}))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an available exact RESOURCE destination.");
        break;
    case OP_OWN_PACK:
        for(uint16_t n=0;n<fields_count;n++)if(!mc_exact(stack[base+n],fields[n].tag))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact scalar fields before producing an owner token.");
        result=mc_owner(in->operands[0].u32);break;
    case OP_AGG_PACK: {
        const NvmMixedFloatOrigin *o=&a->proof->shape->origins[i->origin];
        const NvmV2Layout *layout=&a->proof->shape->view->layouts.items[o->global_layout];
        if(mc_owned_layout(a,o->global_layout))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I never construct an owner through ordinary packing.");
        for(uint16_t n=0;n<o->field_count;n++) {
            const NvmMixedFieldFact *fact=&a->proof->shape->fields[o->field_start+n];
            const NvmV2LayoutField *field=&layout->fields[n];MCValue value=stack[base+n];
            if(!mc_field(a,value,field->type_tag,field->nested_idx) || (value.tags&~fact->tags) || (value.origins&~fact->origins))
                return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require every independent ordinary field alternative in the closed proof.");
        }
        result=mc_tag(TAG_STRUCT);result.origins=1UL<<i->origin;break;
    }
    case OP_AGG_GET: {
        MCValue receiver=stack[base];
        if(receiver.kind) {
            uint8_t tag;
            if(receiver.kind!=2 || !mc_owned_local(a,owners,receiver.root) ||
               owners->facts->locals[receiver.root].layout!=receiver.nominal ||
               !nvm_affine_scalar_field(owners,receiver.root,local,&tag))
                return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an intact independent owner observation.");
            result=mc_tag(tag);
        } else {
            if(receiver.tags!=((uint16_t)(1u << (TAG_STRUCT))) || !receiver.origins)return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact ordinary receiver alternatives.");
            for(uint32_t n=0;n<a->proof->shape->origin_count;n++)if(receiver.origins&(1UL<<n)) {
                const NvmMixedFloatOrigin *o=&a->proof->shape->origins[n];
                if(o->tag!=TAG_STRUCT || local>=o->field_count || mc_owned_layout(a,o->global_layout))
                    return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require a proved field on every ordinary receiver.");
                const NvmMixedFieldFact *fact=&a->proof->shape->fields[o->field_start+local];
                result.tags|=fact->tags;result.origins|=fact->origins;
            }
        }
        break;
    }
    case OP_ARR_NEW:case OP_ARR_LITERAL:
        for(uint16_t n=base;n<frame->depth;n++)if(!mc_exact(stack[n],TAG_FLOAT))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact FLOAT elements for array construction.");
        result=mc_tag(TAG_ARRAY);result.origins=1UL<<i->origin;break;
    case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN:
        if(!mc_array(a,stack[base]))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require closed FLOAT-array receiver alternatives.");
        if((op==OP_ARR_SET || op==OP_ARR_GET) && !mc_exact(stack[base+1],TAG_INT))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact integer array indices.");
        if((op==OP_ARR_PUSH || op==OP_ARR_SET) && !mc_exact(stack[frame->depth-1],TAG_FLOAT))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact FLOAT alias writes.");
        if(op==OP_ARR_GET){result=mc_tag(TAG_FLOAT);result.tags|=((uint16_t)(1u << (TAG_VOID)));}
        else if(op==OP_ARR_LEN)result=mc_tag(TAG_INT);else result=stack[base];
        break;
    case OP_CALL: {
        const NvmAffineState *callee=a->functions[in->operands[0].u32].seed;
        for(uint16_t n=0;n<callee->facts->params;n++)if(!mc_type(a,stack[base+n],callee->facts->locals[n]))
            return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require exact positional call values before owner transfer.");
        Slot returned=callee->facts->result;result=returned.tag==TAG_STRUCT?mc_owner(returned.layout):mc_tag(returned.tag);break;
    }
    case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_ASSERT:
        if(!mc_exact(stack[base],TAG_BOOL))return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an exact Boolean control operand.");
        break;
    default:return mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,f,i->pc,"I require an independent transfer for every mixed instruction.");
    }
    frame->depth=(uint16_t)(base+pushes);if(pushes)stack[base]=result;
successors:
    if(frame->depth>a->proof->max_stack[f])a->proof->max_stack[f]=frame->depth;
    if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
        if(!mc_join(a,i->target,frame))return 
# 464 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                             0
# 464 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                  ;
        if(op==OP_JMP)return 
# 465 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                            1
# 465 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                ;
    }
    return mc_join(a,i->next,frame);
}
void nvm_mixed_samples_proof_free(NvmMixedSamplesProof *proof) {
    if(proof){nvm_mixed_float_proof_free(proof->shape);free(proof);}
}
NvmMixedShapeResult nvm_analyze_mixed_samples(const NvmModule *module,NvmMixedSamplesProof **out) {
    NvmMixedShapeResult error={NVM_MIXED_SHAPE_INVALID,0,0,"I require an immutable module and output for private composition."};
    if(!out)return error;
    NvmMixedFloatProof *shape=
# 475 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                             ((void *)0)
# 475 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                 ;error=nvm_analyze_mixed_float_origins(module,&shape);
    if(error.status!=NVM_MIXED_SHAPE_PROVED)return error;
    MCAnalysis *a=calloc(1,sizeof *a);NvmMixedSamplesProof *proof=calloc(1,sizeof *proof);
    if(!a || !proof){free(a);free(proof);nvm_mixed_float_proof_free(shape);return (NvmMixedShapeResult){NVM_MIXED_SHAPE_MEMORY,0,0,"I could not allocate private composition."};}
    a->module=module;a->proof=proof;proof->shape=shape;
    a->error=(NvmMixedShapeResult){NVM_MIXED_SHAPE_INVALID,0,0,"I require complete independent mixed structure."};
    for(uint32_t n=0;n<256u;n++)proof->global_to_managed[n]=proof->managed_to_global[n]=0xFFFFFFFFu;
    if(!mc_preflight(a))goto done;
    for(uint32_t f=0;f<module->function_count;f++) {
        uint16_t locals=module->functions[f].local_count;MCValue values[256u*2]={0};
        MCFrame seed={a->functions[f].seed,values,0};
        for(uint16_t n=0;n<locals;n++)values[n]=mc_tag(TAG_VOID);
        for(uint16_t n=0;n<module->functions[f].arity;n++)if(!mc_owned_local(a,seed.owners,n))values[n]=mc_tag(seed.owners->facts->locals[n].tag);
        if(!mc_join(a,a->functions[f].start,&seed))goto done;
    }
    while(a->pending) {
        if(a->visits++==262144u){mc_stop(a,NVM_MIXED_SHAPE_LIMIT,0,0,"I reached my composed worklist bound.");goto done;}
        uint32_t index=a->queue[a->head];a->head=(a->head+1)%4096u;a->pending--;
        MCInstruction *i=&a->instructions[index];i->queued=
# 493 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                          0
# 493 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                               ;
        MCFrame *frame=mc_frame_clone(i->frame,module->functions[i->function].local_count);
        if(!frame){mc_stop(a,NVM_MIXED_SHAPE_MEMORY,i->function,i->pc,"I could not copy composed transfer state.");goto done;}
        
# 496 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
       _Bool 
# 496 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
            ok=mc_transfer(a,index,frame);mc_frame_free(frame);if(!ok)goto done;
    }
    for(uint32_t n=0;n<a->count;n++)if(!a->instructions[n].frame){mc_stop(a,NVM_MIXED_SHAPE_UNRESOLVED,a->instructions[n].function,a->instructions[n].pc,"I require checked state for every declared mixed instruction.");goto done;}

    for(uint32_t global=0;global<shape->view->layouts.count;global++) {
        
# 501 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
       _Bool 
# 501 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
            included=shape->view->classes[global]==NVM_MIXED_ORDINARY_STRUCTURAL;
        if(shape->view->classes[global]==NVM_MIXED_PENDING_ARRAY_PROOF)
            for(uint32_t n=0;n<shape->origin_count;n++)if(shape->origins[n].tag==TAG_STRUCT && shape->origins[n].global_layout==global)included=
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                                               1
# 503 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                                                   ;
        if(included){proof->global_to_managed[global]=proof->managed_count;proof->managed_to_global[proof->managed_count++]=global;}
    }
    proof->checked_functions=module->function_count;proof->checked_instructions=a->count;proof->visits=a->visits;proof->affine_checked=
# 506 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc" 3 4
                                                                                                                                      1
# 506 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/mixed_samples.inc"
                                                                                                                                          ;
    a->error=(NvmMixedShapeResult){NVM_MIXED_SHAPE_PROVED,0,0,"I checked private mixed composition; runtime obligations and admission remain separate."};
done:
    for(uint32_t n=0;n<a->count;n++)mc_frame_free(a->instructions[n].frame);
    for(uint32_t f=0;f<module->function_count;f++)nvm_affine_state_free(a->functions[f].seed);
    error=a->error;free(a);
    if(error.status==NVM_MIXED_SHAPE_PROVED)*out=proof;else nvm_mixed_samples_proof_free(proof);
    return error;
}
# 878 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 1

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority_internal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
typedef struct NvmOwnedArrayLayouts NvmOwnedArrayLayouts;
typedef struct {
    uint32_t layouts, source_records, managed_records, leaf_paths;
} NvmOwnedArrayLayoutCounts;
typedef struct {
    uint32_t global_layout, source_record, managed_record, field_count;
    uint32_t path_start, path_count;
    uint8_t flags, owner_depth;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
        has_array, has_string, whole_root_borrow_unsuitable;
} NvmOwnedArrayLayoutFact;
typedef struct {
    uint32_t root_layout, terminal_layout;
    uint16_t length;
    uint8_t tag;
    uint16_t fields[32u];
} NvmOwnedArrayLeafPath;
typedef struct {
    const uint8_t *layouts, *ownership;
    uint32_t layout_size, ownership_size;
} NvmOwnedArrayTransport;



NvmRecordPlanResult nvm_describe_owned_array_layouts(const NvmModule *, NvmOwnedArrayLayouts **out);
void nvm_owned_array_layouts_free(NvmOwnedArrayLayouts *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_counts(const NvmOwnedArrayLayouts *, NvmOwnedArrayLayoutCounts *out);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_fact(const NvmOwnedArrayLayouts *, uint32_t global, NvmOwnedArrayLayoutFact *out);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_source_layout(const NvmOwnedArrayLayouts *, uint32_t source, uint32_t *out_global);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_managed_layout(const NvmOwnedArrayLayouts *, uint32_t managed, uint32_t *out_global);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_leaf_path(const NvmOwnedArrayLayouts *, uint32_t path, NvmOwnedArrayLeafPath *out);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_layout_field(const NvmOwnedArrayLayouts *, uint32_t global, uint16_t field, NvmV2LayoutField *out);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_layouts.h"
    nvm_owned_array_transport(const NvmOwnedArrayLayouts *, NvmOwnedArrayTransport *out);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 2



typedef struct NvmOwnedArrayOrigins NvmOwnedArrayOrigins;
typedef enum { NVM_OWNER_ORIGIN_PROVED, NVM_OWNER_ORIGIN_UNRESOLVED,
    NVM_OWNER_ORIGIN_INVALID, NVM_OWNER_ORIGIN_LIMIT, NVM_OWNER_ORIGIN_MEMORY
} NvmOwnerOriginStatus;
typedef struct { NvmOwnerOriginStatus status; uint32_t function, pc; const char *message; } NvmOwnerOriginResult;
typedef struct { uint64_t words[5u]; } NvmOwnerOriginSet;
typedef struct { uint32_t function, pc; uint8_t opcode; } NvmOwnerOriginSite;
typedef struct { uint16_t ordinal; NvmOwnedArrayLeafPath path; NvmOwnerOriginSet origins; } NvmOwnerOriginPath;
typedef struct {
    uint32_t formal_count, result_count;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
        reachable, conditional;
    NvmOwnerOriginSet required;
} NvmOwnerOriginSummary;
typedef struct { uint32_t functions, sites, obligations; } NvmOwnerOriginCounts;
typedef struct {
    uint32_t function, pc;
    uint16_t actual_tags, required_tags, read_tags;

    uint16_t operand_actual[2], operand_required[2];
    uint8_t opcode, operand_count, runtime_checks;
} NvmOwnerOriginObligation;


NvmOwnerOriginResult nvm_analyze_owned_array_origins(const NvmModule *, NvmOwnedArrayOrigins **);
void nvm_owned_array_origins_free(NvmOwnedArrayOrigins *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_counts(const NvmOwnedArrayOrigins *, NvmOwnerOriginCounts *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_site(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSite *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_summary(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginSummary *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_input(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_result(const NvmOwnedArrayOrigins *, uint32_t, uint32_t, NvmOwnerOriginPath *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_origins.h"
    nvm_owned_array_origin_obligation(const NvmOwnedArrayOrigins *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 2

typedef struct NvmOwnedArrayPlan NvmOwnedArrayPlan;
typedef enum { NVM_OWNER_AUTH_PREPARED, NVM_OWNER_AUTH_UNRESOLVED,
    NVM_OWNER_AUTH_INVALID, NVM_OWNER_AUTH_LIMIT, NVM_OWNER_AUTH_MEMORY
} NvmOwnerAuthorityStatus;
typedef struct { NvmOwnerAuthorityStatus status; uint32_t function, pc; const char *message; } NvmOwnerAuthorityResult;
typedef struct { uint8_t tag, mode; uint32_t global_layout; 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
                                                           _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
                                                                owner; } NvmOwnerDeclaration;
typedef struct {
    uint16_t local_count, parameter_count, max_stack, result_fields;
    NvmOwnerDeclaration result, parameters[8];
} NvmOwnerSignature;
typedef struct { uint32_t functions, instructions, persisted_cells, visits, work; } NvmOwnerAuthorityCounts;


NvmOwnerAuthorityResult nvm_prepare_owned_array_authority(const NvmModule *, NvmOwnedArrayPlan **);
void nvm_owned_array_plan_free(NvmOwnedArrayPlan *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_counts(const NvmOwnedArrayPlan *, NvmOwnerAuthorityCounts *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_signature(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerSignature *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_local(const NvmOwnedArrayPlan *, uint32_t, uint16_t, NvmOwnerDeclaration *);

# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_layout(const NvmOwnedArrayPlan *, uint32_t, NvmOwnedArrayLayoutFact *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_source(const NvmOwnedArrayPlan *, uint32_t, uint32_t *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_transport(const NvmOwnedArrayPlan *, NvmOwnedArrayTransport *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.h"
    nvm_owned_array_plan_obligation(const NvmOwnedArrayPlan *, uint32_t, NvmOwnerOriginObligation *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority_internal.h" 2


typedef struct {
    NvmOwnedArrayOrigins *origins;
    NvmOwnedArrayLayouts *layouts;
    NvmOwnerAuthorityCounts counts;
    NvmOwnerSignature signatures[8];
    NvmOwnerDeclaration locals[8][256];
    NvmOwnerOriginObligation obligations[4096];
} NvmOwnerLifetimeFacts;
NvmOwnerAuthorityResult nvm_analyze_owned_array_lifetimes(const NvmModule *, NvmOwnerLifetimeFacts **);
void nvm_owned_array_lifetime_facts_free(NvmOwnerLifetimeFacts *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 2
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
typedef struct { uint16_t tags, root; uint32_t layout; uint8_t kind, unknown; } LAValue;
typedef struct { NvmAffineState *owners; LAValue *values; uint16_t depth; } LAFrame;
typedef struct {
    DecodedInstruction in;
    uint32_t function, pc, next, target;
    LAFrame *frame;
    uint16_t operand_actual[2], operand_required[2];
    uint8_t operand_count, runtime_checks;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
        queued;
} LAInstruction;
typedef struct { uint32_t start, end; NvmAffineState *seed; } LAFunction;
typedef struct {
    const NvmModule *module;
    NvmOwnerLifetimeFacts *proof;
    LAFunction functions[8u];
    LAInstruction instructions[4096u];
    uint32_t count,cells,visits,work;
    uint32_t queue[4096u],head,tail,pending;
    NvmOwnerAuthorityResult error;
} LAAnalysis;
static 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_stop(LAAnalysis *a,NvmOwnerAuthorityStatus s,uint32_t f,uint32_t pc,const char *message) {
    a->error=(NvmOwnerAuthorityResult){s,f,pc,message};return 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                             0
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                  ;
}
static 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_work(LAAnalysis *a,uint32_t amount) {
    if(amount>4194304u -a->work)return la_stop(a,NVM_OWNER_AUTH_LIMIT,0,0,"I reached my independent owner work budget.");
    a->work+=amount;return 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                          1
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                              ;
}
static LAValue la_tag(uint8_t tag) {LAValue v={0};v.tags=((uint16_t)(1u<<(tag)));v.layout=0xFFFFFFFFu;return v;}
static LAValue la_owner(uint32_t layout) {LAValue v=la_tag(TAG_STRUCT);v.kind=1;v.layout=layout;return v;}
static 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_exact(LAValue v,uint8_t tag) {return !v.kind && !v.unknown && v.tags==((uint16_t)(1u<<(tag)));}
static 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_owner_layout(const Facts *facts,uint32_t layout) {
    return layout<facts->layouts.count &&
        (facts->flags[layout]&(1u|2u))==(1u|2u) &&
        facts->layouts.items[layout].kind==NVM_V2_LAYOUT_STRUCT;
}
static 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_type(const Facts *facts,LAValue v,Slot type) {
    if(type.mode)return 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                       0
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                            ;
    if(type.tag==TAG_STRUCT)return la_owner_layout(facts,type.layout) && !v.unknown &&
        v.kind==1 && v.tags==((uint16_t)(1u<<(TAG_STRUCT))) && v.layout==type.layout;
    return type.layout==0xFFFFFFFFu && la_exact(v,type.tag);
}
static NvmOwnerDeclaration la_declaration(const Facts *facts,Slot slot) {
    return (NvmOwnerDeclaration){slot.tag,slot.mode,slot.layout,slot.tag==TAG_STRUCT && la_owner_layout(facts,slot.layout)};
}
static 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_signature(const Facts *facts,Slot slot,
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                     _Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                          result) {
    if(slot.mode)return 
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                       0
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                            ;
    if(slot.tag==TAG_STRUCT)return la_owner_layout(facts,slot.layout);
    return slot.layout==0xFFFFFFFFu && (slot.tag==TAG_INT || slot.tag==TAG_BOOL || slot.tag==TAG_U8 ||
        (result?slot.tag==TAG_VOID:slot.tag==TAG_STRING));
}


static NvmAffineState *la_checked_state(LAAnalysis *a,uint32_t function) {
    NvmAffineState *s=calloc(1,sizeof *s);
    if(!s)return 
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                ((void *)0)
# 65 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                    ;
    s->facts=calloc(1,sizeof *s->facts);
    if(!s->facts){free(s);return 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                ((void *)0)
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                    ;}
    Facts *facts=s->facts;facts->users=1;facts->module=a->module;facts->function=function;s->invocation=1;
    NvmOwnedArrayTransport transport;nvm_owned_array_transport(a->proof->layouts,&transport);
    if(nvm_v2_layouts_decode(transport.layouts,transport.layout_size,&facts->layouts)!=NVM_V2_OK)goto fail;
    NvmV2Cursor c;uint32_t count,ignored;const uint8_t *flags;
    nvm_v2_cursor_init(&c,transport.ownership,transport.ownership_size);
    if(nvm_v2_u32(&c,&ignored)!=NVM_V2_OK || nvm_v2_u32(&c,&count)!=NVM_V2_OK ||
       count!=facts->layouts.count || nvm_v2_take(&c,count,&flags)!=NVM_V2_OK)goto fail;
    facts->flags=malloc(count?count:1);if(!facts->flags)goto fail;memcpy(facts->flags,flags,count);
    if(nvm_v2_align4(&c)!=NVM_V2_OK || nvm_v2_u32(&c,&ignored)!=NVM_V2_OK)goto fail;
    for(uint32_t f=0;f<=function;f++) {
        uint16_t locals,params;Slot result;
        if(nvm_v2_u16(&c,&locals)!=NVM_V2_OK || nvm_v2_u16(&c,&params)!=NVM_V2_OK || !slot_read(&c,&result))goto fail;
        if(f==function) {
            facts->count=locals;facts->params=params;facts->result=result;
            facts->locals=calloc(locals?locals:1,sizeof *facts->locals);
            s->live=calloc(locals?locals:1,sizeof *s->live);s->refs=calloc(1,sizeof *s->refs);
            s->variants=malloc((locals?locals:1)*sizeof *s->variants);
            if(!facts->locals || !s->live || !s->variants || !s->refs)goto fail;
            for(uint16_t local=0;local<locals;local++)s->variants[local]=
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                        (65535)
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                                  ;
        }
        for(uint16_t n=0;n<locals;n++) {
            Slot slot;if(!slot_read(&c,&slot))goto fail;
            if(f==function){facts->locals[n]=slot;s->live[n]=n<params;}
        }
    }
    return s;
fail:nvm_affine_state_free(s);return 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                    ((void *)0)
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                        ;
}
static 
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 96 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_facts(LAAnalysis *a,uint32_t f) {
    const NvmFunctionEntry *fn=&a->module->functions[f];
    NvmAffineState *s=la_checked_state(a,f);
    if(!s)return la_stop(a,NVM_OWNER_AUTH_MEMORY,f,0,"I could not materialize checked owner Facts.");
    a->functions[f].seed=s;Facts *facts=s->facts;
    NvmOwnerSignature *signature=&a->proof->signatures[f];
    if(facts->count!=fn->local_count || facts->params!=fn->arity ||
       !la_signature(facts,facts->result,
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                        1
# 103 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                            ) || facts->result.tag!=fn->result_tag ||
       fn->result_count!=(facts->result.tag==TAG_VOID?0:1))
        return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,0,"I retain exact existing owner value signatures.");
    for(uint32_t l=0;l<facts->layouts.count;l++)if(la_owner_layout(facts,l)) {
        const NvmV2Layout *layout=&facts->layouts.items[l];
        NvmOwnedArrayLayoutFact shape;
        if(!nvm_owned_array_layout_fact(a->proof->layouts,l,&shape))
            return la_stop(a,NVM_OWNER_AUTH_INVALID,f,0,"I require the exact independently retained layout row.");


        if(shape.owner_depth>=32u || layout->field_count>256u)
            return la_stop(a,NVM_OWNER_AUTH_LIMIT,f,0,"I reached my owner depth or direct-field limit.");
        if(!la_work(a,layout->field_count))return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                 0
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                      ;
        for(uint16_t n=0;n<layout->field_count;n++) {
            NvmV2LayoutField field=layout->fields[n];
            if(field.type_tag==TAG_STRUCT) {
                if(field.nested_idx>=l || !la_owner_layout(facts,field.nested_idx))
                    return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,0,"I require prior exact nested owners.");
            } else if(field.nested_idx!=0xFFFFFFFFu || (field.type_tag!=TAG_INT && field.type_tag!=TAG_BOOL &&
                      field.type_tag!=TAG_U8 && field.type_tag!=TAG_STRING && field.type_tag!=TAG_ARRAY))
                return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,0,"I keep unsupported owner fields outside authority.");
        }
    }
    signature->local_count=facts->count;signature->parameter_count=facts->params;
    signature->result=la_declaration(facts,facts->result);
    if(signature->result.owner)signature->result_fields=facts->layouts.items[facts->result.layout].field_count;
    for(uint16_t n=0;n<facts->count;n++) {
        Slot slot=facts->locals[n];
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                  _Bool 
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                       valid=n<facts->params?la_signature(facts,slot,
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                                     0
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                          ):
            !slot.mode && (slot.tag==TAG_STRUCT?la_owner_layout(facts,slot.layout):
                slot.layout==0xFFFFFFFFu && (scalar(slot.tag) || slot.tag==TAG_STRING || slot.tag==TAG_ARRAY));
        if(!valid)return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,0,"I require modeled exact local declarations.");
        a->proof->locals[f][n]=la_declaration(facts,slot);
        if(n<facts->params)signature->parameters[n]=a->proof->locals[f][n];
    }
    return 
# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
          1
# 137 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
              ;
}
static 
# 139 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 139 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_optional_comparison(uint8_t op) {
    switch(op) {
    case OP_F64_EQ:case OP_F64_NE:case OP_F64_LT:case OP_F64_LE:case OP_F64_GT:case OP_F64_GE:return 
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                                                    1
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                                        ;
    default:return 
# 142 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                  0
# 142 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                       ;
    }
}
static int la_scalar(uint8_t op,uint16_t *required) {
    *required=0;
    switch(op) {
    case OP_PUSH_I64:return TAG_INT;case OP_PUSH_F64:return TAG_FLOAT;
    case OP_PUSH_U8:return TAG_U8;case OP_PUSH_BOOL:return TAG_BOOL;case OP_PUSH_VOID:return TAG_VOID;
    case OP_I64_ADD:case OP_I64_SUB:case OP_I64_MUL:case OP_I64_DIV_S:case OP_I64_REM_S:case OP_I64_NEG:
        *required=((uint16_t)(1u<<(TAG_INT)));return TAG_INT;
    case OP_F64_ADD:case OP_F64_SUB:case OP_F64_MUL:case OP_F64_DIV:case OP_F64_NEG:
        *required=((uint16_t)(1u<<(TAG_FLOAT)));return TAG_FLOAT;
    case OP_I64_EQ:case OP_I64_NE:case OP_I64_LT_S:case OP_I64_LE_S:case OP_I64_GT_S:case OP_I64_GE_S:
        *required=((uint16_t)(1u<<(TAG_INT)));return TAG_BOOL;
    case OP_F64_EQ:case OP_F64_NE:case OP_F64_LT:case OP_F64_LE:case OP_F64_GT:case OP_F64_GE:
        *required=((uint16_t)(1u<<(TAG_FLOAT)));return TAG_BOOL;
    case OP_BOOL_AND:case OP_BOOL_OR:case OP_BOOL_NOT:*required=((uint16_t)(1u<<(TAG_BOOL)));return TAG_BOOL;
    case OP_EQ:case OP_NE:return TAG_BOOL;
    default:return -1;
    }
}
static 
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_supported(uint8_t op) {
    uint16_t required;if(la_scalar(op,&required)>=0)return 
# 164 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                          1
# 164 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                              ;
    switch(op) {
    case OP_PUSH_STR:case OP_NOP:case OP_DUP:case OP_POP:case OP_SWAP:case OP_ROT3:
    case OP_LOAD_LOCAL:case OP_STORE_LOCAL:case OP_OWN_MOVE_LOCAL:case OP_OWN_STORE_LOCAL:
    case OP_OWN_PACK:case OP_OWN_UNPACK_LOCAL:case OP_AGG_GET:
    case OP_ARR_NEW:case OP_ARR_LITERAL:case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN:
    case OP_JMP:case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_CALL:case OP_RET:case OP_ASSERT:
    case OP_PRINT:case OP_PRINTLN:return 
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                        1
# 171 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                            ;
    default:return 
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                  0
# 172 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                       ;
    }
}
static 
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 175 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_decode(LAAnalysis *a) {
    NvmOwnerOriginCounts origins;nvm_owned_array_origin_counts(a->proof->origins,&origins);
    for(uint32_t f=0;f<a->module->function_count;f++) {
        if(!la_facts(a,f))return 
# 178 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                0
# 178 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                     ;
        const NvmFunctionEntry *fn=&a->module->functions[f];LAFunction *af=&a->functions[f];af->start=a->count;
        for(uint32_t pc=0;pc<fn->code_length;) {
            if(a->count==4096u)return la_stop(a,NVM_OWNER_AUTH_LIMIT,f,pc,"I reached my independent instruction budget.");
            LAInstruction *i=&a->instructions[a->count];i->function=f;i->pc=pc;
            uint32_t width=isa_decode(a->module->code+fn->code_offset+pc,fn->code_length-pc,&i->in);
            if(!width || !la_supported(i->in.opcode))return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,pc,"I require an explicit independent instruction transfer.");
            NvmOwnerOriginObligation *row=&a->proof->obligations[a->count];
            if(!nvm_owned_array_origin_obligation(a->proof->origins,a->count,row) || row->function!=f || row->pc!=pc || row->opcode!=i->in.opcode)
                return la_stop(a,NVM_OWNER_AUTH_INVALID,f,pc,"I require identical independent and origin instruction locations.");
            a->count++;pc+=width;i->next=a->count;i->target=
# 188 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                           (4294967295U)
# 188 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                     ;
        }
        af->end=a->count;
    }
    if(a->count!=origins.obligations)return la_stop(a,NVM_OWNER_AUTH_INVALID,0,0,"I require complete independent instruction coverage.");
    for(uint32_t f=0;f<a->module->function_count;f++)for(uint32_t n=a->functions[f].start;n<a->functions[f].end;n++) {
        LAInstruction *i=&a->instructions[n];uint8_t op=i->in.opcode;
        if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
            int64_t target=(int64_t)i->pc+i->in.operands[0].i32;
            for(uint32_t t=a->functions[f].start;t<a->functions[f].end;t++)if(target==a->instructions[t].pc)i->target=t;
            if(i->target==
# 198 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                         (4294967295U)
# 198 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                   )return la_stop(a,NVM_OWNER_AUTH_INVALID,f,i->pc,"I require exact independent branch destinations.");
        }
    }
    return 
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
          1
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
              ;
}
static void la_frame_free(LAFrame *f) {
    if(!f)return;
    nvm_affine_state_free(f->owners);free(f->values);free(f);
}
static LAFrame *la_clone(const LAFrame *from,uint16_t locals) {
    LAFrame *f=calloc(1,sizeof *f);if(!f)return 
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                               ((void *)0)
# 208 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                   ;
    f->owners=nvm_affine_state_clone(from->owners);f->values=calloc((uint32_t)locals+256u,sizeof *f->values);
    if(!f->owners || !f->values){la_frame_free(f);return 
# 210 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                        ((void *)0)
# 210 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                            ;}
    f->depth=from->depth;memcpy(f->values,from->values,((uint32_t)locals+from->depth)*sizeof *f->values);return f;
}
static void la_enqueue(LAAnalysis *a,uint32_t n) {
    if(a->instructions[n].queued)return;
    a->instructions[n].queued=
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                             1
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                 ;a->queue[a->tail]=n;a->tail=(a->tail+1)%4096u;a->pending++;
}
static 
# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_join(LAAnalysis *a,uint32_t n,const LAFrame *from) {
    if(n>=a->count)return la_stop(a,NVM_OWNER_AUTH_INVALID,0,0,"I require an existing independent state destination.");
    LAInstruction *i=&a->instructions[n];uint16_t locals=a->module->functions[i->function].local_count;
    if(!la_work(a,(uint32_t)locals*2+from->depth))return 
# 220 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                        0
# 220 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                             ;
    
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
   _Bool 
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
        changed=
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                0
# 221 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                     ;
    if(!i->frame) {
        uint32_t cells=(uint32_t)locals+256u;
        if(cells>1048576u -a->cells)return la_stop(a,NVM_OWNER_AUTH_LIMIT,i->function,i->pc,"I reached my independent state-cell budget.");
        i->frame=la_clone(from,locals);
        if(!i->frame)return la_stop(a,NVM_OWNER_AUTH_MEMORY,i->function,i->pc,"I could not allocate an independent join frame.");
        a->cells+=cells;changed=
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                               1
# 227 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                   ;
    } else {
        LAFrame *to=i->frame;
        if(to->depth!=from->depth)return la_stop(a,NVM_OWNER_AUTH_INVALID,i->function,i->pc,"I require equal independent join heights.");
        for(uint32_t k=0;k<(uint32_t)locals+to->depth;k++) {
            LAValue x=to->values[k],y=from->values[k];
            if((x.kind || y.kind) && (x.kind!=y.kind || x.layout!=y.layout || x.root!=y.root || x.tags!=y.tags || x.unknown!=y.unknown))
                return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,i->function,i->pc,"I require compatible unique stack owners and observations.");
        }
        
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
       _Bool 
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
            met=
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                0
# 236 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                     ;
        if(!nvm_affine_state_meet_initialization(to->owners,from->owners,&met))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,i->function,i->pc,"I require compatible independent owner lifetimes at joins.");
        changed|=met;
        for(uint32_t k=0;k<(uint32_t)locals+to->depth;k++) {
            uint16_t tags=to->values[k].tags;uint8_t unknown=to->values[k].unknown;
            to->values[k].tags|=from->values[k].tags;to->values[k].unknown|=from->values[k].unknown;
            changed|=tags!=to->values[k].tags || unknown!=to->values[k].unknown;
        }
    }
    if(changed)la_enqueue(a,n);
    return 
# 247 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
          1
# 247 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
              ;
}
static 
# 249 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 249 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_observed(const LAFrame *frame,uint16_t locals,uint16_t root) {
    for(uint16_t n=0;n<frame->depth;n++)if(frame->values[locals+n].kind==2 && frame->values[locals+n].root==root)return 
# 250 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                                                                       1
# 250 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                                                           ;
    return 
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
          0
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
               ;
}
static 
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
      _Bool 
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
           la_transfer(LAAnalysis *a,uint32_t index,LAFrame *frame) {
    LAInstruction *i=&a->instructions[index];uint32_t f=i->function;
    NvmAffineState *owners=frame->owners;Facts *facts=owners->facts;
    uint16_t locals=facts->count;LAValue *stack=frame->values+locals;
    DecodedInstruction *in=&i->in;uint8_t op=in->opcode;const InstructionInfo *info=isa_get_info(op);
    if(!info)return la_stop(a,NVM_OWNER_AUTH_INVALID,f,i->pc,"I require complete instruction metadata.");
    int pops=info->pop_count,pushes=info->push_count;
    NvmAffineType fields[256u];uint16_t field_count=0,local=in->operands[0].u16;
    if(op==OP_ARR_LITERAL){pops=in->operands[1].u16;pushes=1;}
    if(op==OP_OWN_PACK || op==OP_OWN_UNPACK_LOCAL) {
        uint32_t layout=op==OP_OWN_PACK?in->operands[0].u32:facts->locals[local].layout;
        if(!la_owner_layout(facts,layout) || !nvm_affine_record_fields(owners,layout,fields,256u,&field_count))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact owner authority before field transfer.");
        if(!la_work(a,field_count))return 
# 266 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                         0
# 266 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                              ;
        pops=op==OP_OWN_PACK?field_count:0;pushes=op==OP_OWN_PACK?1:field_count;
    }
    if(op==OP_CALL) {const NvmFunctionEntry *callee=&a->module->functions[in->operands[0].u32];pops=callee->arity;pushes=callee->result_count;}
    if(op==OP_RET) {
        if(!la_work(a,locals))return 
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                    0
# 271 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                         ;
        if(frame->depth!=a->module->functions[f].result_count ||
           (frame->depth && !la_type(facts,stack[0],facts->result)) ||
           !nvm_affine_can_exit_type(owners,(NvmAffineType){facts->result.tag,facts->result.layout}))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require the exact return and complete independent owner consumption.");
        return 
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
              1
# 276 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                  ;
    }
    if(pops<0 || pushes<0 || frame->depth<pops)return la_stop(a,NVM_OWNER_AUTH_INVALID,f,i->pc,"I require complete independent operand stacks.");
    if((uint32_t)(frame->depth-pops+pushes)>256u)return la_stop(a,NVM_OWNER_AUTH_LIMIT,f,i->pc,"I reached my independent stack budget.");
    uint16_t base=(uint16_t)(frame->depth-pops);LAValue result={0};uint16_t required;
    int produced=la_scalar(op,&required);
    if(produced>=0) {
        result=la_tag((uint8_t)produced);
        if(pops>2)return la_stop(a,NVM_OWNER_AUTH_INVALID,f,i->pc,"I require bounded independent scalar operand rows.");
        i->operand_count=(uint8_t)pops;
        for(uint16_t n=base;n<frame->depth;n++) {
            LAValue v=stack[n];
            if(v.kind || v.unknown || !v.tags || (v.tags&~(((uint16_t)(1u<<(TAG_VOID)))|((uint16_t)(1u<<(TAG_INT)))|((uint16_t)(1u<<(TAG_U8)))|((uint16_t)(1u<<(TAG_FLOAT)))|((uint16_t)(1u<<(TAG_BOOL))))))
                return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require independently modeled scalar operands.");
            uint16_t operand=(uint16_t)(n-base);
            i->operand_actual[operand]|=v.tags;i->operand_required[operand]=required;
            if(required && v.tags!=required) {
                if(!la_optional_comparison(op) || !(v.tags&((uint16_t)(1u<<(TAG_FLOAT)))) ||
                   (v.tags&~(((uint16_t)(1u<<(TAG_FLOAT)))|((uint16_t)(1u<<(TAG_VOID))))))
                    return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require independently exact operands or a checked optional FLOAT comparison.");
                i->runtime_checks|=(uint8_t)(1u<<operand);
            }
        }
    } else switch(op) {
    case OP_NOP:case OP_JMP:break;
    case OP_PUSH_STR:result=la_tag(TAG_STRING);break;
    case OP_DUP:
        if(stack[frame->depth-1].kind)return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I cannot copy a unique owner or observation.");
        stack[frame->depth]=stack[frame->depth-1];frame->depth++;goto successors;
    case OP_SWAP:result=stack[frame->depth-1];stack[frame->depth-1]=stack[frame->depth-2];stack[frame->depth-2]=result;goto successors;
    case OP_ROT3:result=stack[frame->depth-1];stack[frame->depth-1]=stack[frame->depth-2];stack[frame->depth-2]=stack[frame->depth-3];stack[frame->depth-3]=result;goto successors;
    case OP_POP:
        if(stack[base].kind)return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I cannot discard an unconsumed owner or observation.");
        break;
    case OP_LOAD_LOCAL: {
        Slot slot=facts->locals[local];
        if(slot.tag==TAG_STRUCT) {
            if(!la_owner_layout(facts,slot.layout) || !nvm_affine_owner_access(owners,local,
# 313 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                                           ((void *)0)
# 313 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                               ,0,
# 313 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                                                                  0
# 313 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                                                                       ))
                return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require a live owner before observation.");
            result=la_owner(slot.layout);result.kind=2;result.root=local;
        } else {
            result=frame->values[local];
            if(!la_type(facts,result,slot) || ((scalar(slot.tag) || slot.tag==TAG_STRING) && !owners->live[local]))
                return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require independently initialized ordinary locals.");
        }
        break;
    }
    case OP_STORE_LOCAL: {
        Slot slot=facts->locals[local];result=stack[base];
        if(slot.tag==TAG_STRUCT || result.kind || !la_type(facts,result,slot))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I cannot overwrite owner authority through an ordinary store.");
        if(scalar(slot.tag) && !nvm_affine_scalar_define(owners,local))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require a checked scalar initialization.");
        if(slot.tag==TAG_STRING && !nvm_affine_string_define(owners,local))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require a checked STRING initialization.");


        frame->values[local]=result;break;
    }
    case OP_OWN_MOVE_LOCAL:case OP_OWN_UNPACK_LOCAL: {
        NvmAffineType type;
        if(!la_work(a,frame->depth))return 
# 337 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                          0
# 337 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                               ;
        if(!la_owner_layout(facts,facts->locals[local].layout) || la_observed(frame,locals,local) ||
           !nvm_affine_take_local(owners,local,&type))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require a live unobserved owner before consuming it.");
        if(op==OP_OWN_MOVE_LOCAL)result=la_owner(type.layout);
        else {
            for(uint16_t n=0;n<field_count;n++)
                stack[frame->depth++]=fields[n].tag==TAG_STRUCT?la_owner(fields[n].layout):la_tag(fields[n].tag);
            goto successors;
        }
        break;
    }
    case OP_OWN_STORE_LOCAL:
        if(facts->locals[local].tag!=TAG_STRUCT || !la_type(facts,stack[base],facts->locals[local]) ||
           !nvm_affine_put_local(owners,local,(NvmAffineType){TAG_STRUCT,stack[base].layout}))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require an empty exact owner destination.");
        break;
    case OP_OWN_PACK:
        for(uint16_t n=0;n<field_count;n++)if(!la_type(facts,stack[base+n],(Slot){fields[n].tag,0,fields[n].layout}))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact transferred owner constructor fields.");
        result=la_owner(in->operands[0].u32);break;
    case OP_AGG_GET: {
        LAValue receiver=stack[base];uint16_t field=in->operands[0].u16;
        if(receiver.kind!=2 || receiver.unknown || receiver.root>=locals || !owners->live[receiver.root] ||
           !la_owner_layout(facts,receiver.layout) || field>=facts->layouts.items[receiver.layout].field_count)
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require an exact live owner observation path.");
        NvmV2LayoutField declared=facts->layouts.items[receiver.layout].fields[field];
        result=declared.type_tag==TAG_STRUCT?la_owner(declared.nested_idx):la_tag(declared.type_tag);
        if(result.kind){result.kind=2;result.root=receiver.root;}
        break;
    }
    case OP_ARR_NEW:case OP_ARR_LITERAL:
        if(in->operands[0].u8!=TAG_FLOAT)return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require declared FLOAT array construction.");
        for(uint16_t n=base;n<frame->depth;n++)if(!la_exact(stack[n],TAG_FLOAT))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact FLOAT initializer values.");
        result=la_tag(TAG_ARRAY);break;
    case OP_ARR_PUSH:case OP_ARR_SET:case OP_ARR_GET:case OP_ARR_LEN:
        if(!la_exact(stack[base],TAG_ARRAY))return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require an independently initialized ARRAY receiver.");
        if((op==OP_ARR_GET || op==OP_ARR_SET) && !la_exact(stack[base+1],TAG_INT))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact INT indices.");
        if((op==OP_ARR_PUSH || op==OP_ARR_SET) && !la_exact(stack[frame->depth-1],TAG_FLOAT))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact FLOAT writes through aliases.");
        if(op==OP_ARR_GET){result=la_tag(TAG_FLOAT);result.tags|=((uint16_t)(1u<<(TAG_VOID)));}
        else result=la_tag(op==OP_ARR_LEN?TAG_INT:TAG_ARRAY);
        break;
    case OP_CALL: {
        uint32_t callee=in->operands[0].u32;Facts *called=a->functions[callee].seed->facts;
        for(uint16_t n=0;n<called->params;n++)if(!la_type(facts,stack[base+n],called->locals[n]))
            return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact independently transferred call arguments.");
        result=called->result.tag==TAG_STRUCT?la_owner(called->result.layout):la_tag(called->result.tag);break;
    }
    case OP_PRINT:case OP_PRINTLN:
        i->operand_count=1;i->operand_actual[0]|=stack[base].tags;
        i->operand_required[0]=((uint16_t)(1u<<(TAG_INT)));
        if(!la_exact(stack[base],TAG_INT))return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require independently exact INT output operands.");
        break;
    case OP_JMP_TRUE:case OP_JMP_FALSE:case OP_ASSERT:
        i->operand_count=1;i->operand_actual[0]|=stack[base].tags;
        i->operand_required[0]=((uint16_t)(1u<<(TAG_BOOL)));
        if(!la_exact(stack[base],TAG_BOOL))return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require exact BOOL control operands.");
        break;
    default:return la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,f,i->pc,"I require an explicit independent lifetime transfer.");
    }
    frame->depth=(uint16_t)(base+pushes);if(pushes)stack[base]=result;
successors:
    if(frame->depth>a->proof->signatures[f].max_stack)a->proof->signatures[f].max_stack=frame->depth;
    if(op==OP_JMP || op==OP_JMP_TRUE || op==OP_JMP_FALSE) {
        if(!la_join(a,i->target,frame))return 
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                             0
# 404 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                  ;
        if(op==OP_JMP)return 
# 405 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                            1
# 405 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                ;
    }
    return la_join(a,i->next,frame);
}
void nvm_owned_array_lifetime_facts_free(NvmOwnerLifetimeFacts *p) {
    if(!p)return;
    nvm_owned_array_origins_free(p->origins);nvm_owned_array_layouts_free(p->layouts);free(p);
}
static NvmOwnerAuthorityStatus la_origin_status(NvmOwnerOriginStatus status) {
    switch(status) {
    case NVM_OWNER_ORIGIN_MEMORY:return NVM_OWNER_AUTH_MEMORY;
    case NVM_OWNER_ORIGIN_LIMIT:return NVM_OWNER_AUTH_LIMIT;
    case NVM_OWNER_ORIGIN_INVALID:return NVM_OWNER_AUTH_INVALID;
    default:return NVM_OWNER_AUTH_UNRESOLVED;
    }
}
NvmOwnerAuthorityResult nvm_analyze_owned_array_lifetimes(const NvmModule *m,NvmOwnerLifetimeFacts **out) {
    NvmOwnerAuthorityResult invalid={NVM_OWNER_AUTH_INVALID,0,0,"I require a complete immutable module and private output."};
    if(!out)return invalid;
    NvmOwnedArrayOrigins *origins=
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                 ((void *)0)
# 424 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                     ;NvmOwnerOriginResult origin=nvm_analyze_owned_array_origins(m,&origins);
    if(origin.status!=NVM_OWNER_ORIGIN_PROVED)return (NvmOwnerAuthorityResult){la_origin_status(origin.status),origin.function,origin.pc,origin.message};
    NvmOwnedArrayLayouts *layouts=
# 426 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                 ((void *)0)
# 426 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                     ;NvmRecordPlanResult described=nvm_describe_owned_array_layouts(m,&layouts);
    if(described.status!=NVM_RECORD_DESCRIBED) {
        nvm_owned_array_origins_free(origins);
        NvmOwnerAuthorityStatus status=described.status==NVM_RECORD_MEMORY?NVM_OWNER_AUTH_MEMORY:
            described.status==NVM_RECORD_LIMIT?NVM_OWNER_AUTH_LIMIT:
            described.status==NVM_RECORD_INVALID?NVM_OWNER_AUTH_INVALID:NVM_OWNER_AUTH_UNRESOLVED;
        return (NvmOwnerAuthorityResult){status,0,0,described.message};
    }
    LAAnalysis *a=calloc(1,sizeof *a);NvmOwnerLifetimeFacts *p=calloc(1,sizeof *p);
    if(!a || !p) {free(a);free(p);nvm_owned_array_origins_free(origins);nvm_owned_array_layouts_free(layouts);
        return (NvmOwnerAuthorityResult){NVM_OWNER_AUTH_MEMORY,0,0,"I could not allocate independent owner analysis."};}
    p->origins=origins;p->layouts=layouts;a->proof=p;a->module=m;a->error=invalid;
    if(!la_decode(a))goto done;
    for(uint32_t f=0;f<m->function_count;f++) {
        uint16_t locals=m->functions[f].local_count;LAValue values[256u*2]={0};
        LAFrame seed={a->functions[f].seed,values,0};
        for(uint16_t n=0;n<locals;n++){values[n]=la_tag(TAG_VOID);values[n].unknown=1;}
        for(uint16_t n=0;n<m->functions[f].arity;n++)if(seed.owners->facts->locals[n].tag!=TAG_STRUCT)
            values[n]=la_tag(seed.owners->facts->locals[n].tag);
        if(!la_join(a,a->functions[f].start,&seed))goto done;
    }
    while(a->pending) {
        if(a->visits++==262144u){la_stop(a,NVM_OWNER_AUTH_LIMIT,0,0,"I reached my independent transfer visit budget.");goto done;}
        uint32_t n=a->queue[a->head];a->head=(a->head+1)%4096u;a->pending--;
        LAInstruction *i=&a->instructions[n];i->queued=
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
                                                      0
# 450 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
                                                           ;
        uint16_t locals=m->functions[i->function].local_count;
        if(!la_work(a,(uint32_t)locals*2+i->frame->depth))goto done;
        LAFrame *frame=la_clone(i->frame,locals);
        if(!frame){la_stop(a,NVM_OWNER_AUTH_MEMORY,i->function,i->pc,"I could not copy independent transfer state.");goto done;}
        
# 455 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc" 3 4
       _Bool 
# 455 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/owned_array_authority.inc"
            ok=la_transfer(a,n,frame);la_frame_free(frame);if(!ok)goto done;
    }
    for(uint32_t n=0;n<a->count;n++)if(!a->instructions[n].frame) {
        la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,a->instructions[n].function,a->instructions[n].pc,"I require independent state for every declared instruction.");goto done;
    }
    for(uint32_t n=0;n<a->count;n++) {
        LAInstruction *i=&a->instructions[n];const NvmOwnerOriginObligation *row=&p->obligations[n];
        if(!la_work(a,2))goto done;
        if(row->operand_count!=i->operand_count || row->runtime_checks!=i->runtime_checks ||
           row->operand_actual[0]!=i->operand_actual[0] || row->operand_actual[1]!=i->operand_actual[1] ||
           row->operand_required[0]!=i->operand_required[0] || row->operand_required[1]!=i->operand_required[1]) {
            la_stop(a,NVM_OWNER_AUTH_UNRESOLVED,i->function,i->pc,"I require independently matching per-operand obligations.");goto done;
        }
    }
    p->counts=(NvmOwnerAuthorityCounts){m->function_count,a->count,a->cells,a->visits,a->work};
    a->error=(NvmOwnerAuthorityResult){NVM_OWNER_AUTH_PREPARED,0,0,"I checked origin, lifetime and scalar transfers; common structure and runtime admission remain separate."};
done:
    for(uint32_t n=0;n<a->count;n++)la_frame_free(a->instructions[n].frame);
    for(uint32_t f=0;f<m->function_count;f++)nvm_affine_state_free(a->functions[f].seed);
    NvmOwnerAuthorityResult result=a->error;free(a);
    if(result.status==NVM_OWNER_AUTH_PREPARED)*out=p;else nvm_owned_array_lifetime_facts_free(p);
    return result;
}
# 881 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/affine_state.c" 2
