nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal_config.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_file_nominal.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_catalog.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_file_plan.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_nominal_codec.inc \
 /usr/include/string.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/strings.h \
 /usr/include/aarch64-linux-gnu/bits/strings_fortified.h \
 /usr/include/aarch64-linux-gnu/bits/string_fortified.h
