# 0 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 1


# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef unsigned int wchar_t;
# 425 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/aarch64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 1 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 6 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h" 1 3 4
# 9 "/usr/include/aarch64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/timesize.h" 1 3 4
# 29 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/aarch64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/aarch64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h" 2 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_bindings.h"
typedef struct { uint32_t imports[5u]; } NvmServiceBindings;
typedef enum {
    NVM_SERVICE_OK = 0, NVM_SERVICE_ARGUMENT, NVM_SERVICE_SIZE,
    NVM_SERVICE_VERSION, NVM_SERVICE_CATALOG, NVM_SERVICE_COUNT,
    NVM_SERVICE_RESERVED, NVM_SERVICE_ORDINAL, NVM_SERVICE_INDEX
} NvmServiceResult;




NvmServiceResult nvm_service_bindings_check(const NvmServiceBindings *);

NvmServiceResult nvm_service_bindings_decode(const uint8_t *, size_t, NvmServiceBindings *);



NvmServiceResult nvm_service_bindings_encode(const NvmServiceBindings *, uint8_t *, size_t, size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h" 1 3 4
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 2
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_SECTION_CODE = 0x0001,
    NVM_SECTION_STRINGS = 0x0002,
    NVM_SECTION_FUNCTIONS = 0x0003,
    NVM_SECTION_STRUCTS = 0x0004,
    NVM_SECTION_ENUMS = 0x0005,
    NVM_SECTION_UNIONS = 0x0006,
    NVM_SECTION_GLOBALS = 0x0007,
    NVM_SECTION_IMPORTS = 0x0008,
    NVM_SECTION_DEBUG = 0x0009,
    NVM_SECTION_METADATA = 0x000A,
    NVM_SECTION_MODULE_REFS = 0x000B
} NvmSectionType;


typedef struct {
    uint32_t module_name_idx;
} NvmModuleRefEntry;
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint8_t magic[4];
    uint32_t format_version;
    uint32_t flags;
    uint32_t entry_point;
    uint32_t section_count;
    uint32_t string_pool_offset;
    uint32_t string_pool_length;
    uint32_t checksum;
} NvmHeader;







typedef struct {
    uint32_t type;
    uint32_t offset;
    uint32_t size;
} NvmSectionEntry;





typedef struct {
    uint32_t name_idx;
    uint16_t arity;
    uint32_t code_offset;
    uint32_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint8_t result_tag;
    uint8_t result_count;
} NvmFunctionEntry;
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef struct {
    uint32_t bytecode_offset;
    uint32_t source_line;
    uint32_t source_col;
} NvmDebugEntry;
# 136 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_FOREIGN_OWNER_THREAD = 0,
    NVM_FOREIGN_WORKER_THREAD = 1
} NvmForeignExecution;




typedef struct {
    uint32_t import_idx;
    uint32_t adapter_name_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint16_t param_count;
    uint8_t return_tag;
    uint8_t param_tags[16];
} NvmCallbackContract;


# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 155 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_shape_valid(const uint8_t *tags, uint16_t count, uint8_t result);





typedef enum {
    NVM_IMPORT_FFI = 0,
    NVM_IMPORT_COPROCESS = 1,
    NVM_IMPORT_ARTIFACT = 2,
    NVM_IMPORT_SERVICE = 3
} NvmImportKind;

typedef struct {
    uint32_t module_name_idx;
    uint32_t function_name_idx;
    uint16_t param_count;
    uint8_t return_type;
    uint8_t kind;

} NvmImportEntry;
# 189 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
typedef enum {
    NVM_CALL_UNRESOLVED = 0,
    NVM_CALL_RESOLVED,
    NVM_CALL_FAILED
} NvmCallResolution;

typedef struct {
    NvmCallResolution state;
    void *func_ptr;
    const char *func_name;
    const char *module_name;
    const uint8_t *param_types;
    uint16_t param_count;
    uint8_t return_type;
    
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 203 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        all_float;
    void (*string_release)(const char *);
    
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
   _Bool 
# 205 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
        (*array_release)(void *);
} NvmCallDescriptor;







typedef struct { uint32_t key_idx, value_idx; } NvmMetadataEntry;





typedef struct {
    NvmHeader header;
    NvmSectionEntry sections[16];
    uint32_t section_count;


    char **strings;
    uint32_t *string_lengths;
    uint32_t string_count;
    uint32_t string_capacity;


    NvmFunctionEntry *functions;
    uint8_t **function_param_types;
    uint32_t function_count;
    uint32_t function_capacity;


    uint8_t *code;
    uint32_t code_size;
    uint32_t code_capacity;


    uint8_t *ownership_data;
    uint32_t ownership_size;


    uint8_t *layout_data;
    uint32_t layout_size;


    uint8_t *service_data;
    uint32_t service_size;


    uint8_t *passive_data;
    uint32_t passive_size;

    NvmMetadataEntry *metadata;
    uint32_t metadata_count;
    uint32_t metadata_capacity;


    NvmDebugEntry *debug_entries;
    uint32_t debug_count;
    uint32_t debug_capacity;


    uint32_t source_file_idx;


    NvmImportEntry *imports;
    uint8_t **import_param_types;
    NvmCallbackContract *callback_contracts;
    uint32_t callback_contract_count;
    uint32_t callback_contract_capacity;
    uint32_t import_count;
    uint32_t import_capacity;


    NvmModuleRefEntry *module_refs;
    uint32_t module_ref_count;
    uint32_t module_ref_capacity;

    NvmCallDescriptor *call_descriptors;
    uint32_t call_descriptor_count;


    uint32_t struct_count;
    uint32_t enum_count;
    uint32_t union_count;
} NvmModule;






NvmModule *nvm_module_new(void);


void nvm_module_free(NvmModule *mod);



uint32_t nvm_add_string(NvmModule *mod, const char *str, uint32_t length);



# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 308 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_metadata(NvmModule *mod, uint32_t key, uint32_t value);

# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 309 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_valid(const NvmModule *mod);

# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_metadata_source_key(const NvmModule *mod, uint32_t key);





# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_purity(NvmModule *mod, uint32_t function, 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
                                                               _Bool 
# 315 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
                                                                    declared);
int nvm_function_purity(const NvmModule *mod, uint32_t function);





# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 321 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_effects(NvmModule *mod, uint32_t function, unsigned effects);
int nvm_function_effects(const NvmModule *mod, uint32_t function);





# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 327 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_function_affine(NvmModule *mod, uint32_t function, unsigned affine);
int nvm_function_affine(const NvmModule *mod, uint32_t function);





typedef struct {
    uint32_t function, line, column;
    unsigned coverage, coordinates;
    const char *source_path;
    uint32_t source_path_length;
} NvmMatchCoverage;

# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 340 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_match_coverage(NvmModule *mod, uint32_t function, uint32_t line,
    uint32_t column, unsigned coverage, unsigned coordinates, const char *source_path);

# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 342 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_match_coverage_at(const NvmModule *mod, uint32_t metadata_index, NvmMatchCoverage *out);





typedef struct {
    uint32_t function, line, column;
    unsigned state, coordinates;
    const char *source_path, *binding;
    uint32_t source_path_length, binding_length;
} NvmAffineUse;

# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 354 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_affine_use(NvmModule *, uint32_t function, uint32_t line,
    uint32_t column, unsigned state, unsigned coordinates, const char *path, const char *binding);

# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 356 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_affine_use_at(const NvmModule *, uint32_t metadata_index, NvmAffineUse *out);


typedef struct {
    uint32_t function, call_line, call_column, argument_line, argument_column, ordinal;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmBorrowPlace;

# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 365 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_borrow_place(NvmModule *, const NvmBorrowPlace *);

typedef struct {
    uint32_t function, line, column;
    unsigned category, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldRead;

# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 373 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_read(NvmModule *, const NvmFieldRead *);

# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 374 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_read_at(const NvmModule *, uint32_t metadata_index, NvmFieldRead *);
typedef struct {
    uint32_t function, line, column;
    unsigned mode, coordinates;
    const char *source_path, *root, *projection;
    uint32_t source_path_length, root_length, projection_length;
} NvmFieldWrite;

# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_field_write(NvmModule *, const NvmFieldWrite *);

# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 382 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_field_write_at(const NvmModule *, uint32_t metadata_index, NvmFieldWrite *);



# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 385 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_borrow_place_at(const NvmModule *, uint32_t metadata_index, NvmBorrowPlace *);



typedef struct {
    uint32_t function;
    const char *source_name, *source_path, *variable, *type;
    uint32_t source_name_length, source_path_length, variable_length, type_length;
} NvmGenericBinding;

# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 394 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_generic_binding(NvmModule *mod, uint32_t function,
    const char *source_name, const char *source_path, const char *variable,
    const char *type);


# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 398 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_generic_binding_at(const NvmModule *mod, uint32_t metadata_index,
                            NvmGenericBinding *out);



uint32_t nvm_add_function(NvmModule *mod, const NvmFunctionEntry *entry);



# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 406 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_set_function_param_types(NvmModule *mod, uint32_t index,
                                  const uint8_t *tags, uint16_t count);


# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 409 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_callback_contract(NvmModule *mod, const NvmCallbackContract *contract);

# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 410 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_callback_contracts_valid(const NvmModule *mod);



uint32_t nvm_append_code(NvmModule *mod, const uint8_t *code, uint32_t size);





# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 419 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_add_debug_entry(NvmModule *mod, uint32_t bytecode_offset,
                         uint32_t source_line, uint32_t source_col);



void nvm_strip_debug_info(NvmModule *mod);





# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_file_instructions_present(const NvmModule *mod);

uint8_t *nvm_serialize(const NvmModule *mod, uint32_t *out_size);


NvmModule *nvm_deserialize(const uint8_t *data, uint32_t size);



# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h" 3 4
_Bool 
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format.h"
    nvm_validate_header(const NvmHeader *header);


uint32_t nvm_crc32(const uint8_t *data, uint32_t size);



uint32_t nvm_add_import(NvmModule *mod, uint32_t module_name_idx,
                        uint32_t function_name_idx, uint16_t param_count,
                        uint8_t return_type, const uint8_t *param_types);



uint32_t nvm_add_module_ref(NvmModule *mod, uint32_t module_name_idx);


const char *nvm_get_string(const NvmModule *mod, uint32_t index);



uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);




uint32_t nvm_get_string_len(const NvmModule *mod, uint32_t index);


uint32_t nvm_find_function(const NvmModule *mod, const char *name);




void nvm_call_descriptors_reset(NvmModule *mod);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
typedef struct {
    uint32_t imports[4u];
    uint32_t layouts[7u];
} NvmWebSocketNominalBindings;
NvmServiceResult nvm_websocket_nominal_check(const NvmWebSocketNominalBindings *);

NvmServiceResult nvm_websocket_nominal_decode(const uint8_t *,size_t,NvmWebSocketNominalBindings *);


NvmServiceResult nvm_websocket_nominal_encode(const NvmWebSocketNominalBindings *,uint8_t *,size_t,size_t *);

typedef enum {
    NVM_WEBSOCKET_NOMINAL_DESCRIBED, NVM_WEBSOCKET_NOMINAL_INVALID,
    NVM_WEBSOCKET_NOMINAL_LIMIT, NVM_WEBSOCKET_NOMINAL_MEMORY
} NvmWebSocketNominalStatus;
typedef enum {
    NVM_WEBSOCKET_CATEGORY_UNKNOWN, NVM_WEBSOCKET_CATEGORY_CONN,
    NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT, NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT,
    NVM_WEBSOCKET_CATEGORY_RECORD
} NvmWebSocketCategory;
typedef struct {
    uint32_t global_index, catalog_ordinal, source_ordinal;
    uint8_t layout_kind, ownership_flags;
    NvmWebSocketCategory category;
} NvmWebSocketNominalLayout;
typedef struct NvmWebSocketNominalPlan NvmWebSocketNominalPlan;




NvmWebSocketNominalStatus nvm_websocket_nominal_plan(const NvmModule *,NvmWebSocketNominalPlan **);
void nvm_websocket_nominal_plan_free(NvmWebSocketNominalPlan *);



# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_storage_bound(uint32_t layouts, size_t *out);
uint32_t nvm_websocket_nominal_layout_count(const NvmWebSocketNominalPlan *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_layout(const NvmWebSocketNominalPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_type(const NvmWebSocketNominalPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_source(const NvmWebSocketNominalPlan *,uint8_t,uint32_t,NvmWebSocketNominalLayout *);

# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal.h"
    nvm_websocket_nominal_import(const NvmWebSocketNominalPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 2
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
typedef enum {
    NVM_WEBSOCKET_FLOW_OK, NVM_WEBSOCKET_FLOW_INVALID, NVM_WEBSOCKET_FLOW_UNRESOLVED,
    NVM_WEBSOCKET_FLOW_LIMIT, NVM_WEBSOCKET_FLOW_MEMORY
} NvmWebSocketFlowStatus;
typedef struct NvmWebSocketFlowDeclarations NvmWebSocketFlowDeclarations;
typedef struct NvmWebSocketFlowState NvmWebSocketFlowState;
typedef struct {
    uint8_t tag, mode;
    uint32_t global_index, catalog_ordinal;
    NvmWebSocketCategory category;
} NvmWebSocketFlowDeclaration;
typedef struct {
    uint16_t parameters, locals;
    uint8_t result_count;
    NvmWebSocketFlowDeclaration result;
} NvmWebSocketFlowFunction;
typedef enum {
    NVM_WEBSOCKET_FLOW_ARM_NONE, NVM_WEBSOCKET_FLOW_ARM_UNKNOWN,
    NVM_WEBSOCKET_FLOW_ARM_OK, NVM_WEBSOCKET_FLOW_ARM_ERROR
} NvmWebSocketFlowArm;
typedef struct {
    NvmWebSocketFlowDeclaration type;
    
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
   _Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
        initialized;
    uint64_t owner;
    NvmWebSocketFlowArm arm;
} NvmWebSocketFlowValue;
typedef struct {
    
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
   _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
        live, formal;
    uint16_t local;
    uint64_t owner, identity, region;
    
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
   _Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
        shared;
} NvmWebSocketFlowReference;
typedef struct {
    uint16_t stack, regions, owners, references;
    uint64_t cleanup_obligations;
    uint16_t obligations;
    
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
   _Bool 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
        reachable;
} NvmWebSocketFlowCounts;



typedef enum { NVM_WEBSOCKET_FLOW_SERVICE, NVM_WEBSOCKET_FLOW_CALL } NvmWebSocketFlowObligationKind;
typedef enum { NVM_WEBSOCKET_FLOW_INPUT_NONE, NVM_WEBSOCKET_FLOW_INPUT_PRESERVED,
               NVM_WEBSOCKET_FLOW_INPUT_CONSUMED } NvmWebSocketFlowInputState;
enum {
    NVM_WEBSOCKET_FLOW_CHECK_BINDING=1u, NVM_WEBSOCKET_FLOW_CHECK_INVOCATION=2u,
    NVM_WEBSOCKET_FLOW_CHECK_LIVENESS=4u, NVM_WEBSOCKET_FLOW_CHECK_RIGHTS=8u,
    NVM_WEBSOCKET_FLOW_CHECK_BORROW=16u, NVM_WEBSOCKET_FLOW_CHECK_BYTE=32u,
    NVM_WEBSOCKET_FLOW_CHECK_CALLEE=64u, NVM_WEBSOCKET_FLOW_CHECK_CLEANUP=128u,
    NVM_WEBSOCKET_FLOW_CHECK_RESULT=256u, NVM_WEBSOCKET_FLOW_CHECK_TIMEOUT=1024u
};
typedef struct {
    NvmWebSocketFlowObligationKind kind;
    uint32_t site, target, checks, required_rights, acquired_rights;
    uint16_t parameters, owned_inputs, borrowed_inputs;
    uint8_t result_count;
    NvmWebSocketFlowDeclaration result;
    NvmWebSocketFlowInputState outcomes[2];
} NvmWebSocketFlowObligation;




NvmWebSocketFlowStatus nvm_websocket_flow_declarations(const NvmModule *, NvmWebSocketFlowDeclarations **out);
void nvm_websocket_flow_declarations_free(NvmWebSocketFlowDeclarations *);

# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_function(const NvmWebSocketFlowDeclarations *, uint32_t, NvmWebSocketFlowFunction *);

# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_declaration(const NvmWebSocketFlowDeclarations *, uint32_t, uint16_t,
                             NvmWebSocketFlowDeclaration *);


NvmWebSocketFlowStatus nvm_websocket_flow_state(NvmWebSocketFlowDeclarations *, uint32_t, NvmWebSocketFlowState **out);
void nvm_websocket_flow_state_free(NvmWebSocketFlowState *);

# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_local(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowValue *);

# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 91 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_stack(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowValue *);

# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_reference(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowReference *);

# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_counts(const NvmWebSocketFlowState *, NvmWebSocketFlowCounts *);

# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
_Bool 
# 94 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
    nvm_websocket_flow_obligation(const NvmWebSocketFlowState *, uint16_t, NvmWebSocketFlowObligation *);
NvmWebSocketFlowStatus nvm_websocket_flow_clone(const NvmWebSocketFlowState *, NvmWebSocketFlowState **out);

NvmWebSocketFlowStatus nvm_websocket_flow_refine(const NvmWebSocketFlowState *, uint16_t local,
                                     NvmWebSocketFlowState **ok, NvmWebSocketFlowState **error);
NvmWebSocketFlowStatus nvm_websocket_flow_join(NvmWebSocketFlowState *, const NvmWebSocketFlowState *, 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h" 3 4
                                                                                                      _Bool 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow.h"
                                                                                                           *changed);



NvmWebSocketFlowStatus nvm_websocket_flow_push_scalar(NvmWebSocketFlowState *, uint8_t);
NvmWebSocketFlowStatus nvm_websocket_flow_load(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_store(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_dup(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_pop(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_clear_copy(NvmWebSocketFlowState *, uint16_t);


NvmWebSocketFlowStatus nvm_websocket_flow_construct(NvmWebSocketFlowState *, uint32_t catalog, uint16_t variant);
NvmWebSocketFlowStatus nvm_websocket_flow_field(NvmWebSocketFlowState *, uint16_t field);
NvmWebSocketFlowStatus nvm_websocket_flow_take_result(NvmWebSocketFlowState *, uint16_t local, NvmWebSocketFlowArm);



NvmWebSocketFlowStatus nvm_websocket_flow_service(NvmWebSocketFlowState *, uint32_t site, uint32_t import,
                                      uint16_t reference);




NvmWebSocketFlowStatus nvm_websocket_flow_call(NvmWebSocketFlowState *, uint32_t site, uint32_t function,
                                   const uint16_t *references, uint16_t count);
NvmWebSocketFlowStatus nvm_websocket_flow_move(NvmWebSocketFlowState *, uint16_t from, uint16_t to);
NvmWebSocketFlowStatus nvm_websocket_flow_take(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_put(NvmWebSocketFlowState *, uint16_t);

NvmWebSocketFlowStatus nvm_websocket_flow_drop_local(NvmWebSocketFlowState *, uint16_t);
NvmWebSocketFlowStatus nvm_websocket_flow_drop_stack(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_region_begin(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_region_end(NvmWebSocketFlowState *);
NvmWebSocketFlowStatus nvm_websocket_flow_borrow(NvmWebSocketFlowState *, uint16_t local, uint16_t reference);
NvmWebSocketFlowStatus nvm_websocket_flow_borrow_shared(NvmWebSocketFlowState *,uint16_t local,uint16_t reference);
NvmWebSocketFlowStatus nvm_websocket_flow_end_borrow(NvmWebSocketFlowState *, uint16_t reference);



NvmWebSocketFlowStatus nvm_websocket_flow_can_exit(const NvmWebSocketFlowState *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    TAG_VOID = 0x00,
    TAG_INT = 0x01,
    TAG_U8 = 0x02,
    TAG_FLOAT = 0x03,
    TAG_BOOL = 0x04,
    TAG_STRING = 0x05,
    TAG_BSTRING = 0x06,
    TAG_ARRAY = 0x07,
    TAG_STRUCT = 0x08,
    TAG_ENUM = 0x09,
    TAG_UNION = 0x0A,
    TAG_FUNCTION = 0x0B,
    TAG_TUPLE = 0x0C,
    TAG_HASHMAP = 0x0D,
    TAG_OPAQUE = 0x0E,
    TAG_CLOSURE = 0x0F,

    TAG_COUNT = 0x10
} NanoValueTag;






typedef enum {

    OP_NOP = 0x00,
    OP_PUSH_I64 = 0x01,
    OP_PUSH_F64 = 0x02,
    OP_PUSH_BOOL = 0x03,
    OP_PUSH_STR = 0x04,
    OP_PUSH_VOID = 0x05,
    OP_PUSH_U8 = 0x06,
    OP_DUP = 0x07,
    OP_POP = 0x08,
    OP_SWAP = 0x09,
    OP_ROT3 = 0x0A,


    OP_OWN_MOVE_LOCAL = 0x0B,
    OP_OWN_STORE_LOCAL = 0x0C,
    OP_OWN_PACK = 0x0D,
    OP_OWN_UNPACK_LOCAL = 0x0E,
    OP_CALL_REF = 0x0F,


    OP_LOAD_LOCAL = 0x10,
    OP_STORE_LOCAL = 0x11,
    OP_LOAD_GLOBAL = 0x12,
    OP_STORE_GLOBAL = 0x13,
    OP_LOAD_UPVALUE = 0x14,
    OP_STORE_UPVALUE = 0x15,


    OP_REGION_BEGIN = 0x16,
    OP_REGION_END = 0x17,
    OP_BORROW_LOCAL_SHARED = 0x18,
    OP_BORROW_LOCAL_EXCLUSIVE = 0x19,
    OP_REF_GET = 0x1A,
    OP_REF_SET = 0x1B,

    OP_BORROW_PATH_SHARED = 0x1C,
    OP_BORROW_PATH_EXCLUSIVE = 0x1D,
    OP_REBORROW_SHARED = 0x1E,
    OP_REBORROW_EXCLUSIVE = 0x1F,


    OP_ADD = 0x20,
    OP_SUB = 0x21,
    OP_MUL = 0x22,
    OP_DIV = 0x23,
    OP_MOD = 0x24,
    OP_NEG = 0x25,


    OP_EQ = 0x28,
    OP_NE = 0x29,
    OP_LT = 0x2A,
    OP_LE = 0x2B,
    OP_GT = 0x2C,
    OP_GE = 0x2D,


    OP_AND = 0x30,
    OP_OR = 0x31,
    OP_NOT = 0x32,
    OP_TAIL_CALL = 0x33,


    OP_JMP = 0x38,
    OP_JMP_TRUE = 0x39,
    OP_JMP_FALSE = 0x3A,
    OP_CALL = 0x3B,




    OP_CALL_INDIRECT = 0x3C,
    OP_RET = 0x3D,
    OP_CALL_EXTERN = 0x3E,
    OP_CALL_MODULE = 0x3F,


    OP_STR_LEN = 0x40,
    OP_STR_CONCAT = 0x41,
    OP_STR_SUBSTR = 0x42,
    OP_STR_CONTAINS = 0x43,
    OP_STR_EQ = 0x44,
    OP_STR_CHAR_AT = 0x45,
    OP_STR_FROM_INT = 0x46,
    OP_STR_FROM_FLOAT = 0x47,
    OP_STR_TRIM = 0x48,
    OP_STR_TO_LOWER = 0x49,
    OP_STR_TO_UPPER = 0x4A,
    OP_STR_STARTS_WITH = 0x4B,
    OP_STR_ENDS_WITH = 0x4C,
    OP_STR_SPLIT = 0x4D,
    OP_STR_REPLACE = 0x4E,


    OP_ARR_NEW = 0x50,
    OP_ARR_PUSH = 0x51,
    OP_ARR_POP = 0x52,
    OP_ARR_GET = 0x53,
    OP_ARR_SET = 0x54,
    OP_ARR_LEN = 0x55,
    OP_ARR_SLICE = 0x56,
    OP_ARR_REMOVE = 0x57,
    OP_ARR_LITERAL = 0x58,


    OP_STRUCT_NEW = 0x60,
    OP_STRUCT_GET = 0x61,
    OP_STRUCT_SET = 0x62,
    OP_STRUCT_LITERAL = 0x63,


    OP_UNION_CONSTRUCT = 0x68,
    OP_UNION_TAG = 0x69,
    OP_UNION_FIELD = 0x6A,
    OP_MATCH_TAG = 0x6B,
    OP_ENUM_VAL = 0x6C,


    OP_TUPLE_NEW = 0x70,
    OP_TUPLE_GET = 0x71,


    OP_HM_NEW = 0x78,
    OP_HM_GET = 0x79,
    OP_HM_SET = 0x7A,
    OP_HM_HAS = 0x7B,
    OP_HM_DELETE = 0x7C,
    OP_HM_KEYS = 0x7D,
    OP_HM_VALUES = 0x7E,
    OP_HM_LEN = 0x7F,


    OP_GC_RETAIN = 0x80,
    OP_GC_RELEASE = 0x81,


    OP_CAST_INT = 0x88,
    OP_F64_FROM_BITS = 0x8D,
    OP_F64_TO_BITS = 0x8E,
    OP_CAST_FLOAT = 0x89,
    OP_CAST_BOOL = 0x8A,
    OP_CAST_STRING = 0x8B,
    OP_TYPE_CHECK = 0x8C,
    OP_CAST_U8 = 0x8F,


    OP_CLOSURE_NEW = 0x90,


    OP_PRINT = 0xA0,
    OP_ASSERT = 0xA1,
    OP_DEBUG_LINE = 0xA2,
    OP_HANDLER_PUSH = 0xa5,
    OP_HANDLER_POP = 0xa6,
    OP_PERFORM = 0xa7,
    OP_EFFECT_RESUME = 0xa8,
    OP_HALT = 0xA3,
    OP_PRINTLN = 0xA4,


    OP_OPAQUE_NULL = 0xB0,
    OP_OPAQUE_VALID = 0xB1,
    OP_MEM_LOAD8 = 0xB2,
    OP_MEM_LOAD16 = 0xB3,
    OP_MEM_LOAD32 = 0xB4,
    OP_MEM_LOAD64 = 0xB5,
    OP_MEM_STORE8 = 0xB6,
    OP_MEM_STORE16 = 0xB7,
    OP_MEM_STORE32 = 0xB8,
    OP_MEM_STORE64 = 0xB9,


    OP_FILE_SERVICE = 0x91,
    OP_FILE_RESULT_BRANCH = 0x92,
    OP_FILE_RESULT_TAKE = 0x93,
    OP_FILE_DROP_LOCAL = 0x94,
    OP_FILE_DROP_STACK = 0x95,
    OP_FILE_END_BORROW = 0x96,
    OP_FILE_CALL_REFS = 0x97,
    OP_FILE_CALL_INDIRECT_REFS = 0x98,


    OP_I64_ADD = 0xC0,
    OP_I64_SUB = 0xC1,
    OP_I64_MUL = 0xC2,
    OP_I64_DIV_S = 0xC3,
    OP_I64_REM_S = 0xC4,
    OP_I64_NEG = 0xC5,
    OP_F64_ADD = 0xC8,
    OP_F64_SUB = 0xC9,
    OP_F64_MUL = 0xCA,
    OP_F64_DIV = 0xCB,
    OP_F64_NEG = 0xCC,

    OP_I64_EQ = 0xD0,
    OP_I64_NE = 0xD1,
    OP_I64_LT_S = 0xD2,
    OP_I64_LE_S = 0xD3,
    OP_I64_GT_S = 0xD4,
    OP_I64_GE_S = 0xD5,
    OP_F64_EQ = 0xD8,
    OP_F64_NE = 0xD9,
    OP_F64_LT = 0xDA,
    OP_F64_LE = 0xDB,
    OP_F64_GT = 0xDC,
    OP_F64_GE = 0xDD,
    OP_BOOL_AND = 0xE0,
    OP_BOOL_OR = 0xE1,
    OP_BOOL_NOT = 0xE2,
    OP_I64_DIV_U = 0xE3,
    OP_I64_REM_U = 0xE4,
    OP_I64_LT_U = 0xE5,
    OP_I64_LE_U = 0xE6,
    OP_I64_GT_U = 0xE7,
    OP_I64_GE_U = 0xE8,
    OP_I64_AND = 0xE9,
    OP_I64_OR = 0xEA,
    OP_I64_XOR = 0xEB,
    OP_I64_INVERT = 0xEC,
    OP_I64_SHL = 0xED,
    OP_I64_SHR_S = 0xEE,
    OP_I64_SHR_U = 0xEF,
    OP_I64_ADD_CARRY = 0xF0,
    OP_I64_SUB_BORROW = 0xF1,
    OP_I64_MUL_WIDE_S = 0xF2,
    OP_I64_MUL_WIDE_U = 0xF3,
    OP_PICK = 0xF4,
    OP_ROLL = 0xF5,
    OP_ARRAY_ADD = 0xF6,
    OP_ARRAY_SUB = 0xF7,
    OP_ARRAY_MUL = 0xF8,
    OP_ARRAY_DIV = 0xF9,
    OP_FUNCREF = 0xFA,
    OP_AGG_PACK = 0xFB,
    OP_AGG_GET = 0xFC,
    OP_AGG_SET = 0xFD,
    OP_AGG_TAG = 0xFE,





    OP_EXTENSION_PREFIX = 0xFF
} NanoOpcode;
# 305 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef enum {
    AGG_RECORD = 0,
    AGG_VARIANT = 1,
    AGG_TUPLE = 2
} NanoAggregateKind;





typedef enum {
    OPERAND_NONE,
    OPERAND_U8,
    OPERAND_U16,
    OPERAND_U32,
    OPERAND_I32,
    OPERAND_I64,
    OPERAND_F64
} OperandType;
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} InstructionInfo;

typedef struct {
    const char *name;
    uint8_t code;
} NanoisaSchemaTag;

typedef struct {
    const char *name;
    uint8_t opcode;
    uint8_t operand_count;
    OperandType operands[4];
    int8_t pop_count;
    int8_t push_count;
} NanoisaSchemaOpcode;

typedef struct {
    const char *name;
    const char *meaning;
    const char *ownership;
    const char *justification;

    uint8_t operand_count;
    uint8_t pop_count;
    uint8_t push_count;
} NanoisaV2Family;

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/generated_schema.h"
static const NanoisaSchemaTag nanoisa_schema_tags[] = {
    {"void", 0x00},
    {"i64", 0x01},
    {"u8", 0x02},
    {"f64", 0x03},
    {"bool", 0x04},
    {"string", 0x05},
    {"bstring", 0x06},
    {"array", 0x07},
    {"record", 0x08},
    {"enum", 0x09},
    {"variant", 0x0a},
    {"funcref", 0x0b},
    {"tuple", 0x0c},
    {"hashmap", 0x0d},
    {"opaque", 0x0e},
    {"closure", 0x0f},
};

static const NanoisaSchemaOpcode nanoisa_schema_opcodes[] = {
    {"HANDLER_PUSH", 0xa5, 4, {OPERAND_U32, OPERAND_I32, OPERAND_U16, OPERAND_U16}, 0, 0},
    {"HANDLER_POP", 0xa6, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PERFORM", 0xa7, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"EFFECT_RESUME", 0xa8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"NOP", 0x00, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PUSH_I64", 0x01, 1, {OPERAND_I64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_F64", 0x02, 1, {OPERAND_F64, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_BOOL", 0x03, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_STR", 0x04, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_VOID", 0x05, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"PUSH_U8", 0x06, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"DUP", 0x07, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 2},
    {"POP", 0x08, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"SWAP", 0x09, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"ROT3", 0x0a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 3},
    {"FILE_SERVICE", 0x91, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_RESULT_BRANCH", 0x92, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_RESULT_TAKE", 0x93, 2, {OPERAND_U16, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"FILE_DROP_LOCAL", 0x94, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"FILE_DROP_STACK", 0x95, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"FILE_CALL_REFS", 0x97, 2, {OPERAND_U32, OPERAND_U32, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"FILE_CALL_INDIRECT_REFS", 0x98, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, -1, 1},
    {"FILE_END_BORROW", 0x96, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"OWN_MOVE_LOCAL", 0x0b, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OWN_STORE_LOCAL", 0x0c, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OWN_PACK", 0x0d, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, 1},
    {"OWN_UNPACK_LOCAL", 0x0e, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, -1},
    {"CALL_REF", 0x0f, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"LOAD_LOCAL", 0x10, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_LOCAL", 0x11, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_GLOBAL", 0x12, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_GLOBAL", 0x13, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"LOAD_UPVALUE", 0x14, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STORE_UPVALUE", 0x15, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"REGION_BEGIN", 0x16, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REGION_END", 0x17, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_SHARED", 0x18, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"BORROW_LOCAL_EXCLUSIVE", 0x19, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REF_GET", 0x1a, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"REF_SET", 0x1b, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"BORROW_PATH_SHARED", 0x1c, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"BORROW_PATH_EXCLUSIVE", 0x1d, 3, {OPERAND_U16, OPERAND_U16, OPERAND_U32, OPERAND_NONE}, 0, 0},
    {"REBORROW_SHARED", 0x1e, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"REBORROW_EXCLUSIVE", 0x1f, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ADD", 0x20, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"SUB", 0x21, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MUL", 0x22, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"DIV", 0x23, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"MOD", 0x24, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NEG", 0x25, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"EQ", 0x28, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NE", 0x29, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LT", 0x2a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"LE", 0x2b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GT", 0x2c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"GE", 0x2d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AND", 0x30, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"OR", 0x31, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"NOT", 0x32, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TAIL_CALL", 0x33, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"JMP", 0x38, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"JMP_TRUE", 0x39, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"JMP_FALSE", 0x3a, 1, {OPERAND_I32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CALL", 0x3b, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_INDIRECT", 0x3c, 2, {OPERAND_U16, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"RET", 0x3d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_EXTERN", 0x3e, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"CALL_MODULE", 0x3f, 4, {OPERAND_U32, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"STR_LEN", 0x40, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_CONCAT", 0x41, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SUBSTR", 0x42, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"STR_CONTAINS", 0x43, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_EQ", 0x44, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_CHAR_AT", 0x45, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_FROM_INT", 0x46, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_FROM_FLOAT", 0x47, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TRIM", 0x48, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_LOWER", 0x49, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_TO_UPPER", 0x4a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STR_STARTS_WITH", 0x4b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_ENDS_WITH", 0x4c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_SPLIT", 0x4d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STR_REPLACE", 0x4e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_NEW", 0x50, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"ARR_PUSH", 0x51, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_POP", 0x52, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_GET", 0x53, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_SET", 0x54, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_LEN", 0x55, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"ARR_SLICE", 0x56, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"ARR_REMOVE", 0x57, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARR_LITERAL", 0x58, 2, {OPERAND_U8, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"STRUCT_NEW", 0x60, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"STRUCT_GET", 0x61, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"STRUCT_SET", 0x62, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"STRUCT_LITERAL", 0x63, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"UNION_CONSTRUCT", 0x68, 3, {OPERAND_U32, OPERAND_U16, OPERAND_U16, OPERAND_NONE}, -1, -1},
    {"UNION_TAG", 0x69, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"UNION_FIELD", 0x6a, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MATCH_TAG", 0x6b, 2, {OPERAND_U16, OPERAND_I32, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"ENUM_VAL", 0x6c, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"TUPLE_NEW", 0x70, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"TUPLE_GET", 0x71, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_NEW", 0x78, 2, {OPERAND_U8, OPERAND_U8, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"HM_GET", 0x79, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_SET", 0x7a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 1},
    {"HM_HAS", 0x7b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_DELETE", 0x7c, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"HM_KEYS", 0x7d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_VALUES", 0x7e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"HM_LEN", 0x7f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RETAIN", 0x80, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"GC_RELEASE", 0x81, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"CAST_INT", 0x88, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_FLOAT", 0x89, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_BOOL", 0x8a, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_STRING", 0x8b, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"TYPE_CHECK", 0x8c, 1, {OPERAND_U8, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_FROM_BITS", 0x8d, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_TO_BITS", 0x8e, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CAST_U8", 0x8f, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"CLOSURE_NEW", 0x90, 2, {OPERAND_U32, OPERAND_U16, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"PRINT", 0xa0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"ASSERT", 0xa1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"DEBUG_LINE", 0xa2, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"HALT", 0xa3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0},
    {"PRINTLN", 0xa4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 0},
    {"OPAQUE_NULL", 0xb0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"OPAQUE_VALID", 0xb1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD8", 0xb2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD16", 0xb3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD32", 0xb4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_LOAD64", 0xb5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"MEM_STORE8", 0xb6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE16", 0xb7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE32", 0xb8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"MEM_STORE64", 0xb9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 0},
    {"I64_ADD", 0xc0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SUB", 0xc1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_MUL", 0xc2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_DIV_S", 0xc3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_S", 0xc4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NEG", 0xc5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"F64_ADD", 0xc8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_SUB", 0xc9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_MUL", 0xca, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_DIV", 0xcb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NEG", 0xcc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_EQ", 0xd0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_NE", 0xd1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_S", 0xd2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_S", 0xd3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_S", 0xd4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_S", 0xd5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_EQ", 0xd8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_NE", 0xd9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LT", 0xda, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_LE", 0xdb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GT", 0xdc, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"F64_GE", 0xdd, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_AND", 0xe0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_OR", 0xe1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"BOOL_NOT", 0xe2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_DIV_U", 0xe3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_REM_U", 0xe4, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LT_U", 0xe5, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_LE_U", 0xe6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GT_U", 0xe7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_GE_U", 0xe8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_AND", 0xe9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_OR", 0xea, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_XOR", 0xeb, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_INVERT", 0xec, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"I64_SHL", 0xed, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_S", 0xee, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_SHR_U", 0xef, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"I64_ADD_CARRY", 0xf0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_SUB_BORROW", 0xf1, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 3, 2},
    {"I64_MUL_WIDE_S", 0xf2, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"I64_MUL_WIDE_U", 0xf3, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 2},
    {"PICK", 0xf4, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ROLL", 0xf5, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, -1, -1},
    {"ARRAY_ADD", 0xf6, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_SUB", 0xf7, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_MUL", 0xf8, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"ARRAY_DIV", 0xf9, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"FUNCREF", 0xfa, 1, {OPERAND_U32, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 1},
    {"AGG_PACK", 0xfb, 4, {OPERAND_U8, OPERAND_U32, OPERAND_U16, OPERAND_U16}, -1, -1},
    {"AGG_GET", 0xfc, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
    {"AGG_SET", 0xfd, 1, {OPERAND_U16, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 2, 1},
    {"AGG_TAG", 0xfe, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 1, 1},
};


static const NanoisaSchemaOpcode nanoisa_extended_opcodes[1] = { {0, 0, 0, {OPERAND_NONE, OPERAND_NONE, OPERAND_NONE, OPERAND_NONE}, 0, 0} };

static const NanoisaV2Family nanoisa_v2_families[] = {
    {"const.i64", "Push a signed 64-bit integer literal.", "none", "core-semantics", 1, 0, 1},
    {"const.f64", "Push a 64-bit IEEE-754 float literal.", "none", "core-semantics", 1, 0, 1},
    {"const.pool", "Push a constant loaded from the constant pool.", "retain", "representation", 1, 0, 1},
    {"drop", "Discard the top stack value.", "release", "execution-substrate", 0, 1, 0},
    {"dup", "Duplicate the top stack value.", "retain", "execution-substrate", 0, 1, 2},
    {"swap", "Exchange the top two stack values.", "move", "execution-substrate", 0, 2, 2},
    {"pick", "Copy the value at a stack depth to the top.", "retain", "execution-substrate", 1, 0, 1},
    {"roll", "Rotate the value at a stack depth to the top.", "move", "execution-substrate", 1, 0, 0},
    {"local.get", "Read an indexed frame local onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"local.set", "Store the top value into an indexed frame local.", "move", "execution-substrate", 1, 1, 0},
    {"global.get", "Read an indexed global onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"global.set", "Store the top value into an indexed global.", "move", "execution-substrate", 1, 1, 0},
    {"upvalue.get", "Read a captured upvalue onto the stack.", "retain", "execution-substrate", 1, 0, 1},
    {"upvalue.set", "Store the top value into a captured upvalue.", "move", "execution-substrate", 1, 1, 0},
    {"i64.add", "Add two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.sub", "Subtract the top integer from the next.", "none", "core-semantics", 0, 2, 1},
    {"i64.mul", "Multiply two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-s", "Divide two integers as signed.", "none", "core-semantics", 0, 2, 1},
    {"i64.div-u", "Divide two integers as unsigned.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-s", "Take the signed remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.rem-u", "Take the unsigned remainder of two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.and", "Bitwise AND two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.or", "Bitwise OR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.xor", "Bitwise XOR two integers.", "none", "core-semantics", 0, 2, 1},
    {"i64.shl", "Shift an integer left by a count.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-s", "Arithmetic (sign-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.shr-u", "Logical (zero-filling) shift an integer right.", "none", "core-semantics", 0, 2, 1},
    {"i64.add-carry", "Add two integers with an incoming carry, producing sum and carry.", "none", "core-semantics", 0, 3, 2},
    {"i64.sub-borrow", "Subtract two integers with an incoming borrow, producing difference and borrow.", "none", "core-semantics", 0, 3, 2},
    {"i64.mul-wide-s", "Multiply two integers as signed into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"i64.mul-wide-u", "Multiply two integers as unsigned into a 128-bit high/low pair.", "none", "core-semantics", 0, 2, 2},
    {"f64.from-bits", "Copy an exact i64 bit pattern to f64 without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.to-bits", "Copy exact f64 bits to a signed i64 bit pattern without arithmetic or NaN quieting.", "none", "representation", 0, 1, 1},
    {"f64.add", "Add two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.sub", "Subtract the top binary64 float from the next with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.mul", "Multiply two binary64 floats with separate default rounding; canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"f64.div", "Divide two binary64 floats with separate default rounding; either zero divisor returns positive zero first, otherwise canonicalize a NaN result to bits 0x7ff8000000000000.", "none", "core-semantics", 0, 2, 1},
    {"mem.load8", "Load 8 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load16", "Load 16 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load32", "Load 32 bits from memory, zero-extended to an integer.", "none", "representation", 2, 1, 1},
    {"mem.load64", "Load 64 bits from memory into an integer.", "none", "representation", 2, 1, 1},
    {"mem.store8", "Store the low 8 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store16", "Store the low 16 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store32", "Store the low 32 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"mem.store64", "Store all 64 bits of an integer to memory.", "none", "representation", 2, 2, 0},
    {"aggregate.pack", "Pack stacked fields into an aggregate of a declared layout.", "move", "representation", 2, 1, 1},
    {"aggregate.get", "Read a field out of an aggregate.", "retain", "representation", 1, 1, 1},
    {"aggregate.set", "Write a field into an aggregate, yielding the updated aggregate.", "move", "representation", 1, 2, 1},
    {"aggregate.tag", "Read the discriminant tag of an aggregate.", "none", "representation", 0, 1, 1},
    {"branch", "Jump unconditionally to a relative target.", "none", "control-flow", 1, 0, 0},
    {"branch.zero", "Jump to a relative target when the top integer is zero.", "none", "control-flow", 1, 1, 0},
    {"branch.nonzero", "Jump to a relative target when the top integer is nonzero.", "none", "control-flow", 1, 1, 0},
    {"call", "Call a function by index using its declared signature.", "call", "control-flow", 1, 1, 1},
    {"call.indirect", "Call a callable value against a declared signature.", "call", "control-flow", 1, 2, 1},
    {"tail.call", "Replace the current frame with a call to a function by index.", "call", "control-flow", 1, 1, 1},
    {"call.import", "Call an imported host function by index.", "trap", "host-boundary", 1, 1, 1},
    {"return", "Return from the current function with its signature result.", "return", "control-flow", 0, 1, 0},
    {"trap.print", "Write the top value to standard output through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.println", "Write the top value and a newline through the host trap boundary.", "trap", "host-boundary", 0, 1, 0},
    {"trap.assert", "Raise an assertion failure unless the top boolean is true.", "trap", "host-boundary", 0, 1, 0},
    {"trap.halt", "Stop execution through the host trap boundary.", "trap", "host-boundary", 0, 0, 0},
    {"trap.host", "Call an imported host function through the typed trap boundary.", "trap", "host-boundary", 1, 1, 1},
    {"trap.dispatch", "Raise a typed extensible trap with an explicit argument count.", "trap", "host-boundary", 2, 1, 1},
    {"const.i64.small", "Push a small signed 64-bit integer using its compact encoding.", "none", "encoding", 1, 0, 1},
    {"local.get.short", "Read a short-indexed frame local onto the stack.", "retain", "encoding", 1, 0, 1},
    {"local.set.short", "Store the top value into a short-indexed frame local.", "move", "encoding", 1, 1, 0},
    {"pick.compact", "Copy a compactly encoded stack-depth value to the top.", "retain", "encoding", 1, 0, 1},
    {"roll.compact", "Rotate a compactly encoded stack-depth value to the top.", "move", "encoding", 1, 0, 0},
    {"global.get.compact", "Read a compactly indexed global onto the stack.", "retain", "encoding", 1, 0, 1},
    {"global.set.compact", "Store the top value into a compactly indexed global.", "move", "encoding", 1, 1, 0},
    {"aggregate.get.compact", "Read a compactly indexed field out of an aggregate.", "retain", "encoding", 1, 1, 1},
    {"aggregate.set.compact", "Write a compactly indexed field into an aggregate.", "move", "encoding", 1, 2, 1},
};
# 367 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 2
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
_Static_assert(0xff == OP_EXTENSION_PREFIX,
               "extension prefix must match the reserved opcode byte");
_Static_assert(0xff == 0xff,
               "primary opcode plane ends exactly at the extension prefix");
_Static_assert(OP_AGG_TAG < 0xff,
               "the last primary opcode must stay below the plane limit");






typedef struct {
    uint8_t opcode;
    uint8_t operand_count;
    union {
        uint8_t u8;
        uint16_t u16;
        uint32_t u32;
        int32_t i32;
        int64_t i64;
        double f64;
    } operands[4];
    OperandType operand_types[4];
    uint32_t byte_length;
} DecodedInstruction;






const InstructionInfo *isa_get_info(uint8_t opcode);


const char *isa_tag_name(uint8_t tag);




uint32_t isa_encode(const DecodedInstruction *instr, uint8_t *buf, size_t buf_size);



uint32_t isa_decode(const uint8_t *buf, size_t buf_size, DecodedInstruction *out);


uint32_t isa_operand_size(OperandType type);






# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 429 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_file_opcode(uint8_t opcode);

static inline 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
             _Bool 
# 431 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
                  isa_is_file_indirect_call(uint8_t opcode) {
    return opcode==OP_CALL_INDIRECT || opcode==OP_FILE_CALL_INDIRECT_REFS;
}



# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_code_has_file_instructions(const uint8_t *code,size_t size);


int isa_opcode_by_name(const char *name);





# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h" 3 4
_Bool 
# 444 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/isa.h"
    isa_is_extension_prefix(uint8_t opcode);



const InstructionInfo *isa_get_extended_info(uint8_t ext_opcode);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 2
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
typedef struct NvmWebSocketCodePlan NvmWebSocketCodePlan;
typedef struct {
    uint32_t byte_offset;
    DecodedInstruction decoded;
    uint16_t successors[2];
    uint8_t successor_count;
    uint16_t call_references[256u];
    uint32_t catalog_ordinal;
} NvmWebSocketCodeInstruction;
typedef struct {
    uint32_t code_offset, code_length;
    uint16_t instruction_count;
    NvmWebSocketFlowFunction declaration;
} NvmWebSocketCodeFunction;
NvmWebSocketFlowStatus nvm_websocket_code_prepare(const NvmModule *, NvmWebSocketCodePlan **out);
void nvm_websocket_code_free(NvmWebSocketCodePlan *);
uint32_t nvm_websocket_code_function_count(const NvmWebSocketCodePlan *);


# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
    nvm_websocket_code_function(const NvmWebSocketCodePlan *, uint32_t, NvmWebSocketCodeFunction *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
    nvm_websocket_code_local(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                         NvmWebSocketFlowDeclaration *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
    nvm_websocket_code_instruction(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                               NvmWebSocketCodeInstruction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
    nvm_websocket_code_instruction_order(const NvmWebSocketCodePlan *, uint32_t, uint16_t,
                                     uint16_t *);


# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_code.h"
    nvm_websocket_code_function_order(const NvmWebSocketCodePlan *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 2




typedef struct NvmWebSocketBodyReport NvmWebSocketBodyReport;
typedef enum {
    NVM_WEBSOCKET_BODY_CLEANUP_NORMAL, NVM_WEBSOCKET_BODY_CLEANUP_DROP_LOCAL,
    NVM_WEBSOCKET_BODY_CLEANUP_DROP_STACK, NVM_WEBSOCKET_BODY_CLEANUP_ASSERT,
    NVM_WEBSOCKET_BODY_CLEANUP_RETURN, NVM_WEBSOCKET_BODY_CLEANUP_CALL,
    NVM_WEBSOCKET_BODY_CLEANUP_SERVICE
} NvmWebSocketBodyCleanup;
typedef struct {
    
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 3 4
   _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h"
        reachable, exit_checked, refinement, has_obligation;
    uint16_t input_stack, output_stack, cleanup_local;
    NvmWebSocketBodyCleanup cleanup;
    uint32_t discharged_checks, pending_checks;
    NvmWebSocketFlowObligation obligation;
} NvmWebSocketBodyInstruction;
NvmWebSocketFlowStatus nvm_websocket_body_analyze(const NvmModule *, NvmWebSocketBodyReport **out);
void nvm_websocket_body_free(NvmWebSocketBodyReport *);
uint32_t nvm_websocket_body_function_count(const NvmWebSocketBodyReport *);

# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h"
    nvm_websocket_body_function(const NvmWebSocketBodyReport *, uint32_t, NvmWebSocketCodeFunction *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h"
    nvm_websocket_body_local(const NvmWebSocketBodyReport *, uint32_t, uint16_t, NvmWebSocketFlowDeclaration *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_body.h"
    nvm_websocket_body_instruction(const NvmWebSocketBodyReport *, uint32_t, uint16_t,
                              NvmWebSocketCodeInstruction *, NvmWebSocketBodyInstruction *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 2


typedef struct NvmWebSocketHostedPlan NvmWebSocketHostedPlan;
typedef struct {
    uint32_t entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t allocation_bound;
} NvmWebSocketHostedStartup;
typedef struct {
    NvmWebSocketCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
} NvmWebSocketHostedFunction;






NvmWebSocketFlowStatus nvm_websocket_hosted_prepare(const uint8_t *,size_t,NvmWebSocketHostedPlan **);
void nvm_websocket_hosted_free(NvmWebSocketHostedPlan *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_startup(const NvmWebSocketHostedPlan *,NvmWebSocketHostedStartup *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_function(const NvmWebSocketHostedPlan *,uint32_t,NvmWebSocketHostedFunction *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_local(const NvmWebSocketHostedPlan *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_instruction(const NvmWebSocketHostedPlan *,uint32_t,uint16_t,
                                NvmWebSocketCodeInstruction *,NvmWebSocketBodyInstruction *);


# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_type(const NvmWebSocketHostedPlan *,uint32_t,NvmWebSocketNominalLayout *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_hosted.h"
    nvm_websocket_hosted_import(const NvmWebSocketHostedPlan *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 2


typedef struct NlWsTransport NlWsTransport;
typedef enum {
    NL_WS_TRANSPORT_OK, NL_WS_TRANSPORT_ARGUMENT, NL_WS_TRANSPORT_RIGHTS,
    NL_WS_TRANSPORT_MEMORY, NL_WS_TRANSPORT_LIMIT, NL_WS_TRANSPORT_TIMEOUT,
    NL_WS_TRANSPORT_IO, NL_WS_TRANSPORT_PROTOCOL, NL_WS_TRANSPORT_CRYPTO,
    NL_WS_TRANSPORT_CLOSED
} NlWsTransportStatus;
typedef struct {
    NlWsTransportStatus status;
    int host_errno,resolver_error,supervisor_status,close_code,cleanup_errno;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
        cleanup_failed,closure_unknown,terminal;
    size_t bytes;
} NlWsTransportResult;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
        allow_network,allow_lookup;
    const char *resolver_helper;
    unsigned max_timeout_ms;
} NlWsTransportPolicy;
typedef struct { 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
                _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
                     binary; unsigned char *bytes; size_t length; } NlWsMessage;
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_storage_bound(size_t *out);
NlWsTransportResult nl_ws_transport_connect(const void *url,size_t length,
    const NlWsTransportPolicy *,unsigned timeout_ms,NlWsTransport **out);
NlWsTransportResult nl_ws_transport_send(NlWsTransport *,
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
                                                        _Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
                                                             binary,
    const void *bytes,size_t length,unsigned timeout_ms);


NlWsTransportResult nl_ws_transport_receive(NlWsTransport *,unsigned timeout_ms,NlWsMessage *out);
void nl_ws_message_free(NlWsMessage *);


NlWsTransportResult nl_ws_transport_close(NlWsTransport *,unsigned timeout_ms);

NlWsTransportResult nl_ws_transport_abort(NlWsTransport *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_transport.h"
    nl_ws_transport_connected(const NlWsTransport *);
const char *nl_ws_transport_error(const NlWsTransport *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 2





typedef struct NlWsValues NlWsValues;
typedef enum {
    NL_WS_VALUE_OK, NL_WS_VALUE_ARGUMENT, NL_WS_VALUE_STALE, NL_WS_VALUE_TYPE,
    NL_WS_VALUE_BORROWED, NL_WS_VALUE_LIMIT, NL_WS_VALUE_MEMORY,
    NL_WS_VALUE_DISPOSED, NL_WS_VALUE_STATE, NL_WS_VALUE_STATUS_COUNT
} NlWsValueStatus;
typedef struct { uint64_t invocation,generation; uint32_t slot; } NlWsValue;
typedef struct { NlWsValue value; uint64_t epoch; } NlWsValueBorrow;
typedef struct { 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                     ok; NlWsTransportResult error; } NlWsConnectView;
typedef struct {
    NlWsValueStatus execution;
    uint64_t cleanup_failures;
    NlWsTransportResult first_cleanup,next_cleanup;
} NlWsValuesFinish;
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
NlWsValueStatus nl_ws_values_create_bounded(const NlWsTransportPolicy *,size_t,NlWsValues **out);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
    nl_ws_values_minimum_storage(size_t *out);
NlWsValueStatus nl_ws_values_create(const NlWsTransportPolicy *,NlWsValues **out);
NlWsValueStatus nl_ws_values_connect(NlWsValues *,const void *,size_t,int64_t,NlWsValue *out);
NlWsValueStatus nl_ws_connect_view(NlWsValues *,const NlWsValue *,NlWsConnectView *out);
NlWsValueStatus nl_ws_connect_take_ok(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_connect_take_error(NlWsValues *,NlWsValue *,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_move(NlWsValues *,NlWsValue *,NlWsValue *out);
NlWsValueStatus nl_ws_value_borrow(NlWsValues *,const NlWsValue *,NlWsValueBorrow *out);
NlWsValueStatus nl_ws_value_end_borrow(NlWsValues *,NlWsValueBorrow *);
NlWsValueStatus nl_ws_value_send(NlWsValues *,const NlWsValueBorrow *,
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                                                                     _Bool
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                                                                         ,
    const void *,size_t,int64_t,NlWsTransportResult *out);


NlWsValueStatus nl_ws_value_receive(NlWsValues *,const NlWsValueBorrow *,int64_t,
    NlWsMessage *message,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_close(NlWsValues *,NlWsValue *,int64_t,NlWsTransportResult *out);
NlWsValueStatus nl_ws_value_drop(NlWsValues *,NlWsValue *);
NlWsValueStatus nl_ws_value_validate(NlWsValues *,const NlWsValue *,
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
                                                                   _Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
                                                                        connect_result);
NlWsValueStatus nl_ws_value_borrow_validate(NlWsValues *,const NlWsValueBorrow *);
NlWsValueStatus nl_ws_values_live_slots(NlWsValues *,uint64_t *owners,uint64_t *borrowed);

# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_values.h"
    nl_ws_values_report(const NlWsValues *,NlWsValuesFinish *out);



NlWsValuesFinish nl_ws_values_finish(NlWsValues *,NlWsValueStatus);
NlWsValuesFinish nl_ws_values_destroy(NlWsValues *,NlWsValueStatus);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
typedef enum { NVM_WEBSOCKET_RUNTIME_VM, NVM_WEBSOCKET_RUNTIME_NATIVE } NvmWebSocketRuntimeMode;
typedef enum {
    NVM_WEBSOCKET_RUNTIME_OK, NVM_WEBSOCKET_RUNTIME_INVALID, NVM_WEBSOCKET_RUNTIME_UNRESOLVED,
    NVM_WEBSOCKET_RUNTIME_LIMIT, NVM_WEBSOCKET_RUNTIME_MEMORY, NVM_WEBSOCKET_RUNTIME_STATE,
    NVM_WEBSOCKET_RUNTIME_TYPE, NVM_WEBSOCKET_RUNTIME_STALE, NVM_WEBSOCKET_RUNTIME_BORROWED,
    NVM_WEBSOCKET_RUNTIME_ASSERT, NVM_WEBSOCKET_RUNTIME_CLEANUP, NVM_WEBSOCKET_RUNTIME_BUSY
} NvmWebSocketRuntimeStatus;
typedef struct {
    
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
   _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
        initialized, owning, formal;
    NvmWebSocketFlowDeclaration type;
    NvmWebSocketFlowArm arm;
    uint8_t fields;
    int64_t values[9u];
} NvmWebSocketRuntimeView;
typedef struct {
    NvmWebSocketRuntimeStatus status;
    
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
   _Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
        acquired;
    NlWsValueStatus core_status;
    uint32_t function, instruction;
    NlWsValuesFinish cleanup;
} NvmWebSocketRuntimeReport;
typedef struct {
    size_t allocation_bound;
    uint32_t values, references, regions;
    uint16_t frames;
} NvmWebSocketRuntimeStorage;
typedef struct NvmWebSocketRuntime NvmWebSocketRuntime;


NvmWebSocketRuntimeStatus nvm_websocket_runtime_create(const uint8_t *,size_t,NvmWebSocketRuntimeMode,NvmWebSocketRuntime **out);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_storage(const NvmWebSocketRuntime *,NvmWebSocketRuntimeStorage *);
const NvmWebSocketHostedPlan *nvm_websocket_runtime_plan(const NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_begin(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_site(NvmWebSocketRuntime *,uint32_t function,uint16_t instruction);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_fail(NvmWebSocketRuntime *,NvmWebSocketRuntimeStatus);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_current_root(const NvmWebSocketRuntime *,uint32_t *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_view(const NvmWebSocketRuntime *,uint32_t,NvmWebSocketRuntimeView *);

NvmWebSocketRuntimeStatus nvm_websocket_runtime_scalar(NvmWebSocketRuntime *,uint32_t,uint8_t,int64_t);




NvmWebSocketRuntimeStatus nvm_websocket_runtime_string(NvmWebSocketRuntime *,uint32_t,const void *,size_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_literal(NvmWebSocketRuntime *,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_operation(NvmWebSocketRuntime *,uint8_t,uint32_t,uint32_t,uint32_t);

# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h" 3 4
_Bool 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.h"
    nvm_websocket_runtime_string_read(const NvmWebSocketRuntime *,uint32_t,void *,size_t,size_t *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_copy(NvmWebSocketRuntime *,uint32_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_move(NvmWebSocketRuntime *,uint32_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_drop(NvmWebSocketRuntime *,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_construct(NvmWebSocketRuntime *,uint32_t ordinal,uint16_t variant,const uint32_t *,size_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_project(NvmWebSocketRuntime *,uint32_t,uint16_t,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_result_arm(NvmWebSocketRuntime *,uint32_t,NvmWebSocketFlowArm *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_take(NvmWebSocketRuntime *,uint32_t,NvmWebSocketFlowArm,uint32_t);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_begin(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_end(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow(NvmWebSocketRuntime *,uint32_t owner,uint32_t reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow_shared(NvmWebSocketRuntime *,uint32_t owner,uint32_t reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_bind_formal(NvmWebSocketRuntime *,uint32_t source_reference,uint32_t formal_root,uint32_t formal_reference);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_end_reference(NvmWebSocketRuntime *,uint32_t);

NvmWebSocketRuntimeStatus nvm_websocket_runtime_policy(NvmWebSocketRuntime *,const NlWsTransportPolicy *);



NvmWebSocketRuntimeStatus nvm_websocket_runtime_service(NvmWebSocketRuntime *,uint32_t import,uint32_t reference,const uint32_t *inputs,size_t count,uint32_t output);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_complete_root(NvmWebSocketRuntime *,uint32_t result);



NvmWebSocketRuntimeReport nvm_websocket_runtime_finish(NvmWebSocketRuntime *,NvmWebSocketRuntimeView *);
NvmWebSocketRuntimeReport nvm_websocket_runtime_destroy(NvmWebSocketRuntime **,NvmWebSocketRuntimeView *);
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 1
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
typedef struct {
    NvmWebSocketRuntimeMode mode;
    uint32_t function, instruction, byte_offset;
    uint16_t depth, locals, staging_slots, operand_peak;
    uint32_t locals_base, staging_base, stack_base, stack_count;
    uint32_t reference_base, region_floor;
} NvmWebSocketRuntimeFrameView;

NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_start(NvmWebSocketRuntime *);

# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_view(const NvmWebSocketRuntime *,NvmWebSocketRuntimeFrameView *);

# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_local(const NvmWebSocketRuntime *,uint16_t,uint32_t *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_operand(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_reserve(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_scratch(const NvmWebSocketRuntime *,uint32_t *);

# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_frames.h"
    nvm_websocket_runtime_frame_reference(const NvmWebSocketRuntime *,uint16_t,uint32_t *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_store(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_next(NvmWebSocketRuntime *,uint8_t successor);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_call(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_return(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_begin(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_end(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_borrow(NvmWebSocketRuntime *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_end_reference(NvmWebSocketRuntime *);
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
typedef struct NvmWebSocketCyclicReport NvmWebSocketCyclicReport;
typedef struct {
    uint32_t revision, functions, instructions, variants, transfers, edges;
    size_t storage_peak;
    
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
   _Bool 
# 17 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
        runtime_admitted;
} NvmWebSocketCyclicSummary;
typedef struct {
    uint16_t locals, stack, regions, owners, references;
} NvmWebSocketCyclicStateInfo;
typedef struct {
    NvmWebSocketCyclicStateInfo input, output;
    NvmWebSocketBodyInstruction body;
    uint8_t edge_mask, edge_variants[2];


} NvmWebSocketCyclicVariant;
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
NvmWebSocketFlowStatus nvm_websocket_cyclic_analyze(const NvmModule *, NvmWebSocketCyclicReport **);
void nvm_websocket_cyclic_free(NvmWebSocketCyclicReport *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_summary(const NvmWebSocketCyclicReport *, NvmWebSocketCyclicSummary *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_function(const NvmWebSocketCyclicReport *, uint32_t, NvmWebSocketCodeFunction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_local(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, NvmWebSocketFlowDeclaration *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_instruction(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, NvmWebSocketCodeInstruction *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_component(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint16_t *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_variant_count(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_variant(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, NvmWebSocketCyclicVariant *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_local(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowValue *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_stack(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowValue *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_reference(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, NvmWebSocketFlowReference *);

# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_input_region(const NvmWebSocketCyclicReport *, uint32_t, uint16_t, uint8_t, uint16_t, uint64_t *);

# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_type(const NvmWebSocketCyclicReport *, uint32_t, NvmWebSocketNominalLayout *);

# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h" 3 4
_Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic.h"
    nvm_websocket_cyclic_import(const NvmWebSocketCyclicReport *, uint32_t, uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 2
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
typedef struct NvmWebSocketCyclicHostedPlan NvmWebSocketCyclicHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
        runtime_admitted;
} NvmWebSocketCyclicHostedStartup;
typedef struct {
    NvmWebSocketCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmWebSocketCyclicHostedFunction;




NvmWebSocketFlowStatus nvm_websocket_cyclic_hosted_prepare(const uint8_t *,size_t,NvmWebSocketCyclicHostedPlan **);
void nvm_websocket_cyclic_hosted_free(NvmWebSocketCyclicHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_query_summary(const NvmWebSocketCyclicHostedPlan *,NvmWebSocketCyclicSummary *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_startup(const NvmWebSocketCyclicHostedPlan *,NvmWebSocketCyclicHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_function(const NvmWebSocketCyclicHostedPlan *,uint32_t,NvmWebSocketCyclicHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_function_order(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_local(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_instruction(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,NvmWebSocketCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_component(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_variant_count(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_variant(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,NvmWebSocketCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_input_local(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_input_stack(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_input_reference(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_input_region(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_type(const NvmWebSocketCyclicHostedPlan *,uint32_t,NvmWebSocketNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_import(const NvmWebSocketCyclicHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_hosted.h"
    nvm_websocket_cyclic_hosted_bytes(const NvmWebSocketCyclicHostedPlan *,size_t,void *,size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_report.h" 1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_report.h"
typedef struct { uint32_t revision; uint64_t instruction_limit; } NvmWebSocketCyclicOptions;
typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeReport runtime;
    uint64_t instruction_limit, instructions_started;
    
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_report.h" 3 4
   _Bool 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_report.h"
        fuel_exhausted;
} NvmWebSocketCyclicExecutionReport;
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 2


typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeFrameView frame;
    uint8_t variant;
    
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h"
        instruction_open;
} NvmWebSocketCyclicFrameView;
NvmWebSocketRuntimeStatus nvm_websocket_runtime_cyclic_create(const uint8_t *,size_t,
    NvmWebSocketRuntimeMode,const NvmWebSocketCyclicOptions *,NvmWebSocketRuntime **);

const NvmWebSocketCyclicHostedPlan *nvm_websocket_runtime_cyclic_plan(const NvmWebSocketRuntime *);

# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 3 4
_Bool 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h"
    nvm_websocket_runtime_cyclic_frame_view(const NvmWebSocketRuntime *,NvmWebSocketCyclicFrameView *);

NvmWebSocketRuntimeStatus nvm_websocket_runtime_cyclic_enter(NvmWebSocketRuntime *);

# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 3 4
_Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h"
    nvm_websocket_runtime_cyclic_report(const NvmWebSocketRuntime *,NvmWebSocketCyclicExecutionReport *);
NvmWebSocketCyclicExecutionReport nvm_websocket_runtime_cyclic_finish(NvmWebSocketRuntime *,NvmWebSocketRuntimeView *);
NvmWebSocketCyclicExecutionReport nvm_websocket_runtime_cyclic_destroy(NvmWebSocketRuntime **,NvmWebSocketRuntimeView *);

# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 3 4
_Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h"
    nvm_websocket_runtime_cyclic_abi(uint32_t,size_t,size_t,size_t,size_t);


# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h" 3 4
_Bool 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_cyclic_runtime.h"
    nvm_websocket_runtime_cyclic_native_abi(uint32_t,size_t,size_t,size_t,size_t,size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 1



# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h" 1





typedef struct NvmWebSocketIndirectTargets NvmWebSocketIndirectTargets;
typedef enum { NVM_WEBSOCKET_INDIRECT_DESCRIBED, NVM_WEBSOCKET_INDIRECT_INVALID,
 NVM_WEBSOCKET_INDIRECT_UNRESOLVED, NVM_WEBSOCKET_INDIRECT_LIMIT,
 NVM_WEBSOCKET_INDIRECT_MEMORY } NvmWebSocketIndirectStatus;
typedef struct {
 NvmWebSocketIndirectStatus status;
 uint32_t function,pc;
 const char *message;
} NvmWebSocketIndirectResult;
typedef struct {
 uint32_t functions,instructions,calls,visits;
 size_t storage_bound;
} NvmWebSocketIndirectSummary;
typedef struct {
 uint32_t function,pc;
 uint16_t instruction,parameters;
 uint64_t candidates;
 uint8_t result_count;
 NvmWebSocketFlowDeclaration result;
} NvmWebSocketIndirectCall;





NvmWebSocketIndirectResult nvm_websocket_indirect_targets(const NvmModule *,NvmWebSocketIndirectTargets **);
void nvm_websocket_indirect_targets_free(NvmWebSocketIndirectTargets *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_summary(const NvmWebSocketIndirectTargets *,NvmWebSocketIndirectSummary *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_call(const NvmWebSocketIndirectTargets *,uint32_t,NvmWebSocketIndirectCall *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_targets.h"
    nvm_websocket_indirect_targets_parameter(const NvmWebSocketIndirectTargets *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 2


typedef struct NvmWebSocketIndirectFlow NvmWebSocketIndirectFlow;
typedef struct {
 NvmWebSocketIndirectSummary targets;
 NvmWebSocketCyclicSummary ownership;
 uint32_t candidate_applications;
 size_t storage_bound;
 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
     runtime_admitted;
} NvmWebSocketIndirectFlowSummary;
typedef struct {
 uint32_t function,pc;
 uint64_t candidates,checked_candidates;
 NvmWebSocketFlowObligation common;
} NvmWebSocketIndirectFlowCall;





NvmWebSocketFlowStatus nvm_websocket_indirect_flow_analyze(const NvmModule *,NvmWebSocketIndirectFlow **);
void nvm_websocket_indirect_flow_free(NvmWebSocketIndirectFlow *);

# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_summary(const NvmWebSocketIndirectFlow *,NvmWebSocketIndirectFlowSummary *);

# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_function(const NvmWebSocketIndirectFlow *,uint32_t,NvmWebSocketCodeFunction *);

# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_local(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 30 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_instruction(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,NvmWebSocketCodeInstruction *);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_variant_count(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t *);

# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_variant(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmWebSocketCyclicVariant *);

# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_local(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_stack(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_reference(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowReference *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_input_region(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_call(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint8_t,NvmWebSocketIndirectFlowCall *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_component(const NvmWebSocketIndirectFlow *,uint32_t,uint16_t,uint16_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_type(const NvmWebSocketIndirectFlow *,uint32_t,NvmWebSocketNominalLayout *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_flow.h"
    nvm_websocket_indirect_flow_import(const NvmWebSocketIndirectFlow *,uint32_t,uint32_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 2
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
typedef struct NvmWebSocketIndirectHostedPlan NvmWebSocketIndirectHostedPlan;
typedef struct {
    uint32_t revision, entry, initializer, functions, features;
    uint64_t vm_value_slots, native_value_slots;
    uint16_t frames;
    uint32_t reference_slots, region_slots;
    size_t input_bytes, allocation_bound, query_storage_peak, retained_bound;
    
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
   _Bool 
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
        runtime_admitted;
} NvmWebSocketIndirectHostedStartup;
typedef struct {
    NvmWebSocketCodeFunction code;
    uint16_t declared_stack, operand_peak, locals, staging_slots, frames;
    uint16_t frame_owner_peak, frame_reference_peak, frame_region_peak;
    uint32_t reference_slots, region_slots;
    uint64_t vm_value_slots, native_value_slots;
    uint8_t entry_variant;
} NvmWebSocketIndirectHostedFunction;




NvmWebSocketFlowStatus nvm_websocket_indirect_hosted_prepare(const uint8_t *,size_t,NvmWebSocketIndirectHostedPlan **);
void nvm_websocket_indirect_hosted_free(NvmWebSocketIndirectHostedPlan *);

# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_query_summary(const NvmWebSocketIndirectHostedPlan *,NvmWebSocketIndirectFlowSummary *);

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_startup(const NvmWebSocketIndirectHostedPlan *,NvmWebSocketIndirectHostedStartup *);

# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_function(const NvmWebSocketIndirectHostedPlan *,uint32_t,NvmWebSocketIndirectHostedFunction *);

# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_function_order(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint32_t *);

# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_local(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,NvmWebSocketFlowDeclaration *);

# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_instruction(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,NvmWebSocketCodeInstruction *);

# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_component(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint16_t *);

# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_variant_count(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t *);

# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_variant(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmWebSocketCyclicVariant *);

# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_local(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_stack(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowValue *);

# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_reference(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,NvmWebSocketFlowReference *);

# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_input_region(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,uint16_t,uint64_t *);

# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_type(const NvmWebSocketIndirectHostedPlan *,uint32_t,NvmWebSocketNominalLayout *);


# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_import(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint32_t *);


# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_bytes(const NvmWebSocketIndirectHostedPlan *,size_t,void *,size_t);

# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_call(const NvmWebSocketIndirectHostedPlan *,uint32_t,uint16_t,uint8_t,NvmWebSocketIndirectFlowCall *);


# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h" 3 4
_Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_hosted.h"
    nvm_websocket_indirect_hosted_string(const NvmWebSocketIndirectHostedPlan *,uint32_t,const uint8_t **,size_t *);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_report.h" 1






typedef struct { uint32_t revision; uint64_t instruction_limit; } NvmWebSocketIndirectOptions;
typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeReport runtime;
    uint64_t instruction_limit, instructions_started;
    
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_report.h" 3 4
   _Bool 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_report.h"
        fuel_exhausted;
} NvmWebSocketIndirectExecutionReport;
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 2
typedef struct {
    uint32_t revision;
    NvmWebSocketRuntimeFrameView frame;
    uint8_t variant;
    
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 3 4
   _Bool 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h"
        instruction_open;
} NvmWebSocketIndirectFrameView;
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_create(const uint8_t *,size_t,
    NvmWebSocketRuntimeMode,const NvmWebSocketIndirectOptions *,NvmWebSocketRuntime **);
const NvmWebSocketIndirectHostedPlan *nvm_websocket_runtime_indirect_plan(const NvmWebSocketRuntime *);

# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 3 4
_Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h"
    nvm_websocket_runtime_indirect_frame_view(const NvmWebSocketRuntime *,NvmWebSocketIndirectFrameView *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_enter(NvmWebSocketRuntime *);


NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_funcref(NvmWebSocketRuntime *,uint32_t dst);
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_finish(NvmWebSocketRuntime *,NvmWebSocketRuntimeView *);
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_destroy(NvmWebSocketRuntime **,NvmWebSocketRuntimeView *);

# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h" 3 4
_Bool 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_indirect_runtime.h"
    nvm_websocket_runtime_indirect_native_abi(uint32_t,size_t,size_t,size_t,size_t,size_t);
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 1
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 1
# 19 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h" 2
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_format_v2.h"
typedef enum {
    NVM_V2_SECTION_METADATA = 0x01,
    NVM_V2_SECTION_CONSTANTS = 0x02,
    NVM_V2_SECTION_SIGNATURES = 0x03,
    NVM_V2_SECTION_LAYOUTS = 0x04,
    NVM_V2_SECTION_FUNCTIONS = 0x05,
    NVM_V2_SECTION_CODE = 0x06,
    NVM_V2_SECTION_GLOBALS = 0x07,
    NVM_V2_SECTION_IMPORTS = 0x08,
    NVM_V2_SECTION_LINKS = 0x09,
    NVM_V2_SECTION_DEBUG = 0x0A,
    NVM_V2_SECTION_CALLBACKS = 0x0B,
    NVM_V2_SECTION_PASSIVE = 0x0C,
    NVM_V2_SECTION_OWNERSHIP = 0x0D,
    NVM_V2_SECTION_SERVICE_BINDINGS = 0x0E
} NvmV2SectionType;







typedef struct {
    uint8_t magic[4];
    uint16_t format_version;
    uint16_t isa_version;
    uint32_t feature_bits;
    uint64_t total_size;
    uint32_t header_size;
    uint32_t section_count;
    uint32_t entry_point;
    uint32_t flags;
    uint32_t checksum;
} NvmV2Header;

typedef struct {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t size;
} NvmV2SectionEntry;

typedef enum {
    NVM_V2_OK = 0,
    NVM_V2_ERR_TRUNCATED,
    NVM_V2_ERR_MAGIC,
    NVM_V2_ERR_FORMAT_VERSION,
    NVM_V2_ERR_HEADER_SIZE,
    NVM_V2_ERR_UNKNOWN_FEATURE,
    NVM_V2_ERR_TOTAL_SIZE,
    NVM_V2_ERR_RESERVED_FLAGS,
    NVM_V2_ERR_SECTION_TYPE,
    NVM_V2_ERR_SECTION_RANGE,
    NVM_V2_ERR_SECTION_OVERLAP,
    NVM_V2_ERR_SECTION_DUPLICATE,
    NVM_V2_ERR_CHECKSUM,
    NVM_V2_ERR_INDEX_RANGE,
    NVM_V2_ERR_FEATURE_MISMATCH
} NvmV2Result;


const char *nvm_v2_result_name(NvmV2Result r);


NvmV2Result nvm_v2_read_header(const uint8_t *data, size_t size,
                               NvmV2Header *out);


NvmV2Result nvm_v2_read_section(const uint8_t *data, size_t size,
                                const NvmV2Header *header, uint32_t index,
                                NvmV2SectionEntry *out);



NvmV2Result nvm_v2_validate(const uint8_t *data, size_t size);


void nvm_v2_write_header(uint8_t *out, const NvmV2Header *header);


void nvm_v2_write_section(uint8_t *out, const NvmV2SectionEntry *entry);
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 2
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    const uint8_t *base;
    size_t size;
    size_t pos;
} NvmV2Cursor;

void nvm_v2_cursor_init(NvmV2Cursor *c, const uint8_t *base, size_t size);

# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
           nvm_v2_cursor_exhausted(const NvmV2Cursor *c);



NvmV2Result nvm_v2_take(NvmV2Cursor *c, size_t n, const uint8_t **out);

NvmV2Result nvm_v2_u8 (NvmV2Cursor *c, uint8_t *out);
NvmV2Result nvm_v2_u16(NvmV2Cursor *c, uint16_t *out);
NvmV2Result nvm_v2_u32(NvmV2Cursor *c, uint32_t *out);
NvmV2Result nvm_v2_u64(NvmV2Cursor *c, uint64_t *out);




NvmV2Result nvm_v2_align4(NvmV2Cursor *c);
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint8_t tag;
    uint32_t length;
    const uint8_t *payload;
} NvmV2Constant;

typedef struct {
    NvmV2Constant *items;
    uint32_t count;
} NvmV2Constants;



NvmV2Result nvm_v2_constants_decode(const uint8_t *data, size_t size,
                                    NvmV2Constants *out);
void nvm_v2_constants_free(NvmV2Constants *c);
size_t nvm_v2_constants_encoded_size(const NvmV2Constants *c);
NvmV2Result nvm_v2_constants_encode(const NvmV2Constants *c,
                                    uint8_t *out, size_t size);
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t param_count;
    uint16_t result_count;
    const uint8_t *param_tags;
    const uint8_t *result_tags;
} NvmV2Signature;

typedef struct {
    NvmV2Signature *items;
    uint32_t count;
} NvmV2Signatures;



NvmV2Result nvm_v2_signatures_decode(const uint8_t *data, size_t size,
                                     NvmV2Signatures *out);
void nvm_v2_signatures_free(NvmV2Signatures *s);
size_t nvm_v2_signatures_encoded_size(const NvmV2Signatures *s);
NvmV2Result nvm_v2_signatures_encode(const NvmV2Signatures *s,
                                     uint8_t *out, size_t size);




# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
_Bool 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
    nvm_v2_signature_equal(const NvmV2Signature *a, const NvmV2Signature *b);
# 149 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_LAYOUT_STRUCT = 0,
    NVM_V2_LAYOUT_TUPLE = 1,
    NVM_V2_LAYOUT_UNION = 2,
    NVM_V2_LAYOUT_ENUM = 3
} NvmV2LayoutKind;



typedef struct {
    uint8_t type_tag;
    uint32_t nested_idx;
    uint32_t name_idx;
} NvmV2LayoutField;

typedef struct {
    uint8_t kind;
    uint16_t field_count;
    uint32_t name_idx;
    NvmV2LayoutField *fields;
} NvmV2Layout;

typedef struct {
    NvmV2Layout *items;
    uint32_t count;
} NvmV2Layouts;

NvmV2Result nvm_v2_layouts_decode(const uint8_t *data, size_t size,
                                  NvmV2Layouts *out);
void nvm_v2_layouts_free(NvmV2Layouts *l);
size_t nvm_v2_layouts_encoded_size(const NvmV2Layouts *l);
NvmV2Result nvm_v2_layouts_encode(const NvmV2Layouts *l,
                                  uint8_t *out, size_t size);
# 201 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint32_t signature_idx;
    uint64_t code_offset;
    uint64_t code_length;
    uint16_t local_count;
    uint16_t upvalue_count;
    uint16_t max_stack;
} NvmV2Function;

typedef struct {
    NvmV2Function *items;
    uint32_t count;
} NvmV2Functions;

NvmV2Result nvm_v2_functions_decode(const uint8_t *data, size_t size,
                                    NvmV2Functions *out);
void nvm_v2_functions_free(NvmV2Functions *f);
size_t nvm_v2_functions_encoded_size(const NvmV2Functions *f);
NvmV2Result nvm_v2_functions_encode(const NvmV2Functions *f,
                                    uint8_t *out, size_t size);
# 240 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t name_idx;
    uint8_t type_tag;
    uint8_t flags;
    uint32_t init_idx;
} NvmV2Global;

typedef struct {
    NvmV2Global *items;
    uint32_t count;
} NvmV2Globals;

NvmV2Result nvm_v2_globals_decode(const uint8_t *data, size_t size,
                                  NvmV2Globals *out);
void nvm_v2_globals_free(NvmV2Globals *g);
size_t nvm_v2_globals_encoded_size(const NvmV2Globals *g);
NvmV2Result nvm_v2_globals_encode(const NvmV2Globals *g,
                                  uint8_t *out, size_t size);
# 277 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef enum {
    NVM_V2_IMPORT_FFI = 0,
    NVM_V2_IMPORT_COPROCESS = 1,
    NVM_V2_IMPORT_ARTIFACT = 2,
    NVM_V2_IMPORT_SERVICE = 3
} NvmV2ImportKind;
# 291 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint8_t kind;
} NvmV2Import;

typedef struct { NvmV2Import *items; uint32_t count; } NvmV2Imports;





typedef struct {
    uint32_t import_idx;
    uint16_t parameter_idx;
    uint8_t abi_version;
    uint8_t execution;
    uint32_t signature_idx;
    uint32_t adapter_name_idx;
} NvmV2Callback;
typedef struct { NvmV2Callback *items; uint32_t count; } NvmV2Callbacks;
NvmV2Result nvm_v2_callbacks_decode(const uint8_t *data, size_t size, NvmV2Callbacks *out);
void nvm_v2_callbacks_free(NvmV2Callbacks *callbacks);
size_t nvm_v2_callbacks_encoded_size(const NvmV2Callbacks *callbacks);
NvmV2Result nvm_v2_callbacks_encode(const NvmV2Callbacks *callbacks, uint8_t *out, size_t size);

typedef struct {
    uint32_t module_name_idx;
    uint32_t symbol_name_idx;
    uint32_t signature_idx;
    uint32_t flags;
} NvmV2Link;

typedef struct { NvmV2Link *items; uint32_t count; } NvmV2Links;

NvmV2Result nvm_v2_imports_decode(const uint8_t *data, size_t size, NvmV2Imports *out);
void nvm_v2_imports_free(NvmV2Imports *i);
size_t nvm_v2_imports_encoded_size(const NvmV2Imports *i);
NvmV2Result nvm_v2_imports_encode(const NvmV2Imports *i, uint8_t *out, size_t size);

NvmV2Result nvm_v2_links_decode(const uint8_t *data, size_t size, NvmV2Links *out);
void nvm_v2_links_free(NvmV2Links *l);
size_t nvm_v2_links_encoded_size(const NvmV2Links *l);
NvmV2Result nvm_v2_links_encode(const NvmV2Links *l, uint8_t *out, size_t size);
# 349 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct { uint32_t key_idx, value_idx; } NvmV2MetadataEntry;
typedef struct { NvmV2MetadataEntry *items; uint32_t count; } NvmV2Metadata;

typedef struct { uint64_t bytecode_offset; uint32_t source_line, source_col; } NvmV2DebugEntry;
typedef struct { NvmV2DebugEntry *items; uint32_t count; } NvmV2Debug;

NvmV2Result nvm_v2_metadata_decode(const uint8_t *data, size_t size, NvmV2Metadata *out);
void nvm_v2_metadata_free(NvmV2Metadata *m);
size_t nvm_v2_metadata_encoded_size(const NvmV2Metadata *m);
NvmV2Result nvm_v2_metadata_encode(const NvmV2Metadata *m, uint8_t *out, size_t size);

NvmV2Result nvm_v2_debug_decode(const uint8_t *data, size_t size, NvmV2Debug *out);
void nvm_v2_debug_free(NvmV2Debug *d);
size_t nvm_v2_debug_encoded_size(const NvmV2Debug *d);
NvmV2Result nvm_v2_debug_encode(const NvmV2Debug *d, uint8_t *out, size_t size);
# 376 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
typedef struct {
    uint16_t isa_version;
    uint32_t entry_point;
    NvmV2Metadata metadata;
    NvmV2Constants constants;
    NvmV2Signatures signatures;
    NvmV2Layouts layouts;
    NvmV2Functions functions;
    NvmV2Globals globals;
    NvmV2Imports imports;
    NvmV2Callbacks callbacks;
    NvmV2Links links;
    NvmV2Debug debug;
    const uint8_t *code;
    uint64_t code_size;
    const uint8_t *ownership_data;
    uint32_t ownership_size;
    const uint8_t *passive_data;
    uint32_t passive_size;
    const uint8_t *service_data;
    uint32_t service_size;
    
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h" 3 4
   _Bool 
# 397 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
                   has_debug;





    uint8_t *owned_tags;




    uint32_t extra_features;
} NvmV2Module;



NvmV2Result nvm_v2_module_serialize(const NvmV2Module *m,
                                    uint8_t *out, size_t capacity,
                                    size_t *out_size);



NvmV2Result nvm_v2_module_deserialize(const uint8_t *data, size_t size,
                                      NvmV2Module *out);

void nvm_v2_module_free(NvmV2Module *m);
# 437 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/nvm_v2_sections.h"
NvmV2Result nvm_v2_from_nvm_module(const NvmModule *mod, NvmV2Module *out);
NvmV2Result nvm_v2_to_nvm_module(const NvmV2Module *m, NvmModule **out);
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 1 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 1 3 4
# 205 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4


# 24 "/usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 82 "/usr/include/aarch64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/aarch64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 1 3 4
# 64 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uio_lim.h" 1 3 4
# 65 "/usr/include/aarch64-linux-gnu/bits/xopen_lim.h" 2 3 4
# 204 "/usr/include/limits.h" 2 3 4
# 206 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/usr/lib/gcc/aarch64-linux-gnu/13/include/syslimits.h" 2 3 4
# 35 "/usr/lib/gcc/aarch64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/aarch64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 95 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/floatn-common.h" 2 3 4
# 96 "/usr/include/aarch64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 338 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/aarch64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 339 "/usr/include/stdlib.h" 2 3 4

extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 480 "/usr/include/stdlib.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) int
__attribute__ ((__nothrow__ , __leaf__)) atoi (const char *__nptr)
{
  return (int) strtol (__nptr, (char **) ((void *)0), 10);
}
extern __inline __attribute__ ((__gnu_inline__)) long int
__attribute__ ((__nothrow__ , __leaf__)) atol (const char *__nptr)
{
  return strtol (__nptr, (char **) ((void *)0), 10);
}


__extension__ extern __inline __attribute__ ((__gnu_inline__)) long long int
__attribute__ ((__nothrow__ , __leaf__)) atoll (const char *__nptr)
{
  return strtoll (__nptr, (char **) ((void *)0), 10);
}
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




# 1 "/usr/include/aarch64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4






typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/aarch64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/aarch64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;







typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/aarch64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/aarch64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/aarch64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/aarch64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/aarch64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 150 "/usr/include/aarch64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select2.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/select2.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/select-decl.h" 3 4
extern long int __fdelt_chk (long int __d);
extern long int __fdelt_warn (long int __d)
  __attribute__((__warning__ ("bit outside of fd_set selected")));
# 24 "/usr/include/aarch64-linux-gnu/bits/select2.h" 2 3 4
# 151 "/usr/include/aarch64-linux-gnu/sys/select.h" 2 3 4



# 180 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/aarch64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 45 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 27 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock ;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;
# 58 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
  int __kind;




  int __spins;
  __pthread_list_t __list;
# 74 "/usr/include/aarch64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
# 90 "/usr/include/aarch64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/aarch64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[8];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[64];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[48];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[8];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/aarch64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) __attribute__ ((__warn_unused_result__));






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) __attribute__ ((__warn_unused_result__));




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) __attribute__ ((__warn_unused_result__));



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) __attribute__ ((__warn_unused_result__));





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) __attribute__ ((__warn_unused_result__));
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) __attribute__ ((__warn_unused_result__));


# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 1 3 4
# 19 "/usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) void *
bsearch (const void *__key, const void *__base, size_t __nmemb, size_t __size,
  __compar_fn_t __compar)
{
  size_t __l, __u, __idx;
  const void *__p;
  int __comparison;

  __l = 0;
  __u = __nmemb;
  while (__l < __u)
    {
      __idx = (__l + __u) / 2;
      __p = (const void *) (((const char *) __base) + (__idx * __size));
      __comparison = (*__compar) (__key, __p);
      if (__comparison < 0)
 __u = __idx;
      else if (__comparison > 0)
 __l = __idx + 1;
      else
 {

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"

   return (void *) __p;

#pragma GCC diagnostic pop

 }
    }

  return ((void *)0);
}
# 966 "/usr/include/stdlib.h" 2 3 4




extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) __attribute__ ((__warn_unused_result__));
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) __attribute__ ((__warn_unused_result__));
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) __attribute__ ((__warn_unused_result__));




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__warn_unused_result__));
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__warn_unused_result__));







extern int posix_openpt (int __oflag) __attribute__ ((__warn_unused_result__));







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 24 "/usr/include/aarch64-linux-gnu/bits/stdlib-float.h" 3 4
extern __inline __attribute__ ((__gnu_inline__)) double
__attribute__ ((__nothrow__ , __leaf__)) atof (const char *__nptr)
{
  return strtod (__nptr, (char **) ((void *)0));
}
# 1156 "/usr/include/stdlib.h" 2 3 4



# 1 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 1 3 4
# 23 "/usr/include/aarch64-linux-gnu/bits/stdlib.h" 3 4
extern char *__realpath_chk (const char *__restrict __name,
        char *__restrict __resolved,
        size_t __resolvedlen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern char *__realpath_alias (const char *__restrict __name, char *__restrict __resolved) __asm__ ("" "realpath") __attribute__ ((__nothrow__ , __leaf__))

                                                 __attribute__ ((__warn_unused_result__));
extern char *__realpath_chk_warn (const char *__restrict __name, char *__restrict __resolved, size_t __resolvedlen) __asm__ ("" "__realpath_chk") __attribute__ ((__nothrow__ , __leaf__))


                                                __attribute__ ((__warn_unused_result__))
     __attribute__((__warning__ ("second argument of realpath must be either NULL or at " "least PATH_MAX bytes long buffer")))
                                      ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) char *
__attribute__ ((__nothrow__ , __leaf__)) realpath (const char *__restrict __name, char *__restrict __resolved)
{
  size_t sz = __builtin_dynamic_object_size (__resolved, 1);

  if (sz == (size_t) -1)
    return __realpath_alias (__name, __resolved);


  if ((((__typeof (4096)) 0 < (__typeof (4096)) -1 || (__builtin_constant_p (4096) && (4096) > 0)) && __builtin_constant_p ((((long unsigned int) (4096)) <= (sz) / (sizeof (char)))) && !(((long unsigned int) (4096)) <= (sz) / (sizeof (char)))))
    return __realpath_chk_warn (__name, __resolved, sz);

  return __realpath_chk (__name, __resolved, sz);
}


extern int __ptsname_r_chk (int __fd, char *__buf, size_t __buflen,
       size_t __nreal) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_alias (int __fd, char *__buf, size_t __buflen) __asm__ ("" "ptsname_r") __attribute__ ((__nothrow__ , __leaf__))

     __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int __ptsname_r_chk_warn (int __fd, char *__buf, size_t __buflen, size_t __nreal) __asm__ ("" "__ptsname_r_chk") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (2))) __attribute__((__warning__ ("ptsname_r called with buflen bigger than " "size of buf")))
                   ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) int
__attribute__ ((__nothrow__ , __leaf__)) ptsname_r (int __fd, char *__buf, size_t __buflen)
{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__buf, 1)) && (__builtin_dynamic_object_size (__buf, 1)) == (long unsigned int) -1) || (((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char))))) && (((long unsigned int) (__buflen)) <= ((__builtin_dynamic_object_size (__buf, 1))) / ((sizeof (char)))))) ? __ptsname_r_alias (__fd, __buf, __buflen) : ((((__typeof (__buflen)) 0 < (__typeof (__buflen)) -1 || (__builtin_constant_p (__buflen) && (__buflen) > 0)) && __builtin_constant_p ((((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) && !(((long unsigned int) (__buflen)) <= (__builtin_dynamic_object_size (__buf, 1)) / (sizeof (char)))) ? __ptsname_r_chk_warn (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1)) : __ptsname_r_chk (__fd, __buf, __buflen, __builtin_dynamic_object_size (__buf, 1))))

                           ;
}


extern int __wctomb_chk (char *__s, wchar_t __wchar, size_t __buflen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__));
extern int __wctomb_alias (char *__s, wchar_t __wchar) __asm__ ("" "wctomb") __attribute__ ((__nothrow__ , __leaf__))
              __attribute__ ((__warn_unused_result__));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) __attribute__ ((__warn_unused_result__)) int
__attribute__ ((__nothrow__ , __leaf__)) wctomb (char *__s, wchar_t __wchar)
{







  if (__builtin_dynamic_object_size (__s, 1) != (size_t) -1
      && 16 > __builtin_dynamic_object_size (__s, 1))
    return __wctomb_chk (__s, __wchar, __builtin_dynamic_object_size (__s, 1));
  return __wctomb_alias (__s, __wchar);
}


extern size_t __mbstowcs_chk (wchar_t *__restrict __dst,
         const char *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_nulldst (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_alias (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len) __asm__ ("" "mbstowcs") __attribute__ ((__nothrow__ , __leaf__))



    __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __mbstowcs_chk_warn (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__mbstowcs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("mbstowcs called with dst buffer smaller than len " "* sizeof (wchar_t)")))
                        ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) mbstowcs (wchar_t *__restrict __dst, const char *__restrict __src, size_t __len)

{
  if (__builtin_constant_p (__dst == ((void *)0)) && __dst == ((void *)0))
    return __mbstowcs_nulldst (__dst, __src, __len);
  else
    return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (wchar_t)))))) ? __mbstowcs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))) ? __mbstowcs_chk_warn (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t))) : __mbstowcs_chk (__dst, __src, __len, (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (wchar_t)))))
                                                      ;
}

extern size_t __wcstombs_chk (char *__restrict __dst,
         const wchar_t *__restrict __src,
         size_t __len, size_t __dstlen) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_alias (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len) __asm__ ("" "wcstombs") __attribute__ ((__nothrow__ , __leaf__))



  __attribute__ ((__access__ (__write_only__, 1, 3))) __attribute__ ((__access__ (__read_only__, 2)));
extern size_t __wcstombs_chk_warn (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len, size_t __dstlen) __asm__ ("" "__wcstombs_chk") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__((__warning__ ("wcstombs called with dst buffer smaller than len")));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) wcstombs (char *__restrict __dst, const wchar_t *__restrict __src, size_t __len)

{
  return (((__builtin_constant_p (__builtin_dynamic_object_size (__dst, 1)) && (__builtin_dynamic_object_size (__dst, 1)) == (long unsigned int) -1) || (((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char))))) && (((long unsigned int) (__len)) <= ((__builtin_dynamic_object_size (__dst, 1))) / ((sizeof (char)))))) ? __wcstombs_alias (__dst, __src, __len) : ((((__typeof (__len)) 0 < (__typeof (__len)) -1 || (__builtin_constant_p (__len) && (__len) > 0)) && __builtin_constant_p ((((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) && !(((long unsigned int) (__len)) <= (__builtin_dynamic_object_size (__dst, 1)) / (sizeof (char)))) ? __wcstombs_chk_warn (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1)) : __wcstombs_chk (__dst, __src, __len, __builtin_dynamic_object_size (__dst, 1))))

                         ;
}
# 1160 "/usr/include/stdlib.h" 2 3 4








# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/aarch64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__warn_unused_result__)) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));








# 1 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 1 3 4
# 22 "/usr/include/aarch64-linux-gnu/bits/strings_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bcopy (const void *__src, void *__dest, size_t __len)
{
  (void) __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) bzero (void *__dest, size_t __len)
{
  (void) __builtin___memset_chk (__dest, '\0', __len,
     __builtin_dynamic_object_size (__dest, 0));
}
# 145 "/usr/include/strings.h" 2 3 4
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 1 3 4
# 25 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___memcpy_chk (__dest, __src, __len,
     __builtin_dynamic_object_size (__dest, 0));
}

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memmove (void *__dest, const void *__src, size_t __len)
{
  return __builtin___memmove_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) mempcpy (void *__restrict __dest, const void *__restrict __src, size_t __len)

{
  return __builtin___mempcpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 0));
}
# 56 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void *
__attribute__ ((__nothrow__ , __leaf__)) memset (void *__dest, int __ch, size_t __len)
{
  return __builtin___memset_chk (__dest, __ch, __len,
     __builtin_dynamic_object_size (__dest, 0));
}




void __explicit_bzero_chk (void *__dest, size_t __len, size_t __destlen)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__write_only__, 1)));

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) void
__attribute__ ((__nothrow__ , __leaf__)) explicit_bzero (void *__dest, size_t __len)
{
  __explicit_bzero_chk (__dest, __len, __builtin_dynamic_object_size (__dest, 0));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpcpy (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___stpcpy_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncpy (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncpy_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}



extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) stpncpy (char *__dest, const char *__src, size_t __n)
{
  return __builtin___stpncpy_chk (__dest, __src, __n,
      __builtin_dynamic_object_size (__dest, 1));
}
# 127 "/usr/include/aarch64-linux-gnu/bits/string_fortified.h" 3 4
extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strcat (char *__restrict __dest, const char *__restrict __src)
{
  return __builtin___strcat_chk (__dest, __src, __builtin_dynamic_object_size (__dest, 1));
}


extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) char *
__attribute__ ((__nothrow__ , __leaf__)) strncat (char *__restrict __dest, const char *__restrict __src, size_t __len)

{
  return __builtin___strncat_chk (__dest, __src, __len,
      __builtin_dynamic_object_size (__dest, 1));
}


extern size_t __strlcpy_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcpy_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcpy") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcpy (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcpy_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcpy_alias (__dest, __src, __n);
}

extern size_t __strlcat_chk (char *__dest, const char *__src, size_t __n,
        size_t __destlen) __attribute__ ((__nothrow__ , __leaf__));
extern size_t __strlcat_alias (char *__dest, const char *__src, size_t __n) __asm__ ("" "strlcat") __attribute__ ((__nothrow__ , __leaf__))

                 ;

extern __inline __attribute__ ((__always_inline__)) __attribute__ ((__gnu_inline__)) __attribute__ ((__artificial__)) size_t
__attribute__ ((__nothrow__ , __leaf__)) strlcat (char *__restrict __dest, const char *__restrict __src, size_t __n)

{
  if (__builtin_dynamic_object_size (__dest, 1) != (size_t) -1
      && (!__builtin_constant_p (__n > __builtin_dynamic_object_size (__dest, 1))
   || __n > __builtin_dynamic_object_size (__dest, 1)))
    return __strlcat_chk (__dest, __src, __n, __builtin_dynamic_object_size (__dest, 1));
  return __strlcat_alias (__dest, __src, __n);
}
# 549 "/usr/include/string.h" 2 3 4




# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow_config.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal_config.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_plan.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 1


# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 1



# 1 "/usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h" 1 3 4
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h" 2
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h"

# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi.h"
typedef enum {
    NL_NSI_DIR_IN = 0,
    NL_NSI_DIR_OUT,
    NL_NSI_DIR_INOUT,
    NL_NSI_DIR_RETURN
} NlNsiDirection;

typedef enum {
    NL_NSI_OWN_BORROW = 0,
    NL_NSI_OWN_TRANSFER,
    NL_NSI_OWN_COPY
} NlNsiOwnership;

typedef enum {
    NL_NSI_LIFE_CALL = 0,
    NL_NSI_LIFE_CALLER,
    NL_NSI_LIFE_CALLEE,
    NL_NSI_LIFE_RESOURCE
} NlNsiLifetime;

typedef enum {
    NL_NSI_MUT_IMMUTABLE = 0,
    NL_NSI_MUT_MUTABLE
} NlNsiMutability;

typedef enum {
    NL_NSI_STREAM_NONE = 0,
    NL_NSI_STREAM_IN,
    NL_NSI_STREAM_OUT,
    NL_NSI_STREAM_BIDI
} NlNsiStreaming;

typedef enum {
    NL_NSI_TYPE_OPAQUE = 0,
    NL_NSI_TYPE_RECORD,
    NL_NSI_TYPE_VARIANT,
    NL_NSI_TYPE_ARRAY,
    NL_NSI_TYPE_STRING,
    NL_NSI_TYPE_BINARY,
    NL_NSI_TYPE_RESOURCE,
    NL_NSI_TYPE_CALLBACK,
    NL_NSI_TYPE_ASYNC
} NlNsiTypeKind;

typedef struct {
    char *id;
    char *name;
} NlNsiNamed;

typedef struct {
    char *id;
    char *name;
    char *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    int optional;
    NlNsiStreaming streaming;
} NlNsiParam;

typedef struct {
    char *id;
    char *name;
    NlNsiParam *params;
    size_t param_count;
    int idempotent;
} NlNsiMethod;

typedef struct {
    char *id;
    char *name;
    char *type_id;
} NlNsiMember;

typedef struct {
    char *id;
    char *name;
    NlNsiTypeKind kind;
    NlNsiMember *members;
    size_t member_count;
    char *element_id;
    char *method_id;
    char *result_id;
} NlNsiType;

typedef struct {
    char *id;
    char *name;
    char *version;
} NlNsiError;

typedef struct {
    int version;
    NlNsiNamed iface;
    NlNsiMethod *methods;
    size_t method_count;
    NlNsiType *types;
    size_t type_count;
    NlNsiError *errors;
    size_t error_count;
    NlNsiNamed *capabilities;
    size_t capability_count;
} NlNsi;

void nl_nsi_free(NlNsi *nsi);
NlNsi *nl_nsi_load_path(const char *path);

const char *nl_nsi_interface_id(const NlNsi *nsi);
size_t nl_nsi_method_count(const NlNsi *nsi);
const char *nl_nsi_method_id(const NlNsi *nsi, size_t i);
size_t nl_nsi_param_count(const NlNsi *nsi, size_t method_i);
const NlNsiParam *nl_nsi_param(const NlNsi *nsi, size_t method_i, size_t param_i);



typedef enum {
    NL_NSI_COMPAT_OK = 0,
    NL_NSI_COMPAT_BREAKING = 1
} NlNsiCompatResult;

NlNsiCompatResult nl_nsi_compat(const NlNsi *older, const NlNsi *newer);

const NlNsiMethod *nl_nsi_find_method(const NlNsi *nsi, const char *id);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_service_catalog.h" 2



typedef enum { NL_SERVICE_INPUT_NONE, NL_SERVICE_INPUT_EXCLUSIVE, NL_SERVICE_INPUT_CONSUME } NlServiceInputMode;
typedef enum { NL_SERVICE_OWNER_NONE, NL_SERVICE_OWNER_PRESERVED, NL_SERVICE_OWNER_CONSUMED } NlServiceOwnerState;
typedef enum {
    NL_SERVICE_DOMAIN_NONE, NL_SERVICE_DOMAIN_BYTE_INT,
    NL_SERVICE_DOMAIN_U32_INT, NL_SERVICE_DOMAIN_PORT_INT, NL_SERVICE_DOMAIN_IP_FAMILY,
    NL_SERVICE_DOMAIN_TIMEOUT_MS
} NlServiceDomain;
typedef struct { const char *id, *name; } NlServicePlanCapability;
typedef struct {
    const char *id, *name, *type_id;
    NlNsiDirection direction;
    NlNsiOwnership ownership;
    NlNsiLifetime lifetime;
    NlNsiMutability mutability;
    NlServiceDomain domain;
} NlServicePlanParam;
typedef struct { const char *id, *name, *type_id; NlServiceDomain domain; } NlServicePlanMember;
typedef struct {
    const char *id, *name;
    NlNsiTypeKind kind;
    const NlServicePlanMember *members;
    size_t member_count;
} NlServicePlanType;
typedef struct {
    NlServiceOwnerState input_state;
    const char *owned_payload_type;
} NlServicePlanOutcome;
typedef struct {
    const char *id, *name, *generated_name, *binding_id;
    uint32_t abi_version, required_rights, acquired_rights;
    NlServiceInputMode input_mode;
    const NlServicePlanParam *params;
    size_t param_count;
    NlServicePlanOutcome outcomes[2];
} NlServicePlanMethod;
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/../nsi_websocket_plan.h" 2



typedef struct NlWebSocketPlan NlWebSocketPlan;
typedef enum { NL_WEBSOCKET_PLAN_OK, NL_WEBSOCKET_PLAN_INVALID, NL_WEBSOCKET_PLAN_MEMORY } NlWebSocketPlanStatus;



NlWebSocketPlanStatus nl_websocket_plan_build(const NlNsi *,NlWebSocketPlan **out);
void nl_websocket_plan_free(NlWebSocketPlan *);
size_t nl_websocket_plan_storage_size(void);
const char *nl_websocket_plan_interface(const NlWebSocketPlan *);
size_t nl_websocket_plan_method_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_type_count(const NlWebSocketPlan *);
size_t nl_websocket_plan_capability_count(const NlWebSocketPlan *);
const NlServicePlanMethod *nl_websocket_plan_method(const NlWebSocketPlan *,size_t);
const NlServicePlanType *nl_websocket_plan_type(const NlWebSocketPlan *,size_t);
const NlServicePlanCapability *nl_websocket_plan_capability(const NlWebSocketPlan *,size_t);
const char *nl_websocket_catalog_interface(void);
const NlServicePlanMethod *nl_websocket_catalog_method(size_t);
const NlServicePlanType *nl_websocket_catalog_type(size_t);
const NlServicePlanCapability *nl_websocket_catalog_capability(size_t);
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_websocket_nominal_config.h" 2
# 4 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_flow_config.h" 2
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h" 2
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h"
static 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h" 3 4
      _Bool 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h"
           fr_ws_bound(size_t *out){*out=(32u*1024u*1024u);return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h" 3 4
                                                                    1
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_config.h"
                                                                        ;}
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 1
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_catalog.inc" 1
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
typedef struct ServiceRuntimeString {
    uint32_t identity;
    size_t length;
    unsigned char bytes[];
} ServiceRuntimeString;
typedef struct {
    NvmWebSocketRuntimeView view;
    NlWsValue owner;
    uint32_t reference;
    const NvmWebSocketIndirectHostedPlan *callable_plan;
    uint32_t callable_target;
} FileRuntimeValue;
typedef struct {
    
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
        live, formal, shared;
    uint32_t owner_root, origin, formal_root;
    uint64_t region;
    NlWsValueBorrow borrow;
} FileRuntimeReference;

typedef struct {
    uint32_t function, instruction, locals_base, stack_base, stack_count;
    uint32_t staging_base, reference_base, region_base;
    
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
        waiting, instruction_open;
    uint8_t variant;
    uint32_t selected_target;
} FileRuntimeFrame;
typedef enum { FR_ACYCLIC, FR_CYCLIC, FR_INDIRECT } FileRuntimeKind;
typedef struct { NlWsValue owners[256u]; uint32_t roots[256u]; } FileRuntimeWitness;
typedef enum { FR_READY, FR_ACTIVE, FR_TERMINAL } FileRuntimePhase;
struct NvmWebSocketRuntime {
    NvmWebSocketHostedPlan *plan;
    NvmWebSocketCyclicHostedPlan *cyclic_plan;
    NvmWebSocketIndirectHostedPlan *indirect_plan;
    FileRuntimeKind kind;
    FileRuntimeWitness *witness;
    uint64_t instruction_limit, instructions_started;
    
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
        fuel_exhausted, transfer_active;
    NvmWebSocketHostedStartup startup;
    NvmWebSocketRuntimeStorage storage;
    NvmWebSocketFlowDeclaration types[7u];
    NlWsTransportPolicy policy; char resolver_helper[4096]; 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
   policy_set;
    ServiceRuntimeString *strings[4096];
    uint32_t string_count;
    FileRuntimeValue *values;
    FileRuntimeReference *references;
    uint64_t *regions;
    FileRuntimeFrame *frames;
    NlWsValues *files;
    NvmWebSocketRuntimeReport report;
    NvmWebSocketRuntimeView result;
    FileRuntimePhase phase;
    NvmWebSocketRuntimeMode mode;
    uint16_t frame_count;
    
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
        busy, acquired, complete;
    uint32_t current_root, region_count;
    uint64_t next_region;
};
static NvmWebSocketFlowDeclaration fr_scalar_type(uint8_t tag) {
    return (NvmWebSocketFlowDeclaration){tag,0,0xFFFFFFFFu,0xFFFFFFFFu,NVM_WEBSOCKET_CATEGORY_UNKNOWN};
}
static 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_same(NvmWebSocketFlowDeclaration a,NvmWebSocketFlowDeclaration b) {
    return a.tag==b.tag && a.mode==b.mode && a.global_index==b.global_index &&
           a.catalog_ordinal==b.catalog_ordinal && a.category==b.category;
}
static NvmWebSocketRuntimeStatus fr_error(NvmWebSocketRuntime *c,NvmWebSocketRuntimeStatus s,NlWsValueStatus core) {
    if(c && c->phase!=FR_TERMINAL && c->report.status==NVM_WEBSOCKET_RUNTIME_OK && s!=NVM_WEBSOCKET_RUNTIME_BUSY) {
        c->report.status=s;c->report.core_status=core;
    }
    return s;
}
static NvmWebSocketRuntimeStatus fr_ready(NvmWebSocketRuntime *c) {
    if(!c)return NVM_WEBSOCKET_RUNTIME_INVALID;
    if(c->busy)return NVM_WEBSOCKET_RUNTIME_BUSY;
    if(c->phase!=FR_ACTIVE)return NVM_WEBSOCKET_RUNTIME_STATE;
    if(c->report.status!=NVM_WEBSOCKET_RUNTIME_OK)return c->report.status;
    if(c->complete)return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketRuntimeStatus fr_effect(NvmWebSocketRuntime *c) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(c->kind!=FR_ACYCLIC && !c->transfer_active &&
       (!c->frame_count || c->frames[c->frame_count-1].waiting ||
        !c->frames[c->frame_count-1].instruction_open))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketRuntimeStatus fr_core(NvmWebSocketRuntime *c,NlWsValueStatus s) {
    NvmWebSocketRuntimeStatus result;
    switch(s) {
    case NL_WS_VALUE_OK:return NVM_WEBSOCKET_RUNTIME_OK;
    case NL_WS_VALUE_ARGUMENT:result=NVM_WEBSOCKET_RUNTIME_INVALID;break;
    case NL_WS_VALUE_TYPE:result=NVM_WEBSOCKET_RUNTIME_TYPE;break;
    case NL_WS_VALUE_STALE:result=NVM_WEBSOCKET_RUNTIME_STALE;break;
    case NL_WS_VALUE_BORROWED:result=NVM_WEBSOCKET_RUNTIME_BORROWED;break;
    case NL_WS_VALUE_LIMIT:result=NVM_WEBSOCKET_RUNTIME_LIMIT;break;
    case NL_WS_VALUE_MEMORY:result=NVM_WEBSOCKET_RUNTIME_MEMORY;break;
    default:result=NVM_WEBSOCKET_RUNTIME_STATE;break;
    }
    return fr_error(c,result,s);
}
static NvmWebSocketRuntimeStatus fr_prepare(NvmWebSocketFlowStatus s) {
    switch(s) {
    case NVM_WEBSOCKET_FLOW_OK:return NVM_WEBSOCKET_RUNTIME_OK;
    case NVM_WEBSOCKET_FLOW_INVALID:return NVM_WEBSOCKET_RUNTIME_INVALID;
    case NVM_WEBSOCKET_FLOW_LIMIT:return NVM_WEBSOCKET_RUNTIME_LIMIT;
    case NVM_WEBSOCKET_FLOW_MEMORY:return NVM_WEBSOCKET_RUNTIME_MEMORY;
    default:return NVM_WEBSOCKET_RUNTIME_UNRESOLVED;
    }
}
static 
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_add(size_t *total,size_t count,size_t width) {
    if(count && width>
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                     (18446744073709551615UL)
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                             /count)return 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                           0
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                ;
    size_t n=count*width;
    if(*total>(64u*1024u*1024u) || n>(64u*1024u*1024u)-*total)return 
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                          0
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                               ;
    *total+=n;return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                    1
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                        ;
}
static 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_empty(const NvmWebSocketRuntime *c,uint32_t root) {
    return root<c->storage.values && !c->values[root].view.initialized;
}
static 
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_live(const NvmWebSocketRuntime *c,uint32_t root) {
    return root<c->storage.values && c->values[root].view.initialized;
}
static void fr_clear(NvmWebSocketRuntime *c,uint32_t root) { c->values[root]=(FileRuntimeValue){0}; }
static 
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 124 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_member(const NvmWebSocketRuntime *c,uint32_t context,const char *id,NvmWebSocketFlowDeclaration *out) {
    if(!id){*out=fr_scalar_type(TAG_VOID);return 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                1
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                    ;}
    if(!strcmp(id,"nsi:core/int")){*out=fr_scalar_type(TAG_INT);return 
# 126 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                      1
# 126 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                          ;}
    if(!strcmp(id,"nsi:core/bool")){*out=fr_scalar_type(TAG_BOOL);return 
# 127 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                        1
# 127 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                            ;}
    if(!strcmp(id,"nsi:core/string")){*out=fr_scalar_type(TAG_STRING);return 
# 128 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                            1
# 128 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                ;}
    (void)c;(void)context;
    uint32_t base=(0u);
    for(uint32_t i=base;i<base+7u;i++) {
        const NlServicePlanType *t=nl_websocket_catalog_type(i);
        if(t && !strcmp(t->id,id)){*out=c->types[i];return 
# 133 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                          1
# 133 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                              ;}
    }
    return 
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
          0
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
               ;
}
static NvmWebSocketRuntimeView fr_view(NvmWebSocketFlowDeclaration type) {
    NvmWebSocketRuntimeView v={0};v.initialized=
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                 1
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                     ;v.type=type;
    v.owning=type.category==NVM_WEBSOCKET_CATEGORY_CONN || type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT;
    return v;
}
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc"
           fr_error_payload(NlWsTransportResult r,int64_t out[9u]) {
    out[0]=r.status;out[1]=r.host_errno;out[2]=r.resolver_error;out[3]=r.supervisor_status;
    out[4]=r.close_code;out[5]=r.cleanup_errno;out[6]=r.cleanup_failed;
    out[7]=r.closure_unknown;out[8]=r.terminal;return 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc" 3 4
                                                     1
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc"
                                                         ;
}
static 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc" 3 4
      _Bool 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_values.inc"
           fr_ws_payload(const NvmWebSocketRuntime *,const NvmWebSocketRuntimeView *);
# 143 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 1


static 
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_function(const NvmWebSocketRuntime *c,uint32_t f,NvmWebSocketHostedFunction *out) {
    if(c->kind==FR_ACYCLIC)return nvm_websocket_hosted_function(c->plan,f,out);
    if(c->kind==FR_INDIRECT) {
        NvmWebSocketIndirectHostedFunction v;
        if(!nvm_websocket_indirect_hosted_function(c->indirect_plan,f,&v) || v.entry_variant!=0)return 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                                                                                    0
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                                                                         ;
        *out=(NvmWebSocketHostedFunction){v.code,v.declared_stack,v.operand_peak,v.locals,
            v.staging_slots,v.frames,v.reference_slots,v.region_slots,v.vm_value_slots,v.native_value_slots};return 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                                                                                                   1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                                                                                       ;
    }
    NvmWebSocketCyclicHostedFunction v;
    if(!nvm_websocket_cyclic_hosted_function(c->cyclic_plan,f,&v) || v.entry_variant!=0)return 
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                                                                            0
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                                                                 ;
    *out=(NvmWebSocketHostedFunction){v.code,v.declared_stack,v.operand_peak,v.locals,
        v.staging_slots,v.frames,v.reference_slots,v.region_slots,v.vm_value_slots,v.native_value_slots};return 
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                                                                                               1
# 14 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                                                                                   ;
}
static 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_local(const NvmWebSocketRuntime *c,uint32_t f,uint16_t local,NvmWebSocketFlowDeclaration *out) {
    if(c->kind==FR_INDIRECT)return nvm_websocket_indirect_hosted_local(c->indirect_plan,f,local,out);
    return c->kind==FR_ACYCLIC?nvm_websocket_hosted_local(c->plan,f,local,out):
        nvm_websocket_cyclic_hosted_local(c->cyclic_plan,f,local,out);
}
static 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_variant(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t v,NvmWebSocketCyclicVariant *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_variant(c->indirect_plan,f,i,v,out):
        nvm_websocket_cyclic_hosted_variant(c->cyclic_plan,f,i,v,out);
}
static 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_input_local(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t v,uint16_t n,NvmWebSocketFlowValue *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_input_local(c->indirect_plan,f,i,v,n,out):
        nvm_websocket_cyclic_hosted_input_local(c->cyclic_plan,f,i,v,n,out);
}
static 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_input_stack(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t v,uint16_t n,NvmWebSocketFlowValue *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_input_stack(c->indirect_plan,f,i,v,n,out):
        nvm_websocket_cyclic_hosted_input_stack(c->cyclic_plan,f,i,v,n,out);
}
static 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_input_reference(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t v,uint16_t n,NvmWebSocketFlowReference *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_input_reference(c->indirect_plan,f,i,v,n,out):
        nvm_websocket_cyclic_hosted_input_reference(c->cyclic_plan,f,i,v,n,out);
}
static 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 37 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_input_region(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t v,uint16_t n,uint64_t *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_input_region(c->indirect_plan,f,i,v,n,out):
        nvm_websocket_cyclic_hosted_input_region(c->cyclic_plan,f,i,v,n,out);
}
static 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_code(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,NvmWebSocketCodeInstruction *out) {
    return c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_instruction(c->indirect_plan,f,i,out):
        nvm_websocket_cyclic_hosted_instruction(c->cyclic_plan,f,i,out);
}
static 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_instruction(const NvmWebSocketRuntime *c,uint32_t f,uint16_t i,uint8_t variant,
                            NvmWebSocketCodeInstruction *in,NvmWebSocketBodyInstruction *fact) {
    if(c->kind==FR_ACYCLIC)return nvm_websocket_hosted_instruction(c->plan,f,i,in,fact);
    NvmWebSocketCyclicVariant v;
    if(!fr_code(c,f,i,in) ||
       !fr_variant(c,f,i,variant,&v))return 
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                           0
# 50 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                ;
    *fact=v.body;return 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                       1
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                           ;
}
static 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_import(const NvmWebSocketRuntime *c,uint32_t original,uint32_t *ordinal) {
    for(uint32_t i=0;i<4u;i++) {
        uint32_t value;
        if(!(c->kind==FR_ACYCLIC?nvm_websocket_hosted_import(c->plan,i,&value):
             c->kind==FR_INDIRECT?nvm_websocket_indirect_hosted_import(c->indirect_plan,i,&value):
             nvm_websocket_cyclic_hosted_import(c->cyclic_plan,i,&value))) {



            return 
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                  0
# 62 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                       ;
        }
        if(value==original){*ordinal=i;return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                             1
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                 ;}
    }
    return 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
          0
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
               ;
}
static 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 68 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           frc_edge(const NvmWebSocketRuntime *c,const FileRuntimeFrame *f,uint8_t edge,uint8_t *out) {
    if(c->kind==FR_ACYCLIC){*out=0;return 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                         1
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                             ;}
    NvmWebSocketCyclicVariant v;
    if(edge>=2 || !fr_variant(c,f->function,
       (uint16_t)f->instruction,f->variant,&v) || !(v.edge_mask&(1u<<edge)) ||
       v.edge_variants[edge]==
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                             (255)
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                             )return 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                                                     0
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                                                          ;
    *out=v.edge_variants[edge];return 
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                     1
# 74 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                         ;
}
static 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
      _Bool 
# 76 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
           fr_call_target(const NvmWebSocketRuntime *c,const FileRuntimeFrame *f,
                           const NvmWebSocketCodeInstruction *in,uint32_t target) {
    if(!isa_is_file_indirect_call(in->decoded.opcode))
        return (in->decoded.opcode==OP_CALL || in->decoded.opcode==OP_CALL_REF ||
                in->decoded.opcode==OP_FILE_CALL_REFS) && in->decoded.operands[0].u32==target;
    NvmWebSocketIndirectFlowCall call;
    return c->kind==FR_INDIRECT && target<64u &&
        nvm_websocket_indirect_hosted_call(c->indirect_plan,f->function,(uint16_t)f->instruction,f->variant,&call) &&
        call.candidates && call.candidates==call.checked_candidates &&
        (call.candidates&(1UL<<target)) && call.common.target==0xFFFFFFFFu;
}
static NvmWebSocketRuntimeStatus frc_validate(NvmWebSocketRuntime *,const FileRuntimeFrame *);
NvmWebSocketRuntimeStatus nvm_websocket_runtime_cyclic_create(const uint8_t *bytes,size_t size,
    NvmWebSocketRuntimeMode mode,const NvmWebSocketCyclicOptions *options,NvmWebSocketRuntime **out) {
    if(!out || !options || options->revision!=1u ||
       options->instruction_limit>1000000UL ||
       (mode!=NVM_WEBSOCKET_RUNTIME_VM && mode!=NVM_WEBSOCKET_RUNTIME_NATIVE))return NVM_WEBSOCKET_RUNTIME_INVALID;
    NvmWebSocketCyclicHostedPlan *plan=
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                                        ((void *)0)
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                            ;
    NvmWebSocketFlowStatus checked=nvm_websocket_cyclic_hosted_prepare(bytes,size,&plan);
    if(checked!=NVM_WEBSOCKET_FLOW_OK)return fr_prepare(checked);
    NvmWebSocketCyclicHostedStartup v;size_t core,total;
    if(!nvm_websocket_cyclic_hosted_startup(plan,&v) || !fr_ws_bound(&core)) {
        nvm_websocket_cyclic_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_INVALID;
    }
    uint64_t values=mode==NVM_WEBSOCKET_RUNTIME_VM?v.vm_value_slots:v.native_value_slots;
    total=v.retained_bound;
    if(!values || values>
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc" 3 4
                        (4294967295U) 
# 102 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime_facts.inc"
                                   || !v.frames || !v.reference_slots || !v.region_slots ||
       !fr_add(&total,1,sizeof(NvmWebSocketRuntime)) || !fr_add(&total,1,sizeof(FileRuntimeWitness)) ||
       !fr_add(&total,(size_t)values,sizeof(FileRuntimeValue)) ||
       !fr_add(&total,v.reference_slots,sizeof(FileRuntimeReference)) ||
       !fr_add(&total,v.region_slots,sizeof(uint64_t)) ||
       !fr_add(&total,v.frames,sizeof(FileRuntimeFrame)) || !fr_add(&total,1,core)) {
        nvm_websocket_cyclic_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_LIMIT;
    }
    NvmWebSocketRuntime *c=calloc(1,sizeof *c);
    if(!c){nvm_websocket_cyclic_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_MEMORY;}
    c->kind=FR_CYCLIC;c->cyclic_plan=plan;c->mode=mode;c->next_region=1;
    c->instruction_limit=options->instruction_limit;
    c->startup=(NvmWebSocketHostedStartup){v.entry,v.initializer,v.functions,v.features,
        v.vm_value_slots,v.native_value_slots,v.frames,v.reference_slots,v.region_slots,v.allocation_bound};
    c->storage=(NvmWebSocketRuntimeStorage){total,(uint32_t)values,v.reference_slots,v.region_slots,v.frames};
    c->witness=calloc(1,sizeof *c->witness);
    c->values=calloc(c->storage.values,sizeof *c->values);
    c->references=calloc(c->storage.references,sizeof *c->references);
    c->regions=calloc(c->storage.regions,sizeof *c->regions);
    c->frames=calloc(c->storage.frames,sizeof *c->frames);
    NvmWebSocketRuntimeStatus status=NVM_WEBSOCKET_RUNTIME_MEMORY;
    if(!c->witness || !c->values || !c->references || !c->regions || !c->frames)goto fail;
    status=NVM_WEBSOCKET_RUNTIME_INVALID;
    do { for(uint32_t i=0;i<7u;i++) { NvmWebSocketNominalLayout type;if(!nvm_websocket_cyclic_hosted_type(plan,i,&type))goto fail; (c)->types[i]=(NvmWebSocketFlowDeclaration){type.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION, 0,type.global_index,type.catalog_ordinal,type.category}; } } while(0);
    c->report.function=c->report.instruction=0xFFFFFFFFu;
    c->current_root=v.initializer!=0xFFFFFFFFu?v.initializer:v.entry;
    *out=c;return NVM_WEBSOCKET_RUNTIME_OK;
fail:
    free(c->frames);free(c->regions);free(c->references);free(c->values);free(c->witness);
    nvm_websocket_cyclic_hosted_free(plan);free(c);return status;
}
# 144 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime_create.inc" 1
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_create(const uint8_t *bytes,size_t size,
    NvmWebSocketRuntimeMode mode,const NvmWebSocketIndirectOptions *options,NvmWebSocketRuntime **out) {
    if(!out || !options || options->revision!=1u ||
       options->instruction_limit>1000000UL ||
       (mode!=NVM_WEBSOCKET_RUNTIME_VM && mode!=NVM_WEBSOCKET_RUNTIME_NATIVE))return NVM_WEBSOCKET_RUNTIME_INVALID;
    NvmWebSocketIndirectHostedPlan *plan=
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime_create.inc" 3 4
                                          ((void *)0)
# 6 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime_create.inc"
                                              ;
    NvmWebSocketFlowStatus checked=nvm_websocket_indirect_hosted_prepare(bytes,size,&plan);
    if(checked!=NVM_WEBSOCKET_FLOW_OK)return fr_prepare(checked);
    NvmWebSocketIndirectHostedStartup v;size_t core,total;
    if(!nvm_websocket_indirect_hosted_startup(plan,&v) || !fr_ws_bound(&core)) {
        nvm_websocket_indirect_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_INVALID;
    }
    uint64_t values=mode==NVM_WEBSOCKET_RUNTIME_VM?v.vm_value_slots:v.native_value_slots;
    total=v.retained_bound;
    if(!values || values>
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime_create.inc" 3 4
                        (4294967295U) 
# 15 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime_create.inc"
                                   || !v.frames || !v.reference_slots || !v.region_slots ||
       !fr_add(&total,1,sizeof(NvmWebSocketRuntime)) || !fr_add(&total,1,sizeof(FileRuntimeWitness)) ||
       !fr_add(&total,(size_t)values,sizeof(FileRuntimeValue)) ||
       !fr_add(&total,v.reference_slots,sizeof(FileRuntimeReference)) ||
       !fr_add(&total,v.region_slots,sizeof(uint64_t)) ||
       !fr_add(&total,v.frames,sizeof(FileRuntimeFrame)) || !fr_add(&total,1,core)) {
        nvm_websocket_indirect_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_LIMIT;
    }
    NvmWebSocketRuntime *c=calloc(1,sizeof *c);
    if(!c){nvm_websocket_indirect_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_MEMORY;}
    c->kind=FR_INDIRECT;c->indirect_plan=plan;c->mode=mode;c->next_region=1;
    c->instruction_limit=options->instruction_limit;
    c->startup=(NvmWebSocketHostedStartup){v.entry,v.initializer,v.functions,v.features,
        v.vm_value_slots,v.native_value_slots,v.frames,v.reference_slots,v.region_slots,v.allocation_bound};
    c->storage=(NvmWebSocketRuntimeStorage){total,(uint32_t)values,v.reference_slots,v.region_slots,v.frames};
    c->witness=calloc(1,sizeof *c->witness);
    c->values=calloc(c->storage.values,sizeof *c->values);
    c->references=calloc(c->storage.references,sizeof *c->references);
    c->regions=calloc(c->storage.regions,sizeof *c->regions);
    c->frames=calloc(c->storage.frames,sizeof *c->frames);
    NvmWebSocketRuntimeStatus status=NVM_WEBSOCKET_RUNTIME_MEMORY;
    if(!c->witness || !c->values || !c->references || !c->regions || !c->frames)goto fail;
    status=NVM_WEBSOCKET_RUNTIME_INVALID;
    do { for(uint32_t i=0;i<7u;i++) { NvmWebSocketNominalLayout type;if(!nvm_websocket_indirect_hosted_type(plan,i,&type))goto fail; (c)->types[i]=(NvmWebSocketFlowDeclaration){type.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION, 0,type.global_index,type.catalog_ordinal,type.category}; } } while(0);
    c->report.function=c->report.instruction=0xFFFFFFFFu;
    c->current_root=v.initializer!=0xFFFFFFFFu?v.initializer:v.entry;
    *out=c;return NVM_WEBSOCKET_RUNTIME_OK;
fail:
    free(c->frames);free(c->regions);free(c->references);free(c->values);free(c->witness);
    nvm_websocket_indirect_hosted_free(plan);free(c);return status;
}
# 145 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2

NvmWebSocketRuntimeStatus nvm_websocket_runtime_create(const uint8_t *bytes,size_t size,NvmWebSocketRuntimeMode mode,NvmWebSocketRuntime **out) {
    if(!out || (mode!=NVM_WEBSOCKET_RUNTIME_VM && mode!=NVM_WEBSOCKET_RUNTIME_NATIVE))return NVM_WEBSOCKET_RUNTIME_INVALID;
    NvmWebSocketHostedPlan *plan=
# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                  ((void *)0)
# 148 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                      ;NvmWebSocketFlowStatus checked=nvm_websocket_hosted_prepare(bytes,size,&plan);
    if(checked!=NVM_WEBSOCKET_FLOW_OK)return fr_prepare(checked);
    NvmWebSocketHostedStartup startup;size_t core=0,total;
    if(!nvm_websocket_hosted_startup(plan,&startup) || !fr_ws_bound(&core)) {
        nvm_websocket_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_INVALID;
    }
    uint64_t values=mode==NVM_WEBSOCKET_RUNTIME_VM?startup.vm_value_slots:startup.native_value_slots;
    total=startup.allocation_bound;
    if(!values || values>
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                        (4294967295U) 
# 156 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                   || !startup.frames || !startup.reference_slots || !startup.region_slots ||
       !fr_add(&total,1,sizeof(NvmWebSocketRuntime)) || !fr_add(&total,(size_t)values,sizeof(FileRuntimeValue)) ||
       !fr_add(&total,startup.reference_slots,sizeof(FileRuntimeReference)) ||
       !fr_add(&total,startup.region_slots,sizeof(uint64_t)) ||
       !fr_add(&total,startup.frames,sizeof(FileRuntimeFrame)) || !fr_add(&total,1,core)) {
        nvm_websocket_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_LIMIT;
    }
    NvmWebSocketRuntime *c=calloc(1,sizeof *c);
    if(!c){nvm_websocket_hosted_free(plan);return NVM_WEBSOCKET_RUNTIME_MEMORY;}
    c->plan=plan;c->startup=startup;c->next_region=1;c->mode=mode;
    c->storage=(NvmWebSocketRuntimeStorage){total,(uint32_t)values,startup.reference_slots,startup.region_slots,startup.frames};
    c->values=calloc(c->storage.values,sizeof *c->values);
    c->references=calloc(c->storage.references,sizeof *c->references);
    c->regions=calloc(c->storage.regions,sizeof *c->regions);
    c->frames=calloc(c->storage.frames,sizeof *c->frames);
    NvmWebSocketRuntimeStatus status=NVM_WEBSOCKET_RUNTIME_MEMORY;
    if(!c->values || !c->references || !c->regions || !c->frames)goto fail;
    status=NVM_WEBSOCKET_RUNTIME_INVALID;
    do { for(uint32_t i=0;i<7u;i++) { NvmWebSocketNominalLayout type;if(!nvm_websocket_hosted_type(plan,i,&type))goto fail; (c)->types[i]=(NvmWebSocketFlowDeclaration){type.layout_kind==NVM_V2_LAYOUT_STRUCT?TAG_STRUCT:TAG_UNION, 0,type.global_index,type.catalog_ordinal,type.category}; } } while(0);
    c->report.function=c->report.instruction=0xFFFFFFFFu;
    c->current_root=startup.initializer!=0xFFFFFFFFu?startup.initializer:startup.entry;
    *out=c;return NVM_WEBSOCKET_RUNTIME_OK;
fail:
    free(c->frames);free(c->regions);free(c->references);free(c->values);nvm_websocket_hosted_free(plan);free(c);return status;
}

# 181 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
_Bool 
# 181 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
    nvm_websocket_runtime_storage(const NvmWebSocketRuntime *c,NvmWebSocketRuntimeStorage *out) {
    if(!c || !out)return 
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                        0
# 182 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                             ;
    *out=c->storage;return 
# 183 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                          1
# 183 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                              ;
}
const NvmWebSocketHostedPlan *nvm_websocket_runtime_plan(const NvmWebSocketRuntime *c) { return c?c->plan:
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                           ((void *)0)
# 185 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                               ; }
NvmWebSocketRuntimeStatus nvm_websocket_runtime_begin(NvmWebSocketRuntime *c) {
    if(!c)return NVM_WEBSOCKET_RUNTIME_INVALID;
    if(c->busy || c->phase==FR_ACTIVE)return NVM_WEBSOCKET_RUNTIME_BUSY;
    if(c->phase!=FR_READY)return NVM_WEBSOCKET_RUNTIME_STATE;
    c->busy=
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
           1
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
               ;NlWsValueStatus core=((c)->policy_set?nl_ws_values_create_bounded(&(c)->policy,(32u*1024u*1024u),&(c)->files):NL_WS_VALUE_ARGUMENT);c->busy=
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                         0
# 190 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                              ;c->phase=FR_ACTIVE;
    if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
    c->acquired=
# 192 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
               1
# 192 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                   ;c->report.acquired=
# 192 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                       1
# 192 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                           ;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_site(NvmWebSocketRuntime *c,uint32_t function,uint16_t instruction) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    uint8_t variant=0;
    if(c->kind!=FR_ACYCLIC) {
        if(!c->frame_count || c->frames[c->frame_count-1].function!=function ||
           c->frames[c->frame_count-1].instruction!=instruction)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
        variant=c->frames[c->frame_count-1].variant;
    }
    if(!fr_instruction(c,function,instruction,variant,&in,&fact) || !fact.reachable)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    c->report.function=function;c->report.instruction=in.byte_offset;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_fail(NvmWebSocketRuntime *c,NvmWebSocketRuntimeStatus status) {
    NvmWebSocketRuntimeStatus ready=fr_ready(c);if(ready!=NVM_WEBSOCKET_RUNTIME_OK)return ready;
    if(status<=NVM_WEBSOCKET_RUNTIME_OK || status>NVM_WEBSOCKET_RUNTIME_CLEANUP)return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    return fr_error(c,status,NL_WS_VALUE_STATE);
}

# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
_Bool 
# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
    nvm_websocket_runtime_current_root(const NvmWebSocketRuntime *c,uint32_t *out) {
    if(!c || !out || c->phase!=FR_ACTIVE || c->complete || c->busy)return 
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                         0
# 214 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                              ;
    *out=c->current_root;return 
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                               1
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                   ;
}

# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
_Bool 
# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
    nvm_websocket_runtime_view(const NvmWebSocketRuntime *c,uint32_t root,NvmWebSocketRuntimeView *out) {
    if(!c || !out || root>=c->storage.values || c->busy)return 
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                              0
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                   ;
    *out=c->values[root].view;return 
# 219 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                    1
# 219 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                        ;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_scalar(NvmWebSocketRuntime *c,uint32_t dst,uint8_t tag,int64_t value) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_empty(c,dst) || (tag!=TAG_INT && tag!=TAG_BOOL && tag!=TAG_VOID) ||
       (tag==TAG_BOOL && value!=0 && value!=1) || (tag==TAG_VOID && value))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    NvmWebSocketRuntimeView v=fr_view(fr_scalar_type(tag));v.fields=tag==TAG_VOID?0:1;v.values[0]=value;
    c->values[dst].view=v;return NVM_WEBSOCKET_RUNTIME_OK;
}
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 1



static const ServiceRuntimeString *fr_string_identity(const NvmWebSocketRuntime *c,int64_t identity) {
    return identity>0 && (uint64_t)identity<=c->string_count?c->strings[identity-1]:
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                                                                   ((void *)0)
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                                       ;
}
static const ServiceRuntimeString *fr_string(const NvmWebSocketRuntime *c,uint32_t root) {
    if(!fr_live(c,root))return 
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                              ((void *)0)
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                  ;
    const NvmWebSocketRuntimeView *v=&c->values[root].view;
    if(v->owning || v->formal || v->fields!=1 || !fr_same(v->type,fr_scalar_type(TAG_STRING)))return 
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                                                                                    ((void *)0)
# 10 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                                                        ;
    return fr_string_identity(c,v->values[0]);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string(NvmWebSocketRuntime *c,uint32_t dst,
    const void *bytes,size_t length) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_empty(c,dst) || (!bytes && length))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(length>1024u*1024u)return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
    ServiceRuntimeString *found=
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                               ((void *)0)
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                   ;
    for(uint32_t i=0;i<c->string_count;i++) {
        ServiceRuntimeString *s=c->strings[i];
        if(s->length==length && (!length || !memcmp(s->bytes,bytes,length))){found=s;break;}
    }
    if(!found) {
        size_t bound=c->storage.allocation_bound;
        if(c->string_count>=4096 || !fr_add(&bound,1,sizeof(ServiceRuntimeString)) || !fr_add(&bound,length,1))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
        found=calloc(1,sizeof(*found)+length);
        if(!found)return fr_error(c,NVM_WEBSOCKET_RUNTIME_MEMORY,NL_WS_VALUE_MEMORY);
        found->identity=++c->string_count;found->length=length;
        if(length)memcpy(found->bytes,bytes,length);
        c->strings[found->identity-1]=found;c->storage.allocation_bound=bound;
    }
    NvmWebSocketRuntimeView v=fr_view(fr_scalar_type(TAG_STRING));v.fields=1;v.values[0]=found->identity;
    c->values[dst].view=v;return NVM_WEBSOCKET_RUNTIME_OK;
}

# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
_Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
    nvm_websocket_runtime_string_read(const NvmWebSocketRuntime *c,uint32_t root,
    void *out,size_t capacity,size_t *length) {
    if(!c || !length || c->busy || c->phase!=FR_ACTIVE || c->report.status!=NVM_WEBSOCKET_RUNTIME_OK)return 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                                                                                            0
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                                                                 ;
    const ServiceRuntimeString *s=fr_string(c,root);
    if(!s || capacity<s->length || (!out && s->length))return 
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                                             0
# 40 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                  ;
    if(s->length)memcpy(out,s->bytes,s->length);
    *length=s->length;return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                            1
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                ;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_literal(NvmWebSocketRuntime *c,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(c->kind!=FR_INDIRECT || !c->frame_count)return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    const uint8_t *bytes;size_t length;
    if(!fr_instruction(c,f->function,f->instruction,f->variant,&in,&fact) || in.decoded.opcode!=OP_PUSH_STR ||
       !nvm_websocket_indirect_hosted_string(c->indirect_plan,in.decoded.operands[0].u32,&bytes,&length))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    return nvm_websocket_runtime_string(c,dst,bytes,length);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_string_operation(NvmWebSocketRuntime *c,uint8_t op,
    uint32_t left,uint32_t right,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    const ServiceRuntimeString *a=fr_string(c,left),*b=op==OP_STR_EQ?fr_string(c,right):
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                                                                       ((void *)0)
# 58 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                                           ;
    if(!a || (op!=OP_STR_EQ && op!=OP_STR_LEN) ||
       (op==OP_STR_EQ && (!b || left==right)) || (dst!=left && dst!=right && !fr_empty(c,dst)) ||
       (op==OP_STR_LEN && (right!=
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc" 3 4
                                 (4294967295U) 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_strings.inc"
                                                                || (dst!=left && !fr_empty(c,dst)))))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    int64_t value=op==OP_STR_LEN?(int64_t)a->length:
        a->length==b->length && (!a->length || !memcmp(a->bytes,b->bytes,a->length));
    fr_clear(c,left);if(op==OP_STR_EQ)fr_clear(c,right);
    return nvm_websocket_runtime_scalar(c,dst,op==OP_STR_LEN?TAG_INT:TAG_BOOL,value);
}
# 230 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2

NvmWebSocketRuntimeStatus nvm_websocket_runtime_copy(NvmWebSocketRuntime *c,uint32_t src,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,src) || !fr_empty(c,dst) || c->values[src].view.owning || c->values[src].view.formal)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    c->values[dst]=c->values[src];return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_move(NvmWebSocketRuntime *c,uint32_t src,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,src) || !fr_empty(c,dst) || c->values[src].view.formal)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(c->values[src].view.owning) {
        c->busy=
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
               1
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                   ;NlWsValueStatus core=nl_ws_value_move(c->files,&c->values[src].owner,&c->values[dst].owner);c->busy=
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                      0
# 242 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                           ;
        if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
    }
    c->values[dst].view=c->values[src].view;
    c->values[dst].callable_plan=c->values[src].callable_plan;
    c->values[dst].callable_target=c->values[src].callable_target;fr_clear(c,src);return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_drop(NvmWebSocketRuntime *c,uint32_t root) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,root) || c->values[root].view.formal)return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(c->values[root].view.owning) {
        c->busy=
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
               1
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                   ;NlWsValueStatus core=nl_ws_value_drop(c->files,&c->values[root].owner);c->busy=
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                 0
# 253 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                      ;
        if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
    }
    fr_clear(c,root);return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_construct(NvmWebSocketRuntime *c,uint32_t ordinal,uint16_t variant,const uint32_t *inputs,size_t count,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!((ordinal)<7u) || dst>=c->storage.values || count>9u || (count && !inputs))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    NvmWebSocketFlowDeclaration type=c->types[ordinal];
# 262 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                        _Bool 
# 262 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                             record=type.category==NVM_WEBSOCKET_CATEGORY_RECORD;
    const NlServicePlanType *catalog=nl_websocket_catalog_type(ordinal);
    if(!catalog || (type.category!=NVM_WEBSOCKET_CATEGORY_RECORD && type.category!=NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT) ||
       (record?variant!=0:variant>=catalog->member_count) || count!=(record?catalog->member_count:1))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    NvmWebSocketRuntimeView value=fr_view(type);
# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                 _Bool 
# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                      replaces=
# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                               0
# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                    ;
    if(!record)value.arm=variant?NVM_WEBSOCKET_FLOW_ARM_ERROR:NVM_WEBSOCKET_FLOW_ARM_OK;
    for(size_t i=0;i<count;i++) {
        for(size_t j=0;j<i;j++)if(inputs[j]==inputs[i])return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
        if(!fr_live(c,inputs[i]))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        NvmWebSocketRuntimeView input=c->values[inputs[i]].view;NvmWebSocketFlowDeclaration expected;
        if(input.owning || input.formal || !fr_member(c,ordinal,catalog->members[record?i:variant].type_id,&expected) || !fr_same(input.type,expected))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        replaces|=inputs[i]==dst;
        if(record) {
            if(input.fields!=1 || (input.type.tag!=TAG_INT && input.type.tag!=TAG_BOOL && input.type.tag!=TAG_STRING))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
            if(input.type.tag==TAG_STRING && !fr_string(c,inputs[i]))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
            value.values[i]=input.values[0];value.fields=(uint8_t)count;
        } else { value.fields=input.fields;memcpy(value.values,input.values,sizeof value.values); }
    }
    if(!replaces && !fr_empty(c,dst))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    for(size_t i=0;i<count;i++)fr_clear(c,inputs[i]);
    c->values[dst].view=value;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_project(NvmWebSocketRuntime *c,uint32_t src,uint16_t field,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,src) || (src!=dst && !fr_empty(c,dst)))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    NvmWebSocketRuntimeView input=c->values[src].view;uint32_t ordinal=input.type.catalog_ordinal;
    if(input.owning || input.formal || !((ordinal)<7u))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    const NlServicePlanType *catalog=nl_websocket_catalog_type(ordinal);NvmWebSocketFlowDeclaration type;
    NvmWebSocketRuntimeView result={0};
    if(input.type.category==NVM_WEBSOCKET_CATEGORY_RECORD) {
        if(!catalog || field>=catalog->member_count || field>=input.fields || !fr_member(c,ordinal,catalog->members[field].type_id,&type))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        result=fr_view(type);result.fields=1;result.values[0]=input.values[field];
    } else if(input.type.category==NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT && !field &&
              (input.arm==NVM_WEBSOCKET_FLOW_ARM_OK || input.arm==NVM_WEBSOCKET_FLOW_ARM_ERROR)) {
        if(!catalog || !fr_member(c,ordinal,catalog->members[input.arm==NVM_WEBSOCKET_FLOW_ARM_ERROR].type_id,&type))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        result=fr_view(type);result.fields=input.fields;memcpy(result.values,input.values,sizeof result.values);
    } else return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    fr_clear(c,src);c->values[dst].view=result;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_result_arm(NvmWebSocketRuntime *c,uint32_t root,NvmWebSocketFlowArm *out) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!out || !fr_live(c,root))return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    NvmWebSocketRuntimeView *view=&c->values[root].view;NvmWebSocketFlowArm arm;
    if(view->type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT) {
        NlWsConnectView actual;c->busy=
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                   1
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                       ;NlWsValueStatus core=nl_ws_connect_view(c->files,&c->values[root].owner,&actual);c->busy=
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                            0
# 310 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                                 ;
        if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
        arm=actual.ok?NVM_WEBSOCKET_FLOW_ARM_OK:NVM_WEBSOCKET_FLOW_ARM_ERROR;
    } else if(view->type.category==NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT)arm=view->arm;
    else return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(arm!=NVM_WEBSOCKET_FLOW_ARM_OK && arm!=NVM_WEBSOCKET_FLOW_ARM_ERROR)return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    *out=arm;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_take(NvmWebSocketRuntime *c,uint32_t src,NvmWebSocketFlowArm arm,uint32_t dst) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,src) || !fr_empty(c,dst) || (arm!=NVM_WEBSOCKET_FLOW_ARM_OK && arm!=NVM_WEBSOCKET_FLOW_ARM_ERROR))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    NvmWebSocketFlowArm actual;status=nvm_websocket_runtime_result_arm(c,src,&actual);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(actual!=arm)return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    NvmWebSocketRuntimeView input=c->values[src].view,value={0};
    uint32_t ordinal=input.type.catalog_ordinal,base=(0u);
    if(input.type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT) {
        NlWsValueStatus core;
        if(arm==NVM_WEBSOCKET_FLOW_ARM_OK) {
            value=fr_view(c->types[base]);c->busy=
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                 1
# 329 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                     ;
            core=nl_ws_connect_take_ok(c->files,&c->values[src].owner,&c->values[dst].owner);c->busy=
# 330 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                    0
# 330 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                         ;
        } else {
            NlWsConnectView observed;c->busy=
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                         1
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                             ;core=nl_ws_connect_view(c->files,&c->values[src].owner,&observed);c->busy=
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                        0
# 332 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                             ;
            if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
            value=fr_view(c->types[base+1]);value.fields=9u;
            if(!fr_error_payload(((observed).error),value.values))return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
            NlWsTransportResult error;c->busy=
# 336 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                    1
# 336 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                        ;core=nl_ws_connect_take_error(c->files,&c->values[src].owner,&error);c->busy=
# 336 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                      0
# 336 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                           ;
        }
        if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
    } else {
        const NlServicePlanType *catalog=nl_websocket_catalog_type(input.type.catalog_ordinal);NvmWebSocketFlowDeclaration type;
        if(!catalog || !fr_member(c,ordinal,catalog->members[arm==NVM_WEBSOCKET_FLOW_ARM_ERROR].type_id,&type))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        value=fr_view(type);value.fields=input.fields;memcpy(value.values,input.values,sizeof value.values);
    }
    fr_clear(c,src);c->values[dst].view=value;return NVM_WEBSOCKET_RUNTIME_OK;
}
static 
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 347 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_reference(const NvmWebSocketRuntime *c,uint32_t index) {
    if(index>=c->storage.references)return 
# 348 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                          0
# 348 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                               ;
    const FileRuntimeReference *r=&c->references[index];
    if(!r->live || r->origin>=c->storage.references)return 
# 350 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                          0
# 350 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                               ;
    const FileRuntimeReference *origin=&c->references[r->origin];
    return origin->live && !origin->formal && origin->origin==r->origin &&
           origin->shared==r->shared && ((origin->borrow).epoch)==((r->borrow).epoch) && origin->owner_root==r->owner_root &&
           fr_live(c,r->owner_root) && c->values[r->owner_root].view.owning &&
           c->values[r->owner_root].view.type.category==NVM_WEBSOCKET_CATEGORY_CONN;
}
static 
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
      _Bool 
# 357 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
           fr_aliases(const NvmWebSocketRuntime *c,uint32_t origin) {
    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live && c->references[i].formal && c->references[i].origin==origin)return 
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                                              1
# 358 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                                                  ;
    return 
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
          0
# 359 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
               ;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_begin(NvmWebSocketRuntime *c) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(c->region_count==c->storage.regions || c->next_region==
# 363 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                             (18446744073709551615UL)
# 363 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                       )return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
    c->regions[c->region_count++]=c->next_region++;return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketRuntimeStatus file_runtime_borrow_mode(NvmWebSocketRuntime *c,uint32_t owner,uint32_t reference,
# 366 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                      _Bool 
# 366 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                           shared) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_live(c,owner) || c->values[owner].view.type.category!=NVM_WEBSOCKET_CATEGORY_CONN ||
       !c->values[owner].view.owning || !c->region_count || reference>=c->storage.references || c->references[reference].live)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    FileRuntimeReference r={0};r.owner_root=owner;r.origin=reference;r.formal_root=
# 371 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                  (4294967295U)
# 371 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                ;
    r.region=c->regions[c->region_count-1];r.shared=shared;
    if(shared)for(uint32_t i=0;i<c->storage.references;i++) {
        const FileRuntimeReference *prior=&c->references[i];
        if(!prior->live || prior->owner_root!=owner)continue;
        if(!prior->shared || !fr_reference(c,i))return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
        r.origin=prior->origin;r.borrow=prior->borrow;r.live=
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                            1
# 377 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                ;
        c->references[reference]=r;return NVM_WEBSOCKET_RUNTIME_OK;
    }
    c->busy=
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
           1
# 380 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
               ;
    NlWsValueStatus core=nl_ws_value_borrow(c->files,&c->values[owner].owner,&r.borrow);c->busy=
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                             0
# 381 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                  ;
    if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
    r.live=
# 383 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
          1
# 383 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
              ;c->references[reference]=r;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow(NvmWebSocketRuntime *c,uint32_t owner,uint32_t reference) {
    return file_runtime_borrow_mode(c,owner,reference,
# 386 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                     0
# 386 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                          );
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_borrow_shared(NvmWebSocketRuntime *c,uint32_t owner,uint32_t reference) {
    return file_runtime_borrow_mode(c,owner,reference,
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                     1
# 389 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                         );
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_bind_formal(NvmWebSocketRuntime *c,uint32_t source,uint32_t root,uint32_t reference) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_reference(c,source) || !fr_empty(c,root) || reference>=c->storage.references || c->references[reference].live)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    FileRuntimeReference r=c->references[source];r.formal=
# 395 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                         1
# 395 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                             ;r.formal_root=root;r.region=0;
    NvmWebSocketRuntimeView value=fr_view(c->values[r.owner_root].view.type);value.type.mode=r.shared?1:2;value.owning=
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                        0
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                             ;value.formal=
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                                           1
# 396 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                                               ;
    c->references[reference]=r;c->values[root].view=value;c->values[root].reference=reference;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_end_reference(NvmWebSocketRuntime *c,uint32_t reference) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!fr_reference(c,reference))return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    FileRuntimeReference *r=&c->references[reference];
    if(r->formal) {
        if(!fr_live(c,r->formal_root) || !c->values[r->formal_root].view.formal || c->values[r->formal_root].reference!=reference)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
        fr_clear(c,r->formal_root);
    } else {
        uint32_t replacement=
# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                            (4294967295U)
# 408 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                          ;
        if(r->shared)for(uint32_t i=0;i<c->storage.references;i++)
            if(i!=reference && c->references[i].live && !c->references[i].formal &&
               c->references[i].shared && c->references[i].origin==r->origin) {replacement=i;break;}
        if(replacement!=
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                       (4294967295U)
# 412 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                     ) {
            if(r->origin==reference)for(uint32_t i=0;i<c->storage.references;i++)
                if(c->references[i].live && c->references[i].origin==reference)c->references[i].origin=replacement;
        } else {
            if(fr_aliases(c,r->origin))return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
            c->busy=
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                   1
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                       ;NlWsValueStatus core=nl_ws_value_end_borrow(c->files,&r->borrow);c->busy=
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                               0
# 417 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                    ;
            if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
        }
    }
    *r=(FileRuntimeReference){0};return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_region_end(NvmWebSocketRuntime *c) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!c->region_count)return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    uint64_t region=c->regions[c->region_count-1];
    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live && !c->references[i].formal &&
       c->references[i].region==region && fr_aliases(c,i))return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live && !c->references[i].formal && c->references[i].region==region) {
        status=nvm_websocket_runtime_end_reference(c,i);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    }
    c->regions[--c->region_count]=0;return NVM_WEBSOCKET_RUNTIME_OK;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
           fr_ws_fields(const NvmWebSocketRuntime *c,NvmWebSocketFlowDeclaration type,
                        const int64_t *values,uint8_t fields) {
    if(type.tag==TAG_VOID)return !fields;
    if(type.tag==TAG_INT)return fields==1;
    if(type.tag==TAG_BOOL)return fields==1 && (values[0]==0 || values[0]==1);
    if(type.tag==TAG_STRING)return fields==1 && fr_string_identity(c,values[0]);
    if(type.category!=NVM_WEBSOCKET_CATEGORY_RECORD || !((type.catalog_ordinal)<7u) ||
       !fr_same(type,c->types[type.catalog_ordinal]))return 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                                                           0
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                                ;
    const NlServicePlanType *record=nl_websocket_catalog_type(type.catalog_ordinal);
    if(!record || fields!=record->member_count || fields>9u)return 
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                                                                                            0
# 11 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                                                                 ;
    for(uint8_t i=0;i<fields;i++) {
        NvmWebSocketFlowDeclaration member;
        if(!fr_member(c,type.catalog_ordinal,record->members[i].type_id,&member) ||
           (member.tag!=TAG_INT && member.tag!=TAG_BOOL && member.tag!=TAG_STRING) ||
           !fr_ws_fields(c,member,values+i,1))return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                                                    0
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                         ;
    }
    return 
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
          1
# 18 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
              ;
}
static 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
      _Bool 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
           fr_ws_payload(const NvmWebSocketRuntime *c,const NvmWebSocketRuntimeView *p) {
    if(!p->initialized || p->owning || p->formal || p->type.mode)return 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                                                                       0
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                                            ;
    if(p->type.category!=NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT)
        return p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE && fr_ws_fields(c,p->type,p->values,p->fields);
    const NlServicePlanType *type=nl_websocket_catalog_type(p->type.catalog_ordinal);
    if(!type || !fr_same(p->type,c->types[p->type.catalog_ordinal]) ||
       (p->arm!=NVM_WEBSOCKET_FLOW_ARM_OK && p->arm!=NVM_WEBSOCKET_FLOW_ARM_ERROR))return 
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                                                                                         0
# 26 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                                                              ;
    NvmWebSocketFlowDeclaration member;
    return fr_member(c,p->type.catalog_ordinal,type->members[p->arm==NVM_WEBSOCKET_FLOW_ARM_ERROR].type_id,&member) &&
        fr_ws_fields(c,member,p->values,p->fields);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_service(NvmWebSocketRuntime *c,uint32_t import,
    uint32_t reference,const uint32_t *inputs,size_t count,uint32_t output) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    uint32_t ordinal;
    if(!fr_empty(c,output) || !fr_import(c,import,&ordinal) || ordinal>=4u)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    if(c->kind!=FR_ACYCLIC) {
        const FileRuntimeFrame *frame=&c->frames[c->frame_count-1];
        NvmWebSocketCodeInstruction instruction;NvmWebSocketBodyInstruction fact;
        if(!fr_instruction(c,frame->function,(uint16_t)frame->instruction,frame->variant,&instruction,&fact) ||
           instruction.decoded.opcode!=OP_FILE_SERVICE || instruction.decoded.operands[0].u32!=import ||
           instruction.catalog_ordinal!=ordinal)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    }
    const NlServicePlanMethod *method=nl_websocket_catalog_method(ordinal);
    
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
   _Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
        borrowed=method->input_mode==NL_SERVICE_INPUT_EXCLUSIVE;
    
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
   _Bool 
# 47 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
        consumed=method->input_mode==NL_SERVICE_INPUT_CONSUME;
    size_t offset=borrowed?1:0;
    if(count!=method->param_count-1-offset || (count && !inputs))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
    if(borrowed) {
        if(!fr_reference(c,reference) || c->references[reference].shared)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
        if(!fr_same(c->values[c->references[reference].owner_root].view.type,c->types[0]))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    } else if(reference!=
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                        (4294967295U)
# 56 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                                     )
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    for(size_t i=0;i<count;i++) {
        for(size_t j=0;j<i;j++)if(inputs[i]==inputs[j])return fr_error(c,NVM_WEBSOCKET_RUNTIME_INVALID,NL_WS_VALUE_ARGUMENT);
        NvmWebSocketFlowDeclaration expected;
        if(!fr_live(c,inputs[i]) || !fr_member(c,0,method->params[i+offset].type_id,&expected))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        const NvmWebSocketRuntimeView *value=&c->values[inputs[i]].view;
        
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
       _Bool 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
            owner=consumed && !i;
        if(!fr_same(value->type,expected) || value->formal || value->owning!=owner ||
           (!owner && !fr_ws_payload(c,value)))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    }
    int64_t timeout=c->values[inputs[count-1]].view.values[0];
    NlWsValueStatus core;NlWsTransportResult actual={0};NlWsMessage message={0};
    c->busy=
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
           1
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
               ;
    switch(ordinal) {
    case 0: {
        const ServiceRuntimeString *url=fr_string(c,inputs[0]);
        core=nl_ws_values_connect(c->files,url->bytes,url->length,timeout,&c->values[output].owner);break;
    }
    case 1: {
        const NvmWebSocketRuntimeView *value=&c->values[inputs[0]].view;
        const ServiceRuntimeString *data=fr_string_identity(c,value->values[1]);
        core=nl_ws_value_send(c->files,&c->references[reference].borrow,value->values[0]!=0,
            data->bytes,data->length,timeout,&actual);break;
    }
    case 2:core=nl_ws_value_receive(c->files,&c->references[reference].borrow,timeout,&message,&actual);break;
    default:core=nl_ws_value_close(c->files,&c->values[inputs[0]].owner,timeout,&actual);break;
    }
    c->busy=
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
           0
# 86 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                ;
    if(core!=NL_WS_VALUE_OK){nl_ws_message_free(&message);return fr_core(c,core);}
    for(size_t i=0;i<count;i++)fr_clear(c,inputs[i]);
    if(!ordinal){c->values[output].view=fr_view(c->types[3]);return NVM_WEBSOCKET_RUNTIME_OK;}
    NvmWebSocketRuntimeView result=fr_view(c->types[ordinal+3]);
    result.arm=actual.status==NL_WS_TRANSPORT_OK?NVM_WEBSOCKET_FLOW_ARM_OK:NVM_WEBSOCKET_FLOW_ARM_ERROR;
    if(result.arm==NVM_WEBSOCKET_FLOW_ARM_ERROR) {
        result.fields=9u;fr_error_payload(actual,result.values);
    } else if(ordinal==1) {
        if(actual.bytes>
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
                       (9223372036854775807L)
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
                                )return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
        result.fields=1;result.values[0]=(int64_t)actual.bytes;
    } else if(ordinal==2) {
        status=nvm_websocket_runtime_string(c,output,message.bytes,message.length);
        
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc" 3 4
       _Bool 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_service.inc"
            binary=message.binary;nl_ws_message_free(&message);
        if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
        result.fields=2;result.values[0]=binary;result.values[1]=c->values[output].view.values[0];
    }
    nl_ws_message_free(&message);
    c->values[output].view=result;return NVM_WEBSOCKET_RUNTIME_OK;
}
# 436 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 502 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
NvmWebSocketRuntimeStatus nvm_websocket_runtime_complete_root(NvmWebSocketRuntime *c,uint32_t root) {
    NvmWebSocketRuntimeStatus status=fr_effect(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(c->kind!=FR_ACYCLIC) {
        NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
        FileRuntimeFrame *f=&c->frames[c->frame_count-1];
        if(c->frame_count!=1 || !fr_instruction(c,f->function,(uint16_t)f->instruction,f->variant,&in,&fact) ||
           in.decoded.opcode!=OP_RET || !fact.exit_checked)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    }
    
# 511 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
   _Bool 
# 511 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
        initializer=c->current_root==c->startup.initializer;
    NvmWebSocketHostedFunction fn;
    if(!fr_function(c,c->current_root,&fn))return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    if(initializer) {
        if(root!=
# 515 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                (4294967295U) 
# 515 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                               || fn.code.declaration.result_count)return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    } else if(!fr_live(c,root) || !fr_same(c->values[root].view.type,fn.code.declaration.result) ||
              c->values[root].view.owning || c->values[root].view.formal ||
              (c->values[root].view.type.tag!=TAG_INT && c->values[root].view.type.tag!=TAG_BOOL))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(c->region_count)return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live)return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    for(uint32_t i=0;i<c->storage.values;i++)if(c->values[i].view.initialized &&
       (c->values[i].view.owning || c->values[i].view.formal))return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    if(initializer) {
        NlWsValuesFinish observed;
        if(!nl_ws_values_report(c->files,&observed))return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
        if(observed.execution!=NL_WS_VALUE_OK || observed.cleanup_failures)
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_CLEANUP,observed.execution);
    }
    if(!initializer)c->result=c->values[root].view;
    memset(c->values,0,(size_t)c->storage.values*sizeof *c->values);
    memset(c->frames,0,(size_t)c->storage.frames*sizeof *c->frames);c->frame_count=0;
    if(initializer)c->current_root=c->startup.entry;
    else c->complete=
# 534 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                    1
# 534 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                        ;
    return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketRuntimeReport fr_refused(NvmWebSocketRuntimeStatus status) {
    NvmWebSocketRuntimeReport report={0};report.status=status;
    report.function=report.instruction=0xFFFFFFFFu;return report;
}
static NvmWebSocketRuntimeReport fr_finish(NvmWebSocketRuntime *c,NvmWebSocketRuntimeView *out) {
    if(!c)return fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID);
    if(c->busy)return fr_refused(NVM_WEBSOCKET_RUNTIME_BUSY);
    if(c->phase==FR_TERMINAL) {
        if(c->report.status==NVM_WEBSOCKET_RUNTIME_OK && out)*out=c->result;
        return c->report;
    }
    if(!c->complete && c->report.status==NVM_WEBSOCKET_RUNTIME_OK)fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    c->busy=
# 549 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
           1
# 549 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
               ;


    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live && c->references[i].formal) {
        uint32_t root=c->references[i].formal_root;
        if(root<c->storage.values && c->values[root].view.formal && c->values[root].reference==i)fr_clear(c,root);
        else fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
        c->references[i]=(FileRuntimeReference){0};
    }
    if(c->acquired) {
        for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live) {
            if(!c->references[i].shared || c->references[i].origin==i) {
                NlWsValueStatus core=nl_ws_value_end_borrow(c->files,&c->references[i].borrow);
                if(core!=NL_WS_VALUE_OK)fr_core(c,core);
            }
            c->references[i]=(FileRuntimeReference){0};
        }
        for(uint32_t i=0;i<c->storage.values;i++) {
            if(c->values[i].view.initialized && c->values[i].view.owning) {
                NlWsValueStatus core=nl_ws_value_drop(c->files,&c->values[i].owner);
                if(core!=NL_WS_VALUE_OK)fr_core(c,core);
            }
            fr_clear(c,i);
        }
        NlWsValueStatus execution=c->report.status==NVM_WEBSOCKET_RUNTIME_OK?NL_WS_VALUE_OK:
            c->report.core_status==NL_WS_VALUE_OK?NL_WS_VALUE_STATE:c->report.core_status;
        c->report.cleanup=nl_ws_values_destroy(c->files,execution);c->files=
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                              ((void *)0)
# 575 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                  ;
        if(c->report.status==NVM_WEBSOCKET_RUNTIME_OK &&
           (c->report.cleanup.execution!=NL_WS_VALUE_OK || c->report.cleanup.cleanup_failures))
            fr_error(c,NVM_WEBSOCKET_RUNTIME_CLEANUP,c->report.cleanup.execution);
    } else c->report.cleanup.execution=c->report.core_status;
    memset(c->regions,0,(size_t)c->storage.regions*sizeof *c->regions);c->region_count=0;
    for(uint32_t i=0;i<c->string_count;i++){free(c->strings[i]);c->strings[i]=
# 581 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                             ((void *)0)
# 581 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                 ;}
    c->string_count=0;
    c->frame_count=0;c->busy=
# 583 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                            0
# 583 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                 ;c->phase=FR_TERMINAL;
    if(c->report.status==NVM_WEBSOCKET_RUNTIME_OK && out)*out=c->result;
    return c->report;
}
NvmWebSocketRuntimeReport nvm_websocket_runtime_finish(NvmWebSocketRuntime *c,NvmWebSocketRuntimeView *out) {
    if(c && c->kind!=FR_ACYCLIC)return fr_refused(NVM_WEBSOCKET_RUNTIME_STATE);
    return fr_finish(c,out);
}
NvmWebSocketRuntimeReport nvm_websocket_runtime_destroy(NvmWebSocketRuntime **address,NvmWebSocketRuntimeView *out) {
    if(!address || !*address)return fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID);
    NvmWebSocketRuntime *c=*address;
    if(c->kind!=FR_ACYCLIC)return fr_refused(NVM_WEBSOCKET_RUNTIME_STATE);
    if(c->busy)return fr_refused(NVM_WEBSOCKET_RUNTIME_BUSY);
    NvmWebSocketRuntimeReport report=nvm_websocket_runtime_finish(c,out);
    free(c->frames);free(c->regions);free(c->references);free(c->values);nvm_websocket_hosted_free(c->plan);free(c);*address=
# 597 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 3 4
                                                                                                                          ((void *)0)
# 597 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc"
                                                                                                                              ;
    return report;
}

# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_current(const NvmWebSocketRuntime *c,NvmWebSocketHostedFunction *fn,
                        NvmWebSocketCodeInstruction *in,NvmWebSocketBodyInstruction *fact) {
    if(!c || c->busy || c->phase!=FR_ACTIVE || !c->acquired || c->complete ||
       c->report.status!=NVM_WEBSOCKET_RUNTIME_OK || !c->frame_count || c->frame_count>c->storage.frames)return 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                                                0
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                                                     ;
    const FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    return !f->waiting && fr_function(c,f->function,fn) &&
           f->instruction<=
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                          (65535) 
# 8 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                     && fr_instruction(c,f->function,
               (uint16_t)f->instruction,f->variant,in,fact) && fact->reachable &&
           f->stack_count==fact->input_stack;
}
static NvmWebSocketRuntimeStatus frf_ready(NvmWebSocketRuntime *c,NvmWebSocketHostedFunction *fn,
                                      NvmWebSocketCodeInstruction *in,NvmWebSocketBodyInstruction *fact) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(!frf_current(c,fn,in,fact) || (c->kind!=FR_ACYCLIC &&
       !c->frames[c->frame_count-1].instruction_open))return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
    c->report.function=c->frames[c->frame_count-1].function;
    c->report.instruction=in->byte_offset;return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketRuntimeStatus frf_bad(NvmWebSocketRuntime *c) {
    return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
}
static 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 23 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_matches(NvmWebSocketRuntimeView v,NvmWebSocketFlowDeclaration type) {
    
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
   _Bool 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
        owner=type.category==NVM_WEBSOCKET_CATEGORY_CONN || type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT;
    return v.initialized && fr_same(v.type,type) && v.formal==(type.mode!=0) &&
           v.owning==(owner && !type.mode);
}
static 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 28 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_range(const NvmWebSocketRuntime *c,uint64_t base,uint64_t count) {
    return base<=c->storage.values && count<=c->storage.values-base;
}
static 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 31 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_empty_range(const NvmWebSocketRuntime *c,uint32_t base,uint32_t count) {
    if(!frf_range(c,base,count))return 
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                      0
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                           ;
    for(uint32_t i=0;i<count;i++)if(!fr_empty(c,base+i))return 
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                              0
# 33 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                   ;
    return 
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
          1
# 34 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
              ;
}
static 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_stack(const NvmWebSocketRuntime *c,const FileRuntimeFrame *f,
                      const NvmWebSocketHostedFunction *fn,uint32_t count) {
    if(count>fn->operand_peak || !frf_range(c,f->stack_base,fn->operand_peak) ||
       !frf_empty_range(c,f->staging_base,fn->staging_slots))return 
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                   0
# 39 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                        ;
    for(uint32_t i=0;i<fn->operand_peak;i++) {
        const NvmWebSocketRuntimeView *v=&c->values[f->stack_base+i].view;
        if(i<count?(!v->initialized || v->formal):v->initialized)return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                       0
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                            ;
    }
    return 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
          1
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
              ;
}
static 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_held(const NvmWebSocketRuntime *c,uint32_t root) {
    for(uint32_t i=0;i<c->storage.references;i++)
        if(c->references[i].live && c->references[i].owner_root==root)return 
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                            1
# 48 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                ;
    return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
          0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
               ;
}
static 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 51 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_layout(const NvmWebSocketRuntime *c,uint32_t function,uint64_t base,
                       uint16_t depth,FileRuntimeFrame *out,NvmWebSocketHostedFunction *fn) {
    if(depth>=c->storage.frames || !fr_function(c,function,fn) ||
       !fn->staging_slots || fn->locals!=fn->code.declaration.locals)return 
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                           0
# 54 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                ;
    uint64_t extent=c->mode==NVM_WEBSOCKET_RUNTIME_VM?fn->vm_value_slots:fn->native_value_slots;
    uint64_t stage=base+fn->locals,stack=stage+fn->staging_slots;
    uint64_t refs=(uint64_t)depth*256u;
    if(!frf_range(c,base,extent) || stack>c->storage.values ||
       !frf_range(c,stack,fn->operand_peak) || refs>c->storage.references ||
       256u>c->storage.references-refs ||
       fn->frames>c->storage.frames-depth)return 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                0
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                     ;
    *out=(FileRuntimeFrame){.function=function,.locals_base=(uint32_t)base,
        .stack_base=(uint32_t)stack,.staging_base=(uint32_t)stage,
        .reference_base=(uint32_t)refs,.region_base=c->region_count};return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                           1
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                               ;
}
static 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
      _Bool 
# 66 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
           frf_next_fact(const NvmWebSocketRuntime *c,uint32_t function,uint16_t index,uint8_t variant,uint32_t count) {
    NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    return fr_instruction(c,function,index,variant,&in,&fact) &&
           fact.reachable && fact.input_stack==count;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_start(NvmWebSocketRuntime *c) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame frame;NvmWebSocketHostedFunction fn;
    if(!c->acquired || c->frame_count || c->region_count ||
       !frf_layout(c,c->current_root,0,0,&frame,&fn) || fn.code.declaration.parameters ||
       !frf_next_fact(c,c->current_root,0,0,0) || !frf_empty_range(c,0,c->storage.values))return frf_bad(c);
    for(uint32_t i=0;i<c->storage.references;i++)if(c->references[i].live)return frf_bad(c);
    c->frames[0]=frame;c->frame_count=1;
    if(c->kind!=FR_ACYCLIC && frc_validate(c,&frame)!=NVM_WEBSOCKET_RUNTIME_OK)return c->report.status;
    return nvm_websocket_runtime_site(c,frame.function,0);
}

# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 82 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_view(const NvmWebSocketRuntime *c,NvmWebSocketRuntimeFrameView *out) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    if(!out || !frf_current(c,&fn,&in,&fact))return 
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                   0
# 84 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                        ;
    const FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    *out=(NvmWebSocketRuntimeFrameView){c->mode,f->function,f->instruction,in.byte_offset,c->frame_count,
        fn.locals,fn.staging_slots,fn.operand_peak,f->locals_base,f->staging_base,f->stack_base,
        f->stack_count,f->reference_base,f->region_base};return 
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                               1
# 88 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                   ;
}

# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 90 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_local(const NvmWebSocketRuntime *c,uint16_t local,uint32_t *out) {
    NvmWebSocketRuntimeFrameView f;
    if(!out || !nvm_websocket_runtime_frame_view(c,&f) || local>=f.locals)return 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                              0
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                   ;
    *out=f.locals_base+local;return 
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                   1
# 93 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                       ;
}

# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 95 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_operand(const NvmWebSocketRuntime *c,uint16_t index,uint32_t *out) {
    NvmWebSocketRuntimeFrameView f;
    if(!out || !nvm_websocket_runtime_frame_view(c,&f) || index>=f.stack_count ||
       !fr_live(c,f.stack_base+index))return 
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                            0
# 98 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                 ;
    *out=f.stack_base+index;return 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                  1
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                      ;
}

# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 101 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_reserve(const NvmWebSocketRuntime *c,uint16_t index,uint32_t *out) {
    NvmWebSocketRuntimeFrameView f;
    if(!out || !nvm_websocket_runtime_frame_view(c,&f) || index>=f.operand_peak ||
       !fr_empty(c,f.stack_base+index))return 
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                             0
# 104 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                  ;
    *out=f.stack_base+index;return 
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                  1
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                      ;
}

# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 107 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_scratch(const NvmWebSocketRuntime *c,uint32_t *out) {
    NvmWebSocketRuntimeFrameView f;
    if(!out || !nvm_websocket_runtime_frame_view(c,&f) || !f.staging_slots)return 
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                               0
# 109 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                    ;
    uint64_t slot=(uint64_t)f.staging_base+f.staging_slots-1;
    if(slot>=c->storage.values || !fr_empty(c,(uint32_t)slot))return 
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                    0
# 111 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                         ;
    *out=(uint32_t)slot;return 
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                              1
# 112 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                  ;
}

# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
_Bool 
# 114 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
    nvm_websocket_runtime_frame_reference(const NvmWebSocketRuntime *c,uint16_t index,uint32_t *out) {
    NvmWebSocketRuntimeFrameView f;
    if(!out || !nvm_websocket_runtime_frame_view(c,&f) || index>=256u)return 
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                                    0
# 116 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                                         ;
    *out=f.reference_base+index;return 
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                      1
# 117 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                          ;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_store(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];uint16_t local=in.decoded.operands[0].u16;
    
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
   _Bool 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
        owner=in.decoded.opcode==OP_OWN_STORE_LOCAL;NvmWebSocketFlowDeclaration expected;
    if((!owner && in.decoded.opcode!=OP_STORE_LOCAL) || !f->stack_count || local>=fn.locals ||
       !frf_stack(c,f,&fn,f->stack_count) || !fr_local(c,f->function,local,&expected))return frf_bad(c);
    uint32_t src=f->stack_base+f->stack_count-1,dst=f->locals_base+local;
    NvmWebSocketRuntimeView v=c->values[src].view;
    if(!owner && v.initialized && !v.owning && !v.formal &&
       v.type.tag==TAG_VOID && !v.type.mode && v.type.global_index==0xFFFFFFFFu &&
       expected.tag!=TAG_VOID && !expected.mode &&
       expected.category!=NVM_WEBSOCKET_CATEGORY_CONN && expected.category!=NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT) {
        if(fr_live(c,dst) && !frf_matches(c->values[dst].view,expected))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        fr_clear(c,dst);fr_clear(c,src);return NVM_WEBSOCKET_RUNTIME_OK;
    }
    if(expected.mode || !frf_matches(v,expected) || v.owning!=owner ||
       (owner?(!fr_empty(c,dst) || frf_held(c,src)):
        (fr_live(c,dst) && !frf_matches(c->values[dst].view,expected))))
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    if(!owner)fr_clear(c,dst);
    return nvm_websocket_runtime_move(c,src,dst);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_next(NvmWebSocketRuntime *c,uint8_t successor) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    uint8_t next;
    if(!frc_edge(c,f,successor,&next) || isa_is_file_indirect_call(in.decoded.opcode) || in.decoded.opcode==OP_CALL || (in.decoded.opcode==OP_CALL_REF || in.decoded.opcode==OP_FILE_CALL_REFS) || in.decoded.opcode==OP_RET ||
       successor>=in.successor_count || !frf_stack(c,f,&fn,fact.output_stack) ||
       !frf_next_fact(c,f->function,in.successors[successor],next,fact.output_stack))return frf_bad(c);
    FileRuntimeFrame completed=*f;completed.stack_count=fact.output_stack;
    completed.instruction=in.successors[successor];completed.variant=next;completed.instruction_open=
# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                                    0
# 152 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                                         ;
    if(c->kind!=FR_ACYCLIC && frc_validate(c,&completed)!=NVM_WEBSOCKET_RUNTIME_OK)return c->report.status;
    *f=completed;
    return nvm_websocket_runtime_site(c,f->function,(uint16_t)f->instruction);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_call(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn,callee;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1],child;
    uint32_t target=in.decoded.operands[0].u32;
    
# 162 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
   _Bool 
# 162 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
        indirect=isa_is_file_indirect_call(in.decoded.opcode);
    uint32_t callable=
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                     (4294967295U)
# 163 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                   ;
    if(indirect) {
        if(c->kind!=FR_INDIRECT || !f->stack_count)return frf_bad(c);
        callable=f->stack_base+f->stack_count-1;
        if(!fr_live(c,callable))return frf_bad(c);
        const FileRuntimeValue *v=&c->values[callable];
        if(!frf_matches(v->view,fr_scalar_type(TAG_FUNCTION)) || v->view.fields ||
           v->callable_plan!=c->indirect_plan)return frf_bad(c);
        target=v->callable_target;
        if(!fr_call_target(c,f,&in,target))return frf_bad(c);
    }
    if((!indirect && in.decoded.opcode!=OP_CALL && (in.decoded.opcode!=OP_CALL_REF && in.decoded.opcode!=OP_FILE_CALL_REFS)) || in.successor_count!=1 ||
       !fact.has_obligation || fact.obligation.kind!=NVM_WEBSOCKET_FLOW_CALL || fact.obligation.target!=(indirect?0xFFFFFFFFu:target) ||
       fact.obligation.site!=in.byte_offset || !(fact.discharged_checks&NVM_WEBSOCKET_FLOW_CHECK_CALLEE) ||
       !frf_stack(c,f,&fn,f->stack_count) || !fr_function(c,target,&callee))return frf_bad(c);
    uint16_t parameters=callee.code.declaration.parameters,borrowed=0,values=0;
    uint32_t references[256u]={0};
    for(uint16_t i=0;i<parameters;i++) {
        NvmWebSocketFlowDeclaration type;
        if(!fr_local(c,target,i,&type))return frf_bad(c);
        if(type.mode) {
            if((indirect && in.decoded.opcode!=OP_FILE_CALL_INDIRECT_REFS) || (type.mode!=1 && type.mode!=2) || ++borrowed>256u || (in.decoded.opcode!=OP_CALL_REF && in.decoded.opcode!=OP_FILE_CALL_REFS && in.decoded.opcode!=OP_FILE_CALL_INDIRECT_REFS) ||
               in.call_references[i]>=256u ||
               (in.decoded.opcode==OP_CALL_REF && in.call_references[i]!=in.decoded.operands[1].u16))return frf_bad(c);
            uint32_t reference=f->reference_base+in.call_references[i];
            references[i]=reference;
            if(!fr_reference(c,reference))return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
            NvmWebSocketFlowDeclaration wanted=c->values[c->references[reference].owner_root].view.type;wanted.mode=type.mode;
            if(!fr_same(type,wanted) || c->references[reference].shared!=(type.mode==1))
                return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
            for(uint16_t j=0;j<i;j++) {
                NvmWebSocketFlowDeclaration prior;
                if(!fr_local(c,target,j,&prior))return frf_bad(c);
                if(prior.mode && (prior.mode!=1 || type.mode!=1) && c->references[references[j]].owner_root==c->references[reference].owner_root)
                    return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
            }
        } else {
            if((!indirect || in.decoded.opcode==OP_FILE_CALL_INDIRECT_REFS) && in.call_references[i]!=
# 200 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                                     (65535)
# 200 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                                                                     )return frf_bad(c);
            values++;
        }
    }
    if((in.decoded.opcode==OP_CALL_REF && borrowed!=1) ||
       ((in.decoded.opcode==OP_FILE_CALL_REFS || in.decoded.opcode==OP_FILE_CALL_INDIRECT_REFS) && !borrowed) ||
       parameters!=fact.obligation.parameters || borrowed!=fact.obligation.borrowed_inputs ||
       (uint32_t)values+(indirect?1u:0u)>f->stack_count || fn.staging_slots<parameters+1u+(indirect?1u:0u) ||
       callee.code.declaration.result_count!=fact.obligation.result_count ||
       (callee.code.declaration.result_count && !fr_same(callee.code.declaration.result,fact.obligation.result)))return frf_bad(c);
    uint32_t prefix=f->stack_count-values-(indirect?1u:0u);uint8_t next;
    if(!frc_edge(c,f,0,&next))return frf_bad(c);
    if((uint32_t)prefix+callee.code.declaration.result_count!=fact.output_stack ||
       fact.output_stack>fn.operand_peak || !frf_next_fact(c,f->function,in.successors[0],next,fact.output_stack))return frf_bad(c);
    uint64_t base=(uint64_t)f->stack_base+(c->mode==NVM_WEBSOCKET_RUNTIME_VM?prefix:fn.operand_peak);
    if(!frf_layout(c,target,base,c->frame_count,&child,&callee) || !frf_next_fact(c,target,0,0,0))return frf_bad(c);
    uint32_t end=child.stack_base+callee.operand_peak;
    for(uint32_t i=child.locals_base;i<end;i++) {
        
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
       _Bool 
# 218 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
            argument=i>=f->stack_base+prefix && i<f->stack_base+f->stack_count;
        if(!argument && !fr_empty(c,i))return frf_bad(c);
    }
    for(uint32_t i=0;i<256u;i++)
        if(c->references[child.reference_base+i].live)return frf_bad(c);
    uint32_t arg=f->stack_base+prefix;uint16_t owned=0;
    for(uint16_t i=0;i<parameters;i++) {
        NvmWebSocketFlowDeclaration type;
        if(!fr_local(c,target,i,&type))return frf_bad(c);
        if(type.mode)continue;
        NvmWebSocketRuntimeView value=c->values[arg].view;
        if(!frf_matches(value,type) || value.formal || (value.owning && frf_held(c,arg)))
            return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
        owned+=value.owning;arg++;
    }
    if(owned!=fact.obligation.owned_inputs)return frf_bad(c);


    if(indirect)fr_clear(c,callable);
    arg=f->stack_base+prefix;
    for(uint16_t i=0;i<parameters;i++) {
        NvmWebSocketFlowDeclaration type;
        if(!fr_local(c,target,i,&type))return frf_bad(c);
        if(type.mode)continue;
        status=nvm_websocket_runtime_move(c,arg++,f->staging_base+i);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    }
    for(uint16_t i=0;i<parameters;i++) {
        NvmWebSocketFlowDeclaration type;
        if(!fr_local(c,target,i,&type))return frf_bad(c);
        if(type.mode)status=nvm_websocket_runtime_bind_formal(c,references[i],child.locals_base+i,child.reference_base+i);
        else status=nvm_websocket_runtime_move(c,f->staging_base+i,child.locals_base+i);
        if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    }
    f->stack_count=prefix;f->selected_target=target;f->waiting=
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                              1
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                  ;f->instruction_open=
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                       0
# 251 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                            ;c->frames[c->frame_count++]=child;
    if(c->kind!=FR_ACYCLIC && frc_validate(c,&child)!=NVM_WEBSOCKET_RUNTIME_OK)return c->report.status;
    return nvm_websocket_runtime_site(c,child.function,0);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_return(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];uint8_t results=fn.code.declaration.result_count;
    if(in.decoded.opcode!=OP_RET || !fact.exit_checked || in.successor_count ||
       f->stack_count!=results || !frf_stack(c,f,&fn,results) || c->region_count!=f->region_base)return frf_bad(c);
    uint32_t result=results?f->stack_base:
# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                         (4294967295U)
# 261 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                       ;
    if(results && (!frf_matches(c->values[result].view,fn.code.declaration.result) ||
       c->values[result].view.formal || frf_held(c,result)))return fr_error(c,NVM_WEBSOCKET_RUNTIME_TYPE,NL_WS_VALUE_TYPE);
    for(uint16_t i=0;i<fn.locals;i++) {
        NvmWebSocketRuntimeView v=c->values[f->locals_base+i].view;NvmWebSocketFlowDeclaration type;
        if(!fr_local(c,f->function,i,&type) ||
           (v.initialized && v.owning) || (type.mode && !frf_matches(v,type)))return frf_bad(c);
        if(v.formal) {
            uint32_t ref=f->reference_base+i;
            if(i>=fn.code.declaration.parameters ||
               !frf_matches(v,type) || c->values[f->locals_base+i].reference!=ref ||
               !fr_reference(c,ref) || !c->references[ref].formal ||
               c->references[ref].formal_root!=f->locals_base+i)return frf_bad(c);
        }
    }
    for(uint32_t i=0;i<256u;i++) {
        FileRuntimeReference *r=&c->references[f->reference_base+i];
        if(r->live && (!r->formal || i>=fn.code.declaration.parameters ||
           !fr_live(c,f->locals_base+i) || !c->values[f->locals_base+i].view.formal ||
           r->formal_root!=f->locals_base+i || !fr_reference(c,f->reference_base+i)))return frf_bad(c);
    }
    uint8_t next=0;
    FileRuntimeFrame *parent=
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                            ((void *)0)
# 283 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                ;NvmWebSocketHostedFunction caller={0};
    NvmWebSocketCodeInstruction call={0};NvmWebSocketBodyInstruction call_fact={0};uint32_t staged=
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                                                      (4294967295U)
# 284 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                                                                                    ;
    if(c->frame_count>1) {
        parent=&c->frames[c->frame_count-2];
        if(!parent->waiting || !fr_function(c,parent->function,&caller) ||
           !fr_instruction(c,parent->function,(uint16_t)parent->instruction,parent->variant,&call,&call_fact) ||
           call.successor_count!=1 || !fr_call_target(c,parent,&call,f->function) ||
           parent->selected_target!=f->function || !call_fact.has_obligation ||
           !frf_empty_range(c,parent->staging_base,caller.staging_slots) ||
           call_fact.output_stack!=parent->stack_count+results ||
           !frc_edge(c,parent,0,&next) ||
           !frf_next_fact(c,parent->function,call.successors[0],next,call_fact.output_stack))return frf_bad(c);
        for(uint32_t i=0;i<parent->stack_count;i++)if(!fr_live(c,parent->stack_base+i) ||
            c->values[parent->stack_base+i].view.formal)return frf_bad(c);
        staged=parent->staging_base+caller.staging_slots-1;
        if(results) { status=nvm_websocket_runtime_move(c,result,staged);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status; }
    }

    for(uint32_t i=0;i<256u;i++)if(c->references[f->reference_base+i].live) {
        status=nvm_websocket_runtime_end_reference(c,f->reference_base+i);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    }
    if(!parent) {
        if(f->function!=c->current_root)return frf_bad(c);
        return nvm_websocket_runtime_complete_root(c,result);
    }
    uint32_t end=f->stack_base+fn.operand_peak;
    for(uint32_t i=f->locals_base;i<end;i++)fr_clear(c,i);
    *f=(FileRuntimeFrame){0};c->frame_count--;
    c->transfer_active=
# 311 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                      1
# 311 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                          ;
    if(results) {
        status=nvm_websocket_runtime_move(c,staged,parent->stack_base+parent->stack_count);
        if(status!=NVM_WEBSOCKET_RUNTIME_OK){c->transfer_active=
# 314 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                                0
# 314 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                     ;return status;}
    }
    c->transfer_active=
# 316 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                      0
# 316 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                           ;
    if(!frf_stack(c,parent,&caller,call_fact.output_stack))return frf_bad(c);
    parent->stack_count=call_fact.output_stack;parent->waiting=
# 318 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                              0
# 318 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                                   ;parent->instruction=call.successors[0];
    parent->variant=next;parent->instruction_open=
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc" 3 4
                                                 0
# 319 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime_frames.inc"
                                                      ;parent->selected_target=0;
    if(c->kind!=FR_ACYCLIC && frc_validate(c,parent)!=NVM_WEBSOCKET_RUNTIME_OK)return c->report.status;
    return nvm_websocket_runtime_site(c,parent->function,(uint16_t)parent->instruction);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_begin(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    if(in.decoded.opcode!=OP_REGION_BEGIN || c->region_count<f->region_base ||
       c->region_count-f->region_base>=256u)return frf_bad(c);
    return nvm_websocket_runtime_region_begin(c);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_region_end(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(in.decoded.opcode!=OP_REGION_END || c->region_count<=c->frames[c->frame_count-1].region_base)return frf_bad(c);
    return nvm_websocket_runtime_region_end(c);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_borrow(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    uint16_t reference=in.decoded.operands[0].u16,local=in.decoded.operands[1].u16;
    if((in.decoded.opcode!=OP_BORROW_LOCAL_EXCLUSIVE && in.decoded.opcode!=OP_BORROW_LOCAL_SHARED) || reference>=256u ||
       local>=fn.locals || c->region_count<=f->region_base)return frf_bad(c);
    return in.decoded.opcode==OP_BORROW_LOCAL_SHARED?
        nvm_websocket_runtime_borrow_shared(c,f->locals_base+local,f->reference_base+reference):
        nvm_websocket_runtime_borrow(c,f->locals_base+local,f->reference_base+reference);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_frame_end_reference(NvmWebSocketRuntime *c) {
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];uint16_t index=in.decoded.operands[0].u16;
    if(in.decoded.opcode!=OP_FILE_END_BORROW || index>=256u ||
       !fr_reference(c,f->reference_base+index) || c->references[f->reference_base+index].formal)
        return fr_error(c,NVM_WEBSOCKET_RUNTIME_BORROWED,NL_WS_VALUE_BORROWED);
    return nvm_websocket_runtime_end_reference(c,f->reference_base+index);
}
# 602 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 1

static 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 2 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_identity(NlWsValue a,NlWsValue b) {
    return ((a).invocation==(b).invocation && (a).generation==(b).generation && (a).slot==(b).slot);
}
static 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_zero(NlWsValue a) { return (!(a).invocation && !(a).generation && !(a).slot); }
static NvmWebSocketRuntimeStatus frc_bad(NvmWebSocketRuntime *c) {
    return fr_error(c,NVM_WEBSOCKET_RUNTIME_STATE,NL_WS_VALUE_STATE);
}
static 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_payload(const NvmWebSocketRuntime *c,const FileRuntimeValue *v) {
    const NvmWebSocketRuntimeView *p=&v->view;
    if(p->initialized && p->type.tag==TAG_FUNCTION)
        return c->kind==FR_INDIRECT && !p->owning && !p->formal && !p->fields &&
            p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE && fr_same(p->type,fr_scalar_type(TAG_FUNCTION)) &&
            !v->reference && frc_zero(v->owner) && v->callable_plan==c->indirect_plan &&
            v->callable_target<c->startup.functions;
    if(v->callable_plan || v->callable_target)return 
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                    0
# 16 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                         ;
    if(!p->initialized) {
        if(!frc_zero(v->owner) || v->reference || p->owning || p->formal || p->fields ||
           p->arm || p->type.tag || p->type.mode || p->type.global_index ||
           p->type.catalog_ordinal || p->type.category)return 
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                             0
# 20 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                  ;
        for(uint8_t i=0;i<9u;i++)if(p->values[i])return 
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                  0
# 21 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                       ;
        return 
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
              1
# 22 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                  ;
    }
    if(p->owning)return 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                       1 
# 24 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                               && !p->formal && !p->fields && !v->reference;
    if(!frc_zero(v->owner))return 
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                 0
# 25 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                      ;
    if(p->formal)return (p->type.mode==1 || p->type.mode==2) && !p->fields;
    if(v->reference || p->type.mode)return 
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                          0
# 27 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                               ;
    if(p->type.tag==TAG_STRING)return p->fields==1 && p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE &&
        fr_same(p->type,fr_scalar_type(TAG_STRING)) && fr_string_identity(c,p->values[0]);
    if(p->type.tag==TAG_INT)return p->fields==1 && p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE;
    if(p->type.tag==TAG_BOOL)return p->fields==1 && p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE &&
        (p->values[0]==0 || p->values[0]==1);
    if(p->type.tag==TAG_VOID)return !p->fields && p->arm==NVM_WEBSOCKET_FLOW_ARM_NONE;
    const NlServicePlanType *type=nl_websocket_catalog_type(p->type.catalog_ordinal);
    if(!type)return 
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                   0
# 35 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                        ;
    if(p->type.category==NVM_WEBSOCKET_CATEGORY_RECORD) {
        if(p->fields!=type->member_count || p->fields>9u ||
           p->arm!=NVM_WEBSOCKET_FLOW_ARM_NONE)return 
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                      0
# 38 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                           ;
        for(uint8_t i=0;i<p->fields;i++) {
            const char *id=type->members[i].type_id;
            if(!id)return 
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                         0
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                              ;
            if(!strcmp(id,"nsi:core/bool")) {if(p->values[i]!=0 && p->values[i]!=1)return 
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                         0
# 42 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                              ;}
            else if(!strcmp(id,"nsi:core/string")) {if(!fr_string_identity(c,p->values[i]))return 
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                 0
# 43 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                      ;}
            else if(strcmp(id,"nsi:core/int"))return 
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                    0
# 44 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                         ;
        }
        return 
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
              1
# 46 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                  ;
    }
    if(p->type.category!=NVM_WEBSOCKET_CATEGORY_SCALAR_RESULT ||
       (p->arm!=NVM_WEBSOCKET_FLOW_ARM_OK && p->arm!=NVM_WEBSOCKET_FLOW_ARM_ERROR))return 
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                           0
# 49 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                ;
    return fr_ws_payload(c,p);
}
static 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 52 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_value(NvmWebSocketRuntime *c,uint32_t root,NvmWebSocketFlowValue expected) {
    if(root>=c->storage.values)return 
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                     0
# 53 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                          ;
    const FileRuntimeValue *v=&c->values[root];
    if(!frc_payload(c,v) || v->view.initialized!=expected.initialized)return 
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                            0
# 55 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                 ;
    if(!expected.initialized)return !expected.owner;
    if(!frf_matches(v->view,expected.type))return 
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                 0
# 57 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                      ;
    NvmWebSocketFlowArm actual=v->view.arm;
    if(v->view.owning) {
        
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
       _Bool 
# 60 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
            open=v->view.type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT;
        if(nl_ws_value_validate(c->files,&v->owner,open)!=NL_WS_VALUE_OK)return 
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                   0
# 61 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                        ;
        if(open) {
            NlWsConnectView view;
            if(nl_ws_connect_view(c->files,&v->owner,&view)!=NL_WS_VALUE_OK)return 
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                   0
# 64 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                        ;
            actual=view.ok?NVM_WEBSOCKET_FLOW_ARM_OK:NVM_WEBSOCKET_FLOW_ARM_ERROR;
        }
        if(!expected.owner || expected.owner>256u)return 
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                              0
# 67 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                   ;
        uint32_t index=(uint32_t)expected.owner-1;
        if(!frc_zero(c->witness->owners[index]))return 
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                      0
# 69 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                           ;
        for(uint32_t i=0;i<256u;i++)
            if(!frc_zero(c->witness->owners[i]) && frc_identity(c->witness->owners[i],v->owner))return 
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                      0
# 71 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                           ;
        c->witness->owners[index]=v->owner;c->witness->roots[index]=root;
    } else if(expected.owner)return 
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                   0
# 73 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                        ;
    return expected.arm==NVM_WEBSOCKET_FLOW_ARM_UNKNOWN?
        (actual==NVM_WEBSOCKET_FLOW_ARM_OK || actual==NVM_WEBSOCKET_FLOW_ARM_ERROR):actual==expected.arm;
}
static 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 77 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_reference_empty(const FileRuntimeReference *r) {
    return !r->live && !r->formal && !r->shared && !r->owner_root && !r->origin && !r->formal_root &&
        !r->region && !((r->borrow).epoch) && frc_zero(((r->borrow).value));
}
static 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
      _Bool 
# 81 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
           frc_frame(NvmWebSocketRuntime *c,const FileRuntimeFrame *f,uint32_t region_end) {
    NvmWebSocketCyclicVariant fact;NvmWebSocketHostedFunction fn;
    if(!fr_function(c,f->function,&fn) || f->instruction>
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                        (65535) 
# 83 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                   ||
       !fr_variant(c,f->function,(uint16_t)f->instruction,f->variant,&fact) ||
       !fact.body.reachable || fact.input.locals!=fn.locals || f->stack_count>fn.operand_peak ||
       (!f->waiting && f->stack_count!=fact.input.stack) ||
       (f->waiting && f->stack_count>fact.input.stack) ||
       !frf_range(c,f->locals_base,fn.locals) || !frf_range(c,f->stack_base,f->stack_count) ||
       !frf_empty_range(c,f->staging_base,fn.staging_slots) ||
       f->reference_base>c->storage.references || 256u>c->storage.references-f->reference_base ||
       f->region_base>region_end || region_end>c->region_count ||
       region_end-f->region_base!=fact.input.regions)return 
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                           0
# 92 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                ;
    if(f->waiting) {
        NvmWebSocketCodeInstruction in;
        if(!fr_code(c,f->function,(uint16_t)f->instruction,&in) ||
           !fr_call_target(c,f,&in,f->selected_target) || !fact.body.has_obligation ||
           (uint32_t)f->stack_count+fact.body.obligation.parameters-fact.body.obligation.borrowed_inputs+
               (isa_is_file_indirect_call(in.decoded.opcode)?1u:0u)!=fact.input.stack)
            return 
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                  0
# 99 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                       ;
    }
    memset(c->witness,0,sizeof *c->witness);
    for(uint16_t i=0;i<fn.locals;i++) {
        NvmWebSocketFlowValue v;
        if(!fr_input_local(c,f->function,(uint16_t)f->instruction,f->variant,i,&v) ||
           !frc_value(c,f->locals_base+i,v))return 
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                  0
# 105 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                       ;
    }
    for(uint16_t i=0;i<f->stack_count;i++) {
        NvmWebSocketFlowValue v;
        if(!fr_input_stack(c,f->function,(uint16_t)f->instruction,f->variant,i,&v) ||
           !frc_value(c,f->stack_base+i,v))return 
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                 0
# 110 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                      ;
    }
    for(uint16_t i=0;i<fact.input.regions;i++) {
        uint64_t abstract;
        if(!fr_input_region(c,f->function,(uint16_t)f->instruction,f->variant,i,&abstract) ||
           abstract!=513UL +i || !c->regions[f->region_base+i])return 
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                            0
# 115 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                 ;
    }
    for(uint16_t i=0;i<256u;i++) {
        NvmWebSocketFlowReference expected;const FileRuntimeReference *r=&c->references[f->reference_base+i];
        if(!fr_input_reference(c,f->function,(uint16_t)f->instruction,f->variant,i,&expected))return 
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                    0
# 119 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                         ;
        if(!expected.live){if(!frc_reference_empty(r))return 
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                            0
# 120 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                 ;continue;}
        if(!r->live || expected.formal!=r->formal || expected.shared!=r->shared || !fr_reference(c,f->reference_base+i) ||
           nl_ws_value_borrow_validate(c->files,&r->borrow)!=NL_WS_VALUE_OK ||
           !frc_identity(((r->borrow).value),c->values[r->owner_root].owner))return 
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                               0
# 123 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                    ;
        const FileRuntimeReference *origin=&c->references[r->origin];
        if(!frc_identity(((origin->borrow).value),((r->borrow).value)) || ((origin->borrow).epoch)!=((r->borrow).epoch))return 
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                                                                                              0
# 125 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                                                                                                   ;
        if(expected.formal) {
            if(i>=fn.code.declaration.parameters || expected.local!=i || expected.owner!=257UL +i ||
               expected.identity!=expected.owner || expected.region || r->region ||
               r->formal_root!=f->locals_base+i || !c->values[r->formal_root].view.formal ||
               c->values[r->formal_root].reference!=f->reference_base+i || r->origin>=f->reference_base)return 
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                              0
# 130 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                                   ;
        } else {
            if(!expected.owner || expected.owner>256u || expected.local>=fn.locals ||
               expected.identity!=769UL +i || expected.region<513 ||
               expected.region-513>=fact.input.regions || (!r->shared && r->origin!=f->reference_base+i) ||
               r->formal_root!=
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                              (4294967295U) 
# 135 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                             || r->owner_root!=f->locals_base+expected.local ||
               c->witness->roots[expected.owner-1]!=r->owner_root ||
               !frc_identity(c->witness->owners[expected.owner-1],((r->borrow).value)) ||
               r->region!=c->regions[f->region_base+(uint32_t)(expected.region-513)])return 
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                           0
# 138 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                ;
        }
    }
    return 
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
          1
# 141 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
              ;
}
static NvmWebSocketRuntimeStatus frc_validate(NvmWebSocketRuntime *c,const FileRuntimeFrame *current) {
    if(c->kind==FR_ACYCLIC || !c->witness || !c->frame_count ||
       c->frame_count>c->storage.frames || c->region_count>c->storage.regions || !c->acquired || !c->files)return frc_bad(c);
    uint64_t rooted[1u]={0},borrowed[1u]={0};


    for(uint32_t root=0;root<c->storage.values;root++) {
        FileRuntimeValue *v=&c->values[root];
        if(!frc_payload(c,v))return frc_bad(c);
        if(v->view.initialized) {
            
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
           _Bool 
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                covered=
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                        0
# 153 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                             ;
            for(uint16_t d=0;d<c->frame_count;d++) {
                const FileRuntimeFrame *f=d+1==c->frame_count?current:&c->frames[d];
                NvmWebSocketHostedFunction fn;if(!fr_function(c,f->function,&fn))return frc_bad(c);
                if((root>=f->locals_base && root-f->locals_base<fn.locals) ||
                   (root>=f->stack_base && root-f->stack_base<f->stack_count))covered=
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                     1
# 158 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                         ;
            }
            if(!covered)return frc_bad(c);
        }
        if(v->view.initialized && v->view.owning) {
            uint32_t instance=0u,slot=((v->owner).slot);
            if(instance>=1u || slot>=64 || (rooted[instance]&(1UL<<slot)))return frc_bad(c);
            NlWsValueStatus checked=nl_ws_value_validate(c->files,&v->owner,
                v->view.type.category==NVM_WEBSOCKET_CATEGORY_CONNECT_RESULT);
            if(checked!=NL_WS_VALUE_OK)return fr_core(c,checked);
            rooted[instance]|=1UL<<slot;
        }
    }
    for(uint32_t i=0;i<c->region_count;i++) {
        if(!c->regions[i])return frc_bad(c);
        for(uint32_t j=0;j<i;j++)if(c->regions[j]==c->regions[i])return frc_bad(c);
    }
    for(uint32_t i=c->region_count;i<c->storage.regions;i++)if(c->regions[i])return frc_bad(c);
    for(uint32_t i=(uint32_t)c->frame_count*256u;i<c->storage.references;i++)
        if(!frc_reference_empty(&c->references[i]))return frc_bad(c);
    for(uint32_t i=0;i<c->storage.references;i++) {
        const FileRuntimeReference *r=&c->references[i];
        if(r->live && !r->formal && r->origin==i) {
            NlWsValue owner=((r->borrow).value);
            uint32_t instance=0u,slot=((owner).slot);
            if(instance>=1u || slot>=64 || (borrowed[instance]&(1UL<<slot)))return frc_bad(c);
            borrowed[instance]|=1UL<<slot;
        }
    }
    for(uint32_t i=0;i<1u;i++) {
        uint64_t core_owners,core_borrowed;
        NlWsValueStatus core=nl_ws_values_live_slots((c)->files,&core_owners,&core_borrowed);
        if(core!=NL_WS_VALUE_OK)return fr_core(c,core);
        if(rooted[i]!=core_owners || borrowed[i]!=core_borrowed)return frc_bad(c);
    }
    uint64_t base=0;
    for(uint16_t d=0;d<c->frame_count;d++) {
        const FileRuntimeFrame *f=d+1==c->frame_count?current:&c->frames[d];
        FileRuntimeFrame layout;NvmWebSocketHostedFunction fn;
        if(!frf_layout(c,f->function,base,d,&layout,&fn) || f->locals_base!=layout.locals_base ||
           f->stack_base!=layout.stack_base || f->staging_base!=layout.staging_base ||
           f->reference_base!=layout.reference_base || (d==0 && f->region_base))return frc_bad(c);
        if(d+1<c->frame_count) {
            NvmWebSocketCodeInstruction call;
            if(!fr_code(c,f->function,(uint16_t)f->instruction,&call) ||
               !fr_call_target(c,f,&call,c->frames[d+1].function) ||
               f->selected_target!=c->frames[d+1].function)return frc_bad(c);
        }
        base=(uint64_t)f->stack_base+(c->mode==NVM_WEBSOCKET_RUNTIME_VM?f->stack_count:fn.operand_peak);
        uint32_t end=d+1==c->frame_count?c->region_count:c->frames[d+1].region_base;
        if((d+1<c->frame_count && !f->waiting) || !frc_frame(c,f,end))return frc_bad(c);
    }
    return NVM_WEBSOCKET_RUNTIME_OK;
}
const NvmWebSocketCyclicHostedPlan *nvm_websocket_runtime_cyclic_plan(const NvmWebSocketRuntime *c) {
    return c && c->kind==FR_CYCLIC?c->cyclic_plan:
# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                 ((void *)0)
# 213 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                     ;
}

# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
_Bool 
# 215 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
    nvm_websocket_runtime_cyclic_frame_view(const NvmWebSocketRuntime *c,NvmWebSocketCyclicFrameView *out) {
    NvmWebSocketRuntimeFrameView frame;
    if(!out || !c || c->kind!=FR_CYCLIC || !nvm_websocket_runtime_frame_view(c,&frame))return 
# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                           0
# 217 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                ;
    const FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    *out=(NvmWebSocketCyclicFrameView){1u,frame,f->variant,f->instruction_open};return 
# 219 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                                                            1
# 219 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                                                                ;
}
static NvmWebSocketRuntimeStatus frc_enter(NvmWebSocketRuntime *c) {
    NvmWebSocketRuntimeStatus status=fr_ready(c);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    NvmWebSocketHostedFunction fn;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    if(!frf_current(c,&fn,&in,&fact))return frc_bad(c);
    FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    if(f->instruction_open)return frc_bad(c);
    c->report.function=f->function;c->report.instruction=in.byte_offset;
    status=frc_validate(c,f);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    if(c->instructions_started>c->instruction_limit)return frc_bad(c);
    if(c->instructions_started==c->instruction_limit) {
        c->fuel_exhausted=
# 231 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                         1
# 231 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                             ;return fr_error(c,NVM_WEBSOCKET_RUNTIME_LIMIT,NL_WS_VALUE_LIMIT);
    }
    c->instructions_started++;f->instruction_open=
# 233 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                 1
# 233 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                     ;return NVM_WEBSOCKET_RUNTIME_OK;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_cyclic_enter(NvmWebSocketRuntime *c) {
    if(!c || c->kind!=FR_CYCLIC)return NVM_WEBSOCKET_RUNTIME_INVALID;
    return frc_enter(c);
}
static NvmWebSocketCyclicExecutionReport frc_report(const NvmWebSocketRuntime *c,NvmWebSocketRuntimeReport r) {
    return (NvmWebSocketCyclicExecutionReport){1u,r,
        c?c->instruction_limit:0,c?c->instructions_started:0,c?c->fuel_exhausted:
# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                                0
# 241 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                     };
}

# 243 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
_Bool 
# 243 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
    nvm_websocket_runtime_cyclic_report(const NvmWebSocketRuntime *c,NvmWebSocketCyclicExecutionReport *out) {
    if(!c || !out || c->kind!=FR_CYCLIC || c->busy)return 
# 244 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                         0
# 244 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                              ;
    *out=frc_report(c,c->report);return 
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                       1
# 245 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                           ;
}
NvmWebSocketCyclicExecutionReport nvm_websocket_runtime_cyclic_finish(NvmWebSocketRuntime *c,NvmWebSocketRuntimeView *out) {
    if(!c || c->kind!=FR_CYCLIC)return frc_report(
# 248 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                 ((void *)0)
# 248 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                     ,fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID));
    return frc_report(c,fr_finish(c,out));
}
NvmWebSocketCyclicExecutionReport nvm_websocket_runtime_cyclic_destroy(NvmWebSocketRuntime **address,NvmWebSocketRuntimeView *out) {
    if(!address || !*address || (*address)->kind!=FR_CYCLIC)return frc_report(
# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                             ((void *)0)
# 252 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                                 ,fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID));
    NvmWebSocketRuntime *c=*address;
    if(c->busy)return frc_report(c,fr_refused(NVM_WEBSOCKET_RUNTIME_BUSY));
    NvmWebSocketCyclicExecutionReport report=nvm_websocket_runtime_cyclic_finish(c,out);
    free(c->frames);free(c->regions);free(c->references);free(c->values);free(c->witness);
    nvm_websocket_cyclic_hosted_free(c->cyclic_plan);free(c);*address=
# 257 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
                                                                   ((void *)0)
# 257 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
                                                                       ;return report;
}

# 259 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
_Bool 
# 259 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
    nvm_websocket_runtime_cyclic_abi(uint32_t revision,size_t options,size_t report,size_t view,size_t frame) {
    return revision==1u && options==sizeof(NvmWebSocketCyclicOptions) &&
        report==sizeof(NvmWebSocketCyclicExecutionReport) && view==sizeof(NvmWebSocketRuntimeView) &&
        frame==sizeof(NvmWebSocketCyclicFrameView);
}




# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc" 3 4
_Bool 
# 267 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_cyclic_runtime.inc"
    nvm_websocket_runtime_cyclic_native_abi(uint32_t revision,size_t options,size_t report,
                                      size_t view,size_t frame,size_t value) {
    return revision==1u && frame==sizeof(NvmWebSocketRuntimeFrameView) &&
        nvm_websocket_runtime_cyclic_abi(revision,options,report,value,view);
}
# 603 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 1

const NvmWebSocketIndirectHostedPlan *nvm_websocket_runtime_indirect_plan(const NvmWebSocketRuntime *c) {
    return c && c->kind==FR_INDIRECT?c->indirect_plan:
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                     ((void *)0)
# 3 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                         ;
}

# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
_Bool 
# 5 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
    nvm_websocket_runtime_indirect_frame_view(const NvmWebSocketRuntime *c,NvmWebSocketIndirectFrameView *out) {
    NvmWebSocketRuntimeFrameView frame;
    if(!out || !c || c->kind!=FR_INDIRECT || !nvm_websocket_runtime_frame_view(c,&frame))return 
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                                                             0
# 7 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                                                                  ;
    const FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    *out=(NvmWebSocketIndirectFrameView){1u,frame,f->variant,f->instruction_open};return 
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                                                                                                1
# 9 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                                                                                                    ;
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_enter(NvmWebSocketRuntime *c) {
    if(!c || c->kind!=FR_INDIRECT)return NVM_WEBSOCKET_RUNTIME_INVALID;
    return frc_enter(c);
}
NvmWebSocketRuntimeStatus nvm_websocket_runtime_indirect_funcref(NvmWebSocketRuntime *c,uint32_t dst) {
    if(!c || c->kind!=FR_INDIRECT)return NVM_WEBSOCKET_RUNTIME_INVALID;
    NvmWebSocketHostedFunction fn,target;NvmWebSocketCodeInstruction in;NvmWebSocketBodyInstruction fact;
    NvmWebSocketRuntimeStatus status=frf_ready(c,&fn,&in,&fact);if(status!=NVM_WEBSOCKET_RUNTIME_OK)return status;
    const FileRuntimeFrame *f=&c->frames[c->frame_count-1];
    if(in.decoded.opcode!=OP_FUNCREF || !fr_function(c,in.decoded.operands[0].u32,&target) ||
       f->stack_count>=fn.operand_peak || dst!=f->stack_base+f->stack_count || !fr_empty(c,dst))return frf_bad(c);
    c->values[dst].view=fr_view(fr_scalar_type(TAG_FUNCTION));
    c->values[dst].callable_plan=c->indirect_plan;
    c->values[dst].callable_target=in.decoded.operands[0].u32;
    return NVM_WEBSOCKET_RUNTIME_OK;
}
static NvmWebSocketIndirectExecutionReport fri_report(const NvmWebSocketRuntime *c,NvmWebSocketRuntimeReport report) {
    return (NvmWebSocketIndirectExecutionReport){1u,report,
        c?c->instruction_limit:0,c?c->instructions_started:0,c?c->fuel_exhausted:
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                                                0
# 29 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                                                     };
}
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_finish(NvmWebSocketRuntime *c,NvmWebSocketRuntimeView *out) {
    if(!c || c->kind!=FR_INDIRECT)return fri_report(
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                   ((void *)0)
# 32 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                       ,fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID));
    return fri_report(c,fr_finish(c,out));
}
NvmWebSocketIndirectExecutionReport nvm_websocket_runtime_indirect_destroy(NvmWebSocketRuntime **address,NvmWebSocketRuntimeView *out) {
    if(!address || !*address || (*address)->kind!=FR_INDIRECT)return fri_report(
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                                               ((void *)0)
# 36 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                                                   ,fr_refused(NVM_WEBSOCKET_RUNTIME_INVALID));
    NvmWebSocketRuntime *c=*address;
    if(c->busy)return fri_report(c,fr_refused(NVM_WEBSOCKET_RUNTIME_BUSY));
    NvmWebSocketIndirectExecutionReport report=nvm_websocket_runtime_indirect_finish(c,out);
    free(c->frames);free(c->regions);free(c->references);free(c->values);free(c->witness);
    nvm_websocket_indirect_hosted_free(c->indirect_plan);free(c);*address=
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
                                                                       ((void *)0)
# 41 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
                                                                           ;return report;
}



# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc" 3 4
_Bool 
# 45 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_indirect_runtime.inc"
    nvm_websocket_runtime_indirect_native_abi(uint32_t revision,size_t options,size_t report,
                                        size_t view,size_t frame,size_t value) {
    return revision==1u && options==sizeof(NvmWebSocketIndirectOptions) &&
        report==sizeof(NvmWebSocketIndirectExecutionReport) && view==sizeof(NvmWebSocketIndirectFrameView) &&
        frame==sizeof(NvmWebSocketRuntimeFrameView) && value==sizeof(NvmWebSocketRuntimeView);
}
# 604 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/service_runtime.inc" 2
# 12 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
# 1 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_policy.inc" 1
NvmWebSocketRuntimeStatus nvm_websocket_runtime_policy(NvmWebSocketRuntime *c,const NlWsTransportPolicy *policy) {
    if(!c)return NVM_WEBSOCKET_RUNTIME_INVALID;
    if(c->busy)return NVM_WEBSOCKET_RUNTIME_BUSY;
    if(c->phase!=FR_READY || c->policy_set)return NVM_WEBSOCKET_RUNTIME_STATE;
    if(!policy || policy->max_timeout_ms>60000)return NVM_WEBSOCKET_RUNTIME_INVALID;
    size_t length=policy->resolver_helper?strnlen(policy->resolver_helper,sizeof c->resolver_helper):0;
    if(length>=sizeof c->resolver_helper || (policy->resolver_helper && (!length || policy->resolver_helper[0]!='/')))
        return NVM_WEBSOCKET_RUNTIME_INVALID;
    c->policy=*policy;
    if(policy->resolver_helper) {
        memcpy(c->resolver_helper,policy->resolver_helper,length+1);c->policy.resolver_helper=c->resolver_helper;
    }
    c->policy_set=
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_policy.inc" 3 4
                 1
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime_policy.inc"
                     ;return NVM_WEBSOCKET_RUNTIME_OK;
}
# 13 "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/file_product/../../src/nanoisa/websocket_runtime.c" 2
