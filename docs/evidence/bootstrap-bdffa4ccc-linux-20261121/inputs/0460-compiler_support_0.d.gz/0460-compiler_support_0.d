nano_module_dependencies: \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/compiler_support.c \
 /usr/include/stdc-predef.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/compiler_support.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/module_builder.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdbool.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stddef.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/nanolang.h \
 /usr/include/stdio.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/aarch64-linux-gnu/sys/types.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/alloca.h /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/string.h /usr/include/strings.h /usr/include/ctype.h \
 /usr/lib/gcc/aarch64-linux-gnu/13/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-least.h /usr/include/assert.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/generated/compiler_schema.h \
 src/runtime/dyn_array.h src/runtime/gc.h /usr/include/execinfo.h \
 /usr/include/unistd.h /usr/include/aarch64-linux-gnu/bits/posix_opt.h \
 /usr/include/aarch64-linux-gnu/bits/environments.h \
 /usr/include/aarch64-linux-gnu/bits/confname.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_posix.h \
 /usr/include/aarch64-linux-gnu/bits/getopt_core.h \
 /usr/include/aarch64-linux-gnu/bits/unistd_ext.h \
 /usr/include/linux/close_range.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/runtime/dyn_array.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/runtime/gc_struct.h \
 /home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/modules/compiler_support/../../src/runtime/gc.h \
 /usr/include/aarch64-linux-gnu/sys/stat.h \
 /usr/include/aarch64-linux-gnu/bits/stat.h \
 /usr/include/aarch64-linux-gnu/bits/struct_stat.h \
 /usr/include/aarch64-linux-gnu/bits/statx.h /usr/include/linux/stat.h \
 /usr/include/linux/types.h /usr/include/aarch64-linux-gnu/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/aarch64-linux-gnu/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h \
 /usr/include/aarch64-linux-gnu/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/aarch64-linux-gnu/bits/statx-generic.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx_timestamp.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_statx.h \
 /usr/include/inttypes.h
