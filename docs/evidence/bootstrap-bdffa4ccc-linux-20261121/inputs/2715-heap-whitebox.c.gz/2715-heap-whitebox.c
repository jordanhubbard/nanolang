#include "/home/jkh/.worktrees/nanolang/installed-tools-bootstrap-20261121/src/nanovm/heap.c"
bool test_shared_slot(const VmHashMap *m,NanoValue k,uint32_t *s,bool *f){return hm_find_slot(m,k,s,f);}
