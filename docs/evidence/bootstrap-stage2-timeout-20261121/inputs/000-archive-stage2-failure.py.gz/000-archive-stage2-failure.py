from pathlib import Path
import gzip,hashlib,json,subprocess
old=Path('/home/jkh/Src/nanolang-callable-ownership');work=old/'obj/bootstrap-nanoisa/run-s7hqibs_';dest=Path('docs/evidence/bootstrap-stage2-timeout-20261121');(dest/'inputs').mkdir(parents=True,exist_ok=True)
m=json.loads((work/'manifest.json').read_text());assert m['steps'][-1]['label']=='stage2' and m['steps'][-1]['interrupted_or_timed_out'];assert 1800<=m['steps'][-1]['elapsed_seconds']<1805
sha=lambda b:hashlib.sha256(b).hexdigest();paths={Path(__file__),work/'manifest.json',work/'stage1.c',old/'bin/nanoc_bootstrap.json'}
for step in m['steps']:paths.add(Path(step['log']))
for name in ('bootstrap-join-phases-linux.jsonl','bootstrap-join-phase-linux.log','bootstrap-join-phase-stage2-linux.log','bootstrap-phase-perf-control.stderr','bootstrap-join-phase-recorder.py','bootstrap-join-phase-plan-linux.json'):
 p=old/'.test_output'/name
 if p.exists():paths.add(p)
for name in m['tools']:paths.add(old/'bin'/name)
for name in ('nanoc_seed.nvm','nanoc_stage1.nvm','nanoc_stage1'):paths.add(old/'bin'/name)
paths.update(Path(p) for p in m['hosts'])
paths.update(p for p in work.glob('guard*') if p.is_file())
observed={}
for p in (work/'stage2.nvm',old/'bin/nanoc_stage2.nvm',old/'bin/nanoc_stage2'):
 observed[str(p)]=dict(exists=p.exists(),qualified_in_this_manifest=p.name in m['artifacts'])
 if p.is_file():observed[str(p)]['sha256']=sha(p.read_bytes())
files=[];seen={}
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();digest=sha(raw);out=seen.get(digest,dest/'inputs'/f'{i:03d}-{p.name}.gz');seen[digest]=out;packed=gzip.compress(raw,mtime=0);out.write_bytes(packed);files.append(dict(path=str(p),artifact=str(out.relative_to(dest)),sha256=digest,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
record=dict(source_pin='74644c29f',issue=1161,stage2_observed_paths=observed,files=files)
(dest/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for item in files:
 packed=(dest/item['artifact']).read_bytes();assert sha(packed)==item['compressed_sha256'] and sha(gzip.decompress(packed))==item['sha256']
print(len(files),sum(x['bytes'] for x in files),sum(p.stat().st_size for p in seen.values()),observed)
