import pathlib,subprocess,shlex,json,hashlib,os,time,signal
base=pathlib.Path('/home/jkh/nanolang-qualification/forth-benign-787');root=pathlib.Path('/home/jkh/nanolang-qualification/ci-sanitizer-787-forth');r=pathlib.Path(str(root)+'-reports')
def sha(p):return hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
def save(n,d):(base/n).write_text(json.dumps(d,indent=2)+'\n')
log=(r/'tests.log').read_text().replace('\\\n',' ');line=next(l for l in log.splitlines() if l.startswith('cc ') and ' -o tests/forth/' in l);cmd=shlex.split(line);cmd[cmd.index('-o')+1]=str(base/'probe');cmd[cmd.index('tests/forth/test_forth_session.c')]=str(base/'probe.c')
inputs={str(root/x):sha(root/x) for x in cmd if x.endswith('.o')};inputs[str(base/'probe.c')]=sha(base/'probe.c');save('inputs-before.json',inputs);save('compile-command.json',cmd)
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1');t=time.time()
with (base/'compile.log').open('wb') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
save('compile-terminal.json',{'returncode':p.returncode,'seconds':time.time()-t})
if p.returncode:raise SystemExit(p.returncode)
save('product.json',{'sha256':sha(base/'probe')})
with (base/'run.log').open('wb') as f:
 p=subprocess.Popen([str(base/'probe')],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);start=time.monotonic();next_sample=3;count=0
 while p.poll() is None and time.monotonic()-start<30:
  if time.monotonic()-start>=next_sample:
   with (base/('sample-%d.log'%count)).open('wb') as g:
    try:q=subprocess.run(['gdb','-q','-batch','-ex','set pagination off','-ex','thread apply all bt 24','-p',str(p.pid)],stdout=g,stderr=subprocess.STDOUT,timeout=5);code=q.returncode
    except subprocess.TimeoutExpired:code=124
   save('sample-%d.json'%count,{'returncode':code,'seconds':time.monotonic()-start});count+=1;next_sample+=7
  time.sleep(.05)
 timeout=p.poll() is None
 if timeout:os.killpg(p.pid,signal.SIGTERM)
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 try:os.killpg(p.pid,0);gone=False
 except ProcessLookupError:gone=True
 save('terminal.json',{'returncode':p.returncode,'seconds':time.monotonic()-start,'timeout':timeout,'leader_reaped':p.returncode is not None,'group_gone':gone,'bound':30})
after={k:sha(k) for k in inputs};assert after==inputs;save('inputs-after.json',after);print((base/'terminal.json').read_text());print((base/'run.log').read_text())
