#include "forth/forth_session.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <sys/prctl.h>
int g_argc=0; char **g_argv=NULL;
static void stamp(const char *name) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);fprintf(stderr,"%s %lld.%09ld\n",name,(long long)t.tv_sec,t.tv_nsec);fflush(stderr);}
int main(void) {
 (void)prctl(PR_SET_PTRACER,PR_SET_PTRACER_ANY,0,0,0);
 stamp("create-start");ForthSession *s=forth_session_create();if(!s)return 1;stamp("create-done");
 const char *a="1 2 + 3 *";int64_t v=0;
 if(!forth_interpret(s,(const uint8_t *)a,(uint32_t)strlen(a))||!forth_data_pop(s,&v)||v!=9)return 2;stamp("arithmetic-done");
 if(!forth_interpret_file(s,"examples/language/forth/pi.fs"))return 3;stamp("pi-load-done");
 forth_output_clear(s);const char *p="1 PI";
 if(!forth_interpret(s,(const uint8_t *)p,(uint32_t)strlen(p)))return 4;stamp("pi-one-done");
 fprintf(stderr,"output=%s\n",forth_output(s));if(strncmp(forth_output(s),"3.1",3))return 5;
 forth_session_destroy(s);stamp("destroy-done");return 0;
}
