/**
 * test_module_metadata.c — unit tests for module_metadata.c
 *
 * Tests serialize_module_metadata_to_c, embed_metadata_in_module_c, and
 * deserialize_module_metadata_from_c with a variety of module shapes.
 */

#define _POSIX_C_SOURCE 200809L
#define _DARWIN_C_SOURCE
#include "../src/nanolang.h"
#include "../src/module_builder.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#define TEST(name) printf("  Testing %s...", #name); test_##name(); printf(" ✓\n")
#define ASSERT(cond) \
    if (!(cond)) { printf("\n    FAILED: %s at line %d\n", #cond, __LINE__); exit(1); }
#define ASSERT_NOT_NULL(p) \
    if ((p) == NULL) { printf("\n    FAILED: unexpected NULL at line %d\n", __LINE__); exit(1); }
#define ASSERT_NULL(p) \
    if ((p) != NULL) { printf("\n    FAILED: expected NULL at line %d\n", __LINE__); exit(1); }
#define ASSERT_CONTAINS(haystack, needle) \
    if (strstr((haystack), (needle)) == NULL) { \
        printf("\n    FAILED: expected \"%s\" in output at line %d\n    got:\n%s\n", \
            (needle), __LINE__, (haystack)); exit(1); }

/* Required by runtime/cli.c (extern in eval.c) */
int g_argc = 0;
char **g_argv = NULL;

/* Helper: build a zero-initialised ModuleMetadata on the stack */
static ModuleMetadata make_empty_meta(const char *name) {
    ModuleMetadata m;
    memset(&m, 0, sizeof(m));
    m.module_name = (char *)name;
    return m;
}

/* Helper: build a single void→void function entry */
static Function make_simple_fn(const char *name) {
    Function f;
    memset(&f, 0, sizeof(f));
    f.name = (char *)name;
    f.return_type = TYPE_VOID;
    return f;
}

/* ============================================================================
 * Tests
 * ============================================================================ */

void test_serialize_null_returns_null(void) {
    char *result = serialize_module_metadata_to_c(NULL);
    ASSERT_NULL(result);
}

void test_serialize_empty_module(void) {
    ModuleMetadata meta = make_empty_meta("mymod");
    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "mymod");
    ASSERT_CONTAINS(out, "#include \"nanolang.h\"");
    ASSERT_CONTAINS(out, "_module_functions[0]");  /* static array of size 0 */
    free(out);
}

void test_serialize_single_void_function(void) {
    Function fn = make_simple_fn("my_func");
    ModuleMetadata meta = make_empty_meta("testmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "my_func");
    ASSERT_CONTAINS(out, "function_count = 1");
    ASSERT_CONTAINS(out, "return_type");
    ASSERT_CONTAINS(out, "_init_module_metadata");
    free(out);
}

void test_serialize_function_is_extern(void) {
    Function fn = make_simple_fn("ext_fn");
    fn.is_extern = true;
    ModuleMetadata meta = make_empty_meta("extmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "is_extern = true");
    free(out);
}

void test_serialize_function_with_params(void) {
    Parameter params[2];
    memset(params, 0, sizeof(params));
    params[0].name = "x";
    params[0].type = TYPE_INT;
    params[1].name = "s";
    params[1].type = TYPE_STRING;

    Function fn = make_simple_fn("add");
    fn.param_count = 2;
    fn.params = params;
    fn.return_type = TYPE_INT;

    ModuleMetadata meta = make_empty_meta("mathmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "\"x\"");
    ASSERT_CONTAINS(out, "\"s\"");
    ASSERT_CONTAINS(out, "param_count = 2");
    free(out);
}

void test_serialize_function_with_struct_return(void) {
    Function fn = make_simple_fn("get_point");
    fn.return_type = TYPE_STRUCT;
    fn.return_struct_type_name = "Point";

    ModuleMetadata meta = make_empty_meta("geomod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "\"Point\"");
    ASSERT_CONTAINS(out, "return_struct_type_name");
    free(out);
}

void test_serialize_memory_annotations(void) {
    Function fn = make_simple_fn("alloc_handle");
    fn.returns_gc_managed = true;
    fn.requires_manual_free = true;
    fn.cleanup_function = "handle_free";
    fn.returns_borrowed = false;

    ModuleMetadata meta = make_empty_meta("memmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "returns_gc_managed = true");
    ASSERT_CONTAINS(out, "requires_manual_free = true");
    ASSERT_CONTAINS(out, "\"handle_free\"");
    ASSERT_CONTAINS(out, "returns_borrowed = false");
    free(out);
}

void test_serialize_int_constant(void) {
    ConstantDef c;
    memset(&c, 0, sizeof(c));
    c.name = "MAX_SIZE";
    c.type = TYPE_INT;
    c.value = 1024;

    ModuleMetadata meta = make_empty_meta("constmod");
    meta.constant_count = 1;
    meta.constants = &c;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "MAX_SIZE");
    ASSERT_CONTAINS(out, "1024");
    free(out);
}

void test_serialize_float_constant(void) {
    ConstantDef c;
    memset(&c, 0, sizeof(c));
    c.name = "PI";
    c.type = TYPE_FLOAT;
    /* Store 3.14159 as bit pattern in int64 */
    union { double d; int64_t i; } u;
    u.d = 3.14159;
    c.value = u.i;

    ModuleMetadata meta = make_empty_meta("mathconst");
    meta.constant_count = 1;
    meta.constants = &c;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "PI");
    ASSERT_CONTAINS(out, "const double");
    free(out);
}

void test_serialize_multiple_functions(void) {
    Function fns[3];
    memset(fns, 0, sizeof(fns));
    fns[0].name = "alpha";  fns[0].return_type = TYPE_VOID;
    fns[1].name = "beta";   fns[1].return_type = TYPE_INT;
    fns[2].name = "gamma";  fns[2].return_type = TYPE_STRING;

    ModuleMetadata meta = make_empty_meta("multimod");
    meta.function_count = 3;
    meta.functions = fns;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "\"alpha\"");
    ASSERT_CONTAINS(out, "\"beta\"");
    ASSERT_CONTAINS(out, "\"gamma\"");
    ASSERT_CONTAINS(out, "function_count = 3");
    free(out);
}

void test_serialize_param_with_struct_type(void) {
    Parameter p;
    memset(&p, 0, sizeof(p));
    p.name = "pt";
    p.type = TYPE_STRUCT;
    p.struct_type_name = "Vec3";

    Function fn = make_simple_fn("normalize");
    fn.param_count = 1;
    fn.params = &p;

    ModuleMetadata meta = make_empty_meta("vecmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char *out = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(out);
    ASSERT_CONTAINS(out, "\"Vec3\"");
    ASSERT_CONTAINS(out, "\"pt\"");
    free(out);
}

void test_embed_null_inputs_return_false(void) {
    ASSERT(!embed_metadata_in_module_c(NULL, NULL, 0));

    ModuleMetadata meta = make_empty_meta("x");
    ASSERT(!embed_metadata_in_module_c(NULL, &meta, 1024));

    char buf[16] = "code";
    ASSERT(!embed_metadata_in_module_c(buf, NULL, sizeof(buf)));
}

void test_embed_buffer_too_small(void) {
    /* Buffer must be large enough: code + metadata + 100 bytes */
    Function fn = make_simple_fn("f");
    ModuleMetadata meta = make_empty_meta("small");
    meta.function_count = 1;
    meta.functions = &fn;

    char small_buf[32] = "int main() {}";
    bool ok = embed_metadata_in_module_c(small_buf, &meta, sizeof(small_buf));
    ASSERT(!ok);  /* too small */
}

void test_embed_metadata_at_end(void) {
    /* Code without main() — metadata goes at the end */
    Function fn = make_simple_fn("helper");
    ModuleMetadata meta = make_empty_meta("embedmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char buf[65536] = "/* preamble */\n";
    bool ok = embed_metadata_in_module_c(buf, &meta, sizeof(buf));
    ASSERT(ok);
    ASSERT(strstr(buf, "helper") != NULL);
    ASSERT(strstr(buf, "_init_module_metadata") != NULL);
}

void test_embed_metadata_before_main(void) {
    /* Code with int main() — metadata should be inserted before it */
    Function fn = make_simple_fn("do_work");
    ModuleMetadata meta = make_empty_meta("mainmod");
    meta.function_count = 1;
    meta.functions = &fn;

    char buf[65536];
    snprintf(buf, sizeof(buf), "/* top */\nint main() { return 0; }\n");
    bool ok = embed_metadata_in_module_c(buf, &meta, sizeof(buf));
    ASSERT(ok);
    /* Metadata should appear before int main() */
    char *meta_pos = strstr(buf, "do_work");
    char *main_pos = strstr(buf, "int main()");
    ASSERT_NOT_NULL(meta_pos);
    ASSERT_NOT_NULL(main_pos);
    ASSERT(meta_pos < main_pos);
}

void test_serialize_long_identifiers(void) {
    char name[3001], constant[3001], expected[6200];
    memset(name, 'm', sizeof(name) - 1);
    name[sizeof(name) - 1] = '\0';
    memset(constant, 'c', sizeof(constant) - 1);
    constant[sizeof(constant) - 1] = '\0';
    ModuleMetadata meta = make_empty_meta(name);
    ConstantDef constants[2] = {0};
    constants[0].name = constant;
    constants[0].type = TYPE_INT;
    constants[0].value = 42;
    constants[1].name = constant;
    constants[1].type = TYPE_FLOAT;
    union { double d; int64_t i; } value = {.d = 1.5};
    constants[1].value = value.i;
    meta.constants = constants;
    meta.constant_count = 2;
    char *output = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(output);
    snprintf(expected, sizeof(expected), "ModuleMetadata _module_metadata_%s = {\n", name);
    ASSERT_CONTAINS(output, expected);
    snprintf(expected, sizeof(expected), "static const int64_t _module_const_%s_%s = 42LL;\n", name, constant);
    ASSERT_CONTAINS(output, expected);
    snprintf(expected, sizeof(expected), "static const double _module_const_%s_%s = 1.5;\n", name, constant);
    ASSERT_CONTAINS(output, expected);
    free(output);
}

void test_deserialize_stub_returns_false(void) {
    ModuleMetadata *out = NULL;
    bool ok = deserialize_module_metadata_from_c("/* some c code */", &out);
    ASSERT(!ok);
    ASSERT_NULL(out);
}

void test_module_json_requires_utf8(void) {
    char dir[512];
    snprintf(dir, sizeof(dir), "%s/nano_mod_utf8_%d",
             getenv("TMPDIR") ? getenv("TMPDIR") : "/tmp", (int)getpid());
    rmdir(dir);
    ASSERT(mkdir(dir, 0700) == 0);
    char path[640];
    snprintf(path, sizeof(path), "%s/module.json", dir);
    FILE *f = fopen(path, "wb");
    ASSERT_NOT_NULL(f);
    fputs("{ \"name\": \"x\" }", f);
    fputc((char)0xFF, f);
    fclose(f);
    ASSERT_NULL(module_load_metadata(dir));
    unlink(path);

    f = fopen(path, "wb");
    ASSERT_NOT_NULL(f);
    fputs("{ \"name\": \"okmod\", \"version\": \"0\" }", f);
    fclose(f);
    ModuleBuildMetadata *meta = module_load_metadata(dir);
    ASSERT_NOT_NULL(meta);
    ASSERT(meta->name && strcmp(meta->name, "okmod") == 0);
    module_metadata_free(meta);
    unlink(path);
    rmdir(dir);
}

/* ============================================================================
 * main
 * ============================================================================ */

static void test_callback_adapters(void) {
    char directory[] = "/tmp/nanolang-callback-metadata-XXXXXX";
    ASSERT_NOT_NULL(mkdtemp(directory));
    char path[256];
    snprintf(path, sizeof(path), "%s/module.json", directory);
    const char *valid = "{\"name\":\"fixture\",\"callback_adapters\":{"
        "\"submit\":{\"symbol\":\"retained_submit\",\"abi\":\"retained_v1\",\"execution\":\"worker\"},"
        "\"wait\":{\"symbol\":\"retained_wait\",\"abi\":\"retained_v1\",\"execution\":\"owner\"}}}";
    FILE *f = fopen(path, "wb");
    ASSERT_NOT_NULL(f);
    ASSERT(fputs(valid, f) >= 0 && fclose(f) == 0);
    ModuleBuildMetadata *meta = module_load_metadata(directory);
    ASSERT_NOT_NULL(meta);
    ASSERT(meta->callback_adapters_count == 2);
    ASSERT(!strcmp(meta->callback_adapters[0].function_name, "submit"));
    ASSERT(!strcmp(meta->callback_adapters[0].adapter_symbol, "retained_submit"));
    ASSERT(meta->callback_adapters[0].worker_thread);
    ASSERT(!meta->callback_adapters[1].worker_thread);
    const char *invalid[] = {
        "[]", "{} trailing", "{\"callback_adapters\":null}",
        "{\"callback_adapters\":[],\"name\":\"x\"}",
        "{\"callback_adapters\":{},\"callback_adapters\":{}}",
        "{\"callback_adapters\":{\"submit\":{}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"abi\":\"raw\",\"execution\":\"worker\"}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"abi\":\"retained_v1\",\"execution\":\"any\"}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"abi\":\"retained_v1\",\"execution\":\"worker\",\"typo\":\"x\"}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"symbol\":\"b\",\"abi\":\"retained_v1\",\"execution\":\"worker\"}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"abi\":\"retained_v1\",\"execution\":true}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\",\"abi\":\"retained_v1\",\"execution\":\"worker\"},\"submit\":{}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"bad symbol\",\"abi\":\"retained_v1\",\"execution\":\"worker\"}}}",
        "{\"callback_adapters\":{\"submit\":{\"symbol\":\"a\\u0000b\",\"abi\":\"retained_v1\",\"execution\":\"worker\"}}}",
        "{\"callback_adapters\\u0000ignored\":{}}"
    };
    for (size_t i = 0; i < sizeof(invalid) / sizeof(invalid[0]); i++) {
        f = fopen(path, "wb");
        ASSERT_NOT_NULL(f);
        ASSERT(fputs(invalid[i], f) >= 0 && fclose(f) == 0);
        ASSERT_NULL(module_load_metadata(directory));
        /* I retain the selected metadata after the manifest changes. */
        ASSERT(!strcmp(meta->callback_adapters[0].adapter_symbol, "retained_submit"));
    }
    f = fopen(path, "wb");
    ASSERT_NOT_NULL(f);
    ASSERT(fputs("{\"description\":\"literal \\\\u0000\"}", f) >= 0 && fclose(f) == 0);
    ModuleBuildMetadata *literal = module_load_metadata(directory);
    ASSERT_NOT_NULL(literal);
    module_metadata_free(literal);
    f = fopen(path, "wb");
    ASSERT_NOT_NULL(f);
    ASSERT(fwrite("{}\0{}", 1, 5, f) == 5 && fclose(f) == 0);
    ASSERT_NULL(module_load_metadata(directory));
    module_metadata_free(meta);
    ASSERT(unlink(path) == 0 && rmdir(directory) == 0);
}

/* I keep nested annotations alive after the parser and registering environment
 * are gone, and substitute without mutating either retained declaration. */
static void test_union_payload_lifetime(void) {
    int count = 0;
    Token *tokens = tokenize("union Box<T> { Some { values: array<array<T>> }, None {} }", &count);
    ASSERT_NOT_NULL(tokens);
    ASTNode *program = parse_program(tokens, count);
    ASSERT_NOT_NULL(program);
    Environment *env = create_environment();
    typecheck_set_current_file("<payload-metadata>");
    ASSERT(type_check_module(program, env));
    UnionDef *registered = env_get_union(env, "Box");
    ASSERT_NOT_NULL(registered);
    TypeInfo *payload = registered->variant_field_type_info[0][0];
    ASSERT(payload->base_type == TYPE_ARRAY);
    ASSERT(payload->element_type->base_type == TYPE_ARRAY);
    ASSERT(!strcmp(payload->element_type->element_type->generic_name, "T"));
    ModuleMetadata *meta = extract_module_metadata(env, "payload");
    ASSERT_NOT_NULL(meta);
    ASSERT(meta->union_count == 1);
    TypeInfo *retained = meta->unions[0].variant_field_type_info[0][0];
    ASSERT(retained != payload && retained->element_type != payload->element_type);
    free_ast(program);
    free_tokens(tokens, count);
    ASSERT(!strcmp(payload->element_type->element_type->generic_name, "T"));
    TypeInfo string = { .base_type = TYPE_STRING };
    TypeInfo *parameters[] = { &string };
    TypeInfo arguments = { .base_type = TYPE_UNION, .type_params = parameters, .type_param_count = 1 };
    TypeInfo *concrete = resolve_union_payload_type_info(registered, 0, 0, &arguments);
    ASSERT(concrete->base_type == TYPE_ARRAY);
    ASSERT(concrete->element_type->base_type == TYPE_ARRAY);
    ASSERT(concrete->element_type->element_type->base_type == TYPE_STRING);
    ASSERT(!strcmp(payload->element_type->element_type->generic_name, "T"));
    free_environment(env);
    ASSERT(!strcmp(retained->element_type->element_type->generic_name, "T"));
    ASSERT(concrete->element_type->element_type->base_type == TYPE_STRING);
    free_module_metadata(meta);
    ASSERT(concrete->element_type->element_type->base_type == TYPE_STRING);
    free_payload_type_info(concrete);
}

/* I keep imported callback annotations after both parser and environment die. */
static void test_function_metadata_lifetime(void) {
    const char *source =
        "fn transform(values: array<array<int>>) -> array<array<int>> { return values } "
        "fn invoke(callback: fn(array<array<int>>) -> array<array<int>>, values: array<array<int>>) -> array<array<int>> { return (callback values) } "
        "fn factory() -> fn(array<array<int>>) -> array<array<int>> { return transform }";
    int count = 0;
    Token *tokens = tokenize(source, &count);
    ASSERT_NOT_NULL(tokens);
    ASTNode *program = parse_program(tokens, count);
    ASSERT_NOT_NULL(program);
    Environment *env = create_environment();
    typecheck_set_current_file("<signature-metadata>");
    ASSERT(type_check_module(program, env));
    ModuleMetadata *meta = extract_module_metadata(env, "callbacks");
    ASSERT_NOT_NULL(meta);
    free_ast(program);
    free_tokens(tokens, count);
    free_environment(env);
    Function *invoke = NULL, *factory = NULL;
    for (int i = 0; i < meta->function_count; i++) {
        if (!strcmp(meta->functions[i].name, "invoke")) invoke = &meta->functions[i];
        if (!strcmp(meta->functions[i].name, "factory")) factory = &meta->functions[i];
    }
    ASSERT_NOT_NULL(invoke);
    ASSERT_NOT_NULL(factory);
    FunctionSignature *callback = invoke->params[0].fn_sig;
    ASSERT_NOT_NULL(callback);
    ASSERT_NOT_NULL(callback->param_type_info);
    ASSERT(callback->param_type_info[0]->base_type == TYPE_ARRAY);
    ASSERT(callback->param_type_info[0]->element_type->base_type == TYPE_ARRAY);
    ASSERT(callback->param_type_info[0]->element_type->element_type->base_type == TYPE_INT);
    ASSERT(callback->return_type_info->element_type->element_type->base_type == TYPE_INT);
    ASSERT(invoke->params[1].type_info->element_type->element_type->base_type == TYPE_INT);
    ASSERT(factory->return_fn_sig->return_type_info->element_type->element_type->base_type == TYPE_INT);
    char *serialized = serialize_module_metadata_to_c(meta);
    ASSERT_NOT_NULL(serialized);
    free_module_metadata(meta);
    ASSERT_CONTAINS(serialized, ".param_type_info =");
    ASSERT_CONTAINS(serialized, ".return_type_info =");
    free(serialized);
}

static void test_extracted_signature_ownership(void) {
    TypeInfo integer = {.base_type = TYPE_INT};
    TypeInfo array = {.base_type = TYPE_ARRAY, .element_type = &integer};
    Type types[] = {TYPE_ARRAY};
    TypeInfo *infos[] = {&array};
    FunctionSignature nested = {.return_type = TYPE_ARRAY, .return_type_info = &array};
    FunctionSignature signature = {.param_count = 1, .param_types = types,
        .param_type_info = infos, .return_type = TYPE_FUNCTION, .return_fn_sig = &nested};
    TypeInfo callback = {.base_type = TYPE_FUNCTION, .fn_sig = &signature};
    Parameter parameter = {.name = "callback", .type = TYPE_FUNCTION,
        .fn_sig = &signature, .type_info = &callback};
    Function function = {.name = "factory", .param_count = 1, .params = &parameter,
        .return_type = TYPE_FUNCTION, .return_fn_sig = &signature, .return_type_info = &callback};
    Environment env = {.functions = &function, .function_count = 1};
    for (int i = 0; i < 100; i++) {
        ModuleMetadata *meta = extract_module_metadata(&env, "owned");
        ASSERT_NOT_NULL(meta);
        Function *copy = &meta->functions[0];
        ASSERT(copy->return_fn_sig != &signature);
        ASSERT(copy->return_type_info != &callback);
        ASSERT(copy->params[0].fn_sig != &signature);
        ASSERT(copy->params[0].type_info != &callback);
        ASSERT(copy->params[0].fn_sig->param_type_info[0] != &array);
        ASSERT(copy->params[0].fn_sig->param_type_info[0]->element_type != &integer);
        ASSERT(copy->return_fn_sig->return_fn_sig->return_type_info->element_type->base_type == TYPE_INT);
        char *serialized = serialize_module_metadata_to_c(meta);
        ASSERT_NOT_NULL(serialized);
        free_module_metadata(meta);
        ASSERT_CONTAINS(serialized, ".return_fn_sig =");
        free(serialized);
    }
}

/* I compile the emitted representation after discarding its original graph.
 * Static generated edges must preserve identity, cycles and complete types. */
static void test_recursive_signature_roundtrip(void) {
    TypeInfo integer = {.base_type = TYPE_INT};
    TypeInfo array = {.base_type = TYPE_ARRAY, .element_type = &integer};
    TypeInfo nested = {.base_type = TYPE_ARRAY, .element_type = &array};
    TypeInfo *arguments[] = {&nested, &integer};
    TypeInfo generic = {.base_type = TYPE_UNION, .generic_name = "Box",
        .type_params = arguments, .type_param_count = 2};
    TypeInfo *parameter_info[] = {&generic, NULL};
    Type parameter_types[] = {TYPE_UNION, TYPE_FUNCTION};
    char *parameter_names[] = {"Box<array<array<int>>>", NULL};
    FunctionSignature inner = {.return_type = TYPE_ARRAY, .return_type_info = &nested};
    FunctionSignature outer = {.param_types = parameter_types, .param_count = 2,
        .param_struct_names = parameter_names, .param_type_info = parameter_info,
        .return_type = TYPE_FUNCTION, .return_fn_sig = &inner};
    TypeInfo callback = {.base_type = TYPE_FUNCTION, .fn_sig = &outer};
    parameter_info[1] = &callback; /* I retain an intentional graph cycle. */
    Type tuple_types[] = {TYPE_INT, TYPE_UNION};
    char *tuple_names[] = {NULL, "Box<int>"};
    TypeInfo service = {.base_type = TYPE_OPAQUE, .service_declaration = 37,
        .service_module = 2, .service_ordinal = 0, .service_category = 1};
    char *row_names[] = {"value", "owned"};
    Type row_types[] = {TYPE_UNION, TYPE_OPAQUE};
    char *row_type_names[] = {"Box<int>", NULL};
    char *variables[] = {"T", "U"};
    TypeInfo tuple_integer = {.base_type = TYPE_INT};
    TypeInfo *tuple_elements[] = {&tuple_integer, &generic};
    TypeInfo *row_annotations[] = {&generic, &service};
    TypeInfo tuple = {.base_type = TYPE_TUPLE, .tuple_types = tuple_types,
        .tuple_elements = tuple_elements,
        .tuple_type_names = tuple_names, .tuple_element_count = 2,
        .opaque_type_name = "opaque\"\\\n", .is_open_row = true,
        .row_var_name = "r", .row_field_names = row_names,
        .row_field_types = row_types, .row_field_type_names = row_type_names,
        .row_field_type_info = row_annotations,
        .row_field_count = 2, .type_var_names = variables, .type_var_count = 2};
    Parameter parameters[] = {
        {.name = "callback", .type = TYPE_FUNCTION, .fn_sig = &outer, .type_info = &callback},
        {.name = "values", .type = TYPE_ARRAY, .element_type = TYPE_ARRAY, .type_info = &nested},
        {.name = "pair", .type = TYPE_TUPLE, .type_info = &tuple},
        {.name = "file", .type = TYPE_OPAQUE, .type_info = &service}};
    Function fn = make_simple_fn("factory");
    fn.return_type = TYPE_FUNCTION;
    fn.return_fn_sig = &outer;
    fn.return_type_info = &callback;
    fn.params = parameters;
    fn.param_count = 4;
    ModuleMetadata meta = make_empty_meta("recursive");
    meta.functions = &fn;
    meta.function_count = 1;
    char *generated = serialize_module_metadata_to_c(&meta);
    ASSERT_NOT_NULL(generated);
    memset(&outer, 0, sizeof(outer));
    memset(&inner, 0, sizeof(inner));
    memset(&nested, 0, sizeof(nested));
    memset(&generic, 0, sizeof(generic));

    char directory[] = "/tmp/nanolang-metadata-roundtrip-XXXXXX";
    ASSERT_NOT_NULL(mkdtemp(directory));
    char source[256], executable[256];
    snprintf(source, sizeof(source), "%s/roundtrip.c", directory);
    snprintf(executable, sizeof(executable), "%s/roundtrip", directory);
    FILE *out = fopen(source, "w");
    ASSERT_NOT_NULL(out);
    ASSERT(fputs(generated, out) >= 0);
    free(generated);
    ASSERT(fputs(
        "int main(void) {\n"
        " Function *f = &_module_metadata_recursive.functions[0];\n"
        " FunctionSignature *s = f->return_fn_sig;\n"
        " assert(s == f->params[0].fn_sig);\n"
        " assert(f->return_type_info == f->params[0].type_info);\n"
        " assert(s->param_count == 2 && s->param_types[0] == TYPE_UNION);\n"
        " assert(!strcmp(s->param_struct_names[0], \"Box<array<array<int>>>\"));\n"
        " assert(s->param_struct_names[1] == NULL);\n"
        " assert(s->param_type_info[1]->fn_sig == s);\n"
        " TypeInfo *g = s->param_type_info[0];\n"
        " assert(!strcmp(g->generic_name, \"Box\") && g->type_param_count == 2);\n"
        " TypeInfo *a = g->type_params[0];\n"
        " assert(a == f->params[1].type_info);\n"
        " assert(a->base_type == TYPE_ARRAY && a->element_type->base_type == TYPE_ARRAY);\n"
        " assert(a->element_type->element_type == g->type_params[1]);\n"
        " assert(g->type_params[1]->base_type == TYPE_INT);\n"
        " assert(s->return_fn_sig->return_type_info == a);\n"
        " assert(s->return_fn_sig->param_types == NULL && s->return_fn_sig->param_type_info == NULL);\n"
        " TypeInfo *file = f->params[3].type_info;\n"
        " assert(file->base_type == TYPE_OPAQUE && file->service_declaration == 37);\n"
        " assert(file->service_module == 2 && file->service_ordinal == 0 && file->service_category == 1);\n"
        " assert(a->service_declaration == 0);\n"
        " TypeInfo *t = f->params[2].type_info;\n"
        " assert(t->tuple_element_count == 2 && t->tuple_types[1] == TYPE_UNION);\n"
        " assert(t->tuple_elements[0]->base_type == TYPE_INT);\n"
        " assert(t->tuple_elements[1]->type_params[0]->element_type->element_type->base_type == TYPE_INT);\n"
        " assert(t->tuple_type_names[0] == NULL && !strcmp(t->tuple_type_names[1], \"Box<int>\"));\n"
        " assert(!strcmp(t->opaque_type_name, \"opaque\\\"\\\\\\n\"));\n"
        " assert(t->is_open_row && !strcmp(t->row_var_name, \"r\"));\n"
        " assert(t->row_field_count == 2 && t->row_field_types[0] == TYPE_UNION);\n"
        " assert(t->row_field_type_info[1]->base_type == TYPE_OPAQUE);\n"
        " assert(t->row_field_type_info[1]->service_declaration == 37 && t->row_field_type_info[1]->service_module == 2);\n"
        " assert(t->row_field_type_info[0]->type_params[0]->element_type->element_type->base_type == TYPE_INT);\n"
        " assert(!strcmp(t->row_field_names[0], \"value\"));\n"
        " assert(!strcmp(t->row_field_type_names[0], \"Box<int>\"));\n"
        " assert(t->type_var_count == 2 && !strcmp(t->type_var_names[1], \"U\"));\n"
        " return 0;\n}\n", out) >= 0);
    ASSERT(fclose(out) == 0);
    pid_t child = fork();
    ASSERT(child >= 0);
    if (!child) {
        execlp("cc", "cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-Isrc", source, "-o", executable, (char *)NULL);
        _exit(127);
    }
    int status;
    ASSERT(waitpid(child, &status, 0) == child);
    ASSERT(WIFEXITED(status) && WEXITSTATUS(status) == 0);
    child = fork();
    ASSERT(child >= 0);
    if (!child) { execl(executable, executable, (char *)NULL); _exit(127); }
    ASSERT(waitpid(child, &status, 0) == child);
    ASSERT(WIFEXITED(status) && WEXITSTATUS(status) == 0);
    ASSERT(unlink(source) == 0 && unlink(executable) == 0 && rmdir(directory) == 0);
}

static void test_malformed_signature_metadata(void) {
    FunctionSignature signature = {.param_count = 1};
    Function fn = make_simple_fn("bad");
    fn.return_fn_sig = &signature;
    ModuleMetadata meta = make_empty_meta("invalid");
    meta.functions = &fn;
    meta.function_count = 1;
    ASSERT_NULL(serialize_module_metadata_to_c(&meta));
    signature.param_count = -1;
    ASSERT_NULL(serialize_module_metadata_to_c(&meta));
    fn.return_fn_sig = NULL;
    TypeInfo invalid = {.base_type = TYPE_UNION, .type_param_count = 1};
    fn.return_type_info = &invalid;
    ASSERT_NULL(serialize_module_metadata_to_c(&meta));
    invalid.type_param_count = -1;
    ASSERT_NULL(serialize_module_metadata_to_c(&meta));
}

/* I preserve the reported name while source identities select distinct table symbols. */
void test_serialize_source_identity(void) {
    ModuleMetadata metadata = make_empty_meta("value");
    char *left = serialize_module_metadata_for_source(&metadata, "left/value.nano");
    char *right = serialize_module_metadata_for_source(&metadata, "right/value.nano");
    char *legacy = serialize_module_metadata_to_c(&metadata);
    ASSERT_NOT_NULL(left); ASSERT_NOT_NULL(right); ASSERT_NOT_NULL(legacy);
    ASSERT(strcmp(left, right) != 0);
    ASSERT(strstr(left, ".module_name = \"value\"") != NULL);
    ASSERT(strstr(right, ".module_name = \"value\"") != NULL);
    ASSERT(strstr(legacy, "ModuleMetadata _module_metadata_value") != NULL);
    char *canonical = realpath(__FILE__, NULL);
    ASSERT_NOT_NULL(canonical);
    char *relative = serialize_module_metadata_for_source(&metadata, __FILE__);
    char *absolute = serialize_module_metadata_for_source(&metadata, canonical);
    ASSERT_NOT_NULL(relative); ASSERT_NOT_NULL(absolute);
    ASSERT(strcmp(relative, absolute) == 0);
    free(left); free(right); free(legacy); free(canonical); free(relative); free(absolute);
}

int main(void) {
    TEST(serialize_source_identity);
    printf("=== Module Metadata Tests ===\n");
    TEST(union_payload_lifetime);
    TEST(recursive_signature_roundtrip);
    TEST(function_metadata_lifetime);
    TEST(extracted_signature_ownership);
    TEST(malformed_signature_metadata);
    TEST(serialize_null_returns_null);
    TEST(serialize_empty_module);
    TEST(serialize_single_void_function);
    TEST(serialize_function_is_extern);
    TEST(serialize_function_with_params);
    TEST(serialize_function_with_struct_return);
    TEST(serialize_memory_annotations);
    TEST(serialize_int_constant);
    TEST(serialize_float_constant);
    TEST(serialize_long_identifiers);
    TEST(serialize_multiple_functions);
    TEST(serialize_param_with_struct_type);
    TEST(embed_null_inputs_return_false);
    TEST(embed_buffer_too_small);
    TEST(embed_metadata_at_end);
    TEST(embed_metadata_before_main);
    TEST(deserialize_stub_returns_false);
    TEST(module_json_requires_utf8);
    TEST(callback_adapters);

    printf("\n✓ All module metadata tests passed!\n");
    return 0;
}
