#!/usr/bin/env python3
"""I retain current selected assembler diagnostics without changing admission."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys

out = Path('.test_output/source-capture-diagnostic').resolve()
out.mkdir(parents=True, exist_ok=True)
records = []
selected_environment = dict(os.environ)
backend_hashes = {}


def run(args, label, cwd=None):
    try:
        result = subprocess.run(list(map(str, args)), capture_output=True, text=True, timeout=30,
                                env=selected_environment, cwd=cwd)
        record = {'label': label, 'command': list(map(str, args)), 'returncode': result.returncode,
                  'stdout': result.stdout, 'stderr': result.stderr,
                  'cwd': str(cwd or Path.cwd()),
                  'developer_dir': selected_environment.get('DEVELOPER_DIR'),
                  'sdk_root': selected_environment.get('SDKROOT')}
    except subprocess.TimeoutExpired as error:
        record = {'label': label, 'command': list(map(str, args)), 'timeout': 30,
                  'stdout': repr(error.stdout), 'stderr': repr(error.stderr)}
    records.append(record)
    (out/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(label, record.get('returncode', 'timeout'), flush=True)
    return record


identity = {'platform': platform.platform(), 'machine': platform.machine(), 'python': sys.version,
            'environment': {name: os.environ.get(name) for name in
                            ('ImageOS', 'ImageVersion', 'PATH', 'DEVELOPER_DIR', 'SDKROOT', 'CC')},
            'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}
(out/'identity.json').write_text(json.dumps(identity, indent=2)+'\n')
for tool in ('cc', 'clang', 'as', 'gcc', 'xcrun', 'xcode-select', 'brew'):
    path = shutil.which(tool)
    if path:
        run([path, '-p' if tool == 'xcode-select' else '--version'], tool+'-version')
if sys.platform == 'darwin':
    run(['xcrun', '--find', 'as'], 'selected-as')
    run(['xcrun', '--find', 'clang'], 'selected-clang')
    run(['xcrun', '--show-sdk-path'], 'selected-sdk')

compilers = [(shutil.which('cc'), None), (shutil.which('clang'), None)]
if Path('/opt/homebrew/opt/llvm/bin/clang').is_file():
    compilers.append(('/opt/homebrew/opt/llvm/bin/clang', None))
if sys.platform == 'darwin':
    installed = []
    for app in sorted(Path('/Applications').glob('Xcode*.app')):
        developer = app/'Contents/Developer'
        compiler = developer/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang'
        if compiler.is_file():
            installed.append({'application': str(app), 'developer_dir': str(developer),
                              'compiler': str(compiler)})
            compilers.append((str(compiler), str(developer)))
    (out/'installed-xcodes.json').write_text(json.dumps(installed, indent=2)+'\n')
seen = set()
for number, (compiler, developer) in enumerate(compilers):
    if not compiler or (compiler, developer) in seen:
        continue
    seen.add((compiler, developer))
    selected_environment = dict(os.environ)
    if developer:
        selected_environment['DEVELOPER_DIR'] = developer
    work = out/str(number); work.mkdir(exist_ok=True)
    source = work/'answer.c'
    source.write_text('long long nano_build_answer(void) { return 42; }\n')
    if sys.platform == 'darwin':
        run(['xcrun', '--find', 'as'], f'{number}-selected-as')
        sdk = run(['xcrun', '--show-sdk-path'], f'{number}-selected-sdk')
        if sdk.get('returncode') == 0 and Path(sdk['stdout'].strip()).is_dir():
            selected_environment['SDKROOT'] = sdk['stdout'].strip()
    resolved = Path(compiler).resolve()
    (work/'compiler.json').write_text(json.dumps({'selected': compiler, 'resolved': str(resolved),
        'developer_dir': developer,
        'sdk_root': selected_environment.get('SDKROOT'),
        'sha256': hashlib.sha256(resolved.read_bytes()).hexdigest()}, indent=2)+'\n')
    version = run([compiler, '--version'], f'{number}-compiler-version')
    run([compiler, '-print-prog-name=as'], f'{number}-assembler-path')
    # I measure each actual driver's response grammar without a shell or a
    # version-derived parser choice. These observations do not admit a tool.
    response_source = work/'response-source.c'
    response_source.write_text('VALUE\n')
    response_forms = [
        '-DVALUE=42', "'-DVALUE=two words'", '"-DVALUE=cost$HOME"',
        r"'-DVALUE=a\b'", r'"-DVALUE=a\qb"', r'-DVALUE=one\ two',
        r'-DVALUE=\"literal\ text\"', '-DVALUE=42\r\n-U VALUE\n-D VALUE=43',
        r"'-DVALUE=a\\b'", r'"-DVALUE=a\\b"',
        r"'-DVALUE=a\'b'", r'"-DVALUE=a\"b"',
        r"'-DVALUE=a\"b'", r'"-DVALUE=a\'b"',
    ]
    for form_index, form in enumerate(response_forms):
        response = work/f'response-{form_index}.rsp'
        response.write_text(form + '\n')
        run([compiler, '-E', '-P', '-x', 'c', response_source, '@'+str(response)],
            f'{number}-response-grammar-{form_index}')
    nested_response = work/'response-nested.rsp'
    nested_response.write_text('@'+str(work/'response-3.rsp')+'\n')
    run([compiler, '-E', '-P', '-x', 'c', response_source, '@'+str(nested_response)],
        f'{number}-response-grammar-nested')
    if sys.platform.startswith('linux'):
        # I preserve the original failing native .S flags separately from
        # capture admission, then retain a diagnostic preprocessor action.
        native_source = work/'payload.S'
        native_source.write_text('#define INSTRUCTION nop\n.text\nINSTRUCTION\n.data\n'
                                 '.globl snapshot_payload\nsnapshot_payload:\n.byte 42\n')
        native_object = work/'payload-native.o'
        native_command = [compiler, '-c', '-fPIC', '-g', native_source, '-o', native_object]
        run(native_command, f'{number}-native-preprocessed-debug')
        run([*native_command, '-###'], f'{number}-native-preprocessed-debug-report')
        run([compiler, '-E', '-fPIC', '-g', native_source, '-o', work/'payload-preprocessed.s'],
            f'{number}-native-preprocessor-action')
        reader = shutil.which('readelf')
        if reader and native_object.is_file():
            backend_hashes[str(Path(reader).resolve())] = hashlib.sha256(Path(reader).read_bytes()).hexdigest()
            (out/'backend-hashes.json').write_text(json.dumps(backend_hashes, indent=2)+'\n')
            run([reader, '--version'], f'{number}-native-debug-reader')
            run([reader, '--debug-dump=info', native_object], f'{number}-native-debug-info')
            run([reader, '--debug-dump=decodedline', native_object], f'{number}-native-debug-lines')
    if sys.platform.startswith('linux'):
        macros = '.macro read_payload path\n.incbin "\\path"\n.endm\n.macro step operation\n\\operation\n.endm\n'
        for variant in ('include-plain', 'inline-step', 'include-step', 'original-includes',
                        'marker-inline-step', 'marker-include-step', 'marker-include-restore'):
            case = work/('native-nop-' + variant); case.mkdir(exist_ok=True)
            (case/'debug macro.s').write_text(macros)
            (case/'debug payload.bin').write_bytes(b'*')
            raw = variant.startswith('marker-')
            include = variant not in ('inline-step', 'marker-inline-step')
            prefix = ('.include "' + ('debug macro.s' if raw else str(case/'debug macro.s')) + '"\n') if include else macros
            if variant == 'marker-include-restore': prefix += '# 3 "payload.S"\n'
            instruction = ('nop' if raw else 'INSTRUCTION') if variant == 'include-plain' else ('step nop' if raw else 'step INSTRUCTION')
            data = ('read_payload "' + str(case/'debug payload.bin') + '"') if variant == 'original-includes' else '.byte 42'
            contents = ('# 1 "payload.S"\n' if raw else '#define INSTRUCTION nop\n') + prefix
            contents += '.text\n' + instruction + '\n.data\n.globl snapshot_payload\nsnapshot_payload:\n' + data + '\n'
            source_case = case/('repro.s' if raw else 'payload.S'); source_case.write_text(contents)
            output_case = case/'native.o'
            command = [compiler, '-c', '-fPIC', '-g', source_case, '-o', output_case]
            label = f'{number}-native-{variant}'
            run(command, label, cwd=case)
            run([*command, '-###'], label+'-report', cwd=case)
            if not raw:
                run([compiler, '-E', '-fPIC', '-g', source_case, '-o', case/'preprocessed.s'],
                    label+'-preprocess', cwd=case)
            reader = shutil.which('readelf')
            if reader and output_case.is_file():
                run([reader, '--debug-dump=info', output_case], label+'-info', cwd=case)
                run([reader, '--debug-dump=decodedline', output_case], label+'-lines', cwd=case)
            if not raw and (case/'preprocessed.s').is_file():
                # I replay actual preprocessing bytes separately from native
                # acceptance, then isolate marker effects without changing it.
                expanded = (case/'preprocessed.s').read_text()
                lines = expanded.splitlines(keepends=True)
                variants = {
                    'actual': expanded,
                    'without-directory': ''.join(line for line in lines
                                                 if not (line.startswith('# ') and '//"' in line)),
                    'without-predef': ''.join(line for line in lines
                                              if not (line.startswith('# ') and 'stdc-predef.h' in line)),
                    'source-marker-only': '# 1 "' + str(source_case) + '"\n' +
                                          ''.join(line for line in lines if not line.startswith('# ')),
                }
                for replay, text in variants.items():
                    replay_source = case/('replay-' + replay + '.s')
                    replay_object = case/('replay-' + replay + '.o')
                    replay_source.write_text(text)
                    run([compiler, '-c', '-x', 'assembler', '-fPIC', '-g',
                         replay_source, '-o', replay_object], label+'-replay-'+replay, cwd=case)
                    if reader and replay_object.is_file():
                        run([reader, '--debug-dump=info', replay_object],
                            label+'-replay-'+replay+'-info', cwd=case)
    assembly = work/'answer.s'
    run([compiler, '-S', '-O0', source, '-o', assembly], f'{number}-emit-assembly')
    for integrated in (True, False):
        mode = 'integrated' if integrated else 'external'
        flags = [] if integrated else ['-fno-integrated-as']
        if 'clang' in version.get('stdout', '') and integrated:
            flags = ['-fintegrated-as']
        output = work/(mode+'.o')
        command = [compiler, *flags, '-c', '-x', 'assembler', assembly, '-o', output]
        dry = run([*command, '-###'], f'{number}-{mode}-dry-run')
        run([*command, '-v'], f'{number}-{mode}-assemble')
        run([compiler, *flags, '-fPIC', '-dynamiclib' if sys.platform == 'darwin' else '-shared',
             source, '-o', work/(mode+('.dylib' if sys.platform == 'darwin' else '.so'))],
            f'{number}-{mode}-fresh-shared')
        # I execute only actual quoted argv reported by this selected installed
        # compiler, without a shell. This is a diagnostic, not admission proof.
        for index, line in enumerate(dry.get('stderr', '').splitlines()):
            if not line.lstrip().startswith('"'):
                continue
            args = shlex.split(line)
            if args and Path(args[0]).is_file():
                backend = Path(args[0]).resolve()
                if str(backend) not in backend_hashes:
                    backend_hashes[str(backend)] = hashlib.sha256(backend.read_bytes()).hexdigest()
                    (out/'backend-hashes.json').write_text(json.dumps(backend_hashes, indent=2)+'\n')
                run(args, f'{number}-{mode}-direct-backend-{index}')
                run([*args, '-###'], f'{number}-{mode}-backend-dry-run-{index}')
    if 'clang' in version.get('stdout', ''):
        debug = work/'debug.s'
        expanded = work/'debug-expanded.s'
        run([compiler, '-S', '-g', '-O0', source, '-o', debug], f'{number}-debug-assembly')
        dry = run([compiler, '-fintegrated-as', '-c', '-x', 'assembler', debug,
                   '-o', work/'debug.o', '-###'], f'{number}-debug-dry-run')
        jobs = [shlex.split(line) for line in dry.get('stderr', '').splitlines()
                if line.lstrip().startswith('"')]
        if len(jobs) == 1 and len(jobs[0]) > 1 and jobs[0][1] == '-cc1as':
            args = jobs[0]
            if args.count('-filetype') == args.count('-o') == 1:
                args[args.index('-filetype') + 1] = 'asm'
                args[args.index('-o') + 1] = str(expanded)
                run([*args, '-msave-temp-labels'], f'{number}-debug-expand')
                run([compiler, '-fintegrated-as', '-c', '-x', 'assembler', expanded,
                     '-o', work/'debug-replay.o'], f'{number}-debug-replay')
manifest = {str(p.relative_to(out)): {'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in out.rglob('*') if p.is_file()}
(out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
