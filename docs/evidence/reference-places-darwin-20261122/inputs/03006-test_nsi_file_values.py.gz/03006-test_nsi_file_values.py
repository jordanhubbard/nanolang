"""I qualify private File/Result lifetimes, without module/source admission."""
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class FileValues(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.artifacts = Path(tempfile.mkdtemp(prefix="nano-file-values-"))
        print(f"I retain File value artifacts at {cls.artifacts}", flush=True)
        cls.compiler = shlex.split(os.environ.get("NANO_FILE_VALUES_CC", "cc"))
        cls.flags = ["-std=c11", "-D_DEFAULT_SOURCE", "-g", "-O1", "-Wall", "-Wextra",
                     "-Werror", "-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
        cls.flags += shlex.split(os.environ.get("NANO_FILE_VALUES_CFLAGS", ""))

    def qualify(self, name, sources):
        exe = self.artifacts / name
        env = dict(os.environ, ASAN_OPTIONS="halt_on_error=1",
                   UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
        for label, command in (("build", [*self.compiler, *self.flags, *sources, "-o", str(exe)]),
                               ("run", [str(exe)])):
            (self.artifacts / f"{name}-{label}-command.txt").write_text(shlex.join(command) + "\n")
            result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=60)
            (self.artifacts / f"{name}-{label}.log").write_text(result.stdout + result.stderr)
            self.assertEqual(result.returncode, 0, (command, result.stdout, result.stderr))
            if label == "run":
                self.assertIn("PASS", result.stdout)
                print(result.stdout.strip(), flush=True)

    def test_instrumented_owner_faults_and_cleanup(self):
        self.qualify("instrumented", ["tests/test_nsi_file_values.c"])

    def test_linked_real_file_value_lifetimes(self):
        self.qualify("linked", ["tests/test_nsi_file_values_linked.c", "src/nsi_file_values.c",
                                "src/nsi_file.c", "src/nsi_cap.c"])


if __name__ == "__main__":
    unittest.main()
