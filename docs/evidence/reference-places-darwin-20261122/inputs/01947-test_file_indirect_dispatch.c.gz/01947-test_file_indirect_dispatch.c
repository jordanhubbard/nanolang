/* One exact serialized corpus drives actual private VM capture and separately
 * compiled native replay. I do not execute a pending public File module. */
#define FILE_INDIRECT_RUNTIME_MAIN retained_indirect_carrier_main
#define file_runtime_tmpfile dispatch_base_tmpfile
#define file_runtime_fclose dispatch_base_fclose
#define file_runtime_fread dispatch_base_fread
#define file_runtime_fwrite dispatch_base_fwrite
#define file_runtime_fseek dispatch_base_fseek
#include "test_file_indirect_runtime.c"
#undef FILE_INDIRECT_RUNTIME_MAIN
#undef file_runtime_tmpfile
#undef file_runtime_fclose
#undef file_runtime_fread
#undef file_runtime_fwrite
#undef file_runtime_fseek
#undef malloc
#undef calloc
#undef realloc
#undef free
#include "../../src/nanovm/file_vm_indirect_private.h"
#include "../../src/nanoisa/nvm2c_file_indirect_private.h"
#include "file_indirect_dispatch_hooks.h"
#include <stdarg.h>
static char events[65536];static size_t event_bytes;
static bool no_alloc=true;static int staging_fault=-1;static size_t execution_failures;
static unsigned invocations;
#ifdef HOSTED_INSTRUMENT
extern unsigned dispatch_core_drains;
#endif
static void event(const char *format,...){va_list ap;va_start(ap,format);int n=vsnprintf(events+event_bytes,sizeof events-event_bytes,format,ap);va_end(ap);CHECK(n>=0 && (size_t)n<sizeof events-event_bytes);event_bytes+=(size_t)n;}
FILE *file_runtime_tmpfile(void){FILE *f=dispatch_base_tmpfile();event("O%u;",f!=NULL);return f;}
int file_runtime_fclose(FILE *f){int n=dispatch_base_fclose(f);event("C%d:%d;",n,n?errno:0);return n;}
size_t file_runtime_fread(void *p,size_t n,size_t count,FILE *f){size_t got=dispatch_base_fread(p,n,count,f);event("R%zu:%zu:%zu:%u;",n,count,got,got?*(unsigned char *)p:0);return got;}
size_t file_runtime_fwrite(const void *p,size_t n,size_t count,FILE *f){size_t got=dispatch_base_fwrite(p,n,count,f);event("W%zu:%zu:%zu:%u;",n,count,got,n&&count?*(const unsigned char *)p:0);return got;}
int file_runtime_fseek(FILE *f,long off,int whence){int n=dispatch_base_fseek(f,off,whence);event("S%ld:%d:%d;",off,whence,n);return n;}
static void release_wire(void *p){
#ifdef HOSTED_INSTRUMENT
 file_test_free(p);
#else
 free(p);
#endif
}
NvmFileRuntimeStatus dispatch_begin(NvmFileRuntime *c){
 NvmFileRuntimeStatus status=nvm_file_runtime_begin(c);
#ifdef HOSTED_INSTRUMENT
 if(status==NVM_FILE_RUNTIME_OK && no_alloc){execution_failures=failed_calls;allocation_budget=0;}
#else
 (void)no_alloc;(void)execution_failures;
#endif
 return status;
}
NvmFileRuntimeStatus dispatch_call(NvmFileRuntime *c){
#ifdef HOSTED_INSTRUMENT
 if(staging_fault==0)near_limit(c,fs(c,0),UINT64_MAX);
 if(staging_fault>=3 && staging_fault<=5){
  uint32_t callable=fs(c,fv(c).stack_count-1);
  if(staging_fault==3)c->values[callable].callable_plan=NULL;
  else c->values[callable].callable_target=staging_fault==4?0:64;
 }
#endif
 NvmFileRuntimeStatus status=nvm_file_runtime_frame_call(c);
 if(status==NVM_FILE_RUNTIME_OK)event("F%u;",fv(c).function);
 return status;
}
NvmFileRuntimeStatus dispatch_return(NvmFileRuntime *c){
#ifdef HOSTED_INSTRUMENT
 if(staging_fault==1 && fv(c).depth>1)near_limit(c,fs(c,0),UINT64_MAX);
#endif
 return nvm_file_runtime_frame_return(c);
}
NvmFileRuntimeStatus dispatch_service(NvmFileRuntime *c,uint32_t i,uint32_t r,uint32_t a,uint32_t o){
 NvmFileRuntimeStatus status=nvm_file_runtime_service(c,i,r,a,o);
#ifdef HOSTED_INSTRUMENT
 if(status==NVM_FILE_RUNTIME_OK && staging_fault==2 && view(c,o).owning)near_limit(c,o,UINT64_MAX);
#endif
 return status;
}
NvmFileIndirectExecutionReport dispatch_destroy(NvmFileRuntime **address,NvmFileRuntimeView *out){
#ifdef HOSTED_INSTRUMENT
 if(address && *address && (*address)->acquired){
  if(no_alloc){CHECK(failed_calls==execution_failures);allocation_budget=-1;}
  if((*address)->report.status==NVM_FILE_RUNTIME_OK && (*address)->complete){
   uint64_t owners=UINT64_MAX,borrows=UINT64_MAX;
   CHECK(!(*address)->frame_count && !(*address)->region_count);
   CHECK(nl_file_values_live_slots((*address)->files,&owners,&borrows)==NL_FILE_VALUE_OK && !owners && !borrows);
  }
 }
#endif
 return nvm_file_runtime_indirect_destroy(address,out);
}
#ifdef HOSTED_INSTRUMENT
#define nvm_file_runtime_begin dispatch_begin
#define nvm_file_runtime_frame_call dispatch_call
#define nvm_file_runtime_frame_return dispatch_return
#define nvm_file_runtime_service dispatch_service
#define nvm_file_runtime_indirect_destroy dispatch_destroy
#include "../../src/nanovm/file_vm_indirect_private.c"
#undef nvm_file_runtime_begin
#undef nvm_file_runtime_frame_call
#undef nvm_file_runtime_frame_return
#undef nvm_file_runtime_service
#undef nvm_file_runtime_indirect_destroy
#endif
#ifndef FILE_INDIRECT_VM_EXECUTE
#define FILE_INDIRECT_VM_EXECUTE nvm_file_vm_indirect_execute
#endif
#ifndef FILE_INDIRECT_EMIT
#define FILE_INDIRECT_EMIT nvm2c_file_indirect_private_emit
#endif
#ifndef FILE_INDIRECT_DISPATCH_MAIN
#define FILE_INDIRECT_DISPATCH_MAIN main
#endif
#ifdef FILE_INDIRECT_CAPTURE
static struct {uint8_t *bytes;size_t size;} captured[128];static unsigned captured_count;
static NvmFileIndirectExecutionReport execute(const uint8_t *bytes,size_t size,const NvmFileIndirectOptions *options,NvmFileRuntimeView *out){
 if(bytes && size){unsigned i=0;for(;i<captured_count;i++)if(captured[i].size==size && !memcmp(captured[i].bytes,bytes,size))break;
  if(i==captured_count){CHECK(i<128);captured[i].bytes=malloc(size);CHECK(captured[i].bytes);memcpy(captured[i].bytes,bytes,size);captured[i].size=size;captured_count++;}}
 return FILE_INDIRECT_VM_EXECUTE(bytes,size,options,out);
}
#else
NvmFileIndirectExecutionReport file_indirect_registered(const uint8_t *,size_t,const NvmFileIndirectOptions *,NvmFileRuntimeView *);
static NvmFileIndirectExecutionReport execute(const uint8_t *bytes,size_t size,const NvmFileIndirectOptions *options,NvmFileRuntimeView *out){return file_indirect_registered(bytes,size,options,out);}
#endif
static void print_detail(NlFileResult r){printf("%u,%d,%d,%zu,%u,%u,%u",r.status,r.host_errno,r.cleanup_errno,r.bytes,r.eof,r.consumed,r.cleanup_failed);}
static NvmFileIndirectExecutionReport run_wire(const uint8_t *wire,size_t size,uint64_t fuel,NvmFileRuntimeStatus expected,int64_t value,uint64_t instructions,bool trace){
 NvmFileRuntimeView out,old;memset(&out,0xa5,sizeof out);old=out;NvmFileIndirectOptions options={1,fuel};
 printf("I begin dispatch case%u fuel%llu expected%u\n",invocations,(unsigned long long)fuel,expected);
 event_bytes=0;events[0]=0;unsigned opens=open_attempts,closed_before=closed;
#ifdef HOSTED_INSTRUMENT
 size_t live=tracked_live,bytes=tracked_bytes;unsigned drains=dispatch_core_drains;
#endif
 NvmFileIndirectExecutionReport r=execute(wire,size,&options,&out);
 if(r.runtime.status!=expected)fprintf(stderr,"I expected status%u but got%u at%u:%u after%llu fuel\n",expected,r.runtime.status,r.runtime.function,r.runtime.instruction,(unsigned long long)r.instructions_started);
 CHECK(r.revision==1 && r.runtime.status==expected && r.instruction_limit==fuel);
 if(instructions!=UINT64_MAX)CHECK(r.instructions_started==instructions);
 CHECK(r.fuel_exhausted==(expected==NVM_FILE_RUNTIME_LIMIT && staging_fault<0));
 if(expected==NVM_FILE_RUNTIME_OK)CHECK(out.initialized && out.type.tag==TAG_INT && out.values[0]==value);
 else CHECK(!memcmp(&out,&old,sizeof out));
 empty_host();
#ifdef HOSTED_INSTRUMENT
 CHECK(tracked_live==live && tracked_bytes==bytes);CHECK(dispatch_core_drains==drains+(r.runtime.acquired?1u:0u));
#endif
 if(trace){printf("TRACE %u %u %u %u %u %llu %llu %u %u %u %u %llu ",invocations++,r.revision,r.runtime.status,r.runtime.acquired,r.runtime.core_status,(unsigned long long)r.instruction_limit,(unsigned long long)r.instructions_started,r.fuel_exhausted,r.runtime.function,r.runtime.instruction,r.runtime.cleanup.execution,(unsigned long long)r.runtime.cleanup.cleanup_failures);
  print_detail(r.runtime.cleanup.first_cleanup);putchar(' ');print_detail(r.runtime.cleanup.next_cleanup);
  printf(" OUT%lld HOST%u/%u %s\n",expected==NVM_FILE_RUNTIME_OK?(long long)out.values[0]:-999LL,open_attempts-opens,closed-closed_before,events);
 }
 return r;
}
static void run_module(NvmModule *m,uint64_t fuel,NvmFileRuntimeStatus expected,int64_t value,uint64_t instructions){
 size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);run_wire(wire,size,fuel,expected,value,instructions,true);release_wire(wire);
}
static NvmModule *init_helper(NvmFileNominalBindings *b){
 FrameSpec s[3]={{.result=-1},{.result=-1},{.result=-3}};
 fi(&s[0].code,11);op(&s[0].code,OP_RET);fc(&s[1].code,0);op(&s[1].code,OP_RET);fc(&s[2].code,0);op(&s[2].code,OP_POP);op(&s[2].code,OP_RET);
 NvmModule *m=frame_module(s,3,b,false,2);m->header.entry_point=1;return m;
}
static void initializer_fuel(void){
 NvmFileNominalBindings b;NvmModule *m=init_helper(&b);size_t n;uint8_t *wire=serialize(m,&n);nvm_module_free(m);
 NvmFileIndirectExecutionReport r=run_wire(wire,n,9,NVM_FILE_RUNTIME_OK,11,9,true);
 CHECK(r.runtime.function==1 && r.runtime.instruction==5);
 r=run_wire(wire,n,8,NVM_FILE_RUNTIME_LIMIT,0,8,true);CHECK(r.runtime.function==1 && r.runtime.instruction==5);
 r=run_wire(wire,n,0,NVM_FILE_RUNTIME_LIMIT,0,0,true);CHECK(r.runtime.function==2 && r.runtime.instruction==0);
 release_wire(wire);
}
static NvmModule *held_loop(NvmFileNominalBindings *b,bool fail,bool endless){
 NvmModule *seed=fixture(false,b);nvm_module_free(seed);FrameSpec s={.locals=3,.types={3,0,-1},.result=-1};Body *p=&s.code;
 service(p,*b,0,UINT16_MAX);one(p,OP_OWN_STORE_LOCAL,0);uint32_t error=branch(p,OP_FILE_RESULT_BRANCH,0);
 take_result(p,0,0);one(p,OP_OWN_STORE_LOCAL,1);op(p,OP_REGION_BEGIN);op(p,OP_BORROW_LOCAL_EXCLUSIVE);u16(p,0);u16(p,1);
 fi(p,3);one(p,OP_STORE_LOCAL,2);uint32_t header=p->n;
 if(fail){op(p,OP_PUSH_BOOL);op(p,0);op(p,OP_ASSERT);}
 one(p,OP_LOAD_LOCAL,2);fi(p,0);op(p,OP_I64_GT_S);uint32_t done=branch(p,OP_JMP_FALSE,0);
 if(!endless){one(p,OP_LOAD_LOCAL,2);fi(p,1);op(p,OP_I64_SUB);one(p,OP_STORE_LOCAL,2);}
 uint32_t back=branch(p,OP_JMP,0);wr32(p->bytes+back+1,(uint32_t)((int32_t)header-(int32_t)back));target(p,done);
 one(p,OP_FILE_END_BORROW,0);op(p,OP_REGION_END);one(p,OP_FILE_DROP_LOCAL,1);fi(p,29);op(p,OP_RET);
 target(p,error);take_result(p,0,1);op(p,OP_POP);fi(p,0);op(p,OP_RET);
 return frame_module(&s,1,b,false,-1);
}
static NvmModule *dead_label(NvmFileNominalBindings *b){NvmModule *m=csimple(b,false);Body c={0};fi(&c,17);op(&c,OP_RET);op(&c,OP_NOP);op(&c,OP_RET);setbody(m,0,c);return m;}
static NvmModule *multiple_variants(NvmFileNominalBindings *b){
 FrameSpec s={.locals=1,.types={-1},.result=-1};Body *p=&s.code;
 op(p,OP_PUSH_BOOL);op(p,1);uint32_t skip=branch(p,OP_JMP_FALSE,0);
 fi(p,7);one(p,OP_STORE_LOCAL,0);target(p,skip);fi(p,17);op(p,OP_RET);
 return frame_module(&s,1,b,false,-1);
}
static void back_to(Body *p,uint32_t where){uint32_t j=branch(p,OP_JMP,0);wr32(p->bytes+j+1,(uint32_t)((int32_t)where-(int32_t)j));}
static NvmModule *nested_iterations(NvmFileNominalBindings *b,bool early){
 FrameSpec s={.locals=3,.types={-1,-1,-1},.result=-1};Body *p=&s.code;
 fi(p,0);one(p,OP_STORE_LOCAL,2);fi(p,2);one(p,OP_STORE_LOCAL,0);uint32_t outer=p->n;
 one(p,OP_LOAD_LOCAL,0);fi(p,0);op(p,OP_I64_GT_S);uint32_t done=branch(p,OP_JMP_FALSE,0);
 fi(p,2);one(p,OP_STORE_LOCAL,1);uint32_t inner=p->n;
 one(p,OP_LOAD_LOCAL,1);fi(p,0);op(p,OP_I64_GT_S);uint32_t leave=branch(p,OP_JMP_FALSE,0);
 op(p,OP_PUSH_BOOL);op(p,early);uint32_t no_return=branch(p,OP_JMP_FALSE,0);fi(p,99);op(p,OP_RET);target(p,no_return);
 one(p,OP_LOAD_LOCAL,2);fi(p,1);op(p,OP_I64_ADD);one(p,OP_STORE_LOCAL,2);
 one(p,OP_LOAD_LOCAL,1);fi(p,1);op(p,OP_I64_SUB);one(p,OP_STORE_LOCAL,1);
 one(p,OP_LOAD_LOCAL,1);fi(p,1);op(p,OP_I64_EQ);uint32_t onward=branch(p,OP_JMP_TRUE,0);op(p,OP_NOP);target(p,onward);back_to(p,inner);
 target(p,leave);one(p,OP_LOAD_LOCAL,0);fi(p,1);op(p,OP_I64_SUB);one(p,OP_STORE_LOCAL,0);back_to(p,outer);
 target(p,done);one(p,OP_LOAD_LOCAL,2);op(p,OP_RET);return frame_module(&s,1,b,false,-1);
}
static void preserved_corpus(void){
 NvmFileNominalBindings b;
 run_module(dead_label(&b),2,NVM_FILE_RUNTIME_OK,17,2);
 run_module(multiple_variants(&b),100,NVM_FILE_RUNTIME_OK,17,6);
 run_module(nested_iterations(&b,false),1000,NVM_FILE_RUNTIME_OK,4,UINT64_MAX);
 run_module(nested_iterations(&b,true),1000,NVM_FILE_RUNTIME_OK,99,UINT64_MAX);
 initializer_fuel();
 for(unsigned perm=0;perm<2;perm++)for(unsigned k=0;k<4;k++){int64_t count=k==3?258:k;uint64_t n=8+(uint64_t)count*24;
  run_module(cloop(&b,perm!=0,count),n,NVM_FILE_RUNTIME_OK,73,n);
  run_module(cloop(&b,perm!=0,count),n-1,NVM_FILE_RUNTIME_LIMIT,0,n-1);
 }
 run_module(cswap(&b),14,NVM_FILE_RUNTIME_OK,31,14);
 run_module(owner_module(&b,false),9,NVM_FILE_RUNTIME_OK,37,9);
 run_module(cnested(&b,false),20,NVM_FILE_RUNTIME_OK,42,20);
 run_module(cnested(&b,true),9,NVM_FILE_RUNTIME_LIMIT,0,9);
 run_module(held_loop(&b,false,false),45,NVM_FILE_RUNTIME_OK,29,45);
 run_module(held_loop(&b,false,true),43,NVM_FILE_RUNTIME_LIMIT,0,43);
 run_module(held_loop(&b,true,false),100,NVM_FILE_RUNTIME_ASSERT,0,11);
 deny_open=true;run_module(cloop(&b,false,3),100,NVM_FILE_RUNTIME_OK,0,13);deny_open=false;
 close_index=0;close_error[0]=EIO;close_error[1]=ENOSPC;
 run_module(cswap(&b),14,NVM_FILE_RUNTIME_CLEANUP,0,14);memset(close_error,0,sizeof close_error);close_index=0;
#ifdef HOSTED_INSTRUMENT
 for(staging_fault=0;staging_fault<3;staging_fault++)run_module(owner_module(&b,false),100,NVM_FILE_RUNTIME_LIMIT,0,UINT64_MAX);
 staging_fault=-1;
#endif
}
static NvmModule *indirect_iterations(unsigned count){
 FrameSpec spec[3]={{.locals=3,.types={-4,-1,-1},.result=-1},
  {.parameters=1,.locals=1,.types={-1},.result=-1},
  {.parameters=1,.locals=1,.types={-1},.result=-1}};
 NvmFileNominalBindings b;Body *p=&spec[0].code;
 fi(p,count);one(p,OP_STORE_LOCAL,1);fi(p,0);one(p,OP_STORE_LOCAL,2);uint32_t header=p->n;
 one(p,OP_LOAD_LOCAL,1);fi(p,0);op(p,OP_I64_GT_S);uint32_t done=branch(p,OP_JMP_FALSE,0);
 one(p,OP_LOAD_LOCAL,1);fi(p,3);op(p,OP_I64_LT_S);uint32_t other=branch(p,OP_JMP_FALSE,0);
 iref(p,1);uint32_t join=branch(p,OP_JMP,0);target(p,other);iref(p,2);target(p,join);one(p,OP_STORE_LOCAL,0);
 one(p,OP_LOAD_LOCAL,2);one(p,OP_LOAD_LOCAL,1);one(p,OP_LOAD_LOCAL,0);icall(p);op(p,OP_I64_ADD);one(p,OP_STORE_LOCAL,2);
 one(p,OP_LOAD_LOCAL,1);fi(p,1);op(p,OP_I64_SUB);one(p,OP_STORE_LOCAL,1);back_to(p,header);
 target(p,done);one(p,OP_LOAD_LOCAL,2);op(p,OP_RET);
 one(&spec[1].code,OP_LOAD_LOCAL,0);op(&spec[1].code,OP_RET);
 one(&spec[2].code,OP_LOAD_LOCAL,0);fi(&spec[2].code,10);op(&spec[2].code,OP_I64_ADD);op(&spec[2].code,OP_RET);
 return frame_module(spec,3,&b,false,-1);
}
/* I force target propagation through a forward factory, a callable identity
 * return, and a higher-order application. Both target alternatives survive. */
static NvmModule *higher_order(bool other,unsigned owner,bool indirect_wrappers){
 int value=owner?(owner==2?0:3):-1;
 FrameSpec spec[6]={
  {.locals=2,.types={-4,3},.result=-1},
  {.parameters=1,.locals=1,.types={value},.result=value},
  {.parameters=1,.locals=1,.types={value},.result=value},
  {.parameters=1,.locals=1,.types={-4},.result=-4},
  {.parameters=2,.locals=2,.types={value,-4},.result=value},
  {.result=-4}};
 NvmFileNominalBindings bindings;Body *b=&spec[0].code;
 if(indirect_wrappers){iref(b,5);op(b,OP_CALL_INDIRECT);u16(b,0);u16(b,1);}
 else fc(b,5);
 if(indirect_wrappers){iref(b,3);icall(b);}else fc(b,3);
 one(b,OP_STORE_LOCAL,0);
 if(owner){op(b,OP_FILE_SERVICE);u32(b,0);u16(b,UINT16_MAX);}else fi(b,41);
 uint32_t failed=UINT32_MAX;
 if(owner==2){one(b,OP_OWN_STORE_LOCAL,1);failed=branch(b,OP_FILE_RESULT_BRANCH,1);take_result(b,1,0);}
 one(b,OP_LOAD_LOCAL,0);
 if(indirect_wrappers){iref(b,4);op(b,OP_CALL_INDIRECT);u16(b,2);u16(b,1);}else fc(b,4);
 if(owner){op(b,OP_FILE_DROP_STACK);fi(b,9);}op(b,OP_RET);
 if(owner==2){target(b,failed);take_result(b,1,1);op(b,OP_POP);fi(b,9);op(b,OP_RET);}
 for(unsigned f=1;f<3;f++){
  if(owner || f==1)one(&spec[f].code,owner?OP_OWN_MOVE_LOCAL:OP_LOAD_LOCAL,0);
  else fi(&spec[f].code,42);
  op(&spec[f].code,OP_RET);
 }
 one(&spec[3].code,OP_LOAD_LOCAL,0);op(&spec[3].code,OP_RET);
 one(&spec[4].code,owner?OP_OWN_MOVE_LOCAL:OP_LOAD_LOCAL,0);one(&spec[4].code,OP_LOAD_LOCAL,1);icall(&spec[4].code);op(&spec[4].code,OP_RET);
 b=&spec[5].code;op(b,OP_PUSH_BOOL);op(b,!other);uint32_t alternate=branch(b,OP_JMP_FALSE,0);
 iref(b,1);op(b,OP_RET);target(b,alternate);iref(b,2);op(b,OP_RET);
 NvmModule *m=frame_module(spec,6,&bindings,other,-1);
 if(owner)for(uint32_t pc=m->functions[0].code_offset;pc<m->functions[0].code_offset+m->functions[0].code_length;){
  DecodedInstruction d;CHECK(isa_decode(m->code+pc,m->code_size-pc,&d));
  if(d.opcode==OP_FILE_SERVICE)wr32(m->code+pc+1,bindings.imports[0]);
  pc+=d.byte_length;
 }
 return m;
}
static void higher_order_corpus(void){
 for(unsigned other=0;other<2;other++)for(unsigned owner=0;owner<3;owner++)for(unsigned wrappers=0;wrappers<2;wrappers++){
  NvmModule *m=higher_order(other,owner,wrappers);NvmFileIndirectTargets *targets=NULL;
  CHECK(nvm_file_indirect_targets(m,&targets).status==NVM_FILE_INDIRECT_DESCRIBED);
  NvmFileIndirectSummary summary;CHECK(nvm_file_indirect_targets_summary(targets,&summary));
  bool found=false;
  for(uint32_t i=0;i<summary.calls;i++){
   NvmFileIndirectCall call;CHECK(nvm_file_indirect_targets_call(targets,i,&call));
   if(call.function==4){CHECK(call.candidates==6 && call.parameters==1);found=true;}
  }
  CHECK(found);nvm_file_indirect_targets_free(targets);
  size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);int64_t expected=owner?9:other?42:41;
  NvmFileIndirectExecutionReport r=run_wire(wire,size,1000,NVM_FILE_RUNTIME_OK,expected,UINT64_MAX,true);
  run_wire(wire,size,r.instructions_started,NVM_FILE_RUNTIME_OK,expected,r.instructions_started,true);
  for(uint64_t fuel=0;fuel<r.instructions_started;fuel++)run_wire(wire,size,fuel,NVM_FILE_RUNTIME_LIMIT,0,fuel,true);
  release_wire(wire);
 }
 /* Neither an unused callable parameter nor a recursive higher-order graph
  * is permission to invent possible targets. */
 NvmModule *m=higher_order(false,0,false);Body b={0};fi(&b,0);op(&b,OP_RET);setbody(m,0,b);
 run_module(m,1000,NVM_FILE_RUNTIME_UNRESOLVED,0,0);
 m=higher_order(false,0,false);b=(Body){0};one(&b,OP_LOAD_LOCAL,0);iref(&b,1);fc(&b,4);op(&b,OP_RET);setbody(m,1,b);
 run_module(m,1000,NVM_FILE_RUNTIME_UNRESOLVED,0,0);
 deny_open=true;run_module(higher_order(false,1,true),1000,NVM_FILE_RUNTIME_OK,9,UINT64_MAX);deny_open=false;
 close_index=0;close_error[0]=EIO;run_module(higher_order(true,2,true),1000,NVM_FILE_RUNTIME_CLEANUP,0,UINT64_MAX);
 memset(close_error,0,sizeof close_error);close_index=0;
}
static void ibcall(Body *b){op(b,OP_FILE_CALL_INDIRECT_REFS);u16(b,3);u16(b,1);u32(b,0);}
static NvmModule *borrowed_indirect(unsigned mode,bool other,unsigned fault){
 /* mode0: shared aliases; mode1: exclusive disjoint; mode2: mixed disjoint;
  * mode3: repeated shared reference. Borrow maps deliberately reorder slots. */
 unsigned modes[2]={mode==1?2u:1u,(mode==1 || mode==2)?2u:1u};
 NvmFileNominalBindings bindings;NvmModule *seed=fixture(other,&bindings);nvm_module_free(seed);
 FrameSpec spec[4]={{.locals=3,.types={3,0,0},.result=-1},
  {.parameters=3,.locals=3,.types={0,0,-1},.result=-1,.borrowed=3},
  {.parameters=3,.locals=3,.types={0,0,-1},.result=-1,.borrowed=3},
  {.parameters=3,.locals=3,.types={0,0,-1},.result=-1,.borrowed=3}};
 Body *b=&spec[0].code;
 service(b,bindings,0,UINT16_MAX);one(b,OP_OWN_STORE_LOCAL,0);uint32_t first_error=branch(b,OP_FILE_RESULT_BRANCH,0);
 take_result(b,0,0);one(b,OP_OWN_STORE_LOCAL,1);
 service(b,bindings,0,UINT16_MAX);one(b,OP_OWN_STORE_LOCAL,0);uint32_t second_error=branch(b,OP_FILE_RESULT_BRANCH,0);
 take_result(b,0,0);one(b,OP_OWN_STORE_LOCAL,2);op(b,OP_REGION_BEGIN);
 op(b,modes[0]==1?OP_BORROW_LOCAL_SHARED:OP_BORROW_LOCAL_EXCLUSIVE);u16(b,11);u16(b,1);
 op(b,modes[1]==1?OP_BORROW_LOCAL_SHARED:OP_BORROW_LOCAL_EXCLUSIVE);u16(b,7);u16(b,(mode==0 || mode==3 || fault==5)?1:2);
 fi(b,41);op(b,OP_PUSH_BOOL);op(b,!other);uint32_t alternate=branch(b,OP_JMP_FALSE,0);
 iref(b,1);uint32_t join=branch(b,OP_JMP,0);target(b,alternate);iref(b,2);target(b,join);ibcall(b);
 one(b,OP_FILE_END_BORROW,11);one(b,OP_FILE_END_BORROW,7);op(b,OP_REGION_END);
 one(b,OP_FILE_DROP_LOCAL,1);one(b,OP_FILE_DROP_LOCAL,2);op(b,OP_RET);
 target(b,second_error);take_result(b,0,1);op(b,OP_POP);one(b,OP_FILE_DROP_LOCAL,1);fi(b,0);op(b,OP_RET);
 target(b,first_error);take_result(b,0,1);op(b,OP_POP);fi(b,0);op(b,OP_RET);
 for(unsigned f=1;f<3;f++){
  b=&spec[f].code;one(b,OP_LOAD_LOCAL,2);iref(b,3);ibcall(b);fi(b,f);op(b,OP_I64_ADD);op(b,OP_RET);
 }
 b=&spec[3].code;
 if(fault==7){op(b,OP_PUSH_BOOL);op(b,0);op(b,OP_ASSERT);}
 for(unsigned i=0;i<2;i++)if(modes[i]==2){one(b,OP_LOAD_LOCAL,2);service(b,bindings,1,(uint16_t)i);op(b,OP_POP);}
 one(b,OP_LOAD_LOCAL,2);op(b,OP_RET);
 NvmModule *m=frame_module(spec,4,&bindings,other,-1);
 for(unsigned f=1;f<4;f++)for(unsigned i=0;i<2;i++)
  desc(m->ownership_data+ownership_function_offset(m,f)+12+8*i,TAG_STRUCT,
       fault==4 && f==2 && i==0?2:modes[i],bindings.layouts[0]);
 uint8_t rootmap[]={11,0,7,0,255,255},forward[]={0,0,1,0,255,255};
 if(mode==3)rootmap[2]=11;
 if(fault==2){rootmap[0]=254;rootmap[1]=255;}
 if(fault==3)rootmap[4]=rootmap[5]=0;
 uint32_t maps[2]={nvm_add_string(m,(const char *)rootmap,fault==1?5:6),nvm_add_string(m,(const char *)forward,6)};
 for(unsigned f=0;f<3;f++)for(uint32_t pc=m->functions[f].code_offset;pc<m->functions[f].code_offset+m->functions[f].code_length;){
  DecodedInstruction d;CHECK(isa_decode(m->code+pc,m->code_size-pc,&d));
  if(d.opcode==OP_FILE_CALL_INDIRECT_REFS)wr32(m->code+pc+5,fault==6 && f==0?UINT32_MAX:maps[f!=0]);
  pc+=d.byte_length;
 }
 return m;
}
static NvmModule *borrowed_maximum(void){
 NvmFileNominalBindings bindings;NvmModule *seed=fixture(false,&bindings);nvm_module_free(seed);
 FrameSpec spec[2]={{.locals=2,.types={3,0},.result=-1},
  {.parameters=1,.locals=1,.types={0},.result=-1,.borrowed=1}};
 Body *b=&spec[0].code;service(b,bindings,0,UINT16_MAX);one(b,OP_OWN_STORE_LOCAL,0);
 uint32_t failed=branch(b,OP_FILE_RESULT_BRANCH,0);take_result(b,0,0);one(b,OP_OWN_STORE_LOCAL,1);
 op(b,OP_REGION_BEGIN);op(b,OP_BORROW_LOCAL_SHARED);u16(b,11);u16(b,1);iref(b,1);
 op(b,OP_FILE_CALL_INDIRECT_REFS);u16(b,256);u16(b,1);uint32_t map_site=b->n;u32(b,0);
 one(b,OP_FILE_END_BORROW,11);op(b,OP_REGION_END);one(b,OP_FILE_DROP_LOCAL,1);op(b,OP_RET);
 target(b,failed);take_result(b,0,1);op(b,OP_POP);fi(b,0);op(b,OP_RET);
 fi(&spec[1].code,42);op(&spec[1].code,OP_RET);
 NvmModule *m=frame_module(spec,2,&bindings,false,-1);size_t offset=ownership_function_offset(m,1);
 m->ownership_size+=255*8;
#ifdef HOSTED_INSTRUMENT
 m->ownership_data=file_test_realloc(m->ownership_data,m->ownership_size);
#else
 m->ownership_data=realloc(m->ownership_data,m->ownership_size);
#endif
 CHECK(m->ownership_data);
 uint8_t *d=m->ownership_data+offset;d[0]=d[2]=0;d[1]=d[3]=1;
 uint8_t tags[256],map[512];
 for(unsigned i=0;i<256;i++){desc(d+12+8*i,TAG_STRUCT,1,bindings.layouts[0]);tags[i]=TAG_STRUCT;map[2*i]=11;map[2*i+1]=0;}
 m->functions[1].arity=m->functions[1].local_count=256;CHECK(nvm_set_function_param_types(m,1,tags,256));
 uint32_t index=nvm_add_string(m,(const char *)map,sizeof map);wr32(m->code+m->functions[0].code_offset+map_site,index);
 return m;
}
static void borrowed_indirect_corpus(void){
 NvmModule *maximum=borrowed_maximum();size_t extent;uint8_t *maximum_wire=serialize(maximum,&extent);nvm_module_free(maximum);
 NvmFileIndirectHostedPlan *plan=NULL;CHECK(nvm_file_indirect_hosted_prepare(maximum_wire,extent,&plan)==NVM_FILE_FLOW_OK);
 NvmFileIndirectHostedFunction entry;CHECK(nvm_file_indirect_hosted_function(plan,0,&entry) && entry.staging_slots==258);
 nvm_file_indirect_hosted_free(plan);
 NvmFileIndirectExecutionReport complete=run_wire(maximum_wire,extent,1000,NVM_FILE_RUNTIME_OK,42,UINT64_MAX,true);
 for(uint64_t fuel=0;fuel<=complete.instructions_started;fuel++)run_wire(maximum_wire,extent,fuel,
  fuel==complete.instructions_started?NVM_FILE_RUNTIME_OK:NVM_FILE_RUNTIME_LIMIT,42,fuel,true);
 release_wire(maximum_wire);
 for(unsigned mode=0;mode<4;mode++)for(unsigned other=0;other<2;other++){
  NvmModule *m=borrowed_indirect(mode,other,0);size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);
  NvmFileIndirectExecutionReport r=run_wire(wire,size,1000,NVM_FILE_RUNTIME_OK,other?43:42,UINT64_MAX,true);
  run_wire(wire,size,r.instructions_started,NVM_FILE_RUNTIME_OK,other?43:42,r.instructions_started,true);
  for(uint64_t fuel=0;fuel<r.instructions_started;fuel++)run_wire(wire,size,fuel,NVM_FILE_RUNTIME_LIMIT,0,fuel,true);
  release_wire(wire);
 }
 for(unsigned fault=1;fault<=6;fault++)
  run_module(borrowed_indirect(fault==5?1:0,false,fault),1000,
             fault==4?NVM_FILE_RUNTIME_UNRESOLVED:NVM_FILE_RUNTIME_INVALID,0,0);
 for(unsigned mode=0;mode<3;mode++)run_module(borrowed_indirect(mode,true,7),1000,NVM_FILE_RUNTIME_ASSERT,0,UINT64_MAX);
 deny_open=true;run_module(borrowed_indirect(0,false,0),1000,NVM_FILE_RUNTIME_OK,0,UINT64_MAX);deny_open=false;
 close_index=0;close_error[0]=EIO;close_error[1]=ENOSPC;
 run_module(borrowed_indirect(2,false,0),1000,NVM_FILE_RUNTIME_CLEANUP,0,UINT64_MAX);
 memset(close_error,0,sizeof close_error);close_index=0;
}
static void cleared_callable_corpus(void){
 /* I forget cleared target identity, accept a fresh binding, and refuse stale
  * reads. The same spelling cannot erase affine owners or borrowed formals. */
 for(unsigned stale=0;stale<2;stale++){
  NvmModule *m=imodule(false,0,false,false);Body b={0};
  iref(&b,1);one(&b,OP_STORE_LOCAL,0);op(&b,OP_PUSH_VOID);one(&b,OP_STORE_LOCAL,0);
  if(!stale){iref(&b,2);one(&b,OP_STORE_LOCAL,0);}
  fi(&b,41);one(&b,OP_LOAD_LOCAL,0);icall(&b);op(&b,OP_RET);setbody(m,0,b);
  run_module(m,1000,stale?NVM_FILE_RUNTIME_INVALID:NVM_FILE_RUNTIME_OK,stale?0:42,stale?0:UINT64_MAX);
 }
 NvmModule *m=imodule(false,1,false,false);Body b={0};
 op(&b,OP_PUSH_VOID);one(&b,OP_STORE_LOCAL,0);one(&b,OP_OWN_MOVE_LOCAL,0);op(&b,OP_RET);setbody(m,1,b);
 run_module(m,1000,NVM_FILE_RUNTIME_INVALID,0,0);
 m=borrowed_indirect(0,0,0);b=(Body){0};
 op(&b,OP_PUSH_VOID);one(&b,OP_STORE_LOCAL,0);fi(&b,42);op(&b,OP_RET);setbody(m,3,b);
 run_module(m,1000,NVM_FILE_RUNTIME_INVALID,0,0);
}
static void corpus(void){
 preserved_corpus();higher_order_corpus();borrowed_indirect_corpus();cleared_callable_corpus();
 for(unsigned count=0;count<=4;count+=4){
  NvmModule *m=indirect_iterations(count);size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);
  NvmFileIndirectExecutionReport r=run_wire(wire,size,1000,NVM_FILE_RUNTIME_OK,count?30:0,UINT64_MAX,true);
  run_wire(wire,size,r.instructions_started,NVM_FILE_RUNTIME_OK,count?30:0,r.instructions_started,true);
  for(uint64_t fuel=0;fuel<r.instructions_started;fuel++)run_wire(wire,size,fuel,NVM_FILE_RUNTIME_LIMIT,0,fuel,true);
  release_wire(wire);
 }
 for(unsigned other=0;other<2;other++)for(unsigned owner=0;owner<3;owner++)for(unsigned init=0;init<2;init++)for(unsigned permute=0;permute<2;permute++){
  NvmModule *m=imodule(other,owner,init,permute);size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);
  NvmFileIndirectExecutionReport r=run_wire(wire,size,1000,NVM_FILE_RUNTIME_OK,owner?9:other?42:41,UINT64_MAX,true);
  run_wire(wire,size,r.instructions_started,NVM_FILE_RUNTIME_OK,owner?9:other?42:41,r.instructions_started,true);
  for(uint64_t fuel=0;fuel<r.instructions_started;fuel++)run_wire(wire,size,fuel,NVM_FILE_RUNTIME_LIMIT,0,fuel,true);
  release_wire(wire);
 }
 /* I retain owners in the selected callee at an assertion failure. */
 for(unsigned owner=1;owner<3;owner++){
  NvmModule *m=imodule(false,owner,true,false);Body b={0};op(&b,OP_PUSH_BOOL);op(&b,0);op(&b,OP_ASSERT);
  one(&b,OP_OWN_MOVE_LOCAL,0);op(&b,OP_RET);setbody(m,1,b);
  run_module(m,1000,NVM_FILE_RUNTIME_ASSERT,0,UINT64_MAX);
 }
 /* An indirectly selected function makes a real direct call before return. */
 for(unsigned owner=0;owner<3;owner++){
  NvmModule *m=imodule(false,owner,false,false);Body b={0};one(&b,owner?OP_OWN_MOVE_LOCAL:OP_LOAD_LOCAL,0);
  fc(&b,2);op(&b,OP_RET);setbody(m,1,b);run_module(m,1000,NVM_FILE_RUNTIME_OK,owner?9:42,UINT64_MAX);
 }
 deny_open=true;run_module(imodule(false,1,false,false),1000,NVM_FILE_RUNTIME_OK,9,UINT64_MAX);deny_open=false;
 close_index=0;close_error[0]=EIO;run_module(imodule(true,2,true,true),1000,NVM_FILE_RUNTIME_CLEANUP,0,UINT64_MAX);
 memset(close_error,0,sizeof close_error);close_index=0;
#ifdef HOSTED_INSTRUMENT
 for(staging_fault=3;staging_fault<=5;staging_fault++)run_module(imodule(false,2,false,false),1000,NVM_FILE_RUNTIME_STATE,0,UINT64_MAX);
 staging_fault=-1;
#endif
}
static void refusal_controls(void){
 NvmFileNominalBindings b;NvmModule *m=csimple(&b,false);size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);
 for(unsigned kind=0;kind<3;kind++){
  NvmFileIndirectOptions options={kind==0?2:1,kind==1?NVM_FILE_INDIRECT_FUEL_MAX+1:37};
  NvmFileRuntimeView out,old;memset(&out,0x5a,sizeof out);old=out;unsigned opens=open_attempts;
  NvmFileIndirectExecutionReport report=execute(wire,size,kind==2?NULL:&options,&out);
  CHECK(report.runtime.status==NVM_FILE_RUNTIME_INVALID && !report.runtime.acquired && !report.instructions_started && !report.fuel_exhausted);
  CHECK(report.instruction_limit==(kind==2?0:options.instruction_limit) && !memcmp(&out,&old,sizeof out) && open_attempts==opens);
 }
 release_wire(wire);
 m=dead_label(&b);m->code[m->code_size-2]=OP_PRINT;
 run_module(m,100,NVM_FILE_RUNTIME_UNRESOLVED,0,0);
 m=held_loop(&b,false,false);CHECK(!nvm_verify(m).ok);char error[256];CHECK(!nvm2c_emit(m,error,sizeof error));
 nvm_module_free(m);
 CHECK(nvm_file_runtime_indirect_native_abi(1,sizeof(NvmFileIndirectOptions),sizeof(NvmFileIndirectExecutionReport),sizeof(NvmFileIndirectFrameView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)));
 CHECK(!nvm_file_runtime_indirect_native_abi(2,sizeof(NvmFileIndirectOptions),sizeof(NvmFileIndirectExecutionReport),sizeof(NvmFileIndirectFrameView),sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)));
 CHECK(!nvm_file_runtime_indirect_native_abi(1,sizeof(NvmFileIndirectOptions),sizeof(NvmFileIndirectExecutionReport),sizeof(NvmFileIndirectFrameView)+1,sizeof(NvmFileRuntimeFrameView),sizeof(NvmFileRuntimeView)));
}
static void prepare_faults(void){
#ifdef HOSTED_INSTRUMENT
 NvmModule *m=higher_order(false,1,true);size_t size;uint8_t *wire=serialize(m,&size);nvm_module_free(m);
 no_alloc=false;size_t live=tracked_live,bytes=tracked_bytes;unsigned refusals=0;
 NvmFileIndirectOptions options={1,100};
 for(unsigned transient=0;transient<2;transient++){
  bool complete=false;
  for(unsigned prefix=0;prefix<4096;prefix++){
   printf("I begin allocation prefix%u transient%u\n",prefix,transient);
   NvmFileRuntimeView out,old;memset(&out,0xa5,sizeof out);old=out;
   allocation_budget=(int)prefix;single_failure=transient!=0;failed_calls=0;
   NvmFileIndirectExecutionReport report=execute(wire,size,&options,&out);
   allocation_budget=-1;single_failure=false;
   if(report.runtime.status==NVM_FILE_RUNTIME_OK){CHECK(out.values[0]==9);if(!failed_calls)complete=true;}
   else {CHECK(failed_calls && !memcmp(&out,&old,sizeof out));CHECK(report.runtime.status==NVM_FILE_RUNTIME_MEMORY || report.runtime.status==NVM_FILE_RUNTIME_UNRESOLVED);CHECK(!report.fuel_exhausted);refusals++;}
   CHECK(tracked_live==live && tracked_bytes==bytes);empty_host();
   NvmFileIndirectExecutionReport recovery=execute(wire,size,&options,&out);CHECK(recovery.runtime.status==NVM_FILE_RUNTIME_OK && out.values[0]==9);
   CHECK(tracked_live==live && tracked_bytes==bytes);empty_host();if(complete)break;
  }
  CHECK(complete);
 }
 CHECK(refusals);printf("PASS indirect dispatch preparation allocation refusals=%u\n",refusals);no_alloc=true;release_wire(wire);
#endif
}
#ifdef FILE_INDIRECT_CAPTURE
int file_indirect_buffer_checks(void);
static void emit_cases(const char *directory){
 CHECK(file_indirect_buffer_checks()==0);
#ifdef HOSTED_INSTRUMENT
 size_t live=tracked_live,bytes=tracked_bytes;unsigned refusals=0;
 for(unsigned transient=0;transient<2;transient++){
  bool complete=false;
  for(unsigned prefix=0;prefix<4096;prefix++){
   printf("I begin allocation prefix%u transient%u\n",prefix,transient);
   char *out=(char *)(uintptr_t)1;char error[256];unsigned opens=open_attempts;
   allocation_budget=(int)prefix;single_failure=transient!=0;failed_calls=0;
   NvmFileRuntimeStatus status=FILE_INDIRECT_EMIT(captured[0].bytes,captured[0].size,&out,error,sizeof error);
   allocation_budget=-1;single_failure=false;CHECK(open_attempts==opens);
   if(status==NVM_FILE_RUNTIME_OK){CHECK(out!=(char *)(uintptr_t)1);file_test_free(out);if(!failed_calls)complete=true;}
   else {CHECK(failed_calls && out==(char *)(uintptr_t)1);CHECK(status==NVM_FILE_RUNTIME_MEMORY || status==NVM_FILE_RUNTIME_UNRESOLVED);refusals++;}
   CHECK(tracked_live==live && tracked_bytes==bytes);
   char *recovered=(char *)(uintptr_t)1;size_t failures=failed_calls;
   ROK(FILE_INDIRECT_EMIT(captured[0].bytes,captured[0].size,&recovered,error,sizeof error));
   CHECK(recovered && recovered!=(char *)(uintptr_t)1 && recovered[0] && !error[0]);
   CHECK(open_attempts==opens && failed_calls==failures);file_test_free(recovered);
   CHECK(tracked_live==live && tracked_bytes==bytes);if(complete)break;
  }
  CHECK(complete);
 }
 CHECK(refusals);printf("PASS indirect emitter allocation refusals=%u\n",refusals);
#endif
 char path[4096];CHECK(snprintf(path,sizeof path,"%s/cases.tsv",directory)>0);FILE *manifest=fopen(path,"w");CHECK(manifest);
 for(unsigned i=0;i<captured_count;i++){
  CHECK(snprintf(path,sizeof path,"%s/case-%03u.nvm",directory,i)>0);FILE *file=fopen(path,"wb");CHECK(file);
  CHECK(fwrite(captured[i].bytes,1,captured[i].size,file)==captured[i].size && !fclose(file));
  char *text=(char *)(uintptr_t)1;char error[256];unsigned opens=open_attempts;
  NvmFileRuntimeStatus status=FILE_INDIRECT_EMIT(captured[i].bytes,captured[i].size,&text,error,sizeof error);CHECK(open_attempts==opens);
  if(status==NVM_FILE_RUNTIME_OK){CHECK(snprintf(path,sizeof path,"%s/case-%03u.c",directory,i)>0);file=fopen(path,"w");CHECK(file);size_t n=strlen(text);CHECK(fwrite(text,1,n,file)==n && !fclose(file));release_wire(text);}
  else CHECK(text==(char *)(uintptr_t)1 && (status==NVM_FILE_RUNTIME_UNRESOLVED || status==NVM_FILE_RUNTIME_INVALID));
  CHECK(fprintf(manifest,"%u\t%u\t%zu\n",i,status,captured[i].size)>0);free(captured[i].bytes);
 }
 CHECK(!fclose(manifest));CHECK(captured_count>=15);
 printf("PASS indirect VM capture: %u exact modules\n",captured_count);
}
int FILE_INDIRECT_DISPATCH_MAIN(int argc,char **argv){CHECK(argc==2);CHECK(!setvbuf(stdout,NULL,_IONBF,0));
 (void)retained_indirect_carrier_main;corpus();refusal_controls();prepare_faults();emit_cases(argv[1]);empty_host();
#ifdef HOSTED_INSTRUMENT
 CHECK(!tracked_live && !tracked_bytes);
#endif
 return 0;
}
#else
int FILE_INDIRECT_DISPATCH_MAIN(void){CHECK(!setvbuf(stdout,NULL,_IONBF,0));(void)retained_indirect_carrier_main;
 corpus();refusal_controls();prepare_faults();empty_host();
#ifdef HOSTED_INSTRUMENT
 CHECK(!tracked_live && !tracked_bytes);
#endif
 printf("PASS indirect native replay: %u matching report/host traces\n",invocations);return 0;
}
#endif
