import ast,hashlib,json,os,re,shlex,shutil,subprocess,sys,time,signal
from pathlib import Path
root=Path(sys.argv[1]).resolve();report=Path(sys.argv[2]).resolve();worker='parser-driver-diagnostic'
# This bounded gate proves preparation only; it cannot produce a passing worker result.
report.mkdir(parents=True,exist_ok=False);artifacts=report/'artifacts';artifacts.mkdir();os.chdir(root)
base=Path('/tmp/nanolang-record-backend-integration-driver.py');tree=ast.parse(base.read_text())
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('sha','write','inventory','run')]
assert len(selected)==4
for node in selected:
 if node.name=='run':
  matches=[item for item in node.body if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='phase_bound' for t in item.targets)]
  assert len(matches)==1
  matches[0].value=ast.parse("180",mode='eval').body
module=ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[]));exec(compile(module,str(base),'exec'))
(report/'effective-supervisor.py').write_text(ast.unparse(module)+'\n');shutil.copyfile(__file__,report/'driver.py');shutil.copyfile(base,report/'base-supervisor.py')
files=[p for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p and not p.startswith('docs/evidence/')]
assert len(files)>3000 and all((root/p).is_file() for p in files)
def source():return {p:sha(root/p) for p in files}
paths={name:shutil.which(name) for name in ('make','cc','gcc','ld','ar','nm','python3','perl','pkg-config','ps')}
paths.update(driver_python=sys.executable,driver=__file__,base_supervisor=str(base),planner=str(root/'scripts/ci_sanitizer_partitions.py'))
for name in ('cc1','collect2','libasan.so','libubsan.so','libgcc_s.so.1'):
 path=subprocess.check_output(['gcc',('-print-prog-name=' if name in ('cc1','collect2') else '-print-file-name=')+name],text=True).strip()
 if Path(path).is_file():paths[name]=path
assert all(paths.values())
def tools():return {name:{'path':str(Path(path).resolve()),'sha256':sha(path)} for name,path in paths.items()}
phases=set();results=[];darwin=False
os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['NANO_SHADOW_TIMEOUT_SECONDS']='60'
os.environ.pop('NANOLANG_COMPILER',None);os.environ.pop('UBSAN_OPTIONS',None);os.environ.pop('LSAN_OPTIONS',None)

os.environ['NANO_SHADOW_TIMING']='1'
os.environ['NANO_CFLAGS']='-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer'
os.environ['NANO_VERBOSE_BUILD']='1'
sample=root/'src_nano/parser_driver.nano'
paths.update(compiler=str(root/'bin/nanoc_c'),sample=str(sample),assembler_capture=str(root/'bin/nano_as_capture.so'))
prior=json.loads(Path('/home/jkh/nanolang-qualification/ci-native-preparation-cce540-reports/sanitize-artifacts.json').read_text())
entry=prior['/home/jkh/nanolang-qualification/ci-native-preparation-cce540-source/bin/nanoc_c']
assert sha(root/'bin/nanoc_c')==entry['sha256']
assert sha(root/'bin/nano_as_capture.so')==prior['/home/jkh/nanolang-qualification/ci-native-preparation-cce540-source/bin/nano_as_capture.so']['sha256']
write('attribution.json',{'scope':'reviewed1ee parser component correction; original520 controls unchanged; same retained cce Cseed','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_sha256':entry['sha256'],'sample_sha256':sha(sample),'shadow_bound':60,'outer_bound':180})
run('parser-driver',[str(root/'bin/nanoc_c'),str(sample),'--verbose','--test-imports','-o',str(report/'sample')])
write('retained-sample-products.json',inventory([report]))
