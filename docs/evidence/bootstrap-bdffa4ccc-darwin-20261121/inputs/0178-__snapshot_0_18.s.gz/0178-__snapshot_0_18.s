	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_host_enter_query    ; -- Begin function nvm_socket_host_enter_query
	.p2align	2
_nvm_socket_host_enter_query:           ; @nvm_socket_host_enter_query
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_nvm_file_host_enter_query
	mov	w8, #5                          ; =0x5
	cmp	w0, #0
	csel	w0, wzr, w8, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_host_leave          ; -- Begin function nvm_socket_host_leave
	.p2align	2
_nvm_socket_host_leave:                 ; @nvm_socket_host_leave
	.cfi_startproc
; %bb.0:
	b	_nvm_file_host_leave
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_host_enter          ; -- Begin function nvm_socket_host_enter
	.p2align	2
_nvm_socket_host_enter:                 ; @nvm_socket_host_enter
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB2_2
; %bb.1:
	mov	w0, #5                          ; =0x5
	b	LBB2_14
LBB2_2:
	cbz	x19, LBB2_11
; %bb.3:
	mov	w8, #4                          ; =0x4
	cmp	w21, #2
	b.ne	LBB2_13
; %bb.4:
	cmp	w20, #1
	b.ne	LBB2_13
; %bb.5:
	ldr	x9, [x19]
Lloh0:
	adrp	x10, _socket_host_identity@PAGE
Lloh1:
	add	x10, x10, _socket_host_identity@PAGEOFF
	cmp	x9, x10
	b.ne	LBB2_13
; %bb.6:
	ldr	w8, [x19, #8]
	cmp	w8, #1
	b.ne	LBB2_12
; %bb.7:
	ldr	w8, [x19, #12]
	cmp	w8, #2
	b.ne	LBB2_12
; %bb.8:
	ldr	w8, [x19, #16]
	cmp	w8, #1
	b.ne	LBB2_12
; %bb.9:
	ldrb	w8, [x19, #20]
	tbz	w8, #0, LBB2_15
; %bb.10:
	mov	w0, #0                          ; =0x0
	b	LBB2_14
LBB2_11:
	mov	w8, #1                          ; =0x1
	b	LBB2_13
LBB2_12:
	mov	w8, #4                          ; =0x4
LBB2_13:
	mov	x19, x8
	bl	_nvm_file_host_leave
	mov	x0, x19
LBB2_14:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB2_15:
	mov	w8, #3                          ; =0x3
	b	LBB2_13
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_host_grant_create_tcp_connections
lCPI3_0:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_host_grant_create_tcp_connections
	.p2align	2
_nvm_socket_host_grant_create_tcp_connections: ; @nvm_socket_host_grant_create_tcp_connections
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB3_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB3_8
LBB3_2:
	cbz	x20, LBB3_5
; %bb.3:
	mov	w0, #24                         ; =0x18
	bl	_malloc
	cbz	x0, LBB3_6
; %bb.4:
	mov	w19, #0                         ; =0x0
	strb	wzr, [x0, #23]
	sturh	wzr, [x0, #21]
Lloh2:
	adrp	x8, _socket_host_identity@PAGE
Lloh3:
	add	x8, x8, _socket_host_identity@PAGEOFF
	str	x8, [x0]
Lloh4:
	adrp	x8, lCPI3_0@PAGE
Lloh5:
	ldr	d0, [x8, lCPI3_0@PAGEOFF]
	str	d0, [x0, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x0, #16]
	strb	w8, [x0, #20]
	str	x0, [x20]
	b	LBB3_7
LBB3_5:
	mov	w19, #1                         ; =0x1
	b	LBB3_7
LBB3_6:
	mov	w19, #2                         ; =0x2
LBB3_7:
	bl	_nvm_file_host_leave
LBB3_8:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_host_grant_revoke   ; -- Begin function nvm_socket_host_grant_revoke
	.p2align	2
_nvm_socket_host_grant_revoke:          ; @nvm_socket_host_grant_revoke
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB4_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB4_11
LBB4_2:
	cbz	x20, LBB4_9
; %bb.3:
	ldr	x8, [x20]
Lloh6:
	adrp	x9, _socket_host_identity@PAGE
Lloh7:
	add	x9, x9, _socket_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB4_8
; %bb.4:
	ldr	w8, [x20, #8]
	cmp	w8, #1
	b.ne	LBB4_8
; %bb.5:
	ldr	w8, [x20, #12]
	cmp	w8, #2
	b.ne	LBB4_8
; %bb.6:
	ldr	w8, [x20, #16]
	cmp	w8, #1
	b.ne	LBB4_8
; %bb.7:
	mov	w19, #0                         ; =0x0
	strb	wzr, [x20, #20]
	b	LBB4_10
LBB4_8:
	mov	w19, #4                         ; =0x4
	b	LBB4_10
LBB4_9:
	mov	w19, #1                         ; =0x1
LBB4_10:
	bl	_nvm_file_host_leave
LBB4_11:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_host_grant_destroy  ; -- Begin function nvm_socket_host_grant_destroy
	.p2align	2
_nvm_socket_host_grant_destroy:         ; @nvm_socket_host_grant_destroy
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
	bl	_nvm_file_host_enter_query
	cbz	w0, LBB5_2
; %bb.1:
	mov	w19, #5                         ; =0x5
	b	LBB5_13
LBB5_2:
	cbz	x20, LBB5_9
; %bb.3:
	ldr	x0, [x20]
	cbz	x0, LBB5_11
; %bb.4:
	ldr	x8, [x0]
Lloh8:
	adrp	x9, _socket_host_identity@PAGE
Lloh9:
	add	x9, x9, _socket_host_identity@PAGEOFF
	cmp	x8, x9
	b.ne	LBB5_10
; %bb.5:
	ldr	w8, [x0, #8]
	cmp	w8, #1
	b.ne	LBB5_10
; %bb.6:
	ldr	w8, [x0, #12]
	cmp	w8, #2
	b.ne	LBB5_10
; %bb.7:
	ldr	w8, [x0, #16]
	cmp	w8, #1
	b.ne	LBB5_10
; %bb.8:
	bl	_free
	mov	w19, #0                         ; =0x0
	str	xzr, [x20]
	b	LBB5_12
LBB5_9:
	mov	w19, #1                         ; =0x1
	b	LBB5_12
LBB5_10:
	mov	w19, #4                         ; =0x4
	b	LBB5_12
LBB5_11:
	mov	w19, #0                         ; =0x0
LBB5_12:
	bl	_nvm_file_host_leave
LBB5_13:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @socket_host_identity
_socket_host_identity:
	.long	1                               ; 0x1

.subsections_via_symbols
