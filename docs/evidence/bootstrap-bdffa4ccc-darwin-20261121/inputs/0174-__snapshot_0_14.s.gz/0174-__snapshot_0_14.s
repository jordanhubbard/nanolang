	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_service_publish             ; -- Begin function nl_service_publish
	.p2align	2
_nl_service_publish:                    ; @nl_service_publish
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #7840                       ; =0x1ea0
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3744
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w26, #1                         ; =0x1
	cbz	x0, LBB0_115
; %bb.1:
	cbz	x1, LBB0_115
; %bb.2:
	cbz	x4, LBB0_115
; %bb.3:
	mov	x23, x3
	mov	x24, x2
	cbnz	x2, LBB0_5
; %bb.4:
	cbnz	x23, LBB0_115
LBB0_5:
	ldr	x8, [x4, #8]
	cbz	x8, LBB0_115
; %bb.6:
	ldr	x8, [x4]
	cbz	x8, LBB0_8
; %bb.7:
	ldrb	w8, [x8]
	cbz	w8, LBB0_115
LBB0_8:
	ldr	x20, [x4, #48]
	cbz	x20, LBB0_16
; %bb.9:
	ldr	w8, [x20]
	cmp	w8, #1
	b.ne	LBB0_15
; %bb.10:
	ldr	w8, [x20, #8]
	mov	w9, #60000                      ; =0xea60
	cmp	w8, w9
	b.hi	LBB0_15
; %bb.11:
	ldrb	w9, [x20, #5]
	ldr	x8, [x20, #16]
	cmp	x8, #0
	cset	w10, ne
	cmp	w9, w10
	b.ne	LBB0_15
; %bb.12:
	cbz	x8, LBB0_36
; %bb.13:
	ldrb	w9, [x8]
	cmp	w9, #47
	b.ne	LBB0_15
; %bb.14:
	mov	x19, x0
	mov	x0, x8
	mov	x21, x4
	mov	x22, x1
	bl	_strlen
	mov	x1, x22
	mov	x4, x21
	mov	x8, x0
	mov	x0, x19
	cmp	x8, #1, lsl #12                 ; =4096
	b.lo	LBB0_36
LBB0_15:
Lloh5:
	adrp	x8, ___stderrp@GOTPAGE
Lloh6:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh7:
	ldr	x1, [x8]
Lloh8:
	adrp	x0, l_.str@PAGE
Lloh9:
	add	x0, x0, l_.str@PAGEOFF
	bl	_fputs
	b	LBB0_115
LBB0_16:
	mov	w9, #0                          ; =0x0
	mov	x25, x4
	mov	x21, x4
	ldrb	w8, [x21, #41]!
	mov	x19, x21
	ldrb	w10, [x19, #2]!
LBB0_17:
	and	w2, w8, #0x1
	and	w3, w10, #0x1
	and	w4, w9, #0x1
	add	x5, sp, #304
	stp	x0, x1, [sp, #96]               ; 16-byte Folded Spill
	bl	_nl_service_policy_read
	cbz	w0, LBB0_115
; %bb.18:
	ldr	w20, [sp, #304]
	ldrb	w22, [sp, #832]
	cbz	x23, LBB0_20
; %bb.19:
	mov	x8, x25
	ldp	x0, x1, [sp, #96]               ; 16-byte Folded Reload
	tbz	w22, #0, LBB0_22
	b	LBB0_32
LBB0_20:
	mov	x8, x25
	ldrb	w9, [x25, #42]
	cmp	w9, #1
	ldp	x0, x1, [sp, #96]               ; 16-byte Folded Reload
	b.ne	LBB0_32
; %bb.21:
	tbnz	w22, #0, LBB0_32
LBB0_22:
	ldrb	w9, [sp, #833]
	cmp	w9, #1
	b.ne	LBB0_25
; %bb.23:
	ldrb	w9, [x21]
	tbnz	w9, #0, LBB0_25
; %bb.24:
Lloh10:
	adrp	x9, ___stderrp@GOTPAGE
Lloh11:
	ldr	x9, [x9, ___stderrp@GOTPAGEOFF]
Lloh12:
	ldr	x1, [x9]
Lloh13:
	adrp	x0, l_.str.1@PAGE
Lloh14:
	add	x0, x0, l_.str.1@PAGEOFF
	mov	x20, x8
	bl	_fputs
	mov	x8, x20
LBB0_25:
	ldrb	w9, [sp, #834]
	cmp	w9, #1
	b.ne	LBB0_28
; %bb.26:
	ldrb	w9, [x19]
	tbnz	w9, #0, LBB0_28
; %bb.27:
Lloh15:
	adrp	x9, ___stderrp@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stderrp@GOTPAGEOFF]
Lloh17:
	ldr	x1, [x9]
Lloh18:
	adrp	x0, l_.str.2@PAGE
Lloh19:
	add	x0, x0, l_.str.2@PAGEOFF
	mov	x19, x8
	bl	_fputs
	mov	x8, x19
LBB0_28:
	ldrb	w9, [sp, #835]
	cmp	w9, #1
	b.ne	LBB0_115
; %bb.29:
	ldr	x8, [x8, #48]
	cbz	x8, LBB0_31
; %bb.30:
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB0_115
LBB0_31:
Lloh20:
	adrp	x8, ___stderrp@GOTPAGE
Lloh21:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh22:
	ldr	x1, [x8]
Lloh23:
	adrp	x0, l_.str.3@PAGE
Lloh24:
	add	x0, x0, l_.str.3@PAGEOFF
	bl	_fputs
	b	LBB0_115
LBB0_32:
	str	xzr, [sp, #296]
	mov	x19, x8
Lloh25:
	adrp	x2, l_.str.4@PAGE
Lloh26:
	add	x2, x2, l_.str.4@PAGEOFF
	add	x3, sp, #296
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3472
	mov	w5, #256                        ; =0x100
	cmp	w20, #4
	b.ne	LBB0_34
; %bb.33:
	bl	_nvm2c_emit_websocket_indirect_bytes
	b	LBB0_40
LBB0_34:
	cmp	w20, #3
	b.ne	LBB0_37
; %bb.35:
	bl	_nvm2c_emit_services_indirect_bytes
	b	LBB0_40
LBB0_36:
	mov	x25, x4
	mov	x21, x4
	ldrb	w8, [x21, #41]!
	mov	x19, x21
	ldrb	w10, [x19, #2]!
	ldrb	w9, [x20, #4]
	b	LBB0_17
LBB0_37:
	cmp	w20, #2
	b.ne	LBB0_39
; %bb.38:
	bl	_nvm2c_emit_socket_indirect_bytes
	b	LBB0_40
LBB0_39:
	bl	_nvm2c_emit_file_indirect_bytes
LBB0_40:
	cbz	w0, LBB0_42
; %bb.41:
Lloh27:
	adrp	x8, ___stderrp@GOTPAGE
Lloh28:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh29:
	ldr	x0, [x8]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3472
	str	x8, [sp]
Lloh30:
	adrp	x1, l_.str.5@PAGE
Lloh31:
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_fprintf
	b	LBB0_115
LBB0_42:
	str	x19, [sp, #72]                  ; 8-byte Folded Spill
	ldr	x8, [x19]
Lloh32:
	adrp	x9, l_.str.6@PAGE
Lloh33:
	add	x9, x9, l_.str.6@PAGEOFF
	cmp	x8, #0
	csel	x0, x9, x8, eq
	bl	_strdup
	cbz	x0, LBB0_114
; %bb.43:
	mov	x21, x0
	mov	w1, #47                         ; =0x2f
	bl	_strrchr
	cbz	x0, LBB0_46
; %bb.44:
	cmp	x0, x21
	b.eq	LBB0_47
; %bb.45:
	strb	wzr, [x0]
	b	LBB0_48
LBB0_46:
	mov	w8, #46                         ; =0x2e
	strh	w8, [x21]
	b	LBB0_48
LBB0_47:
	strb	wzr, [x0, #1]
LBB0_48:
Lloh34:
	adrp	x1, l_.str.8@PAGE
Lloh35:
	add	x1, x1, l_.str.8@PAGEOFF
	mov	x0, x21
	bl	_joined
	mov	x25, x0
Lloh36:
	adrp	x1, l_.str.9@PAGE
Lloh37:
	add	x1, x1, l_.str.9@PAGEOFF
	mov	x0, x21
	bl	_joined
	mov	x19, x0
	mov	x0, x21
	bl	_free
	mov	x27, #0                         ; =0x0
	stp	x19, x25, [sp, #80]             ; 16-byte Folded Spill
	cbz	x25, LBB0_53
; %bb.49:
	str	w20, [sp, #68]                  ; 4-byte Folded Spill
	mov	x28, x27
	mov	x25, x27
	mov	x20, x27
	mov	x21, x27
	mov	x0, x27
	cbz	x19, LBB0_113
; %bb.50:
	ldr	x19, [sp, #88]                  ; 8-byte Folded Reload
	mov	x0, x19
	bl	_mkdtemp
	cbz	x0, LBB0_54
; %bb.51:
Lloh38:
	adrp	x1, l_.str.10@PAGE
Lloh39:
	add	x1, x1, l_.str.10@PAGEOFF
	mov	x0, x19
	bl	_joined
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
Lloh40:
	adrp	x1, l_.str.11@PAGE
Lloh41:
	add	x1, x1, l_.str.11@PAGEOFF
	mov	x0, x19
	bl	_joined
	mov	x26, x0
Lloh42:
	adrp	x1, l_.str.12@PAGE
Lloh43:
	add	x1, x1, l_.str.12@PAGEOFF
	mov	x0, x19
	bl	_joined
	mov	x25, x0
	cbz	x0, LBB0_55
; %bb.52:
Lloh44:
	adrp	x8, l_.str.16@PAGE
Lloh45:
	add	x8, x8, l_.str.16@PAGEOFF
Lloh46:
	adrp	x9, l_.str.15@PAGE
Lloh47:
	add	x9, x9, l_.str.15@PAGEOFF
	ldr	w28, [sp, #68]                  ; 4-byte Folded Reload
	cmp	w28, #2
	csel	x8, x9, x8, eq
Lloh48:
	adrp	x9, l_.str.14@PAGE
Lloh49:
	add	x9, x9, l_.str.14@PAGEOFF
	cmp	w28, #3
	csel	x8, x9, x8, eq
Lloh50:
	adrp	x9, l_.str.13@PAGE
Lloh51:
	add	x9, x9, l_.str.13@PAGEOFF
	cmp	w28, #4
	csel	x1, x9, x8, eq
	mov	x0, x25
	bl	_joined
	mov	x21, x0
	b	LBB0_56
LBB0_53:
	mov	x28, x27
	mov	x25, x27
	mov	x20, x27
	mov	x21, x27
	mov	x0, x27
	b	LBB0_113
LBB0_54:
	mov	x27, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB0_113
LBB0_55:
	mov	x21, #0                         ; =0x0
	ldr	w28, [sp, #68]                  ; 4-byte Folded Reload
LBB0_56:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	mov	x1, #0                          ; =0x0
	bl	_realpath$DARWIN_EXTSN
	str	x26, [sp, #48]                  ; 8-byte Folded Spill
	str	x25, [sp, #32]                  ; 8-byte Folded Spill
	cbz	x0, LBB0_66
; %bb.57:
Lloh52:
	adrp	x1, l_.str.17@PAGE
Lloh53:
	add	x1, x1, l_.str.17@PAGEOFF
	mov	x26, x0
	bl	_joined
	mov	x20, x0
Lloh54:
	adrp	x8, l_.str.21@PAGE
Lloh55:
	add	x8, x8, l_.str.21@PAGEOFF
Lloh56:
	adrp	x9, l_.str.20@PAGE
Lloh57:
	add	x9, x9, l_.str.20@PAGEOFF
	cmp	w28, #2
	csel	x8, x9, x8, eq
Lloh58:
	adrp	x9, l_.str.19@PAGE
Lloh59:
	add	x9, x9, l_.str.19@PAGEOFF
	cmp	w28, #3
	csel	x8, x9, x8, eq
Lloh60:
	adrp	x9, l_.str.18@PAGE
Lloh61:
	add	x9, x9, l_.str.18@PAGEOFF
	cmp	w28, #4
	csel	x1, x9, x8, eq
	mov	x0, x26
	bl	_joined
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x0, x26
	bl	_free
	mov	w27, #0                         ; =0x0
	cbz	x25, LBB0_75
; %bb.58:
	ldp	x26, x0, [sp, #48]              ; 16-byte Folded Reload
	cbz	x0, LBB0_76
; %bb.59:
	cbz	x26, LBB0_76
; %bb.60:
	cbz	x21, LBB0_76
; %bb.61:
	cbz	x20, LBB0_76
; %bb.62:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x8, LBB0_76
; %bb.63:
	add	x1, sp, #152
	mov	x0, x20
	bl	_stat
	cbnz	w0, LBB0_67
; %bb.64:
	ldrh	w8, [sp, #156]
	and	w8, w8, #0xf000
	cmp	w8, #4, lsl #12                 ; =16384
	b.ne	LBB0_67
; %bb.65:
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB0_72
LBB0_66:
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	b	LBB0_74
LBB0_67:
	mov	x0, x20
	bl	_free
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	mov	x1, #0                          ; =0x0
	bl	_realpath$DARWIN_EXTSN
	cbz	x0, LBB0_74
; %bb.68:
Lloh62:
	adrp	x8, l_.str.25@PAGE
Lloh63:
	add	x8, x8, l_.str.25@PAGEOFF
Lloh64:
	adrp	x9, l_.str.24@PAGE
Lloh65:
	add	x9, x9, l_.str.24@PAGEOFF
	cmp	w28, #2
	csel	x8, x9, x8, eq
Lloh66:
	adrp	x9, l_.str.23@PAGE
Lloh67:
	add	x9, x9, l_.str.23@PAGEOFF
	cmp	w28, #3
	csel	x8, x9, x8, eq
Lloh68:
	adrp	x9, l_.str.22@PAGE
Lloh69:
	add	x9, x9, l_.str.22@PAGEOFF
	cmp	w28, #4
	csel	x1, x9, x8, eq
	mov	x26, x0
	bl	_joined
	mov	x20, x0
	mov	x0, x26
	bl	_free
	cbz	x20, LBB0_77
; %bb.69:
	add	x1, sp, #152
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	mov	x0, x20
	bl	_stat
	cbnz	w0, LBB0_78
; %bb.70:
	ldrh	w8, [sp, #156]
	and	w8, w8, #0xf000
	cmp	w8, #4, lsl #12                 ; =16384
	b.ne	LBB0_100
; %bb.71:
	ldr	w28, [sp, #68]                  ; 4-byte Folded Reload
LBB0_72:
	cmp	w28, #4
	b.ne	LBB0_80
; %bb.73:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x2, [x8, #48]
	mov	x0, x24
	mov	x1, x23
	ldr	x19, [sp, #48]                  ; 8-byte Folded Reload
	mov	x3, x19
	bl	_nl_service_run_websocket_shadows
	b	LBB0_83
LBB0_74:
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
	mov	w27, #0                         ; =0x0
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	b	LBB0_102
LBB0_75:
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB0_79
LBB0_76:
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	b	LBB0_102
LBB0_77:
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
LBB0_78:
	mov	w27, #0                         ; =0x0
LBB0_79:
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	ldp	x26, x0, [sp, #48]              ; 16-byte Folded Reload
	b	LBB0_102
LBB0_80:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #3
	b.ne	LBB0_82
; %bb.81:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldrb	w2, [x8, #41]
	ldrb	w3, [x8, #43]
	ldr	x4, [x8, #48]
	mov	x0, x24
	mov	x1, x23
	ldr	x19, [sp, #48]                  ; 8-byte Folded Reload
	mov	x5, x19
	bl	_nl_service_run_mixed_config_shadows
	b	LBB0_83
LBB0_82:
	mov	x0, x24
	mov	x1, x23
	ldr	w2, [sp, #68]                   ; 4-byte Folded Reload
	mov	x3, x22
	ldr	x19, [sp, #48]                  ; 8-byte Folded Reload
	mov	x4, x19
	bl	_nl_service_run_catalog_shadows
LBB0_83:
	mov	x20, x0
	mov	x24, x1
Lloh70:
	adrp	x1, l_.str.26@PAGE
Lloh71:
	add	x1, x1, l_.str.26@PAGEOFF
	mov	x0, x19
	bl	_fopen$DARWIN_EXTSN
	cbz	x0, LBB0_100
; %bb.84:
	mov	x26, x0
	add	x0, sp, #840
	mov	w1, #1                          ; =0x1
	mov	w2, #4096                       ; =0x1000
	mov	x3, x26
	bl	_fread
	cbz	x0, LBB0_87
; %bb.85:
	mov	x2, x0
Lloh72:
	adrp	x22, ___stderrp@GOTPAGE
Lloh73:
	ldr	x22, [x22, ___stderrp@GOTPAGEOFF]
LBB0_86:                                ; =>This Inner Loop Header: Depth=1
	ldr	x3, [x22]
	add	x0, sp, #840
	mov	w1, #1                          ; =0x1
	bl	_fwrite
	add	x0, sp, #840
	mov	w1, #1                          ; =0x1
	mov	w2, #4096                       ; =0x1000
	mov	x3, x26
	bl	_fread
	mov	x2, x0
	cbnz	x0, LBB0_86
LBB0_87:
	mov	x0, x26
	bl	_ferror
	mov	x22, x0
	mov	x0, x26
	bl	_fclose
	orr	w8, w0, w22
	cbnz	w8, LBB0_100
; %bb.88:
	cbnz	w20, LBB0_99
; %bb.89:
	cmp	x24, x23
	b.ne	LBB0_99
; %bb.90:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x24, [x8]
	cmp	x24, #0
	cset	w27, ne
	cbz	x24, LBB0_95
; %bb.91:
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_mkstemp
	tbnz	w0, #31, LBB0_100
; %bb.92:
	mov	x22, x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #40]
	cmp	w8, #1
	b.ne	LBB0_126
; %bb.93:
	mov	x0, x22
	ldp	x1, x2, [sp, #96]               ; 16-byte Folded Reload
	bl	_write_bytes
	mov	x23, x0
	mov	x0, x22
	bl	_close
	cbnz	w0, LBB0_127
; %bb.94:
	tbz	w23, #0, LBB0_127
LBB0_95:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #42]
	cmp	w8, #1
	b.ne	LBB0_117
; %bb.96:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #4
	b.ne	LBB0_128
; %bb.97:
	str	xzr, [sp, #144]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #48]
	add	x1, sp, #144
	bl	_nvm_websocket_host_grant_create
	cbnz	w0, LBB0_101
; %bb.98:
	stp	xzr, xzr, [sp, #128]
Lloh74:
	adrp	x8, l___const.nl_service_publish.execution.43@PAGE
Lloh75:
	add	x8, x8, l___const.nl_service_publish.execution.43@PAGEOFF
Lloh76:
	ldr	q0, [x8]
	str	q0, [sp, #112]
	ldr	x0, [sp, #144]
	add	x8, sp, #840
	add	x3, sp, #112
	add	x4, sp, #128
	ldp	x1, x2, [sp, #96]               ; 16-byte Folded Reload
	bl	_nvm_websocket_execute_indirect_bytes
	ldr	x0, [sp, #144]
	bl	_nvm_websocket_host_grant_revoke
	mov	x20, x0
	add	x0, sp, #144
	bl	_nvm_websocket_host_grant_destroy
	ldr	w8, [sp, #848]
	cbz	w8, LBB0_141
	b	LBB0_101
LBB0_99:
Lloh77:
	adrp	x8, ___stderrp@GOTPAGE
Lloh78:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh79:
	adrp	x9, l_.str.31@PAGE
Lloh80:
	add	x9, x9, l_.str.31@PAGEOFF
Lloh81:
	adrp	x10, l_.str.30@PAGE
Lloh82:
	add	x10, x10, l_.str.30@PAGEOFF
Lloh83:
	ldr	x0, [x8]
	ldr	w11, [sp, #68]                  ; 4-byte Folded Reload
	cmp	w11, #2
	csel	x8, x10, x9, eq
Lloh84:
	adrp	x9, l_.str.29@PAGE
Lloh85:
	add	x9, x9, l_.str.29@PAGEOFF
	cmp	w11, #3
	csel	x8, x9, x8, eq
Lloh86:
	adrp	x9, l_.str.28@PAGE
Lloh87:
	add	x9, x9, l_.str.28@PAGEOFF
	cmp	w11, #4
	csel	x8, x9, x8, eq
	mov	x9, x20
	stp	x8, x9, [sp]
Lloh88:
	adrp	x1, l_.str.27@PAGE
Lloh89:
	add	x1, x1, l_.str.27@PAGEOFF
	bl	_fprintf
LBB0_100:
	mov	w27, #0                         ; =0x0
LBB0_101:
	ldp	x23, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x0, [sp, #48]              ; 16-byte Folded Reload
	ldr	x25, [sp, #32]                  ; 8-byte Folded Reload
LBB0_102:
	bl	_remove_file
	mov	x20, x0
	mov	x0, x26
	bl	_remove_file
	mov	x22, x0
	mov	x0, x21
	bl	_remove_file
	and	w8, w0, w22
	and	w20, w8, w20
	cbz	x25, LBB0_105
; %bb.103:
	mov	x0, x25
	bl	_rmdir
	cbz	w0, LBB0_105
; %bb.104:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #2
	cset	w8, eq
	and	w20, w8, w20
LBB0_105:
	mov	x0, x19
	bl	_rmdir
	cbnz	w0, LBB0_109
; %bb.106:
	tbz	w20, #0, LBB0_109
; %bb.107:
	mov	w26, #1                         ; =0x1
	cbnz	w27, LBB0_110
LBB0_108:
	mov	x25, x21
	b	LBB0_112
LBB0_109:
Lloh90:
	adrp	x8, ___stderrp@GOTPAGE
Lloh91:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh92:
	ldr	x1, [x8]
Lloh93:
	adrp	x0, l_.str.44@PAGE
Lloh94:
	add	x0, x0, l_.str.44@PAGEOFF
	bl	_fputs
	mov	w26, #1                         ; =0x1
	tbz	w27, #0, LBB0_108
LBB0_110:
	mov	x25, x21
	mov	x0, x23
	bl	_remove_file
	tbnz	w0, #0, LBB0_112
; %bb.111:
Lloh95:
	adrp	x8, ___stderrp@GOTPAGE
Lloh96:
	ldr	x8, [x8, ___stderrp@GOTPAGEOFF]
Lloh97:
	ldr	x1, [x8]
Lloh98:
	adrp	x0, l_.str.45@PAGE
Lloh99:
	add	x0, x0, l_.str.45@PAGEOFF
	bl	_fputs
LBB0_112:
	ldp	x21, x0, [sp, #48]              ; 16-byte Folded Reload
	ldp	x20, x27, [sp, #32]             ; 16-byte Folded Reload
	ldr	x28, [sp, #24]                  ; 8-byte Folded Reload
LBB0_113:
	bl	_free
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_free
	mov	x0, x25
	bl	_free
	mov	x0, x28
	bl	_free
	mov	x0, x27
	bl	_free
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_free
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_free
LBB0_114:
	ldr	x0, [sp, #296]
	bl	_free
LBB0_115:
	ldur	x8, [x29, #-96]
Lloh100:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh101:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh102:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB0_131
; %bb.116:
	mov	x0, x26
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3744
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_117:
	mov	w26, #0                         ; =0x0
LBB0_118:
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_remove_file
	cbz	w0, LBB0_101
; %bb.119:
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	bl	_remove_file
	cbz	w0, LBB0_101
; %bb.120:
	mov	x0, x21
	bl	_remove_file
	cbz	w0, LBB0_101
; %bb.121:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_rmdir
	cbz	w0, LBB0_123
; %bb.122:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #2
	b.ne	LBB0_101
LBB0_123:
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_rmdir
	cbnz	w0, LBB0_101
; %bb.124:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [x8]
	cbz	x1, LBB0_176
; %bb.125:
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	mov	x0, x23
	bl	_rename
	cmp	w0, #0
	csinc	w26, w26, wzr, eq
	cbnz	x24, LBB0_110
	b	LBB0_108
LBB0_126:
	mov	x0, x22
	bl	_close
	cbz	w0, LBB0_132
LBB0_127:
	mov	w27, #1                         ; =0x1
	b	LBB0_101
LBB0_128:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #3
	b.ne	LBB0_136
; %bb.129:
	str	xzr, [sp, #144]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x1, [x8, #48]
	add	x0, sp, #304
	add	x2, sp, #144
	bl	_nl_service_policy_grant
	cbnz	w0, LBB0_101
; %bb.130:
	stp	xzr, xzr, [sp, #128]
Lloh103:
	adrp	x8, l___const.nl_service_publish.execution.43@PAGE
Lloh104:
	add	x8, x8, l___const.nl_service_publish.execution.43@PAGEOFF
Lloh105:
	ldr	q0, [x8]
	str	q0, [sp, #112]
	ldr	x0, [sp, #144]
	add	x8, sp, #840
	add	x3, sp, #112
	add	x4, sp, #128
	ldp	x1, x2, [sp, #96]               ; 16-byte Folded Reload
	bl	_nvm_services_execute_indirect_bytes
	ldr	x0, [sp, #144]
	bl	_nvm_services_host_grant_revoke
	mov	x20, x0
	add	x0, sp, #144
	bl	_nvm_services_host_grant_destroy
	ldr	w8, [sp, #848]
	cbz	w8, LBB0_141
	b	LBB0_101
LBB0_131:
	bl	___stack_chk_fail
LBB0_132:
	mov	w8, #384                        ; =0x180
	str	x8, [sp]
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	w1, #2561                       ; =0xa01
	bl	_open
	tbnz	w0, #31, LBB0_127
; %bb.133:
	mov	x22, x0
	ldr	x23, [sp, #296]
	mov	x0, x23
	bl	_strlen
	mov	x2, x0
	mov	x0, x22
	mov	x1, x23
	bl	_write_bytes
	tbz	w0, #0, LBB0_147
; %bb.134:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	subs	w26, w8, #3
	b.ne	LBB0_148
; %bb.135:
	add	x1, sp, #304
	mov	x0, x22
	bl	_write_mixed_launcher
	b	LBB0_149
LBB0_136:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	cmp	w8, #2
	b.ne	LBB0_139
; %bb.137:
	str	xzr, [sp, #144]
	add	x0, sp, #144
	bl	_nvm_socket_host_grant_create_tcp_connections
	cbnz	w0, LBB0_101
; %bb.138:
	stp	xzr, xzr, [sp, #128]
Lloh106:
	adrp	x8, l___const.nl_service_publish.execution.43@PAGE
Lloh107:
	add	x8, x8, l___const.nl_service_publish.execution.43@PAGEOFF
Lloh108:
	ldr	q0, [x8]
	str	q0, [sp, #112]
	ldr	x0, [sp, #144]
	add	x8, sp, #840
	add	x3, sp, #112
	add	x4, sp, #128
	ldp	x1, x2, [sp, #96]               ; 16-byte Folded Reload
	bl	_nvm_socket_execute_indirect_bytes
	ldr	x0, [sp, #144]
	bl	_nvm_socket_host_grant_revoke
	mov	x20, x0
	add	x0, sp, #144
	bl	_nvm_socket_host_grant_destroy
	ldr	w8, [sp, #848]
	cbz	w8, LBB0_141
	b	LBB0_101
LBB0_139:
	str	xzr, [sp, #144]
	add	x0, sp, #144
	bl	_nvm_file_host_grant_create_temporary_files
	cbnz	w0, LBB0_101
; %bb.140:
	stp	xzr, xzr, [sp, #128]
Lloh109:
	adrp	x8, l___const.nl_service_publish.execution.43@PAGE
Lloh110:
	add	x8, x8, l___const.nl_service_publish.execution.43@PAGEOFF
Lloh111:
	ldr	q0, [x8]
	str	q0, [sp, #112]
	ldr	x0, [sp, #144]
	add	x8, sp, #840
	add	x3, sp, #112
	add	x4, sp, #128
	ldp	x1, x2, [sp, #96]               ; 16-byte Folded Reload
	bl	_nvm_file_execute_indirect_bytes
	ldr	x0, [sp, #144]
	bl	_nvm_file_host_grant_revoke
	mov	x20, x0
	add	x0, sp, #144
	bl	_nvm_file_host_grant_destroy
	ldr	w8, [sp, #848]
	cbnz	w8, LBB0_101
LBB0_141:
	ldrb	w8, [sp, #852]
	tbz	w8, #0, LBB0_101
; %bb.142:
	ldr	x8, [sp, #880]
	cbnz	x8, LBB0_101
; %bb.143:
	cbnz	w20, LBB0_101
; %bb.144:
	cbnz	w0, LBB0_101
; %bb.145:
	ldr	x8, [sp, #144]
	cbnz	x8, LBB0_101
; %bb.146:
	ldr	x8, [sp, #136]
	and	w26, w8, #0xff
	b	LBB0_118
LBB0_147:
	mov	x0, x22
	bl	_close
	mov	w27, #1                         ; =0x1
	b	LBB0_101
LBB0_148:
Lloh112:
	adrp	x8, _launcher@PAGE
Lloh113:
	add	x8, x8, _launcher@PAGEOFF
Lloh114:
	adrp	x9, _socket_launcher@PAGE
Lloh115:
	add	x9, x9, _socket_launcher@PAGEOFF
	ldr	w10, [sp, #68]                  ; 4-byte Folded Reload
	cmp	w10, #2
	csel	x8, x9, x8, eq
Lloh116:
	adrp	x9, _websocket_launcher@PAGE
Lloh117:
	add	x9, x9, _websocket_launcher@PAGEOFF
	cmp	w10, #4
	csel	x23, x9, x8, eq
	mov	x0, x23
	bl	_strlen
	mov	x2, x0
	mov	x0, x22
	mov	x1, x23
	bl	_write_bytes
LBB0_149:
	mov	x23, x0
	mov	x0, x22
	bl	_close
	cbnz	w0, LBB0_127
; %bb.150:
	cbz	w23, LBB0_127
; %bb.151:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	w1, #448                        ; =0x1c0
	bl	_mkdir
	cbnz	w0, LBB0_127
; %bb.152:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x1, x21
	bl	_symlink
	cbnz	w0, LBB0_127
; %bb.153:
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_module_quote_path
	mov	x23, x0
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_module_quote_path
	mov	x25, x0
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_module_quote_path
	mov	x20, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	bl	_module_quote_path
	mov	x19, x0
	str	xzr, [sp, #840]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x22, [x8, #32]
	cbnz	x22, LBB0_155
; %bb.154:
Lloh118:
	adrp	x0, l_.str.32@PAGE
Lloh119:
	add	x0, x0, l_.str.32@PAGEOFF
	bl	_getenv
	mov	x22, x0
LBB0_155:
	cbz	x23, LBB0_177
; %bb.156:
	cbz	x25, LBB0_177
; %bb.157:
	cbz	x20, LBB0_177
; %bb.158:
	cbz	x19, LBB0_177
; %bb.159:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
Lloh120:
	adrp	x9, l_.str.33@PAGE
Lloh121:
	add	x9, x9, l_.str.33@PAGEOFF
	cmp	x8, #0
	csel	x1, x9, x8, eq
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.160:
Lloh122:
	adrp	x1, l_.str.34@PAGE
Lloh123:
	add	x1, x1, l_.str.34@PAGEOFF
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.161:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
Lloh124:
	adrp	x9, l_.str.35@PAGE
Lloh125:
	add	x9, x9, l_.str.35@PAGEOFF
	cmp	x8, #0
	csel	x1, x9, x8, eq
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.162:
Lloh126:
	adrp	x1, l_.str.36@PAGE
Lloh127:
	add	x1, x1, l_.str.36@PAGEOFF
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.163:
	add	x0, sp, #840
	mov	x1, x20
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.164:
	add	x0, sp, #840
	mov	x1, x23
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.165:
	add	x0, sp, #840
	mov	x1, x19
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.166:
Lloh128:
	adrp	x1, l_.str.37@PAGE
Lloh129:
	add	x1, x1, l_.str.37@PAGEOFF
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.167:
	cmp	w26, #1
	b.hi	LBB0_169
; %bb.168:
Lloh130:
	adrp	x1, l_.str.38@PAGE
Lloh131:
	add	x1, x1, l_.str.38@PAGEOFF
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
LBB0_169:
Lloh132:
	adrp	x8, l_.str.39@PAGE
Lloh133:
	add	x8, x8, l_.str.39@PAGEOFF
	cmp	x22, #0
	csel	x1, x8, x22, eq
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.170:
Lloh134:
	adrp	x1, l_.str.40@PAGE
Lloh135:
	add	x1, x1, l_.str.40@PAGEOFF
	add	x0, sp, #840
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.171:
	add	x0, sp, #840
	mov	x1, x25
	bl	_module_append_fragment
	cbz	w0, LBB0_177
; %bb.172:
	ldr	x22, [sp, #840]
	mov	x0, x22
	bl	_compile_native
	mov	x26, x0
	mov	x0, x22
	bl	_free
	mov	x0, x23
	bl	_free
	mov	x0, x25
	bl	_free
	mov	x0, x20
	bl	_free
	mov	x0, x19
	bl	_free
	cbz	w26, LBB0_127
; %bb.173:
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	w1, #448                        ; =0x1c0
	bl	_chmod
	cbnz	w0, LBB0_127
; %bb.174:
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	w1, #0                          ; =0x0
	bl	_open
	tbnz	w0, #31, LBB0_127
; %bb.175:
	mov	x22, x0
	bl	_fsync
	mov	x23, x0
	mov	x0, x22
	bl	_close
	orr	w8, w0, w23
	cbz	w8, LBB0_95
	b	LBB0_127
LBB0_176:
	ldr	x23, [sp, #80]                  ; 8-byte Folded Reload
	cbz	w27, LBB0_108
	b	LBB0_110
LBB0_177:
	ldr	x0, [sp, #840]
	bl	_free
	mov	x0, x23
	bl	_free
	mov	x0, x25
	bl	_free
	mov	x0, x20
	bl	_free
	mov	x0, x19
	bl	_free
	mov	w27, #1                         ; =0x1
	b	LBB0_101
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpAdd	Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh10, Lloh11, Lloh12
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.loh AdrpAdd	Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh20, Lloh21, Lloh22
	.loh AdrpAdd	Lloh25, Lloh26
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpLdrGotLdr	Lloh27, Lloh28, Lloh29
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh62, Lloh63
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpLdrGot	Lloh72, Lloh73
	.loh AdrpAddLdr	Lloh74, Lloh75, Lloh76
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh81, Lloh82
	.loh AdrpAdd	Lloh79, Lloh80
	.loh AdrpLdrGotLdr	Lloh77, Lloh78, Lloh83
	.loh AdrpAdd	Lloh93, Lloh94
	.loh AdrpLdrGotLdr	Lloh90, Lloh91, Lloh92
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpLdrGotLdr	Lloh95, Lloh96, Lloh97
	.loh AdrpLdrGotLdr	Lloh100, Lloh101, Lloh102
	.loh AdrpAddLdr	Lloh103, Lloh104, Lloh105
	.loh AdrpAddLdr	Lloh106, Lloh107, Lloh108
	.loh AdrpAddLdr	Lloh109, Lloh110, Lloh111
	.loh AdrpAdd	Lloh116, Lloh117
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpAdd	Lloh112, Lloh113
	.loh AdrpAdd	Lloh118, Lloh119
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.loh AdrpAdd	Lloh126, Lloh127
	.loh AdrpAdd	Lloh128, Lloh129
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpAdd	Lloh132, Lloh133
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function joined
_joined:                                ; @joined
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
	bl	_strlen
	mov	x21, x0
	mov	x0, x20
	bl	_strlen
	mov	x8, #-3                         ; =0xfffffffffffffffd
	sub	x8, x8, x0
	cmp	x21, x8
	b.ls	LBB1_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	b	LBB1_4
LBB1_2:
	add	x21, x21, x0
	add	x0, x21, #2
	bl	_malloc
	cbz	x0, LBB1_4
; %bb.3:
	stp	x19, x20, [sp]
Lloh136:
	adrp	x2, l_.str.46@PAGE
Lloh137:
	add	x2, x2, l_.str.46@PAGEOFF
	add	x1, x21, #2
	mov	x19, x0
	bl	_snprintf
	mov	x0, x19
LBB1_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpAdd	Lloh136, Lloh137
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_bytes
_write_bytes:                           ; @write_bytes
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	cbz	x2, LBB2_7
; %bb.1:
	mov	x20, x2
	mov	x21, x1
	b	LBB2_4
LBB2_2:                                 ;   in Loop: Header=BB2_4 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB2_9
; %bb.3:                                ;   in Loop: Header=BB2_4 Depth=1
	cbz	x20, LBB2_7
LBB2_4:                                 ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x21
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB2_2
; %bb.5:                                ;   in Loop: Header=BB2_4 Depth=1
	cbz	x0, LBB2_8
; %bb.6:                                ;   in Loop: Header=BB2_4 Depth=1
	add	x21, x21, x0
	sub	x20, x20, x0
	cbnz	x20, LBB2_4
LBB2_7:
	mov	x0, x19
	bl	_fsync
	cmp	w0, #0
	cset	w0, eq
LBB2_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB2_9:
	mov	w0, #0                          ; =0x0
	b	LBB2_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function write_mixed_launcher
_write_mixed_launcher:                  ; @write_mixed_launcher
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #304]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #320]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #336]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh138:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh139:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh140:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	ldr	x8, [x1, #8]
	cbz	x8, LBB3_7
; %bb.1:
	mov	x21, x1
	ldr	w8, [x1, #16]
Lloh141:
	adrp	x9, l_.str.39@PAGE
Lloh142:
	add	x9, x9, l_.str.39@PAGEOFF
	stp	x9, x8, [sp]
Lloh143:
	adrp	x2, l_.str.47@PAGE
Lloh144:
	add	x2, x2, l_.str.47@PAGEOFF
	add	x0, sp, #16
	mov	w1, #256                        ; =0x100
	bl	_snprintf
	cmp	w0, #255
	b.hi	LBB3_23
; %bb.2:
	mov	w20, w0
	ldr	x8, [x21, #8]
	cmp	x8, #2
	b.lo	LBB3_8
; %bb.3:
	add	x24, x21, #24
	mov	w25, #1                         ; =0x1
	add	x26, sp, #16
	mov	w27, #256                       ; =0x100
Lloh145:
	adrp	x28, l_.str.48@PAGE
Lloh146:
	add	x28, x28, l_.str.48@PAGEOFF
Lloh147:
	adrp	x22, l_.str.47@PAGE
Lloh148:
	add	x22, x22, l_.str.47@PAGEOFF
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	sub	x23, x27, x20
	ldr	w8, [x24], #8
	stp	x28, x8, [sp]
	add	x0, x26, x20
	mov	x1, x23
	mov	x2, x22
	bl	_snprintf
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	tbnz	w8, #31, LBB3_24
; %bb.5:                                ;   in Loop: Header=BB3_4 Depth=1
	mov	w8, w8
	cmp	x23, x8
	b.ls	LBB3_24
; %bb.6:                                ;   in Loop: Header=BB3_4 Depth=1
	add	x20, x20, x8
	add	x25, x25, #1
	ldr	x8, [x21, #8]
	cmp	x25, x8
	b.lo	LBB3_4
	b	LBB3_8
LBB3_7:
	mov	x20, #0                         ; =0x0
LBB3_8:
Lloh149:
	adrp	x21, _write_mixed_launcher.prefix@PAGE
Lloh150:
	add	x21, x21, _write_mixed_launcher.prefix@PAGEOFF
	mov	w22, #62                        ; =0x3e
	b	LBB3_11
LBB3_9:                                 ;   in Loop: Header=BB3_11 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB3_23
; %bb.10:                               ;   in Loop: Header=BB3_11 Depth=1
	cbz	x22, LBB3_14
LBB3_11:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x21
	mov	x2, x22
	bl	_write
	tbnz	x0, #63, LBB3_9
; %bb.12:                               ;   in Loop: Header=BB3_11 Depth=1
	cbz	x0, LBB3_24
; %bb.13:                               ;   in Loop: Header=BB3_11 Depth=1
	add	x21, x21, x0
	sub	x22, x22, x0
	cbnz	x22, LBB3_11
LBB3_14:
	mov	x0, x19
	bl	_fsync
	cbnz	w0, LBB3_23
; %bb.15:
	cbz	x20, LBB3_22
; %bb.16:
	add	x21, sp, #16
	b	LBB3_19
LBB3_17:                                ;   in Loop: Header=BB3_19 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB3_23
; %bb.18:                               ;   in Loop: Header=BB3_19 Depth=1
	cbz	x20, LBB3_22
LBB3_19:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x21
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB3_17
; %bb.20:                               ;   in Loop: Header=BB3_19 Depth=1
	cbz	x0, LBB3_24
; %bb.21:                               ;   in Loop: Header=BB3_19 Depth=1
	add	x21, x21, x0
	sub	x20, x20, x0
	cbnz	x20, LBB3_19
LBB3_22:
	mov	x0, x19
	bl	_fsync
	cbz	w0, LBB3_26
LBB3_23:
	mov	w0, #0                          ; =0x0
LBB3_24:
	ldur	x8, [x29, #-96]
Lloh151:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh152:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh153:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB3_33
; %bb.25:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #352]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #336]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #320]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
LBB3_26:
Lloh154:
	adrp	x20, _write_mixed_launcher.suffix@PAGE
Lloh155:
	add	x20, x20, _write_mixed_launcher.suffix@PAGEOFF
	mov	w21, #2040                      ; =0x7f8
	b	LBB3_29
LBB3_27:                                ;   in Loop: Header=BB3_29 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB3_23
; %bb.28:                               ;   in Loop: Header=BB3_29 Depth=1
	cbz	x21, LBB3_32
LBB3_29:                                ; =>This Inner Loop Header: Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	bl	_write
	tbnz	x0, #63, LBB3_27
; %bb.30:                               ;   in Loop: Header=BB3_29 Depth=1
	cbz	x0, LBB3_24
; %bb.31:                               ;   in Loop: Header=BB3_29 Depth=1
	add	x20, x20, x0
	sub	x21, x21, x0
	cbnz	x21, LBB3_29
LBB3_32:
	mov	x0, x19
	bl	_fsync
	cmp	w0, #0
	cset	w0, eq
	b	LBB3_24
LBB3_33:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh138, Lloh139, Lloh140
	.loh AdrpAdd	Lloh143, Lloh144
	.loh AdrpAdd	Lloh141, Lloh142
	.loh AdrpAdd	Lloh147, Lloh148
	.loh AdrpAdd	Lloh145, Lloh146
	.loh AdrpAdd	Lloh149, Lloh150
	.loh AdrpLdrGotLdr	Lloh151, Lloh152, Lloh153
	.loh AdrpAdd	Lloh154, Lloh155
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function module_quote_path
_module_quote_path:                     ; @module_quote_path
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_strlen
	lsr	x8, x0, #62
	cbz	x8, LBB4_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	b	LBB4_9
LBB4_2:
	mov	w8, #3                          ; =0x3
	orr	x0, x8, x0, lsl #2
	bl	_malloc
	cbz	x0, LBB4_9
; %bb.3:
	mov	w9, #39                         ; =0x27
	mov	x8, x0
	strb	w9, [x8], #1
	mov	w9, #23591                      ; =0x5c27
	movk	w9, #10023, lsl #16
	b	LBB4_5
LBB4_4:                                 ;   in Loop: Header=BB4_5 Depth=1
	str	w9, [x8], #4
	add	x19, x19, #1
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x19]
	cmp	w10, #39
	b.eq	LBB4_4
; %bb.6:                                ;   in Loop: Header=BB4_5 Depth=1
	cbz	w10, LBB4_8
; %bb.7:                                ;   in Loop: Header=BB4_5 Depth=1
	strb	w10, [x8], #1
	add	x19, x19, #1
	b	LBB4_5
LBB4_8:
	mov	w9, #39                         ; =0x27
	strh	w9, [x8]
LBB4_9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function module_append_fragment
_module_append_fragment:                ; @module_append_fragment
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldr	x23, [x0]
	cbz	x23, LBB5_2
; %bb.1:
	mov	x0, x23
	bl	_strlen
	mov	x22, x0
	b	LBB5_3
LBB5_2:
	mov	x22, #0                         ; =0x0
LBB5_3:
	mov	x0, x20
	bl	_strlen
	mov	x8, #-3                         ; =0xfffffffffffffffd
	sub	x8, x8, x22
	cmp	x0, x8
	b.ls	LBB5_5
; %bb.4:
	mov	w0, #0                          ; =0x0
	b	LBB5_10
LBB5_5:
	mov	x21, x0
	add	x8, x22, x0
	add	x1, x8, #2
	mov	x0, x23
	bl	_realloc
	cbz	x0, LBB5_10
; %bb.6:
	cbz	x22, LBB5_8
; %bb.7:
	add	x8, x22, #1
	mov	w9, #32                         ; =0x20
	strb	w9, [x0, x22]
	b	LBB5_9
LBB5_8:
	mov	x8, #0                          ; =0x0
LBB5_9:
	mov	x22, x0
	add	x0, x0, x8
	add	x2, x21, #1
	mov	x1, x20
	bl	_memcpy
	str	x22, [x19]
	mov	w0, #1                          ; =0x1
LBB5_10:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function compile_native
_compile_native:                        ; @compile_native
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x0
Lloh156:
	adrp	x8, l___const.compile_native.pause@PAGE
Lloh157:
	add	x8, x8, l___const.compile_native.pause@PAGEOFF
Lloh158:
	ldr	q0, [x8]
	str	q0, [sp, #32]
	sub	x1, x29, #32
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB6_3
LBB6_1:
	mov	w0, #0                          ; =0x0
LBB6_2:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB6_3:
	bl	_fork
	cbz	w0, LBB6_22
; %bb.4:
	mov	x19, x0
	tbnz	w0, #31, LBB6_1
; %bb.5:
	mov	x0, x19
	mov	x1, x19
	bl	_setpgid
	str	wzr, [sp, #28]
LBB6_6:                                 ; =>This Inner Loop Header: Depth=1
	add	x1, sp, #28
	mov	x0, x19
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	cmp	w0, w19
	b.eq	LBB6_12
; %bb.7:                                ;   in Loop: Header=BB6_6 Depth=1
	tbz	w0, #31, LBB6_9
; %bb.8:                                ;   in Loop: Header=BB6_6 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB6_13
LBB6_9:                                 ;   in Loop: Header=BB6_6 Depth=1
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_13
; %bb.10:                               ;   in Loop: Header=BB6_6 Depth=1
	ldr	x8, [sp, #48]
	ldur	x9, [x29, #-32]
	sub	x8, x8, x9
	cmp	x8, #119
	b.gt	LBB6_13
; %bb.11:                               ;   in Loop: Header=BB6_6 Depth=1
	add	x0, sp, #32
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	b	LBB6_6
LBB6_12:
	ldrh	w8, [sp, #28]
	mov	w9, #65407                      ; =0xff7f
	tst	w8, w9
	cset	w20, eq
	b	LBB6_14
LBB6_13:
	mov	w20, #0                         ; =0x0
LBB6_14:
	neg	w0, w19
	mov	w1, #9                          ; =0x9
	bl	_kill
	cbz	w0, LBB6_16
; %bb.15:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #3
	cset	w0, eq
	tbnz	w20, #0, LBB6_2
	b	LBB6_17
LBB6_16:
	mov	w0, #1                          ; =0x1
	tbnz	w20, #0, LBB6_2
LBB6_17:
	mov	x0, x19
	mov	w1, #9                          ; =0x9
	bl	_kill
	mov	w20, #100                       ; =0x64
	b	LBB6_19
LBB6_18:                                ;   in Loop: Header=BB6_19 Depth=1
	add	x0, sp, #32
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	subs	w20, w20, #1
	b.eq	LBB6_1
LBB6_19:                                ; =>This Inner Loop Header: Depth=1
	add	x1, sp, #28
	mov	x0, x19
	mov	w2, #1                          ; =0x1
	bl	_waitpid
	cmp	w0, w19
	b.eq	LBB6_1
; %bb.20:                               ;   in Loop: Header=BB6_19 Depth=1
	tbz	w0, #31, LBB6_18
; %bb.21:                               ;   in Loop: Header=BB6_19 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #10
	b.ne	LBB6_18
	b	LBB6_1
LBB6_22:
	mov	w1, #0                          ; =0x0
	bl	_setpgid
	cbnz	w0, LBB6_24
; %bb.23:
	stp	x20, xzr, [sp, #8]
Lloh159:
	adrp	x8, l_.str.52@PAGE
Lloh160:
	add	x8, x8, l_.str.52@PAGEOFF
	str	x8, [sp]
Lloh161:
	adrp	x0, l_.str.50@PAGE
Lloh162:
	add	x0, x0, l_.str.50@PAGEOFF
Lloh163:
	adrp	x1, l_.str.51@PAGE
Lloh164:
	add	x1, x1, l_.str.51@PAGEOFF
	bl	_execl
LBB6_24:
	mov	w0, #1                          ; =0x1
	bl	__exit
	.loh AdrpAddLdr	Lloh156, Lloh157, Lloh158
	.loh AdrpAdd	Lloh163, Lloh164
	.loh AdrpAdd	Lloh161, Lloh162
	.loh AdrpAdd	Lloh159, Lloh160
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function remove_file
_remove_file:                           ; @remove_file
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_3
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_unlink
	cbz	w0, LBB7_4
; %bb.2:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #2
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB7_3:
	mov	w0, #1                          ; =0x1
	ret
LBB7_4:
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require separate WebSocket lookup permission and an absolute resolver helper together.\n"

l_.str.1:                               ; @.str.1
	.asciz	"I require --allow-temporary-files for selected service shadows or execution.\n"

l_.str.2:                               ; @.str.2
	.asciz	"I require --allow-tcp-connections for selected service shadows or execution.\n"

l_.str.3:                               ; @.str.3
	.asciz	"I require --allow-websocket-connections for selected service shadows or execution.\n"

l_.str.4:                               ; @.str.4
	.asciz	"product"

l_.str.5:                               ; @.str.5
	.asciz	"I cannot validate service output: %s\n"

l_.str.6:                               ; @.str.6
	.asciz	"/tmp/nano-file-run"

l_.str.8:                               ; @.str.8
	.asciz	".nano-file.XXXXXX"

l_.str.9:                               ; @.str.9
	.asciz	".nano-publish.XXXXXX"

l_.str.10:                              ; @.str.10
	.asciz	"program.c"

l_.str.11:                              ; @.str.11
	.asciz	"shadows.log"

l_.str.12:                              ; @.str.12
	.asciz	"nanolang"

l_.str.13:                              ; @.str.13
	.asciz	"websocket"

l_.str.14:                              ; @.str.14
	.asciz	"services"

l_.str.15:                              ; @.str.15
	.asciz	"socket"

l_.str.16:                              ; @.str.16
	.asciz	"file"

l_.str.17:                              ; @.str.17
	.asciz	"src"

l_.str.18:                              ; @.str.18
	.asciz	"lib/libnano_websocket_runtime.a"

l_.str.19:                              ; @.str.19
	.asciz	"lib/libnano_services_runtime.a"

l_.str.20:                              ; @.str.20
	.asciz	"lib/libnano_socket_runtime.a"

l_.str.21:                              ; @.str.21
	.asciz	"lib/libnano_file_runtime.a"

l_.str.22:                              ; @.str.22
	.asciz	"include/nanolang/websocket"

l_.str.23:                              ; @.str.23
	.asciz	"include/nanolang/services"

l_.str.24:                              ; @.str.24
	.asciz	"include/nanolang/socket"

l_.str.25:                              ; @.str.25
	.asciz	"include/nanolang/file"

l_.str.26:                              ; @.str.26
	.asciz	"rb"

l_.str.27:                              ; @.str.27
	.asciz	"I will not publish after %s shadow failure (status %u).\n"

l_.str.28:                              ; @.str.28
	.asciz	"WebSocket"

l_.str.29:                              ; @.str.29
	.asciz	"mixed-service"

l_.str.30:                              ; @.str.30
	.asciz	"TCP"

l_.str.31:                              ; @.str.31
	.asciz	"File"

	.section	__TEXT,__const
_websocket_launcher:                    ; @websocket_launcher
	.asciz	"\n#include <stdio.h>\n#include <string.h>\nint main(int argc,char **argv) {\n NvmWebSocketHostPolicy policy={1,false,false,60000,NULL};\n for(int i=1;i<argc;i++) {\n  if(!strcmp(argv[i],\"--allow-websocket-connections\") && !policy.allow_connections)policy.allow_connections=true;\n  else if(!strcmp(argv[i],\"--allow-websocket-lookup\") && !policy.allow_lookup)policy.allow_lookup=true;\n  else if(!strcmp(argv[i],\"--websocket-resolver-helper\") && !policy.resolver_helper && i+1<argc)policy.resolver_helper=argv[++i];\n  else {fputs(\"I refuse an unknown or repeated WebSocket invocation option.\\n\",stderr);return 1;}\n }\n if(!policy.allow_connections){fputs(\"I require --allow-websocket-connections for this invocation.\\n\",stderr);return 1;}\n if(policy.allow_lookup!=(policy.resolver_helper!=NULL)){fputs(\"I require separate lookup permission and an absolute resolver helper together.\\n\",stderr);return 1;}\n NvmWebSocketHostGrant *grant=NULL;\n if(nvm_websocket_host_grant_create(&policy,&grant)!=NVM_WEBSOCKET_HOST_OK)return 1;\n NvmWebSocketIndirectOptions options={1,NVM_WEBSOCKET_INDIRECT_FUEL_MAX};NvmWebSocketScalar scalar={0};\n NvmWebSocketIndirectExecutionReport result=nvm_websocket_indirect_program_product(grant,&options,&scalar);\n NvmWebSocketHostStatus revoked=nvm_websocket_host_grant_revoke(grant);\n NvmWebSocketHostStatus destroyed=nvm_websocket_host_grant_destroy(&grant);\n if(result.runtime.status!=NVM_WEBSOCKET_RUNTIME_OK || !result.runtime.acquired || result.runtime.cleanup.cleanup_failures || revoked!=NVM_WEBSOCKET_HOST_OK || destroyed!=NVM_WEBSOCKET_HOST_OK || grant)return 1;\n return (int)((uint64_t)scalar.value&255u);\n}\n"

_socket_launcher:                       ; @socket_launcher
	.asciz	"\n#include <stdio.h>\nint main(int argc,char **argv) {\n if(argc!=2 || strcmp(argv[1],\"--allow-tcp-connections\")) {\n  fputs(\"I require --allow-tcp-connections for this invocation.\\n\",stderr); return 1; }\n NvmSocketHostGrant *grant=NULL;\n if(nvm_socket_host_grant_create_tcp_connections(&grant)!=NVM_SOCKET_HOST_OK)return 1;\n NvmSocketIndirectOptions options={NVM_SOCKET_INDIRECT_RUNTIME_REVISION,NVM_SOCKET_INDIRECT_FUEL_MAX};\n NvmSocketScalar scalar={0};\n NvmSocketIndirectExecutionReport result=nvm_socket_indirect_program_product(grant,&options,&scalar);\n NvmSocketHostStatus revoked=nvm_socket_host_grant_revoke(grant);\n NvmSocketHostStatus destroyed=nvm_socket_host_grant_destroy(&grant);\n if(result.runtime.status!=NVM_SOCKET_RUNTIME_OK || !result.runtime.acquired ||\n result.runtime.cleanup.cleanup_failures || revoked!=NVM_SOCKET_HOST_OK || destroyed!=NVM_SOCKET_HOST_OK)return 1;\n return (int)((uint64_t)scalar.value & 255u);\n}\n"

_launcher:                              ; @launcher
	.asciz	"\n#include <stdio.h>\nint main(int argc,char **argv) {\n if(argc!=2 || strcmp(argv[1],\"--allow-temporary-files\")) {\n  fputs(\"I require --allow-temporary-files for this invocation.\\n\",stderr); return 1; }\n NvmFileHostGrant *grant=NULL;\n if(nvm_file_host_grant_create_temporary_files(&grant)!=NVM_FILE_HOST_OK)return 1;\n NvmFileIndirectOptions options={NVM_FILE_INDIRECT_RUNTIME_REVISION,NVM_FILE_INDIRECT_FUEL_MAX};\n NvmFileScalar scalar={0};\n NvmFileIndirectExecutionReport result=nvm_file_indirect_program_product(grant,&options,&scalar);\n NvmFileHostStatus revoked=nvm_file_host_grant_revoke(grant);\n NvmFileHostStatus destroyed=nvm_file_host_grant_destroy(&grant);\n if(result.runtime.status!=NVM_FILE_RUNTIME_OK || !result.runtime.acquired ||\n result.runtime.cleanup.cleanup_failures || revoked!=NVM_FILE_HOST_OK || destroyed!=NVM_FILE_HOST_OK)return 1;\n return (int)((uint64_t)scalar.value & 255u);\n}\n"

	.section	__TEXT,__cstring,cstring_literals
l_.str.32:                              ; @.str.32
	.asciz	"LDFLAGS"

l_.str.33:                              ; @.str.33
	.asciz	"cc"

l_.str.34:                              ; @.str.34
	.asciz	"-std=c11"

l_.str.35:                              ; @.str.35
	.asciz	"-O1"

l_.str.36:                              ; @.str.36
	.asciz	"-I"

l_.str.37:                              ; @.str.37
	.asciz	"-lm"

l_.str.38:                              ; @.str.38
	.asciz	"$(pkg-config --libs libcrypto)"

l_.str.39:                              ; @.str.39
	.space	1

l_.str.40:                              ; @.str.40
	.asciz	"-o"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.nl_service_publish.execution.43
l___const.nl_service_publish.execution.43:
	.long	1                               ; 0x1
	.space	4
	.quad	1000000                         ; 0xf4240

	.section	__TEXT,__cstring,cstring_literals
l_.str.44:                              ; @.str.44
	.asciz	"I could not clean private service staging.\n"

l_.str.45:                              ; @.str.45
	.asciz	"I could not remove provisional service output.\n"

l_.str.46:                              ; @.str.46
	.asciz	"%s/%s"

l_.str.47:                              ; @.str.47
	.asciz	"%s%u"

l_.str.48:                              ; @.str.48
	.asciz	","

	.section	__TEXT,__const
_write_mixed_launcher.prefix:           ; @write_mixed_launcher.prefix
	.asciz	"\n#include <stdio.h>\nstatic const unsigned product_catalogs[]={"

_write_mixed_launcher.suffix:           ; @write_mixed_launcher.suffix
	.asciz	"};\nint main(int argc,char **argv) {\n bool files=false,tcp=false,websocket=false,lookup=false;const char *helper=NULL;\n for(int i=1;i<argc;i++) {\n  if(!strcmp(argv[i],\"--allow-temporary-files\") && !files)files=true;\n  else if(!strcmp(argv[i],\"--allow-tcp-connections\") && !tcp)tcp=true;\n  else if(!strcmp(argv[i],\"--allow-websocket-connections\") && !websocket)websocket=true;\n  else if(!strcmp(argv[i],\"--allow-websocket-lookup\") && !lookup)lookup=true;\n  else if(!strcmp(argv[i],\"--websocket-resolver-helper\") && !helper && i+1<argc)helper=argv[++i];\n  else return 1;\n }\n if(lookup!=(helper!=NULL) || (helper && (helper[0]!='/' || strlen(helper)>=4096)))return 1;\n NvmServicesHostConfig policies[sizeof product_catalogs/sizeof product_catalogs[0]];\n for(size_t i=0;i<sizeof policies/sizeof policies[0];i++) {\n  unsigned catalog=product_catalogs[i];\n  bool allowed=catalog==1?files:catalog==2?tcp:websocket;\n  if(!allowed){fprintf(stderr,\"I require %s for this invocation.\\n\",catalog==1?\"--allow-temporary-files\":catalog==2?\"--allow-tcp-connections\":\"--allow-websocket-connections\");return 1;}\n  policies[i]=(NvmServicesHostConfig){NVM_SERVICES_HOST_POLICY_REVISION,(NvmServicesHostCatalog)catalog,allowed,catalog==3&&lookup,catalog==3?60000u:0u,catalog==3?helper:NULL};\n }\n NvmServicesHostGrant *grant=NULL;\n if(nvm_services_host_grant_create_config(policies,sizeof policies/sizeof policies[0],&grant)!=NVM_SERVICES_HOST_OK)return 1;\n NvmServicesIndirectOptions options={1,NVM_SERVICES_INDIRECT_FUEL_MAX};NvmServicesScalar scalar={0};\n NvmServicesIndirectExecutionReport result=nvm_services_indirect_program_product(grant,&options,&scalar);\n NvmServicesHostStatus revoked=nvm_services_host_grant_revoke(grant);\n NvmServicesHostStatus destroyed=nvm_services_host_grant_destroy(&grant);\n if(result.runtime.status!=NVM_SERVICES_RUNTIME_OK || !result.runtime.acquired || result.runtime.cleanup.cleanup_failures || revoked!=NVM_SERVICES_HOST_OK || destroyed!=NVM_SERVICES_HOST_OK || grant)return 1;\n return (int)((uint64_t)scalar.value&255u);\n}\n"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.compile_native.pause
l___const.compile_native.pause:
	.quad	0                               ; 0x0
	.quad	10000000                        ; 0x989680

	.section	__TEXT,__cstring,cstring_literals
l_.str.50:                              ; @.str.50
	.asciz	"/bin/sh"

l_.str.51:                              ; @.str.51
	.asciz	"sh"

l_.str.52:                              ; @.str.52
	.asciz	"-c"

.subsections_via_symbols
