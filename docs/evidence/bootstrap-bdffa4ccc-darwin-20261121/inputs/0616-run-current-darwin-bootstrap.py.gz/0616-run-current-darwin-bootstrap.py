
from pathlib import Path
import os,sys,subprocess,time,json,signal,hashlib,traceback
root=Path.cwd();out=root/'.test_output/current-darwin-bootstrap';env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CC='/usr/bin/cc',NANOLANG_ROOT=str(root),NANO_MODULE_PATH=str(root/'modules'),NANO_BUILD_CACHE=str(out/'module-cache'))
for key in ['NANO_CC','NANO_NVM2C','NANO_VM','NANO_AS_CAPTURE_HELPER','NANO_CFLAGS','NANO_LDFLAGS','NANO_SHADOW_TIMEOUT_SECONDS','NANOLANG_SELFHOST_COMPILER']:env.pop(key,None)
record=dict(pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),cc=subprocess.check_output(['/usr/bin/cc','--version'],text=True),system=subprocess.check_output(['uname','-a'],text=True),steps=[],limits=['I build a fresh isolated Darwin checkout at the recorded source pin using actual source-built tools. My original generation/compiler-shadow budgets remain1800/30. I preserve all earlier Darwin trees/artifacts and claim no completion until the original commands, raw equality and guards pass.'])
def save():(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,timeout):
 t=time.monotonic();s=dict(label=label,argv=args);record['steps'].append(s);save()
 with (out/(label+'.stdout')).open('wb') as a,(out/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True);s['pid']=p.pid;save()
  try:s['returncode']=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:s['driver_timeout']=True;os.killpg(p.pid,signal.SIGKILL);s['returncode']=p.wait()
 s['elapsed_seconds']=time.monotonic()-t;save();assert s['returncode']==0,s
try:
 run('original-vm-heap-controls',['make','CC=/usr/bin/cc','test-nanovm','test-vm-heap-allocation-sanitizers','test-record-map-heap','test-record-map-ordinary-heap','test-record-map-string-heap'],7200)
 run('original-bootstrap3',['make','CC=/usr/bin/cc','BOOTSTRAP_NANOISA_TIMEOUT=1800','bootstrap3'],14400)
 sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap,digest
 b=Bootstrap(root,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert (root/'bin/nanoc_stage1.nvm').read_bytes()==(root/'bin/nanoc_stage2.nvm').read_bytes();assert all(b.imports(root/'bin'/('nanoc_'+name+'.nvm'))==b.manifest['hosts'] for name in ['seed','stage1','stage2']);record.update(bootstrap_guards_unchanged=True,raw_equal=True,work=str(b.work),receipt_sha256=digest(root/'bin/nanoc_bootstrap.json'),artifacts=b.manifest['artifacts'],status='passed');save()
except BaseException as e:
 record['status']='failed';record['error']=repr(e);save();traceback.print_exc();sys.exit(1)
