	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_affine_value_call_graph    ; -- Begin function nvm_affine_value_call_graph
	.p2align	2
_nvm_affine_value_call_graph:           ; @nvm_affine_value_call_graph
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #544
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #136]
	ldr	x8, [sp, #136]
	cbz	x8, LBB0_5
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #136]
	ldr	x8, [x8, #256]
	cbz	x8, LBB0_5
	b	LBB0_2
LBB0_2:
	ldr	x8, [sp, #136]
	ldr	w8, [x8, #272]
	cbz	w8, LBB0_5
	b	LBB0_3
LBB0_3:
	ldr	x8, [sp, #136]
	ldr	w8, [x8, #272]
	subs	w8, w8, #8
	b.hi	LBB0_5
	b	LBB0_4
LBB0_4:
	ldr	x8, [sp, #136]
	ldr	w8, [x8, #12]
	cbz	w8, LBB0_6
	b	LBB0_5
LBB0_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_6:
	sub	x0, x29, #88
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	str	wzr, [sp, #132]
	b	LBB0_7
LBB0_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_29 Depth 2
	ldr	w8, [sp, #132]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB0_51
	b	LBB0_8
LBB0_8:                                 ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #136]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #132]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #120]
	ldr	w8, [sp, #132]
	cbnz	w8, LBB0_14
	b	LBB0_9
LBB0_9:                                 ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #4]
	cbnz	w8, LBB0_17
	b	LBB0_10
LBB0_10:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.ne	LBB0_17
	b	LBB0_11
LBB0_11:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #1
	b.eq	LBB0_14
	b	LBB0_12
LBB0_12:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #4
	b.eq	LBB0_14
	b	LBB0_13
LBB0_13:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #2
	b.ne	LBB0_17
	b	LBB0_14
LBB0_14:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB0_17
	b	LBB0_15
LBB0_15:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.hi	LBB0_17
	b	LBB0_16
LBB0_16:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x8, [sp, #120]
	ldr	w8, [x8, #12]
	subs	w8, w8, #32, lsl #12            ; =131072
	b.ls	LBB0_18
	b	LBB0_17
LBB0_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_18:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x0, [sp, #136]
	ldr	w1, [sp, #132]
	ldr	x8, [sp, #120]
	ldrh	w2, [x8, #16]
	bl	_nvm_affine_state_create
	str	x0, [sp, #112]
	add	x3, sp, #102
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	strh	wzr, [sp, #102]
	strh	wzr, [sp, #100]
	ldr	x0, [sp, #112]
	sub	x1, x29, #152
	mov	w2, #8                          ; =0x8
	bl	_nvm_affine_value_parameters
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB0_21
	b	LBB0_19
LBB0_19:                                ;   in Loop: Header=BB0_7 Depth=1
	ldrh	w8, [sp, #102]
	ldr	x9, [sp, #120]
	ldrh	w9, [x9, #4]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b.ne	LBB0_21
	b	LBB0_20
LBB0_20:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	x0, [sp, #112]
	add	x1, sp, #104
	add	x2, sp, #100
	bl	_nvm_affine_value_result
	str	w0, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB0_21
LBB0_21:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #99]
	ldr	x0, [sp, #112]
	bl	_nvm_affine_state_free
	ldrb	w8, [sp, #99]
	tbnz	w8, #0, LBB0_23
	b	LBB0_22
LBB0_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_23:                                ;   in Loop: Header=BB0_7 Depth=1
	movi.2d	v0, #0000000000000000
	add	x2, sp, #64
	str	q0, [sp, #64]
	str	q0, [sp, #80]
	ldr	x0, [sp, #136]
	ldr	w1, [sp, #132]
	add	x3, sp, #152
	bl	_vm_decode_function
	tbnz	w0, #0, LBB0_25
	b	LBB0_24
LBB0_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_25:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	w8, [sp, #72]
	cbz	w8, LBB0_27
	b	LBB0_26
LBB0_26:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	w8, [sp, #72]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ls	LBB0_28
	b	LBB0_27
LBB0_27:                                ;   in Loop: Header=BB0_7 Depth=1
	strb	wzr, [sp, #99]
	b	LBB0_28
LBB0_28:                                ;   in Loop: Header=BB0_7 Depth=1
	str	wzr, [sp, #60]
	b	LBB0_29
LBB0_29:                                ;   Parent Loop BB0_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w9, [sp, #60]
	ldr	w10, [sp, #72]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.hs	LBB0_31
	b	LBB0_30
LBB0_30:                                ;   in Loop: Header=BB0_29 Depth=2
	ldrb	w8, [sp, #99]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB0_31
LBB0_31:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB0_47
	b	LBB0_32
LBB0_32:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x10, [sp, #64]
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #40
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #59
	b.ne	LBB0_38
	b	LBB0_33
LBB0_33:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
	str	w8, [sp, #44]
	ldr	w8, [sp, #44]
	cbz	w8, LBB0_35
	b	LBB0_34
LBB0_34:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB0_36
	b	LBB0_35
LBB0_35:                                ;   in Loop: Header=BB0_29 Depth=2
	strb	wzr, [sp, #99]
	b	LBB0_37
LBB0_36:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #132]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9, lsl #3
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB0_37
LBB0_37:                                ;   in Loop: Header=BB0_29 Depth=2
	b	LBB0_45
LBB0_38:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #15
	b.eq	LBB0_43
	b	LBB0_39
LBB0_39:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #51
	b.eq	LBB0_43
	b	LBB0_40
LBB0_40:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #60
	b.eq	LBB0_43
	b	LBB0_41
LBB0_41:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #63
	b.eq	LBB0_43
	b	LBB0_42
LBB0_42:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	x8, [sp, #48]
	ldrb	w8, [x8]
	subs	w8, w8, #62
	b.ne	LBB0_44
	b	LBB0_43
LBB0_43:                                ;   in Loop: Header=BB0_29 Depth=2
	strb	wzr, [sp, #99]
	b	LBB0_44
LBB0_44:                                ;   in Loop: Header=BB0_29 Depth=2
	b	LBB0_45
LBB0_45:                                ;   in Loop: Header=BB0_29 Depth=2
	b	LBB0_46
LBB0_46:                                ;   in Loop: Header=BB0_29 Depth=2
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB0_29
LBB0_47:                                ;   in Loop: Header=BB0_7 Depth=1
	add	x0, sp, #64
	bl	_vm_decoded_function_free
	ldrb	w8, [sp, #99]
	tbnz	w8, #0, LBB0_49
	b	LBB0_48
LBB0_48:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_49:                                ;   in Loop: Header=BB0_7 Depth=1
	b	LBB0_50
LBB0_50:                                ;   in Loop: Header=BB0_7 Depth=1
	ldr	w8, [sp, #132]
	add	w8, w8, #1
	str	w8, [sp, #132]
	b	LBB0_7
LBB0_51:
	str	wzr, [sp, #40]
	b	LBB0_52
LBB0_52:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_54 Depth 2
                                        ;       Child Loop BB0_56 Depth 3
	ldr	w8, [sp, #40]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB0_67
	b	LBB0_53
LBB0_53:                                ;   in Loop: Header=BB0_52 Depth=1
	str	wzr, [sp, #36]
	b	LBB0_54
LBB0_54:                                ;   Parent Loop BB0_52 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_56 Depth 3
	ldr	w8, [sp, #36]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB0_65
	b	LBB0_55
LBB0_55:                                ;   in Loop: Header=BB0_54 Depth=2
	str	wzr, [sp, #32]
	b	LBB0_56
LBB0_56:                                ;   Parent Loop BB0_52 Depth=1
                                        ;     Parent Loop BB0_54 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [sp, #32]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB0_63
	b	LBB0_57
LBB0_57:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #36]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9, lsl #3
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB0_61
	b	LBB0_58
LBB0_58:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #36]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9, lsl #3
	ldr	w9, [sp, #40]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB0_60
	b	LBB0_59
LBB0_59:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #40]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9, lsl #3
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB0_60
LBB0_60:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_61
LBB0_61:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #36]
	mov	x10, x9
	sub	x9, x29, #88
	add	x9, x9, x10, lsl #3
	ldr	w10, [sp, #32]
                                        ; kill: def $x10 killed $w10
	and	w8, w8, #0x1
	strb	w8, [x9, x10]
	b	LBB0_62
LBB0_62:                                ;   in Loop: Header=BB0_56 Depth=3
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB0_56
LBB0_63:                                ;   in Loop: Header=BB0_54 Depth=2
	b	LBB0_64
LBB0_64:                                ;   in Loop: Header=BB0_54 Depth=2
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB0_54
LBB0_65:                                ;   in Loop: Header=BB0_52 Depth=1
	b	LBB0_66
LBB0_66:                                ;   in Loop: Header=BB0_52 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB0_52
LBB0_67:
	str	wzr, [sp, #28]
	b	LBB0_68
LBB0_68:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldr	x9, [sp, #136]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB0_73
	b	LBB0_69
LBB0_69:                                ;   in Loop: Header=BB0_68 Depth=1
	ldr	w8, [sp, #28]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9, lsl #3
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB0_71
	b	LBB0_70
LBB0_70:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_71:                                ;   in Loop: Header=BB0_68 Depth=1
	b	LBB0_72
LBB0_72:                                ;   in Loop: Header=BB0_68 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB0_68
LBB0_73:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #151]
	b	LBB0_74
LBB0_74:
	ldrb	w8, [sp, #151]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_76
	b	LBB0_75
LBB0_75:
	bl	___stack_chk_fail
LBB0_76:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #544
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_analyze_function    ; -- Begin function nvm_affine_analyze_function
	.p2align	2
_nvm_affine_analyze_function:           ; @nvm_affine_analyze_function
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #16304                      ; =0x3fb0
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #4016
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #32]
	str	w1, [sp, #28]
	add	x0, sp, #248
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x1, #16048                      ; =0x3eb0
	bl	_bzero
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]
	bl	_analysis_calls_init
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #32]
	ldr	w1, [sp, #28]
	add	x8, sp, #40
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_analyze
	ldrb	w8, [sp, #40]
	tbz	w8, #0, LBB1_5
	b	LBB1_1
LBB1_1:
	ldrb	w8, [sp, #250]
	tbz	w8, #0, LBB1_5
	b	LBB1_2
LBB1_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp, #32]
	add	x1, sp, #248
	bl	_effect_global_proof
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB1_4
	b	LBB1_3
LBB1_3:
	b	LBB1_6
LBB1_4:
	b	LBB1_5
LBB1_5:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, sp, #40
	mov	x2, #208                        ; =0xd0
	bl	_memcpy
	b	LBB1_6
LBB1_6:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB1_8
	b	LBB1_7
LBB1_7:
	bl	___stack_chk_fail
LBB1_8:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #4016
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function analysis_calls_init
_analysis_calls_init:                   ; @analysis_calls_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #64]
	str	x1, [sp, #56]
	ldr	x0, [sp, #56]
	ldr	x9, [sp, #64]
	ldr	x8, [sp, #64]
	add	x1, x9, #8
	mov	w2, #256                        ; =0x100
	add	x3, x8, #4
	bl	_nvm_ownership_globals
	subs	w8, w0, #0
	cset	w8, eq
	ldr	x9, [sp, #64]
	strb	w8, [x9, #1]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #1]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB2_2
	b	LBB2_1
LBB2_1:
	ldr	x0, [sp, #56]
	bl	_nvm_affine_value_call_graph
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB2_2
LBB2_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x9, [sp, #64]
	mov	w10, #1                         ; =0x1
	and	w8, w8, w10
	strb	w8, [x9]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB2_20
	b	LBB2_3
LBB2_3:
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #4]
	cbz	w8, LBB2_20
	b	LBB2_4
LBB2_4:
	str	wzr, [sp, #52]
	b	LBB2_5
LBB2_5:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_9 Depth 2
	ldr	w8, [sp, #52]
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB2_19
	b	LBB2_6
LBB2_6:                                 ;   in Loop: Header=BB2_5 Depth=1
	movi.2d	v0, #0000000000000000
	add	x2, sp, #16
	str	q0, [sp, #16]
	str	q0, [sp, #32]
	ldr	x0, [sp, #56]
	ldr	w1, [sp, #52]
	add	x3, sp, #72
	bl	_vm_decode_function
	tbnz	w0, #0, LBB2_8
	b	LBB2_7
LBB2_7:
	ldr	x8, [sp, #64]
	strb	wzr, [x8, #1]
	b	LBB2_20
LBB2_8:                                 ;   in Loop: Header=BB2_5 Depth=1
	str	wzr, [sp, #12]
	b	LBB2_9
LBB2_9:                                 ;   Parent Loop BB2_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #12]
	ldr	w9, [sp, #24]
	subs	w8, w8, w9
	b.hs	LBB2_17
	b	LBB2_10
LBB2_10:                                ;   in Loop: Header=BB2_9 Depth=2
	ldr	x10, [sp, #16]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #40]
	strb	w8, [sp, #11]
	ldrb	w8, [sp, #11]
	subs	w8, w8, #165
	b.eq	LBB2_14
	b	LBB2_11
LBB2_11:                                ;   in Loop: Header=BB2_9 Depth=2
	ldrb	w8, [sp, #11]
	subs	w8, w8, #166
	b.eq	LBB2_14
	b	LBB2_12
LBB2_12:                                ;   in Loop: Header=BB2_9 Depth=2
	ldrb	w8, [sp, #11]
	subs	w8, w8, #167
	b.eq	LBB2_14
	b	LBB2_13
LBB2_13:                                ;   in Loop: Header=BB2_9 Depth=2
	ldrb	w8, [sp, #11]
	subs	w8, w8, #168
	b.ne	LBB2_15
	b	LBB2_14
LBB2_14:                                ;   in Loop: Header=BB2_9 Depth=2
	ldr	x9, [sp, #64]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2]
	b	LBB2_15
LBB2_15:                                ;   in Loop: Header=BB2_9 Depth=2
	b	LBB2_16
LBB2_16:                                ;   in Loop: Header=BB2_9 Depth=2
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB2_9
LBB2_17:                                ;   in Loop: Header=BB2_5 Depth=1
	add	x0, sp, #16
	bl	_vm_decoded_function_free
	b	LBB2_18
LBB2_18:                                ;   in Loop: Header=BB2_5 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB2_5
LBB2_19:
	b	LBB2_20
LBB2_20:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB2_22
	b	LBB2_21
LBB2_21:
	bl	___stack_chk_fail
LBB2_22:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function analyze
_analyze:                               ; @analyze
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #5104                       ; =0x13f0
Lloh2:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh3:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1008
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x9, x29, #232
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	add	x9, sp, #224
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
	mov	x5, x8
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x5, [sp, #72]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #2352]
	str	w1, [sp, #2572]
	str	x2, [x8, #2336]
	str	w3, [sp, #2556]
	str	x4, [x8, #2320]
	sub	x0, x29, #232
	mov	x2, #208                        ; =0xd0
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x9, l_.str.2@PAGE
	add	x9, x9, l_.str.2@PAGEOFF
	str	x9, [x8, #2312]
	movi.2d	v0, #0000000000000000
	str	q0, [x8, #2272]
	str	q0, [x8, #2288]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #2264]
	movi.2d	v0, #0000000000000000
	str	q0, [x8, #2224]
	str	q0, [x8, #2240]
	str	xzr, [x8, #2216]
	ldr	x8, [x8, #2352]
	cbz	x8, LBB3_4
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2352]
	ldr	x8, [x8, #256]
	cbz	x8, LBB3_4
	b	LBB3_2
LBB3_2:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #2572]
	ldr	x9, [x9, #2352]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB3_4
	b	LBB3_3
LBB3_3:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB3_5
	b	LBB3_4
LBB3_4:
	b	LBB3_223
LBB3_5:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldr	w8, [x8, #4]
	cbz	w8, LBB3_8
	b	LBB3_6
LBB3_6:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB3_8
	b	LBB3_7
LBB3_7:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.3@PAGE
	add	x8, x8, l_.str.3@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_8:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB3_15
	b	LBB3_9
LBB3_9:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2336]
	cbnz	x8, LBB3_15
	b	LBB3_10
LBB3_10:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	mov	x9, #6168                       ; =0x1818
	add	x8, x8, x9
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #2
	b.ne	LBB3_12
	b	LBB3_11
LBB3_11:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	mov	x9, #6176                       ; =0x1820
	add	x10, x8, x9
	ldr	w8, [sp, #2572]
                                        ; kill: def $x8 killed $w8
	mov	x9, #208                        ; =0xd0
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #208                        ; =0xd0
	bl	_memcpy
	b	LBB3_236
LBB3_12:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	mov	x9, #6168                       ; =0x1818
	add	x8, x8, x9
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #1
	b.ne	LBB3_14
	b	LBB3_13
LBB3_13:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.4@PAGE
	add	x8, x8, l_.str.4@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_14:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2320]
	mov	x10, #6168                      ; =0x1818
	add	x9, x9, x10
	ldr	w10, [sp, #2572]
                                        ; kill: def $x10 killed $w10
	add	x10, x9, x10
	mov	w9, #1                          ; =0x1
	strb	w9, [x10]
	ldr	x9, [x8, #2320]
	add	x9, x9, #2056
	ldr	w10, [sp, #2572]
                                        ; kill: def $x10 killed $w10
	add	x0, x9, x10, lsl #8
	ldr	x8, [x8, #2320]
	ldr	w8, [x8, #4]
	mov	x2, x8
	mov	w1, #3                          ; =0x3
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB3_15
LBB3_15:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2352]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [x8, #2208]
	ldr	x8, [x8, #2208]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.hi	LBB3_17
	b	LBB3_16
LBB3_16:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2208]
	ldr	w8, [x8, #12]
	subs	w8, w8, #32, lsl #12            ; =131072
	b.ls	LBB3_18
	b	LBB3_17
LBB3_17:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_18:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2352]
	ldr	w1, [sp, #2572]
	ldr	x8, [x8, #2208]
	ldrh	w2, [x8, #16]
	bl	_nvm_affine_state_create
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2200]
	ldr	x8, [x8, #2200]
	cbnz	x8, LBB3_20
	b	LBB3_19
LBB3_19:
	b	LBB3_223
LBB3_20:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2336]
	cbz	x8, LBB3_23
	b	LBB3_21
LBB3_21:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	ldr	x1, [x8, #2336]
	ldr	w2, [sp, #2556]
	bl	_nvm_affine_bind_caller
	tbnz	w0, #0, LBB3_23
	b	LBB3_22
LBB3_22:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_23:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2352]
	ldr	w1, [sp, #2572]
	add	x2, sp, #2496
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #536
	bl	_vm_decode_function
	tbnz	w0, #0, LBB3_25
	b	LBB3_24
LBB3_24:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.7@PAGE
	add	x8, x8, l_.str.7@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_25:
	ldr	w8, [sp, #2504]
	str	w8, [sp, #2420]
	ldr	w8, [sp, #2420]
	cbz	w8, LBB3_27
	b	LBB3_26
LBB3_26:
	ldr	w8, [sp, #2420]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ls	LBB3_28
	b	LBB3_27
LBB3_27:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.8@PAGE
	add	x8, x8, l_.str.8@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_28:
	str	wzr, [sp, #2416]
	b	LBB3_29
LBB3_29:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #2416]
	ldr	w9, [sp, #2420]
	subs	w8, w8, w9
	b.hs	LBB3_39
	b	LBB3_30
LBB3_30:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x11, [x8, #2272]
	ldr	w9, [sp, #2416]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w0, [x9, #40]
	ldr	x8, [x8, #2320]
	ldrb	w8, [x8]
	and	w1, w8, #0x1
	bl	_supported
	tbnz	w0, #0, LBB3_37
	b	LBB3_31
LBB3_31:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2272]
	ldr	w10, [sp, #2416]
	mov	x11, x10
	mov	x10, #104                       ; =0x68
	mov	x12, x10
                                        ; kill: def $w11 killed $w11 killed $x11
	umull	x11, w11, w12
	ldr	w9, [x9, x11]
	stur	w9, [x29, #-228]
	ldr	x11, [x8, #2272]
	ldr	w9, [sp, #2416]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #40]
	strb	w9, [sp, #2415]
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldrb	w8, [sp, #2415]
	subs	w8, w8, #4
	b.ne	LBB3_33
	b	LBB3_32
LBB3_32:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB3_36
LBB3_33:
	ldrb	w9, [sp, #2415]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #160
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB3_35
	b	LBB3_34
LBB3_34:
	ldrb	w8, [sp, #2415]
	subs	w8, w8, #164
	cset	w8, eq
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB3_35
LBB3_35:
	ldr	w10, [sp, #52]                  ; 4-byte Folded Reload
	adrp	x9, l_.str.11@PAGE
	add	x9, x9, l_.str.11@PAGEOFF
	adrp	x8, l_.str.10@PAGE
	add	x8, x8, l_.str.10@PAGEOFF
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB3_36
LBB3_36:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_37:                                ;   in Loop: Header=BB3_29 Depth=1
	b	LBB3_38
LBB3_38:                                ;   in Loop: Header=BB3_29 Depth=1
	ldr	w8, [sp, #2416]
	add	w8, w8, #1
	str	w8, [sp, #2416]
	b	LBB3_29
LBB3_39:
	str	wzr, [sp, #2408]
	b	LBB3_40
LBB3_40:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_50 Depth 2
	ldr	w8, [sp, #2408]
	ldr	w9, [sp, #2420]
	subs	w8, w8, w9
	b.hs	LBB3_64
	b	LBB3_41
LBB3_41:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x11, [x8, #2272]
	ldr	w9, [sp, #2408]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x9, x9, #40
	str	x9, [x8, #2176]
	ldr	x8, [x8, #2176]
	ldrb	w8, [x8]
	subs	w8, w8, #165
	b.eq	LBB3_43
	b	LBB3_42
LBB3_42:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2176]
	ldrb	w8, [x8]
	subs	w8, w8, #167
	b.ne	LBB3_58
	b	LBB3_43
LBB3_43:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2176]
	add	x9, x9, #8
	ldr	x10, [x8, #2176]
	ldrb	w11, [x10]
	mov	w10, #3                         ; =0x3
	subs	w11, w11, #165
	csinc	w10, w10, wzr, eq
	add	x9, x9, w10, sxtw #3
	ldrh	w9, [x9]
	strh	w9, [sp, #334]
	ldr	x0, [x8, #2352]
	ldr	x8, [x8, #2176]
	ldr	w1, [x8, #8]
	add	x2, sp, #336
	bl	_nvm_ownership_effect
	cbnz	w0, LBB3_45
	b	LBB3_44
LBB3_44:                                ;   in Loop: Header=BB3_40 Depth=1
	ldrh	w8, [sp, #334]
	ldrh	w9, [sp, #340]
	subs	w8, w8, w9
	b.eq	LBB3_46
	b	LBB3_45
LBB3_45:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.12@PAGE
	add	x8, x8, l_.str.12@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_46:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2176]
	ldrb	w8, [x8]
	subs	w8, w8, #165
	b.ne	LBB3_57
	b	LBB3_47
LBB3_47:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #2176]
	ldrh	w8, [x8, #24]
	strh	w8, [sp, #332]
	ldrh	w8, [sp, #332]
	ldrh	w10, [sp, #334]
	add	w8, w8, w10
	ldr	x9, [x9, #2208]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ls	LBB3_49
	b	LBB3_48
LBB3_48:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.13@PAGE
	add	x8, x8, l_.str.13@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_49:                                ;   in Loop: Header=BB3_40 Depth=1
	strh	wzr, [sp, #330]
	b	LBB3_50
LBB3_50:                                ;   Parent Loop BB3_40 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #330]
	ldrh	w9, [sp, #334]
	subs	w8, w8, w9
	b.ge	LBB3_56
	b	LBB3_51
LBB3_51:                                ;   in Loop: Header=BB3_50 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	ldrh	w8, [sp, #332]
	ldrh	w9, [sp, #330]
	add	w8, w8, w9
	and	w1, w8, #0xffff
	add	x2, sp, #320
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB3_53
	b	LBB3_52
LBB3_52:                                ;   in Loop: Header=BB3_50 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	add	x9, sp, #336
	add	x10, x9, #16
	ldrh	w11, [sp, #330]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11, lsl #3
	ldrb	w11, [x10]
	add	x10, sp, #312
	strb	w11, [sp, #312]
	add	x10, x10, #1
	strh	wzr, [x10]
	strb	wzr, [sp, #315]
	add	x9, x9, #16
	ldrh	w10, [sp, #330]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	str	w9, [sp, #316]
	ldr	x1, [x8, #96]
	ldr	x2, [x8, #88]
	bl	_nvm_affine_types_equal
	tbnz	w0, #0, LBB3_54
	b	LBB3_53
LBB3_53:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.14@PAGE
	add	x8, x8, l_.str.14@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_54:                                ;   in Loop: Header=BB3_50 Depth=2
	b	LBB3_55
LBB3_55:                                ;   in Loop: Header=BB3_50 Depth=2
	ldrh	w8, [sp, #330]
	add	w8, w8, #1
	strh	w8, [sp, #330]
	b	LBB3_50
LBB3_56:                                ;   in Loop: Header=BB3_40 Depth=1
	b	LBB3_57
LBB3_57:                                ;   in Loop: Header=BB3_40 Depth=1
	b	LBB3_58
LBB3_58:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2176]
	ldrb	w8, [x8]
	subs	w8, w8, #18
	b.eq	LBB3_60
	b	LBB3_59
LBB3_59:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2176]
	ldrb	w8, [x8]
	subs	w8, w8, #19
	b.ne	LBB3_62
	b	LBB3_60
LBB3_60:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #2176]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB3_62
	b	LBB3_61
LBB3_61:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2272]
	ldr	w10, [sp, #2408]
                                        ; kill: def $x10 killed $w10
	mov	x11, #104                       ; =0x68
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	stur	w9, [x29, #-228]
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.15@PAGE
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_62:                                ;   in Loop: Header=BB3_40 Depth=1
	b	LBB3_63
LBB3_63:                                ;   in Loop: Header=BB3_40 Depth=1
	ldr	w8, [sp, #2408]
	add	w8, w8, #1
	str	w8, [sp, #2408]
	b	LBB3_40
LBB3_64:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldr	x8, [x8, #6160]
	cbz	x8, LBB3_69
	b	LBB3_65
LBB3_65:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2336]
	cbnz	x8, LBB3_69
	b	LBB3_66
LBB3_66:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #2572]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #6152]
	subs	w8, w8, w9
	b.ne	LBB3_69
	b	LBB3_67
LBB3_67:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #2420]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #6156]
	subs	w8, w8, w9
	b.eq	LBB3_69
	b	LBB3_68
LBB3_68:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.16@PAGE
	add	x8, x8, l_.str.16@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_69:
	ldr	w8, [sp, #2420]
	mov	x0, x8
	mov	x1, #8                          ; =0x8
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2264]
	ldr	w8, [sp, #2420]
	str	w8, [sp, #2464]
	ldr	w8, [sp, #2420]
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #2
	bl	_malloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2224]
	ldr	w8, [sp, #2420]
	mov	x0, x8
	mov	x1, #1                          ; =0x1
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2232]
	ldr	x8, [x8, #2264]
	cbz	x8, LBB3_72
	b	LBB3_70
LBB3_70:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2224]
	cbz	x8, LBB3_72
	b	LBB3_71
LBB3_71:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2232]
	cbnz	x8, LBB3_73
	b	LBB3_72
LBB3_72:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.17@PAGE
	add	x8, x8, l_.str.17@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_73:
	mov	x0, #1                          ; =0x1
	mov	x1, #800                        ; =0x320
	bl	_calloc
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2264]
	str	x0, [x9]
	ldr	x8, [x8, #2264]
	ldr	x8, [x8]
	cbnz	x8, LBB3_75
	b	LBB3_74
LBB3_74:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2200]
	bl	_nvm_affine_state_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.18@PAGE
	add	x8, x8, l_.str.18@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_75:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2200]
	ldr	x10, [x8, #2264]
	ldr	x10, [x10]
	str	x9, [x10]
	ldr	x9, [x8, #2320]
	ldr	w9, [x9, #4]
	ldr	x10, [x8, #2264]
	ldr	x10, [x10]
	strh	w9, [x10, #20]
	ldr	x9, [x8, #2264]
	ldr	x9, [x9]
	add	x0, x9, #22
	ldr	x8, [x8, #2320]
	ldr	w8, [x8, #4]
	mov	x2, x8
	mov	w1, #9                          ; =0x9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #2420]
	ldr	x9, [x10, #2208]
	ldrh	w11, [x9, #16]
	mov	w9, #2                          ; =0x2
	mul	w9, w9, w11
	ldr	x10, [x10, #2320]
	ldr	w11, [x10, #4]
	mov	w10, #4                         ; =0x4
	mul	w10, w10, w11
	add	w9, w9, w10
	add	w9, w9, #1
	mov	w10, #256                       ; =0x100
	movk	w10, #1, lsl #16
	add	w9, w9, w10
	mul	w8, w8, w9
	str	w8, [sp, #308]
	add	x0, sp, #2448
	mov	w1, #0                          ; =0x0
	bl	_enqueue
	tbnz	w0, #0, LBB3_77
	b	LBB3_76
LBB3_76:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.19@PAGE
	add	x8, x8, l_.str.19@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_77:
	b	LBB3_78
LBB3_78:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_159 Depth 2
                                        ;     Child Loop BB3_104 Depth 2
	ldr	w8, [sp, #2476]
	cbz	w8, LBB3_193
	b	LBB3_79
LBB3_79:                                ;   in Loop: Header=BB3_78 Depth=1
	ldur	w8, [x29, #-220]
	ldr	w9, [sp, #308]
	subs	w8, w8, w9
	b.lo	LBB3_81
	b	LBB3_80
LBB3_80:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.20@PAGE
	add	x8, x8, l_.str.20@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_81:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-220]
	add	w9, w9, #1
	stur	w9, [x29, #-220]
	ldr	x9, [x8, #2224]
	ldr	w10, [sp, #2468]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	str	w9, [sp, #304]
	ldr	w9, [sp, #2468]
	add	w9, w9, #1
	ldr	w11, [sp, #2464]
	udiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w9, w9, w10
	str	w9, [sp, #2468]
	ldr	w9, [sp, #2476]
	subs	w9, w9, #1
	str	w9, [sp, #2476]
	ldr	x9, [x8, #2232]
	ldr	w10, [sp, #304]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	wzr, [x9]
	ldr	x11, [x8, #2272]
	ldr	w9, [sp, #304]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [x8, #72]
	ldr	x9, [x8, #72]
	ldr	w9, [x9]
	stur	w9, [x29, #-228]
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #304]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, #18]
	tbnz	w8, #0, LBB3_83
	b	LBB3_82
LBB3_82:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #304]
                                        ; kill: def $x9 killed $w9
	ldr	x9, [x8, x9, lsl #3]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #18]
	ldur	w8, [x29, #-224]
	add	w8, w8, #1
	stur	w8, [x29, #-224]
	b	LBB3_83
LBB3_83:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #304]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_frame_clone
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2216]
	ldr	x8, [x8, #2216]
	cbnz	x8, LBB3_85
	b	LBB3_84
LBB3_84:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.21@PAGE
	add	x8, x8, l_.str.21@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_85:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #72]
	ldrb	w8, [x8, #40]
	strb	w8, [sp, #295]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #294]
	ldrb	w8, [sp, #295]
	subs	w8, w8, #61
	b.ne	LBB3_108
	b	LBB3_86
LBB3_86:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	strb	wzr, [sp, #293]
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB3_89
	b	LBB3_87
LBB3_87:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB3_89
	b	LBB3_88
LBB3_88:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	strb	w8, [sp, #293]
	b	LBB3_92
LBB3_89:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB3_91
	b	LBB3_90
LBB3_90:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.22@PAGE
	add	x8, x8, l_.str.22@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_91:                                ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_92
LBB3_92:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldrh	w9, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b.ne	LBB3_98
	b	LBB3_93
LBB3_93:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #4]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #44]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB3_97
	b	LBB3_94
LBB3_94:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #10
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB3_97
	b	LBB3_95
LBB3_95:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #8
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB3_97
	b	LBB3_96
LBB3_96:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	cset	w8, eq
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB3_97
LBB3_97:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB3_98
LBB3_98:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #292]
	ldrb	w8, [sp, #292]
	tbz	w8, #0, LBB3_100
	b	LBB3_99
LBB3_99:                                ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2216]
	ldr	x0, [x9]
	ldrb	w10, [sp, #293]
	add	x9, sp, #280
	strb	w10, [sp, #280]
	add	x9, x9, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #283]
	ldr	x9, [x8, #2216]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #8]
	str	w9, [sp, #284]
	ldr	x1, [x8, #56]
	bl	_nvm_affine_can_exit_type
	str	w0, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB3_101
LBB3_100:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x0, [x8]
	ldrb	w1, [sp, #293]
	bl	_nvm_affine_can_exit_scalar
	str	w0, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB3_101
LBB3_101:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #291]
	ldrb	w8, [sp, #291]
	tbnz	w8, #0, LBB3_103
	b	LBB3_102
LBB3_102:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.23@PAGE
	add	x8, x8, l_.str.23@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_103:                               ;   in Loop: Header=BB3_78 Depth=1
	str	wzr, [sp, #276]
	b	LBB3_104
LBB3_104:                               ;   Parent Loop BB3_78 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #276]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB3_107
	b	LBB3_105
LBB3_105:                               ;   in Loop: Header=BB3_104 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2216]
	add	x9, x9, #22
	ldr	w10, [sp, #276]
                                        ; kill: def $x10 killed $w10
	ldrb	w10, [x9, x10]
	ldr	x8, [x8, #2320]
	mov	x9, #4104                       ; =0x1008
	add	x8, x8, x9
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #8
	ldr	w9, [sp, #276]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	ldrb	w8, [x9]
	orr	w8, w8, w10
	strb	w8, [x9]
	b	LBB3_106
LBB3_106:                               ;   in Loop: Header=BB3_104 Depth=2
	ldr	w8, [sp, #276]
	add	w8, w8, #1
	str	w8, [sp, #276]
	b	LBB3_104
LBB3_107:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_192
LBB3_108:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #168
	b.ne	LBB3_121
	b	LBB3_109
LBB3_109:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	w8, [x8, #284]
	cbz	w8, LBB3_119
	b	LBB3_110
LBB3_110:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB3_119
	b	LBB3_111
LBB3_111:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB3_119
	b	LBB3_112
LBB3_112:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2216]
	ldr	x9, [x9]
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x9, [x8, #2216]
	ldr	x9, [x9, #8]
	ldrb	w10, [x9]
	add	x9, sp, #268
	strb	w10, [sp, #268]
	add	x9, x9, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #271]
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #8
	b.eq	LBB3_115
	b	LBB3_113
LBB3_113:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #10
	b.eq	LBB3_115
	b	LBB3_114
LBB3_114:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.ne	LBB3_116
	b	LBB3_115
LBB3_115:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB3_117
LBB3_116:                               ;   in Loop: Header=BB3_78 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB3_117
LBB3_117:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	str	w8, [sp, #272]
	add	x8, sp, #13
	ldur	x1, [x8, #255]
	bl	_nvm_affine_can_resume
	tbz	w0, #0, LBB3_119
	b	LBB3_118
LBB3_118:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2216]
	ldr	x9, [x9, #8]
	ldrb	w9, [x9, #4]
	and	w9, w9, #0x1
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	ldr	x9, [x8, #2216]
	ldr	x0, [x9]
	ldr	x9, [x8, #2216]
	ldr	x9, [x9, #8]
	ldrb	w10, [x9]
	add	x9, sp, #260
	strb	w10, [sp, #260]
	add	x9, x9, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #263]
	ldr	x8, [x8, #2216]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	str	w8, [sp, #264]
	add	x8, sp, #5
	ldur	x1, [x8, #255]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.eq	LBB3_120
	b	LBB3_119
LBB3_119:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.24@PAGE
	add	x8, x8, l_.str.24@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_120:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_191
LBB3_121:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #163
	b.ne	LBB3_127
	b	LBB3_122
LBB3_122:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	cbnz	w8, LBB3_125
	b	LBB3_123
LBB3_123:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	w8, [x8, #284]
	cbnz	w8, LBB3_125
	b	LBB3_124
LBB3_124:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	tbnz	w0, #0, LBB3_126
	b	LBB3_125
LBB3_125:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.25@PAGE
	add	x8, x8, l_.str.25@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_126:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_190
LBB3_127:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2216]
	ldr	x9, [x8, #72]
	add	x1, x9, #40
	ldr	x9, [x8, #2208]
	ldrh	w2, [x9, #16]
	ldr	x3, [x8, #2352]
	ldr	w4, [sp, #2572]
	ldr	x9, [x8, #72]
	ldr	w5, [x9]
	ldr	x6, [x8, #2320]
	bl	_step
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #2312]
	ldr	x8, [x8, #2312]
	cbz	x8, LBB3_129
	b	LBB3_128
LBB3_128:
	b	LBB3_223
LBB3_129:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #165
	b.ne	LBB3_142
	b	LBB3_130
LBB3_130:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #278]
	subs	w8, w8, #64
	b.ne	LBB3_132
	b	LBB3_131
LBB3_131:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.26@PAGE
	add	x8, x8, l_.str.26@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_132:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #72]
	ldr	w9, [x9, #48]
	str	w9, [sp, #256]
	ldr	x9, [x8, #72]
	ldrh	w9, [x9, #64]
	strh	w9, [sp, #254]
	ldr	x9, [x8, #2216]
	add	x10, x9, #288
	ldr	x12, [x8, #2216]
	ldrh	w9, [x12, #278]
	mov	x11, x9
	mov	x9, x11
	add	w9, w9, #1
	strh	w9, [x12, #278]
	ldr	w9, [sp, #256]
	str	w9, [sp, #244]
	ldr	w9, [sp, #304]
	str	w9, [sp, #248]
	ldur	x9, [sp, #244]
	str	x9, [x10, x11, lsl #3]
	ldr	x0, [x8, #2216]
	bl	_frame_clone
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8, #8]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB3_134
	b	LBB3_133
LBB3_133:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.27@PAGE
	add	x8, x8, l_.str.27@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_134:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2216]
	ldr	x0, [x8]
	ldr	w1, [sp, #256]
	ldrh	w2, [sp, #254]
	bl	_nvm_affine_handler_enter
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [x8]
	ldr	x8, [x8]
	cbnz	x8, LBB3_136
	b	LBB3_135
LBB3_135:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_frame_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.28@PAGE
	add	x8, x8, l_.str.28@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_136:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	x10, [x8, #8]
	str	x9, [x10]
	ldr	x8, [x8, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
                                        ; kill: def $x10 killed $xzr
	str	xzr, [x8, #8]
	ldr	x8, [x9, #8]
	strh	wzr, [x8, #16]
	ldr	w8, [sp, #304]
	add	w8, w8, #1
	ldr	x10, [x9, #8]
	str	w8, [x10, #284]
	ldr	x8, [x9, #8]
	ldrh	w8, [x8, #278]
	ldr	x10, [x9, #8]
	strh	w8, [x10, #280]
	ldr	x8, [x9, #72]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #2208]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	str	w8, [sp, #220]
	ldr	w1, [sp, #220]
	add	x0, sp, #2496
	bl	_vm_decoded_function_at
	str	x0, [sp, #208]
	ldr	x8, [sp, #208]
	cbz	x8, LBB3_138
	b	LBB3_137
LBB3_137:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2264]
	ldr	x9, [sp, #208]
	ldr	x10, [x8, #2272]
	subs	x9, x9, x10
	mov	x10, #104                       ; =0x68
	sdiv	x9, x9, x10
	mov	x1, x9
	ldr	x2, [x8, #8]
	add	x3, sp, #2448
	add	x4, sp, #2536
	bl	_propagate
	tbnz	w0, #0, LBB3_141
	b	LBB3_138
LBB3_138:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_frame_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2312]
	cbnz	x8, LBB3_140
	b	LBB3_139
LBB3_139:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.29@PAGE
	add	x8, x8, l_.str.29@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_140
LBB3_140:
	b	LBB3_223
LBB3_141:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_frame_free
	b	LBB3_142
LBB3_142:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #107
	b.ne	LBB3_174
	b	LBB3_143
LBB3_143:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #2208]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	str	w8, [sp, #204]
	ldr	w1, [sp, #204]
	add	x0, sp, #2496
	bl	_vm_decoded_function_at
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x0, [sp, #192]
	ldr	x9, [x8, #72]
	ldrh	w9, [x9, #48]
	strh	w9, [sp, #190]
	ldr	x9, [x8, #2216]
	ldr	x10, [x9, #8]
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #12]
	strh	w8, [sp, #188]
	ldr	x8, [sp, #192]
	cbnz	x8, LBB3_145
	b	LBB3_144
LBB3_144:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.30@PAGE
	add	x8, x8, l_.str.30@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_145:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2216]
	ldr	x10, [x9, #8]
	ldr	x8, [x8, #2216]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	str	x8, [sp, #176]
	ldr	x8, [sp, #176]
	add	x8, x8, #16
	ldrh	w9, [sp, #190]
	mov	w11, #64                        ; =0x40
	udiv	w9, w9, w11
	ldr	x8, [x8, w9, uxtw #3]
	ldrh	w9, [sp, #190]
	udiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	ands	x8, x8, x9
	cset	w8, ne
	strb	w8, [sp, #175]
	ldrh	w8, [sp, #188]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB3_147
	b	LBB3_146
LBB3_146:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #175]
	tbz	w8, #0, LBB3_148
	b	LBB3_147
LBB3_147:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #188]
	ldrh	w9, [sp, #190]
	subs	w8, w8, w9
	b.ne	LBB3_155
	b	LBB3_148
LBB3_148:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2216]
	bl	_frame_clone
	str	x0, [sp, #160]
	ldr	x8, [sp, #160]
	cbz	x8, LBB3_151
	b	LBB3_149
LBB3_149:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x0, [sp, #160]
	ldrh	w1, [sp, #190]
	bl	_match_refine
	tbz	w0, #0, LBB3_151
	b	LBB3_150
LBB3_150:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x9, #2264]
	ldr	x8, [sp, #192]
	ldr	x9, [x9, #2272]
	subs	x8, x8, x9
	mov	x9, #104                        ; =0x68
	sdiv	x8, x8, x9
	mov	x1, x8
	ldr	x2, [sp, #160]
	add	x3, sp, #2448
	add	x4, sp, #2536
	bl	_propagate
	tbnz	w0, #0, LBB3_154
	b	LBB3_151
LBB3_151:
	ldr	x0, [sp, #160]
	bl	_frame_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2312]
	cbnz	x8, LBB3_153
	b	LBB3_152
LBB3_152:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.31@PAGE
	add	x8, x8, l_.str.31@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_153
LBB3_153:
	b	LBB3_223
LBB3_154:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x0, [sp, #160]
	bl	_frame_free
	b	LBB3_155
LBB3_155:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #188]
	ldrh	w9, [sp, #190]
	subs	w8, w8, w9
	b.ne	LBB3_157
	b	LBB3_156
LBB3_156:                               ;   in Loop: Header=BB3_78 Depth=1
	strb	wzr, [sp, #294]
	b	LBB3_173
LBB3_157:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #188]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB3_172
	b	LBB3_158
LBB3_158:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #190]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x11, x8, x9
	ldr	x8, [sp, #176]
	add	x9, x8, #16
	ldrh	w8, [sp, #190]
	udiv	w10, w8, w10
	ldr	x8, [x9, w10, uxtw #3]
	orr	x8, x8, x11
	str	x8, [x9, w10, uxtw #3]
	strh	wzr, [sp, #158]
	strh	wzr, [sp, #156]
	strh	wzr, [sp, #154]
	b	LBB3_159
LBB3_159:                               ;   Parent Loop BB3_78 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #154]
	subs	w8, w8, #256
	b.hs	LBB3_166
	b	LBB3_160
LBB3_160:                               ;   in Loop: Header=BB3_159 Depth=2
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2352]
	ldr	x8, [sp, #176]
	ldr	w1, [x8, #8]
	ldrh	w2, [sp, #154]
	add	x3, sp, #140
	bl	_union_fact_for_layout
	tbnz	w0, #0, LBB3_162
	b	LBB3_161
LBB3_161:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_166
LBB3_162:                               ;   in Loop: Header=BB3_159 Depth=2
	ldr	x8, [sp, #176]
	add	x8, x8, #16
	ldrh	w9, [sp, #154]
	mov	w11, #64                        ; =0x40
	udiv	w9, w9, w11
	ldr	x8, [x8, w9, uxtw #3]
	ldrh	w9, [sp, #154]
	udiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbnz	x8, LBB3_164
	b	LBB3_163
LBB3_163:                               ;   in Loop: Header=BB3_159 Depth=2
	ldrh	w8, [sp, #158]
	add	w8, w8, #1
	strh	w8, [sp, #158]
	ldrh	w8, [sp, #154]
	strh	w8, [sp, #156]
	b	LBB3_164
LBB3_164:                               ;   in Loop: Header=BB3_159 Depth=2
	b	LBB3_165
LBB3_165:                               ;   in Loop: Header=BB3_159 Depth=2
	ldrh	w8, [sp, #154]
	add	w8, w8, #1
	strh	w8, [sp, #154]
	b	LBB3_159
LBB3_166:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #158]
	cbnz	w8, LBB3_168
	b	LBB3_167
LBB3_167:                               ;   in Loop: Header=BB3_78 Depth=1
	strb	wzr, [sp, #294]
	b	LBB3_171
LBB3_168:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #158]
	subs	w8, w8, #1
	b.ne	LBB3_170
	b	LBB3_169
LBB3_169:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrh	w8, [sp, #156]
	ldr	x9, [sp, #176]
	strh	w8, [x9, #12]
	ldr	x8, [sp, #176]
	add	x0, x8, #16
	mov	w1, #0                          ; =0x0
	mov	x2, #32                         ; =0x20
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	b	LBB3_170
LBB3_170:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_171
LBB3_171:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_172
LBB3_172:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_173
LBB3_173:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_174
LBB3_174:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #56
	b.eq	LBB3_177
	b	LBB3_175
LBB3_175:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #57
	b.eq	LBB3_177
	b	LBB3_176
LBB3_176:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #58
	b.ne	LBB3_182
	b	LBB3_177
LBB3_177:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #72]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #2208]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	str	w8, [sp, #136]
	ldr	w1, [sp, #136]
	add	x0, sp, #2496
	bl	_vm_decoded_function_at
	str	x0, [sp, #128]
	ldr	x8, [sp, #128]
	cbnz	x8, LBB3_179
	b	LBB3_178
LBB3_178:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.32@PAGE
	add	x8, x8, l_.str.32@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_179:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2264]
	ldr	x9, [sp, #128]
	ldr	x10, [x8, #2272]
	subs	x9, x9, x10
	mov	x10, #104                       ; =0x68
	sdiv	x9, x9, x10
	mov	x1, x9
	ldr	x2, [x8, #2216]
	add	x3, sp, #2448
	add	x4, sp, #2536
	bl	_propagate
	tbnz	w0, #0, LBB3_181
	b	LBB3_180
LBB3_180:
	b	LBB3_223
LBB3_181:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_182
LBB3_182:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #295]
	subs	w8, w8, #56
	b.eq	LBB3_189
	b	LBB3_183
LBB3_183:                               ;   in Loop: Header=BB3_78 Depth=1
	ldrb	w8, [sp, #294]
	tbz	w8, #0, LBB3_189
	b	LBB3_184
LBB3_184:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	w8, [sp, #304]
	add	w8, w8, #1
	ldr	w9, [sp, #2420]
	subs	w8, w8, w9
	b.ne	LBB3_186
	b	LBB3_185
LBB3_185:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.33@PAGE
	add	x8, x8, l_.str.33@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_186:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2264]
	ldr	w9, [sp, #304]
	add	w1, w9, #1
	ldr	x2, [x8, #2216]
	add	x3, sp, #2448
	add	x4, sp, #2536
	bl	_propagate
	tbnz	w0, #0, LBB3_188
	b	LBB3_187
LBB3_187:
	b	LBB3_223
LBB3_188:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_189
LBB3_189:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_190
LBB3_190:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_191
LBB3_191:                               ;   in Loop: Header=BB3_78 Depth=1
	b	LBB3_192
LBB3_192:                               ;   in Loop: Header=BB3_78 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2216]
	bl	_frame_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #2216]
	b	LBB3_78
LBB3_193:
	str	wzr, [sp, #124]
	b	LBB3_194
LBB3_194:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #124]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB3_201
	b	LBB3_195
LBB3_195:                               ;   in Loop: Header=BB3_194 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	add	x8, x8, #2056
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #8
	ldr	w9, [sp, #124]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #123]
	ldrb	w8, [sp, #123]
	cbz	w8, LBB3_198
	b	LBB3_196
LBB3_196:                               ;   in Loop: Header=BB3_194 Depth=1
	ldr	w8, [sp, #2572]
	cbnz	w8, LBB3_199
	b	LBB3_197
LBB3_197:                               ;   in Loop: Header=BB3_194 Depth=1
	ldrb	w8, [sp, #123]
	tbnz	w8, #0, LBB3_199
	b	LBB3_198
LBB3_198:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.34@PAGE
	add	x8, x8, l_.str.34@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_199:                               ;   in Loop: Header=BB3_194 Depth=1
	b	LBB3_200
LBB3_200:                               ;   in Loop: Header=BB3_194 Depth=1
	ldr	w8, [sp, #124]
	add	w8, w8, #1
	str	w8, [sp, #124]
	b	LBB3_194
LBB3_201:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldr	x8, [x8, #6160]
	cbz	x8, LBB3_222
	b	LBB3_202
LBB3_202:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2336]
	cbnz	x8, LBB3_222
	b	LBB3_203
LBB3_203:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #2572]
	ldr	x9, [x9, #2320]
	ldr	w9, [x9, #6152]
	subs	w8, w8, w9
	b.ne	LBB3_222
	b	LBB3_204
LBB3_204:
	ldr	w8, [sp, #2420]
	mov	x0, x8
	mov	x1, #12                         ; =0xc
	bl	_calloc
	str	x0, [sp, #112]
	ldr	x8, [sp, #112]
	cbnz	x8, LBB3_206
	b	LBB3_205
LBB3_205:
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.35@PAGE
	add	x8, x8, l_.str.35@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_206:
	str	wzr, [sp, #108]
	b	LBB3_207
LBB3_207:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #108]
	ldr	w9, [sp, #2420]
	subs	w8, w8, w9
	b.hs	LBB3_221
	b	LBB3_208
LBB3_208:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #2272]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	mov	x11, #104                       ; =0x68
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	ldr	x12, [sp, #112]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	mov	x11, #12                        ; =0xc
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	str	w9, [x10, #8]
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB3_210
	b	LBB3_209
LBB3_209:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, #18]
	tbnz	w8, #0, LBB3_211
	b	LBB3_210
LBB3_210:                               ;   in Loop: Header=BB3_207 Depth=1
	b	LBB3_220
LBB3_211:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x12, [sp, #112]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	mov	x11, #12                        ; =0xc
	mov	x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x10, w9, w10, x12
	mov	w9, #1                          ; =0x1
	strb	w9, [x10]
	ldr	x9, [x8, #2264]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	ldrh	w9, [x9, #16]
	ldr	x12, [sp, #112]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	strh	w9, [x10, #2]
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB3_213
	b	LBB3_212
LBB3_212:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #2264]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	ldr	x8, [x8, #8]
	ldr	x9, [x9, #2264]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB3_214
LBB3_213:                               ;   in Loop: Header=BB3_207 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB3_214
LBB3_214:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	ldr	x12, [sp, #112]
	ldr	w10, [sp, #108]
                                        ; kill: def $x10 killed $w10
	mov	x11, #12                        ; =0xc
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	strb	w9, [x10, #1]
	ldr	x10, [x8, #2272]
	ldr	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #40]
	subs	w8, w8, #14
	b.ne	LBB3_219
	b	LBB3_215
LBB3_215:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	strh	wzr, [sp, #98]
	ldr	x11, [x8, #2272]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #48]
	strh	w9, [sp, #96]
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x0, [x8]
	ldrh	w1, [sp, #96]
	add	x2, sp, #100
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB3_217
	b	LBB3_216
LBB3_216:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x0, [x8]
	ldrh	w1, [sp, #96]
	add	x2, sp, #2584
	mov	w3, #256                        ; =0x100
	add	x4, sp, #98
	bl	_nvm_affine_owned_local_fields
	tbnz	w0, #0, LBB3_218
	b	LBB3_217
LBB3_217:
	ldr	x0, [sp, #112]
	bl	_free
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x8, l_.str.36@PAGE
	add	x8, x8, l_.str.36@PAGEOFF
	str	x8, [x9, #2312]
	b	LBB3_223
LBB3_218:                               ;   in Loop: Header=BB3_207 Depth=1
	ldrh	w8, [sp, #98]
	ldr	x11, [sp, #112]
	ldr	w9, [sp, #108]
                                        ; kill: def $x9 killed $w9
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	strh	w8, [x9, #4]
	b	LBB3_219
LBB3_219:                               ;   in Loop: Header=BB3_207 Depth=1
	b	LBB3_220
LBB3_220:                               ;   in Loop: Header=BB3_207 Depth=1
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB3_207
LBB3_221:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldr	x0, [x8, #6160]
	ldr	x1, [sp, #112]
	ldr	w8, [sp, #2420]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x0, [sp, #112]
	bl	_free
	b	LBB3_222
LBB3_222:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
	mov	w9, #1                          ; =0x1
	strb	w9, [x10]
	stur	wzr, [x29, #-228]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #2312]
	b	LBB3_223
LBB3_223:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2216]
	bl	_frame_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	cbz	x8, LBB3_229
	b	LBB3_224
LBB3_224:
	str	wzr, [sp, #92]
	b	LBB3_225
LBB3_225:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #92]
	ldr	w9, [sp, #2504]
	subs	w8, w8, w9
	b.hs	LBB3_228
	b	LBB3_226
LBB3_226:                               ;   in Loop: Header=BB3_225 Depth=1
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2264]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_frame_free
	b	LBB3_227
LBB3_227:                               ;   in Loop: Header=BB3_225 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB3_225
LBB3_228:
	b	LBB3_229
LBB3_229:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2264]
	bl	_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2224]
	bl	_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #2232]
	bl	_free
	add	x0, sp, #2496
	bl	_vm_decoded_function_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2312]
	cbz	x8, LBB3_231
	b	LBB3_230
LBB3_230:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	sub	x9, x29, #232
	add	x0, x9, #16
	ldr	x8, [x8, #2312]
	mov	x9, sp
	str	x8, [x9]
	mov	x3, #192                        ; =0xc0
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.37@PAGE
	add	x4, x4, l_.str.37@PAGEOFF
	bl	___snprintf_chk
	b	LBB3_231
LBB3_231:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB3_235
	b	LBB3_232
LBB3_232:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2336]
	cbnz	x8, LBB3_235
	b	LBB3_233
LBB3_233:
	ldr	w8, [sp, #2572]
	subs	w8, w8, #8
	b.hs	LBB3_235
	b	LBB3_234
LBB3_234:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	mov	x9, #6176                       ; =0x1820
	add	x10, x8, x9
	ldr	w8, [sp, #2572]
                                        ; kill: def $x8 killed $w8
	mov	x9, #208                        ; =0xd0
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	sub	x1, x29, #232
	mov	x2, #208                        ; =0xd0
	bl	_memcpy
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #2320]
	mov	x9, #6168                       ; =0x1818
	add	x8, x8, x9
	ldr	w9, [sp, #2572]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #2                          ; =0x2
	strb	w8, [x9]
	b	LBB3_235
LBB3_235:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	sub	x1, x29, #232
	mov	x2, #208                        ; =0xd0
	bl	_memcpy
	b	LBB3_236
LBB3_236:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB3_238
	b	LBB3_237
LBB3_237:
	bl	___stack_chk_fail
LBB3_238:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1008
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_global_proof
_effect_global_proof:                   ; @effect_global_proof
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1536
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x8, [sp, #448]
	str	x1, [sp, #440]
	mov	x2, #208                        ; =0xd0
	mov	w1, #0                          ; =0x0
	bl	_memset
	add	x0, sp, #72
	mov	x1, #368                        ; =0x170
	bl	_bzero
	ldr	x8, [sp, #448]
	str	x8, [sp, #72]
	ldr	x8, [sp, #440]
	add	x8, x8, #8
	str	x8, [sp, #80]
	ldr	x8, [sp, #440]
	ldr	w8, [x8, #4]
	str	w8, [sp, #88]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #424]
	str	w8, [sp, #428]
	mov	x0, #65536                      ; =0x10000
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x1, #4                          ; =0x4
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	bl	_calloc
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #400]
	bl	_calloc
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #408]
	bl	_calloc
	str	x0, [sp, #416]
	ldr	x8, [sp, #400]
	cbz	x8, LBB4_3
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #408]
	cbz	x8, LBB4_3
	b	LBB4_2
LBB4_2:
	ldr	x8, [sp, #416]
	cbnz	x8, LBB4_4
	b	LBB4_3
LBB4_3:
	adrp	x8, l_.str.145@PAGE
	add	x8, x8, l_.str.145@PAGEOFF
	str	x8, [sp, #432]
	b	LBB4_21
LBB4_4:
	str	wzr, [sp, #68]
	b	LBB4_5
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #68]
	ldr	x9, [sp, #448]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB4_10
	b	LBB4_6
LBB4_6:                                 ;   in Loop: Header=BB4_5 Depth=1
	ldr	x0, [sp, #448]
	ldr	w1, [sp, #68]
	add	x8, sp, #72
	add	x8, x8, #24
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	add	x2, x8, x9, lsl #5
	add	x3, sp, #1272
	bl	_vm_decode_function
	tbnz	w0, #0, LBB4_8
	b	LBB4_7
LBB4_7:
	adrp	x8, l_.str.146@PAGE
	add	x8, x8, l_.str.146@PAGEOFF
	str	x8, [sp, #432]
	b	LBB4_21
LBB4_8:                                 ;   in Loop: Header=BB4_5 Depth=1
	b	LBB4_9
LBB4_9:                                 ;   in Loop: Header=BB4_5 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB4_5
LBB4_10:
	add	x8, sp, #72
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #88]
	mov	x2, x8
	add	x0, sp, #1016
	mov	w1, #1                          ; =0x1
	mov	x3, #256                        ; =0x100
	bl	___memset_chk
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	w5, #-1                         ; =0xffffffff
	mov	x1, x5
	mov	w2, #0                          ; =0x0
	mov	x3, x5
	mov	x4, x5
	bl	_eg_frame
	str	w0, [sp, #64]
	ldr	w8, [sp, #64]
	adds	w8, w8, #1
	b.eq	LBB4_12
	b	LBB4_11
LBB4_11:
	ldr	w1, [sp, #64]
	add	x0, sp, #72
	mov	w2, #0                          ; =0x0
	mov	w3, #-1                         ; =0xffffffff
	add	x4, sp, #1016
	bl	_eg_queue
	tbnz	w0, #0, LBB4_13
	b	LBB4_12
LBB4_12:
	b	LBB4_21
LBB4_13:
	b	LBB4_14
LBB4_14:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #424]
	adds	w8, w8, #1
	b.eq	LBB4_20
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_14 Depth=1
	ldr	w8, [sp, #424]
	str	w8, [sp, #60]
	ldr	x10, [sp, #368]
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #280                        ; =0x118
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #736
	mov	x2, #280                        ; =0x118
	bl	_memcpy
	ldr	w8, [sp, #752]
	str	w8, [sp, #424]
	ldr	w8, [sp, #424]
	adds	w8, w8, #1
	b.ne	LBB4_17
	b	LBB4_16
LBB4_16:                                ;   in Loop: Header=BB4_14 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #428]
	b	LBB4_17
LBB4_17:                                ;   in Loop: Header=BB4_14 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, sp, #72
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x12, [sp, #368]
	ldr	w10, [sp, #60]
                                        ; kill: def $x10 killed $w10
	mov	x11, #280                       ; =0x118
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	strb	wzr, [x10, #20]
	add	x8, x8, #24
	ldr	x10, [sp, #352]
	add	x1, sp, #736
	ldr	w11, [sp, #736]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11, lsl #5
	ldr	w10, [x10, #4]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #5
	ldr	x8, [x8, x10]
	ldr	w10, [sp, #740]
                                        ; kill: def $x10 killed $w10
	mov	x11, #104                       ; =0x68
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w8, [x8, x10]
	str	w8, [x9, #4]
	ldr	w8, [x9, #12]
	add	w8, w8, #1
	str	w8, [x9, #12]
	add	x0, sp, #456
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #280                        ; =0x118
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	bl	_eg_step
	tbnz	w0, #0, LBB4_19
	b	LBB4_18
LBB4_18:
	b	LBB4_21
LBB4_19:                                ;   in Loop: Header=BB4_14 Depth=1
	b	LBB4_14
LBB4_20:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w9, #1                          ; =0x1
	strb	w9, [x8]
	ldr	w9, [sp, #384]
	str	w9, [x8, #8]
	str	wzr, [x8, #4]
	b	LBB4_21
LBB4_21:
	ldr	x8, [sp, #432]
	cbz	x8, LBB4_23
	b	LBB4_22
LBB4_22:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	x0, x8, #16
	ldr	x8, [sp, #432]
	mov	x9, sp
	str	x8, [x9]
	mov	x3, #192                        ; =0xc0
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	adrp	x4, l_.str.37@PAGE
	add	x4, x4, l_.str.37@PAGEOFF
	bl	___snprintf_chk
	b	LBB4_23
LBB4_23:
	str	wzr, [sp, #56]
	b	LBB4_24
LBB4_24:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #56]
	ldr	x9, [sp, #448]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB4_27
	b	LBB4_25
LBB4_25:                                ;   in Loop: Header=BB4_24 Depth=1
	add	x8, sp, #72
	add	x8, x8, #24
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #5
	bl	_vm_decoded_function_free
	b	LBB4_26
LBB4_26:                                ;   in Loop: Header=BB4_24 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB4_24
LBB4_27:
	ldr	x0, [sp, #352]
	bl	_free
	ldr	x0, [sp, #360]
	bl	_free
	ldr	x0, [sp, #368]
	bl	_free
	ldr	x0, [sp, #400]
	bl	_free
	ldr	x0, [sp, #408]
	bl	_free
	ldr	x0, [sp, #416]
	bl	_free
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB4_29
	b	LBB4_28
LBB4_28:
	bl	___stack_chk_fail
LBB4_29:
	add	sp, sp, #1536
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_affine_analyze_instructions ; -- Begin function nvm_affine_analyze_instructions
	.p2align	2
_nvm_affine_analyze_instructions:       ; @nvm_affine_analyze_instructions
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #16352                      ; =0x3fe0
Lloh4:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh5:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #4064
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #80]
	str	w1, [sp, #76]
	str	x2, [sp, #64]
	str	w3, [sp, #60]
	ldr	x8, [sp, #64]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldr	w8, [sp, #60]
	cbz	w8, LBB5_3
	b	LBB5_2
LBB5_2:
	ldr	w8, [sp, #60]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ls	LBB5_4
	b	LBB5_3
LBB5_3:
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	mov	x2, #208                        ; =0xd0
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	add	x0, x8, #16
	mov	x3, #192                        ; =0xc0
	mov	x1, x3
	adrp	x4, l_.str@PAGE
	add	x4, x4, l_.str@PAGEOFF
	bl	___snprintf_chk
	b	LBB5_22
LBB5_4:
	add	x0, sp, #296
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x1, #16048                      ; =0x3eb0
	bl	_bzero
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #80]
	bl	_analysis_calls_init
	ldrb	w8, [sp, #298]
	tbz	w8, #0, LBB5_6
	b	LBB5_5
LBB5_5:
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x0, w8, w9
	bl	_malloc
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB5_7
LBB5_6:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB5_7
LBB5_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #48]
	ldrb	w8, [sp, #298]
	tbz	w8, #0, LBB5_10
	b	LBB5_8
LBB5_8:
	ldr	x8, [sp, #48]
	cbnz	x8, LBB5_10
	b	LBB5_9
LBB5_9:
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	mov	x2, #208                        ; =0xd0
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	bl	_memset
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #12]                   ; 4-byte Folded Reload
	add	x0, x8, #16
	mov	x3, #192                        ; =0xc0
	mov	x1, x3
	adrp	x4, l_.str.1@PAGE
	add	x4, x4, l_.str.1@PAGEOFF
	bl	___snprintf_chk
	b	LBB5_22
LBB5_10:
	ldr	w8, [sp, #76]
	str	w8, [sp, #6448]
	ldr	w8, [sp, #60]
	str	w8, [sp, #6452]
	ldr	x8, [sp, #48]
	cbz	x8, LBB5_12
	b	LBB5_11
LBB5_11:
	ldr	x8, [sp, #48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_13
LBB5_12:
	ldr	x8, [sp, #64]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB5_13
LBB5_13:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	add	x4, sp, #296
	str	x9, [sp, #6456]
	ldr	x0, [sp, #80]
	ldr	w1, [sp, #76]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_analyze
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbz	w8, #0, LBB5_18
	b	LBB5_14
LBB5_14:
	ldrb	w8, [sp, #298]
	tbz	w8, #0, LBB5_18
	b	LBB5_15
LBB5_15:
	ldr	x0, [sp, #80]
	add	x8, sp, #88
	add	x1, sp, #296
	bl	_effect_global_proof
	ldrb	w8, [sp, #88]
	tbnz	w8, #0, LBB5_17
	b	LBB5_16
LBB5_16:
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	add	x1, sp, #88
	mov	x2, #208                        ; =0xd0
	bl	_memcpy
	b	LBB5_17
LBB5_17:
	b	LBB5_18
LBB5_18:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbz	w8, #0, LBB5_21
	b	LBB5_19
LBB5_19:
	ldr	x8, [sp, #48]
	cbz	x8, LBB5_21
	b	LBB5_20
LBB5_20:
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #48]
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB5_21
LBB5_21:
	ldr	x0, [sp, #48]
	bl	_free
	b	LBB5_22
LBB5_22:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB5_24
	b	LBB5_23
LBB5_23:
	bl	___stack_chk_fail
LBB5_24:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #4064
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function supported
_supported:                             ; @supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	strb	w1, [sp, #13]
	ldrb	w8, [sp, #14]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB6_4
; %bb.1:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI6_0@PAGE
	add	x10, x10, lJTI6_0@PAGEOFF
Ltmp1:
	adr	x8, Ltmp1
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB6_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB6_5
LBB6_3:
	ldrb	w8, [sp, #13]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB6_5
LBB6_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB6_5
LBB6_5:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
	.p2align	2
lJTI6_0:
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_3-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_3-Ltmp1
	.long	LBB6_3-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_3-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_3-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_2-Ltmp1
	.long	LBB6_4-Ltmp1
	.long	LBB6_2-Ltmp1
                                        ; -- End function
	.p2align	2                               ; -- Begin function enqueue
_enqueue:                               ; @enqueue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB7_2
	b	LBB7_1
LBB7_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB7_5
LBB7_2:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #28]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB7_4
	b	LBB7_3
LBB7_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB7_5
LBB7_4:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	x10, [sp, #16]
	ldr	w10, [x10, #24]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #24]
	mov	w9, #1                          ; =0x1
	add	w8, w8, #1
	ldr	x10, [sp, #16]
	ldr	w11, [x10, #16]
	udiv	w10, w8, w11
	mul	w10, w10, w11
	subs	w8, w8, w10
	ldr	x10, [sp, #16]
	str	w8, [x10, #24]
	ldr	x10, [sp, #16]
	ldr	w8, [x10, #28]
	add	w8, w8, #1
	str	w8, [x10, #28]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	add	x10, x8, x10
	mov	w8, #1                          ; =0x1
	strb	w8, [x10]
	and	w8, w9, #0x1
	and	w8, w8, w9
	strb	w8, [sp, #31]
	b	LBB7_5
LBB7_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frame_clone
_frame_clone:                           ; @frame_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	mov	x0, #1                          ; =0x1
	mov	x1, #800                        ; =0x320
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB8_9
LBB8_2:
	ldr	x8, [sp, #16]
	ldr	x0, [x8]
	bl	_nvm_affine_state_clone
	ldr	x8, [sp, #8]
	str	x0, [x8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB8_4
	b	LBB8_3
LBB8_3:
	ldr	x0, [sp, #8]
	bl	_frame_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB8_9
LBB8_4:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #16]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #20]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #20]
	ldr	x8, [sp, #8]
	add	x0, x8, #22
	ldr	x8, [sp, #16]
	add	x1, x8, #22
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #20]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp]                        ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x3, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #278]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #278]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #280]
	ldr	x9, [sp, #8]
	strh	w8, [x9, #280]
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #284]
	ldr	x9, [sp, #8]
	str	w8, [x9, #284]
	ldr	x8, [sp, #8]
	add	x0, x8, #288
	ldr	x8, [sp, #16]
	add	x1, x8, #288
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #278]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	___memcpy_chk
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB8_8
	b	LBB8_5
LBB8_5:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x0, w8, w9
	bl	_malloc
	ldr	x8, [sp, #8]
	str	x0, [x8, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB8_7
	b	LBB8_6
LBB8_6:
	ldr	x0, [sp, #8]
	bl	_frame_free
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB8_9
LBB8_7:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	x1, [x8, #8]
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB8_8
LBB8_8:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB8_9
LBB8_9:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function step
_step:                                  ; @step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #17456                      ; =0x4430
Lloh6:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh7:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #1072
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #584
	str	x8, [sp, #528]                  ; 8-byte Folded Spill
	add	x8, sp, #2220
	str	x8, [sp, #536]                  ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [sp, #4600]
	str	x1, [sp, #4592]
	strh	w2, [sp, #4590]
	str	x3, [sp, #4576]
	str	w4, [sp, #4572]
	str	w5, [sp, #4568]
	str	x6, [sp, #4560]
	ldr	x9, [sp, #4592]
	ldrb	w9, [x9]
	strb	w9, [x8, #2339]
	strb	wzr, [x8, #2338]
	ldrb	w8, [x8, #2339]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #544]                  ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB9_396
; %bb.1:
	ldr	x11, [sp, #544]                 ; 8-byte Folded Reload
	adrp	x10, lJTI9_0@PAGE
	add	x10, x10, lJTI9_0@PAGEOFF
Ltmp3:
	adr	x8, Ltmp3
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB9_2:
	ldr	x0, [sp, #4600]
	ldr	x1, [sp, #4592]
	ldr	x2, [sp, #4576]
	ldr	w3, [sp, #4572]
	ldr	w4, [sp, #4568]
	bl	_array_step
	str	x0, [sp, #4608]
	b	LBB9_398
LBB9_3:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_4:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #8]
	str	w8, [sp, #4548]
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_7
	b	LBB9_5
LBB9_5:
	ldr	w8, [sp, #4548]
	cbz	w8, LBB9_7
	b	LBB9_6
LBB9_6:
	ldr	w8, [sp, #4548]
	ldr	x9, [sp, #4576]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB9_8
	b	LBB9_7
LBB9_7:
	adrp	x8, l_.str.38@PAGE
	add	x8, x8, l_.str.38@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_8:
	ldr	x0, [sp, #4576]
	ldr	w1, [sp, #4548]
	ldr	x8, [sp, #4576]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #4548]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w2, [x8, #16]
	bl	_nvm_affine_state_create
	str	x0, [sp, #4536]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #430
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #520]                  ; 4-byte Folded Spill
	strh	wzr, [sp, #4526]
	strh	wzr, [sp, #4524]
	ldr	x0, [sp, #4536]
	sub	x1, x29, #88
	mov	w2, #8                          ; =0x8
	bl	_nvm_affine_value_parameters
	ldr	w8, [sp, #520]                  ; 4-byte Folded Reload
	str	w8, [sp, #524]                  ; 4-byte Folded Spill
	tbz	w0, #0, LBB9_10
	b	LBB9_9
LBB9_9:
	ldr	x0, [sp, #4536]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #432
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #428
	bl	_nvm_affine_value_result
	str	w0, [sp, #524]                  ; 4-byte Folded Spill
	b	LBB9_10
LBB9_10:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #524]                  ; 4-byte Folded Reload
	mov	w10, #1                         ; =0x1
	and	w8, w8, w10
	strb	w8, [x9, #2303]
	ldr	x0, [sp, #4536]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2303]
	tbz	w8, #0, LBB9_13
	b	LBB9_11
LBB9_11:
	ldrh	w8, [sp, #4526]
	ldr	x9, [sp, #4576]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #4548]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB9_13
	b	LBB9_12
LBB9_12:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #4526]
	subs	w8, w8, w9
	b.ge	LBB9_14
	b	LBB9_13
LBB9_13:
	adrp	x8, l_.str.39@PAGE
	add	x8, x8, l_.str.39@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_14:
	strh	wzr, [sp, #4520]
	b	LBB9_15
LBB9_15:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #4520]
	ldrh	w9, [sp, #4526]
	subs	w8, w8, w9
	b.ge	LBB9_27
	b	LBB9_16
LBB9_16:                                ;   in Loop: Header=BB9_15 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #4526]
	subs	w8, w8, w9
	ldrh	w9, [sp, #4520]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #376
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrh	w8, [sp, #4520]
	mov	x9, x8
	sub	x8, x29, #88
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #4464]
	add	x8, sp, #378
	ldrb	w8, [x8, #4095]
	tbnz	w8, #0, LBB9_24
	b	LBB9_17
LBB9_17:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	add	x9, sp, #369
	ldrb	w9, [x9, #4095]
	subs	w8, w8, w9
	b.ne	LBB9_24
	b	LBB9_18
LBB9_18:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #381
	ldrb	w8, [x8, #4095]
	and	w8, w8, #0x1
	str	w8, [sp, #516]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #4464]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #516]                  ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB9_24
	b	LBB9_19
LBB9_19:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #381
	ldrb	w8, [x8, #4095]
	tbnz	w8, #0, LBB9_23
	b	LBB9_20
LBB9_20:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	subs	w8, w8, #10
	b.eq	LBB9_23
	b	LBB9_21
LBB9_21:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	subs	w8, w8, #8
	b.eq	LBB9_23
	b	LBB9_22
LBB9_22:                                ;   in Loop: Header=BB9_15 Depth=1
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	subs	w8, w8, #7
	b.ne	LBB9_25
	b	LBB9_23
LBB9_23:                                ;   in Loop: Header=BB9_15 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	add	x8, sp, #377
	ldrb	w9, [x8, #4095]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #360
	add	x10, sp, #361
	strb	w9, [x10, #4095]
	add	x8, x8, #1
	strh	wzr, [x8]
	add	x8, sp, #364
	strb	wzr, [x8, #4095]
	ldr	w8, [sp, #4480]
	str	w8, [sp, #4460]
	ldr	x1, [sp, #4456]
	ldr	x2, [sp, #4464]
	bl	_nvm_affine_types_equal
	tbnz	w0, #0, LBB9_25
	b	LBB9_24
LBB9_24:
	adrp	x8, l_.str.40@PAGE
	add	x8, x8, l_.str.40@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_25:                                ;   in Loop: Header=BB9_15 Depth=1
	b	LBB9_26
LBB9_26:                                ;   in Loop: Header=BB9_15 Depth=1
	ldrh	w8, [sp, #4520]
	add	w8, w8, #1
	strh	w8, [sp, #4520]
	b	LBB9_15
LBB9_27:
	ldr	x0, [sp, #4576]
	ldr	w1, [sp, #4548]
	ldr	x4, [sp, #4560]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #792
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_analyze
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #208]
	tbnz	w8, #0, LBB9_29
	b	LBB9_28
LBB9_28:
	adrp	x8, l_.str.41@PAGE
	add	x8, x8, l_.str.41@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_29:
	ldr	x8, [sp, #4560]
	mov	x9, #7840                       ; =0x1ea0
	add	x8, x8, x9
	ldr	w9, [sp, #4548]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	cbz	w8, LBB9_46
	b	LBB9_30
LBB9_30:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	tbnz	w0, #0, LBB9_32
	b	LBB9_31
LBB9_31:
	adrp	x8, l_.str.42@PAGE
	add	x8, x8, l_.str.42@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_32:
	strh	wzr, [sp, #4454]
	b	LBB9_33
LBB9_33:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #4454]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	ldrh	w10, [sp, #4526]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ge	LBB9_39
	b	LBB9_34
LBB9_34:                                ;   in Loop: Header=BB9_33 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #4454]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_36
	b	LBB9_35
LBB9_35:                                ;   in Loop: Header=BB9_33 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #4454]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB9_37
	b	LBB9_36
LBB9_36:
	adrp	x8, l_.str.43@PAGE
	add	x8, x8, l_.str.43@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_37:                                ;   in Loop: Header=BB9_33 Depth=1
	b	LBB9_38
LBB9_38:                                ;   in Loop: Header=BB9_33 Depth=1
	ldrh	w8, [sp, #4454]
	add	w8, w8, #1
	strh	w8, [sp, #4454]
	b	LBB9_33
LBB9_39:
	strh	wzr, [sp, #4452]
	b	LBB9_40
LBB9_40:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #4452]
	ldr	x9, [sp, #4560]
	mov	x10, #7840                      ; =0x1ea0
	add	x9, x9, x10
	ldr	w10, [sp, #4548]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
	subs	w8, w8, w9
	b.ge	LBB9_45
	b	LBB9_41
LBB9_41:                                ;   in Loop: Header=BB9_40 Depth=1
	ldr	x0, [sp, #4560]
	ldr	x1, [sp, #4576]
	ldr	w2, [sp, #4572]
	ldr	x3, [sp, #4600]
	ldr	x8, [sp, #4560]
	mov	x9, #7856                       ; =0x1eb0
	add	x8, x8, x9
	ldr	w9, [sp, #4548]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #10
	ldrh	w9, [sp, #4452]
                                        ; kill: def $x9 killed $w9
	ldr	w4, [x8, x9, lsl #2]
	bl	_effect_escape
	tbnz	w0, #0, LBB9_43
	b	LBB9_42
LBB9_42:
	adrp	x8, l_.str.44@PAGE
	add	x8, x8, l_.str.44@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_43:                                ;   in Loop: Header=BB9_40 Depth=1
	b	LBB9_44
LBB9_44:                                ;   in Loop: Header=BB9_40 Depth=1
	ldrh	w8, [sp, #4452]
	add	w8, w8, #1
	strh	w8, [sp, #4452]
	b	LBB9_40
LBB9_45:
	b	LBB9_46
LBB9_46:
	str	wzr, [sp, #4448]
	b	LBB9_47
LBB9_47:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8, #2]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #512]                  ; 4-byte Folded Spill
	tbnz	w8, #0, LBB9_49
	b	LBB9_48
LBB9_48:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	w8, [sp, #4448]
	ldr	x9, [sp, #4560]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #512]                  ; 4-byte Folded Spill
	b	LBB9_49
LBB9_49:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	w8, [sp, #512]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB9_52
	b	LBB9_50
LBB9_50:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	x0, [sp, #4600]
	ldr	x1, [sp, #4560]
	ldr	w2, [sp, #4572]
	ldr	w3, [sp, #4448]
	ldr	x8, [sp, #4560]
	add	x8, x8, #2056
	ldr	w9, [sp, #4548]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #8
	ldr	w9, [sp, #4448]
                                        ; kill: def $x9 killed $w9
	ldrb	w4, [x8, x9]
	bl	_global_require
	ldr	x8, [sp, #4600]
	add	x8, x8, #22
	ldr	w9, [sp, #4448]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	ldr	x8, [sp, #4560]
	mov	x9, #4104                       ; =0x1008
	add	x8, x8, x9
	ldr	w9, [sp, #4548]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #8
	ldr	w9, [sp, #4448]
                                        ; kill: def $x9 killed $w9
	ldrb	w1, [x8, x9]
	bl	_nvm_affine_global_compose
	ldr	x8, [sp, #4600]
	add	x8, x8, #22
	ldr	w9, [sp, #4448]
                                        ; kill: def $x9 killed $w9
	strb	w0, [x8, x9]
	b	LBB9_51
LBB9_51:                                ;   in Loop: Header=BB9_47 Depth=1
	ldr	w8, [sp, #4448]
	add	w8, w8, #1
	str	w8, [sp, #4448]
	b	LBB9_47
LBB9_52:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrh	w11, [sp, #4526]
	ldr	x10, [sp, #4600]
	ldrh	w9, [x10, #16]
	subs	w9, w9, w11
	strh	w9, [x10, #16]
	ldrb	w8, [x8, #2308]
	cbnz	w8, LBB9_54
	b	LBB9_53
LBB9_53:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_54:
	ldr	x8, [sp, #4600]
	str	x8, [sp, #496]                  ; 8-byte Folded Spill
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #304
	str	x0, [sp, #480]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #488]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2308]
	add	x9, sp, #305
	strb	w8, [x9, #4095]
	mov	w8, #65535                      ; =0xffff
	str	w8, [sp, #476]                  ; 4-byte Folded Spill
	strh	w8, [sp, #4402]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #4528]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #476]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #480]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #488]                  ; 8-byte Folded Reload
	add	x9, sp, #309
	strb	w0, [x9, #4095]
	ldr	w9, [sp, #4532]
	str	w9, [sp, #4408]
	strh	w8, [sp, #4412]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #256
	str	x0, [sp, #504]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #496]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #504]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.45@PAGE
	add	x9, x9, l_.str.45@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_55:
	ldr	w8, [sp, #4572]
	cbnz	w8, LBB9_58
	b	LBB9_56
LBB9_56:
	ldr	x8, [sp, #4576]
	ldr	w8, [x8, #272]
	subs	w8, w8, #2
	b.ne	LBB9_58
	b	LBB9_57
LBB9_57:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB9_59
	b	LBB9_58
LBB9_58:
	adrp	x8, l_.str.46@PAGE
	add	x8, x8, l_.str.46@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_59:
	ldr	x0, [sp, #4576]
	ldr	x8, [sp, #4600]
	ldr	x2, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w3, [x8, #16]
	ldr	x4, [sp, #4560]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #584
	mov	w1, #1                          ; =0x1
	bl	_analyze
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_61
	b	LBB9_60
LBB9_60:
	adrp	x8, l_.str.47@PAGE
	add	x8, x8, l_.str.47@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_61:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #256]
	ldrb	w8, [x8, #44]
	strb	w8, [x9, #2338]
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #256]
	ldrb	w8, [x8, #45]
	subs	w8, w8, #1
	b.ne	LBB9_65
	b	LBB9_62
LBB9_62:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #1
	b.eq	LBB9_66
	b	LBB9_63
LBB9_63:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #4
	b.eq	LBB9_66
	b	LBB9_64
LBB9_64:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #2
	b.eq	LBB9_66
	b	LBB9_65
LBB9_65:
	adrp	x8, l_.str.48@PAGE
	add	x8, x8, l_.str.48@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_66:
	b	LBB9_397
LBB9_67:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_68:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #4350]
	ldrh	w8, [sp, #4350]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #278]
	ldr	x10, [sp, #4600]
	ldrh	w10, [x10, #280]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.le	LBB9_70
	b	LBB9_69
LBB9_69:
	adrp	x8, l_.str.49@PAGE
	add	x8, x8, l_.str.49@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_70:
	ldrh	w10, [sp, #4350]
	ldr	x9, [sp, #4600]
	ldrh	w8, [x9, #278]
	subs	w8, w8, w10
	strh	w8, [x9, #278]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_71:
	ldr	x0, [sp, #4576]
	ldr	x8, [sp, #4592]
	ldr	w1, [x8, #8]
	add	x2, sp, #2284
	bl	_nvm_ownership_effect
	cbnz	w0, LBB9_74
	b	LBB9_72
LBB9_72:
	ldrh	w8, [sp, #2288]
	ldr	x9, [sp, #4592]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB9_74
	b	LBB9_73
LBB9_73:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #2288]
	subs	w8, w8, w9
	b.ge	LBB9_75
	b	LBB9_74
LBB9_74:
	adrp	x8, l_.str.50@PAGE
	add	x8, x8, l_.str.50@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_75:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #2288]
	subs	w8, w8, w9
	strh	w8, [sp, #2282]
	strh	wzr, [sp, #2280]
	b	LBB9_76
LBB9_76:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #2280]
	ldrh	w9, [sp, #2288]
	subs	w8, w8, w9
	b.ge	LBB9_81
	b	LBB9_77
LBB9_77:                                ;   in Loop: Header=BB9_76 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x8, [x8]
	str	x8, [sp, #440]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #2282]
	ldrh	w9, [sp, #2280]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x8, sp, #2284
	add	x8, x8, #16
	str	x8, [sp, #456]                  ; 8-byte Folded Spill
	ldrh	w8, [sp, #2280]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	add	x0, sp, #2232
	str	x0, [sp, #464]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #440]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #448]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #456]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #464]                  ; 8-byte Folded Reload
	ldr	x2, [x8, x9, lsl #3]
	bl	_effect_value_matches
	tbnz	w0, #0, LBB9_79
	b	LBB9_78
LBB9_78:
	adrp	x8, l_.str.51@PAGE
	add	x8, x8, l_.str.51@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_79:                                ;   in Loop: Header=BB9_76 Depth=1
	b	LBB9_80
LBB9_80:                                ;   in Loop: Header=BB9_76 Depth=1
	ldrh	w8, [sp, #2280]
	add	w8, w8, #1
	strh	w8, [sp, #2280]
	b	LBB9_76
LBB9_81:
	strh	wzr, [sp, #2230]
	b	LBB9_82
LBB9_82:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #2230]
	ldrh	w9, [sp, #2282]
	subs	w8, w8, w9
	b.ge	LBB9_88
	b	LBB9_83
LBB9_83:                                ;   in Loop: Header=BB9_82 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #2230]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_85
	b	LBB9_84
LBB9_84:                                ;   in Loop: Header=BB9_82 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #2230]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB9_86
	b	LBB9_85
LBB9_85:
	adrp	x8, l_.str.52@PAGE
	add	x8, x8, l_.str.52@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_86:                                ;   in Loop: Header=BB9_82 Depth=1
	b	LBB9_87
LBB9_87:                                ;   in Loop: Header=BB9_82 Depth=1
	ldrh	w8, [sp, #2230]
	add	w8, w8, #1
	strh	w8, [sp, #2230]
	b	LBB9_82
LBB9_88:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	bl	_nvm_affine_can_suspend
	tbnz	w0, #0, LBB9_90
	b	LBB9_89
LBB9_89:
	adrp	x8, l_.str.53@PAGE
	add	x8, x8, l_.str.53@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_90:
	ldr	x0, [sp, #4560]
	ldr	x1, [sp, #4576]
	ldr	w2, [sp, #4572]
	ldr	x3, [sp, #4600]
	ldr	w4, [sp, #2284]
	bl	_effect_escape
	tbnz	w0, #0, LBB9_92
	b	LBB9_91
LBB9_91:
	adrp	x8, l_.str.44@PAGE
	add	x8, x8, l_.str.44@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_92:
	ldrh	w8, [sp, #2282]
	ldr	x9, [sp, #4600]
	strh	w8, [x9, #16]
	ldrb	w9, [sp, #2292]
	add	x8, sp, #2220
	strb	w9, [sp, #2220]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #2223]
	ldr	w8, [sp, #2296]
	str	w8, [sp, #2224]
	ldr	x8, [sp, #4600]
	str	x8, [sp, #424]                  ; 8-byte Folded Spill
	add	x0, sp, #2168
	str	x0, [sp, #408]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #416]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w9, [sp, #2220]
	strb	w9, [sp, #2168]
	mov	w9, #65535                      ; =0xffff
	str	w9, [sp, #404]                  ; 4-byte Folded Spill
	strh	w9, [sp, #2170]
	ldr	x9, [sp, #4600]
	ldr	x0, [x9]
	ldr	x1, [x8]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #408]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #416]                  ; 8-byte Folded Reload
	strb	w0, [sp, #2172]
	ldr	w9, [sp, #2224]
	str	w9, [sp, #2176]
	strh	w8, [sp, #2180]
	add	x0, sp, #2120
	str	x0, [sp, #432]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #424]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #432]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.54@PAGE
	add	x9, x9, l_.str.54@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_93:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #2338]
	b	LBB9_397
LBB9_94:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_95:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_96:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_97:
	ldr	x8, [sp, #4592]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.le	LBB9_99
	b	LBB9_98
LBB9_98:
	adrp	x8, l_.str.55@PAGE
	add	x8, x8, l_.str.55@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_99:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_100:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_102
	b	LBB9_101
LBB9_101:
	adrp	x8, l_.str.9@PAGE
	add	x8, x8, l_.str.9@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_102:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #8]
	str	w8, [sp, #2116]
	ldr	w8, [sp, #2116]
	ldr	x9, [sp, #4576]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB9_107
	b	LBB9_103
LBB9_103:
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #232]
	cbz	x8, LBB9_107
	b	LBB9_104
LBB9_104:
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #240]
	cbz	x8, LBB9_107
	b	LBB9_105
LBB9_105:
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #2116]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB9_107
	b	LBB9_106
LBB9_106:
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #2116]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #4576]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #2116]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB9_108
	b	LBB9_107
LBB9_107:
	adrp	x8, l_.str.56@PAGE
	add	x8, x8, l_.str.56@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_108:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_109:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	bl	_nvm_affine_region_begin
	adrp	x9, l_.str.57@PAGE
	add	x9, x9, l_.str.57@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_110:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	bl	_nvm_affine_region_end
	adrp	x9, l_.str.58@PAGE
	add	x9, x9, l_.str.58@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_111:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #4600]
	ldr	x0, [x9]
	ldr	x9, [sp, #4592]
	ldrh	w1, [x9, #8]
	ldr	x9, [sp, #4592]
	ldrh	w2, [x9, #16]
	ldrb	w9, [x8, #2339]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #30
	csinc	w3, w8, wzr, ne
	bl	_nvm_affine_reborrow
	adrp	x9, l_.str.59@PAGE
	add	x9, x9, l_.str.59@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_112:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w9, [x8, #2339]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #25
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	b.eq	LBB9_114
	b	LBB9_113
LBB9_113:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #29
	cset	w8, eq
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	b	LBB9_114
LBB9_114:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #400]                  ; 4-byte Folded Reload
	and	w9, w9, #0x1
	strb	w9, [sp, #2115]
	strh	wzr, [sp, #2112]
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #28
	b.eq	LBB9_116
	b	LBB9_115
LBB9_115:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #29
	b.ne	LBB9_118
	b	LBB9_116
LBB9_116:
	ldr	x0, [sp, #4576]
	ldr	x8, [sp, #4592]
	ldr	w1, [x8, #24]
	add	x2, sp, #4, lsl #12             ; =16384
	add	x2, x2, #520
	mov	w3, #32                         ; =0x20
	add	x4, sp, #2112
	bl	_nvm_ownership_path
	cbz	w0, LBB9_118
	b	LBB9_117
LBB9_117:
	adrp	x8, l_.str.60@PAGE
	add	x8, x8, l_.str.60@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_118:
	ldrb	w8, [sp, #2115]
	tbz	w8, #0, LBB9_121
	b	LBB9_119
LBB9_119:
	ldr	x0, [sp, #4600]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #16]
	bl	_observes_owner
	tbz	w0, #0, LBB9_121
	b	LBB9_120
LBB9_120:
	adrp	x8, l_.str.61@PAGE
	add	x8, x8, l_.str.61@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_121:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	ldr	x8, [sp, #4592]
	ldrh	w2, [x8, #16]
	ldrh	w4, [sp, #2112]
	ldrb	w9, [sp, #2115]
	mov	w8, #2                          ; =0x2
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w5, w8, wzr, ne
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #520
	bl	_nvm_affine_borrow
	adrp	x9, l_.str.62@PAGE
	add	x9, x9, l_.str.62@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_122:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #4600]
	ldr	x0, [x9]
	ldr	x9, [sp, #4592]
	ldrh	w1, [x9, #8]
	ldr	x9, [sp, #4592]
	ldrh	w2, [x9, #16]
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #27
	cset	w3, eq
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #462
	bl	_nvm_affine_reference_field
	tbnz	w0, #0, LBB9_124
	b	LBB9_123
LBB9_123:
	adrp	x8, l_.str.63@PAGE
	add	x8, x8, l_.str.63@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_124:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #27
	b.ne	LBB9_126
	b	LBB9_125
LBB9_125:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #4600]
	ldrb	w1, [x8, #2338]
	bl	_pop_scalar
	adrp	x9, l_.str.64@PAGE
	add	x9, x9, l_.str.64@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_126:
	b	LBB9_397
LBB9_127:
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #2102]
	ldr	x0, [sp, #4600]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	bl	_observes_owner
	tbz	w0, #0, LBB9_129
	b	LBB9_128
LBB9_128:
	adrp	x8, l_.str.65@PAGE
	add	x8, x8, l_.str.65@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_129:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	add	x2, sp, #2102
	bl	_nvm_affine_union_variant
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	add	x2, sp, #2104
	bl	_nvm_affine_take_local
	tbnz	w0, #0, LBB9_131
	b	LBB9_130
LBB9_130:
	adrp	x8, l_.str.66@PAGE
	add	x8, x8, l_.str.66@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_131:
	ldr	x8, [sp, #4600]
	str	x8, [sp, #384]                  ; 8-byte Folded Spill
	add	x0, sp, #2048
	str	x0, [sp, #368]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #376]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #368]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #376]                  ; 8-byte Folded Reload
	ldrb	w8, [sp, #2104]
	strb	w8, [sp, #2048]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #2050]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #2052]
	ldr	w8, [sp, #2108]
	str	w8, [sp, #2056]
	ldrh	w8, [sp, #2102]
	strh	w8, [sp, #2060]
	add	x0, sp, #2000
	str	x0, [sp, #392]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #384]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #392]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.67@PAGE
	add	x9, x9, l_.str.67@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_132:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_134
	b	LBB9_133
LBB9_133:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_135
	b	LBB9_134
LBB9_134:
	adrp	x8, l_.str.68@PAGE
	add	x8, x8, l_.str.68@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_135:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1952
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	ldrb	w9, [sp, #1952]
	add	x8, sp, #1944
	strb	w9, [sp, #1944]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #1947]
	ldr	w8, [sp, #1960]
	str	w8, [sp, #1948]
	ldr	x2, [sp, #1944]
	bl	_nvm_affine_put_local
	tbnz	w0, #0, LBB9_137
	b	LBB9_136
LBB9_136:
	adrp	x8, l_.str.69@PAGE
	add	x8, x8, l_.str.69@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_137:
	ldrb	w8, [sp, #1952]
	subs	w8, w8, #10
	b.ne	LBB9_141
	b	LBB9_138
LBB9_138:
	ldrh	w8, [sp, #1964]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB9_141
	b	LBB9_139
LBB9_139:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4592]
	ldrh	w1, [x8, #8]
	ldrh	w2, [sp, #1964]
	bl	_nvm_affine_union_refine
	tbnz	w0, #0, LBB9_141
	b	LBB9_140
LBB9_140:
	adrp	x8, l_.str.70@PAGE
	add	x8, x8, l_.str.70@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_141:
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_142:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #8]
	str	w8, [sp, #1936]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	add	x8, sp, #1928
	mov	w9, #8                          ; =0x8
	strb	w9, [sp, #1928]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #1931]
	ldr	w8, [sp, #1936]
	str	w8, [sp, #1932]
	ldr	x1, [sp, #1928]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB9_145
	b	LBB9_143
LBB9_143:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #1936]
	add	x2, sp, #3, lsl #12             ; =12288
	add	x2, x2, #2568
	mov	w3, #256                        ; =0x100
	add	x4, sp, #1942
	bl	_nvm_affine_record_fields
	tbz	w0, #0, LBB9_145
	b	LBB9_144
LBB9_144:
	ldrh	w8, [sp, #1942]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.le	LBB9_146
	b	LBB9_145
LBB9_145:
	adrp	x8, l_.str.71@PAGE
	add	x8, x8, l_.str.71@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_146:
	strh	wzr, [sp, #1926]
	b	LBB9_147
LBB9_147:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1926]
	ldrh	w9, [sp, #1942]
	subs	w8, w8, w9
	b.ge	LBB9_157
	b	LBB9_148
LBB9_148:                               ;   in Loop: Header=BB9_147 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #1942]
	subs	w8, w8, w9
	ldrh	w9, [sp, #1926]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1872
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrh	w8, [sp, #1926]
	mov	x9, x8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2568
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #1864]
	ldrb	w8, [sp, #1873]
	tbnz	w8, #0, LBB9_154
	b	LBB9_149
LBB9_149:                               ;   in Loop: Header=BB9_147 Depth=1
	ldrb	w8, [sp, #1872]
	ldrb	w9, [sp, #1864]
	subs	w8, w8, w9
	b.ne	LBB9_154
	b	LBB9_150
LBB9_150:                               ;   in Loop: Header=BB9_147 Depth=1
	ldrb	w8, [sp, #1876]
	and	w8, w8, #0x1
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #1864]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB9_154
	b	LBB9_151
LBB9_151:                               ;   in Loop: Header=BB9_147 Depth=1
	ldrb	w8, [sp, #1864]
	subs	w8, w8, #8
	b.eq	LBB9_153
	b	LBB9_152
LBB9_152:                               ;   in Loop: Header=BB9_147 Depth=1
	ldrb	w8, [sp, #1864]
	subs	w8, w8, #10
	b.ne	LBB9_155
	b	LBB9_153
LBB9_153:                               ;   in Loop: Header=BB9_147 Depth=1
	ldr	w8, [sp, #1880]
	ldr	w9, [sp, #1868]
	subs	w8, w8, w9
	b.eq	LBB9_155
	b	LBB9_154
LBB9_154:
	adrp	x8, l_.str.72@PAGE
	add	x8, x8, l_.str.72@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_155:                               ;   in Loop: Header=BB9_147 Depth=1
	b	LBB9_156
LBB9_156:                               ;   in Loop: Header=BB9_147 Depth=1
	ldrh	w8, [sp, #1926]
	add	w8, w8, #1
	strh	w8, [sp, #1926]
	b	LBB9_147
LBB9_157:
	ldrh	w10, [sp, #1942]
	ldr	x9, [sp, #4600]
	ldrh	w8, [x9, #16]
	subs	w8, w8, w10
	strh	w8, [x9, #16]
	ldr	x8, [sp, #4600]
	str	x8, [sp, #344]                  ; 8-byte Folded Spill
	add	x0, sp, #1816
	str	x0, [sp, #328]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #336]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #328]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #336]                  ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	strb	w8, [sp, #1816]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #1818]
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #1820]
	ldr	w9, [sp, #1936]
	str	w9, [sp, #1824]
	strh	w8, [sp, #1828]
	add	x0, sp, #1768
	str	x0, [sp, #352]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #344]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #352]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.67@PAGE
	add	x9, x9, l_.str.67@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_158:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #1756]
	ldr	x0, [sp, #4600]
	ldrh	w1, [sp, #1756]
	bl	_observes_owner
	tbz	w0, #0, LBB9_160
	b	LBB9_159
LBB9_159:
	adrp	x8, l_.str.73@PAGE
	add	x8, x8, l_.str.73@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_160:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #1756]
	add	x2, sp, #1760
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB9_164
	b	LBB9_161
LBB9_161:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #1756]
	add	x2, sp, #3, lsl #12             ; =12288
	add	x2, x2, #520
	mov	w3, #256                        ; =0x100
	add	x4, sp, #1758
	bl	_nvm_affine_owned_local_fields
	tbz	w0, #0, LBB9_164
	b	LBB9_162
LBB9_162:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #1758]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.hi	LBB9_164
	b	LBB9_163
LBB9_163:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #1756]
	add	x2, sp, #1760
	bl	_nvm_affine_take_local
	tbnz	w0, #0, LBB9_165
	b	LBB9_164
LBB9_164:
	adrp	x8, l_.str.74@PAGE
	add	x8, x8, l_.str.74@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_165:
	strh	wzr, [sp, #1754]
	b	LBB9_166
LBB9_166:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1754]
	ldrh	w9, [sp, #1758]
	subs	w8, w8, w9
	b.ge	LBB9_171
	b	LBB9_167
LBB9_167:                               ;   in Loop: Header=BB9_166 Depth=1
	ldr	x8, [sp, #4600]
	str	x8, [sp, #312]                  ; 8-byte Folded Spill
	add	x0, sp, #1704
	str	x0, [sp, #296]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #304]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldrh	w8, [sp, #1754]
	mov	x10, x8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #520
	str	x8, [sp, #280]                  ; 8-byte Folded Spill
	mov	x9, x8
	add	x9, x9, x10, lsl #3
	ldrb	w9, [x9]
	strb	w9, [sp, #1704]
	mov	w9, #65535                      ; =0xffff
	str	w9, [sp, #292]                  ; 4-byte Folded Spill
	strh	w9, [sp, #1706]
	ldr	x9, [sp, #4600]
	ldr	x0, [x9]
	ldrh	w9, [sp, #1754]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_nvm_affine_type_is_owned
	ldr	x9, [sp, #280]                  ; 8-byte Folded Reload
	ldr	w8, [sp, #292]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #296]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #304]                  ; 8-byte Folded Reload
	strb	w0, [sp, #1708]
	ldrh	w10, [sp, #1754]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	str	w9, [sp, #1712]
	strh	w8, [sp, #1716]
	add	x0, sp, #1656
	str	x0, [sp, #320]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #312]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #320]                  ; 8-byte Folded Reload
	bl	_push
	tbnz	w0, #0, LBB9_169
	b	LBB9_168
LBB9_168:
	adrp	x8, l_.str.75@PAGE
	add	x8, x8, l_.str.75@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_169:                               ;   in Loop: Header=BB9_166 Depth=1
	b	LBB9_170
LBB9_170:                               ;   in Loop: Header=BB9_166 Depth=1
	ldrh	w8, [sp, #1754]
	add	w8, w8, #1
	strh	w8, [sp, #1754]
	b	LBB9_166
LBB9_171:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_172:
	ldr	x8, [sp, #4592]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB9_190
	b	LBB9_173
LBB9_173:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #16]
	str	w8, [sp, #1652]
	strh	wzr, [sp, #1650]
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_179
	b	LBB9_174
LBB9_174:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #24]
	cbnz	w8, LBB9_179
	b	LBB9_175
LBB9_175:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #1652]
	bl	_nvm_affine_record_is_copyable
	tbz	w0, #0, LBB9_179
	b	LBB9_176
LBB9_176:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #1652]
	add	x2, sp, #2, lsl #12             ; =8192
	add	x2, x2, #2568
	mov	w3, #256                        ; =0x100
	add	x4, sp, #1650
	bl	_nvm_affine_record_fields
	tbz	w0, #0, LBB9_179
	b	LBB9_177
LBB9_177:
	ldrh	w8, [sp, #1650]
	ldr	x9, [sp, #4592]
	ldrh	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB9_179
	b	LBB9_178
LBB9_178:
	ldrh	w8, [sp, #1650]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.le	LBB9_180
	b	LBB9_179
LBB9_179:
	adrp	x8, l_.str.76@PAGE
	add	x8, x8, l_.str.76@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_180:
	strh	wzr, [sp, #1648]
	b	LBB9_181
LBB9_181:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1648]
	ldrh	w9, [sp, #1650]
	subs	w8, w8, w9
	b.ge	LBB9_189
	b	LBB9_182
LBB9_182:                               ;   in Loop: Header=BB9_181 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #1650]
	subs	w8, w8, w9
	ldrh	w9, [sp, #1648]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1600
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrb	w8, [sp, #1601]
	tbnz	w8, #0, LBB9_186
	b	LBB9_183
LBB9_183:                               ;   in Loop: Header=BB9_181 Depth=1
	ldrb	w8, [sp, #1604]
	tbnz	w8, #0, LBB9_186
	b	LBB9_184
LBB9_184:                               ;   in Loop: Header=BB9_181 Depth=1
	ldrb	w8, [sp, #1600]
	ldrh	w9, [sp, #1648]
                                        ; kill: def $x9 killed $w9
	lsl	x10, x9, #3
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #2568
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.ne	LBB9_186
	b	LBB9_185
LBB9_185:                               ;   in Loop: Header=BB9_181 Depth=1
	ldr	w8, [sp, #1608]
	ldrh	w9, [sp, #1648]
	mov	x10, x9
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #2568
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB9_187
	b	LBB9_186
LBB9_186:
	adrp	x8, l_.str.77@PAGE
	add	x8, x8, l_.str.77@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_187:                               ;   in Loop: Header=BB9_181 Depth=1
	b	LBB9_188
LBB9_188:                               ;   in Loop: Header=BB9_181 Depth=1
	ldrh	w8, [sp, #1648]
	add	w8, w8, #1
	strh	w8, [sp, #1648]
	b	LBB9_181
LBB9_189:
	ldrh	w10, [sp, #1650]
	ldr	x9, [sp, #4600]
	ldrh	w8, [x9, #16]
	subs	w8, w8, w10
	strh	w8, [x9, #16]
	ldr	x8, [sp, #4600]
	str	x8, [sp, #264]                  ; 8-byte Folded Spill
	add	x0, sp, #1552
	str	x0, [sp, #248]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #256]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #248]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #256]                  ; 8-byte Folded Reload
	mov	w8, #8                          ; =0x8
	strb	w8, [sp, #1552]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #1554]
	ldr	w9, [sp, #1652]
	str	w9, [sp, #1560]
	strh	w8, [sp, #1564]
	add	x0, sp, #1504
	str	x0, [sp, #272]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #264]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #272]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.78@PAGE
	add	x9, x9, l_.str.78@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_190:
	ldr	x8, [sp, #4592]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB9_192
	b	LBB9_191
LBB9_191:
	adrp	x8, l_.str.79@PAGE
	add	x8, x8, l_.str.79@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_192:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #24]
	strh	w8, [sp, #1490]
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #32]
	strh	w8, [sp, #1488]
	ldr	x0, [sp, #4576]
	ldr	x8, [sp, #4592]
	ldr	w1, [x8, #16]
	ldrh	w2, [sp, #1490]
	add	x3, sp, #1492
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB9_195
	b	LBB9_193
LBB9_193:
	ldrh	w8, [sp, #1488]
	ldrh	w9, [sp, #1502]
	subs	w8, w8, w9
	b.ne	LBB9_195
	b	LBB9_194
LBB9_194:
	ldrh	w8, [sp, #1488]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.le	LBB9_196
	b	LBB9_195
LBB9_195:
	adrp	x8, l_.str.80@PAGE
	add	x8, x8, l_.str.80@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_196:
	add	x5, sp, #1486
	strh	wzr, [sp, #1486]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #1492]
	ldrh	w2, [sp, #1490]
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #520
	mov	w4, #256                        ; =0x100
	bl	_nvm_affine_union_fields
	tbz	w0, #0, LBB9_198
	b	LBB9_197
LBB9_197:
	ldrh	w8, [sp, #1486]
	ldrh	w9, [sp, #1488]
	subs	w8, w8, w9
	b.eq	LBB9_199
	b	LBB9_198
LBB9_198:
	adrp	x8, l_.str.81@PAGE
	add	x8, x8, l_.str.81@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_199:
	strh	wzr, [sp, #1484]
	b	LBB9_200
LBB9_200:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #1484]
	ldrh	w9, [sp, #1488]
	subs	w8, w8, w9
	b.ge	LBB9_210
	b	LBB9_201
LBB9_201:                               ;   in Loop: Header=BB9_200 Depth=1
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #1488]
	subs	w8, w8, w9
	ldrh	w9, [sp, #1484]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1432
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrb	w8, [sp, #1433]
	tbnz	w8, #0, LBB9_207
	b	LBB9_202
LBB9_202:                               ;   in Loop: Header=BB9_200 Depth=1
	ldrb	w8, [sp, #1432]
	ldrh	w9, [sp, #1484]
                                        ; kill: def $x9 killed $w9
	lsl	x10, x9, #3
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #520
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.ne	LBB9_207
	b	LBB9_203
LBB9_203:                               ;   in Loop: Header=BB9_200 Depth=1
	ldrb	w8, [sp, #1436]
	and	w8, w8, #0x1
	str	w8, [sp, #244]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w8, [sp, #1484]
	mov	x9, x8
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #520
	ldr	x1, [x8, x9, lsl #3]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #244]                  ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB9_207
	b	LBB9_204
LBB9_204:                               ;   in Loop: Header=BB9_200 Depth=1
	ldrb	w8, [sp, #1432]
	subs	w8, w8, #8
	b.eq	LBB9_206
	b	LBB9_205
LBB9_205:                               ;   in Loop: Header=BB9_200 Depth=1
	ldrb	w8, [sp, #1432]
	subs	w8, w8, #10
	b.ne	LBB9_208
	b	LBB9_206
LBB9_206:                               ;   in Loop: Header=BB9_200 Depth=1
	ldr	w8, [sp, #1440]
	ldrh	w9, [sp, #1484]
	mov	x10, x9
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #520
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB9_208
	b	LBB9_207
LBB9_207:
	adrp	x8, l_.str.82@PAGE
	add	x8, x8, l_.str.82@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_208:                               ;   in Loop: Header=BB9_200 Depth=1
	b	LBB9_209
LBB9_209:                               ;   in Loop: Header=BB9_200 Depth=1
	ldrh	w8, [sp, #1484]
	add	w8, w8, #1
	strh	w8, [sp, #1484]
	b	LBB9_200
LBB9_210:
	ldrh	w10, [sp, #1488]
	ldr	x9, [sp, #4600]
	ldrh	w8, [x9, #16]
	subs	w8, w8, w10
	strh	w8, [x9, #16]
	ldr	x8, [sp, #4600]
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
	add	x0, sp, #1384
	str	x0, [sp, #208]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #216]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	mov	w9, #10                         ; =0xa
	strb	w9, [sp, #1384]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #1386]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	add	x8, sp, #1376
	strb	w9, [sp, #1376]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #1379]
	ldr	w8, [sp, #1492]
	str	w8, [sp, #1380]
	ldr	x1, [sp, #1376]
	bl	_nvm_affine_type_is_owned
	ldr	x1, [sp, #208]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #216]                  ; 8-byte Folded Reload
	strb	w0, [sp, #1388]
	ldr	w8, [sp, #1492]
	str	w8, [sp, #1392]
	ldrh	w8, [sp, #1490]
	strh	w8, [sp, #1396]
	add	x0, sp, #1328
	str	x0, [sp, #232]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #224]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #232]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.83@PAGE
	add	x9, x9, l_.str.83@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_211:
	ldr	x8, [sp, #4592]
	ldr	w8, [x8, #8]
	str	w8, [sp, #1324]
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_213
	b	LBB9_212
LBB9_212:
	ldr	w8, [sp, #1324]
	ldr	x9, [sp, #4560]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB9_214
	b	LBB9_213
LBB9_213:
	adrp	x8, l_.str.15@PAGE
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_214:
	ldr	x8, [sp, #4560]
	add	x8, x8, #8
	ldr	w9, [sp, #1324]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #1312]
	ldrb	w9, [sp, #1312]
	add	x8, sp, #1304
	strb	w9, [sp, #1304]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #1307]
	ldr	w8, [sp, #1316]
	str	w8, [sp, #1308]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #1304]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB9_216
	b	LBB9_215
LBB9_215:
	adrp	x8, l_.str.84@PAGE
	add	x8, x8, l_.str.84@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_216:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #18
	b.ne	LBB9_218
	b	LBB9_217
LBB9_217:
	ldr	x0, [sp, #4600]
	ldr	x1, [sp, #4560]
	ldr	w2, [sp, #4572]
	ldr	w3, [sp, #1324]
	mov	w4, #2                          ; =0x2
	bl	_global_require
	ldr	x8, [sp, #4600]
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	add	x0, sp, #1256
	str	x0, [sp, #176]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #184]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #184]                  ; 8-byte Folded Reload
	ldrb	w8, [sp, #1304]
	strb	w8, [sp, #1256]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #1258]
	ldr	w9, [sp, #1308]
	str	w9, [sp, #1264]
	strh	w8, [sp, #1268]
	add	x0, sp, #1208
	str	x0, [sp, #200]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #192]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #200]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.85@PAGE
	add	x9, x9, l_.str.85@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_218:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbnz	w8, LBB9_220
	b	LBB9_219
LBB9_219:
	adrp	x8, l_.str.86@PAGE
	add	x8, x8, l_.str.86@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_220:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #1160
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrb	w8, [sp, #1161]
	tbnz	w8, #0, LBB9_224
	b	LBB9_221
LBB9_221:
	ldrb	w8, [sp, #1164]
	tbnz	w8, #0, LBB9_224
	b	LBB9_222
LBB9_222:
	ldrb	w8, [sp, #1160]
	ldrb	w9, [sp, #1304]
	subs	w8, w8, w9
	b.ne	LBB9_224
	b	LBB9_223
LBB9_223:
	ldr	w8, [sp, #1168]
	ldr	w9, [sp, #1308]
	subs	w8, w8, w9
	b.eq	LBB9_225
	b	LBB9_224
LBB9_224:
	adrp	x8, l_.str.87@PAGE
	add	x8, x8, l_.str.87@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_225:
	ldrb	w8, [sp, #1313]
	tbnz	w8, #0, LBB9_227
	b	LBB9_226
LBB9_226:
	ldr	x0, [sp, #4600]
	ldr	x1, [sp, #4560]
	ldr	w2, [sp, #4572]
	ldr	w3, [sp, #1324]
	mov	w4, #1                          ; =0x1
	bl	_global_require
	b	LBB9_227
LBB9_227:
	ldr	x8, [sp, #4600]
	add	x8, x8, #22
	ldr	w9, [sp, #1324]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	mov	w1, #10                         ; =0xa
	bl	_nvm_affine_global_compose
	ldr	x8, [sp, #4600]
	add	x8, x8, #22
	ldr	w9, [sp, #1324]
                                        ; kill: def $x9 killed $w9
	strb	w0, [x8, x9]
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_228:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #4554]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #462
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #461
	bl	_nvm_affine_local_info
	tbnz	w0, #0, LBB9_230
	b	LBB9_229
LBB9_229:
	adrp	x8, l_.str.88@PAGE
	add	x8, x8, l_.str.88@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_230:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [sp, #1156]
	mov	w9, #65535                      ; =0xffff
	strh	w9, [sp, #1154]
	ldrb	w9, [x8, #2338]
	subs	w9, w9, #8
	cset	w9, eq
	strb	w9, [sp, #1153]
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #8
	b.ne	LBB9_237
	b	LBB9_231
LBB9_231:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2337]
	cbnz	w8, LBB9_237
	b	LBB9_232
LBB9_232:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1144
	bl	_nvm_affine_local_type
	tbnz	w0, #0, LBB9_234
	b	LBB9_233
LBB9_233:
	adrp	x8, l_.str.89@PAGE
	add	x8, x8, l_.str.89@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_234:
	ldr	w8, [sp, #1148]
	str	w8, [sp, #1156]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #1156]
	bl	_nvm_affine_record_is_copyable
	tbz	w0, #0, LBB9_236
	b	LBB9_235
LBB9_235:
	strb	wzr, [sp, #1153]
	b	LBB9_236
LBB9_236:
	b	LBB9_237
LBB9_237:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #7
	b.ne	LBB9_241
	b	LBB9_238
LBB9_238:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1136
	bl	_nvm_affine_local_type
	tbnz	w0, #0, LBB9_240
	b	LBB9_239
LBB9_239:
	adrp	x8, l_.str.90@PAGE
	add	x8, x8, l_.str.90@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_240:
	ldr	w8, [sp, #1140]
	str	w8, [sp, #1156]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #1136]
	bl	_nvm_affine_type_is_owned
	strb	w0, [sp, #1153]
	b	LBB9_241
LBB9_241:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	subs	w8, w8, #10
	b.ne	LBB9_247
	b	LBB9_242
LBB9_242:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1128
	bl	_nvm_affine_local_type
	tbnz	w0, #0, LBB9_244
	b	LBB9_243
LBB9_243:
	adrp	x8, l_.str.91@PAGE
	add	x8, x8, l_.str.91@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_244:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #1128]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB9_246
	b	LBB9_245
LBB9_245:
	adrp	x8, l_.str.92@PAGE
	add	x8, x8, l_.str.92@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_246:
	ldr	w8, [sp, #1132]
	str	w8, [sp, #1156]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1154
	bl	_nvm_affine_union_variant
	b	LBB9_247
LBB9_247:
	ldr	x8, [sp, #4600]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	add	x0, sp, #1080
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #152]                  ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #152]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	strb	w8, [sp, #1080]
	ldrb	w8, [sp, #1153]
	and	w8, w8, #0x1
	strb	w8, [sp, #1081]
	ldrh	w8, [sp, #4554]
	strh	w8, [sp, #1082]
	ldr	w8, [sp, #1156]
	str	w8, [sp, #1088]
	ldrh	w8, [sp, #1154]
	strh	w8, [sp, #1092]
	add	x0, sp, #1032
	str	x0, [sp, #168]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #168]                  ; 8-byte Folded Reload
	bl	_push
	tbnz	w0, #0, LBB9_249
	b	LBB9_248
LBB9_248:
	adrp	x8, l_.str.93@PAGE
	add	x8, x8, l_.str.93@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_249:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_250:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #4554]
	ldrh	w8, [sp, #4554]
	ldrh	w9, [sp, #4590]
	subs	w8, w8, w9
	b.ge	LBB9_254
	b	LBB9_251
LBB9_251:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_254
	b	LBB9_252
LBB9_252:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_254
	b	LBB9_253
LBB9_253:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbz	w8, #0, LBB9_255
	b	LBB9_254
LBB9_254:
	adrp	x8, l_.str.94@PAGE
	add	x8, x8, l_.str.94@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_255:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #984
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrb	w0, [sp, #984]
	bl	_scalar
	tbz	w0, #0, LBB9_257
	b	LBB9_256
LBB9_256:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	bl	_nvm_affine_scalar_define
	str	w0, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB9_274
LBB9_257:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_260
	b	LBB9_258
LBB9_258:
	ldrb	w8, [sp, #984]
	subs	w8, w8, #5
	b.ne	LBB9_260
	b	LBB9_259
LBB9_259:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	bl	_nvm_affine_string_define
	str	w0, [sp, #136]                  ; 4-byte Folded Spill
	b	LBB9_273
LBB9_260:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_263
	b	LBB9_261
LBB9_261:
	ldrb	w8, [sp, #984]
	subs	w8, w8, #10
	b.ne	LBB9_263
	b	LBB9_262
LBB9_262:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	ldr	w2, [sp, #992]
	ldrh	w3, [sp, #996]
	bl	_nvm_affine_union_define
	str	w0, [sp, #132]                  ; 4-byte Folded Spill
	b	LBB9_272
LBB9_263:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_266
	b	LBB9_264
LBB9_264:
	ldrb	w8, [sp, #984]
	subs	w8, w8, #8
	b.ne	LBB9_266
	b	LBB9_265
LBB9_265:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	ldr	w2, [sp, #992]
	bl	_nvm_affine_record_define
	str	w0, [sp, #128]                  ; 4-byte Folded Spill
	b	LBB9_271
LBB9_266:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_269
	b	LBB9_267
LBB9_267:
	ldrb	w8, [sp, #984]
	subs	w8, w8, #7
	b.ne	LBB9_269
	b	LBB9_268
LBB9_268:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	ldr	w2, [sp, #992]
	bl	_nvm_affine_array_define
	str	w0, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB9_270
LBB9_269:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #124]                  ; 4-byte Folded Spill
	b	LBB9_270
LBB9_270:
	ldr	w8, [sp, #124]                  ; 4-byte Folded Reload
	str	w8, [sp, #128]                  ; 4-byte Folded Spill
	b	LBB9_271
LBB9_271:
	ldr	w8, [sp, #128]                  ; 4-byte Folded Reload
	str	w8, [sp, #132]                  ; 4-byte Folded Spill
	b	LBB9_272
LBB9_272:
	ldr	w8, [sp, #132]                  ; 4-byte Folded Reload
	str	w8, [sp, #136]                  ; 4-byte Folded Spill
	b	LBB9_273
LBB9_273:
	ldr	w8, [sp, #136]                  ; 4-byte Folded Reload
	str	w8, [sp, #140]                  ; 4-byte Folded Spill
	b	LBB9_274
LBB9_274:
	ldr	w8, [sp, #140]                  ; 4-byte Folded Reload
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #983]
	ldrb	w8, [sp, #983]
	tbz	w8, #0, LBB9_277
	b	LBB9_275
LBB9_275:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldrh	w1, [sp, #4554]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #462
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #461
	bl	_nvm_affine_local_info
	tbz	w0, #0, LBB9_277
	b	LBB9_276
LBB9_276:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	ldrb	w9, [sp, #984]
	subs	w8, w8, w9
	b.eq	LBB9_278
	b	LBB9_277
LBB9_277:
	adrp	x8, l_.str.95@PAGE
	add	x8, x8, l_.str.95@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_278:
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_279:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_282
	b	LBB9_280
LBB9_280:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB9_282
	b	LBB9_281
LBB9_281:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB9_283
	b	LBB9_282
LBB9_282:
	adrp	x8, l_.str.96@PAGE
	add	x8, x8, l_.str.96@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_283:
	ldr	x0, [sp, #4576]
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldr	w1, [x8, #8]
	ldr	x8, [sp, #4592]
	ldrh	w2, [x8, #8]
	add	x3, sp, #968
	bl	_union_fact_for_layout
	tbnz	w0, #0, LBB9_285
	b	LBB9_284
LBB9_284:
	adrp	x8, l_.str.97@PAGE
	add	x8, x8, l_.str.97@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_285:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_286:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_290
	b	LBB9_287
LBB9_287:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB9_290
	b	LBB9_288
LBB9_288:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_290
	b	LBB9_289
LBB9_289:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbz	w8, #0, LBB9_291
	b	LBB9_290
LBB9_290:
	adrp	x8, l_.str.98@PAGE
	add	x8, x8, l_.str.98@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_291:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #4600]
	ldrh	w11, [x10, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w11, uxth
	strh	w8, [x10, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_292:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_303
	b	LBB9_293
LBB9_293:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.ne	LBB9_303
	b	LBB9_294
LBB9_294:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_303
	b	LBB9_295
LBB9_295:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_303
	b	LBB9_296
LBB9_296:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #920
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	strh	wzr, [sp, #918]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #928]
	bl	_nvm_affine_record_is_copyable
	tbz	w0, #0, LBB9_299
	b	LBB9_297
LBB9_297:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #928]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2568
	mov	w3, #256                        ; =0x100
	add	x4, sp, #918
	bl	_nvm_affine_record_fields
	tbz	w0, #0, LBB9_299
	b	LBB9_298
LBB9_298:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	ldrh	w9, [sp, #918]
	subs	w8, w8, w9
	b.lt	LBB9_300
	b	LBB9_299
LBB9_299:
	adrp	x8, l_.str.99@PAGE
	add	x8, x8, l_.str.99@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_300:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2568
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #904]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x1, [sp, #904]
	bl	_nvm_affine_type_is_owned
	tbz	w0, #0, LBB9_302
	b	LBB9_301
LBB9_301:
	adrp	x8, l_.str.100@PAGE
	add	x8, x8, l_.str.100@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_302:
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #65535                      ; =0xffff
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
	ldr	x8, [sp, #4600]
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	x0, sp, #856
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #96]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #96]                   ; 8-byte Folded Reload
	ldrb	w9, [sp, #904]
	strb	w9, [sp, #856]
	strh	w8, [sp, #858]
	ldr	w9, [sp, #908]
	str	w9, [sp, #864]
	strh	w8, [sp, #868]
	add	x0, sp, #808
	str	x0, [sp, #112]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #112]                  ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.101@PAGE
	add	x9, x9, l_.str.101@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_303:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_316
	b	LBB9_304
LBB9_304:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB9_316
	b	LBB9_305
LBB9_305:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_316
	b	LBB9_306
LBB9_306:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_316
	b	LBB9_307
LBB9_307:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #760
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrh	w8, [sp, #772]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB9_309
	b	LBB9_308
LBB9_308:
	adrp	x8, l_.str.102@PAGE
	add	x8, x8, l_.str.102@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_309:
	add	x5, sp, #758
	strh	wzr, [sp, #758]
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	w1, [sp, #768]
	ldrh	w2, [sp, #772]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #520
	mov	w4, #256                        ; =0x100
	bl	_nvm_affine_union_fields
	tbz	w0, #0, LBB9_311
	b	LBB9_310
LBB9_310:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	ldrh	w9, [sp, #758]
	subs	w8, w8, w9
	b.lt	LBB9_312
	b	LBB9_311
LBB9_311:
	adrp	x8, l_.str.103@PAGE
	add	x8, x8, l_.str.103@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_312:
	ldr	x8, [sp, #4592]
	ldrh	w8, [x8, #8]
	mov	x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #520
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #744]
	ldrb	w0, [sp, #744]
	bl	_scalar
	tbnz	w0, #0, LBB9_315
	b	LBB9_313
LBB9_313:
	ldrb	w8, [sp, #744]
	subs	w8, w8, #5
	b.eq	LBB9_315
	b	LBB9_314
LBB9_314:
	adrp	x8, l_.str.104@PAGE
	add	x8, x8, l_.str.104@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_315:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [sp, #744]
	strb	w8, [x9, #2338]
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
	b	LBB9_397
LBB9_316:
	b	LBB9_317
LBB9_317:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_323
	b	LBB9_318
LBB9_318:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB9_323
	b	LBB9_319
LBB9_319:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_323
	b	LBB9_320
LBB9_320:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrh	w1, [x8, #2]
	ldr	x8, [sp, #4592]
	ldrh	w2, [x8, #8]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #462
	bl	_nvm_affine_scalar_field
	tbnz	w0, #0, LBB9_324
	b	LBB9_321
LBB9_321:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_323
	b	LBB9_322
LBB9_322:
	ldr	x8, [sp, #4600]
	ldr	x0, [x8]
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrh	w1, [x8, #2]
	ldr	x8, [sp, #4592]
	ldrh	w2, [x8, #8]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #462
	bl	_nvm_affine_string_field
	tbnz	w0, #0, LBB9_324
	b	LBB9_323
LBB9_323:
	adrp	x8, l_.str.105@PAGE
	add	x8, x8, l_.str.105@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_324:
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
	b	LBB9_397
LBB9_325:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_328
	b	LBB9_326
LBB9_326:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_328
	b	LBB9_327
LBB9_327:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbz	w8, #0, LBB9_329
	b	LBB9_328
LBB9_328:
	adrp	x8, l_.str.106@PAGE
	add	x8, x8, l_.str.106@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_329:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_332
	b	LBB9_330
LBB9_330:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB9_332
	b	LBB9_331
LBB9_331:
	adrp	x8, l_.str.107@PAGE
	add	x8, x8, l_.str.107@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_332:
	ldr	x8, [sp, #4600]
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #696
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	bl	_push
	tbnz	w0, #0, LBB9_334
	b	LBB9_333
LBB9_333:
	adrp	x8, l_.str.93@PAGE
	add	x8, x8, l_.str.93@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_334:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_335:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_338
	b	LBB9_336
LBB9_336:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_338
	b	LBB9_337
LBB9_337:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbz	w8, #0, LBB9_339
	b	LBB9_338
LBB9_338:
	adrp	x8, l_.str.108@PAGE
	add	x8, x8, l_.str.108@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_339:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_342
	b	LBB9_340
LBB9_340:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB9_342
	b	LBB9_341
LBB9_341:
	adrp	x8, l_.str.109@PAGE
	add	x8, x8, l_.str.109@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_342:
	ldr	x9, [sp, #4600]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_343:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	b.lt	LBB9_348
	b	LBB9_344
LBB9_344:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_348
	b	LBB9_345
LBB9_345:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_348
	b	LBB9_346
LBB9_346:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_348
	b	LBB9_347
LBB9_347:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbz	w8, #0, LBB9_349
	b	LBB9_348
LBB9_348:
	adrp	x8, l_.str.110@PAGE
	add	x8, x8, l_.str.110@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_349:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_353
	b	LBB9_350
LBB9_350:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.eq	LBB9_352
	b	LBB9_351
LBB9_351:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #2
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB9_353
	b	LBB9_352
LBB9_352:
	adrp	x8, l_.str.111@PAGE
	add	x8, x8, l_.str.111@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_353:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #648
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #56]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x0, w8, w9, x10
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	bl	_memcpy
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #2
	mov	w9, #48                         ; =0x30
	smaddl	x0, w8, w9, x10
	bl	_memcpy
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #4608]
	b	LBB9_398
LBB9_354:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB9_356
	b	LBB9_355
LBB9_355:
	adrp	x8, l_.str.10@PAGE
	add	x8, x8, l_.str.10@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_356:
	ldr	x0, [sp, #4600]
	mov	w1, #5                          ; =0x5
	bl	_pop_scalar
	adrp	x9, l_.str.112@PAGE
	add	x9, x9, l_.str.112@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_357:
	ldr	x0, [sp, #4600]
	mov	w1, #4                          ; =0x4
	bl	_pop_scalar
	adrp	x9, l_.str.113@PAGE
	add	x9, x9, l_.str.113@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_358:
	ldr	x0, [sp, #4600]
	mov	w1, #4                          ; =0x4
	bl	_pop_scalar
	adrp	x9, l_.str.114@PAGE
	add	x9, x9, l_.str.114@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_359:
	ldr	x0, [sp, #4600]
	mov	w1, #4                          ; =0x4
	bl	_pop_scalar
	tbz	w0, #0, LBB9_362
	b	LBB9_360
LBB9_360:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #50
	b.eq	LBB9_363
	b	LBB9_361
LBB9_361:
	ldr	x0, [sp, #4600]
	mov	w1, #4                          ; =0x4
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_363
	b	LBB9_362
LBB9_362:
	adrp	x8, l_.str.115@PAGE
	add	x8, x8, l_.str.115@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_363:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_364:
	ldr	x0, [sp, #4600]
	mov	w1, #1                          ; =0x1
	bl	_pop_scalar
	tbz	w0, #0, LBB9_367
	b	LBB9_365
LBB9_365:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #37
	b.eq	LBB9_368
	b	LBB9_366
LBB9_366:
	ldr	x0, [sp, #4600]
	mov	w1, #1                          ; =0x1
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_368
	b	LBB9_367
LBB9_367:
	adrp	x8, l_.str.116@PAGE
	add	x8, x8, l_.str.116@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_368:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_369:
	ldr	x0, [sp, #4600]
	mov	w1, #3                          ; =0x3
	bl	_pop_scalar
	tbz	w0, #0, LBB9_372
	b	LBB9_370
LBB9_370:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #204
	b.eq	LBB9_373
	b	LBB9_371
LBB9_371:
	ldr	x0, [sp, #4600]
	mov	w1, #3                          ; =0x3
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_373
	b	LBB9_372
LBB9_372:
	adrp	x8, l_.str.117@PAGE
	add	x8, x8, l_.str.117@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_373:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_374:
	ldr	x0, [sp, #4600]
	mov	w1, #3                          ; =0x3
	bl	_pop_scalar
	tbz	w0, #0, LBB9_376
	b	LBB9_375
LBB9_375:
	ldr	x0, [sp, #4600]
	mov	w1, #3                          ; =0x3
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_377
	b	LBB9_376
LBB9_376:
	adrp	x8, l_.str.118@PAGE
	add	x8, x8, l_.str.118@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_377:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_378:
	ldr	x8, [sp, #4560]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB9_387
	b	LBB9_379
LBB9_379:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #40
	b.eq	LBB9_381
	b	LBB9_380
LBB9_380:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldrb	w8, [x8, #2339]
	subs	w8, w8, #41
	b.ne	LBB9_387
	b	LBB9_381
LBB9_381:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_387
	b	LBB9_382
LBB9_382:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	subs	w8, w8, #5
	b.ne	LBB9_387
	b	LBB9_383
LBB9_383:
	ldr	x0, [sp, #4600]
	mov	w1, #5                          ; =0x5
	bl	_pop_scalar
	tbz	w0, #0, LBB9_385
	b	LBB9_384
LBB9_384:
	ldr	x0, [sp, #4600]
	mov	w1, #5                          ; =0x5
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_386
	b	LBB9_385
LBB9_385:
	adrp	x8, l_.str.119@PAGE
	add	x8, x8, l_.str.119@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_386:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_387:
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB9_391
	b	LBB9_388
LBB9_388:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB9_391
	b	LBB9_389
LBB9_389:
	ldr	x8, [sp, #4600]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #4600]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB9_391
	b	LBB9_390
LBB9_390:
	ldr	x8, [sp, #4600]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w0, [x8, x9]
	bl	_scalar
	tbnz	w0, #0, LBB9_392
	b	LBB9_391
LBB9_391:
	adrp	x8, l_.str.120@PAGE
	add	x8, x8, l_.str.120@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_392:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #4600]
	ldr	x11, [x9, #8]
	ldr	x9, [sp, #4600]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smaddl	x9, w9, w10, x11
	ldrb	w9, [x9]
	strb	w9, [x8, #2338]
	ldr	x0, [sp, #4600]
	ldrb	w1, [x8, #2338]
	bl	_pop_scalar
	tbz	w0, #0, LBB9_394
	b	LBB9_393
LBB9_393:
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #4600]
	ldrb	w1, [x8, #2338]
	bl	_pop_scalar
	tbnz	w0, #0, LBB9_395
	b	LBB9_394
LBB9_394:
	adrp	x8, l_.str.121@PAGE
	add	x8, x8, l_.str.121@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_395:
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	strb	w8, [x9, #2338]
	b	LBB9_397
LBB9_396:
	adrp	x8, l_.str.11@PAGE
	add	x8, x8, l_.str.11@PAGEOFF
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_397:
	ldr	x8, [sp, #4600]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	add	x0, sp, #600
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #2338]
	strb	w8, [sp, #600]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #602]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [sp, #608]
	strh	w8, [sp, #612]
	add	x0, sp, #552
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_push
	adrp	x9, l_.str.93@PAGE
	add	x9, x9, l_.str.93@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	str	x8, [sp, #4608]
	b	LBB9_398
LBB9_398:
	ldr	x8, [sp, #4608]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB9_400
	b	LBB9_399
LBB9_399:
	bl	___stack_chk_fail
LBB9_400:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #1072
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh6, Lloh7
	.cfi_endproc
	.p2align	2
lJTI9_0:
	.long	LBB9_3-Ltmp3
	.long	LBB9_94-Ltmp3
	.long	LBB9_96-Ltmp3
	.long	LBB9_97-Ltmp3
	.long	LBB9_100-Ltmp3
	.long	LBB9_93-Ltmp3
	.long	LBB9_95-Ltmp3
	.long	LBB9_325-Ltmp3
	.long	LBB9_335-Ltmp3
	.long	LBB9_343-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_127-Ltmp3
	.long	LBB9_132-Ltmp3
	.long	LBB9_142-Ltmp3
	.long	LBB9_158-Ltmp3
	.long	LBB9_55-Ltmp3
	.long	LBB9_228-Ltmp3
	.long	LBB9_250-Ltmp3
	.long	LBB9_211-Ltmp3
	.long	LBB9_211-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_109-Ltmp3
	.long	LBB9_110-Ltmp3
	.long	LBB9_112-Ltmp3
	.long	LBB9_112-Ltmp3
	.long	LBB9_122-Ltmp3
	.long	LBB9_122-Ltmp3
	.long	LBB9_112-Ltmp3
	.long	LBB9_112-Ltmp3
	.long	LBB9_111-Ltmp3
	.long	LBB9_111-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_364-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_378-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_359-Ltmp3
	.long	LBB9_359-Ltmp3
	.long	LBB9_359-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_3-Ltmp3
	.long	LBB9_358-Ltmp3
	.long	LBB9_358-Ltmp3
	.long	LBB9_4-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_2-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_317-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_279-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_354-Ltmp3
	.long	LBB9_357-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_3-Ltmp3
	.long	LBB9_354-Ltmp3
	.long	LBB9_67-Ltmp3
	.long	LBB9_68-Ltmp3
	.long	LBB9_71-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_369-Ltmp3
	.long	LBB9_369-Ltmp3
	.long	LBB9_369-Ltmp3
	.long	LBB9_369-Ltmp3
	.long	LBB9_369-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_374-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_172-Ltmp3
	.long	LBB9_292-Ltmp3
	.long	LBB9_396-Ltmp3
	.long	LBB9_286-Ltmp3
                                        ; -- End function
	.p2align	2                               ; -- Begin function frame_free
_frame_free:                            ; @frame_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	b	LBB10_3
LBB10_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB10_3
LBB10_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function propagate
_propagate:                             ; @propagate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	str	x4, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #15]
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB11_20
	b	LBB11_1
LBB11_1:
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w8, [x8, #278]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #278]
	subs	w8, w8, w9
	b.ne	LBB11_5
	b	LBB11_2
LBB11_2:
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w8, [x8, #280]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #280]
	subs	w8, w8, w9
	b.ne	LBB11_5
	b	LBB11_3
LBB11_3:
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	w8, [x8, #284]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #284]
	subs	w8, w8, w9
	b.ne	LBB11_5
	b	LBB11_4
LBB11_4:
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x0, x8, #288
	ldr	x8, [sp, #32]
	add	x1, x8, #288
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #278]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	_memcmp
	cbz	w0, LBB11_6
	b	LBB11_5
LBB11_5:
	ldr	x9, [sp, #16]
	adrp	x8, l_.str.140@PAGE
	add	x8, x8, l_.str.140@PAGEOFF
	str	x8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_6:
	add	x2, sp, #14
	strb	wzr, [sp, #14]
	strb	wzr, [sp, #13]
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x1, [sp, #32]
	bl	_stack_meet
	tbz	w0, #0, LBB11_8
	b	LBB11_7
LBB11_7:
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x0, [x8]
	ldr	x8, [sp, #32]
	ldr	x1, [x8]
	add	x2, sp, #13
	bl	_nvm_affine_state_meet_initialization
	tbnz	w0, #0, LBB11_9
	b	LBB11_8
LBB11_8:
	ldr	x9, [sp, #16]
	adrp	x8, l_.str.141@PAGE
	add	x8, x8, l_.str.141@PAGEOFF
	str	x8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_9:
	ldrb	w8, [sp, #14]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbnz	w8, #0, LBB11_11
	b	LBB11_10
LBB11_10:
	ldrb	w8, [sp, #13]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB11_11
LBB11_11:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w8, [x8, #20]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #20]
	subs	w8, w8, w9
	b.eq	LBB11_13
	b	LBB11_12
LBB11_12:
	ldr	x9, [sp, #16]
	adrp	x8, l_.str.142@PAGE
	add	x8, x8, l_.str.142@PAGEOFF
	str	x8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_13:
	strh	wzr, [sp, #10]
	b	LBB11_14
LBB11_14:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #20]
	subs	w8, w8, w9
	b.ge	LBB11_19
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_14 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x8, x8, #22
	ldrh	w9, [sp, #10]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldr	x9, [sp, #32]
	add	x9, x9, #22
	ldrh	w10, [sp, #10]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	orr	w8, w8, w9
	strb	w8, [sp, #9]
	ldrb	w8, [sp, #9]
	ldur	x9, [x29, #-16]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	add	x9, x9, #22
	ldrh	w10, [sp, #10]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB11_17
	b	LBB11_16
LBB11_16:                               ;   in Loop: Header=BB11_14 Depth=1
	ldrb	w8, [sp, #9]
	ldur	x9, [x29, #-16]
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	add	x9, x9, #22
	ldrh	w10, [sp, #10]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #15]
	b	LBB11_17
LBB11_17:                               ;   in Loop: Header=BB11_14 Depth=1
	b	LBB11_18
LBB11_18:                               ;   in Loop: Header=BB11_14 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB11_14
LBB11_19:
	b	LBB11_23
LBB11_20:
	ldr	x0, [sp, #32]
	bl	_frame_clone
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	str	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB11_22
	b	LBB11_21
LBB11_21:
	ldr	x9, [sp, #16]
	adrp	x8, l_.str.143@PAGE
	add	x8, x8, l_.str.143@PAGEOFF
	str	x8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_22:
	b	LBB11_23
LBB11_23:
	ldrb	w8, [sp, #15]
	tbz	w8, #0, LBB11_26
	b	LBB11_24
LBB11_24:
	ldr	x0, [sp, #24]
	ldur	w1, [x29, #-20]
	bl	_enqueue
	tbnz	w0, #0, LBB11_26
	b	LBB11_25
LBB11_25:
	ldr	x9, [sp, #16]
	adrp	x8, l_.str.144@PAGE
	add	x8, x8, l_.str.144@PAGEOFF
	str	x8, [x9]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_26:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_27
LBB11_27:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function match_refine
_match_refine:                          ; @match_refine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x8, [sp, #16]
	cbz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	cbnz	w8, LBB12_3
	b	LBB12_2
LBB12_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_9
LBB12_3:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	str	x8, [sp]
	ldr	x8, [sp]
	ldrb	w8, [x8]
	subs	w8, w8, #10
	b.ne	LBB12_7
	b	LBB12_4
LBB12_4:
	ldr	x8, [sp]
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB12_7
	b	LBB12_5
LBB12_5:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB12_8
	b	LBB12_6
LBB12_6:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.eq	LBB12_8
	b	LBB12_7
LBB12_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_9
LBB12_8:
	ldrh	w8, [sp, #14]
	ldr	x9, [sp]
	strh	w8, [x9, #12]
	ldr	x8, [sp]
	add	x0, x8, #16
	mov	w1, #0                          ; =0x0
	mov	x2, #32                         ; =0x20
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_9
LBB12_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function union_fact_for_layout
_union_fact_for_layout:                 ; @union_fact_for_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	str	x3, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB13_3
	b	LBB13_2
LBB13_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_12
LBB13_3:
	str	wzr, [sp, #12]
	b	LBB13_4
LBB13_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.hs	LBB13_11
	b	LBB13_5
LBB13_5:                                ;   in Loop: Header=BB13_4 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #12]
	ldurh	w2, [x29, #-22]
	mov	x3, sp
	bl	_nvm_ownership_union_variant
	cbz	w0, LBB13_7
	b	LBB13_6
LBB13_6:                                ;   in Loop: Header=BB13_4 Depth=1
	b	LBB13_10
LBB13_7:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	w8, [sp]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB13_9
	b	LBB13_8
LBB13_8:
	ldr	x9, [sp, #16]
	ldr	x8, [sp]
	str	x8, [x9]
	ldr	w8, [sp, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_12
LBB13_9:                                ;   in Loop: Header=BB13_4 Depth=1
	b	LBB13_10
LBB13_10:                               ;   in Loop: Header=BB13_4 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB13_4
LBB13_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB13_12
LBB13_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_step
_array_step:                            ; @array_step
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #496
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	w3, [x29, #-52]
	stur	w4, [x29, #-56]
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8]
	sturb	w8, [x29, #-57]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	bl	_nvm_affine_has_array_types
	tbnz	w0, #0, LBB14_2
	b	LBB14_1
LBB14_1:
	adrp	x8, l_.str.122@PAGE
	add	x8, x8, l_.str.122@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_2:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #80
	b.eq	LBB14_4
	b	LBB14_3
LBB14_3:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #88
	b.ne	LBB14_32
	b	LBB14_4
LBB14_4:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #88
	b.ne	LBB14_6
	b	LBB14_5
LBB14_5:
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b	LBB14_7
LBB14_6:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b	LBB14_7
LBB14_7:
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	sturh	w8, [x29, #-82]
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #8]
	sturb	w8, [x29, #-83]
	ldurh	w8, [x29, #-82]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.le	LBB14_9
	b	LBB14_8
LBB14_8:
	adrp	x8, l_.str.123@PAGE
	add	x8, x8, l_.str.123@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_9:
	ldurh	w8, [x29, #-82]
	cbnz	w8, LBB14_21
	b	LBB14_10
LBB14_10:
	ldur	x0, [x29, #-48]
	ldur	w1, [x29, #-52]
	ldur	w2, [x29, #-56]
	sub	x3, x29, #88
	bl	_nvm_ownership_array_constructor
	cbz	w0, LBB14_12
	b	LBB14_11
LBB14_11:
	adrp	x8, l_.str.124@PAGE
	add	x8, x8, l_.str.124@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_12:
	ldur	w8, [x29, #-88]
	adds	w8, w8, #1
	b.eq	LBB14_17
	b	LBB14_13
LBB14_13:
	sub	x8, x29, #96
	mov	w9, #7                          ; =0x7
	sturb	w9, [x29, #-96]
	add	x8, x8, #1
	strh	wzr, [x8]
	sturb	wzr, [x29, #-93]
	ldur	w8, [x29, #-88]
	stur	w8, [x29, #-92]
	ldur	x8, [x29, #-96]
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldur	x1, [x29, #-72]
	sub	x2, x29, #80
	bl	_nvm_affine_array_element
	tbz	w0, #0, LBB14_15
	b	LBB14_14
LBB14_14:
	ldurb	w8, [x29, #-80]
	ldurb	w9, [x29, #-83]
	subs	w8, w8, w9
	b.eq	LBB14_16
	b	LBB14_15
LBB14_15:
	adrp	x8, l_.str.125@PAGE
	add	x8, x8, l_.str.125@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_16:
	b	LBB14_20
LBB14_17:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldurb	w1, [x29, #-83]
	sub	x2, x29, #72
	bl	_nvm_affine_array_tag_type
	tbnz	w0, #0, LBB14_19
	b	LBB14_18
LBB14_18:
	adrp	x8, l_.str.126@PAGE
	add	x8, x8, l_.str.126@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_19:
	b	LBB14_20
LBB14_20:
	b	LBB14_31
LBB14_21:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	sub	x0, x29, #144
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldurb	w9, [x29, #-144]
	sub	x8, x29, #152
	sturb	w9, [x29, #-152]
	add	x8, x8, #1
	strh	wzr, [x8]
	sturb	wzr, [x29, #-149]
	ldur	w8, [x29, #-136]
	stur	w8, [x29, #-148]
	ldur	x8, [x29, #-152]
	stur	x8, [x29, #-80]
	ldurb	w8, [x29, #-80]
	ldurb	w9, [x29, #-83]
	subs	w8, w8, w9
	b.ne	LBB14_23
	b	LBB14_22
LBB14_22:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldur	x1, [x29, #-80]
	sub	x2, x29, #72
	bl	_nvm_affine_array_type
	tbnz	w0, #0, LBB14_24
	b	LBB14_23
LBB14_23:
	adrp	x8, l_.str.127@PAGE
	add	x8, x8, l_.str.127@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_24:
	sturh	wzr, [x29, #-154]
	b	LBB14_25
LBB14_25:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-154]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	b.ge	LBB14_30
	b	LBB14_26
LBB14_26:                               ;   in Loop: Header=BB14_25 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldurh	w9, [x29, #-82]
	subs	w8, w8, w9
	ldurh	w9, [x29, #-154]
	add	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	ldurb	w9, [x29, #-80]
	sub	x8, x29, #164
	sturb	w9, [x29, #-164]
	add	x8, x8, #1
	strh	wzr, [x8]
	sturb	wzr, [x29, #-161]
	ldur	w8, [x29, #-76]
	stur	w8, [x29, #-160]
	sub	x0, x29, #216
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	ldur	x2, [x29, #-164]
	bl	_effect_value_matches
	tbnz	w0, #0, LBB14_28
	b	LBB14_27
LBB14_27:
	adrp	x8, l_.str.128@PAGE
	add	x8, x8, l_.str.128@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_28:                               ;   in Loop: Header=BB14_25 Depth=1
	b	LBB14_29
LBB14_29:                               ;   in Loop: Header=BB14_25 Depth=1
	ldurh	w8, [x29, #-154]
	add	w8, w8, #1
	sturh	w8, [x29, #-154]
	b	LBB14_25
LBB14_30:
	b	LBB14_31
LBB14_31:
	ldurh	w10, [x29, #-82]
	ldur	x9, [x29, #-32]
	ldrh	w8, [x9, #16]
	subs	w8, w8, w10
	strh	w8, [x9, #16]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-72]
	bl	_array_push_type
	adrp	x9, l_.str.129@PAGE
	add	x9, x9, l_.str.129@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_32:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #84
	b.eq	LBB14_34
	b	LBB14_33
LBB14_33:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #86
	b.ne	LBB14_35
	b	LBB14_34
LBB14_34:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB14_39
LBB14_35:
	ldurb	w9, [x29, #-57]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #81
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB14_38
	b	LBB14_36
LBB14_36:
	ldurb	w9, [x29, #-57]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #83
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB14_38
	b	LBB14_37
LBB14_37:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #87
	cset	w8, eq
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB14_38
LBB14_38:
	ldr	w9, [sp, #40]                   ; 4-byte Folded Reload
	mov	w8, #2                          ; =0x2
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB14_39
LBB14_39:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	sturh	w8, [x29, #-218]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldurh	w9, [x29, #-218]
	subs	w8, w8, w9
	b.ge	LBB14_41
	b	LBB14_40
LBB14_40:
	adrp	x8, l_.str.130@PAGE
	add	x8, x8, l_.str.130@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_41:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldurh	w9, [x29, #-218]
	subs	w8, w8, w9
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #240
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldrb	w9, [sp, #240]
	add	x8, sp, #232
	strb	w9, [sp, #232]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #235]
	ldr	w8, [sp, #248]
	str	w8, [sp, #236]
	ldr	x8, [sp, #232]
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldur	x1, [x29, #-72]
	sub	x2, x29, #80
	bl	_nvm_affine_array_element
	tbnz	w0, #0, LBB14_43
	b	LBB14_42
LBB14_42:
	adrp	x8, l_.str.131@PAGE
	add	x8, x8, l_.str.131@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_43:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #85
	b.ne	LBB14_49
	b	LBB14_44
LBB14_44:
	ldrb	w8, [sp, #244]
	tbnz	w8, #0, LBB14_47
	b	LBB14_45
LBB14_45:
	ldrb	w8, [sp, #241]
	tbz	w8, #0, LBB14_48
	b	LBB14_46
LBB14_46:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldrh	w1, [sp, #242]
	mov	x2, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	mov	x3, x8
	and	w4, w8, #0x1
	bl	_nvm_affine_owner_access
	tbnz	w0, #0, LBB14_48
	b	LBB14_47
LBB14_47:
	adrp	x8, l_.str.132@PAGE
	add	x8, x8, l_.str.132@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_48:
	ldur	x10, [x29, #-32]
	ldrh	w11, [x10, #16]
	mov	w8, #-1                         ; =0xffffffff
	mov	x9, x8
	add	w9, w9, w11, uxth
	strh	w9, [x10, #16]
	ldur	x0, [x29, #-32]
	add	x9, sp, #224
	mov	w10, #1                         ; =0x1
	strb	w10, [sp, #224]
	add	x9, x9, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #227]
	str	w8, [sp, #228]
	ldr	x1, [sp, #224]
	bl	_array_push_type
	adrp	x9, l_.str.133@PAGE
	add	x9, x9, l_.str.133@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_49:
	ldrb	w8, [sp, #241]
	tbz	w8, #0, LBB14_51
	b	LBB14_50
LBB14_50:
	adrp	x8, l_.str.134@PAGE
	add	x8, x8, l_.str.134@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_51:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #81
	b.eq	LBB14_54
	b	LBB14_52
LBB14_52:
	ldrb	w8, [sp, #244]
	tbz	w8, #0, LBB14_54
	b	LBB14_53
LBB14_53:
	adrp	x8, l_.str.135@PAGE
	add	x8, x8, l_.str.135@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_54:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #83
	b.eq	LBB14_58
	b	LBB14_55
LBB14_55:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #87
	b.eq	LBB14_58
	b	LBB14_56
LBB14_56:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #84
	b.eq	LBB14_58
	b	LBB14_57
LBB14_57:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #86
	b.ne	LBB14_60
	b	LBB14_58
LBB14_58:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldurh	w9, [x29, #-218]
	subs	w8, w8, w9
	add	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #176
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	bl	_array_index
	tbnz	w0, #0, LBB14_60
	b	LBB14_59
LBB14_59:
	adrp	x8, l_.str.136@PAGE
	add	x8, x8, l_.str.136@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_60:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #86
	b.ne	LBB14_63
	b	LBB14_61
LBB14_61:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	add	x0, sp, #128
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_array_index
	tbnz	w0, #0, LBB14_63
	b	LBB14_62
LBB14_62:
	adrp	x8, l_.str.137@PAGE
	add	x8, x8, l_.str.137@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_63:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #81
	b.eq	LBB14_65
	b	LBB14_64
LBB14_64:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #84
	b.ne	LBB14_68
	b	LBB14_65
LBB14_65:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x1, w8, w9, x10
	ldurb	w9, [x29, #-80]
	add	x8, sp, #120
	strb	w9, [sp, #120]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #123]
	ldur	w8, [x29, #-76]
	str	w8, [sp, #124]
	add	x0, sp, #72
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #120]
	bl	_effect_value_matches
	tbnz	w0, #0, LBB14_67
	b	LBB14_66
LBB14_66:
	adrp	x8, l_.str.138@PAGE
	add	x8, x8, l_.str.138@PAGEOFF
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_67:
	b	LBB14_68
LBB14_68:
	ldurh	w10, [x29, #-218]
	ldur	x9, [x29, #-32]
	ldrh	w8, [x9, #16]
	subs	w8, w8, w10
	strh	w8, [x9, #16]
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #83
	b.eq	LBB14_70
	b	LBB14_69
LBB14_69:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #82
	b.ne	LBB14_71
	b	LBB14_70
LBB14_70:
	ldur	x8, [x29, #-80]
	stur	x8, [x29, #-72]
	b	LBB14_71
LBB14_71:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-72]
	bl	_array_push_type
	adrp	x9, l_.str.139@PAGE
	add	x9, x9, l_.str.139@PAGEOFF
	mov	x8, #0                          ; =0x0
	ands	w10, w0, #0x1
	csel	x8, x8, x9, ne
	stur	x8, [x29, #-24]
	b	LBB14_72
LBB14_72:
	ldur	x0, [x29, #-24]
	add	sp, sp, #496
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_escape
_effect_escape:                         ; @effect_escape
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #24]
	str	w4, [sp, #20]
	strh	wzr, [sp, #18]
	b	LBB15_1
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #18]
	ldr	x9, [sp, #24]
	ldrh	w9, [x9, #278]
	subs	w8, w8, w9
	b.ge	LBB15_6
	b	LBB15_2
LBB15_2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #20]
	ldr	x8, [sp, #24]
	add	x8, x8, #288
	ldrh	w9, [sp, #18]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	w2, [x8, x9]
	bl	_effect_key_equal
	tbz	w0, #0, LBB15_4
	b	LBB15_3
LBB15_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_17
LBB15_4:                                ;   in Loop: Header=BB15_1 Depth=1
	b	LBB15_5
LBB15_5:                                ;   in Loop: Header=BB15_1 Depth=1
	ldrh	w8, [sp, #18]
	add	w8, w8, #1
	strh	w8, [sp, #18]
	b	LBB15_1
LBB15_6:
	ldur	w8, [x29, #-28]
	subs	w8, w8, #8
	b.lo	LBB15_8
	b	LBB15_7
LBB15_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_17
LBB15_8:
	ldur	x8, [x29, #-16]
	mov	x9, #7840                       ; =0x1ea0
	add	x8, x8, x9
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	str	x8, [sp, #8]
	strh	wzr, [sp, #6]
	b	LBB15_9
LBB15_9:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB15_14
	b	LBB15_10
LBB15_10:                               ;   in Loop: Header=BB15_9 Depth=1
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #20]
	ldur	x8, [x29, #-16]
	mov	x9, #7856                       ; =0x1eb0
	add	x8, x8, x9
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #10
	ldrh	w9, [sp, #6]
                                        ; kill: def $x9 killed $w9
	ldr	w2, [x8, x9, lsl #2]
	bl	_effect_key_equal
	tbz	w0, #0, LBB15_12
	b	LBB15_11
LBB15_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_17
LBB15_12:                               ;   in Loop: Header=BB15_9 Depth=1
	b	LBB15_13
LBB15_13:                               ;   in Loop: Header=BB15_9 Depth=1
	ldrh	w8, [sp, #6]
	add	w8, w8, #1
	strh	w8, [sp, #6]
	b	LBB15_9
LBB15_14:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8]
	subs	w8, w8, #256
	b.ne	LBB15_16
	b	LBB15_15
LBB15_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB15_17
LBB15_16:
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	mov	x10, #7856                      ; =0x1eb0
	add	x9, x9, x10
	ldur	w10, [x29, #-28]
                                        ; kill: def $x10 killed $w10
	add	x10, x9, x10, lsl #10
	ldr	x13, [sp, #8]
	ldrh	w9, [x13]
	mov	x11, x9
	mov	x12, x11
	mov	w9, #1                          ; =0x1
	add	w12, w12, #1
	strh	w12, [x13]
	str	w8, [x10, x11, lsl #2]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB15_17
LBB15_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function global_require
_global_require:                        ; @global_require
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	w2, [sp, #12]
	str	w3, [sp, #8]
	strb	w4, [sp, #7]
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #2]
	tbz	w8, #0, LBB16_2
	b	LBB16_1
LBB16_1:
	b	LBB16_3
LBB16_2:
	ldur	x8, [x29, #-8]
	add	x8, x8, #22
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	ldrb	w1, [sp, #7]
	bl	_nvm_affine_global_require
	ldr	x8, [sp, #16]
	add	x8, x8, #2056
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #8
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	ldrb	w8, [x9]
	and	w8, w8, w0
	strb	w8, [x9]
	b	LBB16_3
LBB16_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_affine_global_compose
_nvm_affine_global_compose:             ; @nvm_affine_global_compose
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	strb	w1, [sp, #14]
	strb	wzr, [sp, #13]
	str	wzr, [sp, #8]
	b	LBB17_1
LBB17_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB17_3 Depth 2
	ldr	w8, [sp, #8]
	subs	w8, w8, #2
	b.hs	LBB17_10
	b	LBB17_2
LBB17_2:                                ;   in Loop: Header=BB17_1 Depth=1
	str	wzr, [sp, #4]
	b	LBB17_3
LBB17_3:                                ;   Parent Loop BB17_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #4]
	subs	w8, w8, #2
	b.hs	LBB17_8
	b	LBB17_4
LBB17_4:                                ;   in Loop: Header=BB17_3 Depth=2
	ldrb	w8, [sp, #15]
	ldr	w10, [sp, #8]
	ldr	w9, [sp, #4]
	add	w10, w9, w10, lsl #1
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB17_6
	b	LBB17_5
LBB17_5:                                ;   in Loop: Header=BB17_3 Depth=2
	ldrb	w8, [sp, #14]
	ldr	w9, [sp, #4]
	lsl	w9, w9, #1
	asr	w8, w8, w9
	and	w8, w8, #0x3
	ldr	w9, [sp, #8]
	lsl	w9, w9, #1
	lsl	w8, w8, w9
	and	w9, w8, #0xff
	ldrb	w8, [sp, #13]
	orr	w8, w8, w9
	strb	w8, [sp, #13]
	b	LBB17_6
LBB17_6:                                ;   in Loop: Header=BB17_3 Depth=2
	b	LBB17_7
LBB17_7:                                ;   in Loop: Header=BB17_3 Depth=2
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB17_3
LBB17_8:                                ;   in Loop: Header=BB17_1 Depth=1
	b	LBB17_9
LBB17_9:                                ;   in Loop: Header=BB17_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB17_1
LBB17_10:
	ldrb	w0, [sp, #13]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function push
_push:                                  ; @push
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.ne	LBB18_2
	b	LBB18_1
LBB18_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_5
LBB18_2:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #16]
	add	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smull	x1, w8, w9
	bl	_realloc
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB18_4
	b	LBB18_3
LBB18_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB18_5
LBB18_4:
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #8]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #8]
	ldur	x11, [x29, #-16]
	ldrh	w8, [x11, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #4]                   ; 4-byte Folded Spill
	add	w9, w9, #1
	strh	w9, [x11, #16]
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB18_5
LBB18_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_value_matches
_effect_value_matches:                  ; @effect_value_matches
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	stur	x2, [x29, #-8]
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	ldurb	w9, [x29, #-8]
	add	x8, sp, #32
	strb	w9, [sp, #32]
	mov	w9, #0                          ; =0x0
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #35]
	ldur	w8, [x29, #-4]
	str	w8, [sp, #36]
	ldrb	w8, [x1, #1]
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB19_8
	b	LBB19_1
LBB19_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x8]
	ldrb	w10, [sp, #32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB19_8
	b	LBB19_2
LBB19_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #4]
	and	w8, w8, #0x1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #32]
	bl	_nvm_affine_type_is_owned
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB19_8
	b	LBB19_3
LBB19_3:
	ldrb	w8, [sp, #32]
	subs	w8, w8, #8
	b.eq	LBB19_6
	b	LBB19_4
LBB19_4:
	ldrb	w8, [sp, #32]
	subs	w8, w8, #10
	b.eq	LBB19_6
	b	LBB19_5
LBB19_5:
	ldrb	w8, [sp, #32]
	mov	w0, #1                          ; =0x1
	subs	w8, w8, #7
	str	w0, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB19_7
	b	LBB19_6
LBB19_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldrb	w10, [x8]
	add	x9, sp, #24
	strb	w10, [sp, #24]
	add	x9, x9, #1
	strh	wzr, [x9]
	strb	wzr, [sp, #27]
	ldr	w8, [x8, #8]
	str	w8, [sp, #28]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #32]
	bl	_nvm_affine_types_equal
	str	w0, [sp]                        ; 4-byte Folded Spill
	b	LBB19_7
LBB19_7:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB19_8
LBB19_8:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function observes_owner
_observes_owner:                        ; @observes_owner
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	strh	wzr, [sp, #12]
	b	LBB20_1
LBB20_1:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB20_7
	b	LBB20_2
LBB20_2:                                ;   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB20_5
	b	LBB20_3
LBB20_3:                                ;   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	ldrh	w9, [sp, #14]
	subs	w8, w8, w9
	b.ne	LBB20_5
	b	LBB20_4
LBB20_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB20_8
LBB20_5:                                ;   in Loop: Header=BB20_1 Depth=1
	b	LBB20_6
LBB20_6:                                ;   in Loop: Header=BB20_1 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB20_1
LBB20_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB20_8
LBB20_8:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function pop_scalar
_pop_scalar:                            ; @pop_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	strb	w1, [sp, #15]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	cbz	w8, LBB21_4
	b	LBB21_1
LBB21_1:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB21_4
	b	LBB21_2
LBB21_2:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	mov	w9, #48                         ; =0x30
	smaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #4]
	tbnz	w8, #0, LBB21_4
	b	LBB21_3
LBB21_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w9, w9, #1
	mov	w10, #48                        ; =0x30
	smull	x9, w9, w10
	ldrb	w8, [x8, x9]
	ldrb	w9, [sp, #15]
	subs	w8, w8, w9
	b.eq	LBB21_5
	b	LBB21_4
LBB21_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_6
LBB21_5:
	ldr	x9, [sp, #16]
	ldrh	w10, [x9, #16]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_6
LBB21_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB22_4
	b	LBB22_1
LBB22_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB22_4
	b	LBB22_2
LBB22_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB22_4
	b	LBB22_3
LBB22_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB22_4
LBB22_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_push_type
_array_push_type:                       ; @array_push_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-8]
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	sub	x0, x29, #64
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldurb	w8, [x29, #-8]
	sturb	w8, [x29, #-64]
	mov	w8, #65535                      ; =0xffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	sturh	w8, [x29, #-62]
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x1, [x29, #-8]
	bl	_nvm_affine_type_is_owned
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	sturb	w0, [x29, #-60]
	ldur	w9, [x29, #-4]
	stur	w9, [x29, #-56]
	sturh	w8, [x29, #-52]
	add	x0, sp, #48
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_push
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function array_index
_array_index:                           ; @array_index
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	str	x8, [sp, #24]
	ldrb	w9, [x0]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b.ne	LBB24_3
	b	LBB24_1
LBB24_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #4]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB24_3
	b	LBB24_2
LBB24_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #1]
	eor	w8, w8, #0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB24_3
LBB24_3:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function effect_key_equal
_effect_key_equal:                      ; @effect_key_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	stur	w2, [x29, #-16]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	bl	_nvm_get_string
	str	x0, [sp, #24]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-16]
	bl	_nvm_get_string
	str	x0, [sp, #16]
	ldr	x8, [sp, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB25_4
	b	LBB25_1
LBB25_1:
	ldr	x8, [sp, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB25_4
	b	LBB25_2
LBB25_2:
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	bl	_nvm_get_string_len
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-16]
	bl	_nvm_get_string_len
	mov	x9, x0
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	mov	w8, #0                          ; =0x0
	subs	w9, w0, w9
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB25_4
	b	LBB25_3
LBB25_3:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #16]
	bl	_strcmp
	subs	w8, w0, #0
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB25_4
LBB25_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_affine_global_require
_nvm_affine_global_require:             ; @nvm_affine_global_require
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	strb	w1, [sp, #14]
	mov	w8, #3                          ; =0x3
	strb	w8, [sp, #13]
	str	wzr, [sp, #8]
	b	LBB26_1
LBB26_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #8]
	subs	w8, w8, #2
	b.hs	LBB26_6
	b	LBB26_2
LBB26_2:                                ;   in Loop: Header=BB26_1 Depth=1
	ldrb	w8, [sp, #15]
	ldr	w9, [sp, #8]
	lsl	w9, w9, #1
	asr	w8, w8, w9
	and	w8, w8, #0x3
	ldrb	w9, [sp, #14]
	bic	w8, w8, w9
	cbz	w8, LBB26_4
	b	LBB26_3
LBB26_3:                                ;   in Loop: Header=BB26_1 Depth=1
	ldr	w9, [sp, #8]
	mov	w8, #1                          ; =0x1
	lsl	w9, w8, w9
	mov	w8, #255                        ; =0xff
	bic	w9, w8, w9
	ldrb	w8, [sp, #13]
	and	w8, w8, w9
	strb	w8, [sp, #13]
	b	LBB26_4
LBB26_4:                                ;   in Loop: Header=BB26_1 Depth=1
	b	LBB26_5
LBB26_5:                                ;   in Loop: Header=BB26_1 Depth=1
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB26_1
LBB26_6:
	ldrb	w0, [sp, #13]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function stack_meet
_stack_meet:                            ; @stack_meet
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB27_2
	b	LBB27_1
LBB27_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB27_49
LBB27_2:
	ldur	x8, [x29, #-48]
	strb	wzr, [x8]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB27_4
	b	LBB27_3
LBB27_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB27_49
LBB27_4:
	sturh	wzr, [x29, #-50]
	b	LBB27_5
LBB27_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB27_22 Depth 2
	ldurh	w8, [x29, #-50]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB27_48
	b	LBB27_6
LBB27_6:                                ;   in Loop: Header=BB27_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #104
	mov	x2, #48                         ; =0x30
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #104
	bl	_memcpy
	ldurb	w8, [x29, #-104]
	ldrb	w9, [sp, #104]
	subs	w8, w8, w9
	b.ne	LBB27_15
	b	LBB27_7
LBB27_7:                                ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-103]
	and	w8, w8, #0x1
	ldrb	w9, [sp, #105]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB27_15
	b	LBB27_8
LBB27_8:                                ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-100]
	and	w8, w8, #0x1
	ldrb	w9, [sp, #108]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB27_15
	b	LBB27_9
LBB27_9:                                ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-100]
	tbnz	w8, #0, LBB27_12
	b	LBB27_10
LBB27_10:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #8
	b.eq	LBB27_12
	b	LBB27_11
LBB27_11:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #7
	b.ne	LBB27_13
	b	LBB27_12
LBB27_12:                               ;   in Loop: Header=BB27_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldurb	w9, [x29, #-104]
	add	x8, sp, #96
	strb	w9, [sp, #96]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #99]
	ldur	w8, [x29, #-96]
	str	w8, [sp, #100]
	ldrb	w9, [sp, #104]
	add	x8, sp, #88
	strb	w9, [sp, #88]
	add	x8, x8, #1
	strh	wzr, [x8]
	strb	wzr, [sp, #91]
	ldr	w8, [sp, #112]
	str	w8, [sp, #92]
	ldr	x1, [sp, #96]
	ldr	x2, [sp, #88]
	bl	_nvm_affine_types_equal
	tbz	w0, #0, LBB27_15
	b	LBB27_13
LBB27_13:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-103]
	tbz	w8, #0, LBB27_16
	b	LBB27_14
LBB27_14:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-102]
	ldrh	w9, [sp, #106]
	subs	w8, w8, w9
	b.eq	LBB27_16
	b	LBB27_15
LBB27_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB27_49
LBB27_16:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #10
	b.ne	LBB27_46
	b	LBB27_17
LBB27_17:                               ;   in Loop: Header=BB27_5 Depth=1
	ldur	w8, [x29, #-96]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	b.eq	LBB27_19
	b	LBB27_18
LBB27_18:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB27_49
LBB27_19:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-92]
	ldrh	w9, [sp, #116]
	subs	w8, w8, w9
	b.ne	LBB27_21
	b	LBB27_20
LBB27_20:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-92]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB27_42
	b	LBB27_21
LBB27_21:                               ;   in Loop: Header=BB27_5 Depth=1
	str	wzr, [sp, #84]
	b	LBB27_22
LBB27_22:                               ;   Parent Loop BB27_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #84]
	subs	w8, w8, #4
	b.hs	LBB27_39
	b	LBB27_23
LBB27_23:                               ;   in Loop: Header=BB27_22 Depth=2
	ldurh	w8, [x29, #-92]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB27_25
	b	LBB27_24
LBB27_24:                               ;   in Loop: Header=BB27_22 Depth=2
	sub	x8, x29, #104
	add	x8, x8, #16
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB27_29
LBB27_25:                               ;   in Loop: Header=BB27_22 Depth=2
	ldurh	w8, [x29, #-92]
	mov	w9, #64                         ; =0x40
	udiv	w8, w8, w9
	ldr	w9, [sp, #84]
	subs	w8, w8, w9
	b.ne	LBB27_27
	b	LBB27_26
LBB27_26:                               ;   in Loop: Header=BB27_22 Depth=2
	ldurh	w8, [x29, #-92]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB27_28
LBB27_27:                               ;   in Loop: Header=BB27_22 Depth=2
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB27_28
LBB27_28:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mvn	x8, x8
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB27_29
LBB27_29:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #72]
	ldrh	w8, [sp, #116]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB27_31
	b	LBB27_30
LBB27_30:                               ;   in Loop: Header=BB27_22 Depth=2
	add	x8, sp, #104
	add	x8, x8, #16
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB27_35
LBB27_31:                               ;   in Loop: Header=BB27_22 Depth=2
	ldrh	w8, [sp, #116]
	mov	w9, #64                         ; =0x40
	udiv	w8, w8, w9
	ldr	w9, [sp, #84]
	subs	w8, w8, w9
	b.ne	LBB27_33
	b	LBB27_32
LBB27_32:                               ;   in Loop: Header=BB27_22 Depth=2
	ldrh	w8, [sp, #116]
	mov	w10, #64                        ; =0x40
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB27_34
LBB27_33:                               ;   in Loop: Header=BB27_22 Depth=2
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB27_34
LBB27_34:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mvn	x8, x8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB27_35
LBB27_35:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #64]
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #64]
	and	x8, x8, x9
	str	x8, [sp, #56]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #16
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #56]
	subs	x8, x8, x9
	b.eq	LBB27_37
	b	LBB27_36
LBB27_36:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-32]
	ldr	x11, [x9, #8]
	ldurh	w9, [x29, #-50]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x9, x9, #16
	ldr	w10, [sp, #84]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB27_37
LBB27_37:                               ;   in Loop: Header=BB27_22 Depth=2
	b	LBB27_38
LBB27_38:                               ;   in Loop: Header=BB27_22 Depth=2
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB27_22
LBB27_39:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-92]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB27_41
	b	LBB27_40
LBB27_40:                               ;   in Loop: Header=BB27_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, #12]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB27_41
LBB27_41:                               ;   in Loop: Header=BB27_5 Depth=1
	b	LBB27_42
LBB27_42:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-102]
	ldrh	w9, [sp, #106]
	subs	w8, w8, w9
	b.eq	LBB27_45
	b	LBB27_43
LBB27_43:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-102]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB27_45
	b	LBB27_44
LBB27_44:                               ;   in Loop: Header=BB27_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, #2]
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB27_45
LBB27_45:                               ;   in Loop: Header=BB27_5 Depth=1
	b	LBB27_46
LBB27_46:                               ;   in Loop: Header=BB27_5 Depth=1
	b	LBB27_47
LBB27_47:                               ;   in Loop: Header=BB27_5 Depth=1
	ldurh	w8, [x29, #-50]
	add	w8, w8, #1
	sturh	w8, [x29, #-50]
	b	LBB27_5
LBB27_48:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB27_49
LBB27_49:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_frame
_eg_frame:                              ; @eg_frame
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	stur	w3, [x29, #-28]
	stur	w4, [x29, #-32]
	stur	w5, [x29, #-36]
	ldur	w0, [x29, #-20]
	ldur	w1, [x29, #-24]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-32]
	ldur	w4, [x29, #-36]
	bl	_eg_hash
	stur	w0, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #328]
	ldur	w9, [x29, #-40]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-44]
	b	LBB28_1
LBB28_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	cbz	w8, LBB28_14
	b	LBB28_2
LBB28_2:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-44]
	subs	w9, w9, #1
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-56]
	ldr	w8, [x8]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_3
LBB28_3:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_4
LBB28_4:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_5
LBB28_5:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_6
LBB28_6:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #28]
	and	w8, w8, #0x1
	ldur	w9, [x29, #-36]
	adds	w9, w9, #1
	cset	w9, ne
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_7
LBB28_7:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #16]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	ldur	w8, [x29, #-36]
	adds	w8, w8, #1
	b.ne	LBB28_9
	b	LBB28_8
LBB28_8:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	w8, [x29, #-44]
	subs	w8, w8, #1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB28_10
LBB28_9:                                ;   in Loop: Header=BB28_1 Depth=1
	ldur	w8, [x29, #-36]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB28_10
LBB28_10:                               ;   in Loop: Header=BB28_1 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, w9
	b.ne	LBB28_12
	b	LBB28_11
LBB28_11:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #1
	stur	w8, [x29, #-4]
	b	LBB28_23
LBB28_12:                               ;   in Loop: Header=BB28_1 Depth=1
	b	LBB28_13
LBB28_13:                               ;   in Loop: Header=BB28_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-44]
	subs	w9, w9, #1
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	w8, [x8, #24]
	stur	w8, [x29, #-44]
	b	LBB28_1
LBB28_14:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #280]
	ldur	x8, [x29, #-16]
	add	x1, x8, #316
	ldur	x8, [x29, #-16]
	ldr	w2, [x8, #304]
	mov	x3, #32                         ; =0x20
	bl	_eg_grow
	str	x0, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB28_16
	b	LBB28_15
LBB28_15:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.147@PAGE
	add	x8, x8, l_.str.147@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB28_23
LBB28_16:
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #280]
	ldur	x10, [x29, #-16]
	ldr	w8, [x10, #304]
	add	w9, w8, #1
	str	w9, [x10, #304]
	str	w8, [sp, #60]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	w8, [x29, #-20]
	str	w8, [sp, #28]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #32]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #36]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #40]
	ldur	w8, [x29, #-36]
	adds	w8, w8, #1
	b.ne	LBB28_18
	b	LBB28_17
LBB28_17:
	ldr	w8, [sp, #60]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB28_19
LBB28_18:
	ldur	w8, [x29, #-36]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB28_19
LBB28_19:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #44]
	ldur	w8, [x29, #-20]
	adds	w8, w8, #1
	b.ne	LBB28_21
	b	LBB28_20
LBB28_20:
	mov	w8, #1                          ; =0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB28_22
LBB28_21:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	w8, [x8, #20]
	add	w8, w8, #1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB28_22
LBB28_22:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [sp]                        ; 4-byte Folded Reload
	str	w9, [sp, #48]
	add	x9, sp, #28
	ldur	x10, [x29, #-16]
	ldr	x10, [x10, #328]
	ldur	w11, [x29, #-40]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	str	w10, [sp, #52]
	ldur	w10, [x29, #-36]
	adds	w10, w10, #1
	cset	w10, ne
	strb	w10, [sp, #56]
	add	x9, x9, #29
	strh	wzr, [x9]
	strb	wzr, [sp, #59]
	ldur	q0, [sp, #28]
	str	q0, [x8]
	ldur	q0, [sp, #44]
	str	q0, [x8, #16]
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #328]
	ldur	w10, [x29, #-40]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #60]
	stur	w8, [x29, #-4]
	b	LBB28_23
LBB28_23:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_queue
_eg_queue:                              ; @eg_queue
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #96]
	str	w1, [sp, #92]
	str	w2, [sp, #88]
	str	w3, [sp, #84]
	str	x4, [sp, #72]
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #96]
	ldr	w9, [x9, #304]
	subs	w8, w8, w9
	b.hs	LBB29_2
	b	LBB29_1
LBB29_1:
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #96]
	add	x9, x9, #24
	ldr	x10, [sp, #96]
	ldr	x10, [x10, #280]
	ldr	w11, [sp, #92]
                                        ; kill: def $x11 killed $w11
	add	x10, x10, x11, lsl #5
	ldr	w10, [x10, #4]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB29_3
	b	LBB29_2
LBB29_2:
	ldr	x9, [sp, #96]
	adrp	x8, l_.str.148@PAGE
	add	x8, x8, l_.str.148@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #111]
	b	LBB29_28
LBB29_3:
	ldr	w0, [sp, #92]
	ldr	w1, [sp, #88]
	ldr	w2, [sp, #84]
	mov	w4, #0                          ; =0x0
	mov	x3, x4
	bl	_eg_hash
	str	w0, [sp, #68]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #64]
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #344]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #60]
	b	LBB29_4
LBB29_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	cbz	w8, LBB29_11
	b	LBB29_5
LBB29_5:                                ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #296]
	ldr	w9, [sp, #60]
	subs	w9, w9, #1
	mov	w10, #280                       ; =0x118
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.ne	LBB29_9
	b	LBB29_6
LBB29_6:                                ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp, #96]
	ldr	x10, [x8, #296]
	ldr	w8, [sp, #60]
	subs	w8, w8, #1
	mov	w9, #280                        ; =0x118
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #88]
	subs	w8, w8, w9
	b.ne	LBB29_9
	b	LBB29_7
LBB29_7:                                ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp, #96]
	ldr	x10, [x8, #296]
	ldr	w8, [sp, #60]
	subs	w8, w8, #1
	mov	w9, #280                        ; =0x118
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #84]
	subs	w8, w8, w9
	b.ne	LBB29_9
	b	LBB29_8
LBB29_8:
	ldr	w8, [sp, #60]
	subs	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB29_11
LBB29_9:                                ;   in Loop: Header=BB29_4 Depth=1
	b	LBB29_10
LBB29_10:                               ;   in Loop: Header=BB29_4 Depth=1
	ldr	x8, [sp, #96]
	ldr	x10, [x8, #296]
	ldr	w8, [sp, #60]
	subs	w8, w8, #1
	mov	w9, #280                        ; =0x118
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	str	w8, [sp, #60]
	b	LBB29_4
LBB29_11:
	strb	wzr, [sp, #59]
	ldr	w8, [sp, #64]
	adds	w8, w8, #1
	b.ne	LBB29_15
	b	LBB29_12
LBB29_12:
	ldr	x8, [sp, #96]
	ldr	x0, [x8, #296]
	ldr	x8, [sp, #96]
	add	x1, x8, #324
	ldr	x8, [sp, #96]
	ldr	w2, [x8, #312]
	mov	x3, #280                        ; =0x118
	bl	_eg_grow
	str	x0, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB29_14
	b	LBB29_13
LBB29_13:
	ldr	x9, [sp, #96]
	adrp	x8, l_.str.149@PAGE
	add	x8, x8, l_.str.149@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #111]
	b	LBB29_28
LBB29_14:
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #96]
	str	x8, [x9, #296]
	ldr	x10, [sp, #96]
	ldr	w8, [x10, #312]
	add	w9, w8, #1
	str	w9, [x10, #312]
	str	w8, [sp, #64]
	ldr	x8, [sp, #96]
	ldr	x10, [x8, #296]
	ldr	w8, [sp, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #280                        ; =0x118
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x0, sp, #112
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x1, #280                        ; =0x118
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	bl	_bzero
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #92]
	str	w8, [sp, #112]
	ldr	w8, [sp, #88]
	str	w8, [sp, #116]
	ldr	w8, [sp, #84]
	str	w8, [sp, #120]
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #344]
	ldr	w9, [sp, #68]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #124]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #128]
	bl	_memcpy
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #344]
	ldr	w10, [sp, #68]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #59]
	b	LBB29_15
LBB29_15:
	ldr	x8, [sp, #96]
	ldr	x10, [x8, #296]
	ldr	w8, [sp, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #280                        ; =0x118
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	str	wzr, [sp, #36]
	b	LBB29_16
LBB29_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldr	x9, [sp, #96]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB29_21
	b	LBB29_17
LBB29_17:                               ;   in Loop: Header=BB29_16 Depth=1
	ldr	x8, [sp, #40]
	add	x8, x8, #21
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldr	x9, [sp, #72]
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	orr	w8, w8, w9
	strb	w8, [sp, #35]
	ldrb	w8, [sp, #35]
	ldr	x9, [sp, #40]
	add	x9, x9, #21
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB29_19
	b	LBB29_18
LBB29_18:                               ;   in Loop: Header=BB29_16 Depth=1
	ldrb	w8, [sp, #35]
	ldr	x9, [sp, #40]
	add	x9, x9, #21
	ldr	w10, [sp, #36]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #59]
	b	LBB29_19
LBB29_19:                               ;   in Loop: Header=BB29_16 Depth=1
	b	LBB29_20
LBB29_20:                               ;   in Loop: Header=BB29_16 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB29_16
LBB29_21:
	ldrb	w8, [sp, #59]
	tbz	w8, #0, LBB29_27
	b	LBB29_22
LBB29_22:
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #20]
	tbnz	w8, #0, LBB29_27
	b	LBB29_23
LBB29_23:
	ldr	x9, [sp, #40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #20]
	ldr	x9, [sp, #40]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #16]
	ldr	x8, [sp, #96]
	ldr	w8, [x8, #356]
	adds	w8, w8, #1
	b.ne	LBB29_25
	b	LBB29_24
LBB29_24:
	ldr	w8, [sp, #64]
	ldr	x9, [sp, #96]
	str	w8, [x9, #352]
	b	LBB29_26
LBB29_25:
	ldr	w8, [sp, #64]
	ldr	x9, [sp, #96]
	ldr	x11, [x9, #296]
	ldr	x9, [sp, #96]
	ldr	w9, [x9, #356]
                                        ; kill: def $x9 killed $w9
	mov	x10, #280                       ; =0x118
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #16]
	b	LBB29_26
LBB29_26:
	ldr	w8, [sp, #64]
	ldr	x9, [sp, #96]
	str	w8, [x9, #356]
	b	LBB29_27
LBB29_27:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #111]
	b	LBB29_28
LBB29_28:
	ldrb	w8, [sp, #111]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB29_30
	b	LBB29_29
LBB29_29:
	bl	___stack_chk_fail
LBB29_30:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_step
_eg_step:                               ; @eg_step
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldr	w9, [x1]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-64]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-48]
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-60]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #5
	add	x8, x8, #24
	ldr	x10, [x8, x9]
	ldr	w8, [x1, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-72]
	add	x8, x8, #40
	stur	x8, [x29, #-80]
	ldr	w8, [x1, #4]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	subs	w8, w8, #18
	subs	w8, w8, #1
	b.ls	LBB30_15
	b	LBB30_1
LBB30_1:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #56
	subs	w8, w8, #2
	b.ls	LBB30_60
	b	LBB30_2
LBB30_2:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB30_25
	b	LBB30_3
LBB30_3:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #61
	b.eq	LBB30_11
	b	LBB30_4
LBB30_4:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #107
	b.eq	LBB30_60
	b	LBB30_5
LBB30_5:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #163
	b.eq	LBB30_10
	b	LBB30_6
LBB30_6:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #165
	b.eq	LBB30_33
	b	LBB30_7
LBB30_7:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #166
	b.eq	LBB30_41
	b	LBB30_8
LBB30_8:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #167
	b.eq	LBB30_49
	b	LBB30_9
LBB30_9:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	subs	w8, w8, #168
	b.eq	LBB30_12
	b	LBB30_66
LBB30_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_11:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-48]
	add	x2, x8, #21
	bl	_eg_return
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_12:
	ldurb	w8, [x29, #-36]
	tbnz	w8, #0, LBB30_14
	b	LBB30_13
LBB30_13:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.150@PAGE
	add	x8, x8, l_.str.150@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_14:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8]
	add	x2, x8, #21
	bl	_eg_return
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_15:
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-88]
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB30_17
	b	LBB30_16
LBB30_16:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.151@PAGE
	add	x8, x8, l_.str.151@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_17:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #18
	b.ne	LBB30_19
	b	LBB30_18
LBB30_18:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB30_20
LBB30_19:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldrb	w9, [x8, #1]
	mov	w8, #3                          ; =0x3
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB30_20
LBB30_20:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	sturb	w9, [x29, #-89]
	add	x8, x8, #21
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	ldurb	w1, [x29, #-89]
	bl	_nvm_affine_global_require
	tbnz	w0, #0, LBB30_22
	b	LBB30_21
LBB30_21:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.152@PAGE
	add	x8, x8, l_.str.152@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_22:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #19
	b.ne	LBB30_24
	b	LBB30_23
LBB30_23:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, #21
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	mov	w1, #10                         ; =0xa
	bl	_nvm_affine_global_compose
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, #21
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	strb	w0, [x8, x9]
	b	LBB30_24
LBB30_24:
	b	LBB30_67
LBB30_25:
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-96]
	ldur	w8, [x29, #-96]
	cbz	w8, LBB30_27
	b	LBB30_26
LBB30_26:
	ldur	w8, [x29, #-96]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB30_28
	b	LBB30_27
LBB30_27:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.153@PAGE
	add	x8, x8, l_.str.153@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_28:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #1024
	b.ne	LBB30_30
	b	LBB30_29
LBB30_29:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_30:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8]
	ldur	w2, [x29, #-96]
	ldur	w3, [x29, #-84]
	ldr	w4, [x8, #8]
	mov	w5, #-1                         ; =0xffffffff
	bl	_eg_frame
	stur	w0, [x29, #-100]
	ldur	w8, [x29, #-100]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b.eq	LBB30_32
	b	LBB30_31
LBB30_31:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-100]
	ldr	w3, [x8, #8]
	add	x4, x8, #21
	mov	w2, #0                          ; =0x0
	bl	_eg_queue
	str	w0, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB30_32
LBB30_32:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_33:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB30_36
	b	LBB30_34
LBB30_34:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	ldr	x10, [x9, #288]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #16]
	subs	w8, w8, #1024
	b.ne	LBB30_36
	b	LBB30_35
LBB30_35:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_36:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-60]
	ldur	x8, [x29, #-72]
	ldr	w2, [x8, #8]
	bl	_eg_target
	stur	w0, [x29, #-104]
	ldur	w8, [x29, #-104]
	adds	w8, w8, #1
	b.ne	LBB30_38
	b	LBB30_37
LBB30_37:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_38:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8, #8]
	ldr	w2, [x8]
	ldur	x8, [x29, #-80]
	ldr	w3, [x8, #8]
	ldur	w4, [x29, #-104]
	bl	_eg_handler
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	w0, [x8, #8]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.ne	LBB30_40
	b	LBB30_39
LBB30_39:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_40:
	b	LBB30_67
LBB30_41:
	sturh	wzr, [x29, #-106]
	b	LBB30_42
LBB30_42:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-106]
	ldur	x9, [x29, #-80]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB30_48
	b	LBB30_43
LBB30_43:                               ;   in Loop: Header=BB30_42 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB30_45
	b	LBB30_44
LBB30_44:                               ;   in Loop: Header=BB30_42 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x11, [x8, #288]
	ldr	w8, [x9, #8]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w8, [x8, #4]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.eq	LBB30_46
	b	LBB30_45
LBB30_45:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.154@PAGE
	add	x8, x8, l_.str.154@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_46:                               ;   in Loop: Header=BB30_42 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #288]
	ldr	w10, [x9, #8]
                                        ; kill: def $x10 killed $w10
	mov	x11, #24                        ; =0x18
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w8, [x8, x10]
	str	w8, [x9, #8]
	b	LBB30_47
LBB30_47:                               ;   in Loop: Header=BB30_42 Depth=1
	ldurh	w8, [x29, #-106]
	add	w8, w8, #1
	sturh	w8, [x29, #-106]
	b	LBB30_42
LBB30_48:
	b	LBB30_67
LBB30_49:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #8]
	str	w8, [sp, #112]
	b	LBB30_50
LBB30_50:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [sp, #112]
	mov	w8, #0                          ; =0x0
	adds	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB30_52
	b	LBB30_51
LBB30_51:                               ;   in Loop: Header=BB30_50 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldur	x8, [x29, #-80]
	ldr	w1, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #288]
	ldr	w8, [sp, #112]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w2, [x8, #8]
	bl	_effect_key_equal
	eor	w8, w0, #0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB30_52
LBB30_52:                               ;   in Loop: Header=BB30_50 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB30_54
	b	LBB30_53
LBB30_53:                               ;   in Loop: Header=BB30_50 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #288]
	ldr	w9, [sp, #112]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #112]
	b	LBB30_50
LBB30_54:
	ldr	w8, [sp, #112]
	adds	w8, w8, #1
	b.eq	LBB30_56
	b	LBB30_55
LBB30_55:
	ldur	w8, [x29, #-44]
	subs	w8, w8, #1024
	b.ne	LBB30_57
	b	LBB30_56
LBB30_56:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_57:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	ldr	x11, [x9, #288]
	ldr	w9, [sp, #112]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	q0, [x9]
	str	q0, [sp, #80]
	ldr	x9, [x9, #16]
	str	x9, [sp, #96]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #280]
	ldr	w10, [sp, #84]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #5
	ldr	q0, [x9]
	str	q0, [sp, #48]
	ldr	q0, [x9, #16]
	str	q0, [sp, #64]
	ldur	x0, [x29, #-16]
	ldr	w1, [x8]
	ldr	w2, [sp, #52]
	ldur	w3, [x29, #-84]
	ldr	w4, [x8, #8]
	ldr	w5, [sp, #64]
	bl	_eg_frame
	str	w0, [sp, #44]
	ldr	w8, [sp, #44]
	mov	w0, #0                          ; =0x0
	adds	w8, w8, #1
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB30_59
	b	LBB30_58
LBB30_58:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #44]
	ldr	w2, [sp, #92]
	ldr	w3, [x8, #8]
	add	x4, x8, #21
	bl	_eg_queue
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB30_59
LBB30_59:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_60:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-60]
	ldur	x8, [x29, #-72]
	ldr	w2, [x8, #8]
	bl	_eg_target
	str	w0, [sp, #40]
	ldr	w8, [sp, #40]
	adds	w8, w8, #1
	b.eq	LBB30_62
	b	LBB30_61
LBB30_61:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8]
	ldr	w2, [sp, #40]
	ldr	w3, [x8, #8]
	add	x4, x8, #21
	bl	_eg_queue
	tbnz	w0, #0, LBB30_63
	b	LBB30_62
LBB30_62:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_63:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #56
	b.ne	LBB30_65
	b	LBB30_64
LBB30_64:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_65:
	b	LBB30_67
LBB30_66:
	b	LBB30_67
LBB30_67:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-16]
	ldr	w1, [x8]
	ldur	w2, [x29, #-84]
	ldr	w3, [x8, #8]
	add	x4, x8, #21
	bl	_eg_queue
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB30_68
LBB30_68:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_hash
_eg_hash:                               ; @eg_hash
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	mov	w9, #403                        ; =0x193
	movk	w9, #256, lsl #16
	str	w0, [sp, #28]
	str	w1, [sp, #24]
	str	w2, [sp, #20]
	str	w3, [sp, #16]
	str	w4, [sp, #12]
	mov	w8, #40389                      ; =0x9dc5
	movk	w8, #33052, lsl #16
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	w10, [sp, #28]
	eor	w8, w8, w10
	mul	w8, w8, w9
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	w10, [sp, #24]
	eor	w8, w8, w10
	mul	w8, w8, w9
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	w10, [sp, #20]
	eor	w8, w8, w10
	mul	w8, w8, w9
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	w10, [sp, #16]
	eor	w8, w8, w10
	mul	w8, w8, w9
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	w10, [sp, #12]
	eor	w8, w8, w10
	mul	w8, w8, w9
	str	w8, [sp, #8]
	ldrh	w0, [sp, #8]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_grow
_eg_grow:                               ; @eg_grow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	str	x3, [sp, #24]
	ldur	w8, [x29, #-28]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB32_2
	b	LBB32_1
LBB32_1:
	ldur	x8, [x29, #-16]
	stur	x8, [x29, #-8]
	b	LBB32_12
LBB32_2:
	mov	w8, #262144                     ; =0x40000
	str	w8, [sp, #20]
	ldur	w8, [x29, #-28]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.lo	LBB32_4
	b	LBB32_3
LBB32_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB32_12
LBB32_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	cbz	w8, LBB32_6
	b	LBB32_5
LBB32_5:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	lsl	w8, w8, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB32_7
LBB32_6:
	mov	w8, #32                         ; =0x20
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB32_7
LBB32_7:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.ls	LBB32_9
	b	LBB32_8
LBB32_8:
	ldr	w8, [sp, #20]
	str	w8, [sp, #16]
	b	LBB32_9
LBB32_9:
	ldur	x0, [x29, #-16]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #24]
	mul	x1, x8, x9
	bl	_realloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB32_11
	b	LBB32_10
LBB32_10:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB32_12
LBB32_11:
	ldr	w8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB32_12
LBB32_12:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_return
_eg_return:                             ; @eg_return
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	stur	x2, [x29, #-24]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #280]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	str	q0, [sp, #16]
	ldr	q0, [x8, #16]
	str	q0, [sp, #32]
	ldr	w8, [sp, #16]
	mov	w0, #1                          ; =0x1
	adds	w8, w8, #1
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB33_2
	b	LBB33_1
LBB33_1:
	ldur	x0, [x29, #-8]
	ldr	w1, [sp, #16]
	ldr	w2, [sp, #24]
	ldr	w3, [sp, #28]
	ldur	x4, [x29, #-24]
	bl	_eg_queue
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB33_2
LBB33_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_target
_eg_target:                             ; @eg_target
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	w2, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	str	w8, [sp, #20]
	ldr	w8, [sp, #24]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.lo	LBB34_2
	b	LBB34_1
LBB34_1:
	ldur	x8, [x29, #-16]
	add	x8, x8, #24
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #5
	ldr	w8, [sp, #24]
	ldr	w9, [sp, #20]
	subs	w1, w8, w9
	bl	_vm_decoded_function_at
	str	x0, [sp]                        ; 8-byte Folded Spill
	b	LBB34_3
LBB34_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB34_3
LBB34_3:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB34_5
	b	LBB34_4
LBB34_4:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.155@PAGE
	add	x8, x8, l_.str.155@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB34_6
LBB34_5:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	add	x9, x9, #24
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	lsl	x10, x10, #5
	ldr	x9, [x9, x10]
	subs	x8, x8, x9
	mov	x9, #104                        ; =0x68
	sdiv	x8, x8, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	stur	w8, [x29, #-4]
	b	LBB34_6
LBB34_6:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function eg_handler
_eg_handler:                            ; @eg_handler
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	w2, [x29, #-24]
	stur	w3, [x29, #-28]
	stur	w4, [x29, #-32]
	ldur	w0, [x29, #-20]
	ldur	w1, [x29, #-24]
	ldur	w2, [x29, #-28]
	ldur	w3, [x29, #-32]
	mov	w4, #0                          ; =0x0
	bl	_eg_hash
	stur	w0, [x29, #-36]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #336]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-40]
	b	LBB35_1
LBB35_1:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	cbz	w8, LBB35_9
	b	LBB35_2
LBB35_2:                                ;   in Loop: Header=BB35_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #288]
	ldur	w8, [x29, #-40]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB35_7
	b	LBB35_3
LBB35_3:                                ;   in Loop: Header=BB35_1 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #4]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	b.ne	LBB35_7
	b	LBB35_4
LBB35_4:                                ;   in Loop: Header=BB35_1 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.ne	LBB35_7
	b	LBB35_5
LBB35_5:                                ;   in Loop: Header=BB35_1 Depth=1
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.ne	LBB35_7
	b	LBB35_6
LBB35_6:
	ldur	w8, [x29, #-40]
	subs	w8, w8, #1
	stur	w8, [x29, #-4]
	b	LBB35_15
LBB35_7:                                ;   in Loop: Header=BB35_1 Depth=1
	b	LBB35_8
LBB35_8:                                ;   in Loop: Header=BB35_1 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #288]
	ldur	w8, [x29, #-40]
	subs	w8, w8, #1
	mov	w9, #24                         ; =0x18
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #20]
	stur	w8, [x29, #-40]
	b	LBB35_1
LBB35_9:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8, #288]
	ldur	x8, [x29, #-16]
	add	x1, x8, #320
	ldur	x8, [x29, #-16]
	ldr	w2, [x8, #308]
	mov	x3, #24                         ; =0x18
	bl	_eg_grow
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbnz	x8, LBB35_11
	b	LBB35_10
LBB35_10:
	ldur	x9, [x29, #-16]
	adrp	x8, l_.str.156@PAGE
	add	x8, x8, l_.str.156@PAGEOFF
	str	x8, [x9, #360]
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-4]
	b	LBB35_15
LBB35_11:
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #288]
	ldur	x10, [x29, #-16]
	ldr	w8, [x10, #308]
	add	w9, w8, #1
	str	w9, [x10, #308]
	str	w8, [sp, #52]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #288]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	w8, [x29, #-20]
	str	w8, [sp, #28]
	ldur	w8, [x29, #-24]
	str	w8, [sp, #32]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #36]
	ldur	w8, [x29, #-32]
	str	w8, [sp, #40]
	ldur	w8, [x29, #-20]
	adds	w8, w8, #1
	b.ne	LBB35_13
	b	LBB35_12
LBB35_12:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB35_14
LBB35_13:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #288]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #16]
	add	w8, w8, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB35_14
LBB35_14:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #44]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #336]
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	str	w8, [sp, #48]
	ldur	q0, [sp, #28]
	str	q0, [x9]
	ldur	x8, [sp, #44]
	str	x8, [x9, #16]
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #336]
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #52]
	stur	w8, [x29, #-4]
	b	LBB35_15
LBB35_15:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require a bounded instruction fact buffer"

l_.str.1:                               ; @.str.1
	.asciz	"I cannot stage effect/global instruction facts"

l_.str.2:                               ; @.str.2
	.asciz	"I require checked ownership declarations"

l_.str.3:                               ; @.str.3
	.asciz	"I require a bounded acyclic value graph for global flow"

l_.str.4:                               ; @.str.4
	.asciz	"I refuse recursive owned value analysis"

l_.str.5:                               ; @.str.5
	.asciz	"I exceeded my bounded affine analysis size"

l_.str.6:                               ; @.str.6
	.asciz	"I require exact caller-origin parameter authority"

l_.str.7:                               ; @.str.7
	.asciz	"I require decodable function control flow"

l_.str.8:                               ; @.str.8
	.asciz	"I exceeded my bounded affine instruction count"

l_.str.9:                               ; @.str.9
	.asciz	"I require string literals inside an owned value-call graph"

l_.str.10:                              ; @.str.10
	.asciz	"I require string output inside an owned value-call graph"

l_.str.11:                              ; @.str.11
	.asciz	"I require a connected affine instruction contract"

l_.str.12:                              ; @.str.12
	.asciz	"I require a retained exact effect signature at every operation"

l_.str.13:                              ; @.str.13
	.asciz	"I require bounded handler parameter slots"

l_.str.14:                              ; @.str.14
	.asciz	"I require exact declared handler parameter types"

l_.str.15:                              ; @.str.15
	.asciz	"I require an exact declared global slot"

l_.str.16:                              ; @.str.16
	.asciz	"I require exact instruction fact capacity"

l_.str.17:                              ; @.str.17
	.asciz	"I cannot allocate analysis state"

l_.str.18:                              ; @.str.18
	.asciz	"I cannot allocate entry state"

l_.str.19:                              ; @.str.19
	.asciz	"I cannot queue my entry state"

l_.str.20:                              ; @.str.20
	.asciz	"I exceeded my bounded affine visit count"

l_.str.21:                              ; @.str.21
	.asciz	"I cannot allocate an instruction state"

l_.str.22:                              ; @.str.22
	.asciz	"I refuse an observation escape or extra return operands"

l_.str.23:                              ; @.str.23
	.asciz	"I require an exact declared result and no live owned obligations"

l_.str.24:                              ; @.str.24
	.asciz	"I require the active operation result and resolved arm ownership at resumption"

l_.str.25:                              ; @.str.25
	.asciz	"I require an empty stack and resolved owners at my terminal invariant"

l_.str.26:                              ; @.str.26
	.asciz	"I exceeded my bounded affine handler depth"

l_.str.27:                              ; @.str.27
	.asciz	"I cannot allocate handler control-flow state"

l_.str.28:                              ; @.str.28
	.asciz	"I require a fresh exact handler activation"

l_.str.29:                              ; @.str.29
	.asciz	"I require a valid handler entry edge"

l_.str.30:                              ; @.str.30
	.asciz	"I require an instruction at my match target"

l_.str.31:                              ; @.str.31
	.asciz	"I require a checked scalar-union match edge"

l_.str.32:                              ; @.str.32
	.asciz	"I require an instruction at my branch target"

l_.str.33:                              ; @.str.33
	.asciz	"I require an explicit return rather than fallthrough"

l_.str.34:                              ; @.str.34
	.asciz	"I require global initialization before reads and no repeated immutable store"

l_.str.35:                              ; @.str.35
	.asciz	"I cannot allocate converged instruction facts"

l_.str.36:                              ; @.str.36
	.asciz	"I require exact destructive-unpack facts"

l_.str.37:                              ; @.str.37
	.asciz	"%s"

l_.str.38:                              ; @.str.38
	.asciz	"I require a checked acyclic owned value call"

l_.str.39:                              ; @.str.39
	.asciz	"I require a complete consuming argument list"

l_.str.40:                              ; @.str.40
	.asciz	"I require exact positional consuming argument types"

l_.str.41:                              ; @.str.41
	.asciz	"I require complete consuming-helper owner resolution"

l_.str.42:                              ; @.str.42
	.asciz	"I cannot suspend live local owners across an escaping effect call"

l_.str.43:                              ; @.str.43
	.asciz	"I cannot suspend staged owners across an escaping effect call"

l_.str.44:                              ; @.str.44
	.asciz	"I cannot retain escaping operation identities"

l_.str.45:                              ; @.str.45
	.asciz	"I cannot retain a checked value-call result"

l_.str.46:                              ; @.str.46
	.asciz	"I require entry-to-helper reference calls without recursion"

l_.str.47:                              ; @.str.47
	.asciz	"I require checked caller authority and a non-escaping helper"

l_.str.48:                              ; @.str.48
	.asciz	"I require a single scalar reference-call result"

l_.str.49:                              ; @.str.49
	.asciz	"I cannot pop absent or inherited handlers"

l_.str.50:                              ; @.str.50
	.asciz	"I require the exact retained performed signature"

l_.str.51:                              ; @.str.51
	.asciz	"I require exact positional effect argument ownership"

l_.str.52:                              ; @.str.52
	.asciz	"I cannot abandon a staged owner across an effect"

l_.str.53:                              ; @.str.53
	.asciz	"I cannot abandon a local owner or borrow across an effect"

l_.str.54:                              ; @.str.54
	.asciz	"I cannot retain a resumed effect value"

l_.str.55:                              ; @.str.55
	.asciz	"I require a Boolean literal"

l_.str.56:                              ; @.str.56
	.asciz	"I require an instantiated string literal without embedded NUL"

l_.str.57:                              ; @.str.57
	.asciz	"I cannot begin another reference region"

l_.str.58:                              ; @.str.58
	.asciz	"I need a live reference region to end"

l_.str.59:                              ; @.str.59
	.asciz	"I require permitted parent authority and a fresh reborrow in a deeper region"

l_.str.60:                              ; @.str.60
	.asciz	"I require a retained bounded ownership path"

l_.str.61:                              ; @.str.61
	.asciz	"I cannot borrow exclusively while an owner observation is on my stack"

l_.str.62:                              ; @.str.62
	.asciz	"I require an available scalar-leaf resource owner and reference slot in a live region"

l_.str.63:                              ; @.str.63
	.asciz	"I require a live permitted scalar reference field"

l_.str.64:                              ; @.str.64
	.asciz	"I require the exact scalar reference field type"

l_.str.65:                              ; @.str.65
	.asciz	"I cannot move while an owner observation is on my stack"

l_.str.66:                              ; @.str.66
	.asciz	"I require a live unheld owner for an explicit move"

l_.str.67:                              ; @.str.67
	.asciz	"I cannot extend my owned analysis stack"

l_.str.68:                              ; @.str.68
	.asciz	"I require an owned token for an explicit store"

l_.str.69:                              ; @.str.69
	.asciz	"I require an exact available owner destination"

l_.str.70:                              ; @.str.70
	.asciz	"I require the stored union's exact selected arm"

l_.str.71:                              ; @.str.71
	.asciz	"I require every declared field for owned construction"

l_.str.72:                              ; @.str.72
	.asciz	"I require exact scalar or owned fields in declaration order"

l_.str.73:                              ; @.str.73
	.asciz	"I cannot unpack while an owner observation is on my stack"

l_.str.74:                              ; @.str.74
	.asciz	"I require an intact owner and space for all unpacked fields"

l_.str.75:                              ; @.str.75
	.asciz	"I cannot extend my unpacked analysis stack"

l_.str.76:                              ; @.str.76
	.asciz	"I require an exact complete copyable record constructor"

l_.str.77:                              ; @.str.77
	.asciz	"I require exact copyable record fields without owned authority"

l_.str.78:                              ; @.str.78
	.asciz	"I cannot retain a copyable record"

l_.str.79:                              ; @.str.79
	.asciz	"I require explicit owned construction for records"

l_.str.80:                              ; @.str.80
	.asciz	"I require an exact retained scalar-union constructor shape"

l_.str.81:                              ; @.str.81
	.asciz	"I require exact scalar-union payload facts"

l_.str.82:                              ; @.str.82
	.asciz	"I require exact scalar-union fields in declaration order"

l_.str.83:                              ; @.str.83
	.asciz	"I cannot retain a checked scalar-union value"

l_.str.84:                              ; @.str.84
	.asciz	"I require explicit global owner transfers and lifetime before resource storage"

l_.str.85:                              ; @.str.85
	.asciz	"I cannot retain a checked global load"

l_.str.86:                              ; @.str.86
	.asciz	"I require a value for a global store"

l_.str.87:                              ; @.str.87
	.asciz	"I require the exact global type without an owner or observation escape"

l_.str.88:                              ; @.str.88
	.asciz	"I require a live checked local"

l_.str.89:                              ; @.str.89
	.asciz	"I require an exact record local"

l_.str.90:                              ; @.str.90
	.asciz	"I require an exact array local"

l_.str.91:                              ; @.str.91
	.asciz	"I require an exact scalar-union local"

l_.str.92:                              ; @.str.92
	.asciz	"I require an explicit move of a resource union"

l_.str.93:                              ; @.str.93
	.asciz	"I cannot extend my analysis stack"

l_.str.94:                              ; @.str.94
	.asciz	"I refuse an observation escape or missing scalar store"

l_.str.95:                              ; @.str.95
	.asciz	"I require the exact scalar local type"

l_.str.96:                              ; @.str.96
	.asciz	"I require an exact scalar-union match source"

l_.str.97:                              ; @.str.97
	.asciz	"I require a match variant within the concrete union"

l_.str.98:                              ; @.str.98
	.asciz	"I require an exact scalar-union tag source"

l_.str.99:                              ; @.str.99
	.asciz	"I require an exact ordinary record projection"

l_.str.100:                             ; @.str.100
	.asciz	"I refuse an owned ordinary projection"

l_.str.101:                             ; @.str.101
	.asciz	"I cannot retain an ordinary projection"

l_.str.102:                             ; @.str.102
	.asciz	"I require a proven scalar-union variant before projection"

l_.str.103:                             ; @.str.103
	.asciz	"I require an exact scalar-union payload field"

l_.str.104:                             ; @.str.104
	.asciz	"I require destructive unpack for aggregate payloads"

l_.str.105:                             ; @.str.105
	.asciz	"I require a checked scalar field observation"

l_.str.106:                             ; @.str.106
	.asciz	"I refuse to duplicate reference authority"

l_.str.107:                             ; @.str.107
	.asciz	"I refuse unsupported string duplication"

l_.str.108:                             ; @.str.108
	.asciz	"I require a scalar discard; an observation is not an owned consume"

l_.str.109:                             ; @.str.109
	.asciz	"I require PRINT or PRINTLN to consume a string"

l_.str.110:                             ; @.str.110
	.asciz	"I require scalar stack permutation"

l_.str.111:                             ; @.str.111
	.asciz	"I refuse unsupported string permutation"

l_.str.112:                             ; @.str.112
	.asciz	"I require one exact immutable string print operand"

l_.str.113:                             ; @.str.113
	.asciz	"I require an exact Boolean assertion condition"

l_.str.114:                             ; @.str.114
	.asciz	"I require an exact Boolean branch condition"

l_.str.115:                             ; @.str.115
	.asciz	"I require Boolean operands"

l_.str.116:                             ; @.str.116
	.asciz	"I require integer arithmetic operands"

l_.str.117:                             ; @.str.117
	.asciz	"I require float arithmetic operands"

l_.str.118:                             ; @.str.118
	.asciz	"I require float comparison operands"

l_.str.119:                             ; @.str.119
	.asciz	"I require exact STRING equality operands"

l_.str.120:                             ; @.str.120
	.asciz	"I require scalar comparison operands"

l_.str.121:                             ; @.str.121
	.asciz	"I require matching comparison tags"

l_.str.122:                             ; @.str.122
	.asciz	"I require retained element types for array flow"

l_.str.123:                             ; @.str.123
	.asciz	"I require all declared array literal elements"

l_.str.124:                             ; @.str.124
	.asciz	"I require checked empty-array constructor declarations"

l_.str.125:                             ; @.str.125
	.asciz	"I require the exact declared empty-array element tag"

l_.str.126:                             ; @.str.126
	.asciz	"I require an unambiguous retained element type for empty array construction"

l_.str.127:                             ; @.str.127
	.asciz	"I require an exact retained array literal element type"

l_.str.128:                             ; @.str.128
	.asciz	"I require exact array literal element ownership in source order"

l_.str.129:                             ; @.str.129
	.asciz	"I cannot retain an array construction result"

l_.str.130:                             ; @.str.130
	.asciz	"I require every array operation operand"

l_.str.131:                             ; @.str.131
	.asciz	"I require an exact array operand"

l_.str.132:                             ; @.str.132
	.asciz	"I require a live owner observation for resource-array length"

l_.str.133:                             ; @.str.133
	.asciz	"I cannot retain array length"

l_.str.134:                             ; @.str.134
	.asciz	"I cannot mutate or extract through an array owner observation"

l_.str.135:                             ; @.str.135
	.asciz	"I require explicit resource-element extraction and disposal contracts"

l_.str.136:                             ; @.str.136
	.asciz	"I require an integer array index"

l_.str.137:                             ; @.str.137
	.asciz	"I require an integer slice end"

l_.str.138:                             ; @.str.138
	.asciz	"I require the exact array element type and ownership"

l_.str.139:                             ; @.str.139
	.asciz	"I cannot retain an array operation result"

l_.str.140:                             ; @.str.140
	.asciz	"I require identical handler context at every control-flow join"

l_.str.141:                             ; @.str.141
	.asciz	"I require exact ownership and stack provenance at every join"

l_.str.142:                             ; @.str.142
	.asciz	"I require one global declaration domain at every join"

l_.str.143:                             ; @.str.143
	.asciz	"I cannot allocate an analysis branch"

l_.str.144:                             ; @.str.144
	.asciz	"I exceeded my bounded affine worklist"

l_.str.145:                             ; @.str.145
	.asciz	"I cannot allocate effect/global control indexes"

l_.str.146:                             ; @.str.146
	.asciz	"I require decodable effect/global control flow"

l_.str.147:                             ; @.str.147
	.asciz	"I cannot retain bounded effect/global activation states"

l_.str.148:                             ; @.str.148
	.asciz	"I require an exact effect/global continuation"

l_.str.149:                             ; @.str.149
	.asciz	"I exceeded my effect/global control-state storage budget"

l_.str.150:                             ; @.str.150
	.asciz	"I require an active effect/global resumption"

l_.str.151:                             ; @.str.151
	.asciz	"I require a declared effect/global slot"

l_.str.152:                             ; @.str.152
	.asciz	"I require global initialization before reads and no repeated immutable store across effects"

l_.str.153:                             ; @.str.153
	.asciz	"I require a declared effect/global callee"

l_.str.154:                             ; @.str.154
	.asciz	"I cannot pop an absent or inherited effect/global handler"

l_.str.155:                             ; @.str.155
	.asciz	"I require an exact effect/global branch target"

l_.str.156:                             ; @.str.156
	.asciz	"I cannot retain bounded effect/global handler states"

.subsections_via_symbols
