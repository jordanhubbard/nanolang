from pathlib import Path
import json,sys,gzip,hashlib,subprocess,os,re
root=Path('/Users/jkh/.worktrees/nanolang/post-bootstrap-qualification-20261121');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='bdffa4cccff93ed5b6870aa2f74289f94f2643ee';sys.path.insert(0,str(root));from scripts.bootstrap_nanoisa import Bootstrap,digest
b=Bootstrap(root,1800,30);b.load();b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));assert all(b.imports(root/'bin'/('nanoc_'+stage+'.nvm'))==b.manifest['hosts'] for stage in ['seed','stage1','stage2']);assert (root/'bin/nanoc_stage1.nvm').read_bytes()==(root/'bin/nanoc_stage2.nvm').read_bytes();assert os.readlink(root/'bin/nanoc')=='nanoc_stage2';assert (root/'.bootstrap3.built').is_file();assert not (b.work/'unexpected-native-compiler').exists()
controller=root/'.test_output/current-darwin-bootstrap';state=json.loads((controller/'manifest.json').read_text());assert state['status']=='passed';out=root/'.test_output/preserved-darwin-bdffa4ccc-20261121';(out/'inputs').mkdir(parents=True,exist_ok=False);paths={Path(__file__).resolve(),root/'bin/nanoc_bootstrap.json',root/'.bootstrap3.built',root/'.test_output/run-current-darwin-bootstrap.py'}
paths.update(p for p in b.work.rglob('*') if p.is_file());paths.update(p for p in controller.rglob('*') if p.is_file() and 'module-cache' not in p.relative_to(controller).parts)
for name in b.manifest['sources']:
 p=root/name
 if p.is_file():paths.add(p)
for name in ['nano_virt','nano_vm','nanoisa','nvm2c','nano_aot_runtime.o','nanoc_c','nano_cop','nano_vmd',*b.manifest['artifacts']]:
 p=root/'bin'/name
 if p.is_file():paths.add(p)
for library in b.manifest['hosts']:paths.update(p for p in Path(library).parent.rglob('*') if p.is_file())
log=(controller/'original-vm-heap-controls.stdout').read_text()
for directory in re.findall(r'I retain (?:heap|ordinary heap|string heap) artifacts at (/[^\n]+)',log):paths.update(p for p in Path(directory).rglob('*') if p.is_file())
analysis=dict(pin=state['pin'],steps=b.manifest['steps'],original_commands=state['steps'],guards_unchanged=True,raw_equal=True,raw_sha256=digest(root/'bin/nanoc_stage1.nvm'),raw_bytes=(root/'bin/nanoc_stage1.nvm').stat().st_size,hosts=b.manifest['hosts'],receipt_sha256=digest(root/'bin/nanoc_bootstrap.json'),cache=b.manifest.get('module_build_cache'),installed_link=os.readlink(root/'bin/nanoc'),bootstrap3_sentinel=True,vm_terminal_lines=[line for line in log.splitlines() if '569591' in line],limits=['I preserve successful exact-source bdffa4ccc Darwin bootstrap and original VM/heap gates. These bytes do not qualify later parser/checker/workflow changes or explain the different-pin c908523c3 timeout. I do not rewrite raw imports or substitute stages.'])
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');paths.add(out/'analysis.json');sha=lambda x:hashlib.sha256(x).hexdigest();seen={};entries=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes();h=sha(raw);artifact=seen.get(h,out/'inputs'/f'{i:04d}-{p.name}.gz')
 if h not in seen:artifact.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0));seen[h]=artifact
 packed=artifact.read_bytes();entries.append(dict(path=str(p),artifact=str(artifact.relative_to(out)),sha256=h,bytes=len(raw),compressed_sha256=sha(packed),compressed_bytes=len(packed)))
b.check_inputs();b.check_artifacts(list(b.manifest['artifacts']));(out/'manifest.json').write_text(json.dumps(dict(files=entries,analysis=analysis),indent=2)+'\n')
for e in entries:
 packed=(out/e['artifact']).read_bytes();assert sha(packed)==e['compressed_sha256'] and sha(gzip.decompress(packed))==e['sha256']
print(json.dumps(dict(out=str(out),files=len(entries),raw_bytes=sum(e['bytes'] for e in entries),unique_compressed_bytes=sum(p.stat().st_size for p in seen.values()),raw_sha256=analysis['raw_sha256'],raw_bytes_per_stage=analysis['raw_bytes'],steps=[(s['label'],s['elapsed_seconds'],s['exit_code']) for s in b.manifest['steps']])))
