	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_file_product_new            ; -- Begin function nl_file_product_new
	.p2align	2
_nl_file_product_new:                   ; @nl_file_product_new
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_13
; %bb.1:
	ldrb	w8, [x0]
	cbz	w8, LBB0_12
; %bb.2:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x1
	mov	x24, x2
	mov	x20, x0
	bl	_strlen
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	cbz	x19, LBB0_17
; %bb.3:
	cmp	x8, #1, lsl #12                 ; =4096
	b.hi	LBB0_17
; %bb.4:
	ldrb	w8, [x19]
	cbz	w8, LBB0_16
; %bb.5:
	mov	x0, x19
	bl	_strlen
	mov	x21, x0
	mov	x0, #0                          ; =0x0
	cmp	x24, #7
	b.hi	LBB0_17
; %bb.6:
	cmp	x21, #1, lsl #12                ; =4096
	b.hi	LBB0_17
; %bb.7:
	mov	w0, #1                          ; =0x1
	mov	w1, #2176                       ; =0x880
	bl	_calloc
	cbz	x0, LBB0_17
; %bb.8:
	mov	x25, x0
	mov	x0, x20
	bl	_strlen
	mov	x23, x0
	add	x0, x0, #1
	bl	_malloc
	mov	x22, x0
	cbz	x0, LBB0_10
; %bb.9:
	add	x2, x23, #1
	mov	x0, x22
	mov	x1, x20
	bl	_memcpy
LBB0_10:
	str	x22, [x25]
	add	x0, x21, #1
	bl	_malloc
	cbz	x0, LBB0_14
; %bb.11:
	add	x2, x21, #1
	mov	x20, x0
	mov	x1, x19
	bl	_memcpy
	mov	x0, x25
	str	x20, [x25, #8]
	str	x24, [x25, #2168]
	cbnz	x22, LBB0_17
	b	LBB0_15
LBB0_12:
	mov	x0, #0                          ; =0x0
LBB0_13:
	ret
LBB0_14:
	mov	x0, x25
	str	x24, [x25, #2168]
LBB0_15:
	bl	_nl_file_product_free
LBB0_16:
	mov	x0, #0                          ; =0x0
LBB0_17:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function copy_text
_copy_text:                             ; @copy_text
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_strlen
	mov	x20, x0
	add	x0, x0, #1
	bl	_malloc
	cbz	x0, LBB1_2
; %bb.1:
	add	x2, x20, #1
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_memcpy
LBB1_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_product_free           ; -- Begin function nl_file_product_free
	.p2align	2
_nl_file_product_free:                  ; @nl_file_product_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x0, [x0, #56]
	bl	_free
	ldr	x0, [x19, #64]
	bl	_free
	ldr	x0, [x19]
	bl	_free
	ldr	x0, [x19, #8]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x8, [x19, #104]
	cbz	x8, LBB2_4
; %bb.2:
	mov	x20, #0                         ; =0x0
	add	x21, x19, #136
LBB2_3:                                 ; =>This Inner Loop Header: Depth=1
	ldur	x0, [x21, #-24]
	bl	_free
	ldur	x0, [x21, #-8]
	bl	_free
	ldr	x0, [x21], #32
	bl	_free
	add	x20, x20, #1
	ldr	x8, [x19, #104]
	cmp	x20, x8
	b.lo	LBB2_3
LBB2_4:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_free
LBB2_5:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_product_valid          ; -- Begin function nl_file_product_valid
	.p2align	2
_nl_file_product_valid:                 ; @nl_file_product_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_4
; %bb.1:
	ldrb	w8, [x0, #2160]
	tbz	w8, #0, LBB3_3
; %bb.2:
	mov	x0, #0                          ; =0x0
	ret
LBB3_3:
	ldrb	w8, [x0, #2161]
	eor	x0, x8, #0x1
LBB3_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nl_file_product_websocket
lCPI4_0:
	.long	60000                           ; 0xea60
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_file_product_websocket
	.p2align	2
_nl_file_product_websocket:             ; @nl_file_product_websocket
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_3
; %bb.1:
	ldrb	w8, [x0, #2160]
	tbnz	w8, #0, LBB4_3
; %bb.2:
	ldrb	w8, [x0, #2161]
	tbz	w8, #0, LBB4_4
LBB4_3:
	mov	w0, #1                          ; =0x1
	ret
LBB4_4:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldrb	w8, [x0, #24]
	tbnz	w8, #0, LBB4_6
; %bb.5:
	ldr	x8, [x0, #72]
	cbz	x8, LBB4_8
LBB4_6:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #2160]
	mov	w0, #1                          ; =0x1
LBB4_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB4_8:
	cbz	x2, LBB4_6
; %bb.9:
	cmp	x1, #3
	b.hi	LBB4_6
; %bb.10:
	ldr	x8, [x0, #64]
	cbnz	x8, LBB4_6
; %bb.11:
	mov	x19, x0
	mov	x0, x2
	mov	x20, x1
	mov	x21, x2
	bl	_strlen
	mov	x9, x0
	mov	x0, x19
	cmp	x9, #4095
	b.hi	LBB4_6
; %bb.12:
	mov	x8, x21
	mov	x10, x20
	cmp	x20, #1
	cset	w11, hi
	ldrb	w9, [x21]
	cmp	w9, #0
	cset	w12, ne
	eor	w11, w11, w12
	tbnz	w11, #0, LBB4_6
; %bb.13:
	cmp	w9, #47
	b.eq	LBB4_16
; %bb.14:
	cbnz	w9, LBB4_6
; %bb.15:
	ldr	x8, [x0, #16]
	b	LBB4_17
LBB4_16:
	mov	x0, x8
	bl	_copy_text
	mov	x10, x20
	mov	x8, x0
	mov	x0, x19
	str	x8, [x19, #16]
	cbz	x8, LBB4_6
LBB4_17:
	cmp	x10, #1
	cset	w11, hi
	and	w10, w10, #0x1
	mov	w12, #1                         ; =0x1
	str	w12, [x0, #32]
	strb	w10, [x0, #36]
	strb	w11, [x0, #37]
	strh	wzr, [x0, #38]
Lloh0:
	adrp	x10, lCPI4_0@PAGE
Lloh1:
	ldr	d0, [x10, lCPI4_0@PAGEOFF]
	str	d0, [x0, #40]
	str	x8, [x0, #48]
	strb	w12, [x0, #24]
	mov	x0, #0                          ; =0x0
	b	LBB4_7
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_product_append         ; -- Begin function nl_file_product_append
	.p2align	2
_nl_file_product_append:                ; @nl_file_product_append
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_3
; %bb.1:
	ldrb	w8, [x0, #2160]
	tbnz	w8, #0, LBB5_3
; %bb.2:
	ldrb	w8, [x0, #2161]
	tbz	w8, #0, LBB5_4
LBB5_3:
	mov	w0, #1                          ; =0x1
	ret
LBB5_4:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x1, LBB5_8
; %bb.5:
	mov	x22, x0
	mov	x0, x1
	mov	x23, x1
	bl	_strlen
	mov	x19, x0
	mov	x0, x22
	sub	x8, x19, #1
	lsr	x8, x8, #13
	cbnz	x8, LBB5_8
; %bb.6:
	tbnz	w19, #0, LBB5_8
; %bb.7:
	lsr	x21, x19, #1
	ldr	x8, [x0, #88]
	mov	w10, #67108864                  ; =0x4000000
	sub	x8, x10, x8
	cmp	x21, x8
	b.ls	LBB5_10
LBB5_8:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #2160]
	mov	w0, #1                          ; =0x1
LBB5_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB5_10:
	mov	x9, x23
	mov	x8, #0                          ; =0x0
LBB5_11:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9, x8]
	sub	w10, w11, #48
	cmp	w10, #9
	b.ls	LBB5_14
; %bb.12:                               ;   in Loop: Header=BB5_11 Depth=1
	sub	w10, w11, #97
	cmp	w10, #5
	b.hi	LBB5_8
; %bb.13:                               ;   in Loop: Header=BB5_11 Depth=1
	sub	w10, w11, #87
LBB5_14:                                ;   in Loop: Header=BB5_11 Depth=1
	tbnz	w10, #31, LBB5_8
; %bb.15:                               ;   in Loop: Header=BB5_11 Depth=1
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	LBB5_11
; %bb.16:
	ldp	x8, x10, [x0, #72]
	add	x8, x8, x21
	cmp	x8, x10
	b.ls	LBB5_21
; %bb.17:
	mov	w9, #4096                       ; =0x1000
	cmp	x10, #0
	csel	x9, x9, x10, eq
LBB5_18:                                ; =>This Inner Loop Header: Depth=1
	mov	x20, x9
	lsl	x9, x9, #1
	cmp	x20, x8
	b.lo	LBB5_18
; %bb.19:
	ldr	x0, [x0, #56]
	mov	x1, x20
	bl	_realloc
	mov	x8, x0
	mov	x0, x22
	cbz	x8, LBB5_8
; %bb.20:
	mov	x9, x23
	str	x8, [x0, #56]
	str	x20, [x0, #80]
LBB5_21:
	mov	x8, #0                          ; =0x0
	mov	w10, #15                        ; =0xf
LBB5_22:                                ; =>This Inner Loop Header: Depth=1
	add	x11, x9, x8
	ldrb	w12, [x11]
	sub	w13, w12, #48
	sub	w14, w12, #97
	add	w15, w12, #9
	cmp	w14, #6
	csel	w14, w15, w10, lo
	cmp	w13, #10
	csel	w12, w12, w14, lo
	ldrb	w11, [x11, #1]
	sub	w13, w11, #48
	sub	w14, w11, #97
	sub	w11, w11, #87
	cmp	w14, #6
	csinv	w11, w11, wzr, lo
	cmp	w13, #10
	csel	w11, w13, w11, lo
	add	w11, w11, w12, lsl #4
	ldr	x12, [x0, #56]
	ldr	x13, [x0, #72]
	add	x14, x13, #1
	str	x14, [x0, #72]
	strb	w11, [x12, x13]
	add	x8, x8, #2
	cmp	x8, x19
	b.lo	LBB5_22
; %bb.23:
	ldr	x9, [x0, #88]
	add	x9, x9, x21
	str	x9, [x0, #88]
	mov	x0, #0                          ; =0x0
	b	LBB5_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_product_seal           ; -- Begin function nl_file_product_seal
	.p2align	2
_nl_file_product_seal:                  ; @nl_file_product_seal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_3
; %bb.1:
	ldrb	w8, [x0, #2160]
	tbnz	w8, #0, LBB6_3
; %bb.2:
	ldrb	w8, [x0, #2161]
	tbz	w8, #0, LBB6_4
LBB6_3:
	mov	w0, #1                          ; =0x1
	ret
LBB6_4:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x1, LBB6_20
; %bb.5:
	mov	x21, x0
	ldr	x19, [x21, #72]!
	cbz	x19, LBB6_20
; %bb.6:
	ldrb	w8, [x1]
	cbz	w8, LBB6_20
; %bb.7:
	mov	x22, x0
	mov	x0, x1
	mov	x20, x2
	mov	x23, x1
	bl	_strlen
	mov	x9, x0
	mov	x0, x22
	cbz	x20, LBB6_20
; %bb.8:
	cmp	x9, #1, lsl #12                 ; =4096
	b.hi	LBB6_20
; %bb.9:
	mov	x0, x20
	bl	_strlen
	mov	x9, x0
	mov	x0, x22
	cmp	x9, #1, lsl #12                 ; =4096
	b.hi	LBB6_20
; %bb.10:
	ldr	x10, [x0, #64]
	ldrb	w9, [x20]
	cbz	x10, LBB6_16
; %bb.11:
	cbz	w9, LBB6_20
; %bb.12:
	ldr	x9, [x0, #104]
	cmp	x9, #64
	b.eq	LBB6_20
; %bb.13:
	mov	x0, x23
	bl	_copy_text
	mov	x19, x0
	mov	x0, x20
	bl	_copy_text
	mov	x20, x0
	cbz	x19, LBB6_19
; %bb.14:
	cbz	x20, LBB6_19
; %bb.15:
	mov	x0, x22
	ldr	x8, [x22, #104]
	add	x9, x22, x8, lsl #5
	add	x8, x8, #1
	str	x8, [x22, #104]
	ldr	x8, [x22, #56]
	ldr	x10, [x22, #72]
	stp	x8, x10, [x9, #112]
	stp	x19, x20, [x9, #128]
	b	LBB6_18
LBB6_16:
	cbnz	w9, LBB6_20
; %bb.17:
	ldr	x8, [x0, #56]
	str	x8, [x0, #64]
	str	x19, [x0, #96]
LBB6_18:
	str	xzr, [x0, #56]
	mov	x0, #0                          ; =0x0
	stp	xzr, xzr, [x21]
	b	LBB6_21
LBB6_19:
	mov	x0, x19
	bl	_free
	mov	x0, x20
	bl	_free
	mov	x0, x22
LBB6_20:
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #2160]
	mov	w0, #1                          ; =0x1
LBB6_21:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_file_product_publish        ; -- Begin function nl_file_product_publish
	.p2align	2
_nl_file_product_publish:               ; @nl_file_product_publish
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_2
; %bb.1:
	ldrb	w8, [x0, #2160]
	tbz	w8, #0, LBB7_3
LBB7_2:
	mov	w0, #1                          ; =0x1
	ret
LBB7_3:
	mov	x8, x0
	ldrb	w9, [x0, #2161]
	mov	w0, #1                          ; =0x1
	tbz	w9, #0, LBB7_5
; %bb.4:
	ret
LBB7_5:
	sub	sp, sp, #96
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	strb	w0, [x8, #2161]
	ldr	x19, [x8, #64]
	cbz	x19, LBB7_12
; %bb.6:
	ldr	x9, [x8, #72]
	cbz	x9, LBB7_8
; %bb.7:
	mov	w0, #1                          ; =0x1
	b	LBB7_12
LBB7_8:
	mov	x20, x8
Lloh2:
	adrp	x0, l_.str@PAGE
Lloh3:
	add	x0, x0, l_.str@PAGEOFF
	bl	_getenv
	cbz	x0, LBB7_10
; %bb.9:
	ldrb	w8, [x0]
	cbnz	w8, LBB7_11
LBB7_10:
Lloh4:
	adrp	x0, l_.str.1@PAGE
Lloh5:
	add	x0, x0, l_.str.1@PAGEOFF
	bl	_getenv
LBB7_11:
	ldr	q0, [x20]
	str	q0, [sp]
	str	x0, [sp, #16]
Lloh6:
	adrp	x0, l_.str.2@PAGE
Lloh7:
	add	x0, x0, l_.str.2@PAGEOFF
	bl	_getenv
	str	x0, [sp, #24]
Lloh8:
	adrp	x0, l_.str.3@PAGE
Lloh9:
	add	x0, x0, l_.str.3@PAGEOFF
	bl	_getenv
	str	x0, [sp, #32]
	ldrb	w8, [x20, #2168]
	and	w9, w8, #0x1
	strb	w9, [sp, #40]
	ubfx	w9, w8, #1, #1
	strb	w9, [sp, #41]
	strb	wzr, [sp, #42]
	ubfx	w8, w8, #2, #1
	strb	w8, [sp, #43]
	str	wzr, [sp, #44]
	ldrb	w8, [x20, #24]
	add	x9, x20, #32
	cmp	w8, #0
	csel	x8, x9, xzr, ne
	str	x8, [sp, #48]
	ldp	x1, x3, [x20, #96]
	add	x2, x20, #112
	mov	x4, sp
	mov	x0, x19
	bl	_nl_service_publish
                                        ; kill: def $w0 killed $w0 def $x0
	sxtw	x0, w0
LBB7_12:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"NANO_CC"

l_.str.1:                               ; @.str.1
	.asciz	"CC"

l_.str.2:                               ; @.str.2
	.asciz	"NANO_CFLAGS"

l_.str.3:                               ; @.str.3
	.asciz	"NANO_LDFLAGS"

.subsections_via_symbols
