	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_service_bindings_present ; -- Begin function nvm_service_bindings_present
	.globl	_nvm_service_bindings_present
	.p2align	2
_nvm_service_bindings_present:          ; @nvm_service_bindings_present
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_8
; %bb.1:
	ldr	x8, [x0, #328]
	cbnz	x8, LBB0_3
; %bb.2:
	ldr	w8, [x0, #336]
	cbz	w8, LBB0_4
LBB0_3:
	mov	w0, #1                          ; =0x1
	ret
LBB0_4:
	ldr	x8, [x0, #400]
	cbz	x8, LBB0_9
; %bb.5:
	ldr	w9, [x0, #432]
	cbz	w9, LBB0_9
; %bb.6:
	sub	x9, x9, #1
	add	x8, x8, #11
LBB0_7:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x8], #12
	cmp	w10, #3
	cset	w0, eq
	ccmp	x9, #0, #4, ne
	sub	x9, x9, #1
	b.ne	LBB0_7
LBB0_8:
	ret
LBB0_9:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_service_bindings_present ; -- Begin function nvm_v2_service_bindings_present
	.globl	_nvm_v2_service_bindings_present
	.p2align	2
_nvm_v2_service_bindings_present:       ; @nvm_v2_service_bindings_present
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_9
; %bb.1:
	ldr	x8, [x0, #216]
	cbnz	x8, LBB1_8
; %bb.2:
	ldr	w8, [x0, #224]
	cbnz	w8, LBB1_8
; %bb.3:
	ldrb	w8, [x0, #241]
	tbnz	w8, #1, LBB1_8
; %bb.4:
	ldr	x8, [x0, #104]
	cbz	x8, LBB1_10
; %bb.5:
	ldr	w9, [x0, #112]
	cbz	w9, LBB1_10
; %bb.6:
	sub	x9, x9, #1
	add	x8, x8, #12
LBB1_7:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x8], #16
	cmp	w10, #3
	cset	w0, eq
	ccmp	x9, #0, #4, ne
	sub	x9, x9, #1
	b.ne	LBB1_7
	b	LBB1_9
LBB1_8:
	mov	w0, #1                          ; =0x1
LBB1_9:
	ret
LBB1_10:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_file_instructions_present ; -- Begin function nvm_v2_file_instructions_present
	.globl	_nvm_v2_file_instructions_present
	.p2align	2
_nvm_v2_file_instructions_present:      ; @nvm_v2_file_instructions_present
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_12
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x8, [x0, #72]
	cbz	x8, LBB2_10
; %bb.2:
	ldr	x8, [x19, #168]
	cbz	x8, LBB2_10
; %bb.3:
	ldr	w8, [x19, #80]
	cbz	w8, LBB2_10
; %bb.4:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB2_6
LBB2_5:                                 ;   in Loop: Header=BB2_6 Depth=1
	add	x21, x21, #1
	add	x20, x20, #32
	cmp	x21, x8
	b.hs	LBB2_10
LBB2_6:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19, #72]
	add	x10, x9, x20
	ldr	x9, [x10, #8]
	ldr	x11, [x19, #176]
	subs	x11, x11, x9
	b.lo	LBB2_5
; %bb.7:                                ;   in Loop: Header=BB2_6 Depth=1
	ldr	x1, [x10, #16]
	cmp	x1, x11
	b.hi	LBB2_5
; %bb.8:                                ;   in Loop: Header=BB2_6 Depth=1
	ldr	x8, [x19, #168]
	add	x0, x8, x9
	bl	_isa_code_has_file_instructions
	tbnz	w0, #0, LBB2_13
; %bb.9:                                ;   in Loop: Header=BB2_6 Depth=1
	ldr	w8, [x19, #80]
	b	LBB2_5
LBB2_10:
	mov	w0, #0                          ; =0x0
LBB2_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB2_12:
	ret
LBB2_13:
	mov	w0, #1                          ; =0x1
	b	LBB2_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_execution_pending ; -- Begin function nvm_service_execution_pending
	.globl	_nvm_service_execution_pending
	.p2align	2
_nvm_service_execution_pending:         ; @nvm_service_execution_pending
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_9
; %bb.1:
	ldr	x8, [x0, #328]
	cbnz	x8, LBB3_3
; %bb.2:
	ldr	w8, [x0, #336]
	cbz	w8, LBB3_4
LBB3_3:
	mov	w0, #1                          ; =0x1
	ret
LBB3_4:
	ldr	x9, [x0, #400]
	cbz	x9, LBB3_9
; %bb.5:
	ldr	w8, [x0, #432]
	cbz	w8, LBB3_9
; %bb.6:
	add	x9, x9, #11
LBB3_7:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #12
	cmp	w10, #3
	b.eq	LBB3_3
; %bb.8:                                ;   in Loop: Header=BB3_7 Depth=1
	subs	x8, x8, #1
	b.ne	LBB3_7
LBB3_9:
	b	_nvm_file_instructions_present
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_classify   ; -- Begin function nvm_service_classify
	.globl	_nvm_service_classify
	.p2align	2
_nvm_service_classify:                  ; @nvm_service_classify
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB4_9
; %bb.1:
	ldr	x8, [x0, #328]
	cbnz	x8, LBB4_3
; %bb.2:
	ldr	w8, [x0, #336]
	cbz	w8, LBB4_4
LBB4_3:
	mov	w1, #1                          ; =0x1
	b	LBB4_10
LBB4_4:
	ldr	x9, [x0, #400]
	cbz	x9, LBB4_9
; %bb.5:
	ldr	w8, [x0, #432]
	cbz	w8, LBB4_9
; %bb.6:
	add	x9, x9, #11
	mov	w1, #1                          ; =0x1
LBB4_7:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #12
	cmp	w10, #3
	b.eq	LBB4_10
; %bb.8:                                ;   in Loop: Header=BB4_7 Depth=1
	subs	x8, x8, #1
	b.ne	LBB4_7
LBB4_9:
	mov	x19, x0
	bl	_nvm_file_instructions_present
	mov	x8, x0
	mov	x0, x19
	mov	w1, w8
LBB4_10:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_pending_classified ; -- Begin function nvm_service_pending_classified
	.globl	_nvm_service_pending_classified
	.p2align	2
_nvm_service_pending_classified:        ; @nvm_service_pending_classified
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB5_2
; %bb.1:
	ldr	x8, [x1]
	cmp	x8, x0
	b.eq	LBB5_6
LBB5_2:
	cbz	x0, LBB5_12
; %bb.3:
	ldr	x8, [x0, #328]
	cbnz	x8, LBB5_5
; %bb.4:
	ldr	w8, [x0, #336]
	cbz	w8, LBB5_7
LBB5_5:
	mov	w0, #1                          ; =0x1
	ret
LBB5_6:
	ldrb	w0, [x1, #8]
	ret
LBB5_7:
	ldr	x9, [x0, #400]
	cbz	x9, LBB5_12
; %bb.8:
	ldr	w8, [x0, #432]
	cbz	w8, LBB5_12
; %bb.9:
	add	x9, x9, #11
LBB5_10:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #12
	cmp	w10, #3
	b.eq	LBB5_5
; %bb.11:                               ;   in Loop: Header=BB5_10 Depth=1
	subs	x8, x8, #1
	b.ne	LBB5_10
LBB5_12:
	b	_nvm_file_instructions_present
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_private_nominal_wire
lCPI6_0:
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_private_nominal_wire
	.globl	_nvm_private_nominal_wire
	.p2align	2
_nvm_private_nominal_wire:              ; @nvm_private_nominal_wire
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	mov	w9, #6944                       ; =0x1b20
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2848
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	mov	w19, #8                         ; =0x8
	cbz	w2, LBB6_9
; %bb.1:
	cbz	w1, LBB6_9
; %bb.2:
	cbz	x0, LBB6_9
; %bb.3:
	cbz	x3, LBB6_9
; %bb.4:
	ldr	w9, [x0, #112]
	cmp	w9, w1
	b.lo	LBB6_9
; %bb.5:
	cmp	w9, #320
	b.hi	LBB6_9
; %bb.6:
	ldr	x10, [x0, #104]
	cbz	x10, LBB6_9
; %bb.7:
	ldr	w8, [x0, #144]
	cbnz	w8, LBB6_9
; %bb.8:
	ldr	w8, [x0, #128]
	cbz	w8, LBB6_11
LBB6_9:
	ldur	x8, [x29, #-72]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB6_74
; %bb.10:
	mov	x0, x19
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2848
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB6_11:
	ldr	x8, [x0, #184]
	cbz	x8, LBB6_9
; %bb.12:
	ldr	w8, [x0, #192]
	cbz	w8, LBB6_9
; %bb.13:
	mov	w12, w2
	ldr	w11, [x0, #64]
	cmp	x11, x12
	b.lo	LBB6_9
; %bb.14:
	cmp	x11, #16, lsl #12               ; =65536
	b.hi	LBB6_9
; %bb.15:
	ldur	x13, [x0, #56]
	cbz	x13, LBB6_9
; %bb.16:
	ldr	w12, [x0, #32]
	cbz	w12, LBB6_18
; %bb.17:
	ldr	x14, [x0, #24]
	cbz	x14, LBB6_9
LBB6_18:
	ldr	w23, [x0, #80]
	cbz	w23, LBB6_20
; %bb.19:
	ldr	x14, [x0, #72]
	cbz	x14, LBB6_9
LBB6_20:
	ldr	w14, [x0, #48]
	cbz	w14, LBB6_23
; %bb.21:
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #43690, lsl #16
	umull	x8, w8, w15
	lsr	x8, x8, #35
	cmp	w23, w8
	b.hi	LBB6_9
; %bb.22:
	ldr	x8, [x0, #40]
	cbnz	x8, LBB6_24
	b	LBB6_9
LBB6_23:
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #43690, lsl #16
	umull	x8, w8, w15
	lsr	x8, x8, #35
	cmp	w23, w8
	b.hi	LBB6_9
LBB6_24:
	mov	w15, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #480]
	lsl	x8, x12, #3
	lsl	x19, x12, #2
	stp	q1, q1, [sp, #448]
	add	x17, x23, x23, lsl #1
	stp	q1, q1, [sp, #416]
	lsl	x21, x17, #3
	lsl	x25, x23, #3
	stp	q1, q1, [sp, #384]
	stp	q1, q1, [sp, #352]
	stp	q1, q1, [sp, #320]
	stp	q1, q1, [sp, #288]
	stp	q1, q1, [sp, #256]
	stp	q1, q1, [sp, #224]
	stp	q1, q1, [sp, #192]
	stp	q1, q1, [sp, #160]
	stp	q1, q1, [sp, #128]
	stp	q1, q1, [sp, #96]
	stp	q1, q1, [sp, #64]
	movi.2d	v0, #0000000000000000
	add	x17, sp, #48
	str	q1, [sp, #48]
	add	x17, x17, #468
	mov	w1, #4                          ; =0x4
	mov	w2, #-9                         ; =0xfffffff7
Lloh8:
	adrp	x4, lCPI6_0@PAGE
Lloh9:
	ldr	d1, [x4, lCPI6_0@PAGEOFF]
	mov	w4, #12                         ; =0xc
	str	xzr, [sp, #512]
LBB6_25:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_30 Depth 2
	add	x7, x13, x16, lsl #4
	ldrb	w5, [x7]
	cmp	w5, #3
	b.hi	LBB6_38
; %bb.26:                               ;   in Loop: Header=BB6_25 Depth=1
	ldrh	w6, [x7, #2]
	cbz	x6, LBB6_32
; %bb.27:                               ;   in Loop: Header=BB6_25 Depth=1
	ldr	x7, [x7, #8]
	cbz	x7, LBB6_38
; %bb.28:                               ;   in Loop: Header=BB6_25 Depth=1
	umaddl	x1, w6, w4, x1
	add	x1, x1, #8
	lsr	x20, x1, #32
	cbnz	x20, LBB6_37
; %bb.29:                               ;   in Loop: Header=BB6_25 Depth=1
	add	x7, x7, #4
LBB6_30:                                ;   Parent Loop BB6_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w20, [x7], #12
	cmn	w20, #1
	ccmp	x20, x16, #0, ne
	b.hs	LBB6_37
; %bb.31:                               ;   in Loop: Header=BB6_30 Depth=2
	subs	x6, x6, #1
	b.ne	LBB6_30
	b	LBB6_34
LBB6_32:                                ;   in Loop: Header=BB6_25 Depth=1
	cmp	x1, x2
	b.hi	LBB6_37
; %bb.33:                               ;   in Loop: Header=BB6_25 Depth=1
	add	x1, x1, #8
LBB6_34:                                ;   in Loop: Header=BB6_25 Depth=1
	dup.2s	v2, w5
	cmp	w5, #2
	cinc	w15, w15, eq
	cmeq.2s	v2, v2, v1
	sub.2s	v0, v0, v2
	add	x16, x16, #1
	cmp	x16, x11
	b.ne	LBB6_25
; %bb.35:
	stp	x10, x9, [sp, #16]              ; 16-byte Folded Spill
	str	w14, [sp, #36]                  ; 4-byte Folded Spill
	stp	x3, x1, [sp]                    ; 16-byte Folded Spill
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	str	w15, [sp, #524]
	str	d0, [x17]
	mov	x22, x12
	cbz	w12, LBB6_39
; %bb.36:
	mov	x0, x8
	bl	_malloc
	mov	x24, x0
	str	x0, [sp, #280]
	mov	x0, x19
	bl	_malloc
	mov	x20, x0
	b	LBB6_40
LBB6_37:
	mov	w19, #13                        ; =0xd
	b	LBB6_9
LBB6_38:
	mov	w19, #8                         ; =0x8
	b	LBB6_9
LBB6_39:
	mov	x24, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
LBB6_40:
	str	x20, [sp, #288]
	cbz	w23, LBB6_42
; %bb.41:
	mov	w0, #1                          ; =0x1
	mov	x1, x21
	bl	_calloc
	mov	x21, x0
	str	x0, [sp, #304]
	mov	w0, #1                          ; =0x1
	mov	x1, x25
	bl	_calloc
	b	LBB6_43
LBB6_42:
	mov	x21, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	str	xzr, [sp, #304]
LBB6_43:
	mov	x25, #0                         ; =0x0
	cmp	w23, #0
	cset	w8, eq
	cmp	x21, #0
	csinc	w9, w8, wzr, eq
	cmp	x0, #0
	csinc	w8, w8, wzr, eq
	cmp	x20, #0
	ccmp	x24, #0, #4, ne
	ccmp	w22, #0, #4, eq
	str	x0, [sp, #312]
	mov	w19, #1                         ; =0x1
	b.ne	LBB6_73
; %bb.44:
	cbz	w9, LBB6_73
; %bb.45:
	cbz	w8, LBB6_73
; %bb.46:
	str	w22, [sp, #296]
	str	w23, [sp, #320]
	cbz	w22, LBB6_51
; %bb.47:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	add	x8, x8, #8
LBB6_48:                                ; =>This Inner Loop Header: Depth=1
	ldurb	w9, [x8, #-8]
	cmp	w9, #5
	b.ne	LBB6_72
; %bb.49:                               ;   in Loop: Header=BB6_48 Depth=1
	ldur	w9, [x8, #-4]
	ldr	x10, [x8], #16
	cmp	w9, #0
	ccmp	x10, #0, #0, ne
	b.eq	LBB6_72
; %bb.50:                               ;   in Loop: Header=BB6_48 Depth=1
	str	x10, [x24], #8
	str	w9, [x20], #4
	subs	x22, x22, #1
	b.ne	LBB6_48
LBB6_51:
	cbz	w23, LBB6_62
; %bb.52:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #72]
	add	x8, x8, #24
	add	x9, x21, #21
	mov	w10, #24                        ; =0x18
	b	LBB6_54
LBB6_53:                                ;   in Loop: Header=BB6_54 Depth=1
	sturb	w12, [x9, #-1]
	ldr	x11, [x11, #8]
	str	x11, [x0], #8
	add	x8, x8, #32
	add	x9, x9, #24
	subs	x23, x23, #1
	b.eq	LBB6_62
LBB6_54:                                ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x8, #-20]
	ldr	w12, [sp, #36]                  ; 4-byte Folded Reload
	cmp	w11, w12
	b.hs	LBB6_72
; %bb.55:                               ;   in Loop: Header=BB6_54 Depth=1
	ldr	x12, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x12, [x12, #40]
	umaddl	x11, w11, w10, x12
	ldrh	w12, [x11, #2]
	cmp	w12, #1
	b.hi	LBB6_72
; %bb.56:                               ;   in Loop: Header=BB6_54 Depth=1
	cbz	w12, LBB6_58
; %bb.57:                               ;   in Loop: Header=BB6_54 Depth=1
	ldr	x13, [x11, #16]
	cbz	x13, LBB6_72
LBB6_58:                                ;   in Loop: Header=BB6_54 Depth=1
	ldrh	w13, [x11]
	cbz	w13, LBB6_60
; %bb.59:                               ;   in Loop: Header=BB6_54 Depth=1
	ldr	x14, [x11, #8]
	cbz	x14, LBB6_72
LBB6_60:                                ;   in Loop: Header=BB6_54 Depth=1
	sturh	w13, [x9, #-17]
	ldrh	w13, [x8]
	sturh	w13, [x9, #-5]
	strb	w12, [x9]
	cbz	w12, LBB6_53
; %bb.61:                               ;   in Loop: Header=BB6_54 Depth=1
	ldr	x12, [x11, #16]
	ldrb	w12, [x12]
	b	LBB6_53
LBB6_62:
	add	x20, sp, #3096
	add	x0, sp, #3096
	mov	w1, #3840                       ; =0xf00
	bl	_bzero
	add	x19, sp, #536
	add	x0, sp, #536
	mov	w1, #2560                       ; =0xa00
	bl	_bzero
	stp	x20, x19, [sp, #448]
	ldp	x8, x12, [sp, #16]              ; 16-byte Folded Reload
	add	x8, x8, #12
	add	x9, x20, #11
	mov	w10, #24                        ; =0x18
	mov	w11, #3                         ; =0x3
	str	w12, [sp, #480]
LBB6_63:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x8]
	cmp	w12, #3
	b.ne	LBB6_72
; %bb.64:                               ;   in Loop: Header=BB6_63 Depth=1
	ldur	w12, [x8, #-4]
	ldr	w13, [sp, #36]                  ; 4-byte Folded Reload
	cmp	w12, w13
	b.hs	LBB6_72
; %bb.65:                               ;   in Loop: Header=BB6_63 Depth=1
	ldr	x13, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x13, [x13, #40]
	umaddl	x13, w12, w10, x13
	ldrh	w12, [x13, #2]
	cmp	w12, #1
	b.ne	LBB6_72
; %bb.66:                               ;   in Loop: Header=BB6_63 Depth=1
	ldr	x12, [x13, #16]
	cbz	x12, LBB6_72
; %bb.67:                               ;   in Loop: Header=BB6_63 Depth=1
	ldrh	w14, [x13]
	ldr	x13, [x13, #8]
	cmp	w14, #0
	ccmp	x13, #0, #0, ne
	b.eq	LBB6_72
; %bb.68:                               ;   in Loop: Header=BB6_63 Depth=1
	ldur	d0, [x8, #-12]
	stur	d0, [x9, #-11]
	strb	w11, [x9]
	sturh	w14, [x9, #-3]
	ldrb	w12, [x12]
	sturb	w12, [x9, #-1]
	str	x13, [x19], #8
	add	x8, x8, #16
	add	x9, x9, #12
	ldr	x12, [sp, #24]                  ; 8-byte Folded Reload
	subs	x12, x12, #1
	str	x12, [sp, #24]                  ; 8-byte Folded Spill
	b.ne	LBB6_63
; %bb.69:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_malloc
	mov	x25, x0
	str	x0, [sp, #360]
	cbz	x0, LBB6_75
; %bb.70:
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	str	w2, [sp, #368]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x0, x8, #56
	mov	x1, x25
	bl	_nvm_v2_layouts_encode
	mov	x19, x0
	cbnz	w0, LBB6_73
; %bb.71:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #216]
	str	x9, [sp, #376]
	ldr	w9, [x8, #224]
	str	w9, [sp, #384]
	ldr	x9, [x8, #184]
	str	x9, [sp, #344]
	ldr	w8, [x8, #192]
	str	w8, [sp, #352]
	add	x0, sp, #48
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	blr	x8
	mov	x19, x0
	ldr	x25, [sp, #360]
	b	LBB6_73
LBB6_72:
	mov	x25, #0                         ; =0x0
	mov	w19, #8                         ; =0x8
LBB6_73:
	mov	x0, x25
	bl	_free
	ldr	x0, [sp, #280]
	bl	_free
	ldr	x0, [sp, #288]
	bl	_free
	ldr	x0, [sp, #304]
	bl	_free
	ldr	x0, [sp, #312]
	bl	_free
	b	LBB6_9
LBB6_74:
	bl	___stack_chk_fail
LBB6_75:
	mov	w19, #1                         ; =0x1
	b	LBB6_73
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_bindings_validate ; -- Begin function nvm_service_bindings_validate
	.globl	_nvm_service_bindings_validate
	.p2align	2
_nvm_service_bindings_validate:         ; @nvm_service_bindings_validate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB7_37
; %bb.1:
	mov	x19, x0
	bl	_nvm_file_instructions_present
	mov	x8, x0
	ldr	x0, [x19, #328]
	cbz	w8, LBB7_6
; %bb.2:
	mov	w8, #8                          ; =0x8
	cbz	x0, LBB7_38
; %bb.3:
	ldr	w9, [x19, #336]
	cmp	w9, #2
	b.lo	LBB7_38
; %bb.4:
	ldrb	w8, [x0]
	and	w8, w8, #0xfe
	cmp	w8, #2
	b.ne	LBB7_14
; %bb.5:
	ldrb	w8, [x0, #1]
	cbnz	w8, LBB7_14
	b	LBB7_7
LBB7_6:
	cbz	x0, LBB7_11
LBB7_7:
	ldr	w8, [x19, #336]
	cmp	w8, #2
	b.lo	LBB7_13
; %bb.8:
	ldrb	w9, [x0]
	and	w9, w9, #0xfe
	cmp	w9, #2
	b.ne	LBB7_13
; %bb.9:
	ldrb	w9, [x0, #1]
	cbnz	w9, LBB7_13
; %bb.10:
	mov	x0, x19
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_nominal_module
LBB7_11:
	ldr	w8, [x19, #336]
	cbz	w8, LBB7_20
; %bb.12:
	mov	x0, #0                          ; =0x0
LBB7_13:
	mov	w1, w8
	add	x2, sp, #12
	bl	_nvm_service_bindings_decode
	cbz	w0, LBB7_15
LBB7_14:
	mov	w8, #8                          ; =0x8
	b	LBB7_38
LBB7_15:
	ldr	w8, [x19, #432]
	cmp	w8, #5
	b.ne	LBB7_19
; %bb.16:
	ldr	x8, [x19, #400]
	cbz	x8, LBB7_19
; %bb.17:
	ldr	w8, [x19, #448]
	cbnz	w8, LBB7_19
; %bb.18:
	ldr	w8, [x19, #424]
	cbz	w8, LBB7_27
LBB7_19:
	mov	w8, #14                         ; =0xe
	b	LBB7_38
LBB7_20:
	ldr	x8, [x19, #400]
	cbz	x8, LBB7_38
; %bb.21:
	ldr	w9, [x19, #432]
	cbz	w9, LBB7_25
; %bb.22:
	add	x10, x8, #11
LBB7_23:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x10], #12
	cmp	w8, #3
	b.eq	LBB7_26
; %bb.24:                               ;   in Loop: Header=BB7_23 Depth=1
	mov	w8, #0                          ; =0x0
	subs	x9, x9, #1
	b.ne	LBB7_23
	b	LBB7_38
LBB7_25:
	mov	w8, #0                          ; =0x0
	b	LBB7_38
LBB7_26:
	mov	w8, #0                          ; =0x0
	b	LBB7_13
LBB7_27:
	mov	x20, #0                         ; =0x0
	add	x24, sp, #12
	mov	w25, #12                        ; =0xc
LBB7_28:                                ; =>This Inner Loop Header: Depth=1
	ldr	w23, [x24, x20, lsl #2]
	ldr	w8, [x19, #432]
	cmp	w23, w8
	b.hs	LBB7_37
; %bb.29:                               ;   in Loop: Header=BB7_28 Depth=1
	ldr	x26, [x19, #400]
	mov	x0, x20
	bl	_nl_file_catalog_method
	mov	x21, x0
	ldr	x8, [x19, #408]
	cbz	x8, LBB7_31
; %bb.30:                               ;   in Loop: Header=BB7_28 Depth=1
	ldr	x22, [x8, x23, lsl #3]
	b	LBB7_32
LBB7_31:                                ;   in Loop: Header=BB7_28 Depth=1
	mov	x22, #0                         ; =0x0
LBB7_32:                                ;   in Loop: Header=BB7_28 Depth=1
	umaddl	x26, w23, w25, x26
	ldrb	w8, [x26, #11]
	cmp	w8, #3
	b.ne	LBB7_14
; %bb.33:                               ;   in Loop: Header=BB7_28 Depth=1
	ldr	w23, [x26]
	bl	_nl_file_catalog_interface
	mov	x2, x0
	mov	x0, x19
	mov	x1, x23
	bl	_nvm_name
	cbz	w0, LBB7_14
; %bb.34:                               ;   in Loop: Header=BB7_28 Depth=1
	ldr	w1, [x26, #4]
	ldr	x2, [x21]
	mov	x0, x19
	bl	_nvm_name
	cbz	w0, LBB7_14
; %bb.35:                               ;   in Loop: Header=BB7_28 Depth=1
	ldrh	w2, [x26, #8]
	add	x3, x26, #10
	mov	x0, x21
	mov	x1, x22
	mov	w4, #1                          ; =0x1
	bl	_category_signature
	tbz	w0, #0, LBB7_14
; %bb.36:                               ;   in Loop: Header=BB7_28 Depth=1
	mov	w8, #0                          ; =0x0
	add	x20, x20, #1
	cmp	x20, #5
	b.ne	LBB7_28
	b	LBB7_38
LBB7_37:
	mov	w8, #13                         ; =0xd
LBB7_38:
	mov	x0, x8
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nominal_module
_nominal_module:                        ; @nominal_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #328]
	cbz	x8, LBB8_7
; %bb.1:
	ldr	w9, [x0, #336]
	cmp	w9, #2
	b.lo	LBB8_7
; %bb.2:
	ldrb	w10, [x8]
	cmp	w10, #3
	b.ne	LBB8_4
; %bb.3:
	ldrb	w10, [x8, #1]
	cbz	w10, LBB8_9
LBB8_4:
	cmp	w9, #4
	b.lo	LBB8_7
; %bb.5:
	ldrb	w9, [x8, #2]
	cmp	w9, #2
	b.ne	LBB8_7
; %bb.6:
	ldrb	w8, [x8, #3]
	cbz	w8, LBB8_10
LBB8_7:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	bl	_nvm_file_nominal_plan
	mov	w8, #8                          ; =0x8
	mov	w9, #13                         ; =0xd
	cmp	w0, #2
	csel	w8, w9, w8, eq
	mov	w9, #1                          ; =0x1
	cmp	w0, #3
	csel	w8, w8, w9, ne
	cmp	w0, #0
	csel	w19, w0, w8, eq
	ldr	x0, [sp, #8]
	bl	_nvm_file_nominal_plan_free
LBB8_8:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB8_9:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	bl	_nvm_multi_nominal_plan
	mov	x19, x0
	ldr	x0, [sp, #8]
	bl	_nvm_multi_nominal_plan_free
	mov	w8, #8                          ; =0x8
	mov	w9, #13                         ; =0xd
	cmp	w19, #2
	csel	w8, w9, w8, eq
	mov	w9, #1                          ; =0x1
	cmp	w19, #3
	csel	w8, w8, w9, ne
	cmp	w19, #0
	csel	w19, w19, w8, eq
	b	LBB8_8
LBB8_10:
	str	xzr, [sp, #8]
	add	x1, sp, #8
	bl	_nvm_socket_nominal_plan
	mov	x19, x0
	ldr	x0, [sp, #8]
	bl	_nvm_socket_nominal_plan_free
	cbz	w19, LBB8_8
; %bb.11:
	cmp	w19, #3
	b.ne	LBB8_13
; %bb.12:
	mov	w19, #1                         ; =0x1
	b	LBB8_8
LBB8_13:
	mov	w8, #8                          ; =0x8
	mov	w9, #13                         ; =0xd
	cmp	w19, #2
	csel	w19, w9, w8, eq
	b	LBB8_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_name
_nvm_name:                              ; @nvm_name
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB9_5
; %bb.1:
	ldr	x8, [x0, #232]
	cbz	x8, LBB9_5
; %bb.2:
	ldr	x9, [x0, #240]
	cbz	x9, LBB9_5
; %bb.3:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x19, [x8, w1, uxtw #3]
	ldr	w21, [x9, w1, uxtw #2]
	mov	x20, x2
	mov	x0, x2
	bl	_strlen
	cmp	x19, #0
	ccmp	x0, x21, #0, ne
	b.eq	LBB9_6
; %bb.4:
	mov	w0, #0                          ; =0x0
	b	LBB9_7
LBB9_5:
	mov	w0, #0                          ; =0x0
	ret
LBB9_6:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
LBB9_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function category_signature
_category_signature:                    ; @category_signature
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_11
; %bb.1:
	ldr	x9, [x0, #56]
	cbz	x9, LBB10_10
; %bb.2:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x3, LBB10_11
; %bb.3:
	cmp	w4, #1
	b.ne	LBB10_11
; %bb.4:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	sub	x22, x9, #1
	mov	w9, w2
	cmp	x22, x9
	b.ne	LBB10_9
; %bb.5:
	ldrb	w9, [x3]
	cmp	w9, #10
	b.ne	LBB10_8
; %bb.6:
	cbnz	x1, LBB10_12
; %bb.7:
	cbz	w2, LBB10_12
LBB10_8:
	mov	w0, #0                          ; =0x0
LBB10_9:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB10_10:
	mov	w0, #0                          ; =0x0
LBB10_11:
	ret
LBB10_12:
	ldr	x23, [x8, #48]
	cbz	w2, LBB10_20
; %bb.13:
	add	x24, x23, #24
Lloh10:
	adrp	x19, l_.str@PAGE
Lloh11:
	add	x19, x19, l_.str@PAGEOFF
	mov	x25, x22
Lloh12:
	adrp	x20, l_.str.1@PAGE
Lloh13:
	add	x20, x20, l_.str.1@PAGEOFF
LBB10_14:                               ; =>This Inner Loop Header: Depth=1
	mov	x26, x1
	ldur	x21, [x24, #-8]
	mov	x0, x21
	mov	x1, x19
	bl	_strcmp
	cbz	w0, LBB10_17
; %bb.15:                               ;   in Loop: Header=BB10_14 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_strcmp
	cbnz	w0, LBB10_8
; %bb.16:                               ;   in Loop: Header=BB10_14 Depth=1
	mov	w8, #8                          ; =0x8
	ldr	w9, [x24], #48
	cbz	w9, LBB10_18
	b	LBB10_8
LBB10_17:                               ;   in Loop: Header=BB10_14 Depth=1
	mov	w8, #1                          ; =0x1
	ldr	w9, [x24], #48
	cbnz	w9, LBB10_8
LBB10_18:                               ;   in Loop: Header=BB10_14 Depth=1
	mov	x1, x26
	ldrb	w9, [x26]
	cmp	w8, w9
	b.ne	LBB10_8
; %bb.19:                               ;   in Loop: Header=BB10_14 Depth=1
	add	x1, x1, #1
	subs	x25, x25, #1
	b.ne	LBB10_14
LBB10_20:
	mov	w8, #48                         ; =0x30
	madd	x8, x22, x8, x23
	ldr	w8, [x8, #24]
	cmp	w8, #3
	cset	w0, eq
	b	LBB10_9
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_service_bindings_validate ; -- Begin function nvm_v2_service_bindings_validate
	.globl	_nvm_v2_service_bindings_validate
	.p2align	2
_nvm_v2_service_bindings_validate:      ; @nvm_v2_service_bindings_validate
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_10
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #3856
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldr	x8, [x0, #72]
	cbz	x8, LBB11_15
; %bb.2:
	ldr	x8, [x19, #168]
	cbz	x8, LBB11_15
; %bb.3:
	ldr	w8, [x19, #80]
	cbz	w8, LBB11_15
; %bb.4:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB11_6
LBB11_5:                                ;   in Loop: Header=BB11_6 Depth=1
	add	x21, x21, #1
	add	x20, x20, #32
	cmp	x21, x8
	b.hs	LBB11_15
LBB11_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19, #72]
	add	x10, x9, x20
	ldr	x9, [x10, #8]
	ldr	x11, [x19, #176]
	subs	x11, x11, x9
	b.lo	LBB11_5
; %bb.7:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	x1, [x10, #16]
	cmp	x1, x11
	b.hi	LBB11_5
; %bb.8:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	x8, [x19, #168]
	add	x0, x8, x9
	bl	_isa_code_has_file_instructions
	tbnz	w0, #0, LBB11_11
; %bb.9:                                ;   in Loop: Header=BB11_6 Depth=1
	ldr	w8, [x19, #80]
	b	LBB11_5
LBB11_10:
	mov	w0, #13                         ; =0xd
	ret
LBB11_11:
	ldr	x8, [x19, #216]
	mov	w0, #8                          ; =0x8
	cbz	x8, LBB11_39
; %bb.12:
	ldr	w9, [x19, #224]
	cmp	w9, #2
	b.lo	LBB11_39
; %bb.13:
	ldrb	w9, [x8]
	and	w9, w9, #0xfe
	cmp	w9, #2
	b.ne	LBB11_39
; %bb.14:
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB11_39
LBB11_15:
	ldr	x0, [x19, #216]
	ldr	w1, [x19, #224]
	cbz	x0, LBB11_24
; %bb.16:
	cmp	w1, #2
	b.lo	LBB11_32
; %bb.17:
	ldrb	w8, [x0]
	and	w9, w8, #0xfe
	cmp	w9, #2
	b.ne	LBB11_32
; %bb.18:
	ldrb	w9, [x0, #1]
	cbnz	w9, LBB11_32
; %bb.19:
	cmp	w8, #3
	b.ne	LBB11_41
; %bb.20:
	add	x2, sp, #12
	bl	_nvm_multi_nominal_decode
	cbnz	w0, LBB11_33
; %bb.21:
	ldr	w8, [sp, #12]
	cbz	w8, LBB11_54
; %bb.22:
	mov	x22, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	mov	w23, #4                         ; =0x4
	add	x24, sp, #12
LBB11_23:                               ; =>This Inner Loop Header: Depth=1
	ldr	w0, [x24, x23]
	bl	_nvm_multi_nominal_catalog_methods
	add	w20, w0, w20
	ldr	w0, [x24, x23]
	bl	_nvm_multi_nominal_catalog_types
	add	w21, w0, w21
	add	x22, x22, #1
	ldr	w8, [sp, #12]
	add	x23, x23, #60
	cmp	x22, x8
	b.lo	LBB11_23
	b	LBB11_42
LBB11_24:
	cbnz	w1, LBB11_32
; %bb.25:
	ldrb	w8, [x19, #241]
	tbnz	w8, #1, LBB11_31
; %bb.26:
	ldr	x10, [x19, #104]
	cbz	x10, LBB11_40
; %bb.27:
	ldr	w8, [x19, #112]
	cbz	w8, LBB11_40
; %bb.28:
	mov	x9, x0
	add	x10, x10, #12
LBB11_29:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x10], #16
	cmp	w11, #3
	b.eq	LBB11_52
; %bb.30:                               ;   in Loop: Header=BB11_29 Depth=1
	mov	w0, #0                          ; =0x0
	subs	x8, x8, #1
	b.ne	LBB11_29
	b	LBB11_39
LBB11_31:
	mov	w1, #0                          ; =0x0
LBB11_32:
	mov	w1, w1
	add	x2, sp, #12
	bl	_nvm_service_bindings_decode
	cbz	w0, LBB11_34
LBB11_33:
	mov	w0, #8                          ; =0x8
	b	LBB11_39
LBB11_34:
	ldr	w8, [x19, #112]
	cmp	w8, #5
	b.ne	LBB11_38
; %bb.35:
	ldr	x8, [x19, #104]
	cbz	x8, LBB11_38
; %bb.36:
	ldr	w8, [x19, #144]
	cbnz	w8, LBB11_38
; %bb.37:
	ldr	w8, [x19, #128]
	cbz	w8, LBB11_43
LBB11_38:
	mov	w0, #14                         ; =0xe
LBB11_39:
	add	sp, sp, #3856
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB11_40:
	mov	w0, #0                          ; =0x0
	b	LBB11_39
LBB11_41:
	mov	w20, #5                         ; =0x5
	mov	w21, #8                         ; =0x8
LBB11_42:
Lloh14:
	adrp	x3, _nominal_module@PAGE
Lloh15:
	add	x3, x3, _nominal_module@PAGEOFF
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	bl	_nvm_private_nominal_wire
	b	LBB11_39
LBB11_43:
	mov	x20, #0                         ; =0x0
	add	x23, sp, #12
	mov	w24, #24                        ; =0x18
LBB11_44:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23, x20, lsl #2]
	ldr	w9, [x19, #112]
	cmp	w8, w9
	b.hs	LBB11_53
; %bb.45:                               ;   in Loop: Header=BB11_44 Depth=1
	ldr	x9, [x19, #104]
	add	x27, x9, x8, lsl #4
	ldr	w25, [x27, #8]
	ldr	w8, [x19, #48]
	cmp	w25, w8
	b.hs	LBB11_53
; %bb.46:                               ;   in Loop: Header=BB11_44 Depth=1
	ldr	x26, [x19, #40]
	cbz	x26, LBB11_53
; %bb.47:                               ;   in Loop: Header=BB11_44 Depth=1
	mov	x0, x20
	bl	_nl_file_catalog_method
	ldrb	w8, [x27, #12]
	cmp	w8, #3
	b.ne	LBB11_33
; %bb.48:                               ;   in Loop: Header=BB11_44 Depth=1
	mov	x21, x0
	ldr	w22, [x27]
	bl	_nl_file_catalog_interface
	mov	x2, x0
	mov	x0, x19
	mov	x1, x22
	bl	_v2_name
	cbz	w0, LBB11_33
; %bb.49:                               ;   in Loop: Header=BB11_44 Depth=1
	ldr	w1, [x27, #4]
	ldr	x2, [x21]
	mov	x0, x19
	bl	_v2_name
	cbz	w0, LBB11_33
; %bb.50:                               ;   in Loop: Header=BB11_44 Depth=1
	umaddl	x8, w25, w24, x26
	ldrh	w2, [x8]
	ldp	x1, x3, [x8, #8]
	ldrh	w4, [x8, #2]
	mov	x0, x21
	bl	_category_signature
	tbz	w0, #0, LBB11_33
; %bb.51:                               ;   in Loop: Header=BB11_44 Depth=1
	mov	w0, #0                          ; =0x0
	add	x20, x20, #1
	cmp	x20, #5
	b.ne	LBB11_44
	b	LBB11_39
LBB11_52:
	mov	w1, #0                          ; =0x0
	mov	x0, x9
	b	LBB11_32
LBB11_53:
	mov	w0, #13                         ; =0xd
	b	LBB11_39
LBB11_54:
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	b	LBB11_42
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function v2_name
_v2_name:                               ; @v2_name
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #32]
	cmp	w1, w8
	b.hs	LBB12_5
; %bb.1:
	ldr	x8, [x0, #24]
	cbz	x8, LBB12_5
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x8, x8, w1, uxtw #4
	ldrb	w9, [x8]
	cmp	w9, #5
	b.ne	LBB12_4
; %bb.3:
	ldr	x19, [x8, #8]
	ldr	w21, [x8, #4]
	mov	x20, x2
	mov	x0, x2
	bl	_strlen
	cmp	x19, #0
	ccmp	x0, x21, #0, ne
	b.eq	LBB12_6
LBB12_4:
	mov	w0, #0                          ; =0x0
	b	LBB12_7
LBB12_5:
	mov	w0, #0                          ; =0x0
	ret
LBB12_6:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
LBB12_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_service_bindings_attach ; -- Begin function nvm_service_bindings_attach
	.globl	_nvm_service_bindings_attach
	.p2align	2
_nvm_service_bindings_attach:           ; @nvm_service_bindings_attach
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #560
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x0
Lloh16:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh17:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh18:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #8                          ; =0x8
	cbz	x19, LBB13_11
; %bb.1:
	mov	x21, x1
	cbz	x1, LBB13_11
; %bb.2:
	mov	x20, x2
	mov	x0, x21
	bl	_nl_file_plan_method_count
	cmp	x0, #5
	b.ne	LBB13_10
; %bb.3:
	mov	x0, x21
	bl	_nl_file_plan_interface
	mov	x22, x0
	bl	_nl_file_catalog_interface
	mov	x1, x0
	mov	x0, x22
	bl	_strcmp
	cbnz	w0, LBB13_10
; %bb.4:
	mov	x0, x21
	mov	x1, #0                          ; =0x0
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB13_10
; %bb.5:
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB13_10
; %bb.6:
	mov	x0, x21
	mov	w1, #2                          ; =0x2
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB13_10
; %bb.7:
	mov	x0, x21
	mov	w1, #3                          ; =0x3
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB13_10
; %bb.8:
	mov	x0, x21
	mov	w1, #4                          ; =0x4
	bl	_nl_file_plan_method
	mov	x21, x0
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_method
	cmp	x21, x0
	b.ne	LBB13_10
; %bb.9:
	stur	xzr, [x29, #-120]
	sub	x21, x29, #112
	sub	x1, x29, #112
	sub	x3, x29, #120
	mov	x0, x20
	mov	w2, #56                         ; =0x38
	bl	_nvm_service_bindings_encode
	cbz	w0, LBB13_13
LBB13_10:
	mov	w0, #8                          ; =0x8
LBB13_11:
	ldur	x8, [x29, #-56]
Lloh19:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh20:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh21:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB13_22
; %bb.12:
	add	sp, sp, #560
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB13_13:
	add	x0, sp, #8
	mov	x1, x19
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	str	x21, [sp, #336]
	ldur	x8, [x29, #-120]
	str	w8, [sp, #344]
	add	x0, sp, #8
	bl	_nvm_service_bindings_validate
	cbnz	w0, LBB13_11
; %bb.14:
	ldr	x8, [x19, #328]
	ldr	w2, [x19, #336]
	cbz	x8, LBB13_17
; %bb.15:
	ldur	x9, [x29, #-120]
	mov	w0, #14                         ; =0xe
	cmp	x9, x2
	b.ne	LBB13_11
; %bb.16:
	sub	x1, x29, #112
	mov	x0, x8
	bl	_memcmp
	mov	x8, x0
	mov	w0, #14                         ; =0xe
	cmp	w8, #0
	csel	w0, wzr, w0, eq
	b	LBB13_11
LBB13_17:
	cbz	w2, LBB13_19
; %bb.18:
	mov	w0, #14                         ; =0xe
	b	LBB13_11
LBB13_19:
	ldur	x20, [x29, #-120]
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB13_21
; %bb.20:
	mov	x21, x0
	sub	x1, x29, #112
	mov	x2, x20
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	str	x21, [x19, #328]
	str	w20, [x19, #336]
	b	LBB13_11
LBB13_21:
	mov	w0, #1                          ; =0x1
	b	LBB13_11
LBB13_22:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh16, Lloh17, Lloh18
	.loh AdrpLdrGotLdr	Lloh19, Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_nominal_attach ; -- Begin function nvm_file_nominal_attach
	.globl	_nvm_file_nominal_attach
	.p2align	2
_nvm_file_nominal_attach:               ; @nvm_file_nominal_attach
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x0
Lloh22:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh23:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh24:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #8                          ; =0x8
	cbz	x19, LBB14_19
; %bb.1:
	mov	x21, x1
	cbz	x1, LBB14_19
; %bb.2:
	mov	x20, x2
	mov	x0, x21
	bl	_nl_file_plan_type_count
	cmp	x0, #8
	b.ne	LBB14_18
; %bb.3:
	mov	x0, x21
	bl	_nl_file_plan_method_count
	cmp	x0, #5
	b.ne	LBB14_18
; %bb.4:
	mov	x0, x21
	bl	_nl_file_plan_interface
	mov	x22, x0
	bl	_nl_file_catalog_interface
	mov	x1, x0
	mov	x0, x22
	bl	_strcmp
	cbnz	w0, LBB14_18
; %bb.5:
	mov	x0, x21
	mov	x1, #0                          ; =0x0
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.6:
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.7:
	mov	x0, x21
	mov	w1, #2                          ; =0x2
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.8:
	mov	x0, x21
	mov	w1, #3                          ; =0x3
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.9:
	mov	x0, x21
	mov	w1, #4                          ; =0x4
	bl	_nl_file_plan_method
	mov	x22, x0
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_method
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.10:
	mov	x0, x21
	mov	x1, #0                          ; =0x0
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	x0, #0                          ; =0x0
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.11:
	mov	x0, x21
	mov	w1, #1                          ; =0x1
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.12:
	mov	x0, x21
	mov	w1, #2                          ; =0x2
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #2                          ; =0x2
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.13:
	mov	x0, x21
	mov	w1, #3                          ; =0x3
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #3                          ; =0x3
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.14:
	mov	x0, x21
	mov	w1, #4                          ; =0x4
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #4                          ; =0x4
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.15:
	mov	x0, x21
	mov	w1, #5                          ; =0x5
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #5                          ; =0x5
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.16:
	mov	x0, x21
	mov	w1, #6                          ; =0x6
	bl	_nl_file_plan_type
	mov	x22, x0
	mov	w0, #6                          ; =0x6
	bl	_nl_file_catalog_type
	cmp	x22, x0
	b.ne	LBB14_18
; %bb.17:
	mov	x0, x21
	mov	w1, #7                          ; =0x7
	bl	_nl_file_plan_type
	mov	x21, x0
	mov	w0, #7                          ; =0x7
	bl	_nl_file_catalog_type
	cmp	x21, x0
	b.eq	LBB14_22
LBB14_18:
	mov	w0, #8                          ; =0x8
LBB14_19:
	ldur	x8, [x29, #-56]
Lloh25:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh26:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh27:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB14_21
; %bb.20:
	add	sp, sp, #624
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB14_21:
	bl	___stack_chk_fail
LBB14_22:
	stur	xzr, [x29, #-184]
	sub	x21, x29, #176
	sub	x1, x29, #176
	sub	x3, x29, #184
	mov	x0, x20
	mov	w2, #120                        ; =0x78
	bl	_nvm_file_nominal_encode
	cbz	w0, LBB14_24
; %bb.23:
	mov	w22, #8                         ; =0x8
	b	LBB14_25
LBB14_24:
	add	x0, sp, #8
	mov	x1, x19
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	str	x21, [sp, #336]
	ldur	x8, [x29, #-184]
	str	w8, [sp, #344]
	add	x0, sp, #8
	bl	_nominal_module
	mov	x22, x0
	cbz	w0, LBB14_26
LBB14_25:
	mov	x0, x22
	b	LBB14_19
LBB14_26:
	ldr	x0, [x19, #328]
	ldr	w2, [x19, #336]
	cbz	x0, LBB14_29
; %bb.27:
	ldur	x8, [x29, #-184]
	mov	w22, #14                        ; =0xe
	cmp	x8, x2
	b.ne	LBB14_25
; %bb.28:
	sub	x1, x29, #176
	bl	_memcmp
	cmp	w0, #0
	csel	w22, wzr, w22, eq
	b	LBB14_25
LBB14_29:
	cbz	w2, LBB14_31
; %bb.30:
	mov	w22, #14                        ; =0xe
	b	LBB14_25
LBB14_31:
	ldur	x20, [x29, #-184]
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB14_33
; %bb.32:
	mov	x21, x0
	sub	x1, x29, #176
	mov	x2, x20
	bl	_memcpy
	mov	w22, #0                         ; =0x0
	str	x21, [x19, #328]
	str	w20, [x19, #336]
	b	LBB14_25
LBB14_33:
	mov	w22, #1                         ; =0x1
	b	LBB14_25
	.loh AdrpLdrGotLdr	Lloh22, Lloh23, Lloh24
	.loh AdrpLdrGotLdr	Lloh25, Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_socket_nominal_attach ; -- Begin function nvm_socket_nominal_attach
	.globl	_nvm_socket_nominal_attach
	.p2align	2
_nvm_socket_nominal_attach:             ; @nvm_socket_nominal_attach
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x0
Lloh28:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh29:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh30:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	mov	w0, #8                          ; =0x8
	cbz	x19, LBB15_19
; %bb.1:
	mov	x20, x1
	cbz	x1, LBB15_19
; %bb.2:
	mov	x22, x2
	mov	x0, x20
	bl	_nl_socket_plan_type_count
	cmp	x0, #9
	b.ne	LBB15_18
; %bb.3:
	mov	x0, x20
	bl	_nl_socket_plan_method_count
	cmp	x0, #5
	b.ne	LBB15_18
; %bb.4:
	mov	x0, x20
	bl	_nl_socket_plan_interface
	mov	x21, x0
	bl	_nl_socket_catalog_interface
	mov	x1, x0
	mov	x0, x21
	bl	_strcmp
	cbnz	w0, LBB15_18
; %bb.5:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nl_socket_plan_method
	mov	x21, x0
	mov	x0, #0                          ; =0x0
	bl	_nl_socket_catalog_method
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.6:
	mov	x0, x20
	mov	w1, #1                          ; =0x1
	bl	_nl_socket_plan_method
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	bl	_nl_socket_catalog_method
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.7:
	mov	x0, x20
	mov	w1, #2                          ; =0x2
	bl	_nl_socket_plan_method
	mov	x21, x0
	mov	w0, #2                          ; =0x2
	bl	_nl_socket_catalog_method
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.8:
	mov	x0, x20
	mov	w1, #3                          ; =0x3
	bl	_nl_socket_plan_method
	mov	x21, x0
	mov	w0, #3                          ; =0x3
	bl	_nl_socket_catalog_method
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.9:
	mov	x0, x20
	mov	w1, #4                          ; =0x4
	bl	_nl_socket_plan_method
	mov	x21, x0
	mov	w0, #4                          ; =0x4
	bl	_nl_socket_catalog_method
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.10:
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	x0, #0                          ; =0x0
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.11:
	mov	x0, x20
	mov	w1, #1                          ; =0x1
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.12:
	mov	x0, x20
	mov	w1, #2                          ; =0x2
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #2                          ; =0x2
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.13:
	mov	x0, x20
	mov	w1, #3                          ; =0x3
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #3                          ; =0x3
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.14:
	mov	x0, x20
	mov	w1, #4                          ; =0x4
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #4                          ; =0x4
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.15:
	mov	x0, x20
	mov	w1, #5                          ; =0x5
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #5                          ; =0x5
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.16:
	mov	x0, x20
	mov	w1, #6                          ; =0x6
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #6                          ; =0x6
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.ne	LBB15_18
; %bb.17:
	mov	x0, x20
	mov	w1, #7                          ; =0x7
	bl	_nl_socket_plan_type
	mov	x21, x0
	mov	w0, #7                          ; =0x7
	bl	_nl_socket_catalog_type
	cmp	x21, x0
	b.eq	LBB15_22
LBB15_18:
	mov	w0, #8                          ; =0x8
LBB15_19:
	ldur	x8, [x29, #-56]
Lloh31:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh32:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh33:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB15_21
; %bb.20:
                                        ; kill: def $w0 killed $w0 killed $x0
	add	sp, sp, #624
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB15_21:
	bl	___stack_chk_fail
LBB15_22:
	mov	x0, x20
	mov	w1, #8                          ; =0x8
	bl	_nl_socket_plan_type
	mov	x20, x0
	mov	w0, #8                          ; =0x8
	bl	_nl_socket_catalog_type
	mov	x8, x0
	mov	w0, #8                          ; =0x8
	cmp	x20, x8
	b.ne	LBB15_19
; %bb.23:
	stur	xzr, [x29, #-192]
	sub	x20, x29, #184
	sub	x1, x29, #184
	sub	x3, x29, #192
	mov	x0, x22
	mov	w2, #128                        ; =0x80
	bl	_nvm_socket_nominal_encode
	cbz	w0, LBB15_25
; %bb.24:
	mov	w22, #8                         ; =0x8
	b	LBB15_26
LBB15_25:
	mov	x0, sp
	mov	x1, x19
	mov	w2, #480                        ; =0x1e0
	bl	_memcpy
	str	x20, [sp, #328]
	ldur	x8, [x29, #-192]
	str	w8, [sp, #336]
	mov	x0, sp
	bl	_nominal_module
                                        ; kill: def $w0 killed $w0 def $x0
	mov	x22, x0
	cbz	w0, LBB15_27
LBB15_26:
	mov	x0, x22
	b	LBB15_19
LBB15_27:
	ldr	x0, [x19, #328]
	ldr	w2, [x19, #336]
	cbz	x0, LBB15_30
; %bb.28:
	ldur	x8, [x29, #-192]
	mov	w22, #14                        ; =0xe
	cmp	x8, x2
	b.ne	LBB15_26
; %bb.29:
	sub	x1, x29, #184
	bl	_memcmp
	cmp	w0, #0
	csel	w22, wzr, w22, eq
	b	LBB15_26
LBB15_30:
	cbz	w2, LBB15_32
; %bb.31:
	mov	w22, #14                        ; =0xe
	b	LBB15_26
LBB15_32:
	ldur	x20, [x29, #-192]
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB15_34
; %bb.33:
	mov	x21, x0
	sub	x1, x29, #184
	mov	x2, x20
	bl	_memcpy
	mov	w22, #0                         ; =0x0
	str	x21, [x19, #328]
	str	w20, [x19, #336]
	b	LBB15_26
LBB15_34:
	mov	w22, #1                         ; =0x1
	b	LBB15_26
	.loh AdrpLdrGotLdr	Lloh28, Lloh29, Lloh30
	.loh AdrpLdrGotLdr	Lloh31, Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:nanolang/filesystem#File"

.subsections_via_symbols
