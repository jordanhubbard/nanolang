	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_services_nominal_plan      ; -- Begin function nvm_services_nominal_plan
	.p2align	2
_nvm_services_nominal_plan:             ; @nvm_services_nominal_plan
	.cfi_startproc
; %bb.0:
	b	_nvm_multi_nominal_plan
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_nominal_layout    ; -- Begin function nvm_services_nominal_layout
	.p2align	2
_nvm_services_nominal_layout:           ; @nvm_services_nominal_layout
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB1_4
; %bb.1:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x2
	add	x2, sp, #8
	bl	_nvm_multi_nominal_layout
	cbz	w0, LBB1_7
; %bb.2:
	ldp	w8, w12, [sp, #8]
	ldr	w9, [sp, #24]
	ldrb	w10, [sp, #28]
	ldrb	w11, [sp, #29]
	cmn	w12, #1
	b.eq	LBB1_5
; %bb.3:
	ldr	w13, [sp, #20]
	add	w12, w12, w12, lsl #3
	add	w12, w13, w12
	mov	w14, #1                         ; =0x1
	mov	w15, #2                         ; =0x2
	cmp	w10, #0
	mov	w16, #3                         ; =0x3
	cinc	w16, w16, eq
	cmp	w13, #3
	csel	w15, w15, w16, eq
	cmp	w13, #0
	csel	w13, w14, w15, eq
	b	LBB1_6
LBB1_4:
	mov	w0, #0                          ; =0x0
	ret
LBB1_5:
	mov	w13, #0                         ; =0x0
LBB1_6:
	stp	w8, w12, [x19]
	str	w9, [x19, #8]
	strb	w10, [x19, #12]
	strb	w11, [x19, #13]
	strh	wzr, [x19, #14]
	mov	w0, #1                          ; =0x1
	str	w13, [x19, #16]
LBB1_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_nominal_type      ; -- Begin function nvm_services_nominal_type
	.p2align	2
_nvm_services_nominal_type:             ; @nvm_services_nominal_type
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB2_4
; %bb.1:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x2
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x8, x8, #33
	add	w9, w8, w8, lsl #3
	sub	w2, w1, w9
	add	x3, sp, #8
	mov	x1, x8
	bl	_nvm_multi_nominal_type
	cbz	w0, LBB2_7
; %bb.2:
	ldp	w8, w12, [sp, #8]
	ldr	w9, [sp, #24]
	ldrb	w10, [sp, #28]
	ldrb	w11, [sp, #29]
	cmn	w12, #1
	b.eq	LBB2_5
; %bb.3:
	ldr	w13, [sp, #20]
	add	w12, w12, w12, lsl #3
	add	w12, w13, w12
	mov	w14, #1                         ; =0x1
	mov	w15, #2                         ; =0x2
	cmp	w10, #0
	mov	w16, #3                         ; =0x3
	cinc	w16, w16, eq
	cmp	w13, #3
	csel	w15, w15, w16, eq
	cmp	w13, #0
	csel	w13, w14, w15, eq
	b	LBB2_6
LBB2_4:
	mov	w0, #0                          ; =0x0
	ret
LBB2_5:
	mov	w13, #0                         ; =0x0
LBB2_6:
	stp	w8, w12, [x19]
	str	w9, [x19, #8]
	strb	w10, [x19, #12]
	strb	w11, [x19, #13]
	strh	wzr, [x19, #14]
	mov	w0, #1                          ; =0x1
	str	w13, [x19, #16]
LBB2_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_nominal_source    ; -- Begin function nvm_services_nominal_source
	.p2align	2
_nvm_services_nominal_source:           ; @nvm_services_nominal_source
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x0
	mov	w0, #0                          ; =0x0
	tst	w1, #0xfffffffd
	b.ne	LBB3_12
; %bb.1:
	cbz	x3, LBB3_12
; %bb.2:
	mov	x20, x2
	mov	x19, x1
	mov	x23, x3
	mov	x0, x21
	bl	_nvm_multi_nominal_layout_count
	cbz	w0, LBB3_12
; %bb.3:
	mov	w22, #0                         ; =0x0
	b	LBB3_5
LBB3_4:                                 ;   in Loop: Header=BB3_5 Depth=1
	add	w22, w22, #1
	mov	x0, x21
	bl	_nvm_multi_nominal_layout_count
	cmp	w22, w0
	b.hs	LBB3_9
LBB3_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x2, sp, #8
	mov	x0, x21
	mov	x1, x22
	bl	_nvm_multi_nominal_layout
	cbz	w0, LBB3_4
; %bb.6:                                ;   in Loop: Header=BB3_5 Depth=1
	ldrb	w8, [sp, #28]
	ldr	w9, [sp, #24]
	cmp	w8, w19
	ccmp	w9, w20, #0, eq
	b.ne	LBB3_4
; %bb.7:
	ldp	w9, w10, [sp, #8]
	ldrb	w8, [sp, #29]
	cmn	w10, #1
	b.eq	LBB3_10
; %bb.8:
	ldr	w11, [sp, #20]
	add	w10, w10, w10, lsl #3
	add	w10, w11, w10
	mov	w12, #1                         ; =0x1
	mov	w13, #2                         ; =0x2
	cmp	w19, #0
	mov	w14, #3                         ; =0x3
	cinc	w14, w14, eq
	cmp	w11, #3
	csel	w13, w13, w14, eq
	cmp	w11, #0
	csel	w11, w12, w13, eq
	b	LBB3_11
LBB3_9:
	mov	w0, #0                          ; =0x0
	b	LBB3_12
LBB3_10:
	mov	w11, #0                         ; =0x0
LBB3_11:
	stp	w9, w10, [x23]
	str	w20, [x23, #8]
	strb	w19, [x23, #12]
	strb	w8, [x23, #13]
	strh	wzr, [x23, #14]
	mov	w0, #1                          ; =0x1
	str	w11, [x23, #16]
LBB3_12:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_nominal_import    ; -- Begin function nvm_services_nominal_import
	.p2align	2
_nvm_services_nominal_import:           ; @nvm_services_nominal_import
	.cfi_startproc
; %bb.0:
	mov	x3, x2
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w1, w8
	lsr	x8, x8, #34
	add	w9, w8, w8, lsl #2
	sub	w2, w1, w9
	mov	x1, x8
	b	_nvm_multi_nominal_import
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_catalog_type      ; -- Begin function nvm_services_catalog_type
	.p2align	2
_nvm_services_catalog_type:             ; @nvm_services_catalog_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x20, x8, #33
	add	x3, sp, #8
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_nvm_multi_nominal_type
	ldr	w8, [sp, #16]
	cmp	w0, #0
	csel	w8, w8, wzr, ne
	cmp	w8, #3
	b.eq	LBB5_5
; %bb.1:
	cmp	w8, #2
	b.eq	LBB5_4
; %bb.2:
	cmp	w8, #1
	b.ne	LBB5_6
; %bb.3:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w19, w8
	lsr	x8, x8, #33
	add	w8, w8, w8, lsl #3
	sub	w0, w19, w8
	bl	_nl_file_catalog_type
	b	LBB5_7
LBB5_4:
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w19, w8
	lsr	x8, x8, #33
	add	w8, w8, w8, lsl #3
	sub	w0, w19, w8
	bl	_nl_socket_catalog_type
	b	LBB5_7
LBB5_5:
	add	w8, w20, w20, lsl #3
	sub	w0, w19, w8
	bl	_nl_websocket_catalog_type
	b	LBB5_7
LBB5_6:
	mov	x0, #0                          ; =0x0
LBB5_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_catalog_method    ; -- Begin function nvm_services_catalog_method
	.p2align	2
_nvm_services_catalog_method:           ; @nvm_services_catalog_method
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w1, w8
	lsr	x20, x8, #34
	add	x3, sp, #8
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_nvm_multi_nominal_type
	ldr	w8, [sp, #16]
	cmp	w0, #0
	csel	w8, w8, wzr, ne
	cmp	w8, #3
	b.eq	LBB6_5
; %bb.1:
	cmp	w8, #2
	b.eq	LBB6_4
; %bb.2:
	cmp	w8, #1
	b.ne	LBB6_6
; %bb.3:
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w19, w8
	lsr	x8, x8, #34
	add	w8, w8, w8, lsl #2
	sub	w0, w19, w8
	bl	_nl_file_catalog_method
	b	LBB6_7
LBB6_4:
	mov	w8, #52429                      ; =0xcccd
	movk	w8, #52428, lsl #16
	umull	x8, w19, w8
	lsr	x8, x8, #34
	add	w8, w8, w8, lsl #2
	sub	w0, w19, w8
	bl	_nl_socket_catalog_method
	b	LBB6_7
LBB6_5:
	add	w8, w20, w20, lsl #2
	sub	w0, w19, w8
	bl	_nl_websocket_catalog_method
	b	LBB6_7
LBB6_6:
	mov	x0, #0                          ; =0x0
LBB6_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_catalog_types     ; -- Begin function nvm_services_catalog_types
	.p2align	2
_nvm_services_catalog_types:            ; @nvm_services_catalog_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w8, #36409                      ; =0x8e39
	movk	w8, #14563, lsl #16
	umull	x8, w1, w8
	lsr	x1, x8, #33
	add	x3, sp, #8
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	w2, #0                          ; =0x0
	bl	_nvm_multi_nominal_type
	ldr	w8, [sp, #16]
	cmp	w0, #0
	csel	w0, w8, wzr, ne
	bl	_nvm_multi_nominal_catalog_types
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_services_catalog_endpoint  ; -- Begin function nvm_services_catalog_endpoint
	.p2align	2
_nvm_services_catalog_endpoint:         ; @nvm_services_catalog_endpoint
	.cfi_startproc
; %bb.0:
	mov	x8, x1
	mov	w9, #36409                      ; =0x8e39
	movk	w9, #14563, lsl #16
	umull	x9, w1, w9
	lsr	x1, x9, #33
	add	w9, w1, w1, lsl #3
	sub	w8, w8, w9
	cmp	w8, #8
	b.ne	LBB8_2
; %bb.1:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x3, sp, #8
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	w2, #0                          ; =0x0
	bl	_nvm_multi_nominal_type
	ldr	w8, [sp, #16]
	cmp	w8, #2
	csel	w0, wzr, w0, ne
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB8_2:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
