	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_disasm_function_styled         ; -- Begin function disasm_function_styled
	.p2align	2
_disasm_function_styled:                ; @disasm_function_styled
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #10512                      ; =0x2910
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #2320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #256]
	str	w1, [sp, #252]
	str	x2, [sp, #240]
	str	x3, [sp, #232]
	str	w4, [sp, #228]
	ldr	x0, [sp, #240]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB0_2
	b	LBB0_1
LBB0_1:
	b	LBB0_57
LBB0_2:
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #252]
	add	x2, sp, #264
	mov	w3, #512                        ; =0x200
	bl	_collect_jump_targets
	str	w0, [sp, #224]
	str	wzr, [sp, #220]
	ldr	x8, [sp, #240]
	cbz	x8, LBB0_7
	b	LBB0_3
LBB0_3:
	ldr	x8, [sp, #240]
	ldr	x8, [x8, #280]
	cbz	x8, LBB0_7
	b	LBB0_4
LBB0_4:
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #240]
	ldr	x9, [x9, #280]
	subs	x8, x8, x9
	b.lo	LBB0_7
	b	LBB0_5
LBB0_5:
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #240]
	ldr	x9, [x9, #280]
	ldr	x10, [sp, #240]
	ldr	w10, [x10, #288]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB0_7
	b	LBB0_6
LBB0_6:
	ldr	x8, [sp, #256]
	ldr	x9, [sp, #240]
	ldr	x9, [x9, #280]
	subs	x8, x8, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [sp, #220]
	b	LBB0_7
LBB0_7:
	adrp	x8, l_.str@PAGE
	add	x8, x8, l_.str@PAGEOFF
	str	x8, [sp, #208]
	ldr	x8, [sp, #240]
	cbz	x8, LBB0_18
	b	LBB0_8
LBB0_8:
	ldr	x8, [sp, #240]
	ldr	w8, [x8, #392]
	subs	w8, w8, #0
	b.ls	LBB0_13
	b	LBB0_9
LBB0_9:
	ldr	x0, [sp, #240]
	ldr	x8, [sp, #240]
	ldr	w1, [x8, #392]
	bl	_nvm_get_string
	str	x0, [sp, #200]
	ldr	x8, [sp, #200]
	cbz	x8, LBB0_12
	b	LBB0_10
LBB0_10:
	ldr	x8, [sp, #200]
	ldrsb	w8, [x8]
	cbz	w8, LBB0_12
	b	LBB0_11
LBB0_11:
	ldr	x8, [sp, #200]
	str	x8, [sp, #208]
	b	LBB0_12
LBB0_12:
	b	LBB0_17
LBB0_13:
	ldr	x0, [sp, #240]
	mov	w1, #0                          ; =0x0
	bl	_nvm_get_string
	str	x0, [sp, #192]
	ldr	x8, [sp, #192]
	cbz	x8, LBB0_16
	b	LBB0_14
LBB0_14:
	ldr	x8, [sp, #192]
	ldrsb	w8, [x8]
	cbz	w8, LBB0_16
	b	LBB0_15
LBB0_15:
	ldr	x8, [sp, #192]
	str	x8, [sp, #208]
	b	LBB0_16
LBB0_16:
	b	LBB0_17
LBB0_17:
	b	LBB0_18
LBB0_18:
	str	wzr, [sp, #188]
	str	wzr, [sp, #184]
	b	LBB0_19
LBB0_19:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_37 Depth 2
	ldr	w8, [sp, #184]
	ldr	w9, [sp, #252]
	subs	w8, w8, w9
	b.hs	LBB0_55
	b	LBB0_20
LBB0_20:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w1, [sp, #224]
	ldr	w2, [sp, #184]
	add	x0, sp, #264
	bl	_find_label_at
	str	x0, [sp, #176]
	ldr	x8, [sp, #176]
	cbz	x8, LBB0_25
	b	LBB0_21
LBB0_21:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w8, [sp, #228]
	subs	w8, w8, #1
	b.ne	LBB0_23
	b	LBB0_22
LBB0_22:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #176]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_fprintf
	b	LBB0_24
LBB0_23:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #176]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_fprintf
	b	LBB0_24
LBB0_24:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_25
LBB0_25:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x8, [sp, #256]
	ldr	w9, [sp, #184]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	w8, [sp, #252]
	ldr	w9, [sp, #184]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #112
	bl	_isa_decode
	str	w0, [sp, #108]
	ldr	w8, [sp, #108]
	cbnz	w8, LBB0_27
	b	LBB0_26
LBB0_26:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #256]
	ldr	w9, [sp, #184]
                                        ; kill: def $x9 killed $w9
	ldrb	w12, [x8, x9]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #220]
	ldr	w10, [sp, #184]
	add	w10, w9, w10
	mov	x9, sp
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x9]
	str	x8, [x9, #8]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #16]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_fprintf
	ldr	w8, [sp, #184]
	add	w8, w8, #1
	str	w8, [sp, #184]
	b	LBB0_19
LBB0_27:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrb	w0, [sp, #112]
	bl	_isa_get_info
	str	x0, [sp, #96]
	ldr	w8, [sp, #228]
	subs	w8, w8, #1
	b.ne	LBB0_32
	b	LBB0_28
LBB0_28:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x8, [sp, #232]
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #96]
	cbz	x8, LBB0_30
	b	LBB0_29
LBB0_29:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x8, [sp, #96]
	ldr	x8, [x8]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB0_31
LBB0_30:                                ;   in Loop: Header=BB0_19 Depth=1
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	b	LBB0_31
LBB0_31:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_fprintf
	b	LBB0_36
LBB0_32:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x8, [sp, #232]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #220]
	ldr	w9, [sp, #184]
	add	w8, w8, w9
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #96]
	cbz	x8, LBB0_34
	b	LBB0_33
LBB0_33:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x8, [sp, #96]
	ldr	x8, [x8]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB0_35
LBB0_34:                                ;   in Loop: Header=BB0_19 Depth=1
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB0_35
LBB0_35:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w11, [sp, #52]                  ; 4-byte Folded Reload
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x10, [x9]
                                        ; implicit-def: $x10
	mov	x10, x11
	str	x10, [x9, #8]
	str	x8, [x9, #16]
	adrp	x1, l_.str.6@PAGE
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_fprintf
	b	LBB0_36
LBB0_36:                                ;   in Loop: Header=BB0_19 Depth=1
	str	wzr, [sp, #92]
	b	LBB0_37
LBB0_37:                                ;   Parent Loop BB0_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #92]
	ldrb	w9, [sp, #113]
	subs	w8, w8, w9
	b.ge	LBB0_40
	b	LBB0_38
LBB0_38:                                ;   in Loop: Header=BB0_37 Depth=2
	ldr	x0, [sp, #232]
	ldr	w2, [sp, #92]
	ldr	x3, [sp, #240]
	ldr	w4, [sp, #184]
	ldr	w6, [sp, #224]
	ldr	w7, [sp, #228]
	add	x1, sp, #112
	add	x5, sp, #264
	bl	_format_operand
	b	LBB0_39
LBB0_39:                                ;   in Loop: Header=BB0_37 Depth=2
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB0_37
LBB0_40:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w8, [sp, #228]
	cbnz	w8, LBB0_54
	b	LBB0_41
LBB0_41:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrb	w8, [sp, #112]
	subs	w8, w8, #162
	b.ne	LBB0_46
	b	LBB0_42
LBB0_42:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrb	w8, [sp, #113]
	subs	w8, w8, #0
	b.le	LBB0_46
	b	LBB0_43
LBB0_43:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w8, [sp, #120]
	str	w8, [sp, #188]
	ldr	w8, [sp, #188]
	subs	w8, w8, #0
	b.ls	LBB0_45
	b	LBB0_44
LBB0_44:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x10, [sp, #208]
	ldr	w8, [sp, #188]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	bl	_fprintf
	b	LBB0_45
LBB0_45:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_49
LBB0_46:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	w8, [sp, #188]
	subs	w8, w8, #0
	b.ls	LBB0_48
	b	LBB0_47
LBB0_47:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x10, [sp, #208]
	ldr	w8, [sp, #188]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_fprintf
	b	LBB0_48
LBB0_48:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_49
LBB0_49:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrb	w0, [sp, #112]
	bl	_is_control_flow_opcode
	tbz	w0, #0, LBB0_53
	b	LBB0_50
LBB0_50:                                ;   in Loop: Header=BB0_19 Depth=1
	ldrb	w0, [sp, #112]
	bl	_control_flow_note
	str	x0, [sp, #80]
	ldr	x8, [sp, #80]
	cbz	x8, LBB0_52
	b	LBB0_51
LBB0_51:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #80]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.9@PAGE
	add	x1, x1, l_.str.9@PAGEOFF
	bl	_fprintf
	b	LBB0_52
LBB0_52:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_53
LBB0_53:                                ;   in Loop: Header=BB0_19 Depth=1
	b	LBB0_54
LBB0_54:                                ;   in Loop: Header=BB0_19 Depth=1
	ldr	x0, [sp, #232]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	ldr	w9, [sp, #108]
	ldr	w8, [sp, #184]
	add	w8, w8, w9
	str	w8, [sp, #184]
	b	LBB0_19
LBB0_55:
	ldr	w1, [sp, #224]
	ldr	w2, [sp, #184]
	add	x0, sp, #264
	bl	_find_label_at
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbz	x8, LBB0_57
	b	LBB0_56
LBB0_56:
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #72]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_fprintf
	b	LBB0_57
LBB0_57:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB0_59
	b	LBB0_58
LBB0_58:
	bl	___stack_chk_fail
LBB0_59:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #2320
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_jump_targets
_collect_jump_targets:                  ; @collect_jump_targets
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	stur	x2, [x29, #-24]
	stur	w3, [x29, #-28]
	stur	wzr, [x29, #-32]
	stur	wzr, [x29, #-36]
	b	LBB1_1
LBB1_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_10 Depth 2
	ldur	w8, [x29, #-36]
	ldur	w9, [x29, #-12]
	subs	w8, w8, w9
	b.hs	LBB1_21
	b	LBB1_2
LBB1_2:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldur	x8, [x29, #-8]
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	w8, [x29, #-12]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #40
	bl	_isa_decode
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	cbnz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	b	LBB1_21
LBB1_4:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldrb	w0, [sp, #40]
	bl	_branch_operand_index
	str	w0, [sp, #32]
	ldr	w8, [sp, #32]
	tbnz	w8, #31, LBB1_20
	b	LBB1_5
LBB1_5:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldr	w8, [sp, #32]
	ldrb	w9, [sp, #41]
	subs	w8, w8, w9
	b.ge	LBB1_20
	b	LBB1_6
LBB1_6:                                 ;   in Loop: Header=BB1_1 Depth=1
	add	x8, sp, #40
	add	x8, x8, #40
	ldrsw	x9, [sp, #32]
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #4
	b.ne	LBB1_20
	b	LBB1_7
LBB1_7:                                 ;   in Loop: Header=BB1_1 Depth=1
	add	x8, sp, #40
	add	x8, x8, #8
	ldrsw	x9, [sp, #32]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	str	w8, [sp, #28]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #28]
	add	x8, x8, x9
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	tbnz	x8, #63, LBB1_19
	b	LBB1_8
LBB1_8:                                 ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #16]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hi	LBB1_19
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_1 Depth=1
	strb	wzr, [sp, #15]
	str	wzr, [sp, #8]
	b	LBB1_10
LBB1_10:                                ;   Parent Loop BB1_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #8]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.hs	LBB1_15
	b	LBB1_11
LBB1_11:                                ;   in Loop: Header=BB1_10 Depth=2
	ldur	x8, [x29, #-24]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #20                        ; =0x14
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #16]
	subs	x8, x8, x9
	b.ne	LBB1_13
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_1 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #15]
	b	LBB1_15
LBB1_13:                                ;   in Loop: Header=BB1_10 Depth=2
	b	LBB1_14
LBB1_14:                                ;   in Loop: Header=BB1_10 Depth=2
	ldr	w8, [sp, #8]
	add	w8, w8, #1
	str	w8, [sp, #8]
	b	LBB1_10
LBB1_15:                                ;   in Loop: Header=BB1_1 Depth=1
	ldrb	w8, [sp, #15]
	tbnz	w8, #0, LBB1_18
	b	LBB1_16
LBB1_16:                                ;   in Loop: Header=BB1_1 Depth=1
	ldur	w8, [x29, #-32]
	ldur	w9, [x29, #-28]
	subs	w8, w8, w9
	b.hs	LBB1_18
	b	LBB1_17
LBB1_17:                                ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #16]
	ldur	x10, [x29, #-24]
	ldur	w9, [x29, #-32]
	mov	x11, x9
	mov	x9, #20                         ; =0x14
	mov	x12, x9
                                        ; kill: def $w11 killed $w11 killed $x11
	umull	x11, w11, w12
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x10, x11]
	ldur	x10, [x29, #-24]
	ldur	w8, [x29, #-32]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x0, x8, #4
	ldur	w8, [x29, #-32]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	mov	x1, #16                         ; =0x10
	mov	w2, #0                          ; =0x0
	mov	x3, #-1                         ; =0xffffffffffffffff
	adrp	x4, l_.str.38@PAGE
	add	x4, x4, l_.str.38@PAGEOFF
	bl	___snprintf_chk
	ldur	w8, [x29, #-32]
	add	w8, w8, #1
	stur	w8, [x29, #-32]
	b	LBB1_18
LBB1_18:                                ;   in Loop: Header=BB1_1 Depth=1
	b	LBB1_19
LBB1_19:                                ;   in Loop: Header=BB1_1 Depth=1
	b	LBB1_20
LBB1_20:                                ;   in Loop: Header=BB1_1 Depth=1
	ldr	w9, [sp, #36]
	ldur	w8, [x29, #-36]
	add	w8, w8, w9
	stur	w8, [x29, #-36]
	b	LBB1_1
LBB1_21:
	ldur	w0, [x29, #-32]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function find_label_at
_find_label_at:                         ; @find_label_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	w2, [sp, #8]
	str	wzr, [sp, #4]
	b	LBB2_1
LBB2_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.hs	LBB2_6
	b	LBB2_2
LBB2_2:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	x8, [sp, #16]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	mov	x10, #20                        ; =0x14
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #8]
	subs	w8, w8, w9
	b.ne	LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	x10, [sp, #16]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #20                         ; =0x14
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #4
	str	x8, [sp, #24]
	b	LBB2_7
LBB2_4:                                 ;   in Loop: Header=BB2_1 Depth=1
	b	LBB2_5
LBB2_5:                                 ;   in Loop: Header=BB2_1 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB2_1
LBB2_6:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB2_7
LBB2_7:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function format_operand
_format_operand:                        ; @format_operand
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	stur	x3, [x29, #-32]
	stur	w4, [x29, #-36]
	stur	x5, [x29, #-48]
	stur	w6, [x29, #-52]
	stur	w7, [x29, #-56]
	ldur	x8, [x29, #-16]
	ldursw	x9, [x29, #-20]
	add	x8, x8, #40
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w8, LBB3_52
	b	LBB3_1
LBB3_1:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB3_7
	b	LBB3_2
LBB3_2:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB3_8
	b	LBB3_3
LBB3_3:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB3_9
	b	LBB3_4
LBB3_4:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB3_41
	b	LBB3_5
LBB3_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #5
	b.eq	LBB3_50
	b	LBB3_6
LBB3_6:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #6
	b.eq	LBB3_51
	b	LBB3_53
LBB3_7:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldrb	w10, [x8, x9]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_8:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldrh	w10, [x8, x9]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_9:
	ldur	w8, [x29, #-56]
	cbnz	w8, LBB3_16
	b	LBB3_10
LBB3_10:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	subs	w8, w8, #4
	b.ne	LBB3_16
	b	LBB3_11
LBB3_11:
	ldur	w8, [x29, #-20]
	cbnz	w8, LBB3_16
	b	LBB3_12
LBB3_12:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_16
	b	LBB3_13
LBB3_13:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w1, [x8, x9]
	bl	_nvm_get_string
	stur	x0, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbz	x8, LBB3_15
	b	LBB3_14
LBB3_14:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-64]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.40@PAGE
	add	x1, x1, l_.str.40@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_15:
	b	LBB3_16
LBB3_16:
	ldur	w8, [x29, #-56]
	cbnz	w8, LBB3_26
	b	LBB3_17
LBB3_17:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	subs	w8, w8, #59
	b.eq	LBB3_19
	b	LBB3_18
LBB3_18:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	subs	w8, w8, #51
	b.ne	LBB3_26
	b	LBB3_19
LBB3_19:
	ldur	w8, [x29, #-20]
	cbnz	w8, LBB3_26
	b	LBB3_20
LBB3_20:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_26
	b	LBB3_21
LBB3_21:
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	stur	w8, [x29, #-68]
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB3_25
	b	LBB3_22
LBB3_22:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #256]
	ldur	w9, [x29, #-68]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	bl	_nvm_get_string
	stur	x0, [x29, #-80]
	ldur	x8, [x29, #-80]
	cbz	x8, LBB3_24
	b	LBB3_23
LBB3_23:
	ldur	x0, [x29, #-8]
	ldur	w8, [x29, #-68]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-80]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.41@PAGE
	add	x1, x1, l_.str.41@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_24:
	b	LBB3_25
LBB3_25:
	b	LBB3_26
LBB3_26:
	ldur	w8, [x29, #-56]
	cbnz	w8, LBB3_40
	b	LBB3_27
LBB3_27:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	subs	w8, w8, #62
	b.ne	LBB3_40
	b	LBB3_28
LBB3_28:
	ldur	w8, [x29, #-20]
	cbnz	w8, LBB3_40
	b	LBB3_29
LBB3_29:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB3_40
	b	LBB3_30
LBB3_30:
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	stur	w8, [x29, #-84]
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB3_39
	b	LBB3_31
LBB3_31:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #80]
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #80]
	ldr	w1, [x8]
	bl	_nvm_get_string
	str	x0, [sp, #72]
	ldur	x0, [x29, #-32]
	ldr	x8, [sp, #80]
	ldr	w1, [x8, #4]
	bl	_nvm_get_string
	str	x0, [sp, #64]
	ldur	x0, [x29, #-8]
	ldur	w8, [x29, #-84]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	ldr	x8, [sp, #72]
	cbz	x8, LBB3_34
	b	LBB3_32
LBB3_32:
	ldr	x8, [sp, #64]
	cbz	x8, LBB3_34
	b	LBB3_33
LBB3_33:
	ldur	x0, [x29, #-8]
	ldr	x10, [sp, #72]
	ldr	x8, [sp, #64]
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.42@PAGE
	add	x1, x1, l_.str.42@PAGEOFF
	bl	_fprintf
	b	LBB3_38
LBB3_34:
	ldr	x8, [sp, #64]
	cbz	x8, LBB3_36
	b	LBB3_35
LBB3_35:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #64]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.43@PAGE
	add	x1, x1, l_.str.43@PAGEOFF
	bl	_fprintf
	b	LBB3_37
LBB3_36:
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.44@PAGE
	add	x1, x1, l_.str.44@PAGEOFF
	bl	_fprintf
	b	LBB3_37
LBB3_37:
	b	LBB3_38
LBB3_38:
	b	LBB3_53
LBB3_39:
	b	LBB3_40
LBB3_40:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.39@PAGE
	add	x1, x1, l_.str.39@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_41:
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	str	w8, [sp, #60]
	ldur	x8, [x29, #-16]
	ldrb	w0, [x8]
	bl	_branch_operand_index
	ldur	w8, [x29, #-20]
	subs	w8, w0, w8
	b.ne	LBB3_49
	b	LBB3_42
LBB3_42:
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #60]
	add	x8, x8, x9
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	tbnz	x8, #63, LBB3_45
	b	LBB3_43
LBB3_43:
	ldr	x8, [sp, #48]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.gt	LBB3_45
	b	LBB3_44
LBB3_44:
	ldur	x0, [x29, #-48]
	ldur	w1, [x29, #-52]
	ldr	x8, [sp, #48]
	mov	x2, x8
	bl	_find_label_at
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_46
LBB3_45:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB3_46
LBB3_46:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	cbz	x8, LBB3_48
	b	LBB3_47
LBB3_47:
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #40]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_48:
	b	LBB3_49
LBB3_49:
	ldur	x0, [x29, #-8]
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.45@PAGE
	add	x1, x1, l_.str.45@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_50:
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	ldr	x8, [x8, x9, lsl #3]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.46@PAGE
	add	x1, x1, l_.str.46@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_51:
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldursw	x9, [x29, #-20]
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #32]
	ldur	x0, [x29, #-8]
	ldr	x8, [sp, #32]
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.47@PAGE
	add	x1, x1, l_.str.47@PAGEOFF
	bl	_fprintf
	b	LBB3_53
LBB3_52:
	b	LBB3_53
LBB3_53:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function is_control_flow_opcode
_is_control_flow_opcode:                ; @is_control_flow_opcode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #56
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_1
LBB4_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #58
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_2
LBB4_2:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #57
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_3
LBB4_3:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #107
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_4
LBB4_4:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #146
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_5
LBB4_5:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #59
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_6
LBB4_6:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #51
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_7
LBB4_7:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #62
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_8
LBB4_8:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #61
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB4_10
	b	LBB4_9
LBB4_9:
	ldr	w8, [sp, #12]
	subs	w8, w8, #163
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB4_10
LBB4_10:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function control_flow_note
_control_flow_note:                     ; @control_flow_note
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	str	w8, [sp]                        ; 4-byte Folded Spill
	subs	w8, w8, #51
	b.eq	LBB5_16
	b	LBB5_1
LBB5_1:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #56
	b.eq	LBB5_10
	b	LBB5_2
LBB5_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #57
	b.eq	LBB5_12
	b	LBB5_3
LBB5_3:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #58
	b.eq	LBB5_11
	b	LBB5_4
LBB5_4:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB5_15
	b	LBB5_5
LBB5_5:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #61
	b.eq	LBB5_18
	b	LBB5_6
LBB5_6:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #62
	b.eq	LBB5_17
	b	LBB5_7
LBB5_7:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #107
	b.eq	LBB5_13
	b	LBB5_8
LBB5_8:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #146
	b.eq	LBB5_14
	b	LBB5_9
LBB5_9:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	subs	w8, w8, #163
	b.eq	LBB5_19
	b	LBB5_20
LBB5_10:
	adrp	x8, l_.str.48@PAGE
	add	x8, x8, l_.str.48@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_11:
	adrp	x8, l_.str.49@PAGE
	add	x8, x8, l_.str.49@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_12:
	adrp	x8, l_.str.50@PAGE
	add	x8, x8, l_.str.50@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_13:
	adrp	x8, l_.str.51@PAGE
	add	x8, x8, l_.str.51@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_14:
	adrp	x8, l_.str.52@PAGE
	add	x8, x8, l_.str.52@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_15:
	adrp	x8, l_.str.53@PAGE
	add	x8, x8, l_.str.53@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_16:
	adrp	x8, l_.str.54@PAGE
	add	x8, x8, l_.str.54@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_17:
	adrp	x8, l_.str.55@PAGE
	add	x8, x8, l_.str.55@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_18:
	adrp	x8, l_.str.56@PAGE
	add	x8, x8, l_.str.56@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_19:
	adrp	x8, l_.str.57@PAGE
	add	x8, x8, l_.str.57@PAGEOFF
	str	x8, [sp, #8]
	b	LBB5_21
LBB5_20:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #8]
	b	LBB5_21
LBB5_21:
	ldr	x0, [sp, #8]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_disasm_function                ; -- Begin function disasm_function
	.p2align	2
_disasm_function:                       ; @disasm_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	str	x3, [sp]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	ldr	x3, [sp]
	mov	w4, #0                          ; =0x0
	bl	_disasm_function_styled
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_disasm_module_to_file_styled   ; -- Begin function disasm_module_to_file_styled
	.p2align	2
_disasm_module_to_file_styled:          ; @disasm_module_to_file_styled
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-32]
	stur	w2, [x29, #-36]
	ldur	x0, [x29, #-24]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB7_2
	b	LBB7_1
LBB7_1:
	b	LBB7_130
LBB7_2:
	stur	wzr, [x29, #-40]
	b	LBB7_3
LBB7_3:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB7_8
	b	LBB7_4
LBB7_4:                                 ;   in Loop: Header=BB7_3 Depth=1
	ldur	x0, [x29, #-24]
	ldur	w1, [x29, #-40]
	bl	_nvm_get_string
	cbnz	x0, LBB7_6
	b	LBB7_5
LBB7_5:                                 ;   in Loop: Header=BB7_3 Depth=1
	b	LBB7_7
LBB7_6:                                 ;   in Loop: Header=BB7_3 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.11@PAGE
	add	x1, x1, l_.str.11@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-24]
	ldur	w2, [x29, #-40]
	bl	_disasm_write_quoted
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_7
LBB7_7:                                 ;   in Loop: Header=BB7_3 Depth=1
	ldur	w8, [x29, #-40]
	add	w8, w8, #1
	stur	w8, [x29, #-40]
	b	LBB7_3
LBB7_8:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #248]
	subs	w8, w8, #0
	b.ls	LBB7_10
	b	LBB7_9
LBB7_9:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_10
LBB7_10:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_56
	b	LBB7_11
LBB7_11:
	stur	wzr, [x29, #-44]
	b	LBB7_12
LBB7_12:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-44]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #368]
	subs	w8, w8, w9
	b.hs	LBB7_15
	b	LBB7_13
LBB7_13:                                ;   in Loop: Header=BB7_12 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	mov	x10, x8
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #360]
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldr	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_fprintf
	b	LBB7_14
LBB7_14:                                ;   in Loop: Header=BB7_12 Depth=1
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB7_12
LBB7_15:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #368]
	cbz	w8, LBB7_17
	b	LBB7_16
LBB7_16:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_17
LBB7_17:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #468]
	cbnz	w8, LBB7_20
	b	LBB7_18
LBB7_18:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #472]
	cbnz	w8, LBB7_20
	b	LBB7_19
LBB7_19:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #476]
	cbz	w8, LBB7_21
	b	LBB7_20
LBB7_20:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #468]
	mov	x11, x8
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #472]
	mov	x10, x8
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #476]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x11, [x9]
	str	x10, [x9, #8]
	str	x8, [x9, #16]
	adrp	x1, l_.str.13@PAGE
	add	x1, x1, l_.str.13@PAGEOFF
	bl	_fprintf
	b	LBB7_21
LBB7_21:
	stur	wzr, [x29, #-48]
	b	LBB7_22
LBB7_22:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_24 Depth 2
	ldur	w8, [x29, #-48]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB7_33
	b	LBB7_23
LBB7_23:                                ;   in Loop: Header=BB7_22 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-48]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-56]
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.14@PAGE
	add	x1, x1, l_.str.14@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-24]
	ldur	x8, [x29, #-56]
	ldr	w2, [x8]
	bl	_disasm_write_quoted
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.15@PAGE
	add	x1, x1, l_.str.15@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-24]
	ldur	x8, [x29, #-56]
	ldr	w2, [x8, #4]
	bl	_disasm_write_quoted
	ldur	x8, [x29, #-32]
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-56]
	ldrb	w0, [x8, #10]
	bl	_isa_tag_name
	mov	x8, x0
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	sturh	wzr, [x29, #-58]
	b	LBB7_24
LBB7_24:                                ;   Parent Loop BB7_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-58]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB7_31
	b	LBB7_25
LBB7_25:                                ;   in Loop: Header=BB7_24 Depth=2
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #408]
	cbz	x8, LBB7_28
	b	LBB7_26
LBB7_26:                                ;   in Loop: Header=BB7_24 Depth=2
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-48]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB7_28
	b	LBB7_27
LBB7_27:                                ;   in Loop: Header=BB7_24 Depth=2
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-48]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldurh	w9, [x29, #-58]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #148]                  ; 4-byte Folded Spill
	b	LBB7_29
LBB7_28:                                ;   in Loop: Header=BB7_24 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #148]                  ; 4-byte Folded Spill
	b	LBB7_29
LBB7_29:                                ;   in Loop: Header=BB7_24 Depth=2
	ldr	w8, [sp, #148]                  ; 4-byte Folded Reload
	sturb	w8, [x29, #-59]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	ldurb	w0, [x29, #-59]
	bl	_isa_tag_name
	mov	x8, x0
	ldr	x0, [sp, #136]                  ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	b	LBB7_30
LBB7_30:                                ;   in Loop: Header=BB7_24 Depth=2
	ldurh	w8, [x29, #-58]
	add	w8, w8, #1
	sturh	w8, [x29, #-58]
	b	LBB7_24
LBB7_31:                                ;   in Loop: Header=BB7_22 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_32
LBB7_32:                                ;   in Loop: Header=BB7_22 Depth=1
	ldur	w8, [x29, #-48]
	add	w8, w8, #1
	stur	w8, [x29, #-48]
	b	LBB7_22
LBB7_33:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #432]
	cbz	w8, LBB7_35
	b	LBB7_34
LBB7_34:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_35
LBB7_35:
	stur	wzr, [x29, #-64]
	b	LBB7_36
LBB7_36:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-64]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB7_41
	b	LBB7_37
LBB7_37:                                ;   in Loop: Header=BB7_36 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #11]
	cbz	w8, LBB7_39
	b	LBB7_38
LBB7_38:                                ;   in Loop: Header=BB7_36 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w8, [x29, #-64]
	mov	x10, x8
	ldur	x8, [x29, #-24]
	ldr	x11, [x8, #400]
	ldur	w8, [x29, #-64]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldrb	w11, [x8, #11]
	adrp	x9, l_.str.19@PAGE
	add	x9, x9, l_.str.19@PAGEOFF
	adrp	x8, l_.str.18@PAGE
	add	x8, x8, l_.str.18@PAGEOFF
	subs	w11, w11, #2
	csel	x8, x8, x9, eq
	mov	x9, sp
	str	x10, [x9]
	str	x8, [x9, #8]
	adrp	x1, l_.str.17@PAGE
	add	x1, x1, l_.str.17@PAGEOFF
	bl	_fprintf
	b	LBB7_39
LBB7_39:                                ;   in Loop: Header=BB7_36 Depth=1
	b	LBB7_40
LBB7_40:                                ;   in Loop: Header=BB7_36 Depth=1
	ldur	w8, [x29, #-64]
	add	w8, w8, #1
	stur	w8, [x29, #-64]
	b	LBB7_36
LBB7_41:
	stur	wzr, [x29, #-68]
	b	LBB7_42
LBB7_42:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_44 Depth 2
	ldur	w8, [x29, #-68]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #424]
	subs	w8, w8, w9
	b.hs	LBB7_49
	b	LBB7_43
LBB7_43:                                ;   in Loop: Header=BB7_42 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #416]
	ldur	w9, [x29, #-68]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-80]
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-80]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-80]
	ldrh	w10, [x9, #8]
	mov	x9, sp
	str	x8, [x9]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #8]
	adrp	x1, l_.str.20@PAGE
	add	x1, x1, l_.str.20@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-24]
	ldur	x8, [x29, #-80]
	ldr	w2, [x8, #4]
	bl	_disasm_write_quoted
	ldur	x8, [x29, #-32]
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8, #10]
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
	ldur	x8, [x29, #-80]
	ldrb	w10, [x8, #11]
	adrp	x9, l_.str.23@PAGE
	add	x9, x9, l_.str.23@PAGEOFF
	adrp	x8, l_.str.22@PAGE
	add	x8, x8, l_.str.22@PAGEOFF
	subs	w10, w10, #1
	csel	x8, x8, x9, eq
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-80]
	ldrb	w0, [x8, #14]
	bl	_isa_tag_name
	ldr	w12, [sp, #116]                 ; 4-byte Folded Reload
	ldr	x10, [sp, #120]                 ; 8-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	mov	x9, sp
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x9]
	str	x10, [x9, #8]
	str	x8, [x9, #16]
	adrp	x1, l_.str.21@PAGE
	add	x1, x1, l_.str.21@PAGEOFF
	bl	_fprintf
	sturh	wzr, [x29, #-82]
	b	LBB7_44
LBB7_44:                                ;   Parent Loop BB7_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-82]
	ldur	x9, [x29, #-80]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ge	LBB7_47
	b	LBB7_45
LBB7_45:                                ;   in Loop: Header=BB7_44 Depth=2
	ldur	x8, [x29, #-32]
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	ldur	x8, [x29, #-80]
	add	x8, x8, #15
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	bl	_isa_tag_name
	mov	x8, x0
	ldr	x0, [sp, #104]                  ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	b	LBB7_46
LBB7_46:                                ;   in Loop: Header=BB7_44 Depth=2
	ldurh	w8, [x29, #-82]
	add	w8, w8, #1
	sturh	w8, [x29, #-82]
	b	LBB7_44
LBB7_47:                                ;   in Loop: Header=BB7_42 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_48
LBB7_48:                                ;   in Loop: Header=BB7_42 Depth=1
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB7_42
LBB7_49:
	stur	wzr, [x29, #-88]
	b	LBB7_50
LBB7_50:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #448]
	subs	w8, w8, w9
	b.hs	LBB7_53
	b	LBB7_51
LBB7_51:                                ;   in Loop: Header=BB7_50 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.24@PAGE
	add	x1, x1, l_.str.24@PAGEOFF
	bl	_fprintf
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #440]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldr	w2, [x8, x9, lsl #2]
	bl	_disasm_write_quoted
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_52
LBB7_52:                                ;   in Loop: Header=BB7_50 Depth=1
	ldur	w8, [x29, #-88]
	add	w8, w8, #1
	stur	w8, [x29, #-88]
	b	LBB7_50
LBB7_53:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #448]
	cbz	w8, LBB7_55
	b	LBB7_54
LBB7_54:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_55
LBB7_55:
	b	LBB7_56
LBB7_56:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_64
	b	LBB7_57
LBB7_57:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	tbz	w8, #1, LBB7_59
	b	LBB7_58
LBB7_58:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.25@PAGE
	add	x1, x1, l_.str.25@PAGEOFF
	bl	_fprintf
	b	LBB7_59
LBB7_59:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	tbz	w8, #2, LBB7_61
	b	LBB7_60
LBB7_60:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.26@PAGE
	add	x1, x1, l_.str.26@PAGEOFF
	bl	_fprintf
	b	LBB7_61
LBB7_61:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	and	w8, w8, #0x6
	cbz	w8, LBB7_63
	b	LBB7_62
LBB7_62:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_63
LBB7_63:
	b	LBB7_64
LBB7_64:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_72
	b	LBB7_65
LBB7_65:
	stur	wzr, [x29, #-92]
	b	LBB7_66
LBB7_66:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-92]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #384]
	subs	w8, w8, w9
	b.hs	LBB7_69
	b	LBB7_67
LBB7_67:                                ;   in Loop: Header=BB7_66 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #376]
	ldur	w8, [x29, #-92]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-104]
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-104]
	ldr	w8, [x8]
	mov	x11, x8
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #4]
	mov	x10, x8
	ldur	x8, [x29, #-104]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x11, [x9]
	str	x10, [x9, #8]
	str	x8, [x9, #16]
	adrp	x1, l_.str.27@PAGE
	add	x1, x1, l_.str.27@PAGEOFF
	bl	_fprintf
	b	LBB7_68
LBB7_68:                                ;   in Loop: Header=BB7_66 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB7_66
LBB7_69:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #384]
	cbz	w8, LBB7_71
	b	LBB7_70
LBB7_70:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_71
LBB7_71:
	b	LBB7_72
LBB7_72:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_84
	b	LBB7_73
LBB7_73:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #352]
	cbz	w8, LBB7_84
	b	LBB7_74
LBB7_74:
	stur	wzr, [x29, #-108]
	b	LBB7_75
LBB7_75:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-108]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #352]
	subs	w8, w8, w9
	b.hs	LBB7_83
	b	LBB7_76
LBB7_76:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	w8, [x29, #-108]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbnz	w8, LBB7_78
	b	LBB7_77
LBB7_77:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.28@PAGE
	add	x1, x1, l_.str.28@PAGEOFF
	bl	_fprintf
	b	LBB7_78
LBB7_78:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #344]
	ldur	w9, [x29, #-108]
                                        ; kill: def $x9 killed $w9
	ldrb	w10, [x8, x9]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.29@PAGE
	add	x1, x1, l_.str.29@PAGEOFF
	bl	_fprintf
	ldur	w8, [x29, #-108]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	subs	w8, w8, #31
	b.eq	LBB7_80
	b	LBB7_79
LBB7_79:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	w8, [x29, #-108]
	add	w8, w8, #1
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #352]
	subs	w8, w8, w9
	b.ne	LBB7_81
	b	LBB7_80
LBB7_80:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.30@PAGE
	add	x1, x1, l_.str.30@PAGEOFF
	bl	_fprintf
	b	LBB7_81
LBB7_81:                                ;   in Loop: Header=BB7_75 Depth=1
	b	LBB7_82
LBB7_82:                                ;   in Loop: Header=BB7_75 Depth=1
	ldur	w8, [x29, #-108]
	add	w8, w8, #1
	stur	w8, [x29, #-108]
	b	LBB7_75
LBB7_83:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_84
LBB7_84:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_96
	b	LBB7_85
LBB7_85:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #320]
	cbz	w8, LBB7_96
	b	LBB7_86
LBB7_86:
	stur	wzr, [x29, #-112]
	b	LBB7_87
LBB7_87:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-112]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #320]
	subs	w8, w8, w9
	b.hs	LBB7_95
	b	LBB7_88
LBB7_88:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	w8, [x29, #-112]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbnz	w8, LBB7_90
	b	LBB7_89
LBB7_89:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.31@PAGE
	add	x1, x1, l_.str.31@PAGEOFF
	bl	_fprintf
	b	LBB7_90
LBB7_90:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #312]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldrb	w10, [x8, x9]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.29@PAGE
	add	x1, x1, l_.str.29@PAGEOFF
	bl	_fprintf
	ldur	w8, [x29, #-112]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	subs	w8, w8, #31
	b.eq	LBB7_92
	b	LBB7_91
LBB7_91:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #320]
	subs	w8, w8, w9
	b.ne	LBB7_93
	b	LBB7_92
LBB7_92:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.30@PAGE
	add	x1, x1, l_.str.30@PAGEOFF
	bl	_fprintf
	b	LBB7_93
LBB7_93:                                ;   in Loop: Header=BB7_87 Depth=1
	b	LBB7_94
LBB7_94:                                ;   in Loop: Header=BB7_87 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	stur	w8, [x29, #-112]
	b	LBB7_87
LBB7_95:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_96
LBB7_96:
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_108
	b	LBB7_97
LBB7_97:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #304]
	cbz	w8, LBB7_108
	b	LBB7_98
LBB7_98:
	stur	wzr, [x29, #-116]
	b	LBB7_99
LBB7_99:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-116]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #304]
	subs	w8, w8, w9
	b.hs	LBB7_107
	b	LBB7_100
LBB7_100:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	w8, [x29, #-116]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	cbnz	w8, LBB7_102
	b	LBB7_101
LBB7_101:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.32@PAGE
	add	x1, x1, l_.str.32@PAGEOFF
	bl	_fprintf
	b	LBB7_102
LBB7_102:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #296]
	ldur	w9, [x29, #-116]
                                        ; kill: def $x9 killed $w9
	ldrb	w10, [x8, x9]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.29@PAGE
	add	x1, x1, l_.str.29@PAGEOFF
	bl	_fprintf
	ldur	w8, [x29, #-116]
	mov	w10, #32                        ; =0x20
	udiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w8, w8, w9
	subs	w8, w8, #31
	b.eq	LBB7_104
	b	LBB7_103
LBB7_103:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #304]
	subs	w8, w8, w9
	b.ne	LBB7_105
	b	LBB7_104
LBB7_104:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.30@PAGE
	add	x1, x1, l_.str.30@PAGEOFF
	bl	_fprintf
	b	LBB7_105
LBB7_105:                               ;   in Loop: Header=BB7_99 Depth=1
	b	LBB7_106
LBB7_106:                               ;   in Loop: Header=BB7_99 Depth=1
	ldur	w8, [x29, #-116]
	add	w8, w8, #1
	stur	w8, [x29, #-116]
	b	LBB7_99
LBB7_107:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_fprintf
	b	LBB7_108
LBB7_108:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB7_110
	b	LBB7_109
LBB7_109:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.33@PAGE
	add	x1, x1, l_.str.33@PAGEOFF
	bl	_fprintf
	b	LBB7_110
LBB7_110:
	stur	wzr, [x29, #-120]
	b	LBB7_111
LBB7_111:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_124 Depth 2
	ldur	w8, [x29, #-120]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB7_130
	b	LBB7_112
LBB7_112:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-120]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-128]
	ldur	x0, [x29, #-24]
	ldur	x8, [x29, #-128]
	ldr	w1, [x8]
	bl	_nvm_get_string
	stur	x0, [x29, #-136]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-136]
	cbz	x8, LBB7_114
	b	LBB7_113
LBB7_113:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-136]
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB7_115
LBB7_114:                               ;   in Loop: Header=BB7_111 Depth=1
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	b	LBB7_115
LBB7_115:                               ;   in Loop: Header=BB7_111 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #4]
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	str	w8, [sp, #80]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #18]
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	ldur	x8, [x29, #-128]
	ldrb	w0, [x8, #20]
	bl	_isa_tag_name
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w14, [sp, #76]                  ; 4-byte Folded Reload
	ldr	w13, [sp, #80]                  ; 4-byte Folded Reload
	ldr	w12, [sp, #84]                  ; 4-byte Folded Reload
	mov	x8, x0
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-128]
	ldrb	w10, [x9, #21]
	mov	x9, sp
	str	x11, [x9]
                                        ; implicit-def: $x11
	mov	x11, x14
	str	x11, [x9, #8]
                                        ; implicit-def: $x11
	mov	x11, x13
	str	x11, [x9, #16]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x9, #24]
	str	x8, [x9, #32]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #40]
	adrp	x1, l_.str.34@PAGE
	add	x1, x1, l_.str.34@PAGEOFF
	bl	_fprintf
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	b.ls	LBB7_119
	b	LBB7_116
LBB7_116:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB7_119
	b	LBB7_117
LBB7_117:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-128]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB7_119
	b	LBB7_118
LBB7_118:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-128]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-128]
	ldr	w1, [x8, #12]
	ldur	x2, [x29, #-24]
	ldur	x3, [x29, #-32]
	ldur	w4, [x29, #-36]
	bl	_disasm_function_styled
	b	LBB7_119
LBB7_119:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.35@PAGE
	add	x1, x1, l_.str.35@PAGEOFF
	bl	_fprintf
	ldur	w8, [x29, #-36]
	subs	w8, w8, #1
	b.ne	LBB7_128
	b	LBB7_120
LBB7_120:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB7_128
	b	LBB7_121
LBB7_121:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #264]
	cbz	x8, LBB7_128
	b	LBB7_122
LBB7_122:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-120]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB7_128
	b	LBB7_123
LBB7_123:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w8, [x29, #-120]
                                        ; kill: def $x8 killed $w8
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.36@PAGE
	add	x1, x1, l_.str.36@PAGEOFF
	bl	_fprintf
	sturh	wzr, [x29, #-138]
	b	LBB7_124
LBB7_124:                               ;   Parent Loop BB7_111 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-138]
	ldur	x9, [x29, #-128]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB7_127
	b	LBB7_125
LBB7_125:                               ;   in Loop: Header=BB7_124 Depth=2
	ldur	x8, [x29, #-32]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-24]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-120]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldurh	w9, [x29, #-138]
                                        ; kill: def $x9 killed $w9
	ldrb	w0, [x8, x9]
	bl	_isa_tag_name
	mov	x8, x0
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	x9, sp
	str	x8, [x9]
	adrp	x1, l_.str.16@PAGE
	add	x1, x1, l_.str.16@PAGEOFF
	bl	_fprintf
	b	LBB7_126
LBB7_126:                               ;   in Loop: Header=BB7_124 Depth=2
	ldurh	w8, [x29, #-138]
	add	w8, w8, #1
	sturh	w8, [x29, #-138]
	b	LBB7_124
LBB7_127:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.37@PAGE
	add	x1, x1, l_.str.37@PAGEOFF
	bl	_fprintf
	b	LBB7_128
LBB7_128:                               ;   in Loop: Header=BB7_111 Depth=1
	b	LBB7_129
LBB7_129:                               ;   in Loop: Header=BB7_111 Depth=1
	ldur	w8, [x29, #-120]
	add	w8, w8, #1
	stur	w8, [x29, #-120]
	b	LBB7_111
LBB7_130:
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function disasm_write_quoted
_disasm_write_quoted:                   ; @disasm_write_quoted
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_nvm_get_string
	str	x0, [sp, #32]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_nvm_get_string_len
	str	w0, [sp, #28]
	ldur	x1, [x29, #-8]
	mov	w0, #34                         ; =0x22
	bl	_fputc
	str	wzr, [sp, #24]
	b	LBB8_1
LBB8_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #32]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #16]                   ; 4-byte Folded Spill
	cbz	x8, LBB8_3
	b	LBB8_2
LBB8_2:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #24]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	cset	w8, lo
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB8_3
LBB8_3:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB8_21
	b	LBB8_4
LBB8_4:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	x8, [sp, #32]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #23]
	ldrb	w8, [sp, #23]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #9
	b.eq	LBB8_11
	b	LBB8_5
LBB8_5:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #10
	b.eq	LBB8_9
	b	LBB8_6
LBB8_6:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #13
	b.eq	LBB8_10
	b	LBB8_7
LBB8_7:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #34
	b.eq	LBB8_13
	b	LBB8_8
LBB8_8:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #92
	b.eq	LBB8_12
	b	LBB8_14
LBB8_9:                                 ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.58@PAGE
	add	x1, x1, l_.str.58@PAGEOFF
	bl	_fprintf
	b	LBB8_19
LBB8_10:                                ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.59@PAGE
	add	x1, x1, l_.str.59@PAGEOFF
	bl	_fprintf
	b	LBB8_19
LBB8_11:                                ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.60@PAGE
	add	x1, x1, l_.str.60@PAGEOFF
	bl	_fprintf
	b	LBB8_19
LBB8_12:                                ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.61@PAGE
	add	x1, x1, l_.str.61@PAGEOFF
	bl	_fprintf
	b	LBB8_19
LBB8_13:                                ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	adrp	x1, l_.str.62@PAGE
	add	x1, x1, l_.str.62@PAGEOFF
	bl	_fprintf
	b	LBB8_19
LBB8_14:                                ;   in Loop: Header=BB8_1 Depth=1
	ldrb	w8, [sp, #23]
	subs	w8, w8, #32
	b.lt	LBB8_16
	b	LBB8_15
LBB8_15:                                ;   in Loop: Header=BB8_1 Depth=1
	ldrb	w8, [sp, #23]
	subs	w8, w8, #127
	b.lt	LBB8_17
	b	LBB8_16
LBB8_16:                                ;   in Loop: Header=BB8_1 Depth=1
	ldur	x0, [x29, #-8]
	ldrb	w10, [sp, #23]
	mov	x9, sp
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9]
	adrp	x1, l_.str.63@PAGE
	add	x1, x1, l_.str.63@PAGEOFF
	bl	_fprintf
	b	LBB8_18
LBB8_17:                                ;   in Loop: Header=BB8_1 Depth=1
	ldrb	w0, [sp, #23]
	ldur	x1, [x29, #-8]
	bl	_fputc
	b	LBB8_18
LBB8_18:                                ;   in Loop: Header=BB8_1 Depth=1
	b	LBB8_19
LBB8_19:                                ;   in Loop: Header=BB8_1 Depth=1
	b	LBB8_20
LBB8_20:                                ;   in Loop: Header=BB8_1 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB8_1
LBB8_21:
	ldur	x1, [x29, #-8]
	mov	w0, #34                         ; =0x22
	bl	_fputc
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_disasm_module_to_file          ; -- Begin function disasm_module_to_file
	.p2align	2
_disasm_module_to_file:                 ; @disasm_module_to_file
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w2, #0                          ; =0x0
	bl	_disasm_module_to_file_styled
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_disasm_module_styled           ; -- Begin function disasm_module_styled
	.p2align	2
_disasm_module_styled:                  ; @disasm_module_styled
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x0, [x29, #-16]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB10_2
	b	LBB10_1
LBB10_1:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_5
LBB10_2:
	add	x0, sp, #16
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #16]
	add	x1, sp, #8
	str	xzr, [sp, #8]
	bl	_open_memstream
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB10_4
	b	LBB10_3
LBB10_3:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB10_5
LBB10_4:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp]
	ldur	w2, [x29, #-20]
	bl	_disasm_module_to_file_styled
	ldr	x0, [sp]
	bl	_fclose
	ldr	x8, [sp, #16]
	stur	x8, [x29, #-8]
	b	LBB10_5
LBB10_5:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_disasm_module                  ; -- Begin function disasm_module
	.p2align	2
_disasm_module:                         ; @disasm_module
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	bl	_disasm_module_styled
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function branch_operand_index
_branch_operand_index:                  ; @branch_operand_index
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	subs	w8, w8, #56
	subs	w8, w8, #2
	b.ls	LBB12_3
	b	LBB12_1
LBB12_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #107
	b.eq	LBB12_4
	b	LBB12_2
LBB12_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #146
	b.eq	LBB12_4
	b	LBB12_5
LBB12_3:
	str	wzr, [sp, #12]
	b	LBB12_6
LBB12_4:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB12_6
LBB12_5:
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #12]
	b	LBB12_6
LBB12_6:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"<unknown>"

l_.str.1:                               ; @.str.1
	.asciz	"%s:\n"

l_.str.2:                               ; @.str.2
	.asciz	"%s:  ; <== jump target\n"

l_.str.3:                               ; @.str.3
	.asciz	"  ; ERROR: invalid opcode 0x%02x at offset %u (abs %u)\n"

l_.str.4:                               ; @.str.4
	.asciz	"  %s"

l_.str.5:                               ; @.str.5
	.asciz	"???"

l_.str.6:                               ; @.str.6
	.asciz	"  [%04u|%04u] %s"

l_.str.7:                               ; @.str.7
	.asciz	"  ; source %s:%u"

l_.str.8:                               ; @.str.8
	.asciz	"  ; @ %s:%u"

l_.str.9:                               ; @.str.9
	.asciz	"  ; cfg:%s"

l_.str.10:                              ; @.str.10
	.asciz	"\n"

l_.str.11:                              ; @.str.11
	.asciz	".string "

l_.str.12:                              ; @.str.12
	.asciz	".metadata %u %u\n"

l_.str.13:                              ; @.str.13
	.asciz	".types %u %u %u\n\n"

l_.str.14:                              ; @.str.14
	.asciz	".import "

l_.str.15:                              ; @.str.15
	.asciz	" "

l_.str.16:                              ; @.str.16
	.asciz	" %s"

l_.str.17:                              ; @.str.17
	.asciz	".import_kind %u %s\n"

l_.str.18:                              ; @.str.18
	.asciz	"artifact"

l_.str.19:                              ; @.str.19
	.asciz	"coprocess"

l_.str.20:                              ; @.str.20
	.asciz	".callback %u %u "

l_.str.21:                              ; @.str.21
	.asciz	" %u %s %s"

l_.str.22:                              ; @.str.22
	.asciz	"worker"

l_.str.23:                              ; @.str.23
	.asciz	"owner"

l_.str.24:                              ; @.str.24
	.asciz	".module_ref "

l_.str.25:                              ; @.str.25
	.asciz	".flag needs_extern\n"

l_.str.26:                              ; @.str.26
	.asciz	".flag debug_info\n"

l_.str.27:                              ; @.str.27
	.asciz	".debug %u %u %u\n"

l_.str.28:                              ; @.str.28
	.asciz	".passive \""

l_.str.29:                              ; @.str.29
	.asciz	"%02x"

l_.str.30:                              ; @.str.30
	.asciz	"\"\n"

l_.str.31:                              ; @.str.31
	.asciz	".layouts \""

l_.str.32:                              ; @.str.32
	.asciz	".ownership \""

l_.str.33:                              ; @.str.33
	.asciz	".entry %u\n\n"

l_.str.34:                              ; @.str.34
	.asciz	".function %s %u %u %u %s %u\n"

l_.str.35:                              ; @.str.35
	.asciz	".end\n\n"

l_.str.36:                              ; @.str.36
	.asciz	".parameters %u"

l_.str.37:                              ; @.str.37
	.asciz	"\n\n"

l_.str.38:                              ; @.str.38
	.asciz	"L%u"

l_.str.39:                              ; @.str.39
	.asciz	" %u"

l_.str.40:                              ; @.str.40
	.asciz	"  ; \"%s\""

l_.str.41:                              ; @.str.41
	.asciz	"  ; %s"

l_.str.42:                              ; @.str.42
	.asciz	"  ; import %s.%s"

l_.str.43:                              ; @.str.43
	.asciz	"  ; import %s"

l_.str.44:                              ; @.str.44
	.asciz	"  ; import"

l_.str.45:                              ; @.str.45
	.asciz	" %d"

l_.str.46:                              ; @.str.46
	.asciz	" %lld"

l_.str.47:                              ; @.str.47
	.asciz	" bits:%016llx"

l_.str.48:                              ; @.str.48
	.asciz	"jump"

l_.str.49:                              ; @.str.49
	.asciz	"branch-if-false"

l_.str.50:                              ; @.str.50
	.asciz	"branch-if-true"

l_.str.51:                              ; @.str.51
	.asciz	"match-tag-branch"

l_.str.52:                              ; @.str.52
	.asciz	"file-result-error-branch"

l_.str.53:                              ; @.str.53
	.asciz	"call"

l_.str.54:                              ; @.str.54
	.asciz	"tail-call"

l_.str.55:                              ; @.str.55
	.asciz	"extern-call"

l_.str.56:                              ; @.str.56
	.asciz	"return"

l_.str.57:                              ; @.str.57
	.asciz	"halt"

l_.str.58:                              ; @.str.58
	.asciz	"\\n"

l_.str.59:                              ; @.str.59
	.asciz	"\\r"

l_.str.60:                              ; @.str.60
	.asciz	"\\t"

l_.str.61:                              ; @.str.61
	.asciz	"\\\\"

l_.str.62:                              ; @.str.62
	.asciz	"\\\""

l_.str.63:                              ; @.str.63
	.asciz	"\\x%02x"

.subsections_via_symbols
