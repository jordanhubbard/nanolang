	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_multi_nominal_catalog_types ; -- Begin function nvm_multi_nominal_catalog_types
	.p2align	2
_nvm_multi_nominal_catalog_types:       ; @nvm_multi_nominal_catalog_types
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.ne	LBB0_2
	b	LBB0_1
LBB0_1:
	mov	w8, #8                          ; =0x8
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB0_6
LBB0_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.ne	LBB0_4
	b	LBB0_3
LBB0_3:
	mov	w8, #9                          ; =0x9
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB0_5
LBB0_4:
	ldr	w10, [sp, #12]
	mov	w9, #0                          ; =0x0
	mov	w8, #7                          ; =0x7
	subs	w10, w10, #3
	csel	w8, w8, w9, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB0_5
LBB0_5:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB0_6
LBB0_6:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_catalog_methods ; -- Begin function nvm_multi_nominal_catalog_methods
	.p2align	2
_nvm_multi_nominal_catalog_methods:     ; @nvm_multi_nominal_catalog_methods
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.eq	LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.ne	LBB1_3
	b	LBB1_2
LBB1_2:
	mov	w8, #5                          ; =0x5
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB1_4
LBB1_3:
	ldr	w10, [sp, #12]
	mov	w9, #0                          ; =0x0
	mov	w8, #4                          ; =0x4
	subs	w10, w10, #3
	csel	w8, w8, w9, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB1_4
LBB1_4:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_check        ; -- Begin function nvm_multi_nominal_check
	.p2align	2
_nvm_multi_nominal_check:               ; @nvm_multi_nominal_check
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB2_2
	b	LBB2_1
LBB2_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	cbz	w8, LBB2_4
	b	LBB2_3
LBB2_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8]
	subs	w8, w8, #64
	b.ls	LBB2_5
	b	LBB2_4
LBB2_4:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_5:
	stur	wzr, [x29, #-20]
	b	LBB2_6
LBB2_6:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_11 Depth 2
                                        ;     Child Loop BB2_17 Depth 2
                                        ;     Child Loop BB2_23 Depth 2
                                        ;       Child Loop BB2_31 Depth 3
                                        ;         Child Loop BB2_35 Depth 4
                                        ;           Child Loop BB2_46 Depth 5
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB2_59
	b	LBB2_7
LBB2_7:                                 ;   in Loop: Header=BB2_6 Depth=1
	ldur	x8, [x29, #-16]
	add	x10, x8, #4
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	w0, [x8]
	bl	_nvm_multi_nominal_catalog_types
	stur	w0, [x29, #-36]
	ldur	x8, [x29, #-32]
	ldr	w0, [x8]
	bl	_nvm_multi_nominal_catalog_methods
	stur	w0, [x29, #-40]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB2_9
	b	LBB2_8
LBB2_8:                                 ;   in Loop: Header=BB2_6 Depth=1
	ldur	w8, [x29, #-40]
	cbnz	w8, LBB2_10
	b	LBB2_9
LBB2_9:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_10:                                ;   in Loop: Header=BB2_6 Depth=1
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-44]
	b	LBB2_11
LBB2_11:                                ;   Parent Loop BB2_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-44]
	subs	w8, w8, #9
	b.hs	LBB2_16
	b	LBB2_12
LBB2_12:                                ;   in Loop: Header=BB2_11 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #24
	ldur	w9, [x29, #-44]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB2_14
	b	LBB2_13
LBB2_13:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_14:                                ;   in Loop: Header=BB2_11 Depth=2
	b	LBB2_15
LBB2_15:                                ;   in Loop: Header=BB2_11 Depth=2
	ldur	w8, [x29, #-44]
	add	w8, w8, #1
	stur	w8, [x29, #-44]
	b	LBB2_11
LBB2_16:                                ;   in Loop: Header=BB2_6 Depth=1
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-48]
	b	LBB2_17
LBB2_17:                                ;   Parent Loop BB2_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-48]
	subs	w8, w8, #5
	b.hs	LBB2_22
	b	LBB2_18
LBB2_18:                                ;   in Loop: Header=BB2_17 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #4
	ldur	w9, [x29, #-48]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB2_20
	b	LBB2_19
LBB2_19:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_20:                                ;   in Loop: Header=BB2_17 Depth=2
	b	LBB2_21
LBB2_21:                                ;   in Loop: Header=BB2_17 Depth=2
	ldur	w8, [x29, #-48]
	add	w8, w8, #1
	stur	w8, [x29, #-48]
	b	LBB2_17
LBB2_22:                                ;   in Loop: Header=BB2_6 Depth=1
	stur	wzr, [x29, #-52]
	b	LBB2_23
LBB2_23:                                ;   Parent Loop BB2_6 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB2_31 Depth 3
                                        ;         Child Loop BB2_35 Depth 4
                                        ;           Child Loop BB2_46 Depth 5
	ldur	w8, [x29, #-52]
	subs	w8, w8, #2
	b.hs	LBB2_57
	b	LBB2_24
LBB2_24:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	w8, [x29, #-52]
	cbz	w8, LBB2_26
	b	LBB2_25
LBB2_25:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #24
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB2_27
LBB2_26:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #4
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB2_27
LBB2_27:                                ;   in Loop: Header=BB2_23 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-64]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB2_29
	b	LBB2_28
LBB2_28:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	w8, [x29, #-36]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB2_30
LBB2_29:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	w8, [x29, #-40]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB2_30
LBB2_30:                                ;   in Loop: Header=BB2_23 Depth=2
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-68]
	str	wzr, [sp, #72]
	b	LBB2_31
LBB2_31:                                ;   Parent Loop BB2_6 Depth=1
                                        ;     Parent Loop BB2_23 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB2_35 Depth 4
                                        ;           Child Loop BB2_46 Depth 5
	ldr	w8, [sp, #72]
	ldur	w9, [x29, #-68]
	subs	w8, w8, w9
	b.hs	LBB2_55
	b	LBB2_32
LBB2_32:                                ;   in Loop: Header=BB2_31 Depth=3
	ldur	x8, [x29, #-64]
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.ne	LBB2_34
	b	LBB2_33
LBB2_33:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_34:                                ;   in Loop: Header=BB2_31 Depth=3
	str	wzr, [sp, #68]
	b	LBB2_35
LBB2_35:                                ;   Parent Loop BB2_6 Depth=1
                                        ;     Parent Loop BB2_23 Depth=2
                                        ;       Parent Loop BB2_31 Depth=3
                                        ; =>      This Loop Header: Depth=4
                                        ;           Child Loop BB2_46 Depth 5
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hi	LBB2_53
	b	LBB2_36
LBB2_36:                                ;   in Loop: Header=BB2_35 Depth=4
	ldur	x8, [x29, #-16]
	add	x10, x8, #4
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB2_38
	b	LBB2_37
LBB2_37:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	x8, [sp, #56]
	add	x8, x8, #24
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB2_39
LBB2_38:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	x8, [sp, #56]
	add	x8, x8, #4
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB2_39
LBB2_39:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #48]
	ldr	w8, [sp, #68]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB2_41
	b	LBB2_40
LBB2_40:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	w8, [sp, #72]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_45
LBB2_41:                                ;   in Loop: Header=BB2_35 Depth=4
	ldur	w8, [x29, #-52]
	cbz	w8, LBB2_43
	b	LBB2_42
LBB2_42:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	x8, [sp, #56]
	ldr	w0, [x8]
	bl	_nvm_multi_nominal_catalog_types
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB2_44
LBB2_43:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	x8, [sp, #56]
	ldr	w0, [x8]
	bl	_nvm_multi_nominal_catalog_methods
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB2_44
LBB2_44:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB2_45
LBB2_45:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB2_46
LBB2_46:                                ;   Parent Loop BB2_6 Depth=1
                                        ;     Parent Loop BB2_23 Depth=2
                                        ;       Parent Loop BB2_31 Depth=3
                                        ;         Parent Loop BB2_35 Depth=4
                                        ; =>        This Inner Loop Header: Depth=5
	ldr	w8, [sp, #40]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.hs	LBB2_51
	b	LBB2_47
LBB2_47:                                ;   in Loop: Header=BB2_46 Depth=5
	ldur	x8, [x29, #-64]
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp, #48]
	ldr	w10, [sp, #40]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.ne	LBB2_49
	b	LBB2_48
LBB2_48:
	mov	w8, #8                          ; =0x8
	stur	w8, [x29, #-4]
	b	LBB2_60
LBB2_49:                                ;   in Loop: Header=BB2_46 Depth=5
	b	LBB2_50
LBB2_50:                                ;   in Loop: Header=BB2_46 Depth=5
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB2_46
LBB2_51:                                ;   in Loop: Header=BB2_35 Depth=4
	b	LBB2_52
LBB2_52:                                ;   in Loop: Header=BB2_35 Depth=4
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB2_35
LBB2_53:                                ;   in Loop: Header=BB2_31 Depth=3
	b	LBB2_54
LBB2_54:                                ;   in Loop: Header=BB2_31 Depth=3
	ldr	w8, [sp, #72]
	add	w8, w8, #1
	str	w8, [sp, #72]
	b	LBB2_31
LBB2_55:                                ;   in Loop: Header=BB2_23 Depth=2
	b	LBB2_56
LBB2_56:                                ;   in Loop: Header=BB2_23 Depth=2
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB2_23
LBB2_57:                                ;   in Loop: Header=BB2_6 Depth=1
	b	LBB2_58
LBB2_58:                                ;   in Loop: Header=BB2_6 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB2_6
LBB2_59:
	stur	wzr, [x29, #-4]
	b	LBB2_60
LBB2_60:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_decode       ; -- Begin function nvm_multi_nominal_decode
	.p2align	2
_nvm_multi_nominal_decode:              ; @nvm_multi_nominal_decode
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3936
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #48
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [x8, #16]
	str	x1, [x8, #8]
	str	x2, [x8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB3_3
	b	LBB3_2
LBB3_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	subs	x8, x8, #16
	b.lo	LBB3_5
	b	LBB3_4
LBB3_4:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #4112                       ; =0x1010
	subs	x8, x8, x9
	b.ls	LBB3_6
	b	LBB3_5
LBB3_5:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_get16
	subs	w8, w0, #3
	b.eq	LBB3_8
	b	LBB3_7
LBB3_7:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_8:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x0, x8, #2
	bl	_get16
	cbnz	w0, LBB3_10
	b	LBB3_9
LBB3_9:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x0, x8, #12
	bl	_get32
	cbz	w0, LBB3_11
	b	LBB3_10
LBB3_10:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_11:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x0, x8, #4
	bl	_get32
	stur	w0, [x29, #-52]
	ldur	w8, [x29, #-52]
	cbz	w8, LBB3_13
	b	LBB3_12
LBB3_12:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #64
	b.ls	LBB3_14
	b	LBB3_13
LBB3_13:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_14:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x0, x8, #8
	bl	_get32
	subs	w8, w0, #64
	b.ne	LBB3_16
	b	LBB3_15
LBB3_15:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #6
	add	x9, x9, #16
	subs	x8, x8, x9
	b.eq	LBB3_17
	b	LBB3_16
LBB3_16:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_17:
	add	x0, sp, #56
	mov	x1, #3844                       ; =0xf04
	bl	_bzero
	ldur	w8, [x29, #-52]
	str	w8, [sp, #56]
	str	wzr, [sp, #52]
	b	LBB3_18
LBB3_18:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_24 Depth 2
                                        ;     Child Loop BB3_28 Depth 2
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB3_33
	b	LBB3_19
LBB3_19:                                ;   in Loop: Header=BB3_18 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	add	x8, x8, #16
	ldr	w10, [sp, #52]
	mov	w9, #64                         ; =0x40
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	add	x8, sp, #56
	add	x10, x8, #4
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x0, [sp, #40]
	bl	_get32
	ldr	w8, [sp, #52]
	subs	w8, w0, w8
	b.eq	LBB3_21
	b	LBB3_20
LBB3_20:
	mov	w8, #7                          ; =0x7
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_21:                                ;   in Loop: Header=BB3_18 Depth=1
	ldr	x8, [sp, #40]
	add	x0, x8, #4
	bl	_get16
	ldr	x8, [sp, #32]
	str	w0, [x8]
	ldr	x8, [sp, #40]
	add	x0, x8, #6
	bl	_get16
	cbz	w0, LBB3_23
	b	LBB3_22
LBB3_22:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_23:                                ;   in Loop: Header=BB3_18 Depth=1
	str	wzr, [sp, #28]
	b	LBB3_24
LBB3_24:                                ;   Parent Loop BB3_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #28]
	subs	w8, w8, #5
	b.hs	LBB3_27
	b	LBB3_25
LBB3_25:                                ;   in Loop: Header=BB3_24 Depth=2
	ldr	x8, [sp, #40]
	add	x8, x8, #8
	ldr	w10, [sp, #28]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_get32
	ldr	x8, [sp, #32]
	add	x8, x8, #4
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	str	w0, [x8, x9, lsl #2]
	b	LBB3_26
LBB3_26:                                ;   in Loop: Header=BB3_24 Depth=2
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB3_24
LBB3_27:                                ;   in Loop: Header=BB3_18 Depth=1
	str	wzr, [sp, #24]
	b	LBB3_28
LBB3_28:                                ;   Parent Loop BB3_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #24]
	subs	w8, w8, #9
	b.hs	LBB3_31
	b	LBB3_29
LBB3_29:                                ;   in Loop: Header=BB3_28 Depth=2
	ldr	x8, [sp, #40]
	add	x8, x8, #28
	ldr	w10, [sp, #24]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_get32
	ldr	x8, [sp, #32]
	add	x8, x8, #24
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	str	w0, [x8, x9, lsl #2]
	b	LBB3_30
LBB3_30:                                ;   in Loop: Header=BB3_28 Depth=2
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB3_28
LBB3_31:                                ;   in Loop: Header=BB3_18 Depth=1
	b	LBB3_32
LBB3_32:                                ;   in Loop: Header=BB3_18 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB3_18
LBB3_33:
	add	x0, sp, #56
	bl	_nvm_multi_nominal_check
	str	w0, [sp, #20]
	ldr	w8, [sp, #20]
	cbnz	w8, LBB3_35
	b	LBB3_34
LBB3_34:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8]
	add	x1, sp, #56
	mov	x2, #3844                       ; =0xf04
	bl	_memcpy
	b	LBB3_35
LBB3_35:
	ldr	w8, [sp, #20]
	stur	w8, [x29, #-20]
	b	LBB3_36
LBB3_36:
	ldur	w0, [x29, #-20]
	add	sp, sp, #3936
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get16
_get16:                                 ; @get16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	and	w0, w8, #0xffff
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function get32
_get32:                                 ; @get32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w0, w8, w9, lsl #24
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_multi_nominal_encode       ; -- Begin function nvm_multi_nominal_encode
	.p2align	2
_nvm_multi_nominal_encode:              ; @nvm_multi_nominal_encode
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #4224                       ; =0x1080
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #88]
	str	x1, [sp, #80]
	str	x2, [sp, #72]
	str	x3, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB6_2
	b	LBB6_1
LBB6_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #100]
	b	LBB6_21
LBB6_2:
	ldr	x0, [sp, #88]
	bl	_nvm_multi_nominal_check
	str	w0, [sp, #60]
	ldr	w8, [sp, #60]
	cbz	w8, LBB6_4
	b	LBB6_3
LBB6_3:
	ldr	w8, [sp, #60]
	str	w8, [sp, #100]
	b	LBB6_21
LBB6_4:
	ldr	x8, [sp, #88]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #6
	add	x8, x8, #16
	str	x8, [sp, #48]
	ldr	x8, [sp, #80]
	cbnz	x8, LBB6_6
	b	LBB6_5
LBB6_5:
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #64]
	str	x8, [x9]
	str	wzr, [sp, #100]
	b	LBB6_21
LBB6_6:
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #48]
	subs	x8, x8, x9
	b.hs	LBB6_8
	b	LBB6_7
LBB6_7:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #100]
	b	LBB6_21
LBB6_8:
	add	x0, sp, #104
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x1, #4112                       ; =0x1010
	bl	_bzero
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w9, #3                          ; =0x3
	strb	w9, [sp, #104]
	add	x0, x8, #4
	ldr	x8, [sp, #88]
	ldr	w1, [x8]
	bl	_put32
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, x8, #8
	mov	w1, #64                         ; =0x40
	bl	_put32
	str	wzr, [sp, #44]
	b	LBB6_9
LBB6_9:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_11 Depth 2
                                        ;     Child Loop BB6_15 Depth 2
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #88]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.hs	LBB6_20
	b	LBB6_10
LBB6_10:                                ;   in Loop: Header=BB6_9 Depth=1
	add	x8, sp, #104
	add	x8, x8, #16
	ldr	w10, [sp, #44]
	mov	w9, #64                         ; =0x40
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldr	x8, [sp, #88]
	add	x10, x8, #4
	ldr	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #60                         ; =0x3c
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x0, [sp, #32]
	ldr	w1, [sp, #44]
	bl	_put32
	ldr	x8, [sp, #24]
	ldr	w8, [x8]
	ldr	x9, [sp, #32]
	strb	w8, [x9, #4]
	str	wzr, [sp, #20]
	b	LBB6_11
LBB6_11:                                ;   Parent Loop BB6_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #20]
	subs	w8, w8, #5
	b.hs	LBB6_14
	b	LBB6_12
LBB6_12:                                ;   in Loop: Header=BB6_11 Depth=2
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldr	w10, [sp, #20]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #24]
	add	x8, x8, #4
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_put32
	b	LBB6_13
LBB6_13:                                ;   in Loop: Header=BB6_11 Depth=2
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB6_11
LBB6_14:                                ;   in Loop: Header=BB6_9 Depth=1
	str	wzr, [sp, #16]
	b	LBB6_15
LBB6_15:                                ;   Parent Loop BB6_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #16]
	subs	w8, w8, #9
	b.hs	LBB6_18
	b	LBB6_16
LBB6_16:                                ;   in Loop: Header=BB6_15 Depth=2
	ldr	x8, [sp, #32]
	add	x8, x8, #28
	ldr	w10, [sp, #16]
	mov	w9, #4                          ; =0x4
	mul	w9, w9, w10
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #24]
	add	x8, x8, #24
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	bl	_put32
	b	LBB6_17
LBB6_17:                                ;   in Loop: Header=BB6_15 Depth=2
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB6_15
LBB6_18:                                ;   in Loop: Header=BB6_9 Depth=1
	b	LBB6_19
LBB6_19:                                ;   in Loop: Header=BB6_9 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB6_9
LBB6_20:
	ldr	x0, [sp, #80]
	ldr	x2, [sp, #48]
	add	x1, sp, #104
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp, #48]
	ldr	x9, [sp, #64]
	str	x8, [x9]
	str	wzr, [sp, #100]
	b	LBB6_21
LBB6_21:
	ldr	w8, [sp, #100]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB6_23
	b	LBB6_22
LBB6_22:
	bl	___stack_chk_fail
LBB6_23:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #128
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function put32
_put32:                                 ; @put32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	str	wzr, [sp]
	b	LBB7_1
LBB7_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	subs	w8, w8, #4
	b.hs	LBB7_4
	b	LBB7_2
LBB7_2:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	w8, [sp, #4]
	ldr	w10, [sp]
	mov	w9, #8                          ; =0x8
	mul	w9, w9, w10
	lsr	w8, w8, w9
	ldr	x9, [sp, #8]
	ldr	w10, [sp]
                                        ; kill: def $x10 killed $w10
	strb	w8, [x9, x10]
	b	LBB7_3
LBB7_3:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB7_1
LBB7_4:
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
