	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_cyclic_create ; -- Begin function nvm_socket_runtime_cyclic_create
	.p2align	2
_nvm_socket_runtime_cyclic_create:      ; @nvm_socket_runtime_cyclic_create
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB0_24
; %bb.1:
	cbz	x4, LBB0_24
; %bb.2:
	ldr	w9, [x3]
	cmp	w9, #1
	b.ne	LBB0_24
; %bb.3:
	cmp	w2, #1
	b.hi	LBB0_24
; %bb.4:
	ldr	x9, [x3, #8]
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	cmp	x9, x10
	b.hi	LBB0_24
; %bb.5:
	sub	sp, sp, #256
	stp	x28, x27, [sp, #160]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #176]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #192]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #208]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #224]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #240]            ; 16-byte Folded Spill
	add	x29, sp, #240
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x2
	mov	x20, x3
	mov	x25, x4
	stur	xzr, [x29, #-96]
	sub	x2, x29, #96
	mov	x0, x8
	bl	_nvm_socket_cyclic_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB0_23
; %bb.6:
	cbz	w0, LBB0_9
; %bb.7:
	cmp	w0, #1
	b.eq	LBB0_23
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB0_23
LBB0_9:
	ldur	x0, [x29, #-96]
	add	x1, sp, #48
	bl	_nvm_socket_cyclic_hosted_startup
	cbz	w0, LBB0_22
; %bb.10:
	add	x0, sp, #40
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB0_22
; %bb.11:
	ldp	x24, x8, [sp, #72]
	cmp	w22, #0
	csel	x21, x24, x8, eq
	mov	x9, #-4294967296                ; =0xffffffff00000000
	mov	x10, #-4294967295               ; =0xffffffff00000001
	add	x9, x21, x9
	cmp	x9, x10
	b.lo	LBB0_21
; %bb.12:
	ldrh	w9, [sp, #88]
	cbz	w9, LBB0_21
; %bb.13:
	ldr	w23, [sp, #92]
	cbz	w23, LBB0_21
; %bb.14:
	ldr	w27, [sp, #96]
	cbz	w27, LBB0_21
; %bb.15:
	mov	w11, #24992                     ; =0x61a0
	movk	w11, #1023, lsl #16
	ldr	x10, [sp, #128]
	subs	x11, x11, x10
	b.lo	LBB0_21
; %bb.16:
	mov	w12, #168                       ; =0xa8
	mul	x12, x21, x12
	cmp	x12, x11
	b.hi	LBB0_21
; %bb.17:
	lsl	x11, x23, #6
	sub	x11, x11, x23, lsl #3
	mov	w13, #24992                     ; =0x61a0
	movk	w13, #1023, lsl #16
	add	x10, x10, x12
	sub	x12, x13, x10
	cmp	x11, x12
	b.hi	LBB0_21
; %bb.18:
	mov	w12, #40544                     ; =0x9e60
	add	x10, x10, x12
	add	x10, x11, x10
	lsl	x11, x27, #3
	mov	w12, #67108864                  ; =0x4000000
	sub	x12, x12, x10
	cmp	x11, x12
	b.hi	LBB0_21
; %bb.19:
	add	x12, x9, x9, lsl #2
	lsl	x12, x12, #3
	mov	w13, #67108864                  ; =0x4000000
	add	x10, x10, x11
	sub	x11, x13, x10
	cmp	x12, x11
	b.hi	LBB0_21
; %bb.20:
	ldr	x28, [sp, #40]
	mov	w11, #67108864                  ; =0x4000000
	add	x26, x10, x12
	sub	x10, x11, x26
	cmp	x28, x10
	b.ls	LBB0_25
LBB0_21:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_cyclic_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB0_23
LBB0_22:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_cyclic_hosted_free
	mov	w0, #1                          ; =0x1
LBB0_23:
	ldp	x29, x30, [sp, #240]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #224]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #208]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #192]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #176]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #256
LBB0_24:
	ret
LBB0_25:
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #33376                      ; =0x8260
	bl	_calloc
	cbz	x0, LBB0_35
; %bb.26:
	mov	x19, x0
	add	x10, x0, #8, lsl #12            ; =32768
	mov	w11, #1                         ; =0x1
	str	w11, [x0, #24]
	add	x9, x28, x26
	ldur	x8, [x29, #-96]
	str	x8, [x0, #8]
	str	w22, [x10, #580]
	str	x11, [x10, #600]
	mov	x28, x10
	ldr	x8, [x20, #8]
	str	x8, [x0, #40]
	ldr	x10, [sp, #112]
	ldur	q0, [sp, #52]
	str	q0, [x0, #64]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	stp	x24, x8, [x0, #80]
	ldr	x24, [sp, #8]                   ; 8-byte Folded Reload
	strh	w24, [x0, #96]
	stp	w23, w27, [x0, #100]
	stp	x10, x9, [x0, #112]
	stp	w21, w23, [x0, #128]
	str	w27, [x0, #136]
	strh	w24, [x0, #140]
	mov	w0, #1                          ; =0x1
	mov	w1, #7168                       ; =0x1c00
	bl	_calloc
	mov	x20, x0
	str	x0, [x19, #32]
	mov	x0, x21
	mov	w1, #168                        ; =0xa8
	bl	_calloc
	mov	x21, x0
	str	x0, [x28, #296]
	mov	x0, x23
	mov	w1, #56                         ; =0x38
	bl	_calloc
	mov	x23, x0
	str	x0, [x28, #304]
	mov	x0, x27
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x22, x0
	str	x0, [x28, #312]
	mov	x0, x24
	mov	w1, #40                         ; =0x28
	bl	_calloc
	str	x0, [x28, #320]
	mov	w24, #4                         ; =0x4
	cbz	x20, LBB0_37
; %bb.27:
	cbz	x21, LBB0_37
; %bb.28:
	cbz	x23, LBB0_37
; %bb.29:
	cbz	x22, LBB0_37
; %bb.30:
	cbz	x0, LBB0_37
; %bb.31:
	mov	x26, x28
	mov	x24, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w27, #10                        ; =0xa
	mov	w28, #8                         ; =0x8
LBB0_32:                                ; =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-96]
	add	x2, sp, #16
	mov	x1, x23
	bl	_nvm_socket_cyclic_hosted_type
	cbz	w0, LBB0_36
; %bb.33:                               ;   in Loop: Header=BB0_32 Depth=1
	add	x8, x19, x24
	ldrb	w9, [sp, #28]
	cmp	w9, #0
	csel	w9, w28, w27, eq
	ldr	w10, [sp, #32]
	strb	w9, [x8, #144]
	strb	wzr, [x8, #145]
	strh	wzr, [x8, #146]
	ldr	d0, [sp, #16]
	stur	d0, [x8, #148]
	str	w10, [x8, #156]
	add	x23, x23, #1
	add	x24, x24, #16
	cmp	x23, #9
	b.ne	LBB0_32
; %bb.34:
	mov	w0, #0                          ; =0x0
	add	x8, x26, #348
	movi.2d	v0, #0xffffffffffffffff
	str	d0, [x8]
	ldp	w9, w8, [sp, #52]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	str	w8, [x26, #592]
	str	x19, [x25]
	b	LBB0_23
LBB0_35:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_cyclic_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB0_23
LBB0_36:
	ldr	x0, [x26, #320]
	ldr	x23, [x26, #304]
	mov	w24, #1                         ; =0x1
LBB0_37:
	bl	_free
	mov	x0, x22
	bl	_free
	mov	x0, x23
	bl	_free
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_free
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_cyclic_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x24
	b	LBB0_23
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_indirect_create ; -- Begin function nvm_socket_runtime_indirect_create
	.p2align	2
_nvm_socket_runtime_indirect_create:    ; @nvm_socket_runtime_indirect_create
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cbz	x3, LBB1_24
; %bb.1:
	cbz	x4, LBB1_24
; %bb.2:
	ldr	w9, [x3]
	cmp	w9, #1
	b.ne	LBB1_24
; %bb.3:
	cmp	w2, #1
	b.hi	LBB1_24
; %bb.4:
	ldr	x9, [x3, #8]
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	cmp	x9, x10
	b.hi	LBB1_24
; %bb.5:
	sub	sp, sp, #256
	stp	x28, x27, [sp, #160]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #176]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #192]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #208]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #224]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #240]            ; 16-byte Folded Spill
	add	x29, sp, #240
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x2
	mov	x20, x3
	mov	x25, x4
	stur	xzr, [x29, #-96]
	sub	x2, x29, #96
	mov	x0, x8
	bl	_nvm_socket_indirect_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB1_23
; %bb.6:
	cbz	w0, LBB1_9
; %bb.7:
	cmp	w0, #1
	b.eq	LBB1_23
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB1_23
LBB1_9:
	ldur	x0, [x29, #-96]
	add	x1, sp, #48
	bl	_nvm_socket_indirect_hosted_startup
	cbz	w0, LBB1_22
; %bb.10:
	add	x0, sp, #40
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB1_22
; %bb.11:
	ldp	x24, x8, [sp, #72]
	cmp	w22, #0
	csel	x21, x24, x8, eq
	mov	x9, #-4294967296                ; =0xffffffff00000000
	mov	x10, #-4294967295               ; =0xffffffff00000001
	add	x9, x21, x9
	cmp	x9, x10
	b.lo	LBB1_21
; %bb.12:
	ldrh	w9, [sp, #88]
	cbz	w9, LBB1_21
; %bb.13:
	ldr	w23, [sp, #92]
	cbz	w23, LBB1_21
; %bb.14:
	ldr	w27, [sp, #96]
	cbz	w27, LBB1_21
; %bb.15:
	mov	w11, #24992                     ; =0x61a0
	movk	w11, #1023, lsl #16
	ldr	x10, [sp, #128]
	subs	x11, x11, x10
	b.lo	LBB1_21
; %bb.16:
	mov	w12, #168                       ; =0xa8
	mul	x12, x21, x12
	cmp	x12, x11
	b.hi	LBB1_21
; %bb.17:
	lsl	x11, x23, #6
	sub	x11, x11, x23, lsl #3
	mov	w13, #24992                     ; =0x61a0
	movk	w13, #1023, lsl #16
	add	x10, x10, x12
	sub	x12, x13, x10
	cmp	x11, x12
	b.hi	LBB1_21
; %bb.18:
	mov	w12, #40544                     ; =0x9e60
	add	x10, x10, x12
	add	x10, x11, x10
	lsl	x11, x27, #3
	mov	w12, #67108864                  ; =0x4000000
	sub	x12, x12, x10
	cmp	x11, x12
	b.hi	LBB1_21
; %bb.19:
	add	x12, x9, x9, lsl #2
	lsl	x12, x12, #3
	mov	w13, #67108864                  ; =0x4000000
	add	x10, x10, x11
	sub	x11, x13, x10
	cmp	x12, x11
	b.hi	LBB1_21
; %bb.20:
	ldr	x26, [sp, #40]
	mov	w11, #67108864                  ; =0x4000000
	add	x28, x10, x12
	sub	x10, x11, x28
	cmp	x26, x10
	b.ls	LBB1_25
LBB1_21:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_indirect_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB1_23
LBB1_22:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_indirect_hosted_free
	mov	w0, #1                          ; =0x1
LBB1_23:
	ldp	x29, x30, [sp, #240]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #224]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #208]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #192]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #176]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #256
LBB1_24:
	ret
LBB1_25:
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
	mov	w0, #1                          ; =0x1
	mov	w1, #33376                      ; =0x8260
	bl	_calloc
	cbz	x0, LBB1_35
; %bb.26:
	mov	x19, x0
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #24]
	add	x10, x0, #8, lsl #12            ; =32768
	add	x9, x26, x28
	ldur	x8, [x29, #-96]
	str	x8, [x0, #16]
	str	w22, [x10, #580]
	mov	w8, #1                          ; =0x1
	str	x8, [x10, #600]
	mov	x28, x10
	ldr	x8, [x20, #8]
	str	x8, [x0, #40]
	ldr	x10, [sp, #112]
	ldur	q0, [sp, #52]
	str	q0, [x0, #64]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	stp	x24, x8, [x0, #80]
	ldr	x24, [sp, #8]                   ; 8-byte Folded Reload
	strh	w24, [x0, #96]
	stp	w23, w27, [x0, #100]
	stp	x10, x9, [x0, #112]
	stp	w21, w23, [x0, #128]
	str	w27, [x0, #136]
	strh	w24, [x0, #140]
	mov	w0, #1                          ; =0x1
	mov	w1, #7168                       ; =0x1c00
	bl	_calloc
	mov	x20, x0
	str	x0, [x19, #32]
	mov	x0, x21
	mov	w1, #168                        ; =0xa8
	bl	_calloc
	mov	x21, x0
	str	x0, [x28, #296]
	mov	x0, x23
	mov	w1, #56                         ; =0x38
	bl	_calloc
	mov	x23, x0
	str	x0, [x28, #304]
	mov	x0, x27
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x22, x0
	str	x0, [x28, #312]
	mov	x0, x24
	mov	w1, #40                         ; =0x28
	bl	_calloc
	str	x0, [x28, #320]
	mov	w24, #4                         ; =0x4
	cbz	x20, LBB1_37
; %bb.27:
	cbz	x21, LBB1_37
; %bb.28:
	cbz	x23, LBB1_37
; %bb.29:
	cbz	x22, LBB1_37
; %bb.30:
	cbz	x0, LBB1_37
; %bb.31:
	mov	x26, x28
	mov	x24, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w27, #10                        ; =0xa
	mov	w28, #8                         ; =0x8
LBB1_32:                                ; =>This Inner Loop Header: Depth=1
	ldur	x0, [x29, #-96]
	add	x2, sp, #16
	mov	x1, x23
	bl	_nvm_socket_indirect_hosted_type
	cbz	w0, LBB1_36
; %bb.33:                               ;   in Loop: Header=BB1_32 Depth=1
	add	x8, x19, x24
	ldrb	w9, [sp, #28]
	cmp	w9, #0
	csel	w9, w28, w27, eq
	ldr	w10, [sp, #32]
	strb	w9, [x8, #144]
	strb	wzr, [x8, #145]
	strh	wzr, [x8, #146]
	ldr	d0, [sp, #16]
	stur	d0, [x8, #148]
	str	w10, [x8, #156]
	add	x23, x23, #1
	add	x24, x24, #16
	cmp	x23, #9
	b.ne	LBB1_32
; %bb.34:
	mov	w0, #0                          ; =0x0
	add	x8, x26, #348
	movi.2d	v0, #0xffffffffffffffff
	str	d0, [x8]
	ldp	w9, w8, [sp, #52]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	str	w8, [x26, #592]
	str	x19, [x25]
	b	LBB1_23
LBB1_35:
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_indirect_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB1_23
LBB1_36:
	ldr	x0, [x26, #320]
	ldr	x23, [x26, #304]
	mov	w24, #1                         ; =0x1
LBB1_37:
	bl	_free
	mov	x0, x22
	bl	_free
	mov	x0, x23
	bl	_free
	mov	x0, x21
	bl	_free
	mov	x0, x20
	bl	_free
	ldur	x0, [x29, #-96]
	bl	_nvm_socket_indirect_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x24
	b	LBB1_23
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_create      ; -- Begin function nvm_socket_runtime_create
	.p2align	2
_nvm_socket_runtime_create:             ; @nvm_socket_runtime_create
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #1                          ; =0x1
	cmp	w2, #1
	b.hi	LBB2_20
; %bb.1:
	cbz	x3, LBB2_20
; %bb.2:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x25, x2
	mov	x24, x3
	str	xzr, [sp, #88]
	add	x2, sp, #88
	mov	x0, x8
	bl	_nvm_socket_hosted_prepare
	sub	w8, w0, #3
	cmp	w8, #2
	b.lo	LBB2_19
; %bb.3:
	cbz	w0, LBB2_5
; %bb.4:
	mov	w8, #2                          ; =0x2
	cmp	w0, #1
	csel	w0, w0, w8, eq
	b	LBB2_19
LBB2_5:
	str	xzr, [sp, #24]
	ldr	x0, [sp, #88]
	add	x1, sp, #32
	bl	_nvm_socket_hosted_startup
	cbz	w0, LBB2_18
; %bb.6:
	add	x0, sp, #24
	bl	_nl_socket_values_storage_bound
	tbz	w0, #0, LBB2_18
; %bb.7:
	add	x8, sp, #32
	add	x9, x8, #16
	add	x8, x8, #24
	cmp	w25, #0
	csel	x8, x9, x8, eq
	ldr	x21, [x8]
	mov	x8, #-4294967296                ; =0xffffffff00000000
	mov	x9, #-4294967295                ; =0xffffffff00000001
	add	x8, x21, x8
	cmp	x8, x9
	b.lo	LBB2_17
; %bb.8:
	ldrh	w20, [sp, #64]
	cbz	w20, LBB2_17
; %bb.9:
	ldr	w23, [sp, #68]
	cbz	w23, LBB2_17
; %bb.10:
	ldr	w22, [sp, #72]
	cbz	w22, LBB2_17
; %bb.11:
	mov	w9, #32160                      ; =0x7da0
	movk	w9, #1023, lsl #16
	ldr	x8, [sp, #80]
	subs	x9, x9, x8
	b.lo	LBB2_17
; %bb.12:
	mov	w10, #168                       ; =0xa8
	mul	x10, x21, x10
	cmp	x10, x9
	b.hi	LBB2_17
; %bb.13:
	lsl	x9, x23, #6
	sub	x9, x9, x23, lsl #3
	mov	w11, #32160                     ; =0x7da0
	movk	w11, #1023, lsl #16
	add	x8, x8, x10
	sub	x10, x11, x8
	cmp	x9, x10
	b.hi	LBB2_17
; %bb.14:
	mov	w10, #33376                     ; =0x8260
	add	x8, x8, x10
	add	x8, x9, x8
	lsl	x9, x22, #3
	mov	w10, #67108864                  ; =0x4000000
	sub	x10, x10, x8
	cmp	x9, x10
	b.hi	LBB2_17
; %bb.15:
	add	x10, x20, x20, lsl #2
	lsl	x10, x10, #3
	mov	w11, #67108864                  ; =0x4000000
	add	x8, x8, x9
	sub	x9, x11, x8
	cmp	x10, x9
	b.hi	LBB2_17
; %bb.16:
	ldr	x26, [sp, #24]
	mov	w9, #67108864                   ; =0x4000000
	add	x27, x8, x10
	sub	x8, x9, x27
	cmp	x26, x8
	b.ls	LBB2_21
LBB2_17:
	ldr	x0, [sp, #88]
	bl	_nvm_socket_hosted_free
	mov	w0, #3                          ; =0x3
	b	LBB2_19
LBB2_18:
	ldr	x0, [sp, #88]
	bl	_nvm_socket_hosted_free
	mov	w0, #1                          ; =0x1
LBB2_19:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
LBB2_20:
	ret
LBB2_21:
	mov	w0, #1                          ; =0x1
	mov	w1, #33376                      ; =0x8260
	bl	_calloc
	cbz	x0, LBB2_30
; %bb.22:
	mov	x19, x0
	add	x8, x26, x27
	ldr	x9, [sp, #88]
	add	x26, x0, #8, lsl #12            ; =32768
	str	x9, [x0]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x0, #64]
	ldr	q0, [sp, #64]
	str	q0, [x0, #96]
	mov	w9, #1                          ; =0x1
	str	x9, [x26, #600]
	ldr	x9, [sp, #80]
	str	w25, [x26, #580]
	stp	x9, x8, [x0, #112]
	stp	w21, w23, [x0, #128]
	str	w22, [x0, #136]
	strh	w20, [x0, #140]
	mov	x0, x21
	mov	w1, #168                        ; =0xa8
	bl	_calloc
	mov	x21, x0
	str	x0, [x26, #296]
	mov	x0, x23
	mov	w1, #56                         ; =0x38
	bl	_calloc
	mov	x23, x0
	str	x0, [x26, #304]
	mov	x0, x22
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x22, x0
	str	x0, [x26, #312]
	mov	x0, x20
	mov	w1, #40                         ; =0x28
	bl	_calloc
	str	x0, [x26, #320]
	mov	w20, #4                         ; =0x4
	cbz	x21, LBB2_32
; %bb.23:
	cbz	x23, LBB2_32
; %bb.24:
	cbz	x22, LBB2_32
; %bb.25:
	cbz	x0, LBB2_32
; %bb.26:
	mov	x23, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w25, #10                        ; =0xa
	mov	w27, #8                         ; =0x8
LBB2_27:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [sp, #88]
	mov	x2, sp
	mov	x1, x20
	bl	_nvm_socket_hosted_type
	cbz	w0, LBB2_31
; %bb.28:                               ;   in Loop: Header=BB2_27 Depth=1
	add	x8, x19, x23
	ldrb	w9, [sp, #12]
	cmp	w9, #0
	csel	w9, w27, w25, eq
	ldr	w10, [sp, #16]
	strb	w9, [x8, #144]
	strb	wzr, [x8, #145]
	strh	wzr, [x8, #146]
	ldr	d0, [sp]
	stur	d0, [x8, #148]
	str	w10, [x8, #156]
	add	x20, x20, #1
	add	x23, x23, #16
	cmp	x20, #9
	b.ne	LBB2_27
; %bb.29:
	mov	w0, #0                          ; =0x0
	add	x8, x26, #348
	movi.2d	v0, #0xffffffffffffffff
	str	d0, [x8]
	ldp	w9, w8, [sp, #32]
	cmn	w8, #1
	csel	w8, w9, w8, eq
	str	w8, [x26, #592]
	str	x19, [x24]
	b	LBB2_19
LBB2_30:
	ldr	x0, [sp, #88]
	bl	_nvm_socket_hosted_free
	mov	w0, #4                          ; =0x4
	b	LBB2_19
LBB2_31:
	ldr	x0, [x26, #320]
	ldr	x23, [x26, #304]
	mov	w20, #1                         ; =0x1
LBB2_32:
	bl	_free
	mov	x0, x22
	bl	_free
	mov	x0, x23
	bl	_free
	mov	x0, x21
	bl	_free
	ldr	x0, [sp, #88]
	bl	_nvm_socket_hosted_free
	mov	x0, x19
	bl	_free
	mov	x0, x20
	b	LBB2_19
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_storage     ; -- Begin function nvm_socket_runtime_storage
	.p2align	2
_nvm_socket_runtime_storage:            ; @nvm_socket_runtime_storage
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	x0, #0
	ccmp	x1, #0, #4, ne
	cset	w0, ne
	b.eq	LBB3_2
; %bb.1:
	ldur	q0, [x8, #120]
	ldr	x8, [x8, #136]
	str	x8, [x1, #16]
	str	q0, [x1]
LBB3_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_plan        ; -- Begin function nvm_socket_runtime_plan
	.p2align	2
_nvm_socket_runtime_plan:               ; @nvm_socket_runtime_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_2
; %bb.1:
	ldr	x0, [x0]
LBB4_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_begin       ; -- Begin function nvm_socket_runtime_begin
	.p2align	2
_nvm_socket_runtime_begin:              ; @nvm_socket_runtime_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_3
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB5_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB5_25
LBB5_3:
	mov	w0, #1                          ; =0x1
	ret
LBB5_4:
	ldr	w8, [x19, #576]
	cbz	w8, LBB5_6
; %bb.5:
	mov	w9, #11                         ; =0xb
	mov	w10, #5                         ; =0x5
	cmp	w8, #1
	csel	w0, w9, w10, eq
	b	LBB5_25
LBB5_6:
	mov	w20, #1                         ; =0x1
	strb	w20, [x19, #586]
	mov	w8, #33096                      ; =0x8148
	add	x0, x0, x8
	bl	_nl_socket_values_create
	strb	wzr, [x19, #586]
	str	w20, [x19, #576]
	cmp	w0, #2
	b.le	LBB5_11
; %bb.7:
	cmp	w0, #4
	b.gt	LBB5_15
; %bb.8:
	cmp	w0, #3
	b.eq	LBB5_20
; %bb.9:
	cmp	w0, #4
	b.ne	LBB5_19
; %bb.10:
	mov	w8, #8                          ; =0x8
	b	LBB5_22
LBB5_11:
	cbz	w0, LBB5_18
; %bb.12:
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB5_22
; %bb.13:
	cmp	w0, #2
	b.ne	LBB5_19
; %bb.14:
	mov	w8, #7                          ; =0x7
	b	LBB5_22
LBB5_15:
	cmp	w0, #5
	b.eq	LBB5_21
; %bb.16:
	cmp	w0, #6
	b.ne	LBB5_19
; %bb.17:
	mov	w8, #4                          ; =0x4
	b	LBB5_22
LBB5_18:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #587]
	strb	w8, [x19, #340]
	b	LBB5_25
LBB5_19:
	mov	w8, #5                          ; =0x5
	b	LBB5_22
LBB5_20:
	mov	w8, #6                          ; =0x6
	b	LBB5_22
LBB5_21:
	mov	w8, #3                          ; =0x3
LBB5_22:
	ldr	w9, [x19, #336]
	cbnz	w9, LBB5_24
; %bb.23:
	str	w8, [x19, #336]
	str	w0, [x19, #344]
LBB5_24:
	mov	x0, x8
LBB5_25:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_core
_fr_core:                               ; @fr_core
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	cmp	w1, #6
	b.hi	LBB6_3
; %bb.1:
	sub	w9, w1, #1
Lloh0:
	adrp	x10, l_switch.table.fr_core@PAGE
Lloh1:
	add	x10, x10, l_switch.table.fr_core@PAGEOFF
	ldr	w0, [x10, w9, uxtw #2]
	cbnz	x8, LBB6_4
LBB6_2:
	ret
LBB6_3:
	mov	w0, #5                          ; =0x5
	cbz	x8, LBB6_2
LBB6_4:
	add	x8, x8, #8, lsl #12             ; =32768
	ldr	w9, [x8, #576]
	cmp	w9, #2
	b.eq	LBB6_2
; %bb.5:
	ldr	w9, [x8, #336]
	cbnz	w9, LBB6_2
; %bb.6:
	str	w0, [x8, #336]
	str	w1, [x8, #344]
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_site        ; -- Begin function nvm_socket_runtime_site
	.p2align	2
_nvm_socket_runtime_site:               ; @nvm_socket_runtime_site
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #688
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB7_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB7_9
LBB7_3:
	mov	w0, #1                          ; =0x1
	ret
LBB7_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB7_8
; %bb.5:
	ldr	w8, [x19, #336]
	cbnz	w8, LBB7_9
; %bb.6:
	ldrb	w8, [x19, #588]
	cmp	w8, #1
	b.ne	LBB7_10
; %bb.7:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x19, #344]
	b	LBB7_9
LBB7_8:
	mov	w8, #5                          ; =0x5
LBB7_9:
	add	sp, sp, #688
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB7_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB7_16
; %bb.11:
	ldrh	w8, [x19, #584]
	cbz	x8, LBB7_15
; %bb.12:
	ldr	x9, [x19, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldr	w9, [x8]
	cmp	w9, w1
	b.ne	LBB7_15
; %bb.13:
	ldr	w9, [x8, #4]
	cmp	w9, w2
	b.ne	LBB7_15
; %bb.14:
	ldrb	w3, [x8, #34]
	b	LBB7_17
LBB7_15:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #336]
	mov	w9, #8                          ; =0x8
	mov	w10, #33112                     ; =0x8158
	b	LBB7_21
LBB7_16:
	mov	w3, #0                          ; =0x0
LBB7_17:
	add	x4, sp, #88
	add	x5, sp, #8
	mov	x20, x0
	mov	x21, x1
	bl	_fr_instruction
	cbz	w0, LBB7_22
; %bb.18:
	ldrb	w8, [sp, #8]
	tbz	w8, #0, LBB7_22
; %bb.19:
	mov	w8, #0                          ; =0x0
	str	w21, [x19, #348]
	ldr	w9, [sp, #88]
	mov	w10, #33120                     ; =0x8160
LBB7_20:
	mov	x0, x20
LBB7_21:
	str	w9, [x0, x10]
	b	LBB7_9
LBB7_22:
	ldr	w8, [x19, #576]
	cmp	w8, #2
	b.ne	LBB7_24
; %bb.23:
	mov	w8, #1                          ; =0x1
	b	LBB7_9
LBB7_24:
	ldr	w9, [x19, #336]
	mov	w8, #1                          ; =0x1
	cbnz	w9, LBB7_9
; %bb.25:
	str	w8, [x19, #336]
	mov	w10, #33112                     ; =0x8158
	mov	w9, #1                          ; =0x1
	b	LBB7_20
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_instruction
_fr_instruction:                        ; @fr_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x5
	mov	x23, x0
	ldr	w8, [x0, #24]
	cbz	w8, LBB8_3
; %bb.1:
	mov	x20, x3
	cmp	w8, #2
	b.ne	LBB8_4
; %bb.2:
	ldr	x0, [x23, #16]
	mov	x22, x1
	mov	x21, x2
	mov	x3, x4
	bl	_nvm_socket_indirect_hosted_instruction
	tbnz	w0, #0, LBB8_5
	b	LBB8_7
LBB8_3:
	ldr	x0, [x23]
	mov	x3, x4
	mov	x4, x19
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	b	_nvm_socket_hosted_instruction
LBB8_4:
	ldr	x0, [x23, #8]
	mov	x22, x1
	mov	x21, x2
	mov	x3, x4
	bl	_nvm_socket_cyclic_hosted_instruction
	cbz	w0, LBB8_10
LBB8_5:
	ldr	w8, [x23, #24]
	cmp	w8, #2
	b.ne	LBB8_8
; %bb.6:
	ldr	x0, [x23, #16]
	add	x4, sp, #8
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_nvm_socket_indirect_hosted_variant
	tbnz	w0, #0, LBB8_9
LBB8_7:
	mov	w0, #0                          ; =0x0
	b	LBB8_10
LBB8_8:
	ldr	x0, [x23, #8]
	add	x4, sp, #8
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_nvm_socket_cyclic_hosted_variant
	cbz	w0, LBB8_10
LBB8_9:
	ldur	q0, [sp, #44]
	ldur	q1, [sp, #60]
	ldur	q2, [sp, #76]
	stp	q1, q2, [x19, #32]
	ldur	q1, [sp, #92]
	str	q1, [x19, #64]
	ldur	q1, [sp, #28]
	stp	q1, q0, [x19]
	mov	w0, #1                          ; =0x1
LBB8_10:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_fail        ; -- Begin function nvm_socket_runtime_fail
	.p2align	2
_nvm_socket_runtime_fail:               ; @nvm_socket_runtime_fail
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_3
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbz	w9, #0, LBB9_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB9_3:
	mov	w0, #1                          ; =0x1
	ret
LBB9_4:
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB9_7
; %bb.5:
	ldr	w0, [x8, #336]
	cbz	w0, LBB9_8
; %bb.6:
	ret
LBB9_7:
	mov	w0, #5                          ; =0x5
	ret
LBB9_8:
	ldrb	w9, [x8, #588]
	cmp	w9, #1
	b.ne	LBB9_10
; %bb.9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #344]
	ret
LBB9_10:
	sub	w9, w1, #11
	cmn	w9, #11
	b.hi	LBB9_12
; %bb.11:
	mov	w0, #1                          ; =0x1
	str	w0, [x8, #336]
	str	w0, [x8, #344]
	ret
LBB9_12:
	str	w1, [x8, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #344]
	mov	x0, x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_current_root ; -- Begin function nvm_socket_runtime_current_root
	.p2align	2
_nvm_socket_runtime_current_root:       ; @nvm_socket_runtime_current_root
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB10_7
; %bb.1:
	cbz	x1, LBB10_7
; %bb.2:
	add	x8, x8, #8, lsl #12             ; =32768
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB10_5
; %bb.3:
	ldrb	w9, [x8, #588]
	tbnz	w9, #0, LBB10_5
; %bb.4:
	ldrb	w9, [x8, #586]
	tbz	w9, #0, LBB10_6
LBB10_5:
	mov	w0, #0                          ; =0x0
	ret
LBB10_6:
	ldr	w8, [x8, #592]
	str	w8, [x1]
	mov	w0, #1                          ; =0x1
LBB10_7:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_view        ; -- Begin function nvm_socket_runtime_view
	.p2align	2
_nvm_socket_runtime_view:               ; @nvm_socket_runtime_view
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	x8, LBB11_5
; %bb.1:
	cbz	x2, LBB11_5
; %bb.2:
	ldr	w9, [x8, #128]
	cmp	w1, w9
	b.hs	LBB11_4
; %bb.3:
	add	x8, x8, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbz	w9, #0, LBB11_6
LBB11_4:
	mov	w0, #0                          ; =0x0
LBB11_5:
	ret
LBB11_6:
	ldr	x8, [x8, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w1, w9, x8
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x2, #32]
	stp	q0, q1, [x2]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x2, #112]
	stp	q1, q2, [x2, #80]
	str	q0, [x2, #64]
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_scalar      ; -- Begin function nvm_socket_runtime_scalar
	.p2align	2
_nvm_socket_runtime_scalar:             ; @nvm_socket_runtime_scalar
	.cfi_startproc
; %bb.0:
                                        ; kill: def $w2 killed $w2 def $x2
	cbz	x0, LBB12_3
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbz	w9, #0, LBB12_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB12_3:
	mov	w0, #1                          ; =0x1
	ret
LBB12_4:
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB12_7
; %bb.5:
	mov	x9, x0
	ldr	w0, [x8, #336]
	cbz	w0, LBB12_8
; %bb.6:
	ret
LBB12_7:
	mov	w0, #5                          ; =0x5
	ret
LBB12_8:
	ldrb	w10, [x8, #588]
	tbz	w10, #0, LBB12_10
LBB12_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #344]
	ret
LBB12_10:
	ldr	w10, [x9, #24]
	cbz	w10, LBB12_12
; %bb.11:
	ldrb	w10, [x9, #57]
	tbz	w10, #0, LBB12_21
LBB12_12:
	ldr	w9, [x9, #128]
	cmp	w1, w9
	b.hs	LBB12_20
; %bb.13:
	ldr	x9, [x8, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	tbnz	w10, #0, LBB12_20
; %bb.14:
	cmp	w2, #4
	b.hi	LBB12_20
; %bb.15:
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w2
	mov	w11, #19                        ; =0x13
	tst	w10, w11
	b.eq	LBB12_20
; %bb.16:
	cmp	w2, #4
	b.ne	LBB12_18
; %bb.17:
	cmp	x3, #1
	b.hi	LBB12_20
LBB12_18:
	cbnz	w2, LBB12_24
; %bb.19:
	cbz	x3, LBB12_24
LBB12_20:
	mov	w0, #6                          ; =0x6
	str	w0, [x8, #336]
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #344]
	ret
LBB12_21:
	ldrh	w10, [x8, #584]
	cbz	x10, LBB12_9
; %bb.22:
	ldr	x11, [x8, #320]
	sub	w10, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldrb	w11, [x10, #32]
	tbnz	w11, #0, LBB12_9
; %bb.23:
	ldrb	w10, [x10, #33]
	tbz	w10, #0, LBB12_9
	b	LBB12_12
LBB12_24:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	orr	x8, x2, #0xffffffff00000000
	stur	x8, [x9, #4]
	cmp	w2, #0
	mov	w8, #-1                         ; =0xffffffff
	stur	x8, [x9, #12]
	cset	w8, ne
	str	wzr, [x9, #20]
	strb	w8, [x9, #24]
	stur	wzr, [x9, #25]
	str	wzr, [x9, #28]
	str	x3, [x9, #32]
	movi.2d	v0, #0000000000000000
	stur	q0, [x9, #40]
	stur	q0, [x9, #56]
	stur	q0, [x9, #72]
	stur	q0, [x9, #88]
	stur	q0, [x9, #104]
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_socket_runtime_string
lCPI13_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_string
	.p2align	2
_nvm_socket_runtime_string:             ; @nvm_socket_runtime_string
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB13_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x22, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x22, #586]
	tbz	w8, #0, LBB13_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB13_9
LBB13_3:
	mov	w0, #1                          ; =0x1
	ret
LBB13_4:
	ldr	w8, [x22, #576]
	cmp	w8, #1
	b.ne	LBB13_8
; %bb.5:
	ldr	w8, [x22, #336]
	cbnz	w8, LBB13_9
; %bb.6:
	ldrb	w8, [x22, #588]
	tbz	w8, #0, LBB13_10
LBB13_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x22, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x22, #344]
	b	LBB13_9
LBB13_8:
	mov	w8, #5                          ; =0x5
LBB13_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB13_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB13_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB13_17
LBB13_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB13_16
; %bb.13:
	ldr	x8, [x22, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x23, w1, w9, x8
	ldrb	w8, [x23]
	tbnz	w8, #0, LBB13_16
; %bb.14:
	cbnz	x2, LBB13_20
; %bb.15:
	cbz	x3, LBB13_20
LBB13_16:
	mov	w8, #6                          ; =0x6
	str	w8, [x22, #336]
	mov	w9, #3                          ; =0x3
	str	w9, [x22, #344]
	b	LBB13_9
LBB13_17:
	ldrh	w8, [x22, #584]
	cbz	x8, LBB13_7
; %bb.18:
	ldr	x9, [x22, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB13_7
; %bb.19:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB13_7
	b	LBB13_12
LBB13_20:
	cmp	x3, #256, lsl #12               ; =1048576
	b.hi	LBB13_35
; %bb.21:
	ldr	w24, [x22, #288]
	mov	x25, x0
	cbz	w24, LBB13_28
; %bb.22:
	add	x19, x0, #288
	mov	x20, x24
	b	LBB13_24
LBB13_23:                               ;   in Loop: Header=BB13_24 Depth=1
	subs	x20, x20, #1
	b.eq	LBB13_28
LBB13_24:                               ; =>This Inner Loop Header: Depth=1
	ldr	x21, [x19], #8
	ldr	x8, [x21, #8]
	cmp	x8, x3
	b.ne	LBB13_23
; %bb.25:                               ;   in Loop: Header=BB13_24 Depth=1
	cbz	x3, LBB13_27
; %bb.26:                               ;   in Loop: Header=BB13_24 Depth=1
	add	x0, x21, #16
	mov	x1, x2
	mov	x26, x2
	mov	x2, x3
	mov	x27, x3
	bl	_memcmp
	mov	x2, x26
	mov	x3, x27
	mov	x8, x0
	mov	x0, x25
	cbnz	w8, LBB13_23
LBB13_27:
	ldr	w21, [x21]
	b	LBB13_34
LBB13_28:
	cmp	w24, #4095
	b.hi	LBB13_35
; %bb.29:
	ldr	x26, [x0, #120]
	mov	w8, #67108848                   ; =0x3fffff0
	sub	x8, x8, x26
	mov	w9, #67108848                   ; =0x3fffff0
	cmp	x26, x9
	ccmp	x3, x8, #2, ls
	b.hi	LBB13_35
; %bb.30:
	mov	x19, x2
	mov	x27, x3
	add	x21, x3, #16
	mov	w0, #1                          ; =0x1
	mov	x1, x21
	bl	_calloc
	cbz	x0, LBB13_36
; %bb.31:
	mov	x20, x0
	add	w8, w24, #1
	str	w8, [x22, #288]
	add	x22, x21, x26
	mov	x21, x8
	str	w8, [x0]
	str	x27, [x0, #8]
	cbz	x27, LBB13_33
; %bb.32:
	mov	x2, x27
	add	x0, x20, #16
	mov	x1, x19
	bl	_memcpy
LBB13_33:
	add	x8, x25, x24, lsl #3
	str	x20, [x8, #288]
	str	x22, [x25, #120]
LBB13_34:
	mov	w8, #0                          ; =0x0
Lloh2:
	adrp	x9, lCPI13_0@PAGE
Lloh3:
	ldr	q0, [x9, lCPI13_0@PAGEOFF]
	mov	w9, #1                          ; =0x1
	str	w9, [x23]
	mov	w10, w21
	stur	q0, [x23, #4]
	str	wzr, [x23, #20]
	strb	w9, [x23, #24]
	stur	wzr, [x23, #25]
	str	wzr, [x23, #28]
	str	x10, [x23, #32]
	movi.2d	v0, #0000000000000000
	stur	q0, [x23, #40]
	stur	q0, [x23, #56]
	stur	q0, [x23, #72]
	stur	q0, [x23, #88]
	stur	q0, [x23, #104]
	b	LBB13_9
LBB13_35:
	mov	w8, #3                          ; =0x3
	str	w8, [x22, #336]
	mov	w9, #5                          ; =0x5
	str	w9, [x22, #344]
	b	LBB13_9
LBB13_36:
	mov	w8, #4                          ; =0x4
	str	w8, [x22, #336]
	mov	w9, #6                          ; =0x6
	str	w9, [x22, #344]
	b	LBB13_9
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_string_read ; -- Begin function nvm_socket_runtime_string_read
	.p2align	2
_nvm_socket_runtime_string_read:        ; @nvm_socket_runtime_string_read
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB14_21
; %bb.1:
	cbz	x4, LBB14_21
; %bb.2:
	add	x8, x0, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbnz	w9, #0, LBB14_20
; %bb.3:
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB14_20
; %bb.4:
	ldr	w9, [x8, #336]
	cbnz	w9, LBB14_20
; %bb.5:
	ldr	w9, [x0, #128]
	cmp	w1, w9
	b.hs	LBB14_20
; %bb.6:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x9, [x8, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB14_18
; %bb.7:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB14_18
; %bb.8:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB14_18
; %bb.9:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB14_18
; %bb.10:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB14_18
; %bb.11:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB14_18
; %bb.12:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB14_18
; %bb.13:
	ldr	w8, [x8, #288]
	cmp	x9, x8
	b.hi	LBB14_18
; %bb.14:
	str	x4, [sp, #8]                    ; 8-byte Folded Spill
	add	x8, x0, x9, lsl #3
	ldr	x8, [x8, #280]
	cbz	x8, LBB14_19
; %bb.15:
	mov	x9, x8
	ldr	x8, [x8, #8]
	cmp	x3, x8
	b.lo	LBB14_18
; %bb.16:
	cbnz	x2, LBB14_22
; %bb.17:
	cbz	x8, LBB14_22
LBB14_18:
	mov	w8, #0                          ; =0x0
LBB14_19:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	mov	x0, x8
	ret
LBB14_20:
	mov	w8, #0                          ; =0x0
LBB14_21:
	mov	x0, x8
	ret
LBB14_22:
	cbz	x8, LBB14_24
; %bb.23:
	mov	x19, x9
	add	x1, x9, #16
	mov	x0, x2
	mov	x2, x8
	bl	_memcpy
	ldr	x8, [x19, #8]
LBB14_24:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	b	LBB14_19
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_string
_fr_string:                             ; @fr_string
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB15_9
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldr	x9, [x8, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w1, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB15_9
; %bb.2:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB15_9
; %bb.3:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB15_9
; %bb.4:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB15_9
; %bb.5:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB15_9
; %bb.6:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB15_9
; %bb.7:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB15_9
; %bb.8:
	ldr	w8, [x8, #288]
	cmp	x9, x8
	b.ls	LBB15_10
LBB15_9:
	mov	x0, #0                          ; =0x0
	ret
LBB15_10:
	add	x8, x0, x9, lsl #3
	ldr	x0, [x8, #280]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_string_literal ; -- Begin function nvm_socket_runtime_string_literal
	.p2align	2
_nvm_socket_runtime_string_literal:     ; @nvm_socket_runtime_string_literal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB16_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x21, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x21, #586]
	tbz	w8, #0, LBB16_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB16_20
LBB16_3:
	mov	w0, #1                          ; =0x1
	ret
LBB16_4:
	ldr	w8, [x21, #576]
	cmp	w8, #1
	b.ne	LBB16_14
; %bb.5:
	ldr	w8, [x21, #336]
	cbnz	w8, LBB16_20
; %bb.6:
	ldrb	w8, [x21, #588]
	tbnz	w8, #0, LBB16_18
; %bb.7:
	ldr	w8, [x0, #24]
	cbz	w8, LBB16_18
; %bb.8:
	ldrb	w9, [x0, #57]
	tbz	w9, #0, LBB16_15
LBB16_9:
	cmp	w8, #2
	b.ne	LBB16_18
; %bb.10:
	ldrh	w8, [x21, #584]
	cbz	x8, LBB16_18
; %bb.11:
	mov	x19, x1
	ldr	x9, [x21, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldr	w1, [x8]
	ldrh	w2, [x8, #4]
	ldrb	w3, [x8, #34]
	add	x4, sp, #104
	add	x5, sp, #24
	mov	x20, x0
	bl	_fr_instruction
	ldrb	w8, [sp, #112]
	cmp	w0, #0
	ccmp	w8, #4, #0, ne
	b.ne	LBB16_21
; %bb.12:
	ldr	x0, [x20, #16]
	ldr	w1, [sp, #120]
	add	x2, sp, #16
	add	x3, sp, #8
	bl	_nvm_socket_indirect_hosted_string
	tbz	w0, #0, LBB16_21
; %bb.13:
	ldp	x3, x2, [sp, #8]
	mov	x0, x20
	mov	x1, x19
	bl	_nvm_socket_runtime_string
	mov	x8, x0
	b	LBB16_20
LBB16_14:
	mov	w8, #5                          ; =0x5
	b	LBB16_20
LBB16_15:
	ldrh	w9, [x21, #584]
	cbz	x9, LBB16_18
; %bb.16:
	ldr	x10, [x21, #320]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB16_18
; %bb.17:
	ldrb	w9, [x9, #33]
	tbnz	w9, #0, LBB16_9
LBB16_18:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #336]
	mov	w9, #8                          ; =0x8
LBB16_19:
	str	w9, [x21, #344]
LBB16_20:
	add	sp, sp, #704
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB16_21:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB16_23
; %bb.22:
	mov	w8, #6                          ; =0x6
	b	LBB16_20
LBB16_23:
	ldr	w9, [x21, #336]
	mov	w8, #6                          ; =0x6
	cbnz	w9, LBB16_20
; %bb.24:
	str	w8, [x21, #336]
	mov	w9, #3                          ; =0x3
	b	LBB16_19
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_string_operation ; -- Begin function nvm_socket_runtime_string_operation
	.p2align	2
_nvm_socket_runtime_string_operation:   ; @nvm_socket_runtime_string_operation
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB17_3
; %bb.1:
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB17_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB17_51
LBB17_3:
	mov	w8, #1                          ; =0x1
	b	LBB17_51
LBB17_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB17_8
; %bb.5:
	ldr	w8, [x19, #336]
	cbnz	w8, LBB17_51
; %bb.6:
	ldrb	w8, [x19, #588]
	tbz	w8, #0, LBB17_9
LBB17_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #336]
	mov	w9, #8                          ; =0x8
	b	LBB17_50
LBB17_8:
	mov	w8, #5                          ; =0x5
	b	LBB17_51
LBB17_9:
	ldr	w8, [x0, #24]
	cbz	w8, LBB17_11
; %bb.10:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB17_31
LBB17_11:
	ldr	w8, [x0, #128]
	cmp	w2, w8
	b.hs	LBB17_20
; %bb.12:
	ldr	x9, [x19, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w2, w10, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB17_20
; %bb.13:
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB17_20
; %bb.14:
	ldrb	w10, [x9, #2]
	tbnz	w10, #0, LBB17_20
; %bb.15:
	ldrb	w10, [x9, #24]
	cmp	w10, #1
	b.ne	LBB17_20
; %bb.16:
	ldur	x10, [x9, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB17_20
; %bb.17:
	ldur	x11, [x9, #12]
	and	x10, x10, #0xffffffffffffff00
	and	x10, x10, #0xffffffff0000ffff
	cmp	x10, #0
	mov	w10, #-1                        ; =0xffffffff
	ccmp	x11, x10, #0, eq
	b.ne	LBB17_20
; %bb.18:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB17_20
; %bb.19:
	ldr	w10, [x19, #288]
	cmp	x9, x10
	b.ls	LBB17_39
LBB17_20:
	mov	x9, #0                          ; =0x0
	cmp	w1, #68
	b.ne	LBB17_40
LBB17_21:
	cmp	w3, w8
	b.hs	LBB17_27
; %bb.22:
	ldr	x10, [x19, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x11, w3, w11, x10
	ldrb	w10, [x11]
	cmp	w10, #1
	b.ne	LBB17_27
; %bb.23:
	ldrb	w10, [x11, #1]
	tbnz	w10, #0, LBB17_27
; %bb.24:
	ldrb	w10, [x11, #2]
	tbnz	w10, #0, LBB17_27
; %bb.25:
	ldrb	w10, [x11, #24]
	cmp	w10, #1
	b.ne	LBB17_27
; %bb.26:
	ldur	x10, [x11, #4]
	mov	x12, #-65531                    ; =0xffffffffffff0005
	movk	x12, #0, lsl #16
	eor	x12, x10, x12
	tst	x12, #0xff
	b.eq	LBB17_34
LBB17_27:
	mov	x10, #0                         ; =0x0
LBB17_28:
	cbz	x9, LBB17_49
; %bb.29:
	cmp	w2, w3
	b.eq	LBB17_49
; %bb.30:
	cbnz	x10, LBB17_43
	b	LBB17_49
LBB17_31:
	ldrh	w8, [x19, #584]
	cbz	x8, LBB17_7
; %bb.32:
	ldr	x9, [x19, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB17_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB17_7
	b	LBB17_11
LBB17_34:
	mov	x10, #0                         ; =0x0
	mov	x13, #-256                      ; =0xffffffffffffff00
	movk	x13, #0, lsl #16
	tst	x12, x13
	b.ne	LBB17_28
; %bb.35:
	ldur	x12, [x11, #12]
	mov	w13, #-1                        ; =0xffffffff
	cmp	x12, x13
	b.ne	LBB17_28
; %bb.36:
	ldr	x10, [x11, #32]
	cmp	x10, #1
	b.lt	LBB17_27
; %bb.37:
	ldr	w11, [x19, #288]
	cmp	x10, x11
	b.hi	LBB17_27
; %bb.38:
	add	x10, x0, x10, lsl #3
	ldr	x10, [x10, #280]
	b	LBB17_28
LBB17_39:
	add	x9, x0, x9, lsl #3
	ldr	x9, [x9, #280]
	cmp	w1, #68
	b.eq	LBB17_21
LBB17_40:
	and	w10, w1, #0xfffffffb
	cmp	w10, #64
	b.ne	LBB17_49
; %bb.41:
	cbz	x9, LBB17_49
; %bb.42:
	mov	x10, #0                         ; =0x0
LBB17_43:
	cmp	w4, w2
	b.eq	LBB17_47
; %bb.44:
	cmp	w4, w3
	b.eq	LBB17_47
; %bb.45:
	cmp	w4, w8
	b.hs	LBB17_49
; %bb.46:
	ldr	x11, [x19, #296]
	mov	w12, #168                       ; =0xa8
	umull	x12, w4, w12
	ldrb	w11, [x11, x12]
	tbnz	w11, #0, LBB17_49
LBB17_47:
	cmp	w1, #64
	b.ne	LBB17_52
; %bb.48:
	cmn	w3, #1
	b.eq	LBB17_56
LBB17_49:
	mov	w8, #6                          ; =0x6
	str	w8, [x19, #336]
	mov	w9, #3                          ; =0x3
LBB17_50:
	str	w9, [x19, #344]
LBB17_51:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB17_52:
	ldr	x8, [x9, #8]
	ldr	x11, [x10, #8]
	cmp	x8, x11
	b.ne	LBB17_55
; %bb.53:
	cbz	x8, LBB17_59
; %bb.54:
	mov	x20, x0
	add	x0, x9, #16
	mov	x21, x1
	add	x1, x10, #16
	mov	x22, x2
	mov	x2, x8
	mov	x23, x4
	mov	x24, x3
	bl	_memcmp
	mov	x1, x21
	mov	x3, x24
	mov	x2, x22
	mov	x4, x23
	mov	x8, x0
	mov	x0, x20
	cmp	w8, #0
	cset	w8, eq
	b	LBB17_60
LBB17_55:
	mov	x8, #0                          ; =0x0
	b	LBB17_60
LBB17_56:
	cmp	w4, w2
	b.ne	LBB17_65
; %bb.57:
	ldr	x10, [x19, #296]
LBB17_58:
	ldr	x8, [x9, #8]
	mov	w9, #1                          ; =0x1
	b	LBB17_62
LBB17_59:
	mov	w8, #1                          ; =0x1
LBB17_60:
	ldr	x9, [x19, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w2, w10, x9
	str	xzr, [x9, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9]
	cmp	w1, #68
	b.ne	LBB17_63
; %bb.61:
	ldr	x10, [x19, #296]
	mov	w9, #4                          ; =0x4
	mov	x2, x3
LBB17_62:
	mov	w11, #168                       ; =0xa8
	umaddl	x10, w2, w11, x10
	str	xzr, [x10, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10]
	b	LBB17_64
LBB17_63:
	mov	w9, #4                          ; =0x4
LBB17_64:
	mov	x1, x4
	mov	x2, x9
	mov	x3, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	b	_nvm_socket_runtime_scalar
LBB17_65:
	cmp	w4, w8
	b.hs	LBB17_49
; %bb.66:
	ldr	x10, [x19, #296]
	mov	w8, #168                        ; =0xa8
	umull	x8, w4, w8
	ldrb	w8, [x10, x8]
	cmp	w8, #1
	b.eq	LBB17_49
	b	LBB17_58
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_copy        ; -- Begin function nvm_socket_runtime_copy
	.p2align	2
_nvm_socket_runtime_copy:               ; @nvm_socket_runtime_copy
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB18_3
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbz	w9, #0, LBB18_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB18_3:
	mov	w0, #1                          ; =0x1
	ret
LBB18_4:
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB18_7
; %bb.5:
	mov	x9, x0
	ldr	w0, [x8, #336]
	cbz	w0, LBB18_8
; %bb.6:
	ret
LBB18_7:
	mov	w0, #5                          ; =0x5
	ret
LBB18_8:
	ldrb	w10, [x8, #588]
	tbz	w10, #0, LBB18_10
LBB18_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x8, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #344]
	ret
LBB18_10:
	ldr	w10, [x9, #24]
	cbz	w10, LBB18_12
; %bb.11:
	ldrb	w10, [x9, #57]
	tbz	w10, #0, LBB18_19
LBB18_12:
	ldr	w9, [x9, #128]
	cmp	w1, w9
	b.hs	LBB18_18
; %bb.13:
	cmp	w2, w9
	b.hs	LBB18_18
; %bb.14:
	ldr	x10, [x8, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x9, w1, w9, x10
	ldrb	w11, [x9]
	tbz	w11, #0, LBB18_18
; %bb.15:
	mov	w11, #168                       ; =0xa8
	umaddl	x10, w2, w11, x10
	ldrb	w11, [x10]
	tbnz	w11, #0, LBB18_18
; %bb.16:
	ldrb	w11, [x9, #1]
	tbnz	w11, #0, LBB18_18
; %bb.17:
	ldrb	w11, [x9, #2]
	cmp	w11, #1
	b.ne	LBB18_22
LBB18_18:
	mov	w0, #6                          ; =0x6
	str	w0, [x8, #336]
	mov	w9, #3                          ; =0x3
	str	w9, [x8, #344]
	ret
LBB18_19:
	ldrh	w10, [x8, #584]
	cbz	x10, LBB18_9
; %bb.20:
	ldr	x11, [x8, #320]
	sub	w10, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldrb	w11, [x10, #32]
	tbnz	w11, #0, LBB18_9
; %bb.21:
	ldrb	w10, [x10, #33]
	tbz	w10, #0, LBB18_9
	b	LBB18_12
LBB18_22:
	mov	w0, #0                          ; =0x0
	ldp	q0, q1, [x9]
	ldr	q2, [x9, #32]
	stp	q1, q2, [x10, #16]
	str	q0, [x10]
	ldp	q0, q1, [x9, #48]
	ldp	q2, q3, [x9, #80]
	stp	q2, q3, [x10, #80]
	stp	q0, q1, [x10, #48]
	ldp	q0, q1, [x9, #112]
	ldr	q2, [x9, #144]
	ldr	x8, [x9, #160]
	str	x8, [x10, #160]
	stp	q1, q2, [x10, #128]
	str	q0, [x10, #112]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_move        ; -- Begin function nvm_socket_runtime_move
	.p2align	2
_nvm_socket_runtime_move:               ; @nvm_socket_runtime_move
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x0, LBB19_3
; %bb.1:
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB19_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB19_9
LBB19_3:
	mov	w8, #1                          ; =0x1
	b	LBB19_9
LBB19_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB19_8
; %bb.5:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB19_9
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB19_10
LBB19_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x20, #344]
	b	LBB19_9
LBB19_8:
	mov	w8, #5                          ; =0x5
LBB19_9:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB19_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB19_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB19_18
LBB19_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB19_17
; %bb.13:
	cmp	w2, w8
	b.hs	LBB19_17
; %bb.14:
	ldr	x9, [x20, #296]
	mov	w8, #168                        ; =0xa8
	umaddl	x8, w1, w8, x9
	ldrb	w10, [x8]
	tbz	w10, #0, LBB19_17
; %bb.15:
	mov	w10, #168                       ; =0xa8
	umull	x10, w2, w10
	ldrb	w10, [x9, x10]
	tbnz	w10, #0, LBB19_17
; %bb.16:
	ldrb	w10, [x8, #2]
	cmp	w10, #1
	b.ne	LBB19_21
LBB19_17:
	mov	w8, #6                          ; =0x6
	str	w8, [x20, #336]
	mov	w9, #3                          ; =0x3
	str	w9, [x20, #344]
	b	LBB19_9
LBB19_18:
	ldrh	w8, [x20, #584]
	cbz	x8, LBB19_7
; %bb.19:
	ldr	x9, [x20, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB19_7
; %bb.20:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB19_7
	b	LBB19_12
LBB19_21:
	mov	w21, w1
	mov	w22, w2
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB19_25
; %bb.22:
	mov	x19, x0
	strb	w8, [x20, #586]
	ldr	x0, [x20, #328]
	mov	w8, #168                        ; =0xa8
	umaddl	x10, w21, w8, x9
	umaddl	x8, w22, w8, x9
	add	x1, x10, #120
	add	x2, x8, #120
	bl	_nl_socket_value_move
	strb	wzr, [x20, #586]
	cbz	w0, LBB19_24
; %bb.23:
	mov	x1, x0
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_fr_core
LBB19_24:
	ldr	x9, [x20, #296]
LBB19_25:
	mov	w8, #0                          ; =0x0
	mov	w10, #168                       ; =0xa8
	umaddl	x11, w22, w10, x9
	umaddl	x9, w21, w10, x9
	ldp	q0, q1, [x9]
	ldp	q2, q3, [x9, #32]
	stp	q2, q3, [x11, #32]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x9, #64]
	ldr	q2, [x9, #96]
	ldr	x9, [x9, #112]
	str	x9, [x11, #112]
	stp	q1, q2, [x11, #80]
	str	q0, [x11, #64]
	ldr	x9, [x20, #296]
	umaddl	x11, w21, w10, x9
	ldr	x12, [x11, #152]
	umaddl	x9, w22, w10, x9
	str	x12, [x9, #152]
	ldr	w10, [x11, #160]
	str	w10, [x9, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x11, #96]
	stp	q0, q0, [x11, #64]
	stp	q0, q0, [x11, #32]
	stp	q0, q0, [x11]
	stp	q0, q0, [x11, #128]
	str	xzr, [x11, #160]
	b	LBB19_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_drop        ; -- Begin function nvm_socket_runtime_drop
	.p2align	2
_nvm_socket_runtime_drop:               ; @nvm_socket_runtime_drop
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB20_3
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB20_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB20_9
LBB20_3:
	mov	w0, #1                          ; =0x1
	ret
LBB20_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB20_8
; %bb.5:
	mov	x8, x0
	ldr	w0, [x19, #336]
	cbnz	w0, LBB20_9
; %bb.6:
	ldrb	w9, [x19, #588]
	tbz	w9, #0, LBB20_10
LBB20_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x19, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x19, #344]
	b	LBB20_9
LBB20_8:
	mov	w0, #5                          ; =0x5
LBB20_9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB20_10:
	ldr	w9, [x8, #24]
	cbz	w9, LBB20_12
; %bb.11:
	ldrb	w9, [x8, #57]
	tbz	w9, #0, LBB20_16
LBB20_12:
	ldr	w8, [x8, #128]
	cmp	w1, w8
	b.hs	LBB20_15
; %bb.13:
	ldr	x8, [x19, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x9, w1, w9, x8
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB20_15
; %bb.14:
	ldrb	w10, [x9, #2]
	cmp	w10, #1
	b.ne	LBB20_19
LBB20_15:
	mov	w0, #6                          ; =0x6
	str	w0, [x19, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #344]
	b	LBB20_9
LBB20_16:
	ldrh	w9, [x19, #584]
	cbz	x9, LBB20_7
; %bb.17:
	ldr	x10, [x19, #320]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB20_7
; %bb.18:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB20_7
	b	LBB20_12
LBB20_19:
	mov	w20, w1
	ldrb	w9, [x9, #1]
	cmp	w9, #1
	b.ne	LBB20_33
; %bb.20:
	strb	w9, [x19, #586]
	ldr	x0, [x19, #328]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w20, w9, x8
	add	x1, x8, #120
	bl	_nl_socket_value_drop
	mov	x8, x0
	strb	wzr, [x19, #586]
	cmp	w0, #2
	b.le	LBB20_25
; %bb.21:
	cmp	w8, #4
	b.gt	LBB20_29
; %bb.22:
	cmp	w8, #3
	b.eq	LBB20_35
; %bb.23:
	cmp	w8, #4
	b.ne	LBB20_34
; %bb.24:
	mov	w0, #8                          ; =0x8
	b	LBB20_37
LBB20_25:
	cbz	w8, LBB20_32
; %bb.26:
	mov	x0, x8
	cmp	w8, #1
	b.eq	LBB20_37
; %bb.27:
	cmp	w8, #2
	b.ne	LBB20_34
; %bb.28:
	mov	w0, #7                          ; =0x7
	b	LBB20_37
LBB20_29:
	cmp	w8, #5
	b.eq	LBB20_36
; %bb.30:
	cmp	w8, #6
	b.ne	LBB20_34
; %bb.31:
	mov	w0, #4                          ; =0x4
	b	LBB20_37
LBB20_32:
	ldr	x8, [x19, #296]
LBB20_33:
	mov	w0, #0                          ; =0x0
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w20, w9, x8
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	b	LBB20_9
LBB20_34:
	mov	w0, #5                          ; =0x5
	b	LBB20_37
LBB20_35:
	mov	w0, #6                          ; =0x6
	b	LBB20_37
LBB20_36:
	mov	w0, #3                          ; =0x3
LBB20_37:
	ldr	w9, [x19, #576]
	cmp	w9, #2
	b.eq	LBB20_9
; %bb.38:
	ldr	w9, [x19, #336]
	cbnz	w9, LBB20_9
; %bb.39:
	str	w0, [x19, #336]
	str	w8, [x19, #344]
	b	LBB20_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_construct   ; -- Begin function nvm_socket_runtime_construct
	.p2align	2
_nvm_socket_runtime_construct:          ; @nvm_socket_runtime_construct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh4:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh5:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh6:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB21_60
; %bb.1:
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB21_3
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB21_61
LBB21_3:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB21_7
; %bb.4:
	mov	x8, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB21_61
; %bb.5:
	ldrb	w9, [x20, #588]
	tbz	w9, #0, LBB21_8
LBB21_6:
	mov	w0, #5                          ; =0x5
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB21_61
LBB21_7:
	mov	w0, #5                          ; =0x5
	b	LBB21_61
LBB21_8:
	ldr	w9, [x8, #24]
	cbz	w9, LBB21_10
; %bb.9:
	ldrb	w9, [x8, #57]
	tbz	w9, #0, LBB21_17
LBB21_10:
	cmp	w1, #8
	b.hi	LBB21_15
; %bb.11:
	cmp	x4, #11
	b.hi	LBB21_15
; %bb.12:
	ldr	w9, [x8, #128]
	cmp	w5, w9
	b.hs	LBB21_15
; %bb.13:
	cbnz	x3, LBB21_20
; %bb.14:
	cbz	x4, LBB21_20
LBB21_15:
	mov	w0, #1                          ; =0x1
LBB21_16:
	str	w0, [x20, #336]
	str	w0, [x20, #344]
	b	LBB21_61
LBB21_17:
	ldrh	w9, [x20, #584]
	cbz	x9, LBB21_6
; %bb.18:
	ldr	x10, [x20, #320]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB21_6
; %bb.19:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB21_6
	b	LBB21_10
LBB21_20:
	mov	x22, x3
	mov	x21, x5
	mov	x19, x8
	add	x8, x8, w1, uxtw #4
	mov	w0, w1
	ldp	x25, x26, [x8, #144]
	mov	x23, x4
	mov	x24, x2
	bl	_nl_socket_catalog_type
	cbz	x0, LBB21_55
; %bb.21:
	mov	x11, x24
	lsr	x24, x26, #32
	sub	x8, x24, #5
	cmn	x8, #2
	b.lo	LBB21_55
; %bb.22:
	mov	x9, x23
	cmp	x24, #4
	b.ne	LBB21_25
; %bb.23:
	cbnz	w11, LBB21_55
; %bb.24:
	ldr	x8, [x0, #32]
	b	LBB21_27
LBB21_25:
	ldr	x8, [x0, #32]
	cmp	x8, w11, uxtw
	b.ls	LBB21_55
; %bb.26:
	mov	w8, #1                          ; =0x1
LBB21_27:
	cmp	x9, x8
	b.ne	LBB21_55
; %bb.28:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	str	xzr, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	str	q0, [sp, #80]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #48]
	stur	x25, [sp, #52]
	stur	x26, [sp, #60]
	cmp	x24, #4
	b.eq	LBB21_30
; %bb.29:
	cmp	w11, #0
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, ne
	str	w8, [sp, #68]
LBB21_30:
	mov	x8, x22
	mov	x10, x19
	cbz	x9, LBB21_53
; %bb.31:
	mov	w13, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	add	x9, sp, #48
	add	x9, x9, #32
	str	x9, [sp]                        ; 8-byte Folded Spill
	mov	w9, w11
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
LBB21_32:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB21_34 Depth 2
	cbz	x26, LBB21_36
; %bb.33:                               ;   in Loop: Header=BB21_32 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	w9, [x8, x26, lsl #2]
LBB21_34:                               ;   Parent Loop BB21_32 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w12, [x8, x11, lsl #2]
	cmp	x12, x9
	b.eq	LBB21_59
; %bb.35:                               ;   in Loop: Header=BB21_34 Depth=2
	add	x11, x11, #1
	cmp	x26, x11
	b.ne	LBB21_34
	b	LBB21_37
LBB21_36:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	w9, [x8]
LBB21_37:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	w8, [x10, #128]
	cmp	x9, x8
	b.hs	LBB21_55
; %bb.38:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	x8, [x20, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x8, w9, w10, x8
	ldrb	w9, [x8]
	tbz	w9, #0, LBB21_55
; %bb.39:                               ;   in Loop: Header=BB21_32 Depth=1
	ldrb	w9, [x8, #1]
	ldur	x25, [x8, #4]
	ldur	x27, [x8, #12]
	ldrb	w10, [x8, #24]
	stp	w13, w10, [sp, #24]             ; 8-byte Folded Spill
	ldr	x10, [x8, #32]
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldur	q2, [x8, #88]
	stp	q1, q2, [sp, #208]
	ldur	q1, [x8, #104]
	str	q1, [sp, #240]
	ldur	q1, [x8, #40]
	stp	q1, q0, [sp, #176]
	tbnz	w9, #0, LBB21_64
; %bb.40:                               ;   in Loop: Header=BB21_32 Depth=1
	ldrb	w8, [x8, #2]
	tbnz	w8, #0, LBB21_64
; %bb.41:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	x8, [x0, #24]
	cmp	x24, #4
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	csel	x9, x26, x9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	add	x2, sp, #32
	mov	x28, x0
	mov	x0, x19
	bl	_fr_member
	cbz	w0, LBB21_64
; %bb.42:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	x8, [sp, #32]
	eor	x8, x8, x25
	tst	x8, #0xff
	b.ne	LBB21_64
; %bb.43:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	x9, [sp, #40]
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	and	x8, x8, x11
	cmp	x8, #0
	ccmp	x27, x9, #0, eq
	b.ne	LBB21_64
; %bb.44:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	w1, [x22, x26, lsl #2]
	cmp	w1, w21
	cset	w27, eq
	cmp	x24, #4
	b.ne	LBB21_50
; %bb.45:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB21_64
; %bb.46:                               ;   in Loop: Header=BB21_32 Depth=1
	and	w8, w25, #0xff
	mov	w9, #251                        ; =0xfb
	and	w9, w25, w9
	cmp	w9, #1
	ccmp	w8, #4, #4, ne
	b.ne	LBB21_64
; %bb.47:                               ;   in Loop: Header=BB21_32 Depth=1
	cmp	w8, #5
	b.ne	LBB21_49
; %bb.48:                               ;   in Loop: Header=BB21_32 Depth=1
	mov	x0, x19
	bl	_fr_string
	cbz	x0, LBB21_64
LBB21_49:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	x9, [x8, x26, lsl #3]
	mov	x9, x23
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	mov	x8, x22
	mov	x10, x19
	mov	x0, x28
	b	LBB21_51
LBB21_50:                               ;   in Loop: Header=BB21_32 Depth=1
	mov	x0, x28
	mov	x10, x19
	mov	x8, x22
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	x9, [sp, #80]
	ldp	q1, q0, [sp, #176]
	add	x9, sp, #48
	stur	q0, [x9, #56]
	ldp	q0, q2, [sp, #208]
	stur	q0, [x9, #72]
	stur	q2, [x9, #88]
	ldr	q0, [sp, #240]
	stur	q0, [x9, #104]
	stur	q1, [x9, #40]
	mov	x9, x23
LBB21_51:                               ;   in Loop: Header=BB21_32 Depth=1
	ldr	w13, [sp, #24]                  ; 4-byte Folded Reload
	orr	w13, w13, w27
	add	x26, x26, #1
	cmp	x26, x9
	b.ne	LBB21_32
; %bb.52:
	ldr	w11, [sp, #28]                  ; 4-byte Folded Reload
	strb	w11, [sp, #72]
	tbnz	w13, #0, LBB21_68
LBB21_53:
	ldr	w11, [x10, #128]
	cmp	w21, w11
	b.hs	LBB21_55
; %bb.54:
	ldr	x11, [x20, #296]
	mov	w12, #168                       ; =0xa8
	umull	x10, w21, w12
	ldrb	w10, [x11, x10]
	cmp	w10, #1
	b.ne	LBB21_67
LBB21_55:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB21_57
LBB21_56:
	mov	w0, #6                          ; =0x6
	b	LBB21_61
LBB21_57:
	ldr	w8, [x20, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB21_61
; %bb.58:
	str	w0, [x20, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #344]
	b	LBB21_61
LBB21_59:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB21_63
LBB21_60:
	mov	w0, #1                          ; =0x1
LBB21_61:
	ldur	x8, [x29, #-96]
Lloh7:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh8:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh9:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB21_70
; %bb.62:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB21_63:
	ldr	w8, [x20, #336]
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB21_61
	b	LBB21_16
LBB21_64:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB21_56
; %bb.65:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB21_56
; %bb.66:
	mov	w8, #6                          ; =0x6
	str	w8, [x20, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #344]
	b	LBB21_56
LBB21_67:
	cbz	x9, LBB21_69
LBB21_68:                               ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x8], #4
	ldr	x11, [x20, #296]
	mov	w12, #168                       ; =0xa8
	umaddl	x10, w10, w12, x11
	str	xzr, [x10, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10]
	subs	x9, x9, #1
	b.ne	LBB21_68
LBB21_69:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w21, w9, x8
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #144]
	str	q0, [x8, #96]
	ldr	x9, [sp, #160]
	str	x9, [x8, #112]
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x8]
	ldp	q0, q1, [sp, #80]
	stp	q0, q1, [x8, #32]
	b	LBB21_61
LBB21_70:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh4, Lloh5, Lloh6
	.loh AdrpLdrGotLdr	Lloh7, Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function fr_member
lCPI22_0:
	.quad	-4294967291                     ; 0xffffffff00000005
	.quad	4294967295                      ; 0xffffffff
lCPI22_1:
	.quad	-4294967292                     ; 0xffffffff00000004
	.quad	4294967295                      ; 0xffffffff
lCPI22_2:
	.quad	-4294967295                     ; 0xffffffff00000001
	.quad	4294967295                      ; 0xffffffff
lCPI22_3:
	.quad	-4294967296                     ; 0xffffffff00000000
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_fr_member:                             ; @fr_member
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x1, LBB22_23
; %bb.1:
	mov	x21, x1
	mov	x20, x0
Lloh10:
	adrp	x1, l_.str@PAGE
Lloh11:
	add	x1, x1, l_.str@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB22_24
; %bb.2:
Lloh12:
	adrp	x1, l_.str.1@PAGE
Lloh13:
	add	x1, x1, l_.str.1@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB22_25
; %bb.3:
Lloh14:
	adrp	x1, l_.str.2@PAGE
Lloh15:
	add	x1, x1, l_.str.2@PAGEOFF
	mov	x0, x21
	bl	_strcmp
	cbz	w0, LBB22_26
; %bb.4:
	mov	x0, #0                          ; =0x0
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_6
; %bb.5:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_27
LBB22_6:
	mov	w0, #1                          ; =0x1
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_8
; %bb.7:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_28
LBB22_8:
	mov	w0, #2                          ; =0x2
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_10
; %bb.9:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_29
LBB22_10:
	mov	w0, #3                          ; =0x3
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_12
; %bb.11:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_30
LBB22_12:
	mov	w0, #4                          ; =0x4
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_14
; %bb.13:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_31
LBB22_14:
	mov	w0, #5                          ; =0x5
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_16
; %bb.15:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_32
LBB22_16:
	mov	w0, #6                          ; =0x6
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_18
; %bb.17:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_33
LBB22_18:
	mov	w0, #7                          ; =0x7
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_20
; %bb.19:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_34
LBB22_20:
	mov	w0, #8                          ; =0x8
	bl	_nl_socket_catalog_type
	cbz	x0, LBB22_38
; %bb.21:
	ldr	x0, [x0]
	mov	x1, x21
	bl	_strcmp
	cbz	w0, LBB22_35
; %bb.22:
	mov	w0, #0                          ; =0x0
	b	LBB22_38
LBB22_23:
Lloh16:
	adrp	x8, lCPI22_3@PAGE
Lloh17:
	ldr	q0, [x8, lCPI22_3@PAGEOFF]
	b	LBB22_37
LBB22_24:
Lloh18:
	adrp	x8, lCPI22_2@PAGE
Lloh19:
	ldr	q0, [x8, lCPI22_2@PAGEOFF]
	b	LBB22_37
LBB22_25:
Lloh20:
	adrp	x8, lCPI22_1@PAGE
Lloh21:
	ldr	q0, [x8, lCPI22_1@PAGEOFF]
	b	LBB22_37
LBB22_26:
Lloh22:
	adrp	x8, lCPI22_0@PAGE
Lloh23:
	ldr	q0, [x8, lCPI22_0@PAGEOFF]
	b	LBB22_37
LBB22_27:
	mov	x8, #0                          ; =0x0
	b	LBB22_36
LBB22_28:
	mov	w8, #1                          ; =0x1
	b	LBB22_36
LBB22_29:
	mov	w8, #2                          ; =0x2
	b	LBB22_36
LBB22_30:
	mov	w8, #3                          ; =0x3
	b	LBB22_36
LBB22_31:
	mov	w8, #4                          ; =0x4
	b	LBB22_36
LBB22_32:
	mov	w8, #5                          ; =0x5
	b	LBB22_36
LBB22_33:
	mov	w8, #6                          ; =0x6
	b	LBB22_36
LBB22_34:
	mov	w8, #7                          ; =0x7
	b	LBB22_36
LBB22_35:
	mov	w8, #8                          ; =0x8
LBB22_36:
	add	x8, x20, x8, lsl #4
	ldr	q0, [x8, #144]
LBB22_37:
	str	q0, [x19]
	mov	w0, #1                          ; =0x1
LBB22_38:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_project     ; -- Begin function nvm_socket_runtime_project
	.p2align	2
_nvm_socket_runtime_project:            ; @nvm_socket_runtime_project
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x24, x23, [sp, #240]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh24:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh25:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh26:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	cbz	x0, LBB23_3
; %bb.1:
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB23_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB23_9
LBB23_3:
	mov	w0, #1                          ; =0x1
	b	LBB23_9
LBB23_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB23_8
; %bb.5:
	mov	x22, x0
	ldr	w0, [x19, #336]
	cbnz	w0, LBB23_9
; %bb.6:
	ldrb	w9, [x19, #588]
	tbz	w9, #0, LBB23_11
LBB23_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x19, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x19, #344]
	b	LBB23_9
LBB23_8:
	mov	w0, #5                          ; =0x5
LBB23_9:
	ldur	x8, [x29, #-56]
Lloh27:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh28:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh29:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB23_42
; %bb.10:
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
LBB23_11:
	mov	x8, x22
	ldr	w9, [x22, #24]
	cbz	w9, LBB23_13
; %bb.12:
	ldrb	w9, [x8, #57]
	tbz	w9, #0, LBB23_25
LBB23_13:
	ldr	w10, [x8, #128]
	cmp	w1, w10
	b.hs	LBB23_30
; %bb.14:
	ldr	x9, [x19, #296]
	mov	w8, #168                        ; =0xa8
	umaddl	x8, w1, w8, x9
	ldrb	w11, [x8]
	cmp	w11, #1
	b.ne	LBB23_30
; %bb.15:
	cmp	w1, w3
	b.ne	LBB23_28
LBB23_16:
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [sp, #80]
	ldr	q0, [x8, #96]
	str	q0, [sp, #112]
	ldr	x9, [x8, #112]
	str	x9, [sp, #128]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [sp, #48]
	ldrb	w8, [sp, #17]
	tbnz	w8, #0, LBB23_30
; %bb.17:
	ldrb	w8, [sp, #18]
	tbnz	w8, #0, LBB23_30
; %bb.18:
	ldr	w0, [sp, #28]
	cmp	w0, #9
	b.hs	LBB23_30
; %bb.19:
	mov	x23, x2
	mov	x21, x1
	mov	x20, x3
	bl	_nl_socket_catalog_type
	ldr	w9, [sp, #32]
	cmp	w9, #4
	b.ne	LBB23_32
; %bb.20:
	cbz	x0, LBB23_39
; %bb.21:
	mov	x8, x22
	mov	w22, w23
	ldr	x9, [x0, #32]
	cmp	x9, x22
	b.ls	LBB23_39
; %bb.22:
	ldrb	w9, [sp, #40]
	cmp	w23, w9
	b.hs	LBB23_39
; %bb.23:
	ldr	x9, [x0, #24]
	add	x9, x9, x22, lsl #5
	ldr	x1, [x9, #16]
	mov	x2, sp
	mov	x0, x8
	bl	_fr_member
	tbz	w0, #0, LBB23_39
; %bb.24:
	ldp	x8, x9, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #144]
	stp	q0, q0, [sp, #176]
	str	q0, [sp, #208]
	add	x10, sp, #16
	add	x10, x10, x22, lsl #3
	ldr	x10, [x10, #32]
	mov	w11, #1                         ; =0x1
	b	LBB23_38
LBB23_25:
	ldrh	w9, [x19, #584]
	cbz	x9, LBB23_7
; %bb.26:
	ldr	x10, [x19, #320]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB23_7
; %bb.27:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB23_7
	b	LBB23_13
LBB23_28:
	cmp	w3, w10
	b.hs	LBB23_30
; %bb.29:
	mov	w10, #168                       ; =0xa8
	umull	x10, w3, w10
	ldrb	w9, [x9, x10]
	cmp	w9, #1
	b.ne	LBB23_16
LBB23_30:
	mov	w0, #6                          ; =0x6
LBB23_31:
	str	w0, [x19, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #344]
	b	LBB23_9
LBB23_32:
	cbnz	w23, LBB23_39
; %bb.33:
	cmp	w9, #3
	b.ne	LBB23_39
; %bb.34:
	ldr	w9, [sp, #36]
	and	w10, w9, #0xfffffffe
	cmp	w10, #2
	b.ne	LBB23_39
; %bb.35:
	cbz	x0, LBB23_39
; %bb.36:
	cmp	w9, #3
	cset	w9, eq
	ldr	x10, [x0, #24]
	add	x9, x10, x9, lsl #5
	ldr	x1, [x9, #16]
	mov	x2, sp
	mov	x0, x22
	bl	_fr_member
	tbz	w0, #0, LBB23_39
; %bb.37:
	ldp	x8, x9, [sp]
	ldrb	w11, [sp, #40]
	ldr	x10, [sp, #48]
	ldur	q0, [sp, #72]
	ldur	q1, [sp, #88]
	ldur	q2, [sp, #104]
	stp	q1, q2, [sp, #176]
	ldur	q1, [sp, #120]
	str	q1, [sp, #208]
	ldur	q1, [sp, #56]
	stp	q1, q0, [sp, #144]
LBB23_38:
	mov	w0, #0                          ; =0x0
	ldr	x12, [x19, #296]
	mov	w13, w21
	mov	w14, #168                       ; =0xa8
	umaddl	x12, w13, w14, x12
	str	xzr, [x12, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x12, #128]
	stp	q0, q0, [x12, #96]
	stp	q0, q0, [x12, #64]
	stp	q0, q0, [x12, #32]
	stp	q0, q0, [x12]
	ldr	x12, [x19, #296]
	umaddl	x12, w20, w14, x12
	ldp	q1, q0, [sp, #144]
	stur	q0, [x12, #56]
	ldp	q0, q2, [sp, #176]
	stur	q0, [x12, #72]
	stur	q2, [x12, #88]
	ldr	q0, [sp, #208]
	stur	q0, [x12, #104]
	lsr	x13, x9, #32
	sub	x13, x13, #1
	cmp	x13, #2
	cset	w13, lo
	mov	w14, #1                         ; =0x1
	strb	w14, [x12]
	strb	w13, [x12, #1]
	strh	wzr, [x12, #2]
	stur	x8, [x12, #4]
	stur	x9, [x12, #12]
	str	wzr, [x12, #20]
	strb	w11, [x12, #24]
	strb	wzr, [x12, #31]
	sturh	wzr, [x12, #29]
	stur	wzr, [x12, #25]
	str	x10, [x12, #32]
	stur	q1, [x12, #40]
	b	LBB23_9
LBB23_39:
	ldr	w8, [x19, #576]
	cmp	w8, #2
	b.ne	LBB23_41
; %bb.40:
	mov	w0, #6                          ; =0x6
	b	LBB23_9
LBB23_41:
	ldr	w8, [x19, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB23_9
	b	LBB23_31
LBB23_42:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh24, Lloh25, Lloh26
	.loh AdrpLdrGotLdr	Lloh27, Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_result_arm  ; -- Begin function nvm_socket_runtime_result_arm
	.p2align	2
_nvm_socket_runtime_result_arm:         ; @nvm_socket_runtime_result_arm
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB24_3
; %bb.1:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB24_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB24_25
LBB24_3:
	mov	w0, #1                          ; =0x1
	ret
LBB24_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB24_24
; %bb.5:
	mov	x8, x0
	ldr	w0, [x19, #336]
	cbnz	w0, LBB24_25
; %bb.6:
	ldrb	w9, [x19, #588]
	cmp	w9, #1
	b.ne	LBB24_10
; %bb.7:
	mov	w0, #5                          ; =0x5
LBB24_8:
	str	w0, [x19, #336]
	mov	w8, #8                          ; =0x8
LBB24_9:
	str	w8, [x19, #344]
	b	LBB24_25
LBB24_10:
	cbz	x2, LBB24_20
; %bb.11:
	ldr	w8, [x8, #128]
	cmp	w1, w8
	b.hs	LBB24_20
; %bb.12:
	ldr	x8, [x19, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x9, w1, w9, x8
	ldrb	w10, [x9]
	tbz	w10, #0, LBB24_20
; %bb.13:
	ldr	w10, [x9, #16]
	cmp	w10, #3
	b.eq	LBB24_21
; %bb.14:
	cmp	w10, #2
	b.ne	LBB24_26
; %bb.15:
	mov	x20, x2
	mov	w9, w1
	mov	w10, #1                         ; =0x1
	strb	w10, [x19, #586]
	ldr	x0, [x19, #328]
	mov	w10, #168                       ; =0xa8
	umaddl	x8, w9, w10, x8
	add	x1, x8, #120
	mov	x2, sp
	bl	_nl_socket_connect_view
	mov	x8, x0
	strb	wzr, [x19, #586]
	cmp	w0, #2
	b.le	LBB24_28
; %bb.16:
	cmp	w8, #4
	b.gt	LBB24_32
; %bb.17:
	cmp	w8, #3
	b.eq	LBB24_38
; %bb.18:
	cmp	w8, #4
	b.ne	LBB24_37
; %bb.19:
	mov	w0, #8                          ; =0x8
	b	LBB24_40
LBB24_20:
	mov	w0, #1                          ; =0x1
	str	w0, [x19, #336]
	str	w0, [x19, #344]
	b	LBB24_25
LBB24_21:
	ldr	w8, [x9, #20]
LBB24_22:
	sub	w9, w8, #4
	cmn	w9, #3
	b.hi	LBB24_27
; %bb.23:
	ldr	w8, [x19, #576]
	cmp	w8, #2
	b.ne	LBB24_35
LBB24_24:
	mov	w0, #5                          ; =0x5
LBB24_25:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB24_26:
	mov	w0, #6                          ; =0x6
	str	w0, [x19, #336]
	mov	w8, #3                          ; =0x3
	b	LBB24_9
LBB24_27:
	mov	w0, #0                          ; =0x0
	str	w8, [x2]
	b	LBB24_25
LBB24_28:
	cbz	w8, LBB24_36
; %bb.29:
	mov	x0, x8
	cmp	w8, #1
	b.eq	LBB24_40
; %bb.30:
	cmp	w8, #2
	b.ne	LBB24_37
; %bb.31:
	mov	w0, #7                          ; =0x7
	b	LBB24_40
LBB24_32:
	cmp	w8, #5
	b.eq	LBB24_39
; %bb.33:
	cmp	w8, #6
	b.ne	LBB24_37
; %bb.34:
	mov	w0, #4                          ; =0x4
	b	LBB24_40
LBB24_35:
	ldr	w8, [x19, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB24_25
	b	LBB24_8
LBB24_36:
	mov	x2, x20
	ldrb	w8, [sp]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, eq
	b	LBB24_22
LBB24_37:
	mov	w0, #5                          ; =0x5
	b	LBB24_40
LBB24_38:
	mov	w0, #6                          ; =0x6
	b	LBB24_40
LBB24_39:
	mov	w0, #3                          ; =0x3
LBB24_40:
	ldr	w9, [x19, #576]
	cmp	w9, #2
	b.eq	LBB24_25
; %bb.41:
	ldr	w9, [x19, #336]
	cbnz	w9, LBB24_25
; %bb.42:
	str	w0, [x19, #336]
	b	LBB24_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_take        ; -- Begin function nvm_socket_runtime_take
	.p2align	2
_nvm_socket_runtime_take:               ; @nvm_socket_runtime_take
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB25_3
; %bb.1:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB25_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB25_9
LBB25_3:
	mov	w0, #1                          ; =0x1
	ret
LBB25_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB25_8
; %bb.5:
	mov	x8, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB25_9
; %bb.6:
	ldrb	w9, [x20, #588]
	tbz	w9, #0, LBB25_10
LBB25_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB25_9
LBB25_8:
	mov	w0, #5                          ; =0x5
LBB25_9:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB25_10:
	mov	x0, x8
	ldr	w8, [x8, #24]
	cbz	w8, LBB25_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB25_24
LBB25_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB25_22
; %bb.13:
	cmp	w3, w8
	b.hs	LBB25_22
; %bb.14:
	ldr	x8, [x20, #296]
	mov	w9, #168                        ; =0xa8
	umull	x9, w1, w9
	ldrb	w9, [x8, x9]
	tbz	w9, #0, LBB25_22
; %bb.15:
	sub	w9, w2, #4
	cmn	w9, #2
	b.lo	LBB25_22
; %bb.16:
	mov	w9, #168                        ; =0xa8
	umull	x9, w3, w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB25_22
; %bb.17:
	mov	x21, x3
	mov	x25, x2
	sub	x2, x29, #92
	mov	x19, x0
	mov	x22, x1
	bl	_nvm_socket_runtime_result_arm
	cbnz	w0, LBB25_9
; %bb.18:
	ldur	w8, [x29, #-92]
	cmp	w8, w25
	b.ne	LBB25_27
; %bb.19:
	mov	w22, w22
	mov	w21, w21
	ldr	x8, [x20, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x10, w22, w10, x8
	ldr	w11, [x10, #16]
	cmp	w11, #2
	b.ne	LBB25_29
; %bb.20:
	cmp	w25, #2
	b.ne	LBB25_37
; %bb.21:
	ldp	x23, x9, [x19, #144]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	stur	wzr, [x29, #-100]
	stur	wzr, [x29, #-97]
	mov	w9, #1                          ; =0x1
	mov	w10, #168                       ; =0xa8
	umaddl	x11, w22, w10, x8
	strb	w9, [x20, #586]
	umaddl	x8, w21, w10, x8
	ldr	x0, [x20, #328]
	add	x1, x11, #120
	add	x2, x8, #120
	bl	_nl_socket_connect_take_ok
	mov	x1, x0
	mov	x24, #0                         ; =0x0
	mov	x28, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	mov	x11, #0                         ; =0x0
	stp	xzr, xzr, [sp, #32]             ; 16-byte Folded Spill
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
	mov	w13, #0                         ; =0x0
	strb	wzr, [x20, #586]
	cbnz	w1, LBB25_39
	b	LBB25_32
LBB25_22:
	mov	w0, #6                          ; =0x6
LBB25_23:
	str	w0, [x20, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #344]
	b	LBB25_9
LBB25_24:
	ldrh	w8, [x20, #584]
	cbz	x8, LBB25_7
; %bb.25:
	ldr	x9, [x20, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB25_7
; %bb.26:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB25_7
	b	LBB25_12
LBB25_27:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB25_36
; %bb.28:
	ldr	w8, [x20, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB25_9
	b	LBB25_23
LBB25_29:
	ldr	w0, [x10, #12]
	ldrb	w8, [x10, #24]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldp	x9, x11, [x10, #32]
	stp	x21, x9, [sp, #16]              ; 16-byte Folded Spill
	ldp	x8, x21, [x10, #48]
	stp	x11, x8, [sp, #32]              ; 16-byte Folded Spill
	ldp	x9, x8, [x10, #64]
	stp	x9, x8, [sp, #48]               ; 16-byte Folded Spill
	ldp	x24, x23, [x10, #80]
	ldp	x28, x27, [x10, #96]
	ldr	x26, [x10, #112]
	bl	_nl_socket_catalog_type
	cbz	x0, LBB25_33
; %bb.30:
	ldr	x8, [x0, #24]
	cmp	w25, #3
	cset	w9, eq
	add	x8, x8, x9, lsl #5
	ldr	x1, [x8, #16]
	add	x2, sp, #104
	mov	x0, x19
	bl	_fr_member
	tbz	w0, #0, LBB25_33
; %bb.31:
	ldp	x8, x9, [sp, #104]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	stur	wzr, [x29, #-100]
	stur	wzr, [x29, #-97]
	mov	x25, x26
	mov	x26, x27
	mov	x27, x28
	mov	x28, x23
	mov	x23, x8
	mov	x11, x21
	ldr	x21, [sp, #16]                  ; 8-byte Folded Reload
	ldr	w13, [sp, #4]                   ; 4-byte Folded Reload
LBB25_32:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w22, w9, x8
	str	xzr, [x8, #160]
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	lsr	x10, x12, #32
	sub	x10, x10, #1
	cmp	x10, #2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	cset	w10, lo
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	ldr	x8, [x20, #296]
	umaddl	x8, w21, w9, x8
	mov	w9, #1                          ; =0x1
	strb	w9, [x8]
	strb	w10, [x8, #1]
	strh	wzr, [x8, #2]
	stur	x23, [x8, #4]
	stur	x12, [x8, #12]
	str	wzr, [x8, #20]
	strb	w13, [x8, #24]
	ldur	w9, [x29, #-100]
	stur	w9, [x8, #25]
	ldur	w9, [x29, #-97]
	str	w9, [x8, #28]
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	stp	x10, x9, [x8, #32]
	ldp	x10, x9, [sp, #40]              ; 16-byte Folded Reload
	stp	x10, x11, [x8, #48]
	str	x9, [x8, #64]
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	stp	x9, x24, [x8, #72]
	stp	x28, x27, [x8, #88]
	stp	x26, x25, [x8, #104]
	b	LBB25_9
LBB25_33:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB25_36
; %bb.34:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB25_36
; %bb.35:
	mov	w8, #6                          ; =0x6
	str	w8, [x20, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #344]
LBB25_36:
	mov	w0, #6                          ; =0x6
	b	LBB25_9
LBB25_37:
	mov	w9, #1                          ; =0x1
	strb	w9, [x20, #586]
	ldr	x0, [x20, #328]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w22, w9, x8
	add	x1, x8, #120
	add	x2, sp, #104
	bl	_nl_socket_connect_view
	strb	wzr, [x20, #586]
	cbz	w0, LBB25_40
; %bb.38:
	mov	x1, x0
LBB25_39:
	mov	x0, x19
	bl	_fr_core
	b	LBB25_9
LBB25_40:
	ldp	x23, x8, [x19, #160]
	stp	x8, x21, [sp, #8]               ; 16-byte Folded Spill
	stur	wzr, [x29, #-100]
	stur	wzr, [x29, #-97]
	ldr	x8, [sp, #128]
	tbnz	x8, #63, LBB25_42
; %bb.41:
	mov	x21, x8
	ldrb	w25, [sp, #148]
	ldrb	w26, [sp, #147]
	ldrb	w27, [sp, #146]
	ldrb	w28, [sp, #145]
	ldrb	w24, [sp, #144]
	ldr	w8, [sp, #140]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #136]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	ldpsw	x8, x9, [sp, #116]
	stp	x8, x9, [sp, #32]               ; 16-byte Folded Spill
	ldr	w8, [sp, #112]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	mov	w9, #168                        ; =0xa8
	strb	w8, [x20, #586]
	ldr	x8, [x20, #296]
	umaddl	x8, w22, w9, x8
	ldr	x0, [x20, #328]
	add	x1, x8, #120
	add	x2, sp, #64
	bl	_nl_socket_connect_take_error
	mov	x1, x0
	strb	wzr, [x20, #586]
	mov	w13, #11                        ; =0xb
	mov	x11, x21
	ldr	x21, [sp, #16]                  ; 8-byte Folded Reload
	cbnz	w1, LBB25_39
	b	LBB25_32
LBB25_42:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB25_44
; %bb.43:
	mov	w0, #3                          ; =0x3
	b	LBB25_9
LBB25_44:
	ldr	w8, [x20, #336]
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB25_9
; %bb.45:
	str	w0, [x20, #336]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #344]
	b	LBB25_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_region_begin ; -- Begin function nvm_socket_runtime_region_begin
	.p2align	2
_nvm_socket_runtime_region_begin:       ; @nvm_socket_runtime_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB26_3
; %bb.1:
	add	x9, x0, #8, lsl #12             ; =32768
	ldrb	w8, [x9, #586]
	tbz	w8, #0, LBB26_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB26_3:
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	ret
LBB26_4:
	ldr	w8, [x9, #576]
	cmp	w8, #1
	b.ne	LBB26_7
; %bb.5:
	ldr	w8, [x9, #336]
	cbz	w8, LBB26_8
; %bb.6:
	mov	x0, x8
	ret
LBB26_7:
	mov	w0, #5                          ; =0x5
	ret
LBB26_8:
	ldrb	w8, [x9, #588]
	tbz	w8, #0, LBB26_10
LBB26_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x9, #336]
	mov	w10, #8                         ; =0x8
	str	w10, [x9, #344]
	ret
LBB26_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB26_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB26_16
LBB26_12:
	ldr	w10, [x9, #596]
	ldr	w8, [x0, #136]
	cmp	w10, w8
	b.eq	LBB26_15
; %bb.13:
	ldr	x11, [x9, #600]
	cmn	x11, #1
	b.eq	LBB26_15
; %bb.14:
	add	x12, x11, #1
	str	x12, [x9, #600]
	ldr	x12, [x9, #312]
	add	w13, w10, #1
	str	w13, [x9, #596]
	str	x11, [x12, x10, lsl #3]
	mov	w0, #0                          ; =0x0
	ret
LBB26_15:
	mov	w0, #3                          ; =0x3
	str	w0, [x9, #336]
	mov	w10, #5                         ; =0x5
	str	w10, [x9, #344]
	ret
LBB26_16:
	ldrh	w8, [x9, #584]
	cbz	x8, LBB26_9
; %bb.17:
	ldr	x10, [x9, #320]
	sub	w8, w8, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w8, w11, x10
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB26_9
; %bb.18:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB26_9
	b	LBB26_12
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_borrow      ; -- Begin function nvm_socket_runtime_borrow
	.p2align	2
_nvm_socket_runtime_borrow:             ; @nvm_socket_runtime_borrow
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_file_runtime_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_runtime_borrow_mode
_file_runtime_borrow_mode:              ; @file_runtime_borrow_mode
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB28_3
; %bb.1:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	add	x19, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x19, #586]
	tbz	w8, #0, LBB28_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB28_9
LBB28_3:
	mov	w0, #1                          ; =0x1
	ret
LBB28_4:
	ldr	w8, [x19, #576]
	cmp	w8, #1
	b.ne	LBB28_8
; %bb.5:
	ldr	w8, [x19, #336]
	cbnz	w8, LBB28_9
; %bb.6:
	ldrb	w8, [x19, #588]
	tbz	w8, #0, LBB28_10
LBB28_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x19, #344]
	b	LBB28_9
LBB28_8:
	mov	w8, #5                          ; =0x5
LBB28_9:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	mov	x0, x8
	ret
LBB28_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB28_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB28_20
LBB28_12:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB28_19
; %bb.13:
	ldr	x9, [x19, #296]
	mov	w8, #168                        ; =0xa8
	umaddl	x8, w1, w8, x9
	ldrb	w10, [x8]
	cmp	w10, #1
	b.ne	LBB28_19
; %bb.14:
	ldr	w10, [x8, #16]
	cmp	w10, #1
	b.ne	LBB28_19
; %bb.15:
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB28_19
; %bb.16:
	ldr	w8, [x19, #596]
	cbz	w8, LBB28_19
; %bb.17:
	ldr	w10, [x0, #132]
	cmp	w2, w10
	b.hs	LBB28_19
; %bb.18:
	ldr	x11, [x19, #304]
	mov	w12, #56                        ; =0x38
	umaddl	x12, w2, w12, x11
	ldrb	w13, [x12]
	cmp	w13, #1
	b.ne	LBB28_23
LBB28_19:
	mov	w8, #8                          ; =0x8
	str	w8, [x19, #336]
	mov	w9, #4                          ; =0x4
	str	w9, [x19, #344]
	b	LBB28_9
LBB28_20:
	ldrh	w8, [x19, #584]
	cbz	x8, LBB28_7
; %bb.21:
	ldr	x9, [x19, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB28_7
; %bb.22:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB28_7
	b	LBB28_12
LBB28_23:
	movi.2d	v0, #0000000000000000
	str	xzr, [sp, #64]
	stp	q0, q0, [sp, #32]
	str	q0, [sp, #16]
	stp	w1, w2, [sp, #20]
	mov	w13, #-1                        ; =0xffffffff
	str	w13, [sp, #28]
	ldr	x13, [x19, #312]
	sub	w8, w8, #1
	ldr	x8, [x13, w8, uxtw #3]
	str	x8, [sp, #32]
	strb	w3, [sp, #18]
	cbz	w3, LBB28_31
; %bb.24:
	mov	x8, #0                          ; =0x0
	b	LBB28_26
LBB28_25:                               ;   in Loop: Header=BB28_26 Depth=1
	add	x8, x8, #1
	add	x11, x11, #56
	cmp	x10, x8
	b.eq	LBB28_31
LBB28_26:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w13, [x11]
	cmp	w13, #1
	b.ne	LBB28_25
; %bb.27:                               ;   in Loop: Header=BB28_26 Depth=1
	ldr	w13, [x11, #4]
	cmp	w13, w1
	b.ne	LBB28_25
; %bb.28:
	str	x12, [sp, #8]                   ; 8-byte Folded Spill
	ldrb	w9, [x11, #2]
	cmp	w9, #1
	b.ne	LBB28_19
; %bb.29:
	mov	x20, x11
	mov	x1, x8
	bl	_fr_reference
	tbz	w0, #0, LBB28_19
; %bb.30:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x20, #8]
	str	w9, [sp, #24]
	ldur	q0, [x20, #40]
	ldur	q1, [x20, #24]
	stur	q1, [sp, #40]
	stur	q0, [sp, #56]
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #16]
	ldp	q0, q1, [sp, #16]
	ldr	q2, [sp, #48]
	ldr	x9, [sp, #64]
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	str	x9, [x10, #48]
	stp	q1, q2, [x10, #16]
	str	q0, [x10]
	b	LBB28_9
LBB28_31:
	str	w2, [sp, #4]                    ; 4-byte Folded Spill
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, w1
	mov	w20, #1                         ; =0x1
	strb	w20, [x19, #586]
	ldr	x0, [x19, #328]
	mov	w10, #168                       ; =0xa8
	umaddl	x8, w8, w10, x9
	add	x9, sp, #16
	add	x1, x8, #120
	add	x2, x9, #24
	bl	_nl_socket_value_borrow
	strb	wzr, [x19, #586]
	cbz	w0, LBB28_33
; %bb.32:
	mov	x1, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_fr_core
	mov	x8, x0
	b	LBB28_9
LBB28_33:
	mov	w8, #0                          ; =0x0
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	mov	w9, w9
	strb	w20, [sp, #16]
	ldr	x10, [x19, #304]
	mov	w11, #56                        ; =0x38
	umaddl	x9, w9, w11, x10
	ldp	q0, q1, [sp, #16]
	ldr	q2, [sp, #48]
	ldr	x10, [sp, #64]
	str	x10, [x9, #48]
	stp	q1, q2, [x9, #16]
	str	q0, [x9]
	b	LBB28_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_borrow_shared ; -- Begin function nvm_socket_runtime_borrow_shared
	.p2align	2
_nvm_socket_runtime_borrow_shared:      ; @nvm_socket_runtime_borrow_shared
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_file_runtime_borrow_mode
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_bind_formal ; -- Begin function nvm_socket_runtime_bind_formal
	.p2align	2
_nvm_socket_runtime_bind_formal:        ; @nvm_socket_runtime_bind_formal
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB30_3
; %bb.1:
	add	x9, x0, #8, lsl #12             ; =32768
	ldrb	w8, [x9, #586]
	tbz	w8, #0, LBB30_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	ret
LBB30_3:
	mov	w8, #1                          ; =0x1
	mov	x0, x8
	ret
LBB30_4:
	ldr	w8, [x9, #576]
	cmp	w8, #1
	b.ne	LBB30_7
; %bb.5:
	ldr	w8, [x9, #336]
	cbz	w8, LBB30_8
; %bb.6:
	mov	x0, x8
	ret
LBB30_7:
	mov	w0, #5                          ; =0x5
	ret
LBB30_8:
	ldrb	w8, [x9, #588]
	tbz	w8, #0, LBB30_10
LBB30_9:
	mov	w0, #5                          ; =0x5
	str	w0, [x9, #336]
	mov	w10, #8                         ; =0x8
	str	w10, [x9, #344]
	ret
LBB30_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB30_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB30_26
LBB30_12:
	ldr	w13, [x0, #132]
	cmp	w1, w13
	b.hs	LBB30_25
; %bb.13:
	ldr	x8, [x9, #304]
	mov	w10, #56                        ; =0x38
	umaddl	x10, w1, w10, x8
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB30_25
; %bb.14:
	ldr	w11, [x10, #8]
	cmp	w11, w13
	b.hs	LBB30_25
; %bb.15:
	mov	w12, #56                        ; =0x38
	umaddl	x14, w11, w12, x8
	ldrb	w12, [x14]
	cmp	w12, #1
	b.ne	LBB30_25
; %bb.16:
	ldrb	w12, [x14, #1]
	tbnz	w12, #0, LBB30_25
; %bb.17:
	ldr	w12, [x14, #8]
	cmp	w12, w11
	b.ne	LBB30_25
; %bb.18:
	ldrb	w12, [x14, #2]
	ldrb	w15, [x10, #2]
	cmp	w12, w15
	b.ne	LBB30_25
; %bb.19:
	ldr	x15, [x14, #48]
	ldr	x16, [x10, #48]
	cmp	x15, x16
	b.ne	LBB30_25
; %bb.20:
	ldr	w14, [x14, #4]
	ldr	w15, [x10, #4]
	cmp	w14, w15
	b.ne	LBB30_25
; %bb.21:
	ldr	w16, [x0, #128]
	cmp	w14, w16
	b.hs	LBB30_25
; %bb.22:
	ldr	x15, [x9, #296]
	mov	w17, #168                       ; =0xa8
	umaddl	x17, w14, w17, x15
	ldrb	w0, [x17]
	cmp	w0, #1
	b.ne	LBB30_25
; %bb.23:
	ldrb	w0, [x17, #1]
	cmp	w0, #1
	b.ne	LBB30_25
; %bb.24:
	ldr	w17, [x17, #16]
	cmp	w17, #1
	ccmp	w2, w16, #2, eq
	b.lo	LBB30_29
LBB30_25:
	mov	w0, #8                          ; =0x8
	str	w0, [x9, #336]
	mov	w10, #4                         ; =0x4
	str	w10, [x9, #344]
	ret
LBB30_26:
	ldrh	w8, [x9, #584]
	cbz	x8, LBB30_9
; %bb.27:
	ldr	x10, [x9, #320]
	sub	w8, w8, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w8, w11, x10
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB30_9
; %bb.28:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB30_9
	b	LBB30_12
LBB30_29:
	cmp	w3, w13
	b.hs	LBB30_25
; %bb.30:
	mov	w13, #168                       ; =0xa8
	umull	x13, w2, w13
	ldrb	w13, [x15, x13]
	tbnz	w13, #0, LBB30_25
; %bb.31:
	mov	w13, #56                        ; =0x38
	umaddl	x13, w3, w13, x8
	ldrb	w8, [x13]
	cmp	w8, #1
	b.eq	LBB30_25
; %bb.32:
	mov	w16, w2
	ldrb	w17, [x10, #3]
	mov	w0, #168                        ; =0xa8
	umaddl	x15, w14, w0, x15
	ldur	x1, [x15, #4]
	ldur	x15, [x15, #12]
	mov	w4, #257                        ; =0x101
	strh	w4, [x13]
	mov	w4, #2                          ; =0x2
	sub	x4, x4, x12
	strb	w12, [x13, #2]
	strb	w17, [x13, #3]
	stp	w14, w11, [x13, #4]
	str	w2, [x13, #12]
	str	xzr, [x13, #16]
	ldur	q0, [x10, #40]
	ldur	q1, [x10, #24]
	stur	q1, [x13, #24]
	stur	q0, [x13, #40]
	ldr	x10, [x9, #296]
	umaddl	x10, w16, w0, x10
	movi.4h	v0, #1
	str	s0, [x10]
	and	x11, x1, #0xffffffffffff00ff
	orr	x11, x11, x4, lsl #8
	stur	x11, [x10, #4]
	stur	x15, [x10, #12]
	str	wzr, [x10, #116]
	movi.2d	v0, #0000000000000000
	stur	q0, [x10, #100]
	stur	q0, [x10, #84]
	stur	q0, [x10, #68]
	stur	q0, [x10, #52]
	stur	q0, [x10, #36]
	stur	q0, [x10, #20]
	ldr	x9, [x9, #296]
	umaddl	x9, w16, w0, x9
	str	w3, [x9, #144]
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_reference
_fr_reference:                          ; @fr_reference
	.cfi_startproc
; %bb.0:
	ldr	w12, [x0, #132]
	cmp	w1, w12
	b.hs	LBB31_13
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldr	x10, [x8, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x9, w1, w9, x10
	ldrb	w11, [x9]
	cmp	w11, #1
	b.ne	LBB31_13
; %bb.2:
	ldr	w11, [x9, #8]
	cmp	w11, w12
	b.hs	LBB31_13
; %bb.3:
	mov	w12, #56                        ; =0x38
	umaddl	x10, w11, w12, x10
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB31_13
; %bb.4:
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB31_13
; %bb.5:
	ldr	w12, [x10, #8]
	cmp	w12, w11
	b.ne	LBB31_13
; %bb.6:
	ldrb	w11, [x10, #2]
	ldrb	w12, [x9, #2]
	cmp	w11, w12
	b.ne	LBB31_13
; %bb.7:
	ldr	x11, [x10, #48]
	ldr	x12, [x9, #48]
	cmp	x11, x12
	b.ne	LBB31_13
; %bb.8:
	ldr	w10, [x10, #4]
	ldr	w9, [x9, #4]
	cmp	w10, w9
	b.ne	LBB31_13
; %bb.9:
	ldr	w9, [x0, #128]
	cmp	w10, w9
	b.hs	LBB31_13
; %bb.10:
	ldr	x8, [x8, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w10, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB31_13
; %bb.11:
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB31_13
; %bb.12:
	ldr	w8, [x8, #16]
	cmp	w8, #1
	cset	w0, eq
	ret
LBB31_13:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_end_reference ; -- Begin function nvm_socket_runtime_end_reference
	.p2align	2
_nvm_socket_runtime_end_reference:      ; @nvm_socket_runtime_end_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB32_3
; %bb.1:
	add	x11, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x11, #586]
	tbz	w8, #0, LBB32_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB32_9
LBB32_3:
	mov	w8, #1                          ; =0x1
	b	LBB32_9
LBB32_4:
	ldr	w8, [x11, #576]
	cmp	w8, #1
	b.ne	LBB32_8
; %bb.5:
	ldr	w8, [x11, #336]
	cbnz	w8, LBB32_9
; %bb.6:
	ldrb	w8, [x11, #588]
	tbz	w8, #0, LBB32_10
LBB32_7:
	mov	w8, #5                          ; =0x5
	str	w8, [x11, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x11, #344]
	b	LBB32_9
LBB32_8:
	mov	w8, #5                          ; =0x5
LBB32_9:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB32_10:
	ldr	w8, [x0, #24]
	cbz	w8, LBB32_12
; %bb.11:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB32_31
LBB32_12:
	ldr	w8, [x0, #132]
	cmp	w1, w8
	b.hs	LBB32_48
; %bb.13:
	ldr	x9, [x11, #304]
	mov	w10, #56                        ; =0x38
	umaddl	x12, w1, w10, x9
	ldrb	w10, [x12]
	cmp	w10, #1
	b.ne	LBB32_48
; %bb.14:
	ldr	w10, [x12, #8]
	cmp	w10, w8
	b.hs	LBB32_48
; %bb.15:
	mov	w13, #56                        ; =0x38
	umaddl	x14, w10, w13, x9
	ldrb	w13, [x14]
	cmp	w13, #1
	b.ne	LBB32_48
; %bb.16:
	ldrb	w13, [x14, #1]
	tbnz	w13, #0, LBB32_48
; %bb.17:
	ldr	w13, [x14, #8]
	cmp	w13, w10
	b.ne	LBB32_48
; %bb.18:
	ldrb	w13, [x14, #2]
	ldrb	w15, [x12, #2]
	cmp	w13, w15
	b.ne	LBB32_48
; %bb.19:
	ldr	x15, [x14, #48]
	ldr	x16, [x12, #48]
	cmp	x15, x16
	b.ne	LBB32_48
; %bb.20:
	ldr	w16, [x14, #4]
	ldr	w14, [x12, #4]
	cmp	w16, w14
	b.ne	LBB32_48
; %bb.21:
	ldr	w15, [x0, #128]
	cmp	w16, w15
	b.hs	LBB32_48
; %bb.22:
	ldr	x14, [x11, #296]
	mov	w17, #168                       ; =0xa8
	umaddl	x16, w16, w17, x14
	ldrb	w17, [x16]
	cmp	w17, #1
	b.ne	LBB32_48
; %bb.23:
	ldrb	w17, [x16, #1]
	cmp	w17, #1
	b.ne	LBB32_48
; %bb.24:
	ldr	w16, [x16, #16]
	cmp	w16, #1
	b.ne	LBB32_48
; %bb.25:
	stp	x0, x12, [sp]                   ; 16-byte Folded Spill
	ldrb	w12, [x12, #1]
	cmp	w12, #1
	b.ne	LBB32_34
; %bb.26:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	cmp	w8, w15
	b.hs	LBB32_7
; %bb.27:
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w8, w9, x14
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB32_7
; %bb.28:
	ldrb	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB32_7
; %bb.29:
	ldr	w9, [x8, #144]
	cmp	w9, w1
	b.ne	LBB32_7
; %bb.30:
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	b	LBB32_55
LBB32_31:
	ldrh	w8, [x11, #584]
	cbz	x8, LBB32_7
; %bb.32:
	ldr	x9, [x11, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB32_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB32_7
	b	LBB32_12
LBB32_34:
	cbz	w13, LBB32_45
; %bb.35:
	mov	x12, #0                         ; =0x0
	mov	w13, w1
	mov	x14, x9
	b	LBB32_37
LBB32_36:                               ;   in Loop: Header=BB32_37 Depth=1
	add	x12, x12, #1
	add	x14, x14, #56
	cmp	x8, x12
	b.eq	LBB32_45
LBB32_37:                               ; =>This Inner Loop Header: Depth=1
	cmp	x13, x12
	b.eq	LBB32_36
; %bb.38:                               ;   in Loop: Header=BB32_37 Depth=1
	ldrb	w15, [x14]
	cmp	w15, #1
	b.ne	LBB32_36
; %bb.39:                               ;   in Loop: Header=BB32_37 Depth=1
	ldrb	w15, [x14, #1]
	tbnz	w15, #0, LBB32_36
; %bb.40:                               ;   in Loop: Header=BB32_37 Depth=1
	ldrb	w15, [x14, #2]
	cmp	w15, #1
	b.ne	LBB32_36
; %bb.41:                               ;   in Loop: Header=BB32_37 Depth=1
	ldr	w15, [x14, #8]
	cmp	w15, w10
	b.ne	LBB32_36
; %bb.42:
	cmp	w10, w1
	b.ne	LBB32_55
; %bb.43:
	add	x9, x9, #8
	b	LBB32_52
LBB32_44:                               ;   in Loop: Header=BB32_45 Depth=1
	add	x9, x9, #56
	subs	x8, x8, #1
	b.eq	LBB32_49
LBB32_45:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x9]
	cmp	w12, #1
	b.ne	LBB32_44
; %bb.46:                               ;   in Loop: Header=BB32_45 Depth=1
	ldrb	w12, [x9, #1]
	cmp	w12, #1
	b.ne	LBB32_44
; %bb.47:                               ;   in Loop: Header=BB32_45 Depth=1
	ldr	w12, [x9, #8]
	cmp	w12, w10
	b.ne	LBB32_44
LBB32_48:
	mov	w8, #8                          ; =0x8
	str	w8, [x11, #336]
	mov	w9, #4                          ; =0x4
	str	w9, [x11, #344]
	b	LBB32_9
LBB32_49:
	mov	w8, #1                          ; =0x1
	mov	x19, x11
	strb	w8, [x11, #586]
	ldr	x0, [x11, #328]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, x8, #24
	bl	_nl_socket_value_end_borrow
	strb	wzr, [x19, #586]
	cbz	w0, LBB32_55
; %bb.50:
	mov	x1, x0
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	b	_fr_core
LBB32_51:                               ;   in Loop: Header=BB32_52 Depth=1
	add	x9, x9, #56
	subs	x8, x8, #1
	b.eq	LBB32_55
LBB32_52:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-8]
	cmp	w10, #1
	b.ne	LBB32_51
; %bb.53:                               ;   in Loop: Header=BB32_52 Depth=1
	ldr	w10, [x9]
	cmp	w10, w13
	b.ne	LBB32_51
; %bb.54:                               ;   in Loop: Header=BB32_52 Depth=1
	str	w12, [x9]
	b	LBB32_51
LBB32_55:
	mov	w8, #0                          ; =0x0
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	xzr, [x9, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	b	LBB32_9
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_region_end  ; -- Begin function nvm_socket_runtime_region_end
	.p2align	2
_nvm_socket_runtime_region_end:         ; @nvm_socket_runtime_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB33_3
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB33_4
; %bb.2:
	mov	w8, #11                         ; =0xb
	b	LBB33_28
LBB33_3:
	mov	w0, #1                          ; =0x1
	ret
LBB33_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB33_12
; %bb.5:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB33_28
; %bb.6:
	ldrb	w8, [x20, #588]
	tbnz	w8, #0, LBB33_26
; %bb.7:
	ldr	w8, [x0, #24]
	cbz	w8, LBB33_9
; %bb.8:
	ldrb	w8, [x0, #57]
	tbz	w8, #0, LBB33_23
LBB33_9:
	ldr	w8, [x20, #596]
	cbz	w8, LBB33_26
; %bb.10:
	ldr	x10, [x20, #312]
	sub	w11, w8, #1
	ldr	w8, [x0, #132]
	cbz	w8, LBB33_37
; %bb.11:
	mov	x9, #0                          ; =0x0
	ldr	x21, [x10, w11, uxtw #3]
	ldr	x10, [x20, #304]
	mov	w11, #56                        ; =0x38
	b	LBB33_14
LBB33_12:
	mov	w8, #5                          ; =0x5
	b	LBB33_28
LBB33_13:                               ;   in Loop: Header=BB33_14 Depth=1
	add	x9, x9, #1
	cmp	x9, x8
	b.eq	LBB33_29
LBB33_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB33_19 Depth 2
	madd	x12, x9, x11, x10
	ldrb	w13, [x12]
	cmp	w13, #1
	b.ne	LBB33_13
; %bb.15:                               ;   in Loop: Header=BB33_14 Depth=1
	ldrb	w13, [x12, #1]
	tbnz	w13, #0, LBB33_13
; %bb.16:                               ;   in Loop: Header=BB33_14 Depth=1
	ldr	x12, [x12, #16]
	cmp	x12, x21
	b.ne	LBB33_13
; %bb.17:                               ;   in Loop: Header=BB33_14 Depth=1
	mov	x12, x10
	mov	x13, x8
	b	LBB33_19
LBB33_18:                               ;   in Loop: Header=BB33_19 Depth=2
	add	x12, x12, #56
	subs	x13, x13, #1
	b.eq	LBB33_13
LBB33_19:                               ;   Parent Loop BB33_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w14, [x12]
	cmp	w14, #1
	b.ne	LBB33_18
; %bb.20:                               ;   in Loop: Header=BB33_19 Depth=2
	ldrb	w14, [x12, #1]
	cmp	w14, #1
	b.ne	LBB33_18
; %bb.21:                               ;   in Loop: Header=BB33_19 Depth=2
	ldr	w14, [x12, #8]
	cmp	x9, x14
	b.ne	LBB33_18
; %bb.22:
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #336]
	mov	w9, #4                          ; =0x4
	b	LBB33_27
LBB33_23:
	ldrh	w8, [x20, #584]
	cbz	x8, LBB33_26
; %bb.24:
	ldr	x9, [x20, #320]
	sub	w8, w8, #1
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldrb	w9, [x8, #32]
	tbnz	w9, #0, LBB33_26
; %bb.25:
	ldrb	w8, [x8, #33]
	tbnz	w8, #0, LBB33_9
LBB33_26:
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #336]
	mov	w9, #8                          ; =0x8
LBB33_27:
	str	w9, [x20, #344]
LBB33_28:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB33_29:
	mov	x22, #0                         ; =0x0
	mov	x19, #0                         ; =0x0
	b	LBB33_31
LBB33_30:                               ;   in Loop: Header=BB33_31 Depth=1
	add	x19, x19, #1
	add	x22, x22, #56
	cmp	x19, x8
	b.hs	LBB33_36
LBB33_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20, #304]
	ldrb	w10, [x9, x22]
	cmp	w10, #1
	b.ne	LBB33_30
; %bb.32:                               ;   in Loop: Header=BB33_31 Depth=1
	add	x9, x9, x22
	ldrb	w10, [x9, #1]
	tbnz	w10, #0, LBB33_30
; %bb.33:                               ;   in Loop: Header=BB33_31 Depth=1
	ldr	x9, [x9, #16]
	cmp	x9, x21
	b.ne	LBB33_30
; %bb.34:                               ;   in Loop: Header=BB33_31 Depth=1
	mov	x23, x0
	mov	x1, x19
	bl	_nvm_socket_runtime_end_reference
	cbnz	w0, LBB33_38
; %bb.35:                               ;   in Loop: Header=BB33_31 Depth=1
	mov	x0, x23
	ldr	w8, [x23, #132]
	b	LBB33_30
LBB33_36:
	ldr	x10, [x20, #312]
	ldr	w8, [x20, #596]
	sub	w11, w8, #1
LBB33_37:
	mov	w8, #0                          ; =0x0
	str	w11, [x20, #596]
	str	xzr, [x10, x11, lsl #3]
	b	LBB33_28
LBB33_38:
	mov	x8, x0
	b	LBB33_28
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_service     ; -- Begin function nvm_socket_runtime_service
	.p2align	2
_nvm_socket_runtime_service:            ; @nvm_socket_runtime_service
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB34_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #704
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x21, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x21, #586]
	tbz	w8, #0, LBB34_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB34_132
LBB34_3:
	mov	w0, #1                          ; =0x1
	ret
LBB34_4:
	ldr	w8, [x21, #576]
	cmp	w8, #1
	b.ne	LBB34_131
; %bb.5:
	mov	x8, x0
	ldr	w0, [x21, #336]
	cbnz	w0, LBB34_132
; %bb.6:
	ldrb	w9, [x21, #588]
	tbz	w9, #0, LBB34_9
LBB34_7:
	mov	w0, #5                          ; =0x5
LBB34_8:
	str	w0, [x21, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #344]
	b	LBB34_132
LBB34_9:
	ldr	w9, [x8, #24]
	cbz	w9, LBB34_11
; %bb.10:
	ldrb	w10, [x8, #57]
	tbz	w10, #0, LBB34_16
LBB34_11:
	ldr	w10, [x8, #128]
	cmp	w4, w10
	b.hs	LBB34_123
; %bb.12:
	ldr	x10, [x21, #296]
	mov	w11, #168                       ; =0xa8
	umull	x11, w4, w11
	ldrb	w10, [x10, x11]
	tbnz	w10, #0, LBB34_123
; %bb.13:
	cmp	w9, #2
	mov	x19, x8
	mov	x22, x3
	mov	x23, x2
	mov	x25, x1
	mov	x26, x4
	b.eq	LBB34_19
; %bb.14:
	cbnz	w9, LBB34_20
; %bb.15:
	ldr	x0, [x8]
	add	x2, sp, #104
	mov	w1, #0                          ; =0x0
	bl	_nvm_socket_hosted_import
	tbnz	w0, #0, LBB34_21
	b	LBB34_121
LBB34_16:
	ldrh	w10, [x21, #584]
	cbz	x10, LBB34_7
; %bb.17:
	ldr	x11, [x21, #320]
	sub	w10, w10, #1
	mov	w12, #40                        ; =0x28
	umaddl	x10, w10, w12, x11
	ldrb	w11, [x10, #32]
	tbnz	w11, #0, LBB34_7
; %bb.18:
	ldrb	w10, [x10, #33]
	tbz	w10, #0, LBB34_7
	b	LBB34_11
LBB34_19:
	ldr	x0, [x8, #16]
	add	x2, sp, #104
	mov	w1, #0                          ; =0x0
	bl	_nvm_socket_indirect_hosted_import
	tbnz	w0, #0, LBB34_21
	b	LBB34_121
LBB34_20:
	ldr	x0, [x8, #8]
	add	x2, sp, #104
	mov	w1, #0                          ; =0x0
	bl	_nvm_socket_cyclic_hosted_import
	cbz	w0, LBB34_121
LBB34_21:
	ldr	w8, [sp, #104]
	cmp	w8, w25
	b.ne	LBB34_43
; %bb.22:
	mov	w24, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
LBB34_23:
	mov	x0, x19
	mov	x8, x23
	ldr	w9, [x19, #24]
	cbz	w9, LBB34_29
; %bb.24:
	ldr	x8, [x21, #320]
	ldrh	w9, [x21, #584]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	ldur	w1, [x8, #-40]
	ldurh	w2, [x8, #-36]
	ldurb	w3, [x8, #-6]
	add	x4, sp, #104
	add	x5, sp, #16
	bl	_fr_instruction
	cbz	w0, LBB34_65
; %bb.25:
	ldrb	w8, [sp, #112]
	cmp	w8, #145
	b.ne	LBB34_65
; %bb.26:
	ldr	w8, [sp, #120]
	cmp	w8, w25
	b.ne	LBB34_65
; %bb.27:
	ldr	w8, [sp, #696]
	cmp	w8, w20
	b.ne	LBB34_65
; %bb.28:
	mov	x0, x19
	mov	x8, x23
LBB34_29:
	sub	w9, w20, #4
	cmn	w9, #3
	b.hs	LBB34_46
; %bb.30:
	cmn	w8, #1
	b.ne	LBB34_63
LBB34_31:
	mov	w8, w26
	cmp	w20, #4
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b.eq	LBB34_90
; %bb.32:
	cmp	w20, #1
	b.eq	LBB34_84
; %bb.33:
	cbnz	w20, LBB34_98
; %bb.34:
	ldr	w8, [x0, #128]
	cmp	w22, w8
	b.hs	LBB34_94
; %bb.35:
	mov	x9, x22
	ldr	x8, [x21, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x1, w22, w10, x8
	ldrb	w10, [x1]
	cmp	w10, #1
	b.ne	LBB34_94
; %bb.36:
	mov	w9, w9
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w9, w10, x8
	ldr	x10, [x9, #4]!
	ldr	x11, [x19, #272]
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB34_94
; %bb.37:
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB34_94
; %bb.38:
	ldr	x10, [x19, #280]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB34_94
; %bb.39:
	ldrb	w9, [x1, #1]
	tbnz	w9, #0, LBB34_94
; %bb.40:
	ldrb	w9, [x1, #2]
	tbnz	w9, #0, LBB34_94
; %bb.41:
	ldrb	w9, [x1, #24]
	cmp	w9, #7
	b.ne	LBB34_94
; %bb.42:
	mov	w9, #1                          ; =0x1
	strb	w9, [x21, #586]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	ldr	x0, [x21, #328]
	mov	w10, #168                       ; =0xa8
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	umaddl	x8, w9, w10, x8
	add	x2, x8, #120
	bl	_fr_acquire
	b	LBB34_112
LBB34_43:
	mov	x8, x19
	ldr	w9, [x19, #24]
	cbz	w9, LBB34_70
; %bb.44:
	cmp	w9, #2
	b.ne	LBB34_71
; %bb.45:
	ldr	x0, [x8, #16]
	add	x2, sp, #104
	mov	w1, #1                          ; =0x1
	bl	_nvm_socket_indirect_hosted_import
	tbnz	w0, #0, LBB34_72
	b	LBB34_121
LBB34_46:
	ldr	w11, [x0, #132]
	cmp	w8, w11
	b.hs	LBB34_63
; %bb.47:
	ldr	x10, [x21, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x8, w8, w9, x10
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB34_63
; %bb.48:
	ldr	w9, [x8, #8]
	cmp	w9, w11
	b.hs	LBB34_63
; %bb.49:
	mov	w11, #56                        ; =0x38
	umaddl	x10, w9, w11, x10
	ldrb	w11, [x10]
	cmp	w11, #1
	b.ne	LBB34_63
; %bb.50:
	ldrb	w11, [x10, #1]
	tbnz	w11, #0, LBB34_63
; %bb.51:
	ldr	w11, [x10, #8]
	cmp	w11, w9
	b.ne	LBB34_63
; %bb.52:
	ldrb	w9, [x10, #2]
	ldrb	w11, [x8, #2]
	cmp	w9, w11
	b.ne	LBB34_63
; %bb.53:
	ldr	x11, [x10, #48]
	ldr	x12, [x8, #48]
	cmp	x11, x12
	b.ne	LBB34_63
; %bb.54:
	ldr	w10, [x10, #4]
	ldr	w8, [x8, #4]
	cmp	w10, w8
	b.ne	LBB34_63
; %bb.55:
	ldr	w8, [x0, #128]
	cmp	w10, w8
	b.hs	LBB34_63
; %bb.56:
	ldr	x8, [x21, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x11, w10, w11, x8
	ldrb	w12, [x11]
	cmp	w12, #1
	b.ne	LBB34_63
; %bb.57:
	ldrb	w12, [x11, #1]
	cmp	w12, #1
	b.ne	LBB34_63
; %bb.58:
	ldr	w11, [x11, #16]
	cmp	w11, #1
	b.ne	LBB34_63
; %bb.59:
	tbnz	w9, #0, LBB34_63
; %bb.60:
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w10, w9, x8
	ldr	x9, [x8, #4]!
	ldr	x10, [x0, #144]
	eor	x9, x10, x9
	tst	x9, #0xff
	b.ne	LBB34_94
; %bb.61:
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	tst	x9, x10
	b.ne	LBB34_94
; %bb.62:
	ldr	x9, [x0, #152]
	ldr	x8, [x8, #8]
	cmp	x8, x9
	b.eq	LBB34_31
	b	LBB34_94
LBB34_63:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB34_68
; %bb.64:
	mov	w0, #8                          ; =0x8
	b	LBB34_132
LBB34_65:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.eq	LBB34_95
; %bb.66:
	ldr	w8, [x21, #336]
	cbnz	w8, LBB34_95
; %bb.67:
	mov	w8, #6                          ; =0x6
	str	w8, [x21, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #344]
	b	LBB34_95
LBB34_68:
	ldr	w8, [x21, #336]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB34_132
; %bb.69:
	str	w0, [x21, #336]
	mov	w8, #4                          ; =0x4
	str	w8, [x21, #344]
	b	LBB34_132
LBB34_70:
	ldr	x0, [x8]
	add	x2, sp, #104
	mov	w1, #1                          ; =0x1
	bl	_nvm_socket_hosted_import
	tbnz	w0, #0, LBB34_72
	b	LBB34_121
LBB34_71:
	ldr	x0, [x8, #8]
	add	x2, sp, #104
	mov	w1, #1                          ; =0x1
	bl	_nvm_socket_cyclic_hosted_import
	cbz	w0, LBB34_121
LBB34_72:
	ldr	w8, [sp, #104]
	cmp	w8, w25
	b.ne	LBB34_74
; %bb.73:
	mov	w24, #1                         ; =0x1
	mov	w20, #1                         ; =0x1
	b	LBB34_23
LBB34_74:
	mov	x8, x19
	ldr	w9, [x19, #24]
	cbz	w9, LBB34_77
; %bb.75:
	cmp	w9, #2
	b.ne	LBB34_78
; %bb.76:
	ldr	x0, [x8, #16]
	add	x2, sp, #104
	mov	w1, #2                          ; =0x2
	bl	_nvm_socket_indirect_hosted_import
	tbnz	w0, #0, LBB34_79
	b	LBB34_121
LBB34_77:
	ldr	x0, [x8]
	add	x2, sp, #104
	mov	w1, #2                          ; =0x2
	bl	_nvm_socket_hosted_import
	tbnz	w0, #0, LBB34_79
	b	LBB34_121
LBB34_78:
	ldr	x0, [x8, #8]
	add	x2, sp, #104
	mov	w1, #2                          ; =0x2
	bl	_nvm_socket_cyclic_hosted_import
	cbz	w0, LBB34_121
LBB34_79:
	ldr	w8, [sp, #104]
	cmp	w8, w25
	b.ne	LBB34_81
; %bb.80:
	mov	w24, #0                         ; =0x0
	mov	w20, #2                         ; =0x2
	b	LBB34_23
LBB34_81:
	ldr	w8, [x19, #24]
	cbz	w8, LBB34_102
; %bb.82:
	cmp	w8, #2
	b.ne	LBB34_103
; %bb.83:
	ldr	x0, [x19, #16]
	add	x2, sp, #104
	mov	w1, #3                          ; =0x3
	bl	_nvm_socket_indirect_hosted_import
	tbz	w0, #0, LBB34_121
	b	LBB34_104
LBB34_84:
	ldr	w8, [x0, #128]
	cmp	w22, w8
	b.hs	LBB34_94
; %bb.85:
	mov	x9, x22
	ldr	x8, [x21, #296]
	mov	w10, #168                       ; =0xa8
	umull	x10, w22, w10
	ldrb	w10, [x8, x10]
	cmp	w10, #1
	b.ne	LBB34_94
; %bb.86:
	mov	w9, w9
	mov	w10, #168                       ; =0xa8
	umaddl	x10, w9, w10, x8
	ldr	x11, [x10, #4]!
	eor	x11, x11, #0xffffffff00000001
	tst	x11, #0xff
	b.ne	LBB34_94
; %bb.87:
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	tst	x11, x12
	b.ne	LBB34_94
; %bb.88:
	ldr	x10, [x10, #8]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB34_94
; %bb.89:
	mov	w10, #1                         ; =0x1
	strb	w10, [x21, #586]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	ldr	x0, [x21, #328]
	ldr	x10, [x21, #304]
	mov	w11, #56                        ; =0x38
	umaddl	x10, w23, w11, x10
	mov	w11, #168                       ; =0xa8
	umaddl	x8, w9, w11, x8
	ldr	x2, [x8, #32]
	add	x1, x10, #24
	add	x3, sp, #16
	bl	_nl_socket_value_send_byte
	b	LBB34_112
LBB34_90:
	ldr	w8, [x0, #128]
	cmp	w22, w8
	b.hs	LBB34_94
; %bb.91:
	ldr	x8, [x21, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x9, w22, w9, x8
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB34_94
; %bb.92:
	ldrb	w10, [x9, #1]
	cmp	w10, #1
	b.ne	LBB34_94
; %bb.93:
	ldur	x10, [x9, #4]
	ldr	x11, [x19, #144]
	eor	x10, x11, x10
	tst	x10, #0xff
	b.eq	LBB34_133
LBB34_94:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB34_96
LBB34_95:
	mov	w0, #6                          ; =0x6
	b	LBB34_132
LBB34_96:
	ldr	w8, [x21, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB34_132
; %bb.97:
	str	w0, [x21, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x21, #344]
	b	LBB34_132
LBB34_98:
	cmn	w22, #1
	b.ne	LBB34_121
; %bb.99:
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #586]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	cmp	w20, #2
	b.eq	LBB34_109
; %bb.100:
	cmp	w20, #3
	b.ne	LBB34_110
; %bb.101:
	ldr	x0, [x21, #328]
	ldr	x8, [x21, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x8, w23, w9, x8
	add	x1, x8, #24
	add	x2, sp, #16
	bl	_nl_socket_value_receive_byte
	b	LBB34_112
LBB34_102:
	ldr	x0, [x19]
	add	x2, sp, #104
	mov	w1, #3                          ; =0x3
	bl	_nvm_socket_hosted_import
	tbz	w0, #0, LBB34_121
	b	LBB34_104
LBB34_103:
	ldr	x0, [x19, #8]
	add	x2, sp, #104
	mov	w1, #3                          ; =0x3
	bl	_nvm_socket_cyclic_hosted_import
	cbz	w0, LBB34_121
LBB34_104:
	ldr	w8, [sp, #104]
	cmp	w8, w25
	b.ne	LBB34_106
; %bb.105:
	mov	w24, #0                         ; =0x0
	mov	w20, #3                         ; =0x3
	b	LBB34_23
LBB34_106:
	ldr	w8, [x19, #24]
	cbz	w8, LBB34_117
; %bb.107:
	cmp	w8, #2
	b.ne	LBB34_118
; %bb.108:
	ldr	x0, [x19, #16]
	add	x2, sp, #104
	mov	w1, #4                          ; =0x4
	bl	_nvm_socket_indirect_hosted_import
	tbz	w0, #0, LBB34_121
	b	LBB34_119
LBB34_109:
	ldr	x0, [x21, #328]
	ldr	x8, [x21, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x8, w23, w9, x8
	add	x1, x8, #24
	add	x2, sp, #16
	bl	_nl_socket_value_finish_connect
	b	LBB34_112
LBB34_110:
	ldr	x8, [x21, #296]
	mov	w9, #-1                         ; =0xffffffff
LBB34_111:
	ldr	x0, [x21, #328]
	mov	w10, #168                       ; =0xa8
	umaddl	x8, w9, w10, x8
	add	x1, x8, #120
	add	x2, sp, #16
	bl	_nl_socket_value_close
LBB34_112:
	mov	x1, x0
	strb	wzr, [x21, #586]
	cbz	w0, LBB34_114
; %bb.113:
	mov	x0, x19
	bl	_fr_core
	b	LBB34_132
LBB34_114:
	cmp	w20, #4
	b.eq	LBB34_125
; %bb.115:
	cbnz	w20, LBB34_126
; %bb.116:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x21, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w22, w9, x8
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	ldr	x10, [x21, #296]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	umaddl	x8, w8, w9, x10
	ldr	w9, [x19, #204]
	ldr	q1, [x19, #192]
	sub	x9, x9, #1
	cmp	x9, #2
	cset	w9, lo
	mov	w10, #1                         ; =0x1
	strb	w10, [x8]
	strb	w9, [x8, #1]
	strh	wzr, [x8, #2]
	stur	q1, [x8, #4]
	stur	q0, [x8, #20]
	stur	q0, [x8, #36]
	stur	q0, [x8, #52]
	stur	q0, [x8, #68]
	stur	q0, [x8, #84]
	stur	q0, [x8, #100]
	str	wzr, [x8, #116]
	b	LBB34_132
LBB34_117:
	ldr	x0, [x19]
	add	x2, sp, #104
	mov	w1, #4                          ; =0x4
	bl	_nvm_socket_hosted_import
	tbz	w0, #0, LBB34_121
	b	LBB34_119
LBB34_118:
	ldr	x0, [x19, #8]
	add	x2, sp, #104
	mov	w1, #4                          ; =0x4
	bl	_nvm_socket_cyclic_hosted_import
	cbz	w0, LBB34_121
LBB34_119:
	ldr	w8, [sp, #104]
	cmp	w8, w25
	b.ne	LBB34_121
; %bb.120:
	mov	w24, #0                         ; =0x0
	mov	w20, #4                         ; =0x4
	b	LBB34_23
LBB34_121:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB34_123
; %bb.122:
	mov	w0, #1                          ; =0x1
	b	LBB34_132
LBB34_123:
	ldr	w8, [x21, #336]
	mov	w0, #1                          ; =0x1
	cbnz	w8, LBB34_132
; %bb.124:
	str	w0, [x21, #336]
	str	w0, [x21, #344]
	b	LBB34_132
LBB34_125:
	ldr	x8, [x21, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w22, w9, x8
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
LBB34_126:
	add	x2, sp, #16
	add	x3, sp, #104
	mov	x0, x19
	mov	x1, x20
	bl	_fr_scalar_result
	tbz	w0, #0, LBB34_130
; %bb.127:
	add	x8, sp, #104
	cbz	w24, LBB34_129
; %bb.128:
	ldr	x9, [x21, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x9, w22, w10, x9
	str	xzr, [x9, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9]
LBB34_129:
	mov	w0, #0                          ; =0x0
	ldr	x10, [x21, #296]
	mov	w11, #168                       ; =0xa8
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	umaddl	x9, w9, w11, x10
	ldr	q0, [x8, #64]
	str	q0, [x9, #64]
	ldr	q0, [x8, #80]
	str	q0, [x9, #80]
	ldr	q0, [x8, #96]
	str	q0, [x9, #96]
	ldr	x10, [sp, #216]
	str	x10, [x9, #112]
	ldur	q0, [sp, #104]
	str	q0, [x9]
	ldur	q0, [sp, #120]
	str	q0, [x9, #16]
	ldur	q0, [sp, #136]
	str	q0, [x9, #32]
	ldr	q0, [x8, #48]
	str	q0, [x9, #48]
	b	LBB34_132
LBB34_130:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB34_136
LBB34_131:
	mov	w0, #5                          ; =0x5
LBB34_132:
	add	sp, sp, #704
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB34_133:
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB34_94
; %bb.134:
	ldr	x10, [x19, #152]
	ldur	x9, [x9, #12]
	cmp	x9, x10
	b.ne	LBB34_94
; %bb.135:
	mov	w9, w22
	mov	w10, #1                         ; =0x1
	strb	w10, [x21, #586]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #48]
	stp	q0, q0, [sp, #16]
	b	LBB34_111
LBB34_136:
	ldr	w8, [x21, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB34_132
	b	LBB34_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_acquire
_fr_acquire:                            ; @fr_acquire
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB35_3
; %bb.1:
	ldrb	w8, [x1, #24]
	cmp	w8, #7
	b.ne	LBB35_3
; %bb.2:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldp	q0, q1, [x1, #32]
	stp	q0, q1, [sp]
	ldr	q0, [x1, #64]
	str	q0, [sp, #32]
	ldr	x8, [x1, #80]
	str	x8, [sp, #48]
	mov	x1, sp
	bl	_nl_socket_values_begin_connect
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB35_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_scalar_result
_fr_scalar_result:                      ; @fr_scalar_result
	.cfi_startproc
; %bb.0:
	sub	w8, w1, #5
	cmn	w8, #4
	b.lo	LBB36_16
; %bb.1:
	ldr	w8, [x2]
Lloh30:
	adrp	x9, _fr_scalar_result.kinds@PAGE
Lloh31:
	add	x9, x9, _fr_scalar_result.kinds@PAGEOFF
	ldr	w9, [x9, w1, uxtw #2]
	cmp	w8, w9
	b.ne	LBB36_16
; %bb.2:
	ldrb	w11, [x2, #4]
	ldr	w8, [x2, #8]
	mov	w9, #1                          ; =0x1
	cmp	w8, #1
	cset	w10, eq
	cmp	w1, #3
	csel	w10, wzr, w10, ne
	cmp	w8, #0
	csel	w9, w9, w10, eq
	cmp	w9, w11
	b.ne	LBB36_16
; %bb.3:
	add	w9, w1, #3
	add	x9, x0, w9, uxtw #4
	ldr	w10, [x9, #156]
	ldr	q0, [x9, #144]
	sub	x9, x10, #1
	cmp	x9, #2
	cset	w10, lo
	cmp	w11, #0
	mov	w9, #2                          ; =0x2
	cinc	w9, w9, eq
	tbz	w11, #0, LBB36_8
; %bb.4:
	ldr	x8, [x2, #48]
	cmp	w1, #3
	b.eq	LBB36_10
; %bb.5:
	cmp	w1, #1
	b.ne	LBB36_14
; %bb.6:
	cmp	x8, #1
	b.hi	LBB36_16
; %bb.7:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	mov	w15, #1                         ; =0x1
	b	LBB36_18
LBB36_8:
	ldr	x12, [x2, #24]
	tbnz	x12, #63, LBB36_16
; %bb.9:
	ldrb	w11, [x2, #44]
	ldr	s1, [x2, #40]
	ushll.8h	v2, v1, #0
	ldr	d1, [x2, #32]
	ldpsw	x14, x13, [x2, #12]
	ushll.2d	v1, v1, #0
	ushll.4s	v2, v2, #0
	ushll2.2d	v3, v2, #0
	movi.2d	v4, #0x000000000000ff
	and.16b	v3, v3, v4
	ushll.2d	v2, v2, #0
	and.16b	v2, v2, v4
	mov	w15, #11                        ; =0xb
	b	LBB36_19
LBB36_10:
	cmp	x8, #255
	b.hi	LBB36_16
; %bb.11:
	ldrb	w14, [x2, #56]
	cbz	x8, LBB36_13
; %bb.12:
	tbnz	w14, #0, LBB36_16
LBB36_13:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	and	x14, x14, #0x1
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	mov	w15, #2                         ; =0x2
	b	LBB36_18
LBB36_14:
	cbnz	x8, LBB36_16
; %bb.15:
	ldrb	w8, [x2, #56]
	tbz	w8, #0, LBB36_17
LBB36_16:
	mov	w0, #0                          ; =0x0
	ret
LBB36_17:
	mov	x11, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	x13, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	w15, #0                         ; =0x0
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
LBB36_18:
	movi.2d	v3, #0000000000000000
LBB36_19:
	mov	w0, #1                          ; =0x1
	strb	w0, [x3]
	strb	w10, [x3, #1]
	strh	wzr, [x3, #2]
	stur	q0, [x3, #4]
	str	w9, [x3, #20]
	strb	w15, [x3, #24]
	stur	wzr, [x3, #25]
	str	wzr, [x3, #28]
	stp	x8, x14, [x3, #32]
	stp	x13, x12, [x3, #48]
	stp	q1, q2, [x3, #64]
	str	q3, [x3, #96]
	str	x11, [x3, #112]
	ret
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_complete_root ; -- Begin function nvm_socket_runtime_complete_root
	.p2align	2
_nvm_socket_runtime_complete_root:      ; @nvm_socket_runtime_complete_root
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB37_3
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #688
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB37_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB37_53
LBB37_3:
	mov	w0, #1                          ; =0x1
	ret
LBB37_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB37_52
; %bb.5:
	mov	x8, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB37_53
; %bb.6:
	ldrb	w9, [x20, #588]
	tbz	w9, #0, LBB37_9
LBB37_7:
	mov	w0, #5                          ; =0x5
LBB37_8:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB37_53
LBB37_9:
	mov	x0, x8
	ldr	w9, [x8, #24]
	cbz	w9, LBB37_16
; %bb.10:
	ldrb	w9, [x0, #57]
	tbz	w9, #0, LBB37_23
LBB37_11:
	ldrh	w9, [x20, #584]
	cmp	w9, #1
	b.ne	LBB37_37
; %bb.12:
	mov	x19, x1
	ldr	x9, [x20, #320]
	ldr	w1, [x9]
	ldrh	w2, [x9, #4]
	ldrb	w3, [x9, #34]
	add	x4, sp, #88
	add	x5, sp, #8
	mov	x0, x8
	mov	x21, x8
	bl	_fr_instruction
	cbz	w0, LBB37_36
; %bb.13:
	ldrb	w8, [sp, #96]
	cmp	w8, #61
	b.ne	LBB37_36
; %bb.14:
	ldrb	w8, [sp, #9]
	tbz	w8, #0, LBB37_36
; %bb.15:
	mov	x0, x21
	mov	x1, x19
LBB37_16:
	mov	x23, x1
	ldr	w19, [x20, #592]
	ldr	w21, [x0, #68]
	add	x2, sp, #8
	mov	x22, x0
	mov	x1, x19
	bl	_fr_function
	tbz	w0, #0, LBB37_51
; %bb.17:
	cmp	w19, w21
	b.ne	LBB37_26
; %bb.18:
	cmn	w23, #1
	b.ne	LBB37_34
; %bb.19:
	mov	x8, x23
	mov	x9, x22
	ldrb	w10, [sp, #24]
	cbnz	w10, LBB37_34
LBB37_20:
	ldr	w10, [x20, #596]
	cbz	w10, LBB37_41
LBB37_21:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB37_55
; %bb.22:
	mov	w0, #8                          ; =0x8
	b	LBB37_53
LBB37_23:
	ldrh	w9, [x20, #584]
	cbz	x9, LBB37_7
; %bb.24:
	ldr	x10, [x20, #320]
	sub	w9, w9, #1
	mov	w11, #40                        ; =0x28
	umaddl	x9, w9, w11, x10
	ldrb	w10, [x9, #32]
	tbnz	w10, #0, LBB37_7
; %bb.25:
	ldrb	w9, [x9, #33]
	tbz	w9, #0, LBB37_7
	b	LBB37_11
LBB37_26:
	ldr	w10, [x22, #128]
	cmp	w23, w10
	b.hs	LBB37_34
; %bb.27:
	mov	x8, x23
	ldr	x11, [x20, #296]
	mov	w10, #168                       ; =0xa8
	umaddl	x10, w23, w10, x11
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB37_34
; %bb.28:
	mov	w12, w8
	mov	w13, #168                       ; =0xa8
	umaddl	x12, w12, w13, x11
	ldr	x11, [x12, #4]!
	ldur	x13, [sp, #28]
	eor	x13, x13, x11
	tst	x13, #0xff
	b.ne	LBB37_34
; %bb.29:
	ldur	x14, [sp, #36]
	ldr	x12, [x12, #8]
	and	x13, x13, #0xffffffffffffff00
	and	x13, x13, #0xffffffff0000ffff
	cmp	x13, #0
	ccmp	x12, x14, #0, eq
	b.ne	LBB37_34
; %bb.30:
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB37_34
; %bb.31:
	ldrb	w10, [x10, #2]
	tbnz	w10, #0, LBB37_34
; %bb.32:
	mov	x9, x22
	and	w10, w11, #0xff
	cmp	w10, #1
	b.eq	LBB37_20
; %bb.33:
	cmp	w10, #4
	b.eq	LBB37_20
LBB37_34:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB37_39
; %bb.35:
	mov	w0, #6                          ; =0x6
	b	LBB37_53
LBB37_36:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB37_52
LBB37_37:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB37_52
; %bb.38:
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB37_52
LBB37_39:
	ldr	w8, [x20, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB37_53
; %bb.40:
	str	w0, [x20, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #344]
	b	LBB37_53
LBB37_41:
	ldr	w10, [x9, #132]
	cbz	w10, LBB37_45
; %bb.42:
	ldr	x11, [x20, #304]
LBB37_43:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x11], #56
	cmp	w12, #1
	b.eq	LBB37_21
; %bb.44:                               ;   in Loop: Header=BB37_43 Depth=1
	subs	x10, x10, #1
	b.ne	LBB37_43
LBB37_45:
	ldr	w10, [x9, #128]
	cbz	w10, LBB37_57
; %bb.46:
	ldr	x11, [x20, #296]
	add	x11, x11, #2
	mov	x12, x10
	b	LBB37_48
LBB37_47:                               ;   in Loop: Header=BB37_48 Depth=1
	add	x11, x11, #168
	subs	x12, x12, #1
	b.eq	LBB37_57
LBB37_48:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-2]
	cmp	w13, #1
	b.ne	LBB37_47
; %bb.49:                               ;   in Loop: Header=BB37_48 Depth=1
	ldurb	w13, [x11, #-1]
	tbnz	w13, #0, LBB37_51
; %bb.50:                               ;   in Loop: Header=BB37_48 Depth=1
	ldrb	w13, [x11]
	cmp	w13, #1
	b.ne	LBB37_47
LBB37_51:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB37_54
LBB37_52:
	mov	w0, #5                          ; =0x5
LBB37_53:
	add	sp, sp, #688
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB37_54:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB37_53
	b	LBB37_8
LBB37_55:
	ldr	w8, [x20, #336]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB37_53
; %bb.56:
	str	w0, [x20, #336]
	mov	w8, #4                          ; =0x4
	str	w8, [x20, #344]
	b	LBB37_53
LBB37_57:
	cmp	w19, w21
	b.ne	LBB37_62
; %bb.58:
	ldr	x0, [x20, #328]
	add	x1, sp, #88
	bl	_nl_socket_values_report
	tbz	w0, #0, LBB37_66
; %bb.59:
	ldr	w8, [sp, #88]
	cbnz	w8, LBB37_69
; %bb.60:
	ldr	x9, [sp, #96]
	cbnz	x9, LBB37_69
; %bb.61:
	ldr	x0, [x20, #296]
	ldr	w10, [x22, #128]
	b	LBB37_63
LBB37_62:
	mov	w11, #33224                     ; =0x81c8
	add	x9, x9, x11
	ldr	x0, [x20, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x8, w8, w11, x0
	ldp	q0, q1, [x8, #32]
	ldp	q3, q2, [x8]
	stp	q0, q1, [x9, #32]
	stp	q3, q2, [x9]
	ldp	q1, q0, [x8, #80]
	ldr	x11, [x8, #112]
	ldr	q2, [x8, #64]
	str	x11, [x9, #112]
	stp	q1, q0, [x9, #80]
	str	q2, [x9, #64]
LBB37_63:
	mov	w8, #168                        ; =0xa8
	umull	x1, w10, w8
	bl	_bzero
	ldr	x0, [x20, #320]
	ldrh	w8, [x22, #140]
	add	x8, x8, x8, lsl #2
	lsl	x1, x8, #3
	bl	_bzero
	strh	wzr, [x20, #584]
	cmp	w19, w21
	b.ne	LBB37_65
; %bb.64:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x22, #64]
	str	w8, [x20, #592]
	b	LBB37_53
LBB37_65:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #588]
	b	LBB37_53
LBB37_66:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB37_52
; %bb.67:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB37_53
; %bb.68:
	mov	w8, #8                          ; =0x8
	b	LBB37_72
LBB37_69:
	ldr	w9, [x20, #576]
	cmp	w9, #2
	b.ne	LBB37_71
; %bb.70:
	mov	w0, #10                         ; =0xa
	b	LBB37_53
LBB37_71:
	ldr	w9, [x20, #336]
	mov	w0, #10                         ; =0xa
	cbnz	w9, LBB37_53
LBB37_72:
	str	w0, [x20, #336]
	str	w8, [x20, #344]
	b	LBB37_53
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_function
_fr_function:                           ; @fr_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.eq	LBB38_3
; %bb.1:
	cbnz	w8, LBB38_4
; %bb.2:
	ldr	x0, [x0]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	b	_nvm_socket_hosted_function
LBB38_3:
	mov	x19, x2
	ldr	x0, [x0, #16]
	add	x2, sp, #8
	bl	_nvm_socket_indirect_hosted_function
	b	LBB38_5
LBB38_4:
	mov	x19, x2
	ldr	x0, [x0, #8]
	add	x2, sp, #8
	bl	_nvm_socket_cyclic_hosted_function
LBB38_5:
	ldrb	w8, [sp, #88]
	tst	w8, #0xff
	csel	w0, wzr, w0, ne
	cmp	w0, #1
	b.ne	LBB38_7
; %bb.6:
	ldrh	w8, [sp, #52]
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldr	w9, [sp, #40]
	str	w9, [x19, #32]
	ldur	d0, [sp, #44]
	stur	d0, [x19, #36]
	strh	w8, [x19, #44]
	strh	wzr, [x19, #46]
	ldur	d0, [sp, #60]
	str	d0, [x19, #48]
	ldur	q0, [sp, #72]
	stur	q0, [x19, #56]
LBB38_7:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_finish      ; -- Begin function nvm_socket_runtime_finish
	.p2align	2
_nvm_socket_runtime_finish:             ; @nvm_socket_runtime_finish
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB39_3
; %bb.1:
	ldr	w9, [x0, #24]
	cbz	w9, LBB39_3
; %bb.2:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	str	q0, [x8, #32]
	mov	w9, #5                          ; =0x5
	str	w9, [x8]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #12]
	ret
LBB39_3:
	b	_fr_finish
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_finish
_fr_finish:                             ; @fr_finish
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x8
	cbz	x0, LBB40_3
; %bb.1:
	mov	x21, x0
	add	x22, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x22, #586]
	cmp	w8, #1
	b.ne	LBB40_5
; %bb.2:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	str	q0, [x19, #32]
	mov	w8, #11                         ; =0xb
	b	LBB40_4
LBB40_3:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	str	q0, [x19, #32]
	mov	w8, #1                          ; =0x1
LBB40_4:
	str	w8, [x19]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x19, #12]
	b	LBB40_89
LBB40_5:
	mov	x20, x1
	ldr	w8, [x22, #576]
	cmp	w8, #2
	b.ne	LBB40_7
; %bb.6:
	cbnz	x20, LBB40_86
	b	LBB40_88
LBB40_7:
	ldrb	w8, [x22, #588]
	tbnz	w8, #0, LBB40_10
; %bb.8:
	ldr	w8, [x22, #336]
	cbnz	w8, LBB40_10
; %bb.9:
	mov	w8, #5                          ; =0x5
	str	w8, [x22, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x22, #344]
LBB40_10:
	mov	w8, #1                          ; =0x1
	strb	w8, [x22, #586]
	ldr	w13, [x21, #132]
	cbz	w13, LBB40_49
; %bb.11:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w10, #168                       ; =0xa8
	movi.2d	v0, #0000000000000000
	mov	w11, #5                         ; =0x5
	mov	w12, #8                         ; =0x8
	b	LBB40_15
LBB40_12:                               ;   in Loop: Header=BB40_15 Depth=1
	str	xzr, [x13, #160]
	stp	q0, q0, [x13, #128]
	stp	q0, q0, [x13, #96]
	stp	q0, q0, [x13, #64]
	stp	q0, q0, [x13, #32]
	stp	q0, q0, [x13]
	ldr	x14, [x22, #304]
LBB40_13:                               ;   in Loop: Header=BB40_15 Depth=1
	add	x13, x14, x8
	str	xzr, [x13, #48]
	stp	q0, q0, [x13, #16]
	str	q0, [x13]
	ldr	w13, [x21, #132]
LBB40_14:                               ;   in Loop: Header=BB40_15 Depth=1
	add	x9, x9, #1
	add	x8, x8, #56
	cmp	x9, x13
	b.hs	LBB40_23
LBB40_15:                               ; =>This Inner Loop Header: Depth=1
	ldr	x14, [x22, #304]
	ldrb	w15, [x14, x8]
	cmp	w15, #1
	b.ne	LBB40_14
; %bb.16:                               ;   in Loop: Header=BB40_15 Depth=1
	add	x15, x14, x8
	ldrb	w16, [x15, #1]
	cmp	w16, #1
	b.ne	LBB40_14
; %bb.17:                               ;   in Loop: Header=BB40_15 Depth=1
	ldr	w13, [x15, #12]
	ldr	w15, [x21, #128]
	cmp	w13, w15
	b.hs	LBB40_20
; %bb.18:                               ;   in Loop: Header=BB40_15 Depth=1
	ldr	x15, [x22, #296]
	umaddl	x13, w13, w10, x15
	ldrb	w15, [x13, #2]
	cmp	w15, #1
	b.ne	LBB40_20
; %bb.19:                               ;   in Loop: Header=BB40_15 Depth=1
	ldr	w15, [x13, #144]
	cmp	x9, x15
	b.eq	LBB40_12
LBB40_20:                               ;   in Loop: Header=BB40_15 Depth=1
	ldr	w13, [x22, #576]
	cmp	w13, #2
	b.eq	LBB40_13
; %bb.21:                               ;   in Loop: Header=BB40_15 Depth=1
	ldr	w13, [x22, #336]
	cbnz	w13, LBB40_13
; %bb.22:                               ;   in Loop: Header=BB40_15 Depth=1
	str	w11, [x22, #336]
	str	w12, [x22, #344]
	b	LBB40_13
LBB40_23:
	ldrb	w8, [x22, #587]
	tbz	w8, #0, LBB40_73
; %bb.24:
	cbz	x13, LBB40_50
; %bb.25:
	mov	x23, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	b	LBB40_28
LBB40_26:                               ;   in Loop: Header=BB40_28 Depth=1
	ldr	x8, [x22, #304]
	add	x8, x8, x23
	str	xzr, [x8, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	ldr	w13, [x21, #132]
LBB40_27:                               ;   in Loop: Header=BB40_28 Depth=1
	add	x24, x24, #1
	add	x23, x23, #56
	cmp	x24, x13
	b.hs	LBB40_50
LBB40_28:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22, #304]
	ldrb	w9, [x8, x23]
	cmp	w9, #1
	b.ne	LBB40_27
; %bb.29:                               ;   in Loop: Header=BB40_28 Depth=1
	add	x8, x8, x23
	ldrb	w9, [x8, #2]
	cmp	w9, #1
	b.ne	LBB40_31
; %bb.30:                               ;   in Loop: Header=BB40_28 Depth=1
	ldr	w9, [x8, #8]
	cmp	x24, x9
	b.ne	LBB40_26
LBB40_31:                               ;   in Loop: Header=BB40_28 Depth=1
	ldr	x0, [x22, #328]
	add	x1, x8, #24
	bl	_nl_socket_value_end_borrow
	cmp	w0, #2
	b.le	LBB40_36
; %bb.32:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #4
	b.gt	LBB40_40
; %bb.33:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #3
	b.eq	LBB40_44
; %bb.34:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #4
	b.ne	LBB40_43
; %bb.35:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB40_46
LBB40_36:                               ;   in Loop: Header=BB40_28 Depth=1
	cbz	w0, LBB40_26
; %bb.37:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB40_46
; %bb.38:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #2
	b.ne	LBB40_43
; %bb.39:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB40_46
LBB40_40:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #5
	b.eq	LBB40_45
; %bb.41:                               ;   in Loop: Header=BB40_28 Depth=1
	cmp	w0, #6
	b.ne	LBB40_43
; %bb.42:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB40_46
LBB40_43:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB40_46
LBB40_44:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #6                          ; =0x6
	b	LBB40_46
LBB40_45:                               ;   in Loop: Header=BB40_28 Depth=1
	mov	w8, #3                          ; =0x3
LBB40_46:                               ;   in Loop: Header=BB40_28 Depth=1
	ldr	w9, [x22, #576]
	cmp	w9, #2
	b.eq	LBB40_26
; %bb.47:                               ;   in Loop: Header=BB40_28 Depth=1
	ldr	w9, [x22, #336]
	cbnz	w9, LBB40_26
; %bb.48:                               ;   in Loop: Header=BB40_28 Depth=1
	str	w8, [x22, #336]
	str	w0, [x22, #344]
	b	LBB40_26
LBB40_49:
	ldrb	w8, [x22, #587]
	tbz	w8, #0, LBB40_73
LBB40_50:
	ldr	w8, [x21, #128]
	cbz	w8, LBB40_75
; %bb.51:
	mov	x23, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	b	LBB40_53
LBB40_52:                               ;   in Loop: Header=BB40_53 Depth=1
	ldr	x8, [x22, #296]
	add	x8, x8, x23
	str	xzr, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	add	x24, x24, #1
	ldr	w8, [x21, #128]
	add	x23, x23, #168
	cmp	x24, x8
	b.hs	LBB40_75
LBB40_53:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22, #296]
	ldrb	w9, [x8, x23]
	cmp	w9, #1
	b.ne	LBB40_52
; %bb.54:                               ;   in Loop: Header=BB40_53 Depth=1
	add	x8, x8, x23
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB40_52
; %bb.55:                               ;   in Loop: Header=BB40_53 Depth=1
	ldr	x0, [x22, #328]
	add	x1, x8, #120
	bl	_nl_socket_value_drop
	cmp	w0, #2
	b.le	LBB40_60
; %bb.56:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #4
	b.gt	LBB40_64
; %bb.57:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #3
	movi.2d	v0, #0000000000000000
	b.eq	LBB40_68
; %bb.58:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #4
	b.ne	LBB40_67
; %bb.59:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB40_70
LBB40_60:                               ;   in Loop: Header=BB40_53 Depth=1
	movi.2d	v0, #0000000000000000
	cbz	w0, LBB40_52
; %bb.61:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	x8, x0
	cmp	w0, #1
	b.eq	LBB40_70
; %bb.62:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #2
	b.ne	LBB40_67
; %bb.63:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB40_70
LBB40_64:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #5
	movi.2d	v0, #0000000000000000
	b.eq	LBB40_69
; %bb.65:                               ;   in Loop: Header=BB40_53 Depth=1
	cmp	w0, #6
	b.ne	LBB40_67
; %bb.66:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB40_70
LBB40_67:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB40_70
LBB40_68:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #6                          ; =0x6
	b	LBB40_70
LBB40_69:                               ;   in Loop: Header=BB40_53 Depth=1
	mov	w8, #3                          ; =0x3
LBB40_70:                               ;   in Loop: Header=BB40_53 Depth=1
	ldr	w9, [x22, #576]
	cmp	w9, #2
	b.eq	LBB40_52
; %bb.71:                               ;   in Loop: Header=BB40_53 Depth=1
	ldr	w9, [x22, #336]
	cbnz	w9, LBB40_52
; %bb.72:                               ;   in Loop: Header=BB40_53 Depth=1
	str	w8, [x22, #336]
	str	w0, [x22, #344]
	b	LBB40_52
LBB40_73:
	ldr	w8, [x22, #344]
	mov	w9, #33128                      ; =0x8168
LBB40_74:
	str	w8, [x21, x9]
	b	LBB40_82
LBB40_75:
	ldr	w8, [x22, #336]
	cbz	w8, LBB40_77
; %bb.76:
	ldr	w8, [x22, #344]
	mov	w9, #8                          ; =0x8
	cmp	w8, #0
	csel	w1, w9, w8, eq
	b	LBB40_78
LBB40_77:
	mov	w1, #0                          ; =0x0
LBB40_78:
	add	x23, x22, #360
	ldr	x0, [x22, #328]
	mov	x8, sp
	bl	_nl_socket_values_destroy
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x23, #32]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x23, #64]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x23]
	str	xzr, [x22, #328]
	ldr	w8, [x22, #336]
	cbnz	w8, LBB40_82
; %bb.79:
	ldr	w8, [x23]
	cbnz	w8, LBB40_81
; %bb.80:
	ldr	x9, [x22, #368]
	cbz	x9, LBB40_82
LBB40_81:
	ldr	w9, [x22, #576]
	cmp	w9, #2
	b.ne	LBB40_90
LBB40_82:
	ldr	x0, [x22, #312]
	ldr	w8, [x21, #136]
	lsl	x1, x8, #3
	bl	_bzero
	str	wzr, [x22, #596]
	ldr	w8, [x22, #288]
	cbz	w8, LBB40_85
; %bb.83:
	mov	x23, #0                         ; =0x0
	add	x24, x21, #288
LBB40_84:                               ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x24, x23, lsl #3]
	bl	_free
	str	xzr, [x24, x23, lsl #3]
	add	x23, x23, #1
	ldr	w8, [x22, #288]
	cmp	x23, x8
	b.lo	LBB40_84
LBB40_85:
	str	wzr, [x22, #288]
	strh	wzr, [x22, #584]
	strb	wzr, [x22, #586]
	mov	w8, #2                          ; =0x2
	str	w8, [x22, #576]
	cbz	x20, LBB40_88
LBB40_86:
	ldr	w8, [x22, #336]
	cbnz	w8, LBB40_88
; %bb.87:
	mov	w8, #33224                      ; =0x81c8
	add	x8, x21, x8
	ldp	q0, q1, [x8]
	ldp	q2, q3, [x8, #32]
	stp	q2, q3, [x20, #32]
	stp	q0, q1, [x20]
	ldp	q0, q1, [x8, #64]
	ldr	q2, [x8, #96]
	ldr	x8, [x8, #112]
	str	x8, [x20, #112]
	stp	q1, q2, [x20, #80]
	str	q0, [x20, #64]
LBB40_88:
	ldp	q0, q1, [x22, #400]
	stp	q0, q1, [x19, #64]
	ldr	q0, [x22, #432]
	str	q0, [x19, #96]
	ldr	x8, [x22, #448]
	str	x8, [x19, #112]
	ldp	q0, q1, [x22, #336]
	stp	q0, q1, [x19]
	ldp	q0, q1, [x22, #368]
	stp	q0, q1, [x19, #32]
LBB40_89:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB40_90:
	mov	w9, #10                         ; =0xa
	str	w9, [x22, #336]
	mov	w9, #33112                      ; =0x8158
	b	LBB40_74
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_destroy     ; -- Begin function nvm_socket_runtime_destroy
	.p2align	2
_nvm_socket_runtime_destroy:            ; @nvm_socket_runtime_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x0, LBB41_4
; %bb.1:
	ldr	x19, [x0]
	cbz	x19, LBB41_4
; %bb.2:
	ldr	w9, [x19, #24]
	cbz	w9, LBB41_7
; %bb.3:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	str	q0, [x8, #32]
	mov	w9, #5                          ; =0x5
	b	LBB41_5
LBB41_4:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	str	q0, [x8, #32]
	mov	w9, #1                          ; =0x1
LBB41_5:
	str	w9, [x8]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #12]
LBB41_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB41_7:
	add	x20, x19, #8, lsl #12           ; =32768
	ldrb	w9, [x20, #586]
	cmp	w9, #1
	b.ne	LBB41_9
; %bb.8:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	xzr, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	str	q0, [x8, #32]
	mov	w9, #11                         ; =0xb
	b	LBB41_5
LBB41_9:
	mov	x21, x0
	mov	x0, x19
	bl	_fr_finish
	ldr	x0, [x20, #320]
	bl	_free
	ldr	x0, [x20, #312]
	bl	_free
	ldr	x0, [x20, #304]
	bl	_free
	ldr	x0, [x20, #296]
	bl	_free
	ldr	x0, [x19]
	bl	_nvm_socket_hosted_free
	mov	x0, x19
	bl	_free
	str	xzr, [x21]
	b	LBB41_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_start ; -- Begin function nvm_socket_runtime_frame_start
	.p2align	2
_nvm_socket_runtime_frame_start:        ; @nvm_socket_runtime_frame_start
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB42_3
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #800
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	add	x21, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x21, #586]
	tbz	w8, #0, LBB42_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB42_14
LBB42_3:
	mov	w0, #1                          ; =0x1
	ret
LBB42_4:
	ldr	w8, [x21, #576]
	cmp	w8, #1
	b.ne	LBB42_13
; %bb.5:
	ldr	w0, [x21, #336]
	cbnz	w0, LBB42_14
; %bb.6:
	ldrb	w8, [x21, #588]
	cmp	w8, #1
	b.ne	LBB42_9
; %bb.7:
	mov	w0, #5                          ; =0x5
LBB42_8:
	str	w0, [x21, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #344]
	b	LBB42_14
LBB42_9:
	ldrb	w8, [x21, #587]
	cmp	w8, #1
	b.ne	LBB42_12
; %bb.10:
	ldrh	w8, [x21, #584]
	cbnz	w8, LBB42_12
; %bb.11:
	ldr	w8, [x21, #596]
	cbz	w8, LBB42_16
LBB42_12:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB42_15
LBB42_13:
	mov	w0, #5                          ; =0x5
LBB42_14:
	add	sp, sp, #800
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB42_15:
	ldr	w8, [x21, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB42_14
	b	LBB42_8
LBB42_16:
	ldrh	w8, [x20, #140]
	cbz	w8, LBB42_12
; %bb.17:
	ldr	w19, [x21, #592]
	add	x2, sp, #8
	mov	x0, x20
	mov	x1, x19
	bl	_fr_function
	cbz	w0, LBB42_12
; %bb.18:
	ldrh	w10, [sp, #50]
	cbz	x10, LBB42_12
; %bb.19:
	ldrh	w9, [sp, #48]
	ldrh	w11, [sp, #22]
	cmp	w9, w11
	b.ne	LBB42_12
; %bb.20:
	mov	x8, x20
	ldr	w11, [x21, #580]
	cmp	w11, #0
	mov	w11, #64                        ; =0x40
	mov	w12, #56                        ; =0x38
	csel	x11, x12, x11, eq
	add	x12, sp, #8
	ldr	x12, [x12, x11]
	ldr	w11, [x20, #128]
	cmp	x12, x11
	b.hi	LBB42_12
; %bb.21:
	add	x10, x9, x10
	subs	x11, x11, x10
	b.lo	LBB42_12
; %bb.22:
	ldrh	w12, [sp, #46]
	cmp	x11, x12
	b.lo	LBB42_12
; %bb.23:
	ldr	w11, [x8, #132]
	cmp	w11, #256
	b.lo	LBB42_12
; %bb.24:
	ldrh	w11, [sp, #52]
	ldrh	w12, [x8, #140]
	cmp	w12, w11
	b.lo	LBB42_12
; %bb.25:
	ldr	w11, [x21, #596]
	stp	w19, wzr, [sp, #80]
	stp	wzr, w10, [sp, #88]
	stp	wzr, w9, [sp, #96]
	stp	wzr, w11, [sp, #104]
	str	xzr, [sp, #112]
	ldrh	w9, [sp, #20]
	cbnz	w9, LBB42_12
; %bb.26:
	ldr	w1, [x21, #592]
	add	x4, sp, #200
	add	x5, sp, #120
	mov	x0, x8
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_fr_instruction
	cbz	w0, LBB42_12
; %bb.27:
	ldrb	w8, [sp, #120]
	tbz	w8, #0, LBB42_12
; %bb.28:
	ldrh	w9, [sp, #124]
	cbnz	w9, LBB42_12
; %bb.29:
	ldr	w8, [x20, #128]
	cbz	w8, LBB42_33
; %bb.30:
	ldr	x9, [x21, #296]
LBB42_31:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #168
	tbnz	w10, #0, LBB42_12
; %bb.32:                               ;   in Loop: Header=BB42_31 Depth=1
	subs	x8, x8, #1
	b.ne	LBB42_31
LBB42_33:
	ldr	w8, [x20, #132]
	cbz	w8, LBB42_37
; %bb.34:
	ldr	x9, [x21, #304]
LBB42_35:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #56
	cmp	w10, #1
	b.eq	LBB42_12
; %bb.36:                               ;   in Loop: Header=BB42_35 Depth=1
	subs	x8, x8, #1
	b.ne	LBB42_35
LBB42_37:
	ldr	x8, [x21, #320]
	ldp	q0, q1, [sp, #80]
	stp	q0, q1, [x8]
	ldr	x9, [sp, #112]
	str	x9, [x8, #32]
	mov	w8, #1                          ; =0x1
	strh	w8, [x21, #584]
	ldr	w8, [x20, #24]
	cbz	w8, LBB42_40
; %bb.38:
	add	x1, sp, #80
	mov	x0, x20
	bl	_frc_validate
	cbz	w0, LBB42_40
; %bb.39:
	ldr	w0, [x21, #336]
	b	LBB42_14
LBB42_40:
	mov	x0, x20
	mov	x1, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_socket_runtime_site
	b	LBB42_14
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_layout
_frf_layout:                            ; @frf_layout
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x0, #140]
	cmp	w3, w8
	b.hs	LBB43_9
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x5
	mov	x20, x3
	mov	x23, x2
	mov	x21, x4
	mov	x24, x0
	mov	x22, x1
	mov	x2, x5
	bl	_fr_function
	cbz	w0, LBB43_8
; %bb.2:
	ldrh	w12, [x19, #42]
	cbz	x12, LBB43_7
; %bb.3:
	ldrh	w11, [x19, #40]
	ldrh	w8, [x19, #14]
	cmp	w11, w8
	b.ne	LBB43_7
; %bb.4:
	mov	w0, #0                          ; =0x0
	add	x8, x24, #8, lsl #12            ; =32768
	ldr	w9, [x8, #580]
	cmp	w9, #0
	mov	w9, #64                         ; =0x40
	mov	w13, #56                        ; =0x38
	csel	x14, x13, x9, eq
	ldr	w13, [x24, #128]
	subs	x15, x13, x23
	b.lo	LBB43_8
; %bb.5:
	mov	x9, x23
	ldr	x14, [x19, x14]
	add	x11, x23, x11
	add	x12, x11, x12
	cmp	x14, x15
	ccmp	x13, x12, #0, ls
	b.lo	LBB43_8
; %bb.6:
	ldrh	w14, [x19, #38]
	sub	x13, x13, x12
	cmp	x13, x14
	b.hs	LBB43_10
LBB43_7:
	mov	w0, #0                          ; =0x0
LBB43_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB43_9:
	mov	w0, #0                          ; =0x0
	ret
LBB43_10:
	mov	x10, x24
	mov	w0, #0                          ; =0x0
	ubfiz	x13, x20, #8, #32
	ldr	w14, [x24, #132]
	subs	x14, x14, x13
	b.lo	LBB43_8
; %bb.11:
	cmp	x14, #256
	b.lo	LBB43_8
; %bb.12:
	ldrh	w14, [x19, #44]
	ldrh	w10, [x10, #140]
	sub	w10, w10, w20
	cmp	w10, w14
	b.lt	LBB43_7
; %bb.13:
	ldr	w8, [x8, #596]
	stp	w22, wzr, [x21]
	stp	w9, w12, [x21, #8]
	stp	wzr, w11, [x21, #16]
	stp	w13, w8, [x21, #24]
	str	xzr, [x21, #32]
	mov	w0, #1                          ; =0x1
	b	LBB43_8
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_empty_range
_frf_empty_range:                       ; @frf_empty_range
	.cfi_startproc
; %bb.0:
	mov	w11, w1
	mov	w8, w2
	ldr	w9, [x0, #128]
	sub	x10, x9, x11
	subs	w9, w9, w1
	ccmp	x10, x8, #0, hs
	b.hs	LBB44_2
LBB44_1:
	mov	w0, #0                          ; =0x0
	ret
LBB44_2:
	cbz	w2, LBB44_7
; %bb.3:
	mov	w10, #33064                     ; =0x8128
	mov	w12, #168                       ; =0xa8
	umull	x11, w11, w12
LBB44_4:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB44_1
; %bb.5:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x12, [x0, x10]
	ldrb	w12, [x12, x11]
	cmp	w12, #1
	b.eq	LBB44_1
; %bb.6:                                ;   in Loop: Header=BB44_4 Depth=1
	add	x11, x11, #168
	sub	x9, x9, #1
	subs	x8, x8, #1
	b.ne	LBB44_4
LBB44_7:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_validate
_frc_validate:                          ; @frc_validate
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #736
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x21, x0, #8, lsl #12            ; =32768
	ldr	w8, [x0, #24]
	cbz	w8, LBB45_66
; %bb.1:
	ldr	x8, [x0, #32]
	cbz	x8, LBB45_66
; %bb.2:
	ldrh	w8, [x21, #584]
	cbz	w8, LBB45_66
; %bb.3:
	ldrh	w9, [x0, #140]
	cmp	w8, w9
	b.hi	LBB45_66
; %bb.4:
	ldr	w8, [x21, #596]
	ldr	w9, [x0, #136]
	cmp	w8, w9
	b.hi	LBB45_66
; %bb.5:
	ldrb	w8, [x21, #587]
	cmp	w8, #1
	b.ne	LBB45_66
; %bb.6:
	ldr	x8, [x21, #328]
	cbz	x8, LBB45_66
; %bb.7:
	mov	x22, x1
	ldr	w8, [x0, #128]
	mov	x19, x0
	cbz	w8, LBB45_32
; %bb.8:
	mov	x23, #0                         ; =0x0
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
	mov	w25, #168                       ; =0xa8
LBB45_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB45_13 Depth 2
                                        ;       Child Loop BB45_15 Depth 3
	ldr	x8, [x21, #296]
	madd	x20, x23, x25, x8
	mov	x1, x20
	bl	_frc_payload
	tbz	w0, #0, LBB45_66
; %bb.10:                               ;   in Loop: Header=BB45_9 Depth=1
	ldrb	w8, [x20]
	cmp	w8, #1
	b.ne	LBB45_30
; %bb.11:                               ;   in Loop: Header=BB45_9 Depth=1
	ldrh	w8, [x21, #584]
	cbz	w8, LBB45_66
; %bb.12:                               ;   in Loop: Header=BB45_9 Depth=1
	mov	x24, x22
	mov	x0, x19
	mov	x28, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
LBB45_13:                               ;   Parent Loop BB45_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB45_15 Depth 3
	add	x9, x28, x28, lsl #2
	add	x28, x28, #1
	lsl	x26, x9, #3
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	b	LBB45_15
LBB45_14:                               ;   in Loop: Header=BB45_15 Depth=3
	ldrh	w8, [x21, #584]
	add	x26, x26, #40
	cmp	x28, x8
	add	x28, x28, #1
	mov	x0, x19
	mov	x24, x22
	b.hs	LBB45_23
LBB45_15:                               ;   Parent Loop BB45_9 Depth=1
                                        ;     Parent Loop BB45_13 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	w28, w8, uxth
	b.eq	LBB45_17
; %bb.16:                               ;   in Loop: Header=BB45_15 Depth=3
	ldr	x8, [x21, #320]
	add	x24, x8, x26
LBB45_17:                               ;   in Loop: Header=BB45_15 Depth=3
	ldr	w1, [x24]
	add	x2, sp, #16
	bl	_fr_function
	tbz	w0, #0, LBB45_101
; %bb.18:                               ;   in Loop: Header=BB45_15 Depth=3
	ldr	w8, [x24, #8]
	cmp	x23, x8
	b.lo	LBB45_20
; %bb.19:                               ;   in Loop: Header=BB45_15 Depth=3
	ldrh	w9, [sp, #56]
	sub	w8, w23, w8
	cmp	w8, w9
	b.lo	LBB45_22
LBB45_20:                               ;   in Loop: Header=BB45_15 Depth=3
	ldr	w8, [x24, #12]
	cmp	x23, x8
	b.lo	LBB45_14
; %bb.21:                               ;   in Loop: Header=BB45_15 Depth=3
	ldr	w9, [x24, #16]
	sub	w8, w23, w8
	cmp	w8, w9
	b.hs	LBB45_14
LBB45_22:                               ;   in Loop: Header=BB45_13 Depth=2
	ldrh	w8, [x21, #584]
	mov	w27, #1                         ; =0x1
	cmp	x28, x8
	mov	x0, x19
	mov	x24, x22
	b.lo	LBB45_13
	b	LBB45_24
LBB45_23:                               ;   in Loop: Header=BB45_9 Depth=1
	tbz	w27, #0, LBB45_66
LBB45_24:                               ;   in Loop: Header=BB45_9 Depth=1
	ldrb	w8, [x20]
	cmp	w8, #1
	b.ne	LBB45_31
; %bb.25:                               ;   in Loop: Header=BB45_9 Depth=1
	ldrb	w8, [x20, #1]
	cmp	w8, #1
	b.ne	LBB45_31
; %bb.26:                               ;   in Loop: Header=BB45_9 Depth=1
	ldr	w8, [x20, #136]
	cmp	w8, #63
	b.hi	LBB45_66
; %bb.27:                               ;   in Loop: Header=BB45_9 Depth=1
	mov	w9, #1                          ; =0x1
	lsl	x24, x9, x8
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	tst	x24, x8
	b.ne	LBB45_66
; %bb.28:                               ;   in Loop: Header=BB45_9 Depth=1
	ldr	x0, [x21, #328]
	ldr	w8, [x20, #16]
	cmp	w8, #2
	cset	w2, eq
	add	x1, x20, #120
	bl	_nl_socket_value_validate
	cbnz	w0, LBB45_73
; %bb.29:                               ;   in Loop: Header=BB45_9 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	orr	x8, x24, x8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
LBB45_30:                               ;   in Loop: Header=BB45_9 Depth=1
	mov	x0, x19
LBB45_31:                               ;   in Loop: Header=BB45_9 Depth=1
	add	x23, x23, #1
	ldr	w8, [x0, #128]
	cmp	x23, x8
	b.lo	LBB45_9
	b	LBB45_33
LBB45_32:
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
LBB45_33:
	add	x23, x21, #596
	ldr	w8, [x23]
	cbz	w8, LBB45_40
; %bb.34:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x21, #312]
	b	LBB45_36
LBB45_35:                               ;   in Loop: Header=BB45_36 Depth=1
	add	x9, x9, #1
	cmp	w9, w8
	b.eq	LBB45_40
LBB45_36:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB45_38 Depth 2
	ldr	x11, [x10, w9, uxtw #3]
	cbz	x11, LBB45_66
; %bb.37:                               ;   in Loop: Header=BB45_36 Depth=1
	mov	x12, x9
	mov	x13, x10
	cbz	w9, LBB45_35
LBB45_38:                               ;   Parent Loop BB45_36 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x14, [x13], #8
	cmp	x14, x11
	b.eq	LBB45_65
; %bb.39:                               ;   in Loop: Header=BB45_38 Depth=2
	subs	x12, x12, #1
	b.ne	LBB45_38
	b	LBB45_35
LBB45_40:
	ldr	w10, [x0, #136]
	cmp	w8, w10
	b.hs	LBB45_44
; %bb.41:
	ldr	x9, [x21, #312]
	add	x9, x9, x8, lsl #3
	sub	x8, x10, x8
LBB45_42:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9], #8
	cbnz	x10, LBB45_66
; %bb.43:                               ;   in Loop: Header=BB45_42 Depth=1
	subs	x8, x8, #1
	b.ne	LBB45_42
LBB45_44:
	ldrh	w10, [x21, #584]
	ldr	w8, [x0, #132]
	cmp	w8, w10, lsl #8
	b.ls	LBB45_57
; %bb.45:
	ldr	x9, [x21, #304]
	mov	w11, #14336                     ; =0x3800
	umaddl	x9, w10, w11, x9
	add	x9, x9, #24
	sub	x10, x8, x10, lsl #8
LBB45_46:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w11, [x9, #-24]
	tbnz	w11, #0, LBB45_66
; %bb.47:                               ;   in Loop: Header=BB45_46 Depth=1
	ldurb	w11, [x9, #-23]
	tbnz	w11, #0, LBB45_66
; %bb.48:                               ;   in Loop: Header=BB45_46 Depth=1
	ldurb	w11, [x9, #-22]
	tbnz	w11, #0, LBB45_66
; %bb.49:                               ;   in Loop: Header=BB45_46 Depth=1
	ldur	w11, [x9, #-20]
	cbnz	w11, LBB45_66
; %bb.50:                               ;   in Loop: Header=BB45_46 Depth=1
	ldur	w11, [x9, #-16]
	cbnz	w11, LBB45_66
; %bb.51:                               ;   in Loop: Header=BB45_46 Depth=1
	ldur	w11, [x9, #-12]
	cbnz	w11, LBB45_66
; %bb.52:                               ;   in Loop: Header=BB45_46 Depth=1
	ldur	x11, [x9, #-8]
	cbnz	x11, LBB45_66
; %bb.53:                               ;   in Loop: Header=BB45_46 Depth=1
	ldr	x11, [x9, #24]
	cbnz	x11, LBB45_66
; %bb.54:                               ;   in Loop: Header=BB45_46 Depth=1
	ldp	x11, x12, [x9]
	orr	x11, x11, x12
	cbnz	x11, LBB45_66
; %bb.55:                               ;   in Loop: Header=BB45_46 Depth=1
	ldr	w11, [x9, #16]
	cbnz	w11, LBB45_65
; %bb.56:                               ;   in Loop: Header=BB45_46 Depth=1
	add	x9, x9, #56
	subs	x10, x10, #1
	b.ne	LBB45_46
LBB45_57:
	cbz	w8, LBB45_71
; %bb.58:
	mov	x9, #0                          ; =0x0
	mov	x20, #0                         ; =0x0
	ldr	x10, [x21, #304]
	mov	w11, #1                         ; =0x1
	b	LBB45_60
LBB45_59:                               ;   in Loop: Header=BB45_60 Depth=1
	add	x9, x9, #1
	add	x10, x10, #56
	cmp	x8, x9
	b.eq	LBB45_72
LBB45_60:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB45_59
; %bb.61:                               ;   in Loop: Header=BB45_60 Depth=1
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB45_59
; %bb.62:                               ;   in Loop: Header=BB45_60 Depth=1
	ldr	w12, [x10, #8]
	cmp	x9, x12
	b.ne	LBB45_59
; %bb.63:                               ;   in Loop: Header=BB45_60 Depth=1
	ldr	w12, [x10, #40]
	cmp	w12, #63
	lsl	x12, x11, x12
	and	x13, x12, x20
	ccmp	x13, #0, #0, ls
	b.ne	LBB45_66
; %bb.64:                               ;   in Loop: Header=BB45_60 Depth=1
	orr	x20, x12, x20
	b	LBB45_59
LBB45_65:
	cbz	x0, LBB45_67
LBB45_66:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.ne	LBB45_68
LBB45_67:
	mov	w0, #5                          ; =0x5
	b	LBB45_70
LBB45_68:
	ldr	w8, [x21, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB45_70
; %bb.69:
	str	w0, [x21, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #344]
LBB45_70:
	add	sp, sp, #736
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB45_71:
	mov	x20, #0                         ; =0x0
LBB45_72:
	ldr	x0, [x21, #328]
	add	x1, sp, #16
	sub	x2, x29, #200
	bl	_nl_socket_values_live_slots
	cbz	w0, LBB45_74
LBB45_73:
	mov	x1, x0
	mov	x0, x19
	bl	_fr_core
	b	LBB45_70
LBB45_74:
	ldp	x9, x8, [sp, #8]                ; 8-byte Folded Reload
	cmp	x9, x8
	b.ne	LBB45_66
; %bb.75:
	ldur	x9, [x29, #-200]
	cmp	x20, x9
	b.ne	LBB45_66
; %bb.76:
	ldrh	w9, [x21, #584]
	cbz	w9, LBB45_104
; %bb.77:
	mov	x8, x19
	mov	w24, #0                         ; =0x0
	mov	x2, #0                          ; =0x0
	mov	w25, #40                        ; =0x28
	mov	x20, x22
LBB45_78:                               ; =>This Inner Loop Header: Depth=1
	and	w3, w24, #0xffff
	add	w26, w3, #1
	cmp	w26, w9, uxth
	b.eq	LBB45_80
; %bb.79:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	x9, [x21, #320]
	and	x10, x24, #0xffff
	umaddl	x20, w10, w25, x9
LBB45_80:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w1, [x20]
	sub	x4, x29, #128
	sub	x5, x29, #200
	mov	x0, x8
	bl	_frf_layout
	cbz	w0, LBB45_101
; %bb.81:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x20, #8]
	ldur	w9, [x29, #-120]
	cmp	w8, w9
	b.ne	LBB45_101
; %bb.82:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w27, [x20, #12]
	ldur	w8, [x29, #-116]
	cmp	x27, x8
	b.ne	LBB45_101
; %bb.83:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x20, #20]
	ldur	w9, [x29, #-108]
	cmp	w8, w9
	b.ne	LBB45_101
; %bb.84:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x20, #24]
	ldur	w9, [x29, #-104]
	cmp	w8, w9
	b.ne	LBB45_101
; %bb.85:                               ;   in Loop: Header=BB45_78 Depth=1
	tst	w24, #0xffff
	b.ne	LBB45_87
; %bb.86:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x20, #28]
	cbnz	w8, LBB45_101
LBB45_87:                               ;   in Loop: Header=BB45_78 Depth=1
	ldrh	w8, [x21, #584]
	cmp	w26, w8
	b.hs	LBB45_92
; %bb.88:                               ;   in Loop: Header=BB45_78 Depth=1
	mov	x0, x19
	ldr	w1, [x20]
	ldrh	w2, [x20, #4]
	add	x3, sp, #16
	bl	_fr_code
	cbz	w0, LBB45_101
; %bb.89:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	x8, [x21, #320]
	umull	x9, w26, w25
	ldr	w3, [x8, x9]
	add	x2, sp, #16
	mov	x0, x19
	mov	x1, x20
	bl	_fr_call_target
	cbz	w0, LBB45_101
; %bb.90:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x20, #36]
	ldr	x9, [x21, #320]
	umull	x10, w26, w25
	ldr	w9, [x9, x10]
	cmp	w8, w9
	b.ne	LBB45_101
; %bb.91:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w27, [x20, #12]
LBB45_92:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w8, [x21, #580]
	cbz	w8, LBB45_94
; %bb.93:                               ;   in Loop: Header=BB45_78 Depth=1
	ldurh	w28, [x29, #-162]
	b	LBB45_95
LBB45_94:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w28, [x20, #16]
LBB45_95:                               ;   in Loop: Header=BB45_78 Depth=1
	ldrh	w8, [x21, #584]
	mov	x9, x23
	cmp	w26, w8
	b.eq	LBB45_97
; %bb.96:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	x9, [x21, #320]
	umaddl	x9, w26, w25, x9
	add	x9, x9, #28
LBB45_97:                               ;   in Loop: Header=BB45_78 Depth=1
	ldr	w2, [x9]
	cmp	w26, w8
	b.hs	LBB45_99
; %bb.98:                               ;   in Loop: Header=BB45_78 Depth=1
	ldrb	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB45_101
LBB45_99:                               ;   in Loop: Header=BB45_78 Depth=1
	mov	x0, x19
	mov	x1, x20
	bl	_frc_frame
	tbz	w0, #0, LBB45_101
; %bb.100:                              ;   in Loop: Header=BB45_78 Depth=1
	mov	x8, x19
	mov	w0, #0                          ; =0x0
	add	x2, x28, x27
	add	w24, w24, #1
	ldrh	w9, [x21, #584]
	cmp	w9, w24, uxth
	mov	x20, x22
	b.hi	LBB45_78
	b	LBB45_70
LBB45_101:
	ldr	w8, [x21, #576]
	cmp	w8, #2
	b.eq	LBB45_67
; %bb.102:
	ldr	w8, [x21, #336]
	cbnz	w8, LBB45_67
; %bb.103:
	mov	w8, #5                          ; =0x5
	str	w8, [x21, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x21, #344]
	b	LBB45_67
LBB45_104:
	mov	w0, #0                          ; =0x0
	b	LBB45_70
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_socket_runtime_frame_view
lCPI46_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_frame_view
	.p2align	2
_nvm_socket_runtime_frame_view:         ; @nvm_socket_runtime_frame_view
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB46_4
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x1
	mov	x20, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	cbz	w0, LBB46_3
; %bb.2:
	add	x8, x20, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldr	w8, [x8, #580]
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	strh	w10, [x19, #16]
	stur	w12, [x19, #18]
	strh	w13, [x19, #22]
	ldur	q1, [x9, #-32]
Lloh32:
	adrp	x10, lCPI46_0@PAGE
Lloh33:
	ldr	q2, [x10, lCPI46_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	str	w8, [x19]
	stur	d0, [x19, #4]
	str	w11, [x19, #12]
	stur	q1, [x19, #24]
	str	d2, [x19, #40]
	mov	w0, #1                          ; =0x1
LBB46_3:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB46_4:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_current
_frf_current:                           ; @frf_current
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB47_7
; %bb.1:
	add	x8, x0, #8, lsl #12             ; =32768
	ldrb	w9, [x8, #586]
	tbnz	w9, #0, LBB47_6
; %bb.2:
	ldr	w9, [x8, #576]
	cmp	w9, #1
	b.ne	LBB47_6
; %bb.3:
	ldrb	w9, [x8, #587]
	cmp	w9, #1
	b.ne	LBB47_6
; %bb.4:
	ldrb	w9, [x8, #588]
	tbnz	w9, #0, LBB47_6
; %bb.5:
	ldr	w9, [x8, #336]
	cbz	w9, LBB47_8
LBB47_6:
	mov	w0, #0                          ; =0x0
LBB47_7:
	ret
LBB47_8:
	ldrh	w9, [x8, #584]
	cbz	w9, LBB47_6
; %bb.9:
	ldrh	w10, [x0, #140]
	cmp	w9, w10
	b.hi	LBB47_6
; %bb.10:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	x8, [x8, #320]
	sub	w9, w9, #1
	mov	w10, #40                        ; =0x28
	umaddl	x22, w9, w10, x8
	ldrb	w8, [x22, #32]
	tbz	w8, #0, LBB47_12
LBB47_11:
	mov	w0, #0                          ; =0x0
	b	LBB47_17
LBB47_12:
	mov	x20, x2
	mov	x19, x3
	ldr	w8, [x22]
	mov	x21, x0
	mov	x2, x1
	mov	x1, x8
	bl	_fr_function
	cbz	w0, LBB47_17
; %bb.13:
	ldr	w2, [x22, #4]
	lsr	w8, w2, #16
	cbnz	w8, LBB47_11
; %bb.14:
	ldr	w1, [x22]
	ldrb	w3, [x22, #34]
	mov	x0, x21
	mov	x4, x20
	mov	x5, x19
	bl	_fr_instruction
	cbz	w0, LBB47_17
; %bb.15:
	ldrb	w8, [x19]
	cmp	w8, #1
	b.ne	LBB47_11
; %bb.16:
	ldr	w8, [x22, #16]
	ldrh	w9, [x19, #4]
	cmp	w8, w9
	cset	w0, eq
LBB47_17:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_local ; -- Begin function nvm_socket_runtime_frame_local
	.p2align	2
_nvm_socket_runtime_frame_local:        ; @nvm_socket_runtime_frame_local
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB48_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB48_4
; %bb.2:
	ldurh	w8, [x29, #-64]
	cmp	w20, w8
	b.hs	LBB48_4
; %bb.3:
	add	x8, x21, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w8, [x8, #584]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldur	w8, [x8, #-32]
	add	w8, w8, w20
	str	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB48_5
LBB48_4:
	mov	w0, #0                          ; =0x0
LBB48_5:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB48_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_operand ; -- Begin function nvm_socket_runtime_frame_operand
	.p2align	2
_nvm_socket_runtime_frame_operand:      ; @nvm_socket_runtime_frame_operand
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB49_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, x2
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB49_6
; %bb.2:
	add	x8, x20, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldur	w10, [x9, #-24]
	cmp	w10, w19
	b.ls	LBB49_6
; %bb.3:
	ldur	w9, [x9, #-28]
	ldr	w10, [x20, #128]
	add	w9, w9, w19
	cmp	w9, w10
	b.hs	LBB49_6
; %bb.4:
	ldr	x8, [x8, #296]
	mov	w10, #168                       ; =0xa8
	umull	x10, w9, w10
	ldrb	w8, [x8, x10]
	cmp	w8, #1
	b.ne	LBB49_6
; %bb.5:
	str	w9, [x21]
	mov	w0, #1                          ; =0x1
	b	LBB49_7
LBB49_6:
	mov	w0, #0                          ; =0x0
LBB49_7:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB49_8:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_reserve ; -- Begin function nvm_socket_runtime_frame_reserve
	.p2align	2
_nvm_socket_runtime_frame_reserve:      ; @nvm_socket_runtime_frame_reserve
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB50_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, x2
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB50_5
; %bb.2:
	ldurh	w8, [x29, #-66]
	cmp	w19, w8
	b.hs	LBB50_5
; %bb.3:
	add	x8, x20, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldur	w9, [x9, #-28]
	ldr	w10, [x20, #128]
	add	w9, w9, w19
	cmp	w9, w10
	b.hs	LBB50_5
; %bb.4:
	ldr	x8, [x8, #296]
	mov	w10, #168                       ; =0xa8
	umull	x10, w9, w10
	ldrb	w8, [x8, x10]
	tbz	w8, #0, LBB50_8
LBB50_5:
	mov	w0, #0                          ; =0x0
LBB50_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB50_7:
	mov	w0, #0                          ; =0x0
	ret
LBB50_8:
	str	w9, [x21]
	mov	w0, #1                          ; =0x1
	b	LBB50_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_scratch ; -- Begin function nvm_socket_runtime_frame_scratch
	.p2align	2
_nvm_socket_runtime_frame_scratch:      ; @nvm_socket_runtime_frame_scratch
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB51_7
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x0
	mov	x20, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB51_5
; %bb.2:
	ldurh	w9, [x29, #-62]
	cbz	x9, LBB51_5
; %bb.3:
	add	x8, x19, #8, lsl #12            ; =32768
	ldr	x10, [x8, #320]
	ldrh	w11, [x8, #584]
	mov	w12, #40                        ; =0x28
	umaddl	x10, w11, w12, x10
	ldur	w10, [x10, #-20]
	add	x9, x9, x10
	sub	x9, x9, #1
	ldr	w10, [x19, #128]
	cmp	x9, x10
	b.hs	LBB51_5
; %bb.4:
	ldr	x8, [x8, #296]
	mov	w10, #168                       ; =0xa8
	mul	x10, x9, x10
	ldrb	w8, [x8, x10]
	tbz	w8, #0, LBB51_8
LBB51_5:
	mov	w0, #0                          ; =0x0
LBB51_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB51_7:
	mov	w0, #0                          ; =0x0
	ret
LBB51_8:
	str	w9, [x20]
	mov	w0, #1                          ; =0x1
	b	LBB51_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_reference ; -- Begin function nvm_socket_runtime_frame_reference
	.p2align	2
_nvm_socket_runtime_frame_reference:    ; @nvm_socket_runtime_frame_reference
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB52_6
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	bl	_frf_current
	tbz	w0, #0, LBB52_4
; %bb.2:
	cmp	w20, #255
	b.hi	LBB52_4
; %bb.3:
	add	x8, x21, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w8, [x8, #584]
	mov	w10, #40                        ; =0x28
	umaddl	x8, w8, w10, x9
	ldur	w8, [x8, #-16]
	add	w8, w8, w20
	str	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB52_5
LBB52_4:
	mov	w0, #0                          ; =0x0
LBB52_5:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB52_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_store ; -- Begin function nvm_socket_runtime_frame_store
	.p2align	2
_nvm_socket_runtime_frame_store:        ; @nvm_socket_runtime_frame_store
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB53_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #896
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x23, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x23, #586]
	tbz	w8, #0, LBB53_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB53_22
LBB53_3:
	mov	w0, #1                          ; =0x1
	ret
LBB53_4:
	ldr	w8, [x23, #576]
	cmp	w8, #1
	b.ne	LBB53_21
; %bb.5:
	ldr	w0, [x23, #336]
	cbnz	w0, LBB53_22
; %bb.6:
	ldrb	w8, [x23, #588]
	tbz	w8, #0, LBB53_9
LBB53_7:
	mov	w0, #5                          ; =0x5
LBB53_8:
	str	w0, [x23, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #344]
	b	LBB53_22
LBB53_9:
	sub	x1, x29, #160
	add	x2, sp, #216
	add	x3, sp, #136
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB53_19
; %bb.10:
	mov	x12, x19
	ldr	w8, [x19, #24]
	ldr	x9, [x23, #320]
	ldrh	w10, [x23, #584]
	cbz	w8, LBB53_12
; %bb.11:
	mov	w11, #40                        ; =0x28
	umaddl	x11, w10, w11, x9
	ldurb	w11, [x11, #-7]
	tbz	w11, #0, LBB53_19
LBB53_12:
	mov	w11, #40                        ; =0x28
	umaddl	x20, w10, w11, x9
	ldur	w9, [x20, #-40]
	str	w9, [x23, #348]
	ldr	w9, [sp, #216]
	str	w9, [x23, #352]
	ldrb	w24, [sp, #224]
	cmp	w24, #17
	cset	w9, ne
	cmp	w24, #12
	cset	w10, eq
	eor	w9, w10, w9
	tbnz	w9, #0, LBB53_17
; %bb.13:
	ldur	w9, [x20, #-24]
	cbz	w9, LBB53_17
; %bb.14:
	ldrh	w21, [sp, #232]
	ldurh	w10, [x29, #-120]
	cmp	w21, w10
	b.hs	LBB53_17
; %bb.15:
	ldurh	w10, [x29, #-122]
	cmp	w9, w10
	b.hi	LBB53_17
; %bb.16:
	ldur	w11, [x20, #-28]
	ldr	w12, [x12, #128]
	sub	x13, x12, x11
	cmp	w11, w12
	ccmp	x13, x10, #0, ls
	b.hs	LBB53_23
LBB53_17:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB53_21
; %bb.18:
	ldr	w8, [x23, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB53_22
	b	LBB53_8
LBB53_19:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB53_21
; %bb.20:
	ldr	w8, [x23, #336]
	cbz	w8, LBB53_7
LBB53_21:
	mov	w0, #5                          ; =0x5
LBB53_22:
	add	sp, sp, #896
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB53_23:
	ldur	w15, [x20, #-20]
	cmp	w15, w12
	b.hi	LBB53_17
; %bb.24:
	ldurh	w13, [x29, #-118]
	sub	x14, x12, x15
	cmp	x14, x13
	b.lo	LBB53_17
; %bb.25:
	cbz	w13, LBB53_30
; %bb.26:
	sub	w14, w12, w15
	mov	w12, #168                       ; =0xa8
	umull	x15, w15, w12
LBB53_27:                               ; =>This Inner Loop Header: Depth=1
	cbz	x14, LBB53_17
; %bb.28:                               ;   in Loop: Header=BB53_27 Depth=1
	ldr	x12, [x23, #296]
	ldrb	w16, [x12, x15]
	tbnz	w16, #0, LBB53_17
; %bb.29:                               ;   in Loop: Header=BB53_27 Depth=1
	add	x15, x15, #168
	sub	x14, x14, #1
	sub	x13, x13, #1
	cbnz	x13, LBB53_27
	b	LBB53_31
LBB53_30:
	ldr	x12, [x23, #296]
LBB53_31:
	mov	x13, #0                         ; =0x0
	mov	w14, #168                       ; =0xa8
	b	LBB53_34
LBB53_32:                               ;   in Loop: Header=BB53_34 Depth=1
	tbnz	w16, #0, LBB53_17
LBB53_33:                               ;   in Loop: Header=BB53_34 Depth=1
	add	x13, x13, #1
	cmp	x10, x13
	b.eq	LBB53_37
LBB53_34:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w11, w13
	umaddl	x15, w15, w14, x12
	ldrb	w16, [x15]
	cmp	x13, x9
	b.hs	LBB53_32
; %bb.35:                               ;   in Loop: Header=BB53_34 Depth=1
	cbz	w16, LBB53_17
; %bb.36:                               ;   in Loop: Header=BB53_34 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB53_33
	b	LBB53_17
LBB53_37:
	mov	x22, x23
	ldur	w1, [x20, #-40]
	cbz	w8, LBB53_40
; %bb.38:
	cmp	w8, #2
	b.ne	LBB53_41
; %bb.39:
	ldr	x0, [x19, #16]
	add	x3, sp, #120
	mov	x2, x21
	bl	_nvm_socket_indirect_hosted_local
	b	LBB53_42
LBB53_40:
	ldr	x0, [x19]
	add	x3, sp, #120
	mov	x2, x21
	bl	_nvm_socket_hosted_local
	b	LBB53_42
LBB53_41:
	ldr	x0, [x19, #8]
	add	x3, sp, #120
	mov	x2, x21
	bl	_nvm_socket_cyclic_hosted_local
LBB53_42:
	mov	x23, x22
	mov	x14, x24
	tbz	w0, #0, LBB53_17
; %bb.43:
	ldp	w9, w8, [x20, #-28]
	ldur	w10, [x20, #-32]
	add	w8, w9, w8
	sub	w20, w8, #1
	add	w21, w10, w21
	ldr	x25, [x23, #296]
	mov	w8, #168                        ; =0xa8
	umaddl	x8, w20, w8, x25
	ldr	s0, [x8]
	ldrb	w27, [x8, #1]
	ldrb	w12, [x8, #4]
	ldrb	w9, [x8, #5]
	ldrh	w10, [x8, #6]
	ldr	w11, [x8, #8]
	ldrb	w13, [sp, #121]
	cmp	w14, #12
	b.eq	LBB53_52
; %bb.44:
	ldrb	w14, [x8]
	tbz	w14, #0, LBB53_52
; %bb.45:
	tbnz	w27, #0, LBB53_52
; %bb.46:
	ldrb	w14, [x8, #2]
	tbnz	w14, #0, LBB53_52
; %bb.47:
	ldrb	w14, [sp, #120]
	ldr	w15, [sp, #132]
	sub	w15, w15, #3
	cmp	w12, #0
	ccmp	w9, #0, #0, eq
	ccmn	w11, #1, #0, eq
	ccmp	w14, #0, #4, eq
	ccmp	w13, #0, #0, ne
	ccmn	w15, #3, #2, eq
	b.hi	LBB53_52
; %bb.48:
	ldr	w8, [x19, #128]
	cmp	w21, w8
	b.hs	LBB53_51
; %bb.49:
	mov	w8, #168                        ; =0xa8
	umaddl	x0, w21, w8, x25
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB53_51
; %bb.50:
	ldp	x1, x2, [sp, #120]
	bl	_frf_matches
	tbz	w0, #0, LBB53_53
LBB53_51:
	mov	w0, #0                          ; =0x0
	mov	w8, #168                        ; =0xa8
	umaddl	x9, w21, w8, x25
	str	xzr, [x9, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9]
	ldr	x9, [x22, #296]
	umaddl	x8, w20, w8, x9
	str	xzr, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	b	LBB53_22
LBB53_52:
	cbz	w13, LBB53_57
LBB53_53:
	ldr	w8, [x22, #576]
	cmp	w8, #2
	b.ne	LBB53_55
; %bb.54:
	mov	w0, #6                          ; =0x6
	b	LBB53_22
LBB53_55:
	ldr	w8, [x22, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB53_22
; %bb.56:
	str	w0, [x22, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x22, #344]
	b	LBB53_22
LBB53_57:
	ushll.8h	v0, v0, #0
	uzp1.8b	v0, v0, v0
	str	s0, [sp]
	cmp	w24, #12
	strb	w12, [sp, #4]
	cset	w28, eq
	strb	w9, [sp, #5]
	strh	w10, [sp, #6]
	str	w11, [sp, #8]
	ldur	q0, [x8, #60]
	stur	q0, [sp, #60]
	ldur	q0, [x8, #76]
	stur	q0, [sp, #76]
	ldur	q0, [x8, #92]
	stur	q0, [sp, #92]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #12]
	stur	q0, [sp, #12]
	ldur	q0, [x8, #28]
	stur	q0, [sp, #28]
	ldur	q0, [x8, #44]
	stur	q0, [sp, #44]
	ldp	x26, x23, [sp, #120]
	mov	x0, sp
	mov	x1, x26
	mov	x2, x23
	bl	_frf_matches
	cbz	w0, LBB53_53
; %bb.58:
	eor	w8, w28, w27
	tbnz	w8, #0, LBB53_53
; %bb.59:
	ldr	w8, [x19, #128]
	cmp	w24, #12
	b.ne	LBB53_67
; %bb.60:
	cmp	w21, w8
	b.hs	LBB53_53
; %bb.61:
	mov	w8, #168                        ; =0xa8
	umull	x8, w21, w8
	ldrb	w8, [x25, x8]
	tbnz	w8, #0, LBB53_53
; %bb.62:
	ldr	w8, [x19, #132]
	cbz	w8, LBB53_71
; %bb.63:
	ldr	x9, [x22, #304]
	add	x9, x9, #4
	b	LBB53_65
LBB53_64:                               ;   in Loop: Header=BB53_65 Depth=1
	add	x9, x9, #56
	subs	x8, x8, #1
	b.eq	LBB53_71
LBB53_65:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB53_64
; %bb.66:                               ;   in Loop: Header=BB53_65 Depth=1
	ldr	w10, [x9]
	cmp	w10, w20
	b.ne	LBB53_64
	b	LBB53_53
LBB53_67:
	cmp	w21, w8
	b.hs	LBB53_70
; %bb.68:
	mov	w8, #168                        ; =0xa8
	umaddl	x0, w21, w8, x25
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB53_70
; %bb.69:
	mov	x1, x26
	mov	x2, x23
	bl	_frf_matches
	tbz	w0, #0, LBB53_53
LBB53_70:
	mov	w8, #168                        ; =0xa8
	umaddl	x8, w21, w8, x25
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
LBB53_71:
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	bl	_nvm_socket_runtime_move
	b	LBB53_22
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_stack
_frf_stack:                             ; @frf_stack
	.cfi_startproc
; %bb.0:
	ldrh	w8, [x2, #38]
	cmp	w3, w8
	b.hi	LBB54_3
; %bb.1:
	ldr	w9, [x1, #12]
	ldr	w12, [x0, #128]
	sub	x10, x12, x9
	cmp	w9, w12
	ccmp	x10, x8, #0, ls
	b.lo	LBB54_3
; %bb.2:
	ldr	w13, [x1, #20]
	ldrh	w10, [x2, #42]
	sub	x11, x12, x13
	cmp	w13, w12
	ccmp	x11, x10, #0, ls
	b.hs	LBB54_5
LBB54_3:
	mov	w0, #0                          ; =0x0
LBB54_4:
	ret
LBB54_5:
	cbz	w10, LBB54_10
; %bb.6:
	mov	w11, #33064                     ; =0x8128
	sub	w12, w12, w13
	mov	w14, #168                       ; =0xa8
	umull	x13, w13, w14
LBB54_7:                                ; =>This Inner Loop Header: Depth=1
	cbz	x12, LBB54_3
; %bb.8:                                ;   in Loop: Header=BB54_7 Depth=1
	ldr	x14, [x0, x11]
	ldrb	w14, [x14, x13]
	tbnz	w14, #0, LBB54_3
; %bb.9:                                ;   in Loop: Header=BB54_7 Depth=1
	add	x13, x13, #168
	sub	x12, x12, #1
	sub	x10, x10, #1
	cbnz	x10, LBB54_7
LBB54_10:
	cbz	w8, LBB54_17
; %bb.11:
	mov	x10, #0                         ; =0x0
	mov	w11, #33064                     ; =0x8128
	ldr	x11, [x0, x11]
	mov	w12, w3
	mov	w13, #168                       ; =0xa8
	mov	w0, #1                          ; =0x1
	b	LBB54_14
LBB54_12:                               ;   in Loop: Header=BB54_14 Depth=1
	tbnz	w15, #0, LBB54_3
LBB54_13:                               ;   in Loop: Header=BB54_14 Depth=1
	add	x10, x10, #1
	cmp	x8, x10
	b.eq	LBB54_4
LBB54_14:                               ; =>This Inner Loop Header: Depth=1
	add	w14, w9, w10
	umaddl	x14, w14, w13, x11
	ldrb	w15, [x14]
	cmp	x10, x12
	b.hs	LBB54_12
; %bb.15:                               ;   in Loop: Header=BB54_14 Depth=1
	cbz	w15, LBB54_3
; %bb.16:                               ;   in Loop: Header=BB54_14 Depth=1
	ldrb	w14, [x14, #2]
	tbz	w14, #0, LBB54_13
	b	LBB54_3
LBB54_17:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_local
_fr_local:                              ; @fr_local
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cbz	w8, LBB55_3
; %bb.1:
	cmp	w8, #2
	b.ne	LBB55_4
; %bb.2:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_local
LBB55_3:
	ldr	x0, [x0]
	b	_nvm_socket_hosted_local
LBB55_4:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_local
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frf_matches
_frf_matches:                           ; @frf_matches
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	cmp	w8, #1
	b.ne	LBB56_5
; %bb.1:
	ldur	x8, [x0, #4]
	eor	x8, x8, x1
	tst	x8, #0xff
	b.ne	LBB56_5
; %bb.2:
	ldur	x9, [x0, #12]
	and	x8, x8, #0xffffffffffffff00
	and	x8, x8, #0xffffffff0000ffff
	cmp	x8, #0
	ccmp	x9, x2, #0, eq
	b.ne	LBB56_5
; %bb.3:
	ldrb	w9, [x0, #2]
	ands	x8, x1, #0xff00
	cset	w10, ne
	cmp	w9, w10
	b.ne	LBB56_5
; %bb.4:
	lsr	x9, x2, #32
	sub	x9, x9, #1
	ldrb	w10, [x0, #1]
	cmp	x8, #0
	ccmp	x9, #2, #2, eq
	cset	w8, lo
	cmp	w10, w8
	cset	w0, eq
	ret
LBB56_5:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_next  ; -- Begin function nvm_socket_runtime_frame_next
	.p2align	2
_nvm_socket_runtime_frame_next:         ; @nvm_socket_runtime_frame_next
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB57_3
; %bb.1:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1440
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x23, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x23, #586]
	tbz	w8, #0, LBB57_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB57_36
LBB57_3:
	mov	w0, #1                          ; =0x1
	ret
LBB57_4:
	ldr	w8, [x23, #576]
	cmp	w8, #1
	b.ne	LBB57_35
; %bb.5:
	ldr	w0, [x23, #336]
	cbnz	w0, LBB57_36
; %bb.6:
	ldrb	w8, [x23, #588]
	tbz	w8, #0, LBB57_9
LBB57_7:
	mov	w0, #5                          ; =0x5
LBB57_8:
	str	w0, [x23, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #344]
	b	LBB57_36
LBB57_9:
	mov	x25, x1
	add	x1, sp, #680
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB57_16
; %bb.10:
	mov	x8, x19
	ldr	w9, [x19, #24]
	ldr	x10, [x23, #320]
	ldrh	w11, [x23, #584]
	cbz	w9, LBB57_12
; %bb.11:
	mov	w12, #40                        ; =0x28
	umaddl	x12, w11, w12, x10
	ldurb	w12, [x12, #-7]
	tbz	w12, #0, LBB57_16
LBB57_12:
	mov	w12, #40                        ; =0x28
	umaddl	x24, w11, w12, x10
	mov	x20, x24
	ldr	w10, [x20, #-40]!
	str	w10, [x23, #348]
	ldr	w10, [sp, #80]
	str	w10, [x23, #352]
	cbz	w9, LBB57_18
; %bb.13:
	cmp	w25, #1
	b.hi	LBB57_34
; %bb.14:
	ldp	w1, w10, [x24, #-40]
	ldurb	w3, [x24, #-6]
	cmp	w9, #2
	b.ne	LBB57_31
; %bb.15:
	ldr	x0, [x8, #16]
	and	w2, w10, #0xffff
	add	x4, sp, #832
	bl	_nvm_socket_indirect_hosted_variant
	mov	x8, x25
	tbnz	w0, #0, LBB57_32
	b	LBB57_34
LBB57_16:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB57_35
; %bb.17:
	ldr	w8, [x23, #336]
	cbnz	w8, LBB57_35
	b	LBB57_7
LBB57_18:
	mov	w21, #0                         ; =0x0
	mov	x8, x25
LBB57_19:
	ldrb	w9, [sp, #88]
	cmp	w9, #152
	mov	w10, #60                        ; =0x3c
	ccmp	w9, w10, #4, ne
	b.eq	LBB57_34
; %bb.20:
	cmp	w9, #61
	b.hi	LBB57_22
; %bb.21:
	mov	w10, #1                         ; =0x1
	lsl	x10, x10, x9
	mov	x11, #32768                     ; =0x8000
	movk	x11, #10240, lsl #48
	tst	x10, x11
	b.ne	LBB57_34
LBB57_22:
	cmp	w9, #151
	b.eq	LBB57_34
; %bb.23:
	ldrb	w9, [sp, #156]
	cmp	w8, w9
	b.hs	LBB57_34
; %bb.24:
	ldrh	w22, [sp, #6]
	add	x2, sp, #680
	mov	x0, x19
	mov	x1, x20
	mov	x3, x22
	bl	_frf_stack
	cbz	w0, LBB57_34
; %bb.25:
	ldr	w1, [x20]
	add	x10, sp, #80
	add	x26, x10, #72
	ldrh	w2, [x26, w25, uxtw #1]
	add	x4, sp, #832
	add	x5, sp, #752
	mov	x0, x19
	mov	x3, x21
	bl	_fr_instruction
	cbz	w0, LBB57_34
; %bb.26:
	ldrb	w8, [sp, #752]
	tbz	w8, #0, LBB57_34
; %bb.27:
	ldrh	w8, [sp, #756]
	cmp	w22, w8
	b.ne	LBB57_34
; %bb.28:
	ldr	q0, [x20, #16]
	str	q0, [sp, #848]
	ldr	q0, [x20]
	str	q0, [sp, #832]
	ldr	x9, [x20, #32]
	str	x9, [sp, #864]
	ldrh	w9, [x26, w25, uxtw #1]
	ldrh	w10, [sp, #6]
	str	w10, [sp, #848]
	str	w9, [sp, #836]
	strb	w21, [sp, #866]
	strb	wzr, [sp, #865]
	ldr	w8, [x19, #24]
	cbz	w8, LBB57_38
; %bb.29:
	add	x1, sp, #832
	mov	x0, x19
	bl	_frc_validate
	cbz	w0, LBB57_38
; %bb.30:
	ldr	w0, [x23, #336]
	b	LBB57_36
LBB57_31:
	ldr	x0, [x8, #8]
	and	w2, w10, #0xffff
	add	x4, sp, #832
	bl	_nvm_socket_cyclic_hosted_variant
	mov	x8, x25
	cbz	w0, LBB57_34
LBB57_32:
	ldrb	w9, [sp, #932]
	lsr	w9, w9, w8
	tbz	w9, #0, LBB57_34
; %bb.33:
	add	x9, sp, #832
	add	x9, x9, w8, uxtw
	ldrb	w21, [x9, #101]
	cmp	w21, #255
	b.ne	LBB57_19
LBB57_34:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.ne	LBB57_37
LBB57_35:
	mov	w0, #5                          ; =0x5
LBB57_36:
	add	sp, sp, #1440
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB57_37:
	ldr	w8, [x23, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB57_36
	b	LBB57_8
LBB57_38:
	ldr	q0, [sp, #832]
	str	q0, [x20]
	ldr	q0, [sp, #848]
	str	q0, [x20, #16]
	ldr	x8, [sp, #864]
	str	x8, [x20, #32]
	ldur	w1, [x24, #-40]
	ldurh	w2, [x24, #-36]
	mov	x0, x19
	bl	_nvm_socket_runtime_site
	b	LBB57_36
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_edge
_frc_edge:                              ; @frc_edge
	.cfi_startproc
; %bb.0:
	ldr	w9, [x0, #24]
	cbz	w9, LBB58_3
; %bb.1:
	cmp	w2, #1
	b.ls	LBB58_4
; %bb.2:
	mov	w0, #0                          ; =0x0
	ret
LBB58_3:
	strb	wzr, [x3]
	mov	w0, #1                          ; =0x1
	ret
LBB58_4:
	sub	sp, sp, #144
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x2
	mov	x19, x3
	mov	x10, x1
	ldr	w1, [x1]
	ldr	w8, [x10, #4]
	ldrb	w3, [x10, #34]
	cmp	w9, #2
	b.ne	LBB58_6
; %bb.5:
	ldr	x0, [x0, #16]
	and	w2, w8, #0xffff
	add	x4, sp, #8
	bl	_nvm_socket_indirect_hosted_variant
	tbnz	w0, #0, LBB58_7
	b	LBB58_10
LBB58_6:
	ldr	x0, [x0, #8]
	and	w2, w8, #0xffff
	add	x4, sp, #8
	bl	_nvm_socket_cyclic_hosted_variant
	cbz	w0, LBB58_11
LBB58_7:
	ldrb	w8, [sp, #108]
	lsr	w8, w8, w20
	tbz	w8, #0, LBB58_10
; %bb.8:
	add	x8, sp, #8
	add	x8, x8, w20, uxtw
	ldrb	w8, [x8, #101]
	cmp	w8, #255
	b.eq	LBB58_10
; %bb.9:
	strb	w8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB58_11
LBB58_10:
	mov	w0, #0                          ; =0x0
LBB58_11:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_call  ; -- Begin function nvm_socket_runtime_frame_call
	.p2align	2
_nvm_socket_runtime_frame_call:         ; @nvm_socket_runtime_frame_call
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2640
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh34:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh35:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh36:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cbz	x0, LBB59_3
; %bb.1:
	mov	x19, x0
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB59_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB59_37
LBB59_3:
	mov	w0, #1                          ; =0x1
	b	LBB59_37
LBB59_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB59_36
; %bb.5:
	ldr	w0, [x20, #336]
	cbnz	w0, LBB59_37
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB59_9
LBB59_7:
	mov	w0, #5                          ; =0x5
LBB59_8:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB59_37
LBB59_9:
	add	x1, sp, #848
	add	x2, sp, #176
	add	x3, sp, #96
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB59_24
; %bb.10:
	mov	x9, x19
	ldr	w8, [x19, #24]
	ldr	x10, [x20, #320]
	ldrh	w11, [x20, #584]
	cbz	w8, LBB59_12
; %bb.11:
	mov	w12, #40                        ; =0x28
	umaddl	x12, w11, w12, x10
	ldurb	w12, [x12, #-7]
	tbz	w12, #0, LBB59_24
LBB59_12:
	add	x23, sp, #176
	mov	w12, #40                        ; =0x28
	umaddl	x21, w11, w12, x10
	mov	x1, x21
	ldr	w10, [x1, #-40]!
	str	w10, [x20, #348]
	ldr	w10, [sp, #176]
	str	w10, [x20, #352]
	ldrb	w22, [sp, #184]
	cmp	w22, #60
	cset	w10, eq
	cmp	w22, #152
	csinc	w25, w10, wzr, ne
	b.eq	LBB59_14
; %bb.13:
	cmp	w22, #60
	b.ne	LBB59_26
LBB59_14:
	cmp	w8, #2
	b.ne	LBB59_35
; %bb.15:
	ldur	w8, [x21, #-24]
	cbz	w8, LBB59_35
; %bb.16:
	ldur	w10, [x21, #-28]
	add	w8, w8, w10
	sub	w8, w8, #1
	ldr	w10, [x9, #128]
	cmp	w8, w10
	b.hs	LBB59_35
; %bb.17:
	ldr	x10, [x20, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x10, w8, w11, x10
	ldrb	w11, [x10]
	tbz	w11, #0, LBB59_35
; %bb.18:
	ldur	x11, [x10, #4]
	mov	x12, #-65525                    ; =0xffffffffffff000b
	movk	x12, #0, lsl #16
	eor	x11, x11, x12
	tst	x11, #0xff
	b.ne	LBB59_35
; %bb.19:
	ldur	x12, [x10, #12]
	ldrb	w13, [x10, #2]
	ldrb	w14, [x10, #1]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x11, #0
	mov	w11, #-1                        ; =0xffffffff
	ccmp	x12, x11, #0, eq
	ccmp	w13, #0, #0, eq
	ccmp	w14, #0, #0, eq
	b.ne	LBB59_35
; %bb.20:
	ldrb	w11, [x10, #24]
	cbnz	w11, LBB59_35
; %bb.21:
	ldr	x11, [x10, #152]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.ne	LBB59_35
; %bb.22:
	mov	x24, x8
	ldr	w3, [x10, #160]
	add	x2, sp, #176
	mov	x0, x9
	mov	x23, x1
	mov	x26, x3
	bl	_fr_call_target
	cbz	w0, LBB59_35
; %bb.23:
	ldrb	w11, [sp, #184]
	mov	w10, #-1                        ; =0xffffffff
	mov	x9, x19
	mov	x8, x26
	mov	x1, x23
	add	x23, sp, #176
	b	LBB59_27
LBB59_24:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB59_36
; %bb.25:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB59_36
	b	LBB59_7
LBB59_26:
	ldr	w10, [x23, #16]
	mov	w24, #-1                        ; =0xffffffff
	mov	x11, x22
	mov	x8, x10
LBB59_27:
	cmp	w11, #59
	ccmp	w11, #15, #4, ne
	mov	w12, #151                       ; =0x97
	ccmp	w11, w12, #4, ne
	cset	w11, eq
	orr	w11, w25, w11
	tbz	w11, #0, LBB59_35
; %bb.28:
	ldrb	w11, [sp, #252]
	cmp	w11, #1
	b.ne	LBB59_35
; %bb.29:
	ldrb	w11, [sp, #99]
	tbz	w11, #0, LBB59_35
; %bb.30:
	ldr	w11, [sp, #120]
	cmp	w11, #1
	b.ne	LBB59_35
; %bb.31:
	ldr	w11, [sp, #128]
	cmp	w11, w10
	b.ne	LBB59_35
; %bb.32:
	ldr	w10, [sp, #124]
	ldr	w11, [sp, #176]
	cmp	w10, w11
	b.ne	LBB59_35
; %bb.33:
	ldrb	w10, [sp, #112]
	tbz	w10, #6, LBB59_35
; %bb.34:
	add	x14, sp, #776
	ldur	w10, [x21, #-24]
	ldrh	w11, [x14, #110]
	cmp	w10, w11
	b.ls	LBB59_40
LBB59_35:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB59_39
LBB59_36:
	mov	w0, #5                          ; =0x5
LBB59_37:
	ldur	x8, [x29, #-96]
Lloh37:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh38:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh39:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB59_121
; %bb.38:
	add	sp, sp, #2640
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB59_39:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB59_37
	b	LBB59_8
LBB59_40:
	ldur	w12, [x21, #-28]
	ldr	w13, [x9, #128]
	cmp	w12, w13
	b.hi	LBB59_35
; %bb.41:
	sub	x9, x13, x12
	cmp	x9, x11
	b.lo	LBB59_35
; %bb.42:
	ldur	w15, [x21, #-20]
	cmp	w15, w13
	b.hi	LBB59_35
; %bb.43:
	ldrh	w9, [x14, #114]
	sub	x14, x13, x15
	cmp	x14, x9
	b.lo	LBB59_35
; %bb.44:
	cbz	w9, LBB59_49
; %bb.45:
	sub	w13, w13, w15
	mov	w14, #168                       ; =0xa8
	umull	x14, w15, w14
LBB59_46:                               ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB59_35
; %bb.47:                               ;   in Loop: Header=BB59_46 Depth=1
	ldr	x15, [x20, #296]
	ldrb	w15, [x15, x14]
	tbnz	w15, #0, LBB59_35
; %bb.48:                               ;   in Loop: Header=BB59_46 Depth=1
	add	x14, x14, #168
	sub	x13, x13, #1
	sub	x9, x9, #1
	cbnz	x9, LBB59_46
LBB59_49:
	cbz	w11, LBB59_56
; %bb.50:
	mov	x9, #0                          ; =0x0
	ldr	x13, [x20, #296]
	mov	w14, #168                       ; =0xa8
	b	LBB59_53
LBB59_51:                               ;   in Loop: Header=BB59_53 Depth=1
	tbnz	w16, #0, LBB59_35
LBB59_52:                               ;   in Loop: Header=BB59_53 Depth=1
	add	x9, x9, #1
	cmp	x11, x9
	b.eq	LBB59_56
LBB59_53:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w12, w9
	umaddl	x15, w15, w14, x13
	ldrb	w16, [x15]
	cmp	x9, x10
	b.hs	LBB59_51
; %bb.54:                               ;   in Loop: Header=BB59_53 Depth=1
	cbz	w16, LBB59_35
; %bb.55:                               ;   in Loop: Header=BB59_53 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB59_52
	b	LBB59_35
LBB59_56:
	add	x2, sp, #776
	mov	x0, x19
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	mov	w1, w8
	bl	_fr_function
	tbz	w0, #0, LBB59_35
; %bb.57:
	str	x24, [sp]                       ; 8-byte Folded Spill
	str	w22, [sp, #12]                  ; 4-byte Folded Spill
	str	x21, [sp, #16]                  ; 8-byte Folded Spill
	str	x20, [sp, #40]                  ; 8-byte Folded Spill
	ldrh	w20, [x23, #612]
	add	x27, sp, #1600
	add	x0, sp, #1600
	mov	w1, #1024                       ; =0x400
	bl	_bzero
	str	x20, [sp, #32]                  ; 8-byte Folded Spill
	cbz	w20, LBB59_91
; %bb.58:
	mov	x28, #0                         ; =0x0
	mov	w26, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
	add	x8, sp, #176
	add	x23, x8, #78
	mov	w22, #56                        ; =0x38
LBB59_59:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB59_79 Depth 2
	ldr	w8, [x19, #24]
	cbz	w8, LBB59_62
; %bb.60:                               ;   in Loop: Header=BB59_59 Depth=1
	cmp	w8, #2
	b.ne	LBB59_63
; %bb.61:                               ;   in Loop: Header=BB59_59 Depth=1
	ldr	x0, [x19, #16]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_socket_indirect_hosted_local
	tbnz	w0, #0, LBB59_64
	b	LBB59_88
LBB59_62:                               ;   in Loop: Header=BB59_59 Depth=1
	ldr	x0, [x19]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_socket_hosted_local
	tbnz	w0, #0, LBB59_64
	b	LBB59_88
LBB59_63:                               ;   in Loop: Header=BB59_59 Depth=1
	ldr	x0, [x19, #8]
	and	w2, w28, #0xffff
	add	x3, sp, #1000
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_nvm_socket_cyclic_hosted_local
	tbz	w0, #0, LBB59_88
LBB59_64:                               ;   in Loop: Header=BB59_59 Depth=1
	ldrb	w21, [sp, #1001]
	ldrb	w8, [sp, #184]
	and	w8, w8, #0xff
	cmp	w8, #152
	csel	w9, wzr, w25, eq
	cbz	w21, LBB59_83
; %bb.65:                               ;   in Loop: Header=BB59_59 Depth=1
	sub	w10, w21, #3
	cmn	w10, #2
	csinc	w9, w9, wzr, hs
	tbnz	w9, #0, LBB59_88
; %bb.66:                               ;   in Loop: Header=BB59_59 Depth=1
	cmp	w26, #255
	b.hi	LBB59_88
; %bb.67:                               ;   in Loop: Header=BB59_59 Depth=1
	sub	w9, w8, #151
	cmp	w9, #2
	b.lo	LBB59_69
; %bb.68:                               ;   in Loop: Header=BB59_59 Depth=1
	cmp	w8, #15
	b.ne	LBB59_88
LBB59_69:                               ;   in Loop: Header=BB59_59 Depth=1
	ldrh	w9, [x23, x28, lsl #1]
	cmp	w9, #255
	b.hi	LBB59_88
; %bb.70:                               ;   in Loop: Header=BB59_59 Depth=1
	cmp	w8, #15
	b.ne	LBB59_72
; %bb.71:                               ;   in Loop: Header=BB59_59 Depth=1
	add	x8, sp, #176
	ldrh	w8, [x8, #24]
	cmp	w9, w8
	b.ne	LBB59_88
LBB59_72:                               ;   in Loop: Header=BB59_59 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-16]
	add	w20, w8, w9
	str	w20, [x27, x28, lsl #2]
	mov	x0, x19
	mov	x1, x20
	bl	_fr_reference
	tbz	w0, #0, LBB59_119
; %bb.73:                               ;   in Loop: Header=BB59_59 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldp	x9, x8, [x8, #296]
	umaddl	x10, w20, w22, x8
	ldr	w10, [x10, #4]
	mov	w11, #168                       ; =0xa8
	umaddl	x9, w10, w11, x9
	ldr	x11, [x9, #4]!
	add	x10, sp, #776
	ldr	x10, [x10, #224]
	bfi	x11, x21, #8, #8
	eor	x10, x11, x10
	tst	x10, #0xff
	b.ne	LBB59_119
; %bb.74:                               ;   in Loop: Header=BB59_59 Depth=1
	add	x11, sp, #776
	ldr	x11, [x11, #232]
	ldr	x9, [x9, #8]
	mov	x12, #-256                      ; =0xffffffffffffff00
	movk	x12, #0, lsl #16
	and	x10, x10, x12
	cmp	x10, #0
	ccmp	x11, x9, #0, eq
	b.ne	LBB59_119
; %bb.75:                               ;   in Loop: Header=BB59_59 Depth=1
	umaddl	x8, w20, w22, x8
	ldrb	w8, [x8, #2]
	cmp	w21, #1
	cset	w9, eq
	cmp	w8, w9
	b.ne	LBB59_119
; %bb.76:                               ;   in Loop: Header=BB59_59 Depth=1
	add	w26, w26, #1
	cbz	x28, LBB59_86
; %bb.77:                               ;   in Loop: Header=BB59_59 Depth=1
	mov	x21, #0                         ; =0x0
	b	LBB59_79
LBB59_78:                               ;   in Loop: Header=BB59_79 Depth=2
	add	x21, x21, #1
	cmp	x28, x21
	b.eq	LBB59_86
LBB59_79:                               ;   Parent Loop BB59_59 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x21
	bl	_fr_local
	tbz	w0, #0, LBB59_88
; %bb.80:                               ;   in Loop: Header=BB59_79 Depth=2
	ldrb	w8, [sp, #921]
	cbz	w8, LBB59_78
; %bb.81:                               ;   in Loop: Header=BB59_79 Depth=2
	ldrb	w9, [sp, #1001]
	cmp	w8, #1
	ccmp	w9, #1, #0, eq
	b.eq	LBB59_78
; %bb.82:                               ;   in Loop: Header=BB59_79 Depth=2
	ldr	w9, [x27, x21, lsl #2]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #304]
	umaddl	x9, w9, w22, x8
	ldr	w9, [x9, #4]
	umaddl	x8, w20, w22, x8
	ldr	w8, [x8, #4]
	cmp	w9, w8
	b.ne	LBB59_78
	b	LBB59_119
LBB59_83:                               ;   in Loop: Header=BB59_59 Depth=1
	tbnz	w9, #0, LBB59_85
; %bb.84:                               ;   in Loop: Header=BB59_59 Depth=1
	ldrsh	w8, [x23, x28, lsl #1]
	cmn	w8, #1
	b.ne	LBB59_88
LBB59_85:                               ;   in Loop: Header=BB59_59 Depth=1
	add	w24, w24, #1
LBB59_86:                               ;   in Loop: Header=BB59_59 Depth=1
	add	x28, x28, #1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cmp	x28, x8
	b.ne	LBB59_59
; %bb.87:
	and	w8, w24, #0xffff
	b	LBB59_92
LBB59_88:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #576]
	cmp	w8, #2
	b.eq	LBB59_36
; %bb.89:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB59_37
; %bb.90:
	mov	w8, #8                          ; =0x8
	b	LBB59_124
LBB59_91:
	mov	w8, #0                          ; =0x0
	mov	w26, #0                         ; =0x0
LBB59_92:
	ldrb	w9, [sp, #184]
	cmp	w9, #15
	b.ne	LBB59_97
; %bb.93:
	cmp	w26, #1
	b.eq	LBB59_97
LBB59_94:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #576]
	cmp	w8, #2
	b.eq	LBB59_36
; %bb.95:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB59_37
; %bb.96:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	w0, [x8, #336]
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #344]
	b	LBB59_37
LBB59_97:
	sub	w9, w9, #153
	cmp	w26, #0
	ccmn	w9, #2, #0, eq
	b.hs	LBB59_94
; %bb.98:
	ldrh	w9, [sp, #144]
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	cmp	w10, w9
	b.ne	LBB59_94
; %bb.99:
	ldrh	w9, [sp, #148]
	cmp	w26, w9
	b.ne	LBB59_94
; %bb.100:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w9, [x9, #-24]
	add	w8, w8, w25
	subs	w26, w9, w8
	b.lo	LBB59_94
; %bb.101:
	add	x8, sp, #776
	ldrh	w8, [x8, #114]
	cmp	w25, #0
	mov	w9, #1                          ; =0x1
	cinc	w9, w9, ne
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	add	w9, w9, w10
	cmp	w9, w8
	b.hi	LBB59_94
; %bb.102:
	ldrb	w8, [sp, #792]
	ldrb	w9, [sp, #150]
	cmp	w8, w9
	b.ne	LBB59_94
; %bb.103:
	cbz	w8, LBB59_107
; %bb.104:
	add	x8, sp, #776
	ldur	x8, [x8, #20]
	ldr	x9, [sp, #152]
	eor	x8, x9, x8
	tst	x8, #0xff
	b.ne	LBB59_94
; %bb.105:
	mov	x9, #-256                       ; =0xffffffffffffff00
	movk	x9, #0, lsl #16
	tst	x8, x9
	b.ne	LBB59_94
; %bb.106:
	ldr	x9, [sp, #160]
	add	x8, sp, #776
	ldur	x8, [x8, #28]
	cmp	x8, x9
	b.ne	LBB59_94
LBB59_107:
	add	x3, sp, #55
	mov	x0, x19
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	w2, #0                          ; =0x0
	bl	_frc_edge
	tbz	w0, #0, LBB59_94
; %bb.108:
	ldrb	w8, [sp, #792]
	ldrh	w20, [sp, #102]
	add	w8, w26, w8
	cmp	w8, w20
	b.ne	LBB59_94
; %bb.109:
	add	x8, sp, #776
	ldrh	w8, [x8, #110]
	cmp	w20, w8
	b.hi	LBB59_94
; %bb.110:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w1, [x8]
	add	x8, sp, #176
	ldrh	w2, [x8, #72]
	ldrb	w3, [sp, #55]
	add	x4, sp, #1000
	add	x5, sp, #920
	mov	x0, x19
	bl	_fr_instruction
	cbz	w0, LBB59_94
; %bb.111:
	ldrb	w8, [sp, #920]
	tbz	w8, #0, LBB59_94
; %bb.112:
	add	x8, sp, #776
	ldrh	w8, [x8, #148]
	cmp	w20, w8
	b.ne	LBB59_94
; %bb.113:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w9, [x8, #-28]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldr	w11, [x10, #580]
	add	x8, sp, #776
	ldrh	w8, [x8, #110]
	cmp	w11, #0
	csel	w8, w26, w8, eq
	ldrh	w3, [x10, #584]
	add	x2, x8, x9
	add	x4, sp, #56
	add	x5, sp, #776
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_frf_layout
	cbz	w0, LBB59_94
; %bb.114:
	add	x4, sp, #1000
	add	x5, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	w2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_fr_instruction
	cbz	w0, LBB59_94
; %bb.115:
	ldrb	w8, [sp, #920]
	tbz	w8, #0, LBB59_94
; %bb.116:
	add	x8, sp, #776
	ldrh	w8, [x8, #148]
	cbnz	w8, LBB59_94
; %bb.117:
	add	x8, sp, #776
	ldrh	w8, [x8, #38]
	ldp	w23, w9, [sp, #64]
	add	w11, w9, w8
	cmp	w23, w11
	b.hs	LBB59_130
; %bb.118:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w9, w8, w26
	mov	w10, #168                       ; =0xa8
	umull	x10, w23, w10
	sub	w11, w11, w23
	mov	x12, x23
	b	LBB59_126
LBB59_119:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #576]
	cmp	w8, #2
	b.ne	LBB59_122
; %bb.120:
	mov	w0, #8                          ; =0x8
	b	LBB59_37
LBB59_121:
	bl	___stack_chk_fail
LBB59_122:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #336]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB59_37
; %bb.123:
	mov	w8, #4                          ; =0x4
LBB59_124:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w0, [x9, #336]
	str	w8, [x9, #344]
	b	LBB59_37
LBB59_125:                              ;   in Loop: Header=BB59_126 Depth=1
	add	x12, x12, #1
	add	x10, x10, #168
	subs	w11, w11, #1
	b.eq	LBB59_130
LBB59_126:                              ; =>This Inner Loop Header: Depth=1
	cmp	x12, x9
	b.lo	LBB59_128
; %bb.127:                              ;   in Loop: Header=BB59_126 Depth=1
	ldr	x13, [sp, #16]                  ; 8-byte Folded Reload
	ldur	w13, [x13, #-24]
	add	w13, w13, w8
	cmp	x12, x13
	b.lo	LBB59_125
LBB59_128:                              ;   in Loop: Header=BB59_126 Depth=1
	ldr	w13, [x19, #128]
	cmp	x12, x13
	b.hs	LBB59_94
; %bb.129:                              ;   in Loop: Header=BB59_126 Depth=1
	ldr	x13, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x13, [x13, #296]
	ldrb	w13, [x13, x10]
	cmp	w13, #1
	b.ne	LBB59_125
	b	LBB59_94
LBB59_130:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #304]
	ldr	w24, [sp, #80]
	mov	w9, #256                        ; =0x100
	mov	w10, #56                        ; =0x38
	mov	x11, x24
LBB59_131:                              ; =>This Inner Loop Header: Depth=1
	umull	x12, w11, w10
	ldrb	w12, [x8, x12]
	cmp	w12, #1
	b.eq	LBB59_94
; %bb.132:                              ;   in Loop: Header=BB59_131 Depth=1
	add	w11, w11, #1
	subs	x9, x9, #1
	b.ne	LBB59_131
; %bb.133:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cbz	w8, LBB59_151
; %bb.134:
	mov	w21, #0                         ; =0x0
	mov	w20, #0                         ; =0x0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w22, w8, w26
	add	x8, sp, #1000
	orr	x25, x8, #0x3
	b	LBB59_137
LBB59_135:                              ;   in Loop: Header=BB59_137 Depth=1
	and	w8, w28, #0x1
	add	w20, w20, w8
	add	w22, w22, #1
LBB59_136:                              ;   in Loop: Header=BB59_137 Depth=1
	add	w21, w21, #1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w8, w21, uxth
	b.ls	LBB59_152
LBB59_137:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB59_145 Depth 2
	and	w2, w21, #0xffff
	add	x3, sp, #920
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	bl	_fr_local
	tbz	w0, #0, LBB59_169
; %bb.138:                              ;   in Loop: Header=BB59_137 Depth=1
	ldrb	w8, [sp, #921]
	cbnz	w8, LBB59_136
; %bb.139:                              ;   in Loop: Header=BB59_137 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w22, w9, x8
	ldrb	w9, [x8]
	ldrb	w28, [x8, #1]
	ldrb	w27, [x8, #2]
	ldur	q0, [x8, #67]
	str	q0, [x25, #64]
	ldur	q0, [x8, #83]
	str	q0, [x25, #80]
	ldur	q0, [x8, #99]
	str	q0, [x25, #96]
	ldr	x10, [x8, #112]
	stur	x10, [x25, #109]
	ldur	q0, [x8, #3]
	str	q0, [x25]
	ldur	q0, [x8, #19]
	str	q0, [x25, #16]
	ldur	q0, [x8, #35]
	str	q0, [x25, #32]
	ldur	q0, [x8, #51]
	str	q0, [x25, #48]
	strb	w9, [sp, #1000]
	strb	w28, [sp, #1001]
	strb	w27, [sp, #1002]
	add	x8, sp, #776
	ldp	x1, x2, [x8, #144]
	add	x0, sp, #1000
	bl	_frf_matches
	cbz	w0, LBB59_147
; %bb.140:                              ;   in Loop: Header=BB59_137 Depth=1
	tbnz	w27, #0, LBB59_147
; %bb.141:                              ;   in Loop: Header=BB59_137 Depth=1
	tbz	w28, #0, LBB59_135
; %bb.142:                              ;   in Loop: Header=BB59_137 Depth=1
	ldr	w8, [x19, #132]
	cbz	w8, LBB59_135
; %bb.143:                              ;   in Loop: Header=BB59_137 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x9, #304]
	add	x9, x9, #4
	b	LBB59_145
LBB59_144:                              ;   in Loop: Header=BB59_145 Depth=2
	add	x9, x9, #56
	subs	x8, x8, #1
	b.eq	LBB59_135
LBB59_145:                              ;   Parent Loop BB59_137 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB59_144
; %bb.146:                              ;   in Loop: Header=BB59_145 Depth=2
	ldr	w10, [x9]
	cmp	w10, w22
	b.ne	LBB59_144
LBB59_147:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #576]
	cmp	w8, #2
	b.eq	LBB59_150
; %bb.148:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #336]
	cbnz	w8, LBB59_150
; %bb.149:
	mov	w8, #6                          ; =0x6
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w8, [x9, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #344]
LBB59_150:
	mov	w0, #6                          ; =0x6
	b	LBB59_37
LBB59_151:
	mov	w20, #0                         ; =0x0
LBB59_152:
	ldrh	w8, [sp, #146]
	cmp	w8, w20, uxth
	b.ne	LBB59_94
; %bb.153:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w8, #152
	b.eq	LBB59_155
; %bb.154:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w8, #60
	b.ne	LBB59_156
LBB59_155:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #296]
	mov	w10, #168                       ; =0xa8
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	umaddl	x8, w8, w10, x9
	str	xzr, [x8, #160]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
LBB59_156:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cbz	w8, LBB59_172
; %bb.157:
	mov	w20, #0                         ; =0x0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-28]
	add	w21, w8, w26
	b	LBB59_159
LBB59_158:                              ;   in Loop: Header=BB59_159 Depth=1
	add	w20, w20, #1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w8, w20
	b.eq	LBB59_163
LBB59_159:                              ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #1000
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x20
	bl	_fr_local
	tbz	w0, #0, LBB59_94
; %bb.160:                              ;   in Loop: Header=BB59_159 Depth=1
	ldrb	w8, [sp, #1001]
	cbnz	w8, LBB59_158
; %bb.161:                              ;   in Loop: Header=BB59_159 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-20]
	add	w2, w20, w8
	mov	x0, x19
	mov	x1, x21
	bl	_nvm_socket_runtime_move
	cbnz	w0, LBB59_37
; %bb.162:                              ;   in Loop: Header=BB59_159 Depth=1
	add	w21, w21, #1
	b	LBB59_158
LBB59_163:
	mov	x20, #0                         ; =0x0
	add	x21, sp, #1600
	b	LBB59_166
LBB59_164:                              ;   in Loop: Header=BB59_166 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w8, [x8, #-20]
	add	w1, w20, w8
	mov	x0, x19
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_socket_runtime_move
	cbnz	w0, LBB59_37
LBB59_165:                              ;   in Loop: Header=BB59_166 Depth=1
	add	x20, x20, #1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cmp	x8, x20
	b.eq	LBB59_172
LBB59_166:                              ; =>This Inner Loop Header: Depth=1
	add	x3, sp, #1000
	mov	x0, x19
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	mov	x2, x20
	bl	_fr_local
	tbz	w0, #0, LBB59_169
; %bb.167:                              ;   in Loop: Header=BB59_166 Depth=1
	ldrb	w8, [sp, #1001]
	add	x2, x23, x20
	cbz	w8, LBB59_164
; %bb.168:                              ;   in Loop: Header=BB59_166 Depth=1
	ldr	w1, [x21, x20, lsl #2]
	add	w3, w24, w20
	mov	x0, x19
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_socket_runtime_bind_formal
	cbz	w0, LBB59_165
	b	LBB59_37
LBB59_169:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #576]
	cmp	w8, #2
	b.eq	LBB59_36
; %bb.170:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #336]
	cbnz	w8, LBB59_36
; %bb.171:
	mov	w8, #5                          ; =0x5
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	str	w8, [x9, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x9, #344]
	b	LBB59_36
LBB59_172:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	stur	w26, [x9, #-24]
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	stur	w8, [x9, #-4]
	mov	w8, #1                          ; =0x1
	sturh	w8, [x9, #-8]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	add	w11, w10, #1
	strh	w11, [x8, #584]
	mov	w8, #40                         ; =0x28
	umaddl	x8, w10, w8, x9
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [x8]
	ldr	x9, [sp, #88]
	str	x9, [x8, #32]
	ldr	w8, [x19, #24]
	cbz	w8, LBB59_175
; %bb.173:
	add	x1, sp, #56
	mov	x0, x19
	bl	_frc_validate
	cbz	w0, LBB59_175
; %bb.174:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w0, [x8, #336]
	b	LBB59_37
LBB59_175:
	ldr	w1, [sp, #56]
	mov	x0, x19
	mov	w2, #0                          ; =0x0
	bl	_nvm_socket_runtime_site
	b	LBB59_37
	.loh AdrpLdrGotLdr	Lloh34, Lloh35, Lloh36
	.loh AdrpLdrGotLdr	Lloh37, Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_call_target
_fr_call_target:                        ; @fr_call_target
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x3
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2, #8]
	cmp	w9, #59
	b.le	LBB60_4
; %bb.1:
	cmp	w9, #60
	b.eq	LBB60_9
; %bb.2:
	cmp	w9, #152
	b.eq	LBB60_9
; %bb.3:
	cmp	w9, #151
	b.eq	LBB60_6
	b	LBB60_8
LBB60_4:
	cmp	w9, #15
	b.eq	LBB60_6
; %bb.5:
	cmp	w9, #59
	b.ne	LBB60_8
LBB60_6:
	ldr	w8, [x2, #16]
	cmp	w8, w19
LBB60_7:
	cset	w0, eq
LBB60_8:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB60_9:
	mov	w0, #0                          ; =0x0
	cmp	w19, #63
	b.hi	LBB60_8
; %bb.10:
	ldr	w9, [x8, #24]
	cmp	w9, #2
	b.ne	LBB60_8
; %bb.11:
	ldr	x0, [x8, #16]
	ldr	w8, [x1]
	ldrh	w2, [x1, #4]
	ldrb	w3, [x1, #34]
	mov	x4, sp
	mov	x1, x8
	bl	_nvm_socket_indirect_hosted_call
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB60_8
; %bb.12:
	ldr	x8, [sp, #8]
	cbz	x8, LBB60_8
; %bb.13:
	ldr	x9, [sp, #16]
	cmp	x8, x9
	b.ne	LBB60_8
; %bb.14:
	lsr	x8, x8, x19
	tbz	w8, #0, LBB60_16
; %bb.15:
	ldr	w8, [sp, #32]
	cmn	w8, #1
	b	LBB60_7
LBB60_16:
	mov	w0, #0                          ; =0x0
	b	LBB60_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_return ; -- Begin function nvm_socket_runtime_frame_return
	.p2align	2
_nvm_socket_runtime_frame_return:       ; @nvm_socket_runtime_frame_return
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #2272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh40:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh41:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh42:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	cbz	x0, LBB61_3
; %bb.1:
	mov	x19, x0
	add	x23, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x23, #586]
	tbz	w8, #0, LBB61_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB61_22
LBB61_3:
	mov	w0, #1                          ; =0x1
	b	LBB61_22
LBB61_4:
	ldr	w8, [x23, #576]
	cmp	w8, #1
	b.ne	LBB61_21
; %bb.5:
	ldr	w0, [x23, #336]
	cbnz	w0, LBB61_22
; %bb.6:
	ldrb	w8, [x23, #588]
	tbz	w8, #0, LBB61_9
LBB61_7:
	mov	w0, #5                          ; =0x5
LBB61_8:
	str	w0, [x23, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #344]
	b	LBB61_22
LBB61_9:
	add	x1, sp, #896
	add	x2, sp, #296
	add	x3, sp, #216
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB61_19
; %bb.10:
	mov	x12, x19
	ldr	w10, [x19, #24]
	ldr	x8, [x23, #320]
	ldrh	w9, [x23, #584]
	cbz	w10, LBB61_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB61_19
LBB61_12:
	mov	w10, #40                        ; =0x28
	umaddl	x24, w9, w10, x8
	mov	x8, x24
	ldr	w9, [x8, #-40]!
	str	w9, [x23, #348]
	ldr	w9, [sp, #296]
	str	w9, [x23, #352]
	ldrb	w9, [sp, #304]
	cmp	w9, #61
	b.ne	LBB61_17
; %bb.13:
	ldrb	w9, [sp, #217]
	tbz	w9, #0, LBB61_17
; %bb.14:
	ldrb	w9, [sp, #372]
	cbnz	w9, LBB61_17
; %bb.15:
	ldrb	w9, [sp, #912]
	ldur	w26, [x24, #-24]
	cmp	w26, w9
	b.ne	LBB61_17
; %bb.16:
	ldrh	w11, [sp, #934]
	cmp	w11, w9
	b.hs	LBB61_24
LBB61_17:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB61_21
; %bb.18:
	ldr	w8, [x23, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB61_22
	b	LBB61_8
LBB61_19:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB61_21
; %bb.20:
	ldr	w8, [x23, #336]
	cbz	w8, LBB61_7
LBB61_21:
	mov	w0, #5                          ; =0x5
LBB61_22:
	ldur	x8, [x29, #-104]
Lloh43:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh44:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh45:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB61_121
; %bb.23:
	add	sp, sp, #2272
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB61_24:
	ldur	w10, [x24, #-28]
	ldr	w13, [x12, #128]
	cmp	w10, w13
	b.hi	LBB61_17
; %bb.25:
	sub	x12, x13, x10
	cmp	x12, x11
	b.lo	LBB61_17
; %bb.26:
	ldur	w14, [x24, #-20]
	cmp	w14, w13
	b.hi	LBB61_17
; %bb.27:
	ldrh	w12, [sp, #938]
	sub	x15, x13, x14
	cmp	x15, x12
	b.lo	LBB61_17
; %bb.28:
	cbz	w12, LBB61_33
; %bb.29:
	sub	w13, w13, w14
	mov	w15, #168                       ; =0xa8
	umull	x14, w14, w15
LBB61_30:                               ; =>This Inner Loop Header: Depth=1
	cbz	x13, LBB61_17
; %bb.31:                               ;   in Loop: Header=BB61_30 Depth=1
	ldr	x15, [x23, #296]
	ldrb	w15, [x15, x14]
	tbnz	w15, #0, LBB61_17
; %bb.32:                               ;   in Loop: Header=BB61_30 Depth=1
	add	x14, x14, #168
	sub	x13, x13, #1
	sub	x12, x12, #1
	cbnz	x12, LBB61_30
LBB61_33:
	cbz	w11, LBB61_40
; %bb.34:
	mov	x12, #0                         ; =0x0
	ldr	x13, [x23, #296]
	mov	w14, #168                       ; =0xa8
	b	LBB61_37
LBB61_35:                               ;   in Loop: Header=BB61_37 Depth=1
	tbnz	w16, #0, LBB61_17
LBB61_36:                               ;   in Loop: Header=BB61_37 Depth=1
	add	x12, x12, #1
	cmp	x11, x12
	b.eq	LBB61_40
LBB61_37:                               ; =>This Inner Loop Header: Depth=1
	add	w15, w10, w12
	umaddl	x15, w15, w14, x13
	ldrb	w16, [x15]
	cmp	x12, x9
	b.hs	LBB61_35
; %bb.38:                               ;   in Loop: Header=BB61_37 Depth=1
	cbz	w16, LBB61_17
; %bb.39:                               ;   in Loop: Header=BB61_37 Depth=1
	ldrb	w15, [x15, #2]
	tbz	w15, #0, LBB61_36
	b	LBB61_17
LBB61_40:
	ldr	w11, [x23, #596]
	ldur	w12, [x24, #-12]
	cmp	w11, w12
	b.ne	LBB61_17
; %bb.41:
	stp	x9, x8, [sp]                    ; 16-byte Folded Spill
	str	x10, [sp, #40]                  ; 8-byte Folded Spill
	cbz	w9, LBB61_46
; %bb.42:
	ldr	x20, [x23, #296]
	mov	w9, #168                        ; =0xa8
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	umaddl	x0, w8, w9, x20
	add	x8, sp, #896
	ldur	x1, [x8, #20]
	ldur	x2, [x8, #28]
	bl	_frf_matches
	cbz	w0, LBB61_44
; %bb.43:
	mov	w9, #168                        ; =0xa8
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	umaddl	x8, w8, w9, x20
	ldrb	w8, [x8, #2]
	tbz	w8, #0, LBB61_83
LBB61_44:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.ne	LBB61_72
; %bb.45:
	mov	w0, #6                          ; =0x6
	b	LBB61_22
LBB61_46:
	mov	w8, #-1                         ; =0xffffffff
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
LBB61_47:
	ldrh	w8, [sp, #936]
	cbz	w8, LBB61_74
; %bb.48:
	mov	w20, #0                         ; =0x0
	b	LBB61_50
LBB61_49:                               ;   in Loop: Header=BB61_50 Depth=1
	add	w20, w20, #1
	ldrh	w8, [sp, #936]
	cmp	w20, w8
	b.hs	LBB61_74
LBB61_50:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #296]
	ldur	w9, [x24, #-32]
	add	w9, w20, w9
	mov	w10, #168                       ; =0xa8
	umaddl	x8, w9, w10, x8
	ldr	s0, [x8]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	ldrb	w22, [x8, #2]
	ldrb	w27, [x8, #1]
	ldrb	w28, [x8]
	ldur	x21, [x8, #4]
	ldur	x25, [x8, #12]
	ldur	q0, [x8, #68]
	str	q0, [sp, #1696]
	ldur	q0, [x8, #84]
	str	q0, [sp, #1712]
	ldur	q0, [x8, #100]
	str	q0, [sp, #1728]
	ldr	w9, [x8, #116]
	str	w9, [sp, #1744]
	ldur	q0, [x8, #20]
	str	q0, [sp, #1648]
	ldur	q0, [x8, #36]
	str	q0, [sp, #1664]
	ldur	q0, [x8, #52]
	str	q0, [sp, #1680]
	ldur	w1, [x24, #-40]
	ldr	w8, [x19, #24]
	cbz	w8, LBB61_53
; %bb.51:                               ;   in Loop: Header=BB61_50 Depth=1
	cmp	w8, #2
	b.ne	LBB61_54
; %bb.52:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x0, [x19, #16]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_socket_indirect_hosted_local
	b	LBB61_55
LBB61_53:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x0, [x19]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_socket_hosted_local
	b	LBB61_55
LBB61_54:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x0, [x19, #8]
	add	x3, sp, #968
	mov	x2, x20
	bl	_nvm_socket_cyclic_hosted_local
LBB61_55:                               ;   in Loop: Header=BB61_50 Depth=1
	cbz	w0, LBB61_69
; %bb.56:                               ;   in Loop: Header=BB61_50 Depth=1
	and	w8, w28, w27
	tbnz	w8, #0, LBB61_69
; %bb.57:                               ;   in Loop: Header=BB61_50 Depth=1
	ldrb	w8, [sp, #969]
	cbz	w8, LBB61_62
; %bb.58:                               ;   in Loop: Header=BB61_50 Depth=1
	tbz	w28, #0, LBB61_69
; %bb.59:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x9, [sp, #968]
	ldr	x8, [sp, #976]
	eor	x10, x9, x21
	and	x11, x10, #0xff
	cmp	x11, #0
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	and	x10, x10, x11
	ccmp	x10, #0, #0, eq
	ccmp	x25, x8, #0, eq
	b.ne	LBB61_69
; %bb.60:                               ;   in Loop: Header=BB61_50 Depth=1
	ands	x9, x9, #0xff00
	cset	w10, ne
	cmp	w22, w10
	b.ne	LBB61_69
; %bb.61:                               ;   in Loop: Header=BB61_50 Depth=1
	lsr	x8, x8, #32
	sub	x8, x8, #1
	cmp	x9, #0
	ccmp	x8, #2, #2, eq
	cset	w8, lo
	cmp	w27, w8
	b.ne	LBB61_69
LBB61_62:                               ;   in Loop: Header=BB61_50 Depth=1
	tbz	w22, #0, LBB61_49
; %bb.63:                               ;   in Loop: Header=BB61_50 Depth=1
	ldrh	w8, [sp, #908]
	cmp	w20, w8
	b.hs	LBB61_69
; %bb.64:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	ushll.8h	v0, v0, #0
	ldur	w22, [x24, #-16]
	uzp1.8b	v0, v0, v0
	str	s0, [sp, #1048]
	ldr	q0, [sp, #1696]
	ldr	q1, [sp, #1680]
	add	x9, sp, #1048
	stur	q0, [x9, #68]
	ldr	q0, [sp, #1712]
	ldr	q2, [sp, #1728]
	stur	q0, [x9, #84]
	stur	q2, [x9, #100]
	ldr	q0, [sp, #1648]
	ldr	q2, [sp, #1664]
	stur	q0, [x9, #20]
	stur	q2, [x9, #36]
	add	x8, sp, #896
	stur	x21, [x8, #156]
	stur	x25, [x8, #164]
	ldr	w8, [sp, #1744]
	stur	w8, [x9, #116]
	stur	q1, [x9, #52]
	ldr	x1, [sp, #968]
	ldr	x2, [sp, #976]
	add	x0, sp, #1048
	bl	_frf_matches
	cbz	w0, LBB61_69
; %bb.65:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x8, [x23, #296]
	ldur	w9, [x24, #-32]
	add	w25, w20, w9
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w25, w9, x8
	ldr	w8, [x8, #144]
	add	w21, w20, w22
	cmp	w21, w8
	b.ne	LBB61_69
; %bb.66:                               ;   in Loop: Header=BB61_50 Depth=1
	mov	x0, x19
	mov	x1, x21
	bl	_fr_reference
	cbz	w0, LBB61_69
; %bb.67:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	x8, [x23, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x8, w21, w9, x8
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	b.ne	LBB61_69
; %bb.68:                               ;   in Loop: Header=BB61_50 Depth=1
	ldr	w8, [x8, #12]
	cmp	w25, w8
	b.eq	LBB61_49
LBB61_69:
	ldr	w8, [x23, #576]
	cmp	w8, #2
	b.eq	LBB61_21
; %bb.70:
	ldr	w8, [x23, #336]
	cbnz	w8, LBB61_21
; %bb.71:
	mov	w8, #5                          ; =0x5
	str	w8, [x23, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x23, #344]
	b	LBB61_21
LBB61_72:
	ldr	w8, [x23, #336]
	mov	w0, #6                          ; =0x6
	cbnz	w8, LBB61_22
; %bb.73:
	str	w0, [x23, #336]
	mov	w8, #3                          ; =0x3
	str	w8, [x23, #344]
	b	LBB61_22
LBB61_74:
	mov	x20, #0                         ; =0x0
	ldr	x21, [x23, #304]
	ldur	w22, [x24, #-16]
	mov	w25, #56                        ; =0x38
	mov	w27, #168                       ; =0xa8
	ldrh	w28, [sp, #908]
	b	LBB61_76
LBB61_75:                               ;   in Loop: Header=BB61_76 Depth=1
	add	x20, x20, #1
	cmp	x20, #256
	b.eq	LBB61_88
LBB61_76:                               ; =>This Inner Loop Header: Depth=1
	add	x1, x22, x20
	umaddl	x8, w1, w25, x21
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB61_75
; %bb.77:                               ;   in Loop: Header=BB61_76 Depth=1
	ldrb	w9, [x8, #1]
	cmp	w9, #1
	ccmp	x20, x28, #2, eq
	b.hs	LBB61_17
; %bb.78:                               ;   in Loop: Header=BB61_76 Depth=1
	ldur	w9, [x24, #-32]
	ldr	w10, [x19, #128]
	add	x9, x20, x9
	cmp	w9, w10
	b.hs	LBB61_17
; %bb.79:                               ;   in Loop: Header=BB61_76 Depth=1
	ldr	x10, [x23, #296]
	mov	w11, w9
	umull	x12, w11, w27
	ldrb	w12, [x10, x12]
	cmp	w12, #1
	b.ne	LBB61_17
; %bb.80:                               ;   in Loop: Header=BB61_76 Depth=1
	umaddl	x10, w11, w27, x10
	ldrb	w10, [x10, #2]
	cmp	w10, #1
	b.ne	LBB61_17
; %bb.81:                               ;   in Loop: Header=BB61_76 Depth=1
	ldr	w8, [x8, #12]
	cmp	w9, w8
	b.ne	LBB61_17
; %bb.82:                               ;   in Loop: Header=BB61_76 Depth=1
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_fr_reference
	tbnz	w0, #0, LBB61_75
	b	LBB61_17
LBB61_83:
	ldr	w8, [x19, #132]
	cbz	w8, LBB61_47
; %bb.84:
	ldr	x9, [x23, #304]
	add	x9, x9, #4
	b	LBB61_86
LBB61_85:                               ;   in Loop: Header=BB61_86 Depth=1
	add	x9, x9, #56
	subs	x8, x8, #1
	b.eq	LBB61_47
LBB61_86:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w10, [x9, #-4]
	cmp	w10, #1
	b.ne	LBB61_85
; %bb.87:                               ;   in Loop: Header=BB61_86 Depth=1
	ldr	w11, [x9]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	cmp	w11, w10
	b.ne	LBB61_85
	b	LBB61_44
LBB61_88:
	strb	wzr, [sp, #215]
	str	xzr, [sp, #192]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	add	x0, sp, #1648
	mov	w1, #600                        ; =0x258
	bl	_bzero
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	str	q0, [sp, #48]
	ldrh	w8, [x23, #584]
	cmp	x8, #2
	b.lo	LBB61_109
; %bb.89:
	ldr	x9, [x23, #320]
	sub	w8, w8, #2
	mov	w10, #40                        ; =0x28
	umaddl	x20, w8, w10, x9
	ldrb	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB61_17
; %bb.90:
	ldr	w1, [x20]
	add	x2, sp, #128
	mov	x0, x19
	bl	_fr_function
	cbz	w0, LBB61_17
; %bb.91:
	ldr	w1, [x20]
	ldrh	w2, [x20, #4]
	ldrb	w3, [x20, #34]
	add	x4, sp, #1648
	add	x5, sp, #48
	mov	x0, x19
	bl	_fr_instruction
	ldrb	w8, [sp, #1724]
	cmp	w0, #0
	ccmp	w8, #1, #0, ne
	b.ne	LBB61_17
; %bb.92:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w3, [x8]
	add	x2, sp, #1648
	mov	x0, x19
	mov	x1, x20
	bl	_fr_call_target
	cbz	w0, LBB61_17
; %bb.93:
	ldr	w9, [x20, #36]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8]
	cmp	w9, w8
	b.ne	LBB61_17
; %bb.94:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB61_17
; %bb.95:
	ldr	w1, [x20, #20]
	ldrh	w2, [sp, #170]
	mov	x0, x19
	bl	_frf_empty_range
	cbz	w0, LBB61_17
; %bb.96:
	ldrh	w8, [sp, #54]
	ldr	w9, [x20, #16]
	add	w9, w9, w26
	cmp	w9, w8
	b.ne	LBB61_17
; %bb.97:
	add	x3, sp, #215
	mov	x0, x19
	mov	x1, x20
	mov	w2, #0                          ; =0x0
	bl	_frc_edge
	cbz	w0, LBB61_17
; %bb.98:
	ldr	w1, [x20]
	ldrh	w2, [sp, #1720]
	ldrb	w21, [sp, #215]
	ldrh	w22, [sp, #54]
	add	x4, sp, #1048
	add	x5, sp, #968
	mov	x0, x19
	mov	x3, x21
	bl	_fr_instruction
	cbz	w0, LBB61_17
; %bb.99:
	ldrb	w8, [sp, #968]
	tbz	w8, #0, LBB61_17
; %bb.100:
	ldrh	w8, [sp, #972]
	cmp	w22, w8
	b.ne	LBB61_17
; %bb.101:
	ldr	w8, [x20, #16]
	cbz	w8, LBB61_107
; %bb.102:
	ldr	w10, [x20, #12]
	ldr	w9, [x19, #128]
	subs	w9, w9, w10
	csel	w9, wzr, w9, lo
	mov	w11, #168                       ; =0xa8
	umull	x10, w10, w11
LBB61_103:                              ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB61_17
; %bb.104:                              ;   in Loop: Header=BB61_103 Depth=1
	ldr	x11, [x23, #296]
	ldrb	w12, [x11, x10]
	cmp	w12, #1
	b.ne	LBB61_17
; %bb.105:                              ;   in Loop: Header=BB61_103 Depth=1
	add	x11, x11, x10
	ldrb	w11, [x11, #2]
	cmp	w11, #1
	b.eq	LBB61_17
; %bb.106:                              ;   in Loop: Header=BB61_103 Depth=1
	sub	x9, x9, #1
	add	x10, x10, #168
	subs	x8, x8, #1
	b.ne	LBB61_103
LBB61_107:
	ldr	w8, [x20, #20]
	ldrh	w9, [sp, #170]
	add	w8, w8, w9
	sub	w26, w8, #1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	cbz	w8, LBB61_110
; %bb.108:
	mov	x0, x19
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	mov	x2, x26
	bl	_nvm_socket_runtime_move
	cbnz	w0, LBB61_22
	b	LBB61_110
LBB61_109:
	mov	w21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w26, #-1                        ; =0xffffffff
LBB61_110:
	mov	w22, #0                         ; =0x0
	mov	w25, #56                        ; =0x38
	b	LBB61_112
LBB61_111:                              ;   in Loop: Header=BB61_112 Depth=1
	add	w22, w22, #1
	cmp	w22, #256
	b.eq	LBB61_114
LBB61_112:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #304]
	ldur	w9, [x24, #-16]
	add	w1, w22, w9
	umull	x9, w1, w25
	ldrb	w8, [x8, x9]
	cmp	w8, #1
	b.ne	LBB61_111
; %bb.113:                              ;   in Loop: Header=BB61_112 Depth=1
	mov	x0, x19
	bl	_nvm_socket_runtime_end_reference
	cbz	w0, LBB61_111
	b	LBB61_22
LBB61_114:
	cbz	x20, LBB61_126
; %bb.115:
	ldrh	w8, [sp, #934]
	ldp	w9, w10, [x24, #-32]
	add	w10, w10, w8
	cmp	w9, w10
	b.hs	LBB61_118
; %bb.116:
	mov	w8, #168                        ; =0xa8
	umull	x8, w9, w8
	sub	x9, x10, x9
	movi.2d	v0, #0000000000000000
LBB61_117:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x23, #296]
	add	x10, x10, x8
	str	xzr, [x10, #160]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10]
	add	x8, x8, #168
	subs	x9, x9, #1
	b.ne	LBB61_117
LBB61_118:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ldrh	w8, [x23, #584]
	sub	w8, w8, #1
	strh	w8, [x23, #584]
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #57]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	cbz	w8, LBB61_122
; %bb.119:
	ldp	w8, w9, [x20, #12]
	add	w2, w9, w8
	mov	x0, x19
	mov	x1, x26
	bl	_nvm_socket_runtime_move
	cbz	w0, LBB61_122
; %bb.120:
	strb	wzr, [x19, #57]
	b	LBB61_22
LBB61_121:
	bl	___stack_chk_fail
LBB61_122:
	mov	x0, x19
	strb	wzr, [x19, #57]
	ldrh	w22, [sp, #54]
	add	x2, sp, #128
	mov	x1, x20
	mov	x3, x22
	bl	_frf_stack
	tbz	w0, #0, LBB61_17
; %bb.123:
	str	w22, [x20, #16]
	strh	wzr, [x20, #32]
	ldrh	w8, [sp, #1720]
	str	w8, [x20, #4]
	strb	w21, [x20, #34]
	str	wzr, [x20, #36]
	ldr	w9, [x19, #24]
	cbz	w9, LBB61_129
; %bb.124:
	mov	x0, x19
	mov	x1, x20
	bl	_frc_validate
	cbz	w0, LBB61_128
; %bb.125:
	ldr	w0, [x23, #336]
	b	LBB61_22
LBB61_126:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	w9, [x23, #592]
	cmp	w8, w9
	b.ne	LBB61_17
; %bb.127:
	mov	x0, x19
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_socket_runtime_complete_root
	b	LBB61_22
LBB61_128:
	ldr	w8, [x20, #4]
LBB61_129:
	ldr	w1, [x20]
	and	w2, w8, #0xffff
	mov	x0, x19
	bl	_nvm_socket_runtime_site
	b	LBB61_22
	.loh AdrpLdrGotLdr	Lloh40, Lloh41, Lloh42
	.loh AdrpLdrGotLdr	Lloh43, Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_region_begin ; -- Begin function nvm_socket_runtime_frame_region_begin
	.p2align	2
_nvm_socket_runtime_frame_region_begin: ; @nvm_socket_runtime_frame_region_begin
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB62_3
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB62_4
LBB62_2:
	mov	w0, #11                         ; =0xb
	b	LBB62_28
LBB62_3:
	mov	w0, #1                          ; =0x1
	ret
LBB62_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB62_27
; %bb.5:
	mov	x19, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB62_28
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB62_9
LBB62_7:
	mov	w0, #5                          ; =0x5
LBB62_8:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB62_28
LBB62_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB62_24
; %bb.10:
	ldr	w11, [x19, #24]
	ldr	x8, [x20, #320]
	ldrh	w10, [x20, #584]
	cbz	w11, LBB62_12
; %bb.11:
	mov	w9, #40                         ; =0x28
	umaddl	x9, w10, w9, x8
	ldurb	w9, [x9, #-7]
	tbz	w9, #0, LBB62_24
LBB62_12:
	mov	w9, #40                         ; =0x28
	umaddl	x12, w10, w9, x8
	ldur	w9, [x12, #-40]
	str	w9, [x20, #348]
	ldr	w9, [sp, #80]
	str	w9, [x20, #352]
	ldrb	w9, [sp, #88]
	cmp	w9, #22
	b.ne	LBB62_26
; %bb.13:
	ldr	w9, [x20, #596]
	ldur	w12, [x12, #-12]
	subs	w12, w9, w12
	b.lo	LBB62_26
; %bb.14:
	cmp	w12, #256
	b.hs	LBB62_26
; %bb.15:
	ldrb	w12, [x20, #586]
	tbnz	w12, #0, LBB62_2
; %bb.16:
	ldr	w12, [x20, #576]
	cmp	w12, #1
	b.ne	LBB62_27
; %bb.17:
	ldr	w0, [x20, #336]
	cbnz	w0, LBB62_28
; %bb.18:
	ldrb	w12, [x20, #588]
	tbnz	w12, #0, LBB62_7
; %bb.19:
	cbz	w11, LBB62_21
; %bb.20:
	ldrb	w11, [x19, #57]
	tbz	w11, #0, LBB62_31
LBB62_21:
	ldr	w8, [x19, #136]
	cmp	w9, w8
	b.eq	LBB62_30
; %bb.22:
	ldr	x8, [x20, #600]
	cmn	x8, #1
	b.eq	LBB62_30
; %bb.23:
	mov	w0, #0                          ; =0x0
	add	x10, x8, #1
	str	x10, [x20, #600]
	ldr	x10, [x20, #312]
	add	w11, w9, #1
	str	w11, [x20, #596]
	str	x8, [x10, x9, lsl #3]
	b	LBB62_28
LBB62_24:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB62_27
; %bb.25:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB62_27
	b	LBB62_7
LBB62_26:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB62_29
LBB62_27:
	mov	w0, #5                          ; =0x5
LBB62_28:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB62_29:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB62_28
	b	LBB62_8
LBB62_30:
	mov	w0, #3                          ; =0x3
	str	w0, [x20, #336]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #344]
	b	LBB62_28
LBB62_31:
	cbz	w10, LBB62_7
; %bb.32:
	sub	w10, w10, #1
	mov	w11, #40                        ; =0x28
	umaddl	x8, w10, w11, x8
	ldrb	w10, [x8, #32]
	tbnz	w10, #0, LBB62_7
; %bb.33:
	ldrb	w8, [x8, #33]
	tbz	w8, #0, LBB62_7
	b	LBB62_21
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_region_end ; -- Begin function nvm_socket_runtime_frame_region_end
	.p2align	2
_nvm_socket_runtime_frame_region_end:   ; @nvm_socket_runtime_frame_region_end
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB63_3
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB63_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB63_19
LBB63_3:
	mov	w0, #1                          ; =0x1
	ret
LBB63_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB63_18
; %bb.5:
	mov	x19, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB63_19
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB63_9
LBB63_7:
	mov	w0, #5                          ; =0x5
LBB63_8:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB63_19
LBB63_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB63_15
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #320]
	ldrh	w9, [x20, #584]
	cbz	w10, LBB63_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB63_15
LBB63_12:
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	ldur	w9, [x8, #-40]
	str	w9, [x20, #348]
	ldr	w9, [sp, #80]
	str	w9, [x20, #352]
	ldrb	w9, [sp, #88]
	cmp	w9, #23
	b.ne	LBB63_17
; %bb.13:
	ldr	w9, [x20, #596]
	ldur	w8, [x8, #-12]
	cmp	w9, w8
	b.ls	LBB63_17
; %bb.14:
	mov	x0, x19
	bl	_nvm_socket_runtime_region_end
	b	LBB63_19
LBB63_15:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB63_18
; %bb.16:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB63_18
	b	LBB63_7
LBB63_17:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB63_20
LBB63_18:
	mov	w0, #5                          ; =0x5
LBB63_19:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB63_20:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB63_19
	b	LBB63_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_borrow ; -- Begin function nvm_socket_runtime_frame_borrow
	.p2align	2
_nvm_socket_runtime_frame_borrow:       ; @nvm_socket_runtime_frame_borrow
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB64_3
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB64_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB64_22
LBB64_3:
	mov	w0, #1                          ; =0x1
	ret
LBB64_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB64_21
; %bb.5:
	mov	x19, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB64_22
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB64_9
LBB64_7:
	mov	w0, #5                          ; =0x5
LBB64_8:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB64_22
LBB64_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB64_18
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #320]
	ldrh	w9, [x20, #584]
	cbz	w10, LBB64_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB64_18
LBB64_12:
	mov	w10, #40                        ; =0x28
	umaddl	x9, w9, w10, x8
	ldur	w8, [x9, #-40]
	str	w8, [x20, #348]
	ldr	w8, [sp, #80]
	str	w8, [x20, #352]
	ldrb	w10, [sp, #88]
	sub	w8, w10, #26
	cmn	w8, #2
	b.lo	LBB64_20
; %bb.13:
	ldrh	w8, [sp, #96]
	cmp	w8, #255
	b.hi	LBB64_20
; %bb.14:
	ldrh	w11, [sp, #104]
	ldurh	w12, [x29, #-64]
	cmp	w11, w12
	b.hs	LBB64_20
; %bb.15:
	ldr	w12, [x20, #596]
	ldur	w13, [x9, #-12]
	cmp	w12, w13
	b.ls	LBB64_20
; %bb.16:
	ldur	w12, [x9, #-32]
	ldur	w9, [x9, #-16]
	add	w1, w12, w11
	add	w2, w9, w8
	mov	x0, x19
	cmp	w10, #24
	b.ne	LBB64_24
; %bb.17:
	mov	w3, #1                          ; =0x1
	b	LBB64_25
LBB64_18:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB64_21
; %bb.19:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB64_21
	b	LBB64_7
LBB64_20:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB64_23
LBB64_21:
	mov	w0, #5                          ; =0x5
LBB64_22:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB64_23:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB64_22
	b	LBB64_8
LBB64_24:
	mov	w3, #0                          ; =0x0
LBB64_25:
	bl	_file_runtime_borrow_mode
	b	LBB64_22
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_frame_end_reference ; -- Begin function nvm_socket_runtime_frame_end_reference
	.p2align	2
_nvm_socket_runtime_frame_end_reference: ; @nvm_socket_runtime_frame_end_reference
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB65_3
; %bb.1:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB65_4
; %bb.2:
	mov	w0, #11                         ; =0xb
	b	LBB65_33
LBB65_3:
	mov	w0, #1                          ; =0x1
	ret
LBB65_4:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB65_32
; %bb.5:
	mov	x19, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB65_33
; %bb.6:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB65_9
LBB65_7:
	mov	w0, #5                          ; =0x5
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
LBB65_8:
	str	w8, [x20, #344]
	b	LBB65_33
LBB65_9:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB65_30
; %bb.10:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #320]
	ldrh	w9, [x20, #584]
	cbz	w10, LBB65_12
; %bb.11:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB65_30
LBB65_12:
	mov	w10, #40                        ; =0x28
	umaddl	x8, w9, w10, x8
	ldur	w9, [x8, #-40]
	str	w9, [x20, #348]
	ldr	w9, [sp, #80]
	str	w9, [x20, #352]
	ldrb	w9, [sp, #88]
	cmp	w9, #150
	b.ne	LBB65_28
; %bb.13:
	ldrh	w9, [sp, #96]
	cmp	w9, #255
	b.hi	LBB65_28
; %bb.14:
	ldur	w8, [x8, #-16]
	ldr	w10, [x19, #132]
	add	w1, w8, w9
	cmp	w1, w10
	b.hs	LBB65_28
; %bb.15:
	ldr	x8, [x20, #304]
	mov	w9, #56                         ; =0x38
	umaddl	x9, w1, w9, x8
	ldrb	w11, [x9]
	cmp	w11, #1
	b.ne	LBB65_28
; %bb.16:
	ldr	w11, [x9, #8]
	cmp	w11, w10
	b.hs	LBB65_28
; %bb.17:
	mov	w10, #56                        ; =0x38
	umaddl	x10, w11, w10, x8
	ldrb	w12, [x10]
	cmp	w12, #1
	b.ne	LBB65_28
; %bb.18:
	ldrb	w12, [x10, #1]
	tbnz	w12, #0, LBB65_28
; %bb.19:
	ldr	w12, [x10, #8]
	cmp	w12, w11
	b.ne	LBB65_28
; %bb.20:
	ldrb	w11, [x10, #2]
	ldrb	w12, [x9, #2]
	cmp	w11, w12
	b.ne	LBB65_28
; %bb.21:
	ldr	x11, [x10, #48]
	ldr	x12, [x9, #48]
	cmp	x11, x12
	b.ne	LBB65_28
; %bb.22:
	ldr	w10, [x10, #4]
	ldr	w9, [x9, #4]
	cmp	w10, w9
	b.ne	LBB65_28
; %bb.23:
	ldr	w9, [x19, #128]
	cmp	w10, w9
	b.hs	LBB65_28
; %bb.24:
	ldr	x9, [x20, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x9, w10, w11, x9
	ldrb	w10, [x9]
	cmp	w10, #1
	b.ne	LBB65_28
; %bb.25:
	ldrb	w10, [x9, #1]
	cmp	w10, #1
	b.ne	LBB65_28
; %bb.26:
	ldr	w9, [x9, #16]
	cmp	w9, #1
	b.ne	LBB65_28
; %bb.27:
	mov	w9, #56                         ; =0x38
	umaddl	x8, w1, w9, x8
	ldrb	w8, [x8, #1]
	cmp	w8, #1
	b.ne	LBB65_36
LBB65_28:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB65_34
; %bb.29:
	mov	w0, #8                          ; =0x8
	b	LBB65_33
LBB65_30:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB65_32
; %bb.31:
	ldr	w8, [x20, #336]
	cbz	w8, LBB65_7
LBB65_32:
	mov	w0, #5                          ; =0x5
LBB65_33:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
LBB65_34:
	ldr	w8, [x20, #336]
	mov	w0, #8                          ; =0x8
	cbnz	w8, LBB65_33
; %bb.35:
	str	w0, [x20, #336]
	mov	w8, #4                          ; =0x4
	b	LBB65_8
LBB65_36:
	mov	x0, x19
                                        ; kill: def $w1 killed $w1 killed $x1
	bl	_nvm_socket_runtime_end_reference
	b	LBB65_33
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_cyclic_plan ; -- Begin function nvm_socket_runtime_cyclic_plan
	.p2align	2
_nvm_socket_runtime_cyclic_plan:        ; @nvm_socket_runtime_cyclic_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB66_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB66_4
; %bb.2:
	ldr	x0, [x0, #8]
LBB66_3:
	ret
LBB66_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_socket_runtime_cyclic_frame_view
lCPI67_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_cyclic_frame_view
	.p2align	2
_nvm_socket_runtime_cyclic_frame_view:  ; @nvm_socket_runtime_cyclic_frame_view
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x0
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB67_6
; %bb.1:
	cbz	x1, LBB67_6
; %bb.2:
	ldr	w8, [x19, #24]
	cmp	w8, #1
	b.ne	LBB67_5
; %bb.3:
	mov	x20, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	tbz	w0, #0, LBB67_5
; %bb.4:
	add	x8, x19, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldr	w8, [x8, #580]
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	ldur	q1, [x9, #-32]
Lloh46:
	adrp	x14, lCPI67_0@PAGE
Lloh47:
	ldr	q2, [x14, lCPI67_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	ldurb	w14, [x9, #-6]
	ldurb	w9, [x9, #-7]
	mov	w0, #1                          ; =0x1
	stp	w0, w8, [x20]
	str	d0, [x20, #8]
	str	w11, [x20, #16]
	strh	w10, [x20, #20]
	stur	w12, [x20, #22]
	strh	w13, [x20, #26]
	stur	q1, [x20, #28]
	stur	d2, [x20, #44]
	strb	w14, [x20, #52]
	strb	w9, [x20, #53]
	strh	wzr, [x20, #54]
	b	LBB67_6
LBB67_5:
	mov	w0, #0                          ; =0x0
LBB67_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_cyclic_enter ; -- Begin function nvm_socket_runtime_cyclic_enter
	.p2align	2
_nvm_socket_runtime_cyclic_enter:       ; @nvm_socket_runtime_cyclic_enter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB68_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB68_3
; %bb.2:
	b	_frc_enter
LBB68_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_enter
_frc_enter:                             ; @frc_enter
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	add	x20, x0, #8, lsl #12            ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB69_2
; %bb.1:
	mov	w0, #11                         ; =0xb
	b	LBB69_11
LBB69_2:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB69_10
; %bb.3:
	mov	x19, x0
	ldr	w0, [x20, #336]
	cbnz	w0, LBB69_11
; %bb.4:
	ldrb	w8, [x20, #588]
	cmp	w8, #1
	b.ne	LBB69_7
; %bb.5:
	mov	w0, #5                          ; =0x5
LBB69_6:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB69_11
LBB69_7:
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	tbz	w0, #0, LBB69_9
; %bb.8:
	ldr	x8, [x20, #320]
	ldrh	w9, [x20, #584]
	mov	w10, #40                        ; =0x28
	umaddl	x21, w9, w10, x8
	ldurb	w8, [x21, #-7]
	cmp	w8, #1
	b.ne	LBB69_13
LBB69_9:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB69_12
LBB69_10:
	mov	w0, #5                          ; =0x5
LBB69_11:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB69_12:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB69_11
	b	LBB69_6
LBB69_13:
	mov	x1, x21
	ldr	w8, [x1, #-40]!
	str	w8, [x20, #348]
	ldr	w8, [sp, #80]
	str	w8, [x20, #352]
	mov	x0, x19
	bl	_frc_validate
	cbnz	w0, LBB69_11
; %bb.14:
	ldp	x9, x8, [x19, #40]
	cmp	x8, x9
	b.hi	LBB69_9
; %bb.15:
	b.ne	LBB69_18
; %bb.16:
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #56]
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.ne	LBB69_19
; %bb.17:
	mov	w0, #3                          ; =0x3
	b	LBB69_11
LBB69_18:
	mov	w0, #0                          ; =0x0
	add	x8, x8, #1
	str	x8, [x19, #48]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x21, #-7]
	b	LBB69_11
LBB69_19:
	ldr	w8, [x20, #336]
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB69_11
; %bb.20:
	str	w0, [x20, #336]
	mov	w8, #5                          ; =0x5
	str	w8, [x20, #344]
	b	LBB69_11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_runtime_cyclic_report
lCPI70_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_cyclic_report
	.p2align	2
_nvm_socket_runtime_cyclic_report:      ; @nvm_socket_runtime_cyclic_report
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB70_6
; %bb.1:
	cbz	x1, LBB70_6
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w8, #1
	b.ne	LBB70_4
; %bb.3:
	mov	w8, #33354                      ; =0x824a
	ldrb	w8, [x0, x8]
	tbz	w8, #0, LBB70_5
LBB70_4:
	mov	w0, #0                          ; =0x0
	ret
LBB70_5:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
Lloh48:
	adrp	x8, lCPI70_0@PAGE
Lloh49:
	ldr	d0, [x8, lCPI70_0@PAGEOFF]
	mov	w8, #33104                      ; =0x8150
	add	x8, x0, x8
	ldr	q1, [x0, #33168]
	ldr	q2, [x0, #33184]
	stp	q1, q2, [sp, #64]
	ldr	q1, [x0, #33200]
	str	q1, [sp, #96]
	ldr	q1, [x0, #33104]
	ldr	q2, [x0, #33120]
	stp	q1, q2, [sp]
	ldr	q1, [x0, #33136]
	ldr	q2, [x0, #33152]
	stp	q1, q2, [sp, #32]
	ldr	x8, [x8, #112]
	ldur	q1, [x0, #40]
	ldrb	w9, [x0, #56]
	str	d0, [x1]
	ldp	q0, q2, [sp, #64]
	stur	q0, [x1, #72]
	stur	q2, [x1, #88]
	ldr	q0, [sp, #96]
	stur	q0, [x1, #104]
	ldp	q0, q2, [sp]
	stur	q0, [x1, #8]
	stur	q2, [x1, #24]
	ldp	q0, q2, [sp, #32]
	stur	q0, [x1, #40]
	str	x8, [sp, #112]
	str	x8, [x1, #120]
	stur	q2, [x1, #56]
	str	q1, [x1, #128]
	strb	w9, [x1, #144]
	str	wzr, [x1, #148]
	mov	w8, #1                          ; =0x1
	stur	wzr, [x1, #145]
	add	sp, sp, #128
LBB70_6:
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_runtime_cyclic_finish
lCPI71_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_cyclic_finish
	.p2align	2
_nvm_socket_runtime_cyclic_finish:      ; @nvm_socket_runtime_cyclic_finish
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB71_3
; %bb.1:
	ldr	w9, [x0, #24]
	cmp	w9, #1
	b.ne	LBB71_3
; %bb.2:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x8
	add	x8, x8, #8
	mov	x19, x0
	bl	_fr_finish
Lloh50:
	adrp	x8, lCPI71_0@PAGE
Lloh51:
	ldr	d0, [x8, lCPI71_0@PAGEOFF]
	str	d0, [x20]
	ldrb	w8, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x20, #128]
	strb	w8, [x20, #144]
	stur	wzr, [x20, #145]
	str	wzr, [x20, #148]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB71_3:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh52:
	adrp	x9, lCPI71_0@PAGE
Lloh53:
	ldr	d0, [x9, lCPI71_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	stp	xzr, xzr, [x8, #136]
	str	xzr, [x8, #128]
	ret
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_runtime_cyclic_destroy
lCPI72_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_cyclic_destroy
	.p2align	2
_nvm_socket_runtime_cyclic_destroy:     ; @nvm_socket_runtime_cyclic_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x0, LBB72_5
; %bb.1:
	ldr	x19, [x0]
	cbz	x19, LBB72_5
; %bb.2:
	ldr	w9, [x19, #24]
	cmp	w9, #1
	b.ne	LBB72_5
; %bb.3:
	add	x20, x19, #8, lsl #12           ; =32768
	ldrb	w9, [x20, #586]
	cmp	w9, #1
	b.ne	LBB72_7
; %bb.4:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh54:
	adrp	x9, lCPI72_0@PAGE
Lloh55:
	ldr	d0, [x9, lCPI72_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #11                         ; =0xb
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	ldrb	w9, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x8, #128]
	strb	w9, [x8, #144]
	stur	wzr, [x8, #145]
	str	wzr, [x8, #148]
	b	LBB72_6
LBB72_5:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh56:
	adrp	x9, lCPI72_0@PAGE
Lloh57:
	ldr	d0, [x9, lCPI72_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	stp	xzr, xzr, [x8, #136]
	str	xzr, [x8, #128]
LBB72_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB72_7:
	mov	x21, x8
	add	x8, x8, #8
	mov	x22, x0
	mov	x0, x19
	bl	_fr_finish
Lloh58:
	adrp	x8, lCPI72_0@PAGE
Lloh59:
	ldr	d0, [x8, lCPI72_0@PAGEOFF]
	str	d0, [x21]
	ldrb	w8, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x21, #128]
	strb	w8, [x21, #144]
	stur	wzr, [x21, #145]
	str	wzr, [x21, #148]
	ldr	x0, [x20, #320]
	bl	_free
	ldr	x0, [x20, #312]
	bl	_free
	ldr	x0, [x20, #304]
	bl	_free
	ldr	x0, [x20, #296]
	bl	_free
	ldr	x0, [x19, #32]
	bl	_free
	ldr	x0, [x19, #8]
	bl	_nvm_socket_cyclic_hosted_free
	mov	x0, x19
	bl	_free
	str	xzr, [x22]
	b	LBB72_6
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh58, Lloh59
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_cyclic_abi  ; -- Begin function nvm_socket_runtime_cyclic_abi
	.p2align	2
_nvm_socket_runtime_cyclic_abi:         ; @nvm_socket_runtime_cyclic_abi
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	ccmp	x1, #16, #0, eq
	mov	w8, #152                        ; =0x98
	ccmp	x2, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x3, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x4, x8, #0, eq
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_cyclic_native_abi ; -- Begin function nvm_socket_runtime_cyclic_native_abi
	.p2align	2
_nvm_socket_runtime_cyclic_native_abi:  ; @nvm_socket_runtime_cyclic_native_abi
	.cfi_startproc
; %bb.0:
	cmp	x1, #16
	mov	w8, #152                        ; =0x98
	ccmp	x2, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x5, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x3, x8, #0, eq
	cset	w8, eq
	cmp	x4, #48
	csel	w8, wzr, w8, ne
	cmp	w0, #1
	csel	w0, wzr, w8, ne
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_indirect_plan ; -- Begin function nvm_socket_runtime_indirect_plan
	.p2align	2
_nvm_socket_runtime_indirect_plan:      ; @nvm_socket_runtime_indirect_plan
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB75_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB75_4
; %bb.2:
	ldr	x0, [x0, #16]
LBB75_3:
	ret
LBB75_4:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_socket_runtime_indirect_frame_view
lCPI76_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	12                              ; 0xc
	.byte	13                              ; 0xd
	.byte	14                              ; 0xe
	.byte	15                              ; 0xf
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	6                               ; 0x6
	.byte	7                               ; 0x7
	.byte	8                               ; 0x8
	.byte	9                               ; 0x9
	.byte	10                              ; 0xa
	.byte	11                              ; 0xb
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_indirect_frame_view
	.p2align	2
_nvm_socket_runtime_indirect_frame_view: ; @nvm_socket_runtime_indirect_frame_view
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	sub	sp, sp, #752
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w27, -40
	.cfi_offset w28, -48
	mov	x19, x0
	mov	w0, #0                          ; =0x0
	cbz	x19, LBB76_6
; %bb.1:
	cbz	x1, LBB76_6
; %bb.2:
	ldr	w8, [x19, #24]
	cmp	w8, #2
	b.ne	LBB76_5
; %bb.3:
	mov	x20, x1
	sub	x1, x29, #104
	add	x2, sp, #80
	mov	x3, sp
	mov	x0, x19
	bl	_frf_current
	tbz	w0, #0, LBB76_5
; %bb.4:
	add	x8, x19, #8, lsl #12            ; =32768
	ldr	x9, [x8, #320]
	ldrh	w10, [x8, #584]
	mov	w11, #40                        ; =0x28
	umaddl	x9, w10, w11, x9
	ldr	w8, [x8, #580]
	ldr	w11, [sp, #80]
	ldur	w12, [x29, #-64]
	ldurh	w13, [x29, #-66]
	ldur	d0, [x9, #-40]
	ldur	q1, [x9, #-32]
Lloh60:
	adrp	x14, lCPI76_0@PAGE
Lloh61:
	ldr	q2, [x14, lCPI76_0@PAGEOFF]
	tbl.16b	v1, { v1 }, v2
	ldur	d2, [x9, #-16]
	ldurb	w14, [x9, #-6]
	ldurb	w9, [x9, #-7]
	mov	w0, #1                          ; =0x1
	stp	w0, w8, [x20]
	str	d0, [x20, #8]
	str	w11, [x20, #16]
	strh	w10, [x20, #20]
	stur	w12, [x20, #22]
	strh	w13, [x20, #26]
	stur	q1, [x20, #28]
	stur	d2, [x20, #44]
	strb	w14, [x20, #52]
	strb	w9, [x20, #53]
	strh	wzr, [x20, #54]
	b	LBB76_6
LBB76_5:
	mov	w0, #0                          ; =0x0
LBB76_6:
	add	sp, sp, #752
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh60, Lloh61
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_indirect_enter ; -- Begin function nvm_socket_runtime_indirect_enter
	.p2align	2
_nvm_socket_runtime_indirect_enter:     ; @nvm_socket_runtime_indirect_enter
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB77_3
; %bb.1:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB77_3
; %bb.2:
	b	_frc_enter
LBB77_3:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_socket_runtime_indirect_funcref
lCPI78_0:
	.quad	-4294967285                     ; 0xffffffff0000000b
	.quad	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_indirect_funcref
	.p2align	2
_nvm_socket_runtime_indirect_funcref:   ; @nvm_socket_runtime_indirect_funcref
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB78_4
; %bb.1:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #832
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x19, x0
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB78_5
; %bb.2:
	add	x20, x19, #8, lsl #12           ; =32768
	ldrb	w8, [x20, #586]
	tbz	w8, #0, LBB78_6
; %bb.3:
	mov	w0, #11                         ; =0xb
	b	LBB78_25
LBB78_4:
	mov	w0, #1                          ; =0x1
	ret
LBB78_5:
	mov	w0, #1                          ; =0x1
	b	LBB78_25
LBB78_6:
	ldr	w8, [x20, #576]
	cmp	w8, #1
	b.ne	LBB78_24
; %bb.7:
	ldr	w0, [x20, #336]
	cbnz	w0, LBB78_25
; %bb.8:
	ldrb	w8, [x20, #588]
	tbz	w8, #0, LBB78_11
LBB78_9:
	mov	w0, #5                          ; =0x5
LBB78_10:
	str	w0, [x20, #336]
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #344]
	b	LBB78_25
LBB78_11:
	mov	x21, x1
	sub	x1, x29, #120
	add	x2, sp, #88
	add	x3, sp, #8
	mov	x0, x19
	bl	_frf_current
	cbz	w0, LBB78_22
; %bb.12:
	ldr	w10, [x19, #24]
	ldr	x8, [x20, #320]
	ldrh	w9, [x20, #584]
	cbz	w10, LBB78_14
; %bb.13:
	mov	w10, #40                        ; =0x28
	umaddl	x10, w9, w10, x8
	ldurb	w10, [x10, #-7]
	tbz	w10, #0, LBB78_22
LBB78_14:
	mov	w10, #40                        ; =0x28
	umaddl	x22, w9, w10, x8
	ldur	w8, [x22, #-40]
	str	w8, [x20, #348]
	ldr	w8, [sp, #88]
	str	w8, [x20, #352]
	ldrb	w8, [sp, #96]
	cmp	w8, #250
	b.ne	LBB78_20
; %bb.15:
	ldr	w1, [sp, #104]
	sub	x2, x29, #192
	mov	x0, x19
	bl	_fr_function
	cbz	w0, LBB78_20
; %bb.16:
	ldur	w8, [x22, #-24]
	ldurh	w9, [x29, #-82]
	cmp	w8, w9
	b.hs	LBB78_20
; %bb.17:
	ldur	w9, [x22, #-28]
	add	w8, w9, w8
	cmp	w21, w8
	b.ne	LBB78_20
; %bb.18:
	ldr	w8, [x19, #128]
	cmp	w21, w8
	b.hs	LBB78_20
; %bb.19:
	ldr	x8, [x20, #296]
	mov	w9, #168                        ; =0xa8
	umaddl	x8, w21, w9, x8
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB78_26
LBB78_20:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB78_24
; %bb.21:
	ldr	w8, [x20, #336]
	mov	w0, #5                          ; =0x5
	cbnz	w8, LBB78_25
	b	LBB78_10
LBB78_22:
	ldr	w8, [x20, #576]
	cmp	w8, #2
	b.eq	LBB78_24
; %bb.23:
	ldr	w8, [x20, #336]
	cbz	w8, LBB78_9
LBB78_24:
	mov	w0, #5                          ; =0x5
LBB78_25:
	add	sp, sp, #832
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB78_26:
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
Lloh62:
	adrp	x9, lCPI78_0@PAGE
Lloh63:
	ldr	q0, [x9, lCPI78_0@PAGEOFF]
	mov	w9, w21
	stur	q0, [x8, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #20]
	stur	q0, [x8, #36]
	stur	q0, [x8, #52]
	stur	q0, [x8, #68]
	stur	q0, [x8, #84]
	stur	q0, [x8, #100]
	str	wzr, [x8, #116]
	ldr	x8, [x19, #16]
	ldr	x10, [x20, #296]
	mov	w11, #168                       ; =0xa8
	umaddl	x9, w9, w11, x10
	str	x8, [x9, #152]
	ldr	w8, [sp, #104]
	str	w8, [x9, #160]
	b	LBB78_25
	.loh AdrpLdr	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_runtime_indirect_finish
lCPI79_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_indirect_finish
	.p2align	2
_nvm_socket_runtime_indirect_finish:    ; @nvm_socket_runtime_indirect_finish
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB79_3
; %bb.1:
	ldr	w9, [x0, #24]
	cmp	w9, #2
	b.ne	LBB79_3
; %bb.2:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x8
	add	x8, x8, #8
	mov	x19, x0
	bl	_fr_finish
Lloh64:
	adrp	x8, lCPI79_0@PAGE
Lloh65:
	ldr	d0, [x8, lCPI79_0@PAGEOFF]
	str	d0, [x20]
	ldrb	w8, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x20, #128]
	strb	w8, [x20, #144]
	stur	wzr, [x20, #145]
	str	wzr, [x20, #148]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB79_3:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh66:
	adrp	x9, lCPI79_0@PAGE
Lloh67:
	ldr	d0, [x9, lCPI79_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	stp	xzr, xzr, [x8, #136]
	str	xzr, [x8, #128]
	ret
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh66, Lloh67
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_socket_runtime_indirect_destroy
lCPI80_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_socket_runtime_indirect_destroy
	.p2align	2
_nvm_socket_runtime_indirect_destroy:   ; @nvm_socket_runtime_indirect_destroy
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x0, LBB80_5
; %bb.1:
	ldr	x19, [x0]
	cbz	x19, LBB80_5
; %bb.2:
	ldr	w9, [x19, #24]
	cmp	w9, #2
	b.ne	LBB80_5
; %bb.3:
	add	x20, x19, #8, lsl #12           ; =32768
	ldrb	w9, [x20, #586]
	cmp	w9, #1
	b.ne	LBB80_7
; %bb.4:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh68:
	adrp	x9, lCPI80_0@PAGE
Lloh69:
	ldr	d0, [x9, lCPI80_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #11                         ; =0xb
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	ldrb	w9, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x8, #128]
	strb	w9, [x8, #144]
	stur	wzr, [x8, #145]
	str	wzr, [x8, #148]
	b	LBB80_6
LBB80_5:
	str	wzr, [x8, #124]
	movi.2d	v0, #0000000000000000
	stur	q0, [x8, #108]
	stur	q0, [x8, #92]
	stur	q0, [x8, #76]
	stur	q0, [x8, #60]
	stur	q0, [x8, #44]
	stur	q0, [x8, #28]
Lloh70:
	adrp	x9, lCPI80_0@PAGE
Lloh71:
	ldr	d0, [x9, lCPI80_0@PAGEOFF]
	str	d0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #8]
	stur	xzr, [x8, #12]
	movi.2d	v0, #0xffffffffffffffff
	stur	d0, [x8, #20]
	stp	xzr, xzr, [x8, #136]
	str	xzr, [x8, #128]
LBB80_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB80_7:
	mov	x21, x8
	add	x8, x8, #8
	mov	x22, x0
	mov	x0, x19
	bl	_fr_finish
Lloh72:
	adrp	x8, lCPI80_0@PAGE
Lloh73:
	ldr	d0, [x8, lCPI80_0@PAGEOFF]
	str	d0, [x21]
	ldrb	w8, [x19, #56]
	ldur	q0, [x19, #40]
	str	q0, [x21, #128]
	strb	w8, [x21, #144]
	stur	wzr, [x21, #145]
	str	wzr, [x21, #148]
	ldr	x0, [x20, #320]
	bl	_free
	ldr	x0, [x20, #312]
	bl	_free
	ldr	x0, [x20, #304]
	bl	_free
	ldr	x0, [x20, #296]
	bl	_free
	ldr	x0, [x19, #32]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_nvm_socket_indirect_hosted_free
	mov	x0, x19
	bl	_free
	str	xzr, [x22]
	b	LBB80_6
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh72, Lloh73
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_socket_runtime_indirect_native_abi ; -- Begin function nvm_socket_runtime_indirect_native_abi
	.p2align	2
_nvm_socket_runtime_indirect_native_abi: ; @nvm_socket_runtime_indirect_native_abi
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	ccmp	x1, #16, #0, eq
	mov	w8, #152                        ; =0x98
	ccmp	x2, x8, #0, eq
	mov	w8, #56                         ; =0x38
	ccmp	x3, x8, #0, eq
	mov	w8, #48                         ; =0x30
	ccmp	x4, x8, #0, eq
	mov	w8, #120                        ; =0x78
	ccmp	x5, x8, #0, eq
	cset	w0, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_code
_fr_code:                               ; @fr_code
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB82_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_instruction
LBB82_2:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_instruction
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_payload
_frc_payload:                           ; @frc_payload
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldrb	w8, [x1]
	cmp	w8, #1
	b.ne	LBB83_16
; %bb.1:
	ldrb	w9, [x1, #4]
	cmp	w9, #11
	b.ne	LBB83_16
; %bb.2:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB83_18
; %bb.3:
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB83_18
; %bb.4:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB83_18
; %bb.5:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB83_18
; %bb.6:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB83_18
; %bb.7:
	ldur	x8, [x1, #4]
	mov	x9, #-65531                     ; =0xffffffffffff0005
	movk	x9, #0, lsl #16
	add	x9, x9, #6
	eor	x9, x8, x9
	tst	x9, #0xff
	b.ne	LBB83_18
; %bb.8:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	x10, #-256                      ; =0xffffffffffffff00
	movk	x10, #0, lsl #16
	tst	x9, x10
	b.ne	LBB83_19
; %bb.9:
	ldur	x9, [x1, #12]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB83_19
; %bb.10:
	ldr	w9, [x1, #144]
	cbnz	w9, LBB83_18
; %bb.11:
	mov	w0, #0                          ; =0x0
	ldr	x9, [x1, #120]
	cbnz	x9, LBB83_19
; %bb.12:
	ldr	x9, [x1, #128]
	cbnz	x9, LBB83_19
; %bb.13:
	ldr	w9, [x1, #136]
	cbnz	w9, LBB83_19
; %bb.14:
	ldr	x9, [x1, #152]
	ldr	x10, [x8, #16]
	cmp	x9, x10
	b.ne	LBB83_18
; %bb.15:
	ldr	w9, [x1, #160]
	ldr	w8, [x8, #72]
	cmp	w9, w8
	b	LBB83_85
LBB83_16:
	ldr	x9, [x1, #152]
	cbnz	x9, LBB83_18
; %bb.17:
	ldr	w9, [x1, #160]
	cbz	w9, LBB83_20
LBB83_18:
	mov	w0, #0                          ; =0x0
LBB83_19:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB83_20:
	tbz	w8, #0, LBB83_25
; %bb.21:
	ldrb	w8, [x1, #1]
	cmp	w8, #1
	b.ne	LBB83_49
; %bb.22:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB83_18
; %bb.23:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB83_18
; %bb.24:
	ldr	w8, [x1, #144]
	b	LBB83_55
LBB83_25:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x1, #120]
	cbnz	x8, LBB83_19
; %bb.26:
	ldr	x8, [x1, #128]
	cbnz	x8, LBB83_19
; %bb.27:
	ldr	w8, [x1, #136]
	cbnz	w8, LBB83_19
; %bb.28:
	ldr	w8, [x1, #144]
	cbnz	w8, LBB83_18
; %bb.29:
	ldrb	w8, [x1, #1]
	tbnz	w8, #0, LBB83_18
; %bb.30:
	ldrb	w8, [x1, #2]
	tbnz	w8, #0, LBB83_18
; %bb.31:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB83_18
; %bb.32:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB83_18
; %bb.33:
	ldrb	w8, [x1, #4]
	cbnz	w8, LBB83_18
; %bb.34:
	ldrb	w8, [x1, #5]
	cbnz	w8, LBB83_18
; %bb.35:
	ldr	w9, [x1, #8]
	cbnz	w9, LBB83_18
; %bb.36:
	mov	x8, x1
	ldr	w9, [x1, #12]
	cbnz	w9, LBB83_18
; %bb.37:
	ldr	w9, [x8, #16]
	cbnz	w9, LBB83_18
; %bb.38:
	ldr	x9, [x8, #32]
	cbnz	x9, LBB83_18
; %bb.39:
	ldr	x9, [x8, #40]
	cbnz	x9, LBB83_18
; %bb.40:
	ldr	x9, [x8, #48]
	cbnz	x9, LBB83_18
; %bb.41:
	ldr	x9, [x8, #56]
	cbnz	x9, LBB83_18
; %bb.42:
	ldr	x9, [x8, #64]
	cbnz	x9, LBB83_18
; %bb.43:
	ldr	x9, [x8, #72]
	cbnz	x9, LBB83_18
; %bb.44:
	ldr	x9, [x8, #80]
	cbnz	x9, LBB83_18
; %bb.45:
	ldr	x9, [x8, #88]
	cbnz	x9, LBB83_18
; %bb.46:
	ldr	x9, [x8, #96]
	cbnz	x9, LBB83_18
; %bb.47:
	ldr	x9, [x8, #104]
	cbnz	x9, LBB83_18
; %bb.48:
	ldr	x8, [x8, #112]
	cmp	x8, #0
	cset	w0, eq
	b	LBB83_19
LBB83_49:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [x1, #120]
	cbnz	x9, LBB83_19
; %bb.50:
	ldr	x9, [x1, #128]
	cbnz	x9, LBB83_19
; %bb.51:
	ldr	w9, [x1, #136]
	cbnz	w9, LBB83_19
; %bb.52:
	ldrb	w9, [x1, #2]
	cmp	w9, #1
	b.ne	LBB83_56
; %bb.53:
	ldrb	w8, [x1, #5]
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB83_18
; %bb.54:
	ldrb	w8, [x1, #24]
LBB83_55:
	cmp	w8, #0
	cset	w0, eq
	b	LBB83_19
LBB83_56:
	ldr	w9, [x1, #144]
	cbnz	w9, LBB83_18
; %bb.57:
	ldrb	w9, [x1, #5]
	cbnz	w9, LBB83_18
; %bb.58:
	ldrb	w9, [x1, #4]
	cmp	w9, #3
	b.gt	LBB83_62
; %bb.59:
	cbz	w9, LBB83_80
; %bb.60:
	cmp	w9, #1
	b.ne	LBB83_72
; %bb.61:
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB83_18
	b	LBB83_81
LBB83_62:
	cmp	w9, #4
	b.eq	LBB83_82
; %bb.63:
	cmp	w9, #5
	b.ne	LBB83_72
; %bb.64:
	ldrb	w9, [x1, #24]
	cmp	w9, #1
	b.ne	LBB83_18
; %bb.65:
	ldr	w9, [x1, #20]
	cbnz	w9, LBB83_18
; %bb.66:
	ldur	x10, [x1, #4]
	mov	x11, #-65531                    ; =0xffffffffffff0005
	movk	x11, #0, lsl #16
	eor	x10, x10, x11
	tst	x10, #0xff
	b.ne	LBB83_18
; %bb.67:
	mov	w0, #0                          ; =0x0
	mov	x11, #-256                      ; =0xffffffffffffff00
	movk	x11, #0, lsl #16
	tst	x10, x11
	b.ne	LBB83_19
; %bb.68:
	mov	x9, x1
	ldur	x10, [x1, #12]
	mov	w11, #-1                        ; =0xffffffff
	cmp	x10, x11
	b.ne	LBB83_19
; %bb.69:
	ldr	x9, [x9, #32]
	cmp	x9, #1
	b.lt	LBB83_18
; %bb.70:
	mov	w10, #33056                     ; =0x8120
	ldr	w10, [x8, x10]
	cmp	x9, x10
	b.hi	LBB83_18
; %bb.71:
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #280]
	cmp	x8, #0
	cset	w0, ne
	b	LBB83_19
LBB83_72:
	mov	x21, x8
	mov	x19, x1
	ldr	w0, [x1, #12]
	bl	_nl_socket_catalog_type
	cbz	x0, LBB83_19
; %bb.73:
	ldr	w10, [x19, #16]
	cmp	w10, #3
	b.eq	LBB83_86
; %bb.74:
	cmp	w10, #4
	b.ne	LBB83_18
; %bb.75:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldrb	w24, [x19, #24]
	cmp	w24, #11
	b.hi	LBB83_19
; %bb.76:
	ldr	x9, [x8, #32]
	cmp	x9, x24
	b.ne	LBB83_19
; %bb.77:
	ldr	w9, [x19, #20]
	cbnz	w9, LBB83_18
; %bb.78:
	cbz	w24, LBB83_97
; %bb.79:
	add	x25, x19, #32
	mov	w26, #33056                     ; =0x8120
	add	x27, x21, #288
	ldr	x8, [x8, #24]
	add	x28, x8, #16
Lloh74:
	adrp	x19, l_.str.1@PAGE
Lloh75:
	add	x19, x19, l_.str.1@PAGEOFF
Lloh76:
	adrp	x20, l_.str.2@PAGE
Lloh77:
	add	x20, x20, l_.str.2@PAGEOFF
Lloh78:
	adrp	x23, l_.str@PAGE
Lloh79:
	add	x23, x23, l_.str@PAGEOFF
	b	LBB83_90
LBB83_80:
	ldrb	w8, [x1, #24]
	cbnz	w8, LBB83_18
LBB83_81:
	ldr	w8, [x1, #20]
	b	LBB83_55
LBB83_82:
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB83_18
; %bb.83:
	ldr	w8, [x1, #20]
	cbnz	w8, LBB83_18
; %bb.84:
	ldr	x8, [x1, #32]
	cmp	x8, #2
LBB83_85:
	cset	w0, lo
	b	LBB83_19
LBB83_86:
	ldr	w8, [x19, #20]
	and	w8, w8, #0xfffffffe
	cmp	w8, #2
	b.ne	LBB83_18
; %bb.87:
	mov	x0, x19
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_fr_scalar_payload
LBB83_88:                               ;   in Loop: Header=BB83_90 Depth=1
	ldr	x8, [x25]
	cmp	x8, #2
	b.hs	LBB83_18
LBB83_89:                               ;   in Loop: Header=BB83_90 Depth=1
	add	x25, x25, #8
	mov	w0, #1                          ; =0x1
	subs	x24, x24, #1
	b.eq	LBB83_19
LBB83_90:                               ; =>This Inner Loop Header: Depth=1
	ldr	x22, [x28], #32
	cbz	x22, LBB83_18
; %bb.91:                               ;   in Loop: Header=BB83_90 Depth=1
	mov	x0, x22
	mov	x1, x19
	bl	_strcmp
	cbz	w0, LBB83_88
; %bb.92:                               ;   in Loop: Header=BB83_90 Depth=1
	mov	x0, x22
	mov	x1, x20
	bl	_strcmp
	cbz	w0, LBB83_94
; %bb.93:                               ;   in Loop: Header=BB83_90 Depth=1
	mov	x0, x22
	mov	x1, x23
	bl	_strcmp
	cbz	w0, LBB83_89
	b	LBB83_18
LBB83_94:                               ;   in Loop: Header=BB83_90 Depth=1
	ldr	x8, [x25]
	cmp	x8, #1
	b.lt	LBB83_18
; %bb.95:                               ;   in Loop: Header=BB83_90 Depth=1
	ldr	w9, [x21, x26]
	cmp	x8, x9
	b.hi	LBB83_18
; %bb.96:                               ;   in Loop: Header=BB83_90 Depth=1
	add	x8, x27, x8, lsl #3
	ldur	x8, [x8, #-8]
	cbnz	x8, LBB83_89
	b	LBB83_18
LBB83_97:
	mov	w0, #1                          ; =0x1
	b	LBB83_19
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh74, Lloh75
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_reference_empty
_frc_reference_empty:                   ; @frc_reference_empty
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	tbnz	w8, #0, LBB84_10
; %bb.1:
	ldrb	w8, [x0, #1]
	tbnz	w8, #0, LBB84_10
; %bb.2:
	ldrb	w8, [x0, #2]
	tbnz	w8, #0, LBB84_10
; %bb.3:
	ldr	w8, [x0, #4]
	cbnz	w8, LBB84_10
; %bb.4:
	ldr	w8, [x0, #8]
	cbnz	w8, LBB84_10
; %bb.5:
	ldr	w8, [x0, #12]
	cbnz	w8, LBB84_10
; %bb.6:
	ldr	x8, [x0, #16]
	cbnz	x8, LBB84_10
; %bb.7:
	ldr	x8, [x0, #48]
	cbnz	x8, LBB84_10
; %bb.8:
	ldp	x8, x9, [x0, #24]
	orr	x8, x8, x9
	cbnz	x8, LBB84_10
; %bb.9:
	ldr	w8, [x0, #40]
	cmp	w8, #0
	cset	w0, eq
	ret
LBB84_10:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_frame
_frc_frame:                             ; @frc_frame
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #832
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x2
	mov	x19, x1
	mov	x20, x0
	ldr	w1, [x1]
	sub	x2, x29, #256
	bl	_fr_function
	cbz	w0, LBB85_3
; %bb.1:
	ldr	w2, [x19, #4]
	lsr	w8, w2, #16
	cbz	w8, LBB85_4
LBB85_2:
	mov	w0, #0                          ; =0x0
LBB85_3:
	add	sp, sp, #832
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB85_4:
	ldr	w1, [x19]
	ldrb	w3, [x19, #34]
	ldr	w8, [x20, #24]
	cmp	w8, #2
	b.ne	LBB85_6
; %bb.5:
	ldr	x0, [x20, #16]
	sub	x4, x29, #184
	bl	_nvm_socket_indirect_hosted_variant
	b	LBB85_7
LBB85_6:
	ldr	x0, [x20, #8]
	sub	x4, x29, #184
	bl	_nvm_socket_cyclic_hosted_variant
LBB85_7:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB85_3
; %bb.8:
	ldurb	w8, [x29, #-164]
	tbz	w8, #0, LBB85_3
; %bb.9:
	ldurh	w9, [x29, #-184]
	ldurh	w8, [x29, #-216]
	cmp	w9, w8
	b.ne	LBB85_2
; %bb.10:
	ldr	w8, [x19, #16]
	ldurh	w10, [x29, #-218]
	cmp	w8, w10
	b.hi	LBB85_2
; %bb.11:
	ldrb	w23, [x19, #32]
	ldurh	w10, [x29, #-182]
	cmp	w8, w10
	cset	w10, ne
	cset	w11, hi
	cmp	w23, #0
	mov	w0, #0                          ; =0x0
	csel	w10, w11, w10, ne
	tbnz	w10, #0, LBB85_3
; %bb.12:
	ldr	w11, [x19, #8]
	ldr	w10, [x20, #128]
	cmp	w11, w10
	b.hi	LBB85_3
; %bb.13:
	sub	x11, x10, x11
	cmp	x11, x9
	b.lo	LBB85_3
; %bb.14:
	mov	w0, #0                          ; =0x0
	ldr	w9, [x19, #12]
	cmp	w9, w10
	b.hi	LBB85_3
; %bb.15:
	sub	x9, x10, x9
	cmp	x9, x8
	b.lo	LBB85_3
; %bb.16:
	ldr	w1, [x19, #20]
	ldurh	w2, [x29, #-214]
	mov	x0, x20
	bl	_frf_empty_range
	cbz	w0, LBB85_3
; %bb.17:
	mov	w0, #0                          ; =0x0
	ldr	w8, [x19, #24]
	ldr	w9, [x20, #132]
	subs	w8, w9, w8
	b.lo	LBB85_3
; %bb.18:
	cmp	w8, #256
	b.lo	LBB85_3
; %bb.19:
	ldr	w8, [x19, #28]
	subs	w8, w21, w8
	b.lo	LBB85_2
; %bb.20:
	add	x22, x20, #8, lsl #12           ; =32768
	ldr	w9, [x22, #596]
	cmp	w21, w9
	b.hi	LBB85_2
; %bb.21:
	ldurh	w9, [x29, #-180]
	cmp	w8, w9
	b.ne	LBB85_2
; %bb.22:
	cbz	w23, LBB85_27
; %bb.23:
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	add	x3, sp, #56
	mov	x0, x20
	bl	_fr_code
	cbz	w0, LBB85_2
; %bb.24:
	ldr	w3, [x19, #36]
	add	x2, sp, #56
	mov	x0, x20
	mov	x1, x19
	bl	_fr_call_target
	cbz	w0, LBB85_2
; %bb.25:
	ldurb	w8, [x29, #-161]
	tbz	w8, #0, LBB85_2
; %bb.26:
	ldr	w8, [x19, #16]
	ldurh	w9, [x29, #-116]
	ldurh	w10, [x29, #-112]
	add	w8, w8, w9
	sub	w8, w8, w10
	ldrb	w9, [sp, #64]
	cmp	w9, #60
	mov	w10, #152                       ; =0x98
	ccmp	w9, w10, #4, ne
	cinc	w8, w8, eq
	ldurh	w9, [x29, #-182]
	cmp	w8, w9
	b.ne	LBB85_2
LBB85_27:
	ldr	x0, [x20, #32]
	mov	w1, #7168                       ; =0x1c00
	bl	_bzero
	ldurh	w8, [x29, #-216]
	cbz	w8, LBB85_32
; %bb.28:
	mov	w21, #0                         ; =0x0
LBB85_29:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_local
	cbz	w0, LBB85_2
; %bb.30:                               ;   in Loop: Header=BB85_29 Depth=1
	ldr	w8, [x19, #8]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [sp, #16]
	ldr	x9, [sp, #88]
	str	x9, [sp, #48]
	add	w1, w21, w8
	add	x2, sp, #16
	mov	x0, x20
	bl	_frc_value
	cbz	w0, LBB85_2
; %bb.31:                               ;   in Loop: Header=BB85_29 Depth=1
	add	w21, w21, #1
	ldurh	w8, [x29, #-216]
	cmp	w21, w8
	b.lo	LBB85_29
LBB85_32:
	ldr	w8, [x19, #16]
	cbz	w8, LBB85_37
; %bb.33:
	mov	w23, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
LBB85_34:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	and	w4, w21, #0xffff
	add	x5, sp, #56
	mov	x0, x20
	bl	_fr_input_stack
	cbz	w0, LBB85_2
; %bb.35:                               ;   in Loop: Header=BB85_34 Depth=1
	ldr	w8, [x19, #12]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stp	q0, q1, [sp, #16]
	ldr	x9, [sp, #88]
	str	x9, [sp, #48]
	add	w1, w8, w23
	add	x2, sp, #16
	mov	x0, x20
	bl	_frc_value
	cbz	w0, LBB85_2
; %bb.36:                               ;   in Loop: Header=BB85_34 Depth=1
	add	w21, w21, #1
	and	w23, w21, #0xffff
	ldr	w8, [x19, #16]
	cmp	w8, w23
	b.hi	LBB85_34
LBB85_37:
	ldurh	w8, [x29, #-180]
	cbz	w8, LBB85_43
; %bb.38:
	mov	x21, #0                         ; =0x0
LBB85_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_region
	cbz	w0, LBB85_2
; %bb.40:                               ;   in Loop: Header=BB85_39 Depth=1
	ldr	x8, [sp, #56]
	add	x9, x21, #513
	cmp	x9, x8
	b.ne	LBB85_2
; %bb.41:                               ;   in Loop: Header=BB85_39 Depth=1
	ldr	x8, [x22, #312]
	ldr	w9, [x19, #28]
	add	w9, w21, w9
	ldr	x8, [x8, w9, uxtw #3]
	cbz	x8, LBB85_2
; %bb.42:                               ;   in Loop: Header=BB85_39 Depth=1
	add	x21, x21, #1
	ldurh	w8, [x29, #-180]
	cmp	x21, x8
	b.lo	LBB85_39
LBB85_43:
	mov	x21, #0                         ; =0x0
	mov	w23, #56                        ; =0x38
	mov	w24, #168                       ; =0xa8
	mov	w25, #24                        ; =0x18
LBB85_44:                               ; =>This Inner Loop Header: Depth=1
	ldr	x26, [x22, #304]
	ldr	w27, [x19, #24]
	ldr	w1, [x19]
	ldrh	w2, [x19, #4]
	ldrb	w3, [x19, #34]
	add	x5, sp, #56
	mov	x0, x20
	mov	x4, x21
	bl	_fr_input_reference
	cbz	w0, LBB85_2
; %bb.45:                               ;   in Loop: Header=BB85_44 Depth=1
	add	w8, w21, w27
	umaddl	x8, w8, w23, x26
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldrb	w8, [sp, #56]
	tbz	w8, #0, LBB85_65
; %bb.46:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x8]
	cmp	w9, #1
	b.ne	LBB85_2
; %bb.47:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrb	w9, [sp, #57]
	ldrb	w10, [x8, #1]
	cmp	w9, w10
	b.ne	LBB85_2
; %bb.48:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrb	w9, [sp, #88]
	ldrb	w8, [x8, #2]
	cmp	w9, w8
	b.ne	LBB85_2
; %bb.49:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w8, [x19, #24]
	add	w1, w21, w8
	mov	x0, x20
	bl	_fr_reference
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	w0, LBB85_2
; %bb.50:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x0, [x22, #328]
	add	x1, x8, #24
	bl	_nl_socket_value_borrow_validate
	ldr	x14, [sp, #8]                   ; 8-byte Folded Reload
	cbnz	w0, LBB85_2
; %bb.51:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x13, [x22, #296]
	ldr	w12, [x14, #4]
	umaddl	x8, w12, w24, x13
	ldp	x11, x10, [x14, #24]
	ldr	w9, [x14, #40]
	ldp	x15, x16, [x8, #120]
	ldr	w8, [x8, #136]
	cmp	x11, x15
	ccmp	x10, x16, #0, eq
	ccmp	w9, w8, #0, eq
	b.ne	LBB85_2
; %bb.52:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x15, [x22, #304]
	ldr	w8, [x14, #8]
	umaddl	x15, w8, w23, x15
	ldp	x16, x17, [x15, #24]!
	ldr	w0, [x15, #16]
	cmp	x16, x11
	ccmp	x17, x10, #0, eq
	ccmp	w0, w9, #0, eq
	b.ne	LBB85_2
; %bb.53:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x15, [x15, #24]
	ldr	x14, [x14, #48]
	cmp	x15, x14
	b.ne	LBB85_2
; %bb.54:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrb	w14, [sp, #57]
	cmp	w14, #1
	b.ne	LBB85_66
; %bb.55:                               ;   in Loop: Header=BB85_44 Depth=1
	ldurh	w9, [x29, #-244]
	cmp	x21, x9
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	b.hs	LBB85_2
; %bb.56:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrh	w10, [sp, #58]
	cmp	x21, x10
	b.ne	LBB85_2
; %bb.57:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x10, [sp, #64]
	add	x11, x21, #257
	cmp	x11, x10
	b.ne	LBB85_2
; %bb.58:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x11, [sp, #72]
	cmp	x11, x10
	b.ne	LBB85_2
; %bb.59:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x10, [sp, #80]
	cbnz	x10, LBB85_2
; %bb.60:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x10, [x9, #16]
	cbnz	x10, LBB85_2
; %bb.61:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w9, [x9, #12]
	ldr	w10, [x19, #8]
	add	w10, w21, w10
	cmp	w10, w9
	b.ne	LBB85_2
; %bb.62:                               ;   in Loop: Header=BB85_44 Depth=1
	umaddl	x9, w9, w24, x13
	ldrb	w10, [x9, #2]
	cmp	w10, #1
	b.ne	LBB85_2
; %bb.63:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w10, [x19, #24]
	cmp	w8, w10
	b.hs	LBB85_2
; %bb.64:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w8, [x9, #144]
	add	w9, w21, w10
	cmp	w9, w8
	b.eq	LBB85_80
	b	LBB85_2
LBB85_65:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_frc_reference_empty
	tbnz	w0, #0, LBB85_80
	b	LBB85_2
LBB85_66:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x15, [sp, #64]
	sub	x13, x15, #257
	cmn	x13, #256
	ldr	x13, [sp, #8]                   ; 8-byte Folded Reload
	b.lo	LBB85_2
; %bb.67:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrh	w16, [sp, #58]
	ldurh	w14, [x29, #-216]
	cmp	w16, w14
	b.hs	LBB85_2
; %bb.68:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x14, [sp, #72]
	add	x17, x21, #769
	cmp	x17, x14
	b.ne	LBB85_2
; %bb.69:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x14, [sp, #80]
	subs	x17, x14, #513
	b.lo	LBB85_2
; %bb.70:                               ;   in Loop: Header=BB85_44 Depth=1
	ldurh	w0, [x29, #-180]
	cmp	x17, x0
	b.hs	LBB85_2
; %bb.71:                               ;   in Loop: Header=BB85_44 Depth=1
	ldrb	w17, [x13, #2]
	tbnz	w17, #0, LBB85_73
; %bb.72:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w17, [x19, #24]
	add	w17, w21, w17
	cmp	w17, w8
	b.ne	LBB85_2
LBB85_73:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w8, [x13, #12]
	cmn	w8, #1
	b.ne	LBB85_2
; %bb.74:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w8, [x19, #8]
	add	w8, w8, w16
	cmp	w12, w8
	b.ne	LBB85_2
; %bb.75:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x8, [x20, #32]
	sub	x15, x15, #1
	add	x16, x8, x15, lsl #2
	ldr	w16, [x16, #6144]
	cmp	w16, w12
	b.ne	LBB85_2
; %bb.76:                               ;   in Loop: Header=BB85_44 Depth=1
	madd	x8, x15, x25, x8
	ldr	x12, [x8]
	cmp	x12, x11
	b.ne	LBB85_2
; %bb.77:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x11, [x8, #8]
	cmp	x11, x10
	b.ne	LBB85_2
; %bb.78:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	w8, [x8, #16]
	cmp	w8, w9
	b.ne	LBB85_2
; %bb.79:                               ;   in Loop: Header=BB85_44 Depth=1
	ldr	x8, [x13, #16]
	ldr	x9, [x22, #312]
	ldr	w10, [x19, #28]
	add	w10, w14, w10
	sub	w10, w10, #513
	ldr	x9, [x9, w10, uxtw #3]
	cmp	x8, x9
	b.ne	LBB85_2
LBB85_80:                               ;   in Loop: Header=BB85_44 Depth=1
	add	x21, x21, #1
	mov	w0, #1                          ; =0x1
	cmp	x21, #256
	b.ne	LBB85_44
	b	LBB85_3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_scalar_payload
_fr_scalar_payload:                     ; @fr_scalar_payload
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #20]
	cmp	w8, #3
	b.ne	LBB86_7
; %bb.1:
	ldrb	w8, [x0, #24]
	cmp	w8, #11
	b.ne	LBB86_15
; %bb.2:
	ldr	x8, [x0, #80]
	cmp	x8, #1
	b.hi	LBB86_15
; %bb.3:
	ldr	x8, [x0, #88]
	cmp	x8, #1
	b.hi	LBB86_15
; %bb.4:
	ldr	x8, [x0, #96]
	cmp	x8, #1
	b.hi	LBB86_15
; %bb.5:
	ldr	x8, [x0, #104]
	cmp	x8, #1
	b.hi	LBB86_15
; %bb.6:
	ldr	x8, [x0, #112]
	b	LBB86_12
LBB86_7:
	ldr	w8, [x0, #12]
	cmp	w8, #6
	b.eq	LBB86_10
; %bb.8:
	cmp	w8, #4
	b.ne	LBB86_13
; %bb.9:
	ldrb	w8, [x0, #24]
	cmp	w8, #1
	cset	w0, eq
	ret
LBB86_10:
	ldrb	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB86_15
; %bb.11:
	ldr	x8, [x0, #40]
LBB86_12:
	cmp	x8, #2
	cset	w0, lo
	ret
LBB86_13:
	and	w8, w8, #0xfffffffd
	cmp	w8, #5
	b.ne	LBB86_15
; %bb.14:
	ldrb	w8, [x0, #24]
	cmp	w8, #0
	cset	w0, eq
	ret
LBB86_15:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_local
_fr_input_local:                        ; @fr_input_local
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB87_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_input_local
LBB87_2:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_input_local
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function frc_value
_frc_value:                             ; @frc_value
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #128]
	cmp	w1, w8
	b.hs	LBB88_17
; %bb.1:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	add	x24, x0, #8, lsl #12            ; =32768
	ldr	x8, [x24, #296]
	mov	w9, #168                        ; =0xa8
	mov	x21, x1
	umaddl	x20, w1, w9, x8
	mov	x23, x0
	mov	x1, x20
	bl	_frc_payload
	cbz	w0, LBB88_24
; %bb.2:
	ldrb	w8, [x20]
	ldrb	w9, [x19, #16]
	cmp	w8, w9
	b.ne	LBB88_23
; %bb.3:
	tbz	w8, #0, LBB88_18
; %bb.4:
	ldr	x9, [x19]
	ldur	x8, [x20, #4]
	eor	x11, x8, x9
	tst	x11, #0xff
	b.ne	LBB88_23
; %bb.5:
	ldur	x8, [x20, #12]
	ldr	x10, [x19, #8]
	and	x11, x11, #0xffffffffffffff00
	and	x11, x11, #0xffffffff0000ffff
	cmp	x11, #0
	ccmp	x8, x10, #0, eq
	b.ne	LBB88_23
; %bb.6:
	ldrb	w12, [x20, #2]
	ands	x11, x9, #0xff00
	cset	w9, ne
	cmp	w12, w9
	b.ne	LBB88_23
; %bb.7:
	ldrb	w9, [x20, #1]
	lsr	x10, x10, #32
	sub	x10, x10, #1
	cmp	x11, #0
	ccmp	x10, #2, #2, eq
	cset	w10, lo
	cmp	w9, w10
	b.ne	LBB88_23
; %bb.8:
	ldr	w22, [x20, #20]
	tbz	w9, #0, LBB88_22
; %bb.9:
	and	x25, x8, #0xffffffff00000000
	mov	x26, #8589934592                ; =0x200000000
	cmp	x25, x26
	cset	w2, eq
	ldr	x0, [x24, #328]
	add	x1, x20, #120
	bl	_nl_socket_value_validate
	cbnz	w0, LBB88_23
; %bb.10:
	cmp	x25, x26
	b.ne	LBB88_12
; %bb.11:
	ldr	x0, [x24, #328]
	add	x1, x20, #120
	mov	x2, sp
	bl	_nl_socket_connect_view
	ldrb	w8, [sp]
	cmp	w8, #0
	mov	w8, #2                          ; =0x2
	cinc	w22, w8, eq
	cbnz	w0, LBB88_23
LBB88_12:
	ldr	x8, [x19, #24]
	sub	x9, x8, #257
	cmn	x9, #256
	b.lo	LBB88_23
; %bb.13:
	mov	w0, #0                          ; =0x0
	sub	w8, w8, #1
	ldr	x10, [x23, #32]
	mov	w9, #24                         ; =0x18
	umaddl	x9, w8, w9, x10
	ldr	x11, [x9]
	cbnz	x11, LBB88_24
; %bb.14:
	ldr	x11, [x9, #8]
	cbnz	x11, LBB88_24
; %bb.15:
	ldr	w11, [x9, #16]
	cbnz	w11, LBB88_24
; %bb.16:
	add	x10, x10, #16
	mov	w11, #256                       ; =0x100
	b	LBB88_20
LBB88_17:
	mov	w0, #0                          ; =0x0
	ret
LBB88_18:
	ldr	x8, [x19, #24]
	cmp	x8, #0
	cset	w0, eq
	b	LBB88_24
LBB88_19:                               ;   in Loop: Header=BB88_20 Depth=1
	add	x10, x10, #24
	subs	x11, x11, #1
	b.eq	LBB88_25
LBB88_20:                               ; =>This Inner Loop Header: Depth=1
	ldp	x12, x13, [x10, #-16]
	ldr	w14, [x10]
	cmp	x12, #0
	ccmp	x13, #0, #0, eq
	ccmp	w14, #0, #0, eq
	b.eq	LBB88_19
; %bb.21:                               ;   in Loop: Header=BB88_20 Depth=1
	ldp	x15, x16, [x20, #120]
	ldr	w17, [x20, #136]
	cmp	x12, x15
	ccmp	x13, x16, #0, eq
	ccmp	w14, w17, #0, eq
	b.ne	LBB88_19
	b	LBB88_23
LBB88_22:
	ldr	x8, [x19, #24]
	cbz	x8, LBB88_26
LBB88_23:
	mov	w0, #0                          ; =0x0
LBB88_24:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB88_25:
	ldur	q0, [x20, #120]
	ldur	x10, [x20, #136]
	str	x10, [x9, #16]
	str	q0, [x9]
	ldr	x9, [x23, #32]
	add	x8, x9, x8, lsl #2
	str	w21, [x8, #6144]
LBB88_26:
	ldr	w8, [x19, #32]
	and	w9, w22, #0xfffffffe
	cmp	w9, #2
	cset	w9, eq
	cmp	w22, w8
	cset	w10, eq
	cmp	w8, #1
	csel	w0, w9, w10, eq
	b	LBB88_24
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_stack
_fr_input_stack:                        ; @fr_input_stack
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB89_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_input_stack
LBB89_2:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_input_stack
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_region
_fr_input_region:                       ; @fr_input_region
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB90_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_input_region
LBB90_2:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_input_region
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fr_input_reference
_fr_input_reference:                    ; @fr_input_reference
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #24]
	cmp	w8, #2
	b.ne	LBB91_2
; %bb.1:
	ldr	x0, [x0, #16]
	b	_nvm_socket_indirect_hosted_input_reference
LBB91_2:
	ldr	x0, [x0, #8]
	b	_nvm_socket_cyclic_hosted_input_reference
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @fr_scalar_result.kinds
_fr_scalar_result.kinds:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	2                               ; 0x2
	.long	3                               ; 0x3

	.p2align	2, 0x0                          ; @switch.table.fr_core
l_switch.table.fr_core:
	.long	1                               ; 0x1
	.long	7                               ; 0x7
	.long	6                               ; 0x6
	.long	8                               ; 0x8
	.long	3                               ; 0x3
	.long	4                               ; 0x4

.subsections_via_symbols
