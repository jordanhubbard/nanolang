	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_v2_cursor_init             ; -- Begin function nvm_v2_cursor_init
	.p2align	2
_nvm_v2_cursor_init:                    ; @nvm_v2_cursor_init
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #24]
	str	x8, [x9, #8]
	ldr	x8, [sp, #24]
	str	xzr, [x8, #16]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_cursor_exhausted        ; -- Begin function nvm_v2_cursor_exhausted
	.p2align	2
_nvm_v2_cursor_exhausted:               ; @nvm_v2_cursor_exhausted
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	cset	w0, hs
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_take                    ; -- Begin function nvm_v2_take
	.p2align	2
_nvm_v2_take:                           ; @nvm_v2_take
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	str	x2, [sp]
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #8]
	ldr	x10, [sp, #16]
	ldr	x10, [x10, #16]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB2_2
	b	LBB2_1
LBB2_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]
	b	LBB2_5
LBB2_2:
	ldr	x8, [sp]
	cbz	x8, LBB2_4
	b	LBB2_3
LBB2_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9, #16]
	add	x8, x8, x9
	ldr	x9, [sp]
	str	x8, [x9]
	b	LBB2_4
LBB2_4:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	str	wzr, [sp, #28]
	b	LBB2_5
LBB2_5:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_u8                      ; -- Begin function nvm_v2_u8
	.p2align	2
_nvm_v2_u8:                             ; @nvm_v2_u8
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	mov	x1, #1                          ; =0x1
	add	x2, sp, #8
	bl	_nvm_v2_take
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbnz	w8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	strb	w8, [x9]
	b	LBB3_2
LBB3_2:
	ldr	w0, [sp, #4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_u16                     ; -- Begin function nvm_v2_u16
	.p2align	2
_nvm_v2_u16:                            ; @nvm_v2_u16
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	mov	x1, #2                          ; =0x2
	add	x2, sp, #8
	bl	_nvm_v2_take
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbnz	w8, LBB4_2
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #16]
	strh	w8, [x9]
	b	LBB4_2
LBB4_2:
	ldr	w0, [sp, #4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_u32                     ; -- Begin function nvm_v2_u32
	.p2align	2
_nvm_v2_u32:                            ; @nvm_v2_u32
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	mov	x1, #4                          ; =0x4
	add	x2, sp, #8
	bl	_nvm_v2_take
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbnz	w8, LBB5_2
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #1]
	orr	w8, w8, w9, lsl #8
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #2]
	orr	w8, w8, w9, lsl #16
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #3]
	orr	w8, w8, w9, lsl #24
	ldr	x9, [sp, #16]
	str	w8, [x9]
	b	LBB5_2
LBB5_2:
	ldr	w0, [sp, #4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_u64                     ; -- Begin function nvm_v2_u64
	.p2align	2
_nvm_v2_u64:                            ; @nvm_v2_u64
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x0, [x29, #-16]
	mov	x1, #8                          ; =0x8
	add	x2, sp, #32
	bl	_nvm_v2_take
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB6_2
	b	LBB6_1
LBB6_1:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB6_7
LBB6_2:
	str	xzr, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB6_3
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	subs	w8, w8, #8
	b.ge	LBB6_6
	b	LBB6_4
LBB6_4:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldr	x8, [sp, #32]
	ldrsw	x9, [sp, #12]
	ldrb	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #12]
	lsl	w9, w9, #3
                                        ; kill: def $x9 killed $w9
	lsl	x9, x8, x9
	ldr	x8, [sp, #16]
	orr	x8, x8, x9
	str	x8, [sp, #16]
	b	LBB6_5
LBB6_5:                                 ;   in Loop: Header=BB6_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB6_3
LBB6_6:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB6_7
LBB6_7:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_v2_align4                  ; -- Begin function nvm_v2_align4
	.p2align	2
_nvm_v2_align4:                         ; @nvm_v2_align4
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	b	LBB7_1
LBB7_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	mov	x10, #4                         ; =0x4
	udiv	x9, x8, x10
	mul	x9, x9, x10
	subs	x8, x8, x9
	cbz	x8, LBB7_7
	b	LBB7_2
LBB7_2:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldr	x0, [sp, #16]
	add	x1, sp, #15
	bl	_nvm_v2_u8
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	cbz	w8, LBB7_4
	b	LBB7_3
LBB7_3:
	ldr	w8, [sp, #8]
	stur	w8, [x29, #-4]
	b	LBB7_8
LBB7_4:                                 ;   in Loop: Header=BB7_1 Depth=1
	ldrb	w8, [sp, #15]
	cbz	w8, LBB7_6
	b	LBB7_5
LBB7_5:
	mov	w8, #9                          ; =0x9
	stur	w8, [x29, #-4]
	b	LBB7_8
LBB7_6:                                 ;   in Loop: Header=BB7_1 Depth=1
	b	LBB7_1
LBB7_7:
	stur	wzr, [x29, #-4]
	b	LBB7_8
LBB7_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
