	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_crc32
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_crc32
	.globl	_nvm_crc32
	.p2align	2
_nvm_crc32:                             ; @nvm_crc32
	.cfi_startproc
; %bb.0:
	adrp	x9, _crc32_initialized@PAGE
	ldrb	w10, [x9, _crc32_initialized@PAGEOFF]
Lloh0:
	adrp	x8, _crc32_table@PAGE
Lloh1:
	add	x8, x8, _crc32_table@PAGEOFF
	tbnz	w10, #0, LBB0_4
; %bb.1:
	mov	x10, #0                         ; =0x0
Lloh2:
	adrp	x11, lCPI0_0@PAGE
Lloh3:
	ldr	q0, [x11, lCPI0_0@PAGEOFF]
	movi.4s	v1, #1
	mov	w11, #33568                     ; =0x8320
	movk	w11, #60856, lsl #16
	dup.4s	v2, w11
	movi.4s	v3, #4
LBB0_2:                                 ; =>This Inner Loop Header: Depth=1
	and.16b	v4, v0, v1
	ushr.4s	v5, v0, #1
	cmeq.4s	v4, v4, #0
	eor.16b	v6, v5, v2
	bsl.16b	v4, v5, v6
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	ushr.4s	v4, v4, #1
	cmeq.4s	v5, v5, #0
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	and.16b	v5, v4, v1
	cmeq.4s	v5, v5, #0
	ushr.4s	v4, v4, #1
	eor.16b	v6, v4, v2
	bif.16b	v4, v6, v5
	str	q4, [x8, x10]
	add.4s	v0, v0, v3
	add	x10, x10, #16
	cmp	x10, #1024
	b.ne	LBB0_2
; %bb.3:
	mov	w10, #1                         ; =0x1
	strb	w10, [x9, _crc32_initialized@PAGEOFF]
LBB0_4:
	cbz	w1, LBB0_8
; %bb.5:
	mov	w9, w1
	mov	w10, #-1                        ; =0xffffffff
LBB0_6:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x0], #1
	eor	w11, w11, w10
	and	x11, x11, #0xff
	ldr	w11, [x8, x11, lsl #2]
	eor	w10, w11, w10, lsr #8
	subs	x9, x9, #1
	b.ne	LBB0_6
; %bb.7:
	mvn	w0, w10
	ret
LBB0_8:
	mov	w0, #0                          ; =0x0
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_module_new
lCPI1_0:
	.byte	78                              ; 0x4e
	.byte	86                              ; 0x56
	.byte	77                              ; 0x4d
	.byte	1                               ; 0x1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_module_new
	.globl	_nvm_module_new
	.p2align	2
_nvm_module_new:                        ; @nvm_module_new
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w0, #1                          ; =0x1
	mov	w1, #480                        ; =0x1e0
	bl	_calloc
	cbz	x0, LBB1_11
; %bb.1:
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	d0, [x8, lCPI1_0@PAGEOFF]
	str	s0, [x0]
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #4]
	mov	w8, #64                         ; =0x40
	str	w8, [x0, #252]
	mov	x27, x0
	mov	w0, #64                         ; =0x40
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x19, x0
	str	x0, [x27, #232]
	mov	w0, #64                         ; =0x40
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x20, x0
	str	x0, [x27, #240]
	mov	w25, #32                        ; =0x20
	str	w25, [x27, #276]
	mov	w0, #32                         ; =0x20
	mov	w1, #24                         ; =0x18
	bl	_calloc
	mov	x21, x0
	str	x0, [x27, #256]
	mov	w0, #32                         ; =0x20
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x22, x0
	str	x0, [x27, #264]
	mov	w8, #4096                       ; =0x1000
	str	w8, [x27, #292]
	mov	w0, #4096                       ; =0x1000
	mov	w1, #1                          ; =0x1
	bl	_calloc
	mov	x23, x0
	str	x0, [x27, #280]
	mov	w8, #256                        ; =0x100
	str	w8, [x27, #388]
	mov	w0, #256                        ; =0x100
	mov	w1, #12                         ; =0xc
	bl	_calloc
	mov	x24, x0
	str	x0, [x27, #376]
	str	w25, [x27, #436]
	mov	w0, #32                         ; =0x20
	mov	w1, #12                         ; =0xc
	bl	_calloc
	mov	x25, x0
	str	x0, [x27, #400]
	mov	w0, #32                         ; =0x20
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x26, x0
	str	x0, [x27, #408]
	mov	w8, #16                         ; =0x10
	str	w8, [x27, #452]
	mov	w0, #16                         ; =0x10
	mov	w1, #4                          ; =0x4
	bl	_calloc
	mov	x8, x0
	mov	x0, x27
	str	x8, [x27, #440]
	cbz	x19, LBB1_10
; %bb.2:
	cbz	x20, LBB1_10
; %bb.3:
	cbz	x21, LBB1_10
; %bb.4:
	cbz	x22, LBB1_10
; %bb.5:
	cbz	x23, LBB1_10
; %bb.6:
	cbz	x24, LBB1_10
; %bb.7:
	cbz	x25, LBB1_10
; %bb.8:
	cbz	x26, LBB1_10
; %bb.9:
	cbnz	x8, LBB1_11
LBB1_10:
	bl	_nvm_module_free
	mov	x0, #0                          ; =0x0
LBB1_11:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_module_free        ; -- Begin function nvm_module_free
	.globl	_nvm_module_free
	.p2align	2
_nvm_module_free:                       ; @nvm_module_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB2_20
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x0, [x0, #232]
	cbz	x0, LBB2_7
; %bb.2:
	ldr	w8, [x19, #248]
	cbz	w8, LBB2_6
; %bb.3:
	mov	x20, #0                         ; =0x0
LBB2_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #232]
	ldr	x0, [x8, x20, lsl #3]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #248]
	cmp	x20, x8
	b.lo	LBB2_4
; %bb.5:
	ldr	x0, [x19, #232]
LBB2_6:
	bl	_free
LBB2_7:
	ldr	x0, [x19, #240]
	bl	_free
	ldr	x0, [x19, #256]
	bl	_free
	ldr	x0, [x19, #264]
	cbz	x0, LBB2_13
; %bb.8:
	ldr	w8, [x19, #272]
	cbz	w8, LBB2_12
; %bb.9:
	mov	x20, #0                         ; =0x0
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #264]
	ldr	x0, [x8, x20, lsl #3]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #272]
	cmp	x20, x8
	b.lo	LBB2_10
; %bb.11:
	ldr	x0, [x19, #264]
LBB2_12:
	bl	_free
LBB2_13:
	ldr	x0, [x19, #280]
	bl	_free
	ldr	x0, [x19, #376]
	bl	_free
	ldr	x0, [x19, #408]
	cbz	x0, LBB2_19
; %bb.14:
	ldr	w8, [x19, #432]
	cbz	w8, LBB2_18
; %bb.15:
	mov	x20, #0                         ; =0x0
LBB2_16:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #408]
	ldr	x0, [x8, x20, lsl #3]
	bl	_free
	add	x20, x20, #1
	ldr	w8, [x19, #432]
	cmp	x20, x8
	b.lo	LBB2_16
; %bb.17:
	ldr	x0, [x19, #408]
LBB2_18:
	bl	_free
LBB2_19:
	ldr	x0, [x19, #400]
	bl	_free
	ldr	x0, [x19, #416]
	bl	_free
	ldr	x0, [x19, #344]
	bl	_free
	ldr	x0, [x19, #312]
	bl	_free
	ldr	x0, [x19, #296]
	bl	_free
	ldr	x0, [x19, #328]
	bl	_free
	ldr	x0, [x19, #360]
	bl	_free
	ldr	x0, [x19, #440]
	bl	_free
	ldr	x0, [x19, #456]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB2_20:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_metadata_source_key ; -- Begin function nvm_metadata_source_key
	.globl	_nvm_metadata_source_key
	.p2align	2
_nvm_metadata_source_key:               ; @nvm_metadata_source_key
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_8
; %bb.1:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB3_7
; %bb.2:
	ldr	x8, [x0, #232]
	cbz	x8, LBB3_7
; %bb.3:
	ldr	x9, [x0, #240]
	cbz	x9, LBB3_7
; %bb.4:
	ldr	x8, [x8, w1, uxtw #3]
	cbz	x8, LBB3_7
; %bb.5:
	ldr	w9, [x9, w1, uxtw #2]
	cmp	w9, #16
	b.ne	LBB3_7
; %bb.6:
	ldp	x9, x8, [x8]
	mov	x10, #24942                     ; =0x616e
	movk	x10, #28526, lsl #16
	movk	x10, #29486, lsl #32
	movk	x10, #30063, lsl #48
	cmp	x9, x10
	mov	x9, #25458                      ; =0x6372
	movk	x9, #24421, lsl #16
	movk	x9, #26982, lsl #32
	movk	x9, #25964, lsl #48
	ccmp	x8, x9, #0, eq
	cset	w0, eq
	ret
LBB3_7:
	mov	w0, #0                          ; =0x0
LBB3_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_metadata_valid     ; -- Begin function nvm_metadata_valid
	.globl	_nvm_metadata_valid
	.p2align	2
_nvm_metadata_valid:                    ; @nvm_metadata_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_16
; %bb.1:
	ldr	w9, [x0, #368]
	cbz	w9, LBB4_14
; %bb.2:
	ldr	x10, [x0, #360]
	cbz	x10, LBB4_13
; %bb.3:
	ldr	w8, [x0, #392]
	ldr	w11, [x0, #248]
	add	x12, x10, #4
	mov	x13, #24942                     ; =0x616e
	movk	x13, #28526, lsl #16
	movk	x13, #29486, lsl #32
	movk	x13, #30063, lsl #48
	mov	x14, #25458                     ; =0x6372
	movk	x14, #24421, lsl #16
	movk	x14, #26982, lsl #32
	movk	x14, #25964, lsl #48
	mov	x10, x8
	b	LBB4_5
LBB4_4:                                 ;   in Loop: Header=BB4_5 Depth=1
	add	x12, x12, #8
	subs	x9, x9, #1
	b.eq	LBB4_15
LBB4_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x12, #-4]
	cmp	w16, w11
	b.hs	LBB4_13
; %bb.6:                                ;   in Loop: Header=BB4_5 Depth=1
	ldr	w15, [x12]
	cmp	w15, w11
	b.hs	LBB4_13
; %bb.7:                                ;   in Loop: Header=BB4_5 Depth=1
	ldr	x2, [x0, #232]
	cbz	x2, LBB4_13
; %bb.8:                                ;   in Loop: Header=BB4_5 Depth=1
	ldr	x1, [x0, #240]
	cbz	x1, LBB4_13
; %bb.9:                                ;   in Loop: Header=BB4_5 Depth=1
	ldr	x17, [x2, x16, lsl #3]
	cbz	x17, LBB4_13
; %bb.10:                               ;   in Loop: Header=BB4_5 Depth=1
	ldr	x2, [x2, x15, lsl #3]
	cbz	x2, LBB4_13
; %bb.11:                               ;   in Loop: Header=BB4_5 Depth=1
	ldr	w16, [x1, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB4_4
; %bb.12:                               ;   in Loop: Header=BB4_5 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x13
	eor	x17, x17, x14
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w10, w10, w15, ne
	b	LBB4_4
LBB4_13:
	mov	w0, #0                          ; =0x0
	ret
LBB4_14:
	ldr	w8, [x0, #392]
	mov	x10, x8
LBB4_15:
	cmp	w10, w8
	cset	w0, eq
LBB4_16:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_metadata       ; -- Begin function nvm_add_metadata
	.globl	_nvm_add_metadata
	.p2align	2
_nvm_add_metadata:                      ; @nvm_add_metadata
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB5_18
; %bb.1:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	w21, [x0, #368]
	cbz	w21, LBB5_14
; %bb.2:
	ldr	x12, [x0, #360]
	cbz	x12, LBB5_16
; %bb.3:
	mov	x8, #24942                      ; =0x616e
	movk	x8, #28526, lsl #16
	movk	x8, #29486, lsl #32
	movk	x8, #30063, lsl #48
	mov	x10, #25458                     ; =0x6372
	movk	x10, #24421, lsl #16
	movk	x10, #26982, lsl #32
	movk	x10, #25964, lsl #48
	ldr	w9, [x0, #392]
	ldr	w11, [x0, #248]
	add	x12, x12, #4
	mov	x14, x21
	mov	x13, x9
	b	LBB5_5
LBB5_4:                                 ;   in Loop: Header=BB5_5 Depth=1
	add	x12, x12, #8
	subs	x14, x14, #1
	b.eq	LBB5_13
LBB5_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x12, #-4]
	cmp	w16, w11
	b.hs	LBB5_16
; %bb.6:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	w15, [x12]
	cmp	w15, w11
	b.hs	LBB5_16
; %bb.7:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB5_16
; %bb.8:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB5_16
; %bb.9:                                ;   in Loop: Header=BB5_5 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB5_16
; %bb.10:                               ;   in Loop: Header=BB5_5 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB5_16
; %bb.11:                               ;   in Loop: Header=BB5_5 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB5_4
; %bb.12:                               ;   in Loop: Header=BB5_5 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x8
	eor	x17, x17, x10
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB5_4
LBB5_13:
	cmp	w13, w9
	b.ne	LBB5_16
LBB5_14:
	ldr	w8, [x0, #372]
	cmp	w21, w8
	b.hi	LBB5_16
; %bb.15:
	ldr	w9, [x0, #248]
	cmp	w1, w9
	ccmp	w2, w9, #2, lo
	b.lo	LBB5_19
LBB5_16:
	mov	w0, #0                          ; =0x0
LBB5_17:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
LBB5_18:
	ret
LBB5_19:
	cmp	w21, w8
	b.ne	LBB5_25
; %bb.20:
	tbnz	w21, #31, LBB5_16
; %bb.21:
	mov	x22, x1
	mov	x24, x0
	mov	x23, x2
	lsl	w8, w21, #1
	mov	w9, #8                          ; =0x8
	cmp	w21, #0
	csel	w25, w9, w8, eq
	ubfiz	x0, x25, #3, #32
	bl	_malloc
	cbz	x0, LBB5_17
; %bb.22:
	mov	x19, x0
	ldr	x20, [x24, #360]
	cbz	w21, LBB5_24
; %bb.23:
	lsl	x2, x21, #3
	mov	x0, x19
	mov	x1, x20
	bl	_memcpy
LBB5_24:
	mov	x0, x20
	bl	_free
	mov	x0, x24
	str	x19, [x24, #360]
	str	w25, [x24, #372]
	ldr	w21, [x24, #368]
	mov	x2, x23
	mov	x1, x22
	b	LBB5_26
LBB5_25:
	ldr	x19, [x0, #360]
LBB5_26:
	add	w8, w21, #1
	str	w8, [x0, #368]
	add	x8, x19, w21, uxtw #3
	stp	w1, w2, [x8]
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB5_33
; %bb.27:
	ldr	x8, [x0, #232]
	cbz	x8, LBB5_33
; %bb.28:
	ldr	x9, [x0, #240]
	cbz	x9, LBB5_33
; %bb.29:
	ldr	x8, [x8, w1, uxtw #3]
	cbz	x8, LBB5_33
; %bb.30:
	ldr	w9, [x9, w1, uxtw #2]
	cmp	w9, #16
	b.ne	LBB5_33
; %bb.31:
	ldp	x9, x8, [x8]
	mov	x10, #24942                     ; =0x616e
	movk	x10, #28526, lsl #16
	movk	x10, #29486, lsl #32
	movk	x10, #30063, lsl #48
	cmp	x9, x10
	mov	x9, #25458                      ; =0x6372
	movk	x9, #24421, lsl #16
	movk	x9, #26982, lsl #32
	movk	x9, #25964, lsl #48
	ccmp	x8, x9, #0, eq
	b.ne	LBB5_33
; %bb.32:
	str	w2, [x0, #392]
LBB5_33:
	mov	w0, #1                          ; =0x1
	b	LBB5_17
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_function_purity    ; -- Begin function nvm_function_purity
	.globl	_nvm_function_purity
	.p2align	2
_nvm_function_purity:                   ; @nvm_function_purity
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_26
; %bb.1:
	ldr	w9, [x0, #368]
	cbz	w9, LBB6_26
; %bb.2:
	ldr	x10, [x0, #360]
	cbz	x10, LBB6_26
; %bb.3:
	ldr	w8, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x9
	mov	x14, x8
	b	LBB6_5
LBB6_4:                                 ;   in Loop: Header=BB6_5 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB6_13
LBB6_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB6_26
; %bb.6:                                ;   in Loop: Header=BB6_5 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB6_26
; %bb.7:                                ;   in Loop: Header=BB6_5 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB6_26
; %bb.8:                                ;   in Loop: Header=BB6_5 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB6_26
; %bb.9:                                ;   in Loop: Header=BB6_5 Depth=1
	ldr	x2, [x4, x17, lsl #3]
	cbz	x2, LBB6_26
; %bb.10:                               ;   in Loop: Header=BB6_5 Depth=1
	ldr	x4, [x4, x16, lsl #3]
	cbz	x4, LBB6_26
; %bb.11:                               ;   in Loop: Header=BB6_5 Depth=1
	ldr	w17, [x3, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB6_4
; %bb.12:                               ;   in Loop: Header=BB6_5 Depth=1
	ldp	x17, x2, [x2]
	eor	x17, x17, x12
	eor	x2, x2, x13
	orr	x17, x17, x2
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB6_4
LBB6_13:
	cmp	w14, w8
	b.ne	LBB6_26
; %bb.14:
	ldr	w10, [x0, #272]
	cmp	w1, w10
	b.hs	LBB6_26
; %bb.15:
	ldr	x8, [x0, #360]
	ldr	x11, [x0, #240]
	add	x12, x8, #4
	mov	w8, #-1                         ; =0xffffffff
	mov	x13, #24942                     ; =0x616e
	movk	x13, #28526, lsl #16
	movk	x13, #28718, lsl #32
	movk	x13, #29301, lsl #48
	mov	x14, #29301                     ; =0x7275
	movk	x14, #29801, lsl #16
	movk	x14, #11897, lsl #32
	movk	x14, #12662, lsl #48
	b	LBB6_17
LBB6_16:                                ;   in Loop: Header=BB6_17 Depth=1
	add	x12, x12, #8
	subs	x9, x9, #1
	b.eq	LBB6_27
LBB6_17:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x12, #-4]
	ldr	w15, [x11, x16, lsl #2]
	cmp	w15, #14
	b.ne	LBB6_16
; %bb.18:                               ;   in Loop: Header=BB6_17 Depth=1
	ldr	x15, [x0, #232]
	ldr	x16, [x15, x16, lsl #3]
	ldr	x17, [x16]
	ldur	x16, [x16, #6]
	cmp	x17, x13
	ccmp	x16, x14, #0, eq
	b.ne	LBB6_16
; %bb.19:                               ;   in Loop: Header=BB6_17 Depth=1
	ldr	w16, [x12]
	ldr	w17, [x11, x16, lsl #2]
	cmp	w17, #8
	b.ne	LBB6_26
; %bb.20:                               ;   in Loop: Header=BB6_17 Depth=1
	ldr	x17, [x15, x16, lsl #3]
	ldr	w16, [x17]
	ldrb	w15, [x17, #4]
	cmp	w16, w10
	ccmp	w15, #1, #2, lo
	b.hi	LBB6_26
; %bb.21:                               ;   in Loop: Header=BB6_17 Depth=1
	ldrb	w2, [x17, #5]
	cbnz	w2, LBB6_26
; %bb.22:                               ;   in Loop: Header=BB6_17 Depth=1
	ldrb	w2, [x17, #6]
	cbnz	w2, LBB6_26
; %bb.23:                               ;   in Loop: Header=BB6_17 Depth=1
	ldrb	w17, [x17, #7]
	cbnz	w17, LBB6_26
; %bb.24:                               ;   in Loop: Header=BB6_17 Depth=1
	cmp	w16, w1
	b.ne	LBB6_16
; %bb.25:                               ;   in Loop: Header=BB6_17 Depth=1
	cmn	w8, #1
	mov	x8, x15
	b.eq	LBB6_16
LBB6_26:
	mov	w8, #-1                         ; =0xffffffff
LBB6_27:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_function_purity ; -- Begin function nvm_add_function_purity
	.globl	_nvm_add_function_purity
	.p2align	2
_nvm_add_function_purity:               ; @nvm_add_function_purity
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh6:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh7:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh8:
	ldr	x8, [x8]
	str	x8, [sp, #8]
	cbz	x0, LBB7_29
; %bb.1:
	ldr	w8, [x0, #368]
	cbz	w8, LBB7_13
; %bb.2:
	ldr	x10, [x0, #360]
	cbz	x10, LBB7_28
; %bb.3:
	ldr	w9, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x8
	mov	x14, x9
	b	LBB7_5
LBB7_4:                                 ;   in Loop: Header=BB7_5 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB7_17
LBB7_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB7_28
; %bb.6:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB7_28
; %bb.7:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	x5, [x0, #232]
	cbz	x5, LBB7_28
; %bb.8:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	x4, [x0, #240]
	cbz	x4, LBB7_28
; %bb.9:                                ;   in Loop: Header=BB7_5 Depth=1
	ldr	x3, [x5, x17, lsl #3]
	cbz	x3, LBB7_28
; %bb.10:                               ;   in Loop: Header=BB7_5 Depth=1
	ldr	x5, [x5, x16, lsl #3]
	cbz	x5, LBB7_28
; %bb.11:                               ;   in Loop: Header=BB7_5 Depth=1
	ldr	w17, [x4, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB7_4
; %bb.12:                               ;   in Loop: Header=BB7_5 Depth=1
	ldp	x17, x3, [x3]
	eor	x17, x17, x12
	eor	x3, x3, x13
	orr	x17, x17, x3
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB7_4
LBB7_13:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB7_28
LBB7_14:
	str	xzr, [sp]
	strb	w1, [sp]
	lsr	w8, w1, #8
	strb	w8, [sp, #1]
	lsr	w8, w1, #16
	strb	w8, [sp, #2]
	lsr	w8, w1, #24
	strb	w8, [sp, #3]
	strb	w2, [sp, #4]
Lloh9:
	adrp	x1, _purity_key@PAGE
Lloh10:
	add	x1, x1, _purity_key@PAGEOFF
	mov	x19, x0
	mov	w2, #14                         ; =0xe
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB7_28
; %bb.15:
	mov	x20, x0
	mov	x1, sp
	mov	x0, x19
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB7_28
; %bb.16:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_add_metadata
	b	LBB7_29
LBB7_17:
	cmp	w14, w9
	b.ne	LBB7_28
; %bb.18:
	ldr	w9, [x0, #272]
	cmp	w1, w9
	b.hs	LBB7_28
; %bb.19:
	ldr	x11, [x0, #360]
	ldr	x10, [x0, #240]
	add	x11, x11, #4
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #28718, lsl #32
	movk	x12, #29301, lsl #48
	mov	x13, #29301                     ; =0x7275
	movk	x13, #29801, lsl #16
	movk	x13, #11897, lsl #32
	movk	x13, #12662, lsl #48
	b	LBB7_21
LBB7_20:                                ;   in Loop: Header=BB7_21 Depth=1
	add	x11, x11, #8
	subs	x8, x8, #1
	b.eq	LBB7_14
LBB7_21:                                ; =>This Inner Loop Header: Depth=1
	ldur	w15, [x11, #-4]
	ldr	w14, [x10, x15, lsl #2]
	cmp	w14, #14
	b.ne	LBB7_20
; %bb.22:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	x14, [x0, #232]
	ldr	x15, [x14, x15, lsl #3]
	ldr	x16, [x15]
	ldur	x15, [x15, #6]
	cmp	x16, x12
	ccmp	x15, x13, #0, eq
	b.ne	LBB7_20
; %bb.23:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	w15, [x11]
	ldr	w16, [x10, x15, lsl #2]
	cmp	w16, #8
	b.ne	LBB7_28
; %bb.24:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	x14, [x14, x15, lsl #3]
	ldr	w15, [x14]
	ldrb	w16, [x14, #4]
	cmp	w15, w9
	ccmp	w16, #1, #2, lo
	b.hi	LBB7_28
; %bb.25:                               ;   in Loop: Header=BB7_21 Depth=1
	ldrb	w16, [x14, #5]
	cbnz	w16, LBB7_28
; %bb.26:                               ;   in Loop: Header=BB7_21 Depth=1
	ldrb	w16, [x14, #6]
	cbnz	w16, LBB7_28
; %bb.27:                               ;   in Loop: Header=BB7_21 Depth=1
	ldrb	w14, [x14, #7]
	cmp	w15, w1
	ccmp	w14, #0, #0, ne
	b.eq	LBB7_20
LBB7_28:
	mov	w0, #0                          ; =0x0
LBB7_29:
	ldr	x8, [sp, #8]
Lloh11:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh12:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh13:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_31
; %bb.30:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB7_31:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpAdd	Lloh9, Lloh10
	.loh AdrpLdrGotLdr	Lloh11, Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_string         ; -- Begin function nvm_add_string
	.globl	_nvm_add_string
	.p2align	2
_nvm_add_string:                        ; @nvm_add_string
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB8_3
; %bb.1:
	mov	x20, x2
	mov	x19, x0
	cbnz	x1, LBB8_5
; %bb.2:
	cbz	w20, LBB8_5
LBB8_3:
	mov	w21, #-1                        ; =0xffffffff
LBB8_4:
	mov	x0, x21
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB8_5:
Lloh14:
	adrp	x8, l_.str@PAGE
Lloh15:
	add	x8, x8, l_.str@PAGEOFF
	cmp	x1, #0
	csel	x22, x8, x1, eq
	ldr	w21, [x19, #248]
	cbz	w21, LBB8_11
; %bb.6:
	mov	x24, #0                         ; =0x0
	ldr	x25, [x19, #240]
	mov	w23, w20
	b	LBB8_8
LBB8_7:                                 ;   in Loop: Header=BB8_8 Depth=1
	add	x24, x24, #1
	cmp	x21, x24
	b.eq	LBB8_11
LBB8_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x25, x24, lsl #2]
	cmp	w8, w20
	b.ne	LBB8_7
; %bb.9:                                ;   in Loop: Header=BB8_8 Depth=1
	ldr	x8, [x19, #232]
	ldr	x0, [x8, x24, lsl #3]
	mov	x1, x22
	mov	x2, x23
	bl	_memcmp
	cbnz	w0, LBB8_7
; %bb.10:
	mov	x21, x24
	b	LBB8_4
LBB8_11:
	ldr	w8, [x19, #252]
	cmp	w21, w8
	b.hs	LBB8_13
; %bb.12:
	ldr	x23, [x19, #232]
	b	LBB8_19
LBB8_13:
	tbnz	w8, #31, LBB8_3
; %bb.14:
	lsl	w9, w8, #1
	mov	w10, #16                        ; =0x10
	cmp	w8, #0
	csel	w26, w10, w9, eq
	ubfiz	x0, x26, #3, #32
	bl	_malloc
	mov	x23, x0
	ubfiz	x0, x26, #2, #32
	bl	_malloc
	mov	x24, x0
	cmp	x23, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB8_16
; %bb.15:
	mov	x0, x23
	bl	_free
	mov	x0, x24
	bl	_free
	b	LBB8_3
LBB8_16:
	ldr	x25, [x19, #232]
	cbz	w21, LBB8_18
; %bb.17:
	lsl	x2, x21, #3
	mov	x0, x23
	mov	x1, x25
	bl	_memcpy
	ldr	x1, [x19, #240]
	lsl	x2, x21, #2
	mov	x0, x24
	bl	_memcpy
LBB8_18:
	mov	x0, x25
	bl	_free
	ldr	x0, [x19, #240]
	bl	_free
	stp	x23, x24, [x19, #232]
	str	w26, [x19, #252]
	ldr	w21, [x19, #248]
LBB8_19:
	mov	w24, w20
	add	x0, x24, #1
	bl	_malloc
	str	x0, [x23, w21, uxtw #3]
	cbz	x0, LBB8_3
; %bb.20:
	mov	x23, x0
	mov	x1, x22
	mov	x2, x24
	bl	_memcpy
	strb	wzr, [x23, x24]
	ldr	x8, [x19, #240]
	str	w20, [x8, w21, uxtw #2]
	ldr	w8, [x19, #248]
	add	w8, w8, #1
	str	w8, [x19, #248]
	b	LBB8_4
	.loh AdrpAdd	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_function_effects   ; -- Begin function nvm_function_effects
	.globl	_nvm_function_effects
	.p2align	2
_nvm_function_effects:                  ; @nvm_function_effects
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_27
; %bb.1:
	ldr	w9, [x0, #368]
	cbz	w9, LBB9_27
; %bb.2:
	ldr	x10, [x0, #360]
	cbz	x10, LBB9_27
; %bb.3:
	ldr	w8, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x9
	mov	x14, x8
	b	LBB9_5
LBB9_4:                                 ;   in Loop: Header=BB9_5 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB9_13
LBB9_5:                                 ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB9_27
; %bb.6:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB9_27
; %bb.7:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB9_27
; %bb.8:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB9_27
; %bb.9:                                ;   in Loop: Header=BB9_5 Depth=1
	ldr	x2, [x4, x17, lsl #3]
	cbz	x2, LBB9_27
; %bb.10:                               ;   in Loop: Header=BB9_5 Depth=1
	ldr	x4, [x4, x16, lsl #3]
	cbz	x4, LBB9_27
; %bb.11:                               ;   in Loop: Header=BB9_5 Depth=1
	ldr	w17, [x3, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB9_4
; %bb.12:                               ;   in Loop: Header=BB9_5 Depth=1
	ldp	x17, x2, [x2]
	eor	x17, x17, x12
	eor	x2, x2, x13
	orr	x17, x17, x2
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB9_4
LBB9_13:
	cmp	w14, w8
	b.ne	LBB9_27
; %bb.14:
	ldr	w10, [x0, #272]
	cmp	w1, w10
	b.hs	LBB9_27
; %bb.15:
	ldr	x8, [x0, #360]
	ldr	x11, [x0, #240]
	add	x12, x8, #4
	mov	w13, #-1                        ; =0xffffffff
	mov	x14, #24942                     ; =0x616e
	movk	x14, #28526, lsl #16
	movk	x14, #25902, lsl #32
	movk	x14, #26214, lsl #48
	mov	x15, #25958                     ; =0x6566
	movk	x15, #29795, lsl #16
	movk	x15, #11891, lsl #32
	movk	x15, #12662, lsl #48
	b	LBB9_17
LBB9_16:                                ;   in Loop: Header=BB9_17 Depth=1
	add	x12, x12, #8
	mov	x8, x13
	subs	x9, x9, #1
	b.eq	LBB9_28
LBB9_17:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x12, #-4]
	ldr	w8, [x11, x16, lsl #2]
	cmp	w8, #15
	b.ne	LBB9_16
; %bb.18:                               ;   in Loop: Header=BB9_17 Depth=1
	ldr	x8, [x0, #232]
	ldr	x16, [x8, x16, lsl #3]
	ldr	x17, [x16]
	ldur	x16, [x16, #7]
	cmp	x17, x14
	ccmp	x16, x15, #0, eq
	b.ne	LBB9_16
; %bb.19:                               ;   in Loop: Header=BB9_17 Depth=1
	ldr	w16, [x12]
	ldr	w17, [x11, x16, lsl #2]
	cmp	w17, #8
	b.ne	LBB9_27
; %bb.20:                               ;   in Loop: Header=BB9_17 Depth=1
	ldr	x2, [x8, x16, lsl #3]
	ldr	w16, [x2]
	mov	w8, #-1                         ; =0xffffffff
	cmp	w16, w10
	b.hs	LBB9_28
; %bb.21:                               ;   in Loop: Header=BB9_17 Depth=1
	ldrb	w17, [x2, #4]
	cmp	w17, #63
	b.hi	LBB9_28
; %bb.22:                               ;   in Loop: Header=BB9_17 Depth=1
	ldrb	w8, [x2, #5]
	cbnz	w8, LBB9_27
; %bb.23:                               ;   in Loop: Header=BB9_17 Depth=1
	ldrb	w8, [x2, #6]
	cbnz	w8, LBB9_27
; %bb.24:                               ;   in Loop: Header=BB9_17 Depth=1
	ldrb	w8, [x2, #7]
	cbnz	w8, LBB9_27
; %bb.25:                               ;   in Loop: Header=BB9_17 Depth=1
	cmp	w16, w1
	b.ne	LBB9_16
; %bb.26:                               ;   in Loop: Header=BB9_17 Depth=1
	cmn	w13, #1
	mov	x13, x17
	b.eq	LBB9_16
LBB9_27:
	mov	w8, #-1                         ; =0xffffffff
LBB9_28:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_function_effects ; -- Begin function nvm_add_function_effects
	.globl	_nvm_add_function_effects
	.p2align	2
_nvm_add_function_effects:              ; @nvm_add_function_effects
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w3, #0                          ; =0x0
Lloh16:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh17:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh18:
	ldr	x8, [x8]
	str	x8, [sp, #8]
	cbz	x0, LBB10_31
; %bb.1:
	cmp	w2, #63
	b.hi	LBB10_31
; %bb.2:
	ldr	w8, [x0, #368]
	cbz	w8, LBB10_14
; %bb.3:
	ldr	x10, [x0, #360]
	cbz	x10, LBB10_30
; %bb.4:
	ldr	w9, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x8
	mov	x14, x9
	b	LBB10_6
LBB10_5:                                ;   in Loop: Header=BB10_6 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB10_18
LBB10_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB10_30
; %bb.7:                                ;   in Loop: Header=BB10_6 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB10_30
; %bb.8:                                ;   in Loop: Header=BB10_6 Depth=1
	ldr	x5, [x0, #232]
	cbz	x5, LBB10_30
; %bb.9:                                ;   in Loop: Header=BB10_6 Depth=1
	ldr	x4, [x0, #240]
	cbz	x4, LBB10_30
; %bb.10:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	x3, [x5, x17, lsl #3]
	cbz	x3, LBB10_31
; %bb.11:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	x5, [x5, x16, lsl #3]
	cbz	x5, LBB10_30
; %bb.12:                               ;   in Loop: Header=BB10_6 Depth=1
	ldr	w17, [x4, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB10_5
; %bb.13:                               ;   in Loop: Header=BB10_6 Depth=1
	ldp	x17, x3, [x3]
	eor	x17, x17, x12
	eor	x3, x3, x13
	orr	x17, x17, x3
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB10_5
LBB10_14:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB10_30
LBB10_15:
	str	xzr, [sp]
	strb	w1, [sp]
	lsr	w8, w1, #8
	strb	w8, [sp, #1]
	lsr	w8, w1, #16
	strb	w8, [sp, #2]
	lsr	w8, w1, #24
	strb	w8, [sp, #3]
	strb	w2, [sp, #4]
Lloh19:
	adrp	x1, _effects_key@PAGE
Lloh20:
	add	x1, x1, _effects_key@PAGEOFF
	mov	x19, x0
	mov	w2, #15                         ; =0xf
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB10_30
; %bb.16:
	mov	x20, x0
	mov	x1, sp
	mov	x0, x19
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB10_30
; %bb.17:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_add_metadata
	mov	x3, x0
	b	LBB10_31
LBB10_18:
	cmp	w14, w9
	b.ne	LBB10_30
; %bb.19:
	ldr	w9, [x0, #272]
	cmp	w1, w9
	b.hs	LBB10_30
; %bb.20:
	ldr	x11, [x0, #360]
	ldr	x10, [x0, #240]
	add	x11, x11, #4
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #25902, lsl #32
	movk	x12, #26214, lsl #48
	mov	x13, #25958                     ; =0x6566
	movk	x13, #29795, lsl #16
	movk	x13, #11891, lsl #32
	movk	x13, #12662, lsl #48
	b	LBB10_22
LBB10_21:                               ;   in Loop: Header=BB10_22 Depth=1
	add	x11, x11, #8
	subs	x8, x8, #1
	b.eq	LBB10_15
LBB10_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w15, [x11, #-4]
	ldr	w14, [x10, x15, lsl #2]
	cmp	w14, #15
	b.ne	LBB10_21
; %bb.23:                               ;   in Loop: Header=BB10_22 Depth=1
	ldr	x14, [x0, #232]
	ldr	x15, [x14, x15, lsl #3]
	ldr	x16, [x15]
	ldur	x15, [x15, #7]
	cmp	x16, x12
	ccmp	x15, x13, #0, eq
	b.ne	LBB10_21
; %bb.24:                               ;   in Loop: Header=BB10_22 Depth=1
	ldr	w15, [x11]
	ldr	w16, [x10, x15, lsl #2]
	cmp	w16, #8
	b.ne	LBB10_30
; %bb.25:                               ;   in Loop: Header=BB10_22 Depth=1
	mov	w3, #0                          ; =0x0
	ldr	x14, [x14, x15, lsl #3]
	ldr	w15, [x14]
	cmp	w15, w9
	b.hs	LBB10_31
; %bb.26:                               ;   in Loop: Header=BB10_22 Depth=1
	ldrb	w16, [x14, #4]
	cmp	w16, #63
	b.hi	LBB10_31
; %bb.27:                               ;   in Loop: Header=BB10_22 Depth=1
	ldrb	w16, [x14, #5]
	cbnz	w16, LBB10_30
; %bb.28:                               ;   in Loop: Header=BB10_22 Depth=1
	ldrb	w16, [x14, #6]
	cbnz	w16, LBB10_30
; %bb.29:                               ;   in Loop: Header=BB10_22 Depth=1
	ldrb	w14, [x14, #7]
	cmp	w15, w1
	ccmp	w14, #0, #0, ne
	b.eq	LBB10_21
LBB10_30:
	mov	w3, #0                          ; =0x0
LBB10_31:
	ldr	x8, [sp, #8]
Lloh21:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh22:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh23:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB10_33
; %bb.32:
	mov	x0, x3
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB10_33:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh16, Lloh17, Lloh18
	.loh AdrpAdd	Lloh19, Lloh20
	.loh AdrpLdrGotLdr	Lloh21, Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_function_affine    ; -- Begin function nvm_function_affine
	.globl	_nvm_function_affine
	.p2align	2
_nvm_function_affine:                   ; @nvm_function_affine
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_26
; %bb.1:
	ldr	w9, [x0, #368]
	cbz	w9, LBB11_26
; %bb.2:
	ldr	x10, [x0, #360]
	cbz	x10, LBB11_26
; %bb.3:
	ldr	w8, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x9
	mov	x14, x8
	b	LBB11_5
LBB11_4:                                ;   in Loop: Header=BB11_5 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB11_13
LBB11_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB11_26
; %bb.6:                                ;   in Loop: Header=BB11_5 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB11_26
; %bb.7:                                ;   in Loop: Header=BB11_5 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB11_26
; %bb.8:                                ;   in Loop: Header=BB11_5 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB11_26
; %bb.9:                                ;   in Loop: Header=BB11_5 Depth=1
	ldr	x2, [x4, x17, lsl #3]
	cbz	x2, LBB11_26
; %bb.10:                               ;   in Loop: Header=BB11_5 Depth=1
	ldr	x4, [x4, x16, lsl #3]
	cbz	x4, LBB11_26
; %bb.11:                               ;   in Loop: Header=BB11_5 Depth=1
	ldr	w17, [x3, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB11_4
; %bb.12:                               ;   in Loop: Header=BB11_5 Depth=1
	ldp	x17, x2, [x2]
	eor	x17, x17, x12
	eor	x2, x2, x13
	orr	x17, x17, x2
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB11_4
LBB11_13:
	cmp	w14, w8
	b.ne	LBB11_26
; %bb.14:
	ldr	w10, [x0, #272]
	cmp	w1, w10
	b.hs	LBB11_26
; %bb.15:
	ldr	x8, [x0, #360]
	ldr	x11, [x0, #240]
	add	x12, x8, #4
	mov	w8, #-1                         ; =0xffffffff
	mov	x13, #24942                     ; =0x616e
	movk	x13, #28526, lsl #16
	movk	x13, #24878, lsl #32
	movk	x13, #26214, lsl #48
	mov	x14, #26214                     ; =0x6666
	movk	x14, #28265, lsl #16
	movk	x14, #11877, lsl #32
	movk	x14, #12662, lsl #48
	b	LBB11_17
LBB11_16:                               ;   in Loop: Header=BB11_17 Depth=1
	add	x12, x12, #8
	subs	x9, x9, #1
	b.eq	LBB11_27
LBB11_17:                               ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x12, #-4]
	ldr	w15, [x11, x16, lsl #2]
	cmp	w15, #14
	b.ne	LBB11_16
; %bb.18:                               ;   in Loop: Header=BB11_17 Depth=1
	ldr	x15, [x0, #232]
	ldr	x16, [x15, x16, lsl #3]
	ldr	x17, [x16]
	ldur	x16, [x16, #6]
	cmp	x17, x13
	ccmp	x16, x14, #0, eq
	b.ne	LBB11_16
; %bb.19:                               ;   in Loop: Header=BB11_17 Depth=1
	ldr	w16, [x12]
	ldr	w17, [x11, x16, lsl #2]
	cmp	w17, #8
	b.ne	LBB11_26
; %bb.20:                               ;   in Loop: Header=BB11_17 Depth=1
	ldr	x17, [x15, x16, lsl #3]
	ldr	w16, [x17]
	ldrb	w15, [x17, #4]
	cmp	w16, w10
	ccmp	w15, #1, #2, lo
	b.hi	LBB11_26
; %bb.21:                               ;   in Loop: Header=BB11_17 Depth=1
	ldrb	w2, [x17, #5]
	cbnz	w2, LBB11_26
; %bb.22:                               ;   in Loop: Header=BB11_17 Depth=1
	ldrb	w2, [x17, #6]
	cbnz	w2, LBB11_26
; %bb.23:                               ;   in Loop: Header=BB11_17 Depth=1
	ldrb	w17, [x17, #7]
	cbnz	w17, LBB11_26
; %bb.24:                               ;   in Loop: Header=BB11_17 Depth=1
	cmp	w16, w1
	b.ne	LBB11_16
; %bb.25:                               ;   in Loop: Header=BB11_17 Depth=1
	cmn	w8, #1
	mov	x8, x15
	b.eq	LBB11_16
LBB11_26:
	mov	w8, #-1                         ; =0xffffffff
LBB11_27:
	mov	x0, x8
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_function_affine ; -- Begin function nvm_add_function_affine
	.globl	_nvm_add_function_affine
	.p2align	2
_nvm_add_function_affine:               ; @nvm_add_function_affine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w3, #0                          ; =0x0
Lloh24:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh25:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh26:
	ldr	x8, [x8]
	str	x8, [sp, #8]
	cbz	x0, LBB12_30
; %bb.1:
	cmp	w2, #1
	b.hi	LBB12_30
; %bb.2:
	ldr	w8, [x0, #368]
	cbz	w8, LBB12_14
; %bb.3:
	ldr	x10, [x0, #360]
	cbz	x10, LBB12_29
; %bb.4:
	ldr	w9, [x0, #392]
	add	x10, x10, #4
	ldr	w11, [x0, #248]
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x15, x8
	mov	x14, x9
	b	LBB12_6
LBB12_5:                                ;   in Loop: Header=BB12_6 Depth=1
	add	x10, x10, #8
	subs	x15, x15, #1
	b.eq	LBB12_18
LBB12_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w17, [x10, #-4]
	cmp	w17, w11
	b.hs	LBB12_29
; %bb.7:                                ;   in Loop: Header=BB12_6 Depth=1
	ldr	w16, [x10]
	cmp	w16, w11
	b.hs	LBB12_29
; %bb.8:                                ;   in Loop: Header=BB12_6 Depth=1
	ldr	x5, [x0, #232]
	cbz	x5, LBB12_29
; %bb.9:                                ;   in Loop: Header=BB12_6 Depth=1
	ldr	x4, [x0, #240]
	cbz	x4, LBB12_29
; %bb.10:                               ;   in Loop: Header=BB12_6 Depth=1
	ldr	x3, [x5, x17, lsl #3]
	cbz	x3, LBB12_30
; %bb.11:                               ;   in Loop: Header=BB12_6 Depth=1
	ldr	x5, [x5, x16, lsl #3]
	cbz	x5, LBB12_29
; %bb.12:                               ;   in Loop: Header=BB12_6 Depth=1
	ldr	w17, [x4, x17, lsl #2]
	cmp	w17, #16
	b.ne	LBB12_5
; %bb.13:                               ;   in Loop: Header=BB12_6 Depth=1
	ldp	x17, x3, [x3]
	eor	x17, x17, x12
	eor	x3, x3, x13
	orr	x17, x17, x3
	cmp	x17, #0
	csel	w14, w14, w16, ne
	b	LBB12_5
LBB12_14:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB12_29
LBB12_15:
	str	xzr, [sp]
	strb	w1, [sp]
	lsr	w8, w1, #8
	strb	w8, [sp, #1]
	lsr	w8, w1, #16
	strb	w8, [sp, #2]
	lsr	w8, w1, #24
	strb	w8, [sp, #3]
	strb	w2, [sp, #4]
Lloh27:
	adrp	x1, _affine_key@PAGE
Lloh28:
	add	x1, x1, _affine_key@PAGEOFF
	mov	x19, x0
	mov	w2, #14                         ; =0xe
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB12_29
; %bb.16:
	mov	x20, x0
	mov	x1, sp
	mov	x0, x19
	mov	w2, #8                          ; =0x8
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB12_29
; %bb.17:
	mov	x2, x0
	mov	x0, x19
	mov	x1, x20
	bl	_nvm_add_metadata
	mov	x3, x0
	b	LBB12_30
LBB12_18:
	cmp	w14, w9
	b.ne	LBB12_29
; %bb.19:
	ldr	w9, [x0, #272]
	cmp	w1, w9
	b.hs	LBB12_29
; %bb.20:
	ldr	x11, [x0, #360]
	ldr	x10, [x0, #240]
	add	x11, x11, #4
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #24878, lsl #32
	movk	x12, #26214, lsl #48
	mov	x13, #26214                     ; =0x6666
	movk	x13, #28265, lsl #16
	movk	x13, #11877, lsl #32
	movk	x13, #12662, lsl #48
	b	LBB12_22
LBB12_21:                               ;   in Loop: Header=BB12_22 Depth=1
	add	x11, x11, #8
	subs	x8, x8, #1
	b.eq	LBB12_15
LBB12_22:                               ; =>This Inner Loop Header: Depth=1
	ldur	w15, [x11, #-4]
	ldr	w14, [x10, x15, lsl #2]
	cmp	w14, #14
	b.ne	LBB12_21
; %bb.23:                               ;   in Loop: Header=BB12_22 Depth=1
	ldr	x14, [x0, #232]
	ldr	x15, [x14, x15, lsl #3]
	ldr	x16, [x15]
	ldur	x15, [x15, #6]
	cmp	x16, x12
	ccmp	x15, x13, #0, eq
	b.ne	LBB12_21
; %bb.24:                               ;   in Loop: Header=BB12_22 Depth=1
	ldr	w15, [x11]
	ldr	w16, [x10, x15, lsl #2]
	cmp	w16, #8
	b.ne	LBB12_29
; %bb.25:                               ;   in Loop: Header=BB12_22 Depth=1
	ldr	x14, [x14, x15, lsl #3]
	ldr	w15, [x14]
	ldrb	w16, [x14, #4]
	cmp	w15, w9
	ccmp	w16, #1, #2, lo
	b.hi	LBB12_29
; %bb.26:                               ;   in Loop: Header=BB12_22 Depth=1
	ldrb	w16, [x14, #5]
	cbnz	w16, LBB12_29
; %bb.27:                               ;   in Loop: Header=BB12_22 Depth=1
	ldrb	w16, [x14, #6]
	cbnz	w16, LBB12_29
; %bb.28:                               ;   in Loop: Header=BB12_22 Depth=1
	ldrb	w14, [x14, #7]
	cmp	w15, w1
	ccmp	w14, #0, #0, ne
	b.eq	LBB12_21
LBB12_29:
	mov	w3, #0                          ; =0x0
LBB12_30:
	ldr	x8, [sp, #8]
Lloh29:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh30:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh31:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB12_32
; %bb.31:
	mov	x0, x3
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB12_32:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh24, Lloh25, Lloh26
	.loh AdrpAdd	Lloh27, Lloh28
	.loh AdrpLdrGotLdr	Lloh29, Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_match_coverage_at  ; -- Begin function nvm_match_coverage_at
	.globl	_nvm_match_coverage_at
	.p2align	2
_nvm_match_coverage_at:                 ; @nvm_match_coverage_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB13_25
; %bb.1:
	cbz	x2, LBB13_25
; %bb.2:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w21, [x0, #368]
	cbz	w21, LBB13_23
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB13_24
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x21
	mov	x12, x9
	b	LBB13_6
LBB13_5:                                ;   in Loop: Header=BB13_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB13_14
LBB13_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB13_23
; %bb.7:                                ;   in Loop: Header=BB13_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB13_23
; %bb.8:                                ;   in Loop: Header=BB13_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB13_23
; %bb.9:                                ;   in Loop: Header=BB13_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB13_23
; %bb.10:                               ;   in Loop: Header=BB13_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB13_23
; %bb.11:                               ;   in Loop: Header=BB13_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB13_23
; %bb.12:                               ;   in Loop: Header=BB13_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB13_5
; %bb.13:                               ;   in Loop: Header=BB13_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB13_5
LBB13_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB13_24
; %bb.15:
	cmp	w1, w21
	b.hs	LBB13_24
; %bb.16:
	ldr	x26, [x0, #360]
	add	x8, x26, w1, uxtw #3
	ldr	x22, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x22, x9, lsl #2]
	cmp	w10, #13
	b.ne	LBB13_23
; %bb.17:
	mov	x23, #24942                     ; =0x616e
	movk	x23, #28526, lsl #16
	movk	x23, #27950, lsl #32
	movk	x23, #29793, lsl #48
	mov	x24, #24941                     ; =0x616d
	movk	x24, #25460, lsl #16
	movk	x24, #11880, lsl #32
	movk	x24, #12662, lsl #48
	ldr	x25, [x0, #232]
	ldr	x9, [x25, x9, lsl #3]
	ldr	x10, [x9]
	ldur	x9, [x9, #5]
	cmp	x10, x23
	ccmp	x9, x24, #0, eq
	b.ne	LBB13_23
; %bb.18:
	ldr	w9, [x8, #4]
	ldr	w8, [x22, x9, lsl #2]
	subs	w8, w8, #20
	b.lo	LBB13_23
; %bb.19:
	ldr	x9, [x25, x9, lsl #3]
	ldp	w12, w13, [x9]
	ldr	w28, [x9, #8]
	ldrb	w10, [x9, #12]
	ldrb	w14, [x9, #13]
	ldr	w19, [x0, #272]
	sub	w11, w14, #3
	cmp	w12, w19
	ccmp	w13, #0, #4, lo
	ccmp	w28, #0, #4, ne
	ccmp	w10, #2, #2, ne
	ccmn	w11, #2, #0, ls
	b.lo	LBB13_23
; %bb.20:
	ldrb	w11, [x9, #14]
	cbnz	w11, LBB13_23
; %bb.21:
	str	w10, [sp, #68]                  ; 4-byte Folded Spill
	str	x2, [sp, #56]                   ; 8-byte Folded Spill
	ldr	w2, [x9, #16]
	ldrb	w10, [x9, #15]
	cmp	w10, #0
	ccmp	w2, w8, #0, eq
	b.ne	LBB13_23
; %bb.22:
	mov	x20, x1
	stp	w14, w13, [sp, #44]             ; 8-byte Folded Spill
	str	w12, [sp, #52]                  ; 4-byte Folded Spill
	add	x0, x9, #20
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	str	x2, [sp, #72]                   ; 8-byte Folded Spill
	bl	_memchr
	cbz	x0, LBB13_26
LBB13_23:
	mov	w8, #0                          ; =0x0
LBB13_24:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
LBB13_25:
	mov	x0, x8
	ret
LBB13_26:
	mov	w20, w20
	add	x26, x26, #4
	b	LBB13_28
LBB13_27:                               ;   in Loop: Header=BB13_28 Depth=1
	sub	x20, x20, #1
	add	x26, x26, #8
	subs	x21, x21, #1
	b.eq	LBB13_38
LBB13_28:                               ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB13_27
; %bb.29:                               ;   in Loop: Header=BB13_28 Depth=1
	ldur	w8, [x26, #-4]
	ldr	w9, [x22, x8, lsl #2]
	cmp	w9, #13
	b.ne	LBB13_27
; %bb.30:                               ;   in Loop: Header=BB13_28 Depth=1
	ldr	x8, [x25, x8, lsl #3]
	ldr	x9, [x8]
	ldur	x8, [x8, #5]
	cmp	x9, x23
	ccmp	x8, x24, #0, eq
	b.ne	LBB13_27
; %bb.31:                               ;   in Loop: Header=BB13_28 Depth=1
	ldr	w9, [x26]
	ldr	w8, [x22, x9, lsl #2]
	subs	w8, w8, #20
	b.lo	LBB13_23
; %bb.32:                               ;   in Loop: Header=BB13_28 Depth=1
	ldr	x27, [x25, x9, lsl #3]
	ldp	w11, w12, [x27]
	ldr	w13, [x27, #8]
	ldrb	w9, [x27, #12]
	ldrb	w10, [x27, #13]
	stp	w10, w13, [sp, #28]             ; 8-byte Folded Spill
	sub	w10, w10, #3
	stp	w12, w11, [sp, #36]             ; 8-byte Folded Spill
	cmp	w11, w19
	ccmp	w12, #0, #4, lo
	ccmp	w13, #0, #4, ne
	ccmp	w9, #2, #2, ne
	ccmn	w10, #2, #0, ls
	b.lo	LBB13_23
; %bb.33:                               ;   in Loop: Header=BB13_28 Depth=1
	ldrb	w9, [x27, #14]
	cbnz	w9, LBB13_23
; %bb.34:                               ;   in Loop: Header=BB13_28 Depth=1
	ldr	w2, [x27, #16]
	ldrb	w9, [x27, #15]
	cmp	w9, #0
	ccmp	w2, w8, #0, eq
	b.ne	LBB13_23
; %bb.35:                               ;   in Loop: Header=BB13_28 Depth=1
	add	x0, x27, #20
	mov	w1, #0                          ; =0x0
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memchr
	cbnz	x0, LBB13_23
; %bb.36:                               ;   in Loop: Header=BB13_28 Depth=1
	ldp	w8, w10, [sp, #48]              ; 8-byte Folded Reload
	ldp	w9, w11, [sp, #36]              ; 8-byte Folded Reload
	cmp	w10, w11
	ccmp	w8, w9, #0, eq
	ldp	w9, w8, [sp, #28]               ; 8-byte Folded Reload
	ccmp	w28, w8, #0, eq
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	ccmp	w8, w9, #0, eq
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ccmp	w9, w8, #0, eq
	b.ne	LBB13_27
; %bb.37:                               ;   in Loop: Header=BB13_28 Depth=1
	add	x1, x27, #20
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #72]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB13_27
	b	LBB13_23
LBB13_38:
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	ldp	w8, w10, [sp, #48]              ; 8-byte Folded Reload
	stp	w10, w8, [x9]
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	stp	w28, w8, [x9, #8]
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	stp	w8, wzr, [x9, #16]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [x9, #24]
	mov	w8, #1                          ; =0x1
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	stp	w10, wzr, [x9, #32]
	b	LBB13_24
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_match_coverage ; -- Begin function nvm_add_match_coverage
	.globl	_nvm_add_match_coverage
	.p2align	2
_nvm_add_match_coverage:                ; @nvm_add_match_coverage
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB14_38
; %bb.1:
	mov	x19, x0
	ldr	w22, [x0, #368]
	cbz	w22, LBB14_14
; %bb.2:
	ldr	x9, [x19, #360]
	cbz	x9, LBB14_38
; %bb.3:
	ldr	w8, [x19, #392]
	add	x9, x9, #4
	ldr	w10, [x19, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x22
	mov	x13, x8
	b	LBB14_5
LBB14_4:                                ;   in Loop: Header=BB14_5 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB14_13
LBB14_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB14_38
; %bb.6:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB14_38
; %bb.7:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	x7, [x19, #232]
	cbz	x7, LBB14_38
; %bb.8:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	x0, [x19, #240]
	cbz	x0, LBB14_38
; %bb.9:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	x17, [x7, x16, lsl #3]
	cbz	x17, LBB14_38
; %bb.10:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	x7, [x7, x15, lsl #3]
	cbz	x7, LBB14_38
; %bb.11:                               ;   in Loop: Header=BB14_5 Depth=1
	ldr	w16, [x0, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB14_4
; %bb.12:                               ;   in Loop: Header=BB14_5 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB14_4
LBB14_13:
	cmp	w13, w8
	b.ne	LBB14_38
LBB14_14:
	cbz	x6, LBB14_38
; %bb.15:
	sub	w8, w5, #1
	cmp	w8, #1
	b.hi	LBB14_38
; %bb.16:
	cmp	w4, #2
	b.hi	LBB14_38
; %bb.17:
	cbz	w3, LBB14_38
; %bb.18:
	cbz	w2, LBB14_38
; %bb.19:
	ldr	w8, [x19, #272]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	cmp	w1, w8
	b.hs	LBB14_38
; %bb.20:
	mov	x0, x6
	str	x6, [sp, #40]                   ; 8-byte Folded Spill
	stp	w5, w3, [sp, #28]               ; 8-byte Folded Spill
	str	w4, [sp, #12]                   ; 4-byte Folded Spill
	str	w2, [sp, #52]                   ; 4-byte Folded Spill
	str	w1, [sp, #36]                   ; 4-byte Folded Spill
	bl	_strlen
	mov	w8, #-21                        ; =0xffffffeb
	cmp	x0, x8
	b.hi	LBB14_38
; %bb.21:
	mov	x13, x0
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	cbz	w22, LBB14_33
; %bb.22:
	ldr	x8, [x19, #360]
	ldr	x15, [x19, #240]
	add	x25, x8, #4
	mov	x14, #24942                     ; =0x616e
	movk	x14, #28526, lsl #16
	movk	x14, #27950, lsl #32
	movk	x14, #29793, lsl #48
	mov	x16, #24941                     ; =0x616d
	movk	x16, #25460, lsl #16
	movk	x16, #11880, lsl #32
	movk	x16, #12662, lsl #48
	b	LBB14_24
LBB14_23:                               ;   in Loop: Header=BB14_24 Depth=1
	add	x25, x25, #8
	subs	x22, x22, #1
	b.eq	LBB14_33
LBB14_24:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x25, #-4]
	ldr	w9, [x15, x8, lsl #2]
	cmp	w9, #13
	b.ne	LBB14_23
; %bb.25:                               ;   in Loop: Header=BB14_24 Depth=1
	ldr	x9, [x19, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldr	x10, [x8]
	ldur	x8, [x8, #5]
	cmp	x10, x14
	ccmp	x8, x16, #0, eq
	b.ne	LBB14_23
; %bb.26:                               ;   in Loop: Header=BB14_24 Depth=1
	ldr	w10, [x25]
	ldr	w8, [x15, x10, lsl #2]
	subs	w8, w8, #20
	b.lo	LBB14_38
; %bb.27:                               ;   in Loop: Header=BB14_24 Depth=1
	ldr	x26, [x9, x10, lsl #3]
	ldp	w12, w28, [x26]
	ldr	w13, [x26, #8]
	ldrb	w9, [x26, #12]
	ldrb	w20, [x26, #13]
	sub	w10, w20, #3
	ldr	w11, [sp, #24]                  ; 4-byte Folded Reload
	cmp	w12, w11
	ccmp	w28, #0, #4, lo
	ccmp	w13, #0, #4, ne
	ccmp	w9, #2, #2, ne
	ccmn	w10, #2, #0, ls
	b.lo	LBB14_38
; %bb.28:                               ;   in Loop: Header=BB14_24 Depth=1
	ldrb	w9, [x26, #14]
	cbnz	w9, LBB14_38
; %bb.29:                               ;   in Loop: Header=BB14_24 Depth=1
	ldr	w21, [x26, #16]
	ldrb	w9, [x26, #15]
	cmp	w9, #0
	ccmp	w21, w8, #0, eq
	b.ne	LBB14_38
; %bb.30:                               ;   in Loop: Header=BB14_24 Depth=1
	add	x0, x26, #20
	stp	w13, w12, [sp, #16]             ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	mov	x2, x21
	mov	x23, x14
	mov	x24, x15
	mov	x27, x16
	bl	_memchr
	ldp	w1, w17, [sp, #16]              ; 8-byte Folded Reload
	ldr	x13, [sp, #56]                  ; 8-byte Folded Reload
	ldp	w10, w12, [sp, #32]             ; 8-byte Folded Reload
	ldr	w11, [sp, #52]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbnz	x0, LBB14_38
; %bb.31:                               ;   in Loop: Header=BB14_24 Depth=1
	mov	x16, x27
	mov	x15, x24
	mov	x14, x23
	cmp	w12, w17
	ccmp	w11, w28, #0, eq
	ccmp	w10, w1, #0, eq
	ccmp	w9, w20, #0, eq
	ccmp	w21, w13, #0, eq
	b.ne	LBB14_23
; %bb.32:                               ;   in Loop: Header=BB14_24 Depth=1
	add	x1, x26, #20
	mov	x0, x8
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	bl	_memcmp
	mov	x16, x27
	mov	x15, x24
	mov	x14, x23
	ldr	x13, [sp, #56]                  ; 8-byte Folded Reload
	cbnz	w0, LBB14_23
	b	LBB14_38
LBB14_33:
	add	x1, x13, #20
	mov	w0, #1                          ; =0x1
	bl	_calloc
	ldr	x20, [sp, #56]                  ; 8-byte Folded Reload
	ldp	w10, w12, [sp, #32]             ; 8-byte Folded Reload
	ldr	w11, [sp, #52]                  ; 4-byte Folded Reload
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x0, LBB14_38
; %bb.34:
	mov	x21, x0
	strb	w12, [x0]
	lsr	w13, w12, #8
	strb	w13, [x0, #1]
	lsr	w13, w12, #16
	strb	w13, [x0, #2]
	lsr	w12, w12, #24
	strb	w12, [x0, #3]
	strb	w11, [x0, #4]
	lsr	w12, w11, #8
	strb	w12, [x0, #5]
	lsr	w12, w11, #16
	strb	w12, [x0, #6]
	lsr	w11, w11, #24
	strb	w11, [x0, #7]
	strb	w10, [x0, #8]
	lsr	w11, w10, #8
	strb	w11, [x0, #9]
	lsr	w11, w10, #16
	strb	w11, [x0, #10]
	lsr	w10, w10, #24
	strb	w10, [x0, #11]
	strb	w9, [x0, #12]
	strb	w8, [x0, #13]
	strb	w20, [x0, #16]
	lsr	x8, x20, #8
	strb	w8, [x0, #17]
	lsr	x8, x20, #16
	strb	w8, [x0, #18]
	lsr	x8, x20, #24
	strb	w8, [x0, #19]
	add	x0, x0, #20
	mov	x2, x20
	bl	_memcpy
Lloh32:
	adrp	x1, _match_key@PAGE
Lloh33:
	add	x1, x1, _match_key@PAGEOFF
	mov	x0, x19
	mov	w2, #13                         ; =0xd
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB14_37
; %bb.35:
	mov	x22, x0
	add	w2, w20, #20
	mov	x0, x19
	mov	x1, x21
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x21
	bl	_free
	cmn	w20, #1
	b.eq	LBB14_38
; %bb.36:
	mov	x0, x19
	mov	x1, x22
	mov	x2, x20
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	b	_nvm_add_metadata
LBB14_37:
	mov	x0, x21
	bl	_free
LBB14_38:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.loh AdrpAdd	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_affine_use_at      ; -- Begin function nvm_affine_use_at
	.globl	_nvm_affine_use_at
	.p2align	2
_nvm_affine_use_at:                     ; @nvm_affine_use_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB15_34
; %bb.1:
	cbz	x2, LBB15_34
; %bb.2:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w22, [x0, #368]
	cbz	w22, LBB15_32
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB15_33
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x22
	mov	x12, x9
	b	LBB15_6
LBB15_5:                                ;   in Loop: Header=BB15_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB15_14
LBB15_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB15_32
; %bb.7:                                ;   in Loop: Header=BB15_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB15_32
; %bb.8:                                ;   in Loop: Header=BB15_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB15_32
; %bb.9:                                ;   in Loop: Header=BB15_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB15_32
; %bb.10:                               ;   in Loop: Header=BB15_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB15_32
; %bb.11:                               ;   in Loop: Header=BB15_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB15_32
; %bb.12:                               ;   in Loop: Header=BB15_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB15_5
; %bb.13:                               ;   in Loop: Header=BB15_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB15_5
LBB15_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB15_33
; %bb.15:
	cmp	w1, w22
	b.hs	LBB15_33
; %bb.16:
	ldr	x19, [x0, #360]
	add	x8, x19, w1, uxtw #3
	ldr	x23, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #18
	b.ne	LBB15_32
; %bb.17:
	mov	x24, #24942                     ; =0x616e
	movk	x24, #28526, lsl #16
	movk	x24, #24878, lsl #32
	movk	x24, #26214, lsl #48
	mov	x25, #28265                     ; =0x6e69
	movk	x25, #11621, lsl #16
	movk	x25, #29557, lsl #32
	movk	x25, #11877, lsl #48
	ldr	x26, [x0, #232]
	ldr	x9, [x26, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldrh	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	mov	w10, #12662                     ; =0x3176
	ccmp	w9, w10, #0, eq
	b.ne	LBB15_32
; %bb.18:
	mov	x20, x1
	mov	x27, x2
	add	x2, sp, #80
	mov	x28, x0
	mov	x1, x8
	bl	_affine_use_record
	cbz	w0, LBB15_32
; %bb.19:
	mov	w21, w20
	ldp	w9, w8, [sp, #80]
	stp	w8, w9, [sp, #16]               ; 8-byte Folded Spill
	ldr	w9, [sp, #88]
	ldr	w8, [sp, #96]
	stp	w8, w9, [sp, #8]                ; 8-byte Folded Spill
	ldr	w8, [sp, #120]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w20, #12662                     ; =0x3176
	ldr	x8, [sp, #104]
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	x8, x27
	mov	x0, x28
	b	LBB15_22
LBB15_20:                               ;   in Loop: Header=BB15_22 Depth=1
	mov	x8, x27
	mov	x0, x28
LBB15_21:                               ;   in Loop: Header=BB15_22 Depth=1
	sub	x21, x21, #1
	add	x19, x19, #8
	subs	x22, x22, #1
	b.eq	LBB15_35
LBB15_22:                               ; =>This Inner Loop Header: Depth=1
	cbz	x21, LBB15_21
; %bb.23:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #18
	b.ne	LBB15_21
; %bb.24:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	x9, [x26, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldrh	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	ccmp	w9, w20, #0, eq
	b.ne	LBB15_21
; %bb.25:                               ;   in Loop: Header=BB15_22 Depth=1
	add	x2, sp, #32
	mov	x1, x19
	bl	_affine_use_record
	cbz	w0, LBB15_32
; %bb.26:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w8, [sp, #32]
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB15_20
; %bb.27:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w8, [sp, #36]
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB15_20
; %bb.28:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w8, [sp, #40]
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB15_20
; %bb.29:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #8]                    ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB15_20
; %bb.30:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	w8, [sp, #72]
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB15_20
; %bb.31:                               ;   in Loop: Header=BB15_22 Depth=1
	ldr	x1, [sp, #56]
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB15_20
LBB15_32:
	mov	w8, #0                          ; =0x0
LBB15_33:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
LBB15_34:
	mov	x0, x8
	ret
LBB15_35:
	ldp	q0, q1, [sp, #80]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #112]
	str	q0, [x8, #32]
	mov	w8, #1                          ; =0x1
	b	LBB15_33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function affine_use_record
_affine_use_record:                     ; @affine_use_record
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x9, [x0, #240]
	ldr	w8, [x1, #4]
	ldr	w9, [x9, x8, lsl #2]
	subs	w9, w9, #24
	b.lo	LBB16_7
; %bb.1:
	ldr	x10, [x0, #232]
	ldr	x8, [x10, x8, lsl #3]
	ldp	w19, w20, [x8, #16]
	subs	w9, w9, w19
	ccmp	w20, #0, #4, hs
	ccmp	w20, w9, #0, ne
	b.ne	LBB16_7
; %bb.2:
	ldp	w23, w24, [x8]
	ldr	w25, [x8, #8]
	ldrb	w26, [x8, #12]
	ldrb	w27, [x8, #13]
	ldr	w9, [x0, #272]
	sub	w10, w27, #3
	cmp	w23, w9
	ccmp	w24, #0, #4, lo
	ccmp	w25, #0, #4, ne
	ccmp	w26, #2, #2, ne
	ccmn	w10, #2, #0, ls
	b.lo	LBB16_7
; %bb.3:
	ldrb	w9, [x8, #14]
	cbnz	w9, LBB16_7
; %bb.4:
	ldrb	w9, [x8, #15]
	cbnz	w9, LBB16_7
; %bb.5:
	mov	x28, x2
	add	x21, x8, #24
	mov	x0, x21
	mov	w1, #0                          ; =0x0
	mov	x2, x19
	bl	_memchr
	cbnz	x0, LBB16_7
; %bb.6:
	add	x22, x21, x19
	mov	x0, x22
	mov	w1, #0                          ; =0x0
	mov	x2, x20
	bl	_memchr
	cbz	x0, LBB16_9
LBB16_7:
	mov	w0, #0                          ; =0x0
LBB16_8:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB16_9:
	stp	w23, w24, [x28]
	stp	w25, w26, [x28, #8]
	stp	w27, wzr, [x28, #16]
	stp	x21, x22, [x28, #24]
	mov	w0, #1                          ; =0x1
	stp	w19, w20, [x28, #40]
	b	LBB16_8
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_affine_use     ; -- Begin function nvm_add_affine_use
	.globl	_nvm_add_affine_use
	.p2align	2
_nvm_add_affine_use:                    ; @nvm_add_affine_use
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB17_42
; %bb.1:
	ldr	w24, [x0, #368]
	cbz	w24, LBB17_14
; %bb.2:
	ldr	x9, [x0, #360]
	cbz	x9, LBB17_42
; %bb.3:
	ldr	w8, [x0, #392]
	add	x9, x9, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x24
	mov	x13, x8
	b	LBB17_5
LBB17_4:                                ;   in Loop: Header=BB17_5 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB17_13
LBB17_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB17_42
; %bb.6:                                ;   in Loop: Header=BB17_5 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB17_42
; %bb.7:                                ;   in Loop: Header=BB17_5 Depth=1
	ldr	x20, [x0, #232]
	cbz	x20, LBB17_42
; %bb.8:                                ;   in Loop: Header=BB17_5 Depth=1
	ldr	x19, [x0, #240]
	cbz	x19, LBB17_42
; %bb.9:                                ;   in Loop: Header=BB17_5 Depth=1
	ldr	x17, [x20, x16, lsl #3]
	cbz	x17, LBB17_42
; %bb.10:                               ;   in Loop: Header=BB17_5 Depth=1
	ldr	x20, [x20, x15, lsl #3]
	cbz	x20, LBB17_42
; %bb.11:                               ;   in Loop: Header=BB17_5 Depth=1
	ldr	w16, [x19, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB17_4
; %bb.12:                               ;   in Loop: Header=BB17_5 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB17_4
LBB17_13:
	cmp	w13, w8
	b.ne	LBB17_42
LBB17_14:
	cbz	x7, LBB17_42
; %bb.15:
	cbz	x6, LBB17_42
; %bb.16:
	sub	w8, w5, #1
	cmp	w8, #1
	b.hi	LBB17_42
; %bb.17:
	cmp	w4, #2
	b.hi	LBB17_42
; %bb.18:
	cbz	w3, LBB17_42
; %bb.19:
	cbz	w2, LBB17_42
; %bb.20:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB17_42
; %bb.21:
	ldrb	w8, [x7]
	cbz	w8, LBB17_42
; %bb.22:
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x0, x6
	stp	x6, x7, [sp, #16]               ; 16-byte Folded Spill
	mov	x27, x5
	str	w4, [sp, #12]                   ; 4-byte Folded Spill
	str	w3, [sp, #36]                   ; 4-byte Folded Spill
	mov	x28, x2
	mov	x22, x1
	bl	_strlen
	mov	x19, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_strlen
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	mov	w8, #-25                        ; =0xffffffe7
	cmp	x19, x8
	b.hi	LBB17_42
; %bb.23:
	sub	x8, x8, x19
	cmp	x0, x8
	b.hi	LBB17_42
; %bb.24:
	str	x0, [sp]                        ; 8-byte Folded Spill
	cbz	w24, LBB17_37
; %bb.25:
	ldr	x23, [x11, #360]
	ldr	x21, [x11, #240]
	mov	x25, #24942                     ; =0x616e
	movk	x25, #28526, lsl #16
	movk	x25, #24878, lsl #32
	movk	x25, #26214, lsl #48
	mov	x26, #28265                     ; =0x6e69
	movk	x26, #11621, lsl #16
	movk	x26, #29557, lsl #32
	movk	x26, #11877, lsl #48
	mov	w20, #12662                     ; =0x3176
	b	LBB17_28
LBB17_26:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
LBB17_27:                               ;   in Loop: Header=BB17_28 Depth=1
	add	x23, x23, #8
	subs	x24, x24, #1
	b.eq	LBB17_37
LBB17_28:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23]
	ldr	w9, [x21, x8, lsl #2]
	cmp	w9, #18
	b.ne	LBB17_27
; %bb.29:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	x9, [x11, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldp	x9, x10, [x8]
	ldrh	w8, [x8, #16]
	cmp	x9, x25
	ccmp	x10, x26, #0, eq
	ccmp	w8, w20, #0, eq
	b.ne	LBB17_27
; %bb.30:                               ;   in Loop: Header=BB17_28 Depth=1
	add	x2, sp, #48
	mov	x0, x11
	mov	x1, x23
	bl	_affine_use_record
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	cbz	w0, LBB17_42
; %bb.31:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	w12, [sp, #48]
	cmp	w22, w12
	b.ne	LBB17_26
; %bb.32:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	w11, [sp, #52]
	cmp	w28, w11
	b.ne	LBB17_26
; %bb.33:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	w10, [sp, #56]
	cmp	w9, w10
	b.ne	LBB17_26
; %bb.34:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	w9, [sp, #64]
	cmp	w27, w9
	b.ne	LBB17_26
; %bb.35:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	w8, [sp, #88]
	cmp	w8, w19
	b.ne	LBB17_26
; %bb.36:                               ;   in Loop: Header=BB17_28 Depth=1
	ldr	x1, [sp, #72]
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, x19
	bl	_memcmp
	cbnz	w0, LBB17_26
	b	LBB17_42
LBB17_37:
	ldr	x20, [sp]                       ; 8-byte Folded Reload
	add	w8, w19, w20
	add	w23, w8, #24
	mov	w0, #1                          ; =0x1
	mov	x1, x23
	bl	_calloc
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x1, x25, [sp, #16]              ; 16-byte Folded Reload
	ldr	x24, [sp, #40]                  ; 8-byte Folded Reload
	cbz	x0, LBB17_42
; %bb.38:
	mov	x21, x0
	strb	w22, [x0]
	lsr	w10, w22, #8
	strb	w10, [x0, #1]
	lsr	w10, w22, #16
	strb	w10, [x0, #2]
	lsr	w10, w22, #24
	strb	w10, [x0, #3]
	strb	w28, [x0, #4]
	lsr	w10, w28, #8
	strb	w10, [x0, #5]
	lsr	w10, w28, #16
	strb	w10, [x0, #6]
	lsr	w10, w28, #24
	strb	w10, [x0, #7]
	strb	w9, [x0, #8]
	lsr	w10, w9, #8
	strb	w10, [x0, #9]
	lsr	w10, w9, #16
	strb	w10, [x0, #10]
	lsr	w9, w9, #24
	strb	w9, [x0, #11]
	strb	w8, [x0, #12]
	strb	w27, [x0, #13]
	strb	w19, [x0, #16]
	lsr	x8, x19, #8
	strb	w8, [x0, #17]
	lsr	x8, x19, #16
	strb	w8, [x0, #18]
	lsr	x8, x19, #24
	strb	w8, [x0, #19]
	strb	w20, [x0, #20]
	lsr	x8, x20, #8
	strb	w8, [x0, #21]
	lsr	x8, x20, #16
	strb	w8, [x0, #22]
	lsr	x8, x20, #24
	add	x22, x0, #24
	strb	w8, [x0, #23]
	mov	x0, x22
	mov	x2, x19
	bl	_memcpy
	add	x0, x22, x19
	mov	x1, x25
	mov	x2, x20
	bl	_memcpy
Lloh34:
	adrp	x1, _affine_use_key@PAGE
Lloh35:
	add	x1, x1, _affine_use_key@PAGEOFF
	mov	x0, x24
	mov	w2, #18                         ; =0x12
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB17_41
; %bb.39:
	mov	x19, x0
	ldr	x22, [sp, #40]                  ; 8-byte Folded Reload
	mov	x0, x22
	mov	x1, x21
	mov	x2, x23
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x21
	bl	_free
	cmn	w20, #1
	b.eq	LBB17_42
; %bb.40:
	mov	x0, x22
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	b	_nvm_add_metadata
LBB17_41:
	mov	x0, x21
	bl	_free
LBB17_42:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.loh AdrpAdd	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_borrow_place_at
lCPI18_0:
	.byte	0                               ; 0x0
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	3                               ; 0x3
	.byte	4                               ; 0x4
	.byte	5                               ; 0x5
	.byte	7                               ; 0x7
	.byte	14                              ; 0xe
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_borrow_place_at
	.globl	_nvm_borrow_place_at
	.p2align	2
_nvm_borrow_place_at:                   ; @nvm_borrow_place_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB18_30
; %bb.1:
	cbz	x2, LBB18_30
; %bb.2:
	sub	sp, sp, #336
	stp	d9, d8, [sp, #224]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #256]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #272]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #288]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	ldr	w22, [x0, #368]
	cbz	w22, LBB18_28
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB18_29
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x22
	mov	x12, x9
	b	LBB18_6
LBB18_5:                                ;   in Loop: Header=BB18_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB18_14
LBB18_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB18_28
; %bb.7:                                ;   in Loop: Header=BB18_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB18_28
; %bb.8:                                ;   in Loop: Header=BB18_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB18_28
; %bb.9:                                ;   in Loop: Header=BB18_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB18_28
; %bb.10:                               ;   in Loop: Header=BB18_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB18_28
; %bb.11:                               ;   in Loop: Header=BB18_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB18_28
; %bb.12:                               ;   in Loop: Header=BB18_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB18_5
; %bb.13:                               ;   in Loop: Header=BB18_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB18_5
LBB18_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB18_29
; %bb.15:
	cmp	w1, w22
	b.hs	LBB18_29
; %bb.16:
	ldr	x19, [x0, #360]
	add	x8, x19, w1, uxtw #3
	ldr	x23, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #20
	b.ne	LBB18_28
; %bb.17:
	mov	x24, #24942                     ; =0x616e
	movk	x24, #28526, lsl #16
	movk	x24, #25134, lsl #32
	movk	x24, #29295, lsl #48
	mov	x25, #28530                     ; =0x6f72
	movk	x25, #11639, lsl #16
	movk	x25, #27760, lsl #32
	movk	x25, #25441, lsl #48
	mov	w26, #11877                     ; =0x2e65
	movk	w26, #12662, lsl #16
	ldr	x27, [x0, #232]
	ldr	x9, [x27, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldr	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	ccmp	w9, w26, #0, eq
	b.ne	LBB18_28
; %bb.18:
	mov	x20, x1
	mov	x28, x2
	add	x2, sp, #144
	mov	x21, x0
	mov	x1, x8
	bl	_borrow_place_record
	cbz	w0, LBB18_28
; %bb.19:
	mov	w20, w20
	ldp	q1, q0, [sp, #144]
	mov.s	w8, v0[3]
	mov.s	w9, v0[2]
	mov.s	w10, v0[1]
	mov.s	w11, v1[3]
	mov.s	w12, v1[2]
	mov.s	w13, v1[1]
	ldr	d2, [sp, #192]
	mov.s	w14, v2[1]
	ldr	w15, [sp, #200]
	ldr	x16, [sp, #176]
	stp	x16, x15, [sp]                  ; 16-byte Folded Spill
	mov.s	v1[1], w13
	mov.s	v1[2], w12
	mov.s	v1[3], w11
	mov.s	v0[1], w10
	mov.s	v0[2], w9
	mov.s	v0[3], w8
	stp	q1, q0, [sp, #32]               ; 32-byte Folded Spill
	mov.s	v2[1], w14
	mov.s	v2[2], w15
	str	q2, [sp, #16]                   ; 16-byte Folded Spill
Lloh36:
	adrp	x8, lCPI18_0@PAGE
Lloh37:
	ldr	d8, [x8, lCPI18_0@PAGEOFF]
	mov	x8, x28
	mov	x0, x21
	b	LBB18_22
LBB18_20:                               ;   in Loop: Header=BB18_22 Depth=1
	mov	x8, x28
	mov	x0, x21
LBB18_21:                               ;   in Loop: Header=BB18_22 Depth=1
	sub	x20, x20, #1
	add	x19, x19, #8
	subs	x22, x22, #1
	b.eq	LBB18_31
LBB18_22:                               ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB18_21
; %bb.23:                               ;   in Loop: Header=BB18_22 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #20
	b.ne	LBB18_21
; %bb.24:                               ;   in Loop: Header=BB18_22 Depth=1
	ldr	x9, [x27, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldr	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	ccmp	x9, x26, #0, eq
	b.ne	LBB18_21
; %bb.25:                               ;   in Loop: Header=BB18_22 Depth=1
	add	x2, sp, #72
	mov	x1, x19
	bl	_borrow_place_record
	cbz	w0, LBB18_28
; %bb.26:                               ;   in Loop: Header=BB18_22 Depth=1
	add	x8, sp, #72
	add	x8, x8, #56
	ldr	d0, [sp, #120]
	ld1.s	{ v0 }[2], [x8]
	ldur	q1, [sp, #88]
	ldur	q2, [sp, #72]
	ldp	q4, q3, [sp, #32]               ; 32-byte Folded Reload
	cmeq.4s	v2, v4, v2
	cmeq.4s	v1, v3, v1
	uzp1.8h	v1, v2, v1
	ldr	q2, [sp, #16]                   ; 16-byte Folded Reload
	cmeq.4s	v0, v2, v0
	xtn2.8h	v0, v0
	uzp1.16b	v0, v1, v0
	tbl.8b	v0, { v0 }, v8
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	uminv.8b	b0, v0
	fmov	w8, s0
	tbz	w8, #0, LBB18_20
; %bb.27:                               ;   in Loop: Header=BB18_22 Depth=1
	ldr	x1, [sp, #104]
	ldp	x0, x2, [sp]                    ; 16-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB18_20
LBB18_28:
	mov	w8, #0                          ; =0x0
LBB18_29:
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #304]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #288]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #272]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #224]              ; 16-byte Folded Reload
	add	sp, sp, #336
LBB18_30:
	mov	x0, x8
	ret
LBB18_31:
	ldp	q0, q1, [sp, #176]
	stp	q0, q1, [x8, #32]
	ldr	x9, [sp, #208]
	str	x9, [x8, #64]
	ldp	q1, q0, [sp, #144]
	stp	q1, q0, [x8]
	mov	w8, #1                          ; =0x1
	b	LBB18_29
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_entry
_borrow_place_entry:                    ; @borrow_place_entry
	.cfi_startproc
; %bb.0:
	ldr	x9, [x0, #240]
	ldr	w8, [x1]
	ldr	w9, [x9, x8, lsl #2]
	cmp	w9, #20
	b.ne	LBB19_2
; %bb.1:
	ldr	x9, [x0, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldp	x9, x10, [x8]
	ldr	w8, [x8, #16]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #25134, lsl #32
	movk	x11, #29295, lsl #48
	cmp	x9, x11
	mov	x9, #28530                      ; =0x6f72
	movk	x9, #11639, lsl #16
	movk	x9, #27760, lsl #32
	movk	x9, #25441, lsl #48
	ccmp	x10, x9, #0, eq
	mov	w9, #11877                      ; =0x2e65
	movk	w9, #12662, lsl #16
	ccmp	w8, w9, #0, eq
	cset	w0, eq
	ret
LBB19_2:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_record
_borrow_place_record:                   ; @borrow_place_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x9, [x0, #240]
	ldr	w8, [x1, #4]
	ldr	w9, [x9, x8, lsl #2]
	subs	w9, w9, #40
	b.lo	LBB20_8
; %bb.1:
	ldr	x10, [x0, #232]
	ldr	x8, [x10, x8, lsl #3]
	ldp	w19, w20, [x8, #28]
	cmp	w19, #0
	ccmp	w20, #0, #4, ne
	b.eq	LBB20_8
; %bb.2:
	subs	w9, w9, w19
	b.lo	LBB20_8
; %bb.3:
	ldr	w21, [x8, #36]
	subs	w9, w9, w20
	ccmp	w21, w9, #0, hs
	b.ne	LBB20_8
; %bb.4:
	mov	x9, x0
	mov	w0, #0                          ; =0x0
	ldur	q0, [x8, #4]
	cmeq.4s	v0, v0, #0
	umaxv.4s	s0, v0
	fmov	w10, s0
	tbnz	w10, #0, LBB20_9
; %bb.5:
	ldr	w26, [x8]
	ldrb	w27, [x8, #24]
	ldrb	w25, [x8, #25]
	ldr	w9, [x9, #272]
	sub	w10, w27, #3
	sub	w11, w25, #3
	and	w10, w10, #0xff
	cmp	w10, #254
	ccmp	w26, w9, #2, hs
	ccmn	w11, #2, #0, lo
	b.lo	LBB20_9
; %bb.6:
	ldrb	w9, [x8, #26]
	cbnz	w9, LBB20_8
; %bb.7:
	ldrb	w9, [x8, #27]
	cbz	w9, LBB20_10
LBB20_8:
	mov	w0, #0                          ; =0x0
LBB20_9:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB20_10:
	mov	x28, x2
	ldur	q0, [x8, #8]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	add	x22, x8, #40
	ldr	w24, [x8, #4]
	mov	x0, x22
	mov	x1, x19
	bl	_borrow_place_utf8
	cbz	w0, LBB20_9
; %bb.11:
	add	x23, x22, x19
	mov	x0, x23
	mov	x1, x20
	bl	_borrow_place_utf8
	cbz	w0, LBB20_9
; %bb.12:
	add	x0, x23, x20
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x1, x21
	bl	_borrow_place_utf8
	cbz	w0, LBB20_9
; %bb.13:
	and	w8, w27, #0xff
	stp	w26, w24, [x28]
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	stur	q0, [x28, #8]
	stp	w8, w25, [x28, #24]
	stp	x22, x23, [x28, #32]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [x28, #48]
	stp	w19, w20, [x28, #56]
	mov	w0, #1                          ; =0x1
	stp	w21, wzr, [x28, #64]
	b	LBB20_9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_borrow_place
_same_borrow_place:                     ; @same_borrow_place
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.1:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.2:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.3:
	ldr	w8, [x0, #12]
	ldr	w9, [x1, #12]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.4:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.5:
	ldr	w8, [x0, #20]
	ldr	w9, [x1, #20]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.6:
	ldr	w8, [x0, #28]
	ldr	w9, [x1, #28]
	cmp	w8, w9
	b.ne	LBB21_9
; %bb.7:
	ldr	w2, [x0, #56]
	ldr	w8, [x1, #56]
	cmp	w2, w8
	b.ne	LBB21_9
; %bb.8:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #32]
	ldr	x1, [x1, #32]
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB21_9:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_borrow_place   ; -- Begin function nvm_add_borrow_place
	.globl	_nvm_add_borrow_place
	.p2align	2
_nvm_add_borrow_place:                  ; @nvm_add_borrow_place
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB22_28
; %bb.1:
	cbz	x1, LBB22_28
; %bb.2:
	ldr	w27, [x0, #368]
	cbz	w27, LBB22_15
; %bb.3:
	ldr	x9, [x0, #360]
	cbz	x9, LBB22_28
; %bb.4:
	ldr	w8, [x0, #392]
	add	x9, x9, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x27
	mov	x13, x8
	b	LBB22_6
LBB22_5:                                ;   in Loop: Header=BB22_6 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB22_14
LBB22_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB22_28
; %bb.7:                                ;   in Loop: Header=BB22_6 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB22_28
; %bb.8:                                ;   in Loop: Header=BB22_6 Depth=1
	ldr	x3, [x0, #232]
	cbz	x3, LBB22_28
; %bb.9:                                ;   in Loop: Header=BB22_6 Depth=1
	ldr	x2, [x0, #240]
	cbz	x2, LBB22_28
; %bb.10:                               ;   in Loop: Header=BB22_6 Depth=1
	ldr	x17, [x3, x16, lsl #3]
	cbz	x17, LBB22_28
; %bb.11:                               ;   in Loop: Header=BB22_6 Depth=1
	ldr	x3, [x3, x15, lsl #3]
	cbz	x3, LBB22_28
; %bb.12:                               ;   in Loop: Header=BB22_6 Depth=1
	ldr	w16, [x2, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB22_5
; %bb.13:                               ;   in Loop: Header=BB22_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB22_5
LBB22_14:
	cmp	w13, w8
	b.ne	LBB22_28
LBB22_15:
	ldr	w26, [x1]
	ldr	w8, [x0, #272]
	cmp	w26, w8
	b.hs	LBB22_28
; %bb.16:
	ldr	w19, [x1, #4]
	cbz	w19, LBB22_28
; %bb.17:
	ldr	w23, [x1, #8]
	cbz	w23, LBB22_28
; %bb.18:
	ldr	w22, [x1, #12]
	cbz	w22, LBB22_28
; %bb.19:
	ldr	w24, [x1, #16]
	cbz	w24, LBB22_28
; %bb.20:
	ldr	w28, [x1, #24]
	sub	w8, w28, #3
	cmn	w8, #2
	b.lo	LBB22_28
; %bb.21:
	ldr	w25, [x1, #28]
	sub	w8, w25, #3
	cmn	w8, #2
	b.lo	LBB22_28
; %bb.22:
	ldr	x21, [x1, #32]
	cbz	x21, LBB22_28
; %bb.23:
	ldr	x20, [x1, #40]
	cbz	x20, LBB22_28
; %bb.24:
	ldr	x9, [x1, #48]
	cbz	x9, LBB22_28
; %bb.25:
	ldr	w11, [x1, #56]
	cbz	w11, LBB22_28
; %bb.26:
	ldr	w10, [x1, #60]
	cbz	w10, LBB22_28
; %bb.27:
	cmn	w11, #41
	b.ls	LBB22_29
LBB22_28:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB22_29:
	mov	w8, #-41                        ; =0xffffffd7
	sub	w8, w8, w11
	subs	w8, w8, w10
	b.lo	LBB22_28
; %bb.30:
	ldr	w12, [x1, #64]
	str	x12, [sp, #24]                  ; 8-byte Folded Spill
	cmp	w12, w8
	b.hi	LBB22_28
; %bb.31:
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x0, x21
	stp	x9, x1, [sp, #8]                ; 16-byte Folded Spill
	mov	x1, x11
	str	x10, [sp, #32]                  ; 8-byte Folded Spill
	str	x11, [sp]                       ; 8-byte Folded Spill
	bl	_borrow_place_utf8
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	cbz	w0, LBB22_28
; %bb.32:
	mov	x0, x20
	bl	_borrow_place_utf8
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	w0, LBB22_28
; %bb.33:
	mov	x0, x8
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	bl	_borrow_place_utf8
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	cbz	w0, LBB22_28
; %bb.34:
	cbz	w27, LBB22_40
; %bb.35:
	ldr	x9, [x8, #360]
	b	LBB22_37
LBB22_36:                               ;   in Loop: Header=BB22_37 Depth=1
	ldp	x9, x8, [sp, #40]               ; 16-byte Folded Reload
	add	x9, x9, #8
	subs	x27, x27, #1
	b.eq	LBB22_40
LBB22_37:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x8
	mov	x1, x9
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	bl	_borrow_place_entry
	cbz	w0, LBB22_36
; %bb.38:                               ;   in Loop: Header=BB22_37 Depth=1
	add	x2, sp, #56
	ldp	x1, x0, [sp, #40]               ; 16-byte Folded Reload
	bl	_borrow_place_record
	cbz	w0, LBB22_28
; %bb.39:                               ;   in Loop: Header=BB22_37 Depth=1
	add	x1, sp, #56
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_same_borrow_place
	tbz	w0, #0, LBB22_36
	b	LBB22_28
LBB22_40:
	ldr	x27, [sp]                       ; 8-byte Folded Reload
	ldp	x9, x8, [sp, #24]               ; 16-byte Folded Reload
	add	w8, w27, w8
	add	w8, w8, w9
	add	w1, w8, #40
	mov	w0, #1                          ; =0x1
	str	x1, [sp, #40]                   ; 8-byte Folded Spill
	bl	_calloc
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x0, LBB22_28
; %bb.41:
	mov	x12, x27
	mov	x27, x0
	strb	w26, [x0]
	lsr	w10, w26, #8
	strb	w10, [x0, #1]
	lsr	w10, w26, #16
	strb	w10, [x0, #2]
	lsr	w10, w26, #24
	strb	w10, [x0, #3]
	strb	w19, [x0, #4]
	lsr	w10, w19, #8
	strb	w10, [x0, #5]
	lsr	w10, w19, #16
	strb	w10, [x0, #6]
	lsr	w10, w19, #24
	strb	w10, [x0, #7]
	strb	w23, [x0, #8]
	lsr	w10, w23, #8
	strb	w10, [x0, #9]
	lsr	w10, w23, #16
	strb	w10, [x0, #10]
	lsr	w10, w23, #24
	strb	w10, [x0, #11]
	strb	w22, [x0, #12]
	lsr	w10, w22, #8
	strb	w10, [x0, #13]
	lsr	w10, w22, #16
	strb	w10, [x0, #14]
	lsr	w10, w22, #24
	strb	w10, [x0, #15]
	strb	w24, [x0, #16]
	lsr	w10, w24, #8
	strb	w10, [x0, #17]
	lsr	w10, w24, #16
	strb	w10, [x0, #18]
	lsr	w10, w24, #24
	strb	w10, [x0, #19]
	ldr	w9, [x9, #20]
	strb	w9, [x0, #20]
	lsr	w10, w9, #8
	strb	w10, [x0, #21]
	lsr	w10, w9, #16
	strb	w10, [x0, #22]
	lsr	w9, w9, #24
	strb	w9, [x0, #23]
	strb	w28, [x0, #24]
	strb	w25, [x0, #25]
	strb	w12, [x0, #28]
	lsr	w9, w12, #8
	strb	w9, [x0, #29]
	lsr	w9, w12, #16
	strb	w9, [x0, #30]
	lsr	w9, w12, #24
	strb	w9, [x0, #31]
	strb	w11, [x0, #32]
	lsr	w9, w11, #8
	strb	w9, [x0, #33]
	lsr	w9, w11, #16
	strb	w9, [x0, #34]
	lsr	w9, w11, #24
	strb	w9, [x0, #35]
	ldr	x22, [sp, #24]                  ; 8-byte Folded Reload
	strb	w22, [x0, #36]
	lsr	w9, w22, #8
	strb	w9, [x0, #37]
	lsr	w9, w22, #16
	strb	w9, [x0, #38]
	lsr	w9, w22, #24
	add	x25, x0, #40
	strb	w9, [x0, #39]
	mov	x28, x8
	mov	x0, x25
	mov	x1, x21
	mov	x19, x11
	mov	x21, x12
	mov	x2, x12
	bl	_memcpy
	add	x21, x25, x21
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	bl	_memcpy
	add	x0, x21, x19
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, x22
	bl	_memcpy
Lloh38:
	adrp	x1, _borrow_place_key@PAGE
Lloh39:
	add	x1, x1, _borrow_place_key@PAGEOFF
	mov	x0, x28
	mov	w2, #20                         ; =0x14
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB22_44
; %bb.42:
	mov	x19, x0
	ldp	x2, x21, [sp, #40]              ; 16-byte Folded Reload
	mov	x0, x21
	mov	x1, x27
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x27
	bl	_free
	cmn	w20, #1
	b.eq	LBB22_28
; %bb.43:
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #224
	b	_nvm_add_metadata
LBB22_44:
	mov	x0, x27
	bl	_free
	b	LBB22_28
	.loh AdrpAdd	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function borrow_place_utf8
_borrow_place_utf8:                     ; @borrow_place_utf8
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB23_23
; %bb.1:
	mov	x12, #0                         ; =0x0
	add	x9, x0, #2
	add	x10, x0, #3
	b	LBB23_4
LBB23_2:                                ;   in Loop: Header=BB23_4 Depth=1
	cbz	w15, LBB23_25
LBB23_3:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	x12, x11
	cmp	x11, x1
	b.hs	LBB23_23
LBB23_4:                                ; =>This Inner Loop Header: Depth=1
	add	x11, x12, #1
	ldrsb	w8, [x0, x12]
	and	w15, w8, #0xff
	tbz	w8, #31, LBB23_2
; %bb.5:                                ;   in Loop: Header=BB23_4 Depth=1
	sub	w16, w15, #194
	cmp	w16, #30
	b.hs	LBB23_7
; %bb.6:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w13, #128                       ; =0x80
	mov	w17, #31                        ; =0x1f
	mov	w14, #1                         ; =0x1
	b	LBB23_11
LBB23_7:                                ;   in Loop: Header=BB23_4 Depth=1
	and	w8, w15, #0xf0
	cmp	w8, #224
	b.ne	LBB23_9
; %bb.8:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	w13, #2048                      ; =0x800
	mov	w8, #1                          ; =0x1
	mov	w17, #15                        ; =0xf
	mov	w14, #2                         ; =0x2
	b	LBB23_11
LBB23_9:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	w8, #0                          ; =0x0
	sub	w13, w15, #240
	cmp	w13, #4
	b.hi	LBB23_24
; %bb.10:                               ;   in Loop: Header=BB23_4 Depth=1
	mov	w13, #65536                     ; =0x10000
	mov	w17, #7                         ; =0x7
	mov	w14, #3                         ; =0x3
LBB23_11:                               ;   in Loop: Header=BB23_4 Depth=1
	sub	x2, x1, x11
	cmp	x2, x14
	b.lo	LBB23_25
; %bb.12:                               ;   in Loop: Header=BB23_4 Depth=1
	ldrb	w3, [x0, x11]
	and	w2, w3, #0xc0
	cmp	w2, #128
	b.ne	LBB23_25
; %bb.13:                               ;   in Loop: Header=BB23_4 Depth=1
	and	w15, w17, w15
	lsl	w17, w15, #6
	mov	x2, x17
	bfxil	w2, w3, #0, #6
	cmp	w16, #30
	b.hs	LBB23_15
; %bb.14:                               ;   in Loop: Header=BB23_4 Depth=1
	mov	x12, x2
	b	LBB23_20
LBB23_15:                               ;   in Loop: Header=BB23_4 Depth=1
	ldrb	w16, [x9, x12]
	and	w15, w16, #0xc0
	cmp	w15, #128
	b.ne	LBB23_25
; %bb.16:                               ;   in Loop: Header=BB23_4 Depth=1
	lsl	w17, w2, #6
	mov	x15, x17
	bfxil	w15, w16, #0, #6
	tbz	w8, #0, LBB23_18
; %bb.17:                               ;   in Loop: Header=BB23_4 Depth=1
	mov	x12, x15
	mov	x15, x2
	b	LBB23_20
LBB23_18:                               ;   in Loop: Header=BB23_4 Depth=1
	ldrb	w8, [x10, x12]
	and	w12, w8, #0xc0
	cmp	w12, #128
	b.ne	LBB23_25
; %bb.19:                               ;   in Loop: Header=BB23_4 Depth=1
	lsl	w17, w15, #6
	mov	x12, x17
	bfxil	w12, w8, #0, #6
LBB23_20:                               ;   in Loop: Header=BB23_4 Depth=1
	mov	w8, #0                          ; =0x0
	cmp	w12, w13
	lsr	w12, w17, #16
	ccmp	w12, #16, #2, hs
	b.hi	LBB23_24
; %bb.21:                               ;   in Loop: Header=BB23_4 Depth=1
	and	w12, w15, #0x7fe0
	cmp	w12, #864
	b.eq	LBB23_24
; %bb.22:                               ;   in Loop: Header=BB23_4 Depth=1
	add	x11, x11, x14
	b	LBB23_3
LBB23_23:
	mov	w8, #1                          ; =0x1
LBB23_24:
	mov	x0, x8
	ret
LBB23_25:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_field_read_at      ; -- Begin function nvm_field_read_at
	.globl	_nvm_field_read_at
	.p2align	2
_nvm_field_read_at:                     ; @nvm_field_read_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB24_34
; %bb.1:
	cbz	x2, LBB24_34
; %bb.2:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w22, [x0, #368]
	cbz	w22, LBB24_32
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB24_33
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x22
	mov	x12, x9
	b	LBB24_6
LBB24_5:                                ;   in Loop: Header=BB24_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB24_14
LBB24_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB24_32
; %bb.7:                                ;   in Loop: Header=BB24_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB24_32
; %bb.8:                                ;   in Loop: Header=BB24_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB24_32
; %bb.9:                                ;   in Loop: Header=BB24_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB24_32
; %bb.10:                               ;   in Loop: Header=BB24_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB24_32
; %bb.11:                               ;   in Loop: Header=BB24_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB24_32
; %bb.12:                               ;   in Loop: Header=BB24_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB24_5
; %bb.13:                               ;   in Loop: Header=BB24_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB24_5
LBB24_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB24_33
; %bb.15:
	cmp	w1, w22
	b.hs	LBB24_33
; %bb.16:
	ldr	x19, [x0, #360]
	add	x8, x19, w1, uxtw #3
	ldr	x23, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #18
	b.ne	LBB24_32
; %bb.17:
	mov	x24, #24942                     ; =0x616e
	movk	x24, #28526, lsl #16
	movk	x24, #26158, lsl #32
	movk	x24, #25961, lsl #48
	mov	x25, #25708                     ; =0x646c
	movk	x25, #29229, lsl #16
	movk	x25, #24933, lsl #32
	movk	x25, #11876, lsl #48
	ldr	x26, [x0, #232]
	ldr	x9, [x26, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldrh	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	mov	w10, #12662                     ; =0x3176
	ccmp	w9, w10, #0, eq
	b.ne	LBB24_32
; %bb.18:
	mov	x20, x1
	mov	x27, x2
	add	x2, sp, #104
	mov	x28, x0
	mov	x1, x8
	bl	_field_read_record
	cbz	w0, LBB24_32
; %bb.19:
	mov	w21, w20
	ldp	w9, w8, [sp, #104]
	stp	w8, w9, [sp, #24]               ; 8-byte Folded Spill
	ldr	w9, [sp, #112]
	ldr	w8, [sp, #120]
	stp	w8, w9, [sp, #16]               ; 8-byte Folded Spill
	ldr	w8, [sp, #152]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w20, #12662                     ; =0x3176
	ldr	x8, [sp, #128]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x27
	mov	x0, x28
	b	LBB24_22
LBB24_20:                               ;   in Loop: Header=BB24_22 Depth=1
	mov	x8, x27
	mov	x0, x28
LBB24_21:                               ;   in Loop: Header=BB24_22 Depth=1
	sub	x21, x21, #1
	add	x19, x19, #8
	subs	x22, x22, #1
	b.eq	LBB24_35
LBB24_22:                               ; =>This Inner Loop Header: Depth=1
	cbz	x21, LBB24_21
; %bb.23:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #18
	b.ne	LBB24_21
; %bb.24:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	x9, [x26, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldrh	w9, [x9, #16]
	cmp	x10, x24
	ccmp	x11, x25, #0, eq
	ccmp	w9, w20, #0, eq
	b.ne	LBB24_21
; %bb.25:                               ;   in Loop: Header=BB24_22 Depth=1
	add	x2, sp, #40
	mov	x1, x19
	bl	_field_read_record
	cbz	w0, LBB24_32
; %bb.26:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w8, [sp, #40]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB24_20
; %bb.27:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB24_20
; %bb.28:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB24_20
; %bb.29:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB24_20
; %bb.30:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB24_20
; %bb.31:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	x1, [sp, #64]
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB24_20
LBB24_32:
	mov	w8, #0                          ; =0x0
LBB24_33:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
LBB24_34:
	mov	x0, x8
	ret
LBB24_35:
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #120]
	stp	q0, q1, [x8]
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	stp	q0, q1, [x8, #32]
	mov	w8, #1                          ; =0x1
	b	LBB24_33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_read_entry
_field_read_entry:                      ; @field_read_entry
	.cfi_startproc
; %bb.0:
	ldr	x9, [x0, #240]
	ldr	w8, [x1]
	ldr	w9, [x9, x8, lsl #2]
	cmp	w9, #18
	b.ne	LBB25_2
; %bb.1:
	ldr	x9, [x0, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldp	x9, x10, [x8]
	ldrh	w8, [x8, #16]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #26158, lsl #32
	movk	x11, #25961, lsl #48
	cmp	x9, x11
	mov	x9, #25708                      ; =0x646c
	movk	x9, #29229, lsl #16
	movk	x9, #24933, lsl #32
	movk	x9, #11876, lsl #48
	ccmp	x10, x9, #0, eq
	mov	w9, #12662                      ; =0x3176
	ccmp	w8, w9, #0, eq
	cset	w0, eq
	ret
LBB25_2:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_read_record
_field_read_record:                     ; @field_read_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x9, [x0, #240]
	ldr	w8, [x1, #4]
	ldr	w9, [x9, x8, lsl #2]
	subs	w9, w9, #28
	b.lo	LBB26_12
; %bb.1:
	ldr	x10, [x0, #232]
	ldr	x8, [x10, x8, lsl #3]
	ldp	w19, w20, [x8, #16]
	cmp	w19, #0
	ccmp	w20, #0, #4, ne
	b.eq	LBB26_12
; %bb.2:
	subs	w9, w9, w19
	b.lo	LBB26_12
; %bb.3:
	ldr	w21, [x8, #24]
	subs	w9, w9, w20
	ccmp	w21, w9, #0, hs
	b.ne	LBB26_12
; %bb.4:
	ldp	w25, w26, [x8]
	ldr	w27, [x8, #8]
	ldrb	w28, [x8, #12]
	ldrb	w24, [x8, #13]
	ldr	w9, [x0, #272]
	sub	w10, w28, #4
	sub	w11, w24, #3
	cmp	w25, w9
	ccmp	w26, #0, #4, lo
	ccmp	w27, #0, #4, ne
	ccmn	w10, #3, #0, ne
	ccmn	w11, #2, #0, hs
	b.lo	LBB26_12
; %bb.5:
	ldrb	w9, [x8, #14]
	cbnz	w9, LBB26_12
; %bb.6:
	ldrb	w9, [x8, #15]
	cmp	w9, #0
	ccmp	w21, #0, #4, eq
	b.eq	LBB26_12
; %bb.7:
	add	x22, x8, #28
	add	x23, x22, x19
	add	x9, x23, x20
	ldrb	w8, [x9]
	cmp	w8, #46
	b.ne	LBB26_12
; %bb.8:
	stp	x2, x9, [sp]                    ; 16-byte Folded Spill
	mov	x0, x22
	mov	x1, x19
	bl	_borrow_place_utf8
	cbz	w0, LBB26_13
; %bb.9:
	mov	x0, x23
	mov	x1, x20
	bl	_borrow_place_utf8
	cbz	w0, LBB26_13
; %bb.10:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x1, x21
	bl	_borrow_place_utf8
	cbz	w0, LBB26_13
; %bb.11:
	ldp	x8, x9, [sp]                    ; 16-byte Folded Reload
	stp	w25, w26, [x8]
	stp	w27, w28, [x8, #8]
	stp	w24, wzr, [x8, #16]
	stp	x22, x23, [x8, #24]
	str	x9, [x8, #40]
	stp	w19, w20, [x8, #48]
	mov	w0, #1                          ; =0x1
	stp	w21, wzr, [x8, #56]
	b	LBB26_13
LBB26_12:
	mov	w0, #0                          ; =0x0
LBB26_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_field_read
_same_field_read:                       ; @same_field_read
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB27_6
; %bb.1:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB27_6
; %bb.2:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB27_6
; %bb.3:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB27_6
; %bb.4:
	ldr	w2, [x0, #48]
	ldr	w8, [x1, #48]
	cmp	w2, w8
	b.ne	LBB27_6
; %bb.5:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #24]
	ldr	x1, [x1, #24]
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB27_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_field_read     ; -- Begin function nvm_add_field_read
	.globl	_nvm_add_field_read
	.p2align	2
_nvm_add_field_read:                    ; @nvm_add_field_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB28_45
; %bb.1:
	cbz	x1, LBB28_45
; %bb.2:
	ldr	w28, [x0, #368]
	cbz	w28, LBB28_15
; %bb.3:
	ldr	x9, [x0, #360]
	cbz	x9, LBB28_45
; %bb.4:
	ldr	w8, [x0, #392]
	add	x9, x9, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x28
	mov	x13, x8
	b	LBB28_6
LBB28_5:                                ;   in Loop: Header=BB28_6 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB28_14
LBB28_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB28_45
; %bb.7:                                ;   in Loop: Header=BB28_6 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB28_45
; %bb.8:                                ;   in Loop: Header=BB28_6 Depth=1
	ldr	x3, [x0, #232]
	cbz	x3, LBB28_45
; %bb.9:                                ;   in Loop: Header=BB28_6 Depth=1
	ldr	x2, [x0, #240]
	cbz	x2, LBB28_45
; %bb.10:                               ;   in Loop: Header=BB28_6 Depth=1
	ldr	x17, [x3, x16, lsl #3]
	cbz	x17, LBB28_45
; %bb.11:                               ;   in Loop: Header=BB28_6 Depth=1
	ldr	x3, [x3, x15, lsl #3]
	cbz	x3, LBB28_45
; %bb.12:                               ;   in Loop: Header=BB28_6 Depth=1
	ldr	w16, [x2, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB28_5
; %bb.13:                               ;   in Loop: Header=BB28_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB28_5
LBB28_14:
	cmp	w13, w8
	b.ne	LBB28_45
LBB28_15:
	ldr	w22, [x1]
	ldr	w8, [x0, #272]
	cmp	w22, w8
	b.hs	LBB28_45
; %bb.16:
	ldr	w24, [x1, #4]
	cbz	w24, LBB28_45
; %bb.17:
	ldr	w25, [x1, #8]
	cbz	w25, LBB28_45
; %bb.18:
	ldr	w26, [x1, #12]
	sub	w8, w26, #4
	cmn	w8, #3
	b.lo	LBB28_45
; %bb.19:
	ldr	w27, [x1, #16]
	sub	w8, w27, #3
	cmn	w8, #2
	b.lo	LBB28_45
; %bb.20:
	ldr	x21, [x1, #24]
	cbz	x21, LBB28_45
; %bb.21:
	ldr	x20, [x1, #32]
	cbz	x20, LBB28_45
; %bb.22:
	ldr	x19, [x1, #40]
	cbz	x19, LBB28_45
; %bb.23:
	ldr	w23, [x1, #48]
	cbz	w23, LBB28_45
; %bb.24:
	ldr	w9, [x1, #52]
	cbz	w9, LBB28_45
; %bb.25:
	ldr	w10, [x1, #56]
	cbz	w10, LBB28_45
; %bb.26:
	cmn	w23, #29
	b.hi	LBB28_45
; %bb.27:
	ldrb	w8, [x19]
	cmp	w8, #46
	b.ne	LBB28_45
; %bb.28:
	mov	w8, #-29                        ; =0xffffffe3
	sub	w8, w8, w23
	subs	w8, w8, w9
	b.lo	LBB28_45
; %bb.29:
	cmp	w10, w8
	b.hi	LBB28_45
; %bb.30:
	stp	x9, x0, [sp, #32]               ; 16-byte Folded Spill
	mov	x0, x21
	stp	x10, x1, [sp, #16]              ; 16-byte Folded Spill
	mov	x1, x23
	bl	_borrow_place_utf8
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	cbz	w0, LBB28_45
; %bb.31:
	mov	x0, x20
	bl	_borrow_place_utf8
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	cbz	w0, LBB28_45
; %bb.32:
	mov	x0, x19
	bl	_borrow_place_utf8
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbz	w0, LBB28_45
; %bb.33:
	str	x23, [sp]                       ; 8-byte Folded Spill
	cbz	w28, LBB28_40
; %bb.34:
	ldr	x23, [x8, #360]
	b	LBB28_36
LBB28_35:                               ;   in Loop: Header=BB28_36 Depth=1
	add	x23, x23, #8
	subs	x28, x28, #1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	b.eq	LBB28_40
LBB28_36:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x8
	mov	x1, x23
	bl	_field_read_entry
	cbz	w0, LBB28_35
; %bb.37:                               ;   in Loop: Header=BB28_36 Depth=1
	add	x2, sp, #48
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	str	x23, [sp, #8]                   ; 8-byte Folded Spill
	mov	x1, x23
	bl	_field_read_record
	cbz	w0, LBB28_45
; %bb.38:                               ;   in Loop: Header=BB28_36 Depth=1
	add	x1, sp, #48
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	bl	_same_field_read
	tbnz	w0, #0, LBB28_45
; %bb.39:                               ;   in Loop: Header=BB28_36 Depth=1
	ldr	x23, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB28_35
LBB28_40:
	ldr	x23, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	add	w8, w8, w23
	ldr	x28, [sp, #16]                  ; 8-byte Folded Reload
	add	w8, w8, w28
	add	w1, w8, #28
	mov	w0, #1                          ; =0x1
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	bl	_calloc
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x0, LBB28_45
; %bb.41:
	mov	x11, x28
	mov	x10, x23
	mov	x28, x0
	strb	w22, [x0]
	lsr	w9, w22, #8
	strb	w9, [x0, #1]
	lsr	w9, w22, #16
	strb	w9, [x0, #2]
	lsr	w9, w22, #24
	strb	w9, [x0, #3]
	strb	w24, [x0, #4]
	lsr	w9, w24, #8
	strb	w9, [x0, #5]
	lsr	w9, w24, #16
	strb	w9, [x0, #6]
	lsr	w9, w24, #24
	strb	w9, [x0, #7]
	strb	w25, [x0, #8]
	lsr	w9, w25, #8
	strb	w9, [x0, #9]
	lsr	w9, w25, #16
	strb	w9, [x0, #10]
	lsr	w9, w25, #24
	strb	w9, [x0, #11]
	strb	w26, [x0, #12]
	strb	w27, [x0, #13]
	ldr	x23, [sp]                       ; 8-byte Folded Reload
	strb	w23, [x0, #16]
	lsr	w9, w23, #8
	strb	w9, [x0, #17]
	lsr	w9, w23, #16
	strb	w9, [x0, #18]
	lsr	w9, w23, #24
	strb	w9, [x0, #19]
	strb	w10, [x0, #20]
	lsr	w9, w10, #8
	strb	w9, [x0, #21]
	lsr	w9, w10, #16
	strb	w9, [x0, #22]
	lsr	w9, w10, #24
	strb	w9, [x0, #23]
	strb	w11, [x0, #24]
	lsr	w9, w11, #8
	strb	w9, [x0, #25]
	lsr	w9, w11, #16
	strb	w9, [x0, #26]
	lsr	w9, w11, #24
	add	x22, x0, #28
	strb	w9, [x0, #27]
	mov	x26, x8
	mov	x0, x22
	mov	x1, x21
	mov	x24, x10
	mov	x25, x11
	mov	x2, x23
	bl	_memcpy
	add	x21, x22, x23
	mov	x0, x21
	mov	x1, x20
	mov	x2, x24
	bl	_memcpy
	add	x0, x21, x24
	mov	x1, x19
	mov	x2, x25
	bl	_memcpy
Lloh40:
	adrp	x1, _field_read_key@PAGE
Lloh41:
	add	x1, x1, _field_read_key@PAGEOFF
	mov	x0, x26
	mov	w2, #18                         ; =0x12
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB28_44
; %bb.42:
	mov	x19, x0
	ldr	x25, [sp, #40]                  ; 8-byte Folded Reload
	mov	x0, x25
	mov	x1, x28
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x28
	bl	_free
	cmn	w20, #1
	b.eq	LBB28_45
; %bb.43:
	mov	x0, x25
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	b	_nvm_add_metadata
LBB28_44:
	mov	x0, x28
	bl	_free
LBB28_45:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_field_write_at     ; -- Begin function nvm_field_write_at
	.globl	_nvm_field_write_at
	.p2align	2
_nvm_field_write_at:                    ; @nvm_field_write_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB29_34
; %bb.1:
	cbz	x2, LBB29_34
; %bb.2:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w22, [x0, #368]
	cbz	w22, LBB29_32
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB29_33
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x22
	mov	x12, x9
	b	LBB29_6
LBB29_5:                                ;   in Loop: Header=BB29_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB29_14
LBB29_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB29_32
; %bb.7:                                ;   in Loop: Header=BB29_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB29_32
; %bb.8:                                ;   in Loop: Header=BB29_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB29_32
; %bb.9:                                ;   in Loop: Header=BB29_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB29_32
; %bb.10:                               ;   in Loop: Header=BB29_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB29_32
; %bb.11:                               ;   in Loop: Header=BB29_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB29_32
; %bb.12:                               ;   in Loop: Header=BB29_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB29_5
; %bb.13:                               ;   in Loop: Header=BB29_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB29_5
LBB29_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB29_33
; %bb.15:
	cmp	w1, w22
	b.hs	LBB29_33
; %bb.16:
	ldr	x19, [x0, #360]
	add	x8, x19, w1, uxtw #3
	ldr	x23, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #19
	b.ne	LBB29_32
; %bb.17:
	mov	x24, #25708                     ; =0x646c
	movk	x24, #30509, lsl #16
	movk	x24, #26994, lsl #32
	movk	x24, #25972, lsl #48
	mov	x25, #24942                     ; =0x616e
	movk	x25, #28526, lsl #16
	movk	x25, #26158, lsl #32
	movk	x25, #25961, lsl #48
	mov	x26, #29303                     ; =0x7277
	movk	x26, #29801, lsl #16
	movk	x26, #11877, lsl #32
	movk	x26, #12662, lsl #48
	ldr	x27, [x0, #232]
	ldr	x9, [x27, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldur	x9, [x9, #11]
	cmp	x10, x25
	ccmp	x11, x24, #0, eq
	ccmp	x9, x26, #0, eq
	b.ne	LBB29_32
; %bb.18:
	mov	x20, x1
	mov	x28, x2
	add	x2, sp, #104
	mov	x21, x0
	mov	x1, x8
	bl	_field_write_record
	cbz	w0, LBB29_32
; %bb.19:
	mov	w20, w20
	ldp	w9, w8, [sp, #104]
	stp	w8, w9, [sp, #24]               ; 8-byte Folded Spill
	ldr	w9, [sp, #112]
	ldr	w8, [sp, #120]
	stp	w8, w9, [sp, #16]               ; 8-byte Folded Spill
	ldr	w8, [sp, #152]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #128]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x28
	mov	x0, x21
	b	LBB29_22
LBB29_20:                               ;   in Loop: Header=BB29_22 Depth=1
	mov	x8, x28
	mov	x0, x21
LBB29_21:                               ;   in Loop: Header=BB29_22 Depth=1
	sub	x20, x20, #1
	add	x19, x19, #8
	subs	x22, x22, #1
	b.eq	LBB29_35
LBB29_22:                               ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB29_21
; %bb.23:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x23, x9, lsl #2]
	cmp	w10, #19
	b.ne	LBB29_21
; %bb.24:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	x9, [x27, x9, lsl #3]
	ldp	x10, x11, [x9]
	ldur	x9, [x9, #11]
	cmp	x10, x25
	ccmp	x11, x24, #0, eq
	ccmp	x9, x26, #0, eq
	b.ne	LBB29_21
; %bb.25:                               ;   in Loop: Header=BB29_22 Depth=1
	add	x2, sp, #40
	mov	x1, x19
	bl	_field_write_record
	cbz	w0, LBB29_32
; %bb.26:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w8, [sp, #40]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB29_20
; %bb.27:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB29_20
; %bb.28:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB29_20
; %bb.29:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #16]                   ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB29_20
; %bb.30:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB29_20
; %bb.31:                               ;   in Loop: Header=BB29_22 Depth=1
	ldr	x1, [sp, #64]
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB29_20
LBB29_32:
	mov	w8, #0                          ; =0x0
LBB29_33:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
LBB29_34:
	mov	x0, x8
	ret
LBB29_35:
	ldur	q0, [sp, #104]
	ldur	q1, [sp, #120]
	stp	q0, q1, [x8]
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	stp	q0, q1, [x8, #32]
	mov	w8, #1                          ; =0x1
	b	LBB29_33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_write_entry
_field_write_entry:                     ; @field_write_entry
	.cfi_startproc
; %bb.0:
	ldr	x9, [x0, #240]
	ldr	w8, [x1]
	ldr	w9, [x9, x8, lsl #2]
	cmp	w9, #19
	b.ne	LBB30_2
; %bb.1:
	ldr	x9, [x0, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldp	x9, x10, [x8]
	ldur	x8, [x8, #11]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #26158, lsl #32
	movk	x11, #25961, lsl #48
	cmp	x9, x11
	mov	x9, #25708                      ; =0x646c
	movk	x9, #30509, lsl #16
	movk	x9, #26994, lsl #32
	movk	x9, #25972, lsl #48
	ccmp	x10, x9, #0, eq
	mov	x9, #29303                      ; =0x7277
	movk	x9, #29801, lsl #16
	movk	x9, #11877, lsl #32
	movk	x9, #12662, lsl #48
	ccmp	x8, x9, #0, eq
	cset	w0, eq
	ret
LBB30_2:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function field_write_record
_field_write_record:                    ; @field_write_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x9, [x0, #240]
	ldr	w8, [x1, #4]
	ldr	w9, [x9, x8, lsl #2]
	subs	w9, w9, #28
	b.lo	LBB31_12
; %bb.1:
	ldr	x10, [x0, #232]
	ldr	x8, [x10, x8, lsl #3]
	ldp	w19, w20, [x8, #16]
	cmp	w19, #0
	ccmp	w20, #0, #4, ne
	b.eq	LBB31_12
; %bb.2:
	subs	w9, w9, w19
	b.lo	LBB31_12
; %bb.3:
	ldr	w21, [x8, #24]
	subs	w9, w9, w20
	ccmp	w21, w9, #0, hs
	b.ne	LBB31_12
; %bb.4:
	ldp	w27, w28, [x8]
	ldr	w25, [x8, #8]
	ldrb	w9, [x8, #12]
	ldrb	w26, [x8, #13]
	ldr	w10, [x0, #272]
	sub	w11, w26, #3
	cmp	w27, w10
	ccmp	w28, #0, #4, lo
	ccmp	w25, #0, #4, ne
	ccmp	w9, #1, #0, ne
	ccmn	w11, #2, #0, eq
	b.lo	LBB31_12
; %bb.5:
	ldrb	w9, [x8, #14]
	cbnz	w9, LBB31_12
; %bb.6:
	ldrb	w9, [x8, #15]
	cmp	w9, #0
	ccmp	w21, #0, #4, eq
	b.eq	LBB31_12
; %bb.7:
	add	x22, x8, #28
	add	x23, x22, x19
	add	x24, x23, x20
	ldrb	w8, [x24]
	cmp	w8, #46
	b.ne	LBB31_12
; %bb.8:
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	x0, x22
	mov	x1, x19
	bl	_borrow_place_utf8
	cbz	w0, LBB31_13
; %bb.9:
	mov	x0, x23
	mov	x1, x20
	bl	_borrow_place_utf8
	cbz	w0, LBB31_13
; %bb.10:
	mov	x0, x24
	mov	x1, x21
	bl	_borrow_place_utf8
	cbz	w0, LBB31_13
; %bb.11:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stp	w27, w28, [x8]
	mov	w0, #1                          ; =0x1
	stp	w25, w0, [x8, #8]
	stp	w26, wzr, [x8, #16]
	stp	x22, x23, [x8, #24]
	str	x24, [x8, #40]
	stp	w19, w20, [x8, #48]
	stp	w21, wzr, [x8, #56]
	b	LBB31_13
LBB31_12:
	mov	w0, #0                          ; =0x0
LBB31_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same_field_write
_same_field_write:                      ; @same_field_write
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0]
	ldr	w9, [x1]
	cmp	w8, w9
	b.ne	LBB32_6
; %bb.1:
	ldr	w8, [x0, #4]
	ldr	w9, [x1, #4]
	cmp	w8, w9
	b.ne	LBB32_6
; %bb.2:
	ldr	w8, [x0, #8]
	ldr	w9, [x1, #8]
	cmp	w8, w9
	b.ne	LBB32_6
; %bb.3:
	ldr	w8, [x0, #16]
	ldr	w9, [x1, #16]
	cmp	w8, w9
	b.ne	LBB32_6
; %bb.4:
	ldr	w2, [x0, #48]
	ldr	w8, [x1, #48]
	cmp	w2, w8
	b.ne	LBB32_6
; %bb.5:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #24]
	ldr	x1, [x1, #24]
	bl	_memcmp
	cmp	w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB32_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_field_write    ; -- Begin function nvm_add_field_write
	.globl	_nvm_add_field_write
	.p2align	2
_nvm_add_field_write:                   ; @nvm_add_field_write
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB33_44
; %bb.1:
	cbz	x1, LBB33_44
; %bb.2:
	ldr	w28, [x0, #368]
	cbz	w28, LBB33_15
; %bb.3:
	ldr	x9, [x0, #360]
	cbz	x9, LBB33_44
; %bb.4:
	ldr	w8, [x0, #392]
	add	x9, x9, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x28
	mov	x13, x8
	b	LBB33_6
LBB33_5:                                ;   in Loop: Header=BB33_6 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB33_14
LBB33_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB33_44
; %bb.7:                                ;   in Loop: Header=BB33_6 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB33_44
; %bb.8:                                ;   in Loop: Header=BB33_6 Depth=1
	ldr	x3, [x0, #232]
	cbz	x3, LBB33_44
; %bb.9:                                ;   in Loop: Header=BB33_6 Depth=1
	ldr	x2, [x0, #240]
	cbz	x2, LBB33_44
; %bb.10:                               ;   in Loop: Header=BB33_6 Depth=1
	ldr	x17, [x3, x16, lsl #3]
	cbz	x17, LBB33_44
; %bb.11:                               ;   in Loop: Header=BB33_6 Depth=1
	ldr	x3, [x3, x15, lsl #3]
	cbz	x3, LBB33_44
; %bb.12:                               ;   in Loop: Header=BB33_6 Depth=1
	ldr	w16, [x2, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB33_5
; %bb.13:                               ;   in Loop: Header=BB33_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB33_5
LBB33_14:
	cmp	w13, w8
	b.ne	LBB33_44
LBB33_15:
	ldr	w24, [x1]
	ldr	w8, [x0, #272]
	cmp	w24, w8
	b.hs	LBB33_44
; %bb.16:
	ldr	w26, [x1, #4]
	cbz	w26, LBB33_44
; %bb.17:
	ldr	w25, [x1, #8]
	cbz	w25, LBB33_44
; %bb.18:
	ldr	w8, [x1, #12]
	cmp	w8, #1
	b.ne	LBB33_44
; %bb.19:
	ldr	w22, [x1, #16]
	sub	w8, w22, #3
	cmn	w8, #2
	b.lo	LBB33_44
; %bb.20:
	ldr	x21, [x1, #24]
	cbz	x21, LBB33_44
; %bb.21:
	ldr	x20, [x1, #32]
	cbz	x20, LBB33_44
; %bb.22:
	ldr	x19, [x1, #40]
	cbz	x19, LBB33_44
; %bb.23:
	ldr	w23, [x1, #48]
	cbz	w23, LBB33_44
; %bb.24:
	ldr	w9, [x1, #52]
	cbz	w9, LBB33_44
; %bb.25:
	ldr	w10, [x1, #56]
	cbz	w10, LBB33_44
; %bb.26:
	cmn	w23, #29
	b.hi	LBB33_44
; %bb.27:
	ldrb	w8, [x19]
	cmp	w8, #46
	b.ne	LBB33_44
; %bb.28:
	mov	w8, #-29                        ; =0xffffffe3
	sub	w8, w8, w23
	subs	w8, w8, w9
	b.lo	LBB33_44
; %bb.29:
	cmp	w10, w8
	b.hi	LBB33_44
; %bb.30:
	stp	x9, x0, [sp, #16]               ; 16-byte Folded Spill
	mov	x0, x21
	stp	x10, x1, [sp]                   ; 16-byte Folded Spill
	mov	x1, x23
	bl	_borrow_place_utf8
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	cbz	w0, LBB33_44
; %bb.31:
	mov	x0, x20
	bl	_borrow_place_utf8
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	cbz	w0, LBB33_44
; %bb.32:
	mov	x0, x19
	bl	_borrow_place_utf8
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cbz	w0, LBB33_44
; %bb.33:
	cbz	w28, LBB33_39
; %bb.34:
	ldr	x27, [x8, #360]
	b	LBB33_36
LBB33_35:                               ;   in Loop: Header=BB33_36 Depth=1
	add	x27, x27, #8
	subs	x28, x28, #1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	b.eq	LBB33_39
LBB33_36:                               ; =>This Inner Loop Header: Depth=1
	mov	x0, x8
	mov	x1, x27
	bl	_field_write_entry
	cbz	w0, LBB33_35
; %bb.37:                               ;   in Loop: Header=BB33_36 Depth=1
	add	x2, sp, #32
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x1, x27
	bl	_field_write_record
	cbz	w0, LBB33_44
; %bb.38:                               ;   in Loop: Header=BB33_36 Depth=1
	add	x1, sp, #32
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	bl	_same_field_write
	tbz	w0, #0, LBB33_35
	b	LBB33_44
LBB33_39:
	ldr	x27, [sp, #16]                  ; 8-byte Folded Reload
	add	w8, w23, w27
	ldr	x28, [sp]                       ; 8-byte Folded Reload
	add	w8, w8, w28
	add	w1, w8, #28
	mov	w0, #1                          ; =0x1
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	bl	_calloc
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cbz	x0, LBB33_44
; %bb.40:
	mov	x11, x28
	mov	x10, x27
	mov	x27, x0
	strb	w24, [x0]
	lsr	w9, w24, #8
	strb	w9, [x0, #1]
	lsr	w9, w24, #16
	strb	w9, [x0, #2]
	lsr	w9, w24, #24
	strb	w9, [x0, #3]
	strb	w26, [x0, #4]
	lsr	w9, w26, #8
	strb	w9, [x0, #5]
	lsr	w9, w26, #16
	strb	w9, [x0, #6]
	lsr	w9, w26, #24
	strb	w9, [x0, #7]
	strb	w25, [x0, #8]
	lsr	w9, w25, #8
	strb	w9, [x0, #9]
	lsr	w9, w25, #16
	strb	w9, [x0, #10]
	lsr	w9, w25, #24
	strb	w9, [x0, #11]
	mov	w9, #1                          ; =0x1
	strb	w9, [x0, #12]
	strb	w22, [x0, #13]
	strb	w23, [x0, #16]
	lsr	w9, w23, #8
	strb	w9, [x0, #17]
	lsr	w9, w23, #16
	strb	w9, [x0, #18]
	lsr	w9, w23, #24
	strb	w9, [x0, #19]
	strb	w10, [x0, #20]
	lsr	w9, w10, #8
	strb	w9, [x0, #21]
	lsr	w9, w10, #16
	strb	w9, [x0, #22]
	lsr	w9, w10, #24
	strb	w9, [x0, #23]
	strb	w11, [x0, #24]
	lsr	w9, w11, #8
	strb	w9, [x0, #25]
	lsr	w9, w11, #16
	strb	w9, [x0, #26]
	lsr	w9, w11, #24
	add	x28, x0, #28
	strb	w9, [x0, #27]
	mov	x26, x8
	mov	x0, x28
	mov	x1, x21
	mov	x22, x10
	mov	x24, x11
	mov	x2, x23
	bl	_memcpy
	add	x21, x28, x23
	mov	x0, x21
	mov	x1, x20
	mov	x2, x22
	bl	_memcpy
	add	x0, x21, x22
	mov	x1, x19
	mov	x2, x24
	bl	_memcpy
Lloh42:
	adrp	x1, _field_write_key@PAGE
Lloh43:
	add	x1, x1, _field_write_key@PAGEOFF
	mov	x0, x26
	mov	w2, #19                         ; =0x13
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB33_43
; %bb.41:
	mov	x19, x0
	ldr	x25, [sp, #24]                  ; 8-byte Folded Reload
	mov	x0, x25
	mov	x1, x27
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x27
	bl	_free
	cmn	w20, #1
	b.eq	LBB33_44
; %bb.42:
	mov	x0, x25
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	b	_nvm_add_metadata
LBB33_43:
	mov	x0, x27
	bl	_free
LBB33_44:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.loh AdrpAdd	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_generic_binding_at ; -- Begin function nvm_generic_binding_at
	.globl	_nvm_generic_binding_at
	.p2align	2
_nvm_generic_binding_at:                ; @nvm_generic_binding_at
	.cfi_startproc
; %bb.0:
	mov	w8, #0                          ; =0x0
	cbz	x0, LBB34_35
; %bb.1:
	cbz	x2, LBB34_35
; %bb.2:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #176]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #192]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #208]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w26, [x0, #368]
	cbz	w26, LBB34_33
; %bb.3:
	ldr	x8, [x0, #360]
	cbz	x8, LBB34_34
; %bb.4:
	ldr	w9, [x0, #392]
	add	x8, x8, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
	mov	x14, x26
	mov	x12, x9
	b	LBB34_6
LBB34_5:                                ;   in Loop: Header=BB34_6 Depth=1
	add	x8, x8, #8
	subs	x14, x14, #1
	b.eq	LBB34_14
LBB34_6:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x8, #-4]
	cmp	w16, w10
	b.hs	LBB34_33
; %bb.7:                                ;   in Loop: Header=BB34_6 Depth=1
	ldr	w15, [x8]
	cmp	w15, w10
	b.hs	LBB34_33
; %bb.8:                                ;   in Loop: Header=BB34_6 Depth=1
	ldr	x4, [x0, #232]
	cbz	x4, LBB34_33
; %bb.9:                                ;   in Loop: Header=BB34_6 Depth=1
	ldr	x3, [x0, #240]
	cbz	x3, LBB34_33
; %bb.10:                               ;   in Loop: Header=BB34_6 Depth=1
	ldr	x17, [x4, x16, lsl #3]
	cbz	x17, LBB34_33
; %bb.11:                               ;   in Loop: Header=BB34_6 Depth=1
	ldr	x4, [x4, x15, lsl #3]
	cbz	x4, LBB34_33
; %bb.12:                               ;   in Loop: Header=BB34_6 Depth=1
	ldr	w16, [x3, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB34_5
; %bb.13:                               ;   in Loop: Header=BB34_6 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x13
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w12, w12, w15, ne
	b	LBB34_5
LBB34_14:
	mov	w8, #0                          ; =0x0
	cmp	w12, w9
	b.ne	LBB34_34
; %bb.15:
	cmp	w1, w26
	b.hs	LBB34_34
; %bb.16:
	ldr	x19, [x0, #360]
	add	x8, x19, w1, uxtw #3
	ldr	x27, [x0, #240]
	ldr	w9, [x8]
	ldr	w10, [x27, x9, lsl #2]
	cmp	w10, #15
	b.ne	LBB34_33
; %bb.17:
	mov	x28, #24942                     ; =0x616e
	movk	x28, #28526, lsl #16
	movk	x28, #26414, lsl #32
	movk	x28, #28261, lsl #48
	mov	x25, #25966                     ; =0x656e
	movk	x25, #26994, lsl #16
	movk	x25, #11875, lsl #32
	movk	x25, #12662, lsl #48
	ldr	x23, [x0, #232]
	ldr	x9, [x23, x9, lsl #3]
	ldr	x10, [x9]
	ldur	x9, [x9, #7]
	cmp	x10, x28
	ccmp	x9, x25, #0, eq
	b.ne	LBB34_33
; %bb.18:
	mov	x20, x1
	mov	x22, x2
	add	x2, sp, #112
	mov	x24, x0
	mov	x1, x8
	bl	_generic_metadata_record
	cbz	w0, LBB34_33
; %bb.19:
	mov	w21, w20
	ldr	w8, [sp, #112]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldp	w20, w9, [sp, #152]
	ldp	x10, x8, [sp, #120]
	stp	x8, x10, [sp, #16]              ; 16-byte Folded Spill
	ldr	w8, [sp, #160]
	stp	x8, x9, [sp, #32]               ; 16-byte Folded Spill
	ldr	x8, [sp, #136]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x22
	mov	x0, x24
	b	LBB34_22
LBB34_20:                               ;   in Loop: Header=BB34_22 Depth=1
	mov	x8, x22
	mov	x0, x24
LBB34_21:                               ;   in Loop: Header=BB34_22 Depth=1
	sub	x21, x21, #1
	add	x19, x19, #8
	subs	x26, x26, #1
	b.eq	LBB34_36
LBB34_22:                               ; =>This Inner Loop Header: Depth=1
	cbz	x21, LBB34_21
; %bb.23:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	w9, [x19]
	ldr	w10, [x27, x9, lsl #2]
	cmp	w10, #15
	b.ne	LBB34_21
; %bb.24:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	x9, [x23, x9, lsl #3]
	ldr	x10, [x9]
	ldur	x9, [x9, #7]
	cmp	x10, x28
	ccmp	x9, x25, #0, eq
	b.ne	LBB34_21
; %bb.25:                               ;   in Loop: Header=BB34_22 Depth=1
	add	x2, sp, #56
	mov	x1, x19
	bl	_generic_metadata_record
	cbz	w0, LBB34_33
; %bb.26:                               ;   in Loop: Header=BB34_22 Depth=1
	ldp	w9, w8, [sp, #52]               ; 4-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB34_20
; %bb.27:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	w8, [sp, #96]
	cmp	w20, w8
	b.ne	LBB34_33
; %bb.28:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	x1, [sp, #64]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, x20
	bl	_memcmp
	cbnz	w0, LBB34_33
; %bb.29:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	w8, [sp, #100]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB34_33
; %bb.30:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	x1, [sp, #72]
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB34_33
; %bb.31:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	w8, [sp, #104]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w9, w8
	b.ne	LBB34_20
; %bb.32:                               ;   in Loop: Header=BB34_22 Depth=1
	ldr	x1, [sp, #80]
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB34_20
LBB34_33:
	mov	w8, #0                          ; =0x0
LBB34_34:
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #224]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #208]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #192]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #272
LBB34_35:
	mov	x0, x8
	ret
LBB34_36:
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #144]
	str	q0, [x8, #32]
	ldr	x9, [sp, #160]
	str	x9, [x8, #48]
	mov	w8, #1                          ; =0x1
	b	LBB34_34
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function generic_metadata_record
_generic_metadata_record:               ; @generic_metadata_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x9, [x0, #240]
	ldr	w8, [x1, #4]
	ldr	w9, [x9, x8, lsl #2]
	subs	w24, w9, #20
	b.lo	LBB35_10
; %bb.1:
	ldr	x9, [x0, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldr	w27, [x8]
	ldr	w9, [x0, #272]
	cmp	w27, w9
	b.hs	LBB35_10
; %bb.2:
	ldr	w19, [x8, #4]
	sub	w9, w19, #1
	cmp	w9, w24
	b.hs	LBB35_10
; %bb.3:
	mov	x28, x2
	ldp	w22, w20, [x8, #8]
	add	x23, x8, #20
	ldr	w21, [x8, #16]
	mov	x0, x23
	mov	w1, #0                          ; =0x0
	mov	x2, x19
	bl	_memchr
	cbnz	x0, LBB35_10
; %bb.4:
	sub	w8, w24, w19
	subs	w26, w8, w22
	b.lo	LBB35_10
; %bb.5:
	add	x24, x23, x19
	mov	x0, x24
	mov	w1, #0                          ; =0x0
	mov	x2, x22
	bl	_memchr
	cbnz	x0, LBB35_10
; %bb.6:
	sub	w8, w20, #1
	cmp	w8, w26
	b.hs	LBB35_10
; %bb.7:
	add	x25, x24, x22
	mov	x0, x25
	mov	w1, #0                          ; =0x0
	mov	x2, x20
	bl	_memchr
	cbnz	x0, LBB35_10
; %bb.8:
	sub	w8, w21, #1
	sub	w26, w26, w20
	cmp	w8, w26
	b.hs	LBB35_10
; %bb.9:
	add	x0, x25, x20
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	mov	x2, x21
	bl	_memchr
	cmp	x0, #0
	ccmp	w26, w21, #0, eq
	b.eq	LBB35_12
LBB35_10:
	mov	w0, #0                          ; =0x0
LBB35_11:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB35_12:
	stp	w27, wzr, [x28]
	stp	x23, x24, [x28, #8]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stp	x25, x8, [x28, #24]
	stp	w19, w22, [x28, #40]
	mov	w0, #1                          ; =0x1
	stp	w20, w21, [x28, #48]
	b	LBB35_11
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_generic_binding ; -- Begin function nvm_add_generic_binding
	.globl	_nvm_add_generic_binding
	.p2align	2
_nvm_add_generic_binding:               ; @nvm_add_generic_binding
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB36_41
; %bb.1:
	ldr	w27, [x0, #368]
	cbz	w27, LBB36_14
; %bb.2:
	ldr	x9, [x0, #360]
	cbz	x9, LBB36_41
; %bb.3:
	ldr	w8, [x0, #392]
	add	x9, x9, #4
	ldr	w10, [x0, #248]
	mov	x11, #24942                     ; =0x616e
	movk	x11, #28526, lsl #16
	movk	x11, #29486, lsl #32
	movk	x11, #30063, lsl #48
	mov	x12, #25458                     ; =0x6372
	movk	x12, #24421, lsl #16
	movk	x12, #26982, lsl #32
	movk	x12, #25964, lsl #48
	mov	x14, x27
	mov	x13, x8
	b	LBB36_5
LBB36_4:                                ;   in Loop: Header=BB36_5 Depth=1
	add	x9, x9, #8
	subs	x14, x14, #1
	b.eq	LBB36_13
LBB36_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w16, [x9, #-4]
	cmp	w16, w10
	b.hs	LBB36_41
; %bb.6:                                ;   in Loop: Header=BB36_5 Depth=1
	ldr	w15, [x9]
	cmp	w15, w10
	b.hs	LBB36_41
; %bb.7:                                ;   in Loop: Header=BB36_5 Depth=1
	ldr	x7, [x0, #232]
	cbz	x7, LBB36_41
; %bb.8:                                ;   in Loop: Header=BB36_5 Depth=1
	ldr	x6, [x0, #240]
	cbz	x6, LBB36_41
; %bb.9:                                ;   in Loop: Header=BB36_5 Depth=1
	ldr	x17, [x7, x16, lsl #3]
	cbz	x17, LBB36_41
; %bb.10:                               ;   in Loop: Header=BB36_5 Depth=1
	ldr	x7, [x7, x15, lsl #3]
	cbz	x7, LBB36_41
; %bb.11:                               ;   in Loop: Header=BB36_5 Depth=1
	ldr	w16, [x6, x16, lsl #2]
	cmp	w16, #16
	b.ne	LBB36_4
; %bb.12:                               ;   in Loop: Header=BB36_5 Depth=1
	ldp	x16, x17, [x17]
	eor	x16, x16, x11
	eor	x17, x17, x12
	orr	x16, x16, x17
	cmp	x16, #0
	csel	w13, w13, w15, ne
	b	LBB36_4
LBB36_13:
	cmp	w13, w8
	b.ne	LBB36_41
LBB36_14:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	ccmp	x2, #0, #4, lo
	b.eq	LBB36_41
; %bb.15:
	mov	x28, x0
	mov	x0, x2
	mov	x21, x5
	mov	x24, x4
	mov	x23, x3
	mov	x22, x2
	mov	x25, x1
	bl	_strlen
	mov	x9, #-65516                     ; =0xffffffffffff0014
	movk	x9, #0, lsl #16
	orr	x10, x9, #0x1
	add	x9, x0, x9
	cmp	x9, x10
	b.lo	LBB36_41
; %bb.16:
	mov	x8, x23
	cbz	x23, LBB36_41
; %bb.17:
	mov	x19, x0
	mov	x0, x8
	bl	_strlen
	mov	w9, #-21                        ; =0xffffffeb
	sub	x9, x9, x19
	cmp	x0, x9
	b.hi	LBB36_41
; %bb.18:
	mov	x8, x24
	cbz	x24, LBB36_41
; %bb.19:
	mov	x20, x0
	add	w9, w19, #20
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	add	w26, w9, w20
	mov	x0, x8
	bl	_strlen
	str	w26, [sp, #28]                  ; 4-byte Folded Spill
	mvn	w9, w26
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	sub	x10, x0, #1
	cmp	x10, x9
	b.hs	LBB36_41
; %bb.20:
	mov	x8, x21
	cbz	x21, LBB36_41
; %bb.21:
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	add	w26, w9, w10
	mov	x0, x8
	bl	_strlen
	mvn	w8, w26
	sub	x9, x0, #1
	cmp	x9, x8
	b.hs	LBB36_41
; %bb.22:
	mov	x10, x26
	str	w26, [sp, #20]                  ; 4-byte Folded Spill
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	cbz	w27, LBB36_36
; %bb.23:
	mov	x11, x28
	ldr	x26, [x28, #360]
	ldr	x12, [x28, #240]
	mov	x13, #24942                     ; =0x616e
	movk	x13, #28526, lsl #16
	movk	x13, #26414, lsl #32
	movk	x13, #28261, lsl #48
	mov	x14, #25966                     ; =0x656e
	movk	x14, #26994, lsl #16
	movk	x14, #11875, lsl #32
	movk	x14, #12662, lsl #48
	str	x12, [sp]                       ; 8-byte Folded Spill
	b	LBB36_26
LBB36_24:                               ;   in Loop: Header=BB36_26 Depth=1
	mov	x11, x28
	ldr	w10, [sp, #20]                  ; 4-byte Folded Reload
	ldp	x12, x0, [sp]                   ; 16-byte Folded Reload
	mov	x13, #24942                     ; =0x616e
	movk	x13, #28526, lsl #16
	movk	x13, #26414, lsl #32
	movk	x13, #28261, lsl #48
	mov	x14, #25966                     ; =0x656e
	movk	x14, #26994, lsl #16
	movk	x14, #11875, lsl #32
	movk	x14, #12662, lsl #48
LBB36_25:                               ;   in Loop: Header=BB36_26 Depth=1
	add	x26, x26, #8
	subs	x27, x27, #1
	b.eq	LBB36_36
LBB36_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x26]
	ldr	w9, [x12, x8, lsl #2]
	cmp	w9, #15
	b.ne	LBB36_25
; %bb.27:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	x9, [x11, #232]
	ldr	x8, [x9, x8, lsl #3]
	ldr	x9, [x8]
	ldur	x8, [x8, #7]
	cmp	x9, x13
	ccmp	x8, x14, #0, eq
	b.ne	LBB36_25
; %bb.28:                               ;   in Loop: Header=BB36_26 Depth=1
	add	x2, sp, #40
	mov	x0, x11
	mov	x1, x26
	bl	_generic_metadata_record
	cbz	w0, LBB36_41
; %bb.29:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	w8, [sp, #40]
	cmp	w25, w8
	b.ne	LBB36_24
; %bb.30:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	w8, [sp, #80]
	cmp	w8, w19
	b.ne	LBB36_41
; %bb.31:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	x1, [sp, #48]
	mov	x0, x22
	mov	x2, x19
	bl	_memcmp
	cbnz	w0, LBB36_41
; %bb.32:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	w8, [sp, #84]
	cmp	w8, w20
	b.ne	LBB36_41
; %bb.33:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	x1, [sp, #56]
	mov	x0, x23
	mov	x2, x20
	bl	_memcmp
	cbnz	w0, LBB36_41
; %bb.34:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	cmp	w8, w9
	b.ne	LBB36_24
; %bb.35:                               ;   in Loop: Header=BB36_26 Depth=1
	ldr	x1, [sp, #64]
	mov	x0, x24
	ldr	x2, [sp, #32]                   ; 8-byte Folded Reload
	bl	_memcmp
	cbnz	w0, LBB36_24
	b	LBB36_41
LBB36_36:
	add	w26, w10, w0
	mov	x0, x26
	bl	_malloc
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	cbz	x0, LBB36_41
; %bb.37:
	mov	x1, x22
	mov	x27, x23
	mov	x22, x0
	strb	w25, [x0]
	lsr	w8, w25, #8
	strb	w8, [x0, #1]
	lsr	w8, w25, #16
	strb	w8, [x0, #2]
	lsr	w8, w25, #24
	strb	w8, [x0, #3]
	strb	w19, [x0, #4]
	lsr	x8, x19, #8
	strb	w8, [x0, #5]
	lsr	x8, x19, #16
	strb	w8, [x0, #6]
	lsr	x8, x19, #24
	strb	w8, [x0, #7]
	add	x0, x0, #20
	mov	x2, x19
	mov	x19, x21
	mov	x21, x9
	mov	x25, x10
	bl	_memcpy
	str	w20, [x22, #8]
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	add	x0, x22, w8, uxtw
	mov	w2, w20
	mov	x1, x27
	bl	_memcpy
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	str	w9, [x22, #12]
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	add	x0, x22, w8, uxtw
	mov	w2, w9
	mov	x1, x24
	bl	_memcpy
	str	w25, [x22, #16]
	add	x0, x22, w21, uxtw
	mov	w2, w25
	mov	x1, x19
	bl	_memcpy
Lloh44:
	adrp	x1, _generic_key@PAGE
Lloh45:
	add	x1, x1, _generic_key@PAGEOFF
	mov	x0, x28
	mov	w2, #15                         ; =0xf
	bl	_nvm_add_string
	cmn	w0, #1
	b.eq	LBB36_40
; %bb.38:
	mov	x19, x0
	mov	x21, x28
	mov	x0, x28
	mov	x1, x22
	mov	x2, x26
	bl	_nvm_add_string
	mov	x20, x0
	mov	x0, x22
	bl	_free
	cmn	w20, #1
	b.eq	LBB36_41
; %bb.39:
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	b	_nvm_add_metadata
LBB36_40:
	mov	x0, x22
	bl	_free
LBB36_41:
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_call_descriptors_reset ; -- Begin function nvm_call_descriptors_reset
	.globl	_nvm_call_descriptors_reset
	.p2align	2
_nvm_call_descriptors_reset:            ; @nvm_call_descriptors_reset
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB37_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #456]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19, #456]
	str	wzr, [x19, #464]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB37_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_get_string         ; -- Begin function nvm_get_string
	.globl	_nvm_get_string
	.p2align	2
_nvm_get_string:                        ; @nvm_get_string
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB38_2
; %bb.1:
	ldr	x8, [x0, #232]
	ldr	x0, [x8, w1, uxtw #3]
	ret
LBB38_2:
	mov	x0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_get_string_len     ; -- Begin function nvm_get_string_len
	.globl	_nvm_get_string_len
	.p2align	2
_nvm_get_string_len:                    ; @nvm_get_string_len
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cmp	w1, w8
	b.hs	LBB39_2
; %bb.1:
	ldr	x8, [x0, #240]
	ldr	w0, [x8, w1, uxtw #2]
	ret
LBB39_2:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_function       ; -- Begin function nvm_add_function
	.globl	_nvm_add_function
	.p2align	2
_nvm_add_function:                      ; @nvm_add_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w19, #-1                        ; =0xffffffff
	cbz	x0, LBB40_13
; %bb.1:
	cbz	x1, LBB40_13
; %bb.2:
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	w19, [x0, #272]
	ldr	w8, [x0, #276]
	cmp	w19, w8
	b.hs	LBB40_4
; %bb.3:
	ldr	x20, [x0, #256]
	b	LBB40_12
LBB40_4:
	tbnz	w8, #31, LBB40_7
; %bb.5:
	mov	x24, x0
	lsl	w9, w8, #1
	mov	w10, #32                        ; =0x20
	cmp	w8, #0
	csel	w21, w10, w9, eq
	mov	x0, x21
	mov	w1, #24                         ; =0x18
	bl	_calloc
	mov	x20, x0
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x22, x0
	cmp	x20, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB40_8
; %bb.6:
	mov	x0, x20
	bl	_free
	mov	x0, x22
	bl	_free
LBB40_7:
	mov	w19, #-1                        ; =0xffffffff
	b	LBB40_13
LBB40_8:
	ldr	x23, [x24, #256]
	cbz	w19, LBB40_11
; %bb.9:
	add	x8, x19, x19, lsl #1
	lsl	x2, x8, #3
	mov	x0, x20
	mov	x1, x23
	bl	_memcpy
	ldr	x1, [x24, #264]
	cbz	x1, LBB40_11
; %bb.10:
	lsl	x2, x19, #3
	mov	x0, x22
	bl	_memcpy
LBB40_11:
	mov	x0, x23
	bl	_free
	ldr	x0, [x24, #264]
	bl	_free
	mov	x0, x24
	stp	x20, x22, [x24, #256]
	str	w21, [x24, #276]
	ldr	w19, [x24, #272]
LBB40_12:
	mov	w8, #24                         ; =0x18
	umaddl	x8, w19, w8, x20
	ldr	q0, [sp]
	str	q0, [x8]
	ldr	x9, [sp, #16]
	str	x9, [x8, #16]
	ldr	w8, [x0, #272]
	add	w8, w8, #1
	str	w8, [x0, #272]
LBB40_13:
	mov	x0, x19
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_set_function_param_types ; -- Begin function nvm_set_function_param_types
	.globl	_nvm_set_function_param_types
	.p2align	2
_nvm_set_function_param_types:          ; @nvm_set_function_param_types
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB41_9
; %bb.1:
	ldr	w8, [x0, #272]
	cmp	w1, w8
	b.hs	LBB41_8
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x22, [x0, #264]
	cbz	x22, LBB41_6
; %bb.3:
	ldr	x8, [x0, #256]
	mov	w9, #24                         ; =0x18
	umaddl	x8, w1, w9, x8
	ldrh	w8, [x8, #4]
	cmp	w3, w8
	b.ne	LBB41_6
; %bb.4:
	cbnz	x2, LBB41_10
; %bb.5:
	cbz	w3, LBB41_10
LBB41_6:
	mov	w0, #0                          ; =0x0
LBB41_7:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB41_8:
	mov	w0, #0                          ; =0x0
LBB41_9:
	ret
LBB41_10:
	cbz	w3, LBB41_16
; %bb.11:
	mov	x8, #0                          ; =0x0
	mov	w19, w3
LBB41_12:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x2, x8]
	cmp	w9, #15
	b.hi	LBB41_6
; %bb.13:                               ;   in Loop: Header=BB41_12 Depth=1
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	LBB41_12
; %bb.14:
	mov	x21, x2
	mov	x23, x0
	mov	x24, x1
	mov	x0, x19
	bl	_malloc
	cbz	x0, LBB41_7
; %bb.15:
	mov	x20, x0
	mov	x1, x21
	mov	x2, x19
	bl	_memcpy
	mov	x1, x24
	b	LBB41_17
LBB41_16:
	mov	x23, x0
	mov	x20, #0                         ; =0x0
LBB41_17:
	ldr	x0, [x22, w1, uxtw #3]
	mov	x19, x1
	bl	_free
	ldr	x8, [x23, #264]
	str	x20, [x8, w19, uxtw #3]
	mov	w0, #1                          ; =0x1
	b	LBB41_7
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_callback_shape_valid ; -- Begin function nvm_callback_shape_valid
	.globl	_nvm_callback_shape_valid
	.p2align	2
_nvm_callback_shape_valid:              ; @nvm_callback_shape_valid
	.cfi_startproc
; %bb.0:
	cmp	w1, #16
	b.hi	LBB42_3
; %bb.1:
	cbnz	x0, LBB42_4
; %bb.2:
	cbz	w1, LBB42_4
LBB42_3:
	mov	w0, #0                          ; =0x0
	ret
LBB42_4:
	cmp	w2, #5
	b.hs	LBB42_10
LBB42_5:
	cbz	w1, LBB42_9
; %bb.6:
	mov	w8, w1
LBB42_7:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w9, [x0], #1
	sub	w10, w9, #1
	cmp	w10, #4
	ccmp	w9, #14, #4, hs
	b.ne	LBB42_3
; %bb.8:                                ;   in Loop: Header=BB42_7 Depth=1
	subs	x8, x8, #1
	b.ne	LBB42_7
LBB42_9:
	mov	w0, #1                          ; =0x1
	ret
LBB42_10:
	cmp	w2, #14
	b.eq	LBB42_5
	b	LBB42_3
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_callback_contract ; -- Begin function nvm_add_callback_contract
	.globl	_nvm_add_callback_contract
	.p2align	2
_nvm_add_callback_contract:             ; @nvm_add_callback_contract
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	w8, #0                          ; =0x0
Lloh46:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh47:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh48:
	ldr	x9, [x9]
	str	x9, [sp, #24]
	cbz	x0, LBB43_6
; %bb.1:
	cbz	x1, LBB43_6
; %bb.2:
	ldrb	w8, [x1, #10]
	cmp	w8, #1
	b.ne	LBB43_5
; %bb.3:
	ldrb	w8, [x1, #11]
	cmp	w8, #1
	b.hi	LBB43_5
; %bb.4:
	ldrh	w22, [x1, #12]
	cmp	w22, #16
	b.ls	LBB43_8
LBB43_5:
	mov	w8, #0                          ; =0x0
LBB43_6:
	ldr	x9, [sp, #24]
Lloh49:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh50:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh51:
	ldr	x10, [x10]
	cmp	x10, x9
	b.ne	LBB43_28
; %bb.7:
	mov	x0, x8
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB43_8:
	ldrb	w23, [x1, #14]
	cmp	w23, #5
	b.hs	LBB43_20
LBB43_9:
	add	x8, x1, #15
	cbz	w22, LBB43_13
; %bb.10:
	mov	x9, x8
	mov	x10, x22
LBB43_11:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x9], #1
	sub	w12, w11, #1
	cmp	w12, #4
	ccmp	w11, #14, #4, hs
	b.ne	LBB43_5
; %bb.12:                               ;   in Loop: Header=BB43_11 Depth=1
	subs	x10, x10, #1
	b.ne	LBB43_11
LBB43_13:
	ldr	d8, [x1]
	ldr	w9, [x1]
	ldrh	w24, [x1, #8]
	ldrh	w25, [x1, #10]
	ldr	q0, [x8]
	str	q0, [sp]
	ldrb	w8, [x8, #16]
	strb	w8, [sp, #16]
	mov	w8, #65535                      ; =0xffff
	cmp	w24, w8
	orr	w8, w22, w23
	ccmp	w8, #0, #4, eq
	b.ne	LBB43_5
; %bb.14:
	ldr	w26, [x0, #424]
	cbz	w26, LBB43_21
; %bb.15:
	ldr	x8, [x0, #416]
	sub	w10, w26, #1
	add	x8, x8, x10, lsl #5
	ldr	w10, [x8]
	cmp	w9, w10
	b.lo	LBB43_5
; %bb.16:
	b.ne	LBB43_18
; %bb.17:
	ldrh	w8, [x8, #8]
	cmp	w24, w8
	b.ls	LBB43_5
LBB43_18:
	ldr	w8, [x0, #428]
	cmp	w26, w8
	b.ne	LBB43_26
; %bb.19:
	tbz	w26, #31, LBB43_22
	b	LBB43_5
LBB43_20:
	cmp	w23, #14
	b.ne	LBB43_5
	b	LBB43_9
LBB43_21:
	ldr	w8, [x0, #428]
	cmp	w26, w8
	b.ne	LBB43_26
LBB43_22:
	mov	x27, x0
	lsl	w8, w26, #1
	mov	w9, #8                          ; =0x8
	cmp	w26, #0
	csel	w20, w9, w8, eq
	mov	x0, x20
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB43_5
; %bb.23:
	mov	x19, x0
	ldr	x21, [x27, #416]
	cbz	w26, LBB43_25
; %bb.24:
	lsl	x2, x26, #5
	mov	x0, x19
	mov	x1, x21
	bl	_memcpy
LBB43_25:
	mov	x0, x21
	bl	_free
	mov	x0, x27
	str	x19, [x27, #416]
	str	w20, [x27, #428]
	ldr	w26, [x27, #424]
	b	LBB43_27
LBB43_26:
	ldr	x19, [x0, #416]
LBB43_27:
	add	w8, w26, #1
	str	w8, [x0, #424]
	mov	w8, w26
	add	x8, x19, x8, lsl #5
	str	d8, [x8]
	strh	w24, [x8, #8]
	strh	w25, [x8, #10]
	strh	w22, [x8, #12]
	strb	w23, [x8, #14]
	ldr	q0, [sp]
	stur	q0, [x8, #15]
	ldrb	w9, [sp, #16]
	strb	w9, [x8, #31]
	mov	w8, #1                          ; =0x1
	b	LBB43_6
LBB43_28:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh46, Lloh47, Lloh48
	.loh AdrpLdrGotLdr	Lloh49, Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_callback_contracts_valid
lCPI44_0:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	8                               ; 0x8
lCPI44_1:
	.long	16                              ; 0x10
	.long	32                              ; 0x20
	.long	64                              ; 0x40
	.long	128                             ; 0x80
lCPI44_2:
	.long	256                             ; 0x100
	.long	512                             ; 0x200
	.long	1024                            ; 0x400
	.long	2048                            ; 0x800
lCPI44_3:
	.long	4096                            ; 0x1000
	.long	8192                            ; 0x2000
	.long	16384                           ; 0x4000
	.long	32768                           ; 0x8000
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_callback_contracts_valid
	.globl	_nvm_callback_contracts_valid
	.p2align	2
_nvm_callback_contracts_valid:          ; @nvm_callback_contracts_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB44_55
; %bb.1:
	sub	sp, sp, #224
	stp	d9, d8, [sp, #112]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	ldr	w27, [x0, #424]
	cbz	w27, LBB44_57
; %bb.2:
	ldr	x21, [x0, #416]
	cbz	x21, LBB44_56
; %bb.3:
	mov	w26, #0                         ; =0x0
	add	x8, x21, #15
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh52:
	adrp	x8, lCPI44_2@PAGE
Lloh53:
	ldr	q0, [x8, lCPI44_2@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh54:
	adrp	x8, lCPI44_0@PAGE
Lloh55:
	ldr	q0, [x8, lCPI44_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	mov	w15, #12                        ; =0xc
Lloh56:
	adrp	x8, lCPI44_3@PAGE
Lloh57:
	ldr	q0, [x8, lCPI44_3@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
Lloh58:
	adrp	x8, lCPI44_1@PAGE
Lloh59:
	ldr	q0, [x8, lCPI44_1@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
	mov	w17, #1                         ; =0x1
	ldr	w1, [x0, #432]
	movi.4h	v8, #11
LBB44_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB44_12 Depth 2
                                        ;     Child Loop BB44_23 Depth 2
                                        ;       Child Loop BB44_32 Depth 3
	mov	w8, w26
	add	x3, x21, x8, lsl #5
	ldr	w2, [x3]
	cmp	w2, w1
	b.hs	LBB44_56
; %bb.5:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x9, [x0, #400]
	cbz	x9, LBB44_56
; %bb.6:                                ;   in Loop: Header=BB44_4 Depth=1
	umaddl	x9, w2, w15, x9
	ldrh	w23, [x9, #8]
	cmp	w23, #16
	b.hi	LBB44_56
; %bb.7:                                ;   in Loop: Header=BB44_4 Depth=1
	cbz	w23, LBB44_13
; %bb.8:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x9, [x0, #408]
	cbz	x9, LBB44_56
; %bb.9:                                ;   in Loop: Header=BB44_4 Depth=1
	ldr	x9, [x9, x2, lsl #3]
	cbz	x9, LBB44_56
; %bb.10:                               ;   in Loop: Header=BB44_4 Depth=1
	cmp	w23, #3
	b.hi	LBB44_14
; %bb.11:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	x10, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
LBB44_12:                               ;   Parent Loop BB44_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w11, [x9, x10]
	and	w11, w11, #0xfffffffb
	lsl	w12, w17, w10
	cmp	w11, #11
	csel	w11, w12, wzr, eq
	orr	w22, w11, w22
	add	x10, x10, #1
	cmp	x23, x10
	b.ne	LBB44_12
	b	LBB44_21
LBB44_13:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	w22, #0                         ; =0x0
	b	LBB44_21
LBB44_14:                               ;   in Loop: Header=BB44_4 Depth=1
	cmp	w23, #16
	b.ne	LBB44_16
; %bb.15:                               ;   in Loop: Header=BB44_4 Depth=1
	ldr	q0, [x9]
	movi.16b	v1, #251
	and.16b	v0, v0, v1
	movi.16b	v1, #11
	cmeq.16b	v0, v0, v1
	sshll.8h	v1, v0, #0
	ushll2.4s	v2, v1, #0
	sshll2.8h	v0, v0, #0
	ushll2.4s	v3, v0, #0
	ushll.4s	v1, v1, #0
	ushll.4s	v0, v0, #0
	ldr	q4, [sp, #16]                   ; 16-byte Folded Reload
	and.16b	v0, v0, v4
	ldr	q4, [sp, #48]                   ; 16-byte Folded Reload
	and.16b	v1, v1, v4
	ldr	q4, [sp]                        ; 16-byte Folded Reload
	and.16b	v3, v3, v4
	ldr	q4, [sp, #32]                   ; 16-byte Folded Reload
	and.16b	v2, v2, v4
	orr.16b	v2, v2, v3
	orr.16b	v0, v1, v0
	orr.16b	v0, v0, v2
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x9, d0
	lsr	x10, x9, #32
	orr	w22, w9, w10
	b	LBB44_21
LBB44_16:                               ;   in Loop: Header=BB44_4 Depth=1
	and	x10, x23, #0x1c
	ldr	s0, [x9]
	ushll.8h	v0, v0, #0
	bic.4h	v0, #4
	cmeq.4h	v0, v0, v8
	sshll.4s	v0, v0, #0
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	and.16b	v0, v0, v1
	cmp	x10, #4
	b.eq	LBB44_20
; %bb.17:                               ;   in Loop: Header=BB44_4 Depth=1
	ldr	s1, [x9, #4]
	ushll.8h	v1, v1, #0
	bic.4h	v1, #4
	cmeq.4h	v1, v1, v8
	sshll.4s	v1, v1, #0
	ldr	q2, [sp, #32]                   ; 16-byte Folded Reload
	and.16b	v1, v1, v2
	orr.16b	v0, v1, v0
	cmp	x10, #8
	b.eq	LBB44_20
; %bb.18:                               ;   in Loop: Header=BB44_4 Depth=1
	ldr	s1, [x9, #8]
	ushll.8h	v1, v1, #0
	bic.4h	v1, #4
	cmeq.4h	v1, v1, v8
	sshll.4s	v1, v1, #0
	ldr	q2, [sp, #16]                   ; 16-byte Folded Reload
	and.16b	v1, v1, v2
	orr.16b	v0, v1, v0
	cmp	x10, #12
	b.eq	LBB44_20
; %bb.19:                               ;   in Loop: Header=BB44_4 Depth=1
	ldr	s1, [x9, #12]
	ushll.8h	v1, v1, #0
	bic.4h	v1, #4
	cmeq.4h	v1, v1, v8
	sshll.4s	v1, v1, #0
	ldr	q2, [sp]                        ; 16-byte Folded Reload
	and.16b	v1, v1, v2
	orr.16b	v0, v1, v0
LBB44_20:                               ;   in Loop: Header=BB44_4 Depth=1
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x11, d0
	lsr	x12, x11, #32
	orr	w22, w11, w12
	cmp	x10, x23
	b.ne	LBB44_12
LBB44_21:                               ;   in Loop: Header=BB44_4 Depth=1
	cmp	w26, w27
	b.hs	LBB44_50
; %bb.22:                               ;   in Loop: Header=BB44_4 Depth=1
	stp	w1, wzr, [sp, #96]              ; 8-byte Folded Spill
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	add	x12, x9, x8, lsl #5
	mov	x24, x26
	stp	x3, x2, [sp, #80]               ; 16-byte Folded Spill
LBB44_23:                               ;   Parent Loop BB44_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB44_32 Depth 3
	mov	w8, w24
	add	x20, x21, x8, lsl #5
	ldr	w9, [x20]
	cmp	w9, w2
	b.ne	LBB44_53
; %bb.24:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrb	w8, [x20, #10]
	cmp	w8, #1
	b.ne	LBB44_56
; %bb.25:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrb	w8, [x20, #11]
	cmp	w8, #1
	b.hi	LBB44_56
; %bb.26:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrb	w9, [x3, #11]
	cmp	w8, w9
	b.ne	LBB44_56
; %bb.27:                               ;   in Loop: Header=BB44_23 Depth=2
	ldr	w19, [x20, #4]
	ldr	w8, [x3, #4]
	cmp	w19, w8
	b.ne	LBB44_56
; %bb.28:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrh	w25, [x20, #12]
	cmp	w25, #16
	b.hi	LBB44_56
; %bb.29:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrb	w15, [x20, #14]
	cmp	w15, #5
	ccmp	w15, #14, #4, hs
	b.ne	LBB44_56
; %bb.30:                               ;   in Loop: Header=BB44_23 Depth=2
	cbz	w25, LBB44_34
; %bb.31:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	x8, x12
	mov	x9, x25
LBB44_32:                               ;   Parent Loop BB44_4 Depth=1
                                        ;     Parent Loop BB44_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w10, [x8], #1
	sub	w11, w10, #1
	cmp	w11, #4
	ccmp	w10, #14, #4, hs
	b.ne	LBB44_56
; %bb.33:                               ;   in Loop: Header=BB44_32 Depth=3
	subs	x9, x9, #1
	b.ne	LBB44_32
LBB44_34:                               ;   in Loop: Header=BB44_23 Depth=2
	ldr	w8, [x0, #248]
	cmp	w19, w8
	b.hs	LBB44_56
; %bb.35:                               ;   in Loop: Header=BB44_23 Depth=2
	ldr	x8, [x0, #232]
	ldr	x8, [x8, x19, lsl #3]
	cbz	x8, LBB44_58
; %bb.36:                               ;   in Loop: Header=BB44_23 Depth=2
	ldrb	w9, [x8]
	cbz	w9, LBB44_56
; %bb.37:                               ;   in Loop: Header=BB44_23 Depth=2
	str	w15, [sp, #76]                  ; 4-byte Folded Spill
	str	x12, [sp, #104]                 ; 8-byte Folded Spill
	mov	x28, x0
	mov	x0, x8
	bl	_strlen
	ldr	x9, [x28, #240]
	ldr	w9, [x9, x19, lsl #2]
	cmp	x0, x9
	b.ne	LBB44_56
; %bb.38:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	x0, x28
	ldrh	w8, [x20, #8]
	cmp	w24, w26
	b.ls	LBB44_40
; %bb.39:                               ;   in Loop: Header=BB44_23 Depth=2
	sub	w9, w24, #1
	add	x9, x21, x9, lsl #5
	ldrh	w9, [x9, #8]
	cmp	w8, w9
	b.ls	LBB44_56
LBB44_40:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	w9, #65535                      ; =0xffff
	cmp	w8, w9
	b.ne	LBB44_45
; %bb.41:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	w8, #0                          ; =0x0
	cbnz	w22, LBB44_58
; %bb.42:                               ;   in Loop: Header=BB44_23 Depth=2
	cmp	w24, w26
	b.ne	LBB44_58
; %bb.43:                               ;   in Loop: Header=BB44_23 Depth=2
	cbnz	w25, LBB44_58
; %bb.44:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	w15, #12                        ; =0xc
	mov	w17, #1                         ; =0x1
	ldr	w1, [sp, #96]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #76]                   ; 4-byte Folded Reload
	cbz	w9, LBB44_48
	b	LBB44_58
LBB44_45:                               ;   in Loop: Header=BB44_23 Depth=2
	cmp	w8, w23
	b.hs	LBB44_56
; %bb.46:                               ;   in Loop: Header=BB44_23 Depth=2
	mov	w17, #1                         ; =0x1
	lsl	w8, w17, w8
	tst	w8, w22
	b.eq	LBB44_56
; %bb.47:                               ;   in Loop: Header=BB44_23 Depth=2
	ldp	w1, w9, [sp, #96]               ; 8-byte Folded Reload
	orr	w9, w8, w9
	str	w9, [sp, #100]                  ; 4-byte Folded Spill
	mov	w15, #12                        ; =0xc
LBB44_48:                               ;   in Loop: Header=BB44_23 Depth=2
	add	w24, w24, #1
	ldr	x12, [sp, #104]                 ; 8-byte Folded Reload
	add	x12, x12, #32
	cmp	w24, w27
	ldp	x3, x2, [sp, #80]               ; 16-byte Folded Reload
	b.ne	LBB44_23
; %bb.49:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	x26, x27
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	b	LBB44_51
LBB44_50:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	w8, #0                          ; =0x0
LBB44_51:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	x24, x26
	cmp	w8, w22
	b.ne	LBB44_56
LBB44_52:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	w8, #1                          ; =0x1
	mov	x26, x24
	cmp	w24, w27
	b.lo	LBB44_4
	b	LBB44_58
LBB44_53:                               ;   in Loop: Header=BB44_4 Depth=1
	mov	w8, #0                          ; =0x0
	ldr	w10, [sp, #100]                 ; 4-byte Folded Reload
	cmp	w10, w22
	b.ne	LBB44_58
; %bb.54:                               ;   in Loop: Header=BB44_4 Depth=1
	cmp	w9, w2
	b.hs	LBB44_52
	b	LBB44_58
LBB44_55:
	mov	w0, #0                          ; =0x0
	ret
LBB44_56:
	mov	w8, #0                          ; =0x0
	b	LBB44_58
LBB44_57:
	mov	w8, #1                          ; =0x1
LBB44_58:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #112]              ; 16-byte Folded Reload
	add	sp, sp, #224
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_find_function      ; -- Begin function nvm_find_function
	.globl	_nvm_find_function
	.p2align	2
_nvm_find_function:                     ; @nvm_find_function
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w19, #-1                        ; =0xffffffff
	cbz	x0, LBB45_8
; %bb.1:
	mov	x20, x1
	cbz	x1, LBB45_8
; %bb.2:
	mov	x21, x0
	ldr	w8, [x0, #272]
	cbz	w8, LBB45_8
; %bb.3:
	ldr	x9, [x21, #256]
	ldr	w22, [x21, #248]
	sub	w19, w8, #1
	mov	w8, #24                         ; =0x18
	umaddl	x23, w19, w8, x9
	b	LBB45_5
LBB45_4:                                ;   in Loop: Header=BB45_5 Depth=1
	sub	w19, w19, #1
	cmn	w19, #1
	b.eq	LBB45_8
LBB45_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23], #-24
	cmp	w8, w22
	b.hs	LBB45_4
; %bb.6:                                ;   in Loop: Header=BB45_5 Depth=1
	ldr	x9, [x21, #232]
	ldr	x0, [x9, x8, lsl #3]
	cbz	x0, LBB45_4
; %bb.7:                                ;   in Loop: Header=BB45_5 Depth=1
	mov	x1, x20
	bl	_strcmp
	cbnz	w0, LBB45_4
LBB45_8:
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_append_code        ; -- Begin function nvm_append_code
	.globl	_nvm_append_code
	.p2align	2
_nvm_append_code:                       ; @nvm_append_code
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	cbz	w2, LBB46_7
; %bb.1:
	mov	x20, x2
	ldr	w21, [x19, #288]
	ldr	w22, [x19, #292]
	ldr	x0, [x19, #280]
	add	w8, w21, w2
	cmp	w8, w22
	b.ls	LBB46_6
; %bb.2:
	mov	x23, x1
LBB46_3:                                ; =>This Inner Loop Header: Depth=1
	lsl	w22, w22, #1
	mov	x1, x22
	bl	_realloc
	cbz	x0, LBB46_8
; %bb.4:                                ;   in Loop: Header=BB46_3 Depth=1
	str	x0, [x19, #280]
	str	w22, [x19, #292]
	ldr	w21, [x19, #288]
	add	w8, w21, w20
	cmp	w8, w22
	b.hi	LBB46_3
; %bb.5:
	mov	x1, x23
LBB46_6:
	add	x0, x0, w21, uxtw
	mov	w2, w20
	bl	_memcpy
	ldr	w8, [x19, #288]
	add	w8, w8, w20
	str	w8, [x19, #288]
	b	LBB46_9
LBB46_7:
	ldr	w21, [x19, #288]
	b	LBB46_9
LBB46_8:
	mov	w21, #0                         ; =0x0
LBB46_9:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_debug_entry    ; -- Begin function nvm_add_debug_entry
	.globl	_nvm_add_debug_entry
	.p2align	2
_nvm_add_debug_entry:                   ; @nvm_add_debug_entry
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB47_9
; %bb.1:
	ldr	w9, [x0, #384]
	cmn	w9, #1
	b.eq	LBB47_8
; %bb.2:
	ldr	w8, [x0, #388]
	cmp	w9, w8
	b.hs	LBB47_4
; %bb.3:
	ldr	x8, [x0, #376]
	b	LBB47_7
LBB47_4:
	mov	w9, #16                         ; =0x10
	cmp	w8, #0
	csel	w8, w9, w8, eq
	tbnz	w8, #31, LBB47_8
; %bb.5:
	mov	x19, x1
	mov	x20, x2
	mov	x21, x3
	lsl	w22, w8, #1
	mov	w8, #12                         ; =0xc
	umull	x1, w22, w8
	mov	x23, x0
	ldr	x0, [x0, #376]
	bl	_realloc
	cbz	x0, LBB47_9
; %bb.6:
	mov	x8, x0
	mov	x0, x23
	str	x8, [x23, #376]
	str	w22, [x23, #388]
	ldr	w9, [x23, #384]
	mov	x3, x21
	mov	x2, x20
	mov	x1, x19
LBB47_7:
	mov	w10, #12                        ; =0xc
	umaddl	x8, w9, w10, x8
	stp	w1, w2, [x8]
	str	w3, [x8, #8]
	add	w8, w9, #1
	str	w8, [x0, #384]
	mov	w0, #1                          ; =0x1
	b	LBB47_9
LBB47_8:
	mov	w0, #0                          ; =0x0
LBB47_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_strip_debug_info   ; -- Begin function nvm_strip_debug_info
	.globl	_nvm_strip_debug_info
	.p2align	2
_nvm_strip_debug_info:                  ; @nvm_strip_debug_info
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB48_13
; %bb.1:
	ldr	w11, [x0, #368]
	cbz	w11, LBB48_11
; %bb.2:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	mov	x12, #24942                     ; =0x616e
	movk	x12, #28526, lsl #16
	movk	x12, #29486, lsl #32
	movk	x12, #30063, lsl #48
	mov	x13, #25458                     ; =0x6372
	movk	x13, #24421, lsl #16
	movk	x13, #26982, lsl #32
	movk	x13, #25964, lsl #48
LBB48_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x14, [x0, #360]
	ldr	w15, [x14, x8]
	ldr	w16, [x0, #248]
	cmp	w15, w16
	b.hs	LBB48_9
; %bb.4:                                ;   in Loop: Header=BB48_3 Depth=1
	ldr	x16, [x0, #232]
	cbz	x16, LBB48_9
; %bb.5:                                ;   in Loop: Header=BB48_3 Depth=1
	ldr	x17, [x0, #240]
	cbz	x17, LBB48_9
; %bb.6:                                ;   in Loop: Header=BB48_3 Depth=1
	ldr	x16, [x16, x15, lsl #3]
	cbz	x16, LBB48_9
; %bb.7:                                ;   in Loop: Header=BB48_3 Depth=1
	ldr	w15, [x17, x15, lsl #2]
	cmp	w15, #16
	b.ne	LBB48_9
; %bb.8:                                ;   in Loop: Header=BB48_3 Depth=1
	ldp	x15, x16, [x16]
	cmp	x15, x12
	ccmp	x16, x13, #0, eq
	b.eq	LBB48_10
LBB48_9:                                ;   in Loop: Header=BB48_3 Depth=1
	ldr	x11, [x14, x8]
	str	x11, [x14, w10, uxtw #3]
	add	w10, w10, #1
	ldr	w11, [x0, #368]
LBB48_10:                               ;   in Loop: Header=BB48_3 Depth=1
	add	x9, x9, #1
	add	x8, x8, #8
	cmp	x9, x11
	b.lo	LBB48_3
	b	LBB48_12
LBB48_11:
	mov	w10, #0                         ; =0x0
LBB48_12:
	str	w10, [x0, #368]
	str	wzr, [x0, #384]
	str	wzr, [x0, #392]
	ldr	w8, [x0, #8]
	and	w8, w8, #0xfffffffb
	str	w8, [x0, #8]
LBB48_13:
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_import         ; -- Begin function nvm_add_import
	.globl	_nvm_add_import
	.p2align	2
_nvm_add_import:                        ; @nvm_add_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB49_13
; %bb.1:
	mov	x19, x0
	ldr	w20, [x0, #432]
	ldr	w8, [x0, #436]
	cmp	w20, w8
	b.hs	LBB49_3
; %bb.2:
	ldr	x21, [x19, #400]
	b	LBB49_9
LBB49_3:
	tbnz	w8, #31, LBB49_13
; %bb.4:
	str	w1, [sp, #12]                   ; 4-byte Folded Spill
	mov	x25, x2
	mov	x26, x4
	mov	x27, x3
	mov	x28, x5
	lsl	w9, w8, #1
	mov	w10, #16                        ; =0x10
	cmp	w8, #0
	csel	w24, w10, w9, eq
	add	x8, x24, w24, uxtw #1
	lsl	x0, x8, #2
	bl	_malloc
	mov	x21, x0
	ubfiz	x0, x24, #3, #32
	bl	_malloc
	mov	x22, x0
	cmp	x21, #0
	ccmp	x0, #0, #4, ne
	b.ne	LBB49_6
; %bb.5:
	mov	x0, x21
	bl	_free
	mov	x0, x22
	bl	_free
	b	LBB49_13
LBB49_6:
	ldr	x23, [x19, #400]
	cbz	w20, LBB49_8
; %bb.7:
	add	x8, x20, x20, lsl #1
	lsl	x2, x8, #2
	mov	x0, x21
	mov	x1, x23
	bl	_memcpy
	ldr	x1, [x19, #408]
	lsl	x2, x20, #3
	mov	x0, x22
	bl	_memcpy
LBB49_8:
	mov	x0, x23
	bl	_free
	ldr	x0, [x19, #408]
	bl	_free
	stp	x21, x22, [x19, #400]
	str	w24, [x19, #436]
	ldr	w20, [x19, #432]
	mov	x5, x28
	mov	x3, x27
	mov	x4, x26
	mov	x2, x25
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
LBB49_9:
	mov	w8, #12                         ; =0xc
	umaddl	x8, w20, w8, x21
	stp	w1, w2, [x8]
	strh	w3, [x8, #8]
	strb	w4, [x8, #10]
	strb	wzr, [x8, #11]
	cbz	w3, LBB49_14
; %bb.10:
	cbz	x5, LBB49_14
; %bb.11:
	mov	x22, x5
	mov	w21, w3
	mov	x0, x21
	bl	_malloc
	ldr	x8, [x19, #408]
	str	x0, [x8, w20, uxtw #3]
	cbz	x0, LBB49_13
; %bb.12:
	mov	x1, x22
	mov	x2, x21
	bl	_memcpy
	b	LBB49_15
LBB49_13:
	mov	w20, #-1                        ; =0xffffffff
	b	LBB49_16
LBB49_14:
	ldr	x8, [x19, #408]
	str	xzr, [x8, w20, uxtw #3]
LBB49_15:
	add	w8, w20, #1
	str	w8, [x19, #432]
LBB49_16:
	mov	x0, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_validate_header    ; -- Begin function nvm_validate_header
	.globl	_nvm_validate_header
	.p2align	2
_nvm_validate_header:                   ; @nvm_validate_header
	.cfi_startproc
; %bb.0:
	ldrb	w8, [x0]
	cmp	w8, #78
	b.ne	LBB50_6
; %bb.1:
	ldrb	w8, [x0, #1]
	cmp	w8, #86
	b.ne	LBB50_6
; %bb.2:
	ldrb	w8, [x0, #2]
	cmp	w8, #77
	b.ne	LBB50_6
; %bb.3:
	ldrb	w8, [x0, #3]
	cmp	w8, #1
	b.ne	LBB50_6
; %bb.4:
	ldr	w8, [x0, #4]
	cmp	w8, #2
	b.ne	LBB50_6
; %bb.5:
	ldr	w8, [x0, #16]
	cmp	w8, #17
	cset	w0, lo
	ret
LBB50_6:
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_add_module_ref     ; -- Begin function nvm_add_module_ref
	.globl	_nvm_add_module_ref
	.p2align	2
_nvm_add_module_ref:                    ; @nvm_add_module_ref
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB51_4
; %bb.1:
	mov	x8, x0
	ldr	w9, [x0, #248]
	cmp	w1, w9
	b.hs	LBB51_4
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	w0, [x8, #448]
	ldr	w9, [x8, #452]
	cmp	w0, w9
	b.hs	LBB51_5
; %bb.3:
	ldr	x9, [x8, #440]
	b	LBB51_7
LBB51_4:
	mov	w0, #-1                         ; =0xffffffff
	ret
LBB51_5:
	mov	x19, x1
	lsl	w20, w9, #1
	mov	x21, x8
	ldr	x0, [x8, #440]
	ubfiz	x1, x20, #2, #32
	bl	_realloc
	cbz	x0, LBB51_9
; %bb.6:
	mov	x9, x0
	mov	x8, x21
	str	x0, [x21, #440]
	str	w20, [x21, #452]
	ldr	w0, [x21, #448]
	mov	x1, x19
LBB51_7:
	add	w10, w0, #1
	str	w10, [x8, #448]
	str	w1, [x9, w0, uxtw #2]
LBB51_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB51_9:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB51_8
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_file_instructions_present ; -- Begin function nvm_file_instructions_present
	.globl	_nvm_file_instructions_present
	.p2align	2
_nvm_file_instructions_present:         ; @nvm_file_instructions_present
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB52_12
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldr	x8, [x0, #256]
	cbz	x8, LBB52_10
; %bb.2:
	ldr	x8, [x19, #280]
	cbz	x8, LBB52_10
; %bb.3:
	ldr	w8, [x19, #272]
	cbz	w8, LBB52_10
; %bb.4:
	mov	x20, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB52_6
LBB52_5:                                ;   in Loop: Header=BB52_6 Depth=1
	add	x21, x21, #1
	add	x20, x20, #24
	cmp	x21, x8
	b.hs	LBB52_10
LBB52_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19, #256]
	add	x10, x9, x20
	ldr	w9, [x10, #8]
	ldr	w11, [x19, #288]
	cmp	w11, w9
	b.lo	LBB52_5
; %bb.7:                                ;   in Loop: Header=BB52_6 Depth=1
	ldr	w1, [x10, #12]
	sub	w10, w11, w9
	cmp	w1, w10
	b.hi	LBB52_5
; %bb.8:                                ;   in Loop: Header=BB52_6 Depth=1
	ldr	x8, [x19, #280]
	add	x0, x8, x9
	bl	_isa_code_has_file_instructions
	tbnz	w0, #0, LBB52_13
; %bb.9:                                ;   in Loop: Header=BB52_6 Depth=1
	ldr	w8, [x19, #272]
	b	LBB52_5
LBB52_10:
	mov	w0, #0                          ; =0x0
LBB52_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB52_12:
	ret
LBB52_13:
	mov	w0, #1                          ; =0x1
	b	LBB52_11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_serialize
lCPI53_0:
	.byte	0                               ; 0x0
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	12                              ; 0xc
	.byte	16                              ; 0x10
	.byte	20                              ; 0x14
	.byte	24                              ; 0x18
	.byte	28                              ; 0x1c
	.byte	32                              ; 0x20
	.byte	36                              ; 0x24
	.byte	40                              ; 0x28
	.byte	44                              ; 0x2c
	.byte	48                              ; 0x30
	.byte	52                              ; 0x34
	.byte	56                              ; 0x38
	.byte	60                              ; 0x3c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI53_1:
	.byte	78                              ; 0x4e
	.byte	86                              ; 0x56
	.byte	77                              ; 0x4d
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_serialize
	.globl	_nvm_serialize
	.p2align	2
_nvm_serialize:                         ; @nvm_serialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x1
	mov	x20, x0
	cbz	x0, LBB53_10
; %bb.1:
	ldr	x8, [x20, #256]
	cbz	x8, LBB53_10
; %bb.2:
	ldr	x8, [x20, #280]
	cbz	x8, LBB53_10
; %bb.3:
	ldr	w8, [x20, #272]
	cbz	w8, LBB53_10
; %bb.4:
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	b	LBB53_6
LBB53_5:                                ;   in Loop: Header=BB53_6 Depth=1
	add	x22, x22, #1
	add	x21, x21, #24
	cmp	x22, x8
	b.hs	LBB53_10
LBB53_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20, #256]
	add	x10, x9, x21
	ldr	w9, [x10, #8]
	ldr	w11, [x20, #288]
	cmp	w11, w9
	b.lo	LBB53_5
; %bb.7:                                ;   in Loop: Header=BB53_6 Depth=1
	ldr	w1, [x10, #12]
	sub	w10, w11, w9
	cmp	w1, w10
	b.hi	LBB53_5
; %bb.8:                                ;   in Loop: Header=BB53_6 Depth=1
	ldr	x8, [x20, #280]
	add	x0, x8, x9
	bl	_isa_code_has_file_instructions
	tbnz	w0, #0, LBB53_17
; %bb.9:                                ;   in Loop: Header=BB53_6 Depth=1
	ldr	w8, [x20, #272]
	b	LBB53_5
LBB53_10:
	ldr	x8, [x20, #328]
	cbnz	x8, LBB53_17
; %bb.11:
	ldr	w8, [x20, #336]
	cbnz	w8, LBB53_17
; %bb.12:
	ldr	w8, [x20, #368]
	cbnz	w8, LBB53_17
; %bb.13:
	ldr	w8, [x20, #424]
	cbnz	w8, LBB53_17
; %bb.14:
	ldr	w8, [x20, #352]
	cbnz	w8, LBB53_17
; %bb.15:
	ldr	w8, [x20, #320]
	cbnz	w8, LBB53_17
; %bb.16:
	ldr	w8, [x20, #304]
	cbz	w8, LBB53_21
LBB53_17:
	mov	x0, #0                          ; =0x0
	cbz	x19, LBB53_20
; %bb.18:
	mov	w22, #0                         ; =0x0
LBB53_19:
	str	w22, [x19]
LBB53_20:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB53_21:
	ldr	w25, [x20, #432]
	cbz	w25, LBB53_25
; %bb.22:
	ldr	x8, [x20, #400]
	add	x8, x8, #11
	mov	x9, x25
LBB53_23:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x8], #12
	cbnz	w10, LBB53_17
; %bb.24:                               ;   in Loop: Header=BB53_23 Depth=1
	subs	x9, x9, #1
	b.ne	LBB53_23
LBB53_25:
	ldr	w26, [x20, #248]
	cmp	x26, #0
	cset	w8, ne
	ldr	w21, [x20, #288]
	ldr	w13, [x20, #272]
	cmp	w26, #0
	mov	w9, #1                          ; =0x1
	cinc	w9, w9, ne
	cmp	w21, #0
	csel	w8, w8, w9, eq
	cmp	w13, #0
	ldr	w12, [x20, #384]
	cinc	w8, w8, ne
	cmp	w12, #0
	cinc	w8, w8, ne
	cmp	w25, #0
	ldr	w0, [x20, #448]
	cinc	w8, w8, ne
	cmp	w0, #0
	cinc	w17, w8, ne
	cbz	w26, LBB53_28
; %bb.26:
	ldr	x8, [x20, #240]
	cmp	w26, #4
	b.hs	LBB53_29
; %bb.27:
	mov	x9, #0                          ; =0x0
	mov	w24, #0                         ; =0x0
	b	LBB53_38
LBB53_28:
	mov	w24, #0                         ; =0x0
	b	LBB53_40
LBB53_29:
	cmp	w26, #16
	b.hs	LBB53_31
; %bb.30:
	mov	x9, #0                          ; =0x0
	mov	w24, #0                         ; =0x0
	b	LBB53_35
LBB53_31:
	and	x9, x26, #0xfffffff0
	add	x10, x8, #32
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #4
	mov	x11, x9
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB53_32:                               ; =>This Inner Loop Header: Depth=1
	ldp	q5, q6, [x10, #-32]
	ldp	q7, q16, [x10], #64
	add.4s	v0, v0, v1
	add.4s	v0, v0, v5
	add.4s	v2, v2, v1
	add.4s	v2, v2, v6
	add.4s	v3, v3, v1
	add.4s	v3, v3, v7
	add.4s	v4, v4, v1
	add.4s	v4, v4, v16
	subs	x11, x11, #16
	b.ne	LBB53_32
; %bb.33:
	add.4s	v0, v2, v0
	add.4s	v0, v3, v0
	add.4s	v0, v4, v0
	addv.4s	s0, v0
	fmov	w24, s0
	cmp	x9, x26
	b.eq	LBB53_40
; %bb.34:
	tst	x26, #0xc
	b.eq	LBB53_38
LBB53_35:
	mov	x11, x9
	and	x9, x26, #0xfffffffc
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w24
	sub	x10, x11, x9
	add	x11, x8, x11, lsl #2
	movi.4s	v1, #4
LBB53_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	q2, [x11], #16
	add.4s	v0, v0, v1
	add.4s	v0, v0, v2
	adds	x10, x10, #4
	b.ne	LBB53_36
; %bb.37:
	addv.4s	s0, v0
	fmov	w24, s0
	cmp	x9, x26
	b.eq	LBB53_40
LBB53_38:
	sub	x10, x26, x9
	add	x8, x8, x9, lsl #2
LBB53_39:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x8], #4
	add	w9, w24, w9
	add	w24, w9, #4
	subs	x10, x10, #1
	b.ne	LBB53_39
LBB53_40:
	add	w8, w13, w13, lsl #2
	lsl	w2, w8, #2
	add	w8, w12, w12, lsl #1
	lsl	w1, w8, #2
	stp	w0, w17, [sp, #32]              ; 8-byte Folded Spill
	stp	w13, w12, [sp, #24]             ; 8-byte Folded Spill
	stp	w2, w1, [sp, #8]                ; 8-byte Folded Spill
	cbz	w25, LBB53_43
; %bb.41:
	ldr	x8, [x20, #400]
	cmp	w25, #9
	b.hs	LBB53_44
; %bb.42:
	mov	x9, #0                          ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB53_52
LBB53_43:
	mov	w27, #0                         ; =0x0
	b	LBB53_54
LBB53_44:
	cmp	w25, #33
	b.hs	LBB53_46
; %bb.45:
	mov	x9, #0                          ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB53_49
LBB53_46:
	ands	x9, x25, #0x1f
	movi.2d	v1, #0000000000000000
	movi.4s	v0, #11
	mov	w10, #32                        ; =0x20
	movi.2d	v2, #0000000000000000
	csel	x10, x10, x9, eq
	sub	x9, x25, x10
	add	x11, x8, #200
	mov	x12, x25
	movi.2d	v16, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB53_47:                               ; =>This Inner Loop Header: Depth=1
	sub	x15, x11, #180
	sub	x0, x11, #168
	sub	x7, x11, #156
	sub	x13, x11, #132
	sub	x22, x11, #120
	sub	x23, x11, #108
	sub	x2, x11, #84
	sub	x6, x11, #72
	sub	x4, x11, #60
	sub	x27, x11, #36
	sub	x28, x11, #24
	sub	x30, x11, #12
	add	x17, x11, #12
	add	x16, x11, #24
	add	x14, x11, #36
	add	x5, x11, #60
	add	x3, x11, #72
	add	x1, x11, #84
	ldur	h17, [x11, #-144]
	ld1.h	{ v17 }[1], [x13]
	add	x13, x11, #108
	ld1.h	{ v17 }[2], [x22]
	ld1.h	{ v17 }[3], [x23]
	ldur	h18, [x11, #-192]
	ld1.h	{ v18 }[1], [x15]
	ld1.h	{ v18 }[2], [x0]
	ld1.h	{ v18 }[3], [x7]
	add	x15, x11, #120
	ldur	h19, [x11, #-48]
	ld1.h	{ v19 }[1], [x27]
	ld1.h	{ v19 }[2], [x28]
	add	x0, x11, #132
	ld1.h	{ v19 }[3], [x30]
	ldur	h20, [x11, #-96]
	ld1.h	{ v20 }[1], [x2]
	add	x2, x11, #156
	ld1.h	{ v20 }[2], [x6]
	ld1.h	{ v20 }[3], [x4]
	ldr	h21, [x11, #48]
	ld1.h	{ v21 }[1], [x5]
	ld1.h	{ v21 }[2], [x3]
	ld1.h	{ v21 }[3], [x1]
	add	x1, x11, #168
	ldr	h22, [x11]
	ld1.h	{ v22 }[1], [x17]
	ld1.h	{ v22 }[2], [x16]
	add	x16, x11, #180
	ld1.h	{ v22 }[3], [x14]
	ldr	h23, [x11, #96]
	ld1.h	{ v23 }[1], [x13]
	uaddw.4s	v1, v1, v18
	uaddw.4s	v2, v2, v17
	uaddw.4s	v16, v16, v20
	uaddw.4s	v4, v4, v19
	uaddw.4s	v6, v6, v22
	uaddw.4s	v7, v7, v21
	ld1.h	{ v23 }[2], [x15]
	ld1.h	{ v23 }[3], [x0]
	uaddw.4s	v5, v5, v23
	ldr	h17, [x11, #144]
	ld1.h	{ v17 }[1], [x2]
	ld1.h	{ v17 }[2], [x1]
	ld1.h	{ v17 }[3], [x16]
	uaddw.4s	v3, v3, v17
	add.4s	v2, v2, v0
	add.4s	v1, v1, v0
	add.4s	v4, v4, v0
	add.4s	v16, v16, v0
	add.4s	v7, v7, v0
	add.4s	v6, v6, v0
	add.4s	v3, v3, v0
	add.4s	v5, v5, v0
	sub	x12, x12, #32
	add	x11, x11, #384
	cmp	x10, x12
	b.ne	LBB53_47
; %bb.48:
	add.4s	v0, v16, v1
	add.4s	v1, v4, v2
	add.4s	v1, v7, v1
	add.4s	v0, v6, v0
	add.4s	v0, v5, v0
	add.4s	v1, v3, v1
	add.4s	v0, v0, v1
	addv.4s	s0, v0
	fmov	w27, s0
	cmp	x10, #9
	ldp	w0, w17, [sp, #32]              ; 8-byte Folded Reload
	ldp	w2, w1, [sp, #8]                ; 8-byte Folded Reload
	b.lo	LBB53_52
LBB53_49:
	mov	x11, x9
	ands	x9, x25, #0x7
	mov	w10, #8                         ; =0x8
	csel	x12, x10, x9, eq
	mov	w9, #12                         ; =0xc
	madd	x10, x11, x9, x8
	sub	x9, x25, x12
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.s	v1[0], w27
	add	x10, x10, #56
	add	x11, x12, x11
	sub	x11, x11, x25
	movi.4s	v2, #11
LBB53_50:                               ; =>This Inner Loop Header: Depth=1
	sub	x12, x10, #36
	sub	x13, x10, #24
	sub	x14, x10, #12
	add	x15, x10, #12
	add	x16, x10, #24
	ldr	h3, [x10]
	ld1.h	{ v3 }[1], [x15]
	add	x15, x10, #36
	ld1.h	{ v3 }[2], [x16]
	ld1.h	{ v3 }[3], [x15]
	ldur	h4, [x10, #-48]
	ld1.h	{ v4 }[1], [x12]
	ld1.h	{ v4 }[2], [x13]
	ld1.h	{ v4 }[3], [x14]
	uaddw.4s	v1, v1, v4
	uaddw.4s	v0, v0, v3
	add.4s	v0, v0, v2
	add.4s	v1, v1, v2
	add	x10, x10, #96
	adds	x11, x11, #8
	b.ne	LBB53_50
; %bb.51:
	add.4s	v0, v1, v0
	addv.4s	s0, v0
	fmov	w27, s0
LBB53_52:
	sub	x10, x25, x9
	mov	w11, #12                        ; =0xc
	madd	x8, x9, x11, x8
	add	x8, x8, #8
LBB53_53:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w9, [x8], #12
	add	w9, w27, w9
	add	w27, w9, #11
	subs	x10, x10, #1
	b.ne	LBB53_53
LBB53_54:
	lsl	w28, w0, #2
	add	w8, w17, w17, lsl #1
	lsl	w9, w8, #2
	add	w8, w2, w21
	add	w8, w8, w1
	add	w8, w8, w28
	add	w8, w8, w24
	add	w23, w9, #32
	add	w8, w8, w27
	stp	w8, w9, [sp, #16]               ; 8-byte Folded Spill
	add	w22, w8, w23
	mov	w0, #1                          ; =0x1
	mov	x1, x22
	bl	_calloc
	cbz	x0, LBB53_20
; %bb.55:
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	cbz	w26, LBB53_57
; %bb.56:
	movi.2s	v0, #2
	str	s0, [x0, #32]
	str	w23, [sp, #4]                   ; 4-byte Folded Spill
	strb	w23, [x0, #36]
	sturh	wzr, [x0, #37]
	lsr	w8, w24, #8
	strb	wzr, [x0, #39]
	strb	w24, [x0, #40]
	strb	w8, [x0, #41]
	lsr	w8, w24, #16
	lsr	w9, w24, #24
	strb	w8, [x0, #42]
	add	x1, x0, w23, uxtw
	strb	w9, [x0, #43]
	mov	x0, x20
	bl	_serialize_string_pool
	add	w23, w24, w23
	mov	w26, #44                        ; =0x2c
	b	LBB53_58
LBB53_57:
	str	wzr, [sp, #4]                   ; 4-byte Folded Spill
	mov	w24, #0                         ; =0x0
	mov	w26, #32                        ; =0x20
LBB53_58:
	cbz	w21, LBB53_60
; %bb.59:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x8, w26, uxtw
	movi.2s	v0, #1
	str	s0, [x9]
	strb	w23, [x9, #4]
	lsr	w10, w23, #8
	strb	w10, [x9, #5]
	lsr	w10, w23, #16
	strb	w10, [x9, #6]
	lsr	w10, w23, #24
	strb	w10, [x9, #7]
	strb	w21, [x9, #8]
	lsr	w10, w21, #8
	strb	w10, [x9, #9]
	lsr	w10, w21, #16
	strb	w10, [x9, #10]
	lsr	w10, w21, #24
	add	w26, w26, #12
	strb	w10, [x9, #11]
	ldr	x1, [x20, #280]
	add	x0, x8, w23, uxtw
	mov	x2, x21
	bl	_memcpy
	add	w23, w23, w21
LBB53_60:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	cbz	w8, LBB53_62
; %bb.61:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x8, w26, uxtw
	movi.2s	v0, #3
	str	s0, [x9]
	strb	w23, [x9, #4]
	lsr	w10, w23, #8
	strb	w10, [x9, #5]
	lsr	w10, w23, #16
	strb	w10, [x9, #6]
	lsr	w10, w23, #24
	strb	w10, [x9, #7]
	ldr	w21, [sp, #8]                   ; 4-byte Folded Reload
	strb	w21, [x9, #8]
	lsr	w10, w21, #8
	strb	w10, [x9, #9]
	lsr	w10, w21, #16
	strb	w10, [x9, #10]
	lsr	w10, w21, #24
	add	w26, w26, #12
	strb	w10, [x9, #11]
	add	x1, x8, w23, uxtw
	mov	x0, x20
	bl	_serialize_functions
	add	w23, w23, w21
LBB53_62:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	cbz	w8, LBB53_64
; %bb.63:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x8, w26, uxtw
	movi.2s	v0, #9
	str	s0, [x9]
	strb	w23, [x9, #4]
	lsr	w10, w23, #8
	strb	w10, [x9, #5]
	lsr	w10, w23, #16
	strb	w10, [x9, #6]
	lsr	w10, w23, #24
	strb	w10, [x9, #7]
	ldr	w21, [sp, #12]                  ; 4-byte Folded Reload
	strb	w21, [x9, #8]
	lsr	w10, w21, #8
	strb	w10, [x9, #9]
	lsr	w10, w21, #16
	strb	w10, [x9, #10]
	lsr	w10, w21, #24
	add	w26, w26, #12
	strb	w10, [x9, #11]
	add	x1, x8, w23, uxtw
	mov	x0, x20
	bl	_serialize_debug
	add	w23, w23, w21
LBB53_64:
	cbz	w25, LBB53_66
; %bb.65:
	ldr	x21, [sp, #40]                  ; 8-byte Folded Reload
	add	x8, x21, w26, uxtw
	movi.2s	v0, #8
	str	s0, [x8]
	strb	w23, [x8, #4]
	lsr	w9, w23, #8
	strb	w9, [x8, #5]
	lsr	w9, w23, #16
	strb	w9, [x8, #6]
	lsr	w9, w23, #24
	strb	w9, [x8, #7]
	strb	w27, [x8, #8]
	lsr	w9, w27, #8
	strb	w9, [x8, #9]
	lsr	w9, w27, #16
	strb	w9, [x8, #10]
	lsr	w9, w27, #24
	add	w26, w26, #12
	strb	w9, [x8, #11]
	add	x1, x21, w23, uxtw
	mov	x0, x20
	bl	_serialize_imports
	mov	x8, x21
	add	w23, w23, w27
	b	LBB53_67
LBB53_66:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
LBB53_67:
	ldr	w9, [sp, #32]                   ; 4-byte Folded Reload
	cbz	w9, LBB53_80
; %bb.68:
	add	x9, x8, w26, uxtw
	movi.2s	v0, #11
	str	s0, [x9]
	strb	w23, [x9, #4]
	lsr	w10, w23, #8
	strb	w10, [x9, #5]
	lsr	w10, w23, #16
	strb	w10, [x9, #6]
	lsr	w10, w23, #24
	strb	w10, [x9, #7]
	strb	w28, [x9, #8]
	lsr	w10, w28, #8
	strb	w10, [x9, #9]
	lsr	w10, w28, #16
	strb	w10, [x9, #10]
	lsr	w10, w28, #24
	strb	w10, [x9, #11]
	ldr	w9, [x20, #448]
	cbz	w9, LBB53_80
; %bb.69:
	ldr	x10, [x20, #440]
	cmp	w9, #8
	b.hs	LBB53_71
; %bb.70:
	mov	x11, #0                         ; =0x0
	mov	x12, x23
	b	LBB53_78
LBB53_71:
	mov	x11, #0                         ; =0x0
	sub	x8, x9, #1
	cmn	w23, w8, lsl #2
	b.hs	LBB53_76
; %bb.72:
	lsr	x8, x8, #30
	cbnz	x8, LBB53_76
; %bb.73:
	lsl	x8, x9, #2
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	add	x11, x11, w23, uxtw
	add	x12, x11, x8
	cmp	x10, x12
	b.hs	LBB53_81
; %bb.74:
	add	x8, x10, x8
	cmp	x11, x8
	b.hs	LBB53_81
; %bb.75:
	mov	x11, #0                         ; =0x0
LBB53_76:
	mov	x12, x23
LBB53_77:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
LBB53_78:
	add	x10, x10, x11, lsl #2
	sub	x9, x9, x11
LBB53_79:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x10], #4
	str	w11, [x8, w12, uxtw]
	add	w12, w12, #4
	subs	x9, x9, #1
	b.ne	LBB53_79
LBB53_80:
Lloh60:
	adrp	x9, lCPI53_1@PAGE
Lloh61:
	ldr	d0, [x9, lCPI53_1@PAGEOFF]
	str	d0, [x8]
	ldp	w9, w10, [x20, #8]
	str	w9, [x8, #8]
	strb	w10, [x8, #12]
	lsr	w9, w10, #8
	strb	w9, [x8, #13]
	lsr	w9, w10, #16
	strb	w9, [x8, #14]
	lsr	w9, w10, #24
	strb	w9, [x8, #15]
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	strb	w9, [x8, #16]
	sturh	wzr, [x8, #17]
	strb	wzr, [x8, #19]
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	strb	w9, [x8, #20]
	sturh	wzr, [x8, #21]
	strb	wzr, [x8, #23]
	strb	w24, [x8, #24]
	lsr	w9, w24, #8
	strb	w9, [x8, #25]
	lsr	w9, w24, #16
	strb	w9, [x8, #26]
	lsr	w9, w24, #24
	strb	w9, [x8, #27]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x0, x8, #32
	ldp	w9, w8, [sp, #16]               ; 8-byte Folded Reload
	add	w1, w9, w8
	bl	_nvm_crc32
	mov	x8, x0
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	str	w8, [x0, #28]
	b	LBB53_19
LBB53_81:
	cmp	w9, #16
	b.hs	LBB53_86
; %bb.82:
	mov	x11, #0                         ; =0x0
LBB53_83:
	mov	x8, x11
	and	x11, x9, #0x7ffffff8
	add	w12, w23, w11, lsl #2
	sub	x13, x8, x11
	add	x14, x10, x8, lsl #2
Lloh62:
	adrp	x15, lCPI53_0@PAGE
Lloh63:
	ldr	q0, [x15, lCPI53_0@PAGEOFF]
	add	w15, w23, w8, lsl #2
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
LBB53_84:                               ; =>This Inner Loop Header: Depth=1
	add	x16, x8, w15, uxtw
	ldp	q1, q2, [x14], #32
	ushr.4s	v4, v2, #8
	ushr.4s	v3, v1, #8
	tbl.16b	v16, { v1, v2, v3, v4 }, v0
	ushr.4s	v23, v2, #24
	ushr.4s	v22, v1, #24
	ushr.4s	v21, v2, #16
	ushr.4s	v20, v1, #16
	tbl.16b	v18, { v20, v21, v22, v23 }, v0
	ext.16b	v17, v16, v16, #8
	ext.16b	v19, v18, v18, #8
	st4.8b	{ v16, v17, v18, v19 }, [x16]
	add	w15, w15, #32
	adds	x13, x13, #8
	b.ne	LBB53_84
; %bb.85:
	cmp	x11, x9
	b.ne	LBB53_78
	b	LBB53_80
LBB53_86:
	and	x11, x9, #0x7ffffff0
	mov	x12, x23
	mov	x13, x10
	mov	x14, x11
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
LBB53_87:                               ; =>This Inner Loop Header: Depth=1
	add	x15, x8, w12, uxtw
	ldp	q0, q1, [x13]
	ldp	q2, q3, [x13, #32]
	xtn.4h	v4, v3
	ushr.4h	v4, v4, #8
	xtn.4h	v5, v2
	ushr.4h	v5, v5, #8
	mov.d	v5[1], v4[0]
	xtn.4h	v4, v1
	ushr.4h	v4, v4, #8
	xtn.4h	v6, v0
	ushr.4h	v6, v6, #8
	mov.d	v6[1], v4[0]
	uzp1.16b	v5, v6, v5
	uzp1.8h	v16, v2, v3
	uzp1.8h	v17, v0, v1
	uzp1.16b	v4, v17, v16
	uzp2.8h	v2, v2, v3
	uzp2.8h	v0, v0, v1
	uzp2.16b	v7, v0, v2
	uzp1.16b	v6, v0, v2
	st4.16b	{ v4, v5, v6, v7 }, [x15]
	add	x13, x13, #64
	add	w12, w12, #64
	subs	x14, x14, #16
	b.ne	LBB53_87
; %bb.88:
	cmp	x11, x9
	b.eq	LBB53_80
; %bb.89:
	tbnz	w9, #3, LBB53_83
; %bb.90:
	add	w12, w23, w11, lsl #2
	b	LBB53_77
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_string_pool
_serialize_string_pool:                 ; @serialize_string_pool
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #248]
	cbz	w8, LBB54_4
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	mov	x21, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	ldr	x8, [x0, #240]
LBB54_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x8, x21, lsl #2]
	str	w8, [x19, w9, uxtw]
	add	w22, w9, #4
	ldp	x8, x9, [x20, #232]
	ldr	x1, [x8, x21, lsl #3]
	ldr	w2, [x9, x21, lsl #2]
	add	x0, x19, x22
	bl	_memcpy
	ldr	x8, [x20, #240]
	ldr	w9, [x8, x21, lsl #2]
	add	w9, w9, w22
	add	x21, x21, #1
	ldr	w10, [x20, #248]
	cmp	x21, x10
	b.lo	LBB54_2
; %bb.3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB54_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_functions
_serialize_functions:                   ; @serialize_functions
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #272]
	cbz	w8, LBB55_3
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
LBB55_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x0, #256]
	add	x11, x11, x8
	ldr	w12, [x11]
	str	w12, [x1, w10, uxtw]
	add	w12, w10, #4
	ldrh	w13, [x11, #4]
	strh	w13, [x1, w12, uxtw]
	add	w12, w10, #6
	ldr	w13, [x11, #8]
	str	w13, [x1, w12, uxtw]
	add	w12, w10, #10
	ldr	w13, [x11, #12]
	str	w13, [x1, w12, uxtw]
	add	w12, w10, #14
	ldrh	w13, [x11, #16]
	strh	w13, [x1, w12, uxtw]
	add	w12, w10, #16
	ldrh	w13, [x11, #18]
	strh	w13, [x1, w12, uxtw]
	add	w12, w10, #18
	ldrb	w13, [x11, #20]
	add	w14, w10, #19
	strb	w13, [x1, w12, uxtw]
	ldrb	w11, [x11, #21]
	add	w10, w10, #20
	strb	w11, [x1, w14, uxtw]
	add	x9, x9, #1
	ldr	w11, [x0, #272]
	add	x8, x8, #24
	cmp	x9, x11
	b.lo	LBB55_2
LBB55_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_debug
_serialize_debug:                       ; @serialize_debug
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #384]
	cbz	w8, LBB56_3
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
LBB56_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x0, #376]
	ldr	w10, [x10, x8]
	str	w10, [x1, w8, uxtw]
	add	w10, w8, #4
	ldr	x11, [x0, #376]
	add	x11, x11, x8
	ldr	w11, [x11, #4]
	str	w11, [x1, w10, uxtw]
	add	w10, w8, #8
	ldr	x11, [x0, #376]
	add	x11, x11, x8
	ldr	w11, [x11, #8]
	str	w11, [x1, w10, uxtw]
	add	x9, x9, #1
	ldr	w10, [x0, #384]
	add	x8, x8, #12
	cmp	x9, x10
	b.lo	LBB56_2
LBB56_3:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function serialize_imports
_serialize_imports:                     ; @serialize_imports
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #432]
	cbz	w8, LBB57_6
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	mov	x20, x0
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	w8, #0                          ; =0x0
	b	LBB57_3
LBB57_2:                                ;   in Loop: Header=BB57_3 Depth=1
	ldrh	w8, [x23, #8]
	add	w8, w24, w8
	add	x22, x22, #1
	ldr	w9, [x20, #432]
	add	x21, x21, #12
	cmp	x22, x9
	b.hs	LBB57_5
LBB57_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20, #400]
	add	x23, x9, x21
	ldr	w9, [x23]
	str	w9, [x19, w8, uxtw]
	add	w9, w8, #4
	ldr	w10, [x23, #4]
	str	w10, [x19, w9, uxtw]
	add	w9, w8, #8
	ldrh	w10, [x23, #8]
	strh	w10, [x19, w9, uxtw]
	add	w9, w8, #10
	ldrb	w10, [x23, #10]
	add	w24, w8, #11
	strb	w10, [x19, w9, uxtw]
	ldr	x8, [x20, #408]
	ldr	x1, [x8, x22, lsl #3]
	cbz	x1, LBB57_2
; %bb.4:                                ;   in Loop: Header=BB57_3 Depth=1
	add	x0, x19, w24, uxtw
	ldrh	w2, [x23, #8]
	bl	_memcpy
	b	LBB57_2
LBB57_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB57_6:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function nvm_deserialize
lCPI58_0:
	.byte	78                              ; 0x4e
	.byte	86                              ; 0x56
	.byte	77                              ; 0x4d
	.byte	1                               ; 0x1
	.space	1
	.space	1
	.space	1
	.space	1
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_deserialize
	.globl	_nvm_deserialize
	.p2align	2
_nvm_deserialize:                       ; @nvm_deserialize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	d9, d8, [sp, #240]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #272]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x8, x1
Lloh64:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh65:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh66:
	ldr	x9, [x9]
	stur	x9, [x29, #-112]
	subs	w1, w1, #32
	b.lo	LBB58_4
; %bb.1:
	ldr	w24, [x0, #16]
	ldp	w10, w9, [x0]
	mov	w11, #22094                     ; =0x564e
	movk	w11, #333, lsl #16
	cmp	w10, w11
	ccmp	w24, #16, #2, eq
	ccmp	w9, #2, #0, ls
	b.ne	LBB58_4
; %bb.2:
	mov	x25, x8
	ldur	q0, [x0, #8]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	ldr	d8, [x0, #24]
	ldr	w19, [x0, #28]
	mov	x26, x0
	add	x0, x0, #32
	bl	_nvm_crc32
	cmp	w0, w19
	b.ne	LBB58_4
; %bb.3:
	mov	w8, #12                         ; =0xc
	mov	w9, #32                         ; =0x20
	madd	w9, w24, w8, w9
	cmp	w9, w25
	b.ls	LBB58_7
LBB58_4:
	mov	x0, #0                          ; =0x0
LBB58_5:
	ldur	x8, [x29, #-112]
Lloh67:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh68:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh69:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB58_103
; %bb.6:
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #240]              ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
LBB58_7:
	mov	x10, x25
	cbz	w24, LBB58_25
; %bb.8:
	mov	x8, #0                          ; =0x0
	mov	w11, #0                         ; =0x0
	mov	w12, #12                        ; =0xc
	add	x13, sp, #160
	add	x14, sp, #96
	add	x15, sp, #32
	mov	x16, x26
LBB58_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB58_19 Depth 2
	madd	x1, x8, x12, x16
	ldp	w17, w0, [x1, #36]
	sub	w2, w10, w17
	cmp	w17, w9
	ccmp	w10, w17, #0, hs
	ccmp	w0, w2, #2, hs
	b.hi	LBB58_4
; %bb.10:                               ;   in Loop: Header=BB58_9 Depth=1
	ldr	w1, [x1, #32]
	cmp	w1, #3
	b.eq	LBB58_15
; %bb.11:                               ;   in Loop: Header=BB58_9 Depth=1
	cmp	w1, #11
	b.eq	LBB58_14
; %bb.12:                               ;   in Loop: Header=BB58_9 Depth=1
	cmp	w1, #9
	b.ne	LBB58_24
; %bb.13:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w2, #12                         ; =0xc
	b	LBB58_16
LBB58_14:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w2, #4                          ; =0x4
	b	LBB58_16
LBB58_15:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w2, #20                         ; =0x14
LBB58_16:                               ;   in Loop: Header=BB58_9 Depth=1
	udiv	w3, w0, w2
	msub	w2, w3, w2, w0
	cbnz	w2, LBB58_4
LBB58_17:                               ;   in Loop: Header=BB58_9 Depth=1
	cbz	w11, LBB58_21
; %bb.18:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w2, w11
	add	x3, sp, #160
	mov	x4, x2
LBB58_19:                               ;   Parent Loop BB58_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w5, [x3], #4
	cmp	w5, w1
	b.eq	LBB58_4
; %bb.20:                               ;   in Loop: Header=BB58_19 Depth=2
	subs	x4, x4, #1
	b.ne	LBB58_19
	b	LBB58_22
LBB58_21:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	x2, #0                          ; =0x0
LBB58_22:                               ;   in Loop: Header=BB58_9 Depth=1
	add	w11, w11, #1
	str	w1, [x13, x2, lsl #2]
LBB58_23:                               ;   in Loop: Header=BB58_9 Depth=1
	str	w17, [x14, x8, lsl #2]
	str	w0, [x15, x8, lsl #2]
	add	x8, x8, #1
	cmp	x8, x24
	b.ne	LBB58_9
	b	LBB58_29
LBB58_24:                               ;   in Loop: Header=BB58_9 Depth=1
	sub	w2, w1, #1
	cmp	w2, #10
	b.ls	LBB58_17
	b	LBB58_23
LBB58_25:
	cmp	w9, w10
	b.ne	LBB58_4
LBB58_26:
	bl	_nvm_module_new
	cbz	x0, LBB58_5
; %bb.27:
Lloh70:
	adrp	x8, lCPI58_0@PAGE
Lloh71:
	ldr	d0, [x8, lCPI58_0@PAGEOFF]
	str	s0, [x0]
	mov	w8, #2                          ; =0x2
	str	w8, [x0, #4]
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	stur	q0, [x0, #8]
	str	d8, [x0, #24]
	str	w24, [x0, #224]
	cbz	w24, LBB58_5
; %bb.28:
	mov	x9, x25
	mov	x10, x26
	mov	x13, #0                         ; =0x0
	add	x8, x0, #32
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	w14, #12                        ; =0xc
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB58_38
LBB58_29:
	cmp	w9, w10
	b.hs	LBB58_85
; %bb.30:
	mov	w8, #0                          ; =0x0
LBB58_31:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB58_33 Depth 2
	add	x11, sp, #96
	add	x12, sp, #32
	mov	x13, x24
	b	LBB58_33
LBB58_32:                               ;   in Loop: Header=BB58_33 Depth=2
	add	x11, x11, #4
	subs	x13, x13, #1
	b.eq	LBB58_4
LBB58_33:                               ;   Parent Loop BB58_31 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w14, [x12], #4
	cbz	w14, LBB58_32
; %bb.34:                               ;   in Loop: Header=BB58_33 Depth=2
	ldr	w15, [x11]
	cmp	w15, w9
	b.ne	LBB58_32
; %bb.35:                               ;   in Loop: Header=BB58_31 Depth=1
	add	w8, w8, #1
	add	w9, w14, w9
	cmp	w9, w10
	ccmp	w8, w24, #2, lo
	b.lo	LBB58_31
	b	LBB58_86
LBB58_36:                               ;   in Loop: Header=BB58_38 Depth=1
	add	x0, x8, w9, uxtw
	mov	x1, x21
	mov	x2, x20
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x0, #288]
	add	w8, w8, w20
	str	w8, [x0, #288]
	mov	x9, x25
	mov	x10, x26
LBB58_37:                               ;   in Loop: Header=BB58_38 Depth=1
	ldr	x13, [sp, #8]                   ; 8-byte Folded Reload
	add	x13, x13, #1
	cmp	x13, x24
	mov	w14, #12                        ; =0xc
	b.eq	LBB58_5
LBB58_38:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB58_52 Depth 2
                                        ;     Child Loop BB58_80 Depth 2
                                        ;     Child Loop BB58_65 Depth 2
                                        ;     Child Loop BB58_44 Depth 2
                                        ;     Child Loop BB58_74 Depth 2
                                        ;     Child Loop BB58_58 Depth 2
	mov	w8, #32                         ; =0x20
	madd	w8, w13, w14, w8
	add	x8, x10, x8
	ldp	w11, w20, [x8, #4]
	subs	w12, w9, w11
	ccmp	w20, w12, #2, hs
	b.hi	LBB58_90
; %bb.39:                               ;   in Loop: Header=BB58_38 Depth=1
	ldr	w8, [x8]
	ldr	x12, [sp]                       ; 8-byte Folded Reload
	madd	x12, x13, x14, x12
	stp	w8, w11, [x12]
	str	w20, [x12, #8]
	add	x21, x10, x11
	cmp	w8, #7
	str	x13, [sp, #8]                   ; 8-byte Folded Spill
	b.gt	LBB58_46
; %bb.40:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #1
	b.eq	LBB58_56
; %bb.41:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #2
	b.eq	LBB58_72
; %bb.42:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #3
	ccmp	w20, #20, #0, eq
	b.lo	LBB58_37
; %bb.43:                               ;   in Loop: Header=BB58_38 Depth=1
	mov	w19, #0                         ; =0x0
LBB58_44:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x21, w19, uxtw]
	str	w8, [sp, #160]
	add	w8, w19, #4
	ldrh	w8, [x21, w8, uxtw]
	strh	w8, [sp, #164]
	add	w8, w19, #6
	ldr	w8, [x21, w8, uxtw]
	add	w9, w19, #10
	ldr	w9, [x21, w9, uxtw]
	stp	w8, w9, [sp, #168]
	add	w8, w19, #14
	ldrh	w8, [x21, w8, uxtw]
	strh	w8, [sp, #176]
	add	w8, w19, #16
	ldrh	w8, [x21, w8, uxtw]
	strh	w8, [sp, #178]
	add	w8, w19, #18
	add	w9, w19, #19
	ldrb	w8, [x21, w8, uxtw]
	strb	w8, [sp, #180]
	ldrb	w8, [x21, w9, uxtw]
	strb	w8, [sp, #181]
	add	x1, sp, #160
	bl	_nvm_add_function
	cmn	w0, #1
	b.eq	LBB58_89
; %bb.45:                               ;   in Loop: Header=BB58_44 Depth=2
	add	w8, w19, #40
	add	w19, w19, #20
	cmp	w8, w20
	mov	x9, x25
	mov	x10, x26
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	b.ls	LBB58_44
	b	LBB58_37
LBB58_46:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #8
	b.eq	LBB58_61
; %bb.47:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #9
	b.eq	LBB58_76
; %bb.48:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w8, #11
	ccmp	w20, #0, #4, eq
	b.eq	LBB58_37
; %bb.49:                               ;   in Loop: Header=BB58_38 Depth=1
	mov	w19, #0                         ; =0x0
	b	LBB58_52
LBB58_50:                               ;   in Loop: Header=BB58_52 Depth=2
	ldr	x11, [x0, #440]
	add	w12, w8, #1
	str	w12, [x0, #448]
	str	w22, [x11, x8, lsl #2]
LBB58_51:                               ;   in Loop: Header=BB58_52 Depth=2
	add	w19, w19, #4
	cmp	w19, w20
	b.hs	LBB58_37
LBB58_52:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w22, [x21, w19, uxtw]
	ldr	w8, [x0, #248]
	cmp	w22, w8
	b.hs	LBB58_90
; %bb.53:                               ;   in Loop: Header=BB58_52 Depth=2
	ldr	w8, [x0, #448]
	ldr	w11, [x0, #452]
	cmp	w8, w11
	b.lo	LBB58_50
; %bb.54:                               ;   in Loop: Header=BB58_52 Depth=2
	lsl	w23, w11, #1
	ldr	x0, [x0, #440]
	ubfiz	x1, x23, #2, #32
	bl	_realloc
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB58_90
; %bb.55:                               ;   in Loop: Header=BB58_52 Depth=2
	mov	x9, x25
	mov	x10, x26
	str	x8, [x0, #440]
	str	w23, [x0, #452]
	ldr	w11, [x0, #448]
	adds	w12, w11, #1
	str	w12, [x0, #448]
	str	w22, [x8, x11, lsl #2]
	b.lo	LBB58_51
	b	LBB58_90
LBB58_56:                               ;   in Loop: Header=BB58_38 Depth=1
	cbz	w20, LBB58_37
; %bb.57:                               ;   in Loop: Header=BB58_38 Depth=1
	ldr	w9, [x0, #288]
	ldr	w22, [x0, #292]
	ldr	x8, [x0, #280]
LBB58_58:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w10, w9, w20
	cmp	w10, w22
	b.ls	LBB58_36
; %bb.59:                               ;   in Loop: Header=BB58_58 Depth=2
	lsl	w22, w22, #1
	mov	x0, x8
	mov	x1, x22
	bl	_realloc
	mov	x9, x25
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x10, x26
	cbz	x8, LBB58_37
; %bb.60:                               ;   in Loop: Header=BB58_58 Depth=2
	str	x8, [x0, #280]
	str	w22, [x0, #292]
	ldr	w9, [x0, #288]
	b	LBB58_58
LBB58_61:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w20, #11
	b.lo	LBB58_37
; %bb.62:                               ;   in Loop: Header=BB58_38 Depth=1
	mov	w27, #0                         ; =0x0
	ldr	w19, [x0, #432]
	ldr	x22, [x0, #400]
	mov	w28, #11                        ; =0xb
	b	LBB58_65
LBB58_63:                               ;   in Loop: Header=BB58_65 Depth=2
	ldr	x8, [x0, #408]
	str	xzr, [x8, x27, lsl #3]
LBB58_64:                               ;   in Loop: Header=BB58_65 Depth=2
	add	w27, w28, w23
	add	w19, w19, #1
	str	w19, [x0, #432]
	add	w28, w27, #11
	cmp	w28, w20
	mov	x9, x25
	mov	x10, x26
	b.hi	LBB58_37
LBB58_65:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x0, #436]
	cmp	w19, w8
	b.lo	LBB58_68
; %bb.66:                               ;   in Loop: Header=BB58_65 Depth=2
	lsl	w19, w8, #1
	add	x8, x19, w19, uxtw #1
	lsl	x1, x8, #2
	mov	x0, x22
	bl	_realloc
	mov	x22, x0
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #408]
	ubfiz	x1, x19, #3, #32
	bl	_realloc
	mov	x9, x25
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x10, x26
	cmp	x22, #0
	ccmp	x8, #0, #4, ne
	b.eq	LBB58_37
; %bb.67:                               ;   in Loop: Header=BB58_65 Depth=2
	stp	x22, x8, [x0, #400]
	str	w19, [x0, #436]
	ldr	w19, [x0, #432]
LBB58_68:                               ;   in Loop: Header=BB58_65 Depth=2
	ldr	w8, [x21, w27, uxtw]
	mov	w11, #12                        ; =0xc
	umaddl	x11, w19, w11, x22
	str	w8, [x11]
	add	w8, w27, #4
	ldr	w8, [x21, w8, uxtw]
	str	w8, [x11, #4]
	add	w8, w27, #8
	ldrh	w23, [x21, w8, uxtw]
	strh	w23, [x11, #8]
	add	w8, w27, #10
	ldrb	w8, [x21, w8, uxtw]
	strb	w8, [x11, #10]
	strb	wzr, [x11, #11]
	add	w8, w28, w23
	cmp	w8, w20
	b.hi	LBB58_37
; %bb.69:                               ;   in Loop: Header=BB58_65 Depth=2
	mov	w27, w19
	cbz	w23, LBB58_63
; %bb.70:                               ;   in Loop: Header=BB58_65 Depth=2
	mov	x0, x23
	bl	_malloc
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [x0, #408]
	str	x8, [x9, x27, lsl #3]
	cbz	x8, LBB58_64
; %bb.71:                               ;   in Loop: Header=BB58_65 Depth=2
	add	x1, x21, w28, uxtw
	mov	x0, x8
	mov	x2, x23
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x22, [x0, #400]
	mov	w8, #12                         ; =0xc
	umaddl	x8, w27, w8, x22
	ldrh	w23, [x8, #8]
	ldr	w19, [x0, #432]
	b	LBB58_64
LBB58_72:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w20, #4
	b.lo	LBB58_37
; %bb.73:                               ;   in Loop: Header=BB58_38 Depth=1
	mov	w8, #0                          ; =0x0
	mov	w19, #4                         ; =0x4
LBB58_74:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w22, [x21, w8, uxtw]
	sub	w8, w20, w19
	cmp	w22, w8
	b.hi	LBB58_37
; %bb.75:                               ;   in Loop: Header=BB58_74 Depth=2
	add	x1, x21, w19, uxtw
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, x22
	bl	_nvm_add_string
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	mov	x10, x26
	mov	x9, x25
	add	w8, w22, w19
	add	w19, w8, #4
	cmp	w19, w20
	b.ls	LBB58_74
	b	LBB58_37
LBB58_76:                               ;   in Loop: Header=BB58_38 Depth=1
	cmp	w20, #12
	b.lo	LBB58_37
; %bb.77:                               ;   in Loop: Header=BB58_38 Depth=1
	mov	w19, #0                         ; =0x0
	ldr	w11, [x0, #384]
	b	LBB58_80
LBB58_78:                               ;   in Loop: Header=BB58_80 Depth=2
	ldr	x8, [x0, #376]
LBB58_79:                               ;   in Loop: Header=BB58_80 Depth=2
	mov	w12, #12                        ; =0xc
	umaddl	x8, w11, w12, x8
	stp	w22, w23, [x8]
	str	w27, [x8, #8]
	add	w11, w11, #1
	str	w11, [x0, #384]
	add	w8, w19, #24
	add	w19, w19, #12
	cmp	w8, w20
	b.hi	LBB58_37
LBB58_80:                               ;   Parent Loop BB58_38 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmn	w11, #1
	b.eq	LBB58_90
; %bb.81:                               ;   in Loop: Header=BB58_80 Depth=2
	ldr	w22, [x21, w19, uxtw]
	add	w8, w19, #4
	ldr	w23, [x21, w8, uxtw]
	add	w8, w19, #8
	ldr	w27, [x21, w8, uxtw]
	ldr	w8, [x0, #388]
	cmp	w11, w8
	b.lo	LBB58_78
; %bb.82:                               ;   in Loop: Header=BB58_80 Depth=2
	cmp	w8, #0
	mov	w9, #16                         ; =0x10
	csel	w8, w9, w8, eq
	tbnz	w8, #31, LBB58_90
; %bb.83:                               ;   in Loop: Header=BB58_80 Depth=2
	lsl	w28, w8, #1
	mov	w8, #12                         ; =0xc
	umull	x1, w28, w8
	ldr	x0, [x0, #376]
	bl	_realloc
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB58_90
; %bb.84:                               ;   in Loop: Header=BB58_80 Depth=2
	mov	x9, x25
	mov	x10, x26
	str	x8, [x0, #376]
	str	w28, [x0, #388]
	ldr	w11, [x0, #384]
	b	LBB58_79
LBB58_85:
	mov	w8, #0                          ; =0x0
LBB58_86:
	cmp	w9, w10
	b.ne	LBB58_4
; %bb.87:
	cmp	w24, #3
	b.hi	LBB58_91
; %bb.88:
	mov	x9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB58_100
LBB58_89:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
LBB58_90:
	bl	_nvm_module_free
	b	LBB58_4
LBB58_91:
	cmp	w24, #16
	b.hs	LBB58_93
; %bb.92:
	mov	x9, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB58_97
LBB58_93:
	and	x9, x24, #0x10
	add	x10, sp, #32
	add	x10, x10, #32
	movi.2d	v0, #0000000000000000
	mov	x11, x9
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
LBB58_94:                               ; =>This Inner Loop Header: Depth=1
	ldp	q4, q5, [x10, #-32]
	ldp	q6, q7, [x10], #64
	cmtst.4s	v4, v4, v4
	cmtst.4s	v5, v5, v5
	cmtst.4s	v6, v6, v6
	cmtst.4s	v7, v7, v7
	sub.4s	v0, v0, v4
	sub.4s	v1, v1, v5
	sub.4s	v2, v2, v6
	sub.4s	v3, v3, v7
	subs	x11, x11, #16
	b.ne	LBB58_94
; %bb.95:
	add.4s	v0, v1, v0
	add.4s	v1, v3, v2
	add.4s	v0, v1, v0
	addv.4s	s0, v0
	fmov	w10, s0
	cmp	x9, x24
	b.eq	LBB58_102
; %bb.96:
	tst	x24, #0xc
	b.eq	LBB58_100
LBB58_97:
	mov	x11, x9
	and	x9, x24, #0x1c
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w10
	sub	x10, x11, x9
	add	x12, sp, #32
	add	x11, x12, x11, lsl #2
LBB58_98:                               ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x11], #16
	cmtst.4s	v1, v1, v1
	sub.4s	v0, v0, v1
	adds	x10, x10, #4
	b.ne	LBB58_98
; %bb.99:
	addv.4s	s0, v0
	fmov	w10, s0
	cmp	x9, x24
	b.eq	LBB58_102
LBB58_100:
	sub	x11, x24, x9
	add	x12, sp, #32
	add	x9, x12, x9, lsl #2
LBB58_101:                              ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x9], #4
	cmp	w12, #0
	cinc	w10, w10, ne
	subs	x11, x11, #1
	b.ne	LBB58_101
LBB58_102:
	cmp	w8, w10
	b.eq	LBB58_26
	b	LBB58_4
LBB58_103:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh64, Lloh65, Lloh66
	.loh AdrpLdrGotLdr	Lloh67, Lloh68, Lloh69
	.loh AdrpLdr	Lloh70, Lloh71
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,_crc32_table,1024,2 ; @crc32_table
	.section	__TEXT,__const
_nvm_metadata_source_key.name:          ; @nvm_metadata_source_key.name
	.asciz	"nano.source_file"

_purity_key:                            ; @purity_key
	.asciz	"nano.purity.v1"

_effects_key:                           ; @effects_key
	.asciz	"nano.effects.v1"

_affine_key:                            ; @affine_key
	.asciz	"nano.affine.v1"

_match_key:                             ; @match_key
	.asciz	"nano.match.v1"

_affine_use_key:                        ; @affine_use_key
	.asciz	"nano.affine-use.v1"

_borrow_place_key:                      ; @borrow_place_key
	.asciz	"nano.borrow-place.v1"

_field_read_key:                        ; @field_read_key
	.asciz	"nano.field-read.v1"

_field_write_key:                       ; @field_write_key
	.asciz	"nano.field-write.v1"

_generic_key:                           ; @generic_key
	.asciz	"nano.generic.v1"

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.space	1

.zerofill __DATA,__bss,_crc32_initialized,1,0 ; @crc32_initialized
.subsections_via_symbols
