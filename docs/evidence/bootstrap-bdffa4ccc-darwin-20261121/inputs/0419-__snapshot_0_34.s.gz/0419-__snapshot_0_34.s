	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_mixed_samples_plan_free    ; -- Begin function nvm_mixed_samples_plan_free
	.p2align	2
_nvm_mixed_samples_plan_free:           ; @nvm_mixed_samples_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB0_2
	b	LBB0_1
LBB0_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_mixed_samples_proof_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #25552]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB0_2
LBB0_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_prepare      ; -- Begin function nvm_mixed_samples_prepare
	.p2align	2
_nvm_mixed_samples_prepare:             ; @nvm_mixed_samples_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp]                        ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB1_2
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_2:
	ldr	x0, [sp, #72]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB1_4
	b	LBB1_3
LBB1_3:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_4:
	add	x1, sp, #56
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #56]
	ldr	x0, [sp, #72]
	add	x8, sp, #32
	bl	_nvm_analyze_mixed_samples
	ldr	w8, [sp, #32]
	cbz	w8, LBB1_6
	b	LBB1_5
LBB1_5:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	q0, [sp, #32]
	str	q0, [x9]
	ldr	x8, [sp, #48]
	str	x8, [x9, #16]
	b	LBB1_28
LBB1_6:
	strb	wzr, [sp, #31]
	strb	wzr, [sp, #30]
	str	wzr, [sp, #24]
	b	LBB1_7
LBB1_7:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldr	x9, [sp, #56]
	ldr	x9, [x9]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB1_10
	b	LBB1_8
LBB1_8:                                 ;   in Loop: Header=BB1_7 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8]
	ldr	x8, [x8]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #1
	cset	w9, eq
	ldrb	w8, [sp, #31]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #31]
	b	LBB1_9
LBB1_9:                                 ;   in Loop: Header=BB1_7 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB1_7
LBB1_10:
	str	wzr, [sp, #20]
	b	LBB1_11
LBB1_11:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #56]
	ldr	x9, [x9]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB1_14
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x8, [sp, #56]
	ldr	x8, [x8]
	add	x10, x8, #28
	ldr	w8, [sp, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #22]
	subs	w8, w8, #7
	cset	w9, eq
	ldrb	w8, [sp, #30]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #30]
	b	LBB1_13
LBB1_13:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB1_11
LBB1_14:
	ldrb	w8, [sp, #31]
	tbz	w8, #0, LBB1_17
	b	LBB1_15
LBB1_15:
	ldrb	w8, [sp, #30]
	tbz	w8, #0, LBB1_17
	b	LBB1_16
LBB1_16:
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #40]
	cbnz	w8, LBB1_18
	b	LBB1_17
LBB1_17:
	ldr	x0, [sp, #56]
	bl	_nvm_mixed_samples_proof_free
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_18:
	ldr	x0, [sp, #72]
	add	x8, sp, #87
	mov	w9, #1                          ; =0x1
	and	w1, w9, #0x1
	mov	x2, #0                          ; =0x0
	and	w3, w9, #0x1
	bl	_verify_structure_checked
	ldrb	w8, [sp, #87]
	tbz	w8, #0, LBB1_20
	b	LBB1_19
LBB1_19:
	ldr	x0, [sp, #72]
	bl	_nvm_metadata_valid
	tbnz	w0, #0, LBB1_21
	b	LBB1_20
LBB1_20:
	ldr	x0, [sp, #56]
	bl	_nvm_mixed_samples_proof_free
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_21:
	mov	x0, #1                          ; =0x1
	mov	x1, #25568                      ; =0x63e0
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB1_23
	b	LBB1_22
LBB1_22:
	ldr	x0, [sp, #56]
	bl	_nvm_mixed_samples_proof_free
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	adrp	x1, l_.str.4@PAGE
	add	x1, x1, l_.str.4@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_23:
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldr	x0, [sp, #72]
	ldr	x1, [sp, #8]
	bl	_mp_signatures
	tbnz	w0, #0, LBB1_25
	b	LBB1_24
LBB1_24:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_plan_free
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	adrp	x1, l_.str.5@PAGE
	add	x1, x1, l_.str.5@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_25:
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #320]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #8]
	str	x0, [x8, #25552]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #25552]
	cbnz	x8, LBB1_27
	b	LBB1_26
LBB1_26:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_plan_free
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	mov	w0, #4                          ; =0x4
	adrp	x1, l_.str.6@PAGE
	add	x1, x1, l_.str.6@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_27:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #25552]
	ldr	x8, [sp, #72]
	ldr	x1, [x8, #312]
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #320]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #320]
	ldr	x10, [sp, #8]
	mov	x11, #25560                     ; =0x63d8
	str	w9, [x10, x11]
	ldr	x9, [sp, #8]
	ldr	x10, [sp, #64]
	str	x9, [x10]
	mov	w0, #0                          ; =0x0
	adrp	x1, l_.str.7@PAGE
	add	x1, x1, l_.str.7@PAGEOFF
	bl	_mp_result
	b	LBB1_28
LBB1_28:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB1_30
	b	LBB1_29
LBB1_29:
	bl	___stack_chk_fail
LBB1_30:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mp_result
_mp_result:                             ; @mp_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	mov	x9, x8
	str	w0, [sp, #12]
	str	x1, [sp]
	ldr	w8, [sp, #12]
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp]
	str	x8, [x9, #16]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_structure_checked
_verify_structure_checked:              ; @verify_structure_checked
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #800
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #56]
	strb	w1, [sp, #55]
	str	x2, [sp, #40]
	strb	w3, [sp, #39]
	ldr	x8, [sp, #40]
	cbz	x8, LBB3_2
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp, #40]
	strb	wzr, [x8]
	b	LBB3_2
LBB3_2:
	strb	wzr, [sp, #38]
	ldr	x0, [sp, #56]
	add	x8, sp, #535
	bl	_verify_module_ranges
	ldrb	w8, [sp, #535]
	tbnz	w8, #0, LBB3_4
	b	LBB3_3
LBB3_3:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	x1, sp, #535
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB3_25
LBB3_4:
	strb	wzr, [sp, #37]
	ldrb	w8, [sp, #39]
	tbnz	w8, #0, LBB3_7
	b	LBB3_5
LBB3_5:
	ldr	x0, [sp, #56]
	add	x1, sp, #37
	bl	_nvm_ownership_contracts_validate
	cbz	w0, LBB3_7
	b	LBB3_6
LBB3_6:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.101@PAGE
	add	x0, x0, l_.str.101@PAGEOFF
	bl	_fail
	b	LBB3_25
LBB3_7:
	ldrb	w8, [sp, #37]
	tbz	w8, #0, LBB3_18
	b	LBB3_8
LBB3_8:
	ldrb	w8, [sp, #55]
	tbnz	w8, #0, LBB3_18
	b	LBB3_9
LBB3_9:
	str	wzr, [sp, #32]
	b	LBB3_10
LBB3_10:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB3_15
	b	LBB3_11
LBB3_11:                                ;   in Loop: Header=BB3_10 Depth=1
	ldr	x0, [sp, #56]
	ldr	w1, [sp, #32]
	add	x8, sp, #324
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #324]
	tbnz	w8, #0, LBB3_13
	b	LBB3_12
LBB3_12:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #32]
	mov	x12, x9
	add	x9, sp, #324
	ldr	w10, [sp, #328]
	mov	x11, x10
	add	x9, x9, #16
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.102@PAGE
	add	x0, x0, l_.str.102@PAGEOFF
	bl	_fail
	b	LBB3_25
LBB3_13:                                ;   in Loop: Header=BB3_10 Depth=1
	b	LBB3_14
LBB3_14:                                ;   in Loop: Header=BB3_10 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB3_10
LBB3_15:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #56]
	bl	_nvm_verify_owned_module
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB3_17
	b	LBB3_16
LBB3_16:
	b	LBB3_25
LBB3_17:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #38]
	b	LBB3_18
LBB3_18:
	ldr	x0, [sp, #56]
	bl	_nvm_retained_layouts_valid
	tbnz	w0, #0, LBB3_20
	b	LBB3_19
LBB3_19:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.103@PAGE
	add	x0, x0, l_.str.103@PAGEOFF
	bl	_fail
	b	LBB3_25
LBB3_20:
	ldr	x0, [sp, #56]
	add	x8, sp, #67
	bl	_verify_module_contracts_and_imports
	ldrb	w8, [sp, #67]
	tbnz	w8, #0, LBB3_22
	b	LBB3_21
LBB3_21:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	x1, sp, #67
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB3_25
LBB3_22:
	ldr	x8, [sp, #40]
	cbz	x8, LBB3_24
	b	LBB3_23
LBB3_23:
	ldrb	w8, [sp, #38]
	ldr	x9, [sp, #40]
	and	w8, w8, #0x1
	strb	w8, [x9]
	b	LBB3_24
LBB3_24:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB3_25
LBB3_25:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB3_27
	b	LBB3_26
LBB3_26:
	bl	___stack_chk_fail
LBB3_27:
	add	sp, sp, #800
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mp_signatures
_mp_signatures:                         ; @mp_signatures
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #24
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-56]
	stur	x1, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-72]
	ldr	x1, [x8, #5144]
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #5152]
	mov	x2, x8
	add	x0, sp, #80
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	add	x1, sp, #76
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_9
	b	LBB4_1
LBB4_1:
	ldr	w8, [sp, #76]
	subs	w8, w8, #1
	b.eq	LBB4_3
	b	LBB4_2
LBB4_2:
	ldr	w8, [sp, #76]
	subs	w8, w8, #2
	b.ne	LBB4_9
	b	LBB4_3
LBB4_3:
	add	x0, sp, #80
	add	x1, sp, #72
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_9
	b	LBB4_4
LBB4_4:
	ldr	w8, [sp, #72]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB4_9
	b	LBB4_5
LBB4_5:
	ldr	w8, [sp, #72]
	mov	x1, x8
	add	x0, sp, #80
	add	x2, sp, #56
	bl	_nvm_v2_take
	cbnz	w0, LBB4_9
	b	LBB4_6
LBB4_6:
	add	x0, sp, #80
	bl	_nvm_v2_align4
	cbnz	w0, LBB4_9
	b	LBB4_7
LBB4_7:
	add	x0, sp, #80
	add	x1, sp, #68
	bl	_nvm_v2_u32
	cbnz	w0, LBB4_9
	b	LBB4_8
LBB4_8:
	ldr	w8, [sp, #68]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB4_10
	b	LBB4_9
LBB4_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_10:
	ldr	w8, [sp, #68]
	ldur	x9, [x29, #-64]
	mov	x10, #25544                     ; =0x63c8
	str	w8, [x9, x10]
	str	wzr, [sp, #52]
	b	LBB4_11
LBB4_11:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB4_29 Depth 2
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB4_44
	b	LBB4_12
LBB4_12:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldur	x8, [x29, #-64]
	add	x10, x8, #8
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	add	x1, x8, #2
	add	x0, sp, #80
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_23
	b	LBB4_13
LBB4_13:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.gt	LBB4_23
	b	LBB4_14
LBB4_14:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x1, [sp, #32]
	add	x0, sp, #80
	bl	_nvm_v2_u16
	cbnz	w0, LBB4_23
	b	LBB4_15
LBB4_15:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8]
	subs	w8, w8, #8
	b.gt	LBB4_23
	b	LBB4_16
LBB4_16:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.gt	LBB4_23
	b	LBB4_17
LBB4_17:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8]
	ldr	x9, [sp, #40]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB4_23
	b	LBB4_18
LBB4_18:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #40]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB4_23
	b	LBB4_19
LBB4_19:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x1, [x8]
	ldr	x8, [sp, #32]
	add	x2, x8, #104
	add	x0, sp, #80
	bl	_mp_declaration
	tbz	w0, #0, LBB4_23
	b	LBB4_20
LBB4_20:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #32]
	ldr	x10, [x9, #104]
	stur	x10, [x29, #-24]
	ldr	w9, [x9, #112]
	str	w9, [x8, #8]
	ldur	x0, [x29, #-24]
	ldr	x1, [x8, #8]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_mp_value_signature
	tbz	w0, #0, LBB4_23
	b	LBB4_21
LBB4_21:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #104]
	ldr	x9, [sp, #40]
	ldrb	w9, [x9, #20]
	subs	w8, w8, w9
	b.ne	LBB4_23
	b	LBB4_22
LBB4_22:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #21]
	ldr	x9, [sp, #32]
	ldrb	w9, [x9, #104]
	subs	w9, w9, #0
	cset	w9, ne
	subs	w8, w8, w9
	b.eq	LBB4_24
	b	LBB4_23
LBB4_23:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_24:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8]
	add	x8, x8, #24
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	ldr	x9, [sp, #32]
	strh	w8, [x9, #4]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #4]
	add	w8, w8, w9
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lo	LBB4_26
	b	LBB4_25
LBB4_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_26:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #112]
	subs	w8, w8, #2
	b.ne	LBB4_28
	b	LBB4_27
LBB4_27:                                ;   in Loop: Header=BB4_11 Depth=1
	ldur	x8, [x29, #-72]
	ldr	x8, [x8]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #108]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #32]
	strh	w8, [x9, #116]
	b	LBB4_28
LBB4_28:                                ;   in Loop: Header=BB4_11 Depth=1
	strh	wzr, [sp, #30]
	b	LBB4_29
LBB4_29:                                ;   Parent Loop BB4_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB4_42
	b	LBB4_30
LBB4_30:                                ;   in Loop: Header=BB4_29 Depth=2
	ldur	x8, [x29, #-64]
	ldr	x1, [x8]
	ldur	x8, [x29, #-64]
	add	x10, x8, #968
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #3072                       ; =0xc00
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x2, w8, w9, x10
	add	x0, sp, #80
	bl	_mp_declaration
	tbnz	w0, #0, LBB4_32
	b	LBB4_31
LBB4_31:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_32:                                ;   in Loop: Header=BB4_29 Depth=2
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB4_40
	b	LBB4_33
LBB4_33:                                ;   in Loop: Header=BB4_29 Depth=2
	ldur	x8, [x29, #-64]
	add	x10, x8, #968
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #3072                       ; =0xc00
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x10, w8, w9, x10
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8]
	stur	x9, [x29, #-40]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-32]
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-32]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_mp_value_signature
	tbnz	w0, #0, LBB4_35
	b	LBB4_34
LBB4_34:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_35:                                ;   in Loop: Header=BB4_29 Depth=2
	ldr	x8, [sp, #32]
	add	x11, x8, #8
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x11
	ldur	x8, [x29, #-64]
	add	x12, x8, #968
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x11, #3072                      ; =0xc00
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x11, w8, w11, x12
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #264]
	cbz	x8, LBB4_39
	b	LBB4_36
LBB4_36:                                ;   in Loop: Header=BB4_29 Depth=2
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB4_39
	b	LBB4_37
LBB4_37:                                ;   in Loop: Header=BB4_29 Depth=2
	ldur	x8, [x29, #-56]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #30]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldr	x9, [sp, #32]
	add	x9, x9, #8
	ldrh	w10, [sp, #30]
                                        ; kill: def $x10 killed $w10
	mov	x11, #12                        ; =0xc
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB4_39
	b	LBB4_38
LBB4_38:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_39:                                ;   in Loop: Header=BB4_29 Depth=2
	b	LBB4_40
LBB4_40:                                ;   in Loop: Header=BB4_29 Depth=2
	b	LBB4_41
LBB4_41:                                ;   in Loop: Header=BB4_29 Depth=2
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB4_29
LBB4_42:                                ;   in Loop: Header=BB4_11 Depth=1
	b	LBB4_43
LBB4_43:                                ;   in Loop: Header=BB4_11 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB4_11
LBB4_44:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-41]
	b	LBB4_45
LBB4_45:
	ldurb	w8, [x29, #-41]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB4_47
	b	LBB4_46
LBB4_46:
	bl	___stack_chk_fail
LBB4_47:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_signature    ; -- Begin function nvm_mixed_samples_signature
	.p2align	2
_nvm_mixed_samples_signature:           ; @nvm_mixed_samples_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldr	x8, [sp]
	cbz	x8, LBB5_3
	b	LBB5_2
LBB5_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #25544                     ; =0x63c8
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB5_4
	b	LBB5_3
LBB5_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_5
LBB5_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #8
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #120                        ; =0x78
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB5_5
LBB5_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_local        ; -- Begin function nvm_mixed_samples_local
	.p2align	2
_nvm_mixed_samples_local:               ; @nvm_mixed_samples_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB6_4
	b	LBB6_1
LBB6_1:
	ldr	x8, [sp]
	cbz	x8, LBB6_4
	b	LBB6_2
LBB6_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #25544                     ; =0x63c8
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB6_4
	b	LBB6_3
LBB6_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	add	x11, x9, #8
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #120                       ; =0x78
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB6_5
	b	LBB6_4
LBB6_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB6_6
LBB6_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	add	x11, x8, #968
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #3072                      ; =0xc00
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x11, w8, w10, x11
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB6_6
LBB6_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_record       ; -- Begin function nvm_mixed_samples_record
	.p2align	2
_nvm_mixed_samples_record:              ; @nvm_mixed_samples_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	w1, [sp, #44]
	str	x2, [sp, #32]
	ldr	x8, [sp, #48]
	cbz	x8, LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB7_3
	b	LBB7_2
LBB7_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB7_13
LBB7_3:
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ldr	w8, [sp, #44]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB7_5
	b	LBB7_4
LBB7_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB7_13
LBB7_5:
	ldr	x8, [sp, #24]
	add	x8, x8, #24
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #20]
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB7_7
	b	LBB7_6
LBB7_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB7_13
LBB7_7:
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	add	x8, x8, #44
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #16]
	ldr	w8, [sp, #16]
	adds	w8, w8, #1
	b.eq	LBB7_11
	b	LBB7_8
LBB7_8:
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #48]
	ldr	x9, [x9]
	ldr	w9, [x9, #40]
	subs	w8, w8, w9
	b.hs	LBB7_11
	b	LBB7_9
LBB7_9:
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	add	x8, x8, #1068
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #20]
	subs	w8, w8, w9
	b.ne	LBB7_11
	b	LBB7_10
LBB7_10:
	ldr	x8, [sp, #24]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #1
	b.ne	LBB7_12
	b	LBB7_11
LBB7_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB7_13
LBB7_12:
	ldr	x8, [sp, #32]
	ldr	w9, [sp, #44]
	str	w9, [sp]
	ldr	w9, [sp, #20]
	str	w9, [sp, #4]
	ldr	w9, [sp, #16]
	str	w9, [sp, #8]
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #4
	ldrh	w9, [x9, #2]
	str	w9, [sp, #12]
	ldr	q0, [sp]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB7_13
LBB7_13:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_transport    ; -- Begin function nvm_mixed_samples_transport
	.p2align	2
_nvm_mixed_samples_transport:           ; @nvm_mixed_samples_transport
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	ldr	x8, [sp, #48]
	cbz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB8_3
	b	LBB8_2
LBB8_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB8_4
LBB8_3:
	ldr	x8, [sp, #48]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #32]
	ldr	x9, [sp, #40]
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #25552]
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #5144]
	str	x8, [sp, #16]
	ldr	x8, [sp, #48]
	mov	x10, #25560                     ; =0x63d8
	ldr	w8, [x8, x10]
	str	w8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #5152]
	str	w8, [sp, #28]
	ldur	q0, [sp, #8]
	str	q0, [x9]
	ldr	x8, [sp, #24]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB8_4
LBB8_4:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_obligations  ; -- Begin function nvm_mixed_samples_obligations
	.p2align	2
_nvm_mixed_samples_obligations:         ; @nvm_mixed_samples_obligations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB9_3
LBB9_2:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB9_3
LBB9_3:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_candidate    ; -- Begin function nvm_mixed_samples_candidate
	.p2align	2
_nvm_mixed_samples_candidate:           ; @nvm_mixed_samples_candidate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, #0                          ; =0x0
	bl	_nvm_mixed_samples_candidate_classified
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_candidate_classified ; -- Begin function nvm_mixed_samples_candidate_classified
	.p2align	2
_nvm_mixed_samples_candidate_classified: ; @nvm_mixed_samples_candidate_classified
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB11_4
	b	LBB11_1
LBB11_1:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	bl	_nvm_service_pending_classified
	tbnz	w0, #0, LBB11_4
	b	LBB11_2
LBB11_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB11_4
	b	LBB11_3
LBB11_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbnz	x8, LBB11_5
	b	LBB11_4
LBB11_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_5:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	sub	x1, x29, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_11
	b	LBB11_6
LBB11_6:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #1
	b.eq	LBB11_8
	b	LBB11_7
LBB11_7:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #2
	b.ne	LBB11_11
	b	LBB11_8
LBB11_8:
	sub	x0, x29, #48
	sub	x1, x29, #56
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_11
	b	LBB11_9
LBB11_9:
	ldur	w8, [x29, #-56]
	subs	w8, w8, #256
	b.hi	LBB11_11
	b	LBB11_10
LBB11_10:
	ldur	w8, [x29, #-56]
	mov	x1, x8
	sub	x0, x29, #48
	add	x2, sp, #56
	bl	_nvm_v2_take
	cbz	w0, LBB11_12
	b	LBB11_11
LBB11_11:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_12:
	strb	wzr, [sp, #55]
	str	wzr, [sp, #48]
	b	LBB11_13
LBB11_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #48]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.hs	LBB11_16
	b	LBB11_14
LBB11_14:                               ;   in Loop: Header=BB11_13 Depth=1
	ldr	x8, [sp, #56]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w9, ne
	ldrb	w8, [sp, #55]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #55]
	b	LBB11_15
LBB11_15:                               ;   in Loop: Header=BB11_13 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB11_13
LBB11_16:
	ldrb	w8, [sp, #55]
	tbnz	w8, #0, LBB11_18
	b	LBB11_17
LBB11_17:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_18:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #48
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_20
	b	LBB11_19
LBB11_19:
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.eq	LBB11_21
	b	LBB11_20
LBB11_20:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_21:
	str	wzr, [sp, #44]
	str	wzr, [sp, #40]
	b	LBB11_22
LBB11_22:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_30 Depth 2
	ldr	w8, [sp, #40]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.hs	LBB11_39
	b	LBB11_23
LBB11_23:                               ;   in Loop: Header=BB11_22 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #39
	bl	_nvm_v2_u8
	cbnz	w0, LBB11_28
	b	LBB11_24
LBB11_24:                               ;   in Loop: Header=BB11_22 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #38
	bl	_nvm_v2_u8
	cbnz	w0, LBB11_28
	b	LBB11_25
LBB11_25:                               ;   in Loop: Header=BB11_22 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #36
	bl	_nvm_v2_u16
	cbnz	w0, LBB11_28
	b	LBB11_26
LBB11_26:                               ;   in Loop: Header=BB11_22 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB11_28
	b	LBB11_27
LBB11_27:                               ;   in Loop: Header=BB11_22 Depth=1
	ldrh	w8, [sp, #36]
	ldr	w10, [sp, #44]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB11_29
	b	LBB11_28
LBB11_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_29:                               ;   in Loop: Header=BB11_22 Depth=1
	ldrh	w9, [sp, #36]
	ldr	w8, [sp, #44]
	add	w8, w8, w9
	str	w8, [sp, #44]
	strh	wzr, [sp, #22]
	b	LBB11_30
LBB11_30:                               ;   Parent Loop BB11_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #36]
	subs	w8, w8, w9
	b.ge	LBB11_37
	b	LBB11_31
LBB11_31:                               ;   in Loop: Header=BB11_30 Depth=2
	sub	x0, x29, #48
	mov	x1, #12                         ; =0xc
	add	x2, sp, #24
	bl	_nvm_v2_take
	cbz	w0, LBB11_33
	b	LBB11_32
LBB11_32:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_33:                               ;   in Loop: Header=BB11_30 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.ne	LBB11_35
	b	LBB11_34
LBB11_34:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_35:                               ;   in Loop: Header=BB11_30 Depth=2
	b	LBB11_36
LBB11_36:                               ;   in Loop: Header=BB11_30 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB11_30
LBB11_37:                               ;   in Loop: Header=BB11_22 Depth=1
	b	LBB11_38
LBB11_38:                               ;   in Loop: Header=BB11_22 Depth=1
	ldr	w8, [sp, #40]
	add	w8, w8, #1
	str	w8, [sp, #40]
	b	LBB11_22
LBB11_39:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_40
LBB11_40:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_mixed_samples_admit        ; -- Begin function nvm_mixed_samples_admit
	.p2align	2
_nvm_mixed_samples_admit:               ; @nvm_mixed_samples_admit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB12_2
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	adrp	x1, l_.str.8@PAGE
	add	x1, x1, l_.str.8@PAGEOFF
	bl	_mp_result
	b	LBB12_19
LBB12_2:
	ldur	x0, [x29, #-8]
	bl	_nvm_mixed_samples_candidate
	tbnz	w0, #0, LBB12_4
	b	LBB12_3
LBB12_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	adrp	x1, l_.str.9@PAGE
	add	x1, x1, l_.str.9@PAGEOFF
	bl	_mp_result
	b	LBB12_19
LBB12_4:
	sub	x1, x29, #24
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-24]
	ldur	x0, [x29, #-8]
	add	x8, sp, #32
	bl	_nvm_mixed_samples_prepare
	ldr	w8, [sp, #32]
	cbz	w8, LBB12_6
	b	LBB12_5
LBB12_5:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	q0, [sp, #32]
	str	q0, [x9]
	ldr	x8, [sp, #48]
	str	x8, [x9, #16]
	b	LBB12_19
LBB12_6:
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #112]
	strb	w8, [sp, #31]
	ldrb	w9, [sp, #31]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB12_9
	b	LBB12_7
LBB12_7:
	ldrb	w9, [sp, #31]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b.eq	LBB12_9
	b	LBB12_8
LBB12_8:
	ldrb	w8, [sp, #31]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB12_9
LBB12_9:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #30]
	str	wzr, [sp, #24]
	b	LBB12_10
LBB12_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB12_16
	b	LBB12_11
LBB12_11:                               ;   in Loop: Header=BB12_10 Depth=1
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #256]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	bl	_nvm_get_string
	str	x0, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB12_14
	b	LBB12_12
LBB12_12:                               ;   in Loop: Header=BB12_10 Depth=1
	ldr	x0, [sp, #16]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB12_14
	b	LBB12_13
LBB12_13:                               ;   in Loop: Header=BB12_10 Depth=1
	strb	wzr, [sp, #30]
	b	LBB12_14
LBB12_14:                               ;   in Loop: Header=BB12_10 Depth=1
	b	LBB12_15
LBB12_15:                               ;   in Loop: Header=BB12_10 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB12_10
LBB12_16:
	ldrb	w8, [sp, #30]
	tbnz	w8, #0, LBB12_18
	b	LBB12_17
LBB12_17:
	ldur	x0, [x29, #-24]
	bl	_nvm_mixed_samples_plan_free
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	adrp	x1, l_.str.11@PAGE
	add	x1, x1, l_.str.11@PAGEOFF
	bl	_mp_result
	b	LBB12_19
LBB12_18:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x9, [x29, #-24]
	ldur	x10, [x29, #-16]
	str	x9, [x10]
	mov	w0, #0                          ; =0x0
	adrp	x1, l_.str.12@PAGE
	add	x1, x1, l_.str.12@PAGEOFF
	bl	_mp_result
	b	LBB12_19
LBB12_19:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_free      ; -- Begin function nvm_owned_array_plan_free
	.p2align	2
_nvm_owned_array_plan_free:             ; @nvm_owned_array_plan_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	b	LBB13_3
LBB13_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_owned_array_lifetime_facts_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB13_3
LBB13_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_prepare_owned_array_authority ; -- Begin function nvm_prepare_owned_array_authority
	.p2align	2
_nvm_prepare_owned_array_authority:     ; @nvm_prepare_owned_array_authority
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp]                        ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #56]
	str	x1, [sp, #48]
	ldr	x8, [sp, #48]
	cbnz	x8, LBB14_2
	b	LBB14_1
LBB14_1:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.13@PAGE
	add	x8, x8, l_.str.13@PAGEOFF
	str	x8, [x9, #16]
	b	LBB14_10
LBB14_2:
	add	x1, sp, #40
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	ldr	x0, [sp, #56]
	add	x8, sp, #16
	bl	_nvm_analyze_owned_array_lifetimes
	ldr	w8, [sp, #16]
	cbz	w8, LBB14_4
	b	LBB14_3
LBB14_3:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	q0, [sp, #16]
	str	q0, [x9]
	ldr	x8, [sp, #32]
	str	x8, [x9, #16]
	b	LBB14_10
LBB14_4:
	ldr	x0, [sp, #56]
	add	x8, sp, #71
	mov	w9, #1                          ; =0x1
	and	w1, w9, #0x1
	mov	x2, #0                          ; =0x0
	and	w3, w9, #0x1
	bl	_verify_structure_checked
	ldrb	w8, [sp, #71]
	tbz	w8, #0, LBB14_6
	b	LBB14_5
LBB14_5:
	ldr	x0, [sp, #56]
	bl	_nvm_metadata_valid
	tbnz	w0, #0, LBB14_7
	b	LBB14_6
LBB14_6:
	ldr	x0, [sp, #40]
	bl	_nvm_owned_array_lifetime_facts_free
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.14@PAGE
	add	x8, x8, l_.str.14@PAGEOFF
	str	x8, [x9, #16]
	b	LBB14_10
LBB14_7:
	mov	x0, #1                          ; =0x1
	mov	x1, #8                          ; =0x8
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB14_9
	b	LBB14_8
LBB14_8:
	ldr	x0, [sp, #40]
	bl	_nvm_owned_array_lifetime_facts_free
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.15@PAGE
	add	x8, x8, l_.str.15@PAGEOFF
	str	x8, [x9, #16]
	b	LBB14_10
LBB14_9:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	x10, [sp, #8]
	str	x8, [x10]
	ldr	x8, [sp, #8]
	ldr	x10, [sp, #48]
	str	x8, [x10]
	str	wzr, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.16@PAGE
	add	x8, x8, l_.str.16@PAGEOFF
	str	x8, [x9, #16]
	b	LBB14_10
LBB14_10:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB14_12
	b	LBB14_11
LBB14_11:
	bl	___stack_chk_fail
LBB14_12:
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #336]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_counts    ; -- Begin function nvm_owned_array_plan_counts
	.p2align	2
_nvm_owned_array_plan_counts:           ; @nvm_owned_array_plan_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB15_2
	b	LBB15_1
LBB15_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB15_3
	b	LBB15_2
LBB15_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB15_4
LBB15_3:
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	q0, [x8, #16]
	str	q0, [x9]
	ldr	w8, [x8, #32]
	str	w8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB15_4
LBB15_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_signature ; -- Begin function nvm_owned_array_plan_signature
	.p2align	2
_nvm_owned_array_plan_signature:        ; @nvm_owned_array_plan_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB16_3
	b	LBB16_1
LBB16_1:
	ldr	x8, [sp]
	cbz	x8, LBB16_3
	b	LBB16_2
LBB16_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB16_4
	b	LBB16_3
LBB16_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_5
LBB16_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	add	x10, x8, #36
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #116                        ; =0x74
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #116                        ; =0x74
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB16_5
LBB16_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_local     ; -- Begin function nvm_owned_array_plan_local
	.p2align	2
_nvm_owned_array_plan_local:            ; @nvm_owned_array_plan_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB17_4
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp]
	cbz	x8, LBB17_4
	b	LBB17_2
LBB17_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB17_4
	b	LBB17_3
LBB17_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	add	x9, x9, #36
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	mov	x11, #116                       ; =0x74
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w9, [x9, x10]
	subs	w8, w8, w9
	b.lt	LBB17_5
	b	LBB17_4
LBB17_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_6
LBB17_5:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	add	x11, x8, #964
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #3072                      ; =0xc00
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x11, w8, w10, x11
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x10, #12                        ; =0xc
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x10, [x8]
	str	x10, [x9]
	ldr	w8, [x8, #8]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB17_6
LBB17_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_layout    ; -- Begin function nvm_owned_array_plan_layout
	.p2align	2
_nvm_owned_array_plan_layout:           ; @nvm_owned_array_plan_layout
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB18_2
	b	LBB18_1
LBB18_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_owned_array_layout_fact
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB18_2
LBB18_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_source    ; -- Begin function nvm_owned_array_plan_source
	.p2align	2
_nvm_owned_array_plan_source:           ; @nvm_owned_array_plan_source
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB19_2
	b	LBB19_1
LBB19_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_owned_array_source_layout
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB19_2
LBB19_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_transport ; -- Begin function nvm_owned_array_plan_transport
	.p2align	2
_nvm_owned_array_plan_transport:        ; @nvm_owned_array_plan_transport
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB20_2
	b	LBB20_1
LBB20_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldr	x1, [sp, #16]
	bl	_nvm_owned_array_transport
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB20_2
LBB20_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_plan_obligation ; -- Begin function nvm_owned_array_plan_obligation
	.p2align	2
_nvm_owned_array_plan_obligation:       ; @nvm_owned_array_plan_obligation
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB21_3
	b	LBB21_1
LBB21_1:
	ldr	x8, [sp]
	cbz	x8, LBB21_3
	b	LBB21_2
LBB21_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #20]
	subs	w8, w8, w9
	b.lo	LBB21_4
	b	LBB21_3
LBB21_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_5
LBB21_4:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	mov	x10, #25540                     ; =0x63c4
	add	x11, x9, x10
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #28                        ; =0x1c
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	q0, [x9]
	str	q0, [x8]
	ldur	q0, [x9, #12]
	stur	q0, [x8, #12]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB21_5
LBB21_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_route          ; -- Begin function nvm_owned_array_route
	.p2align	2
_nvm_owned_array_route:                 ; @nvm_owned_array_route
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	mov	x1, #0                          ; =0x0
	bl	_nvm_owned_array_route_classified
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_route_classified ; -- Begin function nvm_owned_array_route_classified
	.p2align	2
_nvm_owned_array_route_classified:      ; @nvm_owned_array_route_classified
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB23_2
	b	LBB23_1
LBB23_1:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	bl	_nvm_service_pending_classified
	tbz	w0, #0, LBB23_3
	b	LBB23_2
LBB23_2:
	stur	wzr, [x29, #-4]
	b	LBB23_72
LBB23_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbnz	x8, LBB23_6
	b	LBB23_4
LBB23_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB23_6
	b	LBB23_5
LBB23_5:
	stur	wzr, [x29, #-4]
	b	LBB23_72
LBB23_6:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #296]
	cbz	x8, LBB23_8
	b	LBB23_7
LBB23_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB23_9
	b	LBB23_8
LBB23_8:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_9:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	sub	x0, x29, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	sub	x1, x29, #52
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_16
	b	LBB23_10
LBB23_10:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #1
	b.eq	LBB23_13
	b	LBB23_11
LBB23_11:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #2
	b.eq	LBB23_13
	b	LBB23_12
LBB23_12:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #3
	b.ne	LBB23_16
	b	LBB23_13
LBB23_13:
	sub	x0, x29, #48
	sub	x1, x29, #56
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_16
	b	LBB23_14
LBB23_14:
	ldur	w8, [x29, #-56]
	subs	w8, w8, #256
	b.hi	LBB23_16
	b	LBB23_15
LBB23_15:
	ldur	w8, [x29, #-56]
	mov	x1, x8
	sub	x0, x29, #48
	add	x2, sp, #72
	bl	_nvm_v2_take
	cbz	w0, LBB23_17
	b	LBB23_16
LBB23_16:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_17:
	strb	wzr, [sp, #71]
	str	wzr, [sp, #64]
	b	LBB23_18
LBB23_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #64]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.hs	LBB23_21
	b	LBB23_19
LBB23_19:                               ;   in Loop: Header=BB23_18 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ands	w8, w8, #0x2
	cset	w9, ne
	ldrb	w8, [sp, #71]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #71]
	b	LBB23_20
LBB23_20:                               ;   in Loop: Header=BB23_18 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB23_18
LBB23_21:
	ldrb	w8, [sp, #71]
	tbnz	w8, #0, LBB23_23
	b	LBB23_22
LBB23_22:
	stur	wzr, [x29, #-4]
	b	LBB23_72
LBB23_23:
	str	wzr, [sp, #60]
	b	LBB23_24
LBB23_24:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #60]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.hs	LBB23_31
	b	LBB23_25
LBB23_25:                               ;   in Loop: Header=BB23_24 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	and	w8, w8, #0xfffffffc
	cbnz	w8, LBB23_28
	b	LBB23_26
LBB23_26:                               ;   in Loop: Header=BB23_24 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #1, LBB23_29
	b	LBB23_27
LBB23_27:                               ;   in Loop: Header=BB23_24 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #60]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbnz	w8, #0, LBB23_29
	b	LBB23_28
LBB23_28:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_29:                               ;   in Loop: Header=BB23_24 Depth=1
	b	LBB23_30
LBB23_30:                               ;   in Loop: Header=BB23_24 Depth=1
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB23_24
LBB23_31:
	sub	x0, x29, #48
	bl	_nvm_v2_align4
	cbnz	w0, LBB23_34
	b	LBB23_32
LBB23_32:
	sub	x0, x29, #48
	add	x1, sp, #56
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_34
	b	LBB23_33
LBB23_33:
	ldr	w8, [sp, #56]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB23_35
	b	LBB23_34
LBB23_34:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_35:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #312]
	cbz	x8, LBB23_37
	b	LBB23_36
LBB23_36:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	cbnz	w8, LBB23_38
	b	LBB23_37
LBB23_37:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_38:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #312]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #320]
	mov	x2, x8
	sub	x0, x29, #48
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	sub	x1, x29, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_40
	b	LBB23_39
LBB23_39:
	ldur	w8, [x29, #-60]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.eq	LBB23_41
	b	LBB23_40
LBB23_40:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_41:
	str	wzr, [sp, #52]
	strb	wzr, [sp, #51]
	str	wzr, [sp, #44]
	b	LBB23_42
LBB23_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_52 Depth 2
	ldr	w8, [sp, #44]
	ldur	w9, [x29, #-56]
	subs	w8, w8, w9
	b.hs	LBB23_66
	b	LBB23_43
LBB23_43:                               ;   in Loop: Header=BB23_42 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #43
	bl	_nvm_v2_u8
	cbnz	w0, LBB23_50
	b	LBB23_44
LBB23_44:                               ;   in Loop: Header=BB23_42 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #42
	bl	_nvm_v2_u8
	cbnz	w0, LBB23_50
	b	LBB23_45
LBB23_45:                               ;   in Loop: Header=BB23_42 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #40
	bl	_nvm_v2_u16
	cbnz	w0, LBB23_50
	b	LBB23_46
LBB23_46:                               ;   in Loop: Header=BB23_42 Depth=1
	sub	x0, x29, #48
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB23_50
	b	LBB23_47
LBB23_47:                               ;   in Loop: Header=BB23_42 Depth=1
	ldrh	w8, [sp, #40]
	ldr	w10, [sp, #52]
	mov	w9, #65536                      ; =0x10000
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB23_50
	b	LBB23_48
LBB23_48:                               ;   in Loop: Header=BB23_42 Depth=1
	ldrb	w8, [sp, #42]
	cbnz	w8, LBB23_50
	b	LBB23_49
LBB23_49:                               ;   in Loop: Header=BB23_42 Depth=1
	ldrb	w8, [sp, #43]
	subs	w8, w8, #3
	b.le	LBB23_51
	b	LBB23_50
LBB23_50:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_51:                               ;   in Loop: Header=BB23_42 Depth=1
	ldrh	w9, [sp, #40]
	ldr	w8, [sp, #52]
	add	w8, w8, w9
	str	w8, [sp, #52]
	strh	wzr, [sp, #22]
	b	LBB23_52
LBB23_52:                               ;   Parent Loop BB23_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #22]
	ldrh	w9, [sp, #40]
	subs	w8, w8, w9
	b.ge	LBB23_64
	b	LBB23_53
LBB23_53:                               ;   in Loop: Header=BB23_52 Depth=2
	sub	x0, x29, #48
	mov	x1, #12                         ; =0xc
	add	x2, sp, #24
	bl	_nvm_v2_take
	cbnz	w0, LBB23_58
	b	LBB23_54
LBB23_54:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.ge	LBB23_58
	b	LBB23_55
LBB23_55:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB23_58
	b	LBB23_56
LBB23_56:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #2]
	cbnz	w8, LBB23_58
	b	LBB23_57
LBB23_57:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #3]
	cbz	w8, LBB23_59
	b	LBB23_58
LBB23_58:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_59:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	tbz	w8, #1, LBB23_62
	b	LBB23_60
LBB23_60:                               ;   in Loop: Header=BB23_52 Depth=2
	ldr	x8, [sp, #24]
	ldrb	w8, [x8]
	subs	w8, w8, #7
	b.ne	LBB23_62
	b	LBB23_61
LBB23_61:                               ;   in Loop: Header=BB23_52 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #51]
	b	LBB23_62
LBB23_62:                               ;   in Loop: Header=BB23_52 Depth=2
	b	LBB23_63
LBB23_63:                               ;   in Loop: Header=BB23_52 Depth=2
	ldrh	w8, [sp, #22]
	add	w8, w8, #1
	strh	w8, [sp, #22]
	b	LBB23_52
LBB23_64:                               ;   in Loop: Header=BB23_42 Depth=1
	b	LBB23_65
LBB23_65:                               ;   in Loop: Header=BB23_42 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB23_42
LBB23_66:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.eq	LBB23_68
	b	LBB23_67
LBB23_67:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_68:
	ldrb	w8, [sp, #51]
	tbz	w8, #0, LBB23_71
	b	LBB23_69
LBB23_69:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #3
	b.ne	LBB23_71
	b	LBB23_70
LBB23_70:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_71:
	ldrb	w9, [sp, #51]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w8, w8, wzr, eq
	stur	w8, [x29, #-4]
	b	LBB23_72
LBB23_72:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_owned_array_admit          ; -- Begin function nvm_owned_array_admit
	.p2align	2
_nvm_owned_array_admit:                 ; @nvm_owned_array_admit
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #992
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x9, x29, #168
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	add	x9, sp, #188
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	mov	x9, x8
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #8]
	str	x1, [x8]
	ldr	x8, [x8]
	cbnz	x8, LBB24_2
	b	LBB24_1
LBB24_1:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.17@PAGE
	add	x8, x8, l_.str.17@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_2:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB24_4
	b	LBB24_3
LBB24_3:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.18@PAGE
	add	x8, x8, l_.str.18@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_4:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_nvm_owned_array_route
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	w0, [x8, #648]
	ldr	w8, [x8, #648]
	subs	w8, w8, #1
	b.eq	LBB24_6
	b	LBB24_5
LBB24_5:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w10, [x8, #648]
	mov	w8, #2                          ; =0x2
	subs	w10, w10, #2
	csinc	w8, w8, wzr, eq
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.19@PAGE
	add	x8, x8, l_.str.19@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_6:
	sub	x0, x29, #88
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #4]                    ; 4-byte Folded Spill
	bl	_memset
	ldr	w1, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	sub	x0, x29, #152
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_memset
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	add	x1, sp, #352
	bl	_owner_array_parameter_view
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	w0, [x8, #160]
	ldr	w8, [x8, #160]
	cbz	w8, LBB24_8
	b	LBB24_7
LBB24_7:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #160]
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.20@PAGE
	add	x8, x8, l_.str.20@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #336
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x8, #148]
	add	x8, sp, #312
	add	x0, sp, #352
	bl	_nvm_prepare_owned_array_authority
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #124]
	cbz	w8, LBB24_10
	b	LBB24_9
LBB24_9:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	q0, [x8, #124]
	str	q0, [x9]
	ldur	x8, [x8, #140]
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #148]
	mov	w1, #0                          ; =0x0
	add	x2, sp, #196
	bl	_nvm_owned_array_plan_signature
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbz	w0, #0, LBB24_17
	b	LBB24_11
LBB24_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #10]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbnz	w8, LBB24_17
	b	LBB24_12
LBB24_12:
	ldrb	w8, [sp, #204]
	subs	w8, w8, #1
	b.eq	LBB24_15
	b	LBB24_13
LBB24_13:
	ldrb	w8, [sp, #204]
	subs	w8, w8, #4
	b.eq	LBB24_15
	b	LBB24_14
LBB24_14:
	ldrb	w9, [sp, #204]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #2
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB24_17
	b	LBB24_15
LBB24_15:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	tbz	w8, #0, LBB24_17
	b	LBB24_16
LBB24_16:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB24_17
LBB24_17:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [sp]                        ; 4-byte Folded Reload
	and	w9, w9, #0x1
	strb	w9, [sp, #195]
	str	wzr, [x8]
	b	LBB24_18
LBB24_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_27 Depth 2
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB24_36
	b	LBB24_19
LBB24_19:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #256]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w1, [x8, x9]
	bl	_nvm_get_string
	str	x0, [sp, #176]
	ldr	x8, [sp, #176]
	cbz	x8, LBB24_22
	b	LBB24_20
LBB24_20:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x0, [sp, #176]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB24_22
	b	LBB24_21
LBB24_21:                               ;   in Loop: Header=BB24_18 Depth=1
	strb	wzr, [sp, #195]
	b	LBB24_22
LBB24_22:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #148]
	ldr	w1, [x8]
	add	x2, sp, #60
	bl	_nvm_owned_array_plan_signature
	tbnz	w0, #0, LBB24_24
	b	LBB24_23
LBB24_23:                               ;   in Loop: Header=BB24_18 Depth=1
	strb	wzr, [sp, #195]
	b	LBB24_35
LBB24_24:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #264]
	cbz	x8, LBB24_34
	b	LBB24_25
LBB24_25:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #264]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB24_34
	b	LBB24_26
LBB24_26:                               ;   in Loop: Header=BB24_18 Depth=1
	strh	wzr, [sp, #58]
	b	LBB24_27
LBB24_27:                               ;   Parent Loop BB24_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #58]
	ldrh	w9, [sp, #62]
	subs	w8, w8, w9
	b.ge	LBB24_33
	b	LBB24_28
LBB24_28:                               ;   in Loop: Header=BB24_27 Depth=2
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	x8, [x8, #264]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #58]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #57]
	ldrb	w8, [sp, #57]
	cbz	w8, LBB24_31
	b	LBB24_29
LBB24_29:                               ;   in Loop: Header=BB24_27 Depth=2
	ldrb	w8, [sp, #57]
	add	x9, sp, #60
	add	x9, x9, #20
	ldrh	w10, [sp, #58]
                                        ; kill: def $x10 killed $w10
	mov	x11, #12                        ; =0xc
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB24_31
	b	LBB24_30
LBB24_30:                               ;   in Loop: Header=BB24_27 Depth=2
	strb	wzr, [sp, #195]
	b	LBB24_31
LBB24_31:                               ;   in Loop: Header=BB24_27 Depth=2
	b	LBB24_32
LBB24_32:                               ;   in Loop: Header=BB24_27 Depth=2
	ldrh	w8, [sp, #58]
	add	w8, w8, #1
	strh	w8, [sp, #58]
	b	LBB24_27
LBB24_33:                               ;   in Loop: Header=BB24_18 Depth=1
	b	LBB24_34
LBB24_34:                               ;   in Loop: Header=BB24_18 Depth=1
	b	LBB24_35
LBB24_35:                               ;   in Loop: Header=BB24_18 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB24_18
LBB24_36:
	ldrb	w8, [sp, #195]
	tbnz	w8, #0, LBB24_38
	b	LBB24_37
LBB24_37:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #148]
	bl	_nvm_owned_array_plan_free
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.21@PAGE
	add	x8, x8, l_.str.21@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_38:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #148]
	ldr	x10, [x10]
	str	x8, [x10]
	str	wzr, [x9]
	str	wzr, [x9, #4]
	str	wzr, [x9, #8]
	str	wzr, [x9, #12]
	adrp	x8, l_.str.22@PAGE
	add	x8, x8, l_.str.22@PAGEOFF
	str	x8, [x9, #16]
	b	LBB24_39
LBB24_39:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB24_41
	b	LBB24_40
LBB24_40:
	bl	___stack_chk_fail
LBB24_41:
	add	sp, sp, #992
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function owner_array_parameter_view
_owner_array_parameter_view:            ; @owner_array_parameter_view
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB25_2
	b	LBB25_1
LBB25_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB25_3
	b	LBB25_2
LBB25_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_3:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	subs	w8, w8, #8
	b.ls	LBB25_5
	b	LBB25_4
LBB25_4:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_5:
	ldur	x8, [x29, #-16]
	ldr	x1, [x8, #296]
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #64
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	x1, sp, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB25_14
	b	LBB25_6
LBB25_6:
	ldr	w8, [sp, #60]
	subs	w8, w8, #1
	b.eq	LBB25_8
	b	LBB25_7
LBB25_7:
	ldr	w8, [sp, #60]
	subs	w8, w8, #2
	b.ne	LBB25_14
	b	LBB25_8
LBB25_8:
	add	x0, sp, #64
	add	x1, sp, #56
	bl	_nvm_v2_u32
	cbnz	w0, LBB25_14
	b	LBB25_9
LBB25_9:
	ldr	w8, [sp, #56]
	subs	w8, w8, #256
	b.hi	LBB25_14
	b	LBB25_10
LBB25_10:
	ldr	w8, [sp, #56]
	mov	x1, x8
	add	x0, sp, #64
	add	x2, sp, #48
	bl	_nvm_v2_take
	cbnz	w0, LBB25_14
	b	LBB25_11
LBB25_11:
	add	x0, sp, #64
	bl	_nvm_v2_align4
	cbnz	w0, LBB25_14
	b	LBB25_12
LBB25_12:
	add	x0, sp, #64
	add	x1, sp, #56
	bl	_nvm_v2_u32
	cbnz	w0, LBB25_14
	b	LBB25_13
LBB25_13:
	ldr	w8, [sp, #56]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.eq	LBB25_15
	b	LBB25_14
LBB25_14:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_15:
	str	wzr, [sp, #44]
	b	LBB25_16
LBB25_16:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_27 Depth 2
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #56]
	subs	w8, w8, w9
	b.hs	LBB25_49
	b	LBB25_17
LBB25_17:                               ;   in Loop: Header=BB25_16 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #4]
	subs	w8, w8, #8
	b.gt	LBB25_19
	b	LBB25_18
LBB25_18:                               ;   in Loop: Header=BB25_16 Depth=1
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.le	LBB25_20
	b	LBB25_19
LBB25_19:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_20:                               ;   in Loop: Header=BB25_16 Depth=1
	add	x0, sp, #64
	add	x1, sp, #30
	bl	_nvm_v2_u16
	cbnz	w0, LBB25_25
	b	LBB25_21
LBB25_21:                               ;   in Loop: Header=BB25_16 Depth=1
	add	x0, sp, #64
	add	x1, sp, #28
	bl	_nvm_v2_u16
	cbnz	w0, LBB25_25
	b	LBB25_22
LBB25_22:                               ;   in Loop: Header=BB25_16 Depth=1
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB25_25
	b	LBB25_23
LBB25_23:                               ;   in Loop: Header=BB25_16 Depth=1
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB25_25
	b	LBB25_24
LBB25_24:                               ;   in Loop: Header=BB25_16 Depth=1
	ldrh	w8, [sp, #28]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.le	LBB25_26
	b	LBB25_25
LBB25_25:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_26:                               ;   in Loop: Header=BB25_16 Depth=1
	ldur	x8, [x29, #-40]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	ldur	x9, [x29, #-32]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	str	wzr, [sp, #24]
	b	LBB25_27
LBB25_27:                               ;   Parent Loop BB25_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #24]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.hi	LBB25_47
	b	LBB25_28
LBB25_28:                               ;   in Loop: Header=BB25_27 Depth=2
	add	x0, sp, #64
	mov	x1, #8                          ; =0x8
	add	x2, sp, #16
	bl	_nvm_v2_take
	cbz	w0, LBB25_30
	b	LBB25_29
LBB25_29:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_30:                               ;   in Loop: Header=BB25_27 Depth=2
	ldr	w8, [sp, #24]
	cbz	w8, LBB25_32
	b	LBB25_31
LBB25_31:                               ;   in Loop: Header=BB25_27 Depth=2
	ldr	w8, [sp, #24]
	ldrh	w9, [sp, #28]
	subs	w8, w8, w9
	b.ls	LBB25_33
	b	LBB25_32
LBB25_32:                               ;   in Loop: Header=BB25_27 Depth=2
	b	LBB25_46
LBB25_33:                               ;   in Loop: Header=BB25_27 Depth=2
	ldr	x8, [sp, #16]
	ldrb	w8, [x8]
	strb	w8, [sp, #15]
	ldrb	w8, [sp, #15]
	subs	w8, w8, #1
	b.eq	LBB25_39
	b	LBB25_34
LBB25_34:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #15]
	subs	w8, w8, #4
	b.eq	LBB25_39
	b	LBB25_35
LBB25_35:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #15]
	subs	w8, w8, #2
	b.eq	LBB25_39
	b	LBB25_36
LBB25_36:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #15]
	subs	w8, w8, #5
	b.eq	LBB25_39
	b	LBB25_37
LBB25_37:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #15]
	subs	w8, w8, #8
	b.eq	LBB25_39
	b	LBB25_38
LBB25_38:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_39:                               ;   in Loop: Header=BB25_27 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	cbz	x8, LBB25_45
	b	LBB25_40
LBB25_40:                               ;   in Loop: Header=BB25_27 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB25_45
	b	LBB25_41
LBB25_41:                               ;   in Loop: Header=BB25_27 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #44]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	w9, [sp, #24]
	subs	w9, w9, #1
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #14]
	ldrb	w8, [sp, #14]
	cbz	w8, LBB25_44
	b	LBB25_42
LBB25_42:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #14]
	ldrb	w9, [sp, #15]
	subs	w8, w8, w9
	b.eq	LBB25_44
	b	LBB25_43
LBB25_43:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB25_50
LBB25_44:                               ;   in Loop: Header=BB25_27 Depth=2
	b	LBB25_45
LBB25_45:                               ;   in Loop: Header=BB25_27 Depth=2
	ldrb	w8, [sp, #15]
	ldur	x9, [x29, #-40]
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #3
	ldr	w10, [sp, #24]
	subs	w10, w10, #1
	mov	w10, w10
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	b	LBB25_46
LBB25_46:                               ;   in Loop: Header=BB25_27 Depth=2
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB25_27
LBB25_47:                               ;   in Loop: Header=BB25_16 Depth=1
	b	LBB25_48
LBB25_48:                               ;   in Loop: Header=BB25_16 Depth=1
	ldr	w8, [sp, #44]
	add	w8, w8, #1
	str	w8, [sp, #44]
	b	LBB25_16
LBB25_49:
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-16]
	mov	x2, #480                        ; =0x1e0
	bl	_memcpy
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-24]
	str	x8, [x9, #264]
	stur	wzr, [x29, #-4]
	b	LBB25_50
LBB25_50:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_array_structure_free ; -- Begin function nvm_record_array_structure_free
	.p2align	2
_nvm_record_array_structure_free:       ; @nvm_record_array_structure_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB26_2
	b	LBB26_1
LBB26_1:
	b	LBB26_7
LBB26_2:
	str	wzr, [sp, #4]
	b	LBB26_3
LBB26_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB26_6
	b	LBB26_4
LBB26_4:                                ;   in Loop: Header=BB26_3 Depth=1
	ldr	x8, [sp, #8]
	add	x8, x8, #16
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #5
	bl	_vm_decoded_function_free
	b	LBB26_5
LBB26_5:                                ;   in Loop: Header=BB26_3 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB26_3
LBB26_6:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_ownership_declarations_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB26_7
LBB26_7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_array_structure_prepare ; -- Begin function nvm_record_array_structure_prepare
	.p2align	2
_nvm_record_array_structure_prepare:    ; @nvm_record_array_structure_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #8]
	mov	x3, #0                          ; =0x0
	bl	_record_structure_prepare
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function record_structure_prepare
_record_structure_prepare:              ; @record_structure_prepare
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #312]
	str	x1, [sp, #304]
	str	x2, [sp, #296]
	str	x3, [sp, #288]
	ldr	x8, [sp, #312]
	cbz	x8, LBB28_3
	b	LBB28_1
LBB28_1:
	ldr	x8, [sp, #304]
	cbz	x8, LBB28_3
	b	LBB28_2
LBB28_2:
	ldr	x8, [sp, #296]
	cbnz	x8, LBB28_4
	b	LBB28_3
LBB28_3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.24@PAGE
	add	x2, x2, l_.str.24@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_4:
	ldr	x8, [sp, #304]
	ldr	x8, [x8]
	cbnz	x8, LBB28_9
	b	LBB28_5
LBB28_5:
	ldr	x8, [sp, #304]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB28_9
	b	LBB28_6
LBB28_6:
	ldr	x8, [sp, #304]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB28_9
	b	LBB28_7
LBB28_7:
	ldr	x8, [sp, #304]
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB28_9
	b	LBB28_8
LBB28_8:
	ldr	x8, [sp, #304]
	ldrb	w8, [x8, #25]
	tbz	w8, #0, LBB28_10
	b	LBB28_9
LBB28_9:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.25@PAGE
	add	x2, x2, l_.str.25@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_10:
	ldr	x0, [sp, #304]
	mov	x1, #65536                      ; =0x10000
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB28_12
	b	LBB28_11
LBB28_11:
	ldr	x0, [sp, #304]
	mov	x1, #65536                      ; =0x10000
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_13
	b	LBB28_12
LBB28_12:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.26@PAGE
	add	x2, x2, l_.str.26@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_13:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB28_20
	b	LBB28_14
LBB28_14:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #336]
	cbnz	w8, LBB28_20
	b	LBB28_15
LBB28_15:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB28_20
	b	LBB28_16
LBB28_16:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB28_20
	b	LBB28_17
LBB28_17:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #344]
	cbnz	x8, LBB28_20
	b	LBB28_18
LBB28_18:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB28_20
	b	LBB28_19
LBB28_19:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #424]
	cbz	w8, LBB28_21
	b	LBB28_20
LBB28_20:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.27@PAGE
	add	x2, x2, l_.str.27@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_21:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #272]
	subs	w8, w8, #256
	b.hi	LBB28_24
	b	LBB28_22
LBB28_22:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #248]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.hi	LBB28_24
	b	LBB28_23
LBB28_23:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #288]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB28_25
	b	LBB28_24
LBB28_24:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.28@PAGE
	add	x2, x2, l_.str.28@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_25:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #272]
	cbz	w8, LBB28_34
	b	LBB28_26
LBB28_26:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #256]
	cbz	x8, LBB28_34
	b	LBB28_27
LBB28_27:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #288]
	cbz	w8, LBB28_29
	b	LBB28_28
LBB28_28:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #280]
	cbz	x8, LBB28_34
	b	LBB28_29
LBB28_29:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #248]
	cbz	w8, LBB28_32
	b	LBB28_30
LBB28_30:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #232]
	cbz	x8, LBB28_34
	b	LBB28_31
LBB28_31:
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #240]
	cbz	x8, LBB28_34
	b	LBB28_32
LBB28_32:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #224]
	subs	w8, w8, #16
	b.hi	LBB28_34
	b	LBB28_33
LBB28_33:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #16]
	subs	w8, w8, #16
	b.ls	LBB28_35
	b	LBB28_34
LBB28_34:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.29@PAGE
	add	x2, x2, l_.str.29@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_35:
	ldr	x8, [sp, #312]
	ldrb	w8, [x8]
	subs	w8, w8, #78
	b.ne	LBB28_41
	b	LBB28_36
LBB28_36:
	ldr	x8, [sp, #312]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #86
	b.ne	LBB28_41
	b	LBB28_37
LBB28_37:
	ldr	x8, [sp, #312]
	ldrb	w8, [x8, #2]
	subs	w8, w8, #77
	b.ne	LBB28_41
	b	LBB28_38
LBB28_38:
	ldr	x8, [sp, #312]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #1
	b.ne	LBB28_41
	b	LBB28_39
LBB28_39:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #4]
	subs	w8, w8, #2
	b.ne	LBB28_41
	b	LBB28_40
LBB28_40:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #8]
	and	w8, w8, #0xfffffff8
	cbz	w8, LBB28_42
	b	LBB28_41
LBB28_41:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.30@PAGE
	add	x2, x2, l_.str.30@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_42:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB28_44
	b	LBB28_43
LBB28_43:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB28_45
	b	LBB28_44
LBB28_44:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.31@PAGE
	add	x2, x2, l_.str.31@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_45:
	str	wzr, [sp, #284]
	b	LBB28_46
LBB28_46:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #284]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB28_55
	b	LBB28_47
LBB28_47:                               ;   in Loop: Header=BB28_46 Depth=1
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #284]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB28_49
	b	LBB28_48
LBB28_48:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.32@PAGE
	add	x2, x2, l_.str.32@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_49:                               ;   in Loop: Header=BB28_46 Depth=1
	ldr	x0, [sp, #304]
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #284]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_51
	b	LBB28_50
LBB28_50:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.33@PAGE
	add	x2, x2, l_.str.33@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_51:                               ;   in Loop: Header=BB28_46 Depth=1
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #284]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #312]
	ldr	x9, [x9, #240]
	ldr	w10, [sp, #284]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbz	w8, LBB28_53
	b	LBB28_52
LBB28_52:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.34@PAGE
	add	x2, x2, l_.str.34@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_53:                               ;   in Loop: Header=BB28_46 Depth=1
	b	LBB28_54
LBB28_54:                               ;   in Loop: Header=BB28_46 Depth=1
	ldr	w8, [sp, #284]
	add	w8, w8, #1
	str	w8, [sp, #284]
	b	LBB28_46
LBB28_55:
	ldr	x0, [sp, #304]
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #368]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #5
	add	x1, x8, #1
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_57
	b	LBB28_56
LBB28_56:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.35@PAGE
	add	x2, x2, l_.str.35@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_57:
	ldr	x0, [sp, #312]
	bl	_nvm_metadata_valid
	tbnz	w0, #0, LBB28_59
	b	LBB28_58
LBB28_58:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.36@PAGE
	add	x2, x2, l_.str.36@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_59:
	add	x0, sp, #1096
	mov	x1, #1024                       ; =0x400
	bl	_bzero
	str	wzr, [sp, #280]
	str	wzr, [sp, #276]
	b	LBB28_60
LBB28_60:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB28_78 Depth 2
                                        ;     Child Loop BB28_92 Depth 2
	ldr	w8, [sp, #276]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB28_111
	b	LBB28_61
LBB28_61:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #312]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #276]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #264]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB28_64
	b	LBB28_62
LBB28_62:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB28_64
	b	LBB28_63
LBB28_63:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.37@PAGE
	add	x2, x2, l_.str.37@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_64:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.le	LBB28_66
	b	LBB28_65
LBB28_65:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.38@PAGE
	add	x2, x2, l_.str.38@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_66:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB28_71
	b	LBB28_67
LBB28_67:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB28_71
	b	LBB28_68
LBB28_68:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #5
	b.le	LBB28_72
	b	LBB28_69
LBB28_69:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #7
	b.eq	LBB28_72
	b	LBB28_70
LBB28_70:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #8
	b.eq	LBB28_72
	b	LBB28_71
LBB28_71:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.39@PAGE
	add	x2, x2, l_.str.39@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_72:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB28_74
	b	LBB28_73
LBB28_73:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #288]
	ldr	x10, [sp, #264]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB28_75
	b	LBB28_74
LBB28_74:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.40@PAGE
	add	x2, x2, l_.str.40@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_75:                               ;   in Loop: Header=BB28_60 Depth=1
	ldr	x0, [sp, #304]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #256
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_77
	b	LBB28_76
LBB28_76:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.41@PAGE
	add	x2, x2, l_.str.41@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_77:                               ;   in Loop: Header=BB28_60 Depth=1
	strh	wzr, [sp, #262]
	b	LBB28_78
LBB28_78:                               ;   Parent Loop BB28_60 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #262]
	ldr	x9, [sp, #264]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB28_91
	b	LBB28_79
LBB28_79:                               ;   in Loop: Header=BB28_78 Depth=2
	ldrh	w8, [sp, #262]
	subs	w8, w8, #256
	b.lt	LBB28_81
	b	LBB28_80
LBB28_80:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.42@PAGE
	add	x2, x2, l_.str.42@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_81:                               ;   in Loop: Header=BB28_78 Depth=2
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #264]
	cbz	x8, LBB28_84
	b	LBB28_82
LBB28_82:                               ;   in Loop: Header=BB28_78 Depth=2
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #276]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB28_84
	b	LBB28_83
LBB28_83:                               ;   in Loop: Header=BB28_78 Depth=2
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #276]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #262]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB28_85
LBB28_84:                               ;   in Loop: Header=BB28_78 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB28_85
LBB28_85:                               ;   in Loop: Header=BB28_78 Depth=2
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	strb	w8, [sp, #261]
	ldrb	w8, [sp, #261]
	subs	w8, w8, #5
	b.le	LBB28_89
	b	LBB28_86
LBB28_86:                               ;   in Loop: Header=BB28_78 Depth=2
	ldrb	w8, [sp, #261]
	subs	w8, w8, #7
	b.eq	LBB28_89
	b	LBB28_87
LBB28_87:                               ;   in Loop: Header=BB28_78 Depth=2
	ldrb	w8, [sp, #261]
	subs	w8, w8, #8
	b.eq	LBB28_89
	b	LBB28_88
LBB28_88:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.43@PAGE
	add	x2, x2, l_.str.43@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_89:                               ;   in Loop: Header=BB28_78 Depth=2
	b	LBB28_90
LBB28_90:                               ;   in Loop: Header=BB28_78 Depth=2
	ldrh	w8, [sp, #262]
	add	w8, w8, #1
	strh	w8, [sp, #262]
	b	LBB28_78
LBB28_91:                               ;   in Loop: Header=BB28_60 Depth=1
	str	wzr, [sp, #256]
	b	LBB28_92
LBB28_92:                               ;   Parent Loop BB28_60 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #256]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB28_109
	b	LBB28_93
LBB28_93:                               ;   in Loop: Header=BB28_92 Depth=2
	ldr	x8, [sp, #312]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #256]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #12]
	ldr	w9, [sp, #256]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #192
	bl	_isa_decode
	str	w0, [sp, #188]
	ldr	w8, [sp, #188]
	cbnz	w8, LBB28_95
	b	LBB28_94
LBB28_94:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.44@PAGE
	add	x2, x2, l_.str.44@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_95:                               ;   in Loop: Header=BB28_92 Depth=2
	ldr	w8, [sp, #280]
	add	w8, w8, #1
	str	w8, [sp, #280]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB28_97
	b	LBB28_96
LBB28_96:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.45@PAGE
	add	x2, x2, l_.str.45@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_97:                               ;   in Loop: Header=BB28_92 Depth=2
	ldr	w8, [sp, #276]
	mov	x10, x8
	add	x9, sp, #1096
	ldr	w8, [x9, x10, lsl #2]
	add	w8, w8, #1
	str	w8, [x9, x10, lsl #2]
	ldrb	w0, [sp, #192]
	bl	_nvm_record_array_opcode_supported
	tbnz	w0, #0, LBB28_100
	b	LBB28_98
LBB28_98:                               ;   in Loop: Header=BB28_92 Depth=2
	ldr	x8, [sp, #288]
	cbz	x8, LBB28_103
	b	LBB28_99
LBB28_99:                               ;   in Loop: Header=BB28_92 Depth=2
	ldrb	w0, [sp, #192]
	bl	_nvm_record_map_opcode
	tbz	w0, #0, LBB28_103
	b	LBB28_100
LBB28_100:                              ;   in Loop: Header=BB28_92 Depth=2
	ldrb	w8, [sp, #192]
	subs	w8, w8, #251
	b.ne	LBB28_104
	b	LBB28_101
LBB28_101:                              ;   in Loop: Header=BB28_92 Depth=2
	ldrb	w8, [sp, #200]
	cbnz	w8, LBB28_103
	b	LBB28_102
LBB28_102:                              ;   in Loop: Header=BB28_92 Depth=2
	ldrh	w8, [sp, #216]
	cbz	w8, LBB28_104
	b	LBB28_103
LBB28_103:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.104@PAGE
	add	x2, x2, l_.str.104@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_104:                              ;   in Loop: Header=BB28_92 Depth=2
	ldrb	w8, [sp, #192]
	subs	w8, w8, #18
	b.eq	LBB28_106
	b	LBB28_105
LBB28_105:                              ;   in Loop: Header=BB28_92 Depth=2
	ldrb	w8, [sp, #192]
	subs	w8, w8, #19
	b.ne	LBB28_108
	b	LBB28_106
LBB28_106:                              ;   in Loop: Header=BB28_92 Depth=2
	ldr	w8, [sp, #200]
	subs	w8, w8, #256
	b.lo	LBB28_108
	b	LBB28_107
LBB28_107:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #276]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.47@PAGE
	add	x2, x2, l_.str.47@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_108:                              ;   in Loop: Header=BB28_92 Depth=2
	ldr	w9, [sp, #188]
	ldr	w8, [sp, #256]
	add	w8, w8, w9
	str	w8, [sp, #256]
	b	LBB28_92
LBB28_109:                              ;   in Loop: Header=BB28_60 Depth=1
	b	LBB28_110
LBB28_110:                              ;   in Loop: Header=BB28_60 Depth=1
	ldr	w8, [sp, #276]
	add	w8, w8, #1
	str	w8, [sp, #276]
	b	LBB28_60
LBB28_111:
	str	wzr, [sp, #184]
	b	LBB28_112
LBB28_112:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #184]
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB28_117
	b	LBB28_113
LBB28_113:                              ;   in Loop: Header=BB28_112 Depth=1
	ldr	x0, [sp, #304]
	ldr	x8, [sp, #312]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #184]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #312]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #184]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #312]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x1, x8, #32
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_115
	b	LBB28_114
LBB28_114:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #184]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.48@PAGE
	add	x2, x2, l_.str.48@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_115:                              ;   in Loop: Header=BB28_112 Depth=1
	b	LBB28_116
LBB28_116:                              ;   in Loop: Header=BB28_112 Depth=1
	ldr	w8, [sp, #184]
	add	w8, w8, #1
	str	w8, [sp, #184]
	b	LBB28_112
LBB28_117:
	ldr	x0, [sp, #304]
	mov	x1, #32                         ; =0x20
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_119
	b	LBB28_118
LBB28_118:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.49@PAGE
	add	x2, x2, l_.str.49@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_119:
	ldr	x0, [sp, #312]
	add	x8, sp, #839
	bl	_verify_module_ranges
	ldrb	w8, [sp, #839]
	tbnz	w8, #0, LBB28_121
	b	LBB28_120
LBB28_120:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, sp, #839
	add	x2, x9, #1
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB28_174
LBB28_121:
	ldr	x0, [sp, #312]
	add	x8, sp, #582
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	bl	_verify_module_contracts_and_imports
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	add	x0, sp, #839
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #839]
	tbnz	w8, #0, LBB28_123
	b	LBB28_122
LBB28_122:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, sp, #839
	add	x2, x9, #1
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB28_174
LBB28_123:
	ldr	x0, [sp, #304]
	mov	x1, #16777216                   ; =0x1000000
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB28_125
	b	LBB28_124
LBB28_124:
	ldr	x0, [sp, #304]
	mov	x1, #1048576                    ; =0x100000
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_126
	b	LBB28_125
LBB28_125:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.50@PAGE
	add	x2, x2, l_.str.50@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_126:
	ldr	x0, [sp, #304]
	mov	x1, #1                          ; =0x1
	mov	x2, #8720                       ; =0x2210
	bl	_nvm_ra_alloc
	str	x0, [sp, #176]
	ldr	x8, [sp, #176]
	cbnz	x8, LBB28_128
	b	LBB28_127
LBB28_127:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #304]
	ldrb	w11, [x9, #24]
	mov	w10, #4                         ; =0x4
	mov	w9, #3                          ; =0x3
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w0, w9, w10, ne
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.105@PAGE
	add	x2, x2, l_.str.105@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_128:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #168]
	ldr	x8, [sp, #288]
	cbz	x8, LBB28_142
	b	LBB28_129
LBB28_129:
	ldr	x0, [sp, #304]
	mov	x1, #2097152                    ; =0x200000
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB28_131
	b	LBB28_130
LBB28_130:
	ldr	x0, [sp, #304]
	mov	x1, #4194304                    ; =0x400000
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_132
	b	LBB28_131
LBB28_131:
	ldr	x0, [sp, #176]
	bl	_nvm_record_array_structure_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.106@PAGE
	add	x2, x2, l_.str.106@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_132:
	ldr	x0, [sp, #312]
	ldr	x2, [sp, #176]
	add	x1, sp, #168
	bl	_nvm_prepare_map_declarations_split
	str	x0, [sp, #128]
	str	x1, [sp, #136]
	ldr	w8, [sp, #128]
	subs	w8, w8, #1
	b.ne	LBB28_134
	b	LBB28_133
LBB28_133:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB28_141
LBB28_134:
	ldr	w8, [sp, #128]
	subs	w8, w8, #4
	b.ne	LBB28_136
	b	LBB28_135
LBB28_135:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB28_140
LBB28_136:
	ldr	w8, [sp, #128]
	subs	w8, w8, #3
	b.ne	LBB28_138
	b	LBB28_137
LBB28_137:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB28_139
LBB28_138:
	ldr	w9, [sp, #128]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #0
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB28_139
LBB28_139:
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB28_140
LBB28_140:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB28_141
LBB28_141:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	str	w8, [sp, #112]
	str	wzr, [sp, #116]
	ldr	x8, [sp, #136]
	str	x8, [sp, #120]
	ldr	q0, [sp, #112]
	str	q0, [sp, #144]
	b	LBB28_143
LBB28_142:
	ldr	x0, [sp, #312]
	ldr	x1, [sp, #176]
	bl	_nvm_prepare_ownership_declarations
	str	x0, [sp, #96]
	str	x1, [sp, #104]
	ldr	q0, [sp, #96]
	str	q0, [sp, #144]
	b	LBB28_143
LBB28_143:
	ldr	w8, [sp, #144]
	cbz	w8, LBB28_151
	b	LBB28_144
LBB28_144:
	ldr	x0, [sp, #168]
	bl	_nvm_map_declarations_free
	ldr	x0, [sp, #176]
	bl	_nvm_record_array_structure_free
	ldr	w8, [sp, #144]
	subs	w8, w8, #4
	b.ne	LBB28_146
	b	LBB28_145
LBB28_145:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB28_150
LBB28_146:
	ldr	w8, [sp, #144]
	subs	w8, w8, #3
	b.ne	LBB28_148
	b	LBB28_147
LBB28_147:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB28_149
LBB28_148:
	ldr	w9, [sp, #144]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #1
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB28_149
LBB28_149:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB28_150
LBB28_150:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w0, [sp, #32]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #152]
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB28_174
LBB28_151:
	ldr	x8, [sp, #312]
	ldr	w8, [x8, #272]
	ldr	x9, [sp, #176]
	str	w8, [x9, #8]
	str	wzr, [sp, #92]
	b	LBB28_152
LBB28_152:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB28_154 Depth 2
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #176]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB28_171
	b	LBB28_153
LBB28_153:                              ;   in Loop: Header=BB28_152 Depth=1
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #80]
	b	LBB28_154
LBB28_154:                              ;   Parent Loop BB28_152 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #80]
	ldr	w9, [sp, #92]
	mov	x10, x9
	add	x9, sp, #1096
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB28_156
	b	LBB28_155
LBB28_155:                              ;   in Loop: Header=BB28_154 Depth=2
	ldr	x8, [sp, #80]
	lsl	x8, x8, #1
	str	x8, [sp, #80]
	b	LBB28_154
LBB28_156:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	x8, [sp, #312]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	add	w8, w8, #1
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #92]
	mov	x9, x8
	add	x8, sp, #1096
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB28_158
	b	LBB28_157
LBB28_157:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	x8, [sp, #80]
	mov	x9, #3                          ; =0x3
	mul	x8, x8, x9
	mov	x9, #104                        ; =0x68
	mul	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB28_159
LBB28_158:                              ;   in Loop: Header=BB28_152 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB28_159
LBB28_159:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	mov	w9, #5                          ; =0x5
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldr	x0, [sp, #304]
	ldr	x1, [sp, #72]
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB28_161
	b	LBB28_160
LBB28_160:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	x0, [sp, #304]
	ldr	x8, [sp, #312]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #92]
	mov	x10, x9
	add	x9, sp, #1096
	ldr	w9, [x9, x10, lsl #2]
	lsl	w9, w9, #4
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB28_162
	b	LBB28_161
LBB28_161:
	ldr	x0, [sp, #168]
	bl	_nvm_map_declarations_free
	ldr	x0, [sp, #176]
	bl	_nvm_record_array_structure_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #92]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.53@PAGE
	add	x2, x2, l_.str.53@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_162:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	x0, [sp, #312]
	ldr	w1, [sp, #92]
	ldr	x8, [sp, #176]
	mov	x9, #8208                       ; =0x2010
	add	x8, x8, x9
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x4, x8, x9, lsl #1
	ldr	x5, [sp, #304]
	ldr	x8, [sp, #176]
	add	x8, x8, #16
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x6, x8, x9, lsl #5
	add	x8, sp, #325
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_body
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, sp, #839
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #839]
	tbnz	w8, #0, LBB28_169
	b	LBB28_163
LBB28_163:
	ldr	x0, [sp, #168]
	bl	_nvm_map_declarations_free
	ldr	x0, [sp, #176]
	bl	_nvm_record_array_structure_free
	ldr	x8, [sp, #304]
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB28_165
	b	LBB28_164
LBB28_164:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB28_168
LBB28_165:
	ldr	x8, [sp, #304]
	ldrb	w8, [x8, #25]
	mov	w9, #1                          ; =0x1
	str	w9, [sp]                        ; 4-byte Folded Spill
	tbnz	w8, #0, LBB28_167
	b	LBB28_166
LBB28_166:
	add	x8, sp, #839
	add	x0, x8, #1
	adrp	x1, l_.str.54@PAGE
	add	x1, x1, l_.str.54@PAGEOFF
	bl	_strstr
	subs	x8, x0, #0
	cset	w8, ne
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB28_167
LBB28_167:
	ldr	w10, [sp]                       ; 4-byte Folded Reload
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB28_168
LBB28_168:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldr	w1, [sp, #92]
	add	x9, sp, #839
	add	x2, x9, #1
	bl	_ra_result
	b	LBB28_174
LBB28_169:                              ;   in Loop: Header=BB28_152 Depth=1
	b	LBB28_170
LBB28_170:                              ;   in Loop: Header=BB28_152 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB28_152
LBB28_171:
	ldr	x8, [sp, #288]
	cbz	x8, LBB28_173
	b	LBB28_172
LBB28_172:
	ldr	x8, [sp, #168]
	ldr	x9, [sp, #288]
	str	x8, [x9]
	b	LBB28_173
LBB28_173:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #176]
	ldr	x10, [sp, #296]
	str	x9, [x10]
	mov	w1, #0                          ; =0x0
	mov	x0, x1
	adrp	x2, l_.str.55@PAGE
	add	x2, x2, l_.str.55@PAGEOFF
	bl	_ra_result
	b	LBB28_174
LBB28_174:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB28_176
	b	LBB28_175
LBB28_175:
	bl	___stack_chk_fail
LBB28_176:
	add	sp, sp, #2128
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_map_structure_prepare ; -- Begin function nvm_record_map_structure_prepare
	.p2align	2
_nvm_record_map_structure_prepare:      ; @nvm_record_map_structure_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	str	x2, [sp, #24]
	str	x3, [sp, #16]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB29_2
	b	LBB29_1
LBB29_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.23@PAGE
	add	x2, x2, l_.str.23@PAGEOFF
	bl	_ra_result
	b	LBB29_3
LBB29_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldr	x2, [sp, #24]
	ldr	x3, [sp, #16]
	bl	_record_structure_prepare
	b	LBB29_3
LBB29_3:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ra_result
_ra_result:                             ; @ra_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	stur	w8, [x29, #-4]
	stur	w1, [x29, #-8]
	stur	x2, [x29, #-16]
	mov	x2, #204                        ; =0xcc
	mov	w1, #0                          ; =0x0
	stur	w1, [x29, #-20]                 ; 4-byte Folded Spill
	bl	_memset
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w2, [x29, #-20]                 ; 4-byte Folded Reload
	ldur	w9, [x29, #-4]
	str	w9, [x8]
	ldur	w9, [x29, #-8]
	str	w9, [x8, #4]
	ldur	x9, [x29, #-16]
	mov	x10, sp
	str	x9, [x10]
	add	x0, x8, #12
	mov	x3, #192                        ; =0xc0
	mov	x1, x3
	adrp	x4, l_.str.67@PAGE
	add	x4, x4, l_.str.67@PAGEOFF
	bl	___snprintf_chk
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_union_structure_free ; -- Begin function nvm_record_union_structure_free
	.p2align	2
_nvm_record_union_structure_free:       ; @nvm_record_union_structure_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB31_2
	b	LBB31_1
LBB31_1:
	b	LBB31_3
LBB31_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_record_array_structure_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_nvm_union_field_declarations_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB31_3
LBB31_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_record_union_structure_prepare ; -- Begin function nvm_record_union_structure_prepare
	.p2align	2
_nvm_record_union_structure_prepare:    ; @nvm_record_union_structure_prepare
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2080
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #264]
	str	x1, [sp, #256]
	str	x2, [sp, #248]
	ldr	x8, [sp, #264]
	cbz	x8, LBB32_3
	b	LBB32_1
LBB32_1:
	ldr	x8, [sp, #256]
	cbz	x8, LBB32_3
	b	LBB32_2
LBB32_2:
	ldr	x8, [sp, #248]
	cbnz	x8, LBB32_4
	b	LBB32_3
LBB32_3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.24@PAGE
	add	x2, x2, l_.str.24@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_4:
	ldr	x8, [sp, #256]
	ldr	x8, [x8]
	cbnz	x8, LBB32_9
	b	LBB32_5
LBB32_5:
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB32_9
	b	LBB32_6
LBB32_6:
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB32_9
	b	LBB32_7
LBB32_7:
	ldr	x8, [sp, #256]
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB32_9
	b	LBB32_8
LBB32_8:
	ldr	x8, [sp, #256]
	ldrb	w8, [x8, #25]
	tbz	w8, #0, LBB32_10
	b	LBB32_9
LBB32_9:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.25@PAGE
	add	x2, x2, l_.str.25@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_10:
	ldr	x0, [sp, #256]
	mov	x1, #65536                      ; =0x10000
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB32_12
	b	LBB32_11
LBB32_11:
	ldr	x0, [sp, #256]
	mov	x1, #65536                      ; =0x10000
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_13
	b	LBB32_12
LBB32_12:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.26@PAGE
	add	x2, x2, l_.str.26@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_13:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #328]
	cbnz	x8, LBB32_20
	b	LBB32_14
LBB32_14:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #336]
	cbnz	w8, LBB32_20
	b	LBB32_15
LBB32_15:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB32_20
	b	LBB32_16
LBB32_16:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB32_20
	b	LBB32_17
LBB32_17:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #344]
	cbnz	x8, LBB32_20
	b	LBB32_18
LBB32_18:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB32_20
	b	LBB32_19
LBB32_19:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #424]
	cbz	w8, LBB32_21
	b	LBB32_20
LBB32_20:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.27@PAGE
	add	x2, x2, l_.str.27@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_21:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #272]
	subs	w8, w8, #256
	b.hi	LBB32_24
	b	LBB32_22
LBB32_22:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #248]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.hi	LBB32_24
	b	LBB32_23
LBB32_23:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #288]
	mov	w9, #16777216                   ; =0x1000000
	subs	w8, w8, w9
	b.ls	LBB32_25
	b	LBB32_24
LBB32_24:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.28@PAGE
	add	x2, x2, l_.str.28@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_25:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #272]
	cbz	w8, LBB32_34
	b	LBB32_26
LBB32_26:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #256]
	cbz	x8, LBB32_34
	b	LBB32_27
LBB32_27:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #288]
	cbz	w8, LBB32_29
	b	LBB32_28
LBB32_28:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #280]
	cbz	x8, LBB32_34
	b	LBB32_29
LBB32_29:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #248]
	cbz	w8, LBB32_32
	b	LBB32_30
LBB32_30:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #232]
	cbz	x8, LBB32_34
	b	LBB32_31
LBB32_31:
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #240]
	cbz	x8, LBB32_34
	b	LBB32_32
LBB32_32:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #224]
	subs	w8, w8, #16
	b.hi	LBB32_34
	b	LBB32_33
LBB32_33:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #16]
	subs	w8, w8, #16
	b.ls	LBB32_35
	b	LBB32_34
LBB32_34:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.29@PAGE
	add	x2, x2, l_.str.29@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_35:
	ldr	x8, [sp, #264]
	ldrb	w8, [x8]
	subs	w8, w8, #78
	b.ne	LBB32_41
	b	LBB32_36
LBB32_36:
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #1]
	subs	w8, w8, #86
	b.ne	LBB32_41
	b	LBB32_37
LBB32_37:
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #2]
	subs	w8, w8, #77
	b.ne	LBB32_41
	b	LBB32_38
LBB32_38:
	ldr	x8, [sp, #264]
	ldrb	w8, [x8, #3]
	subs	w8, w8, #1
	b.ne	LBB32_41
	b	LBB32_39
LBB32_39:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #4]
	subs	w8, w8, #2
	b.ne	LBB32_41
	b	LBB32_40
LBB32_40:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #8]
	and	w8, w8, #0xfffffff8
	cbz	w8, LBB32_42
	b	LBB32_41
LBB32_41:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.30@PAGE
	add	x2, x2, l_.str.30@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_42:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB32_44
	b	LBB32_43
LBB32_43:
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB32_45
	b	LBB32_44
LBB32_44:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.31@PAGE
	add	x2, x2, l_.str.31@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_45:
	str	wzr, [sp, #244]
	b	LBB32_46
LBB32_46:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #244]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB32_55
	b	LBB32_47
LBB32_47:                               ;   in Loop: Header=BB32_46 Depth=1
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB32_49
	b	LBB32_48
LBB32_48:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.32@PAGE
	add	x2, x2, l_.str.32@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_49:                               ;   in Loop: Header=BB32_46 Depth=1
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	add	x1, x8, #1
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_51
	b	LBB32_50
LBB32_50:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.33@PAGE
	add	x2, x2, l_.str.33@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_51:                               ;   in Loop: Header=BB32_46 Depth=1
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #264]
	ldr	x9, [x9, #240]
	ldr	w10, [sp, #244]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	ldrsb	w8, [x8, x9]
	cbz	w8, LBB32_53
	b	LBB32_52
LBB32_52:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.34@PAGE
	add	x2, x2, l_.str.34@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_53:                               ;   in Loop: Header=BB32_46 Depth=1
	b	LBB32_54
LBB32_54:                               ;   in Loop: Header=BB32_46 Depth=1
	ldr	w8, [sp, #244]
	add	w8, w8, #1
	str	w8, [sp, #244]
	b	LBB32_46
LBB32_55:
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #368]
                                        ; kill: def $x8 killed $w8
	lsl	x8, x8, #5
	add	x1, x8, #1
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_57
	b	LBB32_56
LBB32_56:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.35@PAGE
	add	x2, x2, l_.str.35@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_57:
	ldr	x0, [sp, #264]
	bl	_nvm_metadata_valid
	tbnz	w0, #0, LBB32_59
	b	LBB32_58
LBB32_58:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.36@PAGE
	add	x2, x2, l_.str.36@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_59:
	add	x0, sp, #1048
	mov	x1, #1024                       ; =0x400
	bl	_bzero
	str	wzr, [sp, #240]
	str	wzr, [sp, #236]
	b	LBB32_60
LBB32_60:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_79 Depth 2
                                        ;     Child Loop BB32_94 Depth 2
	ldr	w8, [sp, #236]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB32_115
	b	LBB32_61
LBB32_61:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #264]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #236]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #224]
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB32_64
	b	LBB32_62
LBB32_62:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #21]
	cbz	w8, LBB32_64
	b	LBB32_63
LBB32_63:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.37@PAGE
	add	x2, x2, l_.str.37@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_64:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.le	LBB32_66
	b	LBB32_65
LBB32_65:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.38@PAGE
	add	x2, x2, l_.str.38@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_66:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB32_72
	b	LBB32_67
LBB32_67:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.gt	LBB32_72
	b	LBB32_68
LBB32_68:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #5
	b.le	LBB32_73
	b	LBB32_69
LBB32_69:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #7
	b.eq	LBB32_73
	b	LBB32_70
LBB32_70:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #8
	b.eq	LBB32_73
	b	LBB32_71
LBB32_71:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #10
	b.eq	LBB32_73
	b	LBB32_72
LBB32_72:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.39@PAGE
	add	x2, x2, l_.str.39@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_73:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB32_75
	b	LBB32_74
LBB32_74:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #288]
	ldr	x10, [sp, #224]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB32_76
	b	LBB32_75
LBB32_75:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.40@PAGE
	add	x2, x2, l_.str.40@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_76:                               ;   in Loop: Header=BB32_60 Depth=1
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #256
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_78
	b	LBB32_77
LBB32_77:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.41@PAGE
	add	x2, x2, l_.str.41@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_78:                               ;   in Loop: Header=BB32_60 Depth=1
	strh	wzr, [sp, #222]
	b	LBB32_79
LBB32_79:                               ;   Parent Loop BB32_60 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #222]
	ldr	x9, [sp, #224]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB32_93
	b	LBB32_80
LBB32_80:                               ;   in Loop: Header=BB32_79 Depth=2
	ldrh	w8, [sp, #222]
	subs	w8, w8, #256
	b.lt	LBB32_82
	b	LBB32_81
LBB32_81:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.42@PAGE
	add	x2, x2, l_.str.42@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_82:                               ;   in Loop: Header=BB32_79 Depth=2
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #264]
	cbz	x8, LBB32_85
	b	LBB32_83
LBB32_83:                               ;   in Loop: Header=BB32_79 Depth=2
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #236]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB32_85
	b	LBB32_84
LBB32_84:                               ;   in Loop: Header=BB32_79 Depth=2
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #236]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #222]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB32_86
LBB32_85:                               ;   in Loop: Header=BB32_79 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB32_86
LBB32_86:                               ;   in Loop: Header=BB32_79 Depth=2
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	strb	w8, [sp, #221]
	ldrb	w8, [sp, #221]
	subs	w8, w8, #5
	b.le	LBB32_91
	b	LBB32_87
LBB32_87:                               ;   in Loop: Header=BB32_79 Depth=2
	ldrb	w8, [sp, #221]
	subs	w8, w8, #7
	b.eq	LBB32_91
	b	LBB32_88
LBB32_88:                               ;   in Loop: Header=BB32_79 Depth=2
	ldrb	w8, [sp, #221]
	subs	w8, w8, #8
	b.eq	LBB32_91
	b	LBB32_89
LBB32_89:                               ;   in Loop: Header=BB32_79 Depth=2
	ldrb	w8, [sp, #221]
	subs	w8, w8, #10
	b.eq	LBB32_91
	b	LBB32_90
LBB32_90:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.43@PAGE
	add	x2, x2, l_.str.43@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_91:                               ;   in Loop: Header=BB32_79 Depth=2
	b	LBB32_92
LBB32_92:                               ;   in Loop: Header=BB32_79 Depth=2
	ldrh	w8, [sp, #222]
	add	w8, w8, #1
	strh	w8, [sp, #222]
	b	LBB32_79
LBB32_93:                               ;   in Loop: Header=BB32_60 Depth=1
	str	wzr, [sp, #216]
	b	LBB32_94
LBB32_94:                               ;   Parent Loop BB32_60 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #216]
	ldr	x9, [sp, #224]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB32_113
	b	LBB32_95
LBB32_95:                               ;   in Loop: Header=BB32_94 Depth=2
	ldr	x8, [sp, #264]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #224]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #216]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #12]
	ldr	w9, [sp, #216]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #152
	bl	_isa_decode
	str	w0, [sp, #148]
	ldr	w8, [sp, #148]
	cbnz	w8, LBB32_97
	b	LBB32_96
LBB32_96:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #2                          ; =0x2
	adrp	x2, l_.str.44@PAGE
	add	x2, x2, l_.str.44@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_97:                               ;   in Loop: Header=BB32_94 Depth=2
	ldr	w8, [sp, #240]
	add	w8, w8, #1
	str	w8, [sp, #240]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB32_99
	b	LBB32_98
LBB32_98:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.45@PAGE
	add	x2, x2, l_.str.45@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_99:                               ;   in Loop: Header=BB32_94 Depth=2
	ldr	w8, [sp, #236]
	mov	x10, x8
	add	x9, sp, #1048
	ldr	w8, [x9, x10, lsl #2]
	add	w8, w8, #1
	str	w8, [x9, x10, lsl #2]
	ldrb	w0, [sp, #152]
	bl	_nvm_record_array_opcode_supported
	tbnz	w0, #0, LBB32_102
	b	LBB32_100
LBB32_100:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #152]
	subs	w8, w8, #254
	b.eq	LBB32_102
	b	LBB32_101
LBB32_101:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #152]
	subs	w8, w8, #163
	b.ne	LBB32_107
	b	LBB32_102
LBB32_102:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #152]
	subs	w8, w8, #251
	b.ne	LBB32_108
	b	LBB32_103
LBB32_103:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #160]
	cbz	w8, LBB32_105
	b	LBB32_104
LBB32_104:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #160]
	subs	w8, w8, #1
	b.ne	LBB32_107
	b	LBB32_105
LBB32_105:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #160]
	cbnz	w8, LBB32_108
	b	LBB32_106
LBB32_106:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrh	w8, [sp, #176]
	cbz	w8, LBB32_108
	b	LBB32_107
LBB32_107:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #1                          ; =0x1
	adrp	x2, l_.str.46@PAGE
	add	x2, x2, l_.str.46@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_108:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #152]
	subs	w8, w8, #18
	b.eq	LBB32_110
	b	LBB32_109
LBB32_109:                              ;   in Loop: Header=BB32_94 Depth=2
	ldrb	w8, [sp, #152]
	subs	w8, w8, #19
	b.ne	LBB32_112
	b	LBB32_110
LBB32_110:                              ;   in Loop: Header=BB32_94 Depth=2
	ldr	w8, [sp, #160]
	subs	w8, w8, #256
	b.lo	LBB32_112
	b	LBB32_111
LBB32_111:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #236]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.47@PAGE
	add	x2, x2, l_.str.47@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_112:                              ;   in Loop: Header=BB32_94 Depth=2
	ldr	w9, [sp, #148]
	ldr	w8, [sp, #216]
	add	w8, w8, w9
	str	w8, [sp, #216]
	b	LBB32_94
LBB32_113:                              ;   in Loop: Header=BB32_60 Depth=1
	b	LBB32_114
LBB32_114:                              ;   in Loop: Header=BB32_60 Depth=1
	ldr	w8, [sp, #236]
	add	w8, w8, #1
	str	w8, [sp, #236]
	b	LBB32_60
LBB32_115:
	str	wzr, [sp, #144]
	b	LBB32_116
LBB32_116:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #144]
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB32_121
	b	LBB32_117
LBB32_117:                              ;   in Loop: Header=BB32_116 Depth=1
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #264]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #144]
                                        ; kill: def $x8 killed $w8
	mov	x10, #24                        ; =0x18
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #264]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #144]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #264]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	add	x1, x8, #32
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_119
	b	LBB32_118
LBB32_118:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #144]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.48@PAGE
	add	x2, x2, l_.str.48@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_119:                              ;   in Loop: Header=BB32_116 Depth=1
	b	LBB32_120
LBB32_120:                              ;   in Loop: Header=BB32_116 Depth=1
	ldr	w8, [sp, #144]
	add	w8, w8, #1
	str	w8, [sp, #144]
	b	LBB32_116
LBB32_121:
	ldr	x0, [sp, #256]
	mov	x1, #32                         ; =0x20
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_123
	b	LBB32_122
LBB32_122:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.49@PAGE
	add	x2, x2, l_.str.49@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_123:
	ldr	x0, [sp, #264]
	add	x8, sp, #791
	bl	_verify_module_ranges
	ldrb	w8, [sp, #791]
	tbnz	w8, #0, LBB32_125
	b	LBB32_124
LBB32_124:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, sp, #791
	add	x2, x9, #1
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB32_163
LBB32_125:
	ldr	x0, [sp, #264]
	add	x8, sp, #534
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	bl	_verify_module_contracts_and_imports
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	add	x0, sp, #791
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #791]
	tbnz	w8, #0, LBB32_127
	b	LBB32_126
LBB32_126:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	add	x9, sp, #791
	add	x2, x9, #1
	mov	w0, #2                          ; =0x2
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB32_163
LBB32_127:
	ldr	x0, [sp, #256]
	mov	x1, #16777216                   ; =0x1000000
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB32_129
	b	LBB32_128
LBB32_128:
	ldr	x0, [sp, #256]
	mov	x1, #1048576                    ; =0x100000
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_130
	b	LBB32_129
LBB32_129:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w0, #3                          ; =0x3
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.50@PAGE
	add	x2, x2, l_.str.50@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_130:
	ldr	x0, [sp, #256]
	mov	x1, #1                          ; =0x1
	mov	x2, #16                         ; =0x10
	bl	_nvm_ra_alloc
	str	x0, [sp, #136]
	ldr	x8, [sp, #136]
	cbnz	x8, LBB32_132
	b	LBB32_131
LBB32_131:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #256]
	ldrb	w11, [x9, #24]
	mov	w10, #4                         ; =0x4
	mov	w9, #3                          ; =0x3
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w0, w9, w10, ne
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.51@PAGE
	add	x2, x2, l_.str.51@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_132:
	ldr	x0, [sp, #256]
	mov	x1, #1                          ; =0x1
	mov	x2, #8720                       ; =0x2210
	bl	_nvm_ra_alloc
	ldr	x8, [sp, #136]
	str	x0, [x8]
	ldr	x8, [sp, #136]
	ldr	x8, [x8]
	cbnz	x8, LBB32_134
	b	LBB32_133
LBB32_133:
	ldr	x0, [sp, #136]
	bl	_nvm_record_union_structure_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #256]
	ldrb	w11, [x9, #24]
	mov	w10, #4                         ; =0x4
	mov	w9, #3                          ; =0x3
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csel	w0, w9, w10, ne
	mov	w1, #0                          ; =0x0
	adrp	x2, l_.str.52@PAGE
	add	x2, x2, l_.str.52@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_134:
	ldr	x0, [sp, #264]
	ldr	x8, [sp, #136]
	add	x1, x8, #8
	add	x8, sp, #104
	bl	_nvm_union_field_declarations_prepare
	ldr	w8, [sp, #104]
	cbz	w8, LBB32_142
	b	LBB32_135
LBB32_135:
	ldr	x0, [sp, #136]
	bl	_nvm_record_union_structure_free
	ldr	w8, [sp, #104]
	subs	w8, w8, #4
	b.ne	LBB32_137
	b	LBB32_136
LBB32_136:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB32_141
LBB32_137:
	ldr	w8, [sp, #104]
	subs	w8, w8, #3
	b.ne	LBB32_139
	b	LBB32_138
LBB32_138:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB32_140
LBB32_139:
	ldr	w9, [sp, #104]
	mov	w8, #2                          ; =0x2
	subs	w9, w9, #1
	csinc	w8, w8, wzr, ne
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB32_140
LBB32_140:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB32_141
LBB32_141:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w0, [sp, #44]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #112]
	mov	w1, #0                          ; =0x0
	bl	_ra_result
	b	LBB32_163
LBB32_142:
	ldr	x8, [sp, #136]
	ldr	x8, [x8]
	str	x8, [sp, #96]
	ldr	x8, [sp, #264]
	ldr	w8, [x8, #272]
	ldr	x9, [sp, #96]
	str	w8, [x9, #8]
	str	wzr, [sp, #92]
	b	LBB32_143
LBB32_143:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_145 Depth 2
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #96]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hs	LBB32_162
	b	LBB32_144
LBB32_144:                              ;   in Loop: Header=BB32_143 Depth=1
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #80]
	b	LBB32_145
LBB32_145:                              ;   Parent Loop BB32_143 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [sp, #80]
	ldr	w9, [sp, #92]
	mov	x10, x9
	add	x9, sp, #1048
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB32_147
	b	LBB32_146
LBB32_146:                              ;   in Loop: Header=BB32_145 Depth=2
	ldr	x8, [sp, #80]
	lsl	x8, x8, #1
	str	x8, [sp, #80]
	b	LBB32_145
LBB32_147:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	x8, [sp, #264]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	add	w8, w8, #1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	ldr	w8, [sp, #92]
	mov	x9, x8
	add	x8, sp, #1048
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB32_149
	b	LBB32_148
LBB32_148:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	x8, [sp, #80]
	mov	x9, #3                          ; =0x3
	mul	x8, x8, x9
	mov	x9, #104                        ; =0x68
	mul	x8, x8, x9
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB32_150
LBB32_149:                              ;   in Loop: Header=BB32_143 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB32_150
LBB32_150:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	mov	w9, #5                          ; =0x5
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldr	x0, [sp, #256]
	ldr	x1, [sp, #72]
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB32_152
	b	LBB32_151
LBB32_151:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #264]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #92]
	mov	x10, x9
	add	x9, sp, #1048
	ldr	w9, [x9, x10, lsl #2]
	lsl	w9, w9, #4
	mov	w9, w9
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB32_153
	b	LBB32_152
LBB32_152:
	ldr	x0, [sp, #136]
	bl	_nvm_record_union_structure_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #92]
	mov	w0, #3                          ; =0x3
	adrp	x2, l_.str.53@PAGE
	add	x2, x2, l_.str.53@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_153:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	x0, [sp, #264]
	ldr	w1, [sp, #92]
	ldr	x8, [sp, #96]
	mov	x9, #8208                       ; =0x2010
	add	x8, x8, x9
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x4, x8, x9, lsl #1
	ldr	x5, [sp, #256]
	ldr	x8, [sp, #96]
	add	x8, x8, #16
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	add	x6, x8, x9, lsl #5
	add	x8, sp, #277
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_body
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, sp, #791
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #791]
	tbnz	w8, #0, LBB32_160
	b	LBB32_154
LBB32_154:
	ldr	x0, [sp, #136]
	bl	_nvm_record_union_structure_free
	ldr	x8, [sp, #256]
	ldrb	w8, [x8, #24]
	tbz	w8, #0, LBB32_156
	b	LBB32_155
LBB32_155:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB32_159
LBB32_156:
	ldr	x8, [sp, #256]
	ldrb	w8, [x8, #25]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbnz	w8, #0, LBB32_158
	b	LBB32_157
LBB32_157:
	add	x8, sp, #791
	add	x0, x8, #1
	adrp	x1, l_.str.54@PAGE
	add	x1, x1, l_.str.54@PAGEOFF
	bl	_strstr
	subs	x8, x0, #0
	cset	w8, ne
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB32_158
LBB32_158:
	ldr	w10, [sp, #8]                   ; 4-byte Folded Reload
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB32_159
LBB32_159:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldr	w1, [sp, #92]
	add	x9, sp, #791
	add	x2, x9, #1
	bl	_ra_result
	b	LBB32_163
LBB32_160:                              ;   in Loop: Header=BB32_143 Depth=1
	b	LBB32_161
LBB32_161:                              ;   in Loop: Header=BB32_143 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB32_143
LBB32_162:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #136]
	ldr	x10, [sp, #248]
	str	x9, [x10]
	mov	w1, #0                          ; =0x0
	mov	x0, x1
	adrp	x2, l_.str.55@PAGE
	add	x2, x2, l_.str.55@PAGEOFF
	bl	_ra_result
	b	LBB32_163
LBB32_163:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB32_165
	b	LBB32_164
LBB32_164:
	bl	___stack_chk_fail
LBB32_165:
	add	sp, sp, #2080
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_ra_bytes
_nvm_ra_bytes:                          ; @nvm_ra_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB33_2
	b	LBB33_1
LBB33_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB33_11
LBB33_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB33_4
	b	LBB33_3
LBB33_3:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #25]
	tbz	w8, #0, LBB33_5
	b	LBB33_4
LBB33_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB33_11
LBB33_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	mov	x9, #67108864                   ; =0x4000000
	subs	x8, x8, x9
	b.hi	LBB33_7
	b	LBB33_6
LBB33_6:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x10, [x9]
	mov	x9, #67108864                   ; =0x4000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB33_8
	b	LBB33_7
LBB33_7:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB33_11
LBB33_8:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.hs	LBB33_10
	b	LBB33_9
LBB33_9:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	str	x8, [x9, #8]
	b	LBB33_10
LBB33_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB33_11
LBB33_11:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_ra_steps
_nvm_ra_steps:                          ; @nvm_ra_steps
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbnz	x8, LBB34_2
	b	LBB34_1
LBB34_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB34_9
LBB34_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #24]
	tbnz	w8, #0, LBB34_4
	b	LBB34_3
LBB34_3:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #25]
	tbz	w8, #0, LBB34_5
	b	LBB34_4
LBB34_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB34_9
LBB34_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #16]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hi	LBB34_7
	b	LBB34_6
LBB34_6:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x10, [x9, #16]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB34_8
	b	LBB34_7
LBB34_7:
	ldr	x9, [sp, #16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB34_9
LBB34_8:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #16]
	add	x8, x8, x10
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB34_9
LBB34_9:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_module_ranges
_verify_module_ranges:                  ; @verify_module_ranges
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	cbnz	x8, LBB35_2
	b	LBB35_1
LBB35_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.107@PAGE
	add	x0, x0, l_.str.107@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_2:
	ldur	x0, [x29, #-8]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB35_4
	b	LBB35_3
LBB35_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.108@PAGE
	add	x0, x0, l_.str.108@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_4:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #280]
	cbnz	x8, LBB35_7
	b	LBB35_5
LBB35_5:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #288]
	subs	w8, w8, #0
	b.ls	LBB35_7
	b	LBB35_6
LBB35_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #288]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.109@PAGE
	add	x0, x0, l_.str.109@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_7:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB35_11
	b	LBB35_8
LBB35_8:
	ldur	x8, [x29, #-8]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB35_10
	b	LBB35_9
LBB35_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #12]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	adrp	x0, l_.str.110@PAGE
	add	x0, x0, l_.str.110@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_10:
	b	LBB35_11
LBB35_11:
	stur	wzr, [x29, #-12]
	b	LBB35_12
LBB35_12:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_24 Depth 2
                                        ;     Child Loop BB35_36 Depth 2
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB35_47
	b	LBB35_13
LBB35_13:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.ls	LBB35_15
	b	LBB35_14
LBB35_14:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x12, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #288]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.111@PAGE
	add	x0, x0, l_.str.111@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_15:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-24]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.ls	LBB35_17
	b	LBB35_16
LBB35_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x13, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #8]
	mov	x12, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #12]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #288]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.112@PAGE
	add	x0, x0, l_.str.112@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_17:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB35_19
	b	LBB35_18
LBB35_18:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x12, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.113@PAGE
	add	x0, x0, l_.str.113@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_19:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #16
	b.lt	LBB35_21
	b	LBB35_20
LBB35_20:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrb	w11, [x10, #20]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.114@PAGE
	add	x0, x0, l_.str.114@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_21:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #264]
	cbz	x8, LBB35_30
	b	LBB35_22
LBB35_22:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB35_30
	b	LBB35_23
LBB35_23:                               ;   in Loop: Header=BB35_12 Depth=1
	sturh	wzr, [x29, #-26]
	b	LBB35_24
LBB35_24:                               ;   Parent Loop BB35_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-26]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB35_29
	b	LBB35_25
LBB35_25:                               ;   in Loop: Header=BB35_24 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #264]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldurh	w9, [x29, #-26]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #16
	b.lt	LBB35_27
	b	LBB35_26
LBB35_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldurh	w11, [x29, #-26]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.115@PAGE
	add	x0, x0, l_.str.115@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_27:                               ;   in Loop: Header=BB35_24 Depth=2
	b	LBB35_28
LBB35_28:                               ;   in Loop: Header=BB35_24 Depth=2
	ldurh	w8, [x29, #-26]
	add	w8, w8, #1
	sturh	w8, [x29, #-26]
	b	LBB35_24
LBB35_29:                               ;   in Loop: Header=BB35_12 Depth=1
	b	LBB35_30
LBB35_30:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #0
	cset	w8, eq
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #20]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB35_32
	b	LBB35_31
LBB35_31:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.116@PAGE
	add	x0, x0, l_.str.116@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_32:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB35_34
	b	LBB35_33
LBB35_33:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrh	w12, [x10, #16]
	ldur	x10, [x29, #-24]
	ldrh	w11, [x10, #4]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.117@PAGE
	add	x0, x0, l_.str.117@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_34:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	cbz	w8, LBB35_45
	b	LBB35_35
LBB35_35:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #12]
	add	w8, w8, w9
	stur	w8, [x29, #-32]
	stur	wzr, [x29, #-36]
	b	LBB35_36
LBB35_36:                               ;   Parent Loop BB35_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-36]
	ldur	w9, [x29, #-12]
	subs	w8, w8, w9
	b.hs	LBB35_44
	b	LBB35_37
LBB35_37:                               ;   in Loop: Header=BB35_36 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB35_39
	b	LBB35_38
LBB35_38:                               ;   in Loop: Header=BB35_36 Depth=2
	b	LBB35_43
LBB35_39:                               ;   in Loop: Header=BB35_36 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #12]
	add	w8, w8, w9
	str	w8, [sp, #44]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #44]
	subs	w8, w8, w9
	b.hs	LBB35_42
	b	LBB35_40
LBB35_40:                               ;   in Loop: Header=BB35_36 Depth=2
	ldr	x8, [sp, #48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-32]
	subs	w8, w8, w9
	b.hs	LBB35_42
	b	LBB35_41
LBB35_41:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x11, x9
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	adrp	x0, l_.str.118@PAGE
	add	x0, x0, l_.str.118@PAGEOFF
	bl	_fail
	b	LBB35_48
LBB35_42:                               ;   in Loop: Header=BB35_36 Depth=2
	b	LBB35_43
LBB35_43:                               ;   in Loop: Header=BB35_36 Depth=2
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB35_36
LBB35_44:                               ;   in Loop: Header=BB35_12 Depth=1
	b	LBB35_45
LBB35_45:                               ;   in Loop: Header=BB35_12 Depth=1
	b	LBB35_46
LBB35_46:                               ;   in Loop: Header=BB35_12 Depth=1
	ldur	w8, [x29, #-12]
	add	w8, w8, #1
	stur	w8, [x29, #-12]
	b	LBB35_12
LBB35_47:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB35_48
LBB35_48:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_module_contracts_and_imports
_verify_module_contracts_and_imports:   ; @verify_module_contracts_and_imports
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	ldur	x0, [x29, #-8]
	bl	_nvm_passive_valid
	tbnz	w0, #0, LBB36_2
	b	LBB36_1
LBB36_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.119@PAGE
	add	x0, x0, l_.str.119@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_2:
	ldur	x0, [x29, #-8]
	bl	_nvm_callback_contracts_valid
	tbnz	w0, #0, LBB36_4
	b	LBB36_3
LBB36_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.120@PAGE
	add	x0, x0, l_.str.120@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_4:
	stur	wzr, [x29, #-12]
	b	LBB36_5
LBB36_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_26 Depth 2
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB36_33
	b	LBB36_6
LBB36_6:                                ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB36_8
	b	LBB36_7
LBB36_7:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x12, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.121@PAGE
	add	x0, x0, l_.str.121@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_8:                                ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB36_10
	b	LBB36_9
LBB36_9:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
	mov	x12, x9
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
	mov	x11, x9
	ldur	x9, [x29, #-8]
	ldr	w9, [x9, #248]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.122@PAGE
	add	x0, x0, l_.str.122@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_10:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #2
	b.le	LBB36_12
	b	LBB36_11
LBB36_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrb	w11, [x10, #11]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.123@PAGE
	add	x0, x0, l_.str.123@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_12:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #11]
	subs	w8, w8, #2
	b.ne	LBB36_18
	b	LBB36_13
LBB36_13:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_nvm_get_string
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB36_16
	b	LBB36_14
LBB36_14:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-32]
	ldrsb	w8, [x8]
	subs	w8, w8, #47
	b.ne	LBB36_16
	b	LBB36_15
LBB36_15:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x0, [x29, #-32]
	bl	_strlen
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-8]
	ldur	x8, [x29, #-24]
	ldr	w1, [x8]
	bl	_nvm_get_string_len
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	subs	x8, x0, w8, uxtw
	b.eq	LBB36_17
	b	LBB36_16
LBB36_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.124@PAGE
	add	x0, x0, l_.str.124@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_17:                               ;   in Loop: Header=BB36_5 Depth=1
	b	LBB36_18
LBB36_18:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #16
	b.lt	LBB36_20
	b	LBB36_19
LBB36_19:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrb	w11, [x10, #10]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.125@PAGE
	add	x0, x0, l_.str.125@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_20:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #16
	b.le	LBB36_22
	b	LBB36_21
LBB36_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrh	w11, [x10, #8]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	mov	x9, #16                         ; =0x10
	str	x9, [x10, #16]
	adrp	x0, l_.str.126@PAGE
	add	x0, x0, l_.str.126@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_22:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #0
	b.le	LBB36_25
	b	LBB36_23
LBB36_23:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB36_25
	b	LBB36_24
LBB36_24:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-24]
	ldrh	w11, [x10, #8]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.127@PAGE
	add	x0, x0, l_.str.127@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_25:                               ;   in Loop: Header=BB36_5 Depth=1
	sturh	wzr, [x29, #-34]
	b	LBB36_26
LBB36_26:                               ;   Parent Loop BB36_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-34]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB36_31
	b	LBB36_27
LBB36_27:                               ;   in Loop: Header=BB36_26 Depth=2
	ldur	x8, [x29, #-8]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldurh	w9, [x29, #-34]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	sturb	w8, [x29, #-35]
	ldurb	w8, [x29, #-35]
	subs	w8, w8, #16
	b.lt	LBB36_29
	b	LBB36_28
LBB36_28:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-12]
                                        ; kill: def $x9 killed $w9
	ldurh	w12, [x29, #-34]
	ldurb	w11, [x29, #-35]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.128@PAGE
	add	x0, x0, l_.str.128@PAGEOFF
	bl	_fail
	b	LBB36_34
LBB36_29:                               ;   in Loop: Header=BB36_26 Depth=2
	b	LBB36_30
LBB36_30:                               ;   in Loop: Header=BB36_26 Depth=2
	ldurh	w8, [x29, #-34]
	add	w8, w8, #1
	sturh	w8, [x29, #-34]
	b	LBB36_26
LBB36_31:                               ;   in Loop: Header=BB36_5 Depth=1
	b	LBB36_32
LBB36_32:                               ;   in Loop: Header=BB36_5 Depth=1
	ldur	w8, [x29, #-12]
	add	w8, w8, #1
	stur	w8, [x29, #-12]
	b	LBB36_5
LBB36_33:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB36_34
LBB36_34:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_ra_alloc
_nvm_ra_alloc:                          ; @nvm_ra_alloc
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB37_5
	b	LBB37_1
LBB37_1:
	ldr	x8, [sp, #24]
	ldr	x10, [sp, #16]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB37_5
	b	LBB37_2
LBB37_2:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB37_4
	b	LBB37_3
LBB37_3:
	ldur	x9, [x29, #-16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #24]
	b	LBB37_4
LBB37_4:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB37_13
LBB37_5:
	ldur	x0, [x29, #-16]
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	mul	x1, x8, x9
	bl	_nvm_ra_bytes
	tbnz	w0, #0, LBB37_7
	b	LBB37_6
LBB37_6:
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-8]
	b	LBB37_13
LBB37_7:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #16]
	bl	_calloc
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB37_12
	b	LBB37_8
LBB37_8:
	ldr	x8, [sp, #24]
	cbz	x8, LBB37_12
	b	LBB37_9
LBB37_9:
	ldr	x8, [sp, #16]
	cbz	x8, LBB37_12
	b	LBB37_10
LBB37_10:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB37_12
	b	LBB37_11
LBB37_11:
	ldur	x9, [x29, #-16]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #25]
	b	LBB37_12
LBB37_12:
	ldr	x8, [sp, #8]
	stur	x8, [x29, #-8]
	b	LBB37_13
LBB37_13:
	ldur	x0, [x29, #-8]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_function_body
_verify_function_body:                  ; @verify_function_body
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1648
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #304
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #392]
	str	w1, [sp, #388]
	str	x2, [sp, #376]
	str	w3, [sp, #372]
	str	x4, [sp, #360]
	str	x5, [sp, #352]
	str	x6, [sp, #344]
	ldr	x8, [sp, #392]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #388]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #336]
	ldr	x0, [sp, #392]
	ldr	w1, [sp, #388]
	add	x2, sp, #304
	add	x3, sp, #1384
	bl	_vm_decode_function
	tbnz	w0, #0, LBB38_2
	b	LBB38_1
LBB38_1:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	mov	x10, sp
	add	x9, sp, #1384
	str	x9, [x10]
	adrp	x0, l_.str.67@PAGE
	add	x0, x0, l_.str.67@PAGEOFF
	bl	_fail
	b	LBB38_177
LBB38_2:
	str	wzr, [sp, #300]
	b	LBB38_3
LBB38_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #300]
	ldr	w9, [sp, #312]
	subs	w8, w8, w9
	b.hs	LBB38_156
	b	LBB38_4
LBB38_4:                                ;   in Loop: Header=BB38_3 Depth=1
	ldr	x0, [sp, #352]
	mov	x1, #8                          ; =0x8
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB38_7
	b	LBB38_5
LBB38_5:
	b	LBB38_6
LBB38_6:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.129@PAGE
	add	x0, x0, l_.str.129@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_7:                                ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #304]
	ldr	w9, [sp, #300]
	mov	x10, x9
	mov	x9, #104                        ; =0x68
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w8, [x8, x10]
	str	w8, [sp, #296]
	ldr	x10, [sp, #304]
	ldr	w8, [sp, #300]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x1, x8, #40
	add	x0, sp, #232
	mov	x2, #64                         ; =0x40
	bl	_memcpy
	ldrb	w0, [sp, #232]
	bl	_isa_get_info
	str	x0, [sp, #224]
	ldr	x8, [sp, #224]
	cbnz	x8, LBB38_10
	b	LBB38_8
LBB38_8:
	b	LBB38_9
LBB38_9:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldrb	w12, [sp, #232]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.130@PAGE
	add	x0, x0, l_.str.130@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_10:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #232]
	subs	w8, w8, #4
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	subs	x8, x8, #247
	b.hi	LBB38_150
; %bb.11:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x11, [sp, #64]                  ; 8-byte Folded Reload
	adrp	x10, lJTI38_0@PAGE
	add	x10, x10, lJTI38_0@PAGEOFF
Ltmp10:
	adr	x8, Ltmp10
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB38_12:
	ldr	x0, [sp, #392]
	ldr	w1, [sp, #388]
	add	x8, sp, #1176
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #1176]
	tbnz	w8, #0, LBB38_15
	b	LBB38_13
LBB38_13:
	b	LBB38_14
LBB38_14:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	add	x9, sp, #1176
	add	x9, x9, #16
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.131@PAGE
	add	x0, x0, l_.str.131@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_15:
	b	LBB38_16
LBB38_16:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.132@PAGE
	add	x0, x0, l_.str.132@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_17:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #220]
	ldr	w8, [sp, #296]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #220]
	add	x8, x8, x9
	str	x8, [sp, #208]
	ldr	x8, [sp, #208]
	tbnz	x8, #63, LBB38_20
	b	LBB38_18
LBB38_18:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #208]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.gt	LBB38_20
	b	LBB38_19
LBB38_19:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #208]
	mov	x1, x8
	add	x0, sp, #304
	bl	_vm_decoded_function_has_boundary
	tbnz	w0, #0, LBB38_22
	b	LBB38_20
LBB38_20:
	b	LBB38_21
LBB38_21:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x11, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w12, w9, w10
	ldr	x9, [sp, #208]
	mov	x10, sp
	str	x11, [x10]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.133@PAGE
	add	x0, x0, l_.str.133@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_22:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_23:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB38_25
	b	LBB38_24
LBB38_24:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #256]
	ldrh	w9, [sp, #264]
	add	w8, w8, w9
	ldr	x9, [sp, #336]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ls	LBB38_27
	b	LBB38_25
LBB38_25:
	b	LBB38_26
LBB38_26:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.134@PAGE
	add	x0, x0, l_.str.134@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_27:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x10, [sp, #304]
	ldr	w8, [sp, #300]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.lo	LBB38_30
	b	LBB38_28
LBB38_28:
	b	LBB38_29
LBB38_29:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.135@PAGE
	add	x0, x0, l_.str.135@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_30:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_31:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB38_34
	b	LBB38_32
LBB38_32:
	b	LBB38_33
LBB38_33:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.136@PAGE
	add	x0, x0, l_.str.136@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_34:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_35:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #248]
	str	w8, [sp, #204]
	ldr	w8, [sp, #296]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #204]
	add	x8, x8, x9
	str	x8, [sp, #192]
	ldr	x8, [sp, #192]
	tbnz	x8, #63, LBB38_38
	b	LBB38_36
LBB38_36:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #192]
	mov	x9, #4294967295                 ; =0xffffffff
	subs	x8, x8, x9
	b.gt	LBB38_38
	b	LBB38_37
LBB38_37:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #192]
	mov	x1, x8
	add	x0, sp, #304
	bl	_vm_decoded_function_has_boundary
	tbnz	w0, #0, LBB38_40
	b	LBB38_38
LBB38_38:
	b	LBB38_39
LBB38_39:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x11, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w12, w9, w10
	ldr	x9, [sp, #192]
	mov	x10, sp
	str	x11, [x10]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.137@PAGE
	add	x0, x0, l_.str.137@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_40:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_41:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #188]
	ldr	w8, [sp, #188]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB38_44
	b	LBB38_42
LBB38_42:
	b	LBB38_43
LBB38_43:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x12, [x9]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #188]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x14, [x10]
	str	x12, [x10, #8]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #16]
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.138@PAGE
	add	x0, x0, l_.str.138@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_44:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #232]
	subs	w8, w8, #51
	b.ne	LBB38_50
	b	LBB38_45
LBB38_45:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #188]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #176]
	ldr	x8, [sp, #176]
	ldrb	w8, [x8, #21]
	ldr	x9, [sp, #336]
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.ne	LBB38_47
	b	LBB38_46
LBB38_46:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #176]
	ldrb	w8, [x8, #20]
	ldr	x9, [sp, #336]
	ldrb	w9, [x9, #20]
	subs	w8, w8, w9
	b.eq	LBB38_49
	b	LBB38_47
LBB38_47:
	b	LBB38_48
LBB38_48:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	adrp	x0, l_.str.139@PAGE
	add	x0, x0, l_.str.139@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_49:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_50
LBB38_50:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_51:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #172]
	ldr	w8, [sp, #248]
	str	w8, [sp, #168]
	ldr	w8, [sp, #372]
	subs	w8, w8, #0
	b.ls	LBB38_68
	b	LBB38_52
LBB38_52:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #172]
	ldr	w9, [sp, #372]
	subs	w8, w8, w9
	b.lo	LBB38_55
	b	LBB38_53
LBB38_53:
	b	LBB38_54
LBB38_54:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #172]
	mov	x11, x9
	ldr	w9, [sp, #372]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.140@PAGE
	add	x0, x0, l_.str.140@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_55:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #376]
	ldr	w9, [sp, #172]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #160]
	ldr	x8, [sp, #160]
	cbnz	x8, LBB38_58
	b	LBB38_56
LBB38_56:
	b	LBB38_57
LBB38_57:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x11, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w12, w9, w10
	ldr	w9, [sp, #172]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.141@PAGE
	add	x0, x0, l_.str.141@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_58:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #168]
	ldr	x9, [sp, #160]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB38_61
	b	LBB38_59
LBB38_59:
	b	LBB38_60
LBB38_60:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #168]
	mov	x11, x9
	ldr	x9, [sp, #160]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.142@PAGE
	add	x0, x0, l_.str.142@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_61:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #160]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #168]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #152]
	ldrh	w8, [sp, #256]
	ldr	x9, [sp, #152]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB38_64
	b	LBB38_62
LBB38_62:
	b	LBB38_63
LBB38_63:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w13, w10, w11
	ldrh	w12, [sp, #256]
	ldr	x10, [sp, #152]
	ldrh	w11, [x10, #4]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x13
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #24]
	adrp	x0, l_.str.143@PAGE
	add	x0, x0, l_.str.143@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_64:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #264]
	ldr	x9, [sp, #152]
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.eq	LBB38_67
	b	LBB38_65
LBB38_65:
	b	LBB38_66
LBB38_66:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w13, w10, w11
	ldrh	w12, [sp, #264]
	ldr	x10, [sp, #152]
	ldrb	w11, [x10, #21]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x13
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #24]
	adrp	x0, l_.str.144@PAGE
	add	x0, x0, l_.str.144@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_67:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_68
LBB38_68:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_69:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #148]
	ldr	w8, [sp, #148]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB38_72
	b	LBB38_70
LBB38_70:
	b	LBB38_71
LBB38_71:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #148]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.145@PAGE
	add	x0, x0, l_.str.145@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_72:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #248]
	ldr	x9, [sp, #392]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #148]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #18]
	subs	w8, w8, w9
	b.eq	LBB38_75
	b	LBB38_73
LBB38_73:
	b	LBB38_74
LBB38_74:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w13, w10, w11
	ldrh	w12, [sp, #248]
	ldr	x10, [sp, #392]
	ldr	x14, [x10, #256]
	ldr	w10, [sp, #148]
                                        ; kill: def $x10 killed $w10
	mov	x11, #24                        ; =0x18
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x14
	ldrh	w11, [x10, #18]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x13
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #24]
	adrp	x0, l_.str.146@PAGE
	add	x0, x0, l_.str.146@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_75:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_76:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #144]
	ldr	w8, [sp, #144]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB38_79
	b	LBB38_77
LBB38_77:
	b	LBB38_78
LBB38_78:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #144]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.147@PAGE
	add	x0, x0, l_.str.147@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_79:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_80:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #140]
	ldr	w8, [sp, #140]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.lo	LBB38_83
	b	LBB38_81
LBB38_81:
	b	LBB38_82
LBB38_82:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #140]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #248]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.148@PAGE
	add	x0, x0, l_.str.148@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_83:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_84:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #136]
	ldr	w8, [sp, #136]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.lo	LBB38_87
	b	LBB38_85
LBB38_85:
	b	LBB38_86
LBB38_86:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #136]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #432]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.149@PAGE
	add	x0, x0, l_.str.149@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_87:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_88:                               ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #132]
	ldr	w8, [sp, #132]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.lo	LBB38_91
	b	LBB38_89
LBB38_89:
	b	LBB38_90
LBB38_90:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x13, x9
	ldr	x9, [sp, #224]
	ldr	x11, [x9]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w12, w9, w10
	ldr	w9, [sp, #132]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x13, [x10]
	str	x11, [x10, #8]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	mov	x9, #4096                       ; =0x1000
	str	x9, [x10, #32]
	adrp	x0, l_.str.150@PAGE
	add	x0, x0, l_.str.150@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_91:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_92:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #240]
	strh	w8, [sp, #130]
	ldrh	w8, [sp, #130]
	ldr	x9, [sp, #336]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.lt	LBB38_95
	b	LBB38_93
LBB38_93:
	b	LBB38_94
LBB38_94:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x9, [x9]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w13, w10, w11
	ldrh	w12, [sp, #130]
	ldr	x10, [sp, #336]
	ldrh	w11, [x10, #16]
	mov	x10, sp
	str	x14, [x10]
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x13
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #24]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #32]
	adrp	x0, l_.str.151@PAGE
	add	x0, x0, l_.str.151@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_95:                               ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_96:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #248]
	strh	w8, [sp, #128]
	ldrh	w8, [sp, #240]
	cbz	w8, LBB38_99
	b	LBB38_97
LBB38_97:
	b	LBB38_98
LBB38_98:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	x9, [sp, #224]
	ldr	x9, [x9]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	mov	x10, sp
	str	x12, [x10]
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.152@PAGE
	add	x0, x0, l_.str.152@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_99:                               ;   in Loop: Header=BB38_3 Depth=1
	ldrh	w8, [sp, #128]
	ldr	x9, [sp, #336]
	ldrh	w9, [x9, #18]
	subs	w8, w8, w9
	b.lt	LBB38_102
	b	LBB38_100
LBB38_100:
	b	LBB38_101
LBB38_101:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x9, [x9]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w13, w10, w11
	ldrh	w12, [sp, #128]
	ldr	x10, [sp, #336]
	ldrh	w11, [x10, #18]
	mov	x10, sp
	str	x14, [x10]
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x13
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #24]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #32]
	adrp	x0, l_.str.153@PAGE
	add	x0, x0, l_.str.153@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_102:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_103:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	w8, [x8, #468]
	subs	w8, w8, #0
	b.ls	LBB38_108
	b	LBB38_104
LBB38_104:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #124]
	ldr	w8, [sp, #124]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.lo	LBB38_107
	b	LBB38_105
LBB38_105:
	b	LBB38_106
LBB38_106:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x12, [x9]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #124]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #468]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x14, [x10]
	str	x12, [x10, #8]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #16]
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.154@PAGE
	add	x0, x0, l_.str.154@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_107:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_108
LBB38_108:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_109:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	w8, [x8, #472]
	subs	w8, w8, #0
	b.ls	LBB38_114
	b	LBB38_110
LBB38_110:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #120]
	ldr	w8, [sp, #120]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #472]
	subs	w8, w8, w9
	b.lo	LBB38_113
	b	LBB38_111
LBB38_111:
	b	LBB38_112
LBB38_112:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x12, [x9]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #120]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #472]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x14, [x10]
	str	x12, [x10, #8]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #16]
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.155@PAGE
	add	x0, x0, l_.str.155@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_113:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_114
LBB38_114:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_115:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	w8, [x8, #476]
	subs	w8, w8, #0
	b.ls	LBB38_120
	b	LBB38_116
LBB38_116:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #240]
	str	w8, [sp, #116]
	ldr	w8, [sp, #116]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.lo	LBB38_119
	b	LBB38_117
LBB38_117:
	b	LBB38_118
LBB38_118:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x14, x9
	ldr	x9, [sp, #224]
	ldr	x12, [x9]
	ldr	x9, [sp, #336]
	ldr	w9, [x9, #8]
	ldr	w10, [sp, #296]
	add	w13, w9, w10
	ldr	w9, [sp, #116]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #476]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x14, [x10]
	str	x12, [x10, #8]
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10, #16]
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.156@PAGE
	add	x0, x0, l_.str.156@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_119:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_120
LBB38_120:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_121:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #240]
	strb	w8, [sp, #115]
	ldr	w8, [sp, #248]
	str	w8, [sp, #108]
	ldrb	w8, [sp, #115]
	subs	w8, w8, #2
	b.le	LBB38_124
	b	LBB38_122
LBB38_122:
	b	LBB38_123
LBB38_123:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w12, w10, w11
	ldrb	w11, [sp, #115]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.157@PAGE
	add	x0, x0, l_.str.157@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_124:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #115]
	cbnz	w8, LBB38_129
	b	LBB38_125
LBB38_125:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	w8, [x8, #468]
	subs	w8, w8, #0
	b.ls	LBB38_129
	b	LBB38_126
LBB38_126:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #108]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #468]
	subs	w8, w8, w9
	b.lo	LBB38_129
	b	LBB38_127
LBB38_127:
	b	LBB38_128
LBB38_128:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	w9, [sp, #108]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #468]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.158@PAGE
	add	x0, x0, l_.str.158@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_129:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #115]
	subs	w8, w8, #1
	b.ne	LBB38_134
	b	LBB38_130
LBB38_130:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	x8, [sp, #392]
	ldr	w8, [x8, #476]
	subs	w8, w8, #0
	b.ls	LBB38_134
	b	LBB38_131
LBB38_131:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #108]
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #476]
	subs	w8, w8, w9
	b.lo	LBB38_134
	b	LBB38_132
LBB38_132:
	b	LBB38_133
LBB38_133:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x12, x9
	ldr	w9, [sp, #108]
	mov	x11, x9
	ldr	x9, [sp, #392]
	ldr	w9, [x9, #476]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.159@PAGE
	add	x0, x0, l_.str.159@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_134:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_135:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #240]
	strb	w8, [sp, #107]
	ldrb	w8, [sp, #107]
	subs	w8, w8, #16
	b.lt	LBB38_138
	b	LBB38_136
LBB38_136:
	b	LBB38_137
LBB38_137:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
	mov	x11, x9
	ldr	x9, [sp, #224]
	ldr	x9, [x9]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w12, [sp, #296]
	add	w13, w10, w12
	ldrb	w12, [sp, #107]
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	mov	x9, #16                         ; =0x10
                                        ; implicit-def: $x11
	mov	x11, x13
	str	x11, [x10, #16]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.160@PAGE
	add	x0, x0, l_.str.160@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_138:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_139:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #240]
	strb	w8, [sp, #106]
	ldrb	w8, [sp, #248]
	strb	w8, [sp, #105]
	ldrb	w8, [sp, #106]
	subs	w8, w8, #16
	b.lt	LBB38_142
	b	LBB38_140
LBB38_140:
	b	LBB38_141
LBB38_141:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	ldrb	w12, [sp, #106]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	mov	x9, #16                         ; =0x10
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.161@PAGE
	add	x0, x0, l_.str.161@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_142:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #105]
	subs	w8, w8, #16
	b.lt	LBB38_145
	b	LBB38_143
LBB38_143:
	b	LBB38_144
LBB38_144:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	ldrb	w12, [sp, #105]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	mov	x9, #16                         ; =0x10
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.162@PAGE
	add	x0, x0, l_.str.162@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_145:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_146:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #240]
	strb	w8, [sp, #104]
	ldrb	w8, [sp, #104]
	subs	w8, w8, #16
	b.lt	LBB38_149
	b	LBB38_147
LBB38_147:
	b	LBB38_148
LBB38_148:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	ldrb	w12, [sp, #104]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #8]
	mov	x9, #16                         ; =0x10
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.163@PAGE
	add	x0, x0, l_.str.163@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_149:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_150:                              ;   in Loop: Header=BB38_3 Depth=1
	ldrb	w8, [sp, #232]
	subs	w8, w8, #255
	b.lt	LBB38_153
	b	LBB38_151
LBB38_151:
	b	LBB38_152
LBB38_152:
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #388]
                                        ; kill: def $x9 killed $w9
	ldrb	w12, [sp, #232]
	ldr	x10, [sp, #336]
	ldr	w10, [x10, #8]
	ldr	w11, [sp, #296]
	add	w11, w10, w11
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.164@PAGE
	add	x0, x0, l_.str.164@PAGEOFF
	bl	_fail
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_177
LBB38_153:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_154
LBB38_154:                              ;   in Loop: Header=BB38_3 Depth=1
	b	LBB38_155
LBB38_155:                              ;   in Loop: Header=BB38_3 Depth=1
	ldr	w8, [sp, #300]
	add	w8, w8, #1
	str	w8, [sp, #300]
	b	LBB38_3
LBB38_156:
	strh	wzr, [sp, #102]
	ldr	w8, [sp, #312]
	add	w8, w8, #1
	mov	w9, #3                          ; =0x3
	umull	x8, w8, w9
	lsl	x8, x8, #2
	str	x8, [sp, #88]
	ldr	x0, [sp, #352]
	ldr	x1, [sp, #88]
	bl	_nvm_ra_bytes
	tbz	w0, #0, LBB38_158
	b	LBB38_157
LBB38_157:
	ldr	x0, [sp, #352]
	ldr	w8, [sp, #312]
	add	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x1, x8, #5
	bl	_nvm_ra_steps
	tbnz	w0, #0, LBB38_159
	b	LBB38_158
LBB38_158:
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.165@PAGE
	add	x0, x0, l_.str.165@PAGEOFF
	bl	_fail
	b	LBB38_177
LBB38_159:
	ldr	x0, [sp, #392]
	ldr	w2, [sp, #388]
	add	x8, sp, #919
	add	x1, sp, #304
	add	x3, sp, #102
	bl	_verify_stack_heights
	ldr	x8, [sp, #352]
	cbz	x8, LBB38_161
	b	LBB38_160
LBB38_160:
	ldr	x10, [sp, #88]
	ldr	x9, [sp, #352]
	ldr	x8, [x9]
	subs	x8, x8, x10
	str	x8, [x9]
	b	LBB38_161
LBB38_161:
	ldr	x8, [sp, #352]
	cbz	x8, LBB38_164
	b	LBB38_162
LBB38_162:
	ldrh	w8, [sp, #102]
	subs	w8, w8, #256
	b.le	LBB38_164
	b	LBB38_163
LBB38_163:
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #352]
	mov	w9, #1                          ; =0x1
	strb	w9, [x10, #24]
	adrp	x0, l_.str.166@PAGE
	add	x0, x0, l_.str.166@PAGEOFF
	bl	_fail
	b	LBB38_177
LBB38_164:
	ldrb	w8, [sp, #919]
	tbz	w8, #0, LBB38_169
	b	LBB38_165
LBB38_165:
	ldr	x8, [sp, #352]
	cbz	x8, LBB38_167
	b	LBB38_166
LBB38_166:
	ldr	x0, [sp, #392]
	ldr	w1, [sp, #388]
	ldrh	w3, [sp, #102]
	ldr	x4, [sp, #352]
	add	x8, sp, #662
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	add	x2, sp, #304
	bl	_nvm_verify_function_types_record_array
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	add	x0, sp, #919
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB38_168
LBB38_167:
	ldr	x0, [sp, #392]
	ldr	w1, [sp, #388]
	ldrh	w3, [sp, #102]
	add	x8, sp, #405
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	add	x2, sp, #304
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	bl	_nvm_verify_function_types
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	add	x0, sp, #919
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB38_168
LBB38_168:
	b	LBB38_169
LBB38_169:
	ldrb	w8, [sp, #919]
	tbz	w8, #0, LBB38_172
	b	LBB38_170
LBB38_170:
	ldr	x8, [sp, #360]
	cbz	x8, LBB38_172
	b	LBB38_171
LBB38_171:
	ldrh	w8, [sp, #102]
	ldr	x9, [sp, #360]
	strh	w8, [x9]
	b	LBB38_172
LBB38_172:
	ldrb	w8, [sp, #919]
	tbz	w8, #0, LBB38_175
	b	LBB38_173
LBB38_173:
	ldr	x8, [sp, #344]
	cbz	x8, LBB38_175
	b	LBB38_174
LBB38_174:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #344]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	q0, [x9, #16]
	str	q0, [x8, #16]
	b	LBB38_176
LBB38_175:
	add	x0, sp, #304
	bl	_vm_decoded_function_free
	b	LBB38_176
LBB38_176:
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	add	x1, sp, #919
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB38_177
LBB38_177:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB38_179
	b	LBB38_178
LBB38_178:
	bl	___stack_chk_fail
LBB38_179:
	add	sp, sp, #1648
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI38_0:
	.long	LBB38_80-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_92-Ltmp10
	.long	LBB38_92-Ltmp10
	.long	LBB38_88-Ltmp10
	.long	LBB38_88-Ltmp10
	.long	LBB38_96-Ltmp10
	.long	LBB38_96-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_12-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_41-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_17-Ltmp10
	.long	LBB38_17-Ltmp10
	.long	LBB38_17-Ltmp10
	.long	LBB38_41-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_84-Ltmp10
	.long	LBB38_51-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_135-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_146-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_103-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_103-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_115-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_35-Ltmp10
	.long	LBB38_109-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_139-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_135-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_69-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_23-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_31-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_150-Ltmp10
	.long	LBB38_76-Ltmp10
	.long	LBB38_121-Ltmp10
                                        ; -- End function
	.globl	_nvm_verify_affine_function     ; -- Begin function nvm_verify_affine_function
	.p2align	2
_nvm_verify_affine_function:            ; @nvm_verify_affine_function
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #40]
	str	w1, [sp, #36]
	ldr	x0, [sp, #40]
	add	x8, sp, #263
	mov	w9, #1                          ; =0x1
	and	w1, w9, #0x1
	mov	x2, #0                          ; =0x0
	bl	_verify_structure
	ldrb	w8, [sp, #263]
	tbnz	w8, #0, LBB39_2
	b	LBB39_1
LBB39_1:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	x1, sp, #263
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB39_5
LBB39_2:
	ldr	x0, [sp, #40]
	ldr	w1, [sp, #36]
	add	x8, sp, #52
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #52]
	tbnz	w8, #0, LBB39_4
	b	LBB39_3
LBB39_3:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x9, sp, #52
	ldr	w10, [sp, #56]
	mov	x11, x10
	add	x9, x9, #16
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	adrp	x0, l_.str.56@PAGE
	add	x0, x0, l_.str.56@PAGEOFF
	bl	_fail
	b	LBB39_5
LBB39_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB39_5
LBB39_5:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB39_7
	b	LBB39_6
LBB39_6:
	bl	___stack_chk_fail
LBB39_7:
	add	sp, sp, #528
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_structure
_verify_structure:                      ; @verify_structure
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	sturb	w1, [x29, #-9]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldurb	w9, [x29, #-9]
	ldr	x2, [sp, #8]
	and	w1, w9, #0x1
	mov	w9, #0                          ; =0x0
	and	w3, w9, #0x1
	bl	_verify_structure_checked
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fail
_fail:                                  ; @fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-8]
	mov	x1, #257                        ; =0x101
	bl	_bzero
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x10, sp, #16
	add	x9, x29, #16
	str	x9, [x10]
	ldur	x4, [x29, #-8]
	ldr	x5, [sp, #16]
	add	x0, x8, #1
	mov	x3, #256                        ; =0x100
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	bl	___vsnprintf_chk
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ok_result
_ok_result:                             ; @ok_result
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w9, #1                          ; =0x1
	strb	w9, [x8]
	add	x0, x8, #1
	mov	x2, #256                        ; =0x100
	adrp	x1, l_.str.182@PAGE
	add	x1, x1, l_.str.182@PAGEOFF
	bl	_memcpy
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_uses_owned_transfers       ; -- Begin function nvm_uses_owned_transfers
	.p2align	2
_nvm_uses_owned_transfers:              ; @nvm_uses_owned_transfers
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB43_2
	b	LBB43_1
LBB43_1:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_25
LBB43_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB43_5
	b	LBB43_3
LBB43_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB43_5
	b	LBB43_4
LBB43_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_25
LBB43_5:
	stur	wzr, [x29, #-20]
	b	LBB43_6
LBB43_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB43_13 Depth 2
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB43_24
	b	LBB43_7
LBB43_7:                                ;   in Loop: Header=BB43_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB43_11
	b	LBB43_8
LBB43_8:                                ;   in Loop: Header=BB43_6 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-32]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB43_11
	b	LBB43_9
LBB43_9:                                ;   in Loop: Header=BB43_6 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	cbz	w8, LBB43_12
	b	LBB43_10
LBB43_10:                               ;   in Loop: Header=BB43_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbnz	x8, LBB43_12
	b	LBB43_11
LBB43_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_25
LBB43_12:                               ;   in Loop: Header=BB43_6 Depth=1
	stur	wzr, [x29, #-36]
	b	LBB43_13
LBB43_13:                               ;   Parent Loop BB43_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB43_22
	b	LBB43_14
LBB43_14:                               ;   in Loop: Header=BB43_13 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	add	x2, sp, #8
	bl	_isa_decode
	str	w0, [sp, #4]
	ldr	w8, [sp, #4]
	cbnz	w8, LBB43_16
	b	LBB43_15
LBB43_15:                               ;   in Loop: Header=BB43_6 Depth=1
	b	LBB43_22
LBB43_16:                               ;   in Loop: Header=BB43_13 Depth=2
	ldrb	w8, [sp, #8]
	subs	w8, w8, #11
	b.lt	LBB43_18
	b	LBB43_17
LBB43_17:                               ;   in Loop: Header=BB43_13 Depth=2
	ldrb	w8, [sp, #8]
	subs	w8, w8, #15
	b.le	LBB43_20
	b	LBB43_18
LBB43_18:                               ;   in Loop: Header=BB43_13 Depth=2
	ldrb	w8, [sp, #8]
	subs	w8, w8, #22
	b.lt	LBB43_21
	b	LBB43_19
LBB43_19:                               ;   in Loop: Header=BB43_13 Depth=2
	ldrb	w8, [sp, #8]
	subs	w8, w8, #31
	b.gt	LBB43_21
	b	LBB43_20
LBB43_20:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_25
LBB43_21:                               ;   in Loop: Header=BB43_13 Depth=2
	ldr	w9, [sp, #4]
	ldur	w8, [x29, #-36]
	add	w8, w8, w9
	stur	w8, [x29, #-36]
	b	LBB43_13
LBB43_22:                               ;   in Loop: Header=BB43_6 Depth=1
	b	LBB43_23
LBB43_23:                               ;   in Loop: Header=BB43_6 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB43_6
LBB43_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB43_25
LBB43_25:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify_owned_module        ; -- Begin function nvm_verify_owned_module
	.p2align	2
_nvm_verify_owned_module:               ; @nvm_verify_owned_module
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #3024
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #232]
	ldr	x0, [sp, #232]
	add	x8, sp, #2759
	mov	w9, #1                          ; =0x1
	and	w1, w9, #0x1
	mov	x2, #0                          ; =0x0
	bl	_verify_structure
	ldrb	w8, [sp, #2759]
	tbnz	w8, #0, LBB44_2
	b	LBB44_1
LBB44_1:
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	x1, sp, #2759
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB44_170
LBB44_2:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #304]
	cbz	w8, LBB44_10
	b	LBB44_3
LBB44_3:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #272]
	cbz	w8, LBB44_10
	b	LBB44_4
LBB44_4:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #272]
	subs	w8, w8, #8
	b.hi	LBB44_10
	b	LBB44_5
LBB44_5:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #12]
	cbnz	w8, LBB44_10
	b	LBB44_6
LBB44_6:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB44_10
	b	LBB44_7
LBB44_7:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB44_10
	b	LBB44_8
LBB44_8:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #424]
	cbnz	w8, LBB44_10
	b	LBB44_9
LBB44_9:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #352]
	cbz	w8, LBB44_11
	b	LBB44_10
LBB44_10:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.57@PAGE
	add	x0, x0, l_.str.57@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_11:
	ldr	x0, [sp, #232]
	add	x1, sp, #708
	mov	w2, #256                        ; =0x100
	add	x3, sp, #228
	bl	_nvm_ownership_globals
	cbz	w0, LBB44_13
	b	LBB44_12
LBB44_12:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.58@PAGE
	add	x0, x0, l_.str.58@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_13:
	str	wzr, [sp, #224]
	b	LBB44_14
LBB44_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #224]
	ldr	w9, [sp, #228]
	subs	w8, w8, w9
	b.hs	LBB44_21
	b	LBB44_15
LBB44_15:                               ;   in Loop: Header=BB44_14 Depth=1
	ldr	w8, [sp, #224]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #708
	ldrb	w8, [x8, x9]
	subs	w8, w8, #8
	b.eq	LBB44_18
	b	LBB44_16
LBB44_16:                               ;   in Loop: Header=BB44_14 Depth=1
	ldr	w8, [sp, #224]
                                        ; kill: def $x8 killed $w8
	lsl	x9, x8, #3
	add	x8, sp, #708
	ldrb	w8, [x8, x9]
	subs	w8, w8, #10
	b.ne	LBB44_19
	b	LBB44_17
LBB44_17:                               ;   in Loop: Header=BB44_14 Depth=1
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #296]
	ldr	w9, [sp, #224]
	mov	x10, x9
	add	x9, sp, #708
	add	x9, x9, x10, lsl #3
	ldr	w9, [x9, #4]
	add	w9, w9, #8
	ldrb	w8, [x8, w9, uxtw]
	tbz	w8, #1, LBB44_19
	b	LBB44_18
LBB44_18:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.59@PAGE
	add	x0, x0, l_.str.59@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_19:                               ;   in Loop: Header=BB44_14 Depth=1
	b	LBB44_20
LBB44_20:                               ;   in Loop: Header=BB44_14 Depth=1
	ldr	w8, [sp, #224]
	add	w8, w8, #1
	str	w8, [sp, #224]
	b	LBB44_14
LBB44_21:
	ldr	x0, [sp, #232]
	bl	_nvm_affine_value_call_graph
	strb	w0, [sp, #223]
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_24
	b	LBB44_22
LBB44_22:
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #272]
	subs	w8, w8, #2
	b.ls	LBB44_24
	b	LBB44_23
LBB44_23:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.60@PAGE
	add	x0, x0, l_.str.60@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_24:
	str	wzr, [sp, #216]
	b	LBB44_25
LBB44_25:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB44_47 Depth 2
	ldr	w8, [sp, #216]
	ldr	x9, [sp, #232]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB44_74
	b	LBB44_26
LBB44_26:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #232]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #216]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #208]
	ldr	x0, [sp, #232]
	ldr	x8, [sp, #208]
	ldr	w1, [x8]
	bl	_nvm_get_string
	str	x0, [sp, #200]
	ldr	w8, [sp, #216]
	cbz	w8, LBB44_30
	b	LBB44_27
LBB44_27:                               ;   in Loop: Header=BB44_25 Depth=1
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_29
	b	LBB44_28
LBB44_28:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB44_41
	b	LBB44_29
LBB44_29:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrh	w8, [x8, #4]
	subs	w8, w8, #8
	b.hi	LBB44_41
	b	LBB44_31
LBB44_30:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrh	w8, [x8, #4]
	cbnz	w8, LBB44_41
	b	LBB44_31
LBB44_31:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB44_41
	b	LBB44_32
LBB44_32:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	w8, [sp, #216]
	cbz	w8, LBB44_34
	b	LBB44_33
LBB44_33:                               ;   in Loop: Header=BB44_25 Depth=1
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_38
	b	LBB44_34
LBB44_34:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.ne	LBB44_41
	b	LBB44_35
LBB44_35:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #1
	b.eq	LBB44_38
	b	LBB44_36
LBB44_36:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #4
	b.eq	LBB44_38
	b	LBB44_37
LBB44_37:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #2
	b.ne	LBB44_41
	b	LBB44_38
LBB44_38:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #208]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.hi	LBB44_41
	b	LBB44_39
LBB44_39:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x8, [sp, #200]
	cbz	x8, LBB44_42
	b	LBB44_40
LBB44_40:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x0, [sp, #200]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB44_42
	b	LBB44_41
LBB44_41:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.61@PAGE
	add	x0, x0, l_.str.61@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_42:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x0, [sp, #232]
	ldr	w1, [sp, #216]
	ldr	x8, [sp, #208]
	ldrh	w2, [x8, #16]
	bl	_nvm_affine_state_create
	str	x0, [sp, #192]
	ldr	x8, [sp, #192]
	cbnz	x8, LBB44_44
	b	LBB44_43
LBB44_43:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.62@PAGE
	add	x0, x0, l_.str.62@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_44:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x0, [sp, #192]
	bl	_nvm_affine_has_array_types
	tbz	w0, #0, LBB44_46
	b	LBB44_45
LBB44_45:
	ldr	x0, [sp, #192]
	bl	_nvm_affine_state_free
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.63@PAGE
	add	x0, x0, l_.str.63@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_46:                               ;   in Loop: Header=BB44_25 Depth=1
	add	x2, sp, #182
	strh	wzr, [sp, #182]
	ldr	x0, [sp, #192]
	add	x1, sp, #184
	bl	_nvm_affine_value_result
	strb	w0, [sp, #181]
	strh	wzr, [sp, #178]
	b	LBB44_47
LBB44_47:                               ;   Parent Loop BB44_25 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #178]
	ldr	x9, [sp, #208]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB44_70
	b	LBB44_48
LBB44_48:                               ;   in Loop: Header=BB44_47 Depth=2
	ldr	w8, [sp, #216]
	cbz	w8, LBB44_54
	b	LBB44_49
LBB44_49:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_54
	b	LBB44_50
LBB44_50:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrh	w8, [sp, #178]
	ldr	x9, [sp, #208]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB44_54
	b	LBB44_51
LBB44_51:                               ;   in Loop: Header=BB44_47 Depth=2
	ldr	x0, [sp, #192]
	ldrh	w1, [sp, #178]
	add	x2, sp, #168
	add	x3, sp, #164
	bl	_nvm_affine_parameter_at
	tbnz	w0, #0, LBB44_53
	b	LBB44_52
LBB44_52:                               ;   in Loop: Header=BB44_47 Depth=2
	strb	wzr, [sp, #181]
	b	LBB44_53
LBB44_53:                               ;   in Loop: Header=BB44_47 Depth=2
	b	LBB44_68
LBB44_54:                               ;   in Loop: Header=BB44_47 Depth=2
	ldr	x0, [sp, #192]
	ldrh	w1, [sp, #178]
	add	x2, sp, #168
	bl	_nvm_affine_local_type
	tbz	w0, #0, LBB44_66
	b	LBB44_55
LBB44_55:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #1
	b.eq	LBB44_67
	b	LBB44_56
LBB44_56:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #4
	b.eq	LBB44_67
	b	LBB44_57
LBB44_57:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #2
	b.eq	LBB44_67
	b	LBB44_58
LBB44_58:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #8
	b.eq	LBB44_67
	b	LBB44_59
LBB44_59:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #10
	b.eq	LBB44_67
	b	LBB44_60
LBB44_60:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrh	w8, [sp, #178]
	ldr	x9, [sp, #208]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.lt	LBB44_63
	b	LBB44_61
LBB44_61:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #3
	b.ne	LBB44_63
	b	LBB44_62
LBB44_62:                               ;   in Loop: Header=BB44_47 Depth=2
	ldr	w8, [sp, #172]
	adds	w8, w8, #1
	b.eq	LBB44_67
	b	LBB44_63
LBB44_63:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #223]
	tbz	w8, #0, LBB44_66
	b	LBB44_64
LBB44_64:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrb	w8, [sp, #168]
	subs	w8, w8, #5
	b.ne	LBB44_66
	b	LBB44_65
LBB44_65:                               ;   in Loop: Header=BB44_47 Depth=2
	ldr	w8, [sp, #172]
	adds	w8, w8, #1
	b.eq	LBB44_67
	b	LBB44_66
LBB44_66:                               ;   in Loop: Header=BB44_47 Depth=2
	strb	wzr, [sp, #181]
	b	LBB44_67
LBB44_67:                               ;   in Loop: Header=BB44_47 Depth=2
	b	LBB44_68
LBB44_68:                               ;   in Loop: Header=BB44_47 Depth=2
	b	LBB44_69
LBB44_69:                               ;   in Loop: Header=BB44_47 Depth=2
	ldrh	w8, [sp, #178]
	add	w8, w8, #1
	strh	w8, [sp, #178]
	b	LBB44_47
LBB44_70:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	x0, [sp, #192]
	bl	_nvm_affine_state_free
	ldrb	w8, [sp, #181]
	tbnz	w8, #0, LBB44_72
	b	LBB44_71
LBB44_71:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.64@PAGE
	add	x0, x0, l_.str.64@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_72:                               ;   in Loop: Header=BB44_25 Depth=1
	b	LBB44_73
LBB44_73:                               ;   in Loop: Header=BB44_25 Depth=1
	ldr	w8, [sp, #216]
	add	w8, w8, #1
	str	w8, [sp, #216]
	b	LBB44_25
LBB44_74:
	add	x2, sp, #144
	str	xzr, [sp, #144]
	str	xzr, [sp, #152]
	ldr	x8, [sp, #232]
	ldr	x0, [x8, #312]
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #320]
	mov	x1, x8
	bl	_nvm_v2_layouts_decode
	cbz	w0, LBB44_76
	b	LBB44_75
LBB44_75:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.65@PAGE
	add	x0, x0, l_.str.65@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_76:
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #143]
	str	wzr, [sp, #136]
	str	wzr, [sp, #132]
	b	LBB44_77
LBB44_77:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB44_90 Depth 2
	ldr	w8, [sp, #132]
	ldr	w9, [sp, #152]
	subs	w8, w8, w9
	b.hs	LBB44_107
	b	LBB44_78
LBB44_78:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #144]
	ldr	w9, [sp, #132]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	str	x8, [sp, #120]
	ldr	x8, [sp, #120]
	ldrb	w8, [x8]
	subs	w8, w8, #2
	b.ne	LBB44_85
	b	LBB44_79
LBB44_79:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #296]
	ldr	w9, [sp, #132]
	add	w9, w9, #8
	ldrb	w8, [x8, w9, uxtw]
	cbz	w8, LBB44_81
	b	LBB44_80
LBB44_80:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #296]
	ldr	w9, [sp, #132]
	add	w9, w9, #8
	ldrb	w8, [x8, w9, uxtw]
	tbz	w8, #0, LBB44_83
	b	LBB44_81
LBB44_81:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x0, [sp, #232]
	ldr	w1, [sp, #136]
	mov	w2, #0                          ; =0x0
	add	x3, sp, #108
	bl	_nvm_ownership_union_variant
	cbnz	w0, LBB44_83
	b	LBB44_82
LBB44_82:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	w8, [sp, #108]
	ldr	w9, [sp, #132]
	subs	w8, w8, w9
	b.eq	LBB44_84
	b	LBB44_83
LBB44_83:                               ;   in Loop: Header=BB44_77 Depth=1
	strb	wzr, [sp, #143]
	b	LBB44_84
LBB44_84:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	w8, [sp, #136]
	add	w8, w8, #1
	str	w8, [sp, #136]
	b	LBB44_106
LBB44_85:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #296]
	ldr	w9, [sp, #132]
	add	w9, w9, #8
	ldrb	w8, [x8, w9, uxtw]
	tbz	w8, #0, LBB44_88
	b	LBB44_86
LBB44_86:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #120]
	ldrb	w8, [x8]
	cbnz	w8, LBB44_88
	b	LBB44_87
LBB44_87:                               ;   in Loop: Header=BB44_77 Depth=1
	ldr	x8, [sp, #120]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.ls	LBB44_89
	b	LBB44_88
LBB44_88:                               ;   in Loop: Header=BB44_77 Depth=1
	strb	wzr, [sp, #143]
	b	LBB44_89
LBB44_89:                               ;   in Loop: Header=BB44_77 Depth=1
	strh	wzr, [sp, #106]
	b	LBB44_90
LBB44_90:                               ;   Parent Loop BB44_77 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #106]
	ldr	x9, [sp, #120]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB44_105
	b	LBB44_91
LBB44_91:                               ;   in Loop: Header=BB44_90 Depth=2
	ldr	x8, [sp, #120]
	ldr	x11, [x8, #8]
	ldrh	w8, [sp, #106]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrb	w8, [x8]
	strb	w8, [sp, #105]
	ldr	x8, [sp, #120]
	ldr	x10, [x8, #8]
	ldrh	w8, [sp, #106]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	str	w8, [sp, #100]
	ldr	w8, [sp, #100]
	adds	w8, w8, #1
	b.eq	LBB44_94
	b	LBB44_92
LBB44_92:                               ;   in Loop: Header=BB44_90 Depth=2
	ldr	w8, [sp, #100]
	ldr	w9, [sp, #132]
	subs	w8, w8, w9
	b.lo	LBB44_94
	b	LBB44_93
LBB44_93:                               ;   in Loop: Header=BB44_90 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_94
LBB44_94:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #1
	b.eq	LBB44_103
	b	LBB44_95
LBB44_95:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #4
	b.eq	LBB44_103
	b	LBB44_96
LBB44_96:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #2
	b.eq	LBB44_103
	b	LBB44_97
LBB44_97:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #8
	b.eq	LBB44_103
	b	LBB44_98
LBB44_98:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #10
	b.eq	LBB44_103
	b	LBB44_99
LBB44_99:                               ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #223]
	tbz	w8, #0, LBB44_102
	b	LBB44_100
LBB44_100:                              ;   in Loop: Header=BB44_90 Depth=2
	ldrb	w8, [sp, #105]
	subs	w8, w8, #5
	b.ne	LBB44_102
	b	LBB44_101
LBB44_101:                              ;   in Loop: Header=BB44_90 Depth=2
	ldr	w8, [sp, #100]
	adds	w8, w8, #1
	b.eq	LBB44_103
	b	LBB44_102
LBB44_102:                              ;   in Loop: Header=BB44_90 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_103
LBB44_103:                              ;   in Loop: Header=BB44_90 Depth=2
	b	LBB44_104
LBB44_104:                              ;   in Loop: Header=BB44_90 Depth=2
	ldrh	w8, [sp, #106]
	add	w8, w8, #1
	strh	w8, [sp, #106]
	b	LBB44_90
LBB44_105:                              ;   in Loop: Header=BB44_77 Depth=1
	b	LBB44_106
LBB44_106:                              ;   in Loop: Header=BB44_77 Depth=1
	ldr	w8, [sp, #132]
	add	w8, w8, #1
	str	w8, [sp, #132]
	b	LBB44_77
LBB44_107:
	add	x0, sp, #144
	bl	_nvm_v2_layouts_free
	ldrb	w8, [sp, #143]
	tbnz	w8, #0, LBB44_109
	b	LBB44_108
LBB44_108:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.66@PAGE
	add	x0, x0, l_.str.66@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_109:
	ldr	w8, [sp, #228]
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #99]
	str	wzr, [sp, #92]
	b	LBB44_110
LBB44_110:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB44_114 Depth 2
	ldr	w8, [sp, #92]
	ldr	x9, [sp, #232]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB44_166
	b	LBB44_111
LBB44_111:                              ;   in Loop: Header=BB44_110 Depth=1
	ldr	x0, [sp, #232]
	ldr	w1, [sp, #92]
	add	x2, sp, #56
	add	x3, sp, #452
	bl	_vm_decode_function
	tbnz	w0, #0, LBB44_113
	b	LBB44_112
LBB44_112:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	x10, sp
	add	x9, sp, #452
	str	x9, [x10]
	adrp	x0, l_.str.67@PAGE
	add	x0, x0, l_.str.67@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_113:                              ;   in Loop: Header=BB44_110 Depth=1
	str	wzr, [sp, #52]
	b	LBB44_114
LBB44_114:                              ;   Parent Loop BB44_110 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #64]
	subs	w8, w8, w9
	b.hs	LBB44_160
	b	LBB44_115
LBB44_115:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x10, [sp, #56]
	ldr	w8, [sp, #52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #40
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8]
	strb	w8, [sp, #39]
	ldrb	w8, [sp, #39]
	subs	w8, w8, #11
	b.lt	LBB44_118
	b	LBB44_116
LBB44_116:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #14
	b.gt	LBB44_118
	b	LBB44_117
LBB44_117:                              ;   in Loop: Header=BB44_114 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #99]
	b	LBB44_118
LBB44_118:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #251
	b.ne	LBB44_121
	b	LBB44_119
LBB44_119:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.ne	LBB44_121
	b	LBB44_120
LBB44_120:                              ;   in Loop: Header=BB44_114 Depth=2
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #99]
	b	LBB44_121
LBB44_121:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w0, [sp, #39]
	ldrb	w8, [sp, #223]
	and	w1, w8, #0x1
	bl	_owned_runtime_opcode
	tbnz	w0, #0, LBB44_123
	b	LBB44_122
LBB44_122:                              ;   in Loop: Header=BB44_114 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_123
LBB44_123:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #4
	b.ne	LBB44_131
	b	LBB44_124
LBB44_124:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	str	w8, [sp, #32]
	ldr	w8, [sp, #32]
	ldr	x9, [sp, #232]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB44_129
	b	LBB44_125
LBB44_125:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #232]
	cbz	x8, LBB44_129
	b	LBB44_126
LBB44_126:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #240]
	cbz	x8, LBB44_129
	b	LBB44_127
LBB44_127:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB44_129
	b	LBB44_128
LBB44_128:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #232]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB44_130
	b	LBB44_129
LBB44_129:                              ;   in Loop: Header=BB44_114 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_130
LBB44_130:                              ;   in Loop: Header=BB44_114 Depth=2
	b	LBB44_131
LBB44_131:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #15
	b.ne	LBB44_137
	b	LBB44_132
LBB44_132:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	w8, [sp, #92]
	cbnz	w8, LBB44_136
	b	LBB44_133
LBB44_133:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_136
	b	LBB44_134
LBB44_134:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #232]
	ldr	w8, [x8, #272]
	subs	w8, w8, #2
	b.ne	LBB44_136
	b	LBB44_135
LBB44_135:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB44_137
	b	LBB44_136
LBB44_136:                              ;   in Loop: Header=BB44_114 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_137
LBB44_137:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #59
	b.ne	LBB44_142
	b	LBB44_138
LBB44_138:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #223]
	tbz	w8, #0, LBB44_141
	b	LBB44_139
LBB44_139:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	cbz	w8, LBB44_141
	b	LBB44_140
LBB44_140:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #232]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB44_142
	b	LBB44_141
LBB44_141:                              ;   in Loop: Header=BB44_114 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_142
LBB44_142:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	w8, [sp, #92]
	cbz	w8, LBB44_158
	b	LBB44_143
LBB44_143:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #223]
	tbnz	w8, #0, LBB44_158
	b	LBB44_144
LBB44_144:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #252
	b.eq	LBB44_157
	b	LBB44_145
LBB44_145:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #97
	b.eq	LBB44_157
	b	LBB44_146
LBB44_146:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #16
	b.eq	LBB44_151
	b	LBB44_147
LBB44_147:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #17
	b.eq	LBB44_151
	b	LBB44_148
LBB44_148:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #11
	b.eq	LBB44_151
	b	LBB44_149
LBB44_149:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #12
	b.eq	LBB44_151
	b	LBB44_150
LBB44_150:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #14
	b.ne	LBB44_152
	b	LBB44_151
LBB44_151:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #8]
	ldr	x9, [sp, #232]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.lt	LBB44_157
	b	LBB44_152
LBB44_152:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #24
	b.eq	LBB44_156
	b	LBB44_153
LBB44_153:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #25
	b.eq	LBB44_156
	b	LBB44_154
LBB44_154:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #28
	b.eq	LBB44_156
	b	LBB44_155
LBB44_155:                              ;   in Loop: Header=BB44_114 Depth=2
	ldrb	w8, [sp, #39]
	subs	w8, w8, #29
	b.ne	LBB44_158
	b	LBB44_156
LBB44_156:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #16]
	ldr	x9, [sp, #232]
	ldr	x11, [x9, #256]
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB44_158
	b	LBB44_157
LBB44_157:                              ;   in Loop: Header=BB44_114 Depth=2
	strb	wzr, [sp, #143]
	b	LBB44_158
LBB44_158:                              ;   in Loop: Header=BB44_114 Depth=2
	b	LBB44_159
LBB44_159:                              ;   in Loop: Header=BB44_114 Depth=2
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB44_114
LBB44_160:                              ;   in Loop: Header=BB44_110 Depth=1
	add	x0, sp, #56
	bl	_vm_decoded_function_free
	ldr	w8, [sp, #92]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	w8, LBB44_162
	b	LBB44_161
LBB44_161:                              ;   in Loop: Header=BB44_110 Depth=1
	ldr	x0, [sp, #232]
	ldr	w1, [sp, #92]
	add	x8, sp, #244
	bl	_nvm_affine_analyze_function
	ldrb	w8, [sp, #244]
	eor	w8, w8, #0x1
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB44_162
LBB44_162:                              ;   in Loop: Header=BB44_110 Depth=1
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB44_164
	b	LBB44_163
LBB44_163:                              ;   in Loop: Header=BB44_110 Depth=1
	strb	wzr, [sp, #143]
	b	LBB44_164
LBB44_164:                              ;   in Loop: Header=BB44_110 Depth=1
	b	LBB44_165
LBB44_165:                              ;   in Loop: Header=BB44_110 Depth=1
	ldr	w8, [sp, #92]
	add	w8, w8, #1
	str	w8, [sp, #92]
	b	LBB44_110
LBB44_166:
	ldrb	w8, [sp, #143]
	tbz	w8, #0, LBB44_168
	b	LBB44_167
LBB44_167:
	ldrb	w8, [sp, #99]
	tbnz	w8, #0, LBB44_169
	b	LBB44_168
LBB44_168:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.68@PAGE
	add	x0, x0, l_.str.68@PAGEOFF
	bl	_fail
	b	LBB44_170
LBB44_169:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #232]
	mov	w1, #0                          ; =0x0
	bl	_nvm_verify_affine_function
	b	LBB44_170
LBB44_170:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB44_172
	b	LBB44_171
LBB44_171:
	bl	___stack_chk_fail
LBB44_172:
	add	sp, sp, #3024
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function owned_runtime_opcode
_owned_runtime_opcode:                  ; @owned_runtime_opcode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #14]
	strb	w1, [sp, #13]
	ldrb	w8, [sp, #14]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB45_4
; %bb.1:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI45_0@PAGE
	add	x10, x10, lJTI45_0@PAGEOFF
Ltmp12:
	adr	x8, Ltmp12
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB45_2:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB45_5
LBB45_3:
	ldrb	w8, [sp, #13]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB45_5
LBB45_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #15]
	b	LBB45_5
LBB45_5:
	ldrb	w8, [sp, #15]
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
	.p2align	2
lJTI45_0:
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_3-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_2-Ltmp12
	.long	LBB45_4-Ltmp12
	.long	LBB45_2-Ltmp12
                                        ; -- End function
	.globl	_nvm_verify_function            ; -- Begin function nvm_verify_function
	.p2align	2
_nvm_verify_function:                   ; @nvm_verify_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	mov	x4, #0                          ; =0x0
	mov	x2, x4
	mov	w3, #0                          ; =0x0
	bl	_verify_function_impl
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_function_impl
_verify_function_impl:                  ; @verify_function_impl
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #88]
	str	w1, [sp, #84]
	str	x2, [sp, #72]
	str	w3, [sp, #68]
	str	x4, [sp, #56]
	ldr	x0, [sp, #88]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB47_2
	b	LBB47_1
LBB47_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.70@PAGE
	add	x0, x0, l_.str.70@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_2:
	str	wzr, [sp, #52]
	b	LBB47_3
LBB47_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB47_9
	b	LBB47_4
LBB47_4:                                ;   in Loop: Header=BB47_3 Depth=1
	ldr	x8, [sp, #72]
	cbz	x8, LBB47_6
	b	LBB47_5
LBB47_5:                                ;   in Loop: Header=BB47_3 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB47_7
	b	LBB47_6
LBB47_6:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.74@PAGE
	add	x0, x0, l_.str.74@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_7:                                ;   in Loop: Header=BB47_3 Depth=1
	b	LBB47_8
LBB47_8:                                ;   in Loop: Header=BB47_3 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB47_3
LBB47_9:
	ldr	x0, [sp, #88]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB47_13
	b	LBB47_10
LBB47_10:
	ldr	w8, [sp, #68]
	cbz	w8, LBB47_12
	b	LBB47_11
LBB47_11:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.75@PAGE
	add	x0, x0, l_.str.75@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_12:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #56]
	mov	x3, #0                          ; =0x0
	bl	_verify_record_maps
	b	LBB47_47
LBB47_13:
	ldr	x0, [sp, #88]
	bl	_nvm_owned_array_route
	cbz	w0, LBB47_17
	b	LBB47_14
LBB47_14:
	ldr	w8, [sp, #68]
	cbz	w8, LBB47_16
	b	LBB47_15
LBB47_15:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.77@PAGE
	add	x0, x0, l_.str.77@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #56]
	bl	_verify_owned_arrays
	b	LBB47_47
LBB47_17:
	ldr	x0, [sp, #88]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB47_21
	b	LBB47_18
LBB47_18:
	ldr	w8, [sp, #68]
	cbz	w8, LBB47_20
	b	LBB47_19
LBB47_19:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.78@PAGE
	add	x0, x0, l_.str.78@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_20:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #56]
	bl	_verify_mixed_samples
	b	LBB47_47
LBB47_21:
	ldr	x0, [sp, #88]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB47_25
	b	LBB47_22
LBB47_22:
	ldr	w8, [sp, #68]
	cbz	w8, LBB47_24
	b	LBB47_23
LBB47_23:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.80@PAGE
	add	x0, x0, l_.str.80@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_24:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #56]
	mov	x3, #0                          ; =0x0
	bl	_verify_record_arrays
	b	LBB47_47
LBB47_25:
	str	wzr, [sp, #48]
	b	LBB47_26
LBB47_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #68]
	subs	w8, w8, w9
	b.hs	LBB47_32
	b	LBB47_27
LBB47_27:                               ;   in Loop: Header=BB47_26 Depth=1
	ldr	x8, [sp, #72]
	cbz	x8, LBB47_29
	b	LBB47_28
LBB47_28:                               ;   in Loop: Header=BB47_26 Depth=1
	ldr	x8, [sp, #72]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB47_30
	b	LBB47_29
LBB47_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.183@PAGE
	add	x0, x0, l_.str.183@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_30:                               ;   in Loop: Header=BB47_26 Depth=1
	b	LBB47_31
LBB47_31:                               ;   in Loop: Header=BB47_26 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB47_26
LBB47_32:
	add	x2, sp, #47
	strb	wzr, [sp, #47]
	ldr	x0, [sp, #88]
	add	x8, sp, #359
	mov	w9, #0                          ; =0x0
	and	w1, w9, #0x1
	bl	_verify_structure
	ldrb	w8, [sp, #359]
	tbnz	w8, #0, LBB47_34
	b	LBB47_33
LBB47_33:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #359
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB47_47
LBB47_34:
	ldr	w8, [sp, #84]
	ldr	x9, [sp, #88]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB47_36
	b	LBB47_35
LBB47_35:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #84]
	mov	x11, x9
	ldr	x9, [sp, #88]
	ldr	w9, [x9, #272]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	adrp	x0, l_.str.184@PAGE
	add	x0, x0, l_.str.184@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_36:
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #304]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #28]                   ; 4-byte Folded Spill
	cbz	w8, LBB47_40
	b	LBB47_37
LBB47_37:
	ldrb	w8, [sp, #47]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #24]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB47_39
	b	LBB47_38
LBB47_38:
	ldr	x0, [sp, #88]
	add	x8, sp, #102
	bl	_nvm_verify_owned_module
	ldrb	w8, [sp, #102]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	b	LBB47_39
LBB47_39:
	ldr	w8, [sp, #24]                   ; 4-byte Folded Reload
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB47_40
LBB47_40:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB47_46
	b	LBB47_41
LBB47_41:
	ldr	w8, [sp, #68]
	cbz	w8, LBB47_43
	b	LBB47_42
LBB47_42:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.82@PAGE
	add	x0, x0, l_.str.82@PAGEOFF
	bl	_fail
	b	LBB47_47
LBB47_43:
	ldr	x8, [sp, #56]
	cbz	x8, LBB47_45
	b	LBB47_44
LBB47_44:
	ldr	x9, [sp, #56]
	mov	w8, #256                        ; =0x100
	strh	w8, [x9]
	b	LBB47_45
LBB47_45:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB47_47
LBB47_46:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #72]
	ldr	w3, [sp, #68]
	ldr	x4, [sp, #56]
	mov	x6, #0                          ; =0x0
	mov	x5, x6
	bl	_verify_function_body
	b	LBB47_47
LBB47_47:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB47_49
	b	LBB47_48
LBB47_48:
	bl	___stack_chk_fail
LBB47_49:
	add	sp, sp, #624
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify_function_max_stack  ; -- Begin function nvm_verify_function_max_stack
	.p2align	2
_nvm_verify_function_max_stack:         ; @nvm_verify_function_max_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldr	x4, [sp, #8]
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_impl
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify_declared_max_stacks ; -- Begin function nvm_verify_declared_max_stacks
	.p2align	2
_nvm_verify_declared_max_stacks:        ; @nvm_verify_declared_max_stacks
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #384
	stp	x28, x27, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	add	x29, sp, #368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #72]
	str	x1, [sp, #64]
	str	w2, [sp, #60]
	ldr	x8, [sp, #72]
	cbz	x8, LBB49_4
	b	LBB49_1
LBB49_1:
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB49_4
	b	LBB49_2
LBB49_2:
	ldr	w8, [sp, #60]
	cbz	w8, LBB49_5
	b	LBB49_3
LBB49_3:
	ldr	x8, [sp, #64]
	cbnz	x8, LBB49_5
	b	LBB49_4
LBB49_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.69@PAGE
	add	x0, x0, l_.str.69@PAGEOFF
	bl	_fail
	b	LBB49_31
LBB49_5:
	strb	wzr, [sp, #59]
	str	wzr, [sp, #52]
	b	LBB49_6
LBB49_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.hs	LBB49_9
	b	LBB49_7
LBB49_7:                                ;   in Loop: Header=BB49_6 Depth=1
	ldr	x8, [sp, #64]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	subs	w8, w8, #0
	cset	w9, ne
	ldrb	w8, [sp, #59]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #59]
	b	LBB49_8
LBB49_8:                                ;   in Loop: Header=BB49_6 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB49_6
LBB49_9:
	ldr	x0, [sp, #72]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB49_11
	b	LBB49_10
LBB49_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	x3, [sp, #64]
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	bl	_verify_record_maps
	b	LBB49_31
LBB49_11:
	ldrb	w8, [sp, #59]
	tbnz	w8, #0, LBB49_13
	b	LBB49_12
LBB49_12:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB49_31
LBB49_13:
	ldr	x0, [sp, #72]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB49_15
	b	LBB49_14
LBB49_14:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.70@PAGE
	add	x0, x0, l_.str.70@PAGEOFF
	bl	_fail
	b	LBB49_31
LBB49_15:
	ldr	x0, [sp, #72]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB49_17
	b	LBB49_16
LBB49_16:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	x3, [sp, #64]
	mov	w1, #-1                         ; =0xffffffff
	mov	x2, #0                          ; =0x0
	bl	_verify_record_arrays
	b	LBB49_31
LBB49_17:
	ldr	x0, [sp, #72]
	bl	_nvm_owned_array_route
	cbnz	w0, LBB49_19
	b	LBB49_18
LBB49_18:
	ldr	x0, [sp, #72]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB49_30
	b	LBB49_19
LBB49_19:
	str	wzr, [sp, #48]
	b	LBB49_20
LBB49_20:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.hs	LBB49_29
	b	LBB49_21
LBB49_21:                               ;   in Loop: Header=BB49_20 Depth=1
	ldr	x8, [sp, #64]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	cbnz	w8, LBB49_23
	b	LBB49_22
LBB49_22:                               ;   in Loop: Header=BB49_20 Depth=1
	b	LBB49_28
LBB49_23:                               ;   in Loop: Header=BB49_20 Depth=1
	add	x4, sp, #46
	strh	wzr, [sp, #46]
	ldr	x0, [sp, #72]
	ldr	w1, [sp, #48]
	add	x8, sp, #87
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_verify_function_impl
	ldrb	w8, [sp, #87]
	tbnz	w8, #0, LBB49_25
	b	LBB49_24
LBB49_24:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	add	x1, sp, #87
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB49_31
LBB49_25:                               ;   in Loop: Header=BB49_20 Depth=1
	ldr	x8, [sp, #64]
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #46]
	subs	w8, w8, w9
	b.ge	LBB49_27
	b	LBB49_26
LBB49_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #48]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #64]
	ldr	w11, [sp, #48]
                                        ; kill: def $x11 killed $w11
	ldrh	w12, [x10, x11, lsl #1]
	ldrh	w11, [sp, #46]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.71@PAGE
	add	x0, x0, l_.str.71@PAGEOFF
	bl	_fail
	b	LBB49_31
LBB49_27:                               ;   in Loop: Header=BB49_20 Depth=1
	b	LBB49_28
LBB49_28:                               ;   in Loop: Header=BB49_20 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB49_20
LBB49_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB49_31
LBB49_30:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	x3, [sp, #64]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_verify_functions_with_structure
	b	LBB49_31
LBB49_31:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB49_33
	b	LBB49_32
LBB49_32:
	bl	___stack_chk_fail
LBB49_33:
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #352]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_map_selected
_nvm_record_map_selected:               ; @nvm_record_map_selected
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB50_3
	b	LBB50_1
LBB50_1:
	ldr	w9, [sp, #12]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB50_3
	b	LBB50_2
LBB50_2:
	ldr	w8, [sp, #12]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB50_3
LBB50_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_record_maps
_verify_record_maps:                    ; @verify_record_maps
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1232
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #208
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	mov	x9, x8
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #32]
	str	w1, [sp, #236]
	str	x2, [x8, #16]
	str	x3, [x8, #8]
	add	x1, sp, #208
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x0, [x8, #32]
	sub	x8, x29, #228
	bl	_nvm_record_map_admit
	ldur	w8, [x29, #-228]
	cbz	w8, LBB51_2
	b	LBB51_1
LBB51_1:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	sub	x9, x29, #228
	add	x9, x9, #12
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.185@PAGE
	add	x0, x0, l_.str.185@PAGEOFF
	bl	_fail
	b	LBB51_23
LBB51_2:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	strh	wzr, [sp, #110]
	bl	_ok_result
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	add	x1, sp, #112
	bl	_nvm_record_map_execution_counts
	tbz	w0, #0, LBB51_5
	b	LBB51_3
LBB51_3:
	ldr	w8, [sp, #236]
	adds	w8, w8, #1
	b.eq	LBB51_6
	b	LBB51_4
LBB51_4:
	ldr	w8, [sp, #236]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	b.lo	LBB51_6
	b	LBB51_5
LBB51_5:
	add	x8, sp, #763
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.186@PAGE
	add	x0, x0, l_.str.186@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB51_19
LBB51_6:
	str	wzr, [sp, #104]
	b	LBB51_7
LBB51_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #104]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	b.hs	LBB51_18
	b	LBB51_8
LBB51_8:                                ;   in Loop: Header=BB51_7 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	w1, [sp, #104]
	add	x2, sp, #68
	bl	_nvm_record_map_execution_function
	tbnz	w0, #0, LBB51_10
	b	LBB51_9
LBB51_9:
	add	x8, sp, #506
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.187@PAGE
	add	x0, x0, l_.str.187@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB51_18
LBB51_10:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB51_14
	b	LBB51_11
LBB51_11:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #104]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	cbz	w8, LBB51_14
	b	LBB51_12
LBB51_12:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldr	w9, [sp, #104]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #100]
	subs	w8, w8, w9
	b.ge	LBB51_14
	b	LBB51_13
LBB51_13:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #104]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [x9, #8]
	ldr	w10, [sp, #104]
                                        ; kill: def $x10 killed $w10
	ldrh	w11, [x9, x10, lsl #1]
	ldrh	w10, [sp, #100]
	mov	x9, sp
	str	x8, [x9]
                                        ; implicit-def: $x8
	mov	x8, x11
	str	x8, [x9, #8]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #16]
	add	x8, sp, #249
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.71@PAGE
	add	x0, x0, l_.str.71@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB51_18
LBB51_14:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	w8, [sp, #104]
	ldr	w9, [sp, #236]
	subs	w8, w8, w9
	b.ne	LBB51_16
	b	LBB51_15
LBB51_15:                               ;   in Loop: Header=BB51_7 Depth=1
	ldrh	w8, [sp, #100]
	strh	w8, [sp, #110]
	b	LBB51_16
LBB51_16:                               ;   in Loop: Header=BB51_7 Depth=1
	b	LBB51_17
LBB51_17:                               ;   in Loop: Header=BB51_7 Depth=1
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB51_7
LBB51_18:
	b	LBB51_19
LBB51_19:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_record_map_execution_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbz	w8, #0, LBB51_22
	b	LBB51_20
LBB51_20:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	cbz	x8, LBB51_22
	b	LBB51_21
LBB51_21:
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #110]
	ldr	x9, [x9, #16]
	strh	w8, [x9]
	b	LBB51_22
LBB51_22:
	b	LBB51_23
LBB51_23:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB51_25
	b	LBB51_24
LBB51_24:
	bl	___stack_chk_fail
LBB51_25:
	add	sp, sp, #1232
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_record_arrays
_verify_record_arrays:                  ; @verify_record_arrays
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1200
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x9, sp, #208
	str	x9, [sp, #48]                   ; 8-byte Folded Spill
	mov	x9, x8
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8]
	str	w1, [sp, #204]
	str	x2, [sp, #192]
	str	x3, [sp, #184]
	add	x1, sp, #176
                                        ; kill: def $x9 killed $xzr
	str	xzr, [sp, #176]
	ldr	x0, [x8]
	sub	x8, x29, #228
	bl	_nvm_record_array_admit
	ldur	w8, [x29, #-228]
	cbz	w8, LBB52_2
	b	LBB52_1
LBB52_1:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	sub	x9, x29, #228
	add	x9, x9, #12
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.188@PAGE
	add	x0, x0, l_.str.188@PAGEOFF
	bl	_fail
	b	LBB52_23
LBB52_2:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	bl	_ok_result
	strh	wzr, [sp, #110]
	ldr	x0, [sp, #176]
	add	x1, sp, #112
	bl	_nvm_record_array_execution_counts
	tbz	w0, #0, LBB52_5
	b	LBB52_3
LBB52_3:
	ldr	w8, [sp, #204]
	adds	w8, w8, #1
	b.eq	LBB52_6
	b	LBB52_4
LBB52_4:
	ldr	w8, [sp, #204]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	b.lo	LBB52_6
	b	LBB52_5
LBB52_5:
	add	x8, sp, #731
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.189@PAGE
	add	x0, x0, l_.str.189@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB52_19
LBB52_6:
	str	wzr, [sp, #104]
	b	LBB52_7
LBB52_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #104]
	ldr	w9, [sp, #112]
	subs	w8, w8, w9
	b.hs	LBB52_18
	b	LBB52_8
LBB52_8:                                ;   in Loop: Header=BB52_7 Depth=1
	ldr	x0, [sp, #176]
	ldr	w1, [sp, #104]
	add	x2, sp, #68
	bl	_nvm_record_array_execution_function
	tbnz	w0, #0, LBB52_10
	b	LBB52_9
LBB52_9:
	add	x8, sp, #474
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.190@PAGE
	add	x0, x0, l_.str.190@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB52_18
LBB52_10:                               ;   in Loop: Header=BB52_7 Depth=1
	ldr	x8, [sp, #184]
	cbz	x8, LBB52_14
	b	LBB52_11
LBB52_11:                               ;   in Loop: Header=BB52_7 Depth=1
	ldr	x8, [sp, #184]
	ldr	w9, [sp, #104]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	cbz	w8, LBB52_14
	b	LBB52_12
LBB52_12:                               ;   in Loop: Header=BB52_7 Depth=1
	ldr	x8, [sp, #184]
	ldr	w9, [sp, #104]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #100]
	subs	w8, w8, w9
	b.ge	LBB52_14
	b	LBB52_13
LBB52_13:
	ldr	w8, [sp, #104]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #184]
	ldr	w10, [sp, #104]
                                        ; kill: def $x10 killed $w10
	ldrh	w11, [x9, x10, lsl #1]
	ldrh	w10, [sp, #100]
	mov	x9, sp
	str	x8, [x9]
                                        ; implicit-def: $x8
	mov	x8, x11
	str	x8, [x9, #8]
                                        ; implicit-def: $x8
	mov	x8, x10
	str	x8, [x9, #16]
	add	x8, sp, #217
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	adrp	x0, l_.str.71@PAGE
	add	x0, x0, l_.str.71@PAGEOFF
	bl	_fail
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB52_18
LBB52_14:                               ;   in Loop: Header=BB52_7 Depth=1
	ldr	w8, [sp, #104]
	ldr	w9, [sp, #204]
	subs	w8, w8, w9
	b.ne	LBB52_16
	b	LBB52_15
LBB52_15:                               ;   in Loop: Header=BB52_7 Depth=1
	ldrh	w8, [sp, #100]
	strh	w8, [sp, #110]
	b	LBB52_16
LBB52_16:                               ;   in Loop: Header=BB52_7 Depth=1
	b	LBB52_17
LBB52_17:                               ;   in Loop: Header=BB52_7 Depth=1
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB52_7
LBB52_18:
	b	LBB52_19
LBB52_19:
	ldr	x0, [sp, #176]
	bl	_nvm_record_array_execution_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	tbz	w8, #0, LBB52_22
	b	LBB52_20
LBB52_20:
	ldr	x8, [sp, #192]
	cbz	x8, LBB52_22
	b	LBB52_21
LBB52_21:
	ldrh	w8, [sp, #110]
	ldr	x9, [sp, #192]
	strh	w8, [x9]
	b	LBB52_22
LBB52_22:
	b	LBB52_23
LBB52_23:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB52_25
	b	LBB52_24
LBB52_24:
	bl	___stack_chk_fail
LBB52_25:
	add	sp, sp, #1200
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_functions_with_structure
_verify_functions_with_structure:       ; @verify_functions_with_structure
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #912
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #120]
	str	x1, [sp, #112]
	str	w2, [sp, #108]
	str	x3, [sp, #96]
	add	x2, sp, #95
	strb	wzr, [sp, #95]
	ldr	x0, [sp, #120]
	add	x8, sp, #647
	mov	w9, #0                          ; =0x0
	and	w1, w9, #0x1
	bl	_verify_structure
	ldrb	w8, [sp, #647]
	tbnz	w8, #0, LBB53_2
	b	LBB53_1
LBB53_1:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	add	x1, sp, #647
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB53_27
LBB53_2:
	ldrb	w8, [sp, #95]
	tbnz	w8, #0, LBB53_6
	b	LBB53_3
LBB53_3:
	ldr	x8, [sp, #120]
	ldr	w8, [x8, #272]
	cbz	w8, LBB53_6
	b	LBB53_4
LBB53_4:
	ldr	x8, [sp, #120]
	ldr	w8, [x8, #304]
	cbz	w8, LBB53_6
	b	LBB53_5
LBB53_5:
	ldr	x0, [sp, #120]
	add	x8, sp, #390
	bl	_nvm_verify_owned_module
	ldrb	w8, [sp, #390]
	and	w8, w8, #0x1
	strb	w8, [sp, #95]
	b	LBB53_6
LBB53_6:
	ldrb	w8, [sp, #95]
	tbz	w8, #0, LBB53_9
	b	LBB53_7
LBB53_7:
	ldr	w8, [sp, #108]
	cbz	w8, LBB53_9
	b	LBB53_8
LBB53_8:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.82@PAGE
	add	x0, x0, l_.str.82@PAGEOFF
	bl	_fail
	b	LBB53_27
LBB53_9:
	str	wzr, [sp, #88]
	b	LBB53_10
LBB53_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #88]
	ldr	x9, [sp, #120]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB53_26
	b	LBB53_11
LBB53_11:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	x8, [sp, #96]
	cbz	x8, LBB53_14
	b	LBB53_12
LBB53_12:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	x8, [sp, #96]
	ldr	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	cbnz	w8, LBB53_14
	b	LBB53_13
LBB53_13:                               ;   in Loop: Header=BB53_10 Depth=1
	b	LBB53_25
LBB53_14:                               ;   in Loop: Header=BB53_10 Depth=1
	mov	w8, #256                        ; =0x100
	strh	w8, [sp, #86]
	ldrb	w8, [sp, #95]
	tbnz	w8, #0, LBB53_21
	b	LBB53_15
LBB53_15:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	x8, [sp, #120]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #88]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #112]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	w8, [sp, #108]
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #96]
	cbz	x8, LBB53_17
	b	LBB53_16
LBB53_16:                               ;   in Loop: Header=BB53_10 Depth=1
	add	x8, sp, #86
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB53_18
LBB53_17:                               ;   in Loop: Header=BB53_10 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	b	LBB53_18
LBB53_18:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	w3, [sp, #68]                   ; 4-byte Folded Reload
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #52]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x4, [sp, #32]                   ; 8-byte Folded Reload
	add	x8, sp, #133
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	x6, #0                          ; =0x0
	mov	x5, x6
	bl	_verify_function_body
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	add	x0, sp, #647
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	ldrb	w8, [sp, #647]
	tbnz	w8, #0, LBB53_20
	b	LBB53_19
LBB53_19:
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	add	x1, sp, #647
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB53_27
LBB53_20:                               ;   in Loop: Header=BB53_10 Depth=1
	b	LBB53_21
LBB53_21:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	x8, [sp, #96]
	cbz	x8, LBB53_24
	b	LBB53_22
LBB53_22:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	x8, [sp, #96]
	ldr	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldrh	w9, [sp, #86]
	subs	w8, w8, w9
	b.ge	LBB53_24
	b	LBB53_23
LBB53_23:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [sp, #96]
	ldr	w11, [sp, #88]
                                        ; kill: def $x11 killed $w11
	ldrh	w12, [x10, x11, lsl #1]
	ldrh	w11, [sp, #86]
	mov	x10, sp
	str	x9, [x10]
                                        ; implicit-def: $x9
	mov	x9, x12
	str	x9, [x10, #8]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #16]
	adrp	x0, l_.str.71@PAGE
	add	x0, x0, l_.str.71@PAGEOFF
	bl	_fail
	b	LBB53_27
LBB53_24:                               ;   in Loop: Header=BB53_10 Depth=1
	b	LBB53_25
LBB53_25:                               ;   in Loop: Header=BB53_10 Depth=1
	ldr	w8, [sp, #88]
	add	w8, w8, #1
	str	w8, [sp, #88]
	b	LBB53_10
LBB53_26:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB53_27
LBB53_27:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB53_29
	b	LBB53_28
LBB53_28:
	bl	___stack_chk_fail
LBB53_29:
	add	sp, sp, #912
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify                     ; -- Begin function nvm_verify
	.p2align	2
_nvm_verify:                            ; @nvm_verify
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp]                        ; 8-byte Folded Spill
	str	x0, [sp, #8]
	ldr	x0, [sp, #8]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB54_2
	b	LBB54_1
LBB54_1:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	adrp	x0, l_.str.70@PAGE
	add	x0, x0, l_.str.70@PAGEOFF
	bl	_fail
	b	LBB54_11
LBB54_2:
	ldr	x0, [sp, #8]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB54_4
	b	LBB54_3
LBB54_3:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #8]
	mov	w1, #-1                         ; =0xffffffff
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_verify_record_maps
	b	LBB54_11
LBB54_4:
	ldr	x0, [sp, #8]
	bl	_nvm_owned_array_route
	cbz	w0, LBB54_6
	b	LBB54_5
LBB54_5:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	bl	_verify_owned_arrays
	b	LBB54_11
LBB54_6:
	ldr	x0, [sp, #8]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB54_8
	b	LBB54_7
LBB54_7:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #8]
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	bl	_verify_mixed_samples
	b	LBB54_11
LBB54_8:
	ldr	x0, [sp, #8]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB54_10
	b	LBB54_9
LBB54_9:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #8]
	mov	w1, #-1                         ; =0xffffffff
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_verify_record_arrays
	b	LBB54_11
LBB54_10:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #8]
	mov	x3, #0                          ; =0x0
	mov	x1, x3
	mov	w2, #0                          ; =0x0
	bl	_verify_functions_with_structure
	b	LBB54_11
LBB54_11:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_owned_arrays
_verify_owned_arrays:                   ; @verify_owned_arrays
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x9, x29, #56
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	mov	x3, x8
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x3, [sp, #40]                   ; 8-byte Folded Spill
	str	x0, [x8, #48]
	str	w1, [x8, #44]
	str	x2, [x8, #32]
	sub	x1, x29, #32
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	ldr	x0, [x8, #48]
	sub	x8, x29, #56
	bl	_nvm_owned_array_admit
	ldur	w8, [x29, #-56]
	cbz	w8, LBB55_2
	b	LBB55_1
LBB55_1:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w10, [x29, #-56]
	mov	x13, x10
	ldur	w10, [x29, #-52]
	mov	x12, x10
	ldur	w10, [x29, #-48]
	mov	x11, x10
	ldr	x9, [x9, #16]
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.191@PAGE
	add	x0, x0, l_.str.191@PAGEOFF
	bl	_fail
	b	LBB55_7
LBB55_2:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	ldr	w1, [x8, #44]
	add	x2, sp, #52
	bl	_nvm_owned_array_plan_signature
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	w0, [sp, #51]
	ldr	x0, [x8, #24]
	bl	_nvm_owned_array_plan_free
	ldrb	w8, [sp, #51]
	tbnz	w8, #0, LBB55_4
	b	LBB55_3
LBB55_3:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.192@PAGE
	add	x0, x0, l_.str.192@PAGEOFF
	bl	_fail
	b	LBB55_7
LBB55_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #32]
	cbz	x8, LBB55_6
	b	LBB55_5
LBB55_5:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #56]
	ldr	x9, [x9, #32]
	strh	w8, [x9]
	b	LBB55_6
LBB55_6:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB55_7
LBB55_7:
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_mixed_samples
_verify_mixed_samples:                  ; @verify_mixed_samples
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	stur	x2, [x29, #-24]
	sub	x1, x29, #32
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	ldur	x0, [x29, #-8]
	add	x8, sp, #56
	bl	_nvm_mixed_samples_admit
	ldr	w8, [sp, #56]
	cbz	w8, LBB56_2
	b	LBB56_1
LBB56_1:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #56]
	mov	x13, x9
	ldr	w9, [sp, #60]
	mov	x12, x9
	ldr	w9, [sp, #64]
	mov	x11, x9
	ldr	x9, [sp, #72]
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.193@PAGE
	add	x0, x0, l_.str.193@PAGEOFF
	bl	_fail
	b	LBB56_7
LBB56_2:
	ldur	w8, [x29, #-12]
	ldur	x9, [x29, #-32]
	mov	x10, #25544                     ; =0x63c8
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.lo	LBB56_4
	b	LBB56_3
LBB56_3:
	ldur	x0, [x29, #-32]
	bl	_nvm_mixed_samples_plan_free
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.194@PAGE
	add	x0, x0, l_.str.194@PAGEOFF
	bl	_fail
	b	LBB56_7
LBB56_4:
	ldur	x8, [x29, #-32]
	add	x10, x8, #8
	ldur	w8, [x29, #-12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #120                        ; =0x78
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #4]
	strh	w8, [sp, #54]
	ldur	x0, [x29, #-32]
	bl	_nvm_mixed_samples_plan_free
	ldur	x8, [x29, #-24]
	cbz	x8, LBB56_6
	b	LBB56_5
LBB56_5:
	ldrh	w8, [sp, #54]
	ldur	x9, [x29, #-24]
	strh	w8, [x9]
	b	LBB56_6
LBB56_6:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB56_7
LBB56_7:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify_linked              ; -- Begin function nvm_verify_linked
	.p2align	2
_nvm_verify_linked:                     ; @nvm_verify_linked
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	w8, [x29, #-20]
	subs	w8, w8, #0
	b.ls	LBB57_3
	b	LBB57_1
LBB57_1:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB57_3
	b	LBB57_2
LBB57_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.72@PAGE
	add	x0, x0, l_.str.72@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_3:
	stur	wzr, [x29, #-24]
	b	LBB57_4
LBB57_4:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-24]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_9
	b	LBB57_5
LBB57_5:                                ;   in Loop: Header=BB57_4 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB57_7
	b	LBB57_6
LBB57_6:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.73@PAGE
	add	x0, x0, l_.str.73@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_7:                                ;   in Loop: Header=BB57_4 Depth=1
	b	LBB57_8
LBB57_8:                                ;   in Loop: Header=BB57_4 Depth=1
	ldur	w8, [x29, #-24]
	add	w8, w8, #1
	stur	w8, [x29, #-24]
	b	LBB57_4
LBB57_9:
	ldur	x0, [x29, #-8]
	bl	_nvm_service_execution_pending
	tbz	w0, #0, LBB57_11
	b	LBB57_10
LBB57_10:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.70@PAGE
	add	x0, x0, l_.str.70@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_11:
	stur	wzr, [x29, #-28]
	b	LBB57_12
LBB57_12:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-28]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_17
	b	LBB57_13
LBB57_13:                               ;   in Loop: Header=BB57_12 Depth=1
	ldur	x8, [x29, #-16]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB57_15
	b	LBB57_14
LBB57_14:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.74@PAGE
	add	x0, x0, l_.str.74@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_15:                               ;   in Loop: Header=BB57_12 Depth=1
	b	LBB57_16
LBB57_16:                               ;   in Loop: Header=BB57_12 Depth=1
	ldur	w8, [x29, #-28]
	add	w8, w8, #1
	stur	w8, [x29, #-28]
	b	LBB57_12
LBB57_17:
	ldur	x0, [x29, #-8]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB57_21
	b	LBB57_18
LBB57_18:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB57_20
	b	LBB57_19
LBB57_19:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.75@PAGE
	add	x0, x0, l_.str.75@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_20:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	mov	w1, #-1                         ; =0xffffffff
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_verify_record_maps
	b	LBB57_68
LBB57_21:
	str	wzr, [sp, #32]
	b	LBB57_22
LBB57_22:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #32]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_27
	b	LBB57_23
LBB57_23:                               ;   in Loop: Header=BB57_22 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #32]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_owned_array_route
	cbz	w0, LBB57_25
	b	LBB57_24
LBB57_24:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.76@PAGE
	add	x0, x0, l_.str.76@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_25:                               ;   in Loop: Header=BB57_22 Depth=1
	b	LBB57_26
LBB57_26:                               ;   in Loop: Header=BB57_22 Depth=1
	ldr	w8, [sp, #32]
	add	w8, w8, #1
	str	w8, [sp, #32]
	b	LBB57_22
LBB57_27:
	ldur	x0, [x29, #-8]
	bl	_nvm_owned_array_route
	cbz	w0, LBB57_31
	b	LBB57_28
LBB57_28:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB57_30
	b	LBB57_29
LBB57_29:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.77@PAGE
	add	x0, x0, l_.str.77@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_30:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	bl	_verify_owned_arrays
	b	LBB57_68
LBB57_31:
	ldur	x0, [x29, #-8]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB57_35
	b	LBB57_32
LBB57_32:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB57_34
	b	LBB57_33
LBB57_33:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.78@PAGE
	add	x0, x0, l_.str.78@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_34:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	bl	_verify_mixed_samples
	b	LBB57_68
LBB57_35:
	str	wzr, [sp, #28]
	b	LBB57_36
LBB57_36:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_41
	b	LBB57_37
LBB57_37:                               ;   in Loop: Header=BB57_36 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #28]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB57_39
	b	LBB57_38
LBB57_38:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.79@PAGE
	add	x0, x0, l_.str.79@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_39:                               ;   in Loop: Header=BB57_36 Depth=1
	b	LBB57_40
LBB57_40:                               ;   in Loop: Header=BB57_36 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB57_36
LBB57_41:
	ldur	x0, [x29, #-8]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB57_45
	b	LBB57_42
LBB57_42:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB57_44
	b	LBB57_43
LBB57_43:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.80@PAGE
	add	x0, x0, l_.str.80@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_44:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	mov	w1, #-1                         ; =0xffffffff
	mov	x3, #0                          ; =0x0
	mov	x2, x3
	bl	_verify_record_arrays
	b	LBB57_68
LBB57_45:
	ldur	w8, [x29, #-20]
	cbz	w8, LBB57_67
	b	LBB57_46
LBB57_46:
	str	wzr, [sp, #24]
	b	LBB57_47
LBB57_47:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #24]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_52
	b	LBB57_48
LBB57_48:                               ;   in Loop: Header=BB57_47 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB57_50
	b	LBB57_49
LBB57_49:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.81@PAGE
	add	x0, x0, l_.str.81@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_50:                               ;   in Loop: Header=BB57_47 Depth=1
	b	LBB57_51
LBB57_51:                               ;   in Loop: Header=BB57_47 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB57_47
LBB57_52:
	strb	wzr, [sp, #23]
	ldur	x8, [x29, #-8]
	cbz	x8, LBB57_57
	b	LBB57_53
LBB57_53:
	ldur	x0, [x29, #-8]
	add	x1, sp, #23
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB57_55
	b	LBB57_54
LBB57_54:
	ldrb	w8, [sp, #23]
	tbnz	w8, #0, LBB57_56
	b	LBB57_55
LBB57_55:
	ldur	x0, [x29, #-8]
	bl	_nvm_uses_owned_transfers
	tbz	w0, #0, LBB57_57
	b	LBB57_56
LBB57_56:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.82@PAGE
	add	x0, x0, l_.str.82@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_57:
	str	wzr, [sp, #16]
	b	LBB57_58
LBB57_58:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #16]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hs	LBB57_66
	b	LBB57_59
LBB57_59:                               ;   in Loop: Header=BB57_58 Depth=1
	strb	wzr, [sp, #23]
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB57_64
	b	LBB57_60
LBB57_60:                               ;   in Loop: Header=BB57_58 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	add	x1, sp, #23
	bl	_nvm_ownership_contracts_validate
	cbnz	w0, LBB57_62
	b	LBB57_61
LBB57_61:                               ;   in Loop: Header=BB57_58 Depth=1
	ldrb	w8, [sp, #23]
	tbnz	w8, #0, LBB57_63
	b	LBB57_62
LBB57_62:                               ;   in Loop: Header=BB57_58 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w9, [sp, #16]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_nvm_uses_owned_transfers
	tbz	w0, #0, LBB57_64
	b	LBB57_63
LBB57_63:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	adrp	x0, l_.str.82@PAGE
	add	x0, x0, l_.str.82@PAGEOFF
	bl	_fail
	b	LBB57_68
LBB57_64:                               ;   in Loop: Header=BB57_58 Depth=1
	b	LBB57_65
LBB57_65:                               ;   in Loop: Header=BB57_58 Depth=1
	ldr	w8, [sp, #16]
	add	w8, w8, #1
	str	w8, [sp, #16]
	b	LBB57_58
LBB57_66:
	b	LBB57_67
LBB57_67:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x0, [x29, #-8]
	ldur	x1, [x29, #-16]
	ldur	w2, [x29, #-20]
	mov	x3, #0                          ; =0x0
	bl	_verify_functions_with_structure
	b	LBB57_68
LBB57_68:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_verify_profile             ; -- Begin function nvm_verify_profile
	.p2align	2
_nvm_verify_profile:                    ; @nvm_verify_profile
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #736
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #256]
	str	w1, [sp, #252]
	ldr	w8, [sp, #252]
	cbz	w8, LBB58_7
	b	LBB58_1
LBB58_1:
	ldr	w8, [sp, #252]
	subs	w8, w8, #1
	b.eq	LBB58_7
	b	LBB58_2
LBB58_2:
	ldr	w8, [sp, #252]
	subs	w8, w8, #2
	b.eq	LBB58_7
	b	LBB58_3
LBB58_3:
	ldr	w8, [sp, #252]
	subs	w8, w8, #3
	b.eq	LBB58_7
	b	LBB58_4
LBB58_4:
	ldr	w8, [sp, #252]
	subs	w8, w8, #4
	b.eq	LBB58_7
	b	LBB58_5
LBB58_5:
	ldr	w8, [sp, #252]
	subs	w8, w8, #5
	b.eq	LBB58_7
	b	LBB58_6
LBB58_6:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #252]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.83@PAGE
	add	x0, x0, l_.str.83@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_7:
	ldr	x0, [sp, #256]
	add	x8, sp, #471
	bl	_nvm_verify
	ldrb	w8, [sp, #471]
	tbz	w8, #0, LBB58_9
	b	LBB58_8
LBB58_8:
	ldr	w8, [sp, #252]
	cbnz	w8, LBB58_10
	b	LBB58_9
LBB58_9:
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	add	x1, sp, #471
	mov	x2, #257                        ; =0x101
	bl	_memcpy
	b	LBB58_181
LBB58_10:
	ldr	x0, [sp, #256]
	bl	_nvm_owned_array_route
	cbz	w0, LBB58_12
	b	LBB58_11
LBB58_11:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.84@PAGE
	add	x0, x0, l_.str.84@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_12:
	ldr	x0, [sp, #256]
	bl	_nvm_mixed_samples_candidate
	tbz	w0, #0, LBB58_14
	b	LBB58_13
LBB58_13:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.85@PAGE
	add	x0, x0, l_.str.85@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_14:
	ldr	x0, [sp, #256]
	bl	_nvm_record_map_route
	bl	_nvm_record_map_selected
	tbz	w0, #0, LBB58_16
	b	LBB58_15
LBB58_15:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.86@PAGE
	add	x0, x0, l_.str.86@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_16:
	ldr	x0, [sp, #256]
	bl	_nvm_record_array_candidate
	tbz	w0, #0, LBB58_18
	b	LBB58_17
LBB58_17:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.87@PAGE
	add	x0, x0, l_.str.87@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_18:
	ldr	w8, [sp, #252]
	subs	w8, w8, #5
	cset	w8, eq
	strb	w8, [sp, #251]
	ldr	w9, [sp, #252]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
	b.eq	LBB58_20
	b	LBB58_19
LBB58_19:
	ldrb	w8, [sp, #251]
	str	w8, [sp, #116]                  ; 4-byte Folded Spill
	b	LBB58_20
LBB58_20:
	ldr	w8, [sp, #116]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #250]
	ldrb	w8, [sp, #250]
	tbz	w8, #0, LBB58_33
	b	LBB58_21
LBB58_21:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #432]
	cbz	w8, LBB58_23
	b	LBB58_22
LBB58_22:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #424]
	cbz	w8, LBB58_24
	b	LBB58_23
LBB58_23:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.88@PAGE
	add	x0, x0, l_.str.88@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_24:
	str	wzr, [sp, #244]
	b	LBB58_25
LBB58_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #244]
	ldr	x9, [sp, #256]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB58_32
	b	LBB58_26
LBB58_26:                               ;   in Loop: Header=BB58_25 Depth=1
	ldrb	w8, [sp, #251]
	tbz	w8, #0, LBB58_28
	b	LBB58_27
LBB58_27:                               ;   in Loop: Header=BB58_25 Depth=1
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #244]
	bl	_nvm_portable_file_read_import
	cbnz	w0, LBB58_30
	b	LBB58_29
LBB58_28:                               ;   in Loop: Header=BB58_25 Depth=1
	ldr	x0, [sp, #256]
	ldr	w1, [sp, #244]
	bl	_nvm_portable_read_import_exact
	tbnz	w0, #0, LBB58_30
	b	LBB58_29
LBB58_29:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #244]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.89@PAGE
	add	x0, x0, l_.str.89@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_30:                               ;   in Loop: Header=BB58_25 Depth=1
	b	LBB58_31
LBB58_31:                               ;   in Loop: Header=BB58_25 Depth=1
	ldr	w8, [sp, #244]
	add	w8, w8, #1
	str	w8, [sp, #244]
	b	LBB58_25
LBB58_32:
	b	LBB58_33
LBB58_33:
	ldr	w9, [sp, #252]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #3
	str	w8, [sp, #112]                  ; 4-byte Folded Spill
	b.ne	LBB58_38
	b	LBB58_34
LBB58_34:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #468]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #108]                  ; 4-byte Folded Spill
	cbnz	w8, LBB58_37
	b	LBB58_35
LBB58_35:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #108]                  ; 4-byte Folded Spill
	cbnz	w8, LBB58_37
	b	LBB58_36
LBB58_36:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #108]                  ; 4-byte Folded Spill
	b	LBB58_37
LBB58_37:
	ldr	w8, [sp, #108]                  ; 4-byte Folded Reload
	str	w8, [sp, #112]                  ; 4-byte Folded Spill
	b	LBB58_38
LBB58_38:
	ldr	w8, [sp, #112]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #243]
	ldrb	w8, [sp, #250]
	tbnz	w8, #0, LBB58_40
	b	LBB58_39
LBB58_39:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #432]
	cbnz	w8, LBB58_47
	b	LBB58_40
LBB58_40:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #448]
	cbnz	w8, LBB58_47
	b	LBB58_41
LBB58_41:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #476]
	cbnz	w8, LBB58_47
	b	LBB58_42
LBB58_42:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #352]
	cbnz	w8, LBB58_47
	b	LBB58_43
LBB58_43:
	ldrb	w8, [sp, #243]
	tbnz	w8, #0, LBB58_48
	b	LBB58_44
LBB58_44:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #468]
	cbnz	w8, LBB58_47
	b	LBB58_45
LBB58_45:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #304]
	cbnz	w8, LBB58_47
	b	LBB58_46
LBB58_46:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #320]
	cbz	w8, LBB58_48
	b	LBB58_47
LBB58_47:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.90@PAGE
	add	x0, x0, l_.str.90@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_48:
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #8]
	tbnz	w8, #0, LBB58_50
	b	LBB58_49
LBB58_49:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.91@PAGE
	add	x0, x0, l_.str.91@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_50:
	ldr	x8, [sp, #256]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.ne	LBB58_53
	b	LBB58_51
LBB58_51:
	ldr	x8, [sp, #256]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #20]
	subs	w8, w8, #1
	b.eq	LBB58_54
	b	LBB58_52
LBB58_52:
	ldr	x8, [sp, #256]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #20]
	subs	w8, w8, #4
	b.eq	LBB58_54
	b	LBB58_53
LBB58_53:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.92@PAGE
	add	x0, x0, l_.str.92@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_54:
	ldr	x8, [sp, #256]
	ldr	x10, [x8, #256]
	ldr	x8, [sp, #256]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #4]
	cbz	w8, LBB58_56
	b	LBB58_55
LBB58_55:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.93@PAGE
	add	x0, x0, l_.str.93@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_56:
	ldr	w9, [sp, #252]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #104]                  ; 4-byte Folded Spill
	b.eq	LBB58_58
	b	LBB58_57
LBB58_57:
	ldrb	w8, [sp, #250]
	str	w8, [sp, #104]                  ; 4-byte Folded Spill
	b	LBB58_58
LBB58_58:
	ldr	w8, [sp, #104]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #242]
	ldr	w9, [sp, #252]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #100]                  ; 4-byte Folded Spill
	b.eq	LBB58_60
	b	LBB58_59
LBB58_59:
	ldrb	w8, [sp, #242]
	str	w8, [sp, #100]                  ; 4-byte Folded Spill
	b	LBB58_60
LBB58_60:
	ldr	w8, [sp, #100]                  ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #241]
	strb	wzr, [sp, #240]
	ldrb	w8, [sp, #251]
	and	w8, w8, #0x1
	strb	w8, [sp, #239]
	strb	wzr, [sp, #238]
	strb	wzr, [sp, #237]
	str	wzr, [sp, #232]
	b	LBB58_61
LBB58_61:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB58_87 Depth 2
                                        ;     Child Loop BB58_104 Depth 2
	ldr	w8, [sp, #232]
	ldr	x9, [sp, #256]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB58_169
	b	LBB58_62
LBB58_62:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #256]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #232]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #224]
	ldr	x0, [sp, #256]
	ldr	x8, [sp, #224]
	ldr	w1, [x8]
	bl	_nvm_get_string
	str	x0, [sp, #216]
	ldrb	w8, [sp, #237]
	tbnz	w8, #0, LBB58_68
	b	LBB58_63
LBB58_63:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #216]
	cbz	x8, LBB58_68
	b	LBB58_64
LBB58_64:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x0, [sp, #216]
	adrp	x1, l_.str.10@PAGE
	add	x1, x1, l_.str.10@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB58_68
	b	LBB58_65
LBB58_65:                               ;   in Loop: Header=BB58_61 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #237]
	ldr	x8, [sp, #224]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB58_67
	b	LBB58_66
LBB58_66:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.94@PAGE
	add	x0, x0, l_.str.94@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_67:                               ;   in Loop: Header=BB58_61 Depth=1
	b	LBB58_68
LBB58_68:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrh	w8, [x8, #18]
	cbnz	w8, LBB58_83
	b	LBB58_69
LBB58_69:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #21]
	cbnz	w8, LBB58_71
	b	LBB58_70
LBB58_70:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	cbz	w8, LBB58_84
	b	LBB58_71
LBB58_71:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.ne	LBB58_83
	b	LBB58_72
LBB58_72:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #1
	b.eq	LBB58_84
	b	LBB58_73
LBB58_73:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #2
	b.eq	LBB58_84
	b	LBB58_74
LBB58_74:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #9
	b.eq	LBB58_84
	b	LBB58_75
LBB58_75:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #4
	b.eq	LBB58_84
	b	LBB58_76
LBB58_76:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #3
	b.eq	LBB58_84
	b	LBB58_77
LBB58_77:                               ;   in Loop: Header=BB58_61 Depth=1
	ldrb	w8, [sp, #241]
	tbz	w8, #0, LBB58_79
	b	LBB58_78
LBB58_78:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #5
	b.eq	LBB58_84
	b	LBB58_79
LBB58_79:                               ;   in Loop: Header=BB58_61 Depth=1
	ldrb	w8, [sp, #242]
	tbz	w8, #0, LBB58_81
	b	LBB58_80
LBB58_80:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #7
	b.eq	LBB58_84
	b	LBB58_81
LBB58_81:                               ;   in Loop: Header=BB58_61 Depth=1
	ldrb	w8, [sp, #243]
	tbz	w8, #0, LBB58_83
	b	LBB58_82
LBB58_82:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #8
	b.eq	LBB58_84
	b	LBB58_83
LBB58_83:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #232]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.95@PAGE
	add	x0, x0, l_.str.95@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_84:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #21]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #96]                   ; 4-byte Folded Spill
	cbz	w8, LBB58_86
	b	LBB58_85
LBB58_85:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	x8, [sp, #224]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp, #96]                   ; 4-byte Folded Spill
	b	LBB58_86
LBB58_86:                               ;   in Loop: Header=BB58_61 Depth=1
	ldr	w8, [sp, #96]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldrb	w8, [sp, #240]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #240]
	strh	wzr, [sp, #214]
	b	LBB58_87
LBB58_87:                               ;   Parent Loop BB58_61 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #214]
	ldr	x9, [sp, #224]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB58_103
	b	LBB58_88
LBB58_88:                               ;   in Loop: Header=BB58_87 Depth=2
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #264]
	cbz	x8, LBB58_90
	b	LBB58_89
LBB58_89:                               ;   in Loop: Header=BB58_87 Depth=2
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #232]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB58_93
	b	LBB58_90
LBB58_90:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #250]
	tbz	w8, #0, LBB58_92
	b	LBB58_91
LBB58_91:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.96@PAGE
	add	x0, x0, l_.str.96@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_92:                               ;   in Loop: Header=BB58_87 Depth=2
	b	LBB58_102
LBB58_93:                               ;   in Loop: Header=BB58_87 Depth=2
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #264]
	ldr	w9, [sp, #232]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrh	w9, [sp, #214]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	strb	w8, [sp, #213]
	ldrb	w8, [sp, #213]
	subs	w8, w8, #5
	cset	w9, eq
	ldrb	w8, [sp, #240]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #240]
	ldrb	w0, [sp, #213]
	bl	_profile_scalar
	cbnz	w0, LBB58_101
	b	LBB58_94
LBB58_94:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #241]
	tbz	w8, #0, LBB58_96
	b	LBB58_95
LBB58_95:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #213]
	subs	w8, w8, #5
	b.eq	LBB58_101
	b	LBB58_96
LBB58_96:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #242]
	tbz	w8, #0, LBB58_98
	b	LBB58_97
LBB58_97:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #213]
	subs	w8, w8, #7
	b.eq	LBB58_101
	b	LBB58_98
LBB58_98:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #243]
	tbz	w8, #0, LBB58_100
	b	LBB58_99
LBB58_99:                               ;   in Loop: Header=BB58_87 Depth=2
	ldrb	w8, [sp, #213]
	subs	w8, w8, #8
	b.eq	LBB58_101
	b	LBB58_100
LBB58_100:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #232]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.97@PAGE
	add	x0, x0, l_.str.97@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_101:                              ;   in Loop: Header=BB58_87 Depth=2
	b	LBB58_102
LBB58_102:                              ;   in Loop: Header=BB58_87 Depth=2
	ldrh	w8, [sp, #214]
	add	w8, w8, #1
	strh	w8, [sp, #214]
	b	LBB58_87
LBB58_103:                              ;   in Loop: Header=BB58_61 Depth=1
	str	wzr, [sp, #208]
	b	LBB58_104
LBB58_104:                              ;   Parent Loop BB58_61 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #208]
	ldr	x9, [sp, #224]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB58_167
	b	LBB58_105
LBB58_105:                              ;   in Loop: Header=BB58_104 Depth=2
	add	x0, sp, #144
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #256]
	ldr	x8, [x8, #280]
	ldr	x9, [sp, #224]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #208]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #224]
	ldr	w8, [x8, #12]
	ldr	w9, [sp, #208]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	bl	_isa_decode
	str	w0, [sp, #140]
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #80
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b.eq	LBB58_111
	b	LBB58_106
LBB58_106:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #81
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b.eq	LBB58_111
	b	LBB58_107
LBB58_107:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #84
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b.eq	LBB58_111
	b	LBB58_108
LBB58_108:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #82
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b.eq	LBB58_111
	b	LBB58_109
LBB58_109:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #88
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b.eq	LBB58_111
	b	LBB58_110
LBB58_110:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #86
	cset	w8, eq
	str	w8, [sp, #92]                   ; 4-byte Folded Spill
	b	LBB58_111
LBB58_111:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #92]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldrb	w8, [sp, #239]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #239]
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	b.eq	LBB58_115
	b	LBB58_112
LBB58_112:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #65
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	b.eq	LBB58_115
	b	LBB58_113
LBB58_113:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #66
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	b.eq	LBB58_115
	b	LBB58_114
LBB58_114:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #139
	cset	w8, eq
	str	w8, [sp, #76]                   ; 4-byte Folded Spill
	b	LBB58_115
LBB58_115:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #76]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldrb	w8, [sp, #240]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #240]
	ldrb	w8, [sp, #242]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #72]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB58_120
	b	LBB58_116
LBB58_116:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #32
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b.eq	LBB58_119
	b	LBB58_117
LBB58_117:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #136
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b.eq	LBB58_119
	b	LBB58_118
LBB58_118:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #137
	cset	w8, eq
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	b	LBB58_119
LBB58_119:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #68]                   ; 4-byte Folded Reload
	str	w8, [sp, #72]                   ; 4-byte Folded Spill
	b	LBB58_120
LBB58_120:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldrb	w8, [sp, #238]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #238]
	ldrb	w8, [sp, #241]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #64]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB58_150
	b	LBB58_121
LBB58_121:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b.eq	LBB58_149
	b	LBB58_122
LBB58_122:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #64
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b.eq	LBB58_149
	b	LBB58_123
LBB58_123:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #68
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b.eq	LBB58_149
	b	LBB58_124
LBB58_124:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #242]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #56]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB58_148
	b	LBB58_125
LBB58_125:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #88
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_126
LBB58_126:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #86
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_127
LBB58_127:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #80
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_128
LBB58_128:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #81
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_129
LBB58_129:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #84
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_130
LBB58_130:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #82
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_131
LBB58_131:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #77
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_132
LBB58_132:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #83
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_133
LBB58_133:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #85
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_134
LBB58_134:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #78
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_135
LBB58_135:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #70
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_136
LBB58_136:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #71
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_137
LBB58_137:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #73
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_138
LBB58_138:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #74
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_139
LBB58_139:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #69
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_140
LBB58_140:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #72
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_141
LBB58_141:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #65
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_142
LBB58_142:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #66
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_143
LBB58_143:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #139
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_144
LBB58_144:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #67
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_145
LBB58_145:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #75
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b.eq	LBB58_147
	b	LBB58_146
LBB58_146:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #76
	cset	w8, eq
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	b	LBB58_147
LBB58_147:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	str	w8, [sp, #56]                   ; 4-byte Folded Spill
	b	LBB58_148
LBB58_148:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #56]                   ; 4-byte Folded Reload
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	b	LBB58_149
LBB58_149:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	str	w8, [sp, #64]                   ; 4-byte Folded Spill
	b	LBB58_150
LBB58_150:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #64]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	strb	w8, [sp, #139]
	ldrb	w8, [sp, #243]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #48]                   ; 4-byte Folded Spill
	tbz	w8, #0, LBB58_159
	b	LBB58_151
LBB58_151:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #96
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_152
LBB58_152:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #99
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_153
LBB58_153:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #97
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_154
LBB58_154:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #98
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_155
LBB58_155:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #251
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_156
LBB58_156:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w9, [sp, #144]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #252
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB58_158
	b	LBB58_157
LBB58_157:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #253
	cset	w8, eq
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB58_158
LBB58_158:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB58_159
LBB58_159:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #138]
	ldr	w8, [sp, #140]
	cbz	w8, LBB58_165
	b	LBB58_160
LBB58_160:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w0, [sp, #144]
	bl	_profile_supported
	cbnz	w0, LBB58_166
	b	LBB58_161
LBB58_161:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #139]
	tbnz	w8, #0, LBB58_166
	b	LBB58_162
LBB58_162:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #138]
	tbnz	w8, #0, LBB58_166
	b	LBB58_163
LBB58_163:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #250]
	tbz	w8, #0, LBB58_165
	b	LBB58_164
LBB58_164:                              ;   in Loop: Header=BB58_104 Depth=2
	ldrb	w8, [sp, #144]
	subs	w8, w8, #62
	b.eq	LBB58_166
	b	LBB58_165
LBB58_165:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldrb	w13, [sp, #144]
	ldr	w9, [sp, #232]
	mov	x11, x9
	ldr	w9, [sp, #208]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
                                        ; implicit-def: $x12
	mov	x12, x13
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.98@PAGE
	add	x0, x0, l_.str.98@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_166:                              ;   in Loop: Header=BB58_104 Depth=2
	ldr	w9, [sp, #140]
	ldr	w8, [sp, #208]
	add	w8, w8, w9
	str	w8, [sp, #208]
	b	LBB58_104
LBB58_167:                              ;   in Loop: Header=BB58_61 Depth=1
	b	LBB58_168
LBB58_168:                              ;   in Loop: Header=BB58_61 Depth=1
	ldr	w8, [sp, #232]
	add	w8, w8, #1
	str	w8, [sp, #232]
	b	LBB58_61
LBB58_169:
	ldrb	w8, [sp, #239]
	tbnz	w8, #0, LBB58_171
	b	LBB58_170
LBB58_170:
	ldrb	w8, [sp, #243]
	tbz	w8, #0, LBB58_177
	b	LBB58_171
LBB58_171:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #128]
	ldrb	w8, [sp, #251]
	tbz	w8, #0, LBB58_173
	b	LBB58_172
LBB58_172:
	ldr	x0, [sp, #256]
	add	x8, sp, #264
	add	x1, sp, #128
	bl	_nvm_select_portable_read_heap
	b	LBB58_174
LBB58_173:
	ldr	x0, [sp, #256]
	ldrb	w8, [sp, #239]
	and	w1, w8, #0x1
	add	x8, sp, #264
	add	x2, sp, #128
	bl	_nvm_select_managed_heap
	b	LBB58_174
LBB58_174:
	ldr	x0, [sp, #128]
	bl	_nvm_managed_heap_plan_free
	ldr	w8, [sp, #264]
	cbz	w8, LBB58_176
	b	LBB58_175
LBB58_175:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	add	x9, sp, #264
	ldr	w10, [sp, #264]
	mov	x13, x10
	ldr	w10, [sp, #268]
	mov	x12, x10
	ldr	w10, [sp, #272]
	mov	x11, x10
	add	x9, x9, #12
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.99@PAGE
	add	x0, x0, l_.str.99@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_176:
	b	LBB58_177
LBB58_177:
	ldrb	w8, [sp, #240]
	tbz	w8, #0, LBB58_180
	b	LBB58_178
LBB58_178:
	ldrb	w8, [sp, #238]
	tbz	w8, #0, LBB58_180
	b	LBB58_179
LBB58_179:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	adrp	x0, l_.str.100@PAGE
	add	x0, x0, l_.str.100@PAGEOFF
	bl	_fail
	b	LBB58_181
LBB58_180:
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB58_181
LBB58_181:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB58_183
	b	LBB58_182
LBB58_182:
	bl	___stack_chk_fail
LBB58_183:
	add	sp, sp, #736
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_portable_file_read_import
_nvm_portable_file_read_import:         ; @nvm_portable_file_read_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB59_6
	b	LBB59_1
LBB59_1:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #432]
	subs	w8, w8, w9
	b.hs	LBB59_6
	b	LBB59_2
LBB59_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #400]
	cbz	x8, LBB59_6
	b	LBB59_3
LBB59_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	cbz	x8, LBB59_6
	b	LBB59_4
LBB59_4:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	cbz	x8, LBB59_6
	b	LBB59_5
LBB59_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	cbnz	x8, LBB59_7
	b	LBB59_6
LBB59_6:
	stur	wzr, [x29, #-4]
	b	LBB59_33
LBB59_7:
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #400]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB59_16
	b	LBB59_8
LBB59_8:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB59_16
	b	LBB59_9
LBB59_9:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #11]
	cbnz	w8, LBB59_16
	b	LBB59_10
LBB59_10:
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #1
	b.ne	LBB59_16
	b	LBB59_11
LBB59_11:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #5
	b.eq	LBB59_13
	b	LBB59_12
LBB59_12:
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #7
	b.ne	LBB59_16
	b	LBB59_13
LBB59_13:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB59_16
	b	LBB59_14
LBB59_14:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #408]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8]
	subs	w8, w8, #5
	b.ne	LBB59_16
	b	LBB59_15
LBB59_15:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #32]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB59_17
	b	LBB59_16
LBB59_16:
	stur	wzr, [x29, #-4]
	b	LBB59_33
LBB59_17:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #232]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	cbnz	x8, LBB59_19
	b	LBB59_18
LBB59_18:
	stur	wzr, [x29, #-4]
	b	LBB59_33
LBB59_19:
	str	xzr, [sp, #16]
	b	LBB59_20
LBB59_20:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	subs	x8, x8, #3
	b.hs	LBB59_32
	b	LBB59_21
LBB59_21:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x9, [sp, #16]
	adrp	x8, _nvm_portable_file_read_import.names@PAGE
	add	x8, x8, _nvm_portable_file_read_import.names@PAGEOFF
	ldr	x0, [x8, x9, lsl #3]
	bl	_strlen
	str	x0, [sp, #8]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #5
	b.ne	LBB59_25
	b	LBB59_22
LBB59_22:                               ;   in Loop: Header=BB59_20 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB59_25
	b	LBB59_23
LBB59_23:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x0, [sp, #24]
	ldr	x9, [sp, #16]
	adrp	x8, _nvm_portable_file_read_import.names@PAGE
	add	x8, x8, _nvm_portable_file_read_import.names@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp, #8]
	bl	_memcmp
	cbnz	w0, LBB59_25
	b	LBB59_24
LBB59_24:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB59_33
LBB59_25:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #7
	b.ne	LBB59_30
	b	LBB59_26
LBB59_26:                               ;   in Loop: Header=BB59_20 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #240]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #8]
	add	x9, x9, #6
	subs	x8, x8, x9
	b.ne	LBB59_30
	b	LBB59_27
LBB59_27:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x0, [sp, #24]
	ldr	x9, [sp, #16]
	adrp	x8, _nvm_portable_file_read_import.names@PAGE
	add	x8, x8, _nvm_portable_file_read_import.names@PAGEOFF
	ldr	x1, [x8, x9, lsl #3]
	ldr	x2, [sp, #8]
	bl	_memcmp
	cbnz	w0, LBB59_30
	b	LBB59_28
LBB59_28:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #8]
	add	x0, x8, x9
	adrp	x1, l_.str.198@PAGE
	add	x1, x1, l_.str.198@PAGEOFF
	mov	x2, #6                          ; =0x6
	bl	_memcmp
	cbnz	w0, LBB59_30
	b	LBB59_29
LBB59_29:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB59_33
LBB59_30:                               ;   in Loop: Header=BB59_20 Depth=1
	b	LBB59_31
LBB59_31:                               ;   in Loop: Header=BB59_20 Depth=1
	ldr	x8, [sp, #16]
	add	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB59_20
LBB59_32:
	stur	wzr, [x29, #-4]
	b	LBB59_33
LBB59_33:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_portable_read_import_exact
_nvm_portable_read_import_exact:        ; @nvm_portable_read_import_exact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	w1, [sp, #4]
	ldr	x0, [sp, #8]
	ldr	w1, [sp, #4]
	bl	_nvm_portable_file_read_import
	subs	w8, w0, #1
	cset	w0, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function profile_scalar
_profile_scalar:                        ; @profile_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB61_6
	b	LBB61_1
LBB61_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB61_6
	b	LBB61_2
LBB61_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB61_6
	b	LBB61_3
LBB61_3:
	ldrb	w8, [sp, #15]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB61_6
	b	LBB61_4
LBB61_4:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #3
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB61_6
	b	LBB61_5
LBB61_5:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #9
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB61_6
LBB61_6:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function profile_supported
_profile_supported:                     ; @profile_supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #11]
	ldrb	w8, [sp, #11]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #226
	b.hi	LBB62_3
; %bb.1:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI62_0@PAGE
	add	x10, x10, lJTI62_0@PAGEOFF
Ltmp16:
	adr	x8, Ltmp16
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB62_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB62_4
LBB62_3:
	str	wzr, [sp, #12]
	b	LBB62_4
LBB62_4:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
	.p2align	2
lJTI62_0:
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_3-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
	.long	LBB62_2-Ltmp16
                                        ; -- End function
	.p2align	2                               ; -- Begin function mp_declaration
_mp_declaration:                        ; @mp_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	add	x1, sp, #16
	str	xzr, [sp, #16]
	str	wzr, [sp, #24]
	ldur	x0, [x29, #-16]
	bl	_nvm_v2_u8
	cbnz	w0, LBB63_6
	b	LBB63_1
LBB63_1:
	ldur	x0, [x29, #-16]
	add	x8, sp, #16
	add	x1, x8, #1
	bl	_nvm_v2_u8
	cbnz	w0, LBB63_6
	b	LBB63_2
LBB63_2:
	ldur	x0, [x29, #-16]
	add	x1, sp, #14
	bl	_nvm_v2_u16
	cbnz	w0, LBB63_6
	b	LBB63_3
LBB63_3:
	ldrh	w8, [sp, #14]
	cbnz	w8, LBB63_6
	b	LBB63_4
LBB63_4:
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB63_6
	b	LBB63_5
LBB63_5:
	ldur	x0, [x29, #-16]
	add	x8, sp, #16
	add	x1, x8, #4
	bl	_nvm_v2_u32
	cbz	w0, LBB63_7
	b	LBB63_6
LBB63_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_31
LBB63_7:
	ldur	x8, [x29, #-24]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp]
	ldrb	w8, [sp, #16]
	subs	w8, w8, #8
	b.ne	LBB63_16
	b	LBB63_8
LBB63_8:
	ldr	w8, [sp, #20]
	ldr	x9, [sp]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.lo	LBB63_10
	b	LBB63_9
LBB63_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_31
LBB63_10:
	ldr	x8, [sp]
	mov	x9, #4120                       ; =0x1018
	add	x8, x8, x9
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	subs	w8, w8, #1
	b.ne	LBB63_12
	b	LBB63_11
LBB63_11:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #24]
	b	LBB63_15
LBB63_12:
	ldur	x8, [x29, #-24]
	add	x8, x8, #44
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB63_14
	b	LBB63_13
LBB63_13:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #24]
	b	LBB63_14
LBB63_14:
	b	LBB63_15
LBB63_15:
	b	LBB63_30
LBB63_16:
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB63_28
	b	LBB63_17
LBB63_17:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #7
	b.ne	LBB63_19
	b	LBB63_18
LBB63_18:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #24]
	b	LBB63_27
LBB63_19:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #1
	b.eq	LBB63_24
	b	LBB63_20
LBB63_20:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #4
	b.eq	LBB63_24
	b	LBB63_21
LBB63_21:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #2
	b.eq	LBB63_24
	b	LBB63_22
LBB63_22:
	ldrb	w8, [sp, #16]
	subs	w8, w8, #3
	b.eq	LBB63_24
	b	LBB63_23
LBB63_23:
	ldrb	w8, [sp, #16]
	cbnz	w8, LBB63_25
	b	LBB63_24
LBB63_24:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #24]
	b	LBB63_26
LBB63_25:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_31
LBB63_26:
	b	LBB63_27
LBB63_27:
	b	LBB63_29
LBB63_28:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_31
LBB63_29:
	b	LBB63_30
LBB63_30:
	ldr	x9, [sp, #32]
	ldr	x8, [sp, #16]
	str	x8, [x9]
	ldr	w8, [sp, #24]
	str	w8, [x9, #8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB63_31
LBB63_31:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mp_value_signature
_mp_value_signature:                    ; @mp_value_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-24]
	stur	x1, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]
	ldur	w8, [x29, #-16]
	str	w8, [sp, #32]
	strb	w2, [sp, #23]
	ldrb	w8, [sp, #25]
	cbz	w8, LBB64_2
	b	LBB64_1
LBB64_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB64_13
LBB64_2:
	ldr	w8, [sp, #32]
	subs	w8, w8, #2
	b.ne	LBB64_4
	b	LBB64_3
LBB64_3:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #8
	cset	w8, eq
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB64_13
LBB64_4:
	ldr	w9, [sp, #32]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b.ne	LBB64_12
	b	LBB64_5
LBB64_5:
	ldrb	w9, [sp, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB64_11
	b	LBB64_6
LBB64_6:
	ldrb	w9, [sp, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB64_11
	b	LBB64_7
LBB64_7:
	ldrb	w9, [sp, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB64_11
	b	LBB64_8
LBB64_8:
	ldrb	w8, [sp, #23]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB64_10
	b	LBB64_9
LBB64_9:
	ldrb	w8, [sp, #24]
	subs	w8, w8, #0
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB64_10
LBB64_10:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB64_11
LBB64_11:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	b	LBB64_12
LBB64_12:
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB64_13
LBB64_13:
	ldurb	w8, [x29, #-25]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB64_15
	b	LBB64_14
LBB64_14:
	bl	___stack_chk_fail
LBB64_15:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nvm_record_map_opcode
_nvm_record_map_opcode:                 ; @nvm_record_map_opcode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #120
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_6
	b	LBB65_1
LBB65_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #122
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_6
	b	LBB65_2
LBB65_2:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #121
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_6
	b	LBB65_3
LBB65_3:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #123
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_6
	b	LBB65_4
LBB65_4:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #127
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB65_6
	b	LBB65_5
LBB65_5:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #124
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB65_6
LBB65_6:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function verify_stack_heights
_verify_stack_heights:                  ; @verify_stack_heights
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x9, x29, #88
	str	x9, [sp, #64]                   ; 8-byte Folded Spill
	mov	x4, x8
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x4, [sp, #56]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #48]
	str	x1, [x8, #40]
	stur	w2, [x29, #-52]
	str	x3, [x8, #24]
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #8]
	add	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #2
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8, #16]
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #8]
	add	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #2
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8, #8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB66_2
	b	LBB66_1
LBB66_1:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbnz	x8, LBB66_3
	b	LBB66_2
LBB66_2:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.167@PAGE
	add	x0, x0, l_.str.167@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #8]
	add	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	lsl	x0, x8, #2
	bl	_malloc
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x0, [x8]
	ldr	x8, [x8]
	cbnz	x8, LBB66_5
	b	LBB66_4
LBB66_4:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x9, [x10]
	adrp	x0, l_.str.167@PAGE
	add	x0, x0, l_.str.167@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_5:
	stur	wzr, [x29, #-92]
	b	LBB66_6
LBB66_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-92]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hi	LBB66_9
	b	LBB66_7
LBB66_7:                                ;   in Loop: Header=BB66_6 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldur	w8, [x29, #-92]
	mov	x10, x8
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, x10, lsl #2]
	b	LBB66_8
LBB66_8:                                ;   in Loop: Header=BB66_6 Depth=1
	ldur	w8, [x29, #-92]
	add	w8, w8, #1
	stur	w8, [x29, #-92]
	b	LBB66_6
LBB66_9:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	str	wzr, [x8]
	stur	wzr, [x29, #-96]
	stur	wzr, [x29, #-100]
	b	LBB66_10
LBB66_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-100]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.hi	LBB66_13
	b	LBB66_11
LBB66_11:                               ;   in Loop: Header=BB66_10 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	ldur	w8, [x29, #-100]
	mov	x10, x8
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, x10, lsl #2]
	b	LBB66_12
LBB66_12:                               ;   in Loop: Header=BB66_10 Depth=1
	ldur	w8, [x29, #-100]
	add	w8, w8, #1
	stur	w8, [x29, #-100]
	b	LBB66_10
LBB66_13:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	mov	w8, #0                          ; =0x0
	stur	wzr, [x29, #-104]
	stur	wzr, [x29, #-108]
	ldr	x10, [x9, #16]
	str	wzr, [x10]
	ldr	x9, [x9, #8]
	ldur	w10, [x29, #-108]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-108]
	str	w8, [x9, x10, lsl #2]
	b	LBB66_14
LBB66_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB66_92 Depth 2
	ldur	w8, [x29, #-104]
	ldur	w9, [x29, #-108]
	subs	w8, w8, w9
	b.hs	LBB66_121
	b	LBB66_15
LBB66_15:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
	ldur	w10, [x29, #-104]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-104]
	ldr	w8, [x8, x10, lsl #2]
	stur	w8, [x29, #-112]
	ldur	w8, [x29, #-112]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB66_17
	b	LBB66_16
LBB66_16:                               ;   in Loop: Header=BB66_14 Depth=1
	b	LBB66_14
LBB66_17:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	x10, [x8]
	ldur	w8, [x29, #-112]
                                        ; kill: def $x8 killed $w8
	mov	x9, #104                        ; =0x68
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-120]
	ldur	x8, [x29, #-120]
	add	x8, x8, #40
	stur	x8, [x29, #-128]
	ldur	x8, [x29, #-128]
	ldrb	w0, [x8]
	bl	_isa_get_info
	stur	x0, [x29, #-136]
	ldur	x8, [x29, #-136]
	ldrsb	w8, [x8, #28]
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-136]
	ldrsb	w8, [x8, #29]
	stur	w8, [x29, #-144]
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	str	w8, [sp, #52]                   ; 4-byte Folded Spill
	subs	w8, w8, #51
	b.eq	LBB66_32
	b	LBB66_18
LBB66_18:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB66_32
	b	LBB66_19
LBB66_19:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #60
	b.eq	LBB66_40
	b	LBB66_20
LBB66_20:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #61
	b.eq	LBB66_43
	b	LBB66_21
LBB66_21:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #62
	b.eq	LBB66_33
	b	LBB66_22
LBB66_22:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #63
	b.eq	LBB66_41
	b	LBB66_23
LBB66_23:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #88
	b.eq	LBB66_39
	b	LBB66_24
LBB66_24:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #99
	b.eq	LBB66_35
	b	LBB66_25
LBB66_25:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #104
	b.eq	LBB66_36
	b	LBB66_26
LBB66_26:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #112
	b.eq	LBB66_37
	b	LBB66_27
LBB66_27:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #144
	b.eq	LBB66_34
	b	LBB66_28
LBB66_28:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #167
	b.eq	LBB66_42
	b	LBB66_29
LBB66_29:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #244
	b.eq	LBB66_44
	b	LBB66_30
LBB66_30:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #245
	b.eq	LBB66_45
	b	LBB66_31
LBB66_31:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #52]                   ; 4-byte Folded Reload
	subs	w8, w8, #251
	b.eq	LBB66_38
	b	LBB66_46
LBB66_32:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #256]
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #152]
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #4]
	stur	w8, [x29, #-140]
	ldr	x8, [sp, #152]
	ldrb	w8, [x8, #21]
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_33:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #400]
	ldur	x8, [x29, #-128]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #12                         ; =0xc
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #144]
	ldr	x8, [sp, #144]
	ldrh	w8, [x8, #8]
	stur	w8, [x29, #-140]
	ldr	x8, [sp, #144]
	ldrb	w8, [x8, #10]
	subs	w8, w8, #0
	cset	w8, ne
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_34:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_35:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_36:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #24]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_37:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_38:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #32]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_39:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_40:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_41:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #24]
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #32]
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_42:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #16]
	stur	w8, [x29, #-140]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_43:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #21]
	stur	w8, [x29, #-140]
	stur	wzr, [x29, #-144]
	b	LBB66_47
LBB66_44:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	add	w8, w8, #2
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_45:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	add	w8, w8, #1
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-128]
	ldrh	w8, [x8, #8]
	add	w8, w8, #1
	stur	w8, [x29, #-144]
	b	LBB66_47
LBB66_46:                               ;   in Loop: Header=BB66_14 Depth=1
	b	LBB66_47
LBB66_47:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	w8, [x29, #-140]
	tbnz	w8, #31, LBB66_49
	b	LBB66_48
LBB66_48:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	w8, [x29, #-144]
	tbz	w8, #31, LBB66_50
	b	LBB66_49
LBB66_49:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x12, x9
	ldur	x9, [x29, #-136]
	ldr	x11, [x9]
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.168@PAGE
	add	x0, x0, l_.str.168@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_50:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #140]
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #61
	b.ne	LBB66_53
	b	LBB66_51
LBB66_51:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #140]
	ldr	x9, [x9, #48]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.eq	LBB66_53
	b	LBB66_52
LBB66_52:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x13, x9
	ldr	w9, [sp, #140]
	mov	x12, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [x10, #48]
	ldr	x14, [x10, #256]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	mov	x11, #24                        ; =0x18
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x14
	ldrb	w11, [x10, #21]
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #24]
	adrp	x0, l_.str.169@PAGE
	add	x0, x0, l_.str.169@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_53:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #165
	b.ne	LBB66_56
	b	LBB66_54
LBB66_54:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB66_56
	b	LBB66_55
LBB66_55:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.170@PAGE
	add	x0, x0, l_.str.170@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_56:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #168
	b.ne	LBB66_60
	b	LBB66_57
LBB66_57:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #140]
	subs	w8, w8, #1
	b.ne	LBB66_59
	b	LBB66_58
LBB66_58:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	cbz	w8, LBB66_60
	b	LBB66_59
LBB66_59:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	adrp	x0, l_.str.171@PAGE
	add	x0, x0, l_.str.171@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_60:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #140]
	ldur	w9, [x29, #-140]
	subs	w8, w8, w9
	b.ge	LBB66_62
	b	LBB66_61
LBB66_61:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x14, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
	mov	x13, x9
	ldur	x9, [x29, #-136]
	ldr	x12, [x9]
	ldur	w9, [x29, #-140]
	mov	x11, x9
	ldr	w9, [sp, #140]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x14, [x10]
	str	x13, [x10, #8]
	str	x12, [x10, #16]
	str	x11, [x10, #24]
	str	x9, [x10, #32]
	adrp	x0, l_.str.172@PAGE
	add	x0, x0, l_.str.172@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_62:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #140]
	ldur	w10, [x29, #-140]
	subs	w9, w9, w10
	ldur	w10, [x29, #-144]
	add	w9, w9, w10
	str	w9, [sp, #136]
	ldr	x8, [x8]
	ldur	w9, [x29, #-112]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #132]
	ldr	w8, [sp, #132]
	str	w8, [sp, #128]
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #128
	b.ne	LBB66_64
	b	LBB66_63
LBB66_63:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #128]
	add	w8, w8, #1
	str	w8, [sp, #128]
	b	LBB66_67
LBB66_64:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #129
	b.ne	LBB66_66
	b	LBB66_65
LBB66_65:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #128]
	subs	w8, w8, #1
	str	w8, [sp, #128]
	b	LBB66_66
LBB66_66:                               ;   in Loop: Header=BB66_14 Depth=1
	b	LBB66_67
LBB66_67:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #128]
	tbz	w8, #31, LBB66_69
	b	LBB66_68
LBB66_68:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x11, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	adrp	x0, l_.str.173@PAGE
	add	x0, x0, l_.str.173@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_69:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	subs	w8, w8, #61
	b.ne	LBB66_72
	b	LBB66_70
LBB66_70:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #132]
	cbz	w8, LBB66_72
	b	LBB66_71
LBB66_71:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x12, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
	mov	x11, x9
	ldr	w9, [sp, #132]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.174@PAGE
	add	x0, x0, l_.str.174@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_72:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #140]
	ldur	w9, [x29, #-96]
	subs	w8, w8, w9
	b.le	LBB66_74
	b	LBB66_73
LBB66_73:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #140]
	stur	w8, [x29, #-96]
	b	LBB66_74
LBB66_74:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #136]
	ldur	w9, [x29, #-96]
	subs	w8, w8, w9
	b.le	LBB66_76
	b	LBB66_75
LBB66_75:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #136]
	stur	w8, [x29, #-96]
	b	LBB66_76
LBB66_76:                               ;   in Loop: Header=BB66_14 Depth=1
	str	wzr, [sp, #124]
	ldur	x8, [x29, #-128]
	ldrb	w8, [x8]
	strb	w8, [sp, #123]
	ldrb	w8, [sp, #123]
	subs	w8, w8, #56
	b.eq	LBB66_81
	b	LBB66_77
LBB66_77:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #57
	b.eq	LBB66_81
	b	LBB66_78
LBB66_78:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #58
	b.eq	LBB66_81
	b	LBB66_79
LBB66_79:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #107
	b.eq	LBB66_81
	b	LBB66_80
LBB66_80:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #165
	b.ne	LBB66_85
	b	LBB66_81
LBB66_81:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #8]
	str	w8, [sp, #116]
	ldur	x8, [x29, #-120]
	ldr	w8, [x8, #8]
	str	w8, [sp, #112]
	ldr	w8, [sp, #112]
	ldr	w9, [sp, #116]
	subs	w8, w8, w9
	b.lo	LBB66_83
	b	LBB66_82
LBB66_82:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #40]
	ldr	w8, [sp, #112]
	ldr	w9, [sp, #116]
	subs	w1, w8, w9
	add	x2, sp, #108
	bl	_instruction_index_at
	tbnz	w0, #0, LBB66_84
	b	LBB66_83
LBB66_83:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x12, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
	mov	x11, x9
	ldr	w9, [sp, #112]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.175@PAGE
	add	x0, x0, l_.str.175@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_84:                               ;   in Loop: Header=BB66_14 Depth=1
	ldr	w8, [sp, #108]
	ldr	w9, [sp, #124]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	str	w9, [sp, #124]
	sub	x9, x29, #32
	str	w8, [x9, x10, lsl #2]
	b	LBB66_85
LBB66_85:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #56
	b.eq	LBB66_91
	b	LBB66_86
LBB66_86:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #61
	b.eq	LBB66_91
	b	LBB66_87
LBB66_87:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #51
	b.eq	LBB66_91
	b	LBB66_88
LBB66_88:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #163
	b.eq	LBB66_91
	b	LBB66_89
LBB66_89:                               ;   in Loop: Header=BB66_14 Depth=1
	ldrb	w8, [sp, #123]
	subs	w8, w8, #168
	b.eq	LBB66_91
	b	LBB66_90
LBB66_90:                               ;   in Loop: Header=BB66_14 Depth=1
	ldur	w8, [x29, #-112]
	add	w8, w8, #1
	ldr	w9, [sp, #124]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	str	w9, [sp, #124]
	sub	x9, x29, #32
	str	w8, [x9, x10, lsl #2]
	b	LBB66_91
LBB66_91:                               ;   in Loop: Header=BB66_14 Depth=1
	str	wzr, [sp, #104]
	b	LBB66_92
LBB66_92:                               ;   Parent Loop BB66_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #104]
	ldr	w9, [sp, #124]
	subs	w8, w8, w9
	b.hs	LBB66_120
	b	LBB66_93
LBB66_93:                               ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #104]
	mov	x9, x8
	sub	x8, x29, #32
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #100]
	ldrb	w8, [sp, #123]
	subs	w8, w8, #165
	b.ne	LBB66_96
	b	LBB66_94
LBB66_94:                               ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #104]
	cbnz	w8, LBB66_96
	b	LBB66_95
LBB66_95:                               ;   in Loop: Header=BB66_92 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB66_97
LBB66_96:                               ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #136]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB66_97
LBB66_97:                               ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	str	w8, [sp, #96]
	ldrb	w8, [sp, #123]
	subs	w8, w8, #165
	b.ne	LBB66_100
	b	LBB66_98
LBB66_98:                               ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #104]
	cbnz	w8, LBB66_100
	b	LBB66_99
LBB66_99:                               ;   in Loop: Header=BB66_92 Depth=2
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB66_101
LBB66_100:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #128]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB66_101
LBB66_101:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	str	w8, [sp, #92]
	ldr	w8, [sp, #100]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB66_107
	b	LBB66_102
LBB66_102:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #128]
	cbz	w8, LBB66_104
	b	LBB66_103
LBB66_103:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x12, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
	mov	x11, x9
	ldr	w9, [sp, #128]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x12, [x10]
	str	x11, [x10, #8]
	str	x9, [x10, #16]
	adrp	x0, l_.str.176@PAGE
	add	x0, x0, l_.str.176@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_104:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #136]
	ldr	x9, [x9, #48]
	ldr	x11, [x9, #256]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrb	w9, [x9, #21]
	subs	w8, w8, w9
	b.eq	LBB66_106
	b	LBB66_105
LBB66_105:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x13, x9
	ldur	x9, [x29, #-120]
	ldr	w9, [x9]
	mov	x12, x9
	ldr	w9, [sp, #136]
                                        ; kill: def $x9 killed $w9
	ldr	x10, [x10, #48]
	ldr	x14, [x10, #256]
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	mov	x11, #24                        ; =0x18
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x14
	ldrb	w11, [x10, #21]
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x9, [x10, #16]
                                        ; implicit-def: $x9
	mov	x9, x11
	str	x9, [x10, #24]
	adrp	x0, l_.str.177@PAGE
	add	x0, x0, l_.str.177@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_106:                              ;   in Loop: Header=BB66_92 Depth=2
	b	LBB66_119
LBB66_107:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	tbz	w8, #31, LBB66_109
	b	LBB66_108
LBB66_108:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #96]
	ldr	x10, [x9, #16]
	ldr	w11, [sp, #100]
                                        ; kill: def $x11 killed $w11
	str	w8, [x10, x11, lsl #2]
	ldr	w8, [sp, #92]
	ldr	x10, [x9]
	ldr	w11, [sp, #100]
                                        ; kill: def $x11 killed $w11
	str	w8, [x10, x11, lsl #2]
	ldr	w8, [sp, #100]
	ldr	x9, [x9, #8]
	ldur	w10, [x29, #-108]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	stur	w11, [x29, #-108]
	str	w8, [x9, x10, lsl #2]
	b	LBB66_118
LBB66_109:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.eq	LBB66_111
	b	LBB66_110
LBB66_110:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #40]
	ldr	x9, [x9]
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	mov	x11, #104                       ; =0x68
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	str	w9, [sp, #88]
	ldr	x9, [x8]
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	str	w9, [sp, #84]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x13, x9
	ldr	w9, [sp, #88]
	mov	x12, x9
	ldr	w9, [sp, #84]
	mov	x11, x9
	ldr	w9, [sp, #92]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.178@PAGE
	add	x0, x0, l_.str.178@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_111:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	w9, [sp, #96]
	subs	w8, w8, w9
	b.eq	LBB66_116
	b	LBB66_112
LBB66_112:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #100]
	ldr	x9, [x9, #40]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB66_114
	b	LBB66_113
LBB66_113:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	w8, [x8, #12]
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB66_115
LBB66_114:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #40]
	ldr	x8, [x8]
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	mov	x10, #104                       ; =0x68
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB66_115
LBB66_115:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #40]                   ; 4-byte Folded Reload
	str	w9, [sp, #80]
	ldr	x9, [x8, #16]
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	str	w9, [sp, #76]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x13, x9
	ldr	w9, [sp, #80]
	mov	x12, x9
	ldr	w9, [sp, #76]
	mov	x11, x9
	ldr	w9, [sp, #96]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x13, [x10]
	str	x12, [x10, #8]
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.179@PAGE
	add	x0, x0, l_.str.179@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_116:                              ;   in Loop: Header=BB66_92 Depth=2
	b	LBB66_117
LBB66_117:                              ;   in Loop: Header=BB66_92 Depth=2
	b	LBB66_118
LBB66_118:                              ;   in Loop: Header=BB66_92 Depth=2
	b	LBB66_119
LBB66_119:                              ;   in Loop: Header=BB66_92 Depth=2
	ldr	w8, [sp, #104]
	add	w8, w8, #1
	str	w8, [sp, #104]
	b	LBB66_92
LBB66_120:                              ;   in Loop: Header=BB66_14 Depth=1
	b	LBB66_14
LBB66_121:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_free
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #48]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	ldur	w9, [x29, #-96]
	add	w8, w8, w9
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lo	LBB66_123
	b	LBB66_122
LBB66_122:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldur	w10, [x29, #-52]
	mov	x11, x10
	ldr	x10, [x9, #48]
	ldr	x14, [x10, #256]
	ldur	w10, [x29, #-52]
	mov	x12, x10
	mov	x10, #24                        ; =0x18
	mov	x13, x10
                                        ; kill: def $w12 killed $w12 killed $x12
	umaddl	x12, w12, w13, x14
	ldrh	w12, [x12, #16]
	ldur	w13, [x29, #-96]
	add	w13, w12, w13
	ldr	x9, [x9, #48]
	ldr	x12, [x9, #256]
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x12
	ldrh	w12, [x9, #16]
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
                                        ; implicit-def: $x11
	mov	x11, x13
	str	x11, [x10, #8]
                                        ; implicit-def: $x11
	mov	x11, x12
	str	x11, [x10, #16]
	str	x9, [x10, #24]
	adrp	x0, l_.str.180@PAGE
	add	x0, x0, l_.str.180@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_123:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbz	x8, LBB66_127
	b	LBB66_124
LBB66_124:
	ldur	w8, [x29, #-96]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.lt	LBB66_126
	b	LBB66_125
LBB66_125:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-52]
	mov	x11, x9
	ldur	w9, [x29, #-96]
                                        ; kill: def $x9 killed $w9
	mov	x10, sp
	str	x11, [x10]
	str	x9, [x10, #8]
	mov	x9, #65535                      ; =0xffff
	str	x9, [x10, #16]
	adrp	x0, l_.str.181@PAGE
	add	x0, x0, l_.str.181@PAGEOFF
	bl	_fail
	b	LBB66_128
LBB66_126:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-96]
	ldr	x9, [x9, #24]
	strh	w8, [x9]
	b	LBB66_127
LBB66_127:
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	bl	_ok_result
	b	LBB66_128
LBB66_128:
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB66_130
	b	LBB66_129
LBB66_129:
	bl	___stack_chk_fail
LBB66_130:
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function instruction_index_at
_instruction_index_at:                  ; @instruction_index_at
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	x2, [sp, #16]
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB67_2
	b	LBB67_1
LBB67_1:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
	ldr	x9, [sp, #16]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_5
LBB67_2:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	bl	_vm_decoded_function_at
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB67_4
	b	LBB67_3
LBB67_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_5
LBB67_4:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	subs	x8, x8, x9
	mov	x9, #104                        ; =0x68
	sdiv	x8, x8, x9
	ldr	x9, [sp, #16]
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB67_5
LBB67_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an output for private mixed preparation."

l_.str.1:                               ; @.str.1
	.asciz	"I refuse service contracts before mixed preparation."

l_.str.2:                               ; @.str.2
	.asciz	"I require an owner and proved ordinary FLOAT-array record graph."

l_.str.3:                               ; @.str.3
	.asciz	"I require complete common structure for private mixed preparation."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate my private mixed plan."

l_.str.5:                               ; @.str.5
	.asciz	"I require exact checked mixed signature transport."

l_.str.6:                               ; @.str.6
	.asciz	"I could not retain my mixed layout transport."

l_.str.7:                               ; @.str.7
	.asciz	"I prepared mixed facts; runtime checks and admission remain unavailable."

l_.str.8:                               ; @.str.8
	.asciz	"I require an output for mixed admission."

l_.str.9:                               ; @.str.9
	.asciz	"I require the explicit mixed Samples candidate."

l_.str.10:                              ; @.str.10
	.asciz	"__init__"

l_.str.11:                              ; @.str.11
	.asciz	"I require a scalar mixed entry without initializer functions."

l_.str.12:                              ; @.str.12
	.asciz	"I admit my closed mixed runtime with exact scalar checks and owner obligations."

l_.str.13:                              ; @.str.13
	.asciz	"I require an output for private owner preparation."

l_.str.14:                              ; @.str.14
	.asciz	"I require complete common structure and metadata for owner preparation."

l_.str.15:                              ; @.str.15
	.asciz	"I could not allocate the private owner plan."

l_.str.16:                              ; @.str.16
	.asciz	"I prepared private origin, lifetime, scalar and structural facts; I grant no runtime permission."

l_.str.17:                              ; @.str.17
	.asciz	"I require an owner ARRAY admission output."

l_.str.18:                              ; @.str.18
	.asciz	"I refuse service contracts before owner ARRAY admission."

l_.str.19:                              ; @.str.19
	.asciz	"I require an exact owner ARRAY candidate."

l_.str.20:                              ; @.str.20
	.asciz	"I require bounded exact owner ARRAY parameter declarations."

l_.str.21:                              ; @.str.21
	.asciz	"I require exact owner ARRAY parameter tags and a no-argument scalar entry without initializers."

l_.str.22:                              ; @.str.22
	.asciz	"I admit exact owner ARRAY runtime authority."

l_.str.23:                              ; @.str.23
	.asciz	"I require a map declaration output."

l_.str.24:                              ; @.str.24
	.asciz	"I require private preparation inputs."

l_.str.25:                              ; @.str.25
	.asciz	"I require fresh private accounting."

l_.str.26:                              ; @.str.26
	.asciz	"I reached my fixed scratch reservation."

l_.str.27:                              ; @.str.27
	.asciz	"I require a closed ordinary module without host contracts."

l_.str.28:                              ; @.str.28
	.asciz	"I reached my private module bound."

l_.str.29:                              ; @.str.29
	.asciz	"I require consistent original module storage."

l_.str.30:                              ; @.str.30
	.asciz	"I require the original in-memory module header."

l_.str.31:                              ; @.str.31
	.asciz	"I require a bounded module entry."

l_.str.32:                              ; @.str.32
	.asciz	"I require a present counted string."

l_.str.33:                              ; @.str.33
	.asciz	"I reached my counted-string work bound."

l_.str.34:                              ; @.str.34
	.asciz	"I require terminated counted strings."

l_.str.35:                              ; @.str.35
	.asciz	"I reached my metadata work bound."

l_.str.36:                              ; @.str.36
	.asciz	"I require consistent source metadata."

l_.str.37:                              ; @.str.37
	.asciz	"I require a value-producing body for a declared result."

l_.str.38:                              ; @.str.38
	.asciz	"I reached my local bound."

l_.str.39:                              ; @.str.39
	.asciz	"I require ordinary direct-call signatures."

l_.str.40:                              ; @.str.40
	.asciz	"I require bounded original code ranges."

l_.str.41:                              ; @.str.41
	.asciz	"I reached my structural scan bound."

l_.str.42:                              ; @.str.42
	.asciz	"I reached my parameter bound."

l_.str.43:                              ; @.str.43
	.asciz	"I require ordinary parameter tags."

l_.str.44:                              ; @.str.44
	.asciz	"I require decodable original instructions."

l_.str.45:                              ; @.str.45
	.asciz	"I reached my instruction bound."

l_.str.46:                              ; @.str.46
	.asciz	"I have no ordinary union-field transfer for this opcode."

l_.str.47:                              ; @.str.47
	.asciz	"I reached my global bound."

l_.str.48:                              ; @.str.48
	.asciz	"I reached my shared structural rescan bound."

l_.str.49:                              ; @.str.49
	.asciz	"I reached my empty contract-check bound."

l_.str.50:                              ; @.str.50
	.asciz	"I reached my declaration reservation bound."

l_.str.51:                              ; @.str.51
	.asciz	"I could not allocate union structure owner."

l_.str.52:                              ; @.str.52
	.asciz	"I could not allocate union structure carrier."

l_.str.53:                              ; @.str.53
	.asciz	"I reached my decoded storage bound."

l_.str.54:                              ; @.str.54
	.asciz	"allocat"

l_.str.55:                              ; @.str.55
	.asciz	"I copied bounded structure, not executable authority."

l_.str.56:                              ; @.str.56
	.asciz	"I refuse reference lifetime and ownership instruction dataflow at %u: %s"

l_.str.57:                              ; @.str.57
	.asciz	"I require standalone ownership instruction execution semantics without linked contracts"

l_.str.58:                              ; @.str.58
	.asciz	"I require exact global declarations before owned execution"

l_.str.59:                              ; @.str.59
	.asciz	"I require explicit record/resource global transfers and lifetime"

l_.str.60:                              ; @.str.60
	.asciz	"I require a bounded acyclic value graph or my separate borrowed helper"

l_.str.61:                              ; @.str.61
	.asciz	"I require a scalar entry and exact bounded value-result helper signatures"

l_.str.62:                              ; @.str.62
	.asciz	"I require complete ownership local declarations"

l_.str.63:                              ; @.str.63
	.asciz	"I require matched collection runtime cleanup before typed-array execution"

l_.str.64:                              ; @.str.64
	.asciz	"I require value entry locals and exact borrowed or consuming value helper parameters"

l_.str.65:                              ; @.str.65
	.asciz	"I require complete owned record layouts"

l_.str.66:                              ; @.str.66
	.asciz	"I require exact scalar, retained STRING or owned-child record fields before execution"

l_.str.67:                              ; @.str.67
	.asciz	"%s"

l_.str.68:                              ; @.str.68
	.asciz	"I require explicit owned entry execution and a non-escaping scalar helper"

l_.str.69:                              ; @.str.69
	.asciz	"I require one declared stack depth per function"

l_.str.70:                              ; @.str.70
	.asciz	"I refuse service contracts before mixed execution selection"

l_.str.71:                              ; @.str.71
	.asciz	"function %u declares max_stack %u but reaches %u"

l_.str.72:                              ; @.str.72
	.asciz	"linked_count %u but linked_modules table is NULL"

l_.str.73:                              ; @.str.73
	.asciz	"I refuse linked service contracts before reviewed dispatch admission"

l_.str.74:                              ; @.str.74
	.asciz	"I refuse record-map authority in linked verification."

l_.str.75:                              ; @.str.75
	.asciz	"I refuse linked record-map execution contracts."

l_.str.76:                              ; @.str.76
	.asciz	"I refuse an owner ARRAY candidate or invalid descriptor in a linked graph"

l_.str.77:                              ; @.str.77
	.asciz	"I refuse linked owner ARRAY execution contracts"

l_.str.78:                              ; @.str.78
	.asciz	"I refuse linked mixed ownership execution contracts"

l_.str.79:                              ; @.str.79
	.asciz	"I refuse a record-array module in a linked graph."

l_.str.80:                              ; @.str.80
	.asciz	"I refuse linked record-array execution contracts."

l_.str.81:                              ; @.str.81
	.asciz	"I refuse a mixed module in a linked graph"

l_.str.82:                              ; @.str.82
	.asciz	"I refuse linked ownership execution contracts"

l_.str.83:                              ; @.str.83
	.asciz	"I do not recognize verifier profile %d"

l_.str.84:                              ; @.str.84
	.asciz	"I keep owner ARRAY candidates outside closed backend profiles"

l_.str.85:                              ; @.str.85
	.asciz	"I keep mixed ownership outside closed backend profiles"

l_.str.86:                              ; @.str.86
	.asciz	"I keep record-map authority outside unqualified backend profiles."

l_.str.87:                              ; @.str.87
	.asciz	"I keep record-array authority outside unqualified backend profiles."

l_.str.88:                              ; @.str.88
	.asciz	"I require explicit portable read-text declarations without callbacks"

l_.str.89:                              ; @.str.89
	.asciz	"I require exact portable read-text import %u"

l_.str.90:                              ; @.str.90
	.asciz	"I support only closed scalar modules without imports, nominal layouts or ownership/passive contracts"

l_.str.91:                              ; @.str.91
	.asciz	"I require an explicit executable entry point"

l_.str.92:                              ; @.str.92
	.asciz	"I require an integer/bool executable entry result"

l_.str.93:                              ; @.str.93
	.asciz	"I require a zero-argument scalar entry point"

l_.str.94:                              ; @.str.94
	.asciz	"I require a zero-argument scalar module initializer"

l_.str.95:                              ; @.str.95
	.asciz	"I require zero void results or one admitted closed-profile result and no captures in function %u"

l_.str.96:                              ; @.str.96
	.asciz	"I require explicit portable function parameter tags"

l_.str.97:                              ; @.str.97
	.asciz	"I require admitted closed-profile parameters in function %u"

l_.str.98:                              ; @.str.98
	.asciz	"I do not support opcode 0x%02x at function %u offset %u in my scalar LLVM profile"

l_.str.99:                              ; @.str.99
	.asciz	"I cannot establish mutable array eligibility (status %u) at function %u offset %u: %s"

l_.str.100:                             ; @.str.100
	.asciz	"I refuse ADD/CAST_INT/CAST_FLOAT in the literal-string profile"

l_.str.101:                             ; @.str.101
	.asciz	"I found invalid ownership declarations"

l_.str.102:                             ; @.str.102
	.asciz	"I refuse reference lifetime and ownership instruction dataflow in function[%u] at %u: %s"

l_.str.103:                             ; @.str.103
	.asciz	"I found invalid retained layout metadata"

l_.str.104:                             ; @.str.104
	.asciz	"I have no ordinary record-array transfer for this opcode."

l_.str.105:                             ; @.str.105
	.asciz	"I could not allocate private structure."

l_.str.106:                             ; @.str.106
	.asciz	"I reached my map declaration overlap bound."

l_.str.107:                             ; @.str.107
	.asciz	"module is NULL"

l_.str.108:                             ; @.str.108
	.asciz	"I require reviewed service lifetime and dispatch admission before execution"

l_.str.109:                             ; @.str.109
	.asciz	"code pointer is NULL but code_size=%u"

l_.str.110:                             ; @.str.110
	.asciz	"entry_point %u >= function_count %u"

l_.str.111:                             ; @.str.111
	.asciz	"function[%u] code_offset %u > code_size %u"

l_.str.112:                             ; @.str.112
	.asciz	"function[%u] code range exceeds code_size: offset %u, length %u, code_size %u"

l_.str.113:                             ; @.str.113
	.asciz	"function[%u] name_idx %u >= string_count %u"

l_.str.114:                             ; @.str.114
	.asciz	"function[%u] result_tag %u is invalid"

l_.str.115:                             ; @.str.115
	.asciz	"I found an invalid parameter tag in function[%u] parameter[%u]"

l_.str.116:                             ; @.str.116
	.asciz	"function[%u] result signature must be void/0 or non-void/nonzero"

l_.str.117:                             ; @.str.117
	.asciz	"function[%u] local_count %u is smaller than arity %u"

l_.str.118:                             ; @.str.118
	.asciz	"function[%u] code range overlaps function[%u]"

l_.str.119:                             ; @.str.119
	.asciz	"I found invalid passive eligibility metadata"

l_.str.120:                             ; @.str.120
	.asciz	"I found an invalid retained callback import contract"

l_.str.121:                             ; @.str.121
	.asciz	"import[%u] module_name_idx %u >= string_count %u"

l_.str.122:                             ; @.str.122
	.asciz	"import[%u] function_name_idx %u >= string_count %u"

l_.str.123:                             ; @.str.123
	.asciz	"import[%u] has unknown kind %u"

l_.str.124:                             ; @.str.124
	.asciz	"import[%u] artifact path must be absolute and contain no NUL"

l_.str.125:                             ; @.str.125
	.asciz	"import[%u] return_type %u is not a valid value tag"

l_.str.126:                             ; @.str.126
	.asciz	"import[%u] param_count %u exceeds the foreign-call argument limit of %u"

l_.str.127:                             ; @.str.127
	.asciz	"import[%u] declares %u params but has no param type array"

l_.str.128:                             ; @.str.128
	.asciz	"import[%u] param[%u] type %u is not a valid value tag"

l_.str.129:                             ; @.str.129
	.asciz	"I reached my private operand-check work bound."

l_.str.130:                             ; @.str.130
	.asciz	"function[%u] unknown opcode 0x%02x at offset %u"

l_.str.131:                             ; @.str.131
	.asciz	"I refuse reference lifetime and ownership instruction dataflow: %s"

l_.str.132:                             ; @.str.132
	.asciz	"I require owned-transfer execution semantics before execution"

l_.str.133:                             ; @.str.133
	.asciz	"function[%u] jump at offset %u targets %ld (not an instruction boundary)"

l_.str.134:                             ; @.str.134
	.asciz	"I require valid handler names and parameter slots."

l_.str.135:                             ; @.str.135
	.asciz	"I require an executable handler arm."

l_.str.136:                             ; @.str.136
	.asciz	"I require a valid effect operation name."

l_.str.137:                             ; @.str.137
	.asciz	"function[%u] match_tag at offset %u targets %ld (not an instruction boundary)"

l_.str.138:                             ; @.str.138
	.asciz	"function[%u] %s at offset %u: fn_idx %u >= function_count %u"

l_.str.139:                             ; @.str.139
	.asciz	"function[%u] OP_TAIL_CALL at offset %u has incompatible result signature"

l_.str.140:                             ; @.str.140
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: module_idx %u >= linked_count %u"

l_.str.141:                             ; @.str.141
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: linked module %u is unresolved"

l_.str.142:                             ; @.str.142
	.asciz	"function[%u] OP_CALL_MODULE at offset %u: fn_idx %u >= linked function_count %u"

l_.str.143:                             ; @.str.143
	.asciz	"function[%u] OP_CALL_MODULE at offset %u declares arity %u but linked callee takes %u"

l_.str.144:                             ; @.str.144
	.asciz	"function[%u] OP_CALL_MODULE at offset %u declares %u results but linked callee returns %u"

l_.str.145:                             ; @.str.145
	.asciz	"function[%u] OP_CLOSURE_NEW at offset %u: fn_idx %u >= function_count %u"

l_.str.146:                             ; @.str.146
	.asciz	"function[%u] OP_CLOSURE_NEW at offset %u: capture_count %u does not match upvalue_count %u"

l_.str.147:                             ; @.str.147
	.asciz	"function[%u] OP_FUNCREF at offset %u: fn_idx %u >= function_count %u"

l_.str.148:                             ; @.str.148
	.asciz	"function[%u] OP_PUSH_STR at offset %u: str_idx %u >= string_count %u"

l_.str.149:                             ; @.str.149
	.asciz	"function[%u] OP_CALL_EXTERN at offset %u: import_idx %u >= import_count %u"

l_.str.150:                             ; @.str.150
	.asciz	"function[%u] %s at offset %u: global index %u >= limit %u"

l_.str.151:                             ; @.str.151
	.asciz	"function[%u] %s at offset %u: slot %u >= local_count %u"

l_.str.152:                             ; @.str.152
	.asciz	"function[%u] %s at offset %u: upvalue depth must be zero"

l_.str.153:                             ; @.str.153
	.asciz	"function[%u] %s at offset %u: upvalue index %u >= upvalue_count %u"

l_.str.154:                             ; @.str.154
	.asciz	"function[%u] %s at offset %u: struct def_idx %u >= struct_count %u"

l_.str.155:                             ; @.str.155
	.asciz	"function[%u] %s at offset %u: enum def_idx %u >= enum_count %u"

l_.str.156:                             ; @.str.156
	.asciz	"function[%u] %s at offset %u: union def_idx %u >= union_count %u"

l_.str.157:                             ; @.str.157
	.asciz	"function[%u] AGG_PACK at offset %u: invalid kind %u"

l_.str.158:                             ; @.str.158
	.asciz	"function[%u] AGG_PACK record layout %u >= struct_count %u"

l_.str.159:                             ; @.str.159
	.asciz	"function[%u] AGG_PACK variant layout %u >= union_count %u"

l_.str.160:                             ; @.str.160
	.asciz	"function[%u] %s at offset %u: type tag %u >= TAG_COUNT %u"

l_.str.161:                             ; @.str.161
	.asciz	"function[%u] OP_HM_NEW at offset %u: key tag %u >= TAG_COUNT %u"

l_.str.162:                             ; @.str.162
	.asciz	"function[%u] OP_HM_NEW at offset %u: value tag %u >= TAG_COUNT %u"

l_.str.163:                             ; @.str.163
	.asciz	"function[%u] OP_ARR_LITERAL at offset %u: element tag %u >= TAG_COUNT %u"

l_.str.164:                             ; @.str.164
	.asciz	"function[%u] opcode 0x%02x at offset %u is outside the primary plane"

l_.str.165:                             ; @.str.165
	.asciz	"I reached my private stack-check budget."

l_.str.166:                             ; @.str.166
	.asciz	"I reached my private stack bound."

l_.str.167:                             ; @.str.167
	.asciz	"function[%u] could not allocate stack verifier state"

l_.str.168:                             ; @.str.168
	.asciz	"function[%u] %s at offset %u has no known stack effect"

l_.str.169:                             ; @.str.169
	.asciz	"function[%u] returns with %d values at offset %u but declares %u"

l_.str.170:                             ; @.str.170
	.asciz	"I cannot install a nonlocal-return handler across outstanding explicit retains."

l_.str.171:                             ; @.str.171
	.asciz	"I require one result and balanced ownership when resuming an effect."

l_.str.172:                             ; @.str.172
	.asciz	"function[%u] stack underflow at offset %u (%s needs %d, has %d)"

l_.str.173:                             ; @.str.173
	.asciz	"function[%u] releases a reference it does not hold at offset %u"

l_.str.174:                             ; @.str.174
	.asciz	"function[%u] returns at offset %u still holding %d retained reference(s)"

l_.str.175:                             ; @.str.175
	.asciz	"function[%u] branch at offset %u targets %u, which is not an instruction boundary in this function"

l_.str.176:                             ; @.str.176
	.asciz	"function[%u] reaches its end after offset %u still holding %d retained reference(s)"

l_.str.177:                             ; @.str.177
	.asciz	"function[%u] reaches its end after offset %u with %d values but declares %u"

l_.str.178:                             ; @.str.178
	.asciz	"function[%u] incompatible ownership balance at offset %u (%d and %d)"

l_.str.179:                             ; @.str.179
	.asciz	"function[%u] incompatible stack heights at offset %u (%d and %d)"

l_.str.180:                             ; @.str.180
	.asciz	"function[%u] frame needs %u slots (%u locals + operand depth %d), more than a frame can address"

l_.str.181:                             ; @.str.181
	.asciz	"function[%u] maximum operand depth %d exceeds %u"

	.section	__TEXT,__const
l_.str.182:                             ; @.str.182
	.space	256

	.section	__TEXT,__cstring,cstring_literals
l_.str.183:                             ; @.str.183
	.asciz	"I refuse record-array candidates in linked function verification."

l_.str.184:                             ; @.str.184
	.asciz	"function index %u >= function_count %u"

l_.str.185:                             ; @.str.185
	.asciz	"I refuse record-map admission: %s"

l_.str.186:                             ; @.str.186
	.asciz	"I require an existing record-map function."

l_.str.187:                             ; @.str.187
	.asciz	"I require complete record-map function facts."

l_.str.188:                             ; @.str.188
	.asciz	"I refuse record-array admission: %s"

l_.str.189:                             ; @.str.189
	.asciz	"I require an existing record-array function."

l_.str.190:                             ; @.str.190
	.asciz	"I require complete record-array function facts."

l_.str.191:                             ; @.str.191
	.asciz	"I refuse owner ARRAY admission (status %u) at function %u offset %u: %s"

l_.str.192:                             ; @.str.192
	.asciz	"I require an existing owner ARRAY function index"

l_.str.193:                             ; @.str.193
	.asciz	"I refuse mixed admission (status %u) at function %u offset %u: %s"

l_.str.194:                             ; @.str.194
	.asciz	"I require an existing mixed function index"

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @nvm_portable_file_read_import.names
_nvm_portable_file_read_import.names:
	.quad	l_.str.195
	.quad	l_.str.196
	.quad	l_.str.197

	.section	__TEXT,__cstring,cstring_literals
l_.str.195:                             ; @.str.195
	.asciz	"file_read"

l_.str.196:                             ; @.str.196
	.asciz	"vm_file_read"

l_.str.197:                             ; @.str.197
	.asciz	"nl_os_file_read"

l_.str.198:                             ; @.str.198
	.asciz	"_bytes"

.subsections_via_symbols
