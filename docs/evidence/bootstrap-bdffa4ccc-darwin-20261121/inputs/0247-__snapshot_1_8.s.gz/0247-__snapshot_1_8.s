	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_constants_decode ; -- Begin function nvm_v2_constants_decode
	.globl	_nvm_v2_constants_decode
	.p2align	2
_nvm_v2_constants_decode:               ; @nvm_v2_constants_decode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	mov	x1, x0
	str	xzr, [x2]
	str	wzr, [x2, #8]
	add	x0, sp, #24
	mov	x2, x19
	bl	_nvm_v2_cursor_init
	add	x0, sp, #24
	add	x1, sp, #20
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_21
; %bb.1:
	ldr	w0, [sp, #20]
	cbz	w0, LBB0_21
; %bb.2:
	ldr	x8, [sp, #40]
	sub	x8, x19, x8
	cmp	x0, x8, lsr #3
	b.hi	LBB0_18
; %bb.3:
	mov	w1, #16                         ; =0x10
	bl	_calloc
	cbz	x0, LBB0_18
; %bb.4:
	mov	x19, x0
	mov	x21, #0                         ; =0x0
	add	x22, x0, #8
LBB0_5:                                 ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #24
	add	x1, sp, #19
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_20
; %bb.6:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #24
	add	x1, sp, #18
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_20
; %bb.7:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #24
	add	x1, sp, #17
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_20
; %bb.8:                                ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #24
	add	x1, sp, #16
	bl	_nvm_v2_u8
	cbnz	w0, LBB0_20
; %bb.9:                                ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [sp, #18]
	mov	w0, #7                          ; =0x7
	cbnz	w8, LBB0_20
; %bb.10:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB0_20
; %bb.11:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [sp, #16]
	cbnz	w8, LBB0_20
; %bb.12:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [sp, #19]
	cmp	w8, #15
	b.hi	LBB0_19
; %bb.13:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #24
	add	x1, sp, #12
	bl	_nvm_v2_u32
	cbnz	w0, LBB0_20
; %bb.14:                               ;   in Loop: Header=BB0_5 Depth=1
	str	xzr, [sp]
	ldr	w1, [sp, #12]
	add	x0, sp, #24
	mov	x2, sp
	bl	_nvm_v2_take
	cbnz	w0, LBB0_20
; %bb.15:                               ;   in Loop: Header=BB0_5 Depth=1
	add	x0, sp, #24
	bl	_nvm_v2_align4
	cbnz	w0, LBB0_20
; %bb.16:                               ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w8, [sp, #19]
	sturb	w8, [x22, #-8]
	ldr	w8, [sp, #12]
	stur	w8, [x22, #-4]
	ldr	x8, [sp]
	str	x8, [x22], #16
	add	x21, x21, #1
	ldr	w8, [sp, #20]
	cmp	x21, x8
	b.lo	LBB0_5
; %bb.17:
	mov	w0, #0                          ; =0x0
	str	x19, [x20]
	str	w8, [x20, #8]
	b	LBB0_21
LBB0_18:
	mov	w0, #1                          ; =0x1
	b	LBB0_21
LBB0_19:
	mov	w0, #8                          ; =0x8
LBB0_20:
	mov	x20, x0
	mov	x0, x19
	bl	_free
	mov	x0, x20
LBB0_21:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	_nvm_v2_constants_free  ; -- Begin function nvm_v2_constants_free
	.globl	_nvm_v2_constants_free
	.p2align	2
_nvm_v2_constants_free:                 ; @nvm_v2_constants_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	str	xzr, [x19]
	str	wzr, [x19, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB1_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_v2_constants_encoded_size
lCPI2_0:
	.quad	4                               ; 0x4
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_constants_encoded_size
	.globl	_nvm_v2_constants_encoded_size
	.p2align	2
_nvm_v2_constants_encoded_size:         ; @nvm_v2_constants_encoded_size
	.cfi_startproc
; %bb.0:
	ldr	w8, [x0, #8]
	cbz	w8, LBB2_3
; %bb.1:
	stp	d11, d10, [sp, #-32]!           ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset b8, -8
	.cfi_offset b9, -16
	.cfi_offset b10, -24
	.cfi_offset b11, -32
	ldr	x9, [x0]
	cmp	w8, #4
	b.hi	LBB2_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w0, #4                          ; =0x4
	b	LBB2_12
LBB2_3:
	mov	w0, #4                          ; =0x4
	ret
LBB2_4:
	cmp	w8, #17
	b.hs	LBB2_6
; %bb.5:
	mov	x10, #0                         ; =0x0
	mov	w0, #4                          ; =0x4
	b	LBB2_9
LBB2_6:
	ands	x10, x8, #0xf
	mov	w11, #16                        ; =0x10
	csel	x11, x11, x10, eq
	sub	x10, x8, x11
	movi.2d	v0, #0000000000000000
	mov	w12, #3                         ; =0x3
	dup.2d	v1, x12
	mov	x12, #8589934588                ; =0x1fffffffc
	dup.2d	v2, x12
	mov	w12, #8                         ; =0x8
	dup.2d	v3, x12
Lloh0:
	adrp	x12, lCPI2_0@PAGE
Lloh1:
	ldr	q4, [x12, lCPI2_0@PAGEOFF]
	add	x12, x9, #132
	mov	x13, x10
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB2_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #128
	sub	x15, x12, #64
	ld4.4s	{ v19, v20, v21, v22 }, [x14]
	ld4.4s	{ v23, v24, v25, v26 }, [x15]
	mov	x14, x12
	ld4.4s	{ v27, v28, v29, v30 }, [x14], #64
	ld4.4s	{ v8, v9, v10, v11 }, [x14]
	uaddw.2d	v31, v1, v19
	uaddw2.2d	v19, v1, v19
	uaddw.2d	v20, v1, v23
	uaddw2.2d	v21, v1, v23
	uaddw.2d	v22, v1, v27
	uaddw2.2d	v23, v1, v27
	uaddw.2d	v24, v1, v8
	uaddw2.2d	v25, v1, v8
	and.16b	v19, v19, v2
	and.16b	v26, v31, v2
	and.16b	v21, v21, v2
	and.16b	v20, v20, v2
	and.16b	v23, v23, v2
	and.16b	v22, v22, v2
	and.16b	v25, v25, v2
	and.16b	v24, v24, v2
	add.2d	v0, v0, v3
	add.2d	v0, v0, v19
	add.2d	v4, v4, v3
	add.2d	v4, v4, v26
	add.2d	v7, v7, v3
	add.2d	v7, v7, v21
	add.2d	v6, v6, v3
	add.2d	v6, v6, v20
	add.2d	v18, v18, v3
	add.2d	v18, v18, v23
	add.2d	v5, v5, v3
	add.2d	v5, v5, v22
	add.2d	v17, v17, v3
	add.2d	v17, v17, v25
	add.2d	v16, v16, v3
	add.2d	v16, v16, v24
	add	x12, x12, #256
	subs	x13, x13, #16
	b.ne	LBB2_7
; %bb.8:
	add.2d	v1, v6, v4
	add.2d	v0, v7, v0
	add.2d	v0, v18, v0
	add.2d	v1, v5, v1
	add.2d	v1, v16, v1
	add.2d	v0, v17, v0
	add.2d	v0, v1, v0
	addp.2d	d0, v0
	fmov	x0, d0
	cmp	x11, #5
	b.lo	LBB2_12
LBB2_9:
	mov	x11, x10
	ands	x10, x8, #0x3
	mov	w12, #4                         ; =0x4
	csel	x12, x12, x10, eq
	movi.2d	v0, #0000000000000000
	mov.d	v0[0], x0
	add	x13, x9, x11, lsl #4
	sub	x10, x8, x12
	movi.2d	v1, #0000000000000000
	add	x11, x12, x11
	sub	x11, x11, x8
	add	x12, x13, #4
	mov	w13, #3                         ; =0x3
	dup.2d	v2, x13
	mov	x13, #8589934588                ; =0x1fffffffc
	dup.2d	v3, x13
	mov	w13, #8                         ; =0x8
	dup.2d	v4, x13
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	ld4.4s	{ v16, v17, v18, v19 }, [x12], #64
	uaddw.2d	v5, v2, v16
	uaddw2.2d	v6, v2, v16
	and.16b	v6, v6, v3
	and.16b	v5, v5, v3
	add.2d	v1, v1, v4
	add.2d	v1, v1, v6
	add.2d	v0, v0, v4
	add.2d	v0, v0, v5
	adds	x11, x11, #4
	b.ne	LBB2_10
; %bb.11:
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x0, d0
LBB2_12:
	add	x9, x9, x10, lsl #4
	add	x9, x9, #4
	sub	x8, x8, x10
LBB2_13:                                ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9], #16
	add	x10, x10, #3
	and	x10, x10, #0x1fffffffc
	add	x10, x0, x10
	add	x0, x10, #8
	subs	x8, x8, #1
	b.ne	LBB2_13
; %bb.14:
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function nvm_v2_constants_encode
lCPI3_0:
	.quad	4                               ; 0x4
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	_nvm_v2_constants_encode
	.globl	_nvm_v2_constants_encode
	.p2align	2
_nvm_v2_constants_encode:               ; @nvm_v2_constants_encode
	.cfi_startproc
; %bb.0:
	stp	d11, d10, [sp, #-96]!           ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -88
	.cfi_offset b11, -96
	mov	x19, x1
	mov	x20, x0
	ldr	w8, [x0, #8]
	cbz	w8, LBB3_3
; %bb.1:
	ldr	x9, [x20]
	cmp	w8, #5
	b.hs	LBB3_4
; %bb.2:
	mov	x10, #0                         ; =0x0
	mov	w1, #4                          ; =0x4
	b	LBB3_12
LBB3_3:
	mov	w1, #4                          ; =0x4
	b	LBB3_14
LBB3_4:
	cmp	w8, #17
	b.hs	LBB3_6
; %bb.5:
	mov	x10, #0                         ; =0x0
	mov	w1, #4                          ; =0x4
	b	LBB3_9
LBB3_6:
	ands	x10, x8, #0xf
	mov	w11, #16                        ; =0x10
	csel	x11, x11, x10, eq
	sub	x10, x8, x11
	movi.2d	v0, #0000000000000000
	mov	w12, #3                         ; =0x3
	dup.2d	v1, x12
	mov	x12, #8589934588                ; =0x1fffffffc
	dup.2d	v2, x12
	mov	w12, #8                         ; =0x8
	dup.2d	v3, x12
Lloh2:
	adrp	x12, lCPI3_0@PAGE
Lloh3:
	ldr	q4, [x12, lCPI3_0@PAGEOFF]
	add	x12, x9, #132
	mov	x13, x10
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB3_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	x14, x12, #128
	sub	x15, x12, #64
	ld4.4s	{ v19, v20, v21, v22 }, [x14]
	ld4.4s	{ v23, v24, v25, v26 }, [x15]
	mov	x14, x12
	ld4.4s	{ v27, v28, v29, v30 }, [x14], #64
	ld4.4s	{ v8, v9, v10, v11 }, [x14]
	uaddw.2d	v31, v1, v19
	uaddw2.2d	v19, v1, v19
	uaddw.2d	v20, v1, v23
	uaddw2.2d	v21, v1, v23
	uaddw.2d	v22, v1, v27
	uaddw2.2d	v23, v1, v27
	uaddw.2d	v24, v1, v8
	uaddw2.2d	v25, v1, v8
	and.16b	v19, v19, v2
	and.16b	v26, v31, v2
	and.16b	v21, v21, v2
	and.16b	v20, v20, v2
	and.16b	v23, v23, v2
	and.16b	v22, v22, v2
	and.16b	v25, v25, v2
	and.16b	v24, v24, v2
	add.2d	v0, v0, v3
	add.2d	v0, v0, v19
	add.2d	v4, v4, v3
	add.2d	v4, v4, v26
	add.2d	v7, v7, v3
	add.2d	v7, v7, v21
	add.2d	v6, v6, v3
	add.2d	v6, v6, v20
	add.2d	v18, v18, v3
	add.2d	v18, v18, v23
	add.2d	v5, v5, v3
	add.2d	v5, v5, v22
	add.2d	v17, v17, v3
	add.2d	v17, v17, v25
	add.2d	v16, v16, v3
	add.2d	v16, v16, v24
	add	x12, x12, #256
	subs	x13, x13, #16
	b.ne	LBB3_7
; %bb.8:
	add.2d	v1, v6, v4
	add.2d	v0, v7, v0
	add.2d	v0, v18, v0
	add.2d	v1, v5, v1
	add.2d	v1, v16, v1
	add.2d	v0, v17, v0
	add.2d	v0, v1, v0
	addp.2d	d0, v0
	fmov	x1, d0
	cmp	x11, #5
	b.lo	LBB3_12
LBB3_9:
	mov	x11, x10
	ands	x10, x8, #0x3
	mov	w12, #4                         ; =0x4
	csel	x12, x12, x10, eq
	movi.2d	v0, #0000000000000000
	mov.d	v0[0], x1
	add	x13, x9, x11, lsl #4
	sub	x10, x8, x12
	movi.2d	v1, #0000000000000000
	add	x11, x12, x11
	sub	x11, x11, x8
	add	x12, x13, #4
	mov	w13, #3                         ; =0x3
	dup.2d	v2, x13
	mov	x13, #8589934588                ; =0x1fffffffc
	dup.2d	v3, x13
	mov	w13, #8                         ; =0x8
	dup.2d	v4, x13
LBB3_10:                                ; =>This Inner Loop Header: Depth=1
	ld4.4s	{ v16, v17, v18, v19 }, [x12], #64
	uaddw.2d	v5, v2, v16
	uaddw2.2d	v6, v2, v16
	and.16b	v6, v6, v3
	and.16b	v5, v5, v3
	add.2d	v1, v1, v4
	add.2d	v1, v1, v6
	add.2d	v0, v0, v4
	add.2d	v0, v0, v5
	adds	x11, x11, #4
	b.ne	LBB3_10
; %bb.11:
	add.2d	v0, v0, v1
	addp.2d	d0, v0
	fmov	x1, d0
LBB3_12:
	sub	x8, x8, x10
	add	x9, x9, x10, lsl #4
	add	x9, x9, #4
LBB3_13:                                ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9], #16
	add	x10, x10, #3
	and	x10, x10, #0x1fffffffc
	add	x10, x1, x10
	add	x1, x10, #8
	subs	x8, x8, #1
	b.ne	LBB3_13
LBB3_14:
	cmp	x2, x1
	b.hs	LBB3_16
; %bb.15:
	mov	w0, #1                          ; =0x1
	b	LBB3_23
LBB3_16:
	mov	x0, x19
	bl	_bzero
	ldr	w8, [x20, #8]
	strb	w8, [x19]
	ldr	w8, [x20, #8]
	lsr	w8, w8, #8
	strb	w8, [x19, #1]
	ldrh	w8, [x20, #10]
	strb	w8, [x19, #2]
	ldrb	w8, [x20, #11]
	strb	w8, [x19, #3]
	ldr	w8, [x20, #8]
	cbz	w8, LBB3_22
; %bb.17:
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	mov	w8, #4                          ; =0x4
	b	LBB3_20
LBB3_18:                                ;   in Loop: Header=BB3_20 Depth=1
	ldr	x8, [x20]
	add	x8, x8, x22
	ldr	x1, [x8, #8]
	add	x0, x19, x24
	mov	x2, x21
	bl	_memcpy
	add	x8, x21, #3
	and	x8, x8, #0x1fffffffc
LBB3_19:                                ;   in Loop: Header=BB3_20 Depth=1
	add	x8, x8, x24
	add	x23, x23, #1
	ldr	w9, [x20, #8]
	add	x22, x22, #16
	cmp	x23, x9
	b.hs	LBB3_22
LBB3_20:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x20]
	add	x9, x9, x22
	ldr	w21, [x9, #4]
	ldrb	w9, [x9]
	add	x10, x19, x8
	strb	w9, [x10]
	strb	w21, [x10, #4]
	lsr	w9, w21, #8
	strb	w9, [x10, #5]
	lsr	w9, w21, #16
	strb	w9, [x10, #6]
	lsr	w9, w21, #24
	add	x24, x8, #8
	strb	w9, [x10, #7]
	cbnz	w21, LBB3_18
; %bb.21:                               ;   in Loop: Header=BB3_20 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB3_19
LBB3_22:
	mov	w0, #0                          ; =0x0
LBB3_23:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
