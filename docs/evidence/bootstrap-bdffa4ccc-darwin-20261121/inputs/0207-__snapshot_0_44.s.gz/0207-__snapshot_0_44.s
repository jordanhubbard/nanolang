	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nl_ws_transport_storage_bound  ; -- Begin function nl_ws_transport_storage_bound
	.p2align	2
_nl_ws_transport_storage_bound:         ; @nl_ws_transport_storage_bound
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_8
; %bb.1:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x0, sp, #8
	bl	_nl_ws_decoder_storage_bound
	cbz	w0, LBB0_7
; %bb.2:
	mov	x0, sp
	bl	_nl_socket_service_storage_bound
	cbz	w0, LBB0_7
; %bb.3:
	mov	x9, #-4255                      ; =0xffffffffffffef61
	movk	x9, #65519, lsl #16
	ldr	x8, [sp, #8]
	cmp	x8, x9
	b.hi	LBB0_5
; %bb.4:
	ldr	x10, [sp]
	sub	x9, x9, x8
	cmp	x10, x9
	b.ls	LBB0_6
LBB0_5:
	mov	w0, #0                          ; =0x0
	b	LBB0_7
LBB0_6:
	add	x8, x8, x10
	add	x8, x8, #257, lsl #12           ; =1052672
	add	x8, x8, #158
	str	x8, [x19]
	mov	w0, #1                          ; =0x1
LBB0_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
LBB0_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_connect        ; -- Begin function nl_ws_transport_connect
	.p2align	2
_nl_ws_transport_connect:               ; @nl_ws_transport_connect
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #4224                       ; =0x1080
Lloh0:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh1:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x8
	sub	x28, x29, #144
Lloh2:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh3:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh4:
	ldr	x8, [x8]
	stur	x8, [x29, #-104]
	stur	wzr, [x29, #-112]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x28]
	sub	x8, x1, #2048
	cmn	x8, #2047
	b.lo	LBB1_5
; %bb.1:
	mov	x24, x0
	cbz	x0, LBB1_5
; %bb.2:
	mov	x21, x2
	cbz	x2, LBB1_5
; %bb.3:
	mov	x20, x4
	cbz	x4, LBB1_5
; %bb.4:
	mov	x22, x3
	mov	x23, x1
	mov	x0, x24
	mov	w1, #0                          ; =0x0
	mov	x2, x23
	bl	_memchr
	movi.2d	v0, #0000000000000000
	cbz	x0, LBB1_10
LBB1_5:
	mov	w8, #1                          ; =0x1
LBB1_6:
	str	w8, [x19]
LBB1_7:
	stur	q0, [x19, #4]
	stur	q0, [x19, #20]
	str	wzr, [x19, #36]
LBB1_8:
	ldur	x8, [x29, #-104]
Lloh5:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh6:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh7:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB1_66
; %bb.9:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #128
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB1_10:
	ldrb	w8, [x21]
	tbz	w8, #0, LBB1_23
; %bb.11:
	ldr	w8, [x21, #16]
	mov	w9, #60000                      ; =0xea60
	cmp	w8, w9
	b.hi	LBB1_24
; %bb.12:
	cmp	w22, w8
	b.hi	LBB1_24
; %bb.13:
	add	x25, sp, #2112
	add	x0, sp, #2112
	mov	x1, x24
	mov	x2, x23
	mov	w3, #2048                       ; =0x800
	bl	___memcpy_chk
	strb	wzr, [x25, x23]
	ldr	w8, [sp, #2112]
	ldrb	w9, [sp, #2116]
	mov	w10, #29559                     ; =0x7377
	movk	w10, #12090, lsl #16
	cmp	w8, w10
	mov	w8, #47                         ; =0x2f
	ccmp	w9, w8, #0, eq
	b.ne	LBB1_27
; %bb.14:
	add	x0, sp, #2112
	mov	w1, #2048                       ; =0x800
	bl	_strnlen
	cmp	x0, #2048
	b.eq	LBB1_27
; %bb.15:
	cmp	x0, #6
	b.lo	LBB1_20
; %bb.16:
	sub	x8, x0, #5
	add	x9, sp, #2112
	add	x9, x9, #5
LBB1_17:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w10, [x9], #1
	cmp	w10, #35
	b.eq	LBB1_27
; %bb.18:                               ;   in Loop: Header=BB1_17 Depth=1
	sub	w10, w10, #127
	cmn	w10, #94
	b.lo	LBB1_27
; %bb.19:                               ;   in Loop: Header=BB1_17 Depth=1
	subs	x8, x8, #1
	b.ne	LBB1_17
LBB1_20:
	mov	x24, #0                         ; =0x0
	add	x8, sp, #40
	add	x9, x8, #535
	add	x8, x8, #534
	stp	x9, x8, [sp, #24]               ; 16-byte Folded Spill
	add	x8, sp, #2112
	add	x23, x8, #5
	mov	w8, #1                          ; =0x1
	mov	x9, #-9223372036854775807       ; =0x8000000000000001
	movk	x9, #32768, lsl #32
	mov	x25, x23
LBB1_21:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w27, [x23, x24]
	cmp	w27, #63
	lsl	x10, x8, x27
	and	x10, x10, x9
	ccmp	x10, #0, #4, ls
	b.ne	LBB1_25
; %bb.22:                               ;   in Loop: Header=BB1_21 Depth=1
	add	x25, x25, #1
	add	x24, x24, #1
	b	LBB1_21
LBB1_23:
	mov	w8, #2                          ; =0x2
	b	LBB1_6
LBB1_24:
	mov	w8, #4                          ; =0x4
	b	LBB1_6
LBB1_25:
	sub	x8, x24, #280
	cmn	x8, #279
	b.lo	LBB1_27
; %bb.26:
	mov	x0, x23
	mov	w1, #64                         ; =0x40
	mov	x2, x24
	bl	_memchr
	cbz	x0, LBB1_29
LBB1_27:
	mov	w8, #1                          ; =0x1
LBB1_28:
	str	w8, [x19]
	movi.2d	v0, #0000000000000000
	b	LBB1_7
LBB1_29:
	add	x26, x23, x24
	ldrb	w8, [sp, #2117]
	cmp	w8, #91
	str	x26, [sp, #8]                   ; 8-byte Folded Spill
	b.ne	LBB1_35
; %bb.30:
	add	x8, sp, #2112
	add	x0, x8, #6
	sub	x2, x24, #1
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	w1, #93                         ; =0x5d
	bl	_memchr
	cbz	x0, LBB1_27
; %bb.31:
	mov	x26, x0
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	sub	x2, x26, x0
	str	x2, [sp]                        ; 8-byte Folded Spill
	mov	w1, #58                         ; =0x3a
	bl	_memchr
	ldr	x13, [sp]                       ; 8-byte Folded Reload
	cbz	x0, LBB1_27
; %bb.32:
	add	x8, x26, #1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	cmp	x8, x9
	b.hs	LBB1_45
; %bb.33:
	ldrb	w8, [x8]
	cmp	w8, #58
	b.ne	LBB1_27
; %bb.34:
	add	x8, x26, #2
	b	LBB1_36
LBB1_35:
	mov	x0, x23
	mov	w1, #58                         ; =0x3a
	mov	x2, x24
	bl	_memchr
	cmp	x0, #0
	csel	x26, x26, x0, eq
	csinc	x8, xzr, x0, eq
	sub	x13, x26, x23
	str	x23, [sp, #16]                  ; 8-byte Folded Spill
LBB1_36:
	cmp	x13, #253
	b.hi	LBB1_27
; %bb.37:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x26, x9
	b.eq	LBB1_27
; %bb.38:
	cbz	x8, LBB1_47
; %bb.39:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	cmp	x8, x9
	b.hs	LBB1_27
; %bb.40:
	mov	w26, #0                         ; =0x0
	sub	x9, x25, x8
	mov	w10, #10                        ; =0xa
LBB1_41:                                ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x8], #1
	sub	w12, w11, #58
	and	w12, w12, #0xff
	cmp	w12, #246
	b.lo	LBB1_27
; %bb.42:                               ;   in Loop: Header=BB1_41 Depth=1
	mul	w12, w26, w10
	sub	w11, w11, #48
	add	w26, w12, w11, uxtb
	lsr	w11, w26, #16
	cbnz	w11, LBB1_27
; %bb.43:                               ;   in Loop: Header=BB1_41 Depth=1
	subs	x9, x9, #1
	b.ne	LBB1_41
; %bb.44:
	cbnz	w26, LBB1_48
	b	LBB1_27
LBB1_45:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x26, x8
	b.eq	LBB1_27
; %bb.46:
	cmp	x13, #253
	b.hi	LBB1_27
LBB1_47:
	mov	w26, #80                        ; =0x50
LBB1_48:
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x25, x13
	bl	_strlen
	cmp	w27, #63
	str	x0, [sp]                        ; 8-byte Folded Spill
	cinc	x8, x0, eq
	cmp	x8, #1535
	b.hi	LBB1_27
; %bb.49:
	add	x0, sp, #40
	mov	w1, #2070                       ; =0x816
	bl	_bzero
	strh	w26, [sp, #2110]
	add	x0, sp, #40
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	w3, #2072                       ; =0x818
	bl	___memcpy_chk
	add	x8, sp, #40
	add	x0, x8, #254
	mov	x1, x23
	mov	x2, x24
	mov	w3, #1818                       ; =0x71a
	bl	___memcpy_chk
	cbz	w27, LBB1_53
; %bb.50:
	cmp	w27, #63
	b.ne	LBB1_52
; %bb.51:
	mov	w8, #47                         ; =0x2f
	strb	w8, [sp, #574]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
LBB1_52:
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldp	x2, x1, [sp]                    ; 16-byte Folded Reload
	mov	w3, #1538                       ; =0x602
	bl	___memcpy_chk
	b	LBB1_54
LBB1_53:
	mov	w8, #47                         ; =0x2f
	strh	w8, [sp, #574]
LBB1_54:
	cbz	w22, LBB1_59
; %bb.55:
	bl	_ws_now
	tbnz	x0, #63, LBB1_60
; %bb.56:
	mov	x24, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #4240                       ; =0x1090
	bl	_calloc
	cbz	x0, LBB1_61
; %bb.57:
	mov	x23, x0
	ldr	w8, [x21, #16]
	str	w8, [x0, #40]
	add	x0, x0, #32
	bl	_nl_ws_decoder_create
	cbz	w0, LBB1_62
; %bb.58:
	mov	w8, #6                          ; =0x6
	mov	w9, #3                          ; =0x3
	cmp	w0, #6
	csel	w8, w9, w8, eq
	str	w8, [x23, #64]
	ldrb	w8, [x23, #44]
	eor	w8, w8, #0x1
	strb	w8, [x23, #90]
	ldur	d0, [x23, #52]
	rev64.2s	v0, v0
	str	d0, [x23, #80]
	ldurh	w8, [x23, #49]
	strh	w8, [x23, #88]
	b	LBB1_65
LBB1_59:
	mov	w8, #5                          ; =0x5
	b	LBB1_28
LBB1_60:
	mov	w8, #6                          ; =0x6
	b	LBB1_28
LBB1_61:
	mov	w8, #3                          ; =0x3
	b	LBB1_28
LBB1_62:
	add	x22, x24, w22, uxtw
	add	x1, sp, #40
	mov	x0, x23
	mov	x2, x21
	mov	x3, x22
	bl	_ws_connect_socket
	cbz	w0, LBB1_65
; %bb.63:
	add	x1, sp, #40
	mov	x0, x23
	mov	x2, x22
	bl	_ws_handshake
	cbz	w0, LBB1_65
; %bb.64:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #64]
	str	xzr, [x23, #96]
	mov	w8, #1                          ; =0x1
	strb	w8, [x23, #44]
	str	x23, [x20]
	strb	wzr, [x23, #90]
	ldur	d0, [x23, #52]
	rev64.2s	v0, v0
	str	d0, [x23, #80]
	ldurh	w8, [x23, #49]
	strh	w8, [x23, #88]
	str	xzr, [x19, #32]
	ldp	q0, q1, [x23, #64]
	stp	q0, q1, [x19]
	b	LBB1_8
LBB1_65:
	mov	x0, x23
	bl	_ws_release
	ldr	w20, [x23, #64]
	ldrb	w8, [x23, #44]
	eor	w8, w8, #0x1
	strb	w8, [x23, #90]
	ldur	d0, [x23, #52]
	rev64.2s	v0, v0
	str	d0, [x23, #80]
	ldurh	w8, [x23, #49]
	strh	w8, [x23, #88]
	ldr	w8, [x23, #100]
	stur	w8, [x29, #-112]
	ldur	q0, [x23, #68]
	ldur	q1, [x23, #84]
	stp	q0, q1, [x28]
	ldr	x0, [x23, #32]
	bl	_nl_ws_decoder_destroy
	mov	x0, x23
	bl	_free
	str	w20, [x19]
	ldp	q0, q1, [x28]
	stur	q0, [x19, #4]
	stur	q1, [x19, #20]
	ldur	w8, [x29, #-112]
	str	w8, [x19, #36]
	b	LBB1_8
LBB1_66:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh2, Lloh3, Lloh4
	.loh AdrpLdrGotLdr	Lloh5, Lloh6, Lloh7
	.loh AdrpLdrGot	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_now
_ws_now:                                ; @ws_now
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB2_2
; %bb.1:
	mov	x0, #-1                         ; =0xffffffffffffffff
	b	LBB2_3
LBB2_2:
	mov	w8, #1000                       ; =0x3e8
	ldp	x9, x10, [sp]
	mov	x11, #13531                     ; =0x34db
	movk	x11, #55222, lsl #16
	movk	x11, #56962, lsl #32
	movk	x11, #17179, lsl #48
	smulh	x10, x10, x11
	asr	x11, x10, #18
	add	x10, x11, x10, lsr #63
	madd	x0, x9, x8, x10
LBB2_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_connect_socket
_ws_connect_socket:                     ; @ws_connect_socket
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #592
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x22, x2
	mov	x21, x1
	mov	x19, x0
	sub	x8, x29, #128
	bl	_nl_socket_service_create
	ldur	w8, [x29, #-128]
	cbz	w8, LBB3_4
; %bb.1:
	ldp	w12, w13, [x29, #-124]
	ldurb	w11, [x29, #-94]
	ldurb	w10, [x29, #-93]
	str	w12, [x19, #68]
	ldr	w9, [x19, #52]
	cbnz	w9, LBB3_3
; %bb.2:
	cmp	w13, #0
	cset	w9, eq
	orr	w14, w11, w10
	tst	w9, w14
	csel	w9, w12, w13, ne
	str	w9, [x19, #52]
LBB3_3:
	mov	w0, #0                          ; =0x0
	ldrb	w12, [x19, #49]
	orr	w11, w12, w11
	strb	w11, [x19, #49]
	ldrb	w12, [x19, #50]
	orr	w10, w12, w10
	strb	w10, [x19, #50]
	and	w12, w8, #0xfffffffe
	mov	w13, #6                         ; =0x6
	mov	w14, #4                         ; =0x4
	cmp	w12, #8
	csel	w12, w14, w13, eq
	mov	w13, #3                         ; =0x3
	cmp	w8, #10
	csel	w8, w13, w12, eq
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldr	w8, [x19, #56]
	stp	w8, w9, [x19, #80]
	strb	w11, [x19, #88]
	strb	w10, [x19, #89]
	b	LBB3_48
LBB3_4:
	ldr	x23, [x19]
	mov	x0, x21
	bl	_strlen
	mov	x2, x0
	ldrh	w3, [x21, #2070]
	add	x5, sp, #88
	mov	x0, x23
	mov	x1, x21
	mov	w4, #0                          ; =0x0
	bl	_nl_socket_resolve_tcp
	cbz	w0, LBB3_10
; %bb.5:
	cmp	w0, #7
	b.ne	LBB3_31
; %bb.6:
	ldrb	w8, [x22, #1]
	tbz	w8, #0, LBB3_32
; %bb.7:
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB3_33
; %bb.8:
	mov	w8, #1000                       ; =0x3e8
	ldp	x9, x10, [sp, #48]
	mov	x11, #13531                     ; =0x34db
	movk	x11, #55222, lsl #16
	movk	x11, #56962, lsl #32
	movk	x11, #17179, lsl #48
	smulh	x10, x10, x11
	asr	x11, x10, #18
	add	x10, x11, x10, lsr #63
	madd	x24, x9, x8, x10
	cmp	x20, x24
	b.ls	LBB3_33
; %bb.9:
	ldr	x23, [x19]
	mov	x0, x21
	bl	_strlen
	mov	x2, x0
	ldrh	w3, [x21, #2070]
	ldr	x5, [x22, #8]
	sub	w6, w20, w24
	add	x22, sp, #48
	add	x8, sp, #48
	add	x7, sp, #88
	mov	x0, x23
	mov	x1, x21
	mov	w4, #1                          ; =0x1
	bl	_nl_socket_resolve_tcp_supervised
	ldr	w9, [sp, #60]
	add	x8, x22, #8
	add	x10, x22, #16
	cmp	w9, #0
	csel	x8, x8, x10, eq
	ldr	w10, [x8]
	ldp	w8, w11, [sp, #48]
	stp	w10, w11, [x19, #68]
	str	w9, [x19, #76]
	orr	w10, w9, w8
	cbnz	w10, LBB3_39
LBB3_10:
	ldr	x8, [sp, #88]
	cbz	x8, LBB3_30
; %bb.11:
	mov	x21, #0                         ; =0x0
	add	x8, sp, #88
	add	x22, x8, #8
	mov	w24, #1000                      ; =0x3e8
	mov	x25, #13531                     ; =0x34db
	movk	x25, #55222, lsl #16
	movk	x25, #56962, lsl #32
	movk	x25, #17179, lsl #48
	mov	w26, #28                        ; =0x1c
	mov	w27, #3                         ; =0x3
	mov	w28, #4                         ; =0x4
Lloh8:
	adrp	x23, l___const.ws_wait.pause@PAGE
Lloh9:
	add	x23, x23, l___const.ws_wait.pause@PAGEOFF
LBB3_12:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_21 Depth 2
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB3_36
; %bb.13:                               ;   in Loop: Header=BB3_12 Depth=1
	ldp	x8, x9, [sp, #48]
	smulh	x9, x9, x25
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	cmp	x8, x20
	b.hs	LBB3_36
; %bb.14:                               ;   in Loop: Header=BB3_12 Depth=1
	ldr	x0, [x19]
	madd	x1, x21, x26, x22
	add	x8, sp, #48
	add	x3, x19, #8
	mov	w2, #3                          ; =0x3
	bl	_nl_socket_acquire_tcp
	ldrb	w9, [sp, #82]
	ldrb	w8, [sp, #83]
	tbnz	w9, #0, LBB3_37
; %bb.15:                               ;   in Loop: Header=BB3_12 Depth=1
	tbnz	w8, #0, LBB3_37
; %bb.16:                               ;   in Loop: Header=BB3_12 Depth=1
	ldr	w8, [sp, #48]
	cbz	w8, LBB3_20
; %bb.17:                               ;   in Loop: Header=BB3_12 Depth=1
	ldp	w9, w10, [sp, #52]
	str	w9, [x19, #68]
	ldr	w9, [x19, #52]
	cbnz	w9, LBB3_19
; %bb.18:                               ;   in Loop: Header=BB3_12 Depth=1
	str	w10, [x19, #52]
	mov	x9, x10
LBB3_19:                                ;   in Loop: Header=BB3_12 Depth=1
	ldurh	w10, [x19, #49]
	and	w11, w8, #0xfffffffe
	cmp	w11, #8
	mov	w11, #6                         ; =0x6
	csel	w11, w28, w11, eq
	cmp	w8, #10
	csel	w8, w27, w11, eq
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldr	w8, [x19, #56]
	stp	w8, w9, [x19, #80]
	strh	w10, [x19, #88]
	b	LBB3_28
LBB3_20:                                ;   in Loop: Header=BB3_12 Depth=1
	ldr	x0, [x19]
	mov	x8, sp
	add	x1, x19, #8
	bl	_nl_socket_finish_connect
	ldp	q0, q1, [sp]
	stp	q0, q1, [sp, #48]
	ldr	x8, [sp, #32]
	str	x8, [sp, #80]
	ldr	w8, [sp, #48]
	cbz	w8, LBB3_35
LBB3_21:                                ;   Parent Loop BB3_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w8, w8, #0xfffffffe
	cmp	w8, #2
	b.ne	LBB3_25
; %bb.22:                               ;   in Loop: Header=BB3_21 Depth=2
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB3_25
; %bb.23:                               ;   in Loop: Header=BB3_21 Depth=2
	ldp	x8, x9, [sp]
	smulh	x9, x9, x25
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	cmp	x8, x20
	b.hs	LBB3_25
; %bb.24:                               ;   in Loop: Header=BB3_21 Depth=2
	ldr	q0, [x23]
	str	q0, [sp]
	mov	x0, sp
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	ldr	x0, [x19]
	mov	x8, sp
	add	x1, x19, #8
	bl	_nl_socket_finish_connect
	ldp	q0, q1, [sp]
	stp	q0, q1, [sp, #48]
	ldr	x8, [sp, #32]
	str	x8, [sp, #80]
	ldr	w8, [sp, #48]
	cbnz	w8, LBB3_21
	b	LBB3_35
LBB3_25:                                ;   in Loop: Header=BB3_12 Depth=1
	ldp	w11, w12, [sp, #52]
	ldrb	w10, [sp, #82]
	ldrb	w9, [sp, #83]
	str	w11, [x19, #68]
	ldr	w8, [x19, #52]
	cbnz	w8, LBB3_27
; %bb.26:                               ;   in Loop: Header=BB3_12 Depth=1
	cmp	w12, #0
	cset	w8, eq
	orr	w13, w10, w9
	tst	w8, w13
	csel	w8, w11, w12, ne
	str	w8, [x19, #52]
LBB3_27:                                ;   in Loop: Header=BB3_12 Depth=1
	ldrb	w11, [x19, #49]
	orr	w10, w11, w10
	strb	w10, [x19, #49]
	ldrb	w11, [x19, #50]
	orr	w9, w11, w9
	strb	w9, [x19, #50]
	ldr	w11, [sp, #48]
	and	w12, w11, #0xfffffffe
	cmp	w12, #8
	mov	w13, #6                         ; =0x6
	csel	w13, w28, w13, eq
	cmp	w11, #10
	csel	w11, w27, w13, eq
	cmp	w12, #2
	mov	w12, #5                         ; =0x5
	csel	w11, w12, w11, eq
	str	w11, [x19, #64]
	ldrb	w11, [x19, #44]
	eor	w11, w11, #0x1
	strb	w11, [x19, #90]
	ldr	w11, [x19, #56]
	stp	w11, w8, [x19, #80]
	strb	w10, [x19, #88]
	strb	w9, [x19, #89]
	ldr	x0, [x19]
	mov	x8, sp
	add	x1, x19, #8
	bl	_nl_socket_consume_close
	ldp	q0, q1, [sp]
	stp	q0, q1, [sp, #48]
	ldr	x8, [sp, #32]
	str	x8, [sp, #80]
	ldr	w8, [sp, #48]
	cbnz	w8, LBB3_42
LBB3_28:                                ;   in Loop: Header=BB3_12 Depth=1
	add	x21, x21, #1
	ldr	x8, [sp, #88]
	cmp	x21, x8
	b.lo	LBB3_12
; %bb.29:
	mov	w8, #0                          ; =0x0
LBB3_30:
	mov	w10, #0                         ; =0x0
	b	LBB3_47
LBB3_31:
	mov	w0, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	b	LBB3_34
LBB3_32:
	mov	w0, #0                          ; =0x0
	mov	w8, #2                          ; =0x2
	b	LBB3_34
LBB3_33:
	mov	w0, #0                          ; =0x0
	mov	w8, #5                          ; =0x5
LBB3_34:
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
	b	LBB3_48
LBB3_35:
	mov	w10, #1                         ; =0x1
	b	LBB3_46
LBB3_36:
	mov	w10, #0                         ; =0x0
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
	b	LBB3_46
LBB3_37:
	ldp	w10, w12, [sp, #52]
	str	w10, [x19, #68]
	ldr	w11, [x19, #52]
	cbnz	w11, LBB3_45
; %bb.38:
	cmp	w12, #0
	csel	w11, w10, w12, eq
	b	LBB3_44
LBB3_39:
	cmp	w9, #1
	b.eq	LBB3_49
; %bb.40:
	cmp	w9, #3
	b.ne	LBB3_50
; %bb.41:
	mov	w8, #5                          ; =0x5
	b	LBB3_51
LBB3_42:
	ldp	w10, w12, [sp, #52]
	ldrb	w9, [sp, #82]
	ldrb	w8, [sp, #83]
	str	w10, [x19, #68]
	ldr	w11, [x19, #52]
	cbnz	w11, LBB3_45
; %bb.43:
	cmp	w12, #0
	cset	w11, eq
	orr	w13, w9, w8
	tst	w11, w13
	csel	w11, w10, w12, ne
LBB3_44:
	str	w11, [x19, #52]
LBB3_45:
	mov	w10, #0                         ; =0x0
	ldrb	w12, [x19, #49]
	orr	w9, w12, w9
	strb	w9, [x19, #49]
	ldrb	w12, [x19, #50]
	orr	w8, w12, w8
	strb	w8, [x19, #50]
	mov	w12, #6                         ; =0x6
	str	w12, [x19, #64]
	ldrb	w12, [x19, #44]
	eor	w12, w12, #0x1
	strb	w12, [x19, #90]
	ldr	w12, [x19, #56]
	stp	w12, w11, [x19, #80]
	strb	w9, [x19, #88]
	strb	w8, [x19, #89]
LBB3_46:
	mov	w8, #1                          ; =0x1
LBB3_47:
	and	w0, w8, w10
LBB3_48:
	add	sp, sp, #592
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB3_49:
	mov	w8, #1                          ; =0x1
	b	LBB3_51
LBB3_50:
	and	w9, w8, #0xfffffffe
	mov	w10, #6                         ; =0x6
	mov	w11, #4                         ; =0x4
	cmp	w9, #8
	csel	w9, w11, w10, eq
	mov	w10, #3                         ; =0x3
	cmp	w8, #10
	csel	w8, w10, w9, eq
LBB3_51:
	mov	w0, #0                          ; =0x0
	b	LBB3_34
	.loh AdrpAdd	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_handshake
_ws_handshake:                          ; @ws_handshake
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #10416                      ; =0x28b0
Lloh10:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh11:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #2224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
Lloh12:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	sub	x0, x29, #112
	mov	w1, #16                         ; =0x10
	bl	_RAND_bytes
	cmp	w0, #1
	b.ne	LBB4_2
; %bb.1:
	sub	x22, x29, #137
	sub	x0, x29, #112
	sub	x1, x29, #137
	sub	x2, x29, #166
	bl	_nl_ws_handshake_key
	cbz	w0, LBB4_6
LBB4_2:
	mov	w0, #0                          ; =0x0
	mov	w8, #8                          ; =0x8
LBB4_3:
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
LBB4_4:
	ldur	x8, [x29, #-96]
Lloh15:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh16:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh17:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB4_27
; %bb.5:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #2224
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB4_6:
	add	x8, x21, #534
	add	x9, x21, #254
	stp	x9, x22, [sp, #8]
	str	x8, [sp]
Lloh18:
	adrp	x2, l_.str.13@PAGE
Lloh19:
	add	x2, x2, l_.str.13@PAGEOFF
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #90
	mov	w1, #2048                       ; =0x800
	bl	_snprintf
	cmp	w0, #2048
	b.lo	LBB4_8
LBB4_7:
	mov	w0, #0                          ; =0x0
	mov	w8, #4                          ; =0x4
	b	LBB4_3
LBB4_8:
	mov	w2, w0
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #90
	mov	x0, x19
	mov	x3, x20
	bl	_ws_send_bytes
	cbz	w0, LBB4_4
; %bb.9:
	mov	x25, #0                         ; =0x0
	add	x22, sp, #90
	sub	x23, x22, #4
	mov	w24, #1000                      ; =0x3e8
	mov	x26, #13531                     ; =0x34db
	movk	x26, #55222, lsl #16
	movk	x26, #56962, lsl #32
	movk	x26, #17179, lsl #48
	mov	w27, #2573                      ; =0xa0d
	movk	w27, #2573, lsl #16
Lloh20:
	adrp	x28, l___const.ws_wait.pause@PAGE
Lloh21:
	add	x28, x28, l___const.ws_wait.pause@PAGEOFF
	b	LBB4_11
LBB4_10:                                ;   in Loop: Header=BB4_11 Depth=1
	mov	x25, x21
	cmp	x25, #2, lsl #12                ; =8192
	b.hs	LBB4_7
LBB4_11:                                ; =>This Inner Loop Header: Depth=1
	add	x1, sp, #24
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB4_21
; %bb.12:                               ;   in Loop: Header=BB4_11 Depth=1
	ldp	x8, x9, [sp, #24]
	smulh	x9, x9, x26
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	cmp	x8, x20
	b.hs	LBB4_21
; %bb.13:                               ;   in Loop: Header=BB4_11 Depth=1
	ldr	x0, [x19]
	add	x8, sp, #24
	add	x1, x19, #8
	add	x2, x22, x25
	mov	w3, #1                          ; =0x1
	bl	_nl_socket_receive
	ldr	w8, [sp, #24]
	cbnz	w8, LBB4_17
; %bb.14:                               ;   in Loop: Header=BB4_11 Depth=1
	ldr	x9, [sp, #40]
	cmp	x9, #1
	b.ne	LBB4_17
; %bb.15:                               ;   in Loop: Header=BB4_11 Depth=1
	add	x21, x25, #1
	cmp	x25, #3
	b.lo	LBB4_10
; %bb.16:                               ;   in Loop: Header=BB4_11 Depth=1
	ldr	w8, [x23, x21]
	cmp	w8, w27
	b.ne	LBB4_10
	b	LBB4_25
LBB4_17:                                ;   in Loop: Header=BB4_11 Depth=1
	sub	w8, w8, #4
	cmn	w8, #3
	b.ls	LBB4_22
; %bb.18:                               ;   in Loop: Header=BB4_11 Depth=1
	add	x1, sp, #64
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB4_21
; %bb.19:                               ;   in Loop: Header=BB4_11 Depth=1
	ldp	x8, x9, [sp, #64]
	smulh	x9, x9, x26
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	cmp	x8, x20
	b.hs	LBB4_21
; %bb.20:                               ;   in Loop: Header=BB4_11 Depth=1
	ldr	q0, [x28]
	str	q0, [sp, #64]
	add	x0, sp, #64
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	cmp	x25, #2, lsl #12                ; =8192
	b.lo	LBB4_11
	b	LBB4_7
LBB4_21:
	mov	w0, #0                          ; =0x0
	mov	w8, #5                          ; =0x5
	b	LBB4_3
LBB4_22:
	ldp	w11, w12, [sp, #28]
	ldrb	w10, [sp, #58]
	ldrb	w8, [sp, #59]
	str	w11, [x19, #68]
	ldr	w9, [x19, #52]
	cbnz	w9, LBB4_24
; %bb.23:
	cmp	w12, #0
	cset	w9, eq
	orr	w13, w10, w8
	tst	w9, w13
	csel	w9, w11, w12, ne
	str	w9, [x19, #52]
LBB4_24:
	mov	w0, #0                          ; =0x0
	ldrb	w11, [x19, #49]
	orr	w10, w11, w10
	strb	w10, [x19, #49]
	ldrb	w11, [x19, #50]
	orr	w8, w11, w8
	strb	w8, [x19, #50]
	mov	w11, #6                         ; =0x6
	str	w11, [x19, #64]
	ldrb	w11, [x19, #44]
	eor	w11, w11, #0x1
	strb	w11, [x19, #90]
	ldr	w11, [x19, #56]
	stp	w11, w9, [x19, #80]
	strb	w10, [x19, #88]
	strb	w8, [x19, #89]
	b	LBB4_4
LBB4_25:
	str	xzr, [sp, #64]
	add	x0, sp, #90
	sub	x2, x29, #166
	add	x3, sp, #64
	mov	x1, x21
	bl	_nl_ws_upgrade_validate
	cmp	w0, #0
	ldr	x8, [sp, #64]
	ccmp	x8, x21, #0, eq
	cset	w0, eq
	b.eq	LBB4_4
; %bb.26:
	mov	w8, #7                          ; =0x7
	b	LBB4_3
LBB4_27:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh15, Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpLdrGot	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_release
_ws_release:                            ; @ws_release
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	strb	wzr, [x0, #44]
	ldr	x0, [x0]
	cbz	x0, LBB5_6
; %bb.1:
	add	x8, sp, #8
	bl	_nl_socket_service_destroy
	str	xzr, [x19]
	ldr	w9, [x19, #68]
	ldp	w11, w12, [sp, #12]
	ldrb	w8, [sp, #42]
	ldrb	w10, [sp, #43]
	str	w11, [x19, #68]
	ldr	w13, [x19, #52]
	cbnz	w13, LBB5_3
; %bb.2:
	cmp	w12, #0
	cset	w13, eq
	orr	w14, w8, w10
	tst	w13, w14
	csel	w11, w11, w12, ne
	str	w11, [x19, #52]
LBB5_3:
	ldrb	w11, [x19, #49]
	ldrb	w12, [x19, #50]
	orr	w10, w12, w10
	strb	w10, [x19, #50]
	cbz	w9, LBB5_5
; %bb.4:
	str	w9, [x19, #68]
LBB5_5:
	ldr	w9, [sp, #8]
	cmp	w9, #0
	csinc	w9, w11, wzr, eq
	orr	w8, w9, w8
	strb	w8, [x19, #49]
LBB5_6:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_send           ; -- Begin function nl_ws_transport_send
	.p2align	2
_nl_ws_transport_send:                  ; @nl_ws_transport_send
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	movi.2d	v0, #0000000000000000
	cbz	x0, LBB6_5
; %bb.1:
	mov	x21, x0
	str	q0, [x21, #64]!
	str	xzr, [x21, #32]
	str	q0, [x21, #16]
	ldurb	w9, [x21, #-20]
	tbz	w9, #0, LBB6_6
; %bb.2:
	cbnz	x2, LBB6_10
; %bb.3:
	cbz	x3, LBB6_10
; %bb.4:
	mov	w9, #1                          ; =0x1
	str	w9, [x0, #64]
	b	LBB6_8
LBB6_5:
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	b	LBB6_9
LBB6_6:
	mov	w9, #9                          ; =0x9
	str	w9, [x0, #64]
	mov	w9, #1                          ; =0x1
LBB6_7:
	strb	w9, [x0, #90]
LBB6_8:
	ldur	d0, [x0, #52]
	rev64.2s	v0, v0
	str	d0, [x0, #80]
	ldurh	w9, [x0, #49]
	strh	w9, [x0, #88]
	ldp	q0, q1, [x21]
	stp	q0, q1, [x8]
	ldr	x9, [x21, #32]
	str	x9, [x8, #32]
LBB6_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB6_10:
	mov	w9, #60000                      ; =0xea60
	cmp	w4, w9
	b.hi	LBB6_15
; %bb.11:
	ldr	w9, [x0, #40]
	cmp	w4, w9
	b.hi	LBB6_15
; %bb.12:
	mov	x24, x1
	mov	x25, x4
	mov	x20, x2
	mov	x19, x3
	mov	x23, x0
	mov	x22, x8
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB6_16
; %bb.13:
	mov	x8, x22
	mov	x0, x23
LBB6_14:
	mov	w9, #6                          ; =0x6
	str	w9, [x0, #64]
	ldrb	w9, [x0, #44]
	eor	w9, w9, #0x1
	b	LBB6_7
LBB6_15:
	mov	w9, #4                          ; =0x4
	str	w9, [x21]
	b	LBB6_8
LBB6_16:
	mov	w8, #1000                       ; =0x3e8
	ldp	x9, x10, [sp]
	mov	x11, #13531                     ; =0x34db
	movk	x11, #55222, lsl #16
	movk	x11, #56962, lsl #32
	movk	x11, #17179, lsl #48
	smulh	x10, x10, x11
	asr	x11, x10, #18
	add	x10, x11, x10, lsr #63
	madd	x9, x9, x8, x10
	mov	x8, x22
	mov	x0, x23
	tbnz	x9, #63, LBB6_14
; %bb.17:
	add	x4, x9, w25, uxtw
	cmp	w24, #0
	mov	w8, #1                          ; =0x1
	cinc	w1, w8, ne
	mov	x2, x20
	mov	x3, x19
	bl	_ws_send_frame
	tbz	w0, #0, LBB6_19
; %bb.18:
	str	x19, [x23, #96]
	str	wzr, [x23, #64]
LBB6_19:
	ldrb	w8, [x23, #44]
	eor	w8, w8, #0x1
	strb	w8, [x23, #90]
	ldur	d0, [x23, #52]
	rev64.2s	v0, v0
	str	d0, [x23, #80]
	ldurh	w8, [x23, #49]
	strh	w8, [x23, #88]
	ldp	q0, q1, [x21]
	stp	q0, q1, [x22]
	ldr	x8, [x21, #32]
	str	x8, [x22, #32]
	b	LBB6_9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_send_frame
_ws_send_frame:                         ; @ws_send_frame
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	cmp	x3, #256, lsl #12               ; =1048576
	b.ls	LBB7_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	mov	w8, #4                          ; =0x4
	b	LBB7_9
LBB7_2:
	mov	x23, x3
	mov	x21, x1
	mov	x24, x2
	mov	x22, x4
	add	x0, sp, #20
	mov	w1, #4                          ; =0x4
	bl	_RAND_bytes
	cmp	w0, #1
	b.ne	LBB7_7
; %bb.3:
	str	xzr, [sp, #8]
	add	x0, x23, #14
	bl	_malloc
	cbz	x0, LBB7_8
; %bb.4:
	mov	x20, x0
	add	x3, sp, #20
	add	x5, x23, #14
	add	x6, sp, #8
	mov	x0, x21
	mov	x1, x24
	mov	x2, x23
	mov	x4, x20
	bl	_nl_ws_client_frame
	cbz	w0, LBB7_11
; %bb.5:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
LBB7_6:
	mov	x0, x20
	bl	_free
	mov	w0, #0                          ; =0x0
	b	LBB7_10
LBB7_7:
	mov	w0, #0                          ; =0x0
	mov	w8, #8                          ; =0x8
	b	LBB7_9
LBB7_8:
	mov	w8, #3                          ; =0x3
LBB7_9:
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
LBB7_10:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB7_11:
	ldr	x2, [sp, #8]
	mov	x0, x19
	mov	x1, x20
	mov	x3, x22
	bl	_ws_send_bytes
	tbz	w0, #0, LBB7_14
; %bb.12:
	mov	x0, x20
	bl	_free
	mov	w0, #1                          ; =0x1
	cmp	w21, #8
	b.ne	LBB7_10
; %bb.13:
	strb	w0, [x19, #45]
	b	LBB7_10
LBB7_14:
	strb	wzr, [x19, #44]
	ldr	x0, [x19]
	cbz	x0, LBB7_6
; %bb.15:
	add	x8, sp, #24
	bl	_nl_socket_service_destroy
	str	xzr, [x19]
	ldr	w9, [x19, #68]
	ldp	w11, w12, [sp, #28]
	ldrb	w8, [sp, #58]
	ldrb	w10, [sp, #59]
	str	w11, [x19, #68]
	ldr	w13, [x19, #52]
	cbnz	w13, LBB7_17
; %bb.16:
	cmp	w12, #0
	cset	w13, eq
	orr	w14, w8, w10
	tst	w13, w14
	csel	w11, w11, w12, ne
	str	w11, [x19, #52]
LBB7_17:
	ldrb	w11, [x19, #49]
	ldrb	w12, [x19, #50]
	orr	w10, w12, w10
	strb	w10, [x19, #50]
	cbz	w9, LBB7_19
; %bb.18:
	str	w9, [x19, #68]
LBB7_19:
	ldr	w9, [sp, #24]
	cmp	w9, #0
	csinc	w9, w11, wzr, eq
	orr	w8, w9, w8
	strb	w8, [x19, #49]
	b	LBB7_6
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_receive        ; -- Begin function nl_ws_transport_receive
	.p2align	2
_nl_ws_transport_receive:               ; @nl_ws_transport_receive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB8_8
; %bb.1:
	cbz	x2, LBB8_8
; %bb.2:
	movi.2d	v0, #0000000000000000
	mov	x20, x0
	str	q0, [x20, #64]!
	str	xzr, [x20, #32]
	str	q0, [x20, #16]
	ldurb	w9, [x20, #-20]
	tbz	w9, #0, LBB8_10
; %bb.3:
	mov	w9, #60000                      ; =0xea60
	cmp	w1, w9
	b.hi	LBB8_13
; %bb.4:
	ldr	w9, [x0, #40]
	cmp	w1, w9
	b.hi	LBB8_13
; %bb.5:
	mov	x21, x1
	mov	x19, x2
	mov	x22, x0
	mov	x23, x8
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB8_16
; %bb.6:
	mov	x8, x23
	mov	x0, x22
LBB8_7:
	mov	w9, #6                          ; =0x6
	str	w9, [x0, #64]
	ldrb	w9, [x0, #44]
	eor	w9, w9, #0x1
	b	LBB8_11
LBB8_8:
	cbz	x0, LBB8_12
; %bb.9:
	mov	w9, #1                          ; =0x1
	str	w9, [x0, #64]
	ldrb	w9, [x0, #44]
	eor	w9, w9, #0x1
	strb	w9, [x0, #90]
	ldur	d0, [x0, #52]
	rev64.2s	v0, v0
	str	d0, [x0, #80]
	ldurh	w9, [x0, #49]
	strh	w9, [x0, #88]
	ldr	x9, [x0, #96]
	str	x9, [x8, #32]
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8]
	b	LBB8_15
LBB8_10:
	mov	w9, #9                          ; =0x9
	str	w9, [x0, #64]
	mov	w9, #1                          ; =0x1
LBB8_11:
	strb	w9, [x0, #90]
	b	LBB8_14
LBB8_12:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	b	LBB8_15
LBB8_13:
	mov	w9, #4                          ; =0x4
	str	w9, [x20]
LBB8_14:
	ldur	d0, [x0, #52]
	rev64.2s	v0, v0
	str	d0, [x0, #80]
	ldurh	w9, [x0, #49]
	strh	w9, [x0, #88]
	ldp	q0, q1, [x20]
	stp	q0, q1, [x8]
	ldr	x9, [x20, #32]
	str	x9, [x8, #32]
LBB8_15:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB8_16:
	mov	w8, #1000                       ; =0x3e8
	ldp	x9, x10, [sp]
	mov	x11, #13531                     ; =0x34db
	movk	x11, #55222, lsl #16
	movk	x11, #56962, lsl #32
	movk	x11, #17179, lsl #48
	smulh	x10, x10, x11
	asr	x11, x10, #18
	add	x10, x11, x10, lsr #63
	madd	x9, x9, x8, x10
	mov	x8, x23
	mov	x0, x22
	tbnz	x9, #63, LBB8_7
; %bb.17:
	add	x1, x9, w21, uxtw
	mov	x2, x19
	bl	_ws_receive
	b	LBB8_15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_receive
_ws_receive:                            ; @ws_receive
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x2
	mov	x22, x1
	mov	x20, x0
	mov	x19, x8
	mov	w8, #4224                       ; =0x1080
	add	x24, x0, x8
	add	x23, x0, #128
	mov	w25, #1                         ; =0x1
	mov	w26, #1000                      ; =0x3e8
	mov	x27, #13531                     ; =0x34db
	movk	x27, #55222, lsl #16
	movk	x27, #56962, lsl #32
	movk	x27, #17179, lsl #48
Lloh22:
	adrp	x28, l___const.ws_wait.pause@PAGE
Lloh23:
	add	x28, x28, l___const.ws_wait.pause@PAGEOFF
	b	LBB9_2
LBB9_1:                                 ;   in Loop: Header=BB9_2 Depth=1
	str	x9, [x20, #4232]
LBB9_2:                                 ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [x20, #48]
	cmp	w8, #1
	b.ne	LBB9_5
; %bb.3:                                ;   in Loop: Header=BB9_2 Depth=1
	ldrb	w8, [x20, #47]
	cmp	w8, #1
	b.ne	LBB9_28
; %bb.4:                                ;   in Loop: Header=BB9_2 Depth=1
	strb	wzr, [x20, #48]
LBB9_5:                                 ;   in Loop: Header=BB9_2 Depth=1
	ldr	x8, [x20, #4224]
	ldr	x9, [x20, #4232]
	subs	x2, x9, x8
	b.ls	LBB9_13
; %bb.6:                                ;   in Loop: Header=BB9_2 Depth=1
	str	xzr, [sp, #48]
	ldr	x0, [x20, #32]
	add	x1, x23, x8
	add	x3, sp, #48
	add	x4, sp, #8
	bl	_nl_ws_decoder_feed
	ldr	x8, [sp, #48]
	ldr	x9, [x20, #4224]
	add	x8, x9, x8
	str	x8, [x20, #4224]
	cmp	w0, #1
	b.eq	LBB9_22
; %bb.7:                                ;   in Loop: Header=BB9_2 Depth=1
	cmp	w0, #2
	b.ne	LBB9_32
; %bb.8:                                ;   in Loop: Header=BB9_2 Depth=1
	ldr	w8, [sp, #8]
	cmp	w8, #9
	b.eq	LBB9_21
; %bb.9:                                ;   in Loop: Header=BB9_2 Depth=1
	cmp	w8, #8
	b.eq	LBB9_38
; %bb.10:                               ;   in Loop: Header=BB9_2 Depth=1
	sub	w8, w8, #1
	cmp	w8, #1
	b.hi	LBB9_22
; %bb.11:                               ;   in Loop: Header=BB9_2 Depth=1
	ldrb	w8, [x20, #47]
	tbnz	w8, #0, LBB9_22
; %bb.12:                               ;   in Loop: Header=BB9_2 Depth=1
	ldur	q0, [sp, #8]
	stur	q0, [x20, #104]
	ldr	x8, [sp, #24]
	stur	x8, [x20, #120]
	strb	w25, [x20, #48]
	b	LBB9_2
LBB9_13:                                ;   in Loop: Header=BB9_2 Depth=1
	stp	xzr, xzr, [x24]
	ldr	x0, [x20]
	add	x8, sp, #8
	add	x1, x20, #8
	mov	x2, x23
	mov	w3, #4096                       ; =0x1000
	bl	_nl_socket_receive
	ldr	w8, [sp, #8]
	cbnz	w8, LBB9_15
; %bb.14:                               ;   in Loop: Header=BB9_2 Depth=1
	ldr	x9, [sp, #24]
	cbnz	x9, LBB9_1
LBB9_15:                                ;   in Loop: Header=BB9_2 Depth=1
	cmp	w8, #1
	b.eq	LBB9_33
; %bb.16:                               ;   in Loop: Header=BB9_2 Depth=1
	sub	w9, w8, #4
	cmn	w9, #3
	b.ls	LBB9_34
; %bb.17:                               ;   in Loop: Header=BB9_2 Depth=1
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB9_25
; %bb.18:                               ;   in Loop: Header=BB9_2 Depth=1
	ldp	x8, x9, [sp, #48]
	smulh	x9, x9, x27
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x26, x9
	tbnz	x8, #63, LBB9_25
; %bb.19:                               ;   in Loop: Header=BB9_2 Depth=1
	cmp	x8, x22
	b.ge	LBB9_25
; %bb.20:                               ;   in Loop: Header=BB9_2 Depth=1
	ldr	q0, [x28]
	str	q0, [sp, #48]
	add	x0, sp, #48
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	b	LBB9_22
LBB9_21:                                ;   in Loop: Header=BB9_2 Depth=1
	ldp	x2, x3, [sp, #16]
	mov	x0, x20
	mov	w1, #10                         ; =0xa
	mov	x4, x22
	bl	_ws_send_frame
	tbz	w0, #0, LBB9_44
LBB9_22:                                ;   in Loop: Header=BB9_2 Depth=1
	add	x1, sp, #8
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB9_27
; %bb.23:                               ;   in Loop: Header=BB9_2 Depth=1
	ldp	x8, x9, [sp, #8]
	smulh	x9, x9, x27
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x26, x9
	tbnz	x8, #63, LBB9_27
; %bb.24:                               ;   in Loop: Header=BB9_2 Depth=1
	cmp	x8, x22
	b.lt	LBB9_2
LBB9_25:
	mov	w8, #5                          ; =0x5
LBB9_26:
	str	w8, [x20, #64]
	ldrb	w8, [x20, #44]
	eor	w8, w8, #0x1
	strb	w8, [x20, #90]
	ldur	d0, [x20, #52]
	rev64.2s	v0, v0
	str	d0, [x20, #80]
	ldurh	w8, [x20, #49]
	strh	w8, [x20, #88]
	ldr	x8, [x20, #96]
	str	x8, [x19, #32]
	ldp	q0, q1, [x20, #64]
	stp	q0, q1, [x19]
	b	LBB9_47
LBB9_27:
	mov	x8, x19
	mov	x0, x20
	mov	w1, #6                          ; =0x6
	b	LBB9_46
LBB9_28:
	ldr	x22, [x20, #120]
	add	x0, x22, #1
	bl	_malloc
	cbz	x0, LBB9_37
; %bb.29:
	mov	x23, x0
	cbz	x22, LBB9_31
; %bb.30:
	ldr	x1, [x20, #112]
	mov	x0, x23
	mov	x2, x22
	bl	_memcpy
LBB9_31:
	strb	wzr, [x23, x22]
	ldr	w8, [x20, #104]
	cmp	w8, #2
	cset	w8, eq
	strb	w8, [x21]
	str	wzr, [x21, #4]
	stur	wzr, [x21, #1]
	stp	x23, x22, [x21, #8]
	strb	wzr, [x20, #48]
	str	x22, [x20, #96]
	str	wzr, [x20, #64]
	ldrb	w8, [x20, #44]
	eor	w8, w8, #0x1
	strb	w8, [x20, #90]
	ldur	d0, [x20, #52]
	rev64.2s	v0, v0
	str	d0, [x20, #80]
	ldurh	w8, [x20, #49]
	strh	w8, [x20, #88]
	ldp	q0, q1, [x20, #64]
	str	x22, [x19, #32]
	stp	q0, q1, [x19]
	b	LBB9_47
LBB9_32:
	mov	w8, #7                          ; =0x7
	mov	w9, #3                          ; =0x3
	cmp	w0, #6
	csel	w1, w9, w8, eq
	b	LBB9_45
LBB9_33:
	ldr	x0, [x20, #32]
	bl	_nl_ws_decoder_eof
	mov	x8, x19
	mov	x0, x20
	mov	w1, #7                          ; =0x7
	b	LBB9_46
LBB9_34:
	ldp	w11, w12, [sp, #12]
	ldrb	w10, [sp, #42]
	ldrb	w9, [sp, #43]
	str	w11, [x20, #68]
	ldr	w13, [x20, #52]
	cbnz	w13, LBB9_36
; %bb.35:
	cmp	w12, #0
	cset	w13, eq
	orr	w14, w10, w9
	tst	w13, w14
	csel	w11, w11, w12, ne
	str	w11, [x20, #52]
LBB9_36:
	ldrb	w11, [x20, #49]
	orr	w10, w11, w10
	strb	w10, [x20, #49]
	ldrb	w10, [x20, #50]
	orr	w9, w10, w9
	strb	w9, [x20, #50]
	and	w9, w8, #0xfffffffe
	mov	w10, #6                         ; =0x6
	mov	w11, #4                         ; =0x4
	cmp	w9, #8
	csel	w9, w11, w10, eq
	mov	w10, #3                         ; =0x3
	cmp	w8, #10
	csel	w1, w10, w9, eq
	b	LBB9_45
LBB9_37:
	mov	w8, #3                          ; =0x3
	b	LBB9_26
LBB9_38:
	mov	w8, #1                          ; =0x1
	strb	w8, [x20, #46]
	ldr	x3, [sp, #24]
	cmp	x3, #2
	b.lo	LBB9_40
; %bb.39:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	rev16	w8, w8
	b	LBB9_41
LBB9_40:
	mov	w8, #0                          ; =0x0
LBB9_41:
	str	w8, [x20, #56]
	ldrb	w8, [x20, #45]
	tbnz	w8, #0, LBB9_43
; %bb.42:
	ldr	x2, [sp, #16]
	mov	x0, x20
	mov	w1, #8                          ; =0x8
	mov	x4, x22
	bl	_ws_send_frame
	tbz	w0, #0, LBB9_44
LBB9_43:
	mov	w1, #9                          ; =0x9
	b	LBB9_45
LBB9_44:
	ldr	w1, [x20, #64]
LBB9_45:
	mov	x8, x19
	mov	x0, x20
LBB9_46:
	bl	_ws_fail
LBB9_47:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.loh AdrpAdd	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_message_free             ; -- Begin function nl_ws_message_free
	.p2align	2
_nl_ws_message_free:                    ; @nl_ws_message_free
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_2
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x0, #8]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
LBB10_2:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_abort          ; -- Begin function nl_ws_transport_abort
	.p2align	2
_nl_ws_transport_abort:                 ; @nl_ws_transport_abort
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_2
; %bb.1:
	mov	w1, #7                          ; =0x7
	b	_ws_fail
LBB11_2:
	movi.2d	v0, #0000000000000000
	str	xzr, [x8, #32]
	stp	q0, q0, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_fail
_ws_fail:                               ; @ws_fail
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x1
	mov	x20, x0
	mov	x19, x8
	strb	wzr, [x0, #44]
	ldr	x0, [x0]
	cbz	x0, LBB12_6
; %bb.1:
	add	x8, sp, #8
	bl	_nl_socket_service_destroy
	str	xzr, [x20]
	ldr	w11, [x20, #68]
	ldp	w12, w13, [sp, #12]
	ldrb	w10, [sp, #42]
	ldrb	w9, [sp, #43]
	str	w12, [x20, #68]
	ldr	w8, [x20, #52]
	cbnz	w8, LBB12_3
; %bb.2:
	cmp	w13, #0
	cset	w8, eq
	orr	w14, w10, w9
	tst	w8, w14
	csel	w8, w12, w13, ne
	str	w8, [x20, #52]
LBB12_3:
	ldrb	w12, [x20, #49]
	ldrb	w13, [x20, #50]
	orr	w9, w13, w9
	strb	w9, [x20, #50]
	cbz	w11, LBB12_5
; %bb.4:
	str	w11, [x20, #68]
LBB12_5:
	ldr	w11, [sp, #8]
	cmp	w11, #0
	csinc	w11, w12, wzr, eq
	orr	w10, w11, w10
	strb	w10, [x20, #49]
	ldrb	w11, [x20, #44]
	eor	w11, w11, #0x1
	b	LBB12_7
LBB12_6:
	ldr	w8, [x20, #52]
	ldrb	w10, [x20, #49]
	mov	w11, #1                         ; =0x1
	ldrb	w9, [x20, #50]
LBB12_7:
	str	w21, [x20, #64]
	and	w11, w11, #0x1
	strb	w11, [x20, #90]
	ldr	w11, [x20, #56]
	stp	w11, w8, [x20, #80]
	strb	w10, [x20, #88]
	strb	w9, [x20, #89]
	ldr	x8, [x20, #96]
	str	x8, [x19, #32]
	ldp	q0, q1, [x20, #64]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_close          ; -- Begin function nl_ws_transport_close
	.p2align	2
_nl_ws_transport_close:                 ; @nl_ws_transport_close
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x8
	cbz	x0, LBB13_5
; %bb.1:
	mov	x20, x0
	movi.2d	v0, #0000000000000000
	mov	x22, x0
	str	q0, [x22, #64]!
	str	xzr, [x22, #32]
	str	q0, [x22, #16]
	mov	w8, #60000                      ; =0xea60
	cmp	w1, w8
	b.hi	LBB13_6
; %bb.2:
	ldur	w8, [x22, #-24]
	cmp	w1, w8
	b.hi	LBB13_6
; %bb.3:
	mov	x21, x1
	add	x1, sp, #24
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbz	w0, LBB13_17
LBB13_4:
	mov	w21, #6                         ; =0x6
	b	LBB13_7
LBB13_5:
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #32]
	stp	q0, q0, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	b	LBB13_16
LBB13_6:
	mov	w21, #4                         ; =0x4
LBB13_7:
	str	w21, [x20, #64]
	ldrb	w8, [x20, #44]
	eor	w8, w8, #0x1
	strb	w8, [x20, #90]
	ldur	d0, [x20, #52]
	rev64.2s	v0, v0
	str	d0, [x20, #80]
	ldurh	w8, [x20, #49]
	strh	w8, [x20, #88]
LBB13_8:
	strb	wzr, [x20, #44]
	ldr	x0, [x20]
	cbz	x0, LBB13_14
; %bb.9:
	add	x8, sp, #24
	bl	_nl_socket_service_destroy
	str	xzr, [x20]
	ldr	w11, [x20, #68]
	ldp	w12, w13, [sp, #28]
	ldrb	w10, [sp, #58]
	ldrb	w9, [sp, #59]
	str	w12, [x20, #68]
	ldr	w8, [x20, #52]
	cbnz	w8, LBB13_11
; %bb.10:
	cmp	w13, #0
	cset	w8, eq
	orr	w14, w10, w9
	tst	w8, w14
	csel	w8, w12, w13, ne
	str	w8, [x20, #52]
LBB13_11:
	ldrb	w12, [x20, #49]
	ldrb	w13, [x20, #50]
	orr	w9, w13, w9
	strb	w9, [x20, #50]
	cbz	w11, LBB13_13
; %bb.12:
	str	w11, [x20, #68]
LBB13_13:
	ldr	w11, [sp, #24]
	cmp	w11, #0
	csinc	w11, w12, wzr, eq
	orr	w10, w11, w10
	strb	w10, [x20, #49]
	ldrb	w11, [x20, #44]
	eor	w11, w11, #0x1
	b	LBB13_15
LBB13_14:
	ldrb	w10, [x20, #49]
	ldr	w8, [x20, #52]
	mov	w11, #1                         ; =0x1
	ldrb	w9, [x20, #50]
LBB13_15:
	cmp	w21, #0
	cset	w12, eq
	tst	w10, w12
	mov	w12, #6                         ; =0x6
	csel	w12, w12, w21, ne
	str	w12, [x20, #64]
	and	w11, w11, #0x1
	strb	w11, [x20, #90]
	ldr	w11, [x20, #56]
	stp	w11, w8, [x20, #80]
	strb	w10, [x20, #88]
	strb	w9, [x20, #89]
	ldp	q0, q1, [x22]
	stp	q0, q1, [x19]
	ldr	x8, [x22, #32]
	str	x8, [x19, #32]
	ldr	x0, [x20, #32]
	bl	_nl_ws_decoder_destroy
	mov	x0, x20
	bl	_free
LBB13_16:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB13_17:
	mov	w8, #1000                       ; =0x3e8
	ldp	x9, x10, [sp, #24]
	mov	x11, #13531                     ; =0x34db
	movk	x11, #55222, lsl #16
	movk	x11, #56962, lsl #32
	movk	x11, #17179, lsl #48
	smulh	x10, x10, x11
	asr	x11, x10, #18
	add	x10, x11, x10, lsr #63
	madd	x8, x9, x8, x10
	tbnz	x8, #63, LBB13_4
; %bb.18:
	ldrb	w9, [x20, #44]
	cmp	w9, #1
	b.ne	LBB13_21
; %bb.19:
	add	x21, x8, w21, uxtw
	mov	w8, #1                          ; =0x1
	sturh	w8, [x20, #47]
	mov	x0, x20
	mov	w1, #8                          ; =0x8
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	x4, x21
	bl	_ws_send_frame
	tbz	w0, #0, LBB13_22
; %bb.20:
	add	x8, sp, #24
	mov	x2, sp
	mov	x0, x20
	mov	x1, x21
	bl	_ws_receive
	ldrb	w8, [x20, #46]
	ldr	w9, [sp, #24]
	cmp	w8, #0
	csel	w21, wzr, w9, ne
	b	LBB13_8
LBB13_21:
	mov	w21, #0                         ; =0x0
	b	LBB13_8
LBB13_22:
	ldr	w21, [x22]
	b	LBB13_8
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_connected      ; -- Begin function nl_ws_transport_connected
	.p2align	2
_nl_ws_transport_connected:             ; @nl_ws_transport_connected
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB14_2
; %bb.1:
	ldrb	w8, [x0, #44]
	and	w0, w8, #0x1
	ret
LBB14_2:
	and	w0, wzr, #0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nl_ws_transport_error          ; -- Begin function nl_ws_transport_error
	.p2align	2
_nl_ws_transport_error:                 ; @nl_ws_transport_error
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB15_2
; %bb.1:
	ldr	w8, [x0, #64]
Lloh24:
	adrp	x9, _nl_ws_transport_error.messages@PAGE
Lloh25:
	add	x9, x9, _nl_ws_transport_error.messages@PAGEOFF
	ldr	x0, [x9, x8, lsl #3]
	ret
LBB15_2:
Lloh26:
	adrp	x0, l_.str@PAGE
Lloh27:
	add	x0, x0, l_.str@PAGEOFF
	ret
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function ws_send_bytes
_ws_send_bytes:                         ; @ws_send_bytes
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB16_15
; %bb.1:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x19, x0
	mov	x23, #0                         ; =0x0
	mov	w24, #1000                      ; =0x3e8
	mov	x25, #13531                     ; =0x34db
	movk	x25, #55222, lsl #16
	movk	x25, #56962, lsl #32
	movk	x25, #17179, lsl #48
	mov	w26, #65536                     ; =0x10000
Lloh28:
	adrp	x27, l___const.ws_wait.pause@PAGE
Lloh29:
	add	x27, x27, l___const.ws_wait.pause@PAGEOFF
	b	LBB16_3
LBB16_2:                                ;   in Loop: Header=BB16_3 Depth=1
	add	x23, x9, x23
	cmp	x23, x21
	b.hs	LBB16_14
LBB16_3:                                ; =>This Inner Loop Header: Depth=1
	add	x1, sp, #8
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB16_16
; %bb.4:                                ;   in Loop: Header=BB16_3 Depth=1
	ldp	x8, x9, [sp, #8]
	smulh	x9, x9, x25
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	tbnz	x8, #63, LBB16_16
; %bb.5:                                ;   in Loop: Header=BB16_3 Depth=1
	cbz	x23, LBB16_7
; %bb.6:                                ;   in Loop: Header=BB16_3 Depth=1
	cmp	x8, x20
	b.ge	LBB16_17
LBB16_7:                                ;   in Loop: Header=BB16_3 Depth=1
	sub	x8, x21, x23
	cmp	x8, #16, lsl #12                ; =65536
	csel	x3, x8, x26, lo
	ldr	x0, [x19]
	add	x8, sp, #8
	add	x1, x19, #8
	add	x2, x22, x23
	bl	_nl_socket_send
	ldr	w8, [sp, #8]
	cbnz	w8, LBB16_9
; %bb.8:                                ;   in Loop: Header=BB16_3 Depth=1
	ldr	x9, [sp, #24]
	cbnz	x9, LBB16_2
LBB16_9:                                ;   in Loop: Header=BB16_3 Depth=1
	sub	w9, w8, #4
	cmn	w9, #3
	b.ls	LBB16_20
; %bb.10:                               ;   in Loop: Header=BB16_3 Depth=1
	add	x1, sp, #48
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB16_19
; %bb.11:                               ;   in Loop: Header=BB16_3 Depth=1
	ldp	x8, x9, [sp, #48]
	smulh	x9, x9, x25
	asr	x10, x9, #18
	add	x9, x10, x9, lsr #63
	madd	x8, x8, x24, x9
	tbnz	x8, #63, LBB16_19
; %bb.12:                               ;   in Loop: Header=BB16_3 Depth=1
	cmp	x8, x20
	b.ge	LBB16_19
; %bb.13:                               ;   in Loop: Header=BB16_3 Depth=1
	ldr	q0, [x27]
	str	q0, [sp, #48]
	add	x0, sp, #48
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
	cmp	x23, x21
	b.lo	LBB16_3
LBB16_14:
	mov	w0, #1                          ; =0x1
	b	LBB16_24
LBB16_15:
	mov	w0, #1                          ; =0x1
	ret
LBB16_16:
	mov	w8, #6                          ; =0x6
	b	LBB16_18
LBB16_17:
	mov	w8, #5                          ; =0x5
LBB16_18:
	mov	w0, #0                          ; =0x0
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldurh	w8, [x19, #49]
	strh	w8, [x19, #88]
	b	LBB16_24
LBB16_19:
	mov	w8, #5                          ; =0x5
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldur	d0, [x19, #52]
	rev64.2s	v0, v0
	str	d0, [x19, #80]
	ldrb	w8, [x19, #49]
	strb	w8, [x19, #88]
	ldrb	w10, [x19, #50]
	b	LBB16_23
LBB16_20:
	ldp	w12, w13, [sp, #12]
	ldrb	w11, [sp, #42]
	ldrb	w10, [sp, #43]
	str	w12, [x19, #68]
	ldr	w9, [x19, #52]
	cbnz	w9, LBB16_22
; %bb.21:
	cmp	w13, #0
	cset	w9, eq
	orr	w14, w11, w10
	tst	w9, w14
	csel	w9, w12, w13, ne
	str	w9, [x19, #52]
LBB16_22:
	ldrb	w12, [x19, #49]
	orr	w11, w12, w11
	strb	w11, [x19, #49]
	ldrb	w12, [x19, #50]
	orr	w10, w12, w10
	strb	w10, [x19, #50]
	and	w12, w8, #0xfffffffe
	mov	w13, #6                         ; =0x6
	mov	w14, #4                         ; =0x4
	cmp	w12, #8
	csel	w12, w14, w13, eq
	mov	w13, #3                         ; =0x3
	cmp	w8, #10
	csel	w8, w13, w12, eq
	str	w8, [x19, #64]
	ldrb	w8, [x19, #44]
	eor	w8, w8, #0x1
	strb	w8, [x19, #90]
	ldr	w8, [x19, #56]
	stp	w8, w9, [x19, #80]
	strb	w11, [x19, #88]
LBB16_23:
	mov	w0, #0                          ; =0x0
	strb	w10, [x19, #89]
LBB16_24:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"I require an owned WebSocket connection."

	.section	__DATA,__const
	.p2align	3, 0x0                          ; @nl_ws_transport_error.messages
_nl_ws_transport_error.messages:
	.quad	l_.str.1
	.quad	l_.str.2
	.quad	l_.str.3
	.quad	l_.str.4
	.quad	l_.str.5
	.quad	l_.str.6
	.quad	l_.str.7
	.quad	l_.str.8
	.quad	l_.str.9
	.quad	l_.str.10

	.section	__TEXT,__cstring,cstring_literals
l_.str.1:                               ; @.str.1
	.space	1

l_.str.2:                               ; @.str.2
	.asciz	"I require valid WebSocket arguments."

l_.str.3:                               ; @.str.3
	.asciz	"I require WebSocket network or lookup authority."

l_.str.4:                               ; @.str.4
	.asciz	"I could not allocate WebSocket storage."

l_.str.5:                               ; @.str.5
	.asciz	"I exceeded my WebSocket bound."

l_.str.6:                               ; @.str.6
	.asciz	"I reached my WebSocket deadline."

l_.str.7:                               ; @.str.7
	.asciz	"I could not complete WebSocket host I/O."

l_.str.8:                               ; @.str.8
	.asciz	"I refused an invalid WebSocket protocol operation."

l_.str.9:                               ; @.str.9
	.asciz	"I could not obtain WebSocket cryptographic randomness."

l_.str.10:                              ; @.str.10
	.asciz	"I have closed this WebSocket transport."

l_.str.11:                              ; @.str.11
	.asciz	"ws://"

	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.ws_wait.pause
l___const.ws_wait.pause:
	.quad	0                               ; 0x0
	.quad	1000000                         ; 0xf4240

	.section	__TEXT,__cstring,cstring_literals
l_.str.13:                              ; @.str.13
	.asciz	"GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n"

l_.str.14:                              ; @.str.14
	.asciz	"\r\n\r\n"

.subsections_via_symbols
