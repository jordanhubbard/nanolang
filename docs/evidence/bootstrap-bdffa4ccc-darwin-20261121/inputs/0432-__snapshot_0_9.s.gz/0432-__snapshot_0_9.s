	.build_version macos, 27, 2	sdk_version 27, 2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_nvm_file_flow_declarations     ; -- Begin function nvm_file_flow_declarations
	.p2align	2
_nvm_file_flow_declarations:            ; @nvm_file_flow_declarations
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_file_flow_declarations_mode
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_flow_declarations_mode
_file_flow_declarations_mode:           ; @file_flow_declarations_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #44
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	stur	x0, [x8, #28]
	stur	x1, [x8, #20]
	sturb	w2, [x29, #-25]
	ldur	x8, [x8, #28]
	cbz	x8, LBB1_4
	b	LBB1_1
LBB1_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #20]
	cbz	x8, LBB1_4
	b	LBB1_2
LBB1_2:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #28]
	ldr	w8, [x8, #272]
	cbz	w8, LBB1_4
	b	LBB1_3
LBB1_3:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #28]
	ldr	x8, [x8, #256]
	cbnz	x8, LBB1_5
	b	LBB1_4
LBB1_4:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_5:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #28]
	ldr	w8, [x8, #272]
	subs	w8, w8, #64
	b.ls	LBB1_7
	b	LBB1_6
LBB1_6:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_7:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #28]
	ldr	w8, [x8, #424]
	cbnz	w8, LBB1_9
	b	LBB1_8
LBB1_8:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #28]
	ldr	w8, [x8, #448]
	cbz	w8, LBB1_10
	b	LBB1_9
LBB1_9:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_10:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	xzr, [x8, #4]
	str	wzr, [x8]
	b	LBB1_11
LBB1_11:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	ldur	x9, [x9, #28]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB1_23
	b	LBB1_12
LBB1_12:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #28]
	ldr	x10, [x9, #256]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.gt	LBB1_14
	b	LBB1_13
LBB1_13:                                ;   in Loop: Header=BB1_11 Depth=1
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #1
	b.le	LBB1_15
	b	LBB1_14
LBB1_14:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_15:                                ;   in Loop: Header=BB1_11 Depth=1
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #18]
	cbz	w8, LBB1_17
	b	LBB1_16
LBB1_16:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_17:                                ;   in Loop: Header=BB1_11 Depth=1
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.ls	LBB1_19
	b	LBB1_18
LBB1_18:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_19:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #4]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #16]
	mov	x10, x9
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_21
	b	LBB1_20
LBB1_20:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_21:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #16]
	mov	x10, x8
	ldur	x8, [x9, #4]
	add	x8, x8, x10
	stur	x8, [x9, #4]
	b	LBB1_22
LBB1_22:                                ;   in Loop: Header=BB1_11 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	b	LBB1_11
LBB1_23:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #4]
	mov	x9, #-114                       ; =0xffffffffffffff8e
	movk	x9, #4095, lsl #48
	subs	x8, x8, x9
	b.ls	LBB1_25
	b	LBB1_24
LBB1_24:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_25:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #4]
	lsl	x8, x8, #4
	add	x8, x8, #1816
	stur	x8, [x29, #-64]
	mov	w0, #65536                      ; =0x10000
	sub	x1, x29, #72
	bl	_nvm_file_nominal_storage_bound
	tbz	w0, #0, LBB1_28
	b	LBB1_26
LBB1_26:
	ldur	x8, [x29, #-64]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hi	LBB1_28
	b	LBB1_27
LBB1_27:
	ldur	x8, [x29, #-72]
	ldur	x10, [x29, #-64]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB1_29
	b	LBB1_28
LBB1_28:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	sub	x1, x29, #80
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-80]
	ldur	x0, [x8, #28]
	bl	_nvm_file_nominal_plan
	bl	_nominal_status
	stur	w0, [x29, #-84]
	ldur	w8, [x29, #-84]
	cbz	w8, LBB1_31
	b	LBB1_30
LBB1_30:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-84]
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_31:
	ldur	x1, [x29, #-64]
	mov	x0, #1                          ; =0x1
	bl	_calloc
	stur	x0, [x29, #-96]
	ldur	x8, [x29, #-96]
	cbnz	x8, LBB1_33
	b	LBB1_32
LBB1_32:
	ldur	x0, [x29, #-80]
	bl	_nvm_file_nominal_plan_free
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_33:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x10, [x29, #-96]
	mov	w9, #1                          ; =0x1
	str	w9, [x10]
	ldur	x9, [x8, #28]
	ldr	w9, [x9, #272]
	ldur	x10, [x29, #-96]
	str	w9, [x10, #4]
	ldur	x9, [x29, #-80]
	ldur	x10, [x29, #-96]
	str	x9, [x10, #16]
	ldur	x10, [x29, #-96]
	mov	x9, #1                          ; =0x1
	str	x9, [x10, #8]
	ldur	x9, [x8, #28]
	ldr	x1, [x9, #296]
	ldur	x8, [x8, #28]
	ldr	w8, [x8, #304]
	mov	x2, x8
	add	x0, sp, #104
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	add	x1, sp, #100
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_41
	b	LBB1_34
LBB1_34:
	ldr	w8, [sp, #100]
	subs	w8, w8, #1
	b.ne	LBB1_41
	b	LBB1_35
LBB1_35:
	add	x0, sp, #104
	add	x1, sp, #96
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_41
	b	LBB1_36
LBB1_36:
	ldr	w8, [sp, #96]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	ldur	x0, [x29, #-80]
	bl	_nvm_file_nominal_layout_count
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, w0
	b.ne	LBB1_41
	b	LBB1_37
LBB1_37:
	ldr	w8, [sp, #96]
	mov	x1, x8
	add	x0, sp, #104
	add	x2, sp, #80
	bl	_nvm_v2_take
	cbnz	w0, LBB1_41
	b	LBB1_38
LBB1_38:
	add	x0, sp, #104
	bl	_nvm_v2_align4
	cbnz	w0, LBB1_41
	b	LBB1_39
LBB1_39:
	add	x0, sp, #104
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbnz	w0, LBB1_41
	b	LBB1_40
LBB1_40:
	ldr	w8, [sp, #92]
	ldur	x9, [x29, #-96]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB1_42
	b	LBB1_41
LBB1_41:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-84]
	b	LBB1_72
LBB1_42:
	str	xzr, [sp, #72]
	str	wzr, [sp, #68]
	b	LBB1_43
LBB1_43:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_58 Depth 2
	ldr	w8, [sp, #68]
	ldur	x9, [x29, #-96]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB1_68
	b	LBB1_44
LBB1_44:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x10, [x29, #-96]
	mov	x9, #24                         ; =0x18
	add	x12, x10, #24
	ldr	w10, [sp, #68]
                                        ; kill: def $x10 killed $w10
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x10, w10, w11, x12
	str	x10, [sp, #56]
	ldur	x8, [x8, #28]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldr	x8, [sp, #56]
	add	x1, x8, #2
	add	x0, sp, #104
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_48
	b	LBB1_45
LBB1_45:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x1, [sp, #56]
	add	x0, sp, #104
	bl	_nvm_v2_u16
	cbnz	w0, LBB1_48
	b	LBB1_46
LBB1_46:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #56]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB1_48
	b	LBB1_47
LBB1_47:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #56]
	ldrh	w8, [x8]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB1_49
	b	LBB1_48
LBB1_48:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-84]
	b	LBB1_72
LBB1_49:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #72]
	ldur	x9, [x29, #-96]
	add	x9, x9, #1560
	ldr	w10, [sp, #68]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w8 killed $w8 killed $x8
	str	w8, [x9, x10, lsl #2]
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #21]
	ldr	x9, [sp, #56]
	strb	w8, [x9, #4]
	ldur	x1, [x29, #-80]
	ldr	x8, [sp, #56]
	add	x2, x8, #8
	ldurb	w8, [x29, #-25]
	add	x0, sp, #104
	and	w3, w8, #0x1
	bl	_read_declaration
	stur	w0, [x29, #-84]
	ldur	w8, [x29, #-84]
	cbz	w8, LBB1_51
	b	LBB1_50
LBB1_50:
	b	LBB1_72
LBB1_51:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB1_56
	b	LBB1_52
LBB1_52:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #8]
	str	w8, [sp, #16]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #4]
	cbz	w8, LBB1_54
	b	LBB1_53
LBB1_53:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #20]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB1_55
LBB1_54:                                ;   in Loop: Header=BB1_43 Depth=1
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB1_55
LBB1_55:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	w8, [sp, #16]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, w9
	b.eq	LBB1_57
	b	LBB1_56
LBB1_56:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-84]
	b	LBB1_72
LBB1_57:                                ;   in Loop: Header=BB1_43 Depth=1
	strh	wzr, [sp, #46]
	b	LBB1_58
LBB1_58:                                ;   Parent Loop BB1_43 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB1_66
	b	LBB1_59
LBB1_59:                                ;   in Loop: Header=BB1_58 Depth=2
	ldur	x1, [x29, #-80]
	ldur	x8, [x29, #-96]
	add	x8, x8, #1816
	ldr	x9, [sp, #72]
	ldrh	w10, [sp, #46]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	add	x2, x8, x9, lsl #4
	ldurb	w8, [x29, #-25]
	add	x0, sp, #104
	and	w3, w8, #0x1
	bl	_read_declaration
	stur	w0, [x29, #-84]
	ldur	w8, [x29, #-84]
	cbz	w8, LBB1_61
	b	LBB1_60
LBB1_60:
	b	LBB1_72
LBB1_61:                                ;   in Loop: Header=BB1_58 Depth=2
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.lt	LBB1_64
	b	LBB1_62
LBB1_62:                                ;   in Loop: Header=BB1_58 Depth=2
	ldur	x8, [x29, #-96]
	add	x8, x8, #1816
	ldr	x9, [sp, #72]
	ldrh	w10, [sp, #46]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #1]
	cbz	w8, LBB1_64
	b	LBB1_63
LBB1_63:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-84]
	b	LBB1_72
LBB1_64:                                ;   in Loop: Header=BB1_58 Depth=2
	b	LBB1_65
LBB1_65:                                ;   in Loop: Header=BB1_58 Depth=2
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB1_58
LBB1_66:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	x8, [sp, #56]
	ldrh	w8, [x8, #2]
	mov	x9, x8
	ldr	x8, [sp, #72]
	add	x8, x8, x9
	str	x8, [sp, #72]
	b	LBB1_67
LBB1_67:                                ;   in Loop: Header=BB1_43 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB1_43
LBB1_68:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	ldur	x9, [x9, #4]
	subs	x8, x8, x9
	b.ne	LBB1_70
	b	LBB1_69
LBB1_69:
	ldr	x8, [sp, #120]
	ldr	x9, [sp, #112]
	subs	x8, x8, x9
	b.eq	LBB1_71
	b	LBB1_70
LBB1_70:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-84]
	b	LBB1_72
LBB1_71:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-96]
	ldur	x10, [x8, #20]
	str	x9, [x10]
	str	wzr, [x8, #40]
	b	LBB1_73
LBB1_72:
	ldur	x0, [x29, #-96]
	bl	_nvm_file_flow_declarations_free
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-84]
	str	w8, [x9, #40]
	b	LBB1_73
LBB1_73:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w0, [x8, #40]
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_declarations_free ; -- Begin function nvm_file_flow_declarations_free
	.p2align	2
_nvm_file_flow_declarations_free:       ; @nvm_file_flow_declarations_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB2_3
	b	LBB2_1
LBB2_1:
	ldr	x9, [sp, #8]
	ldr	w8, [x9]
	subs	w8, w8, #1
	str	w8, [x9]
	cbnz	w8, LBB2_3
	b	LBB2_2
LBB2_2:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_nvm_file_nominal_plan_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB2_3
LBB2_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_function         ; -- Begin function nvm_file_flow_function
	.p2align	2
_nvm_file_flow_function:                ; @nvm_file_flow_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB3_3
	b	LBB3_1
LBB3_1:
	ldr	x8, [sp]
	cbz	x8, LBB3_3
	b	LBB3_2
LBB3_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB3_4
	b	LBB3_3
LBB3_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB3_5
LBB3_4:
	ldr	x9, [sp]
	ldr	x8, [sp, #16]
	mov	x10, #24                        ; =0x18
	add	x11, x8, #24
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB3_5
LBB3_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_declaration      ; -- Begin function nvm_file_flow_declaration
	.p2align	2
_nvm_file_flow_declaration:             ; @nvm_file_flow_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB4_4
	b	LBB4_1
LBB4_1:
	ldr	x8, [sp]
	cbz	x8, LBB4_4
	b	LBB4_2
LBB4_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB4_4
	b	LBB4_3
LBB4_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	mov	x10, #24                        ; =0x18
	add	x11, x9, #24
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB4_5
	b	LBB4_4
LBB4_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB4_6
LBB4_5:
	ldr	x8, [sp]
	ldr	x9, [sp, #16]
	add	x9, x9, #1816
	ldr	x10, [sp, #16]
	add	x10, x10, #1560
	ldr	w11, [sp, #12]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldrh	w11, [sp, #10]
	add	w10, w10, w11
	ldr	q0, [x9, w10, uxtw #4]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB4_6
LBB4_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_state            ; -- Begin function nvm_file_flow_state
	.p2align	2
_nvm_file_flow_state:                   ; @nvm_file_flow_state
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	x2, [x29, #-48]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB5_3
	b	LBB5_1
LBB5_1:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB5_3
	b	LBB5_2
LBB5_2:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB5_4
	b	LBB5_3
LBB5_3:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB5_29
LBB5_4:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB5_6
	b	LBB5_5
LBB5_5:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB5_29
LBB5_6:
	stur	wzr, [x29, #-52]
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-56]
	sturh	wzr, [x29, #-58]
	b	LBB5_7
LBB5_7:                                 ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-58]
	ldur	x9, [x29, #-32]
	mov	x11, #24                        ; =0x18
	add	x9, x9, #24
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w9, [x9, x10]
	subs	w8, w8, w9
	b.ge	LBB5_12
	b	LBB5_8
LBB5_8:                                 ;   in Loop: Header=BB5_7 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1816
	ldur	x9, [x29, #-32]
	add	x9, x9, #1560
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-58]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	stur	q0, [x29, #-80]
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_owned
	ldur	w8, [x29, #-52]
	add	w8, w8, w0
	stur	w8, [x29, #-52]
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_owned
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	tbnz	w0, #0, LBB5_10
	b	LBB5_9
LBB5_9:                                 ;   in Loop: Header=BB5_7 Depth=1
	ldurb	w8, [x29, #-79]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB5_10
LBB5_10:                                ;   in Loop: Header=BB5_7 Depth=1
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w9, w8, #0x1
	ldur	w8, [x29, #-56]
	add	w8, w8, w9
	stur	w8, [x29, #-56]
	b	LBB5_11
LBB5_11:                                ;   in Loop: Header=BB5_7 Depth=1
	ldurh	w8, [x29, #-58]
	add	w8, w8, #1
	sturh	w8, [x29, #-58]
	b	LBB5_7
LBB5_12:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #256
	b.hi	LBB5_14
	b	LBB5_13
LBB5_13:
	ldur	w8, [x29, #-56]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-32]
	ldr	x10, [x9, #8]
	mov	x9, #-1                         ; =0xffffffffffffffff
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB5_15
	b	LBB5_14
LBB5_14:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB5_29
LBB5_15:
	mov	x0, #1                          ; =0x1
	mov	x1, #47152                      ; =0xb830
	bl	_calloc
	stur	x0, [x29, #-88]
	ldur	x8, [x29, #-88]
	cbnz	x8, LBB5_17
	b	LBB5_16
LBB5_16:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-20]
	b	LBB5_29
LBB5_17:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-88]
	str	x8, [x9]
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-88]
	str	w8, [x9, #8]
	ldur	x10, [x29, #-32]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	ldur	x10, [x29, #-88]
	mov	x9, #24                         ; =0x18
	str	x8, [x10, #24]
	ldur	x10, [x29, #-88]
	mov	w8, #1                          ; =0x1
	strb	w8, [x10, #40]
	ldur	x8, [x29, #-32]
	add	x10, x8, #24
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-96]
	sturh	wzr, [x29, #-98]
	b	LBB5_18
LBB5_18:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-98]
	ldur	x9, [x29, #-96]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB5_28
	b	LBB5_19
LBB5_19:                                ;   in Loop: Header=BB5_18 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #1816
	ldur	x9, [x29, #-32]
	add	x9, x9, #1560
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-98]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	str	q0, [sp, #128]
	ldurh	w8, [x29, #-98]
	ldur	x9, [x29, #-96]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	cset	w8, lt
	strb	w8, [sp, #127]
	ldur	x8, [x29, #-88]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-98]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldrb	w8, [sp, #127]
	str	w8, [sp, #24]                   ; 4-byte Folded Spill
	ldrb	w8, [sp, #127]
	tbz	w8, #0, LBB5_22
	b	LBB5_20
LBB5_20:                                ;   in Loop: Header=BB5_18 Depth=1
	ldr	x0, [sp, #128]
	ldr	x1, [sp, #136]
	bl	_owned
	tbz	w0, #0, LBB5_22
	b	LBB5_21
LBB5_21:                                ;   in Loop: Header=BB5_18 Depth=1
	ldur	x10, [x29, #-32]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_23
LBB5_22:                                ;   in Loop: Header=BB5_18 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB5_23
LBB5_23:                                ;   in Loop: Header=BB5_18 Depth=1
	ldr	w9, [sp, #24]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [sp, #128]
	ldr	x1, [sp, #136]
	add	x8, sp, #80
	str	x8, [sp]                        ; 8-byte Folded Spill
	and	w2, w9, #0x1
	bl	_initial_value
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #127]
	tbz	w8, #0, LBB5_26
	b	LBB5_24
LBB5_24:                                ;   in Loop: Header=BB5_18 Depth=1
	ldrb	w8, [sp, #129]
	cbz	w8, LBB5_26
	b	LBB5_25
LBB5_25:                                ;   in Loop: Header=BB5_18 Depth=1
	ldur	x10, [x29, #-32]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	str	x8, [sp, #72]
	ldur	x8, [x29, #-88]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-98]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #32
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #32]
	strb	w8, [sp, #33]
	ldurh	w8, [x29, #-98]
	strh	w8, [sp, #34]
	str	wzr, [sp, #36]
	ldr	x8, [sp, #72]
	str	x8, [sp, #40]
	ldr	x8, [sp, #72]
	str	x8, [sp, #48]
	str	xzr, [sp, #56]
	ldrb	w8, [sp, #129]
	subs	w8, w8, #1
	cset	w8, eq
	strb	w8, [sp, #64]
	stur	wzr, [x1, #33]
	str	wzr, [sp, #68]
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB5_26
LBB5_26:                                ;   in Loop: Header=BB5_18 Depth=1
	b	LBB5_27
LBB5_27:                                ;   in Loop: Header=BB5_18 Depth=1
	ldurh	w8, [x29, #-98]
	add	w8, w8, #1
	sturh	w8, [x29, #-98]
	b	LBB5_18
LBB5_28:
	ldur	x9, [x29, #-32]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	ldur	x8, [x29, #-88]
	ldur	x9, [x29, #-48]
	str	x8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB5_29
LBB5_29:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function owned
_owned:                                 ; @owned
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldrb	w8, [sp, #17]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #12]                   ; 4-byte Folded Spill
	cbnz	w8, LBB6_4
	b	LBB6_1
LBB6_1:
	ldr	w9, [sp, #28]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB6_3
	b	LBB6_2
LBB6_2:
	ldr	w8, [sp, #28]
	subs	w8, w8, #2
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB6_3
LBB6_3:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB6_4
LBB6_4:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function initial_value
_initial_value:                         ; @initial_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x8, [sp]                        ; 8-byte Folded Spill
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	strb	w2, [sp, #31]
	str	x3, [sp, #16]
	ldr	w9, [sp, #44]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB7_2
	b	LBB7_1
LBB7_1:
	ldr	w8, [sp, #44]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB7_2
LBB7_2:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	w11, [sp, #8]                   ; 4-byte Folded Reload
	mov	w9, #0                          ; =0x0
	mov	w10, #1                         ; =0x1
	and	w11, w11, #0x1
	ands	w11, w11, #0x1
	csinc	w9, w9, wzr, eq
	str	w9, [sp, #12]
	ldr	q0, [sp, #32]
	str	q0, [x8]
	ldrb	w9, [sp, #31]
	and	w9, w9, w10
	strb	w9, [x8, #16]
	stur	wzr, [x8, #17]
	str	wzr, [x8, #20]
	ldr	x9, [sp, #16]
	str	x9, [x8, #24]
	ldr	w9, [sp, #12]
	str	w9, [x8, #32]
	str	wzr, [x8, #36]
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_state_free       ; -- Begin function nvm_file_flow_state_free
	.p2align	2
_nvm_file_flow_state_free:              ; @nvm_file_flow_state_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB8_2
	b	LBB8_1
LBB8_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_flow_declarations_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB8_2
LBB8_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_local            ; -- Begin function nvm_file_flow_local
	.p2align	2
_nvm_file_flow_local:                   ; @nvm_file_flow_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	x2, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB9_2
	b	LBB9_1
LBB9_1:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_local_valid
	tbnz	w0, #0, LBB9_3
	b	LBB9_2
LBB9_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_4
LBB9_3:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB9_4
LBB9_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function local_valid
_local_valid:                           ; @local_valid
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldr	x8, [sp, #8]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB10_2
	b	LBB10_1
LBB10_1:
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	mov	x10, #24                        ; =0x18
	add	x11, x9, #24
	ldr	x9, [sp, #8]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	cset	w8, lt
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB10_2
LBB10_2:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_stack            ; -- Begin function nvm_file_flow_stack
	.p2align	2
_nvm_file_flow_stack:                   ; @nvm_file_flow_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB11_3
	b	LBB11_1
LBB11_1:
	ldr	x8, [sp]
	cbz	x8, LBB11_3
	b	LBB11_2
LBB11_2:
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.lt	LBB11_4
	b	LBB11_3
LBB11_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_5
LBB11_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB11_5
LBB11_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_reference        ; -- Begin function nvm_file_flow_reference
	.p2align	2
_nvm_file_flow_reference:               ; @nvm_file_flow_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB12_3
	b	LBB12_1
LBB12_1:
	ldr	x8, [sp]
	cbz	x8, LBB12_3
	b	LBB12_2
LBB12_2:
	ldrh	w8, [sp, #14]
	subs	w8, w8, #256
	b.lo	LBB12_4
	b	LBB12_3
LBB12_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_5
LBB12_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB12_5
LBB12_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_counts           ; -- Begin function nvm_file_flow_counts
	.p2align	2
_nvm_file_flow_counts:                  ; @nvm_file_flow_counts
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	x1, [sp, #40]
	ldr	x8, [sp, #48]
	cbz	x8, LBB13_2
	b	LBB13_1
LBB13_1:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB13_3
	b	LBB13_2
LBB13_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB13_16
LBB13_3:
	ldr	x8, [sp, #48]
	ldrh	w9, [x8, #12]
	add	x8, sp, #16
	strh	w9, [sp, #16]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #14]
	strh	w9, [sp, #18]
	strh	wzr, [sp, #20]
	strh	wzr, [sp, #22]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #32]
	str	x9, [sp, #24]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #16]
	strh	w9, [sp, #32]
	ldr	x9, [sp, #48]
	ldrb	w9, [x9, #40]
	and	w9, w9, #0x1
	strb	w9, [sp, #34]
	stur	wzr, [x8, #19]
	strb	wzr, [sp, #39]
	strh	wzr, [sp, #14]
	b	LBB13_4
LBB13_4:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #48]
	ldr	x9, [x9]
	mov	x10, #24                        ; =0x18
	add	x11, x9, #24
	ldr	x9, [sp, #48]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB13_7
	b	LBB13_5
LBB13_5:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	x8, [sp, #48]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8, #24]
	ldrh	w8, [sp, #20]
	subs	x9, x9, #0
	cinc	w8, w8, ne
	strh	w8, [sp, #20]
	b	LBB13_6
LBB13_6:                                ;   in Loop: Header=BB13_4 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB13_4
LBB13_7:
	strh	wzr, [sp, #12]
	b	LBB13_8
LBB13_8:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ge	LBB13_11
	b	LBB13_9
LBB13_9:                                ;   in Loop: Header=BB13_8 Depth=1
	ldr	x8, [sp, #48]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldrh	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x9, [x8, #24]
	ldrh	w8, [sp, #20]
	subs	x9, x9, #0
	cinc	w8, w8, ne
	strh	w8, [sp, #20]
	b	LBB13_10
LBB13_10:                               ;   in Loop: Header=BB13_8 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB13_8
LBB13_11:
	strh	wzr, [sp, #10]
	b	LBB13_12
LBB13_12:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #10]
	subs	w8, w8, #256
	b.hs	LBB13_15
	b	LBB13_13
LBB13_13:                               ;   in Loop: Header=BB13_12 Depth=1
	ldr	x8, [sp, #48]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #10]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	and	w9, w8, #0x1
	ldrh	w8, [sp, #22]
	add	w8, w8, w9
	strh	w8, [sp, #22]
	b	LBB13_14
LBB13_14:                               ;   in Loop: Header=BB13_12 Depth=1
	ldrh	w8, [sp, #10]
	add	w8, w8, #1
	strh	w8, [sp, #10]
	b	LBB13_12
LBB13_15:
	ldr	x9, [sp, #40]
	ldr	q0, [sp, #16]
	str	q0, [x9]
	ldr	x8, [sp, #32]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB13_16
LBB13_16:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_push_scalar      ; -- Begin function nvm_file_flow_push_scalar
	.p2align	2
_nvm_file_flow_push_scalar:             ; @nvm_file_flow_push_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB14_3
	b	LBB14_1
LBB14_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB14_3
	b	LBB14_2
LBB14_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB14_10
LBB14_3:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB14_5
	b	LBB14_4
LBB14_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB14_10
LBB14_5:
	ldurb	w0, [x29, #-17]
	bl	_scalar
	tbnz	w0, #0, LBB14_7
	b	LBB14_6
LBB14_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB14_10
LBB14_7:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB14_9
	b	LBB14_8
LBB14_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB14_10
LBB14_9:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x11, [x29, #-16]
	ldrh	w8, [x11, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #12]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	strh	w9, [x11, #12]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldurb	w0, [x29, #-17]
	bl	_scalar_type
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	add	x8, sp, #48
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB14_10
LBB14_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar
_scalar:                                ; @scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_4
	b	LBB15_1
LBB15_1:
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #4
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB15_4
	b	LBB15_2
LBB15_2:
	ldrb	w8, [sp, #15]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	cbz	w8, LBB15_4
	b	LBB15_3
LBB15_3:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #5
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB15_4
LBB15_4:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function scalar_type
_scalar_type:                           ; @scalar_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	strb	w0, [sp, #15]
	ldrb	w8, [sp, #15]
	strb	w8, [sp, #16]
	strb	wzr, [sp, #17]
	strh	wzr, [sp, #18]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [sp, #20]
	str	w8, [sp, #24]
	str	wzr, [sp, #28]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_load             ; -- Begin function nvm_file_flow_load
	.p2align	2
_nvm_file_flow_load:                    ; @nvm_file_flow_load
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x8, [sp, #16]
	cbz	x8, LBB17_3
	b	LBB17_1
LBB17_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB17_3
	b	LBB17_2
LBB17_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB17_11
LBB17_3:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_local_valid
	tbz	w0, #0, LBB17_7
	b	LBB17_4
LBB17_4:
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB17_7
	b	LBB17_5
LBB17_5:
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB17_7
	b	LBB17_6
LBB17_6:
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	tbz	w0, #0, LBB17_8
	b	LBB17_7
LBB17_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB17_11
LBB17_8:
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB17_10
	b	LBB17_9
LBB17_9:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB17_11
LBB17_10:
	ldr	x8, [sp, #16]
	mov	x9, #24624                      ; =0x6030
	add	x11, x8, x9
	ldr	x10, [sp, #16]
	ldrh	w8, [x10, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x10, #12]
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldr	x8, [sp, #16]
	mov	x10, #14384                     ; =0x3830
	add	x10, x8, x10
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB17_11
LBB17_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_store            ; -- Begin function nvm_file_flow_store
	.p2align	2
_nvm_file_flow_store:                   ; @nvm_file_flow_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB18_3
	b	LBB18_1
LBB18_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB18_3
	b	LBB18_2
LBB18_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB18_22
LBB18_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_local_valid
	tbz	w0, #0, LBB18_5
	b	LBB18_4
LBB18_4:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB18_6
	b	LBB18_5
LBB18_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB18_22
LBB18_6:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	add	x0, sp, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #32]
	tbz	w8, #0, LBB18_15
	b	LBB18_7
LBB18_7:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB18_15
	b	LBB18_8
LBB18_8:
	ldrb	w8, [sp, #16]
	cbnz	w8, LBB18_15
	b	LBB18_9
LBB18_9:
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB18_15
	b	LBB18_10
LBB18_10:
	ldr	w8, [sp, #20]
	adds	w8, w8, #1
	b.ne	LBB18_15
	b	LBB18_11
LBB18_11:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x8, x8, x9
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldrb	w8, [x8, x9]
	cbz	w8, LBB18_15
	b	LBB18_12
LBB18_12:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_nvm_file_flow_clear_copy
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbnz	w8, LBB18_14
	b	LBB18_13
LBB18_13:
	ldur	x0, [x29, #-16]
	bl	_pop
	b	LBB18_14
LBB18_14:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB18_22
LBB18_15:
	ldrb	w8, [sp, #32]
	tbz	w8, #0, LBB18_20
	b	LBB18_16
LBB18_16:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB18_20
	b	LBB18_17
LBB18_17:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB18_20
	b	LBB18_18
LBB18_18:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	tbnz	w0, #0, LBB18_20
	b	LBB18_19
LBB18_19:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB18_21
	b	LBB18_20
LBB18_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB18_22
LBB18_21:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x0, [x29, #-16]
	bl	_pop
	stur	wzr, [x29, #-4]
	b	LBB18_22
LBB18_22:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_clear_copy       ; -- Begin function nvm_file_flow_clear_copy
	.p2align	2
_nvm_file_flow_clear_copy:              ; @nvm_file_flow_clear_copy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_local_valid
	tbnz	w0, #0, LBB19_2
	b	LBB19_1
LBB19_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB19_8
LBB19_2:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB19_4
	b	LBB19_3
LBB19_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB19_8
LBB19_4:
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB19_6
	b	LBB19_5
LBB19_5:
	ldr	x8, [sp, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	tbz	w0, #0, LBB19_7
	b	LBB19_6
LBB19_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB19_8
LBB19_7:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_clear_local
	stur	wzr, [x29, #-4]
	b	LBB19_8
LBB19_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function pop
_pop:                                   ; @pop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldur	x8, [x29, #-8]
	ldrh	w10, [x8, #12]
	mov	w9, #-1                         ; =0xffffffff
	add	w9, w9, w10, uxth
	strh	w9, [x8, #12]
                                        ; implicit-def: $x8
	mov	x8, x9
	and	x8, x8, #0xffff
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	x8, #40                         ; =0x28
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x0, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	mov	x11, #24624                     ; =0x6030
	add	x10, x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	bl	_memcpy
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function same
_same:                                  ; @same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	str	x2, [sp, #16]
	str	x3, [sp, #24]
	ldrb	w9, [sp, #32]
	ldrb	w10, [sp, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB21_5
	b	LBB21_1
LBB21_1:
	ldrb	w9, [sp, #33]
	ldrb	w10, [sp, #17]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB21_5
	b	LBB21_2
LBB21_2:
	ldr	w9, [sp, #36]
	ldr	w10, [sp, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB21_5
	b	LBB21_3
LBB21_3:
	ldr	w9, [sp, #40]
	ldr	w10, [sp, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB21_5
	b	LBB21_4
LBB21_4:
	ldr	w8, [sp, #44]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB21_5
LBB21_5:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_dup              ; -- Begin function nvm_file_flow_dup
	.p2align	2
_nvm_file_flow_dup:                     ; @nvm_file_flow_dup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB22_3
	b	LBB22_1
LBB22_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB22_3
	b	LBB22_2
LBB22_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB22_10
LBB22_3:
	ldr	x8, [sp]
	cbz	x8, LBB22_6
	b	LBB22_4
LBB22_4:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	cbz	w8, LBB22_6
	b	LBB22_5
LBB22_5:
	ldr	x8, [sp]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	cbz	x8, LBB22_7
	b	LBB22_6
LBB22_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB22_10
LBB22_7:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB22_9
	b	LBB22_8
LBB22_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB22_10
LBB22_9:
	ldr	x8, [sp]
	mov	x9, #24624                      ; =0x6030
	add	x11, x8, x9
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldr	x8, [sp]
	add	x10, x8, x9
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x9, [sp]
	ldrh	w8, [x9, #12]
	add	w8, w8, #1
	strh	w8, [x9, #12]
	stur	wzr, [x29, #-4]
	b	LBB22_10
LBB22_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_pop              ; -- Begin function nvm_file_flow_pop
	.p2align	2
_nvm_file_flow_pop:                     ; @nvm_file_flow_pop
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB23_3
	b	LBB23_1
LBB23_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB23_3
	b	LBB23_2
LBB23_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB23_8
LBB23_3:
	ldr	x8, [sp]
	cbz	x8, LBB23_6
	b	LBB23_4
LBB23_4:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	cbz	w8, LBB23_6
	b	LBB23_5
LBB23_5:
	ldr	x8, [sp]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	cbz	x8, LBB23_7
	b	LBB23_6
LBB23_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB23_8
LBB23_7:
	ldr	x0, [sp]
	bl	_pop
	stur	wzr, [x29, #-4]
	b	LBB23_8
LBB23_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_move             ; -- Begin function nvm_file_flow_move
	.p2align	2
_nvm_file_flow_move:                    ; @nvm_file_flow_move
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB24_3
	b	LBB24_1
LBB24_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB24_3
	b	LBB24_2
LBB24_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB24_11
LBB24_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_live_owner
	tbz	w0, #0, LBB24_7
	b	LBB24_4
LBB24_4:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-20]
	bl	_local_valid
	tbz	w0, #0, LBB24_7
	b	LBB24_5
LBB24_5:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB24_7
	b	LBB24_6
LBB24_6:
	ldur	x8, [x29, #-16]
	mov	x11, #14384                     ; =0x3830
	add	x12, x8, x11
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x12
	ldur	x8, [x29, #-16]
	add	x11, x8, x11
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	x0, [x9]
	ldr	x1, [x9, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB24_8
	b	LBB24_7
LBB24_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB24_11
LBB24_8:
	ldur	x8, [x29, #-16]
	mov	x10, #14384                     ; =0x3830
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	add	x12, x8, x10
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x11, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w11, x12
	ldur	x8, [x29, #-16]
	add	x10, x8, x10
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	add	x10, x8, x10
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	subs	w8, w8, #2
	b.ne	LBB24_10
	b	LBB24_9
LBB24_9:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #32]
	b	LBB24_10
LBB24_10:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_clear_local
	stur	wzr, [x29, #-4]
	b	LBB24_11
LBB24_11:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_owner
_live_owner:                            ; @live_owner
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	ldr	x0, [sp, #8]
	ldrh	w1, [sp, #6]
	bl	_local_valid
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbz	w0, #0, LBB25_5
	b	LBB25_1
LBB25_1:
	ldr	x8, [sp, #8]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	tbz	w8, #0, LBB25_5
	b	LBB25_2
LBB25_2:
	ldr	x8, [sp, #8]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	mov	w9, #0                          ; =0x0
	str	w9, [sp]                        ; 4-byte Folded Spill
	cbz	x8, LBB25_5
	b	LBB25_3
LBB25_3:
	ldr	x8, [sp, #8]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	mov	w8, #0                          ; =0x0
	str	w8, [sp]                        ; 4-byte Folded Spill
	tbz	w0, #0, LBB25_5
	b	LBB25_4
LBB25_4:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #8]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x1, [x8, #24]
	bl	_held
	eor	w8, w0, #0x1
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB25_5
LBB25_5:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function clear_local
_clear_local:                           ; @clear_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	sturh	w1, [x29, #-10]
	ldur	x8, [x29, #-8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldurh	w8, [x29, #-10]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x10, [x29, #-8]
	ldurh	w8, [x29, #-10]
                                        ; kill: def $x8 killed $w8
	mov	x11, #14384                     ; =0x3830
	str	x11, [sp]                       ; 8-byte Folded Spill
	add	x10, x10, x11
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	add	x8, sp, #40
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w9, #0                          ; =0x0
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	add	x10, x10, x11
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_take             ; -- Begin function nvm_file_flow_take
	.p2align	2
_nvm_file_flow_take:                    ; @nvm_file_flow_take
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB27_3
	b	LBB27_1
LBB27_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB27_3
	b	LBB27_2
LBB27_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB27_10
LBB27_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_live_owner
	tbnz	w0, #0, LBB27_5
	b	LBB27_4
LBB27_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB27_10
LBB27_5:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB27_7
	b	LBB27_6
LBB27_6:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB27_10
LBB27_7:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	add	x11, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	ldur	x8, [x29, #-16]
	mov	x10, #14384                     ; =0x3830
	add	x10, x8, x10
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	add	x10, x8, x10
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	subs	w8, w8, #2
	b.ne	LBB27_9
	b	LBB27_8
LBB27_8:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #32]
	b	LBB27_9
LBB27_9:
	ldur	x9, [x29, #-16]
	ldrh	w8, [x9, #12]
	add	w8, w8, #1
	strh	w8, [x9, #12]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_clear_local
	stur	wzr, [x29, #-4]
	b	LBB27_10
LBB27_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_put              ; -- Begin function nvm_file_flow_put
	.p2align	2
_nvm_file_flow_put:                     ; @nvm_file_flow_put
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB28_3
	b	LBB28_1
LBB28_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB28_3
	b	LBB28_2
LBB28_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB28_14
LBB28_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_local_valid
	tbz	w0, #0, LBB28_6
	b	LBB28_4
LBB28_4:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB28_6
	b	LBB28_5
LBB28_5:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB28_7
	b	LBB28_6
LBB28_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB28_14
LBB28_7:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	mov	x0, sp
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x8, [sp, #24]
	cbz	x8, LBB28_10
	b	LBB28_8
LBB28_8:
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	bl	_owned
	tbz	w0, #0, LBB28_10
	b	LBB28_9
LBB28_9:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [sp]
	ldr	x1, [sp, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB28_11
	b	LBB28_10
LBB28_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB28_14
LBB28_11:
	ldr	w8, [sp, #12]
	subs	w8, w8, #2
	b.ne	LBB28_13
	b	LBB28_12
LBB28_12:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #32]
	b	LBB28_13
LBB28_13:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	mov	x1, sp
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x0, [x29, #-16]
	bl	_pop
	stur	wzr, [x29, #-4]
	b	LBB28_14
LBB28_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_drop_local       ; -- Begin function nvm_file_flow_drop_local
	.p2align	2
_nvm_file_flow_drop_local:              ; @nvm_file_flow_drop_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	ldr	x8, [sp, #16]
	cbz	x8, LBB29_3
	b	LBB29_1
LBB29_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB29_3
	b	LBB29_2
LBB29_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB29_8
LBB29_3:
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_live_owner
	tbnz	w0, #0, LBB29_5
	b	LBB29_4
LBB29_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB29_8
LBB29_5:
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #32]
	adds	x8, x8, #1
	b.ne	LBB29_7
	b	LBB29_6
LBB29_6:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB29_8
LBB29_7:
	ldr	x9, [sp, #16]
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	ldr	x0, [sp, #16]
	ldrh	w1, [sp, #14]
	bl	_clear_local
	stur	wzr, [x29, #-4]
	b	LBB29_8
LBB29_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_drop_stack       ; -- Begin function nvm_file_flow_drop_stack
	.p2align	2
_nvm_file_flow_drop_stack:              ; @nvm_file_flow_drop_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB30_3
	b	LBB30_1
LBB30_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB30_3
	b	LBB30_2
LBB30_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB30_10
LBB30_3:
	ldr	x8, [sp]
	cbz	x8, LBB30_6
	b	LBB30_4
LBB30_4:
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	cbz	w8, LBB30_6
	b	LBB30_5
LBB30_5:
	ldr	x8, [sp]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldr	x8, [sp]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	cbnz	x8, LBB30_7
	b	LBB30_6
LBB30_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB30_10
LBB30_7:
	ldr	x8, [sp]
	ldr	x8, [x8, #32]
	adds	x8, x8, #1
	b.ne	LBB30_9
	b	LBB30_8
LBB30_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB30_10
LBB30_9:
	ldr	x9, [sp]
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	ldr	x0, [sp]
	bl	_pop
	stur	wzr, [x29, #-4]
	b	LBB30_10
LBB30_10:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_region_begin     ; -- Begin function nvm_file_flow_region_begin
	.p2align	2
_nvm_file_flow_region_begin:            ; @nvm_file_flow_region_begin
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB31_3
	b	LBB31_1
LBB31_1:
	ldr	x8, [sp]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB31_3
	b	LBB31_2
LBB31_2:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #12]
	b	LBB31_9
LBB31_3:
	ldr	x8, [sp]
	cbnz	x8, LBB31_5
	b	LBB31_4
LBB31_4:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB31_9
LBB31_5:
	ldr	x8, [sp]
	ldrh	w8, [x8, #14]
	subs	w8, w8, #256
	b.eq	LBB31_7
	b	LBB31_6
LBB31_6:
	ldr	x8, [sp]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	adds	x8, x8, #1
	b.ne	LBB31_8
	b	LBB31_7
LBB31_7:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #12]
	b	LBB31_9
LBB31_8:
	ldr	x8, [sp]
	ldr	x10, [x8]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	ldr	x9, [sp]
	mov	x10, #45104                     ; =0xb030
	add	x9, x9, x10
	ldr	x12, [sp]
	ldrh	w10, [x12, #14]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	strh	w11, [x12, #14]
	str	x8, [x9, x10, lsl #3]
	str	wzr, [sp, #12]
	b	LBB31_9
LBB31_9:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_region_end       ; -- Begin function nvm_file_flow_region_end
	.p2align	2
_nvm_file_flow_region_end:              ; @nvm_file_flow_region_end
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB32_3
	b	LBB32_1
LBB32_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB32_3
	b	LBB32_2
LBB32_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB32_15
LBB32_3:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB32_5
	b	LBB32_4
LBB32_4:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #14]
	cbnz	w8, LBB32_6
	b	LBB32_5
LBB32_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB32_15
LBB32_6:
	ldur	x8, [x29, #-16]
	mov	x9, #45104                      ; =0xb030
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #14]
	subs	w9, w9, #1
	ldr	x8, [x8, w9, sxtw #3]
	stur	x8, [x29, #-24]
	sturh	wzr, [x29, #-26]
	b	LBB32_7
LBB32_7:                                ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-26]
	subs	w8, w8, #256
	b.hs	LBB32_14
	b	LBB32_8
LBB32_8:                                ;   in Loop: Header=BB32_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB32_12
	b	LBB32_9
LBB32_9:                                ;   in Loop: Header=BB32_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB32_12
	b	LBB32_10
LBB32_10:                               ;   in Loop: Header=BB32_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.ne	LBB32_12
	b	LBB32_11
LBB32_11:                               ;   in Loop: Header=BB32_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	add	x0, sp, #24
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	bl	_memcpy
	b	LBB32_12
LBB32_12:                               ;   in Loop: Header=BB32_7 Depth=1
	b	LBB32_13
LBB32_13:                               ;   in Loop: Header=BB32_7 Depth=1
	ldurh	w8, [x29, #-26]
	add	w8, w8, #1
	sturh	w8, [x29, #-26]
	b	LBB32_7
LBB32_14:
	ldur	x8, [x29, #-16]
	mov	x9, #45104                      ; =0xb030
	add	x9, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w11, [x8, #14]
	mov	w10, #-1                        ; =0xffffffff
	add	w10, w10, w11, uxth
	strh	w10, [x8, #14]
                                        ; implicit-def: $x8
	mov	x8, x10
	and	x10, x8, #0xffff
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	stur	wzr, [x29, #-4]
	b	LBB32_15
LBB32_15:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_borrow           ; -- Begin function nvm_file_flow_borrow
	.p2align	2
_nvm_file_flow_borrow:                  ; @nvm_file_flow_borrow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	strh	w2, [sp, #4]
	ldr	x0, [sp, #8]
	ldrh	w1, [sp, #6]
	ldrh	w2, [sp, #4]
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	bl	_file_flow_borrow_mode
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_flow_borrow_mode
_file_flow_borrow_mode:                 ; @file_flow_borrow_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturh	w2, [x29, #-20]
	sturb	w3, [x29, #-21]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB34_3
	b	LBB34_1
LBB34_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB34_3
	b	LBB34_2
LBB34_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB34_24
LBB34_3:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_local_valid
	tbz	w0, #0, LBB34_11
	b	LBB34_4
LBB34_4:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB34_11
	b	LBB34_5
LBB34_5:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	cbz	x8, LBB34_11
	b	LBB34_6
LBB34_6:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	cbnz	w8, LBB34_11
	b	LBB34_7
LBB34_7:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #12]
	subs	w8, w8, #1
	b.ne	LBB34_11
	b	LBB34_8
LBB34_8:
	ldurh	w8, [x29, #-20]
	subs	w8, w8, #256
	b.hs	LBB34_11
	b	LBB34_9
LBB34_9:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB34_11
	b	LBB34_10
LBB34_10:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #14]
	cbnz	w8, LBB34_12
	b	LBB34_11
LBB34_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB34_24
LBB34_12:
	sturh	wzr, [x29, #-24]
	b	LBB34_13
LBB34_13:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-24]
	subs	w8, w8, #256
	b.hs	LBB34_21
	b	LBB34_14
LBB34_14:                               ;   in Loop: Header=BB34_13 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB34_19
	b	LBB34_15
LBB34_15:                               ;   in Loop: Header=BB34_13 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x11, x8, x9
	ldurh	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-16]
	mov	x11, #14384                     ; =0x3830
	add	x11, x9, x11
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.ne	LBB34_19
	b	LBB34_16
LBB34_16:                               ;   in Loop: Header=BB34_13 Depth=1
	ldurb	w8, [x29, #-21]
	tbz	w8, #0, LBB34_18
	b	LBB34_17
LBB34_17:                               ;   in Loop: Header=BB34_13 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-24]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #32]
	tbnz	w8, #0, LBB34_19
	b	LBB34_18
LBB34_18:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB34_24
LBB34_19:                               ;   in Loop: Header=BB34_13 Depth=1
	b	LBB34_20
LBB34_20:                               ;   in Loop: Header=BB34_13 Depth=1
	ldurh	w8, [x29, #-24]
	add	w8, w8, #1
	sturh	w8, [x29, #-24]
	b	LBB34_13
LBB34_21:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	adds	x8, x8, #1
	b.ne	LBB34_23
	b	LBB34_22
LBB34_22:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB34_24
LBB34_23:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x11, x8, x9
	ldurh	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w10, x11
	mov	x1, sp
	mov	w8, #1                          ; =0x1
	strb	w8, [sp]
	strb	wzr, [sp, #1]
	ldurh	w8, [x29, #-18]
	strh	w8, [sp, #2]
	str	wzr, [sp, #4]
	ldur	x8, [x29, #-16]
	mov	x10, #14384                     ; =0x3830
	add	x10, x8, x10
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	str	x8, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	str	x8, [sp, #16]
	ldur	x8, [x29, #-16]
	mov	x9, #45104                      ; =0xb030
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #14]
	subs	w9, w9, #1
	ldr	x8, [x8, w9, sxtw #3]
	str	x8, [sp, #24]
	ldurb	w8, [x29, #-21]
	and	w8, w8, #0x1
	strb	w8, [sp, #32]
	stur	wzr, [x1, #33]
	str	wzr, [sp, #36]
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB34_24
LBB34_24:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_borrow_shared    ; -- Begin function nvm_file_flow_borrow_shared
	.p2align	2
_nvm_file_flow_borrow_shared:           ; @nvm_file_flow_borrow_shared
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	strh	w1, [sp, #6]
	strh	w2, [sp, #4]
	ldr	x0, [sp, #8]
	ldrh	w1, [sp, #6]
	ldrh	w2, [sp, #4]
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	bl	_file_flow_borrow_mode
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_end_borrow       ; -- Begin function nvm_file_flow_end_borrow
	.p2align	2
_nvm_file_flow_end_borrow:              ; @nvm_file_flow_end_borrow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB36_3
	b	LBB36_1
LBB36_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB36_3
	b	LBB36_2
LBB36_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB36_9
LBB36_3:
	ldur	x8, [x29, #-16]
	cbz	x8, LBB36_7
	b	LBB36_4
LBB36_4:
	ldurh	w8, [x29, #-18]
	subs	w8, w8, #256
	b.hs	LBB36_7
	b	LBB36_5
LBB36_5:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB36_7
	b	LBB36_6
LBB36_6:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbz	w8, #0, LBB36_8
	b	LBB36_7
LBB36_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB36_9
LBB36_8:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x0, sp, #32
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB36_9
LBB36_9:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_can_exit         ; -- Begin function nvm_file_flow_can_exit
	.p2align	2
_nvm_file_flow_can_exit:                ; @nvm_file_flow_can_exit
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB37_3
	b	LBB37_1
LBB37_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB37_3
	b	LBB37_2
LBB37_2:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_3:
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB37_5
	b	LBB37_4
LBB37_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_5:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	mov	x9, #24                         ; =0x18
	add	x10, x8, #24
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #14]
	cbnz	w8, LBB37_7
	b	LBB37_6
LBB37_6:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB37_8
	b	LBB37_7
LBB37_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_8:
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8, #4]
	cbz	w8, LBB37_14
	b	LBB37_9
LBB37_9:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x1, x8, x9
	add	x0, sp, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #32]
	tbz	w8, #0, LBB37_12
	b	LBB37_10
LBB37_10:
	ldur	x8, [x29, #-24]
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_same
	tbz	w0, #0, LBB37_12
	b	LBB37_11
LBB37_11:
	ldr	x0, [sp, #16]
	ldr	x1, [sp, #24]
	bl	_owned
	ldr	x8, [sp, #40]
	subs	x8, x8, #0
	cset	w8, ne
	subs	w8, w0, w8
	b.eq	LBB37_13
	b	LBB37_12
LBB37_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_13:
	b	LBB37_14
LBB37_14:
	strh	wzr, [sp, #14]
	b	LBB37_15
LBB37_15:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB37_20
	b	LBB37_16
LBB37_16:                               ;   in Loop: Header=BB37_15 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #24]
	cbz	x8, LBB37_18
	b	LBB37_17
LBB37_17:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_18:                               ;   in Loop: Header=BB37_15 Depth=1
	b	LBB37_19
LBB37_19:                               ;   in Loop: Header=BB37_15 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB37_15
LBB37_20:
	strh	wzr, [sp, #12]
	b	LBB37_21
LBB37_21:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	subs	w8, w8, #256
	b.hs	LBB37_27
	b	LBB37_22
LBB37_22:                               ;   in Loop: Header=BB37_21 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB37_25
	b	LBB37_23
LBB37_23:                               ;   in Loop: Header=BB37_21 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB37_25
	b	LBB37_24
LBB37_24:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB37_28
LBB37_25:                               ;   in Loop: Header=BB37_21 Depth=1
	b	LBB37_26
LBB37_26:                               ;   in Loop: Header=BB37_21 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB37_21
LBB37_27:
	stur	wzr, [x29, #-4]
	b	LBB37_28
LBB37_28:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_obligation       ; -- Begin function nvm_file_flow_obligation
	.p2align	2
_nvm_file_flow_obligation:              ; @nvm_file_flow_obligation
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	strh	w1, [sp, #14]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB38_3
	b	LBB38_1
LBB38_1:
	ldr	x8, [sp]
	cbz	x8, LBB38_3
	b	LBB38_2
LBB38_2:
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.lt	LBB38_4
	b	LBB38_3
LBB38_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_5
LBB38_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #44
	ldrh	w8, [sp, #14]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB38_5
LBB38_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_clone            ; -- Begin function nvm_file_flow_clone
	.p2align	2
_nvm_file_flow_clone:                   ; @nvm_file_flow_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB39_2
	b	LBB39_1
LBB39_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB39_3
	b	LBB39_2
LBB39_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB39_8
LBB39_3:
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	ldr	w8, [x8]
	adds	w8, w8, #1
	b.ne	LBB39_5
	b	LBB39_4
LBB39_4:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB39_8
LBB39_5:
	mov	x0, #47152                      ; =0xb830
	bl	_malloc
	str	x0, [sp]
	ldr	x8, [sp]
	cbnz	x8, LBB39_7
	b	LBB39_6
LBB39_6:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB39_8
LBB39_7:
	ldr	x0, [sp]
	ldr	x1, [sp, #16]
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x8, [sp, #16]
	ldr	x9, [x8]
	ldr	w8, [x9]
	add	w8, w8, #1
	str	w8, [x9]
	ldr	x8, [sp]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB39_8
LBB39_8:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_refine           ; -- Begin function nvm_file_flow_refine
	.p2align	2
_nvm_file_flow_refine:                  ; @nvm_file_flow_refine
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB40_5
	b	LBB40_1
LBB40_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB40_5
	b	LBB40_2
LBB40_2:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB40_5
	b	LBB40_3
LBB40_3:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.eq	LBB40_5
	b	LBB40_4
LBB40_4:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_local_valid
	tbnz	w0, #0, LBB40_6
	b	LBB40_5
LBB40_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_6:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB40_8
	b	LBB40_7
LBB40_7:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_8:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #32
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #48]
	tbz	w8, #0, LBB40_11
	b	LBB40_9
LBB40_9:
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	bl	_result_type
	tbz	w0, #0, LBB40_11
	b	LBB40_10
LBB40_10:
	ldrb	w8, [sp, #33]
	cbz	w8, LBB40_12
	b	LBB40_11
LBB40_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_12:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w8, [x8]
	adds	w8, w8, #3
	b.ls	LBB40_14
	b	LBB40_13
LBB40_13:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_14:
	add	x1, sp, #24
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	str	xzr, [sp, #16]
	ldur	x0, [x29, #-16]
	bl	_nvm_file_flow_clone
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbz	w8, LBB40_16
	b	LBB40_15
LBB40_15:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_16:
	ldur	x0, [x29, #-16]
	add	x1, sp, #16
	bl	_nvm_file_flow_clone
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbz	w8, LBB40_18
	b	LBB40_17
LBB40_17:
	ldr	x0, [sp, #24]
	bl	_nvm_file_flow_state_free
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB40_19
LBB40_18:
	ldr	w9, [sp, #64]
	mov	w8, #3                          ; =0x3
	subs	w9, w9, #3
	cset	w9, ne
	ldr	x11, [sp, #24]
	mov	x10, #40                        ; =0x28
	strb	w9, [x11, #40]
	ldr	w11, [sp, #64]
	mov	w9, #2                          ; =0x2
	subs	w11, w11, #2
	cset	w11, ne
	ldr	x12, [sp, #16]
	strb	w11, [x12, #40]
	ldr	x12, [sp, #24]
	mov	x11, #14384                     ; =0x3830
	add	x14, x12, x11
	ldurh	w12, [x29, #-18]
                                        ; kill: def $x12 killed $w12
	mov	x13, x10
                                        ; kill: def $w12 killed $w12 killed $x12
	umaddl	x12, w12, w13, x14
	str	w9, [x12, #32]
	ldr	x9, [sp, #16]
	add	x11, x9, x11
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #32]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-40]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB40_19
LBB40_19:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function result_type
_result_type:                           ; @result_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	ldr	w9, [sp, #28]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #2
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB41_2
	b	LBB41_1
LBB41_1:
	ldr	w8, [sp, #28]
	subs	w8, w8, #3
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB41_2
LBB41_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_join             ; -- Begin function nvm_file_flow_join
	.p2align	2
_nvm_file_flow_join:                    ; @nvm_file_flow_join
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #576
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #48
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	str	x0, [x8, #16]
	str	x1, [x8, #8]
	str	x2, [x8]
	ldr	x8, [x8, #16]
	cbz	x8, LBB42_3
	b	LBB42_1
LBB42_1:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	cbz	x8, LBB42_3
	b	LBB42_2
LBB42_2:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB42_4
	b	LBB42_3
LBB42_3:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_4:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldr	x8, [x8]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	subs	x8, x8, x9
	b.ne	LBB42_7
	b	LBB42_5
LBB42_5:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldr	w8, [x8, #8]
	ldr	x9, [x9, #8]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB42_7
	b	LBB42_6
LBB42_6:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #8]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.eq	LBB42_8
	b	LBB42_7
LBB42_7:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_8:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB42_10
	b	LBB42_9
LBB42_9:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8]
	strb	wzr, [x9]
	str	wzr, [x8, #28]
	b	LBB42_91
LBB42_10:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB42_12
	b	LBB42_11
LBB42_11:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x0, [x8, #16]
	ldr	x1, [x8, #8]
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x10, [x8]
	mov	w9, #1                          ; =0x1
	strb	w9, [x10]
	str	wzr, [x8, #28]
	b	LBB42_91
LBB42_12:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldrh	w8, [x8, #12]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB42_15
	b	LBB42_13
LBB42_13:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldrh	w8, [x8, #14]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ne	LBB42_15
	b	LBB42_14
LBB42_14:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	ldr	x8, [x8, #32]
	ldr	x9, [x9, #8]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.eq	LBB42_16
	b	LBB42_15
LBB42_15:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_16:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	sturb	wzr, [x29, #-49]
	ldr	x9, [x8, #16]
	ldr	x10, [x9]
	mov	x9, #24                         ; =0x18
	add	x10, x10, #24
	ldr	x8, [x8, #16]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #2]
	sturh	w8, [x29, #-52]
	sturh	wzr, [x29, #-54]
	b	LBB42_17
LBB42_17:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-54]
	ldurh	w9, [x29, #-52]
	subs	w8, w8, w9
	b.ge	LBB42_27
	b	LBB42_18
LBB42_18:                               ;   in Loop: Header=BB42_17 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	mov	x10, #14384                     ; =0x3830
	add	x13, x9, x10
	ldurh	w9, [x29, #-54]
	mov	x11, x9
	mov	x9, #40                         ; =0x28
	mov	x12, x9
                                        ; kill: def $w11 killed $w11 killed $x11
	umaddl	x1, w11, w12, x13
	ldr	x8, [x8, #8]
	add	x10, x8, x10
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	sub	x0, x29, #96
	str	x0, [sp, #120]                  ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #112]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #112]                  ; 8-byte Folded Reload
	sub	x0, x29, #136
	str	x0, [sp, #128]                  ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #128]                  ; 8-byte Folded Reload
	bl	_value_same
	tbnz	w0, #0, LBB42_20
	b	LBB42_19
LBB42_19:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_20:                               ;   in Loop: Header=BB42_17 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB42_25
	b	LBB42_21
LBB42_21:                               ;   in Loop: Header=BB42_17 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	mov	x11, #14384                     ; =0x3830
	add	x13, x8, x11
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x12, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w12, x13
	ldr	w8, [x8, #32]
	ldr	x9, [x9, #8]
	add	x11, x9, x11
	ldurh	w9, [x29, #-54]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.eq	LBB42_25
	b	LBB42_22
LBB42_22:                               ;   in Loop: Header=BB42_17 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_result_type
	tbnz	w0, #0, LBB42_24
	b	LBB42_23
LBB42_23:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_24:                               ;   in Loop: Header=BB42_17 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #32]
	subs	w8, w8, #1
	cset	w9, ne
	ldurb	w8, [x29, #-49]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-49]
	b	LBB42_25
LBB42_25:                               ;   in Loop: Header=BB42_17 Depth=1
	b	LBB42_26
LBB42_26:                               ;   in Loop: Header=BB42_17 Depth=1
	ldurh	w8, [x29, #-54]
	add	w8, w8, #1
	sturh	w8, [x29, #-54]
	b	LBB42_17
LBB42_27:
	sturh	wzr, [x29, #-138]
	b	LBB42_28
LBB42_28:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldurh	w8, [x29, #-138]
	ldr	x9, [x9, #16]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ge	LBB42_37
	b	LBB42_29
LBB42_29:                               ;   in Loop: Header=BB42_28 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	mov	x10, #24624                     ; =0x6030
	add	x13, x9, x10
	ldurh	w9, [x29, #-138]
	mov	x11, x9
	mov	x9, #40                         ; =0x28
	mov	x12, x9
                                        ; kill: def $w11 killed $w11 killed $x11
	umaddl	x1, w11, w12, x13
	ldr	x8, [x8, #8]
	add	x10, x8, x10
	ldurh	w8, [x29, #-138]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	sub	x0, x29, #184
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #80]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #80]                   ; 8-byte Folded Reload
	sub	x0, x29, #224
	str	x0, [sp, #96]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
	bl	_value_same
	tbnz	w0, #0, LBB42_31
	b	LBB42_30
LBB42_30:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_31:                               ;   in Loop: Header=BB42_28 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	mov	x11, #24624                     ; =0x6030
	add	x13, x8, x11
	ldurh	w8, [x29, #-138]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x12, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w12, x13
	ldr	w8, [x8, #32]
	ldr	x9, [x9, #8]
	add	x11, x9, x11
	ldurh	w9, [x29, #-138]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.eq	LBB42_35
	b	LBB42_32
LBB42_32:                               ;   in Loop: Header=BB42_28 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldurh	w8, [x29, #-138]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_result_type
	tbnz	w0, #0, LBB42_34
	b	LBB42_33
LBB42_33:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_34:                               ;   in Loop: Header=BB42_28 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldurh	w8, [x29, #-138]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #32]
	subs	w8, w8, #1
	cset	w9, ne
	ldurb	w8, [x29, #-49]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-49]
	b	LBB42_35
LBB42_35:                               ;   in Loop: Header=BB42_28 Depth=1
	b	LBB42_36
LBB42_36:                               ;   in Loop: Header=BB42_28 Depth=1
	ldurh	w8, [x29, #-138]
	add	w8, w8, #1
	sturh	w8, [x29, #-138]
	b	LBB42_28
LBB42_37:
	sturh	wzr, [x29, #-226]
	b	LBB42_38
LBB42_38:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldurh	w8, [x29, #-226]
	ldr	x9, [x9, #16]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ge	LBB42_43
	b	LBB42_39
LBB42_39:                               ;   in Loop: Header=BB42_38 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	mov	x10, #45104                     ; =0xb030
	add	x8, x8, x10
	ldurh	w11, [x29, #-226]
                                        ; kill: def $x11 killed $w11
	ldr	x8, [x8, x11, lsl #3]
	ldr	x9, [x9, #8]
	add	x9, x9, x10
	ldurh	w10, [x29, #-226]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	subs	x8, x8, x9
	b.eq	LBB42_41
	b	LBB42_40
LBB42_40:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_41:                               ;   in Loop: Header=BB42_38 Depth=1
	b	LBB42_42
LBB42_42:                               ;   in Loop: Header=BB42_38 Depth=1
	ldurh	w8, [x29, #-226]
	add	w8, w8, #1
	sturh	w8, [x29, #-226]
	b	LBB42_38
LBB42_43:
	sturh	wzr, [x29, #-228]
	b	LBB42_44
LBB42_44:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-228]
	subs	w8, w8, #256
	b.hs	LBB42_49
	b	LBB42_45
LBB42_45:                               ;   in Loop: Header=BB42_44 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	mov	x10, #34864                     ; =0x8830
	add	x13, x9, x10
	ldurh	w9, [x29, #-228]
	mov	x11, x9
	mov	x9, #40                         ; =0x28
	mov	x12, x9
                                        ; kill: def $w11 killed $w11 killed $x11
	umaddl	x1, w11, w12, x13
	ldr	x8, [x8, #8]
	add	x10, x8, x10
	ldurh	w8, [x29, #-228]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x0, sp, #320
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	add	x0, sp, #280
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	bl	_reference_same
	tbnz	w0, #0, LBB42_47
	b	LBB42_46
LBB42_46:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_47:                               ;   in Loop: Header=BB42_44 Depth=1
	b	LBB42_48
LBB42_48:                               ;   in Loop: Header=BB42_44 Depth=1
	ldurh	w8, [x29, #-228]
	add	w8, w8, #1
	sturh	w8, [x29, #-228]
	b	LBB42_44
LBB42_49:
	strh	wzr, [sp, #278]
	strh	wzr, [sp, #276]
	b	LBB42_50
LBB42_50:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB42_52 Depth 2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldrh	w8, [sp, #276]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB42_61
	b	LBB42_51
LBB42_51:                               ;   in Loop: Header=BB42_50 Depth=1
	strb	wzr, [sp, #275]
	strh	wzr, [sp, #272]
	b	LBB42_52
LBB42_52:                               ;   Parent Loop BB42_50 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldrh	w8, [sp, #272]
	ldr	x9, [x9, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB42_59
	b	LBB42_53
LBB42_53:                               ;   in Loop: Header=BB42_52 Depth=2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	add	x12, x8, #44
	ldrh	w8, [sp, #272]
                                        ; kill: def $x8 killed $w8
	mov	x10, #56                        ; =0x38
	mov	x11, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	ldr	w8, [x8, #4]
	ldr	x9, [x9, #8]
	add	x11, x9, #44
	ldrh	w9, [sp, #276]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB42_57
	b	LBB42_54
LBB42_54:                               ;   in Loop: Header=BB42_50 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	add	x12, x9, #44
	ldrh	w9, [sp, #272]
	mov	x10, x9
	mov	x9, #56                         ; =0x38
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x1, w10, w11, x12
	ldr	x8, [x8, #8]
	add	x10, x8, #44
	ldrh	w8, [sp, #276]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	add	x0, sp, #216
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, sp, #160
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	bl	_obligation_same
	tbnz	w0, #0, LBB42_56
	b	LBB42_55
LBB42_55:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_56:                               ;   in Loop: Header=BB42_50 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #275]
	b	LBB42_59
LBB42_57:                               ;   in Loop: Header=BB42_52 Depth=2
	b	LBB42_58
LBB42_58:                               ;   in Loop: Header=BB42_52 Depth=2
	ldrh	w8, [sp, #272]
	add	w8, w8, #1
	strh	w8, [sp, #272]
	b	LBB42_52
LBB42_59:                               ;   in Loop: Header=BB42_50 Depth=1
	ldrb	w8, [sp, #275]
	eor	w8, w8, #0x1
	and	w9, w8, #0x1
	ldrh	w8, [sp, #278]
	add	w8, w8, w9
	strh	w8, [sp, #278]
	b	LBB42_60
LBB42_60:                               ;   in Loop: Header=BB42_50 Depth=1
	ldrh	w8, [sp, #276]
	add	w8, w8, #1
	strh	w8, [sp, #276]
	b	LBB42_50
LBB42_61:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	ldrh	w8, [x8, #16]
	ldrh	w9, [sp, #278]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.ls	LBB42_63
	b	LBB42_62
LBB42_62:
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #28]
	b	LBB42_91
LBB42_63:
	strh	wzr, [sp, #158]
	b	LBB42_64
LBB42_64:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #158]
	ldurh	w9, [x29, #-52]
	subs	w8, w8, w9
	b.ge	LBB42_70
	b	LBB42_65
LBB42_65:                               ;   in Loop: Header=BB42_64 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #158]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbz	w8, #0, LBB42_68
	b	LBB42_66
LBB42_66:                               ;   in Loop: Header=BB42_64 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	mov	x11, #14384                     ; =0x3830
	add	x13, x8, x11
	ldrh	w8, [sp, #158]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x12, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w12, x13
	ldr	w8, [x8, #32]
	ldr	x9, [x9, #8]
	add	x11, x9, x11
	ldrh	w9, [sp, #158]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.eq	LBB42_68
	b	LBB42_67
LBB42_67:                               ;   in Loop: Header=BB42_64 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #158]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #32]
	b	LBB42_68
LBB42_68:                               ;   in Loop: Header=BB42_64 Depth=1
	b	LBB42_69
LBB42_69:                               ;   in Loop: Header=BB42_64 Depth=1
	ldrh	w8, [sp, #158]
	add	w8, w8, #1
	strh	w8, [sp, #158]
	b	LBB42_64
LBB42_70:
	strh	wzr, [sp, #156]
	b	LBB42_71
LBB42_71:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldrh	w8, [sp, #156]
	ldr	x9, [x9, #16]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ge	LBB42_76
	b	LBB42_72
LBB42_72:                               ;   in Loop: Header=BB42_71 Depth=1
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	mov	x11, #24624                     ; =0x6030
	add	x13, x8, x11
	ldrh	w8, [sp, #156]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x12, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w12, x13
	ldr	w8, [x8, #32]
	ldr	x9, [x9, #8]
	add	x11, x9, x11
	ldrh	w9, [sp, #156]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.eq	LBB42_74
	b	LBB42_73
LBB42_73:                               ;   in Loop: Header=BB42_71 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldrh	w8, [sp, #156]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #32]
	b	LBB42_74
LBB42_74:                               ;   in Loop: Header=BB42_71 Depth=1
	b	LBB42_75
LBB42_75:                               ;   in Loop: Header=BB42_71 Depth=1
	ldrh	w8, [sp, #156]
	add	w8, w8, #1
	strh	w8, [sp, #156]
	b	LBB42_71
LBB42_76:
	strh	wzr, [sp, #154]
	b	LBB42_77
LBB42_77:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB42_79 Depth 2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldrh	w8, [sp, #154]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB42_88
	b	LBB42_78
LBB42_78:                               ;   in Loop: Header=BB42_77 Depth=1
	strb	wzr, [sp, #153]
	strh	wzr, [sp, #150]
	b	LBB42_79
LBB42_79:                               ;   Parent Loop BB42_77 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldrh	w8, [sp, #150]
	ldr	x9, [x9, #16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB42_84
	b	LBB42_80
LBB42_80:                               ;   in Loop: Header=BB42_79 Depth=2
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x8, [x9, #16]
	add	x12, x8, #44
	ldrh	w8, [sp, #150]
                                        ; kill: def $x8 killed $w8
	mov	x10, #56                        ; =0x38
	mov	x11, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	ldr	w8, [x8, #4]
	ldr	x9, [x9, #8]
	add	x11, x9, #44
	ldrh	w9, [sp, #154]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB42_82
	b	LBB42_81
LBB42_81:                               ;   in Loop: Header=BB42_77 Depth=1
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #153]
	b	LBB42_84
LBB42_82:                               ;   in Loop: Header=BB42_79 Depth=2
	b	LBB42_83
LBB42_83:                               ;   in Loop: Header=BB42_79 Depth=2
	ldrh	w8, [sp, #150]
	add	w8, w8, #1
	strh	w8, [sp, #150]
	b	LBB42_79
LBB42_84:                               ;   in Loop: Header=BB42_77 Depth=1
	ldrb	w8, [sp, #153]
	tbnz	w8, #0, LBB42_86
	b	LBB42_85
LBB42_85:                               ;   in Loop: Header=BB42_77 Depth=1
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	add	x12, x9, #44
	ldr	x11, [x8, #16]
	ldrh	w9, [x11, #16]
	mov	x10, x9
	mov	x9, x10
	add	w9, w9, #1
	strh	w9, [x11, #16]
	mov	x9, #56                         ; =0x38
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x0, w10, w11, x12
	ldr	x8, [x8, #8]
	add	x10, x8, #44
	ldrh	w8, [sp, #154]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	b	LBB42_86
LBB42_86:                               ;   in Loop: Header=BB42_77 Depth=1
	b	LBB42_87
LBB42_87:                               ;   in Loop: Header=BB42_77 Depth=1
	ldrh	w8, [sp, #154]
	add	w8, w8, #1
	strh	w8, [sp, #154]
	b	LBB42_77
LBB42_88:
	ldurb	w8, [x29, #-49]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbnz	w8, #0, LBB42_90
	b	LBB42_89
LBB42_89:
	ldrh	w8, [sp, #278]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB42_90
LBB42_90:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w9, [sp, #4]                    ; 4-byte Folded Reload
	ldr	x10, [x8]
	and	w9, w9, #0x1
	strb	w9, [x10]
	str	wzr, [x8, #28]
	b	LBB42_91
LBB42_91:
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	w0, [x8, #28]
	add	sp, sp, #576
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function value_same
_value_same:                            ; @value_same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x8, x1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x0, x9
	stur	x0, [x29, #-8]
	mov	x1, x8
	stur	x1, [x29, #-16]
	ldr	x0, [x9]
	ldr	x1, [x9, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	mov	w8, #0                          ; =0x0
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	tbz	w0, #0, LBB43_3
	b	LBB43_1
LBB43_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x9, #16]
	and	w9, w9, #0x1
	ldrb	w8, [x8, #16]
	and	w10, w8, #0x1
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB43_3
	b	LBB43_2
LBB43_2:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	cset	w8, eq
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b	LBB43_3
LBB43_3:
	ldur	w8, [x29, #-20]                 ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function reference_same
_reference_same:                        ; @reference_same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, x0
	str	x8, [sp, #40]
	mov	x8, x1
	str	x8, [sp, #32]
	ldrb	w8, [x0]
	and	w9, w8, #0x1
	ldrb	w8, [x1]
	and	w10, w8, #0x1
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b.ne	LBB44_10
	b	LBB44_1
LBB44_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #4]                    ; 4-byte Folded Spill
	tbz	w8, #0, LBB44_9
	b	LBB44_2
LBB44_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x9, #1]
	and	w9, w9, #0x1
	ldrb	w8, [x8, #1]
	and	w10, w8, #0x1
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB44_8
	b	LBB44_3
LBB44_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w9, [x9, #2]
	ldrh	w10, [x8, #2]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB44_8
	b	LBB44_4
LBB44_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #8]
	ldr	x10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB44_8
	b	LBB44_5
LBB44_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #16]
	ldr	x10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB44_8
	b	LBB44_6
LBB44_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9, #24]
	ldr	x10, [x8, #24]
	mov	w8, #0                          ; =0x0
	subs	x9, x9, x10
	str	w8, [sp]                        ; 4-byte Folded Spill
	b.ne	LBB44_8
	b	LBB44_7
LBB44_7:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w8, [x8, #32]
	and	w8, w8, #0x1
	ldrb	w9, [x9, #32]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp]                        ; 4-byte Folded Spill
	b	LBB44_8
LBB44_8:
	ldr	w8, [sp]                        ; 4-byte Folded Reload
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB44_9
LBB44_9:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB44_10
LBB44_10:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function obligation_same
_obligation_same:                       ; @obligation_same
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, x0
	stur	x8, [x29, #-8]
	mov	x8, x1
	stur	x8, [x29, #-16]
	ldr	w9, [x0]
	ldr	w10, [x1]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_1
LBB45_1:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #4]
	ldr	w10, [x8, #4]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_2
LBB45_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #8]
	ldr	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_3
LBB45_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #12]
	ldr	w10, [x8, #12]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_4
LBB45_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #16]
	ldr	w10, [x8, #16]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_5
LBB45_5:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #20]
	ldr	w10, [x8, #20]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_6
LBB45_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w9, [x9, #24]
	ldrh	w10, [x8, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_7
LBB45_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w9, [x9, #26]
	ldrh	w10, [x8, #26]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_8
LBB45_8:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrh	w9, [x9, #28]
	ldrh	w10, [x8, #28]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_9
LBB45_9:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldrb	w9, [x9, #30]
	ldrb	w10, [x8, #30]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_10
LBB45_10:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x9, #32]
	ldr	x1, [x9, #40]
	ldr	x2, [x8, #32]
	ldr	x3, [x8, #40]
	bl	_same
	mov	w8, #0                          ; =0x0
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	tbz	w0, #0, LBB45_13
	b	LBB45_11
LBB45_11:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w9, [x9, #48]
	ldr	w10, [x8, #48]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b.ne	LBB45_13
	b	LBB45_12
LBB45_12:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #52]
	ldr	w9, [x9, #52]
	subs	w8, w8, w9
	cset	w8, eq
	stur	w8, [x29, #-20]                 ; 4-byte Folded Spill
	b	LBB45_13
LBB45_13:
	ldur	w8, [x29, #-20]                 ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_construct        ; -- Begin function nvm_file_flow_construct
	.p2align	2
_nvm_file_flow_construct:               ; @nvm_file_flow_construct
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB46_2
	b	LBB46_1
LBB46_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB46_4
	b	LBB46_3
LBB46_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_4:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	sub	x2, x29, #40
	bl	_catalog_type
	tbnz	w0, #0, LBB46_6
	b	LBB46_5
LBB46_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_6:
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-32]
	bl	_owned
	tbz	w0, #0, LBB46_8
	b	LBB46_7
LBB46_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_8:
	ldur	w8, [x29, #-20]
	mov	x0, x8
	bl	_nl_file_catalog_type
	stur	x0, [x29, #-48]
	ldur	w8, [x29, #-28]
	subs	w8, w8, #4
	cset	w8, eq
	sturb	w8, [x29, #-49]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB46_12
	b	LBB46_9
LBB46_9:
	ldurb	w8, [x29, #-49]
	tbz	w8, #0, LBB46_11
	b	LBB46_10
LBB46_10:
	ldurh	w8, [x29, #-22]
	cbnz	w8, LBB46_12
	b	LBB46_13
LBB46_11:
	ldurh	w8, [x29, #-22]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-48]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.lo	LBB46_13
	b	LBB46_12
LBB46_12:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_13:
	ldurb	w8, [x29, #-49]
	tbz	w8, #0, LBB46_15
	b	LBB46_14
LBB46_14:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #32]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB46_16
LBB46_15:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB46_16
LBB46_16:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB46_18
	b	LBB46_17
LBB46_17:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_18:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-64]
	subs	x8, x8, x9
	add	x8, x8, #1
	subs	x8, x8, #256
	b.ls	LBB46_20
	b	LBB46_19
LBB46_19:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_20:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-64]
	subs	x8, x8, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	sturh	w8, [x29, #-66]
	stur	xzr, [x29, #-80]
	b	LBB46_21
LBB46_21:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-80]
	ldur	x9, [x29, #-64]
	subs	x8, x8, x9
	b.hs	LBB46_34
	b	LBB46_22
LBB46_22:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #24]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldurb	w8, [x29, #-49]
	tbz	w8, #0, LBB46_24
	b	LBB46_23
LBB46_23:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x8, [x29, #-80]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB46_25
LBB46_24:                               ;   in Loop: Header=BB46_21 Depth=1
	ldurh	w8, [x29, #-22]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB46_25
LBB46_25:                               ;   in Loop: Header=BB46_21 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #104]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldr	x8, [sp, #104]
	ldr	x2, [x8, #16]
	sub	x3, x29, #96
	bl	_member_type
	tbz	w0, #0, LBB46_27
	b	LBB46_26
LBB46_26:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x0, [x29, #-96]
	ldur	x1, [x29, #-88]
	bl	_owned
	tbz	w0, #0, LBB46_28
	b	LBB46_27
LBB46_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_28:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x8, x8, x9
	ldurh	w9, [x29, #-66]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-80]
	add	x9, x9, x10
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x1, x8, x9
	add	x0, sp, #64
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #80]
	tbz	w8, #0, LBB46_31
	b	LBB46_29
LBB46_29:                               ;   in Loop: Header=BB46_21 Depth=1
	ldr	x8, [sp, #88]
	cbnz	x8, LBB46_31
	b	LBB46_30
LBB46_30:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x0, [x29, #-96]
	ldur	x1, [x29, #-88]
	ldr	x2, [sp, #64]
	ldr	x3, [sp, #72]
	bl	_same
	tbnz	w0, #0, LBB46_32
	b	LBB46_31
LBB46_31:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB46_40
LBB46_32:                               ;   in Loop: Header=BB46_21 Depth=1
	b	LBB46_33
LBB46_33:                               ;   in Loop: Header=BB46_21 Depth=1
	ldur	x8, [x29, #-80]
	add	x8, x8, #1
	stur	x8, [x29, #-80]
	b	LBB46_21
LBB46_34:
	b	LBB46_35
LBB46_35:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-66]
	subs	w8, w8, w9
	b.le	LBB46_37
	b	LBB46_36
LBB46_36:                               ;   in Loop: Header=BB46_35 Depth=1
	ldur	x0, [x29, #-16]
	bl	_pop
	b	LBB46_35
LBB46_37:
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-32]
	add	x8, sp, #24
	mov	w9, #1                          ; =0x1
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldurb	w8, [x29, #-49]
	tbnz	w8, #0, LBB46_39
	b	LBB46_38
LBB46_38:
	ldurh	w10, [x29, #-22]
	mov	w8, #3                          ; =0x3
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #0
	csel	w8, w8, w9, ne
	str	w8, [sp, #56]
	b	LBB46_39
LBB46_39:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x11, [x29, #-16]
	ldrh	w8, [x11, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x11, #12]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #24
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB46_40
LBB46_40:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function catalog_type
_catalog_type:                          ; @catalog_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-20]
	add	x2, sp, #28
	bl	_nvm_file_nominal_type
	tbnz	w0, #0, LBB47_2
	b	LBB47_1
LBB47_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_3
LBB47_2:
	ldur	x8, [x29, #-32]
	ldrb	w11, [sp, #40]
	mov	w10, #10                        ; =0xa
	mov	w9, #8                          ; =0x8
	subs	w11, w11, #0
	csel	w9, w9, w10, eq
	strb	w9, [sp, #12]
	strb	wzr, [sp, #13]
	strh	wzr, [sp, #14]
	ldr	w9, [sp, #28]
	str	w9, [sp, #16]
	ldr	w9, [sp, #32]
	str	w9, [sp, #20]
	ldr	w9, [sp, #44]
	str	w9, [sp, #24]
	ldur	q0, [sp, #12]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB47_3
LBB47_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function member_type
_member_type:                           ; @member_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB48_2
	b	LBB48_1
LBB48_1:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-56]
	stur	x1, [x29, #-48]
	ldur	q0, [x29, #-56]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_2:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB48_4
	b	LBB48_3
LBB48_3:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	bl	_scalar_type
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stur	x0, [x29, #-72]
	stur	x1, [x29, #-64]
	ldur	q0, [x29, #-72]
	str	q0, [x9]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_4:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB48_6
	b	LBB48_5
LBB48_5:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #4                          ; =0x4
	bl	_scalar_type
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #72]
	str	x1, [sp, #80]
	ldur	q0, [sp, #72]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_6:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB48_8
	b	LBB48_7
LBB48_7:
	ldur	x8, [x29, #-40]
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	w0, #5                          ; =0x5
	bl	_scalar_type
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #56]
	str	x1, [sp, #64]
	ldur	q0, [sp, #56]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_8:
	str	wzr, [sp, #52]
	b	LBB48_9
LBB48_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	subs	w8, w8, #8
	b.hs	LBB48_15
	b	LBB48_10
LBB48_10:                               ;   in Loop: Header=BB48_9 Depth=1
	ldr	w8, [sp, #52]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbz	x8, LBB48_13
	b	LBB48_11
LBB48_11:                               ;   in Loop: Header=BB48_9 Depth=1
	ldr	x8, [sp, #40]
	ldr	x0, [x8]
	ldur	x1, [x29, #-32]
	bl	_strcmp
	cbnz	w0, LBB48_13
	b	LBB48_12
LBB48_12:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #52]
	ldur	x2, [x29, #-40]
	bl	_catalog_type
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_13:                               ;   in Loop: Header=BB48_9 Depth=1
	b	LBB48_14
LBB48_14:                               ;   in Loop: Header=BB48_9 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB48_9
LBB48_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB48_16
LBB48_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_field            ; -- Begin function nvm_file_flow_field
	.p2align	2
_nvm_file_flow_field:                   ; @nvm_file_flow_field
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB49_2
	b	LBB49_1
LBB49_1:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB49_3
	b	LBB49_2
LBB49_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB49_15
LBB49_3:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB49_5
	b	LBB49_4
LBB49_4:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB49_15
LBB49_5:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	sub	x0, x29, #64
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB49_7
	b	LBB49_6
LBB49_6:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #4
	b.eq	LBB49_8
	b	LBB49_7
LBB49_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB49_15
LBB49_8:
	ldur	w8, [x29, #-56]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbz	x8, LBB49_13
	b	LBB49_9
LBB49_9:
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #72]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB49_13
	b	LBB49_10
LBB49_10:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-56]
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #24]
	ldurh	w9, [x29, #-18]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #56
	bl	_member_type
	tbz	w0, #0, LBB49_13
	b	LBB49_11
LBB49_11:
	ldrb	w0, [sp, #56]
	bl	_scalar
	tbz	w0, #0, LBB49_13
	b	LBB49_12
LBB49_12:
	ldr	w8, [sp, #60]
	adds	w8, w8, #1
	b.eq	LBB49_14
	b	LBB49_13
LBB49_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB49_15
LBB49_14:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [sp, #56]
	ldr	x1, [sp, #64]
	add	x8, sp, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB49_15
LBB49_15:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_take_result      ; -- Begin function nvm_file_flow_take_result
	.p2align	2
_nvm_file_flow_take_result:             ; @nvm_file_flow_take_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	w2, [x29, #-24]
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_local_valid
	tbnz	w0, #0, LBB50_2
	b	LBB50_1
LBB50_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB50_4
	b	LBB50_3
LBB50_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_4:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #64
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldurb	w8, [x29, #-48]
	tbz	w8, #0, LBB50_9
	b	LBB50_5
LBB50_5:
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-56]
	bl	_result_type
	tbz	w0, #0, LBB50_9
	b	LBB50_6
LBB50_6:
	ldur	w8, [x29, #-32]
	ldur	w9, [x29, #-24]
	subs	w8, w8, w9
	b.ne	LBB50_9
	b	LBB50_7
LBB50_7:
	ldur	w8, [x29, #-24]
	subs	w8, w8, #2
	b.eq	LBB50_10
	b	LBB50_8
LBB50_8:
	ldur	w8, [x29, #-24]
	subs	w8, w8, #3
	b.eq	LBB50_10
	b	LBB50_9
LBB50_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_10:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB50_12
	b	LBB50_11
LBB50_11:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_12:
	ldur	w8, [x29, #-56]
	mov	x0, x8
	bl	_nl_file_catalog_type
	stur	x0, [x29, #-72]
	ldur	x8, [x29, #-72]
	cbz	x8, LBB50_15
	b	LBB50_13
LBB50_13:
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB50_15
	b	LBB50_14
LBB50_14:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-56]
	ldur	x8, [x29, #-72]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-24]
	subs	w9, w9, #3
	cset	w10, eq
                                        ; implicit-def: $x9
	mov	x9, x10
	and	x9, x9, #0x1
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #72
	bl	_member_type
	tbnz	w0, #0, LBB50_16
	b	LBB50_15
LBB50_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_16:
	ldr	x0, [sp, #72]
	ldr	x1, [sp, #80]
	bl	_owned
	tbz	w0, #0, LBB50_20
	b	LBB50_17
LBB50_17:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB50_19
	b	LBB50_18
LBB50_18:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #2
	b.eq	LBB50_20
	b	LBB50_19
LBB50_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB50_24
LBB50_20:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x11, [x29, #-16]
	ldrh	w8, [x11, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x11, #12]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x0, [sp, #72]
	ldr	x1, [sp, #80]
	bl	_owned
	tbz	w0, #0, LBB50_22
	b	LBB50_21
LBB50_21:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB50_23
LBB50_22:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB50_23
LBB50_23:
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	x1, [sp, #80]
	add	x8, sp, #32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
	and	w2, w9, #0x1
	bl	_initial_value
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_clear_local
	stur	wzr, [x29, #-4]
	b	LBB50_24
LBB50_24:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_service          ; -- Begin function nvm_file_flow_service
	.p2align	2
_nvm_file_flow_service:                 ; @nvm_file_flow_service
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #528
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #188
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	sturh	w3, [x29, #-42]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB51_2
	b	LBB51_1
LBB51_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_2:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB51_4
	b	LBB51_3
LBB51_3:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_4:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-48]
	stur	wzr, [x29, #-52]
	b	LBB51_5
LBB51_5:                                ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-52]
	subs	w8, w8, #5
	b.hs	LBB51_11
	b	LBB51_6
LBB51_6:                                ;   in Loop: Header=BB51_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-52]
	sub	x2, x29, #56
	bl	_nvm_file_nominal_import
	tbz	w0, #0, LBB51_9
	b	LBB51_7
LBB51_7:                                ;   in Loop: Header=BB51_5 Depth=1
	ldur	w8, [x29, #-56]
	ldur	w9, [x29, #-40]
	subs	w8, w8, w9
	b.ne	LBB51_9
	b	LBB51_8
LBB51_8:
	ldur	w8, [x29, #-52]
	stur	w8, [x29, #-48]
	b	LBB51_11
LBB51_9:                                ;   in Loop: Header=BB51_5 Depth=1
	b	LBB51_10
LBB51_10:                               ;   in Loop: Header=BB51_5 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB51_5
LBB51_11:
	ldur	w8, [x29, #-48]
	mov	x0, x8
	bl	_nl_file_catalog_method
	stur	x0, [x29, #-64]
	ldur	x8, [x29, #-64]
	cbz	x8, LBB51_13
	b	LBB51_12
LBB51_12:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB51_14
	b	LBB51_13
LBB51_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_14:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-64]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #56]
	subs	x9, x9, #1
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	mov	w1, #0                          ; =0x0
	sub	x3, x29, #80
	bl	_member_type
	tbz	w0, #0, LBB51_16
	b	LBB51_15
LBB51_15:
	ldur	x0, [x29, #-32]
	mov	w1, #0                          ; =0x0
	sub	x2, x29, #96
	bl	_catalog_type
	tbnz	w0, #0, LBB51_17
	b	LBB51_16
LBB51_16:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_17:
	sturh	wzr, [x29, #-98]
	sub	x0, x29, #156
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	stur	wzr, [x29, #-156]
	ldur	w9, [x29, #-36]
	stur	w9, [x29, #-152]
	ldur	w9, [x29, #-40]
	stur	w9, [x29, #-148]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #56]
	subs	x9, x9, #1
                                        ; kill: def $w9 killed $w9 killed $x9
	sturh	w9, [x29, #-132]
	mov	w9, #1                          ; =0x1
	sturb	w9, [x29, #-126]
	ldur	q0, [x29, #-80]
	str	q0, [x8, #64]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #36]
	stur	w8, [x29, #-140]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #40]
	stur	w8, [x29, #-136]
	mov	w8, #399                        ; =0x18f
	stur	w8, [x29, #-144]
	ldur	x8, [x29, #-64]
	ldr	w0, [x8, #64]
	bl	_input_state
	stur	w0, [x29, #-108]
	ldur	x8, [x29, #-64]
	ldr	w0, [x8, #80]
	bl	_input_state
	stur	w0, [x29, #-104]
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #56]
	subs	x8, x8, #1
	stur	x8, [x29, #-168]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #44]
	subs	w8, w8, #1
	cset	w8, eq
	sturb	w8, [x29, #-169]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #44]
	subs	w8, w8, #2
	cset	w8, eq
	sturb	w8, [x29, #-170]
	ldurb	w8, [x29, #-169]
	tbnz	w8, #0, LBB51_19
	b	LBB51_18
LBB51_18:
	ldurb	w8, [x29, #-170]
	tbz	w8, #0, LBB51_21
	b	LBB51_19
LBB51_19:
	ldur	x8, [x29, #-168]
	cbnz	x8, LBB51_21
	b	LBB51_20
LBB51_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_21:
	ldurb	w8, [x29, #-169]
	tbz	w8, #0, LBB51_27
	b	LBB51_22
LBB51_22:
	ldur	x0, [x29, #-32]
	ldurh	w1, [x29, #-42]
	sub	x2, x29, #188
	bl	_live_reference
	tbnz	w0, #0, LBB51_24
	b	LBB51_23
LBB51_23:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_24:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	mov	w9, #2                          ; =0x2
	sturb	w9, [x29, #-95]
	ldur	x0, [x29, #-96]
	ldur	x1, [x29, #-88]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB51_26
	b	LBB51_25
LBB51_25:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_26:
	mov	w8, #1                          ; =0x1
	sturh	w8, [x29, #-128]
	ldur	w8, [x29, #-144]
	orr	w8, w8, #0x10
	stur	w8, [x29, #-144]
	b	LBB51_30
LBB51_27:
	ldurh	w8, [x29, #-42]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB51_29
	b	LBB51_28
LBB51_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_29:
	b	LBB51_30
LBB51_30:
	ldurb	w9, [x29, #-169]
	mov	w8, #0                          ; =0x0
	and	w9, w9, #0x1
	ands	w9, w9, #0x1
	csinc	w9, w8, wzr, eq
                                        ; implicit-def: $x8
	mov	x8, x9
	sxtw	x8, w8
	stur	x8, [x29, #-200]
	ldur	x8, [x29, #-168]
	ldur	x9, [x29, #-200]
	subs	x8, x8, x9
	stur	x8, [x29, #-208]
	ldur	x8, [x29, #-208]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.ls	LBB51_32
	b	LBB51_31
LBB51_31:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_32:
	ldur	x8, [x29, #-200]
	stur	x8, [x29, #-216]
	b	LBB51_33
LBB51_33:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-216]
	ldur	x9, [x29, #-168]
	subs	x8, x8, x9
	b.hs	LBB51_58
	b	LBB51_34
LBB51_34:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x8, [x29, #-32]
	mov	x9, #24624                      ; =0x6030
	add	x8, x8, x9
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #12]
                                        ; kill: def $x9 killed $w9
	ldur	x10, [x29, #-208]
	subs	x9, x9, x10
	ldur	x10, [x29, #-216]
	add	x9, x9, x10
	ldur	x10, [x29, #-200]
	subs	x9, x9, x10
	mov	x10, #40                        ; =0x28
	mul	x9, x9, x10
	add	x1, x8, x9
	add	x0, sp, #272
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-64]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-216]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	mov	w1, #0                          ; =0x0
	sub	x3, x29, #232
	bl	_member_type
	tbz	w0, #0, LBB51_37
	b	LBB51_35
LBB51_35:                               ;   in Loop: Header=BB51_33 Depth=1
	ldrb	w8, [sp, #288]
	tbz	w8, #0, LBB51_37
	b	LBB51_36
LBB51_36:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x0, [x29, #-232]
	ldur	x1, [x29, #-224]
	ldr	x2, [sp, #272]
	ldr	x3, [sp, #280]
	bl	_same
	tbnz	w0, #0, LBB51_38
	b	LBB51_37
LBB51_37:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_38:                               ;   in Loop: Header=BB51_33 Depth=1
	ldurb	w8, [x29, #-170]
	tbz	w8, #0, LBB51_45
	b	LBB51_39
LBB51_39:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x8, [x29, #-216]
	cbnz	x8, LBB51_45
	b	LBB51_40
LBB51_40:                               ;   in Loop: Header=BB51_33 Depth=1
	ldr	x8, [sp, #296]
	cbz	x8, LBB51_43
	b	LBB51_41
LBB51_41:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x0, [x29, #-232]
	ldur	x1, [x29, #-224]
	ldur	x2, [x29, #-96]
	ldur	x3, [x29, #-88]
	bl	_same
	tbz	w0, #0, LBB51_43
	b	LBB51_42
LBB51_42:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x0, [x29, #-32]
	ldr	x1, [sp, #296]
	bl	_held
	tbz	w0, #0, LBB51_44
	b	LBB51_43
LBB51_43:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_44:                               ;   in Loop: Header=BB51_33 Depth=1
	mov	w8, #1                          ; =0x1
	sturh	w8, [x29, #-130]
	b	LBB51_49
LBB51_45:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x0, [x29, #-232]
	ldur	x1, [x29, #-224]
	bl	_owned
	tbnz	w0, #0, LBB51_47
	b	LBB51_46
LBB51_46:                               ;   in Loop: Header=BB51_33 Depth=1
	ldr	x8, [sp, #296]
	cbz	x8, LBB51_48
	b	LBB51_47
LBB51_47:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_48:                               ;   in Loop: Header=BB51_33 Depth=1
	b	LBB51_49
LBB51_49:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x8, [x29, #-64]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-216]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #40]
	subs	w8, w8, #1
	b.ne	LBB51_51
	b	LBB51_50
LBB51_50:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	w8, [x29, #-144]
	orr	w8, w8, #0x20
	stur	w8, [x29, #-144]
	b	LBB51_51
LBB51_51:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x8, [x29, #-64]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-216]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #40]
	subs	w8, w8, #5
	b.ne	LBB51_53
	b	LBB51_52
LBB51_52:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	w8, [x29, #-144]
	mov	w9, #0                          ; =0x0
	orr	w8, w8, w9
	stur	w8, [x29, #-144]
	b	LBB51_53
LBB51_53:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	w8, [x29, #-224]
	adds	w8, w8, #1
	b.ne	LBB51_56
	b	LBB51_54
LBB51_54:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	w8, [x29, #-220]
	subs	w8, w8, #4
	b.ne	LBB51_56
	b	LBB51_55
LBB51_55:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	w8, [x29, #-144]
	mov	w9, #0                          ; =0x0
	orr	w8, w8, w9
	stur	w8, [x29, #-144]
	b	LBB51_56
LBB51_56:                               ;   in Loop: Header=BB51_33 Depth=1
	b	LBB51_57
LBB51_57:                               ;   in Loop: Header=BB51_33 Depth=1
	ldur	x8, [x29, #-216]
	add	x8, x8, #1
	stur	x8, [x29, #-216]
	b	LBB51_33
LBB51_58:
	ldur	x8, [x29, #-208]
                                        ; kill: def $w8 killed $w8 killed $x8
	sturh	w8, [x29, #-98]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-98]
	subs	w8, w8, w9
	add	w8, w8, #1
	subs	w8, w8, #256
	b.ls	LBB51_60
	b	LBB51_59
LBB51_59:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_60:
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_owned
	tbz	w0, #0, LBB51_65
	b	LBB51_61
LBB51_61:
	ldur	x0, [x29, #-32]
	add	x1, sp, #248
	bl	_nvm_file_flow_counts
	ldrh	w8, [sp, #252]
	subs	w8, w8, #256
	b.eq	LBB51_63
	b	LBB51_62
LBB51_62:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	adds	x8, x8, #1
	b.ne	LBB51_64
	b	LBB51_63
LBB51_63:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_64:
	b	LBB51_65
LBB51_65:
	ldur	x8, [x29, #-32]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	add	x0, sp, #184
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	sub	x1, x29, #156
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	add	x2, sp, #246
	bl	_obligation_slot
	str	w0, [sp, #240]
	ldr	w8, [sp, #240]
	cbz	w8, LBB51_67
	b	LBB51_66
LBB51_66:
	ldr	w8, [sp, #240]
	stur	w8, [x29, #-20]
	b	LBB51_74
LBB51_67:
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	bl	_owned
	tbz	w0, #0, LBB51_69
	b	LBB51_68
LBB51_68:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB51_70
LBB51_69:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB51_70
LBB51_70:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #176]
	b	LBB51_71
LBB51_71:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-98]
	cbz	w8, LBB51_73
	b	LBB51_72
LBB51_72:                               ;   in Loop: Header=BB51_71 Depth=1
	ldur	x0, [x29, #-32]
	bl	_pop
	ldurh	w9, [x29, #-98]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w9, uxth
	sturh	w8, [x29, #-98]
	b	LBB51_71
LBB51_73:
	ldur	x8, [x29, #-32]
	mov	x9, #24624                      ; =0x6030
	add	x11, x8, x9
	ldur	x12, [x29, #-32]
	ldrh	w8, [x12, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, x8
	mov	w9, #1                          ; =0x1
	add	w10, w10, #1
	strh	w10, [x12, #12]
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x3, [sp, #176]
	ldur	x0, [x29, #-80]
	ldur	x1, [x29, #-72]
	add	x8, sp, #136
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	bl	_initial_value
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	x8, [x29, #-32]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldrh	w8, [sp, #246]
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	add	x0, sp, #80
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	sub	x1, x29, #156
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #44]                   ; 4-byte Folded Reload
	bl	_commit_obligation
	stur	wzr, [x29, #-20]
	b	LBB51_74
LBB51_74:
	ldur	w0, [x29, #-20]
	add	sp, sp, #528
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function input_state
_input_state:                           ; @input_state
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	subs	w8, w8, #1
	b.ne	LBB52_2
	b	LBB52_1
LBB52_1:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB52_3
LBB52_2:
	ldr	w10, [sp, #12]
	mov	w8, #2                          ; =0x2
	mov	w9, #0                          ; =0x0
	subs	w10, w10, #2
	csel	w8, w8, w9, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB52_3
LBB52_3:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_reference
_live_reference:                        ; @live_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	stur	x2, [x29, #-32]
	ldurh	w8, [x29, #-18]
	subs	w8, w8, #256
	b.lo	LBB53_2
	b	LBB53_1
LBB53_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_2:
	ldur	x8, [x29, #-16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-18]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #56
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #56]
	tbz	w8, #0, LBB53_4
	b	LBB53_3
LBB53_3:
	ldur	x0, [x29, #-16]
	ldrh	w1, [sp, #58]
	bl	_local_valid
	tbnz	w0, #0, LBB53_5
	b	LBB53_4
LBB53_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_5:
	ldur	x8, [x29, #-16]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldrh	w8, [sp, #58]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #32]
	tbz	w8, #0, LBB53_7
	b	LBB53_6
LBB53_6:
	ldr	w8, [sp, #28]
	subs	w8, w8, #1
	b.eq	LBB53_8
	b	LBB53_7
LBB53_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_8:
	ldrb	w8, [sp, #57]
	tbz	w8, #0, LBB53_14
	b	LBB53_9
LBB53_9:
	ldurh	w8, [x29, #-18]
	ldrh	w9, [sp, #58]
	subs	w8, w8, w9
	b.ne	LBB53_12
	b	LBB53_10
LBB53_10:
	ldrb	w8, [sp, #17]
	ldrb	w10, [sp, #88]
	mov	w9, #2                          ; =0x2
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csinc	w9, w9, wzr, eq
	subs	w8, w8, w9
	b.ne	LBB53_12
	b	LBB53_11
LBB53_11:
	ldr	x8, [sp, #40]
	cbz	x8, LBB53_13
	b	LBB53_12
LBB53_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_13:
	b	LBB53_24
LBB53_14:
	ldrb	w8, [sp, #17]
	cbnz	w8, LBB53_16
	b	LBB53_15
LBB53_15:
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #64]
	subs	x8, x8, x9
	b.eq	LBB53_17
	b	LBB53_16
LBB53_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_17:
	strb	wzr, [sp, #15]
	strh	wzr, [sp, #12]
	b	LBB53_18
LBB53_18:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ge	LBB53_21
	b	LBB53_19
LBB53_19:                               ;   in Loop: Header=BB53_18 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #45104                      ; =0xb030
	add	x8, x8, x9
	ldrh	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #80]
	subs	x8, x8, x9
	cset	w9, eq
	ldrb	w8, [sp, #15]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #15]
	b	LBB53_20
LBB53_20:                               ;   in Loop: Header=BB53_18 Depth=1
	ldrh	w8, [sp, #12]
	add	w8, w8, #1
	strh	w8, [sp, #12]
	b	LBB53_18
LBB53_21:
	ldrb	w8, [sp, #15]
	tbnz	w8, #0, LBB53_23
	b	LBB53_22
LBB53_22:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_23:
	b	LBB53_24
LBB53_24:
	ldrb	w10, [sp, #88]
	mov	w8, #2                          ; =0x2
	mov	w9, #1                          ; =0x1
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csinc	w8, w8, wzr, eq
	strb	w8, [sp, #17]
	ldur	x8, [x29, #-32]
	ldr	q0, [sp, #16]
	str	q0, [x8]
	and	w8, w9, #0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-1]
	b	LBB53_25
LBB53_25:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function held
_held:                                  ; @held
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	strh	wzr, [sp, #6]
	b	LBB54_1
LBB54_1:                                ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #6]
	subs	w8, w8, #256
	b.hs	LBB54_7
	b	LBB54_2
LBB54_2:                                ;   in Loop: Header=BB54_1 Depth=1
	ldr	x8, [sp, #16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB54_5
	b	LBB54_3
LBB54_3:                                ;   in Loop: Header=BB54_1 Depth=1
	ldr	x8, [sp, #16]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #6]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #8]
	subs	x8, x8, x9
	b.ne	LBB54_5
	b	LBB54_4
LBB54_4:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB54_8
LBB54_5:                                ;   in Loop: Header=BB54_1 Depth=1
	b	LBB54_6
LBB54_6:                                ;   in Loop: Header=BB54_1 Depth=1
	ldrh	w8, [sp, #6]
	add	w8, w8, #1
	strh	w8, [sp, #6]
	b	LBB54_1
LBB54_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB54_8
LBB54_8:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function obligation_slot
_obligation_slot:                       ; @obligation_slot
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x1, [sp, #32]                   ; 8-byte Folded Spill
	str	x0, [x8]
	mov	x8, x1
	stur	x8, [x29, #-24]
	stur	x2, [x29, #-32]
	ldr	w8, [x1, #4]
	adds	w8, w8, #1
	b.ne	LBB55_2
	b	LBB55_1
LBB55_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB55_13
LBB55_2:
	sturh	wzr, [x29, #-34]
	b	LBB55_3
LBB55_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-34]
	ldr	x9, [x9]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB55_10
	b	LBB55_4
LBB55_4:                                ;   in Loop: Header=BB55_3 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	x11, x8, #44
	ldurh	w8, [x29, #-34]
                                        ; kill: def $x8 killed $w8
	mov	x10, #56                        ; =0x38
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w8, [x8, #4]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB55_8
	b	LBB55_5
LBB55_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	x10, x8, #44
	ldurh	w8, [x29, #-34]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #92
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp]                        ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	add	x0, sp, #44
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	bl	_obligation_same
	tbnz	w0, #0, LBB55_7
	b	LBB55_6
LBB55_6:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB55_13
LBB55_7:
	ldurh	w8, [x29, #-34]
	ldur	x9, [x29, #-32]
	strh	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB55_13
LBB55_8:                                ;   in Loop: Header=BB55_3 Depth=1
	b	LBB55_9
LBB55_9:                                ;   in Loop: Header=BB55_3 Depth=1
	ldurh	w8, [x29, #-34]
	add	w8, w8, #1
	sturh	w8, [x29, #-34]
	b	LBB55_3
LBB55_10:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.ne	LBB55_12
	b	LBB55_11
LBB55_11:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB55_13
LBB55_12:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-32]
	strh	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB55_13
LBB55_13:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function commit_obligation
_commit_obligation:                     ; @commit_obligation
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp]                        ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strh	w2, [sp, #14]
	ldrh	w8, [sp, #14]
	ldur	x9, [x29, #-8]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB56_2
	b	LBB56_1
LBB56_1:
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	add	x10, x8, #44
	ldur	x11, [x29, #-8]
	ldrh	w8, [x11, #16]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	strh	w9, [x11, #16]
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	b	LBB56_2
LBB56_2:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_flow_call             ; -- Begin function nvm_file_flow_call
	.p2align	2
_nvm_file_flow_call:                    ; @nvm_file_flow_call
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	w2, [x29, #-40]
	stur	x3, [x29, #-48]
	sturh	w4, [x29, #-50]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB57_2
	b	LBB57_1
LBB57_1:
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.lo	LBB57_3
	b	LBB57_2
LBB57_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_3:
	ldur	x8, [x29, #-32]
	ldrb	w8, [x8, #40]
	tbz	w8, #0, LBB57_5
	b	LBB57_4
LBB57_4:
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB57_6
	b	LBB57_5
LBB57_5:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_6:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	mov	x9, #24                         ; =0x18
	add	x10, x8, #24
	ldur	w8, [x29, #-40]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldurh	w8, [x29, #-50]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB57_9
	b	LBB57_7
LBB57_7:
	ldurh	w8, [x29, #-50]
	cbz	w8, LBB57_10
	b	LBB57_8
LBB57_8:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB57_10
	b	LBB57_9
LBB57_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_10:
	sturh	wzr, [x29, #-66]
	sturh	wzr, [x29, #-68]
	sturh	wzr, [x29, #-70]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldur	w10, [x29, #-40]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	stur	x8, [x29, #-80]
	sturh	wzr, [x29, #-82]
	b	LBB57_11
LBB57_11:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-82]
	ldurh	w9, [x29, #-50]
	subs	w8, w8, w9
	b.ge	LBB57_14
	b	LBB57_12
LBB57_12:                               ;   in Loop: Header=BB57_11 Depth=1
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w9, [x8, #1]
	ldurh	w8, [x29, #-66]
	subs	w9, w9, #0
	cinc	w8, w8, eq
	sturh	w8, [x29, #-66]
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	ldurh	w8, [x29, #-68]
	add	w8, w8, w0
	sturh	w8, [x29, #-68]
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w9, [x8, #1]
	ldurh	w8, [x29, #-70]
	subs	w9, w9, #0
	cinc	w8, w8, ne
	sturh	w8, [x29, #-70]
	b	LBB57_13
LBB57_13:                               ;   in Loop: Header=BB57_11 Depth=1
	ldurh	w8, [x29, #-82]
	add	w8, w8, #1
	sturh	w8, [x29, #-82]
	b	LBB57_11
LBB57_14:
	ldurh	w8, [x29, #-66]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.le	LBB57_16
	b	LBB57_15
LBB57_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_16:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-66]
	subs	w8, w8, w9
	sturh	w8, [x29, #-84]
	ldurh	w8, [x29, #-84]
	sturh	w8, [x29, #-86]
	sturh	wzr, [x29, #-88]
	b	LBB57_17
LBB57_17:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB57_23 Depth 2
	ldurh	w8, [x29, #-88]
	ldurh	w9, [x29, #-50]
	subs	w8, w8, w9
	b.ge	LBB57_43
	b	LBB57_18
LBB57_18:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #1]
	cbz	w8, LBB57_32
	b	LBB57_19
LBB57_19:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-48]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldrh	w1, [x8, x9, lsl #1]
	sub	x2, x29, #104
	bl	_live_reference
	tbz	w0, #0, LBB57_21
	b	LBB57_20
LBB57_20:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	ldur	x2, [x29, #-104]
	ldur	x3, [x29, #-96]
	bl	_same
	tbnz	w0, #0, LBB57_22
	b	LBB57_21
LBB57_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_22:                               ;   in Loop: Header=BB57_17 Depth=1
	sturh	wzr, [x29, #-106]
	b	LBB57_23
LBB57_23:                               ;   Parent Loop BB57_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-106]
	ldurh	w9, [x29, #-88]
	subs	w8, w8, w9
	b.ge	LBB57_31
	b	LBB57_24
LBB57_24:                               ;   in Loop: Header=BB57_23 Depth=2
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-106]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #1]
	cbz	w8, LBB57_29
	b	LBB57_25
LBB57_25:                               ;   in Loop: Header=BB57_23 Depth=2
	ldur	x8, [x29, #-32]
	mov	x11, #34864                     ; =0x8830
	add	x12, x8, x11
	ldur	x8, [x29, #-48]
	ldurh	w9, [x29, #-106]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
                                        ; kill: def $x8 killed $w8
	mov	x10, #40                        ; =0x28
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x12
	ldr	x8, [x8, #8]
	ldur	x9, [x29, #-32]
	add	x11, x9, x11
	ldur	x9, [x29, #-48]
	ldurh	w12, [x29, #-88]
                                        ; kill: def $x12 killed $w12
	ldrh	w9, [x9, x12, lsl #1]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldr	x9, [x9, #8]
	subs	x8, x8, x9
	b.ne	LBB57_29
	b	LBB57_26
LBB57_26:                               ;   in Loop: Header=BB57_23 Depth=2
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-106]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #1]
	subs	w8, w8, #1
	b.ne	LBB57_28
	b	LBB57_27
LBB57_27:                               ;   in Loop: Header=BB57_23 Depth=2
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldrb	w8, [x8, #1]
	subs	w8, w8, #1
	b.eq	LBB57_29
	b	LBB57_28
LBB57_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_29:                               ;   in Loop: Header=BB57_23 Depth=2
	b	LBB57_30
LBB57_30:                               ;   in Loop: Header=BB57_23 Depth=2
	ldurh	w8, [x29, #-106]
	add	w8, w8, #1
	sturh	w8, [x29, #-106]
	b	LBB57_23
LBB57_31:                               ;   in Loop: Header=BB57_17 Depth=1
	b	LBB57_41
LBB57_32:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-48]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB57_34
	b	LBB57_33
LBB57_33:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_34:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-32]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldurh	w8, [x29, #-86]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	sturh	w9, [x29, #-86]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	sub	x0, x29, #152
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldurb	w8, [x29, #-136]
	tbz	w8, #0, LBB57_39
	b	LBB57_35
LBB57_35:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldur	x0, [x29, #-152]
	ldur	x1, [x29, #-144]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbz	w0, #0, LBB57_39
	b	LBB57_36
LBB57_36:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-80]
	ldurh	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #4
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	ldur	x8, [x29, #-128]
	subs	x8, x8, #0
	cset	w8, ne
	subs	w8, w0, w8
	b.ne	LBB57_39
	b	LBB57_37
LBB57_37:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x8, [x29, #-128]
	cbz	x8, LBB57_40
	b	LBB57_38
LBB57_38:                               ;   in Loop: Header=BB57_17 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-128]
	bl	_held
	tbz	w0, #0, LBB57_40
	b	LBB57_39
LBB57_39:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_40:                               ;   in Loop: Header=BB57_17 Depth=1
	b	LBB57_41
LBB57_41:                               ;   in Loop: Header=BB57_17 Depth=1
	b	LBB57_42
LBB57_42:                               ;   in Loop: Header=BB57_17 Depth=1
	ldurh	w8, [x29, #-88]
	add	w8, w8, #1
	sturh	w8, [x29, #-88]
	b	LBB57_17
LBB57_43:
	ldurh	w8, [x29, #-84]
	ldur	x9, [x29, #-64]
	ldrb	w9, [x9, #4]
	add	w8, w8, w9
	subs	w8, w8, #256
	b.ls	LBB57_45
	b	LBB57_44
LBB57_44:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_45:
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #4]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #84]                   ; 4-byte Folded Spill
	cbz	w8, LBB57_47
	b	LBB57_46
LBB57_46:
	ldur	x8, [x29, #-64]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	bl	_owned
	str	w0, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB57_47
LBB57_47:
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	sturb	w8, [x29, #-153]
	ldur	x0, [x29, #-32]
	sub	x1, x29, #184
	bl	_nvm_file_flow_counts
	ldurh	w8, [x29, #-180]
	ldurh	w9, [x29, #-68]
	subs	w8, w8, w9
	b.ge	LBB57_49
	b	LBB57_48
LBB57_48:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_49:
	ldurh	w8, [x29, #-180]
	ldurh	w9, [x29, #-68]
	subs	w8, w8, w9
	ldurb	w9, [x29, #-153]
	and	w9, w9, #0x1
	add	w8, w8, w9
	subs	w8, w8, #256
	b.hi	LBB57_52
	b	LBB57_50
LBB57_50:
	ldurb	w8, [x29, #-153]
	tbz	w8, #0, LBB57_53
	b	LBB57_51
LBB57_51:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	adds	x8, x8, #1
	b.ne	LBB57_53
	b	LBB57_52
LBB57_52:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_53:
	sub	x0, x29, #240
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp, #56]                   ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-240]
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-236]
	ldur	w8, [x29, #-40]
	stur	w8, [x29, #-232]
	ldurh	w8, [x29, #-50]
	sturh	w8, [x29, #-216]
	ldurh	w8, [x29, #-68]
	sturh	w8, [x29, #-214]
	ldurh	w8, [x29, #-70]
	sturh	w8, [x29, #-212]
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #4]
	sturb	w8, [x29, #-210]
	ldur	x8, [x29, #-64]
	ldur	q0, [x8, #8]
	stur	q0, [x29, #-208]
	mov	w8, #448                        ; =0x1c0
	stur	w8, [x29, #-228]
	ldur	x8, [x29, #-32]
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	add	x0, sp, #192
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	sub	x2, x29, #242
	bl	_obligation_slot
	str	w0, [sp, #248]
	ldr	w8, [sp, #248]
	cbz	w8, LBB57_55
	b	LBB57_54
LBB57_54:
	ldr	w8, [sp, #248]
	stur	w8, [x29, #-20]
	b	LBB57_64
LBB57_55:
	ldurb	w8, [x29, #-153]
	tbz	w8, #0, LBB57_57
	b	LBB57_56
LBB57_56:
	ldur	x8, [x29, #-32]
	ldr	x10, [x8]
	ldr	x8, [x10, #8]
	add	x9, x8, #1
	str	x9, [x10, #8]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB57_58
LBB57_57:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB57_58
LBB57_58:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x8, [sp, #184]
	b	LBB57_59
LBB57_59:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-84]
	subs	w8, w8, w9
	b.le	LBB57_61
	b	LBB57_60
LBB57_60:                               ;   in Loop: Header=BB57_59 Depth=1
	ldur	x0, [x29, #-32]
	bl	_pop
	b	LBB57_59
LBB57_61:
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #4]
	cbz	w8, LBB57_63
	b	LBB57_62
LBB57_62:
	ldur	x8, [x29, #-32]
	mov	x9, #24624                      ; =0x6030
	add	x11, x8, x9
	ldur	x12, [x29, #-32]
	ldrh	w8, [x12, #12]
                                        ; kill: def $x8 killed $w8
	mov	x10, x8
	mov	w9, #1                          ; =0x1
	add	w10, w10, #1
	strh	w10, [x12, #12]
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-64]
	ldr	x3, [sp, #184]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	add	x8, sp, #144
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	bl	_initial_value
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB57_63
LBB57_63:
	ldur	x8, [x29, #-32]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldurh	w8, [x29, #-242]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	add	x0, sp, #88
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	sub	x1, x29, #240
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w2, [sp, #20]                   ; 4-byte Folded Reload
	bl	_commit_obligation
	stur	wzr, [x29, #-20]
	b	LBB57_64
LBB57_64:
	ldur	w0, [x29, #-20]
	add	sp, sp, #480
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_free             ; -- Begin function nvm_file_code_free
	.p2align	2
_nvm_file_code_free:                    ; @nvm_file_code_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB58_2
	b	LBB58_1
LBB58_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_flow_declarations_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #16]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB58_2
LBB58_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_prepare          ; -- Begin function nvm_file_code_prepare
	.p2align	2
_nvm_file_code_prepare:                 ; @nvm_file_code_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	w8, #1                          ; =0x1
	and	w2, w8, #0x1
	bl	_file_code_prepare_mode
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_prepare_mode
_file_code_prepare_mode:                ; @file_code_prepare_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	strb	w2, [sp, #15]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	ldrb	w8, [sp, #15]
	and	w2, w8, #0x1
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	bl	_file_code_prepare_profile
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_function_count   ; -- Begin function nvm_file_code_function_count
	.p2align	2
_nvm_file_code_function_count:          ; @nvm_file_code_function_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB61_2
	b	LBB61_1
LBB61_1:
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #24]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB61_3
LBB61_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB61_3
LBB61_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_function         ; -- Begin function nvm_file_code_function
	.p2align	2
_nvm_file_code_function:                ; @nvm_file_code_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB62_3
	b	LBB62_1
LBB62_1:
	ldr	x8, [sp]
	cbz	x8, LBB62_3
	b	LBB62_2
LBB62_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB62_4
	b	LBB62_3
LBB62_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB62_5
LBB62_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #48
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #36                         ; =0x24
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB62_5
LBB62_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_local            ; -- Begin function nvm_file_code_local
	.p2align	2
_nvm_file_code_local:                   ; @nvm_file_code_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB63_2
	b	LBB63_1
LBB63_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_flow_declaration
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB63_2
LBB63_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_instruction      ; -- Begin function nvm_file_code_instruction
	.p2align	2
_nvm_file_code_instruction:             ; @nvm_file_code_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB64_4
	b	LBB64_1
LBB64_1:
	ldr	x8, [sp]
	cbz	x8, LBB64_4
	b	LBB64_2
LBB64_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB64_4
	b	LBB64_3
LBB64_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	add	x11, x9, #48
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB64_5
	b	LBB64_4
LBB64_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB64_6
LBB64_5:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #16]
	ldr	x8, [sp, #16]
	add	x8, x8, #2352
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x2, #600                        ; =0x258
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB64_6
LBB64_6:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_instruction_order ; -- Begin function nvm_file_code_instruction_order
	.p2align	2
_nvm_file_code_instruction_order:       ; @nvm_file_code_instruction_order
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	str	x3, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB65_4
	b	LBB65_1
LBB65_1:
	ldr	x8, [sp]
	cbz	x8, LBB65_4
	b	LBB65_2
LBB65_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB65_4
	b	LBB65_3
LBB65_3:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	add	x11, x9, #48
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB65_5
	b	LBB65_4
LBB65_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB65_6
LBB65_5:
	ldr	x8, [sp, #16]
	add	x8, x8, #2864
	ldr	x9, [sp, #16]
	add	x9, x9, #2352
	ldr	w10, [sp, #12]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #10]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #1
	ldrh	w8, [x8]
	ldr	x9, [sp]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB65_6
LBB65_6:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_code_function_order   ; -- Begin function nvm_file_code_function_order
	.p2align	2
_nvm_file_code_function_order:          ; @nvm_file_code_function_order
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB66_3
	b	LBB66_1
LBB66_1:
	ldr	x8, [sp]
	cbz	x8, LBB66_3
	b	LBB66_2
LBB66_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB66_4
	b	LBB66_3
LBB66_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB66_5
LBB66_4:
	ldr	x8, [sp, #16]
	add	x8, x8, #2608
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldr	x9, [sp]
	str	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB66_5
LBB66_5:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_free             ; -- Begin function nvm_file_body_free
	.p2align	2
_nvm_file_body_free:                    ; @nvm_file_body_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB67_2
	b	LBB67_1
LBB67_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_code_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB67_2
LBB67_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_analyze          ; -- Begin function nvm_file_body_analyze
	.p2align	2
_nvm_file_body_analyze:                 ; @nvm_file_body_analyze
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #2160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #72
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x0, [x8, #40]
	str	x1, [x8, #32]
	ldr	x8, [x8, #32]
	cbnz	x8, LBB68_2
	b	LBB68_1
LBB68_1:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_2:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	sub	x1, x29, #48
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8, #24]
	ldr	x0, [x8, #40]
	bl	_nvm_file_code_prepare
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	w0, [x8, #20]
	ldr	w8, [x8, #20]
	cbz	w8, LBB68_4
	b	LBB68_3
LBB68_3:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x9, #20]
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_4:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x9, #24]
	ldr	x8, [x8, #40]
	sub	x0, x29, #64
	str	x8, [x9, #8]
	mov	x1, #1                          ; =0x1
	mov	x2, #80                         ; =0x50
	bl	_file_code_budget
	tbz	w0, #0, LBB68_8
	b	LBB68_5
LBB68_5:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	ldr	w8, [x8, #32]
	mov	x1, x8
	sub	x0, x29, #64
	mov	x2, #80                         ; =0x50
	bl	_file_code_budget
	tbz	w0, #0, LBB68_8
	b	LBB68_6
LBB68_6:
	sub	x0, x29, #64
	mov	x1, #1                          ; =0x1
	mov	x2, #2080                       ; =0x820
	bl	_file_code_budget
	tbz	w0, #0, LBB68_8
	b	LBB68_7
LBB68_7:
	sub	x0, x29, #64
	mov	x1, #256                        ; =0x100
	mov	x2, #2                          ; =0x2
	bl	_file_code_budget
	tbnz	w0, #0, LBB68_9
	b	LBB68_8
LBB68_8:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	bl	_nvm_file_code_free
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_9:
	mov	x0, #1                          ; =0x1
	mov	x1, #80                         ; =0x50
	bl	_calloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [x8]
	ldr	x8, [x8]
	cbnz	x8, LBB68_11
	b	LBB68_10
LBB68_10:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8, #24]
	bl	_nvm_file_code_free
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_11:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8, #24]
	ldr	x10, [x8]
	str	x9, [x10]
	ldr	x8, [x8, #24]
	ldr	w8, [x8, #32]
	mov	x0, x8
	mov	x1, #80                         ; =0x50
	bl	_calloc
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8]
	str	x0, [x9, #8]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	cbnz	x8, LBB68_13
	b	LBB68_12
LBB68_12:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_file_body_free
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_13:
	add	x0, sp, #24
	mov	x1, #2080                       ; =0x820
	bl	_bzero
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB68_14
LBB68_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #20]
	ldr	x9, [x9, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB68_19
	b	LBB68_15
LBB68_15:                               ;   in Loop: Header=BB68_14 Depth=1
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x8, [x8, #24]
	add	x8, x8, #2608
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	w1, [x8, x9, lsl #2]
	add	x2, sp, #24
	bl	_file_body_function
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	w0, [x8, #20]
	ldr	w8, [x8, #20]
	cbz	w8, LBB68_17
	b	LBB68_16
LBB68_16:
	b	LBB68_19
LBB68_17:                               ;   in Loop: Header=BB68_14 Depth=1
	b	LBB68_18
LBB68_18:                               ;   in Loop: Header=BB68_14 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB68_14
LBB68_19:
	add	x0, sp, #24
	add	x1, x0, #2056
	bl	_file_body_release
	strh	wzr, [sp, #18]
	b	LBB68_20
LBB68_20:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #18]
	subs	w8, w8, #256
	b.hs	LBB68_23
	b	LBB68_21
LBB68_21:                               ;   in Loop: Header=BB68_20 Depth=1
	add	x0, sp, #24
	add	x8, x0, #8
	ldrh	w9, [sp, #18]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_file_body_release
	b	LBB68_22
LBB68_22:                               ;   in Loop: Header=BB68_20 Depth=1
	ldrh	w8, [sp, #18]
	add	w8, w8, #1
	strh	w8, [sp, #18]
	b	LBB68_20
LBB68_23:
	strb	wzr, [sp, #17]
	b	LBB68_24
LBB68_24:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w8, [sp, #17]
	subs	w8, w8, #2
	b.ge	LBB68_27
	b	LBB68_25
LBB68_25:                               ;   in Loop: Header=BB68_24 Depth=1
	add	x0, sp, #24
	add	x8, x0, #2064
	ldrb	w9, [sp, #17]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_file_body_release
	b	LBB68_26
LBB68_26:                               ;   in Loop: Header=BB68_24 Depth=1
	ldrb	w8, [sp, #17]
	add	w8, w8, #1
	strb	w8, [sp, #17]
	b	LBB68_24
LBB68_27:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x8, #20]
	cbz	w8, LBB68_29
	b	LBB68_28
LBB68_28:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x0, [x8]
	bl	_nvm_file_body_free
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [x9, #20]
	str	w8, [x9, #52]
	b	LBB68_30
LBB68_29:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	x10, [x8, #32]
	str	x9, [x10]
	str	wzr, [x8, #52]
	b	LBB68_30
LBB68_30:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w0, [x8, #52]
	add	sp, sp, #2160
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_budget
_file_code_budget:                      ; @file_code_budget
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB69_3
	b	LBB69_1
LBB69_1:
	ldr	x8, [sp, #16]
	ldr	x10, [sp, #24]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB69_3
	b	LBB69_2
LBB69_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB69_7
LBB69_3:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	mul	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hi	LBB69_5
	b	LBB69_4
LBB69_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x10, [x9]
	mov	x9, #16777216                   ; =0x1000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB69_6
	b	LBB69_5
LBB69_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB69_7
LBB69_6:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB69_7
LBB69_7:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_function
_file_body_function:                    ; @file_body_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	ldur	x0, [x29, #-32]
	mov	x1, #1                          ; =0x1
	bl	_file_body_room
	tbnz	w0, #0, LBB70_2
	b	LBB70_1
LBB70_1:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_2:
	ldur	x8, [x29, #-40]
	ldr	x0, [x8]
	ldur	w1, [x29, #-20]
	ldur	x8, [x29, #-32]
	add	x2, x8, #8
	bl	_nvm_file_flow_state
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_4
	b	LBB70_3
LBB70_3:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_4:
	ldur	x9, [x29, #-32]
	ldr	x8, [x9]
	mov	x10, #47152                     ; =0xb830
	add	x8, x8, x10
	str	x8, [x9]
	sturb	wzr, [x29, #-45]
	strh	wzr, [sp, #48]
	b	LBB70_5
LBB70_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB70_26 Depth 2
	ldrh	w8, [sp, #48]
	ldur	x9, [x29, #-40]
	add	x11, x9, #48
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB70_38
	b	LBB70_6
LBB70_6:                                ;   in Loop: Header=BB70_5 Depth=1
	ldur	x8, [x29, #-40]
	add	x8, x8, #2864
	ldur	x9, [x29, #-40]
	add	x9, x9, #2352
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #48]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #1
	ldrh	w8, [x8]
	strh	w8, [sp, #46]
	ldur	x8, [x29, #-32]
	add	x8, x8, #8
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #2056]
	ldur	x8, [x29, #-32]
	add	x9, x8, #8
	ldrh	w8, [sp, #46]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #2056]
	cbnz	x8, LBB70_8
	b	LBB70_7
LBB70_7:                                ;   in Loop: Header=BB70_5 Depth=1
	b	LBB70_37
LBB70_8:                                ;   in Loop: Header=BB70_5 Depth=1
	ldur	x8, [x29, #-40]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-40]
	add	x8, x8, #2352
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #46]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-40]
	add	x8, x8, #2352
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #46]
	add	w8, w8, w9
	mov	w9, #80                         ; =0x50
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	ldr	x9, [sp, #24]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #2056]
	ldrh	w8, [x8, #12]
	ldr	x9, [sp, #24]
	strh	w8, [x9, #4]
	ldr	x9, [sp, #24]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, #8]
	ldr	x9, [sp, #24]
	mov	w8, #128                        ; =0x80
	str	w8, [x9, #20]
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #2056]
	ldr	x2, [sp, #32]
	ldr	x3, [sp, #24]
	bl	_file_body_transfer
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_10
	b	LBB70_9
LBB70_9:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_10:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #2056]
	ldrh	w8, [x8, #12]
	ldr	x9, [sp, #24]
	strh	w8, [x9, #6]
	ldr	x8, [sp, #24]
	ldrb	w8, [x8, #1]
	and	w9, w8, #0x1
	ldurb	w8, [x29, #-45]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-45]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #146
	b.ne	LBB70_16
	b	LBB70_11
LBB70_11:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x0, [x29, #-32]
	mov	x1, #2                          ; =0x2
	bl	_file_body_room
	tbnz	w0, #0, LBB70_13
	b	LBB70_12
LBB70_12:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_13:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #2056]
	ldr	x8, [sp, #32]
	ldrh	w1, [x8, #16]
	ldur	x8, [x29, #-32]
	add	x2, x8, #2064
	ldur	x8, [x29, #-32]
	add	x3, x8, #2072
	bl	_nvm_file_flow_refine
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_15
	b	LBB70_14
LBB70_14:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_15:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x9, [x29, #-32]
	ldr	x8, [x9]
	mov	x10, #28768                     ; =0x7060
	movk	x10, #1, lsl #16
	add	x8, x8, x10
	str	x8, [x9]
	ldr	x9, [sp, #24]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2]
	b	LBB70_25
LBB70_16:                               ;   in Loop: Header=BB70_5 Depth=1
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #76]
	cbz	w8, LBB70_24
	b	LBB70_17
LBB70_17:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #2056]
	ldur	x8, [x29, #-32]
	add	x2, x8, #2064
	bl	_file_body_clone
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_19
	b	LBB70_18
LBB70_18:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_19:                               ;   in Loop: Header=BB70_5 Depth=1
	ldr	x8, [sp, #32]
	ldrb	w8, [x8, #76]
	subs	w8, w8, #2
	b.ne	LBB70_23
	b	LBB70_20
LBB70_20:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldr	x1, [x8, #2056]
	ldur	x8, [x29, #-32]
	add	x2, x8, #2072
	bl	_file_body_clone
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_22
	b	LBB70_21
LBB70_21:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_22:                               ;   in Loop: Header=BB70_5 Depth=1
	b	LBB70_23
LBB70_23:                               ;   in Loop: Header=BB70_5 Depth=1
	b	LBB70_24
LBB70_24:                               ;   in Loop: Header=BB70_5 Depth=1
	b	LBB70_25
LBB70_25:                               ;   in Loop: Header=BB70_5 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	add	x1, x8, #2056
	bl	_file_body_release
	strb	wzr, [sp, #23]
	b	LBB70_26
LBB70_26:                               ;   Parent Loop BB70_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #23]
	ldr	x9, [sp, #32]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB70_36
	b	LBB70_27
LBB70_27:                               ;   in Loop: Header=BB70_26 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #2064
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldrb	w8, [x8, #40]
	tbnz	w8, #0, LBB70_29
	b	LBB70_28
LBB70_28:                               ;   in Loop: Header=BB70_26 Depth=2
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	add	x8, x8, #2064
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_file_body_release
	b	LBB70_35
LBB70_29:                               ;   in Loop: Header=BB70_26 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #8
	ldr	x9, [sp, #32]
	add	x9, x9, #72
	ldrb	w10, [sp, #23]
                                        ; kill: def $x10 killed $w10
	ldrh	w9, [x9, x10, lsl #1]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8]
	cbnz	x8, LBB70_31
	b	LBB70_30
LBB70_30:                               ;   in Loop: Header=BB70_26 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #2064
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	ldur	x8, [x29, #-32]
	add	x9, x8, #2064
	ldrb	w8, [sp, #23]
	mov	x10, x8
	mov	x8, #0                          ; =0x0
	str	x8, [x9, x10, lsl #3]
	b	LBB70_34
LBB70_31:                               ;   in Loop: Header=BB70_26 Depth=2
	add	x2, sp, #7
	strb	wzr, [sp, #7]
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	ldur	x8, [x29, #-32]
	add	x8, x8, #2064
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	ldr	x1, [x8, x9, lsl #3]
	bl	_nvm_file_flow_join
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB70_33
	b	LBB70_32
LBB70_32:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_33:                               ;   in Loop: Header=BB70_26 Depth=2
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	add	x8, x8, #2064
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9, lsl #3
	bl	_file_body_release
	b	LBB70_34
LBB70_34:                               ;   in Loop: Header=BB70_26 Depth=2
	b	LBB70_35
LBB70_35:                               ;   in Loop: Header=BB70_26 Depth=2
	ldrb	w8, [sp, #23]
	add	w8, w8, #1
	strb	w8, [sp, #23]
	b	LBB70_26
LBB70_36:                               ;   in Loop: Header=BB70_5 Depth=1
	b	LBB70_37
LBB70_37:                               ;   in Loop: Header=BB70_5 Depth=1
	ldrh	w8, [sp, #48]
	add	w8, w8, #1
	strh	w8, [sp, #48]
	b	LBB70_5
LBB70_38:
	ldurb	w8, [x29, #-45]
	tbnz	w8, #0, LBB70_40
	b	LBB70_39
LBB70_39:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB70_41
LBB70_40:
	ldur	x8, [x29, #-16]
	add	x8, x8, #16
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB70_41
LBB70_41:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_release
_file_body_release:                     ; @file_body_release
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x8, [sp]
	ldr	x8, [x8]
	cbz	x8, LBB71_2
	b	LBB71_1
LBB71_1:
	ldr	x8, [sp]
	ldr	x0, [x8]
	bl	_nvm_file_flow_state_free
	ldr	x8, [sp]
                                        ; kill: def $x9 killed $xzr
	str	xzr, [x8]
	ldr	x9, [sp, #8]
	ldr	x8, [x9]
	mov	x10, #-47152                    ; =0xffffffffffff47d0
	add	x8, x8, x10
	str	x8, [x9]
	b	LBB71_2
LBB71_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_function_count   ; -- Begin function nvm_file_body_function_count
	.p2align	2
_nvm_file_body_function_count:          ; @nvm_file_body_function_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB72_2
	b	LBB72_1
LBB72_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_code_function_count
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB72_3
LBB72_2:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB72_3
LBB72_3:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_function         ; -- Begin function nvm_file_body_function
	.p2align	2
_nvm_file_body_function:                ; @nvm_file_body_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB73_2
	b	LBB73_1
LBB73_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_code_function
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB73_2
LBB73_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_local            ; -- Begin function nvm_file_body_local
	.p2align	2
_nvm_file_body_local:                   ; @nvm_file_body_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB74_2
	b	LBB74_1
LBB74_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_code_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB74_2
LBB74_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_body_instruction      ; -- Begin function nvm_file_body_instruction
	.p2align	2
_nvm_file_body_instruction:             ; @nvm_file_body_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	str	x3, [sp, #16]
	str	x4, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB75_5
	b	LBB75_1
LBB75_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB75_5
	b	LBB75_2
LBB75_2:
	ldr	x8, [sp, #8]
	cbz	x8, LBB75_5
	b	LBB75_3
LBB75_3:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB75_5
	b	LBB75_4
LBB75_4:
	ldurh	w8, [x29, #-22]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB75_6
	b	LBB75_5
LBB75_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB75_7
LBB75_6:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-22]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x1, w8, w9, x10
	mov	x2, #600                        ; =0x258
	bl	_memcpy
	ldr	x0, [sp, #8]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-22]
	add	w8, w8, w9
	mov	w9, #80                         ; =0x50
	umaddl	x1, w8, w9, x10
	mov	x2, #80                         ; =0x50
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB75_7
LBB75_7:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_free           ; -- Begin function nvm_file_hosted_free
	.p2align	2
_nvm_file_hosted_free:                  ; @nvm_file_hosted_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB76_2
	b	LBB76_1
LBB76_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_body_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB76_2
LBB76_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_prepare        ; -- Begin function nvm_file_hosted_prepare
	.p2align	2
_nvm_file_hosted_prepare:               ; @nvm_file_hosted_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #48
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	x0, [x8, #336]
	str	x1, [x8, #328]
	str	x2, [x8, #320]
	ldr	x8, [x8, #320]
	cbnz	x8, LBB77_2
	b	LBB77_1
LBB77_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB77_25
LBB77_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #336]
	ldr	x1, [x8, #328]
	sub	x2, x29, #96
	sub	x3, x29, #104
	bl	_file_hosted_preflight
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB77_4
	b	LBB77_3
LBB77_3:
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB77_25
LBB77_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #328]
	bl	_malloc
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x0, [x8, #248]
	ldr	x8, [x8, #248]
	cbnz	x8, LBB77_6
	b	LBB77_5
LBB77_5:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-20]
	b	LBB77_25
LBB77_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #248]
	ldr	x1, [x8, #336]
	ldr	x2, [x8, #328]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	add	x0, sp, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #248                        ; =0xf8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldr	x0, [x8, #248]
	ldr	x1, [x8, #328]
	bl	_nvm_v2_module_deserialize
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB77_8
	b	LBB77_7
LBB77_7:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB77_24
LBB77_8:
	add	x0, sp, #48
	add	x1, sp, #40
	bl	_nvm_v2_to_nvm_module
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB77_10
	b	LBB77_9
LBB77_9:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB77_24
LBB77_10:
	ldr	x8, [sp, #40]
	cbz	x8, LBB77_14
	b	LBB77_11
LBB77_11:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #288]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [x9, #176]
	subs	x8, x8, x9
	b.ne	LBB77_14
	b	LBB77_12
LBB77_12:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #280]
	cbz	x8, LBB77_14
	b	LBB77_13
LBB77_13:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #40]
	ldr	x0, [x9, #280]
	ldr	x1, [x8, #168]
	ldr	x2, [x8, #176]
	bl	_memcmp
	cbz	w0, LBB77_15
	b	LBB77_14
LBB77_14:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-108]
	b	LBB77_24
LBB77_15:
	mov	x0, #1                          ; =0x1
	mov	x1, #4672                       ; =0x1240
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB77_17
	b	LBB77_16
LBB77_16:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-108]
	b	LBB77_24
LBB77_17:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldur	w9, [x29, #-88]
	ldr	x10, [sp, #32]
	str	w9, [x10, #20]
	ldr	x8, [x8, #264]
	ldr	x9, [sp, #32]
	str	x8, [x9, #56]
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #32]
	bl	_nvm_file_body_analyze
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB77_19
	b	LBB77_18
LBB77_18:
	b	LBB77_24
LBB77_19:
	ldr	x0, [sp, #32]
	ldr	x2, [sp, #40]
	add	x1, sp, #48
	bl	_file_hosted_start
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB77_21
	b	LBB77_20
LBB77_20:
	b	LBB77_24
LBB77_21:
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_file_hosted_bounds
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB77_23
	b	LBB77_22
LBB77_22:
	b	LBB77_24
LBB77_23:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #32]
	ldr	x9, [x9, #320]
	str	x8, [x9]
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #32]
	b	LBB77_24
LBB77_24:
	ldr	x0, [sp, #32]
	bl	_nvm_file_hosted_free
	ldr	x0, [sp, #40]
	bl	_nvm_module_free
	add	x0, sp, #48
	bl	_nvm_v2_module_free
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #248]
	bl	_free
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB77_25
LBB77_25:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_preflight
_file_hosted_preflight:                 ; @file_hosted_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #416
	stp	x28, x27, [sp, #384]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #400]            ; 16-byte Folded Spill
	add	x29, sp, #400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB78_2
	b	LBB78_1
LBB78_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_2:
	ldur	x8, [x29, #-40]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB78_4
	b	LBB78_3
LBB78_3:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_4:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	bl	_nvm_v2_validate
	cbnz	w0, LBB78_8
	b	LBB78_5
LBB78_5:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-48]
	bl	_nvm_v2_read_header
	cbnz	w0, LBB78_8
	b	LBB78_6
LBB78_6:
	ldur	x8, [x29, #-48]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	subs	x8, x8, x9
	b.ne	LBB78_8
	b	LBB78_7
LBB78_7:
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #6]
	subs	w8, w8, #2
	b.eq	LBB78_9
	b	LBB78_8
LBB78_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_9:
	mov	w8, #898                        ; =0x382
	stur	w8, [x29, #-60]
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-60]
	and	w8, w8, w9
	ldur	w9, [x29, #-60]
	subs	w8, w8, w9
	b.eq	LBB78_11
	b	LBB78_10
LBB78_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_11:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #8]
	ldur	w9, [x29, #-60]
	orr	w9, w9, #0x8
	bic	w8, w8, w9
	cbz	w8, LBB78_13
	b	LBB78_12
LBB78_12:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_13:
	add	x0, sp, #120
	mov	x2, #216                        ; =0xd8
	mov	w1, #0                          ; =0x0
	bl	_memset
	str	wzr, [sp, #116]
	b	LBB78_14
LBB78_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #116]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.hs	LBB78_21
	b	LBB78_15
LBB78_15:                               ;   in Loop: Header=BB78_14 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	x2, [x29, #-48]
	ldr	w3, [sp, #116]
	add	x4, sp, #88
	bl	_nvm_v2_read_section
	cbz	w0, LBB78_17
	b	LBB78_16
LBB78_16:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_17:                               ;   in Loop: Header=BB78_14 Depth=1
	ldur	x0, [x29, #-32]
	ldur	q0, [sp, #88]
	add	x1, sp, #48
	str	q0, [sp, #48]
	ldr	x8, [sp, #104]
	str	x8, [sp, #64]
	add	x2, sp, #120
	bl	_file_hosted_section
	str	w0, [sp, #84]
	ldr	w8, [sp, #84]
	cbz	w8, LBB78_19
	b	LBB78_18
LBB78_18:
	ldr	w8, [sp, #84]
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_19:                               ;   in Loop: Header=BB78_14 Depth=1
	b	LBB78_20
LBB78_20:                               ;   in Loop: Header=BB78_14 Depth=1
	ldr	w8, [sp, #116]
	add	w8, w8, #1
	str	w8, [sp, #116]
	b	LBB78_14
LBB78_21:
	ldr	w8, [sp, #128]
	str	w8, [sp, #44]
	ldr	w8, [sp, #140]
	str	w8, [sp, #40]
	ldr	w8, [sp, #136]
	str	w8, [sp, #36]
	ldr	x8, [sp, #216]
	str	x8, [sp, #24]
	str	xzr, [sp, #16]
	str	xzr, [sp, #8]
	ldr	w8, [sp, #40]
	cbz	w8, LBB78_26
	b	LBB78_22
LBB78_22:
	ldur	x8, [x29, #-48]
	ldr	w8, [x8, #32]
	ldr	w9, [sp, #40]
	subs	w8, w8, w9
	b.hs	LBB78_26
	b	LBB78_23
LBB78_23:
	ldr	x8, [sp, #296]
	cbz	x8, LBB78_26
	b	LBB78_24
LBB78_24:
	ldr	x8, [sp, #288]
	cbz	x8, LBB78_26
	b	LBB78_25
LBB78_25:
	ldr	x8, [sp, #232]
	cbnz	x8, LBB78_27
	b	LBB78_26
LBB78_26:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_27:
	ldr	w0, [sp, #36]
	add	x1, sp, #16
	bl	_nvm_file_nominal_storage_bound
	tbnz	w0, #0, LBB78_29
	b	LBB78_28
LBB78_28:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_29:
	ldur	x1, [x29, #-40]
	add	x0, sp, #8
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_30
LBB78_30:
	ldr	x1, [sp, #304]
	add	x0, sp, #8
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_31
LBB78_31:
	ldr	x1, [sp, #312]
	add	x0, sp, #8
	mov	x2, #2                          ; =0x2
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_32
LBB78_32:
	ldr	w8, [sp, #36]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #16                         ; =0x10
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_33
LBB78_33:
	add	x0, sp, #8
	mov	x1, #1                          ; =0x1
	mov	x2, #16777216                   ; =0x1000000
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_34
LBB78_34:
	add	x0, sp, #8
	mov	x1, #1                          ; =0x1
	mov	x2, #4672                       ; =0x1240
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_35
LBB78_35:
	add	x0, sp, #8
	mov	x1, #2                          ; =0x2
	mov	x2, #480                        ; =0x1e0
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_36
LBB78_36:
	add	x0, sp, #8
	mov	x1, #1                          ; =0x1
	mov	x2, #248                        ; =0xf8
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_37
LBB78_37:
	add	x0, sp, #8
	mov	x1, #1                          ; =0x1
	mov	x2, #216                        ; =0xd8
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_38
LBB78_38:
	ldr	w8, [sp, #44]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #64                         ; =0x40
	mov	x3, #12                         ; =0xc
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_39
LBB78_39:
	ldr	w8, [sp, #40]
	mov	x1, x8
	add	x0, sp, #8
	mov	x3, #32                         ; =0x20
	mov	x2, x3
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_40
LBB78_40:
	ldr	x1, [sp, #232]
	add	x0, sp, #8
	mov	x2, #4096                       ; =0x1000
	mov	x3, #1                          ; =0x1
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_41
LBB78_41:
	ldr	w8, [sp, #160]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #256                        ; =0x100
	mov	x3, #12                         ; =0xc
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_42
LBB78_42:
	ldr	w8, [sp, #124]
	mov	x1, x8
	add	x0, sp, #8
	mov	x3, #8                          ; =0x8
	mov	x2, x3
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_43
LBB78_43:
	ldr	w8, [sp, #152]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #32                         ; =0x20
	mov	x3, #20                         ; =0x14
	bl	_file_hosted_array
	tbz	w0, #0, LBB78_53
	b	LBB78_44
LBB78_44:
	add	x0, sp, #8
	mov	x1, #16                         ; =0x10
	mov	x2, #4                          ; =0x4
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_45
LBB78_45:
	ldr	x1, [sp, #320]
	add	x0, sp, #8
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_46
LBB78_46:
	ldr	w8, [sp, #40]
                                        ; kill: def $x8 killed $w8
	ldr	w9, [sp, #152]
                                        ; kill: def $x9 killed $w9
	add	x1, x8, x9
	ldrh	w8, [sp, #328]
	mov	x2, x8
	add	x0, sp, #8
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_47
LBB78_47:
	ldr	x1, [sp, #24]
	add	x0, sp, #8
	mov	x2, #2                          ; =0x2
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_48
LBB78_48:
	ldr	x1, [sp, #288]
	add	x0, sp, #8
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_49
LBB78_49:
	add	x0, sp, #8
	mov	x1, #120                        ; =0x78
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_50
LBB78_50:
	ldr	w8, [sp, #44]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #12                         ; =0xc
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_51
LBB78_51:
	ldr	w8, [sp, #40]
	mov	x1, x8
	add	x0, sp, #8
	mov	x2, #32                         ; =0x20
	bl	_file_hosted_add
	tbz	w0, #0, LBB78_53
	b	LBB78_52
LBB78_52:
	ldr	x1, [sp, #16]
	add	x0, sp, #8
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbnz	w0, #0, LBB78_54
	b	LBB78_53
LBB78_53:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB78_55
LBB78_54:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-56]
	str	x8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB78_55
LBB78_55:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #400]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #416
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_codec_status
_file_hosted_codec_status:              ; @file_hosted_codec_status
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #12]
	mov	w0, #2                          ; =0x2
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_start
_file_hosted_start:                     ; @file_hosted_start
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #8]
	ldur	x9, [x29, #-16]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #12]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #16]
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB80_2
	b	LBB80_1
LBB80_1:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB80_3
	b	LBB80_2
LBB80_2:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB80_28
LBB80_3:
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	cbnz	w8, LBB80_9
	b	LBB80_4
LBB80_4:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	subs	w8, w8, #1
	b.ne	LBB80_9
	b	LBB80_5
LBB80_5:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB80_9
	b	LBB80_6
LBB80_6:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.ne	LBB80_9
	b	LBB80_7
LBB80_7:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB80_10
	b	LBB80_8
LBB80_8:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #4
	b.eq	LBB80_10
	b	LBB80_9
LBB80_9:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB80_28
LBB80_10:
	str	wzr, [sp, #12]
	b	LBB80_11
LBB80_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB80_27
	b	LBB80_12
LBB80_12:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #256]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB80_15
	b	LBB80_13
LBB80_13:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB80_15
	b	LBB80_14
LBB80_14:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB80_16
	b	LBB80_15
LBB80_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB80_28
LBB80_16:                               ;   in Loop: Header=BB80_11 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.ne	LBB80_25
	b	LBB80_17
LBB80_17:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB80_25
	b	LBB80_18
LBB80_18:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp]
	ldr	x8, [sp]
	ldrh	w8, [x8]
	cbnz	w8, LBB80_23
	b	LBB80_19
LBB80_19:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #4]
	cbnz	w8, LBB80_23
	b	LBB80_20
LBB80_20:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB80_23
	b	LBB80_21
LBB80_21:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB80_23
	b	LBB80_22
LBB80_22:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.eq	LBB80_24
	b	LBB80_23
LBB80_23:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB80_28
LBB80_24:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #12]
	b	LBB80_25
LBB80_25:                               ;   in Loop: Header=BB80_11 Depth=1
	b	LBB80_26
LBB80_26:                               ;   in Loop: Header=BB80_11 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB80_11
LBB80_27:
	stur	wzr, [x29, #-4]
	b	LBB80_28
LBB80_28:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_bounds
_file_hosted_bounds:                    ; @file_hosted_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x8, [x8]
	stur	x8, [x29, #-48]
	stur	wzr, [x29, #-52]
	b	LBB81_1
LBB81_1:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB81_3 Depth 2
                                        ;     Child Loop BB81_20 Depth 2
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB81_44
	b	LBB81_2
LBB81_2:                                ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-48]
	add	x8, x8, #2608
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-56]
	ldur	x8, [x29, #-32]
	add	x10, x8, #64
	ldur	w8, [x29, #-56]
                                        ; kill: def $x8 killed $w8
	mov	x9, #72                         ; =0x48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x0, [x29, #-64]
	ldur	x8, [x29, #-48]
	add	x10, x8, #48
	ldur	w8, [x29, #-56]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #36                         ; =0x24
	bl	_memcpy
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	ldr	x8, [x8, #72]
	ldur	w10, [x29, #-56]
                                        ; kill: def $x10 killed $w10
	add	x8, x8, x10, lsl #5
	ldrh	w8, [x8, #28]
	ldur	x10, [x29, #-64]
	strh	w8, [x10, #36]
	ldur	x8, [x29, #-48]
	add	x10, x8, #48
	ldur	w8, [x29, #-56]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #14]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #40]
	ldur	x9, [x29, #-64]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #42]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #44]
	sturh	wzr, [x29, #-66]
	b	LBB81_3
LBB81_3:                                ;   Parent Loop BB81_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-66]
	ldur	x9, [x29, #-48]
	add	x11, x9, #48
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB81_16
	b	LBB81_4
LBB81_4:                                ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-48]
	add	x8, x8, #2352
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-66]
	add	w8, w8, w9
	mov	w9, #80                         ; =0x50
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-80]
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB81_6
	b	LBB81_5
LBB81_5:                                ;   in Loop: Header=BB81_3 Depth=2
	b	LBB81_15
LBB81_6:                                ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.le	LBB81_8
	b	LBB81_7
LBB81_7:                                ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #38]
	b	LBB81_8
LBB81_8:                                ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #6]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.le	LBB81_10
	b	LBB81_9
LBB81_9:                                ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #6]
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #38]
	b	LBB81_10
LBB81_10:                               ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8, #3]
	tbz	w8, #0, LBB81_14
	b	LBB81_11
LBB81_11:                               ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.ne	LBB81_14
	b	LBB81_12
LBB81_12:                               ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #48]
	add	w8, w8, #1
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #42]
	subs	w8, w8, w9
	b.ls	LBB81_14
	b	LBB81_13
LBB81_13:                               ;   in Loop: Header=BB81_3 Depth=2
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #48]
	add	w8, w8, #1
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #42]
	b	LBB81_14
LBB81_14:                               ;   in Loop: Header=BB81_3 Depth=2
	b	LBB81_15
LBB81_15:                               ;   in Loop: Header=BB81_3 Depth=2
	ldurh	w8, [x29, #-66]
	add	w8, w8, #1
	sturh	w8, [x29, #-66]
	b	LBB81_3
LBB81_16:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #36]
	cbz	w8, LBB81_19
	b	LBB81_17
LBB81_17:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #36]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.ge	LBB81_19
	b	LBB81_18
LBB81_18:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB81_61
LBB81_19:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #38]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #88]
	ldr	x8, [sp, #88]
	ldur	x9, [x29, #-64]
	str	x8, [x9, #64]
	ldur	x9, [x29, #-64]
	str	x8, [x9, #56]
	strh	wzr, [sp, #86]
	b	LBB81_20
LBB81_20:                               ;   Parent Loop BB81_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #86]
	ldur	x9, [x29, #-48]
	add	x11, x9, #48
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB81_38
	b	LBB81_21
LBB81_21:                               ;   in Loop: Header=BB81_20 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-48]
	add	x8, x8, #2352
	ldur	w9, [x29, #-56]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #86]
	add	w8, w8, w9
	mov	w9, #80                         ; =0x50
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldr	x8, [sp, #72]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB81_24
	b	LBB81_22
LBB81_22:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #72]
	ldrb	w8, [x8, #3]
	tbz	w8, #0, LBB81_24
	b	LBB81_23
LBB81_23:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB81_25
	b	LBB81_24
LBB81_24:                               ;   in Loop: Header=BB81_20 Depth=2
	b	LBB81_37
LBB81_25:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #72]
	add	x8, x8, #24
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-48]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB81_27
	b	LBB81_26
LBB81_26:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #64]
	ldrh	w8, [x8, #28]
	ldr	x9, [sp, #64]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.le	LBB81_28
	b	LBB81_27
LBB81_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB81_61
LBB81_28:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #64]
	ldrh	w8, [x8, #24]
	ldr	x9, [sp, #64]
	ldrh	w9, [x9, #28]
	subs	w8, w8, w9
	strh	w8, [sp, #62]
	ldrh	w8, [sp, #62]
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.le	LBB81_30
	b	LBB81_29
LBB81_29:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB81_61
LBB81_30:                               ;   in Loop: Header=BB81_20 Depth=2
	ldur	x8, [x29, #-32]
	add	x10, x8, #64
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #72                         ; =0x48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrh	w9, [sp, #62]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #56]
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x8, [sp, #88]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #64]
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.ls	LBB81_32
	b	LBB81_31
LBB81_31:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-64]
	str	x8, [x9, #56]
	b	LBB81_32
LBB81_32:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-64]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ls	LBB81_34
	b	LBB81_33
LBB81_33:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-64]
	str	x8, [x9, #64]
	b	LBB81_34
LBB81_34:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #48]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #44]
	subs	w8, w8, w9
	b.ls	LBB81_36
	b	LBB81_35
LBB81_35:                               ;   in Loop: Header=BB81_20 Depth=2
	ldr	x8, [sp, #48]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-64]
	strh	w8, [x9, #44]
	b	LBB81_36
LBB81_36:                               ;   in Loop: Header=BB81_20 Depth=2
	b	LBB81_37
LBB81_37:                               ;   in Loop: Header=BB81_20 Depth=2
	ldrh	w8, [sp, #86]
	add	w8, w8, #1
	strh	w8, [sp, #86]
	b	LBB81_20
LBB81_38:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldur	x9, [x29, #-64]
	str	w8, [x9, #48]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldur	x9, [x29, #-64]
	str	w8, [x9, #52]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #44]
	subs	w8, w8, #64
	b.hi	LBB81_41
	b	LBB81_39
LBB81_39:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #56]
	mov	x9, #49216                      ; =0xc040
	subs	x8, x8, x9
	b.hi	LBB81_41
	b	LBB81_40
LBB81_40:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #64]
	mov	x9, #49216                      ; =0xc040
	subs	x8, x8, x9
	b.ls	LBB81_42
	b	LBB81_41
LBB81_41:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB81_61
LBB81_42:                               ;   in Loop: Header=BB81_1 Depth=1
	b	LBB81_43
LBB81_43:                               ;   in Loop: Header=BB81_1 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB81_1
LBB81_44:
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-16]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #12]
	stur	w8, [x29, #-12]
	str	wzr, [sp, #28]
	b	LBB81_45
LBB81_45:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #28]
	subs	w8, w8, #2
	b.hs	LBB81_60
	b	LBB81_46
LBB81_46:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	w8, [sp, #28]
	mov	x9, x8
	sub	x8, x29, #16
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB81_58
	b	LBB81_47
LBB81_47:                               ;   in Loop: Header=BB81_45 Depth=1
	ldur	x8, [x29, #-32]
	add	x10, x8, #64
	ldr	w8, [sp, #28]
	mov	x9, x8
	sub	x8, x29, #16
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	mov	x9, #72                         ; =0x48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.ls	LBB81_49
	b	LBB81_48
LBB81_48:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #56]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #24]
	b	LBB81_49
LBB81_49:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ls	LBB81_51
	b	LBB81_50
LBB81_50:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-32]
	str	x8, [x9, #32]
	b	LBB81_51
LBB81_51:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #40]
	subs	w8, w8, w9
	b.le	LBB81_53
	b	LBB81_52
LBB81_52:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-32]
	strh	w8, [x9, #40]
	b	LBB81_53
LBB81_53:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #48]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #44]
	subs	w8, w8, w9
	b.ls	LBB81_55
	b	LBB81_54
LBB81_54:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #48]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #44]
	b	LBB81_55
LBB81_55:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.ls	LBB81_57
	b	LBB81_56
LBB81_56:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-32]
	str	w8, [x9, #48]
	b	LBB81_57
LBB81_57:                               ;   in Loop: Header=BB81_45 Depth=1
	b	LBB81_58
LBB81_58:                               ;   in Loop: Header=BB81_45 Depth=1
	b	LBB81_59
LBB81_59:                               ;   in Loop: Header=BB81_45 Depth=1
	ldr	w8, [sp, #28]
	add	w8, w8, #1
	str	w8, [sp, #28]
	b	LBB81_45
LBB81_60:
	stur	wzr, [x29, #-20]
	b	LBB81_61
LBB81_61:
	ldur	w8, [x29, #-20]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB81_63
	b	LBB81_62
LBB81_62:
	bl	___stack_chk_fail
LBB81_63:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_startup        ; -- Begin function nvm_file_hosted_startup
	.p2align	2
_nvm_file_hosted_startup:               ; @nvm_file_hosted_startup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB82_2
	b	LBB82_1
LBB82_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB82_3
	b	LBB82_2
LBB82_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB82_4
LBB82_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x1, x8, #8
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB82_4
LBB82_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_function       ; -- Begin function nvm_file_hosted_function
	.p2align	2
_nvm_file_hosted_function:              ; @nvm_file_hosted_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB83_3
	b	LBB83_1
LBB83_1:
	ldr	x8, [sp]
	cbz	x8, LBB83_3
	b	LBB83_2
LBB83_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB83_4
	b	LBB83_3
LBB83_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB83_5
LBB83_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #64
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #72                         ; =0x48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #72                         ; =0x48
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB83_5
LBB83_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_local          ; -- Begin function nvm_file_hosted_local
	.p2align	2
_nvm_file_hosted_local:                 ; @nvm_file_hosted_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB84_2
	b	LBB84_1
LBB84_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_body_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB84_2
LBB84_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_instruction    ; -- Begin function nvm_file_hosted_instruction
	.p2align	2
_nvm_file_hosted_instruction:           ; @nvm_file_hosted_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #24]
	str	x4, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB85_2
	b	LBB85_1
LBB85_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #24]
	ldr	x4, [sp, #16]
	bl	_nvm_file_body_instruction
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB85_2
LBB85_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_type           ; -- Begin function nvm_file_hosted_type
	.p2align	2
_nvm_file_hosted_type:                  ; @nvm_file_hosted_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB86_2
	b	LBB86_1
LBB86_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_nominal_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB86_2
LBB86_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_hosted_import         ; -- Begin function nvm_file_hosted_import
	.p2align	2
_nvm_file_hosted_import:                ; @nvm_file_hosted_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB87_2
	b	LBB87_1
LBB87_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_nominal_import
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB87_2
LBB87_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_free           ; -- Begin function nvm_file_cyclic_free
	.p2align	2
_nvm_file_cyclic_free:                  ; @nvm_file_cyclic_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbnz	x8, LBB88_2
	b	LBB88_1
LBB88_1:
	b	LBB88_13
LBB88_2:
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #8]
	cbz	x8, LBB88_12
	b	LBB88_3
LBB88_3:
	str	wzr, [sp, #4]
	b	LBB88_4
LBB88_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB88_6 Depth 2
	ldr	w8, [sp, #4]
	ldr	x9, [sp, #8]
	ldr	x9, [x9]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB88_11
	b	LBB88_5
LBB88_5:                                ;   in Loop: Header=BB88_4 Depth=1
	strb	wzr, [sp, #3]
	b	LBB88_6
LBB88_6:                                ;   Parent Loop BB88_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #3]
	ldr	x9, [sp, #8]
	ldr	x9, [x9, #8]
	ldr	w10, [sp, #4]
                                        ; kill: def $x10 killed $w10
	mov	x11, #136                       ; =0x88
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.ge	LBB88_9
	b	LBB88_7
LBB88_7:                                ;   in Loop: Header=BB88_6 Depth=2
	ldr	x8, [sp, #8]
	ldr	x10, [x8, #8]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #136                        ; =0x88
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #8
	ldrb	w9, [sp, #3]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	bl	_free
	b	LBB88_8
LBB88_8:                                ;   in Loop: Header=BB88_6 Depth=2
	ldrb	w8, [sp, #3]
	add	w8, w8, #1
	strb	w8, [sp, #3]
	b	LBB88_6
LBB88_9:                                ;   in Loop: Header=BB88_4 Depth=1
	b	LBB88_10
LBB88_10:                               ;   in Loop: Header=BB88_4 Depth=1
	ldr	w8, [sp, #4]
	add	w8, w8, #1
	str	w8, [sp, #4]
	b	LBB88_4
LBB88_11:
	b	LBB88_12
LBB88_12:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_code_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB88_13
LBB88_13:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_analyze        ; -- Begin function nvm_file_cyclic_analyze
	.p2align	2
_nvm_file_cyclic_analyze:               ; @nvm_file_cyclic_analyze
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	str	x1, [sp]
	ldr	x0, [sp, #8]
	ldr	x1, [sp]
	mov	x2, #0                          ; =0x0
	bl	_file_cyclic_analyze_extended
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_analyze_extended
_file_cyclic_analyze_extended:          ; @file_cyclic_analyze_extended
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #24
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x0, [x8, #8]
	str	x1, [x8]
	stur	x2, [x29, #-32]
	ldr	x8, [x8]
	cbnz	x8, LBB90_2
	b	LBB90_1
LBB90_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_2:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-32]
	cbz	x8, LBB90_4
	b	LBB90_3
LBB90_3:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB90_5
LBB90_4:
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB90_5
LBB90_5:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	sub	x2, x29, #36
	sub	x3, x29, #48
	sub	x4, x29, #56
	bl	_file_cyclic_budget
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB90_7
	b	LBB90_6
LBB90_6:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	sub	x1, x29, #72
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-72]
	ldr	x0, [x8, #8]
	ldur	x8, [x29, #-32]
	subs	x8, x8, #0
	cset	w3, ne
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_file_code_prepare_profile
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB90_9
	b	LBB90_8
LBB90_8:
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_9:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB90_24
	b	LBB90_10
LBB90_10:
	stur	xzr, [x29, #-80]
	stur	wzr, [x29, #-84]
	b	LBB90_11
LBB90_11:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB90_13 Depth 2
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB90_23
	b	LBB90_12
LBB90_12:                               ;   in Loop: Header=BB90_11 Depth=1
	stur	wzr, [x29, #-88]
	b	LBB90_13
LBB90_13:                               ;   Parent Loop BB90_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB90_19
	b	LBB90_14
LBB90_14:                               ;   in Loop: Header=BB90_13 Depth=2
	ldur	x8, [x29, #-80]
	ldur	w9, [x29, #-88]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbnz	x8, LBB90_17
	b	LBB90_15
LBB90_15:                               ;   in Loop: Header=BB90_13 Depth=2
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #8]
	ldur	w9, [x29, #-88]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-80]
	bic	x8, x8, x9
	cbnz	x8, LBB90_17
	b	LBB90_16
LBB90_16:                               ;   in Loop: Header=BB90_11 Depth=1
	b	LBB90_19
LBB90_17:                               ;   in Loop: Header=BB90_13 Depth=2
	b	LBB90_18
LBB90_18:                               ;   in Loop: Header=BB90_13 Depth=2
	ldur	w8, [x29, #-88]
	add	w8, w8, #1
	stur	w8, [x29, #-88]
	b	LBB90_13
LBB90_19:                               ;   in Loop: Header=BB90_11 Depth=1
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB90_21
	b	LBB90_20
LBB90_20:
	ldur	x0, [x29, #-72]
	bl	_nvm_file_code_free
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_21:                               ;   in Loop: Header=BB90_11 Depth=1
	ldur	w8, [x29, #-88]
	ldur	x9, [x29, #-72]
	add	x9, x9, #2608
	ldur	w10, [x29, #-84]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldur	w8, [x29, #-88]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x9, x8, x9
	ldur	x8, [x29, #-80]
	orr	x8, x8, x9
	stur	x8, [x29, #-80]
	b	LBB90_22
LBB90_22:                               ;   in Loop: Header=BB90_11 Depth=1
	ldur	w8, [x29, #-84]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	b	LBB90_11
LBB90_23:
	b	LBB90_24
LBB90_24:
	mov	x0, #1                          ; =0x1
	mov	x1, #56                         ; =0x38
	bl	_calloc
	str	x0, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB90_26
	b	LBB90_25
LBB90_25:
	ldur	x0, [x29, #-72]
	bl	_nvm_file_code_free
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_26:
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #96]
	str	x8, [x9]
	ldr	x8, [sp, #96]
	add	x0, x8, #16
	add	x1, sp, #56
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #56]
	ldur	x8, [x29, #-72]
	ldr	w8, [x8, #24]
	str	w8, [sp, #60]
	ldur	w8, [x29, #-36]
	str	w8, [sp, #64]
	str	wzr, [sp, #68]
	str	wzr, [sp, #72]
	str	wzr, [sp, #76]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #80]
	strb	wzr, [sp, #88]
	stur	wzr, [x1, #33]
	str	wzr, [sp, #92]
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldur	w8, [x29, #-36]
	mov	x0, x8
	mov	x1, #136                        ; =0x88
	bl	_calloc
	ldr	x8, [sp, #96]
	str	x0, [x8, #8]
	mov	x0, #1                          ; =0x1
	mov	x1, #41624                      ; =0xa298
	movk	x1, #1, lsl #16
	bl	_calloc
	str	x0, [sp, #48]
	ldur	x0, [x29, #-56]
	bl	_malloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #96]
	ldr	x8, [x8, #8]
	cbz	x8, LBB90_29
	b	LBB90_27
LBB90_27:
	ldr	x8, [sp, #48]
	cbz	x8, LBB90_29
	b	LBB90_28
LBB90_28:
	ldr	x8, [sp, #40]
	cbnz	x8, LBB90_30
	b	LBB90_29
LBB90_29:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-60]
	b	LBB90_40
LBB90_30:
	ldr	x0, [sp, #40]
	ldur	x8, [x29, #-72]
	ldr	x1, [x8]
	ldur	x2, [x29, #-56]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	ldr	x9, [sp, #40]
	mov	w8, #1                          ; =0x1
	str	w8, [x9]
	ldur	x8, [x29, #-72]
	ldr	x9, [sp, #48]
	str	x8, [x9]
	str	wzr, [sp, #36]
	b	LBB90_31
LBB90_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB90_36
	b	LBB90_32
LBB90_32:                               ;   in Loop: Header=BB90_31 Depth=1
	ldr	x0, [sp, #96]
	ldr	x1, [sp, #48]
	ldr	x2, [sp, #40]
	ldur	x8, [x29, #-72]
	add	x8, x8, #2608
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldr	w3, [x8, x9, lsl #2]
	ldur	x4, [x29, #-32]
	bl	_file_cyclic_function_analyze
	stur	w0, [x29, #-60]
	ldur	w8, [x29, #-60]
	cbz	w8, LBB90_34
	b	LBB90_33
LBB90_33:
	b	LBB90_36
LBB90_34:                               ;   in Loop: Header=BB90_31 Depth=1
	b	LBB90_35
LBB90_35:                               ;   in Loop: Header=BB90_31 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB90_31
LBB90_36:
	ldur	w8, [x29, #-60]
	cbnz	w8, LBB90_39
	b	LBB90_37
LBB90_37:
	ldr	x0, [sp, #96]
	bl	_file_cyclic_complete
	tbnz	w0, #0, LBB90_39
	b	LBB90_38
LBB90_38:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-60]
	b	LBB90_39
LBB90_39:
	b	LBB90_40
LBB90_40:
	ldr	x0, [sp, #40]
	bl	_free
	ldr	x0, [sp, #48]
	bl	_free
	ldur	w8, [x29, #-60]
	cbz	w8, LBB90_42
	b	LBB90_41
LBB90_41:
	ldr	x0, [sp, #96]
	bl	_nvm_file_cyclic_free
	ldur	w8, [x29, #-60]
	stur	w8, [x29, #-4]
	b	LBB90_43
LBB90_42:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #96]
	ldr	x9, [x9]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB90_43
LBB90_43:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_summary        ; -- Begin function nvm_file_cyclic_summary
	.p2align	2
_nvm_file_cyclic_summary:               ; @nvm_file_cyclic_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB91_2
	b	LBB91_1
LBB91_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB91_3
	b	LBB91_2
LBB91_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB91_4
LBB91_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x1, x8, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB91_4
LBB91_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_function       ; -- Begin function nvm_file_cyclic_function
	.p2align	2
_nvm_file_cyclic_function:              ; @nvm_file_cyclic_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB92_2
	b	LBB92_1
LBB92_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_code_function
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB92_2
LBB92_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_local          ; -- Begin function nvm_file_cyclic_local
	.p2align	2
_nvm_file_cyclic_local:                 ; @nvm_file_cyclic_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB93_2
	b	LBB93_1
LBB93_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_code_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB93_2
LBB93_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_instruction    ; -- Begin function nvm_file_cyclic_instruction
	.p2align	2
_nvm_file_cyclic_instruction:           ; @nvm_file_cyclic_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB94_2
	b	LBB94_1
LBB94_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_code_instruction
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB94_2
LBB94_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_component      ; -- Begin function nvm_file_cyclic_component
	.p2align	2
_nvm_file_cyclic_component:             ; @nvm_file_cyclic_component
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	bl	_file_cyclic_site
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB95_2
	b	LBB95_1
LBB95_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB95_3
	b	LBB95_2
LBB95_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB95_4
LBB95_3:
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #16]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB95_4
LBB95_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_site
_file_cyclic_site:                      ; @file_cyclic_site
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	strh	w2, [sp, #10]
	ldr	x8, [sp, #16]
	cbz	x8, LBB96_3
	b	LBB96_1
LBB96_1:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB96_3
	b	LBB96_2
LBB96_2:
	ldrh	w8, [sp, #10]
	ldr	x9, [sp, #16]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB96_4
	b	LBB96_3
LBB96_3:
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #24]
	b	LBB96_5
LBB96_4:
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #16]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #10]
	add	w8, w8, w9
	mov	w9, #136                        ; =0x88
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	b	LBB96_5
LBB96_5:
	ldr	x0, [sp, #24]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_variant_count  ; -- Begin function nvm_file_cyclic_variant_count
	.p2align	2
_nvm_file_cyclic_variant_count:         ; @nvm_file_cyclic_variant_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	str	x3, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	bl	_file_cyclic_site
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB97_2
	b	LBB97_1
LBB97_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB97_3
	b	LBB97_2
LBB97_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB97_4
LBB97_3:
	ldr	x8, [sp, #8]
	ldrb	w8, [x8]
	ldr	x9, [sp, #16]
	strb	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB97_4
LBB97_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_variant        ; -- Begin function nvm_file_cyclic_variant
	.p2align	2
_nvm_file_cyclic_variant:               ; @nvm_file_cyclic_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	str	x4, [sp, #16]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	ldurb	w3, [x29, #-23]
	bl	_file_cyclic_node
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB98_2
	b	LBB98_1
LBB98_1:
	ldr	x8, [sp, #16]
	cbnz	x8, LBB98_3
	b	LBB98_2
LBB98_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB98_4
LBB98_3:
	ldr	x0, [sp, #16]
	ldr	x8, [sp, #8]
	add	x1, x8, #56
	mov	x2, #104                        ; =0x68
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB98_4
LBB98_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_node
_file_cyclic_node:                      ; @file_cyclic_node
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	ldur	x0, [x29, #-8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	bl	_file_cyclic_site
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB99_3
	b	LBB99_1
LBB99_1:
	ldurb	w8, [x29, #-15]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB99_3
	b	LBB99_2
LBB99_2:
	ldr	x8, [sp, #8]
	add	x8, x8, #8
	ldurb	w9, [x29, #-15]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB99_4
LBB99_3:
	mov	x8, #0                          ; =0x0
	str	x8, [sp]                        ; 8-byte Folded Spill
	b	LBB99_4
LBB99_4:
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_input_local    ; -- Begin function nvm_file_cyclic_input_local
	.p2align	2
_nvm_file_cyclic_input_local:           ; @nvm_file_cyclic_input_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	strh	w4, [sp, #22]
	str	x5, [sp, #8]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	ldurb	w3, [x29, #-23]
	bl	_file_cyclic_node
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB100_3
	b	LBB100_1
LBB100_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB100_3
	b	LBB100_2
LBB100_2:
	ldrh	w8, [sp, #22]
	ldr	x9, [sp]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.lt	LBB100_4
	b	LBB100_3
LBB100_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB100_5
LBB100_4:
	ldr	x0, [sp, #8]
	ldr	x8, [sp]
	ldr	x10, [x8, #16]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB100_5
LBB100_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_input_stack    ; -- Begin function nvm_file_cyclic_input_stack
	.p2align	2
_nvm_file_cyclic_input_stack:           ; @nvm_file_cyclic_input_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	strh	w4, [sp, #22]
	str	x5, [sp, #8]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	ldurb	w3, [x29, #-23]
	bl	_file_cyclic_node
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB101_3
	b	LBB101_1
LBB101_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB101_3
	b	LBB101_2
LBB101_2:
	ldrh	w8, [sp, #22]
	ldr	x9, [sp]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB101_4
	b	LBB101_3
LBB101_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB101_5
LBB101_4:
	ldr	x0, [sp, #8]
	ldr	x8, [sp]
	ldr	x10, [x8, #24]
	ldrh	w8, [sp, #22]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB101_5
LBB101_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_input_reference ; -- Begin function nvm_file_cyclic_input_reference
	.p2align	2
_nvm_file_cyclic_input_reference:       ; @nvm_file_cyclic_input_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	sturh	w4, [x29, #-26]
	stur	x5, [x29, #-40]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	ldurb	w3, [x29, #-23]
	bl	_file_cyclic_node
	stur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbz	x8, LBB102_3
	b	LBB102_1
LBB102_1:
	ldur	x8, [x29, #-40]
	cbz	x8, LBB102_3
	b	LBB102_2
LBB102_2:
	ldurh	w8, [x29, #-26]
	subs	w8, w8, #256
	b.lo	LBB102_4
	b	LBB102_3
LBB102_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB102_8
LBB102_4:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldurh	w8, [x29, #-26]
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #48]
	subs	w8, w8, w9
	b.ge	LBB102_6
	b	LBB102_5
LBB102_5:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-48]
	ldr	x10, [x8, #32]
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB102_7
LBB102_6:
	add	x0, sp, #24
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	bl	_memcpy
	b	LBB102_7
LBB102_7:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB102_8
LBB102_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_input_region   ; -- Begin function nvm_file_cyclic_input_region
	.p2align	2
_nvm_file_cyclic_input_region:          ; @nvm_file_cyclic_input_region
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	sturb	w3, [x29, #-23]
	strh	w4, [sp, #22]
	str	x5, [sp, #8]
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-20]
	ldurh	w2, [x29, #-22]
	ldurb	w3, [x29, #-23]
	bl	_file_cyclic_node
	str	x0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB103_3
	b	LBB103_1
LBB103_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB103_3
	b	LBB103_2
LBB103_2:
	ldrh	w8, [sp, #22]
	ldr	x9, [sp]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.lt	LBB103_4
	b	LBB103_3
LBB103_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB103_5
LBB103_4:
	ldr	x8, [sp]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #22]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #8]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB103_5
LBB103_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_type           ; -- Begin function nvm_file_cyclic_type
	.p2align	2
_nvm_file_cyclic_type:                  ; @nvm_file_cyclic_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB104_2
	b	LBB104_1
LBB104_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_nominal_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB104_2
LBB104_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_import         ; -- Begin function nvm_file_cyclic_import
	.p2align	2
_nvm_file_cyclic_import:                ; @nvm_file_cyclic_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB105_2
	b	LBB105_1
LBB105_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_nominal_import
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB105_2
LBB105_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_free    ; -- Begin function nvm_file_cyclic_hosted_free
	.p2align	2
_nvm_file_cyclic_hosted_free:           ; @nvm_file_cyclic_hosted_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB106_2
	b	LBB106_1
LBB106_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_cyclic_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB106_2
LBB106_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_prepare ; -- Begin function nvm_file_cyclic_hosted_prepare
	.p2align	2
_nvm_file_cyclic_hosted_prepare:        ; @nvm_file_cyclic_hosted_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB107_2
	b	LBB107_1
LBB107_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_2:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	sub	x2, x29, #96
	sub	x3, x29, #104
	bl	_file_hosted_preflight
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB107_4
	b	LBB107_3
LBB107_3:
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_4:
	ldur	x8, [x29, #-104]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hs	LBB107_6
	b	LBB107_5
LBB107_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_6:
	sub	x0, x29, #104
	ldur	x8, [x29, #-104]
	mov	x9, #-16777216                  ; =0xffffffffff000000
	add	x8, x8, x9
	stur	x8, [x29, #-104]
	mov	x1, #1                          ; =0x1
	mov	x2, #16777216                   ; =0x1000000
	bl	_file_hosted_add
	tbz	w0, #0, LBB107_8
	b	LBB107_7
LBB107_7:
	sub	x0, x29, #104
	mov	x1, #1                          ; =0x1
	mov	x2, #5744                       ; =0x1670
	bl	_file_hosted_add
	tbnz	w0, #0, LBB107_9
	b	LBB107_8
LBB107_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_9:
	ldur	x0, [x29, #-40]
	bl	_malloc
	stur	x0, [x29, #-120]
	ldur	x8, [x29, #-120]
	cbnz	x8, LBB107_11
	b	LBB107_10
LBB107_10:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_11:
	ldur	x0, [x29, #-120]
	ldur	x1, [x29, #-32]
	ldur	x2, [x29, #-40]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	add	x0, sp, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #248                        ; =0xf8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldur	x0, [x29, #-120]
	ldur	x1, [x29, #-40]
	bl	_nvm_v2_module_deserialize
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB107_13
	b	LBB107_12
LBB107_12:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB107_37
LBB107_13:
	add	x0, sp, #48
	add	x1, sp, #40
	bl	_nvm_v2_to_nvm_module
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB107_15
	b	LBB107_14
LBB107_14:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB107_37
LBB107_15:
	ldr	x8, [sp, #40]
	cbz	x8, LBB107_19
	b	LBB107_16
LBB107_16:
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #288]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #224]
	subs	x8, x8, x9
	b.ne	LBB107_19
	b	LBB107_17
LBB107_17:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #280]
	cbz	x8, LBB107_19
	b	LBB107_18
LBB107_18:
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #280]
	ldr	x1, [sp, #216]
	ldr	x2, [sp, #224]
	bl	_memcmp
	cbz	w0, LBB107_20
	b	LBB107_19
LBB107_19:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-108]
	b	LBB107_37
LBB107_20:
	mov	x0, #1                          ; =0x1
	mov	x1, #5744                       ; =0x1670
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB107_22
	b	LBB107_21
LBB107_21:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-108]
	b	LBB107_37
LBB107_22:
	ldr	x9, [sp, #32]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #16]
	ldur	w8, [x29, #-88]
	ldr	x9, [sp, #32]
	str	w8, [x9, #32]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #32]
	str	x8, [x9, #72]
	ldur	x8, [x29, #-104]
	ldr	x9, [sp, #32]
	str	x8, [x9, #80]
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #32]
	bl	_nvm_file_cyclic_analyze
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB107_24
	b	LBB107_23
LBB107_23:
	b	LBB107_37
LBB107_24:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w8, [x8, #16]
	subs	w8, w8, #1
	b.ne	LBB107_27
	b	LBB107_25
LBB107_25:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldrb	w8, [x8, #48]
	tbnz	w8, #0, LBB107_27
	b	LBB107_26
LBB107_26:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB107_28
	b	LBB107_27
LBB107_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-108]
	b	LBB107_37
LBB107_28:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8, #40]
	ldr	x9, [sp, #32]
	str	x8, [x9, #88]
	add	x0, sp, #16
	mov	x8, #5744                       ; =0x1670
	str	x8, [sp, #16]
	ldur	x1, [x29, #-40]
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB107_31
	b	LBB107_29
LBB107_29:
	ldr	x8, [sp, #32]
	ldr	x2, [x8, #88]
	add	x0, sp, #16
	mov	x1, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB107_31
	b	LBB107_30
LBB107_30:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-104]
	subs	x8, x8, x9
	b.ls	LBB107_32
	b	LBB107_31
LBB107_31:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-108]
	b	LBB107_37
LBB107_32:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	str	x8, [x9, #96]
	ldr	x0, [sp, #32]
	ldr	x2, [sp, #40]
	add	x1, sp, #48
	bl	_file_ch_start
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB107_34
	b	LBB107_33
LBB107_33:
	b	LBB107_37
LBB107_34:
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_file_ch_bounds
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB107_36
	b	LBB107_35
LBB107_35:
	b	LBB107_37
LBB107_36:
	ldur	x8, [x29, #-120]
	ldr	x9, [sp, #32]
	str	x8, [x9, #8]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-120]
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-48]
	str	x8, [x9]
	str	xzr, [sp, #32]
	b	LBB107_37
LBB107_37:
	ldr	x0, [sp, #32]
	bl	_nvm_file_cyclic_hosted_free
	ldr	x0, [sp, #40]
	bl	_nvm_module_free
	add	x0, sp, #48
	bl	_nvm_v2_module_free
	ldur	x0, [x29, #-120]
	bl	_free
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB107_38
LBB107_38:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_add
_file_hosted_add:                       ; @file_hosted_add
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x0, [sp, #32]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldr	x8, [sp, #24]
	cbz	x8, LBB108_3
	b	LBB108_1
LBB108_1:
	ldr	x8, [sp, #16]
	ldr	x10, [sp, #24]
	mov	x9, #-1                         ; =0xffffffffffffffff
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB108_3
	b	LBB108_2
LBB108_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB108_7
LBB108_3:
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #16]
	mul	x8, x8, x9
	str	x8, [sp, #8]
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	mov	x9, #67108864                   ; =0x4000000
	subs	x8, x8, x9
	b.hi	LBB108_5
	b	LBB108_4
LBB108_4:
	ldr	x8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x10, [x9]
	mov	x9, #67108864                   ; =0x4000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB108_6
	b	LBB108_5
LBB108_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB108_7
LBB108_6:
	ldr	x10, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	x8, [x9]
	add	x8, x8, x10
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #47]
	b	LBB108_7
LBB108_7:
	ldrb	w8, [sp, #47]
	and	w0, w8, #0x1
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_start
_file_ch_start:                         ; @file_ch_start
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #80]
	subs	w8, w8, w9
	b.ne	LBB109_5
	b	LBB109_1
LBB109_1:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB109_5
	b	LBB109_2
LBB109_2:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB109_5
	b	LBB109_3
LBB109_3:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB109_5
	b	LBB109_4
LBB109_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB109_6
	b	LBB109_5
LBB109_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB109_31
LBB109_6:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #20]
	ldur	x9, [x29, #-16]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #28]
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	cbnz	w8, LBB109_12
	b	LBB109_7
LBB109_7:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	subs	w8, w8, #1
	b.ne	LBB109_12
	b	LBB109_8
LBB109_8:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB109_12
	b	LBB109_9
LBB109_9:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.ne	LBB109_12
	b	LBB109_10
LBB109_10:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB109_13
	b	LBB109_11
LBB109_11:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #4
	b.eq	LBB109_13
	b	LBB109_12
LBB109_12:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB109_31
LBB109_13:
	str	wzr, [sp, #12]
	b	LBB109_14
LBB109_14:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB109_30
	b	LBB109_15
LBB109_15:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #256]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB109_18
	b	LBB109_16
LBB109_16:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB109_18
	b	LBB109_17
LBB109_17:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB109_19
	b	LBB109_18
LBB109_18:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB109_31
LBB109_19:                              ;   in Loop: Header=BB109_14 Depth=1
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	adds	w8, w8, #1
	b.ne	LBB109_28
	b	LBB109_20
LBB109_20:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB109_28
	b	LBB109_21
LBB109_21:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp]
	ldr	x8, [sp]
	ldrh	w8, [x8]
	cbnz	w8, LBB109_26
	b	LBB109_22
LBB109_22:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #4]
	cbnz	w8, LBB109_26
	b	LBB109_23
LBB109_23:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB109_26
	b	LBB109_24
LBB109_24:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB109_26
	b	LBB109_25
LBB109_25:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.eq	LBB109_27
	b	LBB109_26
LBB109_26:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB109_31
LBB109_27:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	str	w8, [x9, #24]
	b	LBB109_28
LBB109_28:                              ;   in Loop: Header=BB109_14 Depth=1
	b	LBB109_29
LBB109_29:                              ;   in Loop: Header=BB109_14 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB109_14
LBB109_30:
	stur	wzr, [x29, #-4]
	b	LBB109_31
LBB109_31:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_bounds
_file_ch_bounds:                        ; @file_ch_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #352
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-144]
	stur	x1, [x29, #-152]
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x8, [x8]
	stur	x8, [x29, #-160]
	sub	x0, x29, #88
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldur	x8, [x29, #-144]
	ldr	x0, [x8]
	bl	_file_cyclic_complete
	tbnz	w0, #0, LBB110_2
	b	LBB110_1
LBB110_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_2:
	stur	wzr, [x29, #-164]
	b	LBB110_3
LBB110_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB110_12 Depth 2
                                        ;       Child Loop BB110_17 Depth 3
                                        ;     Child Loop BB110_37 Depth 2
                                        ;       Child Loop BB110_39 Depth 3
	ldur	w8, [x29, #-164]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB110_65
	b	LBB110_4
LBB110_4:                               ;   in Loop: Header=BB110_3 Depth=1
	ldur	x8, [x29, #-160]
	add	x8, x8, #2608
	ldur	w9, [x29, #-164]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #168]
	ldr	w8, [sp, #168]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB110_6
	b	LBB110_5
LBB110_5:                               ;   in Loop: Header=BB110_3 Depth=1
	ldr	w8, [sp, #168]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB110_7
	b	LBB110_6
LBB110_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_7:                               ;   in Loop: Header=BB110_3 Depth=1
	ldur	x8, [x29, #-144]
	add	x10, x8, #112
	ldr	w8, [sp, #168]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #160]
	ldr	x0, [sp, #160]
	ldur	x8, [x29, #-160]
	add	x10, x8, #48
	ldr	w8, [sp, #168]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #36                         ; =0x24
	bl	_memcpy
	ldur	x8, [x29, #-152]
	ldr	x8, [x8, #72]
	ldr	w9, [sp, #168]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w8, [x8, #28]
	ldr	x9, [sp, #160]
	strh	w8, [x9, #36]
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #14]
	ldr	x9, [sp, #160]
	strh	w8, [x9, #40]
	ldr	x9, [sp, #160]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #42]
	ldr	x9, [sp, #160]
	strh	w8, [x9, #44]
	ldr	x8, [sp, #160]
	strb	wzr, [x8, #80]
	ldur	x8, [x29, #-144]
	ldr	x0, [x8]
	ldr	w1, [sp, #168]
	mov	w2, #0                          ; =0x0
	bl	_file_cyclic_site
	str	x0, [sp, #152]
	ldr	x8, [sp, #152]
	cbz	x8, LBB110_10
	b	LBB110_8
LBB110_8:                               ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #152]
	ldrb	w8, [x8]
	cbz	w8, LBB110_10
	b	LBB110_9
LBB110_9:                               ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #152]
	ldr	x8, [x8, #8]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB110_11
	b	LBB110_10
LBB110_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_11:                              ;   in Loop: Header=BB110_3 Depth=1
	strh	wzr, [sp, #150]
	b	LBB110_12
LBB110_12:                              ;   Parent Loop BB110_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB110_17 Depth 3
	ldrh	w8, [sp, #150]
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB110_33
	b	LBB110_13
LBB110_13:                              ;   in Loop: Header=BB110_12 Depth=2
	ldur	x8, [x29, #-160]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-160]
	add	x8, x8, #2352
	ldr	w9, [sp, #168]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #150]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #136]
	ldur	x8, [x29, #-144]
	ldr	x0, [x8]
	ldr	w1, [sp, #168]
	ldrh	w2, [sp, #150]
	bl	_file_cyclic_site
	str	x0, [sp, #128]
	ldr	x8, [sp, #128]
	cbz	x8, LBB110_15
	b	LBB110_14
LBB110_14:                              ;   in Loop: Header=BB110_12 Depth=2
	ldr	x8, [sp, #136]
	ldrb	w0, [x8, #8]
	bl	_file_code_supported
	tbnz	w0, #0, LBB110_16
	b	LBB110_15
LBB110_15:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_16:                              ;   in Loop: Header=BB110_12 Depth=2
	strb	wzr, [sp, #127]
	b	LBB110_17
LBB110_17:                              ;   Parent Loop BB110_3 Depth=1
                                        ;     Parent Loop BB110_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w8, [sp, #127]
	ldr	x9, [sp, #128]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB110_31
	b	LBB110_18
LBB110_18:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x8, [sp, #128]
	add	x8, x8, #8
	ldrb	w9, [sp, #127]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x8, x8, #56
	str	x8, [sp, #112]
	ldur	x8, [x29, #-144]
	ldr	x0, [x8]
	ldr	x1, [sp, #136]
	ldr	x2, [sp, #112]
	bl	_file_ch_fact
	tbz	w0, #0, LBB110_21
	b	LBB110_19
LBB110_19:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x0, [sp, #160]
	ldr	x8, [sp, #112]
	ldr	x9, [x8]
	stur	x9, [x29, #-104]
	ldrh	w8, [x8, #8]
	sturh	w8, [x29, #-96]
	ldur	x1, [x29, #-104]
	ldur	x2, [x29, #-96]
	bl	_file_ch_peak
	tbz	w0, #0, LBB110_21
	b	LBB110_20
LBB110_20:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x0, [sp, #160]
	ldr	x8, [sp, #112]
	ldur	x9, [x8, #10]
	stur	x9, [x29, #-120]
	ldrh	w8, [x8, #18]
	sturh	w8, [x29, #-112]
	ldur	x1, [x29, #-120]
	ldur	x2, [x29, #-112]
	bl	_file_ch_peak
	tbnz	w0, #0, LBB110_22
	b	LBB110_21
LBB110_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_22:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x8, [sp, #112]
	ldrb	w8, [x8, #23]
	tbz	w8, #0, LBB110_29
	b	LBB110_23
LBB110_23:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x8, [sp, #112]
	ldr	w8, [x8, #44]
	subs	w8, w8, #1
	b.ne	LBB110_29
	b	LBB110_24
LBB110_24:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	x8, [sp, #112]
	ldrh	w8, [x8, #68]
	add	w8, w8, #1
	str	w8, [sp, #108]
	ldr	w8, [sp, #108]
	subs	w8, w8, #257
	b.ls	LBB110_26
	b	LBB110_25
LBB110_25:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_26:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	w8, [sp, #108]
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #42]
	subs	w8, w8, w9
	b.ls	LBB110_28
	b	LBB110_27
LBB110_27:                              ;   in Loop: Header=BB110_17 Depth=3
	ldr	w8, [sp, #108]
	ldr	x9, [sp, #160]
	strh	w8, [x9, #42]
	b	LBB110_28
LBB110_28:                              ;   in Loop: Header=BB110_17 Depth=3
	b	LBB110_29
LBB110_29:                              ;   in Loop: Header=BB110_17 Depth=3
	b	LBB110_30
LBB110_30:                              ;   in Loop: Header=BB110_17 Depth=3
	ldrb	w8, [sp, #127]
	add	w8, w8, #1
	strb	w8, [sp, #127]
	b	LBB110_17
LBB110_31:                              ;   in Loop: Header=BB110_12 Depth=2
	b	LBB110_32
LBB110_32:                              ;   in Loop: Header=BB110_12 Depth=2
	ldrh	w8, [sp, #150]
	add	w8, w8, #1
	strh	w8, [sp, #150]
	b	LBB110_12
LBB110_33:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #36]
	cbz	w8, LBB110_36
	b	LBB110_34
LBB110_34:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #36]
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.ge	LBB110_36
	b	LBB110_35
LBB110_35:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_36:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #38]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #96]
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #160]
	str	x8, [x9, #72]
	ldr	x9, [sp, #160]
	str	x8, [x9, #64]
	strh	wzr, [sp, #94]
	b	LBB110_37
LBB110_37:                              ;   Parent Loop BB110_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB110_39 Depth 3
	ldrh	w8, [sp, #94]
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB110_59
	b	LBB110_38
LBB110_38:                              ;   in Loop: Header=BB110_37 Depth=2
	ldur	x8, [x29, #-144]
	ldr	x0, [x8]
	ldr	w1, [sp, #168]
	ldrh	w2, [sp, #94]
	bl	_file_cyclic_site
	str	x0, [sp, #80]
	strb	wzr, [sp, #79]
	b	LBB110_39
LBB110_39:                              ;   Parent Loop BB110_3 Depth=1
                                        ;     Parent Loop BB110_37 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w8, [sp, #79]
	ldr	x9, [sp, #80]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB110_57
	b	LBB110_40
LBB110_40:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #80]
	add	x8, x8, #8
	ldrb	w9, [sp, #79]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x8, x8, #76
	str	x8, [sp, #64]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #3]
	tbz	w8, #0, LBB110_42
	b	LBB110_41
LBB110_41:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #64]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB110_43
	b	LBB110_42
LBB110_42:                              ;   in Loop: Header=BB110_39 Depth=3
	b	LBB110_56
LBB110_43:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #64]
	add	x8, x8, #24
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB110_46
	b	LBB110_44
LBB110_44:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB110_46
	b	LBB110_45
LBB110_45:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #56]
	ldrh	w8, [x8, #28]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.le	LBB110_47
	b	LBB110_46
LBB110_46:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_47:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #56]
	ldrh	w8, [x8, #24]
	ldr	x9, [sp, #56]
	ldrh	w9, [x9, #28]
	subs	w8, w8, w9
	strh	w8, [sp, #54]
	ldrh	w8, [sp, #54]
	ldr	x9, [sp, #64]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.le	LBB110_49
	b	LBB110_48
LBB110_48:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_49:                              ;   in Loop: Header=BB110_39 Depth=3
	ldur	x8, [x29, #-144]
	add	x10, x8, #112
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #64]
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrh	w9, [sp, #54]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #64]
	add	x8, x8, x9
	str	x8, [sp, #32]
	ldr	x8, [sp, #96]
	ldr	x9, [sp, #40]
	ldr	x9, [x9, #72]
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #160]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ls	LBB110_51
	b	LBB110_50
LBB110_50:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #160]
	str	x8, [x9, #64]
	b	LBB110_51
LBB110_51:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #160]
	ldr	x9, [x9, #72]
	subs	x8, x8, x9
	b.ls	LBB110_53
	b	LBB110_52
LBB110_52:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #24]
	ldr	x9, [sp, #160]
	str	x8, [x9, #72]
	b	LBB110_53
LBB110_53:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldr	x9, [sp, #160]
	ldrh	w9, [x9, #44]
	subs	w8, w8, w9
	b.ls	LBB110_55
	b	LBB110_54
LBB110_54:                              ;   in Loop: Header=BB110_39 Depth=3
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldr	x9, [sp, #160]
	strh	w8, [x9, #44]
	b	LBB110_55
LBB110_55:                              ;   in Loop: Header=BB110_39 Depth=3
	b	LBB110_56
LBB110_56:                              ;   in Loop: Header=BB110_39 Depth=3
	ldrb	w8, [sp, #79]
	add	w8, w8, #1
	strb	w8, [sp, #79]
	b	LBB110_39
LBB110_57:                              ;   in Loop: Header=BB110_37 Depth=2
	b	LBB110_58
LBB110_58:                              ;   in Loop: Header=BB110_37 Depth=2
	ldrh	w8, [sp, #94]
	add	w8, w8, #1
	strh	w8, [sp, #94]
	b	LBB110_37
LBB110_59:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldr	x9, [sp, #160]
	str	w8, [x9, #52]
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldr	x9, [sp, #160]
	str	w8, [x9, #56]
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #44]
	subs	w8, w8, #64
	b.hi	LBB110_62
	b	LBB110_60
LBB110_60:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldr	x8, [x8, #64]
	mov	x9, #49216                      ; =0xc040
	subs	x8, x8, x9
	b.hi	LBB110_62
	b	LBB110_61
LBB110_61:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	x8, [sp, #160]
	ldr	x8, [x8, #72]
	mov	x9, #49216                      ; =0xc040
	subs	x8, x8, x9
	b.ls	LBB110_63
	b	LBB110_62
LBB110_62:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-132]
	b	LBB110_82
LBB110_63:                              ;   in Loop: Header=BB110_3 Depth=1
	ldr	w8, [sp, #168]
	mov	x9, x8
	sub	x8, x29, #88
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB110_64
LBB110_64:                              ;   in Loop: Header=BB110_3 Depth=1
	ldur	w8, [x29, #-164]
	add	w8, w8, #1
	stur	w8, [x29, #-164]
	b	LBB110_3
LBB110_65:
	ldur	x8, [x29, #-144]
	ldr	w8, [x8, #20]
	stur	w8, [x29, #-128]
	ldur	x8, [x29, #-144]
	ldr	w8, [x8, #24]
	stur	w8, [x29, #-124]
	str	wzr, [sp, #20]
	b	LBB110_66
LBB110_66:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #20]
	subs	w8, w8, #2
	b.hs	LBB110_81
	b	LBB110_67
LBB110_67:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	w8, [sp, #20]
	mov	x9, x8
	sub	x8, x29, #128
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB110_79
	b	LBB110_68
LBB110_68:                              ;   in Loop: Header=BB110_66 Depth=1
	ldur	x8, [x29, #-144]
	add	x10, x8, #112
	ldr	w8, [sp, #20]
	mov	x9, x8
	sub	x8, x29, #128
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-144]
	ldr	x9, [x9, #40]
	subs	x8, x8, x9
	b.ls	LBB110_70
	b	LBB110_69
LBB110_69:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-144]
	str	x8, [x9, #40]
	b	LBB110_70
LBB110_70:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-144]
	ldr	x9, [x9, #48]
	subs	x8, x8, x9
	b.ls	LBB110_72
	b	LBB110_71
LBB110_71:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-144]
	str	x8, [x9, #48]
	b	LBB110_72
LBB110_72:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-144]
	ldrh	w9, [x9, #56]
	subs	w8, w8, w9
	b.le	LBB110_74
	b	LBB110_73
LBB110_73:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-144]
	strh	w8, [x9, #56]
	b	LBB110_74
LBB110_74:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-144]
	ldr	w9, [x9, #60]
	subs	w8, w8, w9
	b.ls	LBB110_76
	b	LBB110_75
LBB110_75:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-144]
	str	w8, [x9, #60]
	b	LBB110_76
LBB110_76:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #56]
	ldur	x9, [x29, #-144]
	ldr	w9, [x9, #64]
	subs	w8, w8, w9
	b.ls	LBB110_78
	b	LBB110_77
LBB110_77:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	x8, [sp, #8]
	ldr	w8, [x8, #56]
	ldur	x9, [x29, #-144]
	str	w8, [x9, #64]
	b	LBB110_78
LBB110_78:                              ;   in Loop: Header=BB110_66 Depth=1
	b	LBB110_79
LBB110_79:                              ;   in Loop: Header=BB110_66 Depth=1
	b	LBB110_80
LBB110_80:                              ;   in Loop: Header=BB110_66 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB110_66
LBB110_81:
	stur	wzr, [x29, #-132]
	b	LBB110_82
LBB110_82:
	ldur	w8, [x29, #-132]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB110_84
	b	LBB110_83
LBB110_83:
	bl	___stack_chk_fail
LBB110_84:
	ldr	w0, [sp, #4]                    ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_query_summary ; -- Begin function nvm_file_cyclic_hosted_query_summary
	.p2align	2
_nvm_file_cyclic_hosted_query_summary:  ; @nvm_file_cyclic_hosted_query_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB111_2
	b	LBB111_1
LBB111_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldr	x1, [sp, #16]
	bl	_nvm_file_cyclic_summary
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB111_2
LBB111_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_startup ; -- Begin function nvm_file_cyclic_hosted_startup
	.p2align	2
_nvm_file_cyclic_hosted_startup:        ; @nvm_file_cyclic_hosted_startup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB112_2
	b	LBB112_1
LBB112_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB112_3
	b	LBB112_2
LBB112_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB112_4
LBB112_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x1, x8, #16
	mov	x2, #96                         ; =0x60
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB112_4
LBB112_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_function ; -- Begin function nvm_file_cyclic_hosted_function
	.p2align	2
_nvm_file_cyclic_hosted_function:       ; @nvm_file_cyclic_hosted_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB113_3
	b	LBB113_1
LBB113_1:
	ldr	x8, [sp]
	cbz	x8, LBB113_3
	b	LBB113_2
LBB113_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #28]
	subs	w8, w8, w9
	b.lo	LBB113_4
	b	LBB113_3
LBB113_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB113_5
LBB113_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	add	x10, x8, #112
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #88                         ; =0x58
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB113_5
LBB113_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_function_order ; -- Begin function nvm_file_cyclic_hosted_function_order
	.p2align	2
_nvm_file_cyclic_hosted_function_order: ; @nvm_file_cyclic_hosted_function_order
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB114_2
	b	LBB114_1
LBB114_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_code_function_order
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB114_2
LBB114_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_local   ; -- Begin function nvm_file_cyclic_hosted_local
	.p2align	2
_nvm_file_cyclic_hosted_local:          ; @nvm_file_cyclic_hosted_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB115_2
	b	LBB115_1
LBB115_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB115_2
LBB115_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_instruction ; -- Begin function nvm_file_cyclic_hosted_instruction
	.p2align	2
_nvm_file_cyclic_hosted_instruction:    ; @nvm_file_cyclic_hosted_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB116_2
	b	LBB116_1
LBB116_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_instruction
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB116_2
LBB116_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_component ; -- Begin function nvm_file_cyclic_hosted_component
	.p2align	2
_nvm_file_cyclic_hosted_component:      ; @nvm_file_cyclic_hosted_component
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB117_2
	b	LBB117_1
LBB117_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_component
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB117_2
LBB117_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_variant_count ; -- Begin function nvm_file_cyclic_hosted_variant_count
	.p2align	2
_nvm_file_cyclic_hosted_variant_count:  ; @nvm_file_cyclic_hosted_variant_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB118_2
	b	LBB118_1
LBB118_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_variant_count
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB118_2
LBB118_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_variant ; -- Begin function nvm_file_cyclic_hosted_variant
	.p2align	2
_nvm_file_cyclic_hosted_variant:        ; @nvm_file_cyclic_hosted_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	str	x4, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB119_2
	b	LBB119_1
LBB119_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldr	x4, [sp, #8]
	bl	_nvm_file_cyclic_variant
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB119_2
LBB119_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_input_local ; -- Begin function nvm_file_cyclic_hosted_input_local
	.p2align	2
_nvm_file_cyclic_hosted_input_local:    ; @nvm_file_cyclic_hosted_input_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB120_2
	b	LBB120_1
LBB120_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_local
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB120_2
LBB120_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_input_stack ; -- Begin function nvm_file_cyclic_hosted_input_stack
	.p2align	2
_nvm_file_cyclic_hosted_input_stack:    ; @nvm_file_cyclic_hosted_input_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB121_2
	b	LBB121_1
LBB121_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_stack
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB121_2
LBB121_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_input_reference ; -- Begin function nvm_file_cyclic_hosted_input_reference
	.p2align	2
_nvm_file_cyclic_hosted_input_reference: ; @nvm_file_cyclic_hosted_input_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB122_2
	b	LBB122_1
LBB122_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_reference
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB122_2
LBB122_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_input_region ; -- Begin function nvm_file_cyclic_hosted_input_region
	.p2align	2
_nvm_file_cyclic_hosted_input_region:   ; @nvm_file_cyclic_hosted_input_region
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB123_2
	b	LBB123_1
LBB123_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_region
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB123_2
LBB123_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_type    ; -- Begin function nvm_file_cyclic_hosted_type
	.p2align	2
_nvm_file_cyclic_hosted_type:           ; @nvm_file_cyclic_hosted_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB124_2
	b	LBB124_1
LBB124_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_cyclic_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB124_2
LBB124_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_import  ; -- Begin function nvm_file_cyclic_hosted_import
	.p2align	2
_nvm_file_cyclic_hosted_import:         ; @nvm_file_cyclic_hosted_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB125_2
	b	LBB125_1
LBB125_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_cyclic_import
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB125_2
LBB125_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_cyclic_hosted_bytes   ; -- Begin function nvm_file_cyclic_hosted_bytes
	.p2align	2
_nvm_file_cyclic_hosted_bytes:          ; @nvm_file_cyclic_hosted_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB126_5
	b	LBB126_1
LBB126_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB126_3
	b	LBB126_2
LBB126_2:
	ldr	x8, [sp, #16]
	cbz	x8, LBB126_5
	b	LBB126_3
LBB126_3:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #72]
	subs	x8, x8, x9
	b.hi	LBB126_5
	b	LBB126_4
LBB126_4:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	ldr	x9, [x9, #72]
	ldr	x10, [sp, #24]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB126_6
	b	LBB126_5
LBB126_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB126_9
LBB126_6:
	ldr	x8, [sp, #8]
	cbz	x8, LBB126_8
	b	LBB126_7
LBB126_7:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #24]
	add	x1, x8, x9
	ldr	x2, [sp, #8]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB126_8
LBB126_8:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB126_9
LBB126_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_targets      ; -- Begin function nvm_file_indirect_targets
	.p2align	2
_nvm_file_indirect_targets:             ; @nvm_file_indirect_targets
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-20]
	stur	w8, [x29, #-24]
	stur	wzr, [x29, #-28]
	stur	xzr, [x29, #-40]
	ldur	x8, [x29, #-16]
	cbnz	x8, LBB127_2
	b	LBB127_1
LBB127_1:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	mov	w0, #1                          ; =0x1
	bl	_fi_result
	b	LBB127_51
LBB127_2:
	ldur	x0, [x29, #-8]
	sub	x1, x29, #28
	sub	x2, x29, #40
	bl	_file_code_preflight
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB127_4
	b	LBB127_3
LBB127_3:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w0, [x29, #-44]
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	bl	_fi_result
	b	LBB127_51
LBB127_4:
	sub	x0, x29, #40
	mov	x1, #1                          ; =0x1
	mov	x2, #1064                       ; =0x428
	movk	x2, #2, lsl #16
	bl	_file_code_budget
	tbz	w0, #0, LBB127_8
	b	LBB127_5
LBB127_5:
	ldur	w8, [x29, #-28]
	mov	x1, x8
	sub	x0, x29, #40
	mov	x2, #48                         ; =0x30
	bl	_file_code_budget
	tbz	w0, #0, LBB127_8
	b	LBB127_6
LBB127_6:
	sub	x0, x29, #40
	mov	x1, #1                          ; =0x1
	mov	x2, #35088                      ; =0x8910
	movk	x2, #64, lsl #16
	bl	_file_code_budget
	tbz	w0, #0, LBB127_8
	b	LBB127_7
LBB127_7:
	ldur	x8, [x29, #-40]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB127_9
	b	LBB127_8
LBB127_8:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	mov	w0, #3                          ; =0x3
	bl	_fi_result
	b	LBB127_51
LBB127_9:
	sub	x1, x29, #56
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-56]
	ldur	x0, [x29, #-8]
	mov	w9, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	and	w2, w9, #0x1
	and	w3, w8, #0x1
	bl	_file_code_prepare_profile
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB127_11
	b	LBB127_10
LBB127_10:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w0, [x29, #-44]
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	bl	_fi_result
	b	LBB127_51
LBB127_11:
	mov	x0, #1                          ; =0x1
	mov	x1, #1064                       ; =0x428
	movk	x1, #2, lsl #16
	bl	_calloc
	str	x0, [sp, #64]
	ldr	x8, [sp, #64]
	cbnz	x8, LBB127_13
	b	LBB127_12
LBB127_12:
	ldur	x0, [x29, #-56]
	bl	_nvm_file_code_free
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	mov	w0, #4                          ; =0x4
	bl	_fi_result
	b	LBB127_51
LBB127_13:
	ldur	x8, [x29, #-56]
	ldr	x9, [sp, #64]
	str	x8, [x9]
	ldr	x9, [sp, #64]
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #24]
	str	w8, [sp, #40]
	ldur	w8, [x29, #-28]
	str	w8, [sp, #44]
	str	wzr, [sp, #48]
	str	wzr, [sp, #52]
	ldur	x8, [x29, #-40]
	str	x8, [sp, #56]
	ldur	q0, [sp, #40]
	stur	q0, [x9, #8]
	ldr	x8, [sp, #56]
	str	x8, [x9, #24]
	ldur	w8, [x29, #-28]
	mov	x0, x8
	mov	x1, #48                         ; =0x30
	bl	_calloc
	ldr	x8, [sp, #64]
	str	x0, [x8, #32]
	mov	x0, #1                          ; =0x1
	mov	x1, #35088                      ; =0x8910
	movk	x1, #64, lsl #16
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #64]
	ldr	x8, [x8, #32]
	cbz	x8, LBB127_15
	b	LBB127_14
LBB127_14:
	ldr	x8, [sp, #32]
	cbnz	x8, LBB127_16
	b	LBB127_15
LBB127_15:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-44]
	b	LBB127_50
LBB127_16:
	ldr	x8, [sp, #64]
	add	x0, x8, #40
	ldur	x8, [x29, #-56]
	mov	x9, #11056                      ; =0x2b30
	add	x1, x8, x9
	mov	x2, #512                        ; =0x200
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB127_17
LBB127_17:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB127_18 Depth 2
	strb	wzr, [sp, #31]
	stur	wzr, [x29, #-20]
	b	LBB127_18
LBB127_18:                              ;   Parent Loop BB127_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB127_23
	b	LBB127_19
LBB127_19:                              ;   in Loop: Header=BB127_18 Depth=2
	sub	x3, x29, #24
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-24]
	ldr	x0, [sp, #64]
	ldur	w1, [x29, #-20]
	ldr	x2, [sp, #32]
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	add	x5, sp, #31
	bl	_fi_function
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB127_21
	b	LBB127_20
LBB127_20:
	b	LBB127_50
LBB127_21:                              ;   in Loop: Header=BB127_18 Depth=2
	b	LBB127_22
LBB127_22:                              ;   in Loop: Header=BB127_18 Depth=2
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB127_18
LBB127_23:                              ;   in Loop: Header=BB127_17 Depth=1
	b	LBB127_24
LBB127_24:                              ;   in Loop: Header=BB127_17 Depth=1
	ldrb	w8, [sp, #31]
	tbnz	w8, #0, LBB127_17
	b	LBB127_25
LBB127_25:
	stur	wzr, [x29, #-20]
	b	LBB127_26
LBB127_26:                              ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB127_31
	b	LBB127_27
LBB127_27:                              ;   in Loop: Header=BB127_26 Depth=1
	sub	x3, x29, #24
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-24]
	ldr	x0, [sp, #64]
	ldur	w1, [x29, #-20]
	ldr	x2, [sp, #32]
	mov	w8, #1                          ; =0x1
	and	w4, w8, #0x1
	add	x5, sp, #31
	bl	_fi_function
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB127_29
	b	LBB127_28
LBB127_28:
	b	LBB127_50
LBB127_29:                              ;   in Loop: Header=BB127_26 Depth=1
	b	LBB127_30
LBB127_30:                              ;   in Loop: Header=BB127_26 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB127_26
LBB127_31:
	ldrb	w8, [sp, #31]
	tbz	w8, #0, LBB127_33
	b	LBB127_32
LBB127_32:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-44]
	b	LBB127_50
LBB127_33:
	str	wzr, [sp, #24]
	b	LBB127_34
LBB127_34:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB127_36 Depth 2
	ldr	w8, [sp, #24]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB127_43
	b	LBB127_35
LBB127_35:                              ;   in Loop: Header=BB127_34 Depth=1
	str	wzr, [sp, #20]
	b	LBB127_36
LBB127_36:                              ;   Parent Loop BB127_34 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #20]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB127_41
	b	LBB127_37
LBB127_37:                              ;   in Loop: Header=BB127_36 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #40
	ldr	w9, [sp, #20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	w9, [sp, #24]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB127_39
	b	LBB127_38
LBB127_38:                              ;   in Loop: Header=BB127_36 Depth=2
	ldr	x8, [sp, #64]
	add	x8, x8, #40
	ldr	w9, [sp, #24]
                                        ; kill: def $x9 killed $w9
	ldr	x11, [x8, x9, lsl #3]
	ldr	x8, [sp, #64]
	add	x9, x8, #40
	ldr	w8, [sp, #20]
	mov	x10, x8
	ldr	x8, [x9, x10, lsl #3]
	orr	x8, x8, x11
	str	x8, [x9, x10, lsl #3]
	b	LBB127_39
LBB127_39:                              ;   in Loop: Header=BB127_36 Depth=2
	b	LBB127_40
LBB127_40:                              ;   in Loop: Header=BB127_36 Depth=2
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB127_36
LBB127_41:                              ;   in Loop: Header=BB127_34 Depth=1
	b	LBB127_42
LBB127_42:                              ;   in Loop: Header=BB127_34 Depth=1
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB127_34
LBB127_43:
	stur	wzr, [x29, #-20]
	b	LBB127_44
LBB127_44:                              ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB127_49
	b	LBB127_45
LBB127_45:                              ;   in Loop: Header=BB127_44 Depth=1
	ldr	x8, [sp, #64]
	add	x8, x8, #40
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	w9, [x29, #-20]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB127_47
	b	LBB127_46
LBB127_46:
	mov	w8, #-1                         ; =0xffffffff
	stur	w8, [x29, #-24]
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-44]
	b	LBB127_50
LBB127_47:                              ;   in Loop: Header=BB127_44 Depth=1
	b	LBB127_48
LBB127_48:                              ;   in Loop: Header=BB127_44 Depth=1
	ldur	w8, [x29, #-20]
	add	w8, w8, #1
	stur	w8, [x29, #-20]
	b	LBB127_44
LBB127_49:
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [sp, #64]
	ldur	x10, [x29, #-16]
	str	x9, [x10]
	mov	w0, #0                          ; =0x0
	mov	w2, #-1                         ; =0xffffffff
	mov	x1, x2
	bl	_fi_result
	b	LBB127_51
LBB127_50:
	ldr	x0, [sp, #32]
	bl	_free
	ldr	x0, [sp, #64]
	bl	_nvm_file_indirect_targets_free
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldur	w0, [x29, #-44]
	ldur	w1, [x29, #-20]
	ldur	w2, [x29, #-24]
	bl	_fi_result
	b	LBB127_51
LBB127_51:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_result
_fi_result:                             ; @fi_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	w0, [sp, #44]
	str	w1, [sp, #40]
	str	w2, [sp, #36]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #32]
	adrp	x8, l_.str.4@PAGE
	add	x8, x8, l_.str.4@PAGEOFF
	str	x8, [sp, #24]
	ldr	w8, [sp, #44]
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	cbz	w8, LBB128_4
	b	LBB128_1
LBB128_1:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB128_5
	b	LBB128_2
LBB128_2:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB128_6
	b	LBB128_3
LBB128_3:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB128_7
	b	LBB128_8
LBB128_4:
	str	wzr, [sp, #32]
	adrp	x8, l_.str.5@PAGE
	add	x8, x8, l_.str.5@PAGEOFF
	str	x8, [sp, #24]
	b	LBB128_9
LBB128_5:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #32]
	adrp	x8, l_.str.6@PAGE
	add	x8, x8, l_.str.6@PAGEOFF
	str	x8, [sp, #24]
	b	LBB128_9
LBB128_6:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #32]
	adrp	x8, l_.str.7@PAGE
	add	x8, x8, l_.str.7@PAGEOFF
	str	x8, [sp, #24]
	b	LBB128_9
LBB128_7:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #32]
	adrp	x8, l_.str.8@PAGE
	add	x8, x8, l_.str.8@PAGEOFF
	str	x8, [sp, #24]
	b	LBB128_9
LBB128_8:
	b	LBB128_9
LBB128_9:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	w8, [sp, #32]
	str	w8, [x9]
	ldr	w8, [sp, #40]
	str	w8, [x9, #4]
	ldr	w8, [sp, #36]
	str	w8, [x9, #8]
	str	wzr, [x9, #12]
	ldr	x8, [sp, #24]
	str	x8, [x9, #16]
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_preflight
_file_code_preflight:                   ; @file_code_preflight
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB129_5
	b	LBB129_1
LBB129_1:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #256]
	cbz	x8, LBB129_5
	b	LBB129_2
LBB129_2:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	cbz	w8, LBB129_5
	b	LBB129_3
LBB129_3:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	cbz	x8, LBB129_5
	b	LBB129_4
LBB129_4:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	cbnz	w8, LBB129_6
	b	LBB129_5
LBB129_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #272]
	subs	w8, w8, #64
	b.hi	LBB129_8
	b	LBB129_7
LBB129_7:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB129_9
	b	LBB129_8
LBB129_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.lo	LBB129_11
	b	LBB129_10
LBB129_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_11:
	stur	wzr, [x29, #-36]
	stur	wzr, [x29, #-40]
	stur	xzr, [x29, #-48]
	stur	wzr, [x29, #-52]
	b	LBB129_12
LBB129_12:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB129_24 Depth 2
                                        ;     Child Loop BB129_31 Depth 2
	ldur	w8, [x29, #-52]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB129_40
	b	LBB129_13
LBB129_13:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #12]
	cbz	w8, LBB129_20
	b	LBB129_14
LBB129_14:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.hi	LBB129_20
	b	LBB129_15
LBB129_15:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	ldur	x10, [x29, #-64]
	ldr	w10, [x10, #8]
	subs	w9, w9, w10
	subs	w8, w8, w9
	b.hi	LBB129_20
	b	LBB129_16
LBB129_16:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.gt	LBB129_20
	b	LBB129_17
LBB129_17:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldr	w8, [x8]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB129_20
	b	LBB129_18
LBB129_18:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #20]
	subs	w8, w8, #16
	b.ge	LBB129_20
	b	LBB129_19
LBB129_19:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #21]
	subs	w8, w8, #0
	cset	w8, eq
	ldur	x9, [x29, #-64]
	ldrb	w9, [x9, #20]
	subs	w9, w9, #0
	cset	w9, eq
	subs	w8, w8, w9
	b.eq	LBB129_21
	b	LBB129_20
LBB129_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_21:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.ls	LBB129_23
	b	LBB129_22
LBB129_22:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_23:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8, #16]
	mov	x9, x8
	ldur	x8, [x29, #-48]
	add	x8, x8, x9
	stur	x8, [x29, #-48]
	stur	wzr, [x29, #-68]
	b	LBB129_24
LBB129_24:                              ;   Parent Loop BB129_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-68]
	ldur	w9, [x29, #-52]
	subs	w8, w8, w9
	b.hs	LBB129_30
	b	LBB129_25
LBB129_25:                              ;   in Loop: Header=BB129_24 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldur	w8, [x29, #-68]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-80]
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-80]
	ldr	w9, [x9, #8]
	ldur	x10, [x29, #-80]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB129_28
	b	LBB129_26
LBB129_26:                              ;   in Loop: Header=BB129_24 Depth=2
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #8]
	ldur	x10, [x29, #-64]
	ldr	w10, [x10, #12]
	add	w9, w9, w10
	subs	w8, w8, w9
	b.hs	LBB129_28
	b	LBB129_27
LBB129_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_28:                              ;   in Loop: Header=BB129_24 Depth=2
	b	LBB129_29
LBB129_29:                              ;   in Loop: Header=BB129_24 Depth=2
	ldur	w8, [x29, #-68]
	add	w8, w8, #1
	stur	w8, [x29, #-68]
	b	LBB129_24
LBB129_30:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	x8, [x29, #-64]
	ldr	w9, [x8, #12]
	ldur	w8, [x29, #-40]
	add	w8, w8, w9
	stur	w8, [x29, #-40]
	stur	wzr, [x29, #-84]
	stur	wzr, [x29, #-88]
	b	LBB129_31
LBB129_31:                              ;   Parent Loop BB129_12 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	w8, [x29, #-84]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB129_38
	b	LBB129_32
LBB129_32:                              ;   in Loop: Header=BB129_31 Depth=2
	add	x0, sp, #40
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #280]
	ldur	x9, [x29, #-64]
	ldr	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	w9, [x29, #-84]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-84]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	bl	_isa_decode
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	cbnz	w8, LBB129_34
	b	LBB129_33
LBB129_33:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_34:                              ;   in Loop: Header=BB129_31 Depth=2
	ldur	w8, [x29, #-88]
	add	w8, w8, #1
	stur	w8, [x29, #-88]
	subs	w8, w8, #256
	b.hi	LBB129_36
	b	LBB129_35
LBB129_35:                              ;   in Loop: Header=BB129_31 Depth=2
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.ls	LBB129_37
	b	LBB129_36
LBB129_36:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_37:                              ;   in Loop: Header=BB129_31 Depth=2
	ldr	w9, [sp, #36]
	ldur	w8, [x29, #-84]
	add	w8, w8, w9
	stur	w8, [x29, #-84]
	b	LBB129_31
LBB129_38:                              ;   in Loop: Header=BB129_12 Depth=1
	b	LBB129_39
LBB129_39:                              ;   in Loop: Header=BB129_12 Depth=1
	ldur	w8, [x29, #-52]
	add	w8, w8, #1
	stur	w8, [x29, #-52]
	b	LBB129_12
LBB129_40:
	ldur	w8, [x29, #-40]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #288]
	subs	w8, w8, w9
	b.eq	LBB129_42
	b	LBB129_41
LBB129_41:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_42:
	str	xzr, [sp, #24]
	add	x1, sp, #16
	str	xzr, [sp, #16]
	mov	w0, #65536                      ; =0x10000
	bl	_nvm_file_nominal_storage_bound
	tbz	w0, #0, LBB129_51
	b	LBB129_43
LBB129_43:
	add	x0, sp, #24
	mov	x1, #1                          ; =0x1
	mov	x2, #1816                       ; =0x718
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_44
LBB129_44:
	ldur	x1, [x29, #-48]
	add	x0, sp, #24
	mov	x2, #16                         ; =0x10
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_45
LBB129_45:
	ldr	x2, [sp, #16]
	add	x0, sp, #24
	mov	x1, #1                          ; =0x1
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_46
LBB129_46:
	add	x0, sp, #24
	mov	x1, #1                          ; =0x1
	mov	x2, #11568                      ; =0x2d30
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_47
LBB129_47:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #288]
	mov	x1, x8
	add	x0, sp, #24
	mov	x2, #1                          ; =0x1
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_48
LBB129_48:
	ldur	w8, [x29, #-36]
	mov	x1, x8
	add	x0, sp, #24
	mov	x2, #600                        ; =0x258
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_49
LBB129_49:
	add	x0, sp, #24
	mov	x1, #256                        ; =0x100
	mov	x2, #3                          ; =0x3
	bl	_file_code_budget
	tbz	w0, #0, LBB129_51
	b	LBB129_50
LBB129_50:
	add	x0, sp, #24
	mov	x1, #1                          ; =0x1
	mov	x2, #64                         ; =0x40
	bl	_file_code_budget
	tbnz	w0, #0, LBB129_52
	b	LBB129_51
LBB129_51:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB129_53
LBB129_52:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	str	w8, [x9]
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB129_53
LBB129_53:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_prepare_profile
_file_code_prepare_profile:             ; @file_code_prepare_profile
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #24
	str	x8, [sp]                        ; 8-byte Folded Spill
	str	x0, [x8, #8]
	str	x1, [x8]
	sturb	w2, [x29, #-25]
	sturb	w3, [x29, #-26]
	ldr	x8, [x8]
	cbnz	x8, LBB130_2
	b	LBB130_1
LBB130_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_2:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	sub	x1, x29, #32
	sub	x2, x29, #40
	bl	_file_code_preflight
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB130_4
	b	LBB130_3
LBB130_3:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_4:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	sub	x1, x29, #56
                                        ; kill: def $x9 killed $xzr
	stur	xzr, [x29, #-56]
	ldr	x0, [x8, #8]
	ldurb	w8, [x29, #-26]
	and	w2, w8, #0x1
	bl	_file_flow_declarations_mode
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB130_6
	b	LBB130_5
LBB130_5:
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_6:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x10, [x29, #-56]
	mov	x9, #24                         ; =0x18
	add	x10, x10, #24
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #12]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #5
	b.eq	LBB130_9
	b	LBB130_7
LBB130_7:
	ldur	x8, [x29, #-64]
	ldrb	w0, [x8, #8]
	bl	_scalar
	tbz	w0, #0, LBB130_9
	b	LBB130_8
LBB130_8:
	ldur	x8, [x29, #-64]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.eq	LBB130_10
	b	LBB130_9
LBB130_9:
	ldur	x0, [x29, #-56]
	bl	_nvm_file_flow_declarations_free
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_10:
	sturh	wzr, [x29, #-66]
	b	LBB130_11
LBB130_11:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-66]
	ldur	x9, [x29, #-64]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB130_18
	b	LBB130_12
LBB130_12:                              ;   in Loop: Header=BB130_11 Depth=1
	ldr	x10, [sp]                       ; 8-byte Folded Reload
	ldur	x8, [x29, #-56]
	add	x8, x8, #1816
	ldur	x9, [x29, #-56]
	add	x9, x9, #1560
	ldr	x10, [x10, #8]
	ldr	w10, [x10, #12]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-66]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	str	q0, [sp, #80]
	ldrb	w8, [sp, #81]
	cbnz	w8, LBB130_15
	b	LBB130_13
LBB130_13:                              ;   in Loop: Header=BB130_11 Depth=1
	ldrb	w0, [sp, #80]
	bl	_scalar
	tbz	w0, #0, LBB130_15
	b	LBB130_14
LBB130_14:                              ;   in Loop: Header=BB130_11 Depth=1
	ldr	w8, [sp, #84]
	adds	w8, w8, #1
	b.eq	LBB130_16
	b	LBB130_15
LBB130_15:
	ldur	x0, [x29, #-56]
	bl	_nvm_file_flow_declarations_free
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_16:                              ;   in Loop: Header=BB130_11 Depth=1
	b	LBB130_17
LBB130_17:                              ;   in Loop: Header=BB130_11 Depth=1
	ldurh	w8, [x29, #-66]
	add	w8, w8, #1
	sturh	w8, [x29, #-66]
	b	LBB130_11
LBB130_18:
	mov	x0, #1                          ; =0x1
	mov	x1, #11568                      ; =0x2d30
	bl	_calloc
	str	x0, [sp, #72]
	ldr	x8, [sp, #72]
	cbnz	x8, LBB130_20
	b	LBB130_19
LBB130_19:
	ldur	x0, [x29, #-56]
	bl	_nvm_file_flow_declarations_free
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_20:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldur	x9, [x29, #-56]
	ldr	x10, [sp, #72]
	str	x9, [x10]
	ldr	x9, [x8, #8]
	ldr	w9, [x9, #272]
	ldr	x10, [sp, #72]
	str	w9, [x10, #24]
	ldr	x9, [x8, #8]
	ldr	w9, [x9, #288]
	ldr	x10, [sp, #72]
	str	w9, [x10, #28]
	ldur	w9, [x29, #-32]
	ldr	x10, [sp, #72]
	str	w9, [x10, #32]
	ldur	x9, [x29, #-40]
	ldr	x10, [sp, #72]
	str	x9, [x10, #40]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #288]
	mov	x0, x8
	bl	_malloc
	ldr	x8, [sp, #72]
	str	x0, [x8, #8]
	ldur	w8, [x29, #-32]
	mov	x0, x8
	mov	x1, #600                        ; =0x258
	bl	_calloc
	ldr	x8, [sp, #72]
	str	x0, [x8, #16]
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #8]
	cbz	x8, LBB130_22
	b	LBB130_21
LBB130_21:
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB130_23
	b	LBB130_22
LBB130_22:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-44]
	b	LBB130_50
LBB130_23:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #72]
	ldr	x0, [x9, #8]
	ldr	x9, [x8, #8]
	ldr	x1, [x9, #280]
	ldr	x8, [x8, #8]
	ldr	w8, [x8, #288]
	mov	x2, x8
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	str	wzr, [sp, #68]
	str	wzr, [sp, #64]
	b	LBB130_24
LBB130_24:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB130_26 Depth 2
	ldr	w8, [sp, #64]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB130_36
	b	LBB130_25
LBB130_25:                              ;   in Loop: Header=BB130_24 Depth=1
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	x9, [sp, #72]
	add	x11, x9, #48
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	x9, [sp, #56]
	ldr	x9, [x8, #8]
	ldr	x12, [x9, #256]
	ldr	w9, [sp, #64]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
	mov	x11, x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w11, x12
	ldr	w9, [x9, #8]
	ldr	x11, [sp, #56]
	str	w9, [x11]
	ldr	x8, [x8, #8]
	ldr	x11, [x8, #256]
	ldr	w8, [sp, #64]
                                        ; kill: def $x8 killed $w8
	mov	x9, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldr	w8, [x8, #12]
	ldr	x9, [sp, #56]
	str	w8, [x9, #4]
	ldr	x9, [sp, #56]
	ldur	x8, [x29, #-56]
	add	x11, x8, #24
	ldr	w8, [sp, #64]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	q0, [x8]
	stur	q0, [x9, #12]
	ldr	x8, [x8, #16]
	stur	x8, [x9, #28]
	ldr	w8, [sp, #68]
	ldr	x9, [sp, #72]
	add	x9, x9, #2352
	ldr	w10, [sp, #64]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	str	wzr, [sp, #52]
	b	LBB130_26
LBB130_26:                              ;   Parent Loop BB130_24 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #52]
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.hs	LBB130_32
	b	LBB130_27
LBB130_27:                              ;   in Loop: Header=BB130_26 Depth=2
	ldr	x8, [sp, #72]
	ldr	x10, [x8, #16]
	ldr	w8, [sp, #68]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	add	w9, w9, #1
	str	w9, [sp, #68]
	mov	x9, #600                        ; =0x258
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	w8, [sp, #52]
	ldr	x9, [sp, #40]
	str	w8, [x9]
	ldr	x9, [sp, #40]
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x9, #592]
	ldr	x9, [sp, #40]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, #74]
	ldr	x9, [sp, #40]
	strh	w8, [x9, #72]
	ldr	x8, [sp, #72]
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #56]
	ldr	w9, [x9]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	ldr	x8, [sp, #56]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #52]
	subs	w8, w8, w9
	mov	w8, w8
	mov	x1, x8
	ldr	x8, [sp, #40]
	add	x2, x8, #8
	bl	_isa_decode
	str	w0, [sp, #36]
	ldr	w8, [sp, #36]
	cbnz	w8, LBB130_29
	b	LBB130_28
LBB130_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-44]
	b	LBB130_50
LBB130_29:                              ;   in Loop: Header=BB130_26 Depth=2
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x0, [sp, #72]
	ldr	w1, [sp, #64]
	ldr	x2, [sp, #40]
	ldurb	w8, [x29, #-26]
	ldr	x4, [x9, #8]
	and	w3, w8, #0x1
	bl	_file_code_operands
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB130_31
	b	LBB130_30
LBB130_30:
	b	LBB130_50
LBB130_31:                              ;   in Loop: Header=BB130_26 Depth=2
	ldr	w9, [sp, #36]
	ldr	w8, [sp, #52]
	add	w8, w8, w9
	str	w8, [sp, #52]
	ldr	x9, [sp, #56]
	ldrh	w8, [x9, #8]
	add	w8, w8, #1
	strh	w8, [x9, #8]
	b	LBB130_26
LBB130_32:                              ;   in Loop: Header=BB130_24 Depth=1
	ldr	x0, [sp, #72]
	ldr	w1, [sp, #64]
	ldurb	w8, [x29, #-25]
	and	w2, w8, #0x1
	bl	_file_code_cfg
	stur	w0, [x29, #-44]
	ldur	w8, [x29, #-44]
	cbz	w8, LBB130_34
	b	LBB130_33
LBB130_33:
	b	LBB130_50
LBB130_34:                              ;   in Loop: Header=BB130_24 Depth=1
	b	LBB130_35
LBB130_35:                              ;   in Loop: Header=BB130_24 Depth=1
	ldr	w8, [sp, #64]
	add	w8, w8, #1
	str	w8, [sp, #64]
	b	LBB130_24
LBB130_36:
	str	xzr, [sp, #24]
	str	wzr, [sp, #20]
	b	LBB130_37
LBB130_37:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB130_39 Depth 2
	ldr	w8, [sp, #20]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB130_49
	b	LBB130_38
LBB130_38:                              ;   in Loop: Header=BB130_37 Depth=1
	ldr	x8, [sp, #72]
	ldr	w8, [x8, #24]
	str	w8, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB130_39
LBB130_39:                              ;   Parent Loop BB130_37 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB130_45
	b	LBB130_40
LBB130_40:                              ;   in Loop: Header=BB130_39 Depth=2
	ldr	x8, [sp, #24]
	ldr	w9, [sp, #12]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbnz	x8, LBB130_43
	b	LBB130_41
LBB130_41:                              ;   in Loop: Header=BB130_39 Depth=2
	ldr	x8, [sp, #72]
	mov	x9, #11056                      ; =0x2b30
	add	x8, x8, x9
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #24]
	bic	x8, x8, x9
	cbnz	x8, LBB130_43
	b	LBB130_42
LBB130_42:                              ;   in Loop: Header=BB130_37 Depth=1
	ldr	w8, [sp, #12]
	str	w8, [sp, #16]
	b	LBB130_45
LBB130_43:                              ;   in Loop: Header=BB130_39 Depth=2
	b	LBB130_44
LBB130_44:                              ;   in Loop: Header=BB130_39 Depth=2
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB130_39
LBB130_45:                              ;   in Loop: Header=BB130_37 Depth=1
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #72]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB130_47
	b	LBB130_46
LBB130_46:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-44]
	b	LBB130_50
LBB130_47:                              ;   in Loop: Header=BB130_37 Depth=1
	ldr	w8, [sp, #16]
	ldr	x9, [sp, #72]
	add	x9, x9, #2608
	ldr	w10, [sp, #20]
                                        ; kill: def $x10 killed $w10
	str	w8, [x9, x10, lsl #2]
	ldr	w8, [sp, #16]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x9, x8, x9
	ldr	x8, [sp, #24]
	orr	x8, x8, x9
	str	x8, [sp, #24]
	b	LBB130_48
LBB130_48:                              ;   in Loop: Header=BB130_37 Depth=1
	ldr	w8, [sp, #20]
	add	w8, w8, #1
	str	w8, [sp, #20]
	b	LBB130_37
LBB130_49:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #72]
	ldr	x9, [x9]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB130_51
LBB130_50:
	ldr	x0, [sp, #72]
	bl	_nvm_file_code_free
	ldur	w8, [x29, #-44]
	stur	w8, [x29, #-4]
	b	LBB130_51
LBB130_51:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_function
_fi_function:                           ; @fi_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	sturb	w4, [x29, #-57]
	stur	x5, [x29, #-72]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	stur	x8, [x29, #-80]
	ldur	x10, [x29, #-80]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-88]
	ldur	x0, [x29, #-48]
	mov	w1, #0                          ; =0x0
	mov	x2, #35088                      ; =0x8910
	movk	x2, #64, lsl #16
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldur	x9, [x29, #-48]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x9, [x29, #-48]
	mov	x10, #34832                     ; =0x8810
	movk	x10, #64, lsl #16
	add	x9, x9, x10
	strb	w8, [x9]
	sturh	wzr, [x29, #-90]
	b	LBB131_1
LBB131_1:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-90]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ge	LBB131_7
	b	LBB131_2
LBB131_2:                               ;   in Loop: Header=BB131_1 Depth=1
	ldur	x8, [x29, #-80]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x9, [x29, #-80]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-90]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #4
	ldurh	w10, [x29, #-90]
	ldur	x9, [x29, #-88]
	ldrh	w11, [x9, #12]
	mov	w9, #2                          ; =0x2
	subs	w10, w10, w11
	csinc	w2, w9, wzr, lt
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	sub	x8, x29, #128
	bl	_fi_value
	ldurh	w8, [x29, #-90]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ge	LBB131_5
	b	LBB131_3
LBB131_3:                               ;   in Loop: Header=BB131_1 Depth=1
	ldurb	w8, [x29, #-128]
	subs	w8, w8, #11
	b.ne	LBB131_5
	b	LBB131_4
LBB131_4:                               ;   in Loop: Header=BB131_1 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #552
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #11
	ldurh	w9, [x29, #-90]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	stur	x8, [x29, #-112]
	b	LBB131_5
LBB131_5:                               ;   in Loop: Header=BB131_1 Depth=1
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-90]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldur	q0, [x29, #-128]
	str	q0, [x8]
	ldur	q0, [x29, #-112]
	str	q0, [x8, #16]
	b	LBB131_6
LBB131_6:                               ;   in Loop: Header=BB131_1 Depth=1
	ldurh	w8, [x29, #-90]
	add	w8, w8, #1
	sturh	w8, [x29, #-90]
	b	LBB131_1
LBB131_7:
	b	LBB131_8
LBB131_8:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB131_9 Depth 2
                                        ;     Child Loop BB131_28 Depth 2
	sturh	wzr, [x29, #-130]
	b	LBB131_9
LBB131_9:                               ;   Parent Loop BB131_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w9, [x29, #-130]
	ldur	x8, [x29, #-88]
	ldrh	w10, [x8, #8]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ge	LBB131_11
	b	LBB131_10
LBB131_10:                              ;   in Loop: Header=BB131_9 Depth=2
	ldur	x8, [x29, #-48]
	mov	x9, #34832                      ; =0x8810
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldurh	w9, [x29, #-130]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	eor	w8, w8, #0x1
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB131_11
LBB131_11:                              ;   in Loop: Header=BB131_9 Depth=2
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	tbz	w8, #0, LBB131_13
	b	LBB131_12
LBB131_12:                              ;   in Loop: Header=BB131_9 Depth=2
	ldurh	w8, [x29, #-130]
	add	w8, w8, #1
	sturh	w8, [x29, #-130]
	b	LBB131_9
LBB131_13:                              ;   in Loop: Header=BB131_8 Depth=1
	ldurh	w8, [x29, #-130]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB131_15
	b	LBB131_14
LBB131_14:
	b	LBB131_38
LBB131_15:                              ;   in Loop: Header=BB131_8 Depth=1
	ldur	x8, [x29, #-80]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-80]
	add	x8, x8, #2352
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-130]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #144]
	ldr	x8, [sp, #144]
	ldr	w8, [x8]
	ldur	x9, [x29, #-56]
	str	w8, [x9]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #20]
	subs	w8, w8, #64, lsl #12            ; =262144
	b.ne	LBB131_17
	b	LBB131_16
LBB131_16:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB131_51
LBB131_17:                              ;   in Loop: Header=BB131_8 Depth=1
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #20]
	add	w8, w8, #1
	str	w8, [x9, #20]
	ldur	x8, [x29, #-48]
	mov	x9, #34832                      ; =0x8810
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldurh	w9, [x29, #-130]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	strb	wzr, [x8]
	ldur	x8, [x29, #-48]
	mov	x9, #2048                       ; =0x800
	movk	x9, #64, lsl #16
	add	x0, x8, x9
	ldur	x10, [x29, #-48]
	ldurh	w8, [x29, #-130]
                                        ; kill: def $x8 killed $w8
	mov	x9, #16392                      ; =0x4008
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #16392                      ; =0x4008
	bl	_memcpy
	ldurb	w8, [x29, #-57]
	tbnz	w8, #0, LBB131_25
	b	LBB131_18
LBB131_18:                              ;   in Loop: Header=BB131_8 Depth=1
	ldr	x8, [sp, #144]
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	tbz	w0, #0, LBB131_25
	b	LBB131_19
LBB131_19:                              ;   in Loop: Header=BB131_8 Depth=1
	ldur	x8, [x29, #-48]
	mov	x9, #2048                       ; =0x800
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldrh	w8, [x8, #2]
	cbz	w8, LBB131_25
	b	LBB131_20
LBB131_20:                              ;   in Loop: Header=BB131_8 Depth=1
	ldur	x8, [x29, #-48]
	mov	x10, #2048                      ; =0x800
	movk	x10, #64, lsl #16
	mov	x9, #10248                      ; =0x2808
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	add	x9, x9, x10
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #136]
	ldr	x8, [sp, #136]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #2
	b.ne	LBB131_24
	b	LBB131_21
LBB131_21:                              ;   in Loop: Header=BB131_8 Depth=1
	ldr	x8, [sp, #136]
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #120]
	str	x1, [sp, #128]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	ldr	x2, [sp, #120]
	ldr	x3, [sp, #128]
	bl	_same
	tbz	w0, #0, LBB131_24
	b	LBB131_22
LBB131_22:                              ;   in Loop: Header=BB131_8 Depth=1
	ldr	x8, [sp, #136]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB131_24
	b	LBB131_23
LBB131_23:                              ;   in Loop: Header=BB131_8 Depth=1
	b	LBB131_8
LBB131_24:                              ;   in Loop: Header=BB131_8 Depth=1
	b	LBB131_25
LBB131_25:                              ;   in Loop: Header=BB131_8 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-36]
	ldur	x8, [x29, #-48]
	mov	x9, #2048                       ; =0x800
	movk	x9, #64, lsl #16
	add	x2, x8, x9
	ldr	x3, [sp, #144]
	ldur	x4, [x29, #-72]
	bl	_fi_transfer
	str	w0, [sp, #116]
	ldr	w8, [sp, #116]
	cbz	w8, LBB131_27
	b	LBB131_26
LBB131_26:
	ldr	w8, [sp, #116]
	stur	w8, [x29, #-20]
	b	LBB131_51
LBB131_27:                              ;   in Loop: Header=BB131_8 Depth=1
	strb	wzr, [sp, #115]
	b	LBB131_28
LBB131_28:                              ;   Parent Loop BB131_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #115]
	ldr	x9, [sp, #144]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB131_37
	b	LBB131_29
LBB131_29:                              ;   in Loop: Header=BB131_28 Depth=2
	ldur	x8, [x29, #-48]
	mov	x9, #18440                      ; =0x4808
	movk	x9, #64, lsl #16
	add	x0, x8, x9
	ldur	x8, [x29, #-48]
	mov	x9, #2048                       ; =0x800
	movk	x9, #64, lsl #16
	add	x1, x8, x9
	mov	x2, #16392                      ; =0x4008
	bl	_memcpy
	ldr	x8, [sp, #144]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #146
	b.ne	LBB131_33
	b	LBB131_30
LBB131_30:                              ;   in Loop: Header=BB131_28 Depth=2
	ldur	x8, [x29, #-48]
	mov	x9, #18448                      ; =0x4810
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldr	x9, [sp, #144]
	ldrh	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #104]
	ldrb	w9, [sp, #115]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	and	w10, w8, #0xff
	ldr	x9, [sp, #104]
	ldrb	w8, [x9, #25]
	and	w8, w8, w10
	strb	w8, [x9, #25]
	ldr	x8, [sp, #104]
	ldrb	w8, [x8, #25]
	cbnz	w8, LBB131_32
	b	LBB131_31
LBB131_31:                              ;   in Loop: Header=BB131_28 Depth=2
	b	LBB131_36
LBB131_32:                              ;   in Loop: Header=BB131_28 Depth=2
	b	LBB131_33
LBB131_33:                              ;   in Loop: Header=BB131_28 Depth=2
	add	x3, sp, #103
	strb	wzr, [sp, #103]
	ldr	x8, [sp, #144]
	add	x8, x8, #72
	ldrb	w9, [sp, #115]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	strh	w8, [sp, #100]
	ldur	x10, [x29, #-48]
	ldrh	w8, [sp, #100]
                                        ; kill: def $x8 killed $w8
	mov	x9, #16392                      ; =0x4008
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	ldur	x8, [x29, #-48]
	mov	x9, #18440                      ; =0x4808
	movk	x9, #64, lsl #16
	add	x1, x8, x9
	ldur	x8, [x29, #-88]
	ldrh	w2, [x8, #14]
	bl	_fi_join
	str	w0, [sp, #116]
	ldr	w8, [sp, #116]
	cbz	w8, LBB131_35
	b	LBB131_34
LBB131_34:
	ldr	w8, [sp, #116]
	stur	w8, [x29, #-20]
	b	LBB131_51
LBB131_35:                              ;   in Loop: Header=BB131_28 Depth=2
	ldrb	w8, [sp, #103]
	and	w10, w8, #0x1
	ldur	x8, [x29, #-48]
	mov	x9, #34832                      ; =0x8810
	movk	x9, #64, lsl #16
	add	x8, x8, x9
	ldrh	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	ldrb	w8, [x9]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9]
	b	LBB131_36
LBB131_36:                              ;   in Loop: Header=BB131_28 Depth=2
	ldrb	w8, [sp, #115]
	add	w8, w8, #1
	strb	w8, [sp, #115]
	b	LBB131_28
LBB131_37:                              ;   in Loop: Header=BB131_8 Depth=1
	b	LBB131_8
LBB131_38:
	ldurb	w8, [x29, #-57]
	tbnz	w8, #0, LBB131_40
	b	LBB131_39
LBB131_39:
	stur	wzr, [x29, #-20]
	b	LBB131_51
LBB131_40:
	strh	wzr, [sp, #98]
	b	LBB131_41
LBB131_41:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #98]
	ldur	x9, [x29, #-88]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB131_50
	b	LBB131_42
LBB131_42:                              ;   in Loop: Header=BB131_41 Depth=1
	ldur	x8, [x29, #-80]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-80]
	add	x8, x8, #2352
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #98]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #88]
	ldr	x8, [sp, #88]
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	tbnz	w0, #0, LBB131_44
	b	LBB131_43
LBB131_43:                              ;   in Loop: Header=BB131_41 Depth=1
	b	LBB131_49
LBB131_44:                              ;   in Loop: Header=BB131_41 Depth=1
	ldr	x8, [sp, #88]
	ldr	w8, [x8]
	ldur	x9, [x29, #-56]
	str	w8, [x9]
	ldur	x10, [x29, #-48]
	ldrh	w8, [sp, #98]
                                        ; kill: def $x8 killed $w8
	mov	x9, #16392                      ; =0x4008
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB131_46
	b	LBB131_45
LBB131_45:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB131_51
LBB131_46:                              ;   in Loop: Header=BB131_41 Depth=1
	ldur	x0, [x29, #-80]
	ldur	x10, [x29, #-48]
	ldrh	w8, [sp, #98]
                                        ; kill: def $x8 killed $w8
	mov	x9, #16392                      ; =0x4008
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	ldr	x2, [sp, #88]
	add	x3, sp, #80
	add	x4, sp, #76
	bl	_fi_candidates
	str	w0, [sp, #72]
	ldr	w8, [sp, #72]
	cbz	w8, LBB131_48
	b	LBB131_47
LBB131_47:
	ldr	w8, [sp, #72]
	stur	w8, [x29, #-20]
	b	LBB131_51
LBB131_48:                              ;   in Loop: Header=BB131_41 Depth=1
	ldur	x8, [x29, #-80]
	mov	x9, #48                         ; =0x30
	add	x11, x8, #48
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	add	x8, x8, #12
	str	x8, [sp, #64]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #32]
	ldur	x12, [x29, #-32]
	ldr	w8, [x12, #16]
                                        ; kill: def $x8 killed $w8
	mov	x11, x8
	add	w11, w11, #1
	str	w11, [x12, #16]
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	ldur	w8, [x29, #-36]
	add	x1, sp, #16
	str	w8, [sp, #16]
	ldr	x8, [sp, #88]
	ldr	w8, [x8]
	str	w8, [sp, #20]
	ldrh	w8, [sp, #98]
	strh	w8, [sp, #24]
	ldr	x8, [sp, #64]
	ldrh	w8, [x8]
	strh	w8, [sp, #26]
	str	wzr, [sp, #28]
	ldr	x8, [sp, #80]
	str	x8, [sp, #32]
	ldr	x8, [sp, #64]
	ldrb	w8, [x8, #4]
	strb	w8, [sp, #40]
	add	x8, x1, #25
	strh	wzr, [x8]
	strb	wzr, [sp, #43]
	ldr	x8, [sp, #64]
	ldur	q0, [x8, #8]
	stur	q0, [x1, #28]
	str	wzr, [sp, #60]
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	x11, [sp, #80]
	ldur	x8, [x29, #-32]
	add	x9, x8, #40
	ldur	w8, [x29, #-36]
	mov	x10, x8
	ldr	x8, [x9, x10, lsl #3]
	orr	x8, x8, x11
	str	x8, [x9, x10, lsl #3]
	b	LBB131_49
LBB131_49:                              ;   in Loop: Header=BB131_41 Depth=1
	ldrh	w8, [sp, #98]
	add	w8, w8, #1
	strh	w8, [sp, #98]
	b	LBB131_41
LBB131_50:
	stur	wzr, [x29, #-20]
	b	LBB131_51
LBB131_51:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_targets_free ; -- Begin function nvm_file_indirect_targets_free
	.p2align	2
_nvm_file_indirect_targets_free:        ; @nvm_file_indirect_targets_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB132_2
	b	LBB132_1
LBB132_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_code_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #32]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB132_2
LBB132_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_targets_summary ; -- Begin function nvm_file_indirect_targets_summary
	.p2align	2
_nvm_file_indirect_targets_summary:     ; @nvm_file_indirect_targets_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB133_2
	b	LBB133_1
LBB133_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB133_3
	b	LBB133_2
LBB133_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB133_4
LBB133_3:
	ldr	x9, [sp, #8]
	ldr	x8, [sp, #16]
	ldur	q0, [x8, #8]
	str	q0, [x9]
	ldr	x8, [x8, #24]
	str	x8, [x9, #16]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #31]
	b	LBB133_4
LBB133_4:
	ldrb	w8, [sp, #31]
	and	w0, w8, #0x1
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_targets_call ; -- Begin function nvm_file_indirect_targets_call
	.p2align	2
_nvm_file_indirect_targets_call:        ; @nvm_file_indirect_targets_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB134_3
	b	LBB134_1
LBB134_1:
	ldr	x8, [sp]
	cbz	x8, LBB134_3
	b	LBB134_2
LBB134_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.lo	LBB134_4
	b	LBB134_3
LBB134_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB134_5
LBB134_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	ldr	x10, [x8, #32]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB134_5
LBB134_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_targets_parameter ; -- Begin function nvm_file_indirect_targets_parameter
	.p2align	2
_nvm_file_indirect_targets_parameter:   ; @nvm_file_indirect_targets_parameter
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	sturh	w2, [x29, #-22]
	str	x3, [sp, #16]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB135_4
	b	LBB135_1
LBB135_1:
	ldr	x8, [sp, #16]
	cbz	x8, LBB135_4
	b	LBB135_2
LBB135_2:
	ldur	w8, [x29, #-20]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB135_4
	b	LBB135_3
LBB135_3:
	ldurh	w8, [x29, #-22]
	ldur	x9, [x29, #-16]
	ldr	x11, [x9, #32]
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	mov	x10, #48                        ; =0x30
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #10]
	subs	w8, w8, w9
	b.lt	LBB135_5
	b	LBB135_4
LBB135_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB135_11
LBB135_5:
	str	wzr, [sp, #12]
	b	LBB135_6
LBB135_6:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [sp, #12]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	w10, [x8, #24]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.hs	LBB135_8
	b	LBB135_7
LBB135_7:                               ;   in Loop: Header=BB135_6 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #32]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #12]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	ands	x8, x8, x9
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB135_8
LBB135_8:                               ;   in Loop: Header=BB135_6 Depth=1
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	tbz	w8, #0, LBB135_10
	b	LBB135_9
LBB135_9:                               ;   in Loop: Header=BB135_6 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB135_6
LBB135_10:
	ldur	x8, [x29, #-16]
	ldr	x0, [x8]
	ldr	w1, [sp, #12]
	ldurh	w2, [x29, #-22]
	ldr	x3, [sp, #16]
	bl	_nvm_file_code_local
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB135_11
LBB135_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_analyze ; -- Begin function nvm_file_indirect_flow_analyze
	.p2align	2
_nvm_file_indirect_flow_analyze:        ; @nvm_file_indirect_flow_analyze
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-24]
	cbnz	x8, LBB136_2
	b	LBB136_1
LBB136_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_2:
	sub	x1, x29, #32
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-32]
	ldur	x0, [x29, #-16]
	sub	x8, x29, #64
	bl	_nvm_file_indirect_targets
	ldur	w0, [x29, #-64]
	bl	_fif_target_status
	stur	w0, [x29, #-36]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB136_4
	b	LBB136_3
LBB136_3:
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_4:
	mov	x8, #4992                       ; =0x1380
	movk	x8, #4, lsl #16
	stur	x8, [x29, #-72]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-72]
	sub	x2, x29, #92
	sub	x3, x29, #80
	sub	x4, x29, #88
	bl	_file_cyclic_budget
	stur	w0, [x29, #-36]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB136_6
	b	LBB136_5
LBB136_5:
	ldur	x0, [x29, #-32]
	bl	_nvm_file_indirect_targets_free
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_6:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	ldur	x10, [x29, #-80]
	mov	x9, #33554432                   ; =0x2000000
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB136_8
	b	LBB136_7
LBB136_7:
	ldur	x0, [x29, #-32]
	bl	_nvm_file_indirect_targets_free
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_8:
	mov	x0, #1                          ; =0x1
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x1, #104                        ; =0x68
	bl	_calloc
	mov	x8, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	stur	x8, [x29, #-104]
	mov	x1, #4888                       ; =0x1318
	movk	x1, #4, lsl #16
	bl	_calloc
	str	x0, [sp, #112]
	ldur	x8, [x29, #-104]
	cbz	x8, LBB136_10
	b	LBB136_9
LBB136_9:
	ldr	x8, [sp, #112]
	cbnz	x8, LBB136_11
	b	LBB136_10
LBB136_10:
	ldur	x0, [x29, #-104]
	bl	_free
	ldr	x0, [sp, #112]
	bl	_free
	ldur	x0, [x29, #-32]
	bl	_nvm_file_indirect_targets_free
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_11:
	ldur	x8, [x29, #-32]
	ldur	x9, [x29, #-104]
	str	x8, [x9]
	ldur	x8, [x29, #-32]
	ldr	x9, [sp, #112]
	str	x8, [x9]
	str	wzr, [sp, #108]
	b	LBB136_12
LBB136_12:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #108]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB136_19
	b	LBB136_13
LBB136_13:                              ;   in Loop: Header=BB136_12 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #32]
	ldr	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #56
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #64]
	add	w8, w8, w9
	str	w8, [sp, #52]
	ldr	w8, [sp, #52]
	ldur	w9, [x29, #-92]
	subs	w8, w8, w9
	b.hs	LBB136_16
	b	LBB136_14
LBB136_14:                              ;   in Loop: Header=BB136_12 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	mov	x10, #600                       ; =0x258
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #60]
	subs	w8, w8, w9
	b.ne	LBB136_16
	b	LBB136_15
LBB136_15:                              ;   in Loop: Header=BB136_12 Depth=1
	ldr	x8, [sp, #112]
	add	x8, x8, #8
	ldr	w9, [sp, #52]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB136_17
	b	LBB136_16
LBB136_16:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-36]
	b	LBB136_24
LBB136_17:                              ;   in Loop: Header=BB136_12 Depth=1
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #112]
	add	x9, x9, #8
	ldr	w10, [sp, #52]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB136_18
LBB136_18:                              ;   in Loop: Header=BB136_12 Depth=1
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB136_12
LBB136_19:
	ldur	x8, [x29, #-72]
	add	x2, sp, #16
	str	x8, [sp, #16]
	ldur	x8, [x29, #-32]
	add	x8, x8, #40
	str	x8, [sp, #24]
	ldr	x8, [sp, #112]
	str	x8, [sp, #32]
	adrp	x8, _fif_transfer@PAGE
	add	x8, x8, _fif_transfer@PAGEOFF
	str	x8, [sp, #40]
	ldur	x0, [x29, #-16]
	ldur	x8, [x29, #-104]
	add	x1, x8, #8
	bl	_file_cyclic_analyze_extended
	stur	w0, [x29, #-36]
	ldur	w8, [x29, #-36]
	cbz	w8, LBB136_21
	b	LBB136_20
LBB136_20:
	b	LBB136_24
LBB136_21:
	ldur	x9, [x29, #-104]
	ldur	x8, [x29, #-32]
	ldur	q0, [x8, #8]
	str	q0, [x9, #16]
	ldr	x8, [x8, #24]
	str	x8, [x9, #32]
	ldur	x8, [x29, #-104]
	add	x0, x8, #40
	ldur	x8, [x29, #-104]
	ldr	x8, [x8, #8]
	add	x1, x8, #16
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x8, [sp, #112]
	mov	x9, #32776                      ; =0x8008
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-104]
	str	w8, [x9, #80]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-104]
	ldr	x9, [x9, #8]
	ldr	x9, [x9, #40]
	add	x8, x8, x9
	ldur	x9, [x29, #-104]
	str	x8, [x9, #88]
	ldur	x8, [x29, #-104]
	ldr	x8, [x8, #88]
	mov	x9, #33554432                   ; =0x2000000
	subs	x8, x8, x9
	b.ls	LBB136_23
	b	LBB136_22
LBB136_22:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-36]
	b	LBB136_24
LBB136_23:
	ldr	x0, [sp, #112]
	bl	_free
	ldur	x8, [x29, #-104]
	ldur	x9, [x29, #-24]
	str	x8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB136_25
LBB136_24:
	ldr	x0, [sp, #112]
	bl	_free
	ldur	x0, [x29, #-104]
	bl	_nvm_file_indirect_flow_free
	ldur	w8, [x29, #-36]
	stur	w8, [x29, #-4]
	b	LBB136_25
LBB136_25:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fif_target_status
_fif_target_status:                     ; @fif_target_status
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB137_5
	b	LBB137_1
LBB137_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.eq	LBB137_6
	b	LBB137_2
LBB137_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB137_7
	b	LBB137_3
LBB137_3:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB137_8
	b	LBB137_4
LBB137_4:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB137_9
	b	LBB137_10
LBB137_5:
	str	wzr, [sp, #12]
	b	LBB137_11
LBB137_6:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB137_11
LBB137_7:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #12]
	b	LBB137_11
LBB137_8:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #12]
	b	LBB137_11
LBB137_9:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB137_11
LBB137_10:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB137_11
LBB137_11:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_budget
_file_cyclic_budget:                    ; @file_cyclic_budget
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	str	x3, [sp, #40]
	str	x4, [sp, #32]
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-32]
	ldr	x2, [sp, #40]
	bl	_file_code_preflight
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB138_2
	b	LBB138_1
LBB138_1:
	ldr	w8, [sp, #28]
	stur	w8, [x29, #-4]
	b	LBB138_14
LBB138_2:
	str	xzr, [sp, #16]
	str	wzr, [sp, #12]
	b	LBB138_3
LBB138_3:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.hs	LBB138_6
	b	LBB138_4
LBB138_4:                               ;   in Loop: Header=BB138_3 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #256]
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #24                         ; =0x18
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #16]
	mov	x9, x8
	ldr	x8, [sp, #16]
	add	x8, x8, x9
	str	x8, [sp, #16]
	b	LBB138_5
LBB138_5:                               ;   in Loop: Header=BB138_3 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB138_3
LBB138_6:
	ldr	x8, [sp, #16]
	lsl	x8, x8, #4
	add	x8, x8, #1816
	ldr	x9, [sp, #32]
	str	x8, [x9]
	ldr	x0, [sp, #40]
	mov	x1, #1                          ; =0x1
	mov	x2, #56                         ; =0x38
	bl	_file_code_budget
	tbz	w0, #0, LBB138_12
	b	LBB138_7
LBB138_7:
	ldr	x0, [sp, #40]
	ldur	x8, [x29, #-32]
	ldr	w8, [x8]
	mov	x1, x8
	mov	x2, #136                        ; =0x88
	bl	_file_code_budget
	tbz	w0, #0, LBB138_12
	b	LBB138_8
LBB138_8:
	ldr	x0, [sp, #40]
	mov	x1, #1                          ; =0x1
	mov	x2, #41624                      ; =0xa298
	movk	x2, #1, lsl #16
	bl	_file_code_budget
	tbz	w0, #0, LBB138_12
	b	LBB138_9
LBB138_9:
	ldr	x0, [sp, #40]
	ldr	x8, [sp, #32]
	ldr	x2, [x8]
	mov	x1, #1                          ; =0x1
	bl	_file_code_budget
	tbz	w0, #0, LBB138_12
	b	LBB138_10
LBB138_10:
	ldr	x0, [sp, #40]
	ldur	x2, [x29, #-24]
	mov	x1, #1                          ; =0x1
	bl	_file_code_budget
	tbz	w0, #0, LBB138_12
	b	LBB138_11
LBB138_11:
	ldr	x8, [sp, #40]
	ldr	x8, [x8]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB138_13
	b	LBB138_12
LBB138_12:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB138_14
LBB138_13:
	stur	wzr, [x29, #-4]
	b	LBB138_14
LBB138_14:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fif_transfer
_fif_transfer:                          ; @fif_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1024
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #216
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	adrp	x9, ___stack_chk_guard@GOTPAGE
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
	str	x0, [x8, #272]
	str	x1, [x8, #264]
	str	x2, [x8, #256]
	str	x3, [x8, #248]
	str	x4, [x8, #240]
	ldr	x9, [x8, #272]
	str	x9, [x8, #232]
	ldr	x8, [x8, #248]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #250
	b.ne	LBB139_6
	b	LBB139_1
LBB139_1:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #248]
	ldr	w8, [x8, #16]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB139_3
	b	LBB139_2
LBB139_2:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_3:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.ne	LBB139_5
	b	LBB139_4
LBB139_4:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_5:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #256]
	mov	x10, #24624                     ; =0x6030
	add	x10, x9, x10
	ldr	x11, [x8, #256]
	ldrh	w8, [x11, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #52]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	strh	w9, [x11, #12]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #52]                   ; 4-byte Folded Reload
	str	x0, [x8, #176]
	str	x1, [x8, #184]
	ldr	x0, [x8, #176]
	ldr	x1, [x8, #184]
	add	x8, sp, #408
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	str	wzr, [sp, #500]
	b	LBB139_72
LBB139_6:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #248]
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	tbnz	w0, #0, LBB139_8
	b	LBB139_7
LBB139_7:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #264]
	ldr	x1, [x8, #256]
	ldr	x2, [x8, #248]
	ldr	x3, [x8, #240]
	bl	_file_body_transfer
	str	w0, [sp, #500]
	b	LBB139_72
LBB139_8:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #256]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB139_10
	b	LBB139_9
LBB139_9:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_10:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #256]
	mov	x10, #24624                     ; =0x6030
	add	x10, x9, x10
	ldr	x8, [x8, #256]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	add	x0, sp, #352
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #368]
	tbz	w8, #0, LBB139_14
	b	LBB139_11
LBB139_11:
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x0, [x8, #120]
	str	x1, [x8, #128]
	ldr	x0, [x8, #136]
	ldr	x1, [x8, #144]
	ldr	x2, [x8, #120]
	ldr	x3, [x8, #128]
	bl	_same
	tbz	w0, #0, LBB139_14
	b	LBB139_12
LBB139_12:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #160]
	cbnz	x8, LBB139_14
	b	LBB139_13
LBB139_13:
	ldr	w8, [sp, #384]
	cbz	w8, LBB139_15
	b	LBB139_14
LBB139_14:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_15:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #248]
	ldr	x10, [x9, #264]
	ldr	x10, [x10]
	ldr	x10, [x10, #16]
	subs	x8, x8, x10
	mov	x10, #600                       ; =0x258
	sdiv	x8, x8, x10
	str	x8, [x9, #112]
	ldr	x8, [x9, #112]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	ldr	w9, [x9, #32]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB139_17
	b	LBB139_16
LBB139_16:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #232]
	add	x8, x8, #8
	ldr	x9, [x9, #112]
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB139_18
	b	LBB139_17
LBB139_17:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_18:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #232]
	ldr	x8, [x8]
	ldr	x8, [x8]
	str	x8, [x9, #104]
	ldr	x8, [x9, #256]
	ldr	w8, [x8, #8]
	str	w8, [sp, #316]
	ldr	w8, [sp, #316]
	ldr	x9, [x9, #104]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB139_27
	b	LBB139_19
LBB139_19:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #316]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB139_27
	b	LBB139_20
LBB139_20:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	ldr	w8, [x8, #32]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.ne	LBB139_27
	b	LBB139_21
LBB139_21:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	add	x8, x8, #2352
	ldr	w10, [sp, #316]
                                        ; kill: def $x10 killed $w10
	ldr	w8, [x8, x10, lsl #2]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	add	x9, x9, #2352
	ldr	w10, [sp, #316]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	subs	w8, w8, w9
	b.ne	LBB139_27
	b	LBB139_22
LBB139_22:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #112]
	ldr	x9, [x9, #104]
	add	x9, x9, #2352
	ldr	w10, [sp, #316]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.lo	LBB139_27
	b	LBB139_23
LBB139_23:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #112]
	ldr	x10, [x9, #104]
	add	x10, x10, #2352
	ldr	w11, [sp, #316]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
                                        ; kill: def $x10 killed $w10
	subs	x8, x8, x10
	ldr	x9, [x9, #104]
	add	x11, x9, #48
	ldr	w9, [sp, #316]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.hs	LBB139_27
	b	LBB139_24
LBB139_24:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	add	x12, x8, #48
	ldr	w8, [sp, #316]
                                        ; kill: def $x8 killed $w8
	mov	x10, #36                        ; =0x24
	mov	x11, x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w11, x12
	ldrh	w8, [x8, #8]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldr	w9, [sp, #316]
                                        ; kill: def $x9 killed $w9
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB139_27
	b	LBB139_25
LBB139_25:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	ldr	x8, [x8, #16]
	ldr	x10, [x9, #112]
	mov	x11, #600                       ; =0x258
	mul	x10, x10, x11
	ldr	w8, [x8, x10]
	ldr	x9, [x9, #248]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB139_27
	b	LBB139_26
LBB139_26:
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #104]
	ldr	x8, [x8, #16]
	ldr	x10, [x9, #112]
	mov	x11, #600                       ; =0x258
	mul	x10, x10, x11
	add	x8, x8, x10
	ldrb	w8, [x8, #8]
	ldr	x9, [x9, #248]
	ldrb	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB139_28
	b	LBB139_27
LBB139_27:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_28:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	add	x9, x9, #8
	ldr	x10, [x8, #112]
	ldr	x9, [x9, x10, lsl #3]
	str	x9, [x8, #88]
	ldr	x0, [x8, #256]
	bl	_pop
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #32784                     ; =0x8010
	add	x0, x9, x10
	ldr	x1, [x8, #256]
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #256]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	str	x8, [x9, #80]
	ldr	x8, [x9, #80]
	str	x8, [x9, #72]
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #287]
	add	x0, sp, #228
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	str	wzr, [sp, #224]
	b	LBB139_29
LBB139_29:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB139_36 Depth 2
                                        ;     Child Loop BB139_48 Depth 2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #224]
	ldr	x9, [x9, #264]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB139_69
	b	LBB139_30
LBB139_30:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #88]
	ldr	w9, [sp, #224]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB139_67
	b	LBB139_31
LBB139_31:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #264]
	add	x8, x8, #16
	ldr	w9, [sp, #224]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB139_33
	b	LBB139_32
LBB139_32:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_33:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #232]
	mov	x9, #32776                      ; =0x8008
	ldr	w8, [x8, x9]
	subs	w8, w8, #64, lsl #12            ; =262144
	b.ne	LBB139_35
	b	LBB139_34
LBB139_34:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_35:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #32776                     ; =0x8008
	add	x10, x9, x10
	ldr	w9, [x10]
	add	w9, w9, #1
	str	w9, [x10]
	ldr	x9, [x8, #232]
	mov	x10, #28880                     ; =0x70d0
	movk	x10, #2, lsl #16
	add	x0, x9, x10
	ldr	x8, [x8, #232]
	mov	x9, #32784                      ; =0x8010
	add	x1, x8, x9
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #80]
	ldr	x10, [x9, #256]
	ldr	x10, [x10]
	str	x8, [x10, #8]
	ldr	x8, [x9, #264]
	ldr	x8, [x8]
	add	x11, x8, #48
	ldr	w8, [sp, #224]
                                        ; kill: def $x8 killed $w8
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	add	x8, x8, #12
	str	x8, [x9]
	strh	wzr, [sp, #214]
	b	LBB139_36
LBB139_36:                              ;   Parent Loop BB139_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #214]
	ldr	x9, [x9]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB139_45
	b	LBB139_37
LBB139_37:                              ;   in Loop: Header=BB139_36 Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #256]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldr	x9, [x9, #256]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldr	w10, [sp, #224]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #214]
	add	w9, w9, w10
	add	x8, x8, w9, uxtw #4
	ldrb	w8, [x8, #1]
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #213]
	ldrb	w8, [sp, #213]
	tbz	w8, #0, LBB139_40
	b	LBB139_38
LBB139_38:                              ;   in Loop: Header=BB139_36 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #248]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #152
	b.eq	LBB139_40
	b	LBB139_39
LBB139_39:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_40:                              ;   in Loop: Header=BB139_36 Depth=2
	ldrb	w8, [sp, #213]
	tbz	w8, #0, LBB139_42
	b	LBB139_41
LBB139_41:                              ;   in Loop: Header=BB139_36 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #248]
	add	x8, x8, #78
	ldrh	w9, [sp, #214]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB139_43
LBB139_42:                              ;   in Loop: Header=BB139_36 Depth=2
	mov	w8, #65535                      ; =0xffff
	str	w8, [sp, #48]                   ; 4-byte Folded Spill
	b	LBB139_43
LBB139_43:                              ;   in Loop: Header=BB139_36 Depth=2
	ldr	w8, [sp, #48]                   ; 4-byte Folded Reload
	ldrh	w9, [sp, #214]
	mov	x10, x9
	add	x9, sp, #504
	strh	w8, [x9, x10, lsl #1]
	b	LBB139_44
LBB139_44:                              ;   in Loop: Header=BB139_36 Depth=2
	ldrh	w8, [sp, #214]
	add	w8, w8, #1
	strh	w8, [sp, #214]
	b	LBB139_36
LBB139_45:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #28880                     ; =0x70d0
	movk	x10, #2, lsl #16
	add	x0, x9, x10
	ldr	x9, [x8, #248]
	ldr	w1, [x9]
	ldr	w2, [sp, #224]
	ldr	x8, [x8]
	ldrh	w4, [x8]
	add	x3, sp, #504
	bl	_nvm_file_flow_call
	str	w0, [sp, #208]
	ldr	w8, [sp, #208]
	cbz	w8, LBB139_47
	b	LBB139_46
LBB139_46:
	ldr	w8, [sp, #208]
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_47:                              ;   in Loop: Header=BB139_29 Depth=1
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #200]
	strh	wzr, [sp, #198]
	b	LBB139_48
LBB139_48:                              ;   Parent Loop BB139_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #198]
	ldr	x9, [x9, #232]
	mov	x10, #28880                     ; =0x70d0
	movk	x10, #2, lsl #16
	add	x9, x9, x10
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB139_53
	b	LBB139_49
LBB139_49:                              ;   in Loop: Header=BB139_48 Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #232]
	mov	x10, #28924                     ; =0x70fc
	movk	x10, #2, lsl #16
	add	x11, x8, x10
	ldrh	w8, [sp, #198]
                                        ; kill: def $x8 killed $w8
	mov	x10, #56                        ; =0x38
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldr	w8, [x8, #4]
	ldr	x9, [x9, #248]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB139_51
	b	LBB139_50
LBB139_50:                              ;   in Loop: Header=BB139_48 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #232]
	mov	x9, #28924                      ; =0x70fc
	movk	x9, #2, lsl #16
	add	x10, x8, x9
	ldrh	w8, [sp, #198]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #200]
	b	LBB139_51
LBB139_51:                              ;   in Loop: Header=BB139_48 Depth=2
	b	LBB139_52
LBB139_52:                              ;   in Loop: Header=BB139_48 Depth=2
	ldrh	w8, [sp, #198]
	add	w8, w8, #1
	strh	w8, [sp, #198]
	b	LBB139_48
LBB139_53:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #200]
	cbz	x8, LBB139_56
	b	LBB139_54
LBB139_54:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #200]
	ldr	w8, [x8]
	subs	w8, w8, #1
	b.ne	LBB139_56
	b	LBB139_55
LBB139_55:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #200]
	ldr	w8, [x8, #8]
	ldr	w9, [sp, #224]
	subs	w8, w8, w9
	b.eq	LBB139_57
	b	LBB139_56
LBB139_56:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_57:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #200]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x10, #8]
	ldr	x8, [x8, #232]
	mov	x9, #28800                      ; =0x7080
	movk	x9, #2, lsl #16
	add	x0, x8, x9
	bl	_file_cyclic_canonicalize
	str	w0, [sp, #208]
	ldr	w8, [sp, #208]
	cbz	w8, LBB139_59
	b	LBB139_58
LBB139_58:
	ldr	w8, [sp, #208]
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_59:                              ;   in Loop: Header=BB139_29 Depth=1
	ldrb	w8, [sp, #287]
	tbz	w8, #0, LBB139_61
	b	LBB139_60
LBB139_60:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #14400                     ; =0x3840
	movk	x10, #1, lsl #16
	add	x0, x9, x10
	ldr	x8, [x8, #232]
	mov	x9, #28880                      ; =0x70d0
	movk	x9, #2, lsl #16
	add	x1, x8, x9
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #61552                     ; =0xf070
	movk	x10, #1, lsl #16
	add	x0, x9, x10
	ldr	x8, [x8, #232]
	mov	x9, #10496                      ; =0x2900
	movk	x9, #3, lsl #16
	add	x1, x8, x9
	mov	x2, #32784                      ; =0x8010
	bl	_memcpy
	ldr	x1, [sp, #200]
	add	x0, sp, #228
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #256]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	str	x8, [x9, #72]
	strb	wzr, [sp, #287]
	b	LBB139_66
LBB139_61:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #61552                     ; =0xf070
	movk	x10, #1, lsl #16
	add	x0, x9, x10
	ldr	x8, [x8, #232]
	mov	x9, #10496                      ; =0x2900
	movk	x9, #3, lsl #16
	add	x1, x8, x9
	bl	_file_cyclic_equal
	tbz	w0, #0, LBB139_64
	b	LBB139_62
LBB139_62:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #232]
	mov	x10, #14400                     ; =0x3840
	movk	x10, #1, lsl #16
	add	x0, x9, x10
	ldr	x8, [x8, #232]
	mov	x9, #28880                      ; =0x70d0
	movk	x9, #2, lsl #16
	add	x1, x8, x9
	bl	_fif_state_metadata_equal
	tbz	w0, #0, LBB139_64
	b	LBB139_63
LBB139_63:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	x8, [sp, #200]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	add	x0, sp, #140
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	add	x1, sp, #228
	mov	x2, #56                         ; =0x38
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	add	x0, sp, #84
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_obligation_same
	tbnz	w0, #0, LBB139_65
	b	LBB139_64
LBB139_64:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_65:                              ;   in Loop: Header=BB139_29 Depth=1
	b	LBB139_66
LBB139_66:                              ;   in Loop: Header=BB139_29 Depth=1
	b	LBB139_67
LBB139_67:                              ;   in Loop: Header=BB139_29 Depth=1
	b	LBB139_68
LBB139_68:                              ;   in Loop: Header=BB139_29 Depth=1
	ldr	w8, [sp, #224]
	add	w8, w8, #1
	str	w8, [sp, #224]
	b	LBB139_29
LBB139_69:
	ldrb	w8, [sp, #287]
	tbz	w8, #0, LBB139_71
	b	LBB139_70
LBB139_70:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #500]
	b	LBB139_72
LBB139_71:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #256]
	ldr	x8, [x8, #232]
	mov	x9, #14400                      ; =0x3840
	movk	x9, #1, lsl #16
	add	x1, x8, x9
	mov	x2, #47152                      ; =0xb830
	bl	_memcpy
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #72]
	ldr	x10, [x8, #256]
	ldr	x10, [x10]
	str	x9, [x10, #8]
	ldr	x10, [x8, #240]
	mov	w9, #5                          ; =0x5
	str	w9, [x10, #12]
	ldr	x10, [x8, #240]
	mov	w9, #1                          ; =0x1
	strb	w9, [x10, #3]
	ldr	x8, [x8, #240]
	add	x0, x8, #24
	add	x1, sp, #228
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x10, [x8, #240]
	mov	w9, #64                         ; =0x40
	str	w9, [x10, #16]
	ldr	w9, [sp, #240]
	ldr	x10, [x8, #240]
	ldr	w10, [x10, #16]
	bic	w10, w9, w10
	ldr	x9, [x8, #240]
	ldr	w8, [x9, #20]
	orr	w8, w8, w10
	str	w8, [x9, #20]
	str	wzr, [sp, #500]
	b	LBB139_72
LBB139_72:
	ldr	w8, [sp, #500]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB139_74
	b	LBB139_73
LBB139_73:
	bl	___stack_chk_fail
LBB139_74:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	add	sp, sp, #1024
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_free    ; -- Begin function nvm_file_indirect_flow_free
	.p2align	2
_nvm_file_indirect_flow_free:           ; @nvm_file_indirect_flow_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB140_2
	b	LBB140_1
LBB140_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8, #8]
	bl	_nvm_file_cyclic_free
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_indirect_targets_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB140_2
LBB140_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_summary ; -- Begin function nvm_file_indirect_flow_summary
	.p2align	2
_nvm_file_indirect_flow_summary:        ; @nvm_file_indirect_flow_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB141_2
	b	LBB141_1
LBB141_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB141_3
	b	LBB141_2
LBB141_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB141_4
LBB141_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	add	x1, x8, #16
	mov	x2, #88                         ; =0x58
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB141_4
LBB141_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_function ; -- Begin function nvm_file_indirect_flow_function
	.p2align	2
_nvm_file_indirect_flow_function:       ; @nvm_file_indirect_flow_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB142_2
	b	LBB142_1
LBB142_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_cyclic_function
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB142_2
LBB142_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_local   ; -- Begin function nvm_file_indirect_flow_local
	.p2align	2
_nvm_file_indirect_flow_local:          ; @nvm_file_indirect_flow_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB143_2
	b	LBB143_1
LBB143_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB143_2
LBB143_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_instruction ; -- Begin function nvm_file_indirect_flow_instruction
	.p2align	2
_nvm_file_indirect_flow_instruction:    ; @nvm_file_indirect_flow_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB144_2
	b	LBB144_1
LBB144_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_instruction
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB144_2
LBB144_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_variant_count ; -- Begin function nvm_file_indirect_flow_variant_count
	.p2align	2
_nvm_file_indirect_flow_variant_count:  ; @nvm_file_indirect_flow_variant_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB145_2
	b	LBB145_1
LBB145_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_variant_count
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB145_2
LBB145_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_variant ; -- Begin function nvm_file_indirect_flow_variant
	.p2align	2
_nvm_file_indirect_flow_variant:        ; @nvm_file_indirect_flow_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	str	x4, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB146_2
	b	LBB146_1
LBB146_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldr	x4, [sp, #8]
	bl	_nvm_file_cyclic_variant
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB146_2
LBB146_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_input_local ; -- Begin function nvm_file_indirect_flow_input_local
	.p2align	2
_nvm_file_indirect_flow_input_local:    ; @nvm_file_indirect_flow_input_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB147_2
	b	LBB147_1
LBB147_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_local
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB147_2
LBB147_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_input_stack ; -- Begin function nvm_file_indirect_flow_input_stack
	.p2align	2
_nvm_file_indirect_flow_input_stack:    ; @nvm_file_indirect_flow_input_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB148_2
	b	LBB148_1
LBB148_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_stack
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB148_2
LBB148_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_input_reference ; -- Begin function nvm_file_indirect_flow_input_reference
	.p2align	2
_nvm_file_indirect_flow_input_reference: ; @nvm_file_indirect_flow_input_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB149_2
	b	LBB149_1
LBB149_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_reference
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB149_2
LBB149_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_input_region ; -- Begin function nvm_file_indirect_flow_input_region
	.p2align	2
_nvm_file_indirect_flow_input_region:   ; @nvm_file_indirect_flow_input_region
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB150_2
	b	LBB150_1
LBB150_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_cyclic_input_region
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB150_2
LBB150_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_call    ; -- Begin function nvm_file_indirect_flow_call
	.p2align	2
_nvm_file_indirect_flow_call:           ; @nvm_file_indirect_flow_call
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #848
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	sturh	w2, [x29, #-38]
	sturb	w3, [x29, #-39]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB151_2
	b	LBB151_1
LBB151_1:
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB151_3
	b	LBB151_2
LBB151_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB151_17
LBB151_3:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-36]
	ldurh	w2, [x29, #-38]
	add	x3, sp, #216
	bl	_nvm_file_cyclic_instruction
	tbz	w0, #0, LBB151_7
	b	LBB151_4
LBB151_4:
	ldrb	w0, [sp, #224]
	bl	_isa_is_file_indirect_call
	tbz	w0, #0, LBB151_7
	b	LBB151_5
LBB151_5:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-36]
	ldurh	w2, [x29, #-38]
	ldurb	w3, [x29, #-39]
	add	x4, sp, #112
	bl	_nvm_file_cyclic_variant
	tbz	w0, #0, LBB151_7
	b	LBB151_6
LBB151_6:
	ldrb	w8, [sp, #135]
	tbnz	w8, #0, LBB151_8
	b	LBB151_7
LBB151_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB151_17
LBB151_8:
	str	wzr, [sp, #108]
	b	LBB151_9
LBB151_9:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #108]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB151_16
	b	LBB151_10
LBB151_10:                              ;   in Loop: Header=BB151_9 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x10, [x8, #32]
	ldr	w8, [sp, #108]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #96]
	ldr	x8, [sp, #96]
	ldr	w8, [x8]
	ldur	w9, [x29, #-36]
	subs	w8, w8, w9
	b.ne	LBB151_14
	b	LBB151_11
LBB151_11:                              ;   in Loop: Header=BB151_9 Depth=1
	ldr	x8, [sp, #96]
	ldrh	w8, [x8, #8]
	ldurh	w9, [x29, #-38]
	subs	w8, w8, w9
	b.ne	LBB151_14
	b	LBB151_12
LBB151_12:                              ;   in Loop: Header=BB151_9 Depth=1
	ldr	x8, [sp, #96]
	ldr	w8, [x8, #4]
	ldr	w9, [sp, #216]
	subs	w8, w8, w9
	b.ne	LBB151_14
	b	LBB151_13
LBB151_13:
	ldur	x8, [x29, #-48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	w9, [x29, #-36]
	add	x8, sp, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	w9, [sp, #16]
	ldr	w9, [sp, #216]
	str	w9, [sp, #20]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #16]
	str	x9, [sp, #24]
	ldr	x9, [sp, #96]
	ldr	x9, [x9, #16]
	str	x9, [sp, #32]
	add	x0, x8, #24
	add	x8, sp, #112
	add	x1, x8, #44
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #80                         ; =0x50
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB151_17
LBB151_14:                              ;   in Loop: Header=BB151_9 Depth=1
	b	LBB151_15
LBB151_15:                              ;   in Loop: Header=BB151_9 Depth=1
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB151_9
LBB151_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB151_17
LBB151_17:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	add	sp, sp, #848
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function isa_is_file_indirect_call
_isa_is_file_indirect_call:             ; @isa_is_file_indirect_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	strb	w0, [sp, #15]
	ldrb	w9, [sp, #15]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #60
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.eq	LBB152_2
	b	LBB152_1
LBB152_1:
	ldrb	w8, [sp, #15]
	subs	w8, w8, #152
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB152_2
LBB152_2:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_component ; -- Begin function nvm_file_indirect_flow_component
	.p2align	2
_nvm_file_indirect_flow_component:      ; @nvm_file_indirect_flow_component
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB153_2
	b	LBB153_1
LBB153_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_cyclic_component
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB153_2
LBB153_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_type    ; -- Begin function nvm_file_indirect_flow_type
	.p2align	2
_nvm_file_indirect_flow_type:           ; @nvm_file_indirect_flow_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB154_2
	b	LBB154_1
LBB154_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_cyclic_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB154_2
LBB154_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_flow_import  ; -- Begin function nvm_file_indirect_flow_import
	.p2align	2
_nvm_file_indirect_flow_import:         ; @nvm_file_indirect_flow_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB155_2
	b	LBB155_1
LBB155_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_cyclic_import
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB155_2
LBB155_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_free  ; -- Begin function nvm_file_indirect_hosted_free
	.p2align	2
_nvm_file_indirect_hosted_free:         ; @nvm_file_indirect_hosted_free
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB156_2
	b	LBB156_1
LBB156_1:
	ldr	x8, [sp, #8]
	ldr	x0, [x8]
	bl	_nvm_file_indirect_flow_free
	ldr	x8, [sp, #8]
	mov	x9, #32776                      ; =0x8008
	ldr	x0, [x8, x9]
	bl	_free
	ldr	x0, [sp, #8]
	bl	_free
	b	LBB156_2
LBB156_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_prepare ; -- Begin function nvm_file_indirect_hosted_prepare
	.p2align	2
_nvm_file_indirect_hosted_prepare:      ; @nvm_file_indirect_hosted_prepare
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #432
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #416]            ; 16-byte Folded Spill
	add	x29, sp, #416
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	ldur	x8, [x29, #-48]
	cbnz	x8, LBB157_2
	b	LBB157_1
LBB157_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_2:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	sub	x2, x29, #96
	sub	x3, x29, #104
	bl	_file_hosted_preflight
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB157_4
	b	LBB157_3
LBB157_3:
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_4:
	ldur	x8, [x29, #-104]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.hs	LBB157_6
	b	LBB157_5
LBB157_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_6:
	sub	x0, x29, #104
	ldur	x8, [x29, #-104]
	mov	x9, #-16777216                  ; =0xffffffffff000000
	add	x8, x8, x9
	stur	x8, [x29, #-104]
	mov	x1, #1                          ; =0x1
	mov	x2, #33554432                   ; =0x2000000
	bl	_file_hosted_add
	tbz	w0, #0, LBB157_8
	b	LBB157_7
LBB157_7:
	sub	x0, x29, #104
	mov	x1, #1                          ; =0x1
	mov	x2, #38512                      ; =0x9670
	bl	_file_hosted_add
	tbnz	w0, #0, LBB157_9
	b	LBB157_8
LBB157_8:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_9:
	ldur	x0, [x29, #-40]
	bl	_malloc
	stur	x0, [x29, #-120]
	ldur	x8, [x29, #-120]
	cbnz	x8, LBB157_11
	b	LBB157_10
LBB157_10:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_11:
	ldur	x0, [x29, #-120]
	ldur	x1, [x29, #-32]
	ldur	x2, [x29, #-40]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	add	x0, sp, #48
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #248                        ; =0xf8
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $x8 killed $xzr
	str	xzr, [sp, #40]
	str	xzr, [sp, #32]
	ldur	x0, [x29, #-120]
	ldur	x1, [x29, #-40]
	bl	_nvm_v2_module_deserialize
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB157_13
	b	LBB157_12
LBB157_12:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB157_40
LBB157_13:
	add	x0, sp, #48
	add	x1, sp, #40
	bl	_nvm_v2_to_nvm_module
	str	w0, [sp, #28]
	ldr	w8, [sp, #28]
	cbz	w8, LBB157_15
	b	LBB157_14
LBB157_14:
	ldr	w0, [sp, #28]
	bl	_file_hosted_codec_status
	stur	w0, [x29, #-108]
	b	LBB157_40
LBB157_15:
	ldr	x8, [sp, #40]
	cbz	x8, LBB157_19
	b	LBB157_16
LBB157_16:
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #288]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #224]
	subs	x8, x8, x9
	b.ne	LBB157_19
	b	LBB157_17
LBB157_17:
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #280]
	cbz	x8, LBB157_19
	b	LBB157_18
LBB157_18:
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #280]
	ldr	x1, [sp, #216]
	ldr	x2, [sp, #224]
	bl	_memcmp
	cbz	w0, LBB157_20
	b	LBB157_19
LBB157_19:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-108]
	b	LBB157_40
LBB157_20:
	mov	x0, #1                          ; =0x1
	mov	x1, #38512                      ; =0x9670
	bl	_calloc
	str	x0, [sp, #32]
	ldr	x8, [sp, #32]
	cbnz	x8, LBB157_22
	b	LBB157_21
LBB157_21:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-108]
	b	LBB157_40
LBB157_22:
	ldr	x9, [sp, #32]
	mov	x10, #32784                     ; =0x8010
	mov	w8, #1                          ; =0x1
	str	w8, [x9, x10]
	ldur	w8, [x29, #-88]
	ldr	x9, [sp, #32]
	add	x9, x9, x10
	str	w8, [x9, #16]
	ldur	x8, [x29, #-40]
	ldr	x9, [sp, #32]
	add	x9, x9, x10
	str	x8, [x9, #56]
	ldur	x8, [x29, #-104]
	ldr	x9, [sp, #32]
	add	x9, x9, x10
	str	x8, [x9, #64]
	ldr	x0, [sp, #40]
	ldr	x1, [sp, #32]
	bl	_nvm_file_indirect_flow_analyze
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB157_24
	b	LBB157_23
LBB157_23:
	b	LBB157_40
LBB157_24:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	w8, [x8, #40]
	subs	w8, w8, #1
	b.ne	LBB157_28
	b	LBB157_25
LBB157_25:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldrb	w8, [x8, #96]
	tbnz	w8, #0, LBB157_28
	b	LBB157_26
LBB157_26:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldrb	w8, [x8, #72]
	tbnz	w8, #0, LBB157_28
	b	LBB157_27
LBB157_27:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8, #88]
	mov	x9, #33554432                   ; =0x2000000
	subs	x8, x8, x9
	b.ls	LBB157_29
	b	LBB157_28
LBB157_28:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-108]
	b	LBB157_40
LBB157_29:
	ldr	x8, [sp, #32]
	ldr	x8, [x8]
	ldr	x8, [x8, #88]
	ldr	x9, [sp, #32]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	x8, [x9, #72]
	add	x0, sp, #16
	mov	x8, #38512                      ; =0x9670
	str	x8, [sp, #16]
	ldur	x1, [x29, #-40]
	mov	x2, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB157_32
	b	LBB157_30
LBB157_30:
	ldr	x8, [sp, #32]
	mov	x9, #32784                      ; =0x8010
	add	x8, x8, x9
	ldr	x2, [x8, #72]
	add	x0, sp, #16
	mov	x1, #1                          ; =0x1
	bl	_file_hosted_add
	tbz	w0, #0, LBB157_32
	b	LBB157_31
LBB157_31:
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-104]
	subs	x8, x8, x9
	b.ls	LBB157_33
	b	LBB157_32
LBB157_32:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-108]
	b	LBB157_40
LBB157_33:
	ldr	x8, [sp, #16]
	ldr	x9, [sp, #32]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	x8, [x9, #80]
	ldr	x0, [sp, #32]
	bl	_file_ih_target_map
	tbnz	w0, #0, LBB157_35
	b	LBB157_34
LBB157_34:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-108]
	b	LBB157_40
LBB157_35:
	ldr	x0, [sp, #32]
	ldr	x2, [sp, #40]
	add	x1, sp, #48
	bl	_file_ih_start
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB157_37
	b	LBB157_36
LBB157_36:
	b	LBB157_40
LBB157_37:
	ldr	x0, [sp, #32]
	add	x1, sp, #48
	bl	_file_ih_bounds
	stur	w0, [x29, #-108]
	ldur	w8, [x29, #-108]
	cbz	w8, LBB157_39
	b	LBB157_38
LBB157_38:
	b	LBB157_40
LBB157_39:
	ldur	x8, [x29, #-120]
	ldr	x9, [sp, #32]
	mov	x10, #32776                     ; =0x8008
	str	x8, [x9, x10]
                                        ; kill: def $x8 killed $xzr
	stur	xzr, [x29, #-120]
	ldr	x8, [sp, #32]
	ldur	x9, [x29, #-48]
	str	x8, [x9]
	str	xzr, [sp, #32]
	b	LBB157_40
LBB157_40:
	ldr	x0, [sp, #32]
	bl	_nvm_file_indirect_hosted_free
	ldr	x0, [sp, #40]
	bl	_nvm_module_free
	add	x0, sp, #48
	bl	_nvm_v2_module_free
	ldur	x0, [x29, #-120]
	bl	_free
	ldur	w8, [x29, #-108]
	stur	w8, [x29, #-20]
	b	LBB157_41
LBB157_41:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #432
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_target_map
_file_ih_target_map:                    ; @file_ih_target_map
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	stur	x8, [x29, #-32]
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB158_2
	b	LBB158_1
LBB158_1:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.eq	LBB158_3
	b	LBB158_2
LBB158_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB158_25
LBB158_3:
	stur	wzr, [x29, #-36]
	b	LBB158_4
LBB158_4:                               ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.hs	LBB158_18
	b	LBB158_5
LBB158_5:                               ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-24]
	ldr	x10, [x8, #32]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #48                         ; =0x30
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #8
	mov	x2, #48                         ; =0x30
	bl	_memcpy
	ldr	w8, [sp, #8]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB158_10
	b	LBB158_6
LBB158_6:                               ;   in Loop: Header=BB158_4 Depth=1
	ldrh	w8, [sp, #16]
	ldur	x9, [x29, #-32]
	add	x11, x9, #48
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB158_10
	b	LBB158_7
LBB158_7:                               ;   in Loop: Header=BB158_4 Depth=1
	ldr	x8, [sp, #24]
	cbz	x8, LBB158_10
	b	LBB158_8
LBB158_8:                               ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #24]
	subs	w8, w8, #64
	b.hs	LBB158_11
	b	LBB158_9
LBB158_9:                               ;   in Loop: Header=BB158_4 Depth=1
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #24]
                                        ; kill: def $x9 killed $w9
	lsr	x8, x8, x9
	cbz	x8, LBB158_11
	b	LBB158_10
LBB158_10:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB158_25
LBB158_11:                              ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-32]
	add	x8, x8, #2352
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #16]
	add	w8, w8, w9
	str	w8, [sp, #4]
	ldr	w8, [sp, #4]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.hs	LBB158_15
	b	LBB158_12
LBB158_12:                              ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB158_15
	b	LBB158_13
LBB158_13:                              ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #16]
	ldr	w8, [sp, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #600                        ; =0x258
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	tbz	w0, #0, LBB158_15
	b	LBB158_14
LBB158_14:                              ;   in Loop: Header=BB158_4 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #4]
                                        ; kill: def $x9 killed $w9
	mov	x10, #600                       ; =0x258
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	w9, [sp, #12]
	subs	w8, w8, w9
	b.eq	LBB158_16
	b	LBB158_15
LBB158_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB158_25
LBB158_16:                              ;   in Loop: Header=BB158_4 Depth=1
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	add	x9, x9, #8
	ldr	w10, [sp, #4]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB158_17
LBB158_17:                              ;   in Loop: Header=BB158_4 Depth=1
	ldur	w8, [x29, #-36]
	add	w8, w8, #1
	stur	w8, [x29, #-36]
	b	LBB158_4
LBB158_18:
	str	wzr, [sp]
	b	LBB158_19
LBB158_19:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp]
	ldur	x9, [x29, #-32]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	b.hs	LBB158_24
	b	LBB158_20
LBB158_20:                              ;   in Loop: Header=BB158_19 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #16]
	ldr	w8, [sp]
                                        ; kill: def $x8 killed $w8
	mov	x9, #600                        ; =0x258
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldr	w9, [sp]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	subs	x8, x8, #0
	cset	w8, ne
	subs	w8, w0, w8
	b.eq	LBB158_22
	b	LBB158_21
LBB158_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB158_25
LBB158_22:                              ;   in Loop: Header=BB158_19 Depth=1
	b	LBB158_23
LBB158_23:                              ;   in Loop: Header=BB158_19 Depth=1
	ldr	w8, [sp]
	add	w8, w8, #1
	str	w8, [sp]
	b	LBB158_19
LBB158_24:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB158_25
LBB158_25:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_start
_file_ih_start:                         ; @file_ih_start
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	str	x8, [sp, #24]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #80]
	subs	w8, w8, w9
	b.ne	LBB159_5
	b	LBB159_1
LBB159_1:
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #272]
	subs	w8, w8, w9
	b.ne	LBB159_5
	b	LBB159_2
LBB159_2:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #8]
	tbz	w8, #0, LBB159_5
	b	LBB159_3
LBB159_3:
	ldr	x8, [sp, #32]
	ldr	w8, [x8, #12]
	ldur	x9, [x29, #-24]
	ldr	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB159_5
	b	LBB159_4
LBB159_4:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB159_6
	b	LBB159_5
LBB159_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB159_31
LBB159_6:
	ldur	x8, [x29, #-24]
	ldr	w8, [x8, #4]
	ldur	x10, [x29, #-16]
	mov	x9, #32784                      ; =0x8010
	add	x10, x10, x9
	str	w8, [x10, #4]
	ldur	x8, [x29, #-16]
	add	x10, x8, x9
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x10, #8]
	ldr	x8, [sp, #24]
	ldr	w8, [x8, #24]
	ldur	x10, [x29, #-16]
	add	x10, x10, x9
	str	w8, [x10, #12]
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldur	x8, [x29, #-16]
	add	x8, x8, x9
	ldr	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	cbnz	w8, LBB159_12
	b	LBB159_7
LBB159_7:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	subs	w8, w8, #1
	b.ne	LBB159_12
	b	LBB159_8
LBB159_8:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB159_12
	b	LBB159_9
LBB159_9:
	ldr	x8, [sp, #16]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.ne	LBB159_12
	b	LBB159_10
LBB159_10:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	b.eq	LBB159_13
	b	LBB159_11
LBB159_11:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #4
	b.eq	LBB159_13
	b	LBB159_12
LBB159_12:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB159_31
LBB159_13:
	str	wzr, [sp, #12]
	b	LBB159_14
LBB159_14:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #24]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB159_30
	b	LBB159_15
LBB159_15:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #256]
	ldr	w9, [sp, #12]
                                        ; kill: def $x9 killed $w9
	mov	x10, #24                        ; =0x18
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	str	w8, [sp, #8]
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #32]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB159_18
	b	LBB159_16
LBB159_16:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB159_18
	b	LBB159_17
LBB159_17:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #240]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	mov	x2, x8
	mov	w1, #0                          ; =0x0
	bl	_memchr
	cbz	x0, LBB159_19
	b	LBB159_18
LBB159_18:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB159_31
LBB159_19:                              ;   in Loop: Header=BB159_14 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #32784                      ; =0x8010
	add	x8, x8, x9
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.ne	LBB159_28
	b	LBB159_20
LBB159_20:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp, #32]
	ldr	x8, [x8, #232]
	ldr	w9, [sp, #8]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	adrp	x1, l_.str.3@PAGE
	add	x1, x1, l_.str.3@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB159_28
	b	LBB159_21
LBB159_21:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp, #24]
	add	x10, x8, #48
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp]
	ldr	x8, [sp]
	ldrh	w8, [x8]
	cbnz	w8, LBB159_26
	b	LBB159_22
LBB159_22:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #4]
	cbnz	w8, LBB159_26
	b	LBB159_23
LBB159_23:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #8]
	cbnz	w8, LBB159_26
	b	LBB159_24
LBB159_24:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp]
	ldrb	w8, [x8, #9]
	cbnz	w8, LBB159_26
	b	LBB159_25
LBB159_25:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	x8, [sp]
	ldr	w8, [x8, #12]
	adds	w8, w8, #1
	b.eq	LBB159_27
	b	LBB159_26
LBB159_26:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB159_31
LBB159_27:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	w8, [sp, #12]
	ldur	x9, [x29, #-16]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	w8, [x9, #8]
	b	LBB159_28
LBB159_28:                              ;   in Loop: Header=BB159_14 Depth=1
	b	LBB159_29
LBB159_29:                              ;   in Loop: Header=BB159_14 Depth=1
	ldr	w8, [sp, #12]
	add	w8, w8, #1
	str	w8, [sp, #12]
	b	LBB159_14
LBB159_30:
	stur	wzr, [x29, #-4]
	b	LBB159_31
LBB159_31:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_bounds
_file_ih_bounds:                        ; @file_ih_bounds
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	stur	x0, [x29, #-144]
	stur	x1, [x29, #-152]
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	stur	x8, [x29, #-160]
	sub	x0, x29, #88
	mov	x2, #64                         ; =0x40
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	bl	_file_cyclic_complete
	tbnz	w0, #0, LBB160_2
	b	LBB160_1
LBB160_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_2:
	stur	wzr, [x29, #-164]
	b	LBB160_3
LBB160_3:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB160_12 Depth 2
                                        ;       Child Loop BB160_17 Depth 3
                                        ;     Child Loop BB160_37 Depth 2
                                        ;       Child Loop BB160_39 Depth 3
                                        ;         Child Loop BB160_57 Depth 4
	ldur	w8, [x29, #-164]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB160_80
	b	LBB160_4
LBB160_4:                               ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-160]
	add	x8, x8, #2608
	ldur	w9, [x29, #-164]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	stur	w8, [x29, #-168]
	ldur	w8, [x29, #-168]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB160_6
	b	LBB160_5
LBB160_5:                               ;   in Loop: Header=BB160_3 Depth=1
	ldur	w8, [x29, #-168]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbz	w8, #0, LBB160_7
	b	LBB160_6
LBB160_6:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_7:                               ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-144]
	mov	x9, #32880                      ; =0x8070
	add	x10, x8, x9
	ldur	w8, [x29, #-168]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-176]
	ldur	x0, [x29, #-176]
	ldur	x8, [x29, #-160]
	add	x10, x8, #48
	ldur	w8, [x29, #-168]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #36                         ; =0x24
	bl	_memcpy
	ldur	x8, [x29, #-152]
	ldr	x8, [x8, #72]
	ldur	w9, [x29, #-168]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w8, [x8, #28]
	ldur	x9, [x29, #-176]
	strh	w8, [x9, #36]
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #14]
	ldur	x9, [x29, #-176]
	strh	w8, [x9, #40]
	ldur	x9, [x29, #-176]
	mov	w8, #1                          ; =0x1
	strh	w8, [x9, #42]
	ldur	x9, [x29, #-176]
	strh	w8, [x9, #44]
	ldur	x8, [x29, #-176]
	strb	wzr, [x8, #80]
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-168]
	mov	w2, #0                          ; =0x0
	bl	_file_cyclic_site
	stur	x0, [x29, #-184]
	ldur	x8, [x29, #-184]
	cbz	x8, LBB160_10
	b	LBB160_8
LBB160_8:                               ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-184]
	ldrb	w8, [x8]
	cbz	w8, LBB160_10
	b	LBB160_9
LBB160_9:                               ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-184]
	ldr	x8, [x8, #8]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB160_11
	b	LBB160_10
LBB160_10:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_11:                              ;   in Loop: Header=BB160_3 Depth=1
	sturh	wzr, [x29, #-186]
	b	LBB160_12
LBB160_12:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB160_17 Depth 3
	ldurh	w8, [x29, #-186]
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB160_33
	b	LBB160_13
LBB160_13:                              ;   in Loop: Header=BB160_12 Depth=2
	ldur	x8, [x29, #-160]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-160]
	add	x8, x8, #2352
	ldur	w9, [x29, #-168]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-186]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #184]
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-168]
	ldurh	w2, [x29, #-186]
	bl	_file_cyclic_site
	str	x0, [sp, #176]
	ldr	x8, [sp, #176]
	cbz	x8, LBB160_15
	b	LBB160_14
LBB160_14:                              ;   in Loop: Header=BB160_12 Depth=2
	ldr	x8, [sp, #184]
	ldrb	w0, [x8, #8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_file_code_supported_mode
	tbnz	w0, #0, LBB160_16
	b	LBB160_15
LBB160_15:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_16:                              ;   in Loop: Header=BB160_12 Depth=2
	strb	wzr, [sp, #175]
	b	LBB160_17
LBB160_17:                              ;   Parent Loop BB160_3 Depth=1
                                        ;     Parent Loop BB160_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w8, [sp, #175]
	ldr	x9, [sp, #176]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB160_31
	b	LBB160_18
LBB160_18:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	x8, [sp, #176]
	add	x8, x8, #8
	ldrb	w9, [sp, #175]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x8, x8, #56
	str	x8, [sp, #160]
	ldur	x0, [x29, #-144]
	ldur	w1, [x29, #-168]
	ldurh	w2, [x29, #-186]
	ldr	x3, [sp, #184]
	ldr	x4, [sp, #160]
	bl	_file_ih_fact
	tbz	w0, #0, LBB160_21
	b	LBB160_19
LBB160_19:                              ;   in Loop: Header=BB160_17 Depth=3
	ldur	x0, [x29, #-176]
	ldr	x8, [sp, #160]
	ldr	x9, [x8]
	stur	x9, [x29, #-104]
	ldrh	w8, [x8, #8]
	sturh	w8, [x29, #-96]
	ldur	x1, [x29, #-104]
	ldur	x2, [x29, #-96]
	bl	_file_ih_peak
	tbz	w0, #0, LBB160_21
	b	LBB160_20
LBB160_20:                              ;   in Loop: Header=BB160_17 Depth=3
	ldur	x0, [x29, #-176]
	ldr	x8, [sp, #160]
	ldur	x9, [x8, #10]
	stur	x9, [x29, #-120]
	ldrh	w8, [x8, #18]
	sturh	w8, [x29, #-112]
	ldur	x1, [x29, #-120]
	ldur	x2, [x29, #-112]
	bl	_file_ih_peak
	tbnz	w0, #0, LBB160_22
	b	LBB160_21
LBB160_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_22:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	x8, [sp, #160]
	ldrb	w8, [x8, #23]
	tbz	w8, #0, LBB160_29
	b	LBB160_23
LBB160_23:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	x8, [sp, #160]
	ldr	w8, [x8, #44]
	subs	w8, w8, #1
	b.ne	LBB160_29
	b	LBB160_24
LBB160_24:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	x8, [sp, #160]
	ldrh	w8, [x8, #68]
	add	w8, w8, #1
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #184]
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	ldr	w8, [sp, #36]                   ; 4-byte Folded Reload
	add	w8, w8, w0
	str	w8, [sp, #156]
	ldr	w8, [sp, #156]
	subs	w8, w8, #258
	b.ls	LBB160_26
	b	LBB160_25
LBB160_25:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_26:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	w8, [sp, #156]
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #42]
	subs	w8, w8, w9
	b.ls	LBB160_28
	b	LBB160_27
LBB160_27:                              ;   in Loop: Header=BB160_17 Depth=3
	ldr	w8, [sp, #156]
	ldur	x9, [x29, #-176]
	strh	w8, [x9, #42]
	b	LBB160_28
LBB160_28:                              ;   in Loop: Header=BB160_17 Depth=3
	b	LBB160_29
LBB160_29:                              ;   in Loop: Header=BB160_17 Depth=3
	b	LBB160_30
LBB160_30:                              ;   in Loop: Header=BB160_17 Depth=3
	ldrb	w8, [sp, #175]
	add	w8, w8, #1
	strb	w8, [sp, #175]
	b	LBB160_17
LBB160_31:                              ;   in Loop: Header=BB160_12 Depth=2
	b	LBB160_32
LBB160_32:                              ;   in Loop: Header=BB160_12 Depth=2
	ldurh	w8, [x29, #-186]
	add	w8, w8, #1
	sturh	w8, [x29, #-186]
	b	LBB160_12
LBB160_33:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #36]
	cbz	w8, LBB160_36
	b	LBB160_34
LBB160_34:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #36]
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.ge	LBB160_36
	b	LBB160_35
LBB160_35:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_36:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #38]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #144]
	ldr	x8, [sp, #144]
	ldur	x9, [x29, #-176]
	str	x8, [x9, #72]
	ldur	x9, [x29, #-176]
	str	x8, [x9, #64]
	strh	wzr, [sp, #142]
	b	LBB160_37
LBB160_37:                              ;   Parent Loop BB160_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB160_39 Depth 3
                                        ;         Child Loop BB160_57 Depth 4
	ldrh	w8, [sp, #142]
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB160_74
	b	LBB160_38
LBB160_38:                              ;   in Loop: Header=BB160_37 Depth=2
	ldur	x8, [x29, #-144]
	ldr	x8, [x8]
	ldr	x0, [x8, #8]
	ldur	w1, [x29, #-168]
	ldrh	w2, [sp, #142]
	bl	_file_cyclic_site
	str	x0, [sp, #128]
	strb	wzr, [sp, #127]
	b	LBB160_39
LBB160_39:                              ;   Parent Loop BB160_3 Depth=1
                                        ;     Parent Loop BB160_37 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB160_57 Depth 4
	ldrb	w8, [sp, #127]
	ldr	x9, [sp, #128]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB160_72
	b	LBB160_40
LBB160_40:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #128]
	add	x8, x8, #8
	ldrb	w9, [sp, #127]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	add	x8, x8, #76
	str	x8, [sp, #112]
	ldr	x8, [sp, #112]
	ldrb	w8, [x8, #3]
	tbz	w8, #0, LBB160_42
	b	LBB160_41
LBB160_41:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #112]
	ldr	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB160_43
	b	LBB160_42
LBB160_42:                              ;   in Loop: Header=BB160_39 Depth=3
	b	LBB160_71
LBB160_43:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #112]
	add	x8, x8, #24
	str	x8, [sp, #104]
	ldur	x8, [x29, #-160]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-160]
	add	x8, x8, #2352
	ldur	w9, [x29, #-168]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #142]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	strb	w0, [sp, #103]
	ldrb	w8, [sp, #103]
	tbz	w8, #0, LBB160_45
	b	LBB160_44
LBB160_44:                              ;   in Loop: Header=BB160_39 Depth=3
	ldur	x8, [x29, #-144]
	add	x8, x8, #8
	ldur	x9, [x29, #-160]
	add	x9, x9, #2352
	ldur	w10, [x29, #-168]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #142]
	add	w9, w9, w10
	ldr	x8, [x8, w9, uxtw #3]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB160_49
LBB160_45:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #104]
	ldr	w8, [x8, #8]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB160_47
	b	LBB160_46
LBB160_46:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #104]
	ldr	w8, [x8, #8]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x8, x8, x9
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB160_48
LBB160_47:                              ;   in Loop: Header=BB160_39 Depth=3
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB160_48
LBB160_48:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB160_49
LBB160_49:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #88]
	ldr	x8, [sp, #88]
	cbz	x8, LBB160_53
	b	LBB160_50
LBB160_50:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #104]
	ldrh	w8, [x8, #28]
	ldr	x9, [sp, #104]
	ldrh	w9, [x9, #24]
	subs	w8, w8, w9
	b.gt	LBB160_53
	b	LBB160_51
LBB160_51:                              ;   in Loop: Header=BB160_39 Depth=3
	ldrb	w8, [sp, #103]
	tbz	w8, #0, LBB160_54
	b	LBB160_52
LBB160_52:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #104]
	ldr	w8, [x8, #8]
	adds	w8, w8, #1
	b.eq	LBB160_54
	b	LBB160_53
LBB160_53:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_54:                              ;   in Loop: Header=BB160_39 Depth=3
	ldr	x8, [sp, #104]
	ldrh	w8, [x8, #24]
	ldr	x9, [sp, #104]
	ldrh	w9, [x9, #28]
	subs	w8, w8, w9
	ldrb	w9, [sp, #103]
	and	w9, w9, #0x1
	add	w8, w8, w9
	str	w8, [sp, #84]
	ldr	w8, [sp, #84]
	ldr	x9, [sp, #112]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ls	LBB160_56
	b	LBB160_55
LBB160_55:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_56:                              ;   in Loop: Header=BB160_39 Depth=3
	str	wzr, [sp, #80]
	b	LBB160_57
LBB160_57:                              ;   Parent Loop BB160_3 Depth=1
                                        ;     Parent Loop BB160_37 Depth=2
                                        ;       Parent Loop BB160_39 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	w8, [sp, #80]
	ldur	x9, [x29, #-160]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB160_70
	b	LBB160_58
LBB160_58:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #88]
	ldr	w9, [sp, #80]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB160_68
	b	LBB160_59
LBB160_59:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	w8, [sp, #80]
	mov	x9, x8
	sub	x8, x29, #88
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB160_61
	b	LBB160_60
LBB160_60:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_61:                              ;   in Loop: Header=BB160_57 Depth=4
	ldur	x8, [x29, #-144]
	mov	x9, #32880                      ; =0x8070
	add	x10, x8, x9
	ldr	w8, [sp, #80]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #40]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #112]
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #42]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldr	x9, [sp, #72]
	ldr	x9, [x9, #64]
	add	x8, x8, x9
	str	x8, [sp, #64]
	ldr	x8, [sp, #144]
	ldr	x9, [sp, #72]
	ldr	x9, [x9, #72]
	add	x8, x8, x9
	str	x8, [sp, #56]
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-176]
	ldr	x9, [x9, #64]
	subs	x8, x8, x9
	b.ls	LBB160_63
	b	LBB160_62
LBB160_62:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #64]
	ldur	x9, [x29, #-176]
	str	x8, [x9, #64]
	b	LBB160_63
LBB160_63:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-176]
	ldr	x9, [x9, #72]
	subs	x8, x8, x9
	b.ls	LBB160_65
	b	LBB160_64
LBB160_64:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #56]
	ldur	x9, [x29, #-176]
	str	x8, [x9, #72]
	b	LBB160_65
LBB160_65:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #72]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-176]
	ldrh	w9, [x9, #44]
	subs	w8, w8, w9
	b.ls	LBB160_67
	b	LBB160_66
LBB160_66:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	x8, [sp, #72]
	ldrh	w8, [x8, #44]
	add	w8, w8, #1
	ldur	x9, [x29, #-176]
	strh	w8, [x9, #44]
	b	LBB160_67
LBB160_67:                              ;   in Loop: Header=BB160_57 Depth=4
	b	LBB160_68
LBB160_68:                              ;   in Loop: Header=BB160_57 Depth=4
	b	LBB160_69
LBB160_69:                              ;   in Loop: Header=BB160_57 Depth=4
	ldr	w8, [sp, #80]
	add	w8, w8, #1
	str	w8, [sp, #80]
	b	LBB160_57
LBB160_70:                              ;   in Loop: Header=BB160_39 Depth=3
	b	LBB160_71
LBB160_71:                              ;   in Loop: Header=BB160_39 Depth=3
	ldrb	w8, [sp, #127]
	add	w8, w8, #1
	strb	w8, [sp, #127]
	b	LBB160_39
LBB160_72:                              ;   in Loop: Header=BB160_37 Depth=2
	b	LBB160_73
LBB160_73:                              ;   in Loop: Header=BB160_37 Depth=2
	ldrh	w8, [sp, #142]
	add	w8, w8, #1
	strh	w8, [sp, #142]
	b	LBB160_37
LBB160_74:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldur	x9, [x29, #-176]
	str	w8, [x9, #52]
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #44]
	lsl	w8, w8, #8
	ldur	x9, [x29, #-176]
	str	w8, [x9, #56]
	ldur	x8, [x29, #-176]
	ldrh	w8, [x8, #44]
	subs	w8, w8, #64
	b.hi	LBB160_77
	b	LBB160_75
LBB160_75:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldr	x8, [x8, #64]
	mov	x9, #49280                      ; =0xc080
	subs	x8, x8, x9
	b.hi	LBB160_77
	b	LBB160_76
LBB160_76:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	x8, [x29, #-176]
	ldr	x8, [x8, #72]
	mov	x9, #49280                      ; =0xc080
	subs	x8, x8, x9
	b.ls	LBB160_78
	b	LBB160_77
LBB160_77:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-132]
	b	LBB160_97
LBB160_78:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	w8, [x29, #-168]
	mov	x9, x8
	sub	x8, x29, #88
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	b	LBB160_79
LBB160_79:                              ;   in Loop: Header=BB160_3 Depth=1
	ldur	w8, [x29, #-164]
	add	w8, w8, #1
	stur	w8, [x29, #-164]
	b	LBB160_3
LBB160_80:
	ldur	x8, [x29, #-144]
	mov	x9, #32784                      ; =0x8010
	add	x8, x8, x9
	ldr	w8, [x8, #4]
	stur	w8, [x29, #-128]
	ldur	x8, [x29, #-144]
	add	x8, x8, x9
	ldr	w8, [x8, #8]
	stur	w8, [x29, #-124]
	str	wzr, [sp, #52]
	b	LBB160_81
LBB160_81:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	subs	w8, w8, #2
	b.hs	LBB160_96
	b	LBB160_82
LBB160_82:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	w8, [sp, #52]
	mov	x9, x8
	sub	x8, x29, #128
	ldr	w8, [x8, x9, lsl #2]
	adds	w8, w8, #1
	b.eq	LBB160_94
	b	LBB160_83
LBB160_83:                              ;   in Loop: Header=BB160_81 Depth=1
	ldur	x8, [x29, #-144]
	mov	x9, #32880                      ; =0x8070
	add	x10, x8, x9
	ldr	w8, [sp, #52]
	mov	x9, x8
	sub	x8, x29, #128
	ldr	w8, [x8, x9, lsl #2]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.ls	LBB160_85
	b	LBB160_84
LBB160_84:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #64]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	x8, [x9, #24]
	b	LBB160_85
LBB160_85:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ls	LBB160_87
	b	LBB160_86
LBB160_86:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	x8, [x8, #72]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	x8, [x9, #32]
	b	LBB160_87
LBB160_87:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldrh	w9, [x9, #40]
	subs	w8, w8, w9
	b.le	LBB160_89
	b	LBB160_88
LBB160_88:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldrh	w8, [x8, #44]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	strh	w8, [x9, #40]
	b	LBB160_89
LBB160_89:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	w9, [x9, #44]
	subs	w8, w8, w9
	b.ls	LBB160_91
	b	LBB160_90
LBB160_90:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #52]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	w8, [x9, #44]
	b	LBB160_91
LBB160_91:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #56]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	w9, [x9, #48]
	subs	w8, w8, w9
	b.ls	LBB160_93
	b	LBB160_92
LBB160_92:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	x8, [sp, #40]
	ldr	w8, [x8, #56]
	ldur	x9, [x29, #-144]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	str	w8, [x9, #48]
	b	LBB160_93
LBB160_93:                              ;   in Loop: Header=BB160_81 Depth=1
	b	LBB160_94
LBB160_94:                              ;   in Loop: Header=BB160_81 Depth=1
	b	LBB160_95
LBB160_95:                              ;   in Loop: Header=BB160_81 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB160_81
LBB160_96:
	stur	wzr, [x29, #-132]
	b	LBB160_97
LBB160_97:
	ldur	w8, [x29, #-132]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB160_99
	b	LBB160_98
LBB160_98:
	bl	___stack_chk_fail
LBB160_99:
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_query_summary ; -- Begin function nvm_file_indirect_hosted_query_summary
	.p2align	2
_nvm_file_indirect_hosted_query_summary: ; @nvm_file_indirect_hosted_query_summary
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB161_2
	b	LBB161_1
LBB161_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldr	x1, [sp, #16]
	bl	_nvm_file_indirect_flow_summary
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB161_2
LBB161_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_startup ; -- Begin function nvm_file_indirect_hosted_startup
	.p2align	2
_nvm_file_indirect_hosted_startup:      ; @nvm_file_indirect_hosted_startup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	cbz	x8, LBB162_2
	b	LBB162_1
LBB162_1:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB162_3
	b	LBB162_2
LBB162_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB162_4
LBB162_3:
	ldr	x0, [sp, #8]
	ldr	x8, [sp, #16]
	mov	x9, #32784                      ; =0x8010
	add	x1, x8, x9
	mov	x2, #96                         ; =0x60
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB162_4
LBB162_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_function ; -- Begin function nvm_file_indirect_hosted_function
	.p2align	2
_nvm_file_indirect_hosted_function:     ; @nvm_file_indirect_hosted_function
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp, #16]
	str	w1, [sp, #12]
	str	x2, [sp]
	ldr	x8, [sp, #16]
	cbz	x8, LBB163_3
	b	LBB163_1
LBB163_1:
	ldr	x8, [sp]
	cbz	x8, LBB163_3
	b	LBB163_2
LBB163_2:
	ldr	w8, [sp, #12]
	ldr	x9, [sp, #16]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.lo	LBB163_4
	b	LBB163_3
LBB163_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB163_5
LBB163_4:
	ldr	x0, [sp]
	ldr	x8, [sp, #16]
	mov	x9, #32880                      ; =0x8070
	add	x10, x8, x9
	ldr	w8, [sp, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, #88                         ; =0x58
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #88                         ; =0x58
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB163_5
LBB163_5:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_function_order ; -- Begin function nvm_file_indirect_hosted_function_order
	.p2align	2
_nvm_file_indirect_hosted_function_order: ; @nvm_file_indirect_hosted_function_order
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB164_2
	b	LBB164_1
LBB164_1:
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_code_function_order
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB164_2
LBB164_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_local ; -- Begin function nvm_file_indirect_hosted_local
	.p2align	2
_nvm_file_indirect_hosted_local:        ; @nvm_file_indirect_hosted_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB165_2
	b	LBB165_1
LBB165_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_indirect_flow_local
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB165_2
LBB165_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_instruction ; -- Begin function nvm_file_indirect_hosted_instruction
	.p2align	2
_nvm_file_indirect_hosted_instruction:  ; @nvm_file_indirect_hosted_instruction
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB166_2
	b	LBB166_1
LBB166_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_indirect_flow_instruction
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB166_2
LBB166_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_component ; -- Begin function nvm_file_indirect_hosted_component
	.p2align	2
_nvm_file_indirect_hosted_component:    ; @nvm_file_indirect_hosted_component
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB167_2
	b	LBB167_1
LBB167_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_indirect_flow_component
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB167_2
LBB167_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_variant_count ; -- Begin function nvm_file_indirect_hosted_variant_count
	.p2align	2
_nvm_file_indirect_hosted_variant_count: ; @nvm_file_indirect_hosted_variant_count
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB168_2
	b	LBB168_1
LBB168_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldr	x3, [sp, #8]
	bl	_nvm_file_indirect_flow_variant_count
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB168_2
LBB168_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_variant ; -- Begin function nvm_file_indirect_hosted_variant
	.p2align	2
_nvm_file_indirect_hosted_variant:      ; @nvm_file_indirect_hosted_variant
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	str	x4, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB169_2
	b	LBB169_1
LBB169_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldr	x4, [sp, #8]
	bl	_nvm_file_indirect_flow_variant
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB169_2
LBB169_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_input_local ; -- Begin function nvm_file_indirect_hosted_input_local
	.p2align	2
_nvm_file_indirect_hosted_input_local:  ; @nvm_file_indirect_hosted_input_local
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB170_2
	b	LBB170_1
LBB170_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_indirect_flow_input_local
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB170_2
LBB170_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_input_stack ; -- Begin function nvm_file_indirect_hosted_input_stack
	.p2align	2
_nvm_file_indirect_hosted_input_stack:  ; @nvm_file_indirect_hosted_input_stack
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB171_2
	b	LBB171_1
LBB171_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_indirect_flow_input_stack
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB171_2
LBB171_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_input_reference ; -- Begin function nvm_file_indirect_hosted_input_reference
	.p2align	2
_nvm_file_indirect_hosted_input_reference: ; @nvm_file_indirect_hosted_input_reference
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB172_2
	b	LBB172_1
LBB172_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_indirect_flow_input_reference
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB172_2
LBB172_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_input_region ; -- Begin function nvm_file_indirect_hosted_input_region
	.p2align	2
_nvm_file_indirect_hosted_input_region: ; @nvm_file_indirect_hosted_input_region
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	sturh	w2, [x29, #-14]
	sturb	w3, [x29, #-15]
	sturh	w4, [x29, #-18]
	str	x5, [sp, #16]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	cbz	x8, LBB173_2
	b	LBB173_1
LBB173_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldurh	w2, [x29, #-14]
	ldurb	w3, [x29, #-15]
	ldurh	w4, [x29, #-18]
	ldr	x5, [sp, #16]
	bl	_nvm_file_indirect_flow_input_region
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB173_2
LBB173_2:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_type  ; -- Begin function nvm_file_indirect_hosted_type
	.p2align	2
_nvm_file_indirect_hosted_type:         ; @nvm_file_indirect_hosted_type
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB174_2
	b	LBB174_1
LBB174_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_indirect_flow_type
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB174_2
LBB174_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_import ; -- Begin function nvm_file_indirect_hosted_import
	.p2align	2
_nvm_file_indirect_hosted_import:       ; @nvm_file_indirect_hosted_import
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	w1, [x29, #-12]
	str	x2, [sp, #8]
	ldur	x8, [x29, #-8]
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	cbz	x8, LBB175_2
	b	LBB175_1
LBB175_1:
	ldur	x8, [x29, #-8]
	ldr	x0, [x8]
	ldur	w1, [x29, #-12]
	ldr	x2, [sp, #8]
	bl	_nvm_file_indirect_flow_import
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	b	LBB175_2
LBB175_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_bytes ; -- Begin function nvm_file_indirect_hosted_bytes
	.p2align	2
_nvm_file_indirect_hosted_bytes:        ; @nvm_file_indirect_hosted_bytes
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	str	x3, [sp, #8]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB176_5
	b	LBB176_1
LBB176_1:
	ldr	x8, [sp, #8]
	cbz	x8, LBB176_3
	b	LBB176_2
LBB176_2:
	ldr	x8, [sp, #16]
	cbz	x8, LBB176_5
	b	LBB176_3
LBB176_3:
	ldr	x8, [sp, #24]
	ldur	x9, [x29, #-16]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hi	LBB176_5
	b	LBB176_4
LBB176_4:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	x9, [x9, #56]
	ldr	x10, [sp, #24]
	subs	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB176_6
	b	LBB176_5
LBB176_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB176_9
LBB176_6:
	ldr	x8, [sp, #8]
	cbz	x8, LBB176_8
	b	LBB176_7
LBB176_7:
	ldr	x0, [sp, #16]
	ldur	x8, [x29, #-16]
	mov	x9, #32776                      ; =0x8008
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #24]
	add	x1, x8, x9
	ldr	x2, [sp, #8]
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memcpy_chk
	b	LBB176_8
LBB176_8:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB176_9
LBB176_9:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_call  ; -- Begin function nvm_file_indirect_hosted_call
	.p2align	2
_nvm_file_indirect_hosted_call:         ; @nvm_file_indirect_hosted_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	add	x29, sp, #256
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	sturh	w2, [x29, #-38]
	sturb	w3, [x29, #-39]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-32]
	cbz	x8, LBB177_4
	b	LBB177_1
LBB177_1:
	ldur	x8, [x29, #-48]
	cbz	x8, LBB177_4
	b	LBB177_2
LBB177_2:
	ldur	w8, [x29, #-36]
	ldur	x9, [x29, #-32]
	mov	x10, #32784                     ; =0x8010
	add	x9, x9, x10
	ldr	w9, [x9, #12]
	subs	w8, w8, w9
	b.hs	LBB177_4
	b	LBB177_3
LBB177_3:
	ldurh	w8, [x29, #-38]
	ldur	x9, [x29, #-32]
	mov	x10, #32880                     ; =0x8070
	add	x11, x9, x10
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	mov	x10, #88                        ; =0x58
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB177_5
	b	LBB177_4
LBB177_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB177_9
LBB177_5:
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x8, [x8, #8]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-38]
	add	w8, w8, w9
	str	w8, [sp, #100]
	ldur	x8, [x29, #-32]
	add	x8, x8, #8
	ldr	w9, [sp, #100]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbz	x8, LBB177_7
	b	LBB177_6
LBB177_6:
	ldur	x8, [x29, #-32]
	ldr	x0, [x8]
	ldur	w1, [x29, #-36]
	ldurh	w2, [x29, #-38]
	ldurb	w3, [x29, #-39]
	add	x4, sp, #104
	bl	_nvm_file_indirect_flow_variant
	tbnz	w0, #0, LBB177_8
	b	LBB177_7
LBB177_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB177_9
LBB177_8:
	ldur	x8, [x29, #-48]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	w9, [x29, #-36]
	add	x8, sp, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	w9, [sp, #16]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	ldr	x9, [x9, #8]
	ldr	x9, [x9]
	ldr	x9, [x9, #16]
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	mov	x11, #600                       ; =0x258
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldr	w9, [x9, x10]
	str	w9, [sp, #20]
	ldur	x9, [x29, #-32]
	add	x9, x9, #8
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	str	x9, [sp, #24]
	ldur	x9, [x29, #-32]
	add	x9, x9, #8
	ldr	w10, [sp, #100]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	str	x9, [sp, #32]
	add	x0, x8, #24
	add	x8, sp, #104
	add	x1, x8, #44
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #80                         ; =0x50
	bl	_memcpy
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB177_9
LBB177_9:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_nvm_file_indirect_hosted_string ; -- Begin function nvm_file_indirect_hosted_string
	.p2align	2
_nvm_file_indirect_hosted_string:       ; @nvm_file_indirect_hosted_string
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-16]
	cbz	x8, LBB178_3
	b	LBB178_1
LBB178_1:
	ldur	x8, [x29, #-32]
	cbz	x8, LBB178_3
	b	LBB178_2
LBB178_2:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB178_4
	b	LBB178_3
LBB178_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_4:
	ldur	x8, [x29, #-16]
	mov	x9, #32776                      ; =0x8008
	ldr	x0, [x8, x9]
	ldur	x8, [x29, #-16]
	mov	x9, #32784                      ; =0x8010
	add	x8, x8, x9
	ldr	x1, [x8, #56]
	add	x2, sp, #88
	bl	_nvm_v2_read_header
	cbz	w0, LBB178_6
	b	LBB178_5
LBB178_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_6:
	str	wzr, [sp, #84]
	b	LBB178_7
LBB178_7:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB178_16 Depth 2
	ldr	w8, [sp, #84]
	ldr	w9, [sp, #116]
	subs	w8, w8, w9
	b.hs	LBB178_33
	b	LBB178_8
LBB178_8:                               ;   in Loop: Header=BB178_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #32776                      ; =0x8008
	ldr	x0, [x8, x9]
	ldur	x8, [x29, #-16]
	mov	x9, #32784                      ; =0x8010
	add	x8, x8, x9
	ldr	x1, [x8, #56]
	ldr	w3, [sp, #84]
	add	x2, sp, #88
	add	x4, sp, #56
	bl	_nvm_v2_read_section
	cbz	w0, LBB178_10
	b	LBB178_9
LBB178_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_10:                              ;   in Loop: Header=BB178_7 Depth=1
	ldr	w8, [sp, #56]
	subs	w8, w8, #2
	b.eq	LBB178_12
	b	LBB178_11
LBB178_11:                              ;   in Loop: Header=BB178_7 Depth=1
	b	LBB178_32
LBB178_12:                              ;   in Loop: Header=BB178_7 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #32776                      ; =0x8008
	ldr	x8, [x8, x9]
	ldr	x9, [sp, #64]
	add	x1, x8, x9
	ldr	x2, [sp, #72]
	add	x0, sp, #32
	str	x0, [sp]                        ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	add	x1, sp, #28
	bl	_nvm_v2_u32
	cbnz	w0, LBB178_14
	b	LBB178_13
LBB178_13:                              ;   in Loop: Header=BB178_7 Depth=1
	ldur	w8, [x29, #-20]
	ldr	w9, [sp, #28]
	subs	w8, w8, w9
	b.lo	LBB178_15
	b	LBB178_14
LBB178_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_15:                              ;   in Loop: Header=BB178_7 Depth=1
	str	wzr, [sp, #24]
	b	LBB178_16
LBB178_16:                              ;   Parent Loop BB178_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #24]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.hi	LBB178_31
	b	LBB178_17
LBB178_17:                              ;   in Loop: Header=BB178_16 Depth=2
	add	x0, sp, #32
	add	x1, sp, #23
	bl	_nvm_v2_u8
	cbnz	w0, LBB178_26
	b	LBB178_18
LBB178_18:                              ;   in Loop: Header=BB178_16 Depth=2
	add	x0, sp, #32
	add	x1, sp, #22
	bl	_nvm_v2_u8
	cbnz	w0, LBB178_26
	b	LBB178_19
LBB178_19:                              ;   in Loop: Header=BB178_16 Depth=2
	add	x0, sp, #32
	add	x1, sp, #20
	bl	_nvm_v2_u16
	cbnz	w0, LBB178_26
	b	LBB178_20
LBB178_20:                              ;   in Loop: Header=BB178_16 Depth=2
	add	x0, sp, #32
	add	x1, sp, #16
	bl	_nvm_v2_u32
	cbnz	w0, LBB178_26
	b	LBB178_21
LBB178_21:                              ;   in Loop: Header=BB178_16 Depth=2
	ldrb	w8, [sp, #23]
	subs	w8, w8, #5
	b.ne	LBB178_26
	b	LBB178_22
LBB178_22:                              ;   in Loop: Header=BB178_16 Depth=2
	ldrb	w8, [sp, #22]
	cbnz	w8, LBB178_26
	b	LBB178_23
LBB178_23:                              ;   in Loop: Header=BB178_16 Depth=2
	ldrh	w8, [sp, #20]
	cbnz	w8, LBB178_26
	b	LBB178_24
LBB178_24:                              ;   in Loop: Header=BB178_16 Depth=2
	ldr	w8, [sp, #16]
	mov	x1, x8
	add	x0, sp, #32
	add	x2, sp, #8
	bl	_nvm_v2_take
	cbnz	w0, LBB178_26
	b	LBB178_25
LBB178_25:                              ;   in Loop: Header=BB178_16 Depth=2
	add	x0, sp, #32
	bl	_nvm_v2_align4
	cbz	w0, LBB178_27
	b	LBB178_26
LBB178_26:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_27:                              ;   in Loop: Header=BB178_16 Depth=2
	ldr	w8, [sp, #24]
	ldur	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ne	LBB178_29
	b	LBB178_28
LBB178_28:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-32]
	str	x8, [x9]
	ldr	w8, [sp, #16]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-40]
	str	x8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_29:                              ;   in Loop: Header=BB178_16 Depth=2
	b	LBB178_30
LBB178_30:                              ;   in Loop: Header=BB178_16 Depth=2
	ldr	w8, [sp, #24]
	add	w8, w8, #1
	str	w8, [sp, #24]
	b	LBB178_16
LBB178_31:                              ;   in Loop: Header=BB178_7 Depth=1
	b	LBB178_32
LBB178_32:                              ;   in Loop: Header=BB178_7 Depth=1
	ldr	w8, [sp, #84]
	add	w8, w8, #1
	str	w8, [sp, #84]
	b	LBB178_7
LBB178_33:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB178_34
LBB178_34:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function nominal_status
_nominal_status:                        ; @nominal_status
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	w0, [sp, #8]
	ldr	w8, [sp, #8]
	str	w8, [sp, #4]                    ; 4-byte Folded Spill
	cbz	w8, LBB179_3
	b	LBB179_1
LBB179_1:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #2
	b.eq	LBB179_4
	b	LBB179_2
LBB179_2:
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	subs	w8, w8, #3
	b.eq	LBB179_5
	b	LBB179_6
LBB179_3:
	str	wzr, [sp, #12]
	b	LBB179_7
LBB179_4:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #12]
	b	LBB179_7
LBB179_5:
	mov	w8, #4                          ; =0x4
	str	w8, [sp, #12]
	b	LBB179_7
LBB179_6:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	b	LBB179_7
LBB179_7:
	ldr	w0, [sp, #12]
	add	sp, sp, #16
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function read_declaration
_read_declaration:                      ; @read_declaration
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	ldur	x0, [x29, #-16]
	sub	x1, x29, #34
	bl	_nvm_v2_u8
	cbnz	w0, LBB180_5
	b	LBB180_1
LBB180_1:
	ldur	x0, [x29, #-16]
	sub	x1, x29, #35
	bl	_nvm_v2_u8
	cbnz	w0, LBB180_5
	b	LBB180_2
LBB180_2:
	ldur	x0, [x29, #-16]
	sub	x1, x29, #38
	bl	_nvm_v2_u16
	cbnz	w0, LBB180_5
	b	LBB180_3
LBB180_3:
	ldur	x0, [x29, #-16]
	add	x1, sp, #36
	bl	_nvm_v2_u32
	cbnz	w0, LBB180_5
	b	LBB180_4
LBB180_4:
	ldurh	w8, [x29, #-38]
	cbz	w8, LBB180_6
	b	LBB180_5
LBB180_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB180_25
LBB180_6:
	ldurb	w0, [x29, #-34]
	bl	_scalar_type
	stur	x0, [sp, #20]
	stur	x1, [sp, #28]
	ldurb	w8, [x29, #-35]
	strb	w8, [sp, #21]
	ldr	w8, [sp, #36]
	str	w8, [sp, #24]
	ldr	w8, [sp, #36]
	adds	w8, w8, #1
	b.ne	LBB180_13
	b	LBB180_7
LBB180_7:
	ldurb	w8, [x29, #-35]
	cbnz	w8, LBB180_11
	b	LBB180_8
LBB180_8:
	ldurb	w0, [x29, #-34]
	bl	_scalar
	tbnz	w0, #0, LBB180_12
	b	LBB180_9
LBB180_9:
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB180_11
	b	LBB180_10
LBB180_10:
	ldurb	w8, [x29, #-34]
	subs	w8, w8, #11
	b.eq	LBB180_12
	b	LBB180_11
LBB180_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB180_25
LBB180_12:
	b	LBB180_24
LBB180_13:
	ldur	x0, [x29, #-24]
	ldr	w1, [sp, #36]
	mov	x2, sp
	bl	_nvm_file_nominal_layout
	tbnz	w0, #0, LBB180_15
	b	LBB180_14
LBB180_14:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB180_25
LBB180_15:
	ldr	w8, [sp, #16]
	cbnz	w8, LBB180_17
	b	LBB180_16
LBB180_16:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB180_25
LBB180_17:
	ldr	w8, [sp, #4]
	str	w8, [sp, #28]
	ldr	w8, [sp, #16]
	str	w8, [sp, #32]
	ldurb	w8, [x29, #-35]
	cbz	w8, LBB180_21
	b	LBB180_18
LBB180_18:
	ldurb	w8, [x29, #-35]
	subs	w8, w8, #1
	b.eq	LBB180_20
	b	LBB180_19
LBB180_19:
	ldurb	w8, [x29, #-35]
	subs	w8, w8, #2
	b.ne	LBB180_22
	b	LBB180_20
LBB180_20:
	ldr	w8, [sp, #32]
	subs	w8, w8, #1
	b.ne	LBB180_22
	b	LBB180_21
LBB180_21:
	ldurb	w8, [x29, #-34]
	ldrb	w11, [sp, #12]
	mov	w10, #10                        ; =0xa
	mov	w9, #8                          ; =0x8
	subs	w11, w11, #0
	csel	w9, w9, w10, eq
	subs	w8, w8, w9
	b.eq	LBB180_23
	b	LBB180_22
LBB180_22:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB180_25
LBB180_23:
	b	LBB180_24
LBB180_24:
	ldur	x8, [x29, #-32]
	ldur	q0, [sp, #20]
	str	q0, [x8]
	stur	wzr, [x29, #-4]
	b	LBB180_25
LBB180_25:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_room
_file_body_room:                        ; @file_body_room
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	add	x0, sp, #8
	str	x8, [sp, #8]
	ldr	x1, [sp, #16]
	mov	x2, #47152                      ; =0xb830
	bl	_file_code_budget
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_transfer
_file_body_transfer:                    ; @file_body_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #656
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #120]
	str	x1, [sp, #112]
	str	x2, [sp, #104]
	str	x3, [sp, #96]
	ldr	x8, [sp, #104]
	add	x8, x8, #8
	str	x8, [sp, #88]
	ldr	x8, [sp, #88]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #86]
	ldr	x8, [sp, #88]
	ldrb	w8, [x8]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB182_49
; %bb.1:
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	adrp	x10, lJTI182_0@PAGE
	add	x10, x10, lJTI182_0@PAGEOFF
Ltmp26:
	adr	x8, Ltmp26
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB182_2:
	str	wzr, [sp, #132]
	b	LBB182_59
LBB182_3:
	ldr	x0, [sp, #112]
	mov	w1, #5                          ; =0x5
	bl	_nvm_file_flow_push_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_4:
	ldr	x0, [sp, #112]
	mov	w1, #5                          ; =0x5
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_5:
	ldr	x0, [sp, #112]
	mov	w1, #5                          ; =0x5
	mov	w3, #1                          ; =0x1
	mov	x2, x3
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_6:
	ldr	x0, [sp, #112]
	mov	w1, #1                          ; =0x1
	bl	_nvm_file_flow_push_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_7:
	ldr	x0, [sp, #112]
	mov	w1, #4                          ; =0x4
	bl	_nvm_file_flow_push_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_8:
	ldr	x0, [sp, #112]
	mov	w1, #0                          ; =0x0
	bl	_nvm_file_flow_push_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_9:
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_dup
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_10:
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_pop
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_11:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_load
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_12:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_store
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_13:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_take
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_14:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_put
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_15:
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_region_begin
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_16:
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_region_end
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_17:
	ldr	x0, [sp, #112]
	ldr	x8, [sp, #88]
	ldrh	w1, [x8, #16]
	ldrh	w2, [sp, #86]
	bl	_nvm_file_flow_borrow_shared
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_18:
	ldr	x0, [sp, #112]
	ldr	x8, [sp, #88]
	ldrh	w1, [x8, #16]
	ldrh	w2, [sp, #86]
	bl	_nvm_file_flow_borrow
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_19:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_end_borrow
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_20:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	ldr	x8, [sp, #88]
	ldrb	w10, [x8, #16]
	mov	w8, #3                          ; =0x3
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #0
	csel	w2, w8, w9, ne
	bl	_nvm_file_flow_take_result
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_21:
	ldr	x9, [sp, #96]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #12]
	ldrh	w8, [sp, #86]
	ldr	x9, [sp, #96]
	strh	w8, [x9, #8]
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	bl	_nvm_file_flow_drop_local
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_22:
	ldr	x9, [sp, #96]
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #12]
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_drop_stack
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_23:
	ldr	x0, [sp, #112]
	bl	_nvm_file_flow_can_exit
	str	w0, [sp, #80]
	ldr	w8, [sp, #80]
	subs	w8, w8, #0
	cset	w8, eq
	ldr	x9, [sp, #96]
	strb	w8, [x9, #1]
	ldr	x9, [sp, #96]
	mov	w8, #4                          ; =0x4
	str	w8, [x9, #12]
	ldr	w8, [sp, #80]
	str	w8, [sp, #132]
	b	LBB182_59
LBB182_24:
	ldr	x9, [sp, #96]
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #12]
	ldr	x0, [sp, #112]
	mov	w1, #4                          ; =0x4
	mov	w2, #16                         ; =0x10
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_25:
	ldr	x0, [sp, #112]
	mov	w1, #4                          ; =0x4
	mov	w2, #16                         ; =0x10
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_26:
	ldr	x0, [sp, #112]
	mov	w2, #1                          ; =0x1
	mov	x1, x2
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_27:
	ldr	x0, [sp, #112]
	mov	w3, #1                          ; =0x1
	mov	x1, x3
	mov	x2, x3
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_28:
	ldr	x0, [sp, #112]
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_29:
	ldr	x0, [sp, #112]
	mov	w1, #1                          ; =0x1
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_30:
	ldr	x0, [sp, #112]
	mov	w2, #4                          ; =0x4
	mov	x1, x2
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_31:
	ldr	x0, [sp, #112]
	mov	w2, #4                          ; =0x4
	mov	x1, x2
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_file_body_scalar
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_32:
	ldr	x0, [sp, #112]
	ldr	x8, [sp, #104]
	ldr	w1, [x8, #592]
	ldr	x8, [sp, #88]
	add	x8, x8, #8
	ldr	x9, [sp, #88]
	ldrb	w10, [x9]
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #251
	csinc	w10, w9, wzr, eq
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	lsl	x9, x9, #3
	ldrh	w2, [x8, x9]
	bl	_nvm_file_flow_construct
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_33:
	ldr	x0, [sp, #112]
	ldrh	w1, [sp, #86]
	ldr	x8, [sp, #88]
	ldrb	w8, [x8]
	subs	w8, w8, #252
	cset	w3, eq
	mov	w8, #0                          ; =0x0
	and	w2, w8, #0x1
	bl	_file_body_projection
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_34:
	ldr	x0, [sp, #112]
	mov	w8, #0                          ; =0x0
	mov	x1, x8
	mov	w9, #1                          ; =0x1
	and	w2, w9, #0x1
	and	w3, w8, #0x1
	bl	_file_body_projection
	str	w0, [sp, #132]
	b	LBB182_59
LBB182_35:
	ldr	x9, [sp, #96]
	mov	w8, #6                          ; =0x6
	str	w8, [x9, #12]
	ldr	x0, [sp, #112]
	ldr	x8, [sp, #104]
	ldr	w1, [x8]
	ldr	x8, [sp, #88]
	ldr	w2, [x8, #8]
	ldr	x8, [sp, #88]
	ldrh	w3, [x8, #16]
	bl	_nvm_file_flow_service
	str	w0, [sp, #80]
	b	LBB182_50
LBB182_36:
	ldr	x8, [sp, #88]
	ldr	w8, [x8, #8]
	str	w8, [sp, #76]
	ldr	w8, [sp, #76]
	ldr	x9, [sp, #120]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB182_38
	b	LBB182_37
LBB182_37:
	ldr	x8, [sp, #120]
	add	x8, x8, #16
	ldr	w9, [sp, #76]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB182_39
	b	LBB182_38
LBB182_38:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #132]
	b	LBB182_59
LBB182_39:
	ldr	x8, [sp, #120]
	ldr	x8, [x8]
	add	x10, x8, #48
	ldr	w8, [sp, #76]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #64]
	strh	wzr, [sp, #62]
	b	LBB182_40
LBB182_40:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #62]
	ldr	x9, [sp, #64]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB182_46
	b	LBB182_41
LBB182_41:                              ;   in Loop: Header=BB182_40 Depth=1
	ldr	x8, [sp, #112]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldr	x9, [sp, #112]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldr	w10, [sp, #76]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #62]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	str	q0, [sp, #32]
	ldrb	w8, [sp, #33]
	cbz	w8, LBB182_43
	b	LBB182_42
LBB182_42:                              ;   in Loop: Header=BB182_40 Depth=1
	ldr	x8, [sp, #104]
	add	x8, x8, #78
	ldrh	w9, [sp, #62]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB182_44
LBB182_43:                              ;   in Loop: Header=BB182_40 Depth=1
	mov	w8, #65535                      ; =0xffff
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB182_44
LBB182_44:                              ;   in Loop: Header=BB182_40 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	ldrh	w9, [sp, #62]
	mov	x10, x9
	add	x9, sp, #136
	strh	w8, [x9, x10, lsl #1]
	b	LBB182_45
LBB182_45:                              ;   in Loop: Header=BB182_40 Depth=1
	ldrh	w8, [sp, #62]
	add	w8, w8, #1
	strh	w8, [sp, #62]
	b	LBB182_40
LBB182_46:
	ldr	x9, [sp, #96]
	mov	w8, #5                          ; =0x5
	str	w8, [x9, #12]
	ldr	x0, [sp, #112]
	ldr	x8, [sp, #104]
	ldr	w1, [x8]
	ldr	w2, [sp, #76]
	ldr	x8, [sp, #64]
	ldrh	w4, [x8]
	add	x3, sp, #136
	bl	_nvm_file_flow_call
	str	w0, [sp, #80]
	ldr	w8, [sp, #80]
	cbnz	w8, LBB182_48
	b	LBB182_47
LBB182_47:
	ldr	x9, [sp, #96]
	mov	w8, #64                         ; =0x40
	str	w8, [x9, #16]
	b	LBB182_48
LBB182_48:
	b	LBB182_50
LBB182_49:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #132]
	b	LBB182_59
LBB182_50:
	ldr	w8, [sp, #80]
	cbz	w8, LBB182_52
	b	LBB182_51
LBB182_51:
	ldr	w8, [sp, #80]
	str	w8, [sp, #132]
	b	LBB182_59
LBB182_52:
	strh	wzr, [sp, #30]
	b	LBB182_53
LBB182_53:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #112]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB182_58
	b	LBB182_54
LBB182_54:                              ;   in Loop: Header=BB182_53 Depth=1
	ldr	x8, [sp, #112]
	add	x10, x8, #44
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	w8, [x8, #4]
	ldr	x9, [sp, #104]
	ldr	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB182_56
	b	LBB182_55
LBB182_55:
	ldr	x9, [sp, #96]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #3]
	ldr	x8, [sp, #96]
	add	x0, x8, #24
	ldr	x8, [sp, #112]
	add	x10, x8, #44
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	mov	x2, #56                         ; =0x38
	bl	_memcpy
	ldr	x8, [sp, #96]
	ldr	w8, [x8, #36]
	ldr	x9, [sp, #96]
	ldr	w9, [x9, #16]
	bic	w10, w8, w9
	ldr	x9, [sp, #96]
	ldr	w8, [x9, #20]
	orr	w8, w8, w10
	str	w8, [x9, #20]
	str	wzr, [sp, #132]
	b	LBB182_59
LBB182_56:                              ;   in Loop: Header=BB182_53 Depth=1
	b	LBB182_57
LBB182_57:                              ;   in Loop: Header=BB182_53 Depth=1
	ldrh	w8, [sp, #30]
	add	w8, w8, #1
	strh	w8, [sp, #30]
	b	LBB182_53
LBB182_58:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #132]
	b	LBB182_59
LBB182_59:
	ldr	w8, [sp, #132]
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB182_61
	b	LBB182_60
LBB182_60:
	bl	___stack_chk_fail
LBB182_61:
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	add	sp, sp, #656
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI182_0:
	.long	LBB182_2-Ltmp26
	.long	LBB182_6-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_7-Ltmp26
	.long	LBB182_3-Ltmp26
	.long	LBB182_8-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_9-Ltmp26
	.long	LBB182_10-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_13-Ltmp26
	.long	LBB182_14-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_36-Ltmp26
	.long	LBB182_11-Ltmp26
	.long	LBB182_12-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_15-Ltmp26
	.long	LBB182_16-Ltmp26
	.long	LBB182_17-Ltmp26
	.long	LBB182_18-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_27-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_28-Ltmp26
	.long	LBB182_28-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_30-Ltmp26
	.long	LBB182_30-Ltmp26
	.long	LBB182_31-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_2-Ltmp26
	.long	LBB182_25-Ltmp26
	.long	LBB182_25-Ltmp26
	.long	LBB182_36-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_23-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_5-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_4-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_32-Ltmp26
	.long	LBB182_34-Ltmp26
	.long	LBB182_33-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_35-Ltmp26
	.long	LBB182_2-Ltmp26
	.long	LBB182_20-Ltmp26
	.long	LBB182_21-Ltmp26
	.long	LBB182_22-Ltmp26
	.long	LBB182_19-Ltmp26
	.long	LBB182_36-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_24-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_26-Ltmp26
	.long	LBB182_27-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_29-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_32-Ltmp26
	.long	LBB182_33-Ltmp26
	.long	LBB182_49-Ltmp26
	.long	LBB182_34-Ltmp26
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_clone
_file_body_clone:                       ; @file_body_clone
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x0, [x29, #-16]
	mov	x1, #1                          ; =0x1
	bl	_file_body_room
	tbnz	w0, #0, LBB183_2
	b	LBB183_1
LBB183_1:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB183_5
LBB183_2:
	ldr	x0, [sp, #24]
	ldr	x1, [sp, #16]
	bl	_nvm_file_flow_clone
	str	w0, [sp, #12]
	ldr	w8, [sp, #12]
	cbnz	w8, LBB183_4
	b	LBB183_3
LBB183_3:
	ldur	x9, [x29, #-16]
	ldr	x8, [x9]
	mov	x10, #47152                     ; =0xb830
	add	x8, x8, x10
	str	x8, [x9]
	b	LBB183_4
LBB183_4:
	ldr	w8, [sp, #12]
	stur	w8, [x29, #-4]
	b	LBB183_5
LBB183_5:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_scalar
_file_body_scalar:                      ; @file_body_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	sturb	w2, [x29, #-18]
	sturh	w3, [x29, #-20]
	sturb	w4, [x29, #-21]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ge	LBB184_2
	b	LBB184_1
LBB184_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB184_28
LBB184_2:
	sturh	wzr, [x29, #-24]
	b	LBB184_3
LBB184_3:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-24]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ge	LBB184_21
	b	LBB184_4
LBB184_4:                               ;   in Loop: Header=BB184_3 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	ldurh	w9, [x29, #-24]
	add	w8, w8, w9
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	sub	x0, x29, #64
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldurb	w8, [x29, #-48]
	tbz	w8, #0, LBB184_7
	b	LBB184_5
LBB184_5:                               ;   in Loop: Header=BB184_3 Depth=1
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB184_7
	b	LBB184_6
LBB184_6:                               ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w0, [x29, #-64]
	bl	_scalar_type
	stur	x0, [x29, #-80]
	stur	x1, [x29, #-72]
	ldur	x0, [x29, #-64]
	ldur	x1, [x29, #-56]
	ldur	x2, [x29, #-80]
	ldur	x3, [x29, #-72]
	bl	_same
	tbnz	w0, #0, LBB184_8
	b	LBB184_7
LBB184_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB184_28
LBB184_8:                               ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w8, [x29, #-21]
	tbz	w8, #0, LBB184_16
	b	LBB184_9
LBB184_9:                               ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w8, [x29, #-64]
	subs	w8, w8, #1
	b.eq	LBB184_12
	b	LBB184_10
LBB184_10:                              ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w8, [x29, #-64]
	subs	w8, w8, #4
	b.eq	LBB184_12
	b	LBB184_11
LBB184_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB184_28
LBB184_12:                              ;   in Loop: Header=BB184_3 Depth=1
	ldurh	w8, [x29, #-24]
	cbz	w8, LBB184_15
	b	LBB184_13
LBB184_13:                              ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w8, [x29, #-64]
	ldur	x9, [x29, #-16]
	mov	x10, #24624                     ; =0x6030
	add	x9, x9, x10
	ldur	x10, [x29, #-16]
	ldrh	w10, [x10, #12]
	ldurh	w11, [x29, #-20]
	subs	w10, w10, w11
	mov	w11, #40                        ; =0x28
	smull	x10, w10, w11
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.eq	LBB184_15
	b	LBB184_14
LBB184_14:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB184_28
LBB184_15:                              ;   in Loop: Header=BB184_3 Depth=1
	b	LBB184_19
LBB184_16:                              ;   in Loop: Header=BB184_3 Depth=1
	ldurb	w8, [x29, #-64]
	ldurb	w9, [x29, #-17]
	subs	w8, w8, w9
	b.eq	LBB184_18
	b	LBB184_17
LBB184_17:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB184_28
LBB184_18:                              ;   in Loop: Header=BB184_3 Depth=1
	b	LBB184_19
LBB184_19:                              ;   in Loop: Header=BB184_3 Depth=1
	b	LBB184_20
LBB184_20:                              ;   in Loop: Header=BB184_3 Depth=1
	ldurh	w8, [x29, #-24]
	add	w8, w8, #1
	sturh	w8, [x29, #-24]
	b	LBB184_3
LBB184_21:
	sturh	wzr, [x29, #-82]
	b	LBB184_22
LBB184_22:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-82]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ge	LBB184_25
	b	LBB184_23
LBB184_23:                              ;   in Loop: Header=BB184_22 Depth=1
	ldur	x0, [x29, #-16]
	bl	_pop
	b	LBB184_24
LBB184_24:                              ;   in Loop: Header=BB184_22 Depth=1
	ldurh	w8, [x29, #-82]
	add	w8, w8, #1
	sturh	w8, [x29, #-82]
	b	LBB184_22
LBB184_25:
	ldurb	w8, [x29, #-18]
	subs	w8, w8, #16
	b.eq	LBB184_27
	b	LBB184_26
LBB184_26:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x11, [x29, #-16]
	ldrh	w8, [x11, #12]
                                        ; kill: def $x8 killed $w8
	mov	x9, x8
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #12]                  ; 4-byte Folded Spill
	add	w9, w9, #1
	strh	w9, [x11, #12]
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldurb	w0, [x29, #-18]
	bl	_scalar_type
	ldr	w9, [sp, #12]                   ; 4-byte Folded Reload
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	add	x8, sp, #48
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB184_27
LBB184_27:
	stur	wzr, [x29, #-4]
	b	LBB184_28
LBB184_28:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_body_projection
_file_body_projection:                  ; @file_body_projection
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturh	w1, [x29, #-18]
	sturb	w2, [x29, #-19]
	sturb	w3, [x29, #-20]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	cbnz	w8, LBB185_2
	b	LBB185_1
LBB185_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_2:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x1, w8, w9, x10
	sub	x0, x29, #64
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldurb	w8, [x29, #-48]
	tbz	w8, #0, LBB185_5
	b	LBB185_3
LBB185_3:
	ldur	x8, [x29, #-40]
	cbnz	x8, LBB185_5
	b	LBB185_4
LBB185_4:
	ldurb	w8, [x29, #-63]
	cbz	w8, LBB185_6
	b	LBB185_5
LBB185_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_6:
	ldurb	w8, [x29, #-20]
	tbz	w8, #0, LBB185_10
	b	LBB185_7
LBB185_7:
	ldurb	w8, [x29, #-19]
	tbnz	w8, #0, LBB185_10
	b	LBB185_8
LBB185_8:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #4
	b.ne	LBB185_10
	b	LBB185_9
LBB185_9:
	ldur	x0, [x29, #-16]
	ldurh	w1, [x29, #-18]
	bl	_nvm_file_flow_field
	stur	w0, [x29, #-4]
	b	LBB185_25
LBB185_10:
	ldur	w8, [x29, #-52]
	subs	w8, w8, #3
	b.eq	LBB185_12
	b	LBB185_11
LBB185_11:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_12:
	mov	w0, #1                          ; =0x1
	bl	_scalar_type
	str	x0, [sp, #64]
	str	x1, [sp, #72]
	ldurb	w8, [x29, #-19]
	tbnz	w8, #0, LBB185_24
	b	LBB185_13
LBB185_13:
	ldurh	w8, [x29, #-18]
	cbz	w8, LBB185_15
	b	LBB185_14
LBB185_14:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_15:
	ldur	w8, [x29, #-32]
	subs	w8, w8, #2
	b.eq	LBB185_18
	b	LBB185_16
LBB185_16:
	ldur	w8, [x29, #-32]
	subs	w8, w8, #3
	b.eq	LBB185_18
	b	LBB185_17
LBB185_17:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_18:
	ldur	w8, [x29, #-56]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #56]
	ldr	x8, [sp, #56]
	cbz	x8, LBB185_22
	b	LBB185_19
LBB185_19:
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB185_22
	b	LBB185_20
LBB185_20:
	ldur	x0, [x29, #-16]
	ldur	w1, [x29, #-56]
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #24]
	ldur	w9, [x29, #-32]
	subs	w9, w9, #3
	cset	w10, eq
                                        ; implicit-def: $x9
	mov	x9, x10
	and	x9, x9, #0x1
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #64
	bl	_member_type
	tbz	w0, #0, LBB185_22
	b	LBB185_21
LBB185_21:
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #72]
	bl	_owned
	tbz	w0, #0, LBB185_23
	b	LBB185_22
LBB185_22:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB185_25
LBB185_23:
	b	LBB185_24
LBB185_24:
	ldur	x8, [x29, #-16]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #1
	mov	w9, #40                         ; =0x28
	smaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldr	x0, [sp, #64]
	ldr	x1, [sp, #72]
	add	x8, sp, #16
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, #1                          ; =0x1
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB185_25
LBB185_25:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_section
_file_hosted_section:                   ; @file_hosted_section
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	stur	x2, [x29, #-32]
	ldr	x8, [x1, #16]
	ldur	x9, [x29, #-32]
	ldr	w10, [x1]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, #64
	str	x8, [x9, x10, lsl #3]
	ldr	w8, [x1]
	subs	w8, w8, #6
	b.ne	LBB186_4
	b	LBB186_1
LBB186_1:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	w9, #0                          ; =0x0
	str	w9, [sp, #20]                   ; 4-byte Folded Spill
	cbz	x8, LBB186_3
	b	LBB186_2
LBB186_2:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	subs	x8, x8, #16, lsl #12            ; =65536
	cset	w8, ls
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB186_3
LBB186_3:
	ldr	w10, [sp, #20]                  ; 4-byte Folded Reload
	mov	w9, #3                          ; =0x3
	mov	w8, #0                          ; =0x0
	and	w10, w10, #0x1
	ands	w10, w10, #0x1
	csel	w8, w8, w9, ne
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	subs	w8, w8, #13
	b.ne	LBB186_6
	b	LBB186_5
LBB186_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	subs	x8, x8, #0
	cset	w8, eq
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_6:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	subs	w8, w8, #14
	b.ne	LBB186_8
	b	LBB186_7
LBB186_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	ldr	x10, [x8, #8]
	add	x0, x9, x10
	ldr	x1, [x8, #16]
	sub	x2, x29, #84
	bl	_nvm_file_nominal_decode
	subs	w8, w0, #0
	cset	w8, ne
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_8:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w8, [x8]
	subs	w8, w8, #12
	b.ne	LBB186_10
	b	LBB186_9
LBB186_9:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_10:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-16]
	ldr	x10, [x8, #8]
	add	x1, x9, x10
	ldr	x2, [x8, #16]
	add	x0, sp, #96
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	_nvm_v2_cursor_init
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	add	x1, sp, #92
	bl	_nvm_v2_u32
	cbz	w0, LBB186_12
	b	LBB186_11
LBB186_11:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_12:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w9, [sp, #92]
	ldur	x10, [x29, #-32]
	ldr	w11, [x8]
                                        ; kill: def $x11 killed $w11
	str	w9, [x10, x11, lsl #2]
	str	xzr, [sp, #80]
	str	xzr, [sp, #72]
	ldr	w8, [x8]
	subs	w8, w8, #1
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #10
	b.hi	LBB186_91
; %bb.13:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI186_0@PAGE
	add	x10, x10, lJTI186_0@PAGEOFF
Ltmp27:
	adr	x8, Ltmp27
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB186_14:
	ldr	w8, [sp, #92]
	cbz	w8, LBB186_16
	b	LBB186_15
LBB186_15:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_16:
	b	LBB186_92
LBB186_17:
	ldr	w8, [sp, #92]
	cbz	w8, LBB186_19
	b	LBB186_18
LBB186_18:
	ldr	w8, [sp, #92]
	subs	w8, w8, #64
	b.ls	LBB186_20
	b	LBB186_19
LBB186_19:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_20:
	mov	x8, #32                         ; =0x20
	str	x8, [sp, #80]
	str	x8, [sp, #72]
	b	LBB186_92
LBB186_21:
	ldr	w8, [sp, #92]
	subs	w8, w8, #5
	b.eq	LBB186_23
	b	LBB186_22
LBB186_22:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_23:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #80]
	str	x8, [sp, #72]
	b	LBB186_92
LBB186_24:
	mov	x8, #8                          ; =0x8
	str	x8, [sp, #80]
	str	x8, [sp, #72]
	b	LBB186_92
LBB186_25:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #80]
	str	x8, [sp, #72]
	b	LBB186_92
LBB186_26:
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	ldr	x10, [sp, #112]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB186_28
	b	LBB186_27
LBB186_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_28:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #72]
	str	wzr, [sp, #68]
	b	LBB186_29
LBB186_29:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #68]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.hs	LBB186_44
	b	LBB186_30
LBB186_30:                              ;   in Loop: Header=BB186_29 Depth=1
	add	x0, sp, #96
	add	x1, sp, #67
	bl	_nvm_v2_u8
	cbnz	w0, LBB186_39
	b	LBB186_31
LBB186_31:                              ;   in Loop: Header=BB186_29 Depth=1
	add	x0, sp, #96
	add	x1, sp, #66
	bl	_nvm_v2_u8
	cbnz	w0, LBB186_39
	b	LBB186_32
LBB186_32:                              ;   in Loop: Header=BB186_29 Depth=1
	add	x0, sp, #96
	add	x1, sp, #64
	bl	_nvm_v2_u16
	cbnz	w0, LBB186_39
	b	LBB186_33
LBB186_33:                              ;   in Loop: Header=BB186_29 Depth=1
	add	x0, sp, #96
	add	x1, sp, #60
	bl	_nvm_v2_u32
	cbnz	w0, LBB186_39
	b	LBB186_34
LBB186_34:                              ;   in Loop: Header=BB186_29 Depth=1
	ldrb	w8, [sp, #66]
	cbnz	w8, LBB186_39
	b	LBB186_35
LBB186_35:                              ;   in Loop: Header=BB186_29 Depth=1
	ldrh	w8, [sp, #64]
	cbnz	w8, LBB186_39
	b	LBB186_36
LBB186_36:                              ;   in Loop: Header=BB186_29 Depth=1
	ldrb	w8, [sp, #67]
	subs	w8, w8, #5
	b.ne	LBB186_39
	b	LBB186_37
LBB186_37:                              ;   in Loop: Header=BB186_29 Depth=1
	ldr	w8, [sp, #60]
	mov	x1, x8
	add	x0, sp, #96
	bl	_file_hosted_take
	tbz	w0, #0, LBB186_39
	b	LBB186_38
LBB186_38:                              ;   in Loop: Header=BB186_29 Depth=1
	add	x0, sp, #96
	bl	_nvm_v2_align4
	cbz	w0, LBB186_40
	b	LBB186_39
LBB186_39:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_40:                              ;   in Loop: Header=BB186_29 Depth=1
	ldur	x8, [x29, #-32]
	add	x0, x8, #200
	ldr	w8, [sp, #60]
                                        ; kill: def $x8 killed $w8
	mov	x2, #1                          ; =0x1
	add	x1, x8, #1
	bl	_file_hosted_add
	tbnz	w0, #0, LBB186_42
	b	LBB186_41
LBB186_41:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_42:                              ;   in Loop: Header=BB186_29 Depth=1
	b	LBB186_43
LBB186_43:                              ;   in Loop: Header=BB186_29 Depth=1
	ldr	w8, [sp, #68]
	add	w8, w8, #1
	str	w8, [sp, #68]
	b	LBB186_29
LBB186_44:
	b	LBB186_92
LBB186_45:
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	ldr	x10, [sp, #112]
	subs	x9, x9, x10
	mov	x10, #4                         ; =0x4
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB186_47
	b	LBB186_46
LBB186_46:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_47:
	mov	x8, #24                         ; =0x18
	str	x8, [sp, #72]
	str	wzr, [sp, #56]
	b	LBB186_48
LBB186_48:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #56]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.hs	LBB186_60
	b	LBB186_49
LBB186_49:                              ;   in Loop: Header=BB186_48 Depth=1
	add	x0, sp, #96
	add	x1, sp, #54
	bl	_nvm_v2_u16
	cbnz	w0, LBB186_55
	b	LBB186_50
LBB186_50:                              ;   in Loop: Header=BB186_48 Depth=1
	add	x0, sp, #96
	add	x1, sp, #52
	bl	_nvm_v2_u16
	cbnz	w0, LBB186_55
	b	LBB186_51
LBB186_51:                              ;   in Loop: Header=BB186_48 Depth=1
	ldrh	w8, [sp, #54]
	mov	x1, x8
	add	x0, sp, #96
	bl	_file_hosted_take
	tbz	w0, #0, LBB186_55
	b	LBB186_52
LBB186_52:                              ;   in Loop: Header=BB186_48 Depth=1
	add	x0, sp, #96
	bl	_nvm_v2_align4
	cbnz	w0, LBB186_55
	b	LBB186_53
LBB186_53:                              ;   in Loop: Header=BB186_48 Depth=1
	ldrh	w8, [sp, #52]
	mov	x1, x8
	add	x0, sp, #96
	bl	_file_hosted_take
	tbz	w0, #0, LBB186_55
	b	LBB186_54
LBB186_54:                              ;   in Loop: Header=BB186_48 Depth=1
	add	x0, sp, #96
	bl	_nvm_v2_align4
	cbz	w0, LBB186_56
	b	LBB186_55
LBB186_55:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_56:                              ;   in Loop: Header=BB186_48 Depth=1
	ldrh	w8, [sp, #54]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #208]
	subs	w8, w8, w9
	b.le	LBB186_58
	b	LBB186_57
LBB186_57:                              ;   in Loop: Header=BB186_48 Depth=1
	ldrh	w8, [sp, #54]
	ldur	x9, [x29, #-32]
	strh	w8, [x9, #208]
	b	LBB186_58
LBB186_58:                              ;   in Loop: Header=BB186_48 Depth=1
	b	LBB186_59
LBB186_59:                              ;   in Loop: Header=BB186_48 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB186_48
LBB186_60:
	b	LBB186_92
LBB186_61:
	ldr	w8, [sp, #92]
	subs	w8, w8, #8
	b.lo	LBB186_63
	b	LBB186_62
LBB186_62:
	ldr	w8, [sp, #92]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ls	LBB186_64
	b	LBB186_63
LBB186_63:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_64:
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	ldr	x10, [sp, #112]
	subs	x9, x9, x10
	mov	x10, #8                         ; =0x8
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB186_66
	b	LBB186_65
LBB186_65:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_66:
	mov	x8, #16                         ; =0x10
	str	x8, [sp, #72]
	str	wzr, [sp, #48]
	b	LBB186_67
LBB186_67:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB186_79 Depth 2
	ldr	w8, [sp, #48]
	ldr	w9, [sp, #92]
	subs	w8, w8, w9
	b.hs	LBB186_90
	b	LBB186_68
LBB186_68:                              ;   in Loop: Header=BB186_67 Depth=1
	add	x0, sp, #96
	add	x1, sp, #47
	bl	_nvm_v2_u8
	cbnz	w0, LBB186_75
	b	LBB186_69
LBB186_69:                              ;   in Loop: Header=BB186_67 Depth=1
	add	x0, sp, #96
	add	x1, sp, #46
	bl	_nvm_v2_u8
	cbnz	w0, LBB186_75
	b	LBB186_70
LBB186_70:                              ;   in Loop: Header=BB186_67 Depth=1
	add	x0, sp, #96
	add	x1, sp, #44
	bl	_nvm_v2_u16
	cbnz	w0, LBB186_75
	b	LBB186_71
LBB186_71:                              ;   in Loop: Header=BB186_67 Depth=1
	add	x0, sp, #96
	add	x1, sp, #40
	bl	_nvm_v2_u32
	cbnz	w0, LBB186_75
	b	LBB186_72
LBB186_72:                              ;   in Loop: Header=BB186_67 Depth=1
	ldrb	w8, [sp, #46]
	cbnz	w8, LBB186_75
	b	LBB186_73
LBB186_73:                              ;   in Loop: Header=BB186_67 Depth=1
	ldrb	w8, [sp, #47]
	subs	w8, w8, #3
	b.gt	LBB186_75
	b	LBB186_74
LBB186_74:                              ;   in Loop: Header=BB186_67 Depth=1
	ldrh	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	ldr	x10, [sp, #112]
	subs	x9, x9, x10
	mov	x10, #12                        ; =0xc
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.ls	LBB186_76
	b	LBB186_75
LBB186_75:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_76:                              ;   in Loop: Header=BB186_67 Depth=1
	ldur	x8, [x29, #-32]
	add	x0, x8, #192
	ldrh	w8, [sp, #44]
	mov	x1, x8
	mov	x2, #12                         ; =0xc
	bl	_file_hosted_add
	tbnz	w0, #0, LBB186_78
	b	LBB186_77
LBB186_77:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_78:                              ;   in Loop: Header=BB186_67 Depth=1
	str	wzr, [sp, #36]
	b	LBB186_79
LBB186_79:                              ;   Parent Loop BB186_67 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #36]
	ldrh	w9, [sp, #44]
	subs	w8, w8, w9
	b.hs	LBB186_88
	b	LBB186_80
LBB186_80:                              ;   in Loop: Header=BB186_79 Depth=2
	add	x0, sp, #96
	mov	x1, #4                          ; =0x4
	bl	_file_hosted_take
	tbz	w0, #0, LBB186_85
	b	LBB186_81
LBB186_81:                              ;   in Loop: Header=BB186_79 Depth=2
	add	x0, sp, #96
	add	x1, sp, #32
	bl	_nvm_v2_u32
	cbnz	w0, LBB186_85
	b	LBB186_82
LBB186_82:                              ;   in Loop: Header=BB186_79 Depth=2
	add	x0, sp, #96
	mov	x1, #4                          ; =0x4
	bl	_file_hosted_take
	tbz	w0, #0, LBB186_85
	b	LBB186_83
LBB186_83:                              ;   in Loop: Header=BB186_79 Depth=2
	ldr	w8, [sp, #32]
	adds	w8, w8, #1
	b.eq	LBB186_86
	b	LBB186_84
LBB186_84:                              ;   in Loop: Header=BB186_79 Depth=2
	ldr	w8, [sp, #32]
	ldr	w9, [sp, #48]
	subs	w8, w8, w9
	b.lo	LBB186_86
	b	LBB186_85
LBB186_85:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_86:                              ;   in Loop: Header=BB186_79 Depth=2
	b	LBB186_87
LBB186_87:                              ;   in Loop: Header=BB186_79 Depth=2
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB186_79
LBB186_88:                              ;   in Loop: Header=BB186_67 Depth=1
	b	LBB186_89
LBB186_89:                              ;   in Loop: Header=BB186_67 Depth=1
	ldr	w8, [sp, #48]
	add	w8, w8, #1
	str	w8, [sp, #48]
	b	LBB186_67
LBB186_90:
	b	LBB186_92
LBB186_91:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_92:
	ldr	x8, [sp, #80]
	cbz	x8, LBB186_96
	b	LBB186_93
LBB186_93:
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #104]
	ldr	x10, [sp, #112]
	subs	x9, x9, x10
	ldr	x10, [sp, #80]
	udiv	x9, x9, x10
	subs	x8, x8, x9
	b.hi	LBB186_95
	b	LBB186_94
LBB186_94:
	ldr	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #80]
	mul	x1, x8, x9
	add	x0, sp, #96
	bl	_file_hosted_take
	tbnz	w0, #0, LBB186_96
	b	LBB186_95
LBB186_95:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_96:
	add	x0, sp, #96
	bl	_nvm_v2_cursor_exhausted
	tbnz	w0, #0, LBB186_98
	b	LBB186_97
LBB186_97:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_98:
	ldur	x8, [x29, #-32]
	add	x0, x8, #184
	ldr	w8, [sp, #92]
	mov	x1, x8
	ldr	x2, [sp, #72]
	bl	_file_hosted_add
	tbnz	w0, #0, LBB186_100
	b	LBB186_99
LBB186_99:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB186_101
LBB186_100:
	stur	wzr, [x29, #-4]
	b	LBB186_101
LBB186_101:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
	.p2align	2
lJTI186_0:
	.long	LBB186_24-Ltmp27
	.long	LBB186_26-Ltmp27
	.long	LBB186_45-Ltmp27
	.long	LBB186_61-Ltmp27
	.long	LBB186_17-Ltmp27
	.long	LBB186_91-Ltmp27
	.long	LBB186_14-Ltmp27
	.long	LBB186_21-Ltmp27
	.long	LBB186_14-Ltmp27
	.long	LBB186_25-Ltmp27
	.long	LBB186_14-Ltmp27
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_array
_file_hosted_array:                     ; @file_hosted_array
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x8, [sp, #32]
	str	x8, [sp, #16]
	b	LBB187_1
LBB187_1:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #16]
	ldur	x9, [x29, #-24]
	subs	x8, x8, x9
	b.hs	LBB187_5
	b	LBB187_2
LBB187_2:                               ;   in Loop: Header=BB187_1 Depth=1
	ldr	x8, [sp, #16]
	mov	x9, #9223372036854775807        ; =0x7fffffffffffffff
	subs	x8, x8, x9
	b.ls	LBB187_4
	b	LBB187_3
LBB187_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB187_8
LBB187_4:                               ;   in Loop: Header=BB187_1 Depth=1
	ldr	x8, [sp, #16]
	lsl	x8, x8, #1
	str	x8, [sp, #16]
	b	LBB187_1
LBB187_5:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_file_hosted_add
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB187_7
	b	LBB187_6
LBB187_6:
	ldur	x0, [x29, #-16]
	ldr	x1, [sp, #16]
	ldr	x2, [sp, #24]
	bl	_file_hosted_add
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB187_7
LBB187_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB187_8
LBB187_8:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_hosted_take
_file_hosted_take:                      ; @file_hosted_take
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	str	x1, [sp, #16]
	ldur	x0, [x29, #-8]
	ldr	x1, [sp, #16]
	add	x2, sp, #8
	bl	_nvm_v2_take
	subs	w8, w0, #0
	cset	w0, eq
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_function_analyze
_file_cyclic_function_analyze:          ; @file_cyclic_function_analyze
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	stur	w3, [x29, #-52]
	stur	x4, [x29, #-64]
	ldur	x9, [x29, #-40]
	mov	x10, #30868                     ; =0x7894
	movk	x10, #1, lsl #16
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #68]                   ; 4-byte Folded Spill
	str	w8, [x9, x10]
	ldur	x9, [x29, #-40]
	mov	x10, #30864                     ; =0x7890
	movk	x10, #1, lsl #16
	str	w8, [x9, x10]
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	w2, [x29, #-52]
	bl	_file_cyclic_components
	ldr	w1, [sp, #68]                   ; 4-byte Folded Reload
	ldur	x8, [x29, #-40]
	mov	x9, #47232                      ; =0xb880
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	add	x0, x8, x9
	mov	x2, #32784                      ; =0x8010
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	ldur	x8, [x29, #-32]
	ldr	x11, [x8]
	ldur	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x11, x11, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	add	x8, x8, #12
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-72]
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-40]
	add	x9, x9, x10
	strh	w8, [x9]
	mov	x8, #1                          ; =0x1
	stur	x8, [x29, #-80]
	sturh	wzr, [x29, #-82]
	b	LBB189_1
LBB189_1:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-82]
	ldur	x9, [x29, #-72]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB189_11
	b	LBB189_2
LBB189_2:                               ;   in Loop: Header=BB189_1 Depth=1
	ldur	x8, [x29, #-48]
	add	x8, x8, #1816
	ldur	x9, [x29, #-48]
	add	x9, x9, #1560
	ldur	w10, [x29, #-52]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-82]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	stur	q0, [x29, #-112]
	ldurh	w8, [x29, #-82]
	ldur	x9, [x29, #-72]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	cset	w8, lt
	sturb	w8, [x29, #-113]
	ldur	x8, [x29, #-40]
	mov	x9, #47248                      ; =0xb890
	add	x10, x8, x9
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldurb	w8, [x29, #-113]
	str	w8, [sp, #64]                   ; 4-byte Folded Spill
	ldurb	w8, [x29, #-113]
	tbz	w8, #0, LBB189_5
	b	LBB189_3
LBB189_3:                               ;   in Loop: Header=BB189_1 Depth=1
	ldur	x0, [x29, #-112]
	ldur	x1, [x29, #-104]
	bl	_owned
	tbz	w0, #0, LBB189_5
	b	LBB189_4
LBB189_4:                               ;   in Loop: Header=BB189_1 Depth=1
	ldur	x8, [x29, #-80]
	add	x9, x8, #1
	stur	x9, [x29, #-80]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB189_6
LBB189_5:                               ;   in Loop: Header=BB189_1 Depth=1
	mov	x8, #0                          ; =0x0
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB189_6
LBB189_6:                               ;   in Loop: Header=BB189_1 Depth=1
	ldr	w9, [sp, #64]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-112]
	ldur	x1, [x29, #-104]
	sub	x8, x29, #160
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	and	w2, w9, #0x1
	bl	_initial_value
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldurb	w8, [x29, #-113]
	tbz	w8, #0, LBB189_9
	b	LBB189_7
LBB189_7:                               ;   in Loop: Header=BB189_1 Depth=1
	ldurb	w8, [x29, #-111]
	cbz	w8, LBB189_9
	b	LBB189_8
LBB189_8:                               ;   in Loop: Header=BB189_1 Depth=1
	ldur	x8, [x29, #-40]
	mov	x9, #2192                       ; =0x890
	movk	x9, #1, lsl #16
	add	x10, x8, x9
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #184
	mov	w8, #1                          ; =0x1
	strb	w8, [sp, #184]
	strb	w8, [sp, #185]
	ldurh	w8, [x29, #-82]
	strh	w8, [sp, #186]
	str	wzr, [sp, #188]
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #257
	str	x8, [sp, #192]
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #257
	str	x8, [sp, #200]
	str	xzr, [sp, #208]
	ldurb	w8, [x29, #-111]
	subs	w8, w8, #1
	cset	w8, eq
	strb	w8, [sp, #216]
	stur	wzr, [x1, #33]
	str	wzr, [sp, #220]
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB189_9
LBB189_9:                               ;   in Loop: Header=BB189_1 Depth=1
	b	LBB189_10
LBB189_10:                              ;   in Loop: Header=BB189_1 Depth=1
	ldurh	w8, [x29, #-82]
	add	w8, w8, #1
	sturh	w8, [x29, #-82]
	b	LBB189_1
LBB189_11:
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-48]
	ldur	w2, [x29, #-52]
	ldur	x8, [x29, #-40]
	mov	x9, #47232                      ; =0xb880
	add	x3, x8, x9
	bl	_file_cyclic_scratch
	ldur	x0, [x29, #-40]
	bl	_file_cyclic_canonicalize
	str	w0, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_13
	b	LBB189_12
LBB189_12:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_13:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	w2, [x29, #-52]
	mov	w3, #0                          ; =0x0
	add	x4, sp, #179
	bl	_file_cyclic_intern
	str	w0, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_15
	b	LBB189_14
LBB189_14:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_15:
	strb	wzr, [sp, #178]
	b	LBB189_16
LBB189_16:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB189_34 Depth 2
	ldur	x8, [x29, #-40]
	mov	x9, #30864                      ; =0x7890
	movk	x9, #1, lsl #16
	ldr	w8, [x8, x9]
	ldur	x9, [x29, #-40]
	mov	x10, #30868                     ; =0x7894
	movk	x10, #1, lsl #16
	ldr	w9, [x9, x10]
	subs	w8, w8, w9
	b.hs	LBB189_49
	b	LBB189_17
LBB189_17:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x8, [x29, #-40]
	mov	x9, #14480                      ; =0x3890
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldur	x9, [x29, #-40]
	mov	x10, #30864                     ; =0x7890
	movk	x10, #1, lsl #16
	add	x11, x9, x10
	ldr	w9, [x11]
                                        ; kill: def $x9 killed $w9
	mov	x10, x9
	add	w10, w10, #1
	str	w10, [x11]
	ldr	w8, [x8, x9, lsl #2]
	str	w8, [sp, #172]
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #172]
	add	w8, w8, w9
	mov	w9, #136                        ; =0x88
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #160]
	ldr	x8, [sp, #160]
	add	x8, x8, #8
	ldrb	w9, [sp, #174]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #152]
	ldr	x8, [sp, #152]
	ldrb	w8, [x8, #160]
	tbnz	w8, #0, LBB189_19
	b	LBB189_18
LBB189_18:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #32]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.ne	LBB189_20
	b	LBB189_19
LBB189_19:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_20:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #32]
	add	w8, w8, #1
	str	w8, [x9, #32]
	ldur	x8, [x29, #-40]
	mov	x9, #47232                      ; =0xb880
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	add	x0, x8, x9
	mov	w1, #0                          ; =0x0
	mov	x2, #32784                      ; =0x8010
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #24]                   ; 8-byte Folded Spill
	bl	___memset_chk
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	add	x9, x8, x9
	ldr	x8, [sp, #152]
	ldr	x10, [x8]
	str	x10, [x9]
	ldrh	w8, [x8, #8]
	strh	w8, [x9, #8]
	ldur	x8, [x29, #-40]
	mov	x9, #47248                      ; =0xb890
	add	x0, x8, x9
	ldr	x8, [sp, #152]
	ldr	x1, [x8, #16]
	ldr	x8, [sp, #152]
	ldrh	w8, [x8]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	___memcpy_chk
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	mov	x10, #57488                     ; =0xe090
	add	x0, x8, x10
	ldr	x8, [sp, #152]
	ldr	x1, [x8, #24]
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #2]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	___memcpy_chk
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	mov	x10, #2192                      ; =0x890
	movk	x10, #1, lsl #16
	add	x0, x8, x10
	ldr	x8, [sp, #152]
	ldr	x1, [x8, #32]
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #48]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	___memcpy_chk
	ldr	x3, [sp, #24]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-40]
	mov	x9, #12432                      ; =0x3090
	movk	x9, #1, lsl #16
	add	x0, x8, x9
	ldr	x8, [sp, #152]
	ldr	x1, [x8, #40]
	ldr	x8, [sp, #152]
	ldrh	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	___memcpy_chk
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-40]
	ldur	x1, [x29, #-48]
	ldur	w2, [x29, #-52]
	ldur	x8, [x29, #-40]
	add	x3, x8, x9
	bl	_file_cyclic_scratch
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #172]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #144]
	ldr	x8, [sp, #152]
	add	x8, x8, #76
	str	x8, [sp, #136]
	ldr	x9, [sp, #136]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #92]
	ldr	x9, [sp, #136]
	strh	w8, [x9, #4]
	ldr	x9, [sp, #136]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [x9, #8]
	ldr	x9, [sp, #136]
	mov	w8, #128                        ; =0x80
	str	w8, [x9, #20]
	ldur	x8, [x29, #-64]
	cbz	x8, LBB189_22
	b	LBB189_21
LBB189_21:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-64]
	ldr	x0, [x9, #16]
	ldur	x1, [x29, #-40]
	ldur	x9, [x29, #-40]
	add	x2, x9, #80
	ldr	x3, [sp, #144]
	ldr	x4, [sp, #136]
	blr	x8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB189_23
LBB189_22:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x0, [x29, #-40]
	ldur	x8, [x29, #-40]
	add	x1, x8, #80
	ldr	x2, [sp, #144]
	ldr	x3, [sp, #136]
	bl	_file_body_transfer
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB189_23
LBB189_23:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_25
	b	LBB189_24
LBB189_24:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_25:                              ;   in Loop: Header=BB189_16 Depth=1
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #92]
	ldr	x9, [sp, #136]
	strh	w8, [x9, #6]
	ldr	x8, [sp, #136]
	ldrb	w8, [x8, #1]
	and	w9, w8, #0x1
	ldrb	w8, [sp, #178]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [sp, #178]
	ldur	x0, [x29, #-40]
	bl	_file_cyclic_canonicalize
	str	w0, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_27
	b	LBB189_26
LBB189_26:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_27:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	x9, [sp, #152]
	ldur	x8, [x29, #-40]
	mov	x10, #47232                     ; =0xb880
	add	x8, x8, x10
	ldr	x10, [x8]
	stur	x10, [x9, #66]
	ldrh	w8, [x8, #8]
	strh	w8, [x9, #74]
	str	wzr, [sp, #132]
	strh	wzr, [sp, #130]
	ldr	x8, [sp, #144]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #146
	b.ne	LBB189_33
	b	LBB189_28
LBB189_28:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	x8, [sp, #144]
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #130]
	ldur	x8, [x29, #-40]
	mov	x9, #14464                      ; =0x3880
	add	x10, x8, x9
	ldrh	w8, [sp, #130]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #88
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #104]
	tbz	w8, #0, LBB189_31
	b	LBB189_29
LBB189_29:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	x0, [sp, #88]
	ldr	x1, [sp, #96]
	bl	_result_type
	tbz	w0, #0, LBB189_31
	b	LBB189_30
LBB189_30:                              ;   in Loop: Header=BB189_16 Depth=1
	ldrb	w8, [sp, #89]
	cbz	w8, LBB189_32
	b	LBB189_31
LBB189_31:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_32:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	w8, [sp, #120]
	str	w8, [sp, #132]
	ldr	x9, [sp, #136]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #2]
	b	LBB189_33
LBB189_33:                              ;   in Loop: Header=BB189_16 Depth=1
	strb	wzr, [sp, #87]
	b	LBB189_34
LBB189_34:                              ;   Parent Loop BB189_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #87]
	ldr	x9, [sp, #144]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB189_48
	b	LBB189_35
LBB189_35:                              ;   in Loop: Header=BB189_34 Depth=2
	ldr	x8, [sp, #136]
	ldrb	w8, [x8, #2]
	tbz	w8, #0, LBB189_40
	b	LBB189_36
LBB189_36:                              ;   in Loop: Header=BB189_34 Depth=2
	ldrb	w10, [sp, #87]
	mov	w9, #2                          ; =0x2
	mov	w8, #3                          ; =0x3
	subs	w10, w10, #0
	csel	w8, w8, w9, ne
	str	w8, [sp, #80]
	ldr	w8, [sp, #132]
	subs	w8, w8, #1
	b.eq	LBB189_39
	b	LBB189_37
LBB189_37:                              ;   in Loop: Header=BB189_34 Depth=2
	ldr	w8, [sp, #132]
	ldr	w9, [sp, #80]
	subs	w8, w8, w9
	b.eq	LBB189_39
	b	LBB189_38
LBB189_38:                              ;   in Loop: Header=BB189_34 Depth=2
	b	LBB189_47
LBB189_39:                              ;   in Loop: Header=BB189_34 Depth=2
	ldr	w8, [sp, #80]
	ldur	x9, [x29, #-40]
	mov	x10, #14464                     ; =0x3880
	add	x11, x9, x10
	ldrh	w9, [sp, #130]
                                        ; kill: def $x9 killed $w9
	mov	x10, #40                        ; =0x28
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	str	w8, [x9, #32]
	b	LBB189_40
LBB189_40:                              ;   in Loop: Header=BB189_34 Depth=2
	ldur	x8, [x29, #-32]
	ldr	w8, [x8, #36]
	subs	w8, w8, #32, lsl #12            ; =131072
	b.ne	LBB189_42
	b	LBB189_41
LBB189_41:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_42:                              ;   in Loop: Header=BB189_34 Depth=2
	ldur	x9, [x29, #-32]
	ldr	w8, [x9, #36]
	add	w8, w8, #1
	str	w8, [x9, #36]
	ldur	x0, [x29, #-40]
	bl	_file_cyclic_canonicalize
	str	w0, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_44
	b	LBB189_43
LBB189_43:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_44:                              ;   in Loop: Header=BB189_34 Depth=2
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-40]
	ldur	w2, [x29, #-52]
	ldr	x8, [sp, #144]
	add	x8, x8, #72
	ldrb	w9, [sp, #87]
                                        ; kill: def $x9 killed $w9
	ldrh	w3, [x8, x9, lsl #1]
	add	x4, sp, #179
	bl	_file_cyclic_intern
	str	w0, [sp, #180]
	ldr	w8, [sp, #180]
	cbz	w8, LBB189_46
	b	LBB189_45
LBB189_45:
	ldr	w8, [sp, #180]
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_46:                              ;   in Loop: Header=BB189_34 Depth=2
	ldrb	w8, [sp, #179]
	ldr	x9, [sp, #152]
	add	x9, x9, #157
	ldrb	w10, [sp, #87]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10
	strb	w8, [x9]
	ldrb	w9, [sp, #87]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	and	w10, w8, #0xff
	ldr	x9, [sp, #152]
	ldrb	w8, [x9, #156]
	orr	w8, w8, w10
	strb	w8, [x9, #156]
	b	LBB189_47
LBB189_47:                              ;   in Loop: Header=BB189_34 Depth=2
	ldrb	w8, [sp, #87]
	add	w8, w8, #1
	strb	w8, [sp, #87]
	b	LBB189_34
LBB189_48:                              ;   in Loop: Header=BB189_16 Depth=1
	ldr	x9, [sp, #152]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #160]
	b	LBB189_16
LBB189_49:
	ldrb	w8, [sp, #178]
	tbnz	w8, #0, LBB189_51
	b	LBB189_50
LBB189_50:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB189_52
LBB189_51:
	ldur	x8, [x29, #-40]
	add	x8, x8, #16
	ldur	w9, [x29, #-52]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-20]
	b	LBB189_52
LBB189_52:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_complete
_file_cyclic_complete:                  ; @file_cyclic_complete
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	str	x0, [sp, #64]
	str	wzr, [sp, #60]
	str	wzr, [sp, #56]
	b	LBB190_1
LBB190_1:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB190_3 Depth 2
                                        ;       Child Loop BB190_8 Depth 3
                                        ;         Child Loop BB190_16 Depth 4
	ldr	w8, [sp, #56]
	ldr	x9, [sp, #64]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB190_34
	b	LBB190_2
LBB190_2:                               ;   in Loop: Header=BB190_1 Depth=1
	strh	wzr, [sp, #54]
	b	LBB190_3
LBB190_3:                               ;   Parent Loop BB190_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB190_8 Depth 3
                                        ;         Child Loop BB190_16 Depth 4
	ldrh	w8, [sp, #54]
	ldr	x9, [sp, #64]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB190_32
	b	LBB190_4
LBB190_4:                               ;   in Loop: Header=BB190_3 Depth=2
	ldr	x8, [sp, #64]
	ldr	x8, [x8]
	ldr	x10, [x8, #16]
	ldr	x8, [sp, #64]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #54]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #40]
	ldr	x8, [sp, #64]
	ldr	x10, [x8, #8]
	ldr	x8, [sp, #64]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #54]
	add	w8, w8, w9
	mov	w9, #136                        ; =0x88
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]
	ldr	x8, [sp, #32]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.hi	LBB190_6
	b	LBB190_5
LBB190_5:                               ;   in Loop: Header=BB190_3 Depth=2
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #64]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.lt	LBB190_7
	b	LBB190_6
LBB190_6:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB190_37
LBB190_7:                               ;   in Loop: Header=BB190_3 Depth=2
	strb	wzr, [sp, #31]
	b	LBB190_8
LBB190_8:                               ;   Parent Loop BB190_1 Depth=1
                                        ;     Parent Loop BB190_3 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB190_16 Depth 4
	ldrb	w8, [sp, #31]
	ldr	x9, [sp, #32]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB190_30
	b	LBB190_9
LBB190_9:                               ;   in Loop: Header=BB190_8 Depth=3
	ldr	x8, [sp, #32]
	add	x8, x8, #8
	ldrb	w9, [sp, #31]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	str	x8, [sp, #16]
	ldr	x8, [sp, #16]
	cbz	x8, LBB190_14
	b	LBB190_10
LBB190_10:                              ;   in Loop: Header=BB190_8 Depth=3
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #160]
	tbz	w8, #0, LBB190_14
	b	LBB190_11
LBB190_11:                              ;   in Loop: Header=BB190_8 Depth=3
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #80]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #58]
	subs	w8, w8, w9
	b.ne	LBB190_14
	b	LBB190_12
LBB190_12:                              ;   in Loop: Header=BB190_8 Depth=3
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #82]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #68]
	subs	w8, w8, w9
	b.ne	LBB190_14
	b	LBB190_13
LBB190_13:                              ;   in Loop: Header=BB190_8 Depth=3
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #156]
	ldr	x9, [sp, #40]
	ldrb	w9, [x9, #76]
	asr	w8, w8, w9
	cbz	w8, LBB190_15
	b	LBB190_14
LBB190_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB190_37
LBB190_15:                              ;   in Loop: Header=BB190_8 Depth=3
	strb	wzr, [sp, #15]
	b	LBB190_16
LBB190_16:                              ;   Parent Loop BB190_1 Depth=1
                                        ;     Parent Loop BB190_3 Depth=2
                                        ;       Parent Loop BB190_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldrb	w8, [sp, #15]
	subs	w8, w8, #2
	b.ge	LBB190_28
	b	LBB190_17
LBB190_17:                              ;   in Loop: Header=BB190_16 Depth=4
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #156]
	ldrb	w10, [sp, #15]
	mov	w9, #1                          ; =0x1
	lsl	w9, w9, w10
	and	w8, w8, w9
	cbz	w8, LBB190_23
	b	LBB190_18
LBB190_18:                              ;   in Loop: Header=BB190_16 Depth=4
	ldrb	w8, [sp, #15]
	ldr	x9, [sp, #40]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB190_21
	b	LBB190_19
LBB190_19:                              ;   in Loop: Header=BB190_16 Depth=4
	ldr	x8, [sp, #40]
	add	x8, x8, #72
	ldrb	w9, [sp, #15]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	ldr	x9, [sp, #64]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldr	w9, [sp, #56]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB190_21
	b	LBB190_20
LBB190_20:                              ;   in Loop: Header=BB190_16 Depth=4
	ldr	x8, [sp, #16]
	add	x8, x8, #157
	ldrb	w9, [sp, #15]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	ldr	x9, [sp, #64]
	ldr	x9, [x9, #8]
	ldr	x10, [sp, #64]
	ldr	x10, [x10]
	add	x10, x10, #2352
	ldr	w11, [sp, #56]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldr	x11, [sp, #40]
	add	x11, x11, #72
	ldrb	w12, [sp, #15]
                                        ; kill: def $x12 killed $w12
	ldrh	w11, [x11, x12, lsl #1]
	add	w10, w10, w11
	mov	w11, #136                       ; =0x88
	umull	x10, w10, w11
	ldrb	w9, [x9, x10]
	subs	w8, w8, w9
	b.lt	LBB190_22
	b	LBB190_21
LBB190_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB190_37
LBB190_22:                              ;   in Loop: Header=BB190_16 Depth=4
	b	LBB190_26
LBB190_23:                              ;   in Loop: Header=BB190_16 Depth=4
	ldr	x8, [sp, #16]
	add	x8, x8, #157
	ldrb	w9, [sp, #15]
                                        ; kill: def $x9 killed $w9
	ldrb	w8, [x8, x9]
	subs	w8, w8, #255
	b.eq	LBB190_25
	b	LBB190_24
LBB190_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB190_37
LBB190_25:                              ;   in Loop: Header=BB190_16 Depth=4
	b	LBB190_26
LBB190_26:                              ;   in Loop: Header=BB190_16 Depth=4
	b	LBB190_27
LBB190_27:                              ;   in Loop: Header=BB190_16 Depth=4
	ldrb	w8, [sp, #15]
	add	w8, w8, #1
	strb	w8, [sp, #15]
	b	LBB190_16
LBB190_28:                              ;   in Loop: Header=BB190_8 Depth=3
	ldr	w8, [sp, #60]
	add	w8, w8, #1
	str	w8, [sp, #60]
	b	LBB190_29
LBB190_29:                              ;   in Loop: Header=BB190_8 Depth=3
	ldrb	w8, [sp, #31]
	add	w8, w8, #1
	strb	w8, [sp, #31]
	b	LBB190_8
LBB190_30:                              ;   in Loop: Header=BB190_3 Depth=2
	b	LBB190_31
LBB190_31:                              ;   in Loop: Header=BB190_3 Depth=2
	ldrh	w8, [sp, #54]
	add	w8, w8, #1
	strh	w8, [sp, #54]
	b	LBB190_3
LBB190_32:                              ;   in Loop: Header=BB190_1 Depth=1
	b	LBB190_33
LBB190_33:                              ;   in Loop: Header=BB190_1 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB190_1
LBB190_34:
	ldr	w9, [sp, #60]
	ldr	x8, [sp, #64]
	ldr	w10, [x8, #28]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, w10
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b.ne	LBB190_36
	b	LBB190_35
LBB190_35:
	ldr	w8, [sp, #60]
	ldr	x9, [sp, #64]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #8]                    ; 4-byte Folded Spill
	b	LBB190_36
LBB190_36:
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #79]
	b	LBB190_37
LBB190_37:
	ldrb	w8, [sp, #79]
	and	w0, w8, #0x1
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_components
_file_cyclic_components:                ; @file_cyclic_components
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	ldur	x8, [x29, #-8]
	ldr	x10, [x8]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrh	w8, [x8, #8]
	sturh	w8, [x29, #-22]
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x0, x8, x9
	mov	w1, #0                          ; =0x0
	mov	x2, #8192                       ; =0x2000
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	___memset_chk
	sturh	wzr, [x29, #-24]
	b	LBB191_1
LBB191_1:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB191_3 Depth 2
                                        ;       Child Loop BB191_5 Depth 3
	ldurh	w8, [x29, #-24]
	ldurh	w9, [x29, #-22]
	subs	w8, w8, w9
	b.ge	LBB191_13
	b	LBB191_2
LBB191_2:                               ;   in Loop: Header=BB191_1 Depth=1
	sturh	wzr, [x29, #-26]
	ldurh	w8, [x29, #-24]
	ldur	x9, [x29, #-16]
	mov	x10, #41112                     ; =0xa098
	movk	x10, #1, lsl #16
	add	x9, x9, x10
	ldurh	w10, [x29, #-26]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	sturh	w11, [x29, #-26]
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	ldurh	w8, [x29, #-24]
	mov	w10, #64                        ; =0x40
	sdiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x11, x8, x9
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldurh	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #5
	ldurh	w8, [x29, #-24]
	sdiv	w10, w8, w10
	ldr	x8, [x9, w10, sxtw #3]
	orr	x8, x8, x11
	str	x8, [x9, w10, sxtw #3]
	b	LBB191_3
LBB191_3:                               ;   Parent Loop BB191_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB191_5 Depth 3
	ldurh	w8, [x29, #-26]
	cbz	w8, LBB191_11
	b	LBB191_4
LBB191_4:                               ;   in Loop: Header=BB191_3 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #41112                      ; =0xa098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldurh	w10, [x29, #-26]
	mov	w9, #-1                         ; =0xffffffff
	add	w9, w9, w10, uxth
	sturh	w9, [x29, #-26]
                                        ; implicit-def: $x0
	mov	x0, x9
	mov	x9, x0
	add	x8, x8, w9, uxth #1
	ldrh	w8, [x8]
	sturh	w8, [x29, #-28]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	ldr	x10, [x8, #16]
	ldur	x8, [x29, #-8]
	ldr	x8, [x8]
	add	x8, x8, #2352
	ldur	w9, [x29, #-20]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-28]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]
	strb	wzr, [sp, #23]
	b	LBB191_5
LBB191_5:                               ;   Parent Loop BB191_1 Depth=1
                                        ;     Parent Loop BB191_3 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldrb	w8, [sp, #23]
	ldr	x9, [sp, #24]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB191_10
	b	LBB191_6
LBB191_6:                               ;   in Loop: Header=BB191_5 Depth=3
	ldr	x8, [sp, #24]
	add	x8, x8, #72
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	strh	w8, [sp, #20]
	ldrh	w8, [sp, #20]
	mov	w10, #64                        ; =0x40
	sdiv	w9, w8, w10
	mul	w9, w9, w10
	subs	w9, w8, w9
	mov	x8, #1                          ; =0x1
                                        ; kill: def $x9 killed $w9
	lsl	x8, x8, x9
	str	x8, [sp, #8]
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldurh	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w9, [sp, #20]
	sdiv	w9, w9, w10
	ldr	x8, [x8, w9, sxtw #3]
	ldr	x9, [sp, #8]
	and	x8, x8, x9
	cbnz	x8, LBB191_8
	b	LBB191_7
LBB191_7:                               ;   in Loop: Header=BB191_5 Depth=3
	ldr	x11, [sp, #8]
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldurh	w9, [x29, #-24]
                                        ; kill: def $x9 killed $w9
	add	x9, x8, x9, lsl #5
	ldrh	w8, [sp, #20]
	mov	w10, #64                        ; =0x40
	sdiv	w10, w8, w10
	ldr	x8, [x9, w10, sxtw #3]
	orr	x8, x8, x11
	str	x8, [x9, w10, sxtw #3]
	ldrh	w8, [sp, #20]
	ldur	x9, [x29, #-16]
	mov	x10, #41112                     ; =0xa098
	movk	x10, #1, lsl #16
	add	x9, x9, x10
	ldurh	w10, [x29, #-26]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	sturh	w11, [x29, #-26]
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB191_8
LBB191_8:                               ;   in Loop: Header=BB191_5 Depth=3
	b	LBB191_9
LBB191_9:                               ;   in Loop: Header=BB191_5 Depth=3
	ldrb	w8, [sp, #23]
	add	w8, w8, #1
	strb	w8, [sp, #23]
	b	LBB191_5
LBB191_10:                              ;   in Loop: Header=BB191_3 Depth=2
	b	LBB191_3
LBB191_11:                              ;   in Loop: Header=BB191_1 Depth=1
	b	LBB191_12
LBB191_12:                              ;   in Loop: Header=BB191_1 Depth=1
	ldurh	w8, [x29, #-24]
	add	w8, w8, #1
	sturh	w8, [x29, #-24]
	b	LBB191_1
LBB191_13:
	strh	wzr, [sp, #6]
	b	LBB191_14
LBB191_14:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB191_16 Depth 2
	ldrh	w8, [sp, #6]
	ldurh	w9, [x29, #-22]
	subs	w8, w8, w9
	b.ge	LBB191_24
	b	LBB191_15
LBB191_15:                              ;   in Loop: Header=BB191_14 Depth=1
	ldrh	w8, [sp, #6]
	strh	w8, [sp, #4]
	strh	wzr, [sp, #2]
	b	LBB191_16
LBB191_16:                              ;   Parent Loop BB191_14 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #2]
	ldrh	w9, [sp, #6]
	subs	w8, w8, w9
	b.ge	LBB191_22
	b	LBB191_17
LBB191_17:                              ;   in Loop: Header=BB191_16 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldrh	w9, [sp, #6]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w9, [sp, #2]
	mov	w11, #64                        ; =0x40
	sdiv	w9, w9, w11
	ldr	x8, [x8, w9, sxtw #3]
	ldrh	w9, [sp, #2]
	sdiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB191_20
	b	LBB191_18
LBB191_18:                              ;   in Loop: Header=BB191_16 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #32920                      ; =0x8098
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldrh	w9, [sp, #2]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrh	w9, [sp, #6]
	mov	w11, #64                        ; =0x40
	sdiv	w9, w9, w11
	ldr	x8, [x8, w9, sxtw #3]
	ldrh	w9, [sp, #6]
	sdiv	w10, w9, w11
	mul	w10, w10, w11
	subs	w10, w9, w10
	mov	x9, #1                          ; =0x1
                                        ; kill: def $x10 killed $w10
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB191_20
	b	LBB191_19
LBB191_19:                              ;   in Loop: Header=BB191_14 Depth=1
	ldrh	w8, [sp, #2]
	strh	w8, [sp, #4]
	b	LBB191_22
LBB191_20:                              ;   in Loop: Header=BB191_16 Depth=2
	b	LBB191_21
LBB191_21:                              ;   in Loop: Header=BB191_16 Depth=2
	ldrh	w8, [sp, #2]
	add	w8, w8, #1
	strh	w8, [sp, #2]
	b	LBB191_16
LBB191_22:                              ;   in Loop: Header=BB191_14 Depth=1
	ldrh	w8, [sp, #4]
	ldur	x9, [x29, #-8]
	ldr	x11, [x9, #8]
	ldur	x9, [x29, #-8]
	ldr	x9, [x9]
	add	x9, x9, #2352
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #6]
	add	w9, w9, w10
	mov	w10, #136                       ; =0x88
	umaddl	x9, w9, w10, x11
	strh	w8, [x9, #2]
	b	LBB191_23
LBB191_23:                              ;   in Loop: Header=BB191_14 Depth=1
	ldrh	w8, [sp, #6]
	add	w8, w8, #1
	strh	w8, [sp, #6]
	b	LBB191_14
LBB191_24:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_scratch
_file_cyclic_scratch:                   ; @file_cyclic_scratch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-8]
	stur	x1, [x29, #-16]
	stur	w2, [x29, #-20]
	str	x3, [sp, #32]
	ldur	x8, [x29, #-8]
	add	x0, x8, #80
	mov	w1, #0                          ; =0x0
	mov	x2, #47152                      ; =0xb830
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	___memset_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-8]
	add	x8, x8, #80
	str	x8, [sp, #24]
	ldur	x8, [x29, #-16]
	ldr	x9, [sp, #24]
	str	x8, [x9]
	ldur	w8, [x29, #-20]
	ldr	x9, [sp, #24]
	str	w8, [x9, #8]
	ldr	x9, [sp, #24]
	mov	x8, #1                          ; =0x1
	str	x8, [x9, #24]
	ldr	x9, [sp, #24]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9, #40]
	ldur	x9, [x29, #-16]
	mov	x8, #1025                       ; =0x401
	str	x8, [x9, #8]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #24]
	strh	w8, [x9, #12]
	ldr	x8, [sp, #32]
	ldrh	w8, [x8, #4]
	ldr	x9, [sp, #24]
	strh	w8, [x9, #14]
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	mov	x10, #14384                     ; =0x3830
	add	x0, x9, x10
	add	x1, x8, #16
	mov	x2, #10240                      ; =0x2800
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	mov	x10, #24624                     ; =0x6030
	add	x0, x9, x10
	mov	x9, #10256                      ; =0x2810
	add	x1, x8, x9
	bl	___memcpy_chk
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	mov	x10, #34864                     ; =0x8830
	add	x0, x9, x10
	mov	x9, #20496                      ; =0x5010
	add	x1, x8, x9
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #24]
	ldr	x8, [sp, #32]
	mov	x10, #45104                     ; =0xb030
	add	x0, x9, x10
	mov	x9, #30736                      ; =0x7810
	add	x1, x8, x9
	mov	x2, #2048                       ; =0x800
	bl	___memcpy_chk
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_canonicalize
_file_cyclic_canonicalize:              ; @file_cyclic_canonicalize
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #320
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	add	x29, sp, #304
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #48
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	str	x0, [x8, #16]
	ldr	x9, [x8, #16]
	add	x9, x9, #80
	str	x9, [x8, #8]
	ldr	x9, [x8, #16]
	mov	x10, #47232                     ; =0xb880
	add	x9, x9, x10
	str	x9, [x8]
	ldr	x8, [x8, #8]
	ldrb	w8, [x8, #40]
	tbz	w8, #0, LBB193_3
	b	LBB193_1
LBB193_1:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrh	w8, [x8, #12]
	subs	w8, w8, #256
	b.hi	LBB193_3
	b	LBB193_2
LBB193_2:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	ldrh	w8, [x8, #14]
	subs	w8, w8, #256
	b.ls	LBB193_4
	b	LBB193_3
LBB193_3:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_4:
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	mov	w1, #0                          ; =0x0
	str	w1, [sp, #60]                   ; 4-byte Folded Spill
	mov	x2, #32784                      ; =0x8010
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #64]                   ; 8-byte Folded Spill
	bl	___memset_chk
	ldr	w1, [sp, #60]                   ; 4-byte Folded Reload
	ldr	x3, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #30872                      ; =0x7898
	movk	x9, #1, lsl #16
	add	x0, x8, x9
	mov	x2, #2048                       ; =0x800
	bl	___memset_chk
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
	ldr	x8, [x8]
	mov	x10, #24                        ; =0x18
	add	x11, x8, #24
	ldr	x8, [x9, #8]
	ldr	w8, [x8, #8]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	ldrh	w8, [x8, #2]
	ldr	x10, [x9]
	strh	w8, [x10]
	ldr	x8, [x9, #8]
	ldrh	w8, [x8, #12]
	ldr	x10, [x9]
	strh	w8, [x10, #2]
	ldr	x8, [x9, #8]
	ldrh	w8, [x8, #14]
	ldr	x9, [x9]
	strh	w8, [x9, #4]
	sturh	wzr, [x29, #-50]
	b	LBB193_5
LBB193_5:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-50]
	ldr	x9, [x9]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB193_12
	b	LBB193_6
LBB193_6:                               ;   in Loop: Header=BB193_5 Depth=1
	ldr	x11, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x8, [x11, #8]
	mov	x9, #14384                      ; =0x3830
	add	x10, x8, x9
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x9, w8, w9, x10
	ldr	x8, [x11, #8]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldr	x10, [x11, #8]
	ldr	x10, [x10]
	add	x10, x10, #1560
	ldr	x11, [x11, #8]
	ldr	w11, [x11, #8]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldurh	w11, [x29, #-50]
	add	w10, w10, w11
	add	x8, x8, w10, uxtw #4
	ldr	x0, [x9]
	ldr	x1, [x9, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB193_8
	b	LBB193_7
LBB193_7:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_8:                               ;   in Loop: Header=BB193_5 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x9, [x8, #8]
	mov	x10, #14384                     ; =0x3830
	add	x12, x9, x10
	ldurh	w9, [x29, #-50]
	mov	x10, x9
	mov	x9, #40                         ; =0x28
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x1, w10, w11, x12
	ldr	x8, [x8]
	add	x10, x8, #16
	ldurh	w8, [x29, #-50]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	sub	x0, x29, #96
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	and	w3, w8, #0x1
	bl	_file_cyclic_value
	stur	w0, [x29, #-56]
	ldur	w8, [x29, #-56]
	cbz	w8, LBB193_10
	b	LBB193_9
LBB193_9:
	ldur	w8, [x29, #-56]
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_10:                              ;   in Loop: Header=BB193_5 Depth=1
	b	LBB193_11
LBB193_11:                              ;   in Loop: Header=BB193_5 Depth=1
	ldurh	w8, [x29, #-50]
	add	w8, w8, #1
	sturh	w8, [x29, #-50]
	b	LBB193_5
LBB193_12:
	sturh	wzr, [x29, #-98]
	b	LBB193_13
LBB193_13:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-98]
	ldr	x9, [x9]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB193_20
	b	LBB193_14
LBB193_14:                              ;   in Loop: Header=BB193_13 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #24624                      ; =0x6030
	add	x10, x8, x9
	ldurh	w8, [x29, #-98]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB193_16
	b	LBB193_15
LBB193_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_16:                              ;   in Loop: Header=BB193_13 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #16]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	ldr	x9, [x8, #8]
	mov	x10, #24624                     ; =0x6030
	add	x12, x9, x10
	ldurh	w9, [x29, #-98]
	mov	x10, x9
	mov	x9, #40                         ; =0x28
	mov	x11, x9
                                        ; kill: def $w10 killed $w10 killed $x10
	umaddl	x1, w10, w11, x12
	ldr	x8, [x8]
	mov	x10, #10256                     ; =0x2810
	add	x10, x8, x10
	ldurh	w8, [x29, #-98]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	sub	x0, x29, #144
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	mov	w8, #0                          ; =0x0
	and	w3, w8, #0x1
	bl	_file_cyclic_value
	stur	w0, [x29, #-104]
	ldur	w8, [x29, #-104]
	cbz	w8, LBB193_18
	b	LBB193_17
LBB193_17:
	ldur	w8, [x29, #-104]
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_18:                              ;   in Loop: Header=BB193_13 Depth=1
	b	LBB193_19
LBB193_19:                              ;   in Loop: Header=BB193_13 Depth=1
	ldurh	w8, [x29, #-98]
	add	w8, w8, #1
	sturh	w8, [x29, #-98]
	b	LBB193_13
LBB193_20:
	sturh	wzr, [x29, #-146]
	b	LBB193_21
LBB193_21:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB193_25 Depth 2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-146]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ge	LBB193_32
	b	LBB193_22
LBB193_22:                              ;   in Loop: Header=BB193_21 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #45104                      ; =0xb030
	add	x8, x8, x9
	ldurh	w9, [x29, #-146]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	cbnz	x8, LBB193_24
	b	LBB193_23
LBB193_23:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_24:                              ;   in Loop: Header=BB193_21 Depth=1
	sturh	wzr, [x29, #-148]
	b	LBB193_25
LBB193_25:                              ;   Parent Loop BB193_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-148]
	ldurh	w9, [x29, #-146]
	subs	w8, w8, w9
	b.ge	LBB193_30
	b	LBB193_26
LBB193_26:                              ;   in Loop: Header=BB193_25 Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #8]
	mov	x10, #45104                     ; =0xb030
	add	x8, x8, x10
	ldurh	w11, [x29, #-146]
                                        ; kill: def $x11 killed $w11
	ldr	x8, [x8, x11, lsl #3]
	ldr	x9, [x9, #8]
	add	x9, x9, x10
	ldurh	w10, [x29, #-148]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	subs	x8, x8, x9
	b.ne	LBB193_28
	b	LBB193_27
LBB193_27:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_28:                              ;   in Loop: Header=BB193_25 Depth=2
	b	LBB193_29
LBB193_29:                              ;   in Loop: Header=BB193_25 Depth=2
	ldurh	w8, [x29, #-148]
	add	w8, w8, #1
	sturh	w8, [x29, #-148]
	b	LBB193_25
LBB193_30:                              ;   in Loop: Header=BB193_21 Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-146]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #513
	ldr	x9, [x9]
	mov	x10, #30736                     ; =0x7810
	add	x9, x9, x10
	ldurh	w10, [x29, #-146]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	b	LBB193_31
LBB193_31:                              ;   in Loop: Header=BB193_21 Depth=1
	ldurh	w8, [x29, #-146]
	add	w8, w8, #1
	sturh	w8, [x29, #-146]
	b	LBB193_21
LBB193_32:
	sturh	wzr, [x29, #-150]
	b	LBB193_33
LBB193_33:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB193_41 Depth 2
                                        ;     Child Loop BB193_59 Depth 2
                                        ;     Child Loop BB193_65 Depth 2
	ldurh	w8, [x29, #-150]
	subs	w8, w8, #256
	b.hs	LBB193_76
	b	LBB193_34
LBB193_34:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldurh	w8, [x29, #-150]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #112
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldrb	w8, [sp, #112]
	tbnz	w8, #0, LBB193_36
	b	LBB193_35
LBB193_35:                              ;   in Loop: Header=BB193_33 Depth=1
	b	LBB193_75
LBB193_36:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #120]
	cbz	x8, LBB193_39
	b	LBB193_37
LBB193_37:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #128]
	cbz	x8, LBB193_39
	b	LBB193_38
LBB193_38:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #8]
	ldurh	w1, [x29, #-150]
	add	x2, sp, #96
	bl	_live_reference
	tbnz	w0, #0, LBB193_40
	b	LBB193_39
LBB193_39:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_40:                              ;   in Loop: Header=BB193_33 Depth=1
	strh	wzr, [sp, #94]
	b	LBB193_41
LBB193_41:                              ;   Parent Loop BB193_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #94]
	ldurh	w9, [x29, #-150]
	subs	w8, w8, w9
	b.ge	LBB193_50
	b	LBB193_42
LBB193_42:                              ;   in Loop: Header=BB193_41 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB193_48
	b	LBB193_43
LBB193_43:                              ;   in Loop: Header=BB193_41 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #8]
	ldr	x9, [sp, #120]
	subs	x8, x8, x9
	b.ne	LBB193_46
	b	LBB193_44
LBB193_44:                              ;   in Loop: Header=BB193_41 Depth=2
	ldrb	w8, [sp, #144]
	tbz	w8, #0, LBB193_47
	b	LBB193_45
LBB193_45:                              ;   in Loop: Header=BB193_41 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #32]
	tbz	w8, #0, LBB193_47
	b	LBB193_46
LBB193_46:                              ;   in Loop: Header=BB193_41 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #34864                      ; =0x8830
	add	x10, x8, x9
	ldrh	w8, [sp, #94]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #128]
	subs	x8, x8, x9
	b.ne	LBB193_48
	b	LBB193_47
LBB193_47:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_48:                              ;   in Loop: Header=BB193_41 Depth=2
	b	LBB193_49
LBB193_49:                              ;   in Loop: Header=BB193_41 Depth=2
	ldrh	w8, [sp, #94]
	add	w8, w8, #1
	strh	w8, [sp, #94]
	b	LBB193_41
LBB193_50:                              ;   in Loop: Header=BB193_33 Depth=1
	ldrb	w8, [sp, #113]
	tbz	w8, #0, LBB193_58
	b	LBB193_51
LBB193_51:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x10, [sp, #72]                  ; 8-byte Folded Reload
	ldurh	w8, [x29, #-150]
	ldr	x9, [x10, #8]
	ldr	x9, [x9]
	mov	x11, #24                        ; =0x18
	add	x9, x9, #24
	ldr	x10, [x10, #8]
	ldr	w10, [x10, #8]
                                        ; kill: def $x10 killed $w10
                                        ; kill: def $w11 killed $w11 killed $x11
                                        ; kill: def $w10 killed $w10 killed $x10
	umull	x10, w10, w11
	ldrh	w9, [x9, x10]
	subs	w8, w8, w9
	b.ge	LBB193_56
	b	LBB193_52
LBB193_52:                              ;   in Loop: Header=BB193_33 Depth=1
	ldrh	w8, [sp, #114]
	ldurh	w9, [x29, #-150]
	subs	w8, w8, w9
	b.ne	LBB193_56
	b	LBB193_53
LBB193_53:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #136]
	cbnz	x8, LBB193_56
	b	LBB193_54
LBB193_54:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #120]
	ldurh	w9, [x29, #-150]
                                        ; kill: def $x9 killed $w9
	add	x9, x9, #257
	subs	x8, x8, x9
	b.ne	LBB193_56
	b	LBB193_55
LBB193_55:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #128]
	ldr	x9, [sp, #120]
	subs	x8, x8, x9
	b.eq	LBB193_57
	b	LBB193_56
LBB193_56:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_57:                              ;   in Loop: Header=BB193_33 Depth=1
	b	LBB193_74
LBB193_58:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	strh	wzr, [sp, #92]
	ldr	x8, [x8, #8]
	ldrh	w8, [x8, #14]
	strh	w8, [sp, #90]
	strh	wzr, [sp, #88]
	b	LBB193_59
LBB193_59:                              ;   Parent Loop BB193_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #88]
	ldr	x9, [x9]
	ldrh	w9, [x9, #6]
	subs	w8, w8, w9
	b.ge	LBB193_64
	b	LBB193_60
LBB193_60:                              ;   in Loop: Header=BB193_59 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #16]
	mov	x9, #30872                      ; =0x7898
	movk	x9, #1, lsl #16
	add	x8, x8, x9
	ldrh	w9, [sp, #88]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #120]
	subs	x8, x8, x9
	b.ne	LBB193_62
	b	LBB193_61
LBB193_61:                              ;   in Loop: Header=BB193_59 Depth=2
	ldrh	w8, [sp, #88]
	add	w8, w8, #1
	strh	w8, [sp, #92]
	b	LBB193_62
LBB193_62:                              ;   in Loop: Header=BB193_59 Depth=2
	b	LBB193_63
LBB193_63:                              ;   in Loop: Header=BB193_59 Depth=2
	ldrh	w8, [sp, #88]
	add	w8, w8, #1
	strh	w8, [sp, #88]
	b	LBB193_59
LBB193_64:                              ;   in Loop: Header=BB193_33 Depth=1
	strh	wzr, [sp, #86]
	b	LBB193_65
LBB193_65:                              ;   Parent Loop BB193_33 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #86]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ge	LBB193_70
	b	LBB193_66
LBB193_66:                              ;   in Loop: Header=BB193_65 Depth=2
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #8]
	mov	x9, #45104                      ; =0xb030
	add	x8, x8, x9
	ldrh	w9, [sp, #86]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldr	x9, [sp, #136]
	subs	x8, x8, x9
	b.ne	LBB193_68
	b	LBB193_67
LBB193_67:                              ;   in Loop: Header=BB193_65 Depth=2
	ldrh	w8, [sp, #86]
	strh	w8, [sp, #90]
	b	LBB193_68
LBB193_68:                              ;   in Loop: Header=BB193_65 Depth=2
	b	LBB193_69
LBB193_69:                              ;   in Loop: Header=BB193_65 Depth=2
	ldrh	w8, [sp, #86]
	add	w8, w8, #1
	strh	w8, [sp, #86]
	b	LBB193_65
LBB193_70:                              ;   in Loop: Header=BB193_33 Depth=1
	ldrh	w8, [sp, #92]
	cbz	w8, LBB193_72
	b	LBB193_71
LBB193_71:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #90]
	ldr	x9, [x9, #8]
	ldrh	w9, [x9, #14]
	subs	w8, w8, w9
	b.ne	LBB193_73
	b	LBB193_72
LBB193_72:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_73:                              ;   in Loop: Header=BB193_33 Depth=1
	ldrh	w8, [sp, #92]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #120]
	ldurh	w8, [x29, #-150]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #769
	str	x8, [sp, #128]
	ldrh	w8, [sp, #90]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #513
	str	x8, [sp, #136]
	b	LBB193_74
LBB193_74:                              ;   in Loop: Header=BB193_33 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	x9, #20496                      ; =0x5010
	add	x10, x8, x9
	ldurh	w8, [x29, #-150]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x0, w8, w9, x10
	add	x1, sp, #112
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldrh	w8, [x9, #8]
	add	w8, w8, #1
	strh	w8, [x9, #8]
	b	LBB193_75
LBB193_75:                              ;   in Loop: Header=BB193_33 Depth=1
	ldurh	w8, [x29, #-150]
	add	w8, w8, #1
	sturh	w8, [x29, #-150]
	b	LBB193_33
LBB193_76:
	strh	wzr, [sp, #84]
	b	LBB193_77
LBB193_77:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #84]
	ldr	x9, [x9]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB193_84
	b	LBB193_78
LBB193_78:                              ;   in Loop: Header=BB193_77 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	add	x10, x8, #16
	ldrh	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	cbz	w8, LBB193_82
	b	LBB193_79
LBB193_79:                              ;   in Loop: Header=BB193_77 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	x9, #20496                      ; =0x5010
	add	x10, x8, x9
	ldrh	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB193_81
	b	LBB193_80
LBB193_80:                              ;   in Loop: Header=BB193_77 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	x9, #20496                      ; =0x5010
	add	x10, x8, x9
	ldrh	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB193_82
	b	LBB193_81
LBB193_81:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB193_85
LBB193_82:                              ;   in Loop: Header=BB193_77 Depth=1
	b	LBB193_83
LBB193_83:                              ;   in Loop: Header=BB193_77 Depth=1
	ldrh	w8, [sp, #84]
	add	w8, w8, #1
	strh	w8, [sp, #84]
	b	LBB193_77
LBB193_84:
	stur	wzr, [x29, #-20]
	b	LBB193_85
LBB193_85:
	ldur	w0, [x29, #-20]
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_intern
_file_cyclic_intern:                    ; @file_cyclic_intern
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	w2, [x29, #-28]
	sturh	w3, [x29, #-30]
	stur	x4, [x29, #-40]
	ldur	x8, [x29, #-16]
	ldr	x10, [x8, #8]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldur	w9, [x29, #-28]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, #2352
	ldr	w8, [x8, x9, lsl #2]
	ldurh	w9, [x29, #-30]
	add	w8, w8, w9
	mov	w9, #136                        ; =0x88
	umaddl	x8, w8, w9, x10
	stur	x8, [x29, #-48]
	sturb	wzr, [x29, #-49]
	b	LBB194_1
LBB194_1:                               ; =>This Inner Loop Header: Depth=1
	ldurb	w8, [x29, #-49]
	ldur	x9, [x29, #-48]
	ldrb	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB194_6
	b	LBB194_2
LBB194_2:                               ;   in Loop: Header=BB194_1 Depth=1
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurb	w9, [x29, #-49]
                                        ; kill: def $x9 killed $w9
	ldr	x0, [x8, x9, lsl #3]
	ldur	x8, [x29, #-24]
	mov	x9, #47232                      ; =0xb880
	add	x1, x8, x9
	bl	_file_cyclic_stored_equal
	tbz	w0, #0, LBB194_4
	b	LBB194_3
LBB194_3:
	ldurb	w8, [x29, #-49]
	ldur	x9, [x29, #-40]
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB194_20
LBB194_4:                               ;   in Loop: Header=BB194_1 Depth=1
	b	LBB194_5
LBB194_5:                               ;   in Loop: Header=BB194_1 Depth=1
	ldurb	w8, [x29, #-49]
	add	w8, w8, #1
	sturb	w8, [x29, #-49]
	b	LBB194_1
LBB194_6:
	sturh	wzr, [x29, #-52]
	sturh	wzr, [x29, #-54]
	b	LBB194_7
LBB194_7:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-54]
	subs	w8, w8, #256
	b.hs	LBB194_12
	b	LBB194_8
LBB194_8:                               ;   in Loop: Header=BB194_7 Depth=1
	ldur	x8, [x29, #-24]
	mov	x9, #2192                       ; =0x890
	movk	x9, #1, lsl #16
	add	x10, x8, x9
	ldurh	w8, [x29, #-54]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	ldrb	w8, [x8]
	tbz	w8, #0, LBB194_10
	b	LBB194_9
LBB194_9:                               ;   in Loop: Header=BB194_7 Depth=1
	ldurh	w8, [x29, #-54]
	add	w8, w8, #1
	sturh	w8, [x29, #-52]
	b	LBB194_10
LBB194_10:                              ;   in Loop: Header=BB194_7 Depth=1
	b	LBB194_11
LBB194_11:                              ;   in Loop: Header=BB194_7 Depth=1
	ldurh	w8, [x29, #-54]
	add	w8, w8, #1
	sturh	w8, [x29, #-54]
	b	LBB194_7
LBB194_12:
	ldur	x8, [x29, #-24]
	mov	x10, #47232                     ; =0xb880
	ldrh	w8, [x8, x10]
                                        ; kill: def $x8 killed $w8
	ldur	x9, [x29, #-24]
	add	x9, x9, x10
	ldrh	w9, [x9, #2]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	mov	x9, #40                         ; =0x28
	mov	x11, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x8, w8, w11
	add	x11, x8, #168
	ldurh	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x11
	ldur	x9, [x29, #-24]
	add	x9, x9, x10
	ldrh	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #3
	str	x8, [sp, #48]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	subs	w8, w8, #16
	b.eq	LBB194_16
	b	LBB194_13
LBB194_13:
	ldur	x8, [x29, #-24]
	mov	x9, #30868                      ; =0x7894
	movk	x9, #1, lsl #16
	ldr	w8, [x8, x9]
	subs	w8, w8, #1, lsl #12             ; =4096
	b.eq	LBB194_16
	b	LBB194_14
LBB194_14:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #28]
	subs	w8, w8, #16, lsl #12            ; =65536
	b.eq	LBB194_16
	b	LBB194_15
LBB194_15:
	ldur	x0, [x29, #-16]
	ldr	x2, [sp, #48]
	mov	x1, #1                          ; =0x1
	bl	_file_cyclic_room
	tbnz	w0, #0, LBB194_17
	b	LBB194_16
LBB194_16:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB194_20
LBB194_17:
	ldr	x1, [sp, #48]
	mov	x0, #1                          ; =0x1
	bl	_calloc
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbnz	x8, LBB194_19
	b	LBB194_18
LBB194_18:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-4]
	b	LBB194_20
LBB194_19:
	ldr	x10, [sp, #40]
	ldur	x8, [x29, #-24]
	mov	x9, #47232                      ; =0xb880
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	add	x8, x8, x9
	ldr	x11, [x8]
	str	x11, [x10]
	ldrh	w8, [x8, #8]
	strh	w8, [x10, #8]
	ldurh	w8, [x29, #-52]
	ldr	x10, [sp, #40]
	strh	w8, [x10, #48]
	ldr	x8, [sp, #40]
	add	x8, x8, #168
	ldr	x10, [sp, #40]
	str	x8, [x10, #16]
	ldr	x8, [sp, #40]
	ldr	x11, [x8, #16]
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, x9]
	mov	w10, #40                        ; =0x28
	smaddl	x8, w8, w10, x11
	ldr	x10, [sp, #40]
	str	x8, [x10, #24]
	ldr	x8, [sp, #40]
	ldr	x11, [x8, #24]
	ldur	x8, [x29, #-24]
	add	x8, x8, x9
	ldrh	w8, [x8, #2]
	mov	w10, #40                        ; =0x28
	smaddl	x8, w8, w10, x11
	ldr	x10, [sp, #40]
	str	x8, [x10, #32]
	ldr	x8, [sp, #40]
	ldr	x11, [x8, #32]
	ldurh	w8, [x29, #-52]
	mov	w10, #40                        ; =0x28
	smaddl	x8, w8, w10, x11
	ldr	x10, [sp, #40]
	str	x8, [x10, #40]
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #16]
	ldur	x8, [x29, #-24]
	mov	x10, #47248                     ; =0xb890
	add	x1, x8, x10
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, x9]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	mov	x3, #-1                         ; =0xffffffffffffffff
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	bl	___memcpy_chk
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #24]
	ldur	x8, [x29, #-24]
	mov	x11, #57488                     ; =0xe090
	add	x1, x8, x11
	ldur	x8, [x29, #-24]
	add	x8, x8, x10
	ldrh	w8, [x8, #2]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	___memcpy_chk
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #32]
	ldur	x8, [x29, #-24]
	mov	x10, #2192                      ; =0x890
	movk	x10, #1, lsl #16
	add	x1, x8, x10
	ldurh	w8, [x29, #-52]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umull	x2, w8, w9
	bl	___memcpy_chk
	ldr	x3, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]
	ldr	x0, [x8, #40]
	ldur	x8, [x29, #-24]
	mov	x10, #12432                     ; =0x3090
	movk	x10, #1, lsl #16
	add	x1, x8, x10
	ldur	x8, [x29, #-24]
	add	x8, x8, x9
	ldrh	w8, [x8, #4]
                                        ; kill: def $x8 killed $w8
	lsl	x2, x8, #3
	bl	___memcpy_chk
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #40]
	ldur	x8, [x29, #-24]
	add	x8, x8, x10
	ldr	x10, [x8]
	str	x10, [x9, #56]
	ldrh	w8, [x8, #8]
	strh	w8, [x9, #64]
	ldr	x9, [sp, #40]
	mov	w8, #255                        ; =0xff
	strb	w8, [x9, #158]
	ldr	x9, [sp, #40]
	strb	w8, [x9, #157]
	ldur	x8, [x29, #-48]
	ldrb	w8, [x8]
	strb	w8, [sp, #39]
	ldr	x8, [sp, #40]
	ldur	x9, [x29, #-48]
	add	x9, x9, #8
	ldrb	w10, [sp, #39]
                                        ; kill: def $x10 killed $w10
	str	x8, [x9, x10, lsl #3]
	ldur	x9, [x29, #-48]
	ldrb	w8, [x9]
	add	w8, w8, #1
	strb	w8, [x9]
	ldur	x9, [x29, #-16]
	ldr	w8, [x9, #28]
	add	w8, w8, #1
	str	w8, [x9, #28]
	ldur	x8, [x29, #-24]
	mov	x9, #14480                      ; =0x3890
	movk	x9, #1, lsl #16
	add	x9, x8, x9
	ldur	x8, [x29, #-24]
	mov	x10, #30868                     ; =0x7894
	movk	x10, #1, lsl #16
	add	x11, x8, x10
	ldr	w8, [x11]
	mov	x10, x8
	mov	x8, x10
	add	w8, w8, #1
	str	w8, [x11]
	ldurh	w8, [x29, #-30]
	strh	w8, [sp, #34]
	ldrb	w8, [sp, #39]
	strb	w8, [sp, #36]
	strb	wzr, [sp, #37]
	ldur	w8, [sp, #34]
	str	w8, [x9, x10, lsl #2]
	ldrb	w8, [sp, #39]
	ldur	x9, [x29, #-40]
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB194_20
LBB194_20:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_value
_file_cyclic_value:                     ; @file_cyclic_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-16]
	mov	x8, x1
	stur	x8, [x29, #-24]
	stur	x2, [x29, #-32]
	sturb	w3, [x29, #-33]
	ldrb	w8, [x1, #1]
	cbz	w8, LBB195_6
	b	LBB195_1
LBB195_1:
	ldurb	w8, [x29, #-33]
	tbz	w8, #0, LBB195_5
	b	LBB195_2
LBB195_2:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #1]
	subs	w8, w8, #1
	b.eq	LBB195_4
	b	LBB195_3
LBB195_3:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #1]
	subs	w8, w8, #2
	b.ne	LBB195_5
	b	LBB195_4
LBB195_4:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #12]
	subs	w8, w8, #1
	b.eq	LBB195_6
	b	LBB195_5
LBB195_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_6:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #16]
	tbnz	w8, #0, LBB195_11
	b	LBB195_7
LBB195_7:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbnz	x8, LBB195_9
	b	LBB195_8
LBB195_8:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #1]
	cbz	w8, LBB195_10
	b	LBB195_9
LBB195_9:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_10:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	add	x8, sp, #32
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, #0                          ; =0x0
	and	w2, w9, #0x1
	mov	x3, #0                          ; =0x0
	bl	_initial_value
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB195_26
LBB195_11:
	ldurb	w8, [x29, #-33]
	tbnz	w8, #0, LBB195_14
	b	LBB195_12
LBB195_12:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldrb	w8, [x8, #1]
	cbz	w8, LBB195_14
	b	LBB195_13
LBB195_13:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_14:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	subs	x8, x8, #0
	cset	w8, ne
	subs	w8, w0, w8
	b.eq	LBB195_16
	b	LBB195_15
LBB195_15:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_16:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_result_type
	tbz	w0, #0, LBB195_22
	b	LBB195_17
LBB195_17:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	subs	w8, w8, #1
	b.eq	LBB195_21
	b	LBB195_18
LBB195_18:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	subs	w8, w8, #2
	b.eq	LBB195_21
	b	LBB195_19
LBB195_19:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	subs	w8, w8, #3
	b.eq	LBB195_21
	b	LBB195_20
LBB195_20:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_21:
	b	LBB195_25
LBB195_22:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	cbz	w8, LBB195_24
	b	LBB195_23
LBB195_23:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_24:
	b	LBB195_25
LBB195_25:
	b	LBB195_26
LBB195_26:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #24]
	cbz	x8, LBB195_36
	b	LBB195_27
LBB195_27:
	ldur	x8, [x29, #-16]
	mov	x9, #47232                      ; =0xb880
	add	x8, x8, x9
	ldrh	w8, [x8, #6]
	strh	w8, [sp, #30]
	ldrh	w8, [sp, #30]
	subs	w8, w8, #256
	b.ne	LBB195_29
	b	LBB195_28
LBB195_28:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_29:
	strh	wzr, [sp, #28]
	b	LBB195_30
LBB195_30:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #28]
	ldrh	w9, [sp, #30]
	subs	w8, w8, w9
	b.ge	LBB195_35
	b	LBB195_31
LBB195_31:                              ;   in Loop: Header=BB195_30 Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x8, [x29, #-16]
	mov	x10, #30872                     ; =0x7898
	movk	x10, #1, lsl #16
	add	x8, x8, x10
	ldrh	w10, [sp, #28]
                                        ; kill: def $x10 killed $w10
	ldr	x8, [x8, x10, lsl #3]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.ne	LBB195_33
	b	LBB195_32
LBB195_32:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB195_37
LBB195_33:                              ;   in Loop: Header=BB195_30 Depth=1
	b	LBB195_34
LBB195_34:                              ;   in Loop: Header=BB195_30 Depth=1
	ldrh	w8, [sp, #28]
	add	w8, w8, #1
	strh	w8, [sp, #28]
	b	LBB195_30
LBB195_35:
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #24]
	ldur	x10, [x29, #-16]
	mov	x11, #30872                     ; =0x7898
	movk	x11, #1, lsl #16
	add	x10, x10, x11
	ldrh	w11, [sp, #30]
                                        ; kill: def $x11 killed $w11
	str	x8, [x10, x11, lsl #3]
	ldrh	w8, [sp, #30]
                                        ; kill: def $x8 killed $w8
	add	x8, x8, #1
	str	x8, [x9, #24]
	ldur	x8, [x29, #-16]
	mov	x9, #47232                      ; =0xb880
	add	x9, x8, x9
	ldrh	w8, [x9, #6]
	add	w8, w8, #1
	strh	w8, [x9, #6]
	b	LBB195_36
LBB195_36:
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldur	x0, [x29, #-32]
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	stur	wzr, [x29, #-4]
	b	LBB195_37
LBB195_37:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_stored_equal
_file_cyclic_stored_equal:              ; @file_cyclic_stored_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB196_5
	b	LBB196_1
LBB196_1:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB196_5
	b	LBB196_2
LBB196_2:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB196_5
	b	LBB196_3
LBB196_3:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #6]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #6]
	subs	w8, w8, w9
	b.ne	LBB196_5
	b	LBB196_4
LBB196_4:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB196_6
	b	LBB196_5
LBB196_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_6:
	sturh	wzr, [x29, #-42]
	b	LBB196_7
LBB196_7:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-42]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB196_12
	b	LBB196_8
LBB196_8:                               ;   in Loop: Header=BB196_7 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x11, [x8, #16]
	ldurh	w8, [x29, #-42]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w10, x11
	ldur	x8, [x29, #-40]
	add	x10, x8, #16
	ldurh	w8, [x29, #-42]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	sub	x0, x29, #88
	str	x0, [sp, #64]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #56]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	sub	x0, x29, #128
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	bl	_file_cyclic_value_equal
	tbnz	w0, #0, LBB196_10
	b	LBB196_9
LBB196_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_10:                              ;   in Loop: Header=BB196_7 Depth=1
	b	LBB196_11
LBB196_11:                              ;   in Loop: Header=BB196_7 Depth=1
	ldurh	w8, [x29, #-42]
	add	w8, w8, #1
	sturh	w8, [x29, #-42]
	b	LBB196_7
LBB196_12:
	sturh	wzr, [x29, #-130]
	b	LBB196_13
LBB196_13:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-130]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB196_18
	b	LBB196_14
LBB196_14:                              ;   in Loop: Header=BB196_13 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x11, [x8, #24]
	ldurh	w8, [x29, #-130]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w10, x11
	ldur	x8, [x29, #-40]
	mov	x10, #10256                     ; =0x2810
	add	x10, x8, x10
	ldurh	w8, [x29, #-130]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	sub	x0, x29, #176
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #24]                   ; 8-byte Folded Reload
	add	x0, sp, #168
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_file_cyclic_value_equal
	tbnz	w0, #0, LBB196_16
	b	LBB196_15
LBB196_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_16:                              ;   in Loop: Header=BB196_13 Depth=1
	b	LBB196_17
LBB196_17:                              ;   in Loop: Header=BB196_13 Depth=1
	ldurh	w8, [x29, #-130]
	add	w8, w8, #1
	sturh	w8, [x29, #-130]
	b	LBB196_13
LBB196_18:
	strh	wzr, [sp, #166]
	b	LBB196_19
LBB196_19:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #166]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB196_24
	b	LBB196_20
LBB196_20:                              ;   in Loop: Header=BB196_19 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x8, [x8, #40]
	ldrh	w9, [sp, #166]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-40]
	mov	x10, #30736                     ; =0x7810
	add	x9, x9, x10
	ldrh	w10, [sp, #166]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	subs	x8, x8, x9
	b.eq	LBB196_22
	b	LBB196_21
LBB196_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_22:                              ;   in Loop: Header=BB196_19 Depth=1
	b	LBB196_23
LBB196_23:                              ;   in Loop: Header=BB196_19 Depth=1
	ldrh	w8, [sp, #166]
	add	w8, w8, #1
	strh	w8, [sp, #166]
	b	LBB196_19
LBB196_24:
	strh	wzr, [sp, #164]
	b	LBB196_25
LBB196_25:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #164]
	subs	w8, w8, #256
	b.hs	LBB196_33
	b	LBB196_26
LBB196_26:                              ;   in Loop: Header=BB196_25 Depth=1
	ldrh	w8, [sp, #164]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #48]
	subs	w8, w8, w9
	b.ge	LBB196_28
	b	LBB196_27
LBB196_27:                              ;   in Loop: Header=BB196_25 Depth=1
	ldur	x8, [x29, #-32]
	ldr	x10, [x8, #32]
	ldrh	w8, [sp, #164]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #120
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	b	LBB196_29
LBB196_28:                              ;   in Loop: Header=BB196_25 Depth=1
	add	x0, sp, #120
	mov	x2, #40                         ; =0x28
	mov	w1, #0                          ; =0x0
	bl	_memset
	b	LBB196_29
LBB196_29:                              ;   in Loop: Header=BB196_25 Depth=1
	ldur	x8, [x29, #-40]
	mov	x9, #20496                      ; =0x5010
	add	x10, x8, x9
	ldrh	w8, [sp, #164]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w9, x10
	add	x0, sp, #80
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	bl	_memcpy
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, sp, #120
	bl	_reference_same
	tbnz	w0, #0, LBB196_31
	b	LBB196_30
LBB196_30:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_31:                              ;   in Loop: Header=BB196_25 Depth=1
	b	LBB196_32
LBB196_32:                              ;   in Loop: Header=BB196_25 Depth=1
	ldrh	w8, [sp, #164]
	add	w8, w8, #1
	strh	w8, [sp, #164]
	b	LBB196_25
LBB196_33:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB196_34
LBB196_34:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_room
_file_cyclic_room:                      ; @file_cyclic_room
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	str	x1, [sp, #24]
	str	x2, [sp, #16]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #40]
	add	x0, sp, #8
	str	x8, [sp, #8]
	ldr	x1, [sp, #24]
	ldr	x2, [sp, #16]
	bl	_file_code_budget
	tbz	w0, #0, LBB197_2
	b	LBB197_1
LBB197_1:
	ldr	x8, [sp, #8]
	mov	x9, #16777216                   ; =0x1000000
	subs	x8, x8, x9
	b.ls	LBB197_3
	b	LBB197_2
LBB197_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB197_4
LBB197_3:
	ldr	x8, [sp, #8]
	ldur	x9, [x29, #-16]
	str	x8, [x9, #40]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB197_4
LBB197_4:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_value_equal
_file_cyclic_value_equal:               ; @file_cyclic_value_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x0, [sp]                        ; 8-byte Folded Spill
	mov	x8, x1
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	x0, x1
	stur	x0, [x29, #-8]
	stur	x8, [x29, #-16]
	sub	x0, x29, #56
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, sp, #48
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	bl	_value_same
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	tbz	w0, #0, LBB198_2
	b	LBB198_1
LBB198_1:
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	w8, [x8, #32]
	ldr	w9, [x9, #32]
	subs	w8, w8, w9
	cset	w8, eq
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB198_2
LBB198_2:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_supported
_file_code_supported:                   ; @file_code_supported
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-1]
	ldurb	w0, [x29, #-1]
	mov	w8, #0                          ; =0x0
	and	w1, w8, #0x1
	bl	_file_code_supported_mode
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_fact
_file_ch_fact:                          ; @file_ch_fact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #400
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	add	x29, sp, #384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #164
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	stur	x2, [x29, #-48]
	ldur	x8, [x29, #-48]
	add	x8, x8, #20
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-40]
	ldrb	w8, [x8, #8]
	sturb	w8, [x29, #-57]
	stur	wzr, [x29, #-64]
	mov	w8, #65535                      ; =0xffff
	sturh	w8, [x29, #-66]
	ldurb	w8, [x29, #-57]
	str	w8, [sp, #60]                   ; 4-byte Folded Spill
	subs	w8, w8, #15
	b.eq	LBB200_12
	b	LBB200_1
LBB200_1:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB200_12
	b	LBB200_2
LBB200_2:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #61
	b.eq	LBB200_11
	b	LBB200_3
LBB200_3:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #145
	b.eq	LBB200_13
	b	LBB200_4
LBB200_4:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #148
	b.eq	LBB200_8
	b	LBB200_5
LBB200_5:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #149
	b.eq	LBB200_9
	b	LBB200_6
LBB200_6:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #151
	b.eq	LBB200_12
	b	LBB200_7
LBB200_7:
	ldr	w8, [sp, #60]                   ; 4-byte Folded Reload
	subs	w8, w8, #161
	b.eq	LBB200_10
	b	LBB200_14
LBB200_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-64]
	ldur	x8, [x29, #-40]
	ldrh	w8, [x8, #16]
	sturh	w8, [x29, #-66]
	b	LBB200_15
LBB200_9:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-64]
	b	LBB200_15
LBB200_10:
	mov	w8, #3                          ; =0x3
	stur	w8, [x29, #-64]
	b	LBB200_15
LBB200_11:
	mov	w8, #4                          ; =0x4
	stur	w8, [x29, #-64]
	b	LBB200_15
LBB200_12:
	mov	w8, #5                          ; =0x5
	stur	w8, [x29, #-64]
	b	LBB200_15
LBB200_13:
	mov	w8, #6                          ; =0x6
	stur	w8, [x29, #-64]
	b	LBB200_15
LBB200_14:
	b	LBB200_15
LBB200_15:
	ldurb	w9, [x29, #-57]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #59
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b.eq	LBB200_19
	b	LBB200_16
LBB200_16:
	ldurb	w9, [x29, #-57]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #15
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b.eq	LBB200_18
	b	LBB200_17
LBB200_17:
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #151
	cset	w8, eq
	str	w8, [sp, #40]                   ; 4-byte Folded Spill
	b	LBB200_18
LBB200_18:
	ldr	w8, [sp, #40]                   ; 4-byte Folded Reload
	str	w8, [sp, #44]                   ; 4-byte Folded Spill
	b	LBB200_19
LBB200_19:
	ldr	w8, [sp, #44]                   ; 4-byte Folded Reload
	mov	w9, #1                          ; =0x1
	and	w8, w8, w9
	sturb	w8, [x29, #-67]
	ldurb	w8, [x29, #-57]
	subs	w8, w8, #145
	cset	w8, eq
	sturb	w8, [x29, #-68]
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB200_29
	b	LBB200_20
LBB200_20:
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #12]
	ldur	w9, [x29, #-64]
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_21
LBB200_21:
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #8]
	ldurh	w9, [x29, #-66]
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_22
LBB200_22:
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #2]
	and	w8, w8, #0x1
	ldurb	w9, [x29, #-57]
	subs	w9, w9, #146
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_23
LBB200_23:
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #1]
	and	w8, w8, #0x1
	ldurb	w9, [x29, #-57]
	subs	w9, w9, #61
	cset	w9, eq
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_24
LBB200_24:
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_25
LBB200_25:
	ldur	x8, [x29, #-56]
	ldrh	w8, [x8, #6]
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB200_29
	b	LBB200_26
LBB200_26:
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8, #3]
	and	w8, w8, #0x1
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	ldurb	w8, [x29, #-67]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #36]                   ; 4-byte Folded Spill
	tbnz	w8, #0, LBB200_28
	b	LBB200_27
LBB200_27:
	ldurb	w8, [x29, #-68]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	b	LBB200_28
LBB200_28:
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	ldr	w9, [sp, #36]                   ; 4-byte Folded Reload
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.eq	LBB200_30
	b	LBB200_29
LBB200_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_30:
	sub	x0, x29, #124
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	stur	wzr, [x29, #-128]
	mov	w8, #128                        ; =0x80
	stur	w8, [x29, #-132]
	ldurb	w8, [x29, #-67]
	tbz	w8, #0, LBB200_40
	b	LBB200_31
LBB200_31:
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #16]
	stur	w8, [x29, #-136]
	ldur	w8, [x29, #-136]
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB200_33
	b	LBB200_32
LBB200_32:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_33:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldur	x9, [x29, #-32]
	ldr	x9, [x9]
	add	x11, x9, #48
	ldur	w9, [x29, #-136]
                                        ; kill: def $x9 killed $w9
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w9 killed $w9 killed $x9
	umaddl	x9, w9, w10, x11
	add	x9, x9, #12
	stur	x9, [x29, #-144]
	mov	w9, #1                          ; =0x1
	stur	w9, [x29, #-124]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9]
	stur	w9, [x29, #-120]
	ldur	w9, [x29, #-136]
	stur	w9, [x29, #-116]
	ldur	x9, [x29, #-144]
	ldrh	w9, [x9]
	sturh	w9, [x29, #-100]
	ldur	x9, [x29, #-144]
	ldrb	w9, [x9, #4]
	sturb	w9, [x29, #-94]
	ldur	x9, [x29, #-144]
	ldur	q0, [x9, #8]
	stur	q0, [x8, #72]
	sturh	wzr, [x29, #-146]
	b	LBB200_34
LBB200_34:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-146]
	ldur	x9, [x29, #-144]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB200_39
	b	LBB200_35
LBB200_35:                              ;   in Loop: Header=BB200_34 Depth=1
	ldur	x0, [x29, #-32]
	ldur	w1, [x29, #-136]
	ldurh	w2, [x29, #-146]
	sub	x3, x29, #164
	bl	_nvm_file_cyclic_local
	tbnz	w0, #0, LBB200_37
	b	LBB200_36
LBB200_36:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_37:                              ;   in Loop: Header=BB200_34 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	ldurh	w8, [x29, #-98]
	add	w8, w8, w0
	sturh	w8, [x29, #-98]
	ldurb	w9, [x29, #-163]
	ldurh	w8, [x29, #-96]
	subs	w9, w9, #0
	cinc	w8, w8, ne
	sturh	w8, [x29, #-96]
	b	LBB200_38
LBB200_38:                              ;   in Loop: Header=BB200_34 Depth=1
	ldurh	w8, [x29, #-146]
	add	w8, w8, #1
	sturh	w8, [x29, #-146]
	b	LBB200_34
LBB200_39:
	ldur	w9, [x29, #-132]
	mov	w8, #64                         ; =0x40
	orr	w9, w9, #0x40
	orr	w9, w9, #0x100
	stur	w9, [x29, #-112]
	stur	w8, [x29, #-128]
	ldur	w8, [x29, #-112]
	stur	w8, [x29, #-132]
	b	LBB200_67
LBB200_40:
	ldurb	w8, [x29, #-68]
	tbz	w8, #0, LBB200_66
	b	LBB200_41
LBB200_41:
	ldur	x8, [x29, #-40]
	ldr	w8, [x8, #592]
	mov	x0, x8
	bl	_nl_file_catalog_method
	stur	x0, [x29, #-176]
	ldur	x8, [x29, #-176]
	cbz	x8, LBB200_46
	b	LBB200_42
LBB200_42:
	ldur	x8, [x29, #-176]
	ldr	x8, [x8, #56]
	cbz	x8, LBB200_46
	b	LBB200_43
LBB200_43:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-40]
	ldr	w1, [x8, #592]
	sub	x2, x29, #180
	bl	_nvm_file_cyclic_import
	tbz	w0, #0, LBB200_46
	b	LBB200_44
LBB200_44:
	ldur	w8, [x29, #-180]
	ldur	x9, [x29, #-40]
	ldr	w9, [x9, #16]
	subs	w8, w8, w9
	b.ne	LBB200_46
	b	LBB200_45
LBB200_45:
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-176]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldur	x9, [x29, #-176]
	ldr	x9, [x9, #56]
	subs	x9, x9, #1
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	sub	x8, x29, #124
	add	x3, x8, #32
	mov	w1, #0                          ; =0x0
	bl	_file_ch_member
	tbnz	w0, #0, LBB200_47
	b	LBB200_46
LBB200_46:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_47:
	stur	wzr, [x29, #-124]
	ldur	x8, [x29, #-40]
	ldr	w8, [x8]
	stur	w8, [x29, #-120]
	ldur	w8, [x29, #-180]
	stur	w8, [x29, #-116]
	ldur	x8, [x29, #-176]
	ldr	x8, [x8, #56]
	subs	x8, x8, #1
                                        ; kill: def $w8 killed $w8 killed $x8
	sturh	w8, [x29, #-100]
	mov	w8, #1                          ; =0x1
	sturb	w8, [x29, #-94]
	ldur	x8, [x29, #-176]
	ldr	w8, [x8, #36]
	stur	w8, [x29, #-108]
	ldur	x8, [x29, #-176]
	ldr	w8, [x8, #40]
	stur	w8, [x29, #-104]
	ldur	x8, [x29, #-176]
	ldr	w0, [x8, #64]
	bl	_input_state
	stur	w0, [x29, #-76]
	ldur	x8, [x29, #-176]
	ldr	w0, [x8, #80]
	bl	_input_state
	stur	w0, [x29, #-72]
	ldur	w8, [x29, #-132]
	mov	w9, #271                        ; =0x10f
	orr	w8, w8, w9
	stur	w8, [x29, #-132]
	ldur	x8, [x29, #-176]
	ldr	w8, [x8, #44]
	subs	w8, w8, #1
	b.ne	LBB200_49
	b	LBB200_48
LBB200_48:
	mov	w8, #1                          ; =0x1
	sturh	w8, [x29, #-96]
	ldur	w8, [x29, #-132]
	orr	w8, w8, #0x10
	stur	w8, [x29, #-132]
	b	LBB200_52
LBB200_49:
	ldur	x8, [x29, #-176]
	ldr	w8, [x8, #44]
	subs	w8, w8, #2
	b.ne	LBB200_51
	b	LBB200_50
LBB200_50:
	mov	w8, #1                          ; =0x1
	sturh	w8, [x29, #-98]
	b	LBB200_51
LBB200_51:
	b	LBB200_52
LBB200_52:
	str	xzr, [sp, #192]
	b	LBB200_53
LBB200_53:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #192]
	add	x8, x8, #1
	ldur	x9, [x29, #-176]
	ldr	x9, [x9, #56]
	subs	x8, x8, x9
	b.hs	LBB200_65
	b	LBB200_54
LBB200_54:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	x8, [x29, #-176]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #192]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #40]
	subs	w8, w8, #1
	b.ne	LBB200_56
	b	LBB200_55
LBB200_55:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	w8, [x29, #-132]
	orr	w8, w8, #0x20
	stur	w8, [x29, #-132]
	b	LBB200_56
LBB200_56:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	x8, [x29, #-176]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #192]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	w8, [x8, #40]
	subs	w8, w8, #5
	b.ne	LBB200_58
	b	LBB200_57
LBB200_57:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	w8, [x29, #-132]
	mov	w9, #0                          ; =0x0
	orr	w8, w8, w9
	stur	w8, [x29, #-132]
	b	LBB200_58
LBB200_58:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	x0, [x29, #-32]
	ldur	x8, [x29, #-176]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #192]
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	mov	w1, #0                          ; =0x0
	add	x3, sp, #176
	bl	_file_ch_member
	tbnz	w0, #0, LBB200_60
	b	LBB200_59
LBB200_59:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_60:                              ;   in Loop: Header=BB200_53 Depth=1
	ldr	w8, [sp, #184]
	adds	w8, w8, #1
	b.ne	LBB200_63
	b	LBB200_61
LBB200_61:                              ;   in Loop: Header=BB200_53 Depth=1
	ldr	w8, [sp, #188]
	subs	w8, w8, #4
	b.ne	LBB200_63
	b	LBB200_62
LBB200_62:                              ;   in Loop: Header=BB200_53 Depth=1
	ldur	w8, [x29, #-132]
	mov	w9, #0                          ; =0x0
	orr	w8, w8, w9
	stur	w8, [x29, #-132]
	b	LBB200_63
LBB200_63:                              ;   in Loop: Header=BB200_53 Depth=1
	b	LBB200_64
LBB200_64:                              ;   in Loop: Header=BB200_53 Depth=1
	ldr	x8, [sp, #192]
	add	x8, x8, #1
	str	x8, [sp, #192]
	b	LBB200_53
LBB200_65:
	ldur	w8, [x29, #-132]
	stur	w8, [x29, #-112]
	b	LBB200_66
LBB200_66:
	b	LBB200_67
LBB200_67:
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #16]
	ldur	w9, [x29, #-128]
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b.ne	LBB200_70
	b	LBB200_68
LBB200_68:
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #20]
	ldur	w9, [x29, #-132]
	ldur	w10, [x29, #-128]
	bic	w9, w9, w10
	mov	w0, #0                          ; =0x0
	subs	w8, w8, w9
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b.ne	LBB200_70
	b	LBB200_69
LBB200_69:
	ldur	x8, [x29, #-56]
	add	x1, x8, #24
	add	x0, sp, #120
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp]                        ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	add	x0, sp, #64
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	sub	x1, x29, #124
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	bl	_obligation_same
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB200_70
LBB200_70:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB200_71
LBB200_71:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_peak
_file_ch_peak:                          ; @file_ch_peak
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]
	ldurh	w8, [x29, #-16]
	strh	w8, [sp, #32]
	str	x0, [sp, #16]
	ldrh	w8, [sp, #24]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #40]
	subs	w8, w8, w9
	b.ne	LBB201_5
	b	LBB201_1
LBB201_1:
	ldrh	w8, [sp, #26]
	subs	w8, w8, #256
	b.hi	LBB201_5
	b	LBB201_2
LBB201_2:
	ldrh	w8, [sp, #30]
	subs	w8, w8, #256
	b.hi	LBB201_5
	b	LBB201_3
LBB201_3:
	ldrh	w8, [sp, #32]
	subs	w8, w8, #256
	b.hi	LBB201_5
	b	LBB201_4
LBB201_4:
	ldrh	w8, [sp, #28]
	subs	w8, w8, #256
	b.ls	LBB201_6
	b	LBB201_5
LBB201_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB201_15
LBB201_6:
	ldrh	w8, [sp, #26]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.le	LBB201_8
	b	LBB201_7
LBB201_7:
	ldrh	w8, [sp, #26]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #38]
	b	LBB201_8
LBB201_8:
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #46]
	subs	w8, w8, w9
	b.le	LBB201_10
	b	LBB201_9
LBB201_9:
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #46]
	b	LBB201_10
LBB201_10:
	ldrh	w8, [sp, #32]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #48]
	subs	w8, w8, w9
	b.le	LBB201_12
	b	LBB201_11
LBB201_11:
	ldrh	w8, [sp, #32]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #48]
	b	LBB201_12
LBB201_12:
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #50]
	subs	w8, w8, w9
	b.le	LBB201_14
	b	LBB201_13
LBB201_13:
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #50]
	b	LBB201_14
LBB201_14:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB201_15
LBB201_15:
	ldurb	w8, [x29, #-25]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB201_17
	b	LBB201_16
LBB201_16:
	bl	___stack_chk_fail
LBB201_17:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_supported_mode
_file_code_supported_mode:              ; @file_code_supported_mode
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sturb	w0, [x29, #-2]
	sturb	w1, [x29, #-3]
	ldurb	w8, [x29, #-3]
	tbz	w8, #0, LBB202_4
	b	LBB202_1
LBB202_1:
	ldurb	w8, [x29, #-2]
	subs	w8, w8, #250
	b.eq	LBB202_3
	b	LBB202_2
LBB202_2:
	ldurb	w0, [x29, #-2]
	bl	_isa_is_file_indirect_call
	tbz	w0, #0, LBB202_4
	b	LBB202_3
LBB202_3:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB202_13
LBB202_4:
	ldurb	w8, [x29, #-3]
	tbz	w8, #0, LBB202_9
	b	LBB202_5
LBB202_5:
	ldurb	w8, [x29, #-2]
	subs	w8, w8, #4
	b.eq	LBB202_8
	b	LBB202_6
LBB202_6:
	ldurb	w8, [x29, #-2]
	subs	w8, w8, #68
	b.eq	LBB202_8
	b	LBB202_7
LBB202_7:
	ldurb	w8, [x29, #-2]
	subs	w8, w8, #64
	b.ne	LBB202_9
	b	LBB202_8
LBB202_8:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB202_13
LBB202_9:
	ldurb	w8, [x29, #-2]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp]                        ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB202_12
; %bb.10:
	ldr	x11, [sp]                       ; 8-byte Folded Reload
	adrp	x10, lJTI202_0@PAGE
	add	x10, x10, lJTI202_0@PAGEOFF
Ltmp29:
	adr	x8, Ltmp29
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB202_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB202_13
LBB202_12:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB202_13
LBB202_13:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
	.p2align	2
lJTI202_0:
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_11-Ltmp29
	.long	LBB202_12-Ltmp29
	.long	LBB202_11-Ltmp29
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ch_member
_file_ch_member:                        ; @file_ch_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x8, x29, #16
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	str	x0, [x8]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB203_2
	b	LBB203_1
LBB203_1:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-56]
	stur	x1, [x29, #-48]
	ldur	q0, [x29, #-56]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_2:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB203_4
	b	LBB203_3
LBB203_3:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	bl	_scalar_type
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stur	x0, [x29, #-72]
	stur	x1, [x29, #-64]
	ldur	q0, [x29, #-72]
	str	q0, [x9]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_4:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB203_6
	b	LBB203_5
LBB203_5:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #4                          ; =0x4
	bl	_scalar_type
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stur	x0, [x29, #-88]
	stur	x1, [x29, #-80]
	ldur	q0, [x29, #-88]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_6:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB203_8
	b	LBB203_7
LBB203_7:
	ldur	x8, [x29, #-40]
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	w0, #5                          ; =0x5
	bl	_scalar_type
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #104]
	str	x1, [sp, #112]
	ldur	q0, [sp, #104]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_8:
	str	wzr, [sp, #100]
	b	LBB203_9
LBB203_9:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #100]
	subs	w8, w8, #8
	b.hs	LBB203_16
	b	LBB203_10
LBB203_10:                              ;   in Loop: Header=BB203_9 Depth=1
	ldr	w8, [sp, #100]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #88]
	ldr	x8, [sp, #88]
	cbz	x8, LBB203_14
	b	LBB203_11
LBB203_11:                              ;   in Loop: Header=BB203_9 Depth=1
	ldr	x8, [sp, #88]
	ldr	x0, [x8]
	ldur	x1, [x29, #-32]
	bl	_strcmp
	cbnz	w0, LBB203_14
	b	LBB203_12
LBB203_12:                              ;   in Loop: Header=BB203_9 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x0, [x8]
	ldr	w1, [sp, #100]
	add	x2, sp, #68
	bl	_nvm_file_cyclic_type
	tbz	w0, #0, LBB203_14
	b	LBB203_13
LBB203_13:
	ldur	x8, [x29, #-40]
	ldrb	w11, [sp, #80]
	mov	w10, #10                        ; =0xa
	mov	w9, #8                          ; =0x8
	subs	w11, w11, #0
	csel	w9, w9, w10, eq
	strb	w9, [sp, #52]
	strb	wzr, [sp, #53]
	strh	wzr, [sp, #54]
	ldr	w9, [sp, #68]
	str	w9, [sp, #56]
	ldr	w9, [sp, #72]
	str	w9, [sp, #60]
	ldr	w9, [sp, #84]
	str	w9, [sp, #64]
	ldur	q0, [sp, #52]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_14:                              ;   in Loop: Header=BB203_9 Depth=1
	b	LBB203_15
LBB203_15:                              ;   in Loop: Header=BB203_9 Depth=1
	ldr	w8, [sp, #100]
	add	w8, w8, #1
	str	w8, [sp, #100]
	b	LBB203_9
LBB203_16:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB203_17
LBB203_17:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_operands
_file_code_operands:                    ; @file_code_operands
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #304
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	add	x29, sp, #288
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x9, x29, #108
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	stur	x0, [x9, #76]
	str	w1, [x9, #72]
	stur	x2, [x9, #60]
	sturb	w3, [x29, #-49]
	stur	x4, [x9, #44]
	ldur	x8, [x9, #60]
	add	x8, x8, #8
	stur	x8, [x9, #36]
	ldur	x11, [x9, #76]
	ldr	w8, [x9, #72]
                                        ; kill: def $x8 killed $w8
	mov	x10, #36                        ; =0x24
	add	x11, x11, #48
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	add	x8, x8, #12
	stur	x8, [x9, #28]
	ldurb	w8, [x29, #-49]
	tbz	w8, #0, LBB204_2
	b	LBB204_1
LBB204_1:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w0, [x8]
	mov	w8, #1                          ; =0x1
	and	w1, w8, #0x1
	bl	_file_code_supported_mode
	tbnz	w0, #0, LBB204_4
	b	LBB204_3
LBB204_2:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w0, [x8]
	bl	_file_code_supported
	tbnz	w0, #0, LBB204_4
	b	LBB204_3
LBB204_3:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_4:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	subs	w8, w8, #3
	b.eq	LBB204_45
	b	LBB204_5
LBB204_5:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #4
	b.eq	LBB204_20
	b	LBB204_6
LBB204_6:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #11
	subs	w8, w8, #1
	b.ls	LBB204_46
	b	LBB204_7
LBB204_7:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #15
	b.eq	LBB204_59
	b	LBB204_8
LBB204_8:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #16
	subs	w8, w8, #1
	b.ls	LBB204_46
	b	LBB204_9
LBB204_9:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #24
	subs	w8, w8, #1
	b.ls	LBB204_52
	b	LBB204_10
LBB204_10:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #59
	b.eq	LBB204_59
	b	LBB204_11
LBB204_11:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #60
	b.eq	LBB204_41
	b	LBB204_12
LBB204_12:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #104
	b.eq	LBB204_116
	b	LBB204_13
LBB204_13:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #145
	b.eq	LBB204_99
	b	LBB204_14
LBB204_14:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #146
	subs	w8, w8, #2
	b.ls	LBB204_46
	b	LBB204_15
LBB204_15:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #150
	b.eq	LBB204_56
	b	LBB204_16
LBB204_16:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #151
	b.eq	LBB204_59
	b	LBB204_17
LBB204_17:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #152
	b.eq	LBB204_25
	b	LBB204_18
LBB204_18:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #250
	b.eq	LBB204_24
	b	LBB204_19
LBB204_19:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	subs	w8, w8, #251
	b.eq	LBB204_116
	b	LBB204_137
LBB204_20:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldr	w8, [x8, #8]
	ldur	x9, [x9, #44]
	ldr	w9, [x9, #248]
	subs	w8, w8, w9
	b.hs	LBB204_22
	b	LBB204_21
LBB204_21:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldur	x8, [x8, #36]
	ldr	w1, [x8, #8]
	bl	_nvm_get_string
	cbnz	x0, LBB204_23
	b	LBB204_22
LBB204_22:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_23:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldur	x8, [x8, #36]
	ldr	w1, [x8, #8]
	bl	_nvm_get_string_len
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w10, #0                         ; =0x0
	mov	w8, #3                          ; =0x3
	subs	w11, w0, #256, lsl #12          ; =1048576
	csel	w8, w8, w10, hi
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_24:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldr	w8, [x8, #8]
	ldur	x10, [x9, #76]
	ldr	w10, [x10, #24]
	subs	w8, w8, w10
	cset	w8, hs
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_25:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #36]
	ldrh	w9, [x9, #8]
	strh	w9, [x8, #26]
	ldur	x9, [x8, #36]
	ldr	w9, [x9, #24]
	str	w9, [x8, #20]
	ldrh	w8, [x8, #26]
	subs	w8, w8, #256
	b.hi	LBB204_27
	b	LBB204_26
LBB204_26:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	b.le	LBB204_28
	b	LBB204_27
LBB204_27:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_28:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldr	w1, [x8, #20]
	bl	_nvm_get_string
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	x0, [x8, #12]
	ldur	x8, [x8, #12]
	cbz	x8, LBB204_30
	b	LBB204_29
LBB204_29:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldr	w1, [x8, #20]
	bl	_nvm_get_string_len
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w9, [x8, #26]
	mov	w8, #2                          ; =0x2
	mul	w8, w8, w9
	subs	w8, w0, w8
	b.eq	LBB204_31
	b	LBB204_30
LBB204_30:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_31:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	sturb	wzr, [x29, #-97]
	strh	wzr, [x8, #8]
	b	LBB204_32
LBB204_32:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [x9, #8]
	ldrh	w9, [x9, #26]
	subs	w8, w8, w9
	b.ge	LBB204_38
	b	LBB204_33
LBB204_33:                              ;   in Loop: Header=BB204_32 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #12]
	ldrh	w10, [x8, #8]
	mov	w11, #2                         ; =0x2
	mul	w10, w11, w10
	ldrb	w9, [x9, w10, uxtw]
	ldur	x10, [x8, #12]
	ldrh	w12, [x8, #8]
	mul	w11, w11, w12
	add	w11, w11, #1
	ldrb	w10, [x10, w11, uxtw]
	orr	w9, w9, w10, lsl #8
	strh	w9, [x8, #6]
	ldrh	w8, [x8, #6]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB204_36
	b	LBB204_34
LBB204_34:                              ;   in Loop: Header=BB204_32 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [x8, #6]
	subs	w8, w8, #256
	b.lo	LBB204_36
	b	LBB204_35
LBB204_35:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_36:                              ;   in Loop: Header=BB204_32 Depth=1
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	ldrh	w8, [x10, #6]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	cset	w9, ne
	ldurb	w8, [x29, #-97]
	and	w8, w8, #0x1
	orr	w8, w8, w9
	subs	w8, w8, #0
	cset	w8, ne
	sturb	w8, [x29, #-97]
	ldrh	w8, [x10, #6]
	ldur	x9, [x10, #60]
	add	x9, x9, #78
	ldrh	w10, [x10, #8]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB204_37
LBB204_37:                              ;   in Loop: Header=BB204_32 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [x9, #8]
	add	w8, w8, #1
	strh	w8, [x9, #8]
	b	LBB204_32
LBB204_38:
	ldurb	w8, [x29, #-97]
	tbnz	w8, #0, LBB204_40
	b	LBB204_39
LBB204_39:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_40:
	b	LBB204_138
LBB204_41:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #256
	b.hi	LBB204_43
	b	LBB204_42
LBB204_42:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #1
	b.le	LBB204_44
	b	LBB204_43
LBB204_43:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_44:
	b	LBB204_138
LBB204_45:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #1
	cset	w8, gt
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_46:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldrh	w8, [x8, #8]
	ldur	x9, [x9, #28]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB204_48
	b	LBB204_47
LBB204_47:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_48:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #147
	b.ne	LBB204_51
	b	LBB204_49
LBB204_49:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8, #16]
	subs	w8, w8, #1
	b.le	LBB204_51
	b	LBB204_50
LBB204_50:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_51:
	b	LBB204_138
LBB204_52:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #256
	b.hs	LBB204_54
	b	LBB204_53
LBB204_53:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldrh	w8, [x8, #16]
	ldur	x9, [x9, #28]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.lt	LBB204_55
	b	LBB204_54
LBB204_54:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_55:
	b	LBB204_138
LBB204_56:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #8]
	subs	w8, w8, #256
	b.lo	LBB204_58
	b	LBB204_57
LBB204_57:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_58:
	b	LBB204_138
LBB204_59:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x9, #36]
	ldr	w8, [x8, #8]
	str	w8, [x9]
	ldr	w8, [x9]
	ldur	x9, [x9, #76]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.lo	LBB204_61
	b	LBB204_60
LBB204_60:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_61:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #76]
	ldr	x0, [x9]
	ldr	w1, [x8]
	sub	x2, x29, #132
	bl	_nvm_file_flow_function
	tbnz	w0, #0, LBB204_63
	b	LBB204_62
LBB204_62:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_63:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
                                        ; kill: def $x9 killed $xzr
	str	xzr, [sp, #144]
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #151
	b.ne	LBB204_68
	b	LBB204_64
LBB204_64:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldur	x8, [x8, #36]
	ldr	w1, [x8, #16]
	bl	_nvm_get_string
	str	x0, [sp, #144]
	ldr	x8, [sp, #144]
	cbz	x8, LBB204_66
	b	LBB204_65
LBB204_65:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x0, [x8, #44]
	ldur	x8, [x8, #36]
	ldr	w1, [x8, #16]
	bl	_nvm_get_string_len
	ldurh	w9, [x29, #-132]
	mov	w8, #2                          ; =0x2
	mul	w8, w8, w9
	subs	w8, w0, w8
	b.eq	LBB204_67
	b	LBB204_66
LBB204_66:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_67:
	b	LBB204_68
LBB204_68:
	str	wzr, [sp, #140]
	strh	wzr, [sp, #138]
	b	LBB204_69
LBB204_69:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #138]
	ldurh	w9, [x29, #-132]
	subs	w8, w8, w9
	b.ge	LBB204_84
	b	LBB204_70
LBB204_70:                              ;   in Loop: Header=BB204_69 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x9, [x8, #76]
	ldr	x0, [x9]
	ldr	w1, [x8]
	ldrh	w2, [sp, #138]
	add	x3, sp, #120
	bl	_nvm_file_flow_declaration
	tbnz	w0, #0, LBB204_72
	b	LBB204_71
LBB204_71:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_72:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrb	w9, [sp, #121]
	ldr	w8, [sp, #140]
	subs	w9, w9, #0
	cinc	w8, w8, ne
	str	w8, [sp, #140]
	mov	w8, #65535                      ; =0xffff
	strh	w8, [sp, #118]
	ldr	x8, [sp, #144]
	cbz	x8, LBB204_74
	b	LBB204_73
LBB204_73:                              ;   in Loop: Header=BB204_69 Depth=1
	ldr	x8, [sp, #144]
	ldrh	w9, [sp, #138]
	mov	w10, #2                         ; =0x2
	mul	w9, w10, w9
	ldrb	w8, [x8, w9, uxtw]
	ldr	x9, [sp, #144]
	ldrh	w11, [sp, #138]
	mul	w10, w10, w11
	add	w10, w10, #1
	ldrb	w9, [x9, w10, uxtw]
	orr	w8, w8, w9, lsl #8
	strh	w8, [sp, #118]
	b	LBB204_78
LBB204_74:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrb	w8, [sp, #121]
	cbz	w8, LBB204_77
	b	LBB204_75
LBB204_75:                              ;   in Loop: Header=BB204_69 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #15
	b.ne	LBB204_77
	b	LBB204_76
LBB204_76:                              ;   in Loop: Header=BB204_69 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #118]
	b	LBB204_77
LBB204_77:                              ;   in Loop: Header=BB204_69 Depth=1
	b	LBB204_78
LBB204_78:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrb	w8, [sp, #121]
	cbz	w8, LBB204_80
	b	LBB204_79
LBB204_79:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrh	w8, [sp, #118]
	subs	w8, w8, #256
	b.hs	LBB204_81
	b	LBB204_82
LBB204_80:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrh	w8, [sp, #118]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB204_82
	b	LBB204_81
LBB204_81:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_82:                              ;   in Loop: Header=BB204_69 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldrh	w8, [sp, #118]
	ldur	x9, [x9, #60]
	add	x9, x9, #78
	ldrh	w10, [sp, #138]
                                        ; kill: def $x10 killed $w10
	add	x9, x9, x10, lsl #1
	strh	w8, [x9]
	b	LBB204_83
LBB204_83:                              ;   in Loop: Header=BB204_69 Depth=1
	ldrh	w8, [sp, #138]
	add	w8, w8, #1
	strh	w8, [sp, #138]
	b	LBB204_69
LBB204_84:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #15
	b.ne	LBB204_90
	b	LBB204_85
LBB204_85:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #16]
	subs	w8, w8, #256
	b.lo	LBB204_87
	b	LBB204_86
LBB204_86:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_87:
	ldr	w8, [sp, #140]
	subs	w8, w8, #1
	b.eq	LBB204_89
	b	LBB204_88
LBB204_88:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_89:
	b	LBB204_98
LBB204_90:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #151
	b.ne	LBB204_94
	b	LBB204_91
LBB204_91:
	ldr	w8, [sp, #140]
	cbnz	w8, LBB204_93
	b	LBB204_92
LBB204_92:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_93:
	b	LBB204_97
LBB204_94:
	ldr	w8, [sp, #140]
	cbz	w8, LBB204_96
	b	LBB204_95
LBB204_95:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_96:
	b	LBB204_97
LBB204_97:
	b	LBB204_98
LBB204_98:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w9, [x8]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x11, x9, x10
	ldur	x9, [x8, #76]
	mov	x10, #11056                     ; =0x2b30
	add	x9, x9, x10
	ldr	w8, [x8, #72]
	mov	x10, x8
	ldr	x8, [x9, x10, lsl #3]
	orr	x8, x8, x11
	str	x8, [x9, x10, lsl #3]
	b	LBB204_138
LBB204_99:
	mov	w8, #5                          ; =0x5
	str	w8, [sp, #112]
	str	wzr, [sp, #108]
	b	LBB204_100
LBB204_100:                             ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #108]
	subs	w8, w8, #5
	b.hs	LBB204_106
	b	LBB204_101
LBB204_101:                             ;   in Loop: Header=BB204_100 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #76]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldr	w1, [sp, #108]
	add	x2, sp, #104
	bl	_nvm_file_nominal_import
	tbz	w0, #0, LBB204_104
	b	LBB204_102
LBB204_102:                             ;   in Loop: Header=BB204_100 Depth=1
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #104]
	ldur	x9, [x9, #36]
	ldr	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB204_104
	b	LBB204_103
LBB204_103:
	ldr	w8, [sp, #108]
	str	w8, [sp, #112]
	b	LBB204_106
LBB204_104:                             ;   in Loop: Header=BB204_100 Depth=1
	b	LBB204_105
LBB204_105:                             ;   in Loop: Header=BB204_100 Depth=1
	ldr	w8, [sp, #108]
	add	w8, w8, #1
	str	w8, [sp, #108]
	b	LBB204_100
LBB204_106:
	ldr	w8, [sp, #112]
	mov	x0, x8
	bl	_nl_file_catalog_method
	str	x0, [sp, #96]
	ldr	x8, [sp, #96]
	cbnz	x8, LBB204_108
	b	LBB204_107
LBB204_107:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_108:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #16]
	strh	w8, [sp, #94]
	ldr	x8, [sp, #96]
	ldr	w8, [x8, #44]
	subs	w8, w8, #1
	b.ne	LBB204_112
	b	LBB204_109
LBB204_109:
	ldrh	w8, [sp, #94]
	subs	w8, w8, #256
	b.lo	LBB204_111
	b	LBB204_110
LBB204_110:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_111:
	b	LBB204_115
LBB204_112:
	ldrh	w8, [sp, #94]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB204_114
	b	LBB204_113
LBB204_113:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_114:
	b	LBB204_115
LBB204_115:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #112]
	ldur	x9, [x9, #60]
	str	w8, [x9, #592]
	b	LBB204_138
LBB204_116:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	mov	w9, #2                          ; =0x2
	strb	w9, [sp, #93]
	ldur	x9, [x8, #36]
	ldr	w9, [x9, #8]
	str	w9, [sp, #88]
	ldur	x9, [x8, #36]
	ldrh	w9, [x9, #16]
	strh	w9, [sp, #86]
	ldur	x9, [x8, #36]
	ldrh	w9, [x9, #24]
	strh	w9, [sp, #84]
	ldur	x8, [x8, #36]
	ldrb	w8, [x8]
	subs	w8, w8, #251
	b.ne	LBB204_122
	b	LBB204_117
LBB204_117:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #36]
	ldrb	w8, [x8, #8]
	strb	w8, [sp, #83]
	ldrb	w8, [sp, #83]
	subs	w8, w8, #2
	b.le	LBB204_119
	b	LBB204_118
LBB204_118:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_119:
	ldrb	w8, [sp, #83]
	subs	w8, w8, #2
	b.ne	LBB204_121
	b	LBB204_120
LBB204_120:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_121:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrb	w11, [sp, #83]
	mov	w9, #0                          ; =0x0
	mov	w10, #2                         ; =0x2
	subs	w11, w11, #0
	csel	w9, w9, w10, eq
	strb	w9, [sp, #93]
	ldur	x9, [x8, #36]
	ldr	w9, [x9, #16]
	str	w9, [sp, #88]
	ldur	x9, [x8, #36]
	ldrh	w9, [x9, #24]
	strh	w9, [sp, #86]
	ldur	x8, [x8, #36]
	ldrh	w8, [x8, #32]
	strh	w8, [sp, #84]
	b	LBB204_122
LBB204_122:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldur	x8, [x8, #76]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldrb	w1, [sp, #93]
	ldr	w2, [sp, #88]
	add	x3, sp, #60
	bl	_nvm_file_nominal_source
	tbnz	w0, #0, LBB204_124
	b	LBB204_123
LBB204_123:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_124:
	ldr	w8, [sp, #76]
	subs	w8, w8, #4
	b.eq	LBB204_127
	b	LBB204_125
LBB204_125:
	ldr	w8, [sp, #76]
	subs	w8, w8, #3
	b.eq	LBB204_127
	b	LBB204_126
LBB204_126:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_127:
	ldr	w8, [sp, #64]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #48]
	ldr	w8, [sp, #76]
	subs	w8, w8, #4
	cset	w8, eq
	strb	w8, [sp, #47]
	ldr	x8, [sp, #48]
	cbz	x8, LBB204_135
	b	LBB204_128
LBB204_128:
	ldrb	w8, [sp, #47]
	tbz	w8, #0, LBB204_130
	b	LBB204_129
LBB204_129:
	ldrh	w8, [sp, #86]
	cbnz	w8, LBB204_135
	b	LBB204_131
LBB204_130:
	ldrh	w8, [sp, #86]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB204_135
	b	LBB204_131
LBB204_131:
	ldrh	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldrb	w8, [sp, #47]
	tbz	w8, #0, LBB204_133
	b	LBB204_132
LBB204_132:
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #32]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB204_134
LBB204_133:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB204_134
LBB204_134:
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	subs	x8, x8, x9
	b.eq	LBB204_136
	b	LBB204_135
LBB204_135:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #88]
	b	LBB204_139
LBB204_136:
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #64]
	ldur	x9, [x9, #60]
	str	w8, [x9, #592]
	b	LBB204_138
LBB204_137:
	b	LBB204_138
LBB204_138:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	wzr, [x8, #88]
	b	LBB204_139
LBB204_139:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	w0, [x8, #88]
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_cfg
_file_code_cfg:                         ; @file_code_cfg
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #880
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	str	x0, [sp, #88]
	str	w1, [sp, #84]
	strb	w2, [sp, #83]
	ldr	x10, [sp, #88]
	ldr	w8, [sp, #84]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #72]
	add	x0, sp, #360
	mov	x1, #512                        ; =0x200
	bl	_bzero
	add	x0, sp, #104
	mov	x2, #256                        ; =0x100
	mov	w1, #0                          ; =0x0
	bl	_memset
	strh	wzr, [sp, #70]
	b	LBB205_1
LBB205_1:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB205_15 Depth 2
	ldrh	w8, [sp, #70]
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB205_20
	b	LBB205_2
LBB205_2:                               ;   in Loop: Header=BB205_1 Depth=1
	ldr	x8, [sp, #88]
	ldr	x10, [x8, #16]
	ldr	x8, [sp, #88]
	add	x8, x8, #2352
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #70]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #56]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #8]
	strb	w8, [sp, #55]
	ldrb	w8, [sp, #55]
	subs	w8, w8, #61
	b.eq	LBB205_7
	b	LBB205_3
LBB205_3:                               ;   in Loop: Header=BB205_1 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #56
	b.eq	LBB205_7
	b	LBB205_4
LBB205_4:                               ;   in Loop: Header=BB205_1 Depth=1
	ldr	x8, [sp, #56]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #56]
	ldr	w9, [x9, #64]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #40]
	ldr	x8, [sp, #56]
	add	x8, x8, #72
	ldr	x9, [sp, #56]
	ldrb	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	add	x3, x8, x9, lsl #1
	bl	_file_code_index
	tbnz	w0, #0, LBB205_6
	b	LBB205_5
LBB205_5:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #100]
	b	LBB205_40
LBB205_6:                               ;   in Loop: Header=BB205_1 Depth=1
	ldr	x9, [sp, #56]
	ldrb	w8, [x9, #76]
	add	w8, w8, #1
	strb	w8, [x9, #76]
	b	LBB205_7
LBB205_7:                               ;   in Loop: Header=BB205_1 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #56
	b.eq	LBB205_11
	b	LBB205_8
LBB205_8:                               ;   in Loop: Header=BB205_1 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #57
	b.eq	LBB205_11
	b	LBB205_9
LBB205_9:                               ;   in Loop: Header=BB205_1 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #58
	b.eq	LBB205_11
	b	LBB205_10
LBB205_10:                              ;   in Loop: Header=BB205_1 Depth=1
	ldrb	w8, [sp, #55]
	subs	w8, w8, #146
	b.ne	LBB205_14
	b	LBB205_11
LBB205_11:                              ;   in Loop: Header=BB205_1 Depth=1
	ldr	x8, [sp, #56]
	add	x8, x8, #16
	ldrb	w10, [sp, #55]
	mov	w9, #0                          ; =0x0
	subs	w10, w10, #146
	csinc	w10, w9, wzr, ne
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	lsl	x9, x9, #3
	ldr	w8, [x8, x9]
	str	w8, [sp, #36]
	ldr	x8, [sp, #56]
	ldr	w8, [x8]
                                        ; kill: def $x8 killed $w8
	ldrsw	x9, [sp, #36]
	add	x8, x8, x9
	str	x8, [sp, #24]
	ldr	x0, [sp, #88]
	ldr	w1, [sp, #84]
	ldr	x2, [sp, #24]
	ldr	x8, [sp, #56]
	add	x8, x8, #72
	ldr	x9, [sp, #56]
	ldrb	w9, [x9, #76]
                                        ; kill: def $x9 killed $w9
	add	x3, x8, x9, lsl #1
	bl	_file_code_index
	tbnz	w0, #0, LBB205_13
	b	LBB205_12
LBB205_12:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #100]
	b	LBB205_40
LBB205_13:                              ;   in Loop: Header=BB205_1 Depth=1
	ldr	x9, [sp, #56]
	ldrb	w8, [x9, #76]
	add	w8, w8, #1
	strb	w8, [x9, #76]
	b	LBB205_14
LBB205_14:                              ;   in Loop: Header=BB205_1 Depth=1
	strb	wzr, [sp, #23]
	b	LBB205_15
LBB205_15:                              ;   Parent Loop BB205_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #23]
	ldr	x9, [sp, #56]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB205_18
	b	LBB205_16
LBB205_16:                              ;   in Loop: Header=BB205_15 Depth=2
	ldr	x8, [sp, #56]
	add	x8, x8, #72
	ldrb	w9, [sp, #23]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	x10, x8
	add	x9, sp, #360
	mov	x8, x9
	add	x8, x8, x10, lsl #1
	ldrh	w8, [x8]
	add	w8, w8, #1
	strh	w8, [x9, x10, lsl #1]
	b	LBB205_17
LBB205_17:                              ;   in Loop: Header=BB205_15 Depth=2
	ldrb	w8, [sp, #23]
	add	w8, w8, #1
	strb	w8, [sp, #23]
	b	LBB205_15
LBB205_18:                              ;   in Loop: Header=BB205_1 Depth=1
	b	LBB205_19
LBB205_19:                              ;   in Loop: Header=BB205_1 Depth=1
	ldrh	w8, [sp, #70]
	add	w8, w8, #1
	strh	w8, [sp, #70]
	b	LBB205_1
LBB205_20:
	ldrb	w8, [sp, #83]
	tbnz	w8, #0, LBB205_22
	b	LBB205_21
LBB205_21:
	str	wzr, [sp, #100]
	b	LBB205_40
LBB205_22:
	strh	wzr, [sp, #20]
	b	LBB205_23
LBB205_23:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB205_25 Depth 2
                                        ;     Child Loop BB205_34 Depth 2
	ldrh	w8, [sp, #20]
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB205_39
	b	LBB205_24
LBB205_24:                              ;   in Loop: Header=BB205_23 Depth=1
	ldr	x8, [sp, #72]
	ldrh	w8, [x8, #8]
	strh	w8, [sp, #18]
	strh	wzr, [sp, #16]
	b	LBB205_25
LBB205_25:                              ;   Parent Loop BB205_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #16]
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB205_31
	b	LBB205_26
LBB205_26:                              ;   in Loop: Header=BB205_25 Depth=2
	ldrh	w8, [sp, #16]
	mov	x9, x8
	add	x8, sp, #104
	add	x8, x8, x9
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB205_29
	b	LBB205_27
LBB205_27:                              ;   in Loop: Header=BB205_25 Depth=2
	ldrh	w8, [sp, #16]
	mov	x9, x8
	add	x8, sp, #360
	add	x8, x8, x9, lsl #1
	ldrh	w8, [x8]
	cbnz	w8, LBB205_29
	b	LBB205_28
LBB205_28:                              ;   in Loop: Header=BB205_23 Depth=1
	ldrh	w8, [sp, #16]
	strh	w8, [sp, #18]
	b	LBB205_31
LBB205_29:                              ;   in Loop: Header=BB205_25 Depth=2
	b	LBB205_30
LBB205_30:                              ;   in Loop: Header=BB205_25 Depth=2
	ldrh	w8, [sp, #16]
	add	w8, w8, #1
	strh	w8, [sp, #16]
	b	LBB205_25
LBB205_31:                              ;   in Loop: Header=BB205_23 Depth=1
	ldrh	w8, [sp, #18]
	ldr	x9, [sp, #72]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB205_33
	b	LBB205_32
LBB205_32:
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #100]
	b	LBB205_40
LBB205_33:                              ;   in Loop: Header=BB205_23 Depth=1
	ldrh	w8, [sp, #18]
	mov	x9, x8
	add	x8, sp, #104
	add	x9, x8, x9
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	ldrh	w8, [sp, #18]
	ldr	x9, [sp, #88]
	add	x9, x9, #2864
	ldr	x10, [sp, #88]
	add	x10, x10, #2352
	ldr	w11, [sp, #84]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldrh	w11, [sp, #20]
	add	w10, w10, w11
	add	x9, x9, w10, uxtw #1
	strh	w8, [x9]
	ldr	x8, [sp, #88]
	ldr	x10, [x8, #16]
	ldr	x8, [sp, #88]
	add	x8, x8, #2352
	ldr	w9, [sp, #84]
                                        ; kill: def $x9 killed $w9
	ldr	w8, [x8, x9, lsl #2]
	ldrh	w9, [sp, #18]
	add	w8, w8, w9
	mov	w9, #600                        ; =0x258
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #8]
	strb	wzr, [sp, #7]
	b	LBB205_34
LBB205_34:                              ;   Parent Loop BB205_23 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w8, [sp, #7]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #76]
	subs	w8, w8, w9
	b.ge	LBB205_37
	b	LBB205_35
LBB205_35:                              ;   in Loop: Header=BB205_34 Depth=2
	ldr	x8, [sp, #8]
	add	x8, x8, #72
	ldrb	w9, [sp, #7]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	x10, x8
	add	x9, sp, #360
	mov	x8, x9
	add	x8, x8, x10, lsl #1
	ldrh	w11, [x8]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w11, uxth
	strh	w8, [x9, x10, lsl #1]
	b	LBB205_36
LBB205_36:                              ;   in Loop: Header=BB205_34 Depth=2
	ldrb	w8, [sp, #7]
	add	w8, w8, #1
	strb	w8, [sp, #7]
	b	LBB205_34
LBB205_37:                              ;   in Loop: Header=BB205_23 Depth=1
	b	LBB205_38
LBB205_38:                              ;   in Loop: Header=BB205_23 Depth=1
	ldrh	w8, [sp, #20]
	add	w8, w8, #1
	strh	w8, [sp, #20]
	b	LBB205_23
LBB205_39:
	str	wzr, [sp, #100]
	b	LBB205_40
LBB205_40:
	ldr	w8, [sp, #100]
	str	w8, [sp]                        ; 4-byte Folded Spill
	ldur	x9, [x29, #-24]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB205_42
	b	LBB205_41
LBB205_41:
	bl	___stack_chk_fail
LBB205_42:
	ldr	w0, [sp]                        ; 4-byte Folded Reload
	add	sp, sp, #880
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_code_index
_file_code_index:                       ; @file_code_index
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	str	x0, [sp, #48]
	str	w1, [sp, #44]
	str	x2, [sp, #32]
	str	x3, [sp, #24]
	ldr	x10, [sp, #48]
	ldr	w8, [sp, #44]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #16]
	ldr	x8, [sp, #32]
	tbnz	x8, #63, LBB206_2
	b	LBB206_1
LBB206_1:
	ldr	x8, [sp, #32]
	ldr	x9, [sp, #16]
	ldr	w9, [x9, #4]
                                        ; kill: def $x9 killed $w9
	subs	x8, x8, x9
	b.lt	LBB206_3
	b	LBB206_2
LBB206_2:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB206_10
LBB206_3:
	strh	wzr, [sp, #14]
	b	LBB206_4
LBB206_4:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ge	LBB206_9
	b	LBB206_5
LBB206_5:                               ;   in Loop: Header=BB206_4 Depth=1
	ldr	x8, [sp, #48]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #48]
	add	x9, x9, #2352
	ldr	w10, [sp, #44]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #14]
	add	w9, w9, w10
	mov	w10, #600                       ; =0x258
	umull	x9, w9, w10
	ldr	w8, [x8, x9]
	ldr	x9, [sp, #32]
                                        ; kill: def $w9 killed $w9 killed $x9
	subs	w8, w8, w9
	b.ne	LBB206_7
	b	LBB206_6
LBB206_6:
	ldrh	w8, [sp, #14]
	ldr	x9, [sp, #24]
	strh	w8, [x9]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB206_10
LBB206_7:                               ;   in Loop: Header=BB206_4 Depth=1
	b	LBB206_8
LBB206_8:                               ;   in Loop: Header=BB206_4 Depth=1
	ldrh	w8, [sp, #14]
	add	w8, w8, #1
	strh	w8, [sp, #14]
	b	LBB206_4
LBB206_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	strb	w8, [sp, #63]
	b	LBB206_10
LBB206_10:
	ldrb	w8, [sp, #63]
	and	w0, w8, #0x1
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_value
_fi_value:                              ; @fi_value
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	mov	x9, x8
	str	x9, [sp]                        ; 8-byte Folded Spill
	str	x0, [sp, #16]
	str	x1, [sp, #24]
	strb	w2, [sp, #15]
	movi.2d	v0, #0000000000000000
	str	q0, [x9]
	str	q0, [x9, #16]
	ldr	q0, [sp, #16]
	str	q0, [x9]
	ldrb	w8, [sp, #15]
	strb	w8, [x9, #24]
	ldr	w8, [sp, #28]
	subs	w8, w8, #2
	b.eq	LBB207_2
	b	LBB207_1
LBB207_1:
	ldr	w8, [sp, #28]
	subs	w8, w8, #3
	b.ne	LBB207_3
	b	LBB207_2
LBB207_2:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	strb	w8, [x9, #25]
	b	LBB207_3
LBB207_3:
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_transfer
_fi_transfer:                           ; @fi_transfer
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #1200
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	add	x8, sp, #840
	str	x8, [sp, #216]                  ; 8-byte Folded Spill
	add	x8, sp, #476
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
	stur	x0, [x29, #-32]
	stur	w1, [x29, #-36]
	stur	x2, [x29, #-48]
	stur	x3, [x29, #-56]
	stur	x4, [x29, #-64]
	ldur	x8, [x29, #-32]
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	ldur	x8, [x29, #-56]
	add	x8, x8, #8
	stur	x8, [x29, #-80]
	ldur	x8, [x29, #-80]
	ldrh	w8, [x8, #8]
	sturh	w8, [x29, #-82]
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	add	w8, w8, #0
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
	subs	x8, x8, #254
	b.hi	LBB208_151
; %bb.1:
	ldr	x11, [sp, #232]                 ; 8-byte Folded Reload
	adrp	x10, lJTI208_0@PAGE
	add	x10, x10, lJTI208_0@PAGEOFF
Ltmp32:
	adr	x8, Ltmp32
	ldrsw	x9, [x10, x11, lsl #2]
	add	x8, x8, x9
	br	x8
LBB208_2:
	stur	wzr, [x29, #-20]
	b	LBB208_152
LBB208_3:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldurb	w9, [x29, #-104]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #2
	str	w8, [sp, #212]                  ; 4-byte Folded Spill
	b.ne	LBB208_5
	b	LBB208_4
LBB208_4:
	ldurb	w8, [x29, #-103]
	subs	w8, w8, #0
	cset	w8, ne
	str	w8, [sp, #212]                  ; 4-byte Folded Spill
	b	LBB208_5
LBB208_5:
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	cset	w8, eq
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_6:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldur	x9, [x29, #-80]
	ldrh	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldurb	w9, [x29, #-104]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #2
	str	w8, [sp, #208]                  ; 4-byte Folded Spill
	b.ne	LBB208_8
	b	LBB208_7
LBB208_7:
	ldur	w8, [x29, #-116]
	subs	w8, w8, #1
	cset	w8, eq
	str	w8, [sp, #208]                  ; 4-byte Folded Spill
	b	LBB208_8
LBB208_8:
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	and	w8, w8, #0x1
	ands	w8, w8, #0x1
	cset	w8, eq
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_9:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	mov	w0, #5                          ; =0x5
	bl	_scalar_type
	stur	x0, [x29, #-200]
	stur	x1, [x29, #-192]
	ldur	x0, [x29, #-200]
	ldur	x1, [x29, #-192]
	sub	x8, x29, #184
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #192]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #200]                  ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_10:
	ldur	x0, [x29, #-48]
	mov	w1, #5                          ; =0x5
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_11:
	ldur	x0, [x29, #-48]
	mov	w1, #5                          ; =0x5
	mov	w3, #1                          ; =0x1
	mov	x2, x3
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_12:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	bl	_scalar_type
	stur	x0, [x29, #-248]
	stur	x1, [x29, #-240]
	ldur	x0, [x29, #-248]
	ldur	x1, [x29, #-240]
	sub	x8, x29, #232
	str	x8, [sp, #184]                  ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #184]                  ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_13:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	mov	w0, #4                          ; =0x4
	bl	_scalar_type
	str	x0, [sp, #920]
	str	x1, [sp, #928]
	ldr	x0, [sp, #920]
	ldr	x1, [sp, #928]
	add	x8, sp, #936
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #168]                  ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_14:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	str	x0, [sp, #872]
	str	x1, [sp, #880]
	ldr	x0, [sp, #872]
	ldr	x1, [sp, #880]
	add	x8, sp, #888
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #152]                  ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_15:
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	str	x0, [sp, #824]
	str	x1, [sp, #832]
	ldr	x0, [sp, #824]
	ldr	x1, [sp, #832]
	add	x8, sp, #840
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x8, x8, x9
	stur	x8, [x29, #-112]
	ldur	x0, [x29, #-48]
	ldur	q0, [x29, #-128]
	add	x1, sp, #784
	str	q0, [sp, #784]
	ldur	q0, [x29, #-112]
	str	q0, [sp, #800]
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_16:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_19
	b	LBB208_17
LBB208_17:
	ldurb	w8, [x29, #-127]
	cbnz	w8, LBB208_19
	b	LBB208_18
LBB208_18:
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	bl	_owned
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #11
	cset	w8, eq
	subs	w8, w0, w8
	b.eq	LBB208_20
	b	LBB208_19
LBB208_19:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_20:
	ldur	x0, [x29, #-48]
	ldur	q0, [x29, #-128]
	add	x1, sp, #752
	str	q0, [sp, #752]
	ldur	q0, [x29, #-112]
	str	q0, [sp, #768]
	bl	_fi_push
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbnz	w8, LBB208_23
	b	LBB208_21
LBB208_21:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #11
	b.ne	LBB208_23
	b	LBB208_22
LBB208_22:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	add	x8, sp, #720
	mov	w2, #1                          ; =0x1
	bl	_fi_value
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	ldr	q0, [sp, #720]
	str	q0, [x8]
	ldr	q0, [sp, #736]
	str	q0, [x8, #16]
	b	LBB208_23
LBB208_23:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_24:
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB208_26
	b	LBB208_25
LBB208_25:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_26:
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #17
	b.ne	LBB208_34
	b	LBB208_27
LBB208_27:
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_34
	b	LBB208_28
LBB208_28:
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	str	x0, [sp, #704]
	str	x1, [sp, #712]
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	ldr	x2, [sp, #704]
	ldr	x3, [sp, #712]
	bl	_same
	tbz	w0, #0, LBB208_34
	b	LBB208_29
LBB208_29:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #5
	ldrb	w8, [x8, x9]
	cbz	w8, LBB208_34
	b	LBB208_30
LBB208_30:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	lsl	x9, x9, #5
	ldr	q0, [x8, x9]
	stur	q0, [x29, #-144]
	ldurb	w8, [x29, #-143]
	cbnz	w8, LBB208_32
	b	LBB208_31
LBB208_31:
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	bl	_owned
	tbz	w0, #0, LBB208_33
	b	LBB208_32
LBB208_32:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_33:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	add	x8, sp, #672
	mov	w2, #1                          ; =0x1
	bl	_fi_value
	ldr	x8, [sp, #120]                  ; 8-byte Folded Reload
	ldr	q0, [sp, #672]
	str	q0, [x8]
	ldr	q0, [sp, #688]
	str	q0, [x8, #16]
	ldur	x8, [x29, #-48]
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	mov	x8, x0
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	str	x8, [sp, #656]
	str	x1, [sp, #664]
	ldr	x1, [sp, #656]
	ldr	x2, [sp, #664]
	bl	_fi_take
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_34:
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_40
	b	LBB208_35
LBB208_35:
	ldurb	w8, [x29, #-127]
	cbnz	w8, LBB208_40
	b	LBB208_36
LBB208_36:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbz	w0, #0, LBB208_40
	b	LBB208_37
LBB208_37:
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	bl	_owned
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #12
	cset	w8, eq
	subs	w8, w0, w8
	b.ne	LBB208_40
	b	LBB208_38
LBB208_38:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #12
	b.ne	LBB208_41
	b	LBB208_39
LBB208_39:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8, #24]
	subs	w8, w8, #1
	b.eq	LBB208_41
	b	LBB208_40
LBB208_40:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_41:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldur	q0, [x29, #-128]
	str	q0, [x8]
	ldur	q0, [x29, #-112]
	str	q0, [x8, #16]
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-128]
	ldur	x2, [x29, #-120]
	bl	_fi_take
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_42:
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #2]
	cbz	w8, LBB208_44
	b	LBB208_43
LBB208_43:
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	bl	_owned
	tbz	w0, #0, LBB208_45
	b	LBB208_44
LBB208_44:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_45:
	ldur	x0, [x29, #-48]
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	add	x1, sp, #624
	str	q0, [sp, #624]
	ldr	q0, [x8, #16]
	str	q0, [sp, #640]
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_46:
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB208_48
	b	LBB208_47
LBB208_47:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_48:
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	bl	_owned
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #149
	cset	w8, eq
	subs	w8, w0, w8
	b.eq	LBB208_50
	b	LBB208_49
LBB208_49:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_50:
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-128]
	ldur	x2, [x29, #-120]
	bl	_fi_take
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_51:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_53
	b	LBB208_52
LBB208_52:
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	bl	_owned
	tbnz	w0, #0, LBB208_54
	b	LBB208_53
LBB208_53:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_54:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	add	x8, sp, #592
	mov	w2, #1                          ; =0x1
	bl	_fi_value
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	ldr	q0, [sp, #592]
	str	q0, [x8]
	ldr	q0, [sp, #608]
	str	q0, [x8, #16]
	stur	wzr, [x29, #-20]
	b	LBB208_152
LBB208_55:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldur	x8, [x29, #-80]
	ldrb	w9, [x8, #16]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	strb	w8, [sp, #591]
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_57
	b	LBB208_56
LBB208_56:
	ldurb	w8, [x29, #-103]
	ldrb	w9, [sp, #591]
	subs	w8, w8, w9
	b.eq	LBB208_58
	b	LBB208_57
LBB208_57:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_58:
	ldur	w8, [x29, #-120]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #576]
	ldr	x8, [sp, #576]
	cbz	x8, LBB208_61
	b	LBB208_59
LBB208_59:
	ldr	x8, [sp, #576]
	ldr	x8, [x8, #32]
	subs	x8, x8, #2
	b.ne	LBB208_61
	b	LBB208_60
LBB208_60:
	ldur	x0, [x29, #-72]
	ldur	w1, [x29, #-120]
	ldr	x8, [sp, #576]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-80]
	ldrb	w9, [x9, #16]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	sub	x3, x29, #144
	bl	_fi_member
	tbnz	w0, #0, LBB208_62
	b	LBB208_61
LBB208_61:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_62:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	add	x8, sp, #544
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbnz	w8, LBB208_64
	b	LBB208_63
LBB208_63:
	ldur	x8, [x29, #-48]
	add	x8, x8, #8
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	add	x8, sp, #512
	mov	w2, #1                          ; =0x1
	bl	_fi_value
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	ldr	q0, [sp, #512]
	str	q0, [x8]
	ldr	q0, [sp, #528]
	str	q0, [x8, #16]
	b	LBB208_64
LBB208_64:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_65:
	ldur	x8, [x29, #-72]
	add	x10, x8, #48
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #504]
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #2]
	ldr	x9, [sp, #504]
	ldrb	w9, [x9, #4]
	subs	w8, w8, w9
	b.eq	LBB208_67
	b	LBB208_66
LBB208_66:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_67:
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #4]
	cbz	w8, LBB208_70
	b	LBB208_68
LBB208_68:
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #11
	b.ne	LBB208_70
	b	LBB208_69
LBB208_69:
	ldur	x8, [x29, #-32]
	mov	x9, #552                        ; =0x228
	movk	x9, #2, lsl #16
	add	x8, x8, x9
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #3
	ldur	x8, [x29, #-48]
	ldr	x1, [x8, #8216]
	ldur	x2, [x29, #-64]
	bl	_fi_grow
	b	LBB208_70
LBB208_70:
	ldr	x8, [sp, #504]
	ldrb	w8, [x8, #4]
	cbz	w8, LBB208_72
	b	LBB208_71
LBB208_71:
	ldur	x0, [x29, #-48]
	ldr	x8, [sp, #504]
	ldr	x1, [x8, #8]
	ldr	x2, [x8, #16]
	bl	_fi_take
	str	w0, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB208_73
LBB208_72:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
	b	LBB208_73
LBB208_73:
	ldr	w8, [sp, #84]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_74:
	ldur	x0, [x29, #-48]
	mov	w1, #4                          ; =0x4
	mov	w2, #16                         ; =0x10
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_75:
	ldur	x0, [x29, #-48]
	mov	w2, #1                          ; =0x1
	mov	x1, x2
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_76:
	ldur	x0, [x29, #-48]
	mov	w3, #1                          ; =0x1
	mov	x1, x3
	mov	x2, x3
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_77:
	ldur	x0, [x29, #-48]
	mov	w8, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_78:
	ldur	x0, [x29, #-48]
	mov	w1, #1                          ; =0x1
	mov	w2, #4                          ; =0x4
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_79:
	ldur	x0, [x29, #-48]
	mov	w2, #4                          ; =0x4
	mov	x1, x2
	mov	w3, #2                          ; =0x2
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_80:
	ldur	x0, [x29, #-48]
	mov	w2, #4                          ; =0x4
	mov	x1, x2
	mov	w3, #1                          ; =0x1
	mov	w8, #0                          ; =0x0
	and	w4, w8, #0x1
	bl	_fi_scalar
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_81:
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-48]
	ldur	x8, [x29, #-80]
	ldr	w8, [x8, #8]
	mov	x9, x8
	mov	x8, #1                          ; =0x1
	lsl	x2, x8, x9
	ldur	x8, [x29, #-80]
	ldr	w3, [x8, #8]
	ldur	x4, [x29, #-64]
	bl	_fi_call
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_82:
	ldur	x0, [x29, #-72]
	ldur	x1, [x29, #-48]
	ldur	x2, [x29, #-56]
	add	x3, sp, #496
	add	x4, sp, #492
	bl	_fi_candidates
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbz	w8, LBB208_84
	b	LBB208_83
LBB208_83:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_84:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	mov	x9, x0
	ldr	x0, [sp, #72]                   ; 8-byte Folded Reload
	str	x9, [x8]
	str	x1, [x8, #8]
	ldr	x1, [x8]
	ldr	x2, [x8, #8]
	bl	_fi_take
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbz	w8, LBB208_86
	b	LBB208_85
LBB208_85:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_86:
	ldur	x8, [x29, #-32]
	add	x8, x8, #40
	ldur	w9, [x29, #-36]
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9, lsl #3
	ldr	x1, [sp, #496]
	ldur	x2, [x29, #-64]
	bl	_fi_grow
	ldur	x0, [x29, #-32]
	ldur	x1, [x29, #-48]
	ldr	x2, [sp, #496]
	ldr	w3, [sp, #492]
	ldur	x4, [x29, #-64]
	bl	_fi_call
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_87:
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #592]
	mov	x0, x8
	bl	_nl_file_catalog_method
	str	x0, [sp, #464]
	ldr	x8, [sp, #464]
	cbz	x8, LBB208_89
	b	LBB208_88
LBB208_88:
	ldr	x8, [sp, #464]
	ldr	x8, [x8, #56]
	cbnz	x8, LBB208_90
	b	LBB208_89
LBB208_89:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_90:
	ldr	x8, [sp, #464]
	ldr	w9, [x8, #44]
	mov	w8, #0                          ; =0x0
	subs	w9, w9, #1
	csinc	w8, w8, wzr, ne
	mov	w8, w8
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #456]
	ldr	x8, [sp, #464]
	ldr	x8, [x8, #56]
	subs	x8, x8, #1
	str	x8, [sp, #448]
	b	LBB208_91
LBB208_91:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #448]
	ldr	x9, [sp, #456]
	subs	x8, x8, x9
	b.ls	LBB208_98
	b	LBB208_92
LBB208_92:                              ;   in Loop: Header=BB208_91 Depth=1
	ldur	x0, [x29, #-72]
	ldr	x8, [sp, #464]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #448]
	subs	x9, x9, #1
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	mov	w1, #0                          ; =0x0
	sub	x3, x29, #144
	bl	_fi_member
	tbnz	w0, #0, LBB208_94
	b	LBB208_93
LBB208_93:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_94:                              ;   in Loop: Header=BB208_91 Depth=1
	ldur	x0, [x29, #-48]
	ldur	x1, [x29, #-144]
	ldur	x2, [x29, #-136]
	bl	_fi_take
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbz	w8, LBB208_96
	b	LBB208_95
LBB208_95:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_96:                              ;   in Loop: Header=BB208_91 Depth=1
	b	LBB208_97
LBB208_97:                              ;   in Loop: Header=BB208_91 Depth=1
	ldr	x8, [sp, #448]
	subs	x8, x8, #1
	str	x8, [sp, #448]
	b	LBB208_91
LBB208_98:
	ldur	x0, [x29, #-72]
	ldr	x8, [sp, #464]
	mov	x10, #48                        ; =0x30
	ldr	x8, [x8, #48]
	ldr	x9, [sp, #464]
	ldr	x9, [x9, #56]
	subs	x9, x9, #1
	mul	x9, x9, x10
	add	x8, x8, x9
	ldr	x2, [x8, #16]
	mov	w1, #0                          ; =0x0
	sub	x3, x29, #144
	bl	_fi_member
	tbnz	w0, #0, LBB208_100
	b	LBB208_99
LBB208_99:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_100:
	ldur	x8, [x29, #-48]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	add	x8, sp, #416
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_101:
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #592]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #408]
	ldr	x8, [sp, #408]
	cbz	x8, LBB208_103
	b	LBB208_102
LBB208_102:
	ldur	x0, [x29, #-72]
	ldur	x8, [x29, #-56]
	ldr	w1, [x8, #592]
	sub	x2, x29, #144
	bl	_fi_catalog
	tbnz	w0, #0, LBB208_104
	b	LBB208_103
LBB208_103:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_104:
	ldur	w8, [x29, #-132]
	subs	w8, w8, #4
	cset	w8, eq
	strb	w8, [sp, #407]
	ldur	x8, [x29, #-80]
	add	x8, x8, #8
	ldur	x9, [x29, #-80]
	ldrb	w10, [x9]
	mov	w9, #2                          ; =0x2
	subs	w10, w10, #251
	csinc	w9, w9, wzr, eq
	add	x8, x8, w9, sxtw #3
	ldrh	w8, [x8]
	strh	w8, [sp, #404]
	ldrb	w8, [sp, #407]
	tbz	w8, #0, LBB208_106
	b	LBB208_105
LBB208_105:
	ldr	x8, [sp, #408]
	ldr	x8, [x8, #32]
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB208_107
LBB208_106:
	mov	x8, #1                          ; =0x1
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	b	LBB208_107
LBB208_107:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #392]
	ldr	x8, [sp, #392]
	str	x8, [sp, #384]
	b	LBB208_108
LBB208_108:                             ; =>This Inner Loop Header: Depth=1
	ldr	x8, [sp, #384]
	subs	x8, x8, #0
	b.ls	LBB208_118
	b	LBB208_109
LBB208_109:                             ;   in Loop: Header=BB208_108 Depth=1
	ldur	x8, [x29, #-72]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldur	x8, [x29, #-56]
	ldr	w8, [x8, #592]
	str	w8, [sp, #36]                   ; 4-byte Folded Spill
	ldr	x8, [sp, #408]
	ldr	x8, [x8, #24]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldrb	w8, [sp, #407]
	tbz	w8, #0, LBB208_111
	b	LBB208_110
LBB208_110:                             ;   in Loop: Header=BB208_108 Depth=1
	ldr	x8, [sp, #384]
	subs	x8, x8, #1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB208_112
LBB208_111:                             ;   in Loop: Header=BB208_108 Depth=1
	ldrh	w8, [sp, #404]
                                        ; kill: def $x8 killed $w8
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB208_112
LBB208_112:                             ;   in Loop: Header=BB208_108 Depth=1
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	add	x3, sp, #368
	bl	_fi_member
	tbnz	w0, #0, LBB208_114
	b	LBB208_113
LBB208_113:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_114:                             ;   in Loop: Header=BB208_108 Depth=1
	ldur	x0, [x29, #-48]
	ldr	x1, [sp, #368]
	ldr	x2, [sp, #376]
	bl	_fi_take
	stur	w0, [x29, #-148]
	ldur	w8, [x29, #-148]
	cbz	w8, LBB208_116
	b	LBB208_115
LBB208_115:
	ldur	w8, [x29, #-148]
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_116:                             ;   in Loop: Header=BB208_108 Depth=1
	b	LBB208_117
LBB208_117:                             ;   in Loop: Header=BB208_108 Depth=1
	ldr	x8, [sp, #384]
	subs	x8, x8, #1
	str	x8, [sp, #384]
	b	LBB208_108
LBB208_118:
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	add	x8, sp, #336
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	q0, [sp, #336]
	stur	q0, [x29, #-128]
	ldr	q0, [sp, #352]
	stur	q0, [x29, #-112]
	ldrb	w8, [sp, #407]
	tbnz	w8, #0, LBB208_120
	b	LBB208_119
LBB208_119:
	ldrh	w9, [sp, #404]
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w9
	sturb	w8, [x29, #-103]
	b	LBB208_120
LBB208_120:
	ldur	x0, [x29, #-48]
	ldur	q0, [x29, #-128]
	add	x1, sp, #304
	str	q0, [sp, #304]
	ldur	q0, [x29, #-112]
	str	q0, [sp, #320]
	bl	_fi_push
	stur	w0, [x29, #-20]
	b	LBB208_152
LBB208_121:
	ldur	x8, [x29, #-48]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB208_123
	b	LBB208_122
LBB208_122:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_123:
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	ldr	q0, [x8, #16]
	stur	q0, [x29, #-112]
	ldurb	w8, [x29, #-104]
	subs	w8, w8, #2
	b.ne	LBB208_126
	b	LBB208_124
LBB208_124:
	ldur	x0, [x29, #-128]
	ldur	x1, [x29, #-120]
	bl	_owned
	tbnz	w0, #0, LBB208_126
	b	LBB208_125
LBB208_125:
	ldurb	w8, [x29, #-127]
	cbz	w8, LBB208_127
	b	LBB208_126
LBB208_126:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_127:
	ldur	w8, [x29, #-120]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #296]
	ldr	x8, [sp, #296]
	cbnz	x8, LBB208_129
	b	LBB208_128
LBB208_128:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_129:
	ldur	x8, [x29, #-80]
	ldrb	w9, [x8]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, #254
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.eq	LBB208_131
	b	LBB208_130
LBB208_130:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #105
	cset	w8, eq
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB208_131
LBB208_131:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w8, w8, #0x1
	strb	w8, [sp, #295]
	ldur	w8, [x29, #-116]
	subs	w8, w8, #4
	b.ne	LBB208_137
	b	LBB208_132
LBB208_132:
	ldur	x8, [x29, #-80]
	ldrb	w8, [x8]
	subs	w8, w8, #252
	b.ne	LBB208_137
	b	LBB208_133
LBB208_133:
	ldurh	w8, [x29, #-82]
                                        ; kill: def $x8 killed $w8
	ldr	x9, [sp, #296]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.hs	LBB208_135
	b	LBB208_134
LBB208_134:
	ldur	x0, [x29, #-72]
	ldur	w1, [x29, #-120]
	ldr	x8, [sp, #296]
	ldr	x8, [x8, #24]
	ldurh	w9, [x29, #-82]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	sub	x3, x29, #144
	bl	_fi_member
	tbnz	w0, #0, LBB208_136
	b	LBB208_135
LBB208_135:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_136:
	b	LBB208_150
LBB208_137:
	ldur	w8, [x29, #-116]
	subs	w8, w8, #3
	b.ne	LBB208_148
	b	LBB208_138
LBB208_138:
	ldrb	w8, [sp, #295]
	tbz	w8, #0, LBB208_140
	b	LBB208_139
LBB208_139:
	mov	w0, #1                          ; =0x1
	bl	_scalar_type
	add	x8, sp, #21
	stur	x0, [x8, #255]
	add	x8, sp, #29
	stur	x1, [x8, #255]
	add	x8, sp, #21
	ldur	q0, [x8, #255]
	stur	q0, [x29, #-144]
	b	LBB208_147
LBB208_140:
	ldurh	w8, [x29, #-82]
	cbnz	w8, LBB208_143
	b	LBB208_141
LBB208_141:
	ldurb	w8, [x29, #-103]
	subs	w8, w8, #1
	b.eq	LBB208_144
	b	LBB208_142
LBB208_142:
	ldurb	w8, [x29, #-103]
	subs	w8, w8, #2
	b.eq	LBB208_144
	b	LBB208_143
LBB208_143:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_144:
	ldur	x0, [x29, #-72]
	ldur	w1, [x29, #-120]
	ldr	x8, [sp, #296]
	ldr	x8, [x8, #24]
	ldurb	w9, [x29, #-103]
	subs	w9, w9, #2
	cset	w10, eq
                                        ; implicit-def: $x9
	mov	x9, x10
	and	x9, x9, #0x1
	add	x8, x8, x9, lsl #5
	ldr	x2, [x8, #16]
	sub	x3, x29, #144
	bl	_fi_member
	tbnz	w0, #0, LBB208_146
	b	LBB208_145
LBB208_145:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_146:
	b	LBB208_147
LBB208_147:
	b	LBB208_149
LBB208_148:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_149:
	b	LBB208_150
LBB208_150:
	ldur	x8, [x29, #-48]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-48]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldur	x0, [x29, #-144]
	ldur	x1, [x29, #-136]
	add	x8, sp, #240
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	ldr	q0, [sp, #240]
	str	q0, [x8]
	ldr	q0, [sp, #256]
	str	q0, [x8, #16]
	stur	wzr, [x29, #-20]
	b	LBB208_152
LBB208_151:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-20]
	b	LBB208_152
LBB208_152:
	ldur	w0, [x29, #-20]
	add	sp, sp, #1200
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
	.p2align	2
lJTI208_0:
	.long	LBB208_2-Ltmp32
	.long	LBB208_12-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_13-Ltmp32
	.long	LBB208_9-Ltmp32
	.long	LBB208_14-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_42-Ltmp32
	.long	LBB208_46-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_16-Ltmp32
	.long	LBB208_24-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_81-Ltmp32
	.long	LBB208_16-Ltmp32
	.long	LBB208_24-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_2-Ltmp32
	.long	LBB208_2-Ltmp32
	.long	LBB208_6-Ltmp32
	.long	LBB208_6-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_76-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_77-Ltmp32
	.long	LBB208_77-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_79-Ltmp32
	.long	LBB208_79-Ltmp32
	.long	LBB208_80-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_2-Ltmp32
	.long	LBB208_74-Ltmp32
	.long	LBB208_74-Ltmp32
	.long	LBB208_81-Ltmp32
	.long	LBB208_82-Ltmp32
	.long	LBB208_65-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_11-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_10-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_101-Ltmp32
	.long	LBB208_121-Ltmp32
	.long	LBB208_121-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_87-Ltmp32
	.long	LBB208_3-Ltmp32
	.long	LBB208_55-Ltmp32
	.long	LBB208_51-Ltmp32
	.long	LBB208_46-Ltmp32
	.long	LBB208_2-Ltmp32
	.long	LBB208_81-Ltmp32
	.long	LBB208_82-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_74-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_75-Ltmp32
	.long	LBB208_76-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_78-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_15-Ltmp32
	.long	LBB208_101-Ltmp32
	.long	LBB208_121-Ltmp32
	.long	LBB208_151-Ltmp32
	.long	LBB208_121-Ltmp32
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_join
_fi_join:                               ; @fi_join
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	sturh	w2, [x29, #-26]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-40]
	strb	wzr, [x8]
	ldur	x8, [x29, #-24]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB209_2
	b	LBB209_1
LBB209_1:
	stur	wzr, [x29, #-4]
	b	LBB209_29
LBB209_2:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8]
	tbnz	w8, #0, LBB209_4
	b	LBB209_3
LBB209_3:
	ldur	x0, [x29, #-16]
	ldur	x1, [x29, #-24]
	mov	x2, #16392                      ; =0x4008
	bl	_memcpy
	ldur	x9, [x29, #-40]
	mov	w8, #1                          ; =0x1
	strb	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB209_29
LBB209_4:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.eq	LBB209_6
	b	LBB209_5
LBB209_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB209_29
LBB209_6:
	sturh	wzr, [x29, #-42]
	b	LBB209_7
LBB209_7:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB209_12 Depth 2
	ldurh	w8, [x29, #-42]
	subs	w8, w8, #2
	b.ge	LBB209_28
	b	LBB209_8
LBB209_8:                               ;   in Loop: Header=BB209_7 Depth=1
	ldurh	w8, [x29, #-42]
	cbz	w8, LBB209_10
	b	LBB209_9
LBB209_9:                               ;   in Loop: Header=BB209_7 Depth=1
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #2]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB209_11
LBB209_10:                              ;   in Loop: Header=BB209_7 Depth=1
	ldurh	w8, [x29, #-26]
	str	w8, [sp, #32]                   ; 4-byte Folded Spill
	b	LBB209_11
LBB209_11:                              ;   in Loop: Header=BB209_7 Depth=1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	sturh	w8, [x29, #-44]
	sturh	wzr, [x29, #-46]
	b	LBB209_12
LBB209_12:                              ;   Parent Loop BB209_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldurh	w8, [x29, #-46]
	ldurh	w9, [x29, #-44]
	subs	w8, w8, w9
	b.ge	LBB209_26
	b	LBB209_13
LBB209_13:                              ;   in Loop: Header=BB209_12 Depth=2
	ldurh	w8, [x29, #-42]
	cbz	w8, LBB209_15
	b	LBB209_14
LBB209_14:                              ;   in Loop: Header=BB209_12 Depth=2
	ldur	x8, [x29, #-16]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldurh	w9, [x29, #-46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB209_16
LBB209_15:                              ;   in Loop: Header=BB209_12 Depth=2
	ldur	x8, [x29, #-16]
	add	x8, x8, #8
	ldurh	w9, [x29, #-46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	b	LBB209_16
LBB209_16:                              ;   in Loop: Header=BB209_12 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #56]
	ldurh	w8, [x29, #-42]
	cbz	w8, LBB209_18
	b	LBB209_17
LBB209_17:                              ;   in Loop: Header=BB209_12 Depth=2
	ldur	x8, [x29, #-24]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldurh	w9, [x29, #-46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB209_19
LBB209_18:                              ;   in Loop: Header=BB209_12 Depth=2
	ldur	x8, [x29, #-24]
	add	x8, x8, #8
	ldurh	w9, [x29, #-46]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB209_19
LBB209_19:                              ;   in Loop: Header=BB209_12 Depth=2
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #48]
	ldr	x9, [sp, #56]
	ldr	x8, [sp, #48]
	ldr	x0, [x9]
	ldr	x1, [x9, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB209_21
	b	LBB209_20
LBB209_20:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB209_29
LBB209_21:                              ;   in Loop: Header=BB209_12 Depth=2
	ldr	x8, [sp, #56]
	ldr	x8, [x8, #16]
	ldr	x9, [sp, #48]
	ldr	x9, [x9, #16]
	orr	x8, x8, x9
	str	x8, [sp, #40]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #24]
	ldr	x9, [sp, #48]
	ldrb	w9, [x9, #24]
	orr	w8, w8, w9
	strb	w8, [sp, #39]
	ldr	x8, [sp, #56]
	ldrb	w8, [x8, #25]
	ldr	x9, [sp, #48]
	ldrb	w9, [x9, #25]
	orr	w8, w8, w9
	strb	w8, [sp, #38]
	ldr	x9, [sp, #40]
	ldr	x8, [sp, #56]
	ldr	x10, [x8, #16]
	mov	w8, #1                          ; =0x1
	subs	x9, x9, x10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB209_24
	b	LBB209_22
LBB209_22:                              ;   in Loop: Header=BB209_12 Depth=2
	ldrb	w9, [sp, #39]
	ldr	x8, [sp, #56]
	ldrb	w10, [x8, #24]
	mov	w8, #1                          ; =0x1
	subs	w9, w9, w10
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b.ne	LBB209_24
	b	LBB209_23
LBB209_23:                              ;   in Loop: Header=BB209_12 Depth=2
	ldrb	w8, [sp, #38]
	ldr	x9, [sp, #56]
	ldrb	w9, [x9, #25]
	subs	w8, w8, w9
	cset	w8, ne
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB209_24
LBB209_24:                              ;   in Loop: Header=BB209_12 Depth=2
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w10, w8, #0x1
	ldur	x9, [x29, #-40]
	ldrb	w8, [x9]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9]
	ldr	x8, [sp, #40]
	ldr	x9, [sp, #56]
	str	x8, [x9, #16]
	ldrb	w8, [sp, #39]
	ldr	x9, [sp, #56]
	strb	w8, [x9, #24]
	ldrb	w8, [sp, #38]
	ldr	x9, [sp, #56]
	strb	w8, [x9, #25]
	b	LBB209_25
LBB209_25:                              ;   in Loop: Header=BB209_12 Depth=2
	ldurh	w8, [x29, #-46]
	add	w8, w8, #1
	sturh	w8, [x29, #-46]
	b	LBB209_12
LBB209_26:                              ;   in Loop: Header=BB209_7 Depth=1
	b	LBB209_27
LBB209_27:                              ;   in Loop: Header=BB209_7 Depth=1
	ldurh	w8, [x29, #-42]
	add	w8, w8, #1
	sturh	w8, [x29, #-42]
	b	LBB209_7
LBB209_28:
	stur	wzr, [x29, #-4]
	b	LBB209_29
LBB209_29:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_candidates
_fi_candidates:                         ; @fi_candidates
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-32]
	add	x8, x8, #8
	stur	x8, [x29, #-56]
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB210_2
	b	LBB210_1
LBB210_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_2:
	ldur	x8, [x29, #-24]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #2
	b.ne	LBB210_5
	b	LBB210_3
LBB210_3:
	ldur	x8, [x29, #-64]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #11                         ; =0xb
	bl	_scalar_type
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #64]
	str	x1, [sp, #72]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	ldr	x2, [sp, #64]
	ldr	x3, [sp, #72]
	bl	_same
	tbz	w0, #0, LBB210_5
	b	LBB210_4
LBB210_4:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	cbnz	x8, LBB210_6
	b	LBB210_5
LBB210_5:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_6:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	subs	w8, w8, #64
	b.hs	LBB210_9
	b	LBB210_7
LBB210_7:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #24]
                                        ; kill: def $x9 killed $w9
	lsr	x8, x8, x9
	cbz	x8, LBB210_9
	b	LBB210_8
LBB210_8:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_9:
	ldur	x8, [x29, #-16]
	ldr	w8, [x8, #24]
	str	w8, [sp, #60]
	str	wzr, [sp, #56]
	b	LBB210_10
LBB210_10:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB210_16 Depth 2
	ldr	w8, [sp, #56]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB210_36
	b	LBB210_11
LBB210_11:                              ;   in Loop: Header=BB210_10 Depth=1
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldr	w9, [sp, #56]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB210_34
	b	LBB210_12
LBB210_12:                              ;   in Loop: Header=BB210_10 Depth=1
	ldur	x8, [x29, #-16]
	add	x10, x8, #48
	ldr	w8, [sp, #56]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #48]
	ldr	x8, [sp, #48]
	ldrh	w8, [x8]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.ne	LBB210_14
	b	LBB210_13
LBB210_13:                              ;   in Loop: Header=BB210_10 Depth=1
	ldr	x8, [sp, #48]
	ldrb	w8, [x8, #4]
	ldur	x9, [x29, #-56]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB210_15
	b	LBB210_14
LBB210_14:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_15:                              ;   in Loop: Header=BB210_10 Depth=1
	strh	wzr, [sp, #46]
	b	LBB210_16
LBB210_16:                              ;   Parent Loop BB210_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrh	w8, [sp, #46]
	ldr	x9, [sp, #48]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB210_28
	b	LBB210_17
LBB210_17:                              ;   in Loop: Header=BB210_16 Depth=2
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldr	w10, [sp, #56]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #46]
	add	w9, w9, w10
	ldr	q0, [x8, w9, uxtw #4]
	str	q0, [sp, #16]
	ldur	x8, [x29, #-56]
	ldrb	w8, [x8]
	subs	w8, w8, #152
	b.ne	LBB210_23
	b	LBB210_18
LBB210_18:                              ;   in Loop: Header=BB210_16 Depth=2
	ldrb	w8, [sp, #17]
	cbz	w8, LBB210_20
	b	LBB210_19
LBB210_19:                              ;   in Loop: Header=BB210_16 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #78
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	subs	w8, w8, #256
	b.hs	LBB210_21
	b	LBB210_22
LBB210_20:                              ;   in Loop: Header=BB210_16 Depth=2
	ldur	x8, [x29, #-32]
	add	x8, x8, #78
	ldrh	w9, [sp, #46]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB210_22
	b	LBB210_21
LBB210_21:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_22:                              ;   in Loop: Header=BB210_16 Depth=2
	b	LBB210_26
LBB210_23:                              ;   in Loop: Header=BB210_16 Depth=2
	ldrb	w8, [sp, #17]
	cbz	w8, LBB210_25
	b	LBB210_24
LBB210_24:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_25:                              ;   in Loop: Header=BB210_16 Depth=2
	b	LBB210_26
LBB210_26:                              ;   in Loop: Header=BB210_16 Depth=2
	b	LBB210_27
LBB210_27:                              ;   in Loop: Header=BB210_16 Depth=2
	ldrh	w8, [sp, #46]
	add	w8, w8, #1
	strh	w8, [sp, #46]
	b	LBB210_16
LBB210_28:                              ;   in Loop: Header=BB210_10 Depth=1
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-16]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.ne	LBB210_30
	b	LBB210_29
LBB210_29:                              ;   in Loop: Header=BB210_10 Depth=1
	ldr	w8, [sp, #56]
	str	w8, [sp, #60]
	b	LBB210_33
LBB210_30:                              ;   in Loop: Header=BB210_10 Depth=1
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #60]
	ldr	w2, [sp, #56]
	bl	_fi_signature
	tbnz	w0, #0, LBB210_32
	b	LBB210_31
LBB210_31:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB210_37
LBB210_32:                              ;   in Loop: Header=BB210_10 Depth=1
	b	LBB210_33
LBB210_33:                              ;   in Loop: Header=BB210_10 Depth=1
	b	LBB210_34
LBB210_34:                              ;   in Loop: Header=BB210_10 Depth=1
	b	LBB210_35
LBB210_35:                              ;   in Loop: Header=BB210_10 Depth=1
	ldr	w8, [sp, #56]
	add	w8, w8, #1
	str	w8, [sp, #56]
	b	LBB210_10
LBB210_36:
	ldur	x8, [x29, #-64]
	ldr	x8, [x8, #16]
	ldur	x9, [x29, #-40]
	str	x8, [x9]
	ldr	w8, [sp, #60]
	ldur	x9, [x29, #-48]
	str	w8, [x9]
	stur	wzr, [x29, #-4]
	b	LBB210_37
LBB210_37:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_push
_fi_push:                               ; @fi_push
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x1, [sp]                        ; 8-byte Folded Spill
	str	x0, [sp, #16]
	str	x1, [sp, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8, #2]
	subs	w8, w8, #256
	b.ne	LBB211_2
	b	LBB211_1
LBB211_1:
	mov	w8, #3                          ; =0x3
	str	w8, [sp, #28]
	b	LBB211_3
LBB211_2:
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	ldr	x8, [sp, #16]
	mov	x10, #8200                      ; =0x2008
	add	x8, x8, x10
	ldr	x12, [sp, #16]
	ldrh	w10, [x12, #2]
                                        ; kill: def $x10 killed $w10
	mov	x11, x10
	add	w11, w11, #1
	strh	w11, [x12, #2]
	add	x8, x8, x10, lsl #5
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	q0, [x9, #16]
	str	q0, [x8, #16]
	str	wzr, [sp, #28]
	b	LBB211_3
LBB211_3:
	ldr	w0, [sp, #28]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_scalar
_fi_scalar:                             ; @fi_scalar
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	sturb	w1, [x29, #-17]
	sturb	w2, [x29, #-18]
	sturh	w3, [x29, #-20]
	sturb	w4, [x29, #-21]
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #2]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ge	LBB212_2
	b	LBB212_1
LBB212_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB212_17
LBB212_2:
	ldurb	w8, [x29, #-21]
	tbz	w8, #0, LBB212_7
	b	LBB212_3
LBB212_3:
	ldur	x8, [x29, #-16]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldrb	w8, [x8]
	sturb	w8, [x29, #-17]
	ldurb	w8, [x29, #-17]
	subs	w8, w8, #1
	b.eq	LBB212_6
	b	LBB212_4
LBB212_4:
	ldurb	w8, [x29, #-17]
	subs	w8, w8, #4
	b.eq	LBB212_6
	b	LBB212_5
LBB212_5:
	mov	w8, #2                          ; =0x2
	stur	w8, [x29, #-4]
	b	LBB212_17
LBB212_6:
	b	LBB212_7
LBB212_7:
	sturh	wzr, [x29, #-24]
	b	LBB212_8
LBB212_8:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-24]
	ldurh	w9, [x29, #-20]
	subs	w8, w8, w9
	b.ge	LBB212_13
	b	LBB212_9
LBB212_9:                               ;   in Loop: Header=BB212_8 Depth=1
	ldur	x8, [x29, #-16]
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	ldurb	w0, [x29, #-17]
	bl	_scalar_type
	mov	x8, x0
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	stur	x8, [x29, #-44]
	stur	x1, [x29, #-36]
	ldur	x1, [x29, #-44]
	ldur	x2, [x29, #-36]
	bl	_fi_take
	stur	w0, [x29, #-28]
	ldur	w8, [x29, #-28]
	cbz	w8, LBB212_11
	b	LBB212_10
LBB212_10:
	ldur	w8, [x29, #-28]
	stur	w8, [x29, #-4]
	b	LBB212_17
LBB212_11:                              ;   in Loop: Header=BB212_8 Depth=1
	b	LBB212_12
LBB212_12:                              ;   in Loop: Header=BB212_8 Depth=1
	ldurh	w8, [x29, #-24]
	add	w8, w8, #1
	sturh	w8, [x29, #-24]
	b	LBB212_8
LBB212_13:
	ldurb	w8, [x29, #-18]
	subs	w8, w8, #16
	b.ne	LBB212_15
	b	LBB212_14
LBB212_14:
	mov	w8, #0                          ; =0x0
	str	w8, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB212_16
LBB212_15:
	ldur	x8, [x29, #-16]
	str	x8, [sp]                        ; 8-byte Folded Spill
	ldurb	w0, [x29, #-18]
	bl	_scalar_type
	str	x0, [sp, #32]
	str	x1, [sp, #40]
	ldr	x0, [sp, #32]
	ldr	x1, [sp, #40]
	add	x8, sp, #48
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldr	x0, [sp]                        ; 8-byte Folded Reload
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	bl	_fi_push
	str	w0, [sp, #20]                   ; 4-byte Folded Spill
	b	LBB212_16
LBB212_16:
	ldr	w8, [sp, #20]                   ; 4-byte Folded Reload
	stur	w8, [x29, #-4]
	b	LBB212_17
LBB212_17:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_take
_fi_take:                               ; @fi_take
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x1, [x29, #-20]
	stur	x2, [x29, #-12]
	stur	x0, [x29, #-32]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB213_2
	b	LBB213_1
LBB213_1:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB213_6
LBB213_2:
	ldur	x8, [x29, #-32]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	str	x8, [sp, #40]
	ldr	x8, [sp, #40]
	ldrb	w8, [x8, #24]
	subs	w8, w8, #2
	b.ne	LBB213_4
	b	LBB213_3
LBB213_3:
	ldr	x8, [sp, #40]
	ldr	x0, [x8]
	ldr	x1, [x8, #8]
	ldur	x2, [x29, #-20]
	ldur	x3, [x29, #-12]
	bl	_same
	tbnz	w0, #0, LBB213_5
	b	LBB213_4
LBB213_4:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB213_6
LBB213_5:
	ldr	x8, [sp, #40]
	movi.2d	v0, #0000000000000000
	str	q0, [sp]
	str	q0, [sp, #16]
	ldr	q0, [sp]
	str	q0, [x8]
	ldr	q0, [sp, #16]
	str	q0, [x8, #16]
	ldur	x9, [x29, #-32]
	ldrh	w10, [x9, #2]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w10, uxth
	strh	w8, [x9, #2]
	stur	wzr, [x29, #-4]
	b	LBB213_6
LBB213_6:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_member
_fi_member:                             ; @fi_member
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	stur	x3, [x29, #-40]
	ldur	x8, [x29, #-32]
	cbnz	x8, LBB214_2
	b	LBB214_1
LBB214_1:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	mov	w0, #0                          ; =0x0
	bl	_scalar_type
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	stur	x0, [x29, #-56]
	stur	x1, [x29, #-48]
	ldur	q0, [x29, #-56]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_2:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str@PAGE
	add	x1, x1, l_.str@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB214_4
	b	LBB214_3
LBB214_3:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #28]                   ; 4-byte Folded Spill
	bl	_scalar_type
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	stur	x0, [x29, #-72]
	stur	x1, [x29, #-64]
	ldur	q0, [x29, #-72]
	str	q0, [x9]
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_4:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.1@PAGE
	add	x1, x1, l_.str.1@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB214_6
	b	LBB214_5
LBB214_5:
	ldur	x8, [x29, #-40]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w0, #4                          ; =0x4
	bl	_scalar_type
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x0, [sp, #72]
	str	x1, [sp, #80]
	ldur	q0, [sp, #72]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_6:
	ldur	x0, [x29, #-32]
	adrp	x1, l_.str.2@PAGE
	add	x1, x1, l_.str.2@PAGEOFF
	bl	_strcmp
	cbnz	w0, LBB214_8
	b	LBB214_7
LBB214_7:
	ldur	x8, [x29, #-40]
	str	x8, [sp]                        ; 8-byte Folded Spill
	mov	w0, #5                          ; =0x5
	bl	_scalar_type
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x0, [sp, #56]
	str	x1, [sp, #64]
	ldur	q0, [sp, #56]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_8:
	str	wzr, [sp, #52]
	b	LBB214_9
LBB214_9:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #52]
	subs	w8, w8, #8
	b.hs	LBB214_15
	b	LBB214_10
LBB214_10:                              ;   in Loop: Header=BB214_9 Depth=1
	ldr	w8, [sp, #52]
	mov	x0, x8
	bl	_nl_file_catalog_type
	str	x0, [sp, #40]
	ldr	x8, [sp, #40]
	cbz	x8, LBB214_13
	b	LBB214_11
LBB214_11:                              ;   in Loop: Header=BB214_9 Depth=1
	ldr	x8, [sp, #40]
	ldr	x0, [x8]
	ldur	x1, [x29, #-32]
	bl	_strcmp
	cbnz	w0, LBB214_13
	b	LBB214_12
LBB214_12:
	ldur	x0, [x29, #-16]
	ldr	w1, [sp, #52]
	ldur	x2, [x29, #-40]
	bl	_fi_catalog
	and	w8, w0, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_13:                              ;   in Loop: Header=BB214_9 Depth=1
	b	LBB214_14
LBB214_14:                              ;   in Loop: Header=BB214_9 Depth=1
	ldr	w8, [sp, #52]
	add	w8, w8, #1
	str	w8, [sp, #52]
	b	LBB214_9
LBB214_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB214_16
LBB214_16:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_grow
_fi_grow:                               ; @fi_grow
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, #24]
	str	x1, [sp, #16]
	str	x2, [sp, #8]
	ldr	x8, [sp, #24]
	ldr	x8, [x8]
	ldr	x9, [sp, #16]
	orr	x8, x8, x9
	ldr	x9, [sp, #24]
	ldr	x9, [x9]
	subs	x8, x8, x9
	cset	w10, ne
	ldr	x9, [sp, #8]
	ldrb	w8, [x9]
	and	w8, w8, #0x1
	orr	w8, w8, w10
	subs	w8, w8, #0
	cset	w8, ne
	strb	w8, [x9]
	ldr	x10, [sp, #16]
	ldr	x9, [sp, #24]
	ldr	x8, [x9]
	orr	x8, x8, x10
	str	x8, [x9]
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_call
_fi_call:                               ; @fi_call
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #224
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-32]
	stur	w3, [x29, #-36]
	stur	x4, [x29, #-48]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
	ldur	x10, [x29, #-56]
	ldur	w8, [x29, #-36]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	stur	x8, [x29, #-64]
	ldur	x8, [x29, #-64]
	ldrh	w8, [x8]
	sturh	w8, [x29, #-66]
	b	LBB216_1
LBB216_1:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB216_10 Depth 2
	ldurh	w8, [x29, #-66]
	subs	w8, w8, #0
	b.le	LBB216_18
	b	LBB216_2
LBB216_2:                               ;   in Loop: Header=BB216_1 Depth=1
	ldur	x8, [x29, #-56]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x9, [x29, #-56]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldur	w10, [x29, #-36]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldurh	w10, [x29, #-66]
	add	w9, w9, w10
	subs	w9, w9, #1
	ldr	q0, [x8, w9, uxtw #4]
	stur	q0, [x29, #-96]
	ldurb	w8, [x29, #-95]
	cbz	w8, LBB216_4
	b	LBB216_3
LBB216_3:                               ;   in Loop: Header=BB216_1 Depth=1
	b	LBB216_17
LBB216_4:                               ;   in Loop: Header=BB216_1 Depth=1
	ldur	x8, [x29, #-24]
	ldrh	w8, [x8, #2]
	cbnz	w8, LBB216_6
	b	LBB216_5
LBB216_5:
	mov	w8, #1                          ; =0x1
	stur	w8, [x29, #-4]
	b	LBB216_29
LBB216_6:                               ;   in Loop: Header=BB216_1 Depth=1
	ldur	x8, [x29, #-24]
	mov	x9, #8200                       ; =0x2008
	add	x8, x8, x9
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #2]
	subs	w10, w9, #1
                                        ; implicit-def: $x9
	mov	x9, x10
	sxtw	x9, w9
	add	x8, x8, x9, lsl #5
	ldr	q0, [x8]
	str	q0, [sp, #80]
	ldr	q0, [x8, #16]
	str	q0, [sp, #96]
	ldur	x0, [x29, #-24]
	ldur	x1, [x29, #-96]
	ldur	x2, [x29, #-88]
	bl	_fi_take
	str	w0, [sp, #76]
	ldr	w8, [sp, #76]
	cbz	w8, LBB216_8
	b	LBB216_7
LBB216_7:
	ldr	w8, [sp, #76]
	stur	w8, [x29, #-4]
	b	LBB216_29
LBB216_8:                               ;   in Loop: Header=BB216_1 Depth=1
	ldurb	w8, [x29, #-96]
	subs	w8, w8, #11
	b.ne	LBB216_16
	b	LBB216_9
LBB216_9:                               ;   in Loop: Header=BB216_1 Depth=1
	str	wzr, [sp, #72]
	b	LBB216_10
LBB216_10:                              ;   Parent Loop BB216_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [sp, #72]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB216_15
	b	LBB216_11
LBB216_11:                              ;   in Loop: Header=BB216_10 Depth=2
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #72]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB216_13
	b	LBB216_12
LBB216_12:                              ;   in Loop: Header=BB216_10 Depth=2
	ldur	x8, [x29, #-16]
	add	x8, x8, #552
	ldr	w9, [sp, #72]
                                        ; kill: def $x9 killed $w9
	add	x8, x8, x9, lsl #11
	ldurh	w9, [x29, #-66]
	subs	w9, w9, #1
	add	x0, x8, w9, sxtw #3
	ldr	x1, [sp, #96]
	ldur	x2, [x29, #-48]
	bl	_fi_grow
	b	LBB216_13
LBB216_13:                              ;   in Loop: Header=BB216_10 Depth=2
	b	LBB216_14
LBB216_14:                              ;   in Loop: Header=BB216_10 Depth=2
	ldr	w8, [sp, #72]
	add	w8, w8, #1
	str	w8, [sp, #72]
	b	LBB216_10
LBB216_15:                              ;   in Loop: Header=BB216_1 Depth=1
	b	LBB216_16
LBB216_16:                              ;   in Loop: Header=BB216_1 Depth=1
	b	LBB216_17
LBB216_17:                              ;   in Loop: Header=BB216_1 Depth=1
	ldurh	w9, [x29, #-66]
	mov	w8, #-1                         ; =0xffffffff
	add	w8, w8, w9, uxth
	sturh	w8, [x29, #-66]
	b	LBB216_1
LBB216_18:
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #4]
	cbnz	w8, LBB216_20
	b	LBB216_19
LBB216_19:
	stur	wzr, [x29, #-4]
	b	LBB216_29
LBB216_20:
	ldur	x8, [x29, #-64]
	ldr	x0, [x8, #8]
	ldr	x1, [x8, #16]
	add	x8, sp, #40
	mov	w2, #2                          ; =0x2
	bl	_fi_value
	ldur	x8, [x29, #-64]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #11
	b.ne	LBB216_28
	b	LBB216_21
LBB216_21:
	str	wzr, [sp, #36]
	b	LBB216_22
LBB216_22:                              ; =>This Inner Loop Header: Depth=1
	ldr	w8, [sp, #36]
	ldur	x9, [x29, #-56]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB216_27
	b	LBB216_23
LBB216_23:                              ;   in Loop: Header=BB216_22 Depth=1
	ldur	x8, [x29, #-32]
	ldr	w9, [sp, #36]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB216_25
	b	LBB216_24
LBB216_24:                              ;   in Loop: Header=BB216_22 Depth=1
	ldur	x8, [x29, #-16]
	mov	x9, #552                        ; =0x228
	movk	x9, #2, lsl #16
	add	x8, x8, x9
	ldr	w9, [sp, #36]
                                        ; kill: def $x9 killed $w9
	ldr	x9, [x8, x9, lsl #3]
	ldr	x8, [sp, #56]
	orr	x8, x8, x9
	str	x8, [sp, #56]
	b	LBB216_25
LBB216_25:                              ;   in Loop: Header=BB216_22 Depth=1
	b	LBB216_26
LBB216_26:                              ;   in Loop: Header=BB216_22 Depth=1
	ldr	w8, [sp, #36]
	add	w8, w8, #1
	str	w8, [sp, #36]
	b	LBB216_22
LBB216_27:
	b	LBB216_28
LBB216_28:
	ldur	x0, [x29, #-24]
	ldur	q0, [sp, #40]
	mov	x1, sp
	str	q0, [sp]
	ldur	q0, [sp, #56]
	str	q0, [sp, #16]
	bl	_fi_push
	stur	w0, [x29, #-4]
	b	LBB216_29
LBB216_29:
	ldur	w0, [x29, #-4]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_catalog
_fi_catalog:                            ; @fi_catalog
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	stur	x2, [x29, #-32]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	ldr	x0, [x8, #16]
	ldur	w1, [x29, #-20]
	add	x2, sp, #28
	bl	_nvm_file_nominal_type
	tbnz	w0, #0, LBB217_2
	b	LBB217_1
LBB217_1:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB217_3
LBB217_2:
	ldur	x8, [x29, #-32]
	ldrb	w11, [sp, #40]
	mov	w10, #10                        ; =0xa
	mov	w9, #8                          ; =0x8
	subs	w11, w11, #0
	csel	w9, w9, w10, eq
	strb	w9, [sp, #12]
	strb	wzr, [sp, #13]
	strh	wzr, [sp, #14]
	ldr	w9, [sp, #28]
	str	w9, [sp, #16]
	ldr	w9, [sp, #32]
	str	w9, [sp, #20]
	ldr	w9, [sp, #44]
	str	w9, [sp, #24]
	ldur	q0, [sp, #12]
	str	q0, [x8]
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB217_3
LBB217_3:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fi_signature
_fi_signature:                          ; @fi_signature
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	w1, [x29, #-20]
	str	w2, [sp, #24]
	ldur	x10, [x29, #-16]
	ldur	w8, [x29, #-20]
                                        ; kill: def $x8 killed $w8
	mov	x9, #36                         ; =0x24
	add	x11, x10, #48
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	add	x8, x8, #12
	str	x8, [sp, #16]
	ldur	x10, [x29, #-16]
	ldr	w8, [sp, #24]
                                        ; kill: def $x8 killed $w8
	add	x10, x10, #48
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	add	x8, x8, #12
	str	x8, [sp, #8]
	ldr	x8, [sp, #16]
	ldrh	w8, [x8]
	ldr	x9, [sp, #8]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB218_3
	b	LBB218_1
LBB218_1:
	ldr	x8, [sp, #16]
	ldrb	w8, [x8, #4]
	ldr	x9, [sp, #8]
	ldrb	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB218_3
	b	LBB218_2
LBB218_2:
	ldr	x9, [sp, #16]
	ldr	x8, [sp, #8]
	ldr	x0, [x9, #8]
	ldr	x1, [x9, #16]
	ldr	x2, [x8, #8]
	ldr	x3, [x8, #16]
	bl	_same
	tbnz	w0, #0, LBB218_4
	b	LBB218_3
LBB218_3:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB218_11
LBB218_4:
	strh	wzr, [sp, #6]
	b	LBB218_5
LBB218_5:                               ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #6]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB218_10
	b	LBB218_6
LBB218_6:                               ;   in Loop: Header=BB218_5 Depth=1
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x9, [x29, #-16]
	ldr	x9, [x9]
	add	x9, x9, #1560
	ldur	w10, [x29, #-20]
                                        ; kill: def $x10 killed $w10
	ldr	w9, [x9, x10, lsl #2]
	ldrh	w10, [sp, #6]
	add	w9, w9, w10
	add	x9, x8, w9, uxtw #4
	ldur	x8, [x29, #-16]
	ldr	x8, [x8]
	add	x8, x8, #1816
	ldur	x10, [x29, #-16]
	ldr	x10, [x10]
	add	x10, x10, #1560
	ldr	w11, [sp, #24]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldrh	w11, [sp, #6]
	add	w10, w10, w11
	add	x8, x8, w10, uxtw #4
	ldr	x0, [x9]
	ldr	x1, [x9, #8]
	ldr	x2, [x8]
	ldr	x3, [x8, #8]
	bl	_same
	tbnz	w0, #0, LBB218_8
	b	LBB218_7
LBB218_7:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB218_11
LBB218_8:                               ;   in Loop: Header=BB218_5 Depth=1
	b	LBB218_9
LBB218_9:                               ;   in Loop: Header=BB218_5 Depth=1
	ldrh	w8, [sp, #6]
	add	w8, w8, #1
	strh	w8, [sp, #6]
	b	LBB218_5
LBB218_10:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB218_11
LBB218_11:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_cyclic_equal
_file_cyclic_equal:                     ; @file_cyclic_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #416
	stp	x28, x27, [sp, #384]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #400]            ; 16-byte Folded Spill
	add	x29, sp, #400
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	stur	x0, [x29, #-32]
	stur	x1, [x29, #-40]
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ne	LBB219_5
	b	LBB219_1
LBB219_1:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #2]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB219_5
	b	LBB219_2
LBB219_2:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #4]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ne	LBB219_5
	b	LBB219_3
LBB219_3:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #6]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #6]
	subs	w8, w8, w9
	b.ne	LBB219_5
	b	LBB219_4
LBB219_4:
	ldur	x8, [x29, #-32]
	ldrh	w8, [x8, #8]
	ldur	x9, [x29, #-40]
	ldrh	w9, [x9, #8]
	subs	w8, w8, w9
	b.eq	LBB219_6
	b	LBB219_5
LBB219_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_6:
	sturh	wzr, [x29, #-42]
	b	LBB219_7
LBB219_7:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-42]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB219_12
	b	LBB219_8
LBB219_8:                               ;   in Loop: Header=BB219_7 Depth=1
	ldur	x8, [x29, #-32]
	add	x11, x8, #16
	ldurh	w8, [x29, #-42]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w10, x11
	ldur	x8, [x29, #-40]
	add	x10, x8, #16
	ldurh	w8, [x29, #-42]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	sub	x0, x29, #88
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #72]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #72]                   ; 8-byte Folded Reload
	sub	x0, x29, #128
	str	x0, [sp, #88]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	bl	_file_cyclic_value_equal
	tbnz	w0, #0, LBB219_10
	b	LBB219_9
LBB219_9:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_10:                              ;   in Loop: Header=BB219_7 Depth=1
	b	LBB219_11
LBB219_11:                              ;   in Loop: Header=BB219_7 Depth=1
	ldurh	w8, [x29, #-42]
	add	w8, w8, #1
	sturh	w8, [x29, #-42]
	b	LBB219_7
LBB219_12:
	sturh	wzr, [x29, #-130]
	b	LBB219_13
LBB219_13:                              ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-130]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ge	LBB219_18
	b	LBB219_14
LBB219_14:                              ;   in Loop: Header=BB219_13 Depth=1
	ldur	x8, [x29, #-32]
	mov	x10, #10256                     ; =0x2810
	add	x12, x8, x10
	ldurh	w8, [x29, #-130]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x11, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w11, x12
	ldur	x8, [x29, #-40]
	add	x10, x8, x10
	ldurh	w8, [x29, #-130]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	sub	x0, x29, #176
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	add	x0, sp, #184
	str	x0, [sp, #56]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	bl	_file_cyclic_value_equal
	tbnz	w0, #0, LBB219_16
	b	LBB219_15
LBB219_15:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_16:                              ;   in Loop: Header=BB219_13 Depth=1
	b	LBB219_17
LBB219_17:                              ;   in Loop: Header=BB219_13 Depth=1
	ldurh	w8, [x29, #-130]
	add	w8, w8, #1
	sturh	w8, [x29, #-130]
	b	LBB219_13
LBB219_18:
	strh	wzr, [sp, #182]
	b	LBB219_19
LBB219_19:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #182]
	ldur	x9, [x29, #-32]
	ldrh	w9, [x9, #4]
	subs	w8, w8, w9
	b.ge	LBB219_24
	b	LBB219_20
LBB219_20:                              ;   in Loop: Header=BB219_19 Depth=1
	ldur	x8, [x29, #-32]
	mov	x10, #30736                     ; =0x7810
	add	x8, x8, x10
	ldrh	w9, [sp, #182]
                                        ; kill: def $x9 killed $w9
	ldr	x8, [x8, x9, lsl #3]
	ldur	x9, [x29, #-40]
	add	x9, x9, x10
	ldrh	w10, [sp, #182]
                                        ; kill: def $x10 killed $w10
	ldr	x9, [x9, x10, lsl #3]
	subs	x8, x8, x9
	b.eq	LBB219_22
	b	LBB219_21
LBB219_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_22:                              ;   in Loop: Header=BB219_19 Depth=1
	b	LBB219_23
LBB219_23:                              ;   in Loop: Header=BB219_19 Depth=1
	ldrh	w8, [sp, #182]
	add	w8, w8, #1
	strh	w8, [sp, #182]
	b	LBB219_19
LBB219_24:
	strh	wzr, [sp, #180]
	b	LBB219_25
LBB219_25:                              ; =>This Inner Loop Header: Depth=1
	ldrh	w8, [sp, #180]
	subs	w8, w8, #256
	b.hs	LBB219_30
	b	LBB219_26
LBB219_26:                              ;   in Loop: Header=BB219_25 Depth=1
	ldur	x8, [x29, #-32]
	mov	x10, #20496                     ; =0x5010
	add	x12, x8, x10
	ldrh	w8, [sp, #180]
                                        ; kill: def $x8 killed $w8
	mov	x9, #40                         ; =0x28
	mov	x11, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w11, x12
	ldur	x8, [x29, #-40]
	add	x10, x8, x10
	ldrh	w8, [sp, #180]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	add	x0, sp, #136
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #40                         ; =0x28
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, sp, #96
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	bl	_reference_same
	tbnz	w0, #0, LBB219_28
	b	LBB219_27
LBB219_27:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_28:                              ;   in Loop: Header=BB219_25 Depth=1
	b	LBB219_29
LBB219_29:                              ;   in Loop: Header=BB219_25 Depth=1
	ldrh	w8, [sp, #180]
	add	w8, w8, #1
	strh	w8, [sp, #180]
	b	LBB219_25
LBB219_30:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB219_31
LBB219_31:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #400]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #416
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function fif_state_metadata_equal
_fif_state_metadata_equal:              ; @fif_state_metadata_equal
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stur	x0, [x29, #-16]
	stur	x1, [x29, #-24]
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #24]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #24]
	subs	x8, x8, x9
	b.ne	LBB220_4
	b	LBB220_1
LBB220_1:
	ldur	x8, [x29, #-16]
	ldrb	w8, [x8, #40]
	and	w8, w8, #0x1
	ldur	x9, [x29, #-24]
	ldrb	w9, [x9, #40]
	and	w9, w9, #0x1
	subs	w8, w8, w9
	b.ne	LBB220_4
	b	LBB220_2
LBB220_2:
	ldur	x8, [x29, #-16]
	ldr	x8, [x8, #32]
	ldur	x9, [x29, #-24]
	ldr	x9, [x9, #32]
	subs	x8, x8, x9
	b.ne	LBB220_4
	b	LBB220_3
LBB220_3:
	ldur	x8, [x29, #-16]
	ldrh	w8, [x8, #16]
	ldur	x9, [x29, #-24]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.eq	LBB220_5
	b	LBB220_4
LBB220_4:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB220_12
LBB220_5:
	sturh	wzr, [x29, #-26]
	b	LBB220_6
LBB220_6:                               ; =>This Inner Loop Header: Depth=1
	ldurh	w8, [x29, #-26]
	ldur	x9, [x29, #-16]
	ldrh	w9, [x9, #16]
	subs	w8, w8, w9
	b.ge	LBB220_11
	b	LBB220_7
LBB220_7:                               ;   in Loop: Header=BB220_6 Depth=1
	ldur	x8, [x29, #-16]
	add	x11, x8, #44
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
	mov	x9, #56                         ; =0x38
	mov	x10, x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x1, w8, w10, x11
	ldur	x8, [x29, #-24]
	add	x10, x8, #44
	ldurh	w8, [x29, #-26]
                                        ; kill: def $x8 killed $w8
                                        ; kill: def $w9 killed $w9 killed $x9
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w9, x10
	str	x8, [sp]                        ; 8-byte Folded Spill
	sub	x0, x29, #84
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x1, [sp]                        ; 8-byte Folded Reload
	ldr	x2, [sp, #8]                    ; 8-byte Folded Reload
	add	x0, sp, #36
	str	x0, [sp, #24]                   ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	bl	_obligation_same
	tbnz	w0, #0, LBB220_9
	b	LBB220_8
LBB220_8:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB220_12
LBB220_9:                               ;   in Loop: Header=BB220_6 Depth=1
	b	LBB220_10
LBB220_10:                              ;   in Loop: Header=BB220_6 Depth=1
	ldurh	w8, [x29, #-26]
	add	w8, w8, #1
	sturh	w8, [x29, #-26]
	b	LBB220_6
LBB220_11:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-1]
	b	LBB220_12
LBB220_12:
	ldurb	w8, [x29, #-1]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_fact
_file_ih_fact:                          ; @file_ih_fact
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #336
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	sub	x8, x29, #152
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	str	x0, [x8, #120]
	stur	w1, [x29, #-36]
	sturh	w2, [x29, #-38]
	str	x3, [x8, #104]
	str	x4, [x8, #96]
	ldr	x9, [x8, #120]
	ldr	x9, [x9]
	ldr	x9, [x9, #8]
	str	x9, [x8, #88]
	ldr	x8, [x8, #104]
	ldrb	w0, [x8, #8]
	bl	_isa_is_file_indirect_call
	tbnz	w0, #0, LBB221_2
	b	LBB221_1
LBB221_1:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x0, [x8, #88]
	ldr	x1, [x8, #104]
	ldr	x2, [x8, #96]
	bl	_file_ch_fact
	and	w8, w0, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_2:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #96]
	add	x9, x9, #20
	str	x9, [x8, #80]
	ldr	x9, [x8, #120]
	add	x9, x9, #8
	ldr	x10, [x8, #88]
	ldr	x10, [x10]
	add	x10, x10, #2352
	ldur	w11, [x29, #-36]
                                        ; kill: def $x11 killed $w11
	ldr	w10, [x10, x11, lsl #2]
	ldurh	w11, [x29, #-38]
	add	w10, w10, w11
	ldr	x9, [x9, w10, uxtw #3]
	str	x9, [x8, #72]
	ldr	x8, [x8, #72]
	cbz	x8, LBB221_14
	b	LBB221_3
LBB221_3:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrb	w8, [x8]
	tbz	w8, #0, LBB221_14
	b	LBB221_4
LBB221_4:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldr	w8, [x8, #12]
	subs	w8, w8, #5
	b.ne	LBB221_14
	b	LBB221_5
LBB221_5:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrh	w8, [x8, #8]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.ne	LBB221_14
	b	LBB221_6
LBB221_6:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrb	w8, [x8, #2]
	tbnz	w8, #0, LBB221_14
	b	LBB221_7
LBB221_7:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrb	w8, [x8, #1]
	tbnz	w8, #0, LBB221_14
	b	LBB221_8
LBB221_8:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrb	w8, [x8, #3]
	tbz	w8, #0, LBB221_14
	b	LBB221_9
LBB221_9:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #80]
	ldrh	w8, [x8, #4]
	ldr	x9, [x9, #96]
	ldrh	w9, [x9, #2]
	subs	w8, w8, w9
	b.ne	LBB221_14
	b	LBB221_10
LBB221_10:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #80]
	ldrh	w8, [x8, #6]
	ldr	x9, [x9, #96]
	ldrh	w9, [x9, #12]
	subs	w8, w8, w9
	b.ne	LBB221_14
	b	LBB221_11
LBB221_11:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldrh	w8, [x8, #4]
	cbz	w8, LBB221_14
	b	LBB221_12
LBB221_12:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldr	w8, [x8, #16]
	subs	w8, w8, #64
	b.ne	LBB221_14
	b	LBB221_13
LBB221_13:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	ldr	w8, [x8, #20]
	subs	w8, w8, #384
	b.eq	LBB221_15
	b	LBB221_14
LBB221_14:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_15:
	stur	wzr, [x29, #-84]
	b	LBB221_16
LBB221_16:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB221_19 Depth 2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldur	w8, [x29, #-84]
	ldr	x9, [x9, #88]
	ldr	x9, [x9]
	ldr	w9, [x9, #24]
	subs	w8, w8, w9
	b.hs	LBB221_37
	b	LBB221_17
LBB221_17:                              ;   in Loop: Header=BB221_16 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #72]
	ldur	w9, [x29, #-84]
	mov	x10, x9
	mov	x9, #1                          ; =0x1
	lsl	x9, x9, x10
	and	x8, x8, x9
	cbz	x8, LBB221_35
	b	LBB221_18
LBB221_18:                              ;   in Loop: Header=BB221_16 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #88]
	ldr	x8, [x8]
	add	x11, x8, #48
	ldur	w8, [x29, #-84]
                                        ; kill: def $x8 killed $w8
	mov	x10, #36                        ; =0x24
                                        ; kill: def $w10 killed $w10 killed $x10
                                        ; kill: def $w8 killed $w8 killed $x8
	umaddl	x8, w8, w10, x11
	add	x8, x8, #12
	str	x8, [x9, #56]
	sub	x0, x29, #152
	mov	x2, #56                         ; =0x38
	mov	w1, #0                          ; =0x0
	bl	_memset
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	mov	w9, #1                          ; =0x1
	stur	w9, [x29, #-152]
	ldr	x9, [x8, #104]
	ldr	w9, [x9]
	stur	w9, [x29, #-148]
	mov	w9, #-1                         ; =0xffffffff
	stur	w9, [x29, #-144]
	ldr	x9, [x8, #56]
	ldrh	w9, [x9]
	sturh	w9, [x29, #-128]
	ldr	x9, [x8, #56]
	ldrb	w9, [x9, #4]
	sturb	w9, [x29, #-122]
	ldr	x9, [x8, #56]
	ldur	q0, [x9, #8]
	str	q0, [x8, #32]
	mov	w8, #448                        ; =0x1c0
	stur	w8, [x29, #-140]
	sturh	wzr, [x29, #-154]
	b	LBB221_19
LBB221_19:                              ;   Parent Loop BB221_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldurh	w8, [x29, #-154]
	ldr	x9, [x9, #56]
	ldrh	w9, [x9]
	subs	w8, w8, w9
	b.ge	LBB221_32
	b	LBB221_20
LBB221_20:                              ;   in Loop: Header=BB221_19 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #120]
	ldr	x0, [x8]
	ldur	w1, [x29, #-84]
	ldurh	w2, [x29, #-154]
	add	x3, sp, #148
	bl	_nvm_file_indirect_flow_local
	tbnz	w0, #0, LBB221_22
	b	LBB221_21
LBB221_21:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_22:                              ;   in Loop: Header=BB221_19 Depth=2
	ldrb	w8, [sp, #149]
	cbz	w8, LBB221_25
	b	LBB221_23
LBB221_23:                              ;   in Loop: Header=BB221_19 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #104]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #152
	b.eq	LBB221_25
	b	LBB221_24
LBB221_24:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_25:                              ;   in Loop: Header=BB221_19 Depth=2
	ldrb	w8, [sp, #149]
	cbz	w8, LBB221_27
	b	LBB221_26
LBB221_26:                              ;   in Loop: Header=BB221_19 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #104]
	add	x8, x8, #78
	ldurh	w9, [x29, #-154]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	subs	w8, w8, #256
	b.hs	LBB221_29
	b	LBB221_30
LBB221_27:                              ;   in Loop: Header=BB221_19 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #104]
	ldrb	w8, [x8, #8]
	subs	w8, w8, #152
	b.ne	LBB221_30
	b	LBB221_28
LBB221_28:                              ;   in Loop: Header=BB221_19 Depth=2
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #104]
	add	x8, x8, #78
	ldurh	w9, [x29, #-154]
                                        ; kill: def $x9 killed $w9
	ldrh	w8, [x8, x9, lsl #1]
	mov	w9, #65535                      ; =0xffff
	subs	w8, w8, w9
	b.eq	LBB221_30
	b	LBB221_29
LBB221_29:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_30:                              ;   in Loop: Header=BB221_19 Depth=2
	ldrb	w9, [sp, #149]
	ldurh	w8, [x29, #-124]
	subs	w9, w9, #0
	cinc	w8, w8, ne
	sturh	w8, [x29, #-124]
	ldur	x0, [sp, #148]
	ldur	x1, [sp, #156]
	bl	_owned
	ldurh	w8, [x29, #-126]
	add	w8, w8, w0
	sturh	w8, [x29, #-126]
	b	LBB221_31
LBB221_31:                              ;   in Loop: Header=BB221_19 Depth=2
	ldurh	w8, [x29, #-154]
	add	w8, w8, #1
	sturh	w8, [x29, #-154]
	b	LBB221_19
LBB221_32:                              ;   in Loop: Header=BB221_16 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #80]
	add	x1, x8, #24
	add	x0, sp, #92
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	x2, #56                         ; =0x38
	str	x2, [sp]                        ; 8-byte Folded Spill
	bl	_memcpy
	ldr	x2, [sp]                        ; 8-byte Folded Reload
	add	x0, sp, #36
	str	x0, [sp, #16]                   ; 8-byte Folded Spill
	sub	x1, x29, #152
	bl	_memcpy
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	bl	_obligation_same
	tbnz	w0, #0, LBB221_34
	b	LBB221_33
LBB221_33:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_34:                              ;   in Loop: Header=BB221_16 Depth=1
	b	LBB221_35
LBB221_35:                              ;   in Loop: Header=BB221_16 Depth=1
	b	LBB221_36
LBB221_36:                              ;   in Loop: Header=BB221_16 Depth=1
	ldur	w8, [x29, #-84]
	add	w8, w8, #1
	stur	w8, [x29, #-84]
	b	LBB221_16
LBB221_37:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-17]
	b	LBB221_38
LBB221_38:
	ldurb	w8, [x29, #-17]
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function file_ih_peak
_file_ih_peak:                          ; @file_ih_peak
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	stur	x8, [x29, #-8]
	stur	x1, [x29, #-24]
	stur	x2, [x29, #-16]
	ldur	x8, [x29, #-24]
	str	x8, [sp, #24]
	ldurh	w8, [x29, #-16]
	strh	w8, [sp, #32]
	str	x0, [sp, #16]
	ldrh	w8, [sp, #24]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #40]
	subs	w8, w8, w9
	b.ne	LBB222_5
	b	LBB222_1
LBB222_1:
	ldrh	w8, [sp, #26]
	subs	w8, w8, #256
	b.hi	LBB222_5
	b	LBB222_2
LBB222_2:
	ldrh	w8, [sp, #30]
	subs	w8, w8, #256
	b.hi	LBB222_5
	b	LBB222_3
LBB222_3:
	ldrh	w8, [sp, #32]
	subs	w8, w8, #256
	b.hi	LBB222_5
	b	LBB222_4
LBB222_4:
	ldrh	w8, [sp, #28]
	subs	w8, w8, #256
	b.ls	LBB222_6
	b	LBB222_5
LBB222_5:
	mov	w8, #0                          ; =0x0
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB222_15
LBB222_6:
	ldrh	w8, [sp, #26]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #38]
	subs	w8, w8, w9
	b.le	LBB222_8
	b	LBB222_7
LBB222_7:
	ldrh	w8, [sp, #26]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #38]
	b	LBB222_8
LBB222_8:
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #46]
	subs	w8, w8, w9
	b.le	LBB222_10
	b	LBB222_9
LBB222_9:
	ldrh	w8, [sp, #30]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #46]
	b	LBB222_10
LBB222_10:
	ldrh	w8, [sp, #32]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #48]
	subs	w8, w8, w9
	b.le	LBB222_12
	b	LBB222_11
LBB222_11:
	ldrh	w8, [sp, #32]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #48]
	b	LBB222_12
LBB222_12:
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #16]
	ldrh	w9, [x9, #50]
	subs	w8, w8, w9
	b.le	LBB222_14
	b	LBB222_13
LBB222_13:
	ldrh	w8, [sp, #28]
	ldr	x9, [sp, #16]
	strh	w8, [x9, #50]
	b	LBB222_14
LBB222_14:
	mov	w8, #1                          ; =0x1
	and	w8, w8, #0x1
	and	w8, w8, #0x1
	sturb	w8, [x29, #-25]
	b	LBB222_15
LBB222_15:
	ldurb	w8, [x29, #-25]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	ldur	x9, [x29, #-8]
	adrp	x8, ___stack_chk_guard@GOTPAGE
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
	ldr	x8, [x8]
	subs	x8, x8, x9
	b.eq	LBB222_17
	b	LBB222_16
LBB222_16:
	bl	___stack_chk_fail
LBB222_17:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	and	w0, w8, #0x1
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"nsi:core/int"

l_.str.1:                               ; @.str.1
	.asciz	"nsi:core/bool"

l_.str.2:                               ; @.str.2
	.asciz	"nsi:core/string"

l_.str.3:                               ; @.str.3
	.asciz	"__init__"

l_.str.4:                               ; @.str.4
	.asciz	"I found invalid callable target facts."

l_.str.5:                               ; @.str.5
	.asciz	"I describe exact targets without File execution authority."

l_.str.6:                               ; @.str.6
	.asciz	"I cannot resolve this complete callable target contract."

l_.str.7:                               ; @.str.7
	.asciz	"I reached my bounded target-query limit."

l_.str.8:                               ; @.str.8
	.asciz	"I could not allocate the target-query staging."

.subsections_via_symbols
